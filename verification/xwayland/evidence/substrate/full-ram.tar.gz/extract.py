from pathlib import Path
import json,sys
from sparse_ram import reconstruct,portable
root=Path(__file__).resolve().parent
out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
for name,spec in json.loads((root/'captures.json').read_text()).items():reconstruct(spec,root/'blocks',out/portable(name))
