"""Lossless, content-addressed 64 KiB blocks for full-length QMP memory captures."""
import hashlib
from pathlib import Path
import re

BLOCK = 1 << 16
ZERO = bytes(BLOCK)


def require(ok,message):
    if not ok:
        raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for buf in iter(lambda: stream.read(1 << 20),b""):
            h.update(buf)
    return h.hexdigest()


def portable(name):
    path = Path(name)
    require(name and not path.is_absolute() and ".." not in path.parts and "\\" not in name
            and path.as_posix()==name and ":" not in name, f"unsafe evidence path {name!r}")
    return path


def encode(path,blobs):
    require(path.is_file() and not path.is_symlink(),f"not a regular capture {path}")
    blobs.mkdir(parents=True,exist_ok=True)
    h, records, size = hashlib.sha256(),[],0
    with path.open("rb") as src:
        for chunk in iter(lambda: src.read(BLOCK),b""):
            h.update(chunk)
            if chunk != ZERO[:len(chunk)]:
                blob = hashlib.sha256(chunk).hexdigest()
                target = blobs/blob
                if not target.exists():
                    with target.open("xb") as dst:
                        dst.write(chunk)
                records.append([size//BLOCK,blob])
            size += len(chunk)
    require(path.stat().st_size==size,"RAM capture changed while reading")
    return {"size":size,"sha256":h.hexdigest(),"blocks":records}


def reconstruct(spec,blobs,dest):
    """Verify every source block and all reconstructed bytes, including every hole."""
    size=spec["size"]
    require(isinstance(size,int) and size>=0,"invalid full capture length")
    dest.parent.mkdir(parents=True,exist_ok=True)
    prev=-1
    with dest.open("xb") as out:
        for index,blob in spec["blocks"]:
            require(isinstance(index,int) and prev<index and index*BLOCK<size and
                    re.fullmatch("[a-f0-9]{64}",blob),"invalid or duplicate sparse RAM extent")
            src=blobs/blob
            require(src.is_file() and not src.is_symlink(),"missing captured memory block")
            chunk=src.read_bytes()
            require(len(chunk)==min(BLOCK,size-index*BLOCK) and hashlib.sha256(chunk).hexdigest()==blob,
                    f"bad captured memory block {blob}")
            out.seek(index*BLOCK)
            out.write(chunk)
            prev=index
        out.truncate(size)
    require(dest.stat().st_size==size and digest(dest)==spec["sha256"],f"full RAM reconstruction digest {dest}")
