"""Read-only ELF symbols and AArch64 virt TTBR0 walks for the frozen JNOX fixtures."""
from contextlib import contextmanager
import gzip
import hashlib
import json
import mmap
import struct

BASE = 0x40000000
PAGE = 4096
MASK = (1 << 48) - PAGE
END = (1 << 64) - 1
SOURCE = "5cc4884a292fb45844b53e80d4db0766def4ebfe"
BROKER = "2214dbd7306cbe8154d5e22e6ce6272dee21226f1c0bcbf43ca69bb7dcfb0e62"
FROZEN_KERNELS = {
    "baseline": "416b825b712c15978ddf1369c779fa373c16c4903ee1743b7d4892635d89d60f",
    "default": "9de2a93a6251c1f1b058357792d9b2b5f4ed97972769270afee9f5eec0d1bd9d",
    "cloexec": "180958eb8474eefc24419bc750cf31e83de304356e24652e0ba981fc97dc6f9a",
    "poll": "ed364b9f79d04f7c52de7e71ac77a8047af9e6a2d936bc6bd32f4f3457e40938",
}


def check(ok, label):
    if not ok:
        raise ValueError(label)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def q(data, at=0):
    return struct.unpack_from("<Q", data, at)[0]


class ELF:
    def __init__(self, path):
        self.data = data = path.read_bytes()
        check(data[:6] == b"\x7fELF\x02\x01" and data[18:20] == b"\xb7\x00", "AArch64 ELF64")
        sections = [struct.unpack_from("<II4QII2Q", data, q(data, 40) + i * 64)
                    for i in range(struct.unpack_from("<H", data, 60)[0])]
        self.symbols = {}
        for sec in sections:
            if sec[1] != 2:
                continue
            strings = sections[sec[6]][4]
            for at in range(sec[4], sec[4] + sec[5], sec[9]):
                name, _, _, shndx, addr, size = struct.unpack_from("<IBBHQQ", data, at)
                if shndx and name and size:
                    name = data[strings + name:data.index(b"\0", strings + name)].decode()
                    self.symbols[name] = (addr, size)
        self.entry = q(data, 24)
        self.code = None
        count = struct.unpack_from("<H", data, 56)[0]
        for i in range(count):
            kind, flags, off, va, _, size, _, _ = struct.unpack_from("<II6Q", data, q(data, 32) + i*56)
            if kind == 1 and flags & 1 and va <= self.entry < va + size - 31:
                start = off + self.entry - va
                self.code = data[start:start+32]

    def sym(self, fragment, size=None):
        found = [v for k, v in self.symbols.items() if fragment in k]
        check(len(found) == 1 and (size is None or found[0][1] == size), "ELF symbol layout " + fragment)
        return found[0][0]


class Package:
    def __init__(self, pkg, count, source=SOURCE):
        m = json.loads((pkg / "manifest.json").read_bytes())
        check(m["commit"] == source and m["policy"] == "fifo", "source and fixed FIFO policy")
        self.kernel = kernel = ELF(pkg / "kernel.elf")
        self.kernel_hash = sha(kernel.data)
        check(self.kernel_hash == m["kernel_elf_sha256"], "kernel ELF identity")
        kspace = [p for n, p in kernel.symbols.items() if "native_el0_mmu" in n and "6SPACES" in n]
        check(len(kspace) == 1 and len(m["slots"]) == count, "MMU root count")
        start, size = kspace[0]
        check(size % (count*PAGE) == 0 and start % PAGE == 0, "root extent")
        self.roots = [start + i*(size//count) for i in range(count)]
        self.elf = []
        self.ids = []
        self.priorities = []
        for i, slot in enumerate(m["slots"]):
            elf = ELF(pkg / slot["elf"])
            digest = sha(elf.data)
            check(slot["slot"] == i, "linked slot")
            if count == 4 or "expected_ttbr0_el1" in slot:
                check(slot["expected_ttbr0_el1"] == (self.roots[i] | ((i+1)<<48)), "manifest TTBR0")
            check(digest == slot["elf_sha256"] and elf.data in kernel.data, "embedded role identity")
            self.elf.append(elf)
            self.ids.append(digest)
            self.priorities.append(slot["priority"])
        check(self.ids[-1] == BROKER and len(set(self.ids[:-1])) == 1, "exact broker layout and application")

    def verify_live(self, ram):
        for root, role in zip(self.roots, self.elf):
            entry = ram.leaf(root, role.entry)
            check(entry and entry[1:] == (True,False,False,True) and
                  ram.user(root, role.entry, 32) == role.code, "EL0 entry bytes and permissions")


class RAM:
    def __init__(self, data):
        check(len(data) == 128 << 20, "128 MiB stopped physical RAM")
        self.data = data
        self.flips = {}

    def read(self, pa, n):
        off = pa - BASE
        check(0 <= off <= len(self.data)-n, "physical read range")
        raw = self.data[off:off+n]
        if self.flips:
            raw = bytearray(raw)
            for address, mask in self.flips.items():
                if pa <= address < pa+n:
                    raw[address-pa] ^= mask
        return bytes(raw)

    def leaf(self, root, va, *, pte=False):
        """Walk three 4 KiB levels, including hierarchical AP/XN and optional block leaves."""
        check(0 <= va < 1 << 39, "TTBR0 address range")
        table, user, writable, xn = root, True, True, False
        for shift in (30, 21, 12):
            at = table + 8*((va >> shift) & 511)
            desc = q(self.read(at, 8))
            if not desc & 1:
                return None
            if shift > 12 and desc & 2:
                table = desc & MASK
                user &= not bool(desc & (1 << 61))
                writable &= not bool(desc & (1 << 62))
                xn |= bool(desc & (1 << 60))
            else:
                check(shift != 12 or desc & 2, "reserved L3 descriptor")
                low = (1 << shift) - 1
                if pte:
                    return at
                return ((desc & MASK & ~low) | (va & low), user and bool(desc & 64),
                        writable and not bool(desc & 128), xn or bool(desc & (1 << 54)),
                        bool(desc & 1024))

    def user(self, root, va, n):
        parts = bytearray()
        while len(parts) < n:
            off = va + len(parts)
            leaf = self.leaf(root, off)
            check(leaf and leaf[1] and leaf[4], "EL0 memory accessibility")
            parts.extend(self.read(leaf[0], min(n-len(parts), PAGE-off%PAGE)))
        return bytes(parts)

    def aliases(self, root, start, end):
        result = {}
        def walk(table, shift, prefix):
            for i, (desc,) in enumerate(struct.iter_unpack("<Q", self.read(table, PAGE))):
                if not desc & 1:
                    continue
                va = prefix + (i << shift)
                if shift > 12 and desc & 2:
                    if not desc & (1 << 61):
                        walk(desc & MASK, shift-9, va)
                    continue
                if not desc & 64:
                    continue
                pa = desc & MASK & ~((1 << shift) - 1)
                for addr in range(max(start,pa), min(end,pa+(1<<shift)), PAGE):
                    alias = va+addr-pa
                    result[alias] = self.leaf(root, alias)
        walk(root, 30, 0)
        return result


@contextmanager
def stopped(path):
    if path.suffix == ".gz":
        with gzip.open(path, "rb") as f:
            yield RAM(f.read())
    else:
        with path.open("rb") as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as buf:
            yield RAM(buf)


def control(ram, address, mask, operation, reason):
    check(not ram.flips, "overlapping control")
    ram.flips[address] = mask
    try:
        operation()
    except ValueError as exc:
        check(str(exc) == reason, f"wrong control rejection at {address:#x}: {exc}")
        return reason
    finally:
        ram.flips.clear()
    raise ValueError("accepted altered " + reason)
