"""Inspect a poller's saved EL0 frame, kernel IPC request, broker and FIFO journal."""
import json
import re
import struct
from physical import END, FROZEN_KERNELS, Package, check, control, q, stopped
from transfer import BANK

OBSERVED = "f9db3c1be87db520aaf4357e733105694ecad90c"


def role_exits(pkg, boot, expected):
    uart = (boot/"uart.bin").read_bytes()
    exits = [(int(a),int(b)) for a,b in re.findall(rb"(?m)^NATIVE EL0 EXIT PID (\d+) (-?\d+)\r?$",uart)]
    check(sorted(exits) == list(enumerate(expected)), "exact UART role exits")
    for i, h in enumerate(pkg.ids):
        title = ["ELF","PEER ELF","PEER2 ELF","PEER3 ELF"][i]
        check(b"NATIVE EL0 "+title.encode()+b" "+h.encode() in uart.splitlines(), "UART linked role identity")
    return uart


def journal(pkg, ram, uart):
    lines = re.findall(rb"(?m)^NATIVE FIXED EVENT ([0-9 ]+)\r?$", uart)
    rows = [list(map(int,s.split())) for s in lines]
    sizes = 21
    start = pkg.kernel.sym("9DECISIONS", 128*sizes*8)
    counts = re.findall(rb"(?m)^NATIVE FIXED DROPPED (\d+)\r?$",uart)
    check(0 < len(rows) <= 128 and len(counts) == 1 and all(len(r) == sizes for r in rows), "bounded journal")
    check(ram.read(start,len(rows)*sizes*8) == b"".join(struct.pack("<21Q",*r) for r in rows),
          "physical scheduler decisions match UART")
    priorities = pkg.priorities
    check(priorities == [7,4,1], "FIFO priorities")
    witnesses, broker_above_base = [], []
    for i,row in enumerate(rows):
        check(i == 0 or rows[i-1][4] == row[3] and rows[i-1][0] <= row[0], "scheduler chain")
        next_pid = row[4]
        ready = [v for v in row[12:15] if v != END]
        check(all(v < 3 for v in ready) and len(set(ready)) == len(ready) and next_pid not in ready,
              "distinct runnable slots")
        check(not any(row[18:21]) and (not ready or next_pid < 3), "FIFO budgets, non-idle dispatch")
        if ready and priorities[next_pid] < max(priorities[v] for v in ready):
            check(next_pid == 2, "dispatch above base priority confined to broker")
            broker_above_base.append(i)
        if next_pid < 3 and ready:
            witnesses.append([i,next_pid,ready])
    check(witnesses, "priority competition in captured rows")
    poll_start, poll_len = pkg.elf[0].symbols["poll"]
    calls = []
    for i,row in enumerate(rows):
        if row[3] != 0 or row[1] != 21 or not poll_start <= row[5]-4 < poll_start+poll_len:
            continue
        completion = next(((j,r) for j,r in enumerate(rows[i+1:], i+1) if r[4] == 0), None)
        joined = None
        if completion:
            j,done = completion
            check(done[7:9] == row[5:7], "resume same poll return PC and stack")
            joined = dict(row=j,tick=done[0],cause=done[1],previous=done[3],wake=done[9],
                          programmed_compare=done[11])
        calls.append(dict(row=i,tick=row[0],pc=row[5],sp=row[6],selected=row[4],resume=joined))
    return dict(count=len(rows),dropped=int(counts[0]),priorities=priorities,
                competing_selections=len(witnesses),first_competition=witnesses[0],
                broker_chosen_over_higher_base_priority=len(broker_above_base),poll_calls=calls)


def stock(build):
    p = Package(build/"poll-package",3)
    check(p.kernel_hash == FROZEN_KERNELS["poll"], "frozen stock poll kernel")
    boot = build/"campaign-01"/"poll"
    uart = role_exits(p,boot,[71,72,0])
    check(json.loads((boot/"launch.json").read_bytes())["kernel"] == p.kernel_hash, "stock launch kernel")
    with stopped(boot/"terminal.ram.gz") as ram:
        p.verify_live(ram)
        addr = p.elf[0].sym("poll_probe",128)
        start,end,byte,*rest = struct.unpack("<16Q",ram.user(p.roots[0],addr,128))
        check(end-start >= 20_000_000 and start > 0 and byte == 120 and not any(rest), "stock poll elapsed and byte")
        return dict(kernel=p.kernel_hash, poller=p.ids[0], broker=p.ids[-1],
                    elapsed_ns=end-start, byte=byte, journal=journal(p,ram,uart))


def blocked(p, ram, stage):
    idx = {"timeout-pending":1,"data-pending":3,"hangup-pending":4}[stage]
    proc,broker = p.elf[0],p.elf[2]
    base = proc.sym("poll_rows",6*9*8)
    fields = struct.unpack("<9Q",ram.user(p.roots[0],base+72*idx,72))
    fd0,e0,fd1,e1 = fields[1],fields[2],fields[4],fields[5]
    check(64 <= fd0 < 68 and 64 <= fd1 < 68 and fd0 != fd1 and e0 == 1 and
          e1 == (0 if idx == 4 else 1) and fields[7] > 0 and fields[8] == 0, "pending poll descriptor identities")
    word = (0x17<<56) | ((128|e0) << (8*(fd0-64))) | ((128|e1) << (8*(fd1-64)))
    slot = ram.read(p.kernel.sym("9ENDPOINTS"),88)
    server,w,deadline,token = struct.unpack_from("<4Q",slot)
    check(server == 2 and slot[32] == 1 and w == word and token, "delivered OP_POLL in PID0 kernel slot")
    check((fields[7] < deadline < END) if idx == 1 else deadline == END, "finite vs indefinite kernel deadline")
    client = ram.user(p.roots[2],broker.sym("CLIENT_STATE",3*288),288)
    pt,held,wt,held_word = struct.unpack_from("<4Q",client)
    check((pt,held,wt,held_word) == (1,token,1,word), "broker PID0 owns matching pending token and poll word")
    frame = ram.read(p.kernel.sym("6FRAMES",3*832),832)
    pc,sp = q(frame,264),q(frame,272)
    proc_poll,extent = proc.symbols["poll"]
    svc = struct.unpack("<I",ram.user(p.roots[0],pc-4,4))[0]
    check(q(frame,8*8) == 21 and proc_poll <= pc-4 < proc_poll+extent and
          svc == 0xd4000001 | (0x4a01 << 5), "saved PID0 EL0 poll syscall instruction")
    table = broker.sym("5BANKS",BANK*2)
    sock_ids, rings = [], []
    for i in range(2):
        bank = ram.user(p.roots[2],table+i*BANK,BANK)
        pair=[]
        for fd in (fd0,fd1):
            tag,ident = struct.unpack_from("<2Q",bank,4160+16*(fd-64))
            check(tag == 1 and ident < 8 and bank[ident*520+515] == 1, "broker socket FD binding")
            pair.append(ident)
        check(pair[0] != pair[1], "distinct listener and accepted stream")
        off = pair[1]*520
        head,count = struct.unpack_from("<2Q",bank,off+160)
        check(count == 0 and head in range(64), "accepted socket empty during pending poll")
        rings.append((head, bank[off+96+((head-1)%64)]))
        sock_ids.append(pair)
    check(sock_ids[0] == sock_ids[1], "both banks agree on sock identities")
    check(rings[0] == rings[1] and (idx != 4 or rings[0] == (1,120)), "consumed x in same accepted socket ring")
    return dict(fds=[fd0,fd1],interests=[e0,e1],word=hex(word),token=token,deadline=deadline,
                entered_ns=fields[7],slots=sock_ids[0],ring_head_and_preceding_byte=rings[0],
                saved_pc=pc,saved_sp=sp)


def enhanced(build):
    p = Package(build/"package",3,OBSERVED)
    check(p.kernel_hash == "009361d1954609f805fa9c668317e5f9a0dac7a53953d2cbb667e61d6e5a0a64",
          "frozen supplemental kernel")
    boot = build/"cold-1"
    uart = role_exits(p,boot,[71,72,0])
    check(json.loads((boot/"launch.json").read_bytes())["kernel"] == p.kernel_hash,"supplement launch kernel")
    phases,controls = {},[]
    for stage in ("timeout-pending","data-pending","hangup-pending"):
        with stopped(boot/(stage+".ram.gz")) as ram:
            p.verify_live(ram)
            run = lambda: blocked(p,ram,stage)
            phases[stage] = run()
            client = p.elf[2].sym("CLIENT_STATE",3*288)
            for addr,reason in [(p.kernel.sym("9ENDPOINTS")+8,"delivered OP_POLL in PID0 kernel slot"),
                                (ram.leaf(p.roots[2],client+8)[0],"broker PID0 owns matching pending token and poll word")]:
                controls.append(control(ram,addr,1,run,reason))
    with stopped(boot/"terminal.ram.gz") as ram:
        p.verify_live(ram)
        proc = p.elf[0]
        rows = list(struct.iter_unpack("<9q",ram.user(p.roots[0],proc.sym("poll_rows",432),432)))
        ios = [struct.unpack("<12q",ram.user(r,proc.sym("poll_io",96),96)) for r in p.roots[:2]]
        p0,p1 = ios
        byte = q(ram.user(p.roots[0],proc.sym("poll_probe",128)+16,8))
        f0,f1 = phases["timeout-pending"]["fds"]
        wants = [(1,f0,1,1,-1,1,0),(0,f0,1,0,f1,1,0),(1,f0,1,0,f1,4,4),
                 (1,f0,1,0,f1,1,1),(1,f0,1,0,f1,0,16),(1,f0,1,0,f1,0,32)]
        check([r[:7] for r in rows] == wants,"per-descriptor poll returns")
        check(all(a[8] <= b[7] for a,b in zip(rows,rows[1:])) and all(r[7] <= r[8] for r in rows),
              "poll invocation chronology")
        finite,data,hup = [phases[s] for s in ("timeout-pending","data-pending","hangup-pending")]
        check(finite["entered_ns"] == rows[1][7] and rows[1][7]+1_500_000_000 <= finite["deadline"] <= rows[1][8],
              "expired actual poll deadline")
        check(data["entered_ns"] == rows[3][7] and hup["entered_ns"] == rows[4][7] and
              len({s["token"] for s in phases.values()}) == 3, "separate pending calls")
        check(p0[:3] == (f1,0,33) and rows[4][8] <= p0[3] <= rows[5][7] and byte == 120,
              "same-FD EOF return, sentinel and byte")
        check(p1[2] == 1 and p1[5] == 0 and p1[1] < p1[3] <= p1[4] < p1[6] and
              p1[0] in range(64,68) and p1[1] < rows[3][8] and p1[4] < rows[4][8],
              "peer transfer and close chronology")
        return dict(kernel=p.kernel_hash, application=p.ids[0], phases=phases, returned_rows=rows,
                    server_io=p0,peer_io=p1,byte=byte, journal=journal(p,ram,uart),
                    rejected_controls=controls)
