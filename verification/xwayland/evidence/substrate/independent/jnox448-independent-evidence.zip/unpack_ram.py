"""Reconstruct the original 36 complete physical images from verified content-addressed blocks."""
import hashlib
import json
from pathlib import Path
import tarfile


def checked(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for data in iter(lambda: f.read(1<<20), b""):
            h.update(data)
    return h.hexdigest()


def main():
    root = Path(__file__).resolve().parent
    base = root/"build"/"campaign-01"
    stages = ("pretimeout","queued","installed","before","after","terminal")
    names = {f"{v}/{b}/{s}.ram" for v in ("baseline","default","cloexec")
             for b in ("cold-1","cold-2") for s in stages}
    with tarfile.open(root/"full-ram.tar.gz", "r:gz") as tar:
        ledger = json.load(tar.extractfile("captures.json"))
        checked(set(ledger) == names, "expected 36 stopped images")
        stored = {}
        for m in tar.getmembers():
            if m.isfile() and m.name.startswith("blocks/"):
                data = tar.extractfile(m).read()
                key = hashlib.sha256(data).hexdigest()
                checked(m.name == "blocks/"+key and len(data) == 65536, "captured block checksum")
                stored[key] = data
    for name, spec in sorted(ledger.items()):
        path = base/name
        checked(spec["size"] == 128<<20, "full RAM size")
        if not path.exists():
            with path.open("xb") as out:
                previous = -1
                for index, key in spec["blocks"]:
                    checked(previous < index < 2048, "block index order")
                    out.seek(index*65536)
                    out.write(stored[key])
                    previous = index
                out.truncate(spec["size"])
        checked(path.stat().st_size == spec["size"] and digest(path) == spec["sha256"], name)
    print("Verified 36 complete reconstructed 128 MiB RAM images.")


if __name__ == "__main__":
    main()
