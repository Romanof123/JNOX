# JNOX 448 frozen memory reader

Run these commands from this directory with Python 3.8 or later. The reader uses only the Python standard library. It opens raw files read-only. Negative controls change a private read overlay in the decoder process.

```sh
build="$HOME/jnox406-lab/448-build-02"
for mode in poll baseline default cloexec; do
    python3 -B review.py "$build" "$mode" > "$mode.json" || break
done
python3 -B review.py "$HOME/jnox406-lab/448-poll-eof-01" observed > observed.json
```

The path layout comes from the frozen package and campaign directories. Each four-process transfer boot needs the six original RAM files, both P6 screendumps, raw UART, QMP event log and linked ELF package. The stock and extended three-process poll captures use gzip-compressed full RAM. Checks bind the linked AArch64 kernel and its embedded process images to their manifest, linked TTBR0 roots, captured UART and QMP launch. Source revisions and the exact broker image identity are pinned in the reader.

For transfer, PID 0 receives the descriptor and PID 1 produces pixels. The reader follows PID 0’s broker descriptor in both transactional state banks. At a stop their agreement on the queue and ancillary marker makes the current bank selector immaterial. The kernel’s escrow token names the right attached to the first byte of the ancillary message. Protected object IDs are one-based in descriptors and zero-based in mapping records. Cloexec has meaning only while the associated descriptor is live. The transfer report includes the unused flag storage after exit so the cleanup result can be interpreted correctly.

The poll journal records scheduling decisions and the interrupted and resumed user program counters. The event rows include retained ready queues and times to program the hardware timer. The fixed-priority policy, IPC deadlines and expiration results have separate fields in the report. The original poll image receives one data byte. Its source checks hangup and invalid descriptor masks. The distinct extended image includes the EOF syscall, captures three live waits, and writes each pair of returned pollfd entries into ordinary private memory.

A snapshot after receipt establishes FD98 and its close-on-exec bit at that stop. The single protected INSTALL callback is the source evidence for atomic installation. The cancellation fixture blocks on an empty stream. After timeout the complete later prefix and right remain queued under a distinct token, with FD98 still free. The four-process EOF occurs on a separate socket when another guest exits.
