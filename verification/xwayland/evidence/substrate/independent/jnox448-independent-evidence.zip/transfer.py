"""Decode actual protected rights, broker stream ring, hardware translations and QMP pixels."""
import struct

from physical import END, PAGE, FROZEN_KERNELS, Package, check, control, q, sha, stopped

SIZE = 320 * 240 * 4
WINDOW = 0x2000000
STRIDE = 0x80000
BANK = 4544
SOCKET = 520
HEADER = b"P6\n320 240\n255\n"


class Transfer:
    def __init__(self, pkg, variant):
        self.p = Package(pkg, 4)
        check(self.p.kernel_hash == FROZEN_KERNELS[variant], "frozen transfer kernel")
        k, broker = self.p.kernel, self.p.elf[3]
        self.state = k.sym("jnox_native_shared_state", 264)
        self.maps = k.sym("jnox_native_shared_maps", 384)
        self.pool = k.sym("jnox_native_shared_pages", 4*SIZE)
        self.l3 = k.sym("jnox_native_shared_l3", 4*PAGE)
        self.endpoints = k.sym("9ENDPOINTS")
        self.clients = broker.sym("CLIENT_STATE", 288*3)
        self.banks = broker.sym("5BANKS", BANK*2)
        self.witness = self.p.elf[0].sym("fd_transfer_witness", 256)
        self.variant = variant

    def read_state(self, ram):
        state = ram.read(self.state, 264)
        return (struct.unpack_from("<4Q", state), list(struct.iter_unpack("BB", state[32:96])),
                [entry for entry in struct.iter_unpack("<QBB6x", state[96:224]) if any(entry)],
                state[224:228], state[228:232], state[232:264])

    def ipc(self, ram):
        slot = ram.read(self.endpoints, 88)
        server, word, deadline, token = struct.unpack_from("<4Q", slot)
        tag = slot[32]
        check(tag in (0,1,2), "IPC request tag")
        return (server, word, deadline, token, tag)

    def bank(self, ram, index):
        return ram.user(self.p.roots[3], self.banks+index*BANK, BANK)

    @staticmethod
    def socket(bank, fd):
        tag, obj = struct.unpack_from("<2Q", bank, 4160+fd*16)
        check(tag == 1 and obj < 8, "broker PID0 socket descriptor")
        off = obj*SOCKET
        head, count = struct.unpack_from("<2Q", bank, off+160)
        check(bank[off+515] == 1 and head < 64 and count <= 64, "broker stream and ring bounds")
        payload = bytes(bank[off+96+(head+i)%64] for i in range(count))
        attached = [(tid, pos) for tid, index, pos in struct.iter_unpack("<3Q",bank[4352:])
                    if tid and index == obj]
        return obj, head, payload, attached

    def pre(self, ram):
        _, fds, escrows, _, _, _ = self.read_state(ram)
        check(fds[2] == (0,0) and not escrows, "pretimeout FD98 and escrow")
        request = self.ipc(ram)
        server, word, deadline, token, tag = request
        c = ram.user(self.p.roots[3], self.clients, 288)
        pending, held = struct.unpack_from("<2Q", c)
        op, fd, count = c[184:187]
        matched = (server == 3 and word == 0x13<<56 and 0 < deadline < END and token and
                   tag == 1 and pending == 1 and held == token and op == 16 and count == 1 and fd < 4)
        result = dict(kernel=list(request), broker_pending=[pending, held], broker_request=[op,fd,count],
                      delivered_commit_observed=bool(matched))
        if matched:
            views = [self.socket(self.bank(ram, i), fd) for i in range(2)]
            check(views[0] == views[1] and views[0][2:] == (b"", []), "empty receive stream in both banks")
            result.update(accepted_socket_fd=64+fd, socket_object=views[0][0])
        return result

    def stage(self, ram, stage, boot, known):
        sizes, fds, escrows, resizable, seals, flags = self.read_state(ram)
        rows = list(struct.iter_unpack("<3Q", ram.read(self.maps,384)))
        cw, pw = [struct.unpack("<32q", ram.user(root,self.witness,256)) for root in self.p.roots[:2]]
        check(cw[29] == -110, "caller ETIMEDOUT")
        if stage == "terminal":
            check(not any(obj or wr for obj,wr in fds) and not escrows, "terminal rights and escrow")
            check(not any(any(row) for row in rows) and not any(ram.read(self.l3,4*PAGE)), "terminal protected maps")
            check(all(not ram.aliases(r, self.pool, self.pool + 4*SIZE) for r in self.p.roots), "terminal hardware aliases")
            return dict(rights=0, escrows=0, maps=0, accessible_pool_pages=0,
                        dead_fd98_flag_storage=flags[2], consumer_eof_witness=cw[25])
        producer = [(i,row) for i,row in enumerate(rows[4:8]) if row[1] == SIZE]
        check(len(producer) == 1, "unique full producer mapping")
        slot,(obj, length, write) = producer[0]
        check(0 <= obj < 4 and write == 1 and sizes[obj] == SIZE, "original object and size")
        if self.variant != "baseline":
            check((resizable[obj],seals[obj]) == (1,2), "original shrink-sealed memfd")
        original = obj+1
        if "object" in known:
            check(known["object"] == original, "backing identity across stops")
        decoy,wr = fds[8]
        check(1 <= decoy <= 4 and decoy != original and wr == 1 and sizes[decoy-1] == 4 and
              fds[9] == (decoy,0) and not any(n == original for n,_ in fds[8:]), "sender FD96/97 reuse")
        check((pw[2],pw[3],pw[27],pw[28]) == (96,96,97,97), "sender descriptor numbers")
        check(ram.read(self.pool+(decoy-1)*SIZE,4) == bytes.fromhex("d4c3b2a1"), "decoy object contents")
        expected_flag = int(self.variant == "cloexec")
        if stage == "queued":
            check(len(escrows) == 1 and escrows[0][1:] == (original,0), "queued read-only escrow")
            check(fds[2] == (0,0) and flags[2] == 0, "queued FD98 absent")
            expected_payload = b"prFD1z"
        else:
            check(not escrows, "consumed escrow")
            if stage == "installed":
                check(fds[2] == (original,0) and cw[3] == 98, "FD98 read-only install")
                check(flags[2] == expected_flag, "installed FD98 CLOEXEC")
                expected_payload = b"D1z"
            else:
                check(not any(obj or wr for obj,wr in fds[:8]), "descriptors closed with surviving mappings")
                expected_payload = b""
        start = self.pool + obj*SIZE
        result = dict(object=original, decoy=decoy, sender_fds=[list(fds[8]),list(fds[9])],
                      size=length, seals=seals[obj], resizable=resizable[obj],
                      fd98=list(fds[2]), flag_storage=flags[2], escrow=escrows, timeout=cw[29])
        for role, root in enumerate(self.p.roots):
            aliases = ram.aliases(root, start, start+SIZE)
            own_rows = [(i,row) for i,row in enumerate(rows[role*4:role*4+4]) if row[:2] == (obj,SIZE)]
            needed = role == 1 or (role == 0 and stage != "queued")
            check(len(own_rows) == int(needed) and len(aliases) == (SIZE//PAGE if needed else 0), "physical alias count")
            if not needed:
                continue
            index, (_,_,wr) = own_rows[0]
            va = WINDOW + index*STRIDE
            check(wr == int(role == 1) and [aliases.get(va+off) for off in range(0,SIZE,PAGE)] ==
                  [(start+off,True,bool(wr),True,True) for off in range(0,SIZE,PAGE)], "hardware alias permissions")
            result["producer_va" if role else "consumer_va"] = va
        result["physical"] = [start,start+SIZE-PAGE]
        if stage in ("queued","installed"):
            banks = [self.bank(ram,i) for i in range(2)]
            if "socket_fd" in known:
                candidates = [known["socket_fd"]]
            else:
                candidates = [fd for fd in range(4) if all(q(b,4160+16*fd) == 1 for b in banks)]
            matches = {}
            for fd in candidates:
                views = [self.socket(b,fd) for b in banks]
                if views[0] == views[1] and views[0][2] == expected_payload:
                    matches[fd] = views[0]
            check(len(matches) == 1, "same unread stream bytes in both banks")
            fd, (sock, head, payload, attached) = next(iter(matches.items()))
            if stage == "queued":
                check(attached == [(escrows[0][0], (head+2)%64)], "escrow marks exact F byte")
            else:
                check(not attached, "installed suffix has no second right")
            result.update(socket_fd=fd, socket_object=sock, ring_head=head,
                          unread_hex=payload.hex(), socket_attachments=attached)
        if stage in ("before","after"):
            raw = ram.read(start,SIZE)
            ppm = (boot/(stage+".ppm")).read_bytes()
            pix = bytearray(3*320*240)
            pix[0::3],pix[1::3],pix[2::3] = raw[2::4],raw[1::4],raw[0::4]
            check(ppm == HEADER+pix, "backing vs raw QMP pixels")
            result.update(pixels_sha256=sha(pix), backing_sha256=sha(raw), raw_ppm_sha256=sha(ppm),
                          corners=[pix[:3].hex(),pix[-3:].hex()])
        return result

    def boot(self, boot, controls):
        stages, changed, known = {}, [], {}
        with stopped(boot/"pretimeout.ram") as ram:
            pre = stages["pretimeout"] = self.pre(ram)
            if pre["delivered_commit_observed"]:
                known["socket_fd"] = pre["accepted_socket_fd"]-64
                if controls:
                    def require_match():
                        check(self.pre(ram)["delivered_commit_observed"], "same kernel and broker receive commitment")
                    for addr in (self.endpoints+8, ram.leaf(self.p.roots[3],self.clients+8)[0]):
                        changed.append(control(ram, addr, 1, require_match, "same kernel and broker receive commitment"))
        for stage in ("queued","installed","before","after","terminal"):
            with stopped(boot/(stage+".ram")) as ram:
                self.p.verify_live(ram)
                run = lambda: self.stage(ram, stage, boot, known)
                found = stages[stage] = run()
                if stage == "queued":
                    known.update(object=found["object"], socket_fd=found["socket_fd"])
                    if pre["delivered_commit_observed"]:
                        check(found["escrow"][0][0] > pre["kernel"][3] and
                              pre["socket_object"] == found["socket_object"], "separate later transfer on same socket")
                if not controls:
                    continue
                if stage == "installed" and self.variant != "baseline":
                    for addr, reason in [(self.state+232+2,"installed FD98 CLOEXEC"),
                                         (self.state+228+found["object"]-1,"original shrink-sealed memfd"),
                                         (self.state+37,"FD98 read-only install")]:
                        changed.append(control(ram, addr, 1, run, reason))
                if stage == "queued":
                    va = self.banks + found["socket_object"]*SOCKET+96+found["ring_head"]
                    changed.append(control(ram,ram.leaf(self.p.roots[3],va)[0],1,run,
                                           "same unread stream bytes in both banks"))
                if stage == "before":
                    addr = ram.leaf(self.p.roots[0],found["consumer_va"],pte=True)
                    changed.append(control(ram,addr,128,run,"hardware alias permissions"))
                    changed.append(control(ram,found["physical"][0],1,run,"backing vs raw QMP pixels"))
                if stage == "terminal":
                    changed.append(control(ram,self.state+36,1,run,"terminal rights and escrow"))
        a,b = [(boot/(s+".ppm")).read_bytes()[len(HEADER):] for s in ("before","after")]
        delta = sum(a[i:i+3] != b[i:i+3] for i in range(0,len(a),3))
        check(delta == 320*240, "complete 76800-pixel frame change")
        return dict(stages=stages, changed_pixels=delta, rejected_controls=changed)
