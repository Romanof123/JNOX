"""Offline only. Supply a frozen build directory; writes JSON to standard output."""
import argparse
import json
from pathlib import Path

from physical import SOURCE, check
from poll import enhanced, role_exits, stock
from transfer import Transfer


def gates(boot):
    events = [json.loads(line) for line in (boot/"events.jsonl").read_text().splitlines()]
    paused, last = True, None
    keys = []
    for _, kind, value in events:
        if kind == "pl011":
            check(paused, "stimulus during frozen capture")
            keys.append((last,value))
        if kind != "command":
            continue
        command, args = value
        if command in ("stop","cont"):
            paused = command == "stop"
            last = None
        if command == "pmemsave":
            check(paused and args["val"] == 0x40000000 and args["size"] == 128<<20, "full stopped RAM capture")
            last = Path(args["filename"]).name
    check(keys == [("queued.ram","72"),("installed.ram","69"),("before.ram","75"),("after.ram","71")]
          and last == "terminal.ram", "QMP capture and serial stimulus chronology")
    return dict(kernel=events[0][2][2], keys=keys)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("build", type=Path)
    parser.add_argument("mode", choices=["poll","baseline","default","cloexec","observed"])
    args = parser.parse_args()
    if args.mode == "poll":
        out = stock(args.build)
    elif args.mode == "observed":
        out = enhanced(args.build)
    else:
        check((args.build/"source-commit").read_text().strip() == SOURCE, "frozen revision")
        capture = args.build/"campaign-01"/args.mode
        review = Transfer(capture/"package",args.mode)
        out = dict(kernel=review.p.kernel_hash, identities=review.p.ids, boots={})
        for name in ("cold-1","cold-2"):
            boot = capture/name
            run = gates(boot)
            check(run["kernel"] == review.p.kernel_hash, "QMP kernel identity")
            role_exits(review.p,boot,[70,71,72,0])
            out["boots"][name] = {**run,**review.boot(boot,name == "cold-1")}
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
