cd ~/jnox271-first/src
export PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo CARGO_TARGET_DIR=$HOME/jnox271-first/host-target JNOX_BOARD=virt
python3 tools/ordinary_multilevel_replay.py mlq ../firsts/15*/guest/audit.bin
python3 tools/ordinary_multilevel_replay.py mlfq ../firsts/17*/guest/audit.bin
for case in "multilevel mlfq-wake typo" "multilevel mlq active" "proportional lottery1 active"; do
 read -r prof app mode <<< "$case"
 (cd kernel && JNOX_PROFILE=$prof JNOX_APP=$app JNOX_SCHED_APP_TRACE=$mode cargo +1.95.0 build --locked --release -j1) >"../host/reject-$app.log" 2>&1
 echo "$case exit $?"
done
