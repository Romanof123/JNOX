import os, subprocess as sp, shutil, time, json, sys
from pathlib import Path
root=Path.home()/'jnox271-first'; src=root/'src'; raw=root/'firsts'; raw.mkdir()
tools=Path.home()/'jnox-169-first-e203caa'
env0=dict(os.environ,PATH=str(tools/'cargo/bin')+':'+os.environ['PATH'],RUSTUP_HOME=str(tools/'rustup'),CARGO_HOME=str(tools/'cargo'),PYTHONDONTWRITEBYTECODE='1',CARGO_TARGET_DIR=str(root/'target'),JNOX_BOARD='virt')
multi='mlfq-wake-refuse mlq mlfq mlq-admit mlq-refuse mlq-saturated mlq-blocked mlq-exited mlfq-delayed'.split()
win='lottery-window1 lottery-window2 lottery-window-tight'.split()
prop='lottery1 lottery2 lottery-miss stride stride-delay proportional-bench'.split()
cases=[('mlfq-wake',m,t) for m in ['off','disabled','active','saturate'] for t in (0,1)]+[(a,'off',0) for a in win]+[(a,'off',t) for a in multi for t in (0,1)]+[(a,'off',0) for a in prop]
for idx,(app,mode,tr) in enumerate(cases,1):
 out=raw/f'{idx:02}-{app}-{mode}-{tr}';out.mkdir();g=out/'guest'; env=env0.copy()
 def run(cmd,log,cwd=src):
  with (out/log).open('ab') as f:
   f.write((repr([str(c) for c in cmd])+'\n').encode());f.flush();return sp.run(cmd,cwd=cwd,env=env,stdout=f,stderr=sp.STDOUT).returncode
 try:
  profile='proportional' if app in win+prop else 'multilevel'
  if app!='proportional-bench':env.update(JNOX_PROFILE=profile,JNOX_APP=app)
  if tr:env['JNOX_MULTILEVEL_TRACE']='1'
  if mode!='off':env['JNOX_SCHED_APP_TRACE']=mode
  (out/'env.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith(('JNOX','CARGO','RUSTUP'))}))
  for cmd in [['cargo','+1.95.0','-V'],['rustc','+1.95.0','-Vv'],['aarch64-linux-gnu-nm','--version'],['qemu-system-aarch64','--version'],['git','rev-parse','HEAD'],['git','status','--porcelain']]:run(cmd,'build.log')
  cmd=['cargo','+1.95.0','build','--locked','--release','-j1']+(['--features','proportional-bench'] if app=='proportional-bench' else [])
  assert run(cmd,'build.log',src/'kernel')==0,'build'
  elf=out/'kernel.elf';shutil.copyfile(root/'target/aarch64-unknown-none/release/jnox-kernel',elf)
  for cmd,log in [(['aarch64-linux-gnu-objdump','-d',elf],'disasm'),(['aarch64-linux-gnu-nm','-S',elf],'symbols'),(['aarch64-linux-gnu-readelf','-SW',elf],'sections')]:run(cmd,log)
  if app in win+prop and app!='proportional-bench':
   args=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-m','128M','-accel','tcg','-nodefaults','-display','none','-monitor','none','-serial','file:'+str(out/'uart'),'-d','int','-D',str(out/'exceptions'),'-kernel',str(elf)]
   (out/'argv.json').write_text(json.dumps(args))
   with (out/'boot.log').open('wb') as f:
    p=sp.Popen(args,env=env,stdout=f,stderr=sp.STDOUT)
    try:
     for _ in range(600):
      if (out/'uart').exists() and b'PROP END ' in (out/'uart').read_bytes():break
      if p.poll()!=None:break
      time.sleep(.1)
     else:raise ValueError('UART deadline')
    finally:
     if p.poll()==None:p.terminate()
     p.wait()
   verdict='terminal' if b'PROP END ' in (out/'uart').read_bytes() else 'missing'
  else:
   cmd=['python3','tools/qemu_boot.py','--profile',('proportional' if app=='proportional-bench' else app),'--kernel',elf]
   if app=='mlfq-wake': helper,var='sched_app_trace','SCHED_APP_TRACE'
   elif app=='mlfq-wake-refuse':helper,var='mlfq_wake','MLFQ_WAKE'
   elif app in ['mlq-admit','mlq-refuse']:helper,var='mlq_admission','MLQ_ADMISSION'
   elif app=='proportional-bench':helper,var='proportional','PROPORTIONAL'
   elif tr or app not in ['mlq','mlfq']:helper,var='ordinary_multilevel','ORDINARY_MULTILEVEL'
   else:helper=None
   if helper:
    env[var+'_CAPTURE_DIR']=str(g);cmd+=['--qemu','tools/'+helper+'_capture.py']
   else:cmd+=['--capture-dir',str(g)]
   verdict=run(cmd,'boot.log')
   if app=='mlfq-wake':
    seal=run(['python3','tools/sched_app_trace_decode.py','seal',g,'--build-log',out/'build.log','--boot-log',out/'boot.log'],'seal.log')
    dec=run(['python3','tools/sched_app_trace_decode.py','decode',g],'decode.log');verdict=[verdict,seal,dec]
  print(out.name,verdict,flush=True)
 except Exception as ex:print(out.name,'ERROR',repr(ex),flush=True)
