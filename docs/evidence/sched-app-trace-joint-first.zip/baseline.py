import json,zipfile,re,struct,hashlib
from pathlib import Path
root=Path.home()/'jnox271-first'; dirs=sorted((root/'firsts').iterdir())
def sections(b):
 pos=struct.unpack_from('<Q',b,40)[0];n,idx=struct.unpack_from('<HH',b,60);hs=[struct.unpack_from('<II6QIIQQ',b,pos+i*64) if False else struct.unpack_from('<IIQQQQIIQQ',b,pos+i*64) for i in range(n)];tab=hs[idx];names=b[tab[4]:tab[4]+tab[5]]
 return {names[h[0]:].split(b'\0')[0].decode():[h[3],h[5],hashlib.sha256(b[h[4]:h[4]+h[5]]).hexdigest() if h[1]!=8 else None] for h in hs if h[2]&2}
def uart(b):
 return b.decode().replace('\r','').strip().split('\n')
def events(b):
 return [b.count(k) for k in (b'Taking exception 5 [IRQ]',b'Taking exception 2 [SVC]',b'Exception return from')]
def stats(lines):
 rows=[[int(x) for x in line.split()] for line in lines if line and line[0].isdigit()];return dict(grants=[sum(r[0]==7 and r[2]==w for r in rows) for w in range(3)],whole_ticks=[sum(r[6] for r in rows if r[0]==9 and r[2]==w) for w in range(3)])
results={};sizes={}
for p in dirs:
 app='-'.join(p.name.split('-')[1:-2]);mode,tr=p.name.split('-')[-2:];s=sections((p/'kernel.elf').read_bytes());sizes[p.name]={k:v[:2] for k,v in s.items()}
 if mode!='off' or app.startswith('lottery-window'):continue
 prop=int(p.name[:2])>=30; z=zipfile.ZipFile(root/'baseline'/('prop.zip' if prop else 'wake.zip'))
 prefix=('new/'+app if prop else ('' if app.startswith('mlfq-wake') else 'legacy/')+app+('-trace' if tr=='1' else '-plain'))+'/'
 old=sections(z.read(prefix+'kernel.elf'));eq={k:v==s.get(k) for k,v in old.items()}
 oldserial=uart(z.read(prefix+'guest/uart.bin'));serial=uart(next(f for f in (p/'uart',p/'guest/uart.bin',p/'guest/run-1/uart') if f.exists()).read_bytes())
 oldexc=next((x for x in z.namelist() if x.startswith(prefix) and (x.endswith('int.trace') or x.endswith('exceptions.log'))),None)
 exc=next(f for f in (p/'exceptions',p/'guest/int.trace',p/'guest/run-1/exceptions.log') if f.exists()).read_bytes()
 result=dict(sections_equal=eq,uart_terminal=[oldserial[-1],serial[-1]],events=[events(z.read(oldexc)) if oldexc else None,events(exc)])
 if prop and app!='proportional-bench':result['grants_and_ticks']=[stats(oldserial),stats(serial)]
 results[p.name]=result
(root/'baseline.json').write_text(json.dumps(results,indent=2));(root/'sizes.json').write_text(json.dumps(sizes,indent=2))
for k,r in results.items():print(k,r['sections_equal']['.text'],r['uart_terminal'],r['events'],r.get('grants_and_ticks',''))

