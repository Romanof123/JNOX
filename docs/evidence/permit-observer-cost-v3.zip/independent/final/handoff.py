"""Summarize previously recorded native bytes. No guest or test execution."""
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[1]
v=r/'v3'
c=json.loads((v/'cohort-close/cohort.json').read_bytes())
def identity(p):
 b=p.read_bytes()
 return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
files={p.relative_to(v).as_posix():identity(p) for p in sorted(v.rglob('*')) if p.is_file()}
redaction={'scope':'Public derivative JSON text fields only. Preserve original raw UART, mechanism, stdout, stderr, source digests and receipt identities. Label any redacted file as a derivative.','literal_prefix_replacements':{str(v):'<NATIVE_COHORT>',json.loads((v/'freeze.json').read_bytes())['replica']:'<REPLICA_COHORT>'}}
out=dict(candidate='34ef5fa604e09258d5711642272677bce97643cc',freeze=identity(v/'freeze.json'),positions=[dict(position=x['position'],termination=x['termination_output'],disposition=x['disposition'],unattempted=x['observation']['unattempted'],first_fault=x['observation']['first_fault'],raw=x['files']) for x in c['observed']],pairs=c['pairs'],native_file_identities=files,public_derivative_redaction=redaction,already_performed_readback='18 bundles reopened and compared with native bytes, manifest byte counts, SHA-256 and intended payload names; 16 matched acknowledgements.')
(r/'final/native-handoff.json').write_text(json.dumps(out,indent=2)+'\n')
