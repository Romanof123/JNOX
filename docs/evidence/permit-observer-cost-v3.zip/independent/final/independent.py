from pathlib import Path
import os, json, shutil, hashlib, sys
from unittest.mock import patch
from permit_cost_retention import publish,verify
srcroot,dstroot=map(Path,sys.argv[1:])
for phase in ['source','stage','final']:
 for change in ['none','extra','missing','type','same-size','new-size','empty-dir','link']:
  ident=phase+'-'+change
  s=srcroot/ident; d=dstroot/ident
  s.mkdir(); (s/'raw').write_bytes(b'one')
  expected={'raw':{'sha256':hashlib.sha256(b'one').hexdigest(),'bytes':3}}
  def mutate(root):
   p=root/'raw'
   if change=='extra': (root/'other').write_bytes(b'x')
   if change=='missing': p.unlink()
   if change=='type': p.unlink(); p.mkdir()
   if change=='same-size': p.write_bytes(b'two')
   if change=='new-size': p.write_bytes(b'four')
   if change=='empty-dir': (root/'extra-dir').mkdir()
   if change=='link': (root/'extra-link').symlink_to('raw')
  cp,ren=shutil.copyfile,os.rename
  def copy(a,b):
   cp(a,b)
   if phase=='stage': mutate(Path(b).parent)
  def rename(a,b):
   ren(a,b)
   if phase=='final': mutate(Path(b))
  if phase=='source': mutate(s)
  rejected=False
  try:
   with patch('permit_cost_retention.shutil.copyfile',copy),patch('permit_cost_retention.os.rename',rename):
    snap=publish(s,d,['raw'],['raw'],expected)
   verify(s,d,['raw'],snap)
  except ValueError as e:
   rejected=True; print(ident,str(e),flush=True)
  assert rejected==(change!='none'), ident
  if not rejected: print(ident,'accepted',flush=True)
