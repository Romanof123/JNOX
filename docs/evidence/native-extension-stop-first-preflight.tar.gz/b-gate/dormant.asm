
/home/ywcho/jnox349-first/b-dormant/kernel.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000040200000 <_start>:
    40200000:	d5034fdf 	msr	daifset, #0xf
    40200004:	d5384240 	mrs	x0, currentel
    40200008:	f100101f 	cmp	x0, #0x4
    4020000c:	54000241 	b.ne	40200054 <_start+0x54>  // b.any
    40200010:	d50041bf 	msr	spsel, #0x1
    40200014:	58000260 	ldr	x0, 40200060 <_start+0x60>
    40200018:	9100001f 	mov	sp, x0
    4020001c:	d5381040 	mrs	x0, cpacr_el1
    40200020:	b26c0400 	orr	x0, x0, #0x300000
    40200024:	d5181040 	msr	cpacr_el1, x0
    40200028:	d5033fdf 	isb
    4020002c:	580001e0 	ldr	x0, 40200068 <_start+0x68>
    40200030:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    40200034:	f9000001 	str	x1, [x0]
    40200038:	580001c0 	ldr	x0, 40200070 <_start+0x70>
    4020003c:	580001e1 	ldr	x1, 40200078 <_start+0x78>
    40200040:	eb01001f 	cmp	x0, x1
    40200044:	54000062 	b.cs	40200050 <_start+0x50>  // b.hs, b.nlast
    40200048:	f800841f 	str	xzr, [x0], #8
    4020004c:	17fffffd 	b	40200040 <_start+0x40>
    40200050:	14000e46 	b	40203968 <_ZN11jnox_kernel11kernel_main17ha0f1dd4d6a7d76bdE>
    40200054:	d503205f 	wfe
    40200058:	17ffffff 	b	40200054 <_start+0x54>
    4020005c:	00000000 	udf	#0
    40200060:	40ea4000 	.word	0x40ea4000
    40200064:	00000000 	.word	0x00000000
    40200068:	40219320 	.word	0x40219320
    4020006c:	00000000 	.word	0x00000000
    40200070:	40214000 	.word	0x40214000
    40200074:	00000000 	.word	0x00000000
    40200078:	40ea0000 	.word	0x40ea0000
	...

0000000040200800 <native_el0_vectors>:
    40200800:	1400026c 00000000 00000000 00000000     l...............
	...
    40200880:	1400024c 00000000 00000000 00000000     L...............
	...
    40200900:	1400022c 00000000 00000000 00000000     ,...............
	...
    40200980:	1400020c 00000000 00000000 00000000     ................
	...
    40200a00:	140001ec 00000000 00000000 00000000     ................
	...
    40200a80:	140002bc 00000000 00000000 00000000     ................
	...
    40200b00:	140001ac 00000000 00000000 00000000     ................
	...
    40200b80:	1400018c 00000000 00000000 00000000     ................
	...
    40200c00:	140001a7 00000000 00000000 00000000     ................
	...
    40200c80:	14000150 00000000 00000000 00000000     P...............
	...
    40200d00:	1400012c 00000000 00000000 00000000     ,...............
	...
    40200d80:	1400010c 00000000 00000000 00000000     ................
	...
    40200e00:	140000ec 00000000 00000000 00000000     ................
	...
    40200e80:	140000cc 00000000 00000000 00000000     ................
	...
    40200f00:	140000ac 00000000 00000000 00000000     ................
	...
    40200f80:	1400008c 00000000 00000000 00000000     ................
	...

0000000040201000 <native_server_enter>:
    40201000:	d10d03ff 	sub	sp, sp, #0x340
    40201004:	910003e1 	mov	x1, sp
    40201008:	d2800682 	mov	x2, #0x34                  	// #52
    4020100c:	a8c11003 	ldp	x3, x4, [x0], #16
    40201010:	a8811023 	stp	x3, x4, [x1], #16
    40201014:	f1000442 	subs	x2, x2, #0x1
    40201018:	54ffffa1 	b.ne	4020100c <native_server_enter+0xc>  // b.any
    4020101c:	140000d6 	b	40201374 <native_el0_enter+0x354>

0000000040201020 <native_el0_enter>:
    40201020:	d5034fdf 	msr	daifset, #0xf
    40201024:	d51bd063 	msr	tpidrro_el0, x3
    40201028:	aa0203e3 	mov	x3, x2
    4020102c:	d5384242 	mrs	x2, currentel
    40201030:	f100105f 	cmp	x2, #0x4
    40201034:	54000be1 	b.ne	402011b0 <native_el0_enter+0x190>  // b.any
    40201038:	d5384202 	mrs	x2, spsel
    4020103c:	b4000ba2 	cbz	x2, 402011b0 <native_el0_enter+0x190>
    40201040:	910003e2 	mov	x2, sp
    40201044:	f2400c5f 	tst	x2, #0xf
    40201048:	54000b41 	b.ne	402011b0 <native_el0_enter+0x190>  // b.any
    4020104c:	f240041f 	tst	x0, #0x3
    40201050:	54000b01 	b.ne	402011b0 <native_el0_enter+0x190>  // b.any
    40201054:	f2400c3f 	tst	x1, #0xf
    40201058:	54000ac1 	b.ne	402011b0 <native_el0_enter+0x190>  // b.any
    4020105c:	d503201f 	nop
    40201060:	10ffbd02 	adr	x2, 40200800 <native_el0_vectors>
    40201064:	d518c002 	msr	vbar_el1, x2
    40201068:	d5033fdf 	isb
    4020106c:	d5184020 	msr	elr_el1, x0
    40201070:	d5184101 	msr	sp_el0, x1
    40201074:	d5184003 	msr	spsr_el1, x3
    40201078:	94000dfe 	bl	40204870 <native_cyclic_return>
    4020107c:	d51bd05f 	msr	tpidr_el0, xzr
    40201080:	d51b441f 	msr	fpcr, xzr
    40201084:	d51b443f 	msr	fpsr, xzr
    40201088:	4f00e400 	movi	v0.16b, #0x0
    4020108c:	4f00e401 	movi	v1.16b, #0x0
    40201090:	4f00e402 	movi	v2.16b, #0x0
    40201094:	4f00e403 	movi	v3.16b, #0x0
    40201098:	4f00e404 	movi	v4.16b, #0x0
    4020109c:	4f00e405 	movi	v5.16b, #0x0
    402010a0:	4f00e406 	movi	v6.16b, #0x0
    402010a4:	4f00e407 	movi	v7.16b, #0x0
    402010a8:	4f00e408 	movi	v8.16b, #0x0
    402010ac:	4f00e409 	movi	v9.16b, #0x0
    402010b0:	4f00e40a 	movi	v10.16b, #0x0
    402010b4:	4f00e40b 	movi	v11.16b, #0x0
    402010b8:	4f00e40c 	movi	v12.16b, #0x0
    402010bc:	4f00e40d 	movi	v13.16b, #0x0
    402010c0:	4f00e40e 	movi	v14.16b, #0x0
    402010c4:	4f00e40f 	movi	v15.16b, #0x0
    402010c8:	4f00e410 	movi	v16.16b, #0x0
    402010cc:	4f00e411 	movi	v17.16b, #0x0
    402010d0:	4f00e412 	movi	v18.16b, #0x0
    402010d4:	4f00e413 	movi	v19.16b, #0x0
    402010d8:	4f00e414 	movi	v20.16b, #0x0
    402010dc:	4f00e415 	movi	v21.16b, #0x0
    402010e0:	4f00e416 	movi	v22.16b, #0x0
    402010e4:	4f00e417 	movi	v23.16b, #0x0
    402010e8:	4f00e418 	movi	v24.16b, #0x0
    402010ec:	4f00e419 	movi	v25.16b, #0x0
    402010f0:	4f00e41a 	movi	v26.16b, #0x0
    402010f4:	4f00e41b 	movi	v27.16b, #0x0
    402010f8:	4f00e41c 	movi	v28.16b, #0x0
    402010fc:	4f00e41d 	movi	v29.16b, #0x0
    40201100:	4f00e41e 	movi	v30.16b, #0x0
    40201104:	4f00e41f 	movi	v31.16b, #0x0
    40201108:	aa1f03e0 	mov	x0, xzr
    4020110c:	aa1f03e1 	mov	x1, xzr
    40201110:	aa1f03e2 	mov	x2, xzr
    40201114:	aa1f03e3 	mov	x3, xzr
    40201118:	aa1f03e4 	mov	x4, xzr
    4020111c:	aa1f03e5 	mov	x5, xzr
    40201120:	aa1f03e6 	mov	x6, xzr
    40201124:	aa1f03e7 	mov	x7, xzr
    40201128:	aa1f03e8 	mov	x8, xzr
    4020112c:	aa1f03e9 	mov	x9, xzr
    40201130:	aa1f03ea 	mov	x10, xzr
    40201134:	aa1f03eb 	mov	x11, xzr
    40201138:	aa1f03ec 	mov	x12, xzr
    4020113c:	aa1f03ed 	mov	x13, xzr
    40201140:	aa1f03ee 	mov	x14, xzr
    40201144:	aa1f03ef 	mov	x15, xzr
    40201148:	aa1f03f0 	mov	x16, xzr
    4020114c:	aa1f03f1 	mov	x17, xzr
    40201150:	aa1f03f2 	mov	x18, xzr
    40201154:	aa1f03f3 	mov	x19, xzr
    40201158:	aa1f03f4 	mov	x20, xzr
    4020115c:	aa1f03f5 	mov	x21, xzr
    40201160:	aa1f03f6 	mov	x22, xzr
    40201164:	aa1f03f7 	mov	x23, xzr
    40201168:	aa1f03f8 	mov	x24, xzr
    4020116c:	aa1f03f9 	mov	x25, xzr
    40201170:	aa1f03fa 	mov	x26, xzr
    40201174:	aa1f03fb 	mov	x27, xzr
    40201178:	aa1f03fc 	mov	x28, xzr
    4020117c:	aa1f03fd 	mov	x29, xzr
    40201180:	aa1f03fe 	mov	x30, xzr
    40201184:	d5033f5f 	clrex
    40201188:	d5033fdf 	isb
    4020118c:	a9bf47f0 	stp	x16, x17, [sp, #-16]!
    40201190:	90000230 	adrp	x16, 40245000 <_ZN11jnox_kernel10native_el09extension9EVALUATOR17h2aebd11a2f23ffadE+0x3cd0>
    40201194:	f9419a10 	ldr	x16, [x16, #816]
    40201198:	b4000090 	cbz	x16, 402011a8 <native_el0_enter+0x188>
    4020119c:	d5033fdf 	isb
    402011a0:	d53be031 	mrs	x17, cntpct_el0
    402011a4:	f9000211 	str	x17, [x16]
    402011a8:	a8c147f0 	ldp	x16, x17, [sp], #16
    402011ac:	d69f03e0 	eret
    402011b0:	d5034fdf 	msr	daifset, #0xf
    402011b4:	94000513 	bl	40202600 <native_el0_unexpected>
    402011b8:	d503205f 	wfe
    402011bc:	17ffffff 	b	402011b8 <native_el0_enter+0x198>
    402011c0:	d5034fdf 	msr	daifset, #0xf
    402011c4:	d10d03ff 	sub	sp, sp, #0x340
    402011c8:	a90007e0 	stp	x0, x1, [sp]
    402011cc:	a9010fe2 	stp	x2, x3, [sp, #16]
    402011d0:	a90217e4 	stp	x4, x5, [sp, #32]
    402011d4:	a9031fe6 	stp	x6, x7, [sp, #48]
    402011d8:	a90427e8 	stp	x8, x9, [sp, #64]
    402011dc:	a9052fea 	stp	x10, x11, [sp, #80]
    402011e0:	a90637ec 	stp	x12, x13, [sp, #96]
    402011e4:	a9073fee 	stp	x14, x15, [sp, #112]
    402011e8:	a90847f0 	stp	x16, x17, [sp, #128]
    402011ec:	a9094ff2 	stp	x18, x19, [sp, #144]
    402011f0:	a90a57f4 	stp	x20, x21, [sp, #160]
    402011f4:	a90b5ff6 	stp	x22, x23, [sp, #176]
    402011f8:	a90c67f8 	stp	x24, x25, [sp, #192]
    402011fc:	a90d6ffa 	stp	x26, x27, [sp, #208]
    40201200:	a90e77fc 	stp	x28, x29, [sp, #224]
    40201204:	f9007bfe 	str	x30, [sp, #240]
    40201208:	d5033fdf 	isb
    4020120c:	d53be022 	mrs	x2, cntpct_el0
    40201210:	d5385209 	mrs	x9, esr_el1
    40201214:	f9007fe9 	str	x9, [sp, #248]
    40201218:	d5384009 	mrs	x9, spsr_el1
    4020121c:	d538402a 	mrs	x10, elr_el1
    40201220:	a9102be9 	stp	x9, x10, [sp, #256]
    40201224:	d5384109 	mrs	x9, sp_el0
    40201228:	d538424a 	mrs	x10, currentel
    4020122c:	a9112be9 	stp	x9, x10, [sp, #272]
    40201230:	d53b4409 	mrs	x9, fpcr
    40201234:	d53b442a 	mrs	x10, fpsr
    40201238:	a9122be9 	stp	x9, x10, [sp, #288]
    4020123c:	ad0987e0 	stp	q0, q1, [sp, #304]
    40201240:	ad0a8fe2 	stp	q2, q3, [sp, #336]
    40201244:	ad0b97e4 	stp	q4, q5, [sp, #368]
    40201248:	ad0c9fe6 	stp	q6, q7, [sp, #400]
    4020124c:	ad0da7e8 	stp	q8, q9, [sp, #432]
    40201250:	ad0eafea 	stp	q10, q11, [sp, #464]
    40201254:	ad0fb7ec 	stp	q12, q13, [sp, #496]
    40201258:	ad10bfee 	stp	q14, q15, [sp, #528]
    4020125c:	ad11c7f0 	stp	q16, q17, [sp, #560]
    40201260:	ad12cff2 	stp	q18, q19, [sp, #592]
    40201264:	ad13d7f4 	stp	q20, q21, [sp, #624]
    40201268:	ad14dff6 	stp	q22, q23, [sp, #656]
    4020126c:	ad15e7f8 	stp	q24, q25, [sp, #688]
    40201270:	ad16effa 	stp	q26, q27, [sp, #720]
    40201274:	ad17f7fc 	stp	q28, q29, [sp, #752]
    40201278:	ad18fffe 	stp	q30, q31, [sp, #784]
    4020127c:	d53bd049 	mrs	x9, tpidr_el0
    40201280:	d53bd06a 	mrs	x10, tpidrro_el0
    40201284:	f9019be9 	str	x9, [sp, #816]
    40201288:	f9019fea 	str	x10, [sp, #824]
    4020128c:	aa0203e1 	mov	x1, x2
    40201290:	910003e0 	mov	x0, sp
    40201294:	940004de 	bl	4020260c <native_sleep_irq>
    40201298:	14000037 	b	40201374 <native_el0_enter+0x354>
    4020129c:	d5034fdf 	msr	daifset, #0xf
    402012a0:	d10d03ff 	sub	sp, sp, #0x340
    402012a4:	a90007e0 	stp	x0, x1, [sp]
    402012a8:	a9010fe2 	stp	x2, x3, [sp, #16]
    402012ac:	a90217e4 	stp	x4, x5, [sp, #32]
    402012b0:	a9031fe6 	stp	x6, x7, [sp, #48]
    402012b4:	a90427e8 	stp	x8, x9, [sp, #64]
    402012b8:	a9052fea 	stp	x10, x11, [sp, #80]
    402012bc:	a90637ec 	stp	x12, x13, [sp, #96]
    402012c0:	a9073fee 	stp	x14, x15, [sp, #112]
    402012c4:	a90847f0 	stp	x16, x17, [sp, #128]
    402012c8:	a9094ff2 	stp	x18, x19, [sp, #144]
    402012cc:	a90a57f4 	stp	x20, x21, [sp, #160]
    402012d0:	a90b5ff6 	stp	x22, x23, [sp, #176]
    402012d4:	a90c67f8 	stp	x24, x25, [sp, #192]
    402012d8:	a90d6ffa 	stp	x26, x27, [sp, #208]
    402012dc:	a90e77fc 	stp	x28, x29, [sp, #224]
    402012e0:	f9007bfe 	str	x30, [sp, #240]
    402012e4:	d5033fdf 	isb
    402012e8:	d53be022 	mrs	x2, cntpct_el0
    402012ec:	d5385209 	mrs	x9, esr_el1
    402012f0:	f9007fe9 	str	x9, [sp, #248]
    402012f4:	d5384009 	mrs	x9, spsr_el1
    402012f8:	d538402a 	mrs	x10, elr_el1
    402012fc:	a9102be9 	stp	x9, x10, [sp, #256]
    40201300:	d5384109 	mrs	x9, sp_el0
    40201304:	d538424a 	mrs	x10, currentel
    40201308:	a9112be9 	stp	x9, x10, [sp, #272]
    4020130c:	d53b4409 	mrs	x9, fpcr
    40201310:	d53b442a 	mrs	x10, fpsr
    40201314:	a9122be9 	stp	x9, x10, [sp, #288]
    40201318:	ad0987e0 	stp	q0, q1, [sp, #304]
    4020131c:	ad0a8fe2 	stp	q2, q3, [sp, #336]
    40201320:	ad0b97e4 	stp	q4, q5, [sp, #368]
    40201324:	ad0c9fe6 	stp	q6, q7, [sp, #400]
    40201328:	ad0da7e8 	stp	q8, q9, [sp, #432]
    4020132c:	ad0eafea 	stp	q10, q11, [sp, #464]
    40201330:	ad0fb7ec 	stp	q12, q13, [sp, #496]
    40201334:	ad10bfee 	stp	q14, q15, [sp, #528]
    40201338:	ad11c7f0 	stp	q16, q17, [sp, #560]
    4020133c:	ad12cff2 	stp	q18, q19, [sp, #592]
    40201340:	ad13d7f4 	stp	q20, q21, [sp, #624]
    40201344:	ad14dff6 	stp	q22, q23, [sp, #656]
    40201348:	ad15e7f8 	stp	q24, q25, [sp, #688]
    4020134c:	ad16effa 	stp	q26, q27, [sp, #720]
    40201350:	ad17f7fc 	stp	q28, q29, [sp, #752]
    40201354:	ad18fffe 	stp	q30, q31, [sp, #784]
    40201358:	d53bd049 	mrs	x9, tpidr_el0
    4020135c:	d53bd06a 	mrs	x10, tpidrro_el0
    40201360:	f9019be9 	str	x9, [sp, #816]
    40201364:	f9019fea 	str	x10, [sp, #824]
    40201368:	910003e0 	mov	x0, sp
    4020136c:	d2808001 	mov	x1, #0x400                 	// #1024
    40201370:	94000468 	bl	40202510 <native_el0_sync>
    40201374:	94000d3f 	bl	40204870 <native_cyclic_return>
    40201378:	a9502be9 	ldp	x9, x10, [sp, #256]
    4020137c:	f240113f 	tst	x9, #0x1f
    40201380:	54fff181 	b.ne	402011b0 <native_el0_enter+0x190>  // b.any
    40201384:	d5184009 	msr	spsr_el1, x9
    40201388:	d518402a 	msr	elr_el1, x10
    4020138c:	f9408be9 	ldr	x9, [sp, #272]
    40201390:	d5184109 	msr	sp_el0, x9
    40201394:	a9522be9 	ldp	x9, x10, [sp, #288]
    40201398:	d51b4409 	msr	fpcr, x9
    4020139c:	d51b442a 	msr	fpsr, x10
    402013a0:	f9419be9 	ldr	x9, [sp, #816]
    402013a4:	f9419fea 	ldr	x10, [sp, #824]
    402013a8:	d51bd049 	msr	tpidr_el0, x9
    402013ac:	d51bd06a 	msr	tpidrro_el0, x10
    402013b0:	ad4987e0 	ldp	q0, q1, [sp, #304]
    402013b4:	ad4a8fe2 	ldp	q2, q3, [sp, #336]
    402013b8:	ad4b97e4 	ldp	q4, q5, [sp, #368]
    402013bc:	ad4c9fe6 	ldp	q6, q7, [sp, #400]
    402013c0:	ad4da7e8 	ldp	q8, q9, [sp, #432]
    402013c4:	ad4eafea 	ldp	q10, q11, [sp, #464]
    402013c8:	ad4fb7ec 	ldp	q12, q13, [sp, #496]
    402013cc:	ad50bfee 	ldp	q14, q15, [sp, #528]
    402013d0:	ad51c7f0 	ldp	q16, q17, [sp, #560]
    402013d4:	ad52cff2 	ldp	q18, q19, [sp, #592]
    402013d8:	ad53d7f4 	ldp	q20, q21, [sp, #624]
    402013dc:	ad54dff6 	ldp	q22, q23, [sp, #656]
    402013e0:	ad55e7f8 	ldp	q24, q25, [sp, #688]
    402013e4:	ad56effa 	ldp	q26, q27, [sp, #720]
    402013e8:	ad57f7fc 	ldp	q28, q29, [sp, #752]
    402013ec:	ad58fffe 	ldp	q30, q31, [sp, #784]
    402013f0:	a94007e0 	ldp	x0, x1, [sp]
    402013f4:	a9410fe2 	ldp	x2, x3, [sp, #16]
    402013f8:	a94217e4 	ldp	x4, x5, [sp, #32]
    402013fc:	a9431fe6 	ldp	x6, x7, [sp, #48]
    40201400:	a94427e8 	ldp	x8, x9, [sp, #64]
    40201404:	a9452fea 	ldp	x10, x11, [sp, #80]
    40201408:	a94637ec 	ldp	x12, x13, [sp, #96]
    4020140c:	a9473fee 	ldp	x14, x15, [sp, #112]
    40201410:	a94847f0 	ldp	x16, x17, [sp, #128]
    40201414:	a9494ff2 	ldp	x18, x19, [sp, #144]
    40201418:	a94a57f4 	ldp	x20, x21, [sp, #160]
    4020141c:	a94b5ff6 	ldp	x22, x23, [sp, #176]
    40201420:	a94c67f8 	ldp	x24, x25, [sp, #192]
    40201424:	a94d6ffa 	ldp	x26, x27, [sp, #208]
    40201428:	a94e77fc 	ldp	x28, x29, [sp, #224]
    4020142c:	f9407bfe 	ldr	x30, [sp, #240]
    40201430:	d5033f5f 	clrex
    40201434:	d0000090 	adrp	x16, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40201438:	f945e610 	ldr	x16, [x16, #3016]
    4020143c:	d5033fdf 	isb
    40201440:	d53be031 	mrs	x17, cntpct_el0
    40201444:	eb10023f 	cmp	x17, x16
    40201448:	540000c2 	b.cs	40201460 <native_el0_enter+0x440>  // b.hs, b.nlast
    4020144c:	90000230 	adrp	x16, 40245000 <_ZN11jnox_kernel10native_el09extension9EVALUATOR17h2aebd11a2f23ffadE+0x3cd0>
    40201450:	f901a211 	str	x17, [x16, #832]
    40201454:	a94847f0 	ldp	x16, x17, [sp, #128]
    40201458:	910d03ff 	add	sp, sp, #0x340
    4020145c:	d69f03e0 	eret
    40201460:	aa1103e0 	mov	x0, x17
    40201464:	910003e1 	mov	x1, sp
    40201468:	94000d99 	bl	40204acc <native_server_reselect>
    4020146c:	17ffffc2 	b	40201374 <native_el0_enter+0x354>

0000000040201470 <native_sleep_switch>:
    40201470:	a9bf7bf3 	stp	x19, x30, [sp, #-16]!
    40201474:	910003f3 	mov	x19, sp
    40201478:	9100001f 	mov	sp, x0
    4020147c:	94000cfd 	bl	40204870 <native_cyclic_return>
    40201480:	d0000090 	adrp	x16, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40201484:	f945e610 	ldr	x16, [x16, #3016]
    40201488:	d5033fdf 	isb
    4020148c:	d53be031 	mrs	x17, cntpct_el0
    40201490:	eb10023f 	cmp	x17, x16
    40201494:	54000082 	b.cs	402014a4 <native_sleep_switch+0x34>  // b.hs, b.nlast
    40201498:	90000230 	adrp	x16, 40245000 <_ZN11jnox_kernel10native_el09extension9EVALUATOR17h2aebd11a2f23ffadE+0x3cd0>
    4020149c:	f901a211 	str	x17, [x16, #832]
    402014a0:	14000006 	b	402014b8 <native_cyclic_idle_landing>
    402014a4:	aa1103e0 	mov	x0, x17
    402014a8:	aa1f03e1 	mov	x1, xzr
    402014ac:	94000d88 	bl	40204acc <native_server_reselect>
    402014b0:	b5000be0 	cbnz	x0, 4020162c <native_extension_eval_stack+0x140>
    402014b4:	17fffff2 	b	4020147c <native_sleep_switch+0xc>

00000000402014b8 <native_cyclic_idle_landing>:
    402014b8:	d5033fdf 	isb
    402014bc:	d53be020 	mrs	x0, cntpct_el0
    402014c0:	94000cd1 	bl	40204804 <native_cyclic_idle_sample>
    402014c4:	94000005 	bl	402014d8 <native_extension_on_idle>
    402014c8:	d50342ff 	msr	daifclr, #0x2
    402014cc:	d5033fdf 	isb

00000000402014d0 <native_sleep_idle>:
    402014d0:	d503207f 	wfi
    402014d4:	17ffffff 	b	402014d0 <native_sleep_idle>

00000000402014d8 <native_extension_on_idle>:
    402014d8:	a9bf7bf3 	stp	x19, x30, [sp, #-16]!
    402014dc:	94000d63 	bl	40204a68 <native_extension_stack_if_pending>
    402014e0:	a8c17bf3 	ldp	x19, x30, [sp], #16
    402014e4:	b5000040 	cbnz	x0, 402014ec <native_extension_eval_stack>
    402014e8:	d65f03c0 	ret

00000000402014ec <native_extension_eval_stack>:
    402014ec:	d10283ff 	sub	sp, sp, #0xa0
    402014f0:	a90053f3 	stp	x19, x20, [sp]
    402014f4:	a9015bf5 	stp	x21, x22, [sp, #16]
    402014f8:	a90263f7 	stp	x23, x24, [sp, #32]
    402014fc:	a9036bf9 	stp	x25, x26, [sp, #48]
    40201500:	a90473fb 	stp	x27, x28, [sp, #64]
    40201504:	a9057bfd 	stp	x29, x30, [sp, #80]
    40201508:	6d0627e8 	stp	d8, d9, [sp, #96]
    4020150c:	6d072fea 	stp	d10, d11, [sp, #112]
    40201510:	6d0837ec 	stp	d12, d13, [sp, #128]
    40201514:	6d093fee 	stp	d14, d15, [sp, #144]
    40201518:	910003eb 	mov	x11, sp
    4020151c:	9000022a 	adrp	x10, 40245000 <_ZN11jnox_kernel10native_el09extension9EVALUATOR17h2aebd11a2f23ffadE+0x3cd0>
    40201520:	f9019d4b 	str	x11, [x10, #824]
    40201524:	9100001f 	mov	sp, x0
    40201528:	94000ced 	bl	402048dc <native_extension_evaluate>
    4020152c:	9000022a 	adrp	x10, 40245000 <_ZN11jnox_kernel10native_el09extension9EVALUATOR17h2aebd11a2f23ffadE+0x3cd0>
    40201530:	f9419d4b 	ldr	x11, [x10, #824]
    40201534:	b40001cb 	cbz	x11, 4020156c <native_extension_eval_stack+0x80>
    40201538:	f9019d5f 	str	xzr, [x10, #824]
    4020153c:	9100017f 	mov	sp, x11
    40201540:	6d4627e8 	ldp	d8, d9, [sp, #96]
    40201544:	6d472fea 	ldp	d10, d11, [sp, #112]
    40201548:	6d4837ec 	ldp	d12, d13, [sp, #128]
    4020154c:	6d493fee 	ldp	d14, d15, [sp, #144]
    40201550:	a94053f3 	ldp	x19, x20, [sp]
    40201554:	a9415bf5 	ldp	x21, x22, [sp, #16]
    40201558:	a94263f7 	ldp	x23, x24, [sp, #32]
    4020155c:	a9436bf9 	ldp	x25, x26, [sp, #48]
    40201560:	a94473fb 	ldp	x27, x28, [sp, #64]
    40201564:	a9457bfd 	ldp	x29, x30, [sp, #80]
    40201568:	910283ff 	add	sp, sp, #0xa0
    4020156c:	d65f03c0 	ret
    40201570:	9000022a 	adrp	x10, 40245000 <_ZN11jnox_kernel10native_el09extension9EVALUATOR17h2aebd11a2f23ffadE+0x3cd0>
    40201574:	f9419d4b 	ldr	x11, [x10, #824]
    40201578:	b40001cb 	cbz	x11, 402015b0 <native_extension_eval_stack+0xc4>
    4020157c:	f9019d5f 	str	xzr, [x10, #824]
    40201580:	9100017f 	mov	sp, x11
    40201584:	6d4627e8 	ldp	d8, d9, [sp, #96]
    40201588:	6d472fea 	ldp	d10, d11, [sp, #112]
    4020158c:	6d4837ec 	ldp	d12, d13, [sp, #128]
    40201590:	6d493fee 	ldp	d14, d15, [sp, #144]
    40201594:	a94053f3 	ldp	x19, x20, [sp]
    40201598:	a9415bf5 	ldp	x21, x22, [sp, #16]
    4020159c:	a94263f7 	ldp	x23, x24, [sp, #32]
    402015a0:	a9436bf9 	ldp	x25, x26, [sp, #48]
    402015a4:	a94473fb 	ldp	x27, x28, [sp, #64]
    402015a8:	a9457bfd 	ldp	x29, x30, [sp, #80]
    402015ac:	910283ff 	add	sp, sp, #0xa0
    402015b0:	aa1f03e0 	mov	x0, xzr
    402015b4:	d5033fdf 	isb
    402015b8:	d53be021 	mrs	x1, cntpct_el0
    402015bc:	94000414 	bl	4020260c <native_sleep_irq>
    402015c0:	b50002a0 	cbnz	x0, 40201614 <native_extension_eval_stack+0x128>
    402015c4:	10fff7a9 	adr	x9, 402014b8 <native_cyclic_idle_landing>
    402015c8:	d5184029 	msr	elr_el1, x9
    402015cc:	d5384009 	mrs	x9, spsr_el1
    402015d0:	b2790129 	orr	x9, x9, #0x80
    402015d4:	d5184009 	msr	spsr_el1, x9
    402015d8:	94000ca6 	bl	40204870 <native_cyclic_return>
    402015dc:	d0000090 	adrp	x16, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402015e0:	f945e610 	ldr	x16, [x16, #3016]
    402015e4:	d5033fdf 	isb
    402015e8:	d53be031 	mrs	x17, cntpct_el0
    402015ec:	eb10023f 	cmp	x17, x16
    402015f0:	54000082 	b.cs	40201600 <native_extension_eval_stack+0x114>  // b.hs, b.nlast
    402015f4:	90000230 	adrp	x16, 40245000 <_ZN11jnox_kernel10native_el09extension9EVALUATOR17h2aebd11a2f23ffadE+0x3cd0>
    402015f8:	f901a211 	str	x17, [x16, #832]
    402015fc:	d69f03e0 	eret
    40201600:	aa1103e0 	mov	x0, x17
    40201604:	aa1f03e1 	mov	x1, xzr
    40201608:	94000d31 	bl	40204acc <native_server_reselect>
    4020160c:	b5000040 	cbnz	x0, 40201614 <native_extension_eval_stack+0x128>
    40201610:	17ffffed 	b	402015c4 <native_extension_eval_stack+0xd8>
    40201614:	100000c9 	adr	x9, 4020162c <native_extension_eval_stack+0x140>
    40201618:	d5184029 	msr	elr_el1, x9
    4020161c:	d5384009 	mrs	x9, spsr_el1
    40201620:	b2790129 	orr	x9, x9, #0x80
    40201624:	d5184009 	msr	spsr_el1, x9
    40201628:	d69f03e0 	eret
    4020162c:	9100027f 	mov	sp, x19

0000000040201630 <native_sleep_resume>:
    40201630:	a8c17bf3 	ldp	x19, x30, [sp], #16
    40201634:	d65f03c0 	ret

0000000040201638 <_ZN11jnox_kernel10native_el011sleep_until17h08dff723cb069a7fE>:
    40201638:	a9402408 	ldp	x8, x9, [x0]
    4020163c:	f100051f 	cmp	x8, #0x1
    40201640:	fa410920 	ccmp	x9, #0x1, #0x0, eq  // eq = none
    40201644:	54000080 	b.eq	40201654 <_ZN11jnox_kernel10native_el011sleep_until17h08dff723cb069a7fE+0x1c>  // b.none
    40201648:	928002a1 	mov	x1, #0xffffffffffffffea    	// #-22
    4020164c:	52800020 	mov	w0, #0x1                   	// #1
    40201650:	d65f03c0 	ret
    40201654:	d10143ff 	sub	sp, sp, #0x50
    40201658:	a900fbff 	stp	xzr, x30, [sp, #8]
    4020165c:	a9025ff8 	stp	x24, x23, [sp, #32]
    40201660:	a90357f6 	stp	x22, x21, [sp, #48]
    40201664:	a9044ff4 	stp	x20, x19, [sp, #64]
    40201668:	f9400800 	ldr	x0, [x0, #16]
    4020166c:	f90003ff 	str	xzr, [sp]
    40201670:	910003e1 	mov	x1, sp
    40201674:	52800202 	mov	w2, #0x10                  	// #16
    40201678:	94000d8a 	bl	40204ca0 <_ZN11jnox_kernel14native_el0_mmu14copy_from_user17h95452b8669d2c3e3E>
    4020167c:	340005a0 	cbz	w0, 40201730 <_ZN11jnox_kernel10native_el011sleep_until17h08dff723cb069a7fE+0xf8>
    40201680:	f94003e8 	ldr	x8, [sp]
    40201684:	928002a1 	mov	x1, #0xffffffffffffffea    	// #-22
    40201688:	52800020 	mov	w0, #0x1                   	// #1
    4020168c:	b7f80568 	tbnz	x8, #63, 40201738 <_ZN11jnox_kernel10native_el011sleep_until17h08dff723cb069a7fE+0x100>
    40201690:	f94007e9 	ldr	x9, [sp, #8]
    40201694:	52993fea 	mov	w10, #0xc9ff                	// #51711
    40201698:	72a7734a 	movk	w10, #0x3b9a, lsl #16
    4020169c:	eb0a013f 	cmp	x9, x10
    402016a0:	540004c8 	b.hi	40201738 <_ZN11jnox_kernel10native_el011sleep_until17h08dff723cb069a7fE+0x100>  // b.pmore
    402016a4:	f000008a 	adrp	x10, 40214000 <_ZN11jnox_kernel10native_el012CLOCK_DOMAIN17h874e00fa96a4d8f0E.0.llvm.16067307468115866285>
    402016a8:	f9400155 	ldr	x21, [x10]
    402016ac:	f000008a 	adrp	x10, 40214000 <_ZN11jnox_kernel10native_el012CLOCK_DOMAIN17h874e00fa96a4d8f0E.0.llvm.16067307468115866285>
    402016b0:	f940054a 	ldr	x10, [x10, #8]
    402016b4:	9bc87d56 	umulh	x22, x10, x8
    402016b8:	9b087d57 	mul	x23, x10, x8
    402016bc:	9b097d53 	mul	x19, x10, x9
    402016c0:	9bc97d54 	umulh	x20, x10, x9
    402016c4:	52994018 	mov	w24, #0xca00                	// #51712
    402016c8:	72a77358 	movk	w24, #0x3b9a, lsl #16
    402016cc:	aa1303e0 	mov	x0, x19
    402016d0:	aa1403e1 	mov	x1, x20
    402016d4:	52994002 	mov	w2, #0xca00                	// #51712
    402016d8:	72a77342 	movk	w2, #0x3b9a, lsl #16
    402016dc:	aa1f03e3 	mov	x3, xzr
    402016e0:	9400144b 	bl	4020680c <__udivti3>
    402016e4:	9bd87c08 	umulh	x8, x0, x24
    402016e8:	9b182028 	madd	x8, x1, x24, x8
    402016ec:	9b187c09 	mul	x9, x0, x24
    402016f0:	eb090269 	subs	x9, x19, x9
    402016f4:	da080288 	sbc	x8, x20, x8
    402016f8:	aa080128 	orr	x8, x9, x8
    402016fc:	f100011f 	cmp	x8, #0x0
    40201700:	1a9f07e8 	cset	w8, ne  // ne = any
    40201704:	ab1502e9 	adds	x9, x23, x21
    40201708:	9a9636ca 	cinc	x10, x22, cs  // cs = hs, nlast
    4020170c:	ab000129 	adds	x9, x9, x0
    40201710:	9a01014a 	adc	x10, x10, x1
    40201714:	ab080128 	adds	x8, x9, x8
    40201718:	9a8a3549 	cinc	x9, x10, cs  // cs = hs, nlast
    4020171c:	f100013f 	cmp	x9, #0x0
    40201720:	1a9f07e0 	cset	w0, ne  // ne = any
    40201724:	92800949 	mov	x9, #0xffffffffffffffb5    	// #-75
    40201728:	9a881121 	csel	x1, x9, x8, ne  // ne = any
    4020172c:	14000003 	b	40201738 <_ZN11jnox_kernel10native_el011sleep_until17h08dff723cb069a7fE+0x100>
    40201730:	928001a1 	mov	x1, #0xfffffffffffffff2    	// #-14
    40201734:	52800020 	mov	w0, #0x1                   	// #1
    40201738:	a9444ff4 	ldp	x20, x19, [sp, #64]
    4020173c:	a94357f6 	ldp	x22, x21, [sp, #48]
    40201740:	a9425ff8 	ldp	x24, x23, [sp, #32]
    40201744:	f9400bfe 	ldr	x30, [sp, #16]
    40201748:	910143ff 	add	sp, sp, #0x50
    4020174c:	d65f03c0 	ret

0000000040201750 <_ZN11jnox_kernel10native_el013clock_gettime17h342113c96274c170E>:
    40201750:	d100c3ff 	sub	sp, sp, #0x30
    40201754:	f9000bfe 	str	x30, [sp, #16]
    40201758:	a9024ff4 	stp	x20, x19, [sp, #32]
    4020175c:	f100041f 	cmp	x0, #0x1
    40201760:	540003e1 	b.ne	402017dc <_ZN11jnox_kernel10native_el013clock_gettime17h342113c96274c170E+0x8c>  // b.any
    40201764:	f0000088 	adrp	x8, 40214000 <_ZN11jnox_kernel10native_el012CLOCK_DOMAIN17h874e00fa96a4d8f0E.0.llvm.16067307468115866285>
    40201768:	f9400108 	ldr	x8, [x8]
    4020176c:	eb080048 	subs	x8, x2, x8
    40201770:	540003a3 	b.cc	402017e4 <_ZN11jnox_kernel10native_el013clock_gettime17h342113c96274c170E+0x94>  // b.lo, b.ul, b.last
    40201774:	f0000089 	adrp	x9, 40214000 <_ZN11jnox_kernel10native_el012CLOCK_DOMAIN17h874e00fa96a4d8f0E.0.llvm.16067307468115866285>
    40201778:	f9400522 	ldr	x2, [x9, #8]
    4020177c:	b40003e2 	cbz	x2, 402017f8 <_ZN11jnox_kernel10native_el013clock_gettime17h342113c96274c170E+0xa8>
    40201780:	9ac20914 	udiv	x20, x8, x2
    40201784:	b7f80314 	tbnz	x20, #63, 402017e4 <_ZN11jnox_kernel10native_el013clock_gettime17h342113c96274c170E+0x94>
    40201788:	aa0103f3 	mov	x19, x1
    4020178c:	52994009 	mov	w9, #0xca00                	// #51712
    40201790:	72a77349 	movk	w9, #0x3b9a, lsl #16
    40201794:	9b097d00 	mul	x0, x8, x9
    40201798:	9bc97d01 	umulh	x1, x8, x9
    4020179c:	aa1f03e3 	mov	x3, xzr
    402017a0:	9400141b 	bl	4020680c <__udivti3>
    402017a4:	f90003f4 	str	x20, [sp]
    402017a8:	52994002 	mov	w2, #0xca00                	// #51712
    402017ac:	72a77342 	movk	w2, #0x3b9a, lsl #16
    402017b0:	aa1f03e3 	mov	x3, xzr
    402017b4:	94001565 	bl	40206d48 <__umodti3>
    402017b8:	f90007e0 	str	x0, [sp, #8]
    402017bc:	910003e1 	mov	x1, sp
    402017c0:	aa1303e0 	mov	x0, x19
    402017c4:	52800202 	mov	w2, #0x10                  	// #16
    402017c8:	94000d14 	bl	40204c18 <_ZN11jnox_kernel14native_el0_mmu12copy_to_user17h9f6ee0e2a7c35599E>
    402017cc:	7100001f 	cmp	w0, #0x0
    402017d0:	928001a8 	mov	x8, #0xfffffffffffffff2    	// #-14
    402017d4:	9a8813e0 	csel	x0, xzr, x8, ne  // ne = any
    402017d8:	14000004 	b	402017e8 <_ZN11jnox_kernel10native_el013clock_gettime17h342113c96274c170E+0x98>
    402017dc:	928002a0 	mov	x0, #0xffffffffffffffea    	// #-22
    402017e0:	14000002 	b	402017e8 <_ZN11jnox_kernel10native_el013clock_gettime17h342113c96274c170E+0x98>
    402017e4:	92800940 	mov	x0, #0xffffffffffffffb5    	// #-75
    402017e8:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402017ec:	f9400bfe 	ldr	x30, [sp, #16]
    402017f0:	9100c3ff 	add	sp, sp, #0x30
    402017f4:	d65f03c0 	ret
    402017f8:	d503201f 	nop
    402017fc:	10049320 	adr	x0, 4020aa60 <anon.cbe5bd67df0a78360b237d45b75dee21.1.llvm.16067307468115866285>
    40201800:	94001374 	bl	402065d0 <_RNvNtNtCsbcsGJ9IzBgZ_4core9panicking11panic_const23panic_const_div_by_zero>

0000000040201804 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E>:
    40201804:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    40201808:	a9016ffc 	stp	x28, x27, [sp, #16]
    4020180c:	a90267fa 	stp	x26, x25, [sp, #32]
    40201810:	a9035ff8 	stp	x24, x23, [sp, #48]
    40201814:	a90457f6 	stp	x22, x21, [sp, #64]
    40201818:	a9054ff4 	stp	x20, x19, [sp, #80]
    4020181c:	d10783ff 	sub	sp, sp, #0x1e0
    40201820:	aa0103f3 	mov	x19, x1
    40201824:	aa0003fc 	mov	x28, x0
    40201828:	aa0803f5 	mov	x21, x8
    4020182c:	910043e8 	add	x8, sp, #0x10
    40201830:	52a00802 	mov	w2, #0x400000              	// #4194304
    40201834:	52a01003 	mov	w3, #0x800000              	// #8388608
    40201838:	940006a2 	bl	402032c0 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE>
    4020183c:	394103e8 	ldrb	w8, [sp, #64]
    40201840:	71000d1f 	cmp	w8, #0x3
    40201844:	54002ba0 	b.eq	40201db8 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x5b4>  // b.none
    40201848:	910043e1 	add	x1, sp, #0x10
    4020184c:	aa1503e0 	mov	x0, x21
    40201850:	52803a02 	mov	w2, #0x1d0                 	// #464
    40201854:	940014ba 	bl	40206b3c <memcpy>
    40201858:	f940e2a8 	ldr	x8, [x21, #448]
    4020185c:	f150011f 	cmp	x8, #0x400, lsl #12
    40201860:	54000361 	b.ne	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.any
    40201864:	f940e6a1 	ldr	x1, [x21, #456]
    40201868:	f100243f 	cmp	x1, #0x9
    4020186c:	540029c2 	b.cs	40201da4 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x5a0>  // b.hs, b.nlast
    40201870:	52800048 	mov	w8, #0x2                   	// #2
    40201874:	39008be8 	strb	w8, [sp, #34]
    40201878:	52800028 	mov	w8, #0x1                   	// #1
    4020187c:	790043e8 	strh	w8, [sp, #32]
    40201880:	f1000c3f 	cmp	x1, #0x3
    40201884:	54000241 	b.ne	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.any
    40201888:	aa1f03e9 	mov	x9, xzr
    4020188c:	d37ae428 	lsl	x8, x1, #6
    40201890:	cb010d12 	sub	x18, x8, x1, lsl #3
    40201894:	910043e8 	add	x8, sp, #0x10
    40201898:	91004108 	add	x8, x8, #0x10
    4020189c:	aa1203ea 	mov	x10, x18
    402018a0:	aa1503eb 	mov	x11, x21
    402018a4:	b400018a 	cbz	x10, 402018d4 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xd0>
    402018a8:	f1000d3f 	cmp	x9, #0x3
    402018ac:	54000100 	b.eq	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.none
    402018b0:	3869690c 	ldrb	w12, [x8, x9]
    402018b4:	3940c16d 	ldrb	w13, [x11, #48]
    402018b8:	9100e16b 	add	x11, x11, #0x38
    402018bc:	91000529 	add	x9, x9, #0x1
    402018c0:	d100e14a 	sub	x10, x10, #0x38
    402018c4:	6b0c01bf 	cmp	w13, w12
    402018c8:	54fffee0 	b.eq	402018a4 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xa0>  // b.none
    402018cc:	528000a0 	mov	w0, #0x5                   	// #5
    402018d0:	9400024d 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    402018d4:	f101027f 	cmp	x19, #0x40
    402018d8:	54ffffa3 	b.cc	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.lo, b.ul, b.last
    402018dc:	3940ef88 	ldrb	w8, [x28, #59]
    402018e0:	3940eb89 	ldrb	w9, [x28, #58]
    402018e4:	2a082128 	orr	w8, w9, w8, lsl #8
    402018e8:	7101011f 	cmp	w8, #0x40
    402018ec:	54ffff01 	b.ne	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.any
    402018f0:	3940f788 	ldrb	w8, [x28, #61]
    402018f4:	3940f389 	ldrb	w9, [x28, #60]
    402018f8:	2a082128 	orr	w8, w9, w8, lsl #8
    402018fc:	3940ff89 	ldrb	w9, [x28, #63]
    40201900:	3940fb8a 	ldrb	w10, [x28, #62]
    40201904:	2a092149 	orr	w9, w10, w9, lsl #8
    40201908:	6b08013f 	cmp	w9, w8
    4020190c:	54fffe02 	b.cs	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.hs, b.nlast
    40201910:	5100050a 	sub	w10, w8, #0x1
    40201914:	7101fd5f 	cmp	w10, #0x7f
    40201918:	54fffda8 	b.hi	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.pmore
    4020191c:	aa1c03ea 	mov	x10, x28
    40201920:	38428d4b 	ldrb	w11, [x10, #40]!
    40201924:	3940054c 	ldrb	w12, [x10, #1]
    40201928:	aa0c216b 	orr	x11, x11, x12, lsl #8
    4020192c:	39400d4c 	ldrb	w12, [x10, #3]
    40201930:	3940094d 	ldrb	w13, [x10, #2]
    40201934:	d370bdad 	lsl	x13, x13, #16
    40201938:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    4020193c:	3940154d 	ldrb	w13, [x10, #5]
    40201940:	38404d4e 	ldrb	w14, [x10, #4]!
    40201944:	aa0b018b 	orr	x11, x12, x11
    40201948:	2a0d21cc 	orr	w12, w14, w13, lsl #8
    4020194c:	39400d4d 	ldrb	w13, [x10, #3]
    40201950:	3940094a 	ldrb	w10, [x10, #2]
    40201954:	53103d4a 	lsl	w10, w10, #16
    40201958:	2a0d614a 	orr	w10, w10, w13, lsl #24
    4020195c:	2a0c014a 	orr	w10, w10, w12
    40201960:	aa0a816a 	orr	x10, x11, x10, lsl #32
    40201964:	ab08194b 	adds	x11, x10, x8, lsl #6
    40201968:	54fffb22 	b.cs	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.hs, b.nlast
    4020196c:	eb13017f 	cmp	x11, x19
    40201970:	54fffae8 	b.hi	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.pmore
    40201974:	8b0a039b 	add	x27, x28, x10
    40201978:	8b091b69 	add	x9, x27, x9, lsl #6
    4020197c:	3940152a 	ldrb	w10, [x9, #5]
    40201980:	aa0903eb 	mov	x11, x9
    40201984:	38404d6c 	ldrb	w12, [x11, #4]!
    40201988:	2a0a218a 	orr	w10, w12, w10, lsl #8
    4020198c:	39400d6c 	ldrb	w12, [x11, #3]
    40201990:	3940096b 	ldrb	w11, [x11, #2]
    40201994:	53103d6b 	lsl	w11, w11, #16
    40201998:	2a0c616b 	orr	w11, w11, w12, lsl #24
    4020199c:	2a0a016a 	orr	w10, w11, w10
    402019a0:	71000d5f 	cmp	w10, #0x3
    402019a4:	54fff941 	b.ne	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.any
    402019a8:	38420d2a 	ldrb	w10, [x9, #32]!
    402019ac:	aa0903eb 	mov	x11, x9
    402019b0:	385f8d6c 	ldrb	w12, [x11, #-8]!
    402019b4:	385f912d 	ldurb	w13, [x9, #-7]
    402019b8:	385fd12e 	ldurb	w14, [x9, #-3]
    402019bc:	3940052f 	ldrb	w15, [x9, #1]
    402019c0:	39400d30 	ldrb	w16, [x9, #3]
    402019c4:	39400931 	ldrb	w17, [x9, #2]
    402019c8:	aa0f214f 	orr	x15, x10, x15, lsl #8
    402019cc:	39400d6a 	ldrb	w10, [x11, #3]
    402019d0:	aa0d218c 	orr	x12, x12, x13, lsl #8
    402019d4:	3940096d 	ldrb	w13, [x11, #2]
    402019d8:	d370be31 	lsl	x17, x17, #16
    402019dc:	aa106230 	orr	x16, x17, x16, lsl #24
    402019e0:	38404d71 	ldrb	w17, [x11, #4]!
    402019e4:	2a0e222e 	orr	w14, w17, w14, lsl #8
    402019e8:	d370bdad 	lsl	x13, x13, #16
    402019ec:	aa0a61aa 	orr	x10, x13, x10, lsl #24
    402019f0:	39400d6d 	ldrb	w13, [x11, #3]
    402019f4:	3940096b 	ldrb	w11, [x11, #2]
    402019f8:	53103d6b 	lsl	w11, w11, #16
    402019fc:	2a0d616b 	orr	w11, w11, w13, lsl #24
    40201a00:	aa0c014a 	orr	x10, x10, x12
    40201a04:	2a0e016b 	orr	w11, w11, w14
    40201a08:	aa0b814a 	orr	x10, x10, x11, lsl #32
    40201a0c:	3940152b 	ldrb	w11, [x9, #5]
    40201a10:	38404d2c 	ldrb	w12, [x9, #4]!
    40201a14:	aa0f020d 	orr	x13, x16, x15
    40201a18:	2a0b218b 	orr	w11, w12, w11, lsl #8
    40201a1c:	3940092c 	ldrb	w12, [x9, #2]
    40201a20:	53103d8c 	lsl	w12, w12, #16
    40201a24:	39400d29 	ldrb	w9, [x9, #3]
    40201a28:	2a096189 	orr	w9, w12, w9, lsl #24
    40201a2c:	2a0b0129 	orr	w9, w9, w11
    40201a30:	aa0981b8 	orr	x24, x13, x9, lsl #32
    40201a34:	ab0a0309 	adds	x9, x24, x10
    40201a38:	54fff4a2 	b.cs	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.hs, b.nlast
    40201a3c:	eb13013f 	cmp	x9, x19
    40201a40:	54fff468 	b.hi	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.pmore
    40201a44:	2a1f03e9 	mov	w9, wzr
    40201a48:	d37ae519 	lsl	x25, x8, #6
    40201a4c:	8b0a039a 	add	x26, x28, x10
    40201a50:	910062b6 	add	x22, x21, #0x18
    40201a54:	d28f0def 	mov	x15, #0x786f                	// #30831
    40201a58:	f2ac25cf 	movk	x15, #0x612e, lsl #16
    40201a5c:	f2cd2c4f 	movk	x15, #0x6962, lsl #32
    40201a60:	d28dc5d0 	mov	x16, #0x6e2e                	// #28206
    40201a64:	f2ae8df0 	movk	x16, #0x746f, lsl #16
    40201a68:	f2c5ccb0 	movk	x16, #0x2e65, lsl #32
    40201a6c:	f2edcd50 	movk	x16, #0x6e6a, lsl #48
    40201a70:	d503201f 	nop
    40201a74:	1004803d 	adr	x29, 4020aa78 <anon.cbe5bd67df0a78360b237d45b75dee21.1.llvm.16067307468115866285+0x18>
    40201a78:	aa1b03f7 	mov	x23, x27
    40201a7c:	394006e8 	ldrb	w8, [x23, #1]
    40201a80:	394002ea 	ldrb	w10, [x23]
    40201a84:	aa082148 	orr	x8, x10, x8, lsl #8
    40201a88:	39400eea 	ldrb	w10, [x23, #3]
    40201a8c:	39400aeb 	ldrb	w11, [x23, #2]
    40201a90:	d370bd6b 	lsl	x11, x11, #16
    40201a94:	aa0a616a 	orr	x10, x11, x10, lsl #24
    40201a98:	aa080148 	orr	x8, x10, x8
    40201a9c:	eb08030a 	subs	x10, x24, x8
    40201aa0:	fa482304 	ccmp	x24, x8, #0x4, cs  // cs = hs, nlast
    40201aa4:	54fff140 	b.eq	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.none
    40201aa8:	aa1f03eb 	mov	x11, xzr
    40201aac:	910102fb 	add	x27, x23, #0x40
    40201ab0:	d1010339 	sub	x25, x25, #0x40
    40201ab4:	8b080348 	add	x8, x26, x8
    40201ab8:	386b690c 	ldrb	w12, [x8, x11]
    40201abc:	340000ac 	cbz	w12, 40201ad0 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x2cc>
    40201ac0:	9100056b 	add	x11, x11, #0x1
    40201ac4:	eb0b015f 	cmp	x10, x11
    40201ac8:	54ffff81 	b.ne	40201ab8 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x2b4>  // b.any
    40201acc:	17ffff80 	b	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>
    40201ad0:	f100397f 	cmp	x11, #0xe
    40201ad4:	54000441 	b.ne	40201b5c <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x358>  // b.any
    40201ad8:	3940050a 	ldrb	w10, [x8, #1]
    40201adc:	3940010b 	ldrb	w11, [x8]
    40201ae0:	39400d0c 	ldrb	w12, [x8, #3]
    40201ae4:	aa0803ed 	mov	x13, x8
    40201ae8:	38404dae 	ldrb	w14, [x13, #4]!
    40201aec:	aa0a216a 	orr	x10, x11, x10, lsl #8
    40201af0:	3940090b 	ldrb	w11, [x8, #2]
    40201af4:	d370bd6b 	lsl	x11, x11, #16
    40201af8:	aa0c616b 	orr	x11, x11, x12, lsl #24
    40201afc:	3940150c 	ldrb	w12, [x8, #5]
    40201b00:	2a0c21cc 	orr	w12, w14, w12, lsl #8
    40201b04:	aa0a016a 	orr	x10, x11, x10
    40201b08:	39400dab 	ldrb	w11, [x13, #3]
    40201b0c:	394009ad 	ldrb	w13, [x13, #2]
    40201b10:	53103dad 	lsl	w13, w13, #16
    40201b14:	2a0b61ab 	orr	w11, w13, w11, lsl #24
    40201b18:	3940250d 	ldrb	w13, [x8, #9]
    40201b1c:	2a0c016b 	orr	w11, w11, w12
    40201b20:	38408d0c 	ldrb	w12, [x8, #8]!
    40201b24:	aa0b814a 	orr	x10, x10, x11, lsl #32
    40201b28:	aa0d218b 	orr	x11, x12, x13, lsl #8
    40201b2c:	3940090c 	ldrb	w12, [x8, #2]
    40201b30:	d370bd8c 	lsl	x12, x12, #16
    40201b34:	39400d0d 	ldrb	w13, [x8, #3]
    40201b38:	aa0d618c 	orr	x12, x12, x13, lsl #24
    40201b3c:	aa0b018b 	orr	x11, x12, x11
    40201b40:	3940150c 	ldrb	w12, [x8, #5]
    40201b44:	39401108 	ldrb	w8, [x8, #4]
    40201b48:	2a0c2108 	orr	w8, w8, w12, lsl #8
    40201b4c:	aa088168 	orr	x8, x11, x8, lsl #32
    40201b50:	eb0f011f 	cmp	x8, x15
    40201b54:	fa500140 	ccmp	x10, x16, #0x0, eq  // eq = none
    40201b58:	540000a0 	b.eq	40201b6c <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x368>  // b.none
    40201b5c:	f101033f 	cmp	x25, #0x40
    40201b60:	aa1b03f7 	mov	x23, x27
    40201b64:	54fff8c2 	b.cs	40201a7c <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x278>  // b.hs, b.nlast
    40201b68:	14000086 	b	40201d80 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x57c>
    40201b6c:	3707eb09 	tbnz	w9, #0, 402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>
    40201b70:	aa1703e8 	mov	x8, x23
    40201b74:	38404d09 	ldrb	w9, [x8, #4]!
    40201b78:	3940050a 	ldrb	w10, [x8, #1]
    40201b7c:	2a0a2129 	orr	w9, w9, w10, lsl #8
    40201b80:	39400d0a 	ldrb	w10, [x8, #3]
    40201b84:	39400908 	ldrb	w8, [x8, #2]
    40201b88:	53103d08 	lsl	w8, w8, #16
    40201b8c:	2a0a6108 	orr	w8, w8, w10, lsl #24
    40201b90:	2a090108 	orr	w8, w8, w9
    40201b94:	71001d1f 	cmp	w8, #0x7
    40201b98:	54ffe9a1 	b.ne	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.any
    40201b9c:	aa1703e8 	mov	x8, x23
    40201ba0:	38408d09 	ldrb	w9, [x8, #8]!
    40201ba4:	3940050a 	ldrb	w10, [x8, #1]
    40201ba8:	aa0a2129 	orr	x9, x9, x10, lsl #8
    40201bac:	39400d0a 	ldrb	w10, [x8, #3]
    40201bb0:	3940090b 	ldrb	w11, [x8, #2]
    40201bb4:	d370bd6b 	lsl	x11, x11, #16
    40201bb8:	aa0a616a 	orr	x10, x11, x10, lsl #24
    40201bbc:	3940150b 	ldrb	w11, [x8, #5]
    40201bc0:	38404d0c 	ldrb	w12, [x8, #4]!
    40201bc4:	aa090149 	orr	x9, x10, x9
    40201bc8:	2a0b218a 	orr	w10, w12, w11, lsl #8
    40201bcc:	39400d0b 	ldrb	w11, [x8, #3]
    40201bd0:	39400908 	ldrb	w8, [x8, #2]
    40201bd4:	53103d08 	lsl	w8, w8, #16
    40201bd8:	2a0b6108 	orr	w8, w8, w11, lsl #24
    40201bdc:	2a0a0108 	orr	w8, w8, w10
    40201be0:	aa088128 	orr	x8, x9, x8, lsl #32
    40201be4:	f100091f 	cmp	x8, #0x2
    40201be8:	54ffe721 	b.ne	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.any
    40201bec:	aa1703e8 	mov	x8, x23
    40201bf0:	38420d09 	ldrb	w9, [x8, #32]!
    40201bf4:	aa0803ea 	mov	x10, x8
    40201bf8:	385f8d4b 	ldrb	w11, [x10, #-8]!
    40201bfc:	385f910c 	ldurb	w12, [x8, #-7]
    40201c00:	385fd10d 	ldurb	w13, [x8, #-3]
    40201c04:	3940050e 	ldrb	w14, [x8, #1]
    40201c08:	39400d0f 	ldrb	w15, [x8, #3]
    40201c0c:	39400910 	ldrb	w16, [x8, #2]
    40201c10:	aa0e2129 	orr	x9, x9, x14, lsl #8
    40201c14:	39400d4e 	ldrb	w14, [x10, #3]
    40201c18:	aa0c216b 	orr	x11, x11, x12, lsl #8
    40201c1c:	3940094c 	ldrb	w12, [x10, #2]
    40201c20:	d370be10 	lsl	x16, x16, #16
    40201c24:	aa0f620f 	orr	x15, x16, x15, lsl #24
    40201c28:	38404d50 	ldrb	w16, [x10, #4]!
    40201c2c:	2a0d220d 	orr	w13, w16, w13, lsl #8
    40201c30:	d370bd8c 	lsl	x12, x12, #16
    40201c34:	aa0e618c 	orr	x12, x12, x14, lsl #24
    40201c38:	39400d4e 	ldrb	w14, [x10, #3]
    40201c3c:	3940094a 	ldrb	w10, [x10, #2]
    40201c40:	53103d4a 	lsl	w10, w10, #16
    40201c44:	2a0e614a 	orr	w10, w10, w14, lsl #24
    40201c48:	aa0b018b 	orr	x11, x12, x11
    40201c4c:	2a0d014a 	orr	w10, w10, w13
    40201c50:	aa0a8175 	orr	x21, x11, x10, lsl #32
    40201c54:	3940150a 	ldrb	w10, [x8, #5]
    40201c58:	38404d0b 	ldrb	w11, [x8, #4]!
    40201c5c:	aa0901e9 	orr	x9, x15, x9
    40201c60:	2a0a216a 	orr	w10, w11, w10, lsl #8
    40201c64:	3940090b 	ldrb	w11, [x8, #2]
    40201c68:	53103d6b 	lsl	w11, w11, #16
    40201c6c:	39400d08 	ldrb	w8, [x8, #3]
    40201c70:	2a086168 	orr	w8, w11, w8, lsl #24
    40201c74:	2a0a0108 	orr	w8, w8, w10
    40201c78:	aa088129 	orr	x9, x9, x8, lsl #32
    40201c7c:	ab150128 	adds	x8, x9, x21
    40201c80:	54ffe262 	b.cs	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.hs, b.nlast
    40201c84:	f100613f 	cmp	x9, #0x18
    40201c88:	54ffe221 	b.ne	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.any
    40201c8c:	eb13011f 	cmp	x8, x19
    40201c90:	54ffe1e8 	b.hi	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>  // b.pmore
    40201c94:	8b150380 	add	x0, x28, x21
    40201c98:	aa1d03e1 	mov	x1, x29
    40201c9c:	52800302 	mov	w2, #0x18                  	// #24
    40201ca0:	aa1303f4 	mov	x20, x19
    40201ca4:	aa1203f3 	mov	x19, x18
    40201ca8:	940012cf 	bl	402067e4 <memcmp>
    40201cac:	d28dc5d0 	mov	x16, #0x6e2e                	// #28206
    40201cb0:	f2ae8df0 	movk	x16, #0x746f, lsl #16
    40201cb4:	f2c5ccb0 	movk	x16, #0x2e65, lsl #32
    40201cb8:	f2edcd50 	movk	x16, #0x6e6a, lsl #48
    40201cbc:	d28f0def 	mov	x15, #0x786f                	// #30831
    40201cc0:	f2ac25cf 	movk	x15, #0x612e, lsl #16
    40201cc4:	f2cd2c4f 	movk	x15, #0x6962, lsl #32
    40201cc8:	35ffe020 	cbnz	w0, 402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>
    40201ccc:	aa1303f2 	mov	x18, x19
    40201cd0:	aa1403f3 	mov	x19, x20
    40201cd4:	38410ee8 	ldrb	w8, [x23, #16]!
    40201cd8:	394006e9 	ldrb	w9, [x23, #1]
    40201cdc:	39400eea 	ldrb	w10, [x23, #3]
    40201ce0:	aa092108 	orr	x8, x8, x9, lsl #8
    40201ce4:	39400ae9 	ldrb	w9, [x23, #2]
    40201ce8:	d370bd29 	lsl	x9, x9, #16
    40201cec:	aa0a6129 	orr	x9, x9, x10, lsl #24
    40201cf0:	aa080128 	orr	x8, x9, x8
    40201cf4:	394016e9 	ldrb	w9, [x23, #5]
    40201cf8:	38404eea 	ldrb	w10, [x23, #4]!
    40201cfc:	2a092149 	orr	w9, w10, w9, lsl #8
    40201d00:	39400eea 	ldrb	w10, [x23, #3]
    40201d04:	39400aeb 	ldrb	w11, [x23, #2]
    40201d08:	53103d6b 	lsl	w11, w11, #16
    40201d0c:	2a0a616a 	orr	w10, w11, w10, lsl #24
    40201d10:	2a090149 	orr	w9, w10, w9
    40201d14:	aa098108 	orr	x8, x8, x9, lsl #32
    40201d18:	aa1203e9 	mov	x9, x18
    40201d1c:	aa1603ea 	mov	x10, x22
    40201d20:	f85f814b 	ldur	x11, [x10, #-8]
    40201d24:	eb0b010b 	subs	x11, x8, x11
    40201d28:	3940614c 	ldrb	w12, [x10, #24]
    40201d2c:	7a402980 	ccmp	w12, #0x0, #0x0, cs  // cs = hs, nlast
    40201d30:	54000181 	b.ne	40201d60 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x55c>  // b.any
    40201d34:	f940014c 	ldr	x12, [x10]
    40201d38:	8b0b018d 	add	x13, x12, x11
    40201d3c:	eb0c01bf 	cmp	x13, x12
    40201d40:	fa5521a0 	ccmp	x13, x21, #0x0, cs  // cs = hs, nlast
    40201d44:	540000e1 	b.ne	40201d60 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x55c>  // b.any
    40201d48:	b100657f 	cmn	x11, #0x19
    40201d4c:	540000a8 	b.hi	40201d60 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x55c>  // b.pmore
    40201d50:	9100616b 	add	x11, x11, #0x18
    40201d54:	f85f014c 	ldur	x12, [x10, #-16]
    40201d58:	eb0c017f 	cmp	x11, x12
    40201d5c:	540000a9 	b.ls	40201d70 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x56c>  // b.plast
    40201d60:	9100e14a 	add	x10, x10, #0x38
    40201d64:	f100e129 	subs	x9, x9, #0x38
    40201d68:	54fffdc1 	b.ne	40201d20 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x51c>  // b.any
    40201d6c:	17fffed8 	b	402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>
    40201d70:	52800029 	mov	w9, #0x1                   	// #1
    40201d74:	f101033f 	cmp	x25, #0x40
    40201d78:	54ffe802 	b.cs	40201a78 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x274>  // b.hs, b.nlast
    40201d7c:	14000002 	b	40201d84 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0x580>
    40201d80:	3607da69 	tbz	w9, #0, 402018cc <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E+0xc8>
    40201d84:	910783ff 	add	sp, sp, #0x1e0
    40201d88:	a9454ff4 	ldp	x20, x19, [sp, #80]
    40201d8c:	a94457f6 	ldp	x22, x21, [sp, #64]
    40201d90:	a9435ff8 	ldp	x24, x23, [sp, #48]
    40201d94:	a94267fa 	ldp	x26, x25, [sp, #32]
    40201d98:	a9416ffc 	ldp	x28, x27, [sp, #16]
    40201d9c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    40201da0:	d65f03c0 	ret
    40201da4:	d503201f 	nop
    40201da8:	10083543 	adr	x3, 40212450 <anon.773058ed228f2edaafa50d5b0d646736.16.llvm.4321263285462747625>
    40201dac:	aa1f03e0 	mov	x0, xzr
    40201db0:	52800102 	mov	w2, #0x8                   	// #8
    40201db4:	940011a3 	bl	40206440 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>
    40201db8:	52800080 	mov	w0, #0x4                   	// #4
    40201dbc:	94000112 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>

0000000040201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE>:
    40201dc0:	f81b0ffd 	str	x29, [sp, #-80]!
    40201dc4:	a90167fe 	stp	x30, x25, [sp, #16]
    40201dc8:	a9025ff8 	stp	x24, x23, [sp, #32]
    40201dcc:	a90357f6 	stp	x22, x21, [sp, #48]
    40201dd0:	a9044ff4 	stp	x20, x19, [sp, #64]
    40201dd4:	d11ac3ff 	sub	sp, sp, #0x6b0
    40201dd8:	f90003ff 	str	xzr, [sp]
    40201ddc:	d53be013 	mrs	x19, cntfrq_el0
    40201de0:	b5000073 	cbnz	x19, 40201dec <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x2c>
    40201de4:	52800100 	mov	w0, #0x8                   	// #8
    40201de8:	94000107 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    40201dec:	aa1f03e9 	mov	x9, xzr
    40201df0:	aa1f03e8 	mov	x8, xzr
    40201df4:	911763f5 	add	x21, sp, #0x5d8
    40201df8:	d5033fdf 	isb
    40201dfc:	d53be02a 	mrs	x10, cntpct_el0
    40201e00:	f000008b 	adrp	x11, 40214000 <_ZN11jnox_kernel10native_el012CLOCK_DOMAIN17h874e00fa96a4d8f0E.0.llvm.16067307468115866285>
    40201e04:	f000008c 	adrp	x12, 40214000 <_ZN11jnox_kernel10native_el012CLOCK_DOMAIN17h874e00fa96a4d8f0E.0.llvm.16067307468115866285>
    40201e08:	f9000593 	str	x19, [x12, #8]
    40201e0c:	d503201f 	nop
    40201e10:	1009808c 	adr	x12, 40214e20 <jnox_native_el0_journal>
    40201e14:	f900016a 	str	x10, [x11]
    40201e18:	5280030a 	mov	w10, #0x18                  	// #24
    40201e1c:	72a1200a 	movk	w10, #0x900, lsl #16
    40201e20:	5280002b 	mov	w11, #0x1                   	// #1
    40201e24:	f900018b 	str	x11, [x12]
    40201e28:	5287480d 	mov	w13, #0x3a40                	// #14912
    40201e2c:	f900058b 	str	x11, [x12, #8]
    40201e30:	52800811 	mov	w17, #0x40                  	// #64
    40201e34:	f9000d8d 	str	x13, [x12, #24]
    40201e38:	52877b0e 	mov	w14, #0x3bd8                	// #15320
    40201e3c:	52875b0f 	mov	w15, #0x3ad8                	// #15064
    40201e40:	d503201f 	nop
    40201e44:	100283eb 	adr	x11, 40206ec0 <jnox_native_el0_image>
    40201e48:	a90037eb 	stp	x11, x13, [sp]
    40201e4c:	910003eb 	mov	x11, sp
    40201e50:	528002ac 	mov	w12, #0x15                  	// #21
    40201e54:	d503201f 	nop
    40201e58:	100461cd 	adr	x13, 4020aa90 <anon.cbe5bd67df0a78360b237d45b75dee21.1.llvm.16067307468115866285+0x30>
    40201e5c:	a90147ed 	stp	x13, x17, [sp, #16]
    40201e60:	d503201f 	nop
    40201e64:	1004636d 	adr	x13, 4020aad0 <anon.cbe5bd67df0a78360b237d45b75dee21.1.llvm.16067307468115866285+0x70>
    40201e68:	d503201f 	nop
    40201e6c:	100641f0 	adr	x16, 4020e6a8 <anon.cbe5bd67df0a78360b237d45b75dee21.1.llvm.16067307468115866285+0x3c48>
    40201e70:	a9023bed 	stp	x13, x14, [sp, #32]
    40201e74:	d503201f 	nop
    40201e78:	10064392 	adr	x18, 4020e6e8 <anon.cbe5bd67df0a78360b237d45b75dee21.1.llvm.16067307468115866285+0x3c88>
    40201e7c:	d503201f 	nop
    40201e80:	10081a00 	adr	x0, 402121c0 <anon.cbe5bd67df0a78360b237d45b75dee21.1.llvm.16067307468115866285+0x7760>
    40201e84:	a90347f0 	stp	x16, x17, [sp, #48]
    40201e88:	d503201f 	nop
    40201e8c:	70081d6d 	adr	x13, 4021223b <anon.cbe5bd67df0a78360b237d45b75dee21.1.llvm.16067307468115866285+0x77db>
    40201e90:	d503201f 	nop
    40201e94:	10081c2e 	adr	x14, 40212218 <anon.cbe5bd67df0a78360b237d45b75dee21.1.llvm.16067307468115866285+0x77b8>
    40201e98:	a9043ff2 	stp	x18, x15, [sp, #64]
    40201e9c:	528001ef 	mov	w15, #0xf                   	// #15
    40201ea0:	52800290 	mov	w16, #0x14                  	// #20
    40201ea4:	a90547e0 	stp	x0, x17, [sp, #80]
    40201ea8:	52a12011 	mov	w17, #0x9000000             	// #150994944
    40201eac:	52800152 	mov	w18, #0xa                   	// #10
    40201eb0:	d503201f 	nop
    40201eb4:	70081b80 	adr	x0, 40212227 <anon.cbe5bd67df0a78360b237d45b75dee21.1.llvm.16067307468115866285+0x77c7>
    40201eb8:	8b080161 	add	x1, x11, x8
    40201ebc:	91008108 	add	x8, x8, #0x20
    40201ec0:	f100053f 	cmp	x9, #0x1
    40201ec4:	9a8d0002 	csel	x2, x0, x13, eq  // eq = none
    40201ec8:	9a8c0203 	csel	x3, x16, x12, eq  // eq = none
    40201ecc:	f100013f 	cmp	x9, #0x0
    40201ed0:	91000529 	add	x9, x9, #0x1
    40201ed4:	9a8201c2 	csel	x2, x14, x2, eq  // eq = none
    40201ed8:	9a8301e3 	csel	x3, x15, x3, eq  // eq = none
    40201edc:	8b030043 	add	x3, x2, x3
    40201ee0:	38401444 	ldrb	w4, [x2], #1
    40201ee4:	b9400145 	ldr	w5, [x10]
    40201ee8:	36280065 	tbz	w5, #5, 40201ef4 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x134>
    40201eec:	d5033fdf 	isb
    40201ef0:	17fffffd 	b	40201ee4 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x124>
    40201ef4:	b9000224 	str	w4, [x17]
    40201ef8:	eb03005f 	cmp	x2, x3
    40201efc:	54ffff21 	b.ne	40201ee0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x120>  // b.any
    40201f00:	f9400c22 	ldr	x2, [x1, #24]
    40201f04:	b40001a2 	cbz	x2, 40201f38 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x178>
    40201f08:	f9400821 	ldr	x1, [x1, #16]
    40201f0c:	8b020022 	add	x2, x1, x2
    40201f10:	38401423 	ldrb	w3, [x1], #1
    40201f14:	b9400144 	ldr	w4, [x10]
    40201f18:	36280064 	tbz	w4, #5, 40201f24 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x164>
    40201f1c:	d5033fdf 	isb
    40201f20:	17fffffd 	b	40201f14 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x154>
    40201f24:	b9000223 	str	w3, [x17]
    40201f28:	eb02003f 	cmp	x1, x2
    40201f2c:	54ffff21 	b.ne	40201f10 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x150>  // b.any
    40201f30:	14000002 	b	40201f38 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x178>
    40201f34:	d5033fdf 	isb
    40201f38:	b9400141 	ldr	w1, [x10]
    40201f3c:	372fffc1 	tbnz	w1, #5, 40201f34 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x174>
    40201f40:	b9000232 	str	w18, [x17]
    40201f44:	f101811f 	cmp	x8, #0x60
    40201f48:	54fffb81 	b.ne	40201eb8 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0xf8>  // b.any
    40201f4c:	52820016 	mov	w22, #0x1000                	// #4096
    40201f50:	72a02016 	movk	w22, #0x100, lsl #16
    40201f54:	910183e8 	add	x8, sp, #0x60
    40201f58:	910003e0 	mov	x0, sp
    40201f5c:	940003af 	bl	40202e18 <_ZN4core5array40_$LT$impl$u20$$u5b$T$u3b$$u20$N$u5d$$GT$3map17h8a5701cd35e00332E>
    40201f60:	aa1f03f4 	mov	x20, xzr
    40201f64:	f902ebf6 	str	x22, [sp, #1488]
    40201f68:	911743e8 	add	x8, sp, #0x5d0
    40201f6c:	d503201f 	nop
    40201f70:	10090517 	adr	x23, 40214010 <_ZN11jnox_kernel10native_el013STARTUP_TAILS17h3a3fdf78ae97ac3fE>
    40201f74:	f90353e8 	str	x8, [sp, #1696]
    40201f78:	f90357f7 	str	x23, [sp, #1704]
    40201f7c:	911963f8 	add	x24, sp, #0x658
    40201f80:	911883e8 	add	x8, sp, #0x620
    40201f84:	911a83e0 	add	x0, sp, #0x6a0
    40201f88:	aa1403e1 	mov	x1, x20
    40201f8c:	940003c1 	bl	40202e90 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17h89e86ab78413ed11E>
    40201f90:	f94313e8 	ldr	x8, [sp, #1568]
    40201f94:	f94317e9 	ldr	x9, [sp, #1576]
    40201f98:	f9431bea 	ldr	x10, [sp, #1584]
    40201f9c:	a9002708 	stp	x8, x9, [x24]
    40201fa0:	f9000b0a 	str	x10, [x24, #16]
    40201fa4:	91000694 	add	x20, x20, #0x1
    40201fa8:	91006318 	add	x24, x24, #0x18
    40201fac:	f1000e9f 	cmp	x20, #0x3
    40201fb0:	54fffe81 	b.ne	40201f80 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1c0>  // b.any
    40201fb4:	911763f9 	add	x25, sp, #0x5d8
    40201fb8:	911963f8 	add	x24, sp, #0x658
    40201fbc:	911763e0 	add	x0, sp, #0x5d8
    40201fc0:	911963e1 	add	x1, sp, #0x658
    40201fc4:	52800902 	mov	w2, #0x48                  	// #72
    40201fc8:	940012dd 	bl	40206b3c <memcpy>
    40201fcc:	aa1f03f4 	mov	x20, xzr
    40201fd0:	91002318 	add	x24, x24, #0x8
    40201fd4:	f90313f7 	str	x23, [sp, #1568]
    40201fd8:	f90317f9 	str	x25, [sp, #1576]
    40201fdc:	911883e0 	add	x0, sp, #0x620
    40201fe0:	aa1403e1 	mov	x1, x20
    40201fe4:	940003d0 	bl	40202f24 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17h8ae4175834463596E>
    40201fe8:	a93f8700 	stp	x0, x1, [x24, #-8]
    40201fec:	91000694 	add	x20, x20, #0x1
    40201ff0:	91004318 	add	x24, x24, #0x10
    40201ff4:	f1000e9f 	cmp	x20, #0x3
    40201ff8:	54ffff21 	b.ne	40201fdc <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x21c>  // b.any
    40201ffc:	911883e0 	add	x0, sp, #0x620
    40202000:	911963e1 	add	x1, sp, #0x658
    40202004:	52800602 	mov	w2, #0x30                  	// #48
    40202008:	940012cd 	bl	40206b3c <memcpy>
    4020200c:	d5034fdf 	msr	daifset, #0xf
    40202010:	d51be23f 	msr	cntp_ctl_el0, xzr
    40202014:	d51be33f 	msr	cntv_ctl_el0, xzr
    40202018:	d5033fdf 	isb
    4020201c:	d5033f9f 	dsb	sy
    40202020:	d5033fdf 	isb
    40202024:	52a10008 	mov	w8, #0x8000000             	// #134217728
    40202028:	b900011f 	str	wzr, [x8]
    4020202c:	52a10029 	mov	w9, #0x8010000             	// #134283264
    40202030:	b900013f 	str	wzr, [x9]
    40202034:	5280100a 	mov	w10, #0x80                  	// #128
    40202038:	72a1000a 	movk	w10, #0x800, lsl #16
    4020203c:	b940014b 	ldr	w11, [x10]
    40202040:	1201796b 	and	w11, w11, #0xbfffffff
    40202044:	b900014b 	str	w11, [x10]
    40202048:	5280100b 	mov	w11, #0x80                  	// #128
    4020204c:	390e794b 	strb	w11, [x10, #926]
    40202050:	52a8000b 	mov	w11, #0x40000000            	// #1073741824
    40202054:	b902014b 	str	w11, [x10, #512]
    40202058:	b900814b 	str	w11, [x10, #128]
    4020205c:	5280008a 	mov	w10, #0x4                   	// #4
    40202060:	72a1002a 	movk	w10, #0x801, lsl #16
    40202064:	52801feb 	mov	w11, #0xff                  	// #255
    40202068:	b900014b 	str	w11, [x10]
    4020206c:	5280002a 	mov	w10, #0x1                   	// #1
    40202070:	b900010a 	str	w10, [x8]
    40202074:	b900012a 	str	w10, [x9]
    40202078:	d5033f9f 	dsb	sy
    4020207c:	d5033fdf 	isb
    40202080:	910183f4 	add	x20, sp, #0x60
    40202084:	910183e0 	add	x0, sp, #0x60
    40202088:	911883e2 	add	x2, sp, #0x620
    4020208c:	52800061 	mov	w1, #0x3                   	// #3
    40202090:	52800063 	mov	w3, #0x3                   	// #3
    40202094:	94000b24 	bl	40204d24 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE>
    40202098:	b5000920 	cbnz	x0, 402021bc <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x3fc>
    4020209c:	911763e9 	add	x9, sp, #0x5d8
    402020a0:	f0000088 	adrp	x8, 40215000 <jnox_native_el0_journal+0x1e0>
    402020a4:	910ac108 	add	x8, x8, #0x2b0
    402020a8:	91004129 	add	x9, x9, #0x10
    402020ac:	5280380a 	mov	w10, #0x1c0                 	// #448
    402020b0:	b000008b 	adrp	x11, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402020b4:	9104416b 	add	x11, x11, #0x110
    402020b8:	f86a6a8c 	ldr	x12, [x20, x10]
    402020bc:	a97f392d 	ldp	x13, x14, [x9, #-16]
    402020c0:	f841852f 	ldr	x15, [x9], #24
    402020c4:	a93fb56c 	stp	x12, x13, [x11, #-8]
    402020c8:	f9032fec 	str	x12, [sp, #1624]
    402020cc:	f90353ed 	str	x13, [sp, #1696]
    402020d0:	f9035fee 	str	x14, [sp, #1720]
    402020d4:	f9032bef 	str	x15, [sp, #1616]
    402020d8:	f9432fec 	ldr	x12, [sp, #1624]
    402020dc:	f81f010c 	stur	x12, [x8, #-16]
    402020e0:	f94353ec 	ldr	x12, [sp, #1696]
    402020e4:	f81f810c 	stur	x12, [x8, #-8]
    402020e8:	f9435fec 	ldr	x12, [sp, #1720]
    402020ec:	f900010c 	str	x12, [x8]
    402020f0:	9107414a 	add	x10, x10, #0x1d0
    402020f4:	f9432bec 	ldr	x12, [sp, #1616]
    402020f8:	f900050c 	str	x12, [x8, #8]
    402020fc:	91008108 	add	x8, x8, #0x20
    40202100:	910d016b 	add	x11, x11, #0x340
    40202104:	f11cc15f 	cmp	x10, #0x730
    40202108:	54fffd81 	b.ne	402020b8 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x2f8>  // b.any
    4020210c:	d5384248 	mrs	x8, currentel
    40202110:	d5381018 	mrs	x24, sctlr_el1
    40202114:	d5382017 	mrs	x23, ttbr0_el1
    40202118:	f100111f 	cmp	x8, #0x4
    4020211c:	54000541 	b.ne	402021c4 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x404>  // b.any
    40202120:	36000538 	tbz	w24, #0, 402021c4 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x404>
    40202124:	f94002b4 	ldr	x20, [x21]
    40202128:	f942f3f5 	ldr	x21, [sp, #1504]
    4020212c:	94000c6d 	bl	402052e0 <_ZN11jnox_kernel14native_el0_mmu6active17hd686f5b0e91753c5E.llvm.14263334612035470596>
    40202130:	f100041f 	cmp	x0, #0x1
    40202134:	54000481 	b.ne	402021c4 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x404>  // b.any
    40202138:	aa0103e0 	mov	x0, x1
    4020213c:	aa1403e1 	mov	x1, x20
    40202140:	aa1503e2 	mov	x2, x21
    40202144:	52800023 	mov	w3, #0x1                   	// #1
    40202148:	94000ca9 	bl	402053ec <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596>
    4020214c:	360003c0 	tbz	w0, #0, 402021c4 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x404>
    40202150:	f94113e8 	ldr	x8, [sp, #544]
    40202154:	d0000089 	adrp	x9, 40214000 <_ZN11jnox_kernel10native_el012CLOCK_DOMAIN17h874e00fa96a4d8f0E.0.llvm.16067307468115866285>
    40202158:	9138a129 	add	x9, x9, #0xe28
    4020215c:	f9000d28 	str	x8, [x9, #24]
    40202160:	f9001134 	str	x20, [x9, #32]
    40202164:	f9001536 	str	x22, [x9, #40]
    40202168:	914042c8 	add	x8, x22, #0x10, lsl #12
    4020216c:	f9001928 	str	x8, [x9, #48]
    40202170:	52800088 	mov	w8, #0x4                   	// #4
    40202174:	f9002d28 	str	x8, [x9, #88]
    40202178:	f9003138 	str	x24, [x9, #96]
    4020217c:	f9003537 	str	x23, [x9, #104]
    40202180:	f942f7e8 	ldr	x8, [sp, #1512]
    40202184:	f9003928 	str	x8, [x9, #112]
    40202188:	52800048 	mov	w8, #0x2                   	// #2
    4020218c:	f9000128 	str	x8, [x9]
    40202190:	aa1303e0 	mov	x0, x19
    40202194:	9400067b 	bl	40203b80 <_ZN11jnox_kernel10native_el09extension5start17h7a1d16f295a7c4b5E>
    40202198:	aa0003f3 	mov	x19, x0
    4020219c:	b5000180 	cbnz	x0, 402021cc <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x40c>
    402021a0:	f0000088 	adrp	x8, 40215000 <jnox_native_el0_journal+0x1e0>
    402021a4:	f901891f 	str	xzr, [x8, #784]
    402021a8:	52806808 	mov	w8, #0x340                 	// #832
    402021ac:	d503201f 	nop
    402021b0:	10087289 	adr	x9, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402021b4:	9b082660 	madd	x0, x19, x8, x9
    402021b8:	97fffb92 	bl	40201000 <native_server_enter>
    402021bc:	528000c0 	mov	w0, #0x6                   	// #6
    402021c0:	94000011 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    402021c4:	528000e0 	mov	w0, #0x7                   	// #7
    402021c8:	9400000f 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    402021cc:	aa1303e0 	mov	x0, x19
    402021d0:	94000c66 	bl	40205368 <_ZN11jnox_kernel14native_el0_mmu6switch17h0d8db83ade90bdd9E>
    402021d4:	b5000140 	cbnz	x0, 402021fc <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x43c>
    402021d8:	f0000088 	adrp	x8, 40215000 <jnox_native_el0_journal+0x1e0>
    402021dc:	f9018913 	str	x19, [x8, #784]
    402021e0:	f1000e7f 	cmp	x19, #0x3
    402021e4:	54fffe23 	b.cc	402021a8 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x3e8>  // b.lo, b.ul, b.last
    402021e8:	d503201f 	nop
    402021ec:	100800a2 	adr	x2, 40212200 <anon.cbe5bd67df0a78360b237d45b75dee21.1.llvm.16067307468115866285+0x77a0>
    402021f0:	aa1303e0 	mov	x0, x19
    402021f4:	52800061 	mov	w1, #0x3                   	// #3
    402021f8:	94000df2 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    402021fc:	52800120 	mov	w0, #0x9                   	// #9
    40202200:	94000001 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>

0000000040202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>:
    40202204:	a9bf4ffe 	stp	x30, x19, [sp, #-16]!
    40202208:	aa1f03e8 	mov	x8, xzr
    4020220c:	52800313 	mov	w19, #0x18                  	// #24
    40202210:	72a12013 	movk	w19, #0x900, lsl #16
    40202214:	d0000089 	adrp	x9, 40214000 <_ZN11jnox_kernel10native_el012CLOCK_DOMAIN17h874e00fa96a4d8f0E.0.llvm.16067307468115866285>
    40202218:	9138a129 	add	x9, x9, #0xe28
    4020221c:	f9000520 	str	x0, [x9, #8]
    40202220:	5280008a 	mov	w10, #0x4                   	// #4
    40202224:	f900012a 	str	x10, [x9]
    40202228:	d5033f9f 	dsb	sy
    4020222c:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202230:	d503201f 	nop
    40202234:	100800ea 	adr	x10, 40212250 <anon.cbe5bd67df0a78360b237d45b75dee21.1.llvm.16067307468115866285+0x77f0>
    40202238:	3868694b 	ldrb	w11, [x10, x8]
    4020223c:	b940026c 	ldr	w12, [x19]
    40202240:	3628006c 	tbz	w12, #5, 4020224c <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E+0x48>
    40202244:	d5033fdf 	isb
    40202248:	17fffffd 	b	4020223c <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E+0x38>
    4020224c:	91000508 	add	x8, x8, #0x1
    40202250:	b900012b 	str	w11, [x9]
    40202254:	f100451f 	cmp	x8, #0x11
    40202258:	54ffff01 	b.ne	40202238 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E+0x34>  // b.any
    4020225c:	9400004c 	bl	4020238c <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E.llvm.16067307468115866285>
    40202260:	b9400268 	ldr	w8, [x19]
    40202264:	36280068 	tbz	w8, #5, 40202270 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E+0x6c>
    40202268:	d5033fdf 	isb
    4020226c:	17fffffd 	b	40202260 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E+0x5c>
    40202270:	52a12008 	mov	w8, #0x9000000             	// #150994944
    40202274:	52800149 	mov	w9, #0xa                   	// #10
    40202278:	b9000109 	str	w9, [x8]
    4020227c:	d503205f 	wfe
    40202280:	17ffffff 	b	4020227c <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E+0x78>

0000000040202284 <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E>:
    40202284:	a9be57fe 	stp	x30, x21, [sp, #-32]!
    40202288:	a9014ff4 	stp	x20, x19, [sp, #16]
    4020228c:	aa0403f3 	mov	x19, x4
    40202290:	aa0303f4 	mov	x20, x3
    40202294:	aa1f03e8 	mov	x8, xzr
    40202298:	52800315 	mov	w21, #0x18                  	// #24
    4020229c:	72a12015 	movk	w21, #0x900, lsl #16
    402022a0:	52a12009 	mov	w9, #0x9000000             	// #150994944
    402022a4:	d503201f 	nop
    402022a8:	3007fdca 	adr	x10, 40212261 <anon.cbe5bd67df0a78360b237d45b75dee21.16.llvm.16067307468115866285>
    402022ac:	3868694b 	ldrb	w11, [x10, x8]
    402022b0:	b94002ac 	ldr	w12, [x21]
    402022b4:	3628006c 	tbz	w12, #5, 402022c0 <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0x3c>
    402022b8:	d5033fdf 	isb
    402022bc:	17fffffd 	b	402022b0 <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0x2c>
    402022c0:	91000508 	add	x8, x8, #0x1
    402022c4:	b900012b 	str	w11, [x9]
    402022c8:	f1002d1f 	cmp	x8, #0xb
    402022cc:	54ffff01 	b.ne	402022ac <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0x28>  // b.any
    402022d0:	b4000161 	cbz	x1, 402022fc <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0x78>
    402022d4:	8b010008 	add	x8, x0, x1
    402022d8:	52a12009 	mov	w9, #0x9000000             	// #150994944
    402022dc:	3840140a 	ldrb	w10, [x0], #1
    402022e0:	b94002ab 	ldr	w11, [x21]
    402022e4:	3628006b 	tbz	w11, #5, 402022f0 <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0x6c>
    402022e8:	d5033fdf 	isb
    402022ec:	17fffffd 	b	402022e0 <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0x5c>
    402022f0:	b900012a 	str	w10, [x9]
    402022f4:	eb08001f 	cmp	x0, x8
    402022f8:	54ffff21 	b.ne	402022dc <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0x58>  // b.any
    402022fc:	aa1f03e8 	mov	x8, xzr
    40202300:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202304:	d503201f 	nop
    40202308:	1007fb2a 	adr	x10, 4021226c <anon.cbe5bd67df0a78360b237d45b75dee21.17.llvm.16067307468115866285>
    4020230c:	3868694b 	ldrb	w11, [x10, x8]
    40202310:	b94002ac 	ldr	w12, [x21]
    40202314:	3628006c 	tbz	w12, #5, 40202320 <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0x9c>
    40202318:	d5033fdf 	isb
    4020231c:	17fffffd 	b	40202310 <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0x8c>
    40202320:	91000508 	add	x8, x8, #0x1
    40202324:	b900012b 	str	w11, [x9]
    40202328:	f100151f 	cmp	x8, #0x5
    4020232c:	54ffff01 	b.ne	4020230c <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0x88>  // b.any
    40202330:	aa0203e0 	mov	x0, x2
    40202334:	94000016 	bl	4020238c <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E.llvm.16067307468115866285>
    40202338:	f100069f 	cmp	x20, #0x1
    4020233c:	54000181 	b.ne	4020236c <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0xe8>  // b.any
    40202340:	b94002a8 	ldr	w8, [x21]
    40202344:	36280068 	tbz	w8, #5, 40202350 <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0xcc>
    40202348:	d5033fdf 	isb
    4020234c:	17fffffd 	b	40202340 <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0xbc>
    40202350:	52a12008 	mov	w8, #0x9000000             	// #150994944
    40202354:	52800409 	mov	w9, #0x20                  	// #32
    40202358:	b9000109 	str	w9, [x8]
    4020235c:	aa1303e0 	mov	x0, x19
    40202360:	9400000b 	bl	4020238c <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E.llvm.16067307468115866285>
    40202364:	14000002 	b	4020236c <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0xe8>
    40202368:	d5033fdf 	isb
    4020236c:	b94002a8 	ldr	w8, [x21]
    40202370:	372fffc8 	tbnz	w8, #5, 40202368 <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E+0xe4>
    40202374:	52a12008 	mov	w8, #0x9000000             	// #150994944
    40202378:	52800149 	mov	w9, #0xa                   	// #10
    4020237c:	b9000109 	str	w9, [x8]
    40202380:	a9414ff4 	ldp	x20, x19, [sp, #16]
    40202384:	a8c257fe 	ldp	x30, x21, [sp], #32
    40202388:	d65f03c0 	ret

000000004020238c <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E.llvm.16067307468115866285>:
    4020238c:	b6f80140 	tbz	x0, #63, 402023b4 <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E.llvm.16067307468115866285+0x28>
    40202390:	52800308 	mov	w8, #0x18                  	// #24
    40202394:	72a12008 	movk	w8, #0x900, lsl #16
    40202398:	b9400109 	ldr	w9, [x8]
    4020239c:	36280069 	tbz	w9, #5, 402023a8 <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E.llvm.16067307468115866285+0x1c>
    402023a0:	d5033fdf 	isb
    402023a4:	17fffffd 	b	40202398 <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E.llvm.16067307468115866285+0xc>
    402023a8:	52a12008 	mov	w8, #0x9000000             	// #150994944
    402023ac:	528005a9 	mov	w9, #0x2d                  	// #45
    402023b0:	b9000109 	str	w9, [x8]
    402023b4:	f100001f 	cmp	x0, #0x0
    402023b8:	da805400 	cneg	x0, x0, mi  // mi = first
    402023bc:	1400002b 	b	40202468 <_ZN11jnox_kernel10native_el08unsigned17haaccd95f5c5ba763E>

00000000402023c0 <_ZN11jnox_kernel10native_el08activate17hc945b2c295390421E>:
    402023c0:	f81d0ffe 	str	x30, [sp, #-48]!
    402023c4:	a90157f6 	stp	x22, x21, [sp, #16]
    402023c8:	a9024ff4 	stp	x20, x19, [sp, #32]
    402023cc:	aa0003f3 	mov	x19, x0
    402023d0:	f0000095 	adrp	x21, 40215000 <jnox_native_el0_journal+0x1e0>
    402023d4:	f9418aa0 	ldr	x0, [x21, #784]
    402023d8:	eb13001f 	cmp	x0, x19
    402023dc:	540002a0 	b.eq	40202430 <_ZN11jnox_kernel10native_el08activate17hc945b2c295390421E+0x70>  // b.none
    402023e0:	f100081f 	cmp	x0, #0x2
    402023e4:	540002e8 	b.hi	40202440 <_ZN11jnox_kernel10native_el08activate17hc945b2c295390421E+0x80>  // b.pmore
    402023e8:	aa0103f4 	mov	x20, x1
    402023ec:	52806808 	mov	w8, #0x340                 	// #832
    402023f0:	d503201f 	nop
    402023f4:	10086076 	adr	x22, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402023f8:	9b085800 	madd	x0, x0, x8, x22
    402023fc:	52806802 	mov	w2, #0x340                 	// #832
    40202400:	940011cf 	bl	40206b3c <memcpy>
    40202404:	aa1303e0 	mov	x0, x19
    40202408:	94000bd8 	bl	40205368 <_ZN11jnox_kernel14native_el0_mmu6switch17h0d8db83ade90bdd9E>
    4020240c:	b5000200 	cbnz	x0, 4020244c <_ZN11jnox_kernel10native_el08activate17hc945b2c295390421E+0x8c>
    40202410:	f1000e7f 	cmp	x19, #0x3
    40202414:	54000202 	b.cs	40202454 <_ZN11jnox_kernel10native_el08activate17hc945b2c295390421E+0x94>  // b.hs, b.nlast
    40202418:	52806808 	mov	w8, #0x340                 	// #832
    4020241c:	9b085a61 	madd	x1, x19, x8, x22
    40202420:	aa1403e0 	mov	x0, x20
    40202424:	52806802 	mov	w2, #0x340                 	// #832
    40202428:	940011c5 	bl	40206b3c <memcpy>
    4020242c:	f9018ab3 	str	x19, [x21, #784]
    40202430:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40202434:	a94157f6 	ldp	x22, x21, [sp, #16]
    40202438:	f84307fe 	ldr	x30, [sp], #48
    4020243c:	d65f03c0 	ret
    40202440:	d503201f 	nop
    40202444:	1007f1a2 	adr	x2, 40212278 <anon.cbe5bd67df0a78360b237d45b75dee21.20.llvm.16067307468115866285>
    40202448:	14000006 	b	40202460 <_ZN11jnox_kernel10native_el08activate17hc945b2c295390421E+0xa0>
    4020244c:	52800120 	mov	w0, #0x9                   	// #9
    40202450:	97ffff6d 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    40202454:	d503201f 	nop
    40202458:	1007f1c2 	adr	x2, 40212290 <anon.cbe5bd67df0a78360b237d45b75dee21.21.llvm.16067307468115866285>
    4020245c:	aa1303e0 	mov	x0, x19
    40202460:	52800061 	mov	w1, #0x3                   	// #3
    40202464:	94000d57 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040202468 <_ZN11jnox_kernel10native_el08unsigned17haaccd95f5c5ba763E>:
    40202468:	d100c3ff 	sub	sp, sp, #0x30
    4020246c:	f90013fe 	str	x30, [sp, #32]
    40202470:	b9001bff 	str	wzr, [sp, #24]
    40202474:	52800268 	mov	w8, #0x13                  	// #19
    40202478:	b202e7e9 	mov	x9, #0xcccccccccccccccc    	// #-3689348814741910324
    4020247c:	f29999a9 	movk	x9, #0xcccd
    40202480:	5280014a 	mov	w10, #0xa                   	// #10
    40202484:	910023eb 	add	x11, sp, #0x8
    40202488:	a900ffff 	stp	xzr, xzr, [sp, #8]
    4020248c:	f1004d1f 	cmp	x8, #0x13
    40202490:	54000368 	b.hi	402024fc <_ZN11jnox_kernel10native_el08unsigned17haaccd95f5c5ba763E+0x94>  // b.pmore
    40202494:	9bc97c0c 	umulh	x12, x0, x9
    40202498:	d343fd8c 	lsr	x12, x12, #3
    4020249c:	1b0a818d 	msub	w13, w12, w10, w0
    402024a0:	321c05ad 	orr	w13, w13, #0x30
    402024a4:	3828696d 	strb	w13, [x11, x8]
    402024a8:	d1000508 	sub	x8, x8, #0x1
    402024ac:	f100281f 	cmp	x0, #0xa
    402024b0:	aa0c03e0 	mov	x0, x12
    402024b4:	54fffec2 	b.cs	4020248c <_ZN11jnox_kernel10native_el08unsigned17haaccd95f5c5ba763E+0x24>  // b.hs, b.nlast
    402024b8:	52800309 	mov	w9, #0x18                  	// #24
    402024bc:	72a12009 	movk	w9, #0x900, lsl #16
    402024c0:	91000508 	add	x8, x8, #0x1
    402024c4:	910023ea 	add	x10, sp, #0x8
    402024c8:	52a1200b 	mov	w11, #0x9000000             	// #150994944
    402024cc:	3868694c 	ldrb	w12, [x10, x8]
    402024d0:	b940012d 	ldr	w13, [x9]
    402024d4:	3628006d 	tbz	w13, #5, 402024e0 <_ZN11jnox_kernel10native_el08unsigned17haaccd95f5c5ba763E+0x78>
    402024d8:	d5033fdf 	isb
    402024dc:	17fffffd 	b	402024d0 <_ZN11jnox_kernel10native_el08unsigned17haaccd95f5c5ba763E+0x68>
    402024e0:	91000508 	add	x8, x8, #0x1
    402024e4:	b900016c 	str	w12, [x11]
    402024e8:	f100511f 	cmp	x8, #0x14
    402024ec:	54ffff01 	b.ne	402024cc <_ZN11jnox_kernel10native_el08unsigned17haaccd95f5c5ba763E+0x64>  // b.any
    402024f0:	f94013fe 	ldr	x30, [sp, #32]
    402024f4:	9100c3ff 	add	sp, sp, #0x30
    402024f8:	d65f03c0 	ret
    402024fc:	d503201f 	nop
    40202500:	1007ed42 	adr	x2, 402122a8 <anon.cbe5bd67df0a78360b237d45b75dee21.22.llvm.16067307468115866285>
    40202504:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    40202508:	52800281 	mov	w1, #0x14                  	// #20
    4020250c:	94000d2d 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040202510 <native_el0_sync>:
    40202510:	a9be57fe 	stp	x30, x21, [sp, #-32]!
    40202514:	a9014ff4 	stp	x20, x19, [sp, #16]
    40202518:	d538c008 	mrs	x8, vbar_el1
    4020251c:	d5382009 	mrs	x9, ttbr0_el1
    40202520:	d538600a 	mrs	x10, far_el1
    40202524:	d0000089 	adrp	x9, 40214000 <_ZN11jnox_kernel10native_el012CLOCK_DOMAIN17h874e00fa96a4d8f0E.0.llvm.16067307468115866285>
    40202528:	f947313f 	ldr	xzr, [x9, #3680]
    4020252c:	f110003f 	cmp	x1, #0x400
    40202530:	54000601 	b.ne	402025f0 <native_el0_sync+0xe0>  // b.any
    40202534:	d503201f 	nop
    40202538:	10ff1649 	adr	x9, 40200800 <native_el0_vectors>
    4020253c:	eb09011f 	cmp	x8, x9
    40202540:	54000581 	b.ne	402025f0 <native_el0_sync+0xe0>  // b.any
    40202544:	aa0003f4 	mov	x20, x0
    40202548:	f9408c08 	ldr	x8, [x0, #280]
    4020254c:	f100111f 	cmp	x8, #0x4
    40202550:	54000501 	b.ne	402025f0 <native_el0_sync+0xe0>  // b.any
    40202554:	39440288 	ldrb	w8, [x20, #256]
    40202558:	7200111f 	tst	w8, #0x1f
    4020255c:	540004a1 	b.ne	402025f0 <native_el0_sync+0xe0>  // b.any
    40202560:	f9407e88 	ldr	x8, [x20, #248]
    40202564:	9266d508 	and	x8, x8, #0xfffffffffc00ffff
    40202568:	52894029 	mov	w9, #0x4a01                	// #18945
    4020256c:	72aa8009 	movk	w9, #0x5400, lsl #16
    40202570:	eb09011f 	cmp	x8, x9
    40202574:	540003e1 	b.ne	402025f0 <native_el0_sync+0xe0>  // b.any
    40202578:	aa0203f3 	mov	x19, x2
    4020257c:	f9408695 	ldr	x21, [x20, #264]
    40202580:	94000b58 	bl	402052e0 <_ZN11jnox_kernel14native_el0_mmu6active17hd686f5b0e91753c5E.llvm.14263334612035470596>
    40202584:	f100041f 	cmp	x0, #0x1
    40202588:	54000341 	b.ne	402025f0 <native_el0_sync+0xe0>  // b.any
    4020258c:	aa0103e0 	mov	x0, x1
    40202590:	aa1503e1 	mov	x1, x21
    40202594:	52800082 	mov	w2, #0x4                   	// #4
    40202598:	2a1f03e3 	mov	w3, wzr
    4020259c:	94000b94 	bl	402053ec <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596>
    402025a0:	34000280 	cbz	w0, 402025f0 <native_el0_sync+0xe0>
    402025a4:	f9408a88 	ldr	x8, [x20, #272]
    402025a8:	9281ffe9 	mov	x9, #0xfffffffffffff000    	// #-4096
    402025ac:	f2bfdfe9 	movk	x9, #0xfeff, lsl #16
    402025b0:	8b090109 	add	x9, x8, x9
    402025b4:	f140413f 	cmp	x9, #0x10, lsl #12
    402025b8:	540001c8 	b.hi	402025f0 <native_el0_sync+0xe0>  // b.pmore
    402025bc:	92400d08 	and	x8, x8, #0xf
    402025c0:	b5000188 	cbnz	x8, 402025f0 <native_el0_sync+0xe0>
    402025c4:	f9402288 	ldr	x8, [x20, #64]
    402025c8:	f100051f 	cmp	x8, #0x1
    402025cc:	54000081 	b.ne	402025dc <native_el0_sync+0xcc>  // b.any
    402025d0:	f9400288 	ldr	x8, [x20]
    402025d4:	eb28c11f 	cmp	x8, w8, sxtw
    402025d8:	54000101 	b.ne	402025f8 <native_el0_sync+0xe8>  // b.any
    402025dc:	aa1303e0 	mov	x0, x19
    402025e0:	aa1403e1 	mov	x1, x20
    402025e4:	a9414ff4 	ldp	x20, x19, [sp, #16]
    402025e8:	a8c257fe 	ldp	x30, x21, [sp], #32
    402025ec:	1400080f 	b	40204628 <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E>
    402025f0:	52800040 	mov	w0, #0x2                   	// #2
    402025f4:	97ffff04 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    402025f8:	52800060 	mov	w0, #0x3                   	// #3
    402025fc:	97ffff02 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>

0000000040202600 <native_el0_unexpected>:
    40202600:	f81f0ffe 	str	x30, [sp, #-16]!
    40202604:	52800020 	mov	w0, #0x1                   	// #1
    40202608:	97fffeff 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>

000000004020260c <native_sleep_irq>:
    4020260c:	aa0003e8 	mov	x8, x0
    40202610:	52800189 	mov	w9, #0xc                   	// #12
    40202614:	72a10029 	movk	w9, #0x801, lsl #16
    40202618:	b9400122 	ldr	w2, [x9]
    4020261c:	aa0103e0 	mov	x0, x1
    40202620:	aa0803e1 	mov	x1, x8
    40202624:	14000504 	b	40203a34 <_ZN11jnox_kernel10native_el09extension3irq17hdd6bb6d12c435e54E>

0000000040202628 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E>:
    40202628:	f81b0ffe 	str	x30, [sp, #-80]!
    4020262c:	a90167fa 	stp	x26, x25, [sp, #16]
    40202630:	a9025ff8 	stp	x24, x23, [sp, #32]
    40202634:	a90357f6 	stp	x22, x21, [sp, #48]
    40202638:	a9044ff4 	stp	x20, x19, [sp, #64]
    4020263c:	aa0003f3 	mov	x19, x0
    40202640:	39408008 	ldrb	w8, [x0, #32]
    40202644:	36000128 	tbz	w8, #0, 40202668 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0x40>
    40202648:	3900827f 	strb	wzr, [x19, #32]
    4020264c:	39406268 	ldrb	w8, [x19, #24]
    40202650:	37000088 	tbnz	w8, #0, 40202660 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0x38>
    40202654:	a940da68 	ldp	x8, x22, [x19, #8]
    40202658:	eb16011f 	cmp	x8, x22
    4020265c:	540005c9 	b.ls	40202714 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0xec>  // b.plast
    40202660:	2a1f03e8 	mov	w8, wzr
    40202664:	14000025 	b	402026f8 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0xd0>
    40202668:	f9400034 	ldr	x20, [x1]
    4020266c:	a940da78 	ldp	x24, x22, [x19, #8]
    40202670:	39400055 	ldrb	w21, [x2]
    40202674:	39406277 	ldrb	w23, [x19, #24]
    40202678:	f9400279 	ldr	x25, [x19]
    4020267c:	eb16031f 	cmp	x24, x22
    40202680:	1a9f97e8 	cset	w8, hi  // hi = pmore
    40202684:	2a0802fa 	orr	w26, w23, w8
    40202688:	370002da 	tbnz	w26, #0, 402026e0 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0xb8>
    4020268c:	ab190301 	adds	x1, x24, x25
    40202690:	540002c2 	b.cs	402026e8 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0xc0>  // b.hs, b.nlast
    40202694:	eb16003f 	cmp	x1, x22
    40202698:	1a9f97e8 	cset	w8, hi  // hi = pmore
    4020269c:	5a9f2108 	csinv	w8, w8, wzr, cs  // cs = hs, nlast
    402026a0:	72001d08 	ands	w8, w8, #0xff
    402026a4:	540000e0 	b.eq	402026c0 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0x98>  // b.none
    402026a8:	7103fd1f 	cmp	w8, #0xff
    402026ac:	540001e1 	b.ne	402026e8 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0xc0>  // b.any
    402026b0:	2a1f03f7 	mov	w23, wzr
    402026b4:	91000438 	add	x24, x1, #0x1
    402026b8:	f9000678 	str	x24, [x19, #8]
    402026bc:	14000005 	b	402026d0 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0xa8>
    402026c0:	f9000661 	str	x1, [x19, #8]
    402026c4:	52800037 	mov	w23, #0x1                   	// #1
    402026c8:	39006277 	strb	w23, [x19, #24]
    402026cc:	aa0103f8 	mov	x24, x1
    402026d0:	120002a2 	and	w2, w21, #0x1
    402026d4:	aa1403e0 	mov	x0, x20
    402026d8:	94000913 	bl	40204b24 <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE>
    402026dc:	b5fffd00 	cbnz	x0, 4020267c <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0x54>
    402026e0:	52000348 	eor	w8, w26, #0x1
    402026e4:	14000005 	b	402026f8 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0xd0>
    402026e8:	2a1f03e8 	mov	w8, wzr
    402026ec:	f9000676 	str	x22, [x19, #8]
    402026f0:	52800029 	mov	w9, #0x1                   	// #1
    402026f4:	39006269 	strb	w9, [x19, #24]
    402026f8:	12000100 	and	w0, w8, #0x1
    402026fc:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40202700:	a94357f6 	ldp	x22, x21, [sp, #48]
    40202704:	a9425ff8 	ldp	x24, x23, [sp, #32]
    40202708:	a94167fa 	ldp	x26, x25, [sp, #16]
    4020270c:	f84507fe 	ldr	x30, [sp], #80
    40202710:	d65f03c0 	ret
    40202714:	1a9f37f7 	cset	w23, cs  // cs = hs, nlast
    40202718:	540000a3 	b.cc	4020272c <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0x104>  // b.lo, b.ul, b.last
    4020271c:	52800029 	mov	w9, #0x1                   	// #1
    40202720:	39006269 	strb	w9, [x19, #24]
    40202724:	aa0803f8 	mov	x24, x8
    40202728:	14000003 	b	40202734 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0x10c>
    4020272c:	91000518 	add	x24, x8, #0x1
    40202730:	f9000678 	str	x24, [x19, #8]
    40202734:	f9400034 	ldr	x20, [x1]
    40202738:	39400055 	ldrb	w21, [x2]
    4020273c:	aa1403e0 	mov	x0, x20
    40202740:	aa0803e1 	mov	x1, x8
    40202744:	2a1503e2 	mov	w2, w21
    40202748:	940008f7 	bl	40204b24 <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE>
    4020274c:	b5fff960 	cbnz	x0, 40202678 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0x50>
    40202750:	52800028 	mov	w8, #0x1                   	// #1
    40202754:	17ffffe9 	b	402026f8 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E+0xd0>

0000000040202758 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE>:
    40202758:	d10243ff 	sub	sp, sp, #0x90
    4020275c:	a9037bfd 	stp	x29, x30, [sp, #48]
    40202760:	a9046ffc 	stp	x28, x27, [sp, #64]
    40202764:	a90567fa 	stp	x26, x25, [sp, #80]
    40202768:	a9065ff8 	stp	x24, x23, [sp, #96]
    4020276c:	a90757f6 	stp	x22, x21, [sp, #112]
    40202770:	a9084ff4 	stp	x20, x19, [sp, #128]
    40202774:	aa0803f3 	mov	x19, x8
    40202778:	f1003c3f 	cmp	x1, #0xf
    4020277c:	54000168 	b.hi	402027a8 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x50>  // b.pmore
    40202780:	aa0603f4 	mov	x20, x6
    40202784:	aa0403f9 	mov	x25, x4
    40202788:	aa0103f6 	mov	x22, x1
    4020278c:	aa0303f8 	mov	x24, x3
    40202790:	2a0203fa 	mov	w26, w2
    40202794:	aa0003f7 	mov	x23, x0
    40202798:	92400c88 	and	x8, x4, #0xf
    4020279c:	36000042 	tbz	w2, #0, 402027a4 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x4c>
    402027a0:	aa160108 	orr	x8, x8, x22
    402027a4:	b4000168 	cbz	x8, 402027d0 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x78>
    402027a8:	aa1f03e8 	mov	x8, xzr
    402027ac:	f9000268 	str	x8, [x19]
    402027b0:	a9484ff4 	ldp	x20, x19, [sp, #128]
    402027b4:	a94757f6 	ldp	x22, x21, [sp, #112]
    402027b8:	a9465ff8 	ldp	x24, x23, [sp, #96]
    402027bc:	a94567fa 	ldp	x26, x25, [sp, #80]
    402027c0:	a9446ffc 	ldp	x28, x27, [sp, #64]
    402027c4:	a9437bfd 	ldp	x29, x30, [sp, #48]
    402027c8:	910243ff 	add	sp, sp, #0x90
    402027cc:	d65f03c0 	ret
    402027d0:	8b1612e8 	add	x8, x23, x22, lsl #4
    402027d4:	a90097e8 	stp	x8, x5, [sp, #8]
    402027d8:	b4000716 	cbz	x22, 402028b8 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x160>
    402027dc:	aa1f03e9 	mov	x9, xzr
    402027e0:	aa1703f5 	mov	x21, x23
    402027e4:	f94006bb 	ldr	x27, [x21, #8]
    402027e8:	b100077f 	cmn	x27, #0x1
    402027ec:	54fffde0 	b.eq	402027a8 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x50>  // b.none
    402027f0:	aa1f03e8 	mov	x8, xzr
    402027f4:	8b1b012a 	add	x10, x9, x27
    402027f8:	9100055d 	add	x29, x10, #0x1
    402027fc:	eb0903bf 	cmp	x29, x9
    40202800:	54fffd63 	b.cc	402027ac <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x54>  // b.lo, b.ul, b.last
    40202804:	f11003bf 	cmp	x29, #0x400
    40202808:	54fffd28 	b.hi	402027ac <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x54>  // b.pmore
    4020280c:	f94002bc 	ldr	x28, [x21]
    40202810:	f1003f7f 	cmp	x27, #0xf
    40202814:	54000128 	b.hi	40202838 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0xe0>  // b.pmore
    40202818:	b40001db 	cbz	x27, 40202850 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0xf8>
    4020281c:	aa1c03e8 	mov	x8, x28
    40202820:	aa1b03e9 	mov	x9, x27
    40202824:	3840150a 	ldrb	w10, [x8], #1
    40202828:	34fffc0a 	cbz	w10, 402027a8 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x50>
    4020282c:	f1000529 	subs	x9, x9, #0x1
    40202830:	54ffffa1 	b.ne	40202824 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0xcc>  // b.any
    40202834:	14000007 	b	40202850 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0xf8>
    40202838:	2a1f03e0 	mov	w0, wzr
    4020283c:	aa1c03e1 	mov	x1, x28
    40202840:	aa1b03e2 	mov	x2, x27
    40202844:	94000f2c 	bl	402064f4 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice6memchr14memchr_aligned>
    40202848:	f100041f 	cmp	x0, #0x1
    4020284c:	54fffae0 	b.eq	402027a8 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x50>  // b.none
    40202850:	910063e8 	add	x8, sp, #0x18
    40202854:	aa1c03e0 	mov	x0, x28
    40202858:	aa1b03e1 	mov	x1, x27
    4020285c:	94000e5d 	bl	402061d0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8>
    40202860:	f9400fe8 	ldr	x8, [sp, #24]
    40202864:	b5fffa28 	cbnz	x8, 402027a8 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x50>
    40202868:	910042b5 	add	x21, x21, #0x10
    4020286c:	8b1612e8 	add	x8, x23, x22, lsl #4
    40202870:	eb0802bf 	cmp	x21, x8
    40202874:	aa1d03e9 	mov	x9, x29
    40202878:	54fffb61 	b.ne	402027e4 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x8c>  // b.any
    4020287c:	d503201f 	nop
    40202880:	1007d248 	adr	x8, 402122c8 <anon.cbe5bd67df0a78360b237d45b75dee21.22.llvm.16067307468115866285+0x20>
    40202884:	d503201f 	nop
    40202888:	1007d389 	adr	x9, 402122f8 <anon.cbe5bd67df0a78360b237d45b75dee21.22.llvm.16067307468115866285+0x50>
    4020288c:	7100035f 	cmp	w26, #0x0
    40202890:	9a88113c 	csel	x28, x9, x8, ne  // ne = any
    40202894:	52800068 	mov	w8, #0x3                   	// #3
    40202898:	9a9f1515 	csinc	x21, x8, xzr, ne  // ne = any
    4020289c:	8b1602ba 	add	x26, x21, x22
    402028a0:	d37df348 	lsl	x8, x26, #3
    402028a4:	9100611b 	add	x27, x8, #0x18
    402028a8:	8b1a0fa8 	add	x8, x29, x26, lsl #3
    402028ac:	1100c108 	add	w8, w8, #0x30
    402028b0:	927c1d16 	and	x22, x8, #0xff0
    402028b4:	1400000c 	b	402028e4 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x18c>
    402028b8:	d503201f 	nop
    402028bc:	1007d068 	adr	x8, 402122c8 <anon.cbe5bd67df0a78360b237d45b75dee21.22.llvm.16067307468115866285+0x20>
    402028c0:	d503201f 	nop
    402028c4:	1007d1a9 	adr	x9, 402122f8 <anon.cbe5bd67df0a78360b237d45b75dee21.22.llvm.16067307468115866285+0x50>
    402028c8:	7100035f 	cmp	w26, #0x0
    402028cc:	9a88113c 	csel	x28, x9, x8, ne  // ne = any
    402028d0:	52800068 	mov	w8, #0x3                   	// #3
    402028d4:	9a9f151a 	csinc	x26, x8, xzr, ne  // ne = any
    402028d8:	52800a16 	mov	w22, #0x50                  	// #80
    402028dc:	5280061b 	mov	w27, #0x30                  	// #48
    402028e0:	aa1a03f5 	mov	x21, x26
    402028e4:	eb160339 	subs	x25, x25, x22
    402028e8:	54fff603 	b.cc	402027a8 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x50>  // b.lo, b.ul, b.last
    402028ec:	aa1f03e8 	mov	x8, xzr
    402028f0:	f112c2df 	cmp	x22, #0x4b0
    402028f4:	54fff5c8 	b.hi	402027ac <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x54>  // b.pmore
    402028f8:	eb18033f 	cmp	x25, x24
    402028fc:	54fff583 	b.cc	402027ac <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x54>  // b.lo, b.ul, b.last
    40202900:	eb1402df 	cmp	x22, x20
    40202904:	54fff548 	b.hi	402027ac <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x54>  // b.pmore
    40202908:	f9400bf4 	ldr	x20, [sp, #16]
    4020290c:	aa1403e0 	mov	x0, x20
    40202910:	2a1f03e1 	mov	w1, wzr
    40202914:	aa1603e2 	mov	x2, x22
    40202918:	94001115 	bl	40206d6c <memset>
    4020291c:	3900029a 	strb	w26, [x20]
    40202920:	d368ff48 	lsr	x8, x26, #40
    40202924:	d360ff49 	lsr	x9, x26, #32
    40202928:	39001688 	strb	w8, [x20, #5]
    4020292c:	aa1403e8 	mov	x8, x20
    40202930:	38004d09 	strb	w9, [x8, #4]!
    40202934:	d358ff49 	lsr	x9, x26, #24
    40202938:	39000e89 	strb	w9, [x20, #3]
    4020293c:	d350ff49 	lsr	x9, x26, #16
    40202940:	39000a89 	strb	w9, [x20, #2]
    40202944:	d378ff49 	lsr	x9, x26, #56
    40202948:	39000d09 	strb	w9, [x8, #3]
    4020294c:	d370ff49 	lsr	x9, x26, #48
    40202950:	39000909 	strb	w9, [x8, #2]
    40202954:	d348ff48 	lsr	x8, x26, #8
    40202958:	8b151389 	add	x9, x28, x21, lsl #4
    4020295c:	f90003e9 	str	x9, [sp]
    40202960:	52800118 	mov	w24, #0x8                   	// #8
    40202964:	39000688 	strb	w8, [x20, #1]
    40202968:	b40000fc 	cbz	x28, 40202984 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x22c>
    4020296c:	f94003e8 	ldr	x8, [sp]
    40202970:	eb08039f 	cmp	x28, x8
    40202974:	54000080 	b.eq	40202984 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x22c>  // b.none
    40202978:	9100439d 	add	x29, x28, #0x10
    4020297c:	aa1703f4 	mov	x20, x23
    40202980:	14000007 	b	4020299c <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x244>
    40202984:	f94007e8 	ldr	x8, [sp, #8]
    40202988:	eb0802ff 	cmp	x23, x8
    4020298c:	540005a0 	b.eq	40202a40 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x2e8>  // b.none
    40202990:	aa1f03fd 	mov	x29, xzr
    40202994:	910042f4 	add	x20, x23, #0x10
    40202998:	aa1703fc 	mov	x28, x23
    4020299c:	f9400782 	ldr	x2, [x28, #8]
    402029a0:	ab1b0049 	adds	x9, x2, x27
    402029a4:	54fff022 	b.cs	402027a8 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x50>  // b.hs, b.nlast
    402029a8:	b1000535 	adds	x21, x9, #0x1
    402029ac:	54ffefe2 	b.cs	402027a8 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x50>  // b.hs, b.nlast
    402029b0:	aa1f03e8 	mov	x8, xzr
    402029b4:	8b19036a 	add	x10, x27, x25
    402029b8:	eb19015f 	cmp	x10, x25
    402029bc:	54ffef83 	b.cc	402027ac <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x54>  // b.lo, b.ul, b.last
    402029c0:	eb1602bf 	cmp	x21, x22
    402029c4:	54ffef48 	b.hi	402027ac <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x54>  // b.pmore
    402029c8:	eb16031f 	cmp	x24, x22
    402029cc:	54ffef02 	b.cs	402027ac <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x54>  // b.hs, b.nlast
    402029d0:	f9400381 	ldr	x1, [x28]
    402029d4:	f9400bec 	ldr	x12, [sp, #16]
    402029d8:	8b180188 	add	x8, x12, x24
    402029dc:	3900010a 	strb	w10, [x8]
    402029e0:	d368fd4b 	lsr	x11, x10, #40
    402029e4:	3900150b 	strb	w11, [x8, #5]
    402029e8:	d358fd4b 	lsr	x11, x10, #24
    402029ec:	39000d0b 	strb	w11, [x8, #3]
    402029f0:	d350fd4b 	lsr	x11, x10, #16
    402029f4:	3900090b 	strb	w11, [x8, #2]
    402029f8:	d348fd4b 	lsr	x11, x10, #8
    402029fc:	3900050b 	strb	w11, [x8, #1]
    40202a00:	d360fd4b 	lsr	x11, x10, #32
    40202a04:	38004d0b 	strb	w11, [x8, #4]!
    40202a08:	d378fd4b 	lsr	x11, x10, #56
    40202a0c:	39000d0b 	strb	w11, [x8, #3]
    40202a10:	d370fd4a 	lsr	x10, x10, #48
    40202a14:	eb16013f 	cmp	x9, x22
    40202a18:	3900090a 	strb	w10, [x8, #2]
    40202a1c:	54ffec68 	b.hi	402027a8 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x50>  // b.pmore
    40202a20:	8b1b0180 	add	x0, x12, x27
    40202a24:	94001046 	bl	40206b3c <memcpy>
    40202a28:	91002318 	add	x24, x24, #0x8
    40202a2c:	aa1d03fc 	mov	x28, x29
    40202a30:	aa1403f7 	mov	x23, x20
    40202a34:	aa1503fb 	mov	x27, x21
    40202a38:	b5fff9bc 	cbnz	x28, 4020296c <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x214>
    40202a3c:	17ffffd2 	b	40202984 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x22c>
    40202a40:	a900da79 	stp	x25, x22, [x19, #8]
    40202a44:	52800028 	mov	w8, #0x1                   	// #1
    40202a48:	f9000e7a 	str	x26, [x19, #24]
    40202a4c:	17ffff58 	b	402027ac <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE+0x54>

0000000040202a50 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E>:
    40202a50:	d105c3ff 	sub	sp, sp, #0x170
    40202a54:	a9117bfd 	stp	x29, x30, [sp, #272]
    40202a58:	a9126ffc 	stp	x28, x27, [sp, #288]
    40202a5c:	a91367fa 	stp	x26, x25, [sp, #304]
    40202a60:	a9145ff8 	stp	x24, x23, [sp, #320]
    40202a64:	a91557f6 	stp	x22, x21, [sp, #336]
    40202a68:	a9164ff4 	stp	x20, x19, [sp, #352]
    40202a6c:	f9401409 	ldr	x9, [x0, #40]
    40202a70:	eb09003f 	cmp	x1, x9
    40202a74:	540000a2 	b.cs	40202a88 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x38>  // b.hs, b.nlast
    40202a78:	528000a9 	mov	w9, #0x5                   	// #5
    40202a7c:	79005109 	strh	w9, [x8, #40]
    40202a80:	f900011f 	str	xzr, [x8]
    40202a84:	140000bc 	b	40202d74 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x324>
    40202a88:	aa0503f9 	mov	x25, x5
    40202a8c:	aa0003f8 	mov	x24, x0
    40202a90:	aa0103f7 	mov	x23, x1
    40202a94:	aa0203fa 	mov	x26, x2
    40202a98:	f9001401 	str	x1, [x0, #40]
    40202a9c:	f9401809 	ldr	x9, [x0, #48]
    40202aa0:	f90017e9 	str	x9, [sp, #40]
    40202aa4:	eb09005f 	cmp	x2, x9
    40202aa8:	54000049 	b.ls	40202ab0 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x60>  // b.plast
    40202aac:	a9035f1a 	stp	x26, x23, [x24, #48]
    40202ab0:	f9000be6 	str	x6, [sp, #16]
    40202ab4:	f90013e7 	str	x7, [sp, #32]
    40202ab8:	a90313e8 	stp	x8, x4, [sp, #48]
    40202abc:	f940071d 	ldr	x29, [x24, #8]
    40202ac0:	b400199d 	cbz	x29, 40202df0 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x3a0>
    40202ac4:	3945c3e8 	ldrb	w8, [sp, #368]
    40202ac8:	b9001fe8 	str	w8, [sp, #28]
    40202acc:	f9400314 	ldr	x20, [x24]
    40202ad0:	a941a309 	ldp	x9, x8, [x24, #24]
    40202ad4:	cb0802e8 	sub	x8, x23, x8
    40202ad8:	f9400b16 	ldr	x22, [x24, #16]
    40202adc:	9add090a 	udiv	x10, x8, x29
    40202ae0:	9b1da15b 	msub	x27, x10, x29, x8
    40202ae4:	8b160135 	add	x21, x9, x22
    40202ae8:	eb1b02df 	cmp	x22, x27
    40202aec:	fa5b92a0 	ccmp	x21, x27, #0x0, ls  // ls = plast
    40202af0:	1a9f97f3 	cset	w19, hi  // hi = pmore
    40202af4:	910103fc 	add	x28, sp, #0x40
    40202af8:	910103e0 	add	x0, sp, #0x40
    40202afc:	aa0303e1 	mov	x1, x3
    40202b00:	52800c02 	mov	w2, #0x60                  	// #96
    40202b04:	9400100e 	bl	40206b3c <memcpy>
    40202b08:	52800308 	mov	w8, #0x18                  	// #24
    40202b0c:	f1000694 	subs	x20, x20, #0x1
    40202b10:	1a9f37e9 	cset	w9, cs  // cs = hs, nlast
    40202b14:	4a090269 	eor	w9, w19, w9
    40202b18:	38686b8a 	ldrb	w10, [x28, x8]
    40202b1c:	0a0a0129 	and	w9, w9, w10
    40202b20:	38286b89 	strb	w9, [x28, x8]
    40202b24:	91008108 	add	x8, x8, #0x20
    40202b28:	f101e11f 	cmp	x8, #0x78
    40202b2c:	54ffff01 	b.ne	40202b0c <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0xbc>  // b.any
    40202b30:	36000173 	tbz	w19, #0, 40202b5c <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x10c>
    40202b34:	2a1f03f8 	mov	w24, wzr
    40202b38:	aa1f03e8 	mov	x8, xzr
    40202b3c:	cb1b02a9 	sub	x9, x21, x27
    40202b40:	eb19013f 	cmp	x9, x25
    40202b44:	9a993129 	csel	x9, x9, x25, cc  // cc = lo, ul, last
    40202b48:	aa3703ea 	mvn	x10, x23
    40202b4c:	eb09015f 	cmp	x10, x9
    40202b50:	da972122 	csinv	x2, x9, x23, cs  // cs = hs, nlast
    40202b54:	528000f7 	mov	w23, #0x7                   	// #7
    40202b58:	14000068 	b	40202cf8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x2a8>
    40202b5c:	eb1b02c8 	subs	x8, x22, x27
    40202b60:	9a9d83e9 	csel	x9, xzr, x29, hi  // hi = pmore
    40202b64:	8b090108 	add	x8, x8, x9
    40202b68:	eb19011f 	cmp	x8, x25
    40202b6c:	9a993108 	csel	x8, x8, x25, cc  // cc = lo, ul, last
    40202b70:	aa3703e9 	mvn	x9, x23
    40202b74:	eb08013f 	cmp	x9, x8
    40202b78:	da972102 	csinv	x2, x8, x23, cs  // cs = hs, nlast
    40202b7c:	f94017e8 	ldr	x8, [sp, #40]
    40202b80:	eb08035f 	cmp	x26, x8
    40202b84:	540000a2 	b.cs	40202b98 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x148>  // b.hs, b.nlast
    40202b88:	2a1f03f8 	mov	w24, wzr
    40202b8c:	aa1f03e8 	mov	x8, xzr
    40202b90:	528000b7 	mov	w23, #0x5                   	// #5
    40202b94:	14000059 	b	40202cf8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x2a8>
    40202b98:	a943a708 	ldp	x8, x9, [x24, #56]
    40202b9c:	cb0802e8 	sub	x8, x23, x8
    40202ba0:	eb09011f 	cmp	x8, x9
    40202ba4:	540009c2 	b.cs	40202cdc <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x28c>  // b.hs, b.nlast
    40202ba8:	f94013e1 	ldr	x1, [sp, #32]
    40202bac:	b4000a01 	cbz	x1, 40202cec <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x29c>
    40202bb0:	aa1f03e8 	mov	x8, xzr
    40202bb4:	2a1f03f8 	mov	w24, wzr
    40202bb8:	52800097 	mov	w23, #0x4                   	// #4
    40202bbc:	f100403f 	cmp	x1, #0x10
    40202bc0:	540009c8 	b.hi	40202cf8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x2a8>  // b.pmore
    40202bc4:	b9401fef 	ldr	w15, [sp, #28]
    40202bc8:	12001de9 	and	w9, w15, #0xff
    40202bcc:	7100413f 	cmp	w9, #0x10
    40202bd0:	54000948 	b.hi	40202cf8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x2a8>  // b.pmore
    40202bd4:	8b010828 	add	x8, x1, x1, lsl #2
    40202bd8:	d37df108 	lsl	x8, x8, #3
    40202bdc:	f9400bee 	ldr	x14, [sp, #16]
    40202be0:	910005c9 	add	x9, x14, #0x1
    40202be4:	385ff12a 	ldurb	w10, [x9, #-1]
    40202be8:	5100094b 	sub	w11, w10, #0x2
    40202bec:	7100097f 	cmp	w11, #0x2
    40202bf0:	54000203 	b.cc	40202c30 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x1e0>  // b.lo, b.ul, b.last
    40202bf4:	350000aa 	cbnz	w10, 40202c08 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x1b8>
    40202bf8:	3940012a 	ldrb	w10, [x9]
    40202bfc:	6b01015f 	cmp	w10, w1
    40202c00:	54000ca2 	b.cs	40202d94 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x344>  // b.hs, b.nlast
    40202c04:	1400000b 	b	40202c30 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x1e0>
    40202c08:	3940012a 	ldrb	w10, [x9]
    40202c0c:	7100095f 	cmp	w10, #0x2
    40202c10:	54000c28 	b.hi	40202d94 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x344>  // b.pmore
    40202c14:	3940092a 	ldrb	w10, [x9, #2]
    40202c18:	52800097 	mov	w23, #0x4                   	// #4
    40202c1c:	eb0a003f 	cmp	x1, x10
    40202c20:	54000dc9 	b.ls	40202dd8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x388>  // b.plast
    40202c24:	3940052a 	ldrb	w10, [x9, #1]
    40202c28:	eb0a003f 	cmp	x1, x10
    40202c2c:	54000d69 	b.ls	40202dd8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x388>  // b.plast
    40202c30:	9100a129 	add	x9, x9, #0x28
    40202c34:	f100a108 	subs	x8, x8, #0x28
    40202c38:	54fffd61 	b.ne	40202be4 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x194>  // b.any
    40202c3c:	72001dff 	tst	w15, #0xff
    40202c40:	54000b20 	b.eq	40202da4 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x354>  // b.none
    40202c44:	aa1f03e0 	mov	x0, xzr
    40202c48:	52800038 	mov	w24, #0x1                   	// #1
    40202c4c:	52800508 	mov	w8, #0x28                  	// #40
    40202c50:	910103e9 	add	x9, sp, #0x40
    40202c54:	5280004a 	mov	w10, #0x2                   	// #2
    40202c58:	12001f0b 	and	w11, w24, #0xff
    40202c5c:	6b2f017f 	cmp	w11, w15, uxtb
    40202c60:	1a98270b 	cinc	w11, w24, cc  // cc = lo, ul, last
    40202c64:	eb01001f 	cmp	x0, x1
    40202c68:	54000ca2 	b.cs	40202dfc <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x3ac>  // b.hs, b.nlast
    40202c6c:	9b08380c 	madd	x12, x0, x8, x14
    40202c70:	3940018d 	ldrb	w13, [x12]
    40202c74:	710001bf 	cmp	w13, #0x0
    40202c78:	5400018d 	b.le	40202ca8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x258>
    40202c7c:	710005bf 	cmp	w13, #0x1
    40202c80:	540009a1 	b.ne	40202db4 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x364>  // b.any
    40202c84:	39400580 	ldrb	w0, [x12, #1]
    40202c88:	f1000c1f 	cmp	x0, #0x3
    40202c8c:	54000be2 	b.cs	40202e08 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x3b8>  // b.hs, b.nlast
    40202c90:	8b00152d 	add	x13, x9, x0, lsl #5
    40202c94:	394061ad 	ldrb	w13, [x13, #24]
    40202c98:	710001bf 	cmp	w13, #0x0
    40202c9c:	9a8a154d 	cinc	x13, x10, eq  // eq = none
    40202ca0:	386d698c 	ldrb	w12, [x12, x13]
    40202ca4:	14000002 	b	40202cac <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x25c>
    40202ca8:	3940058c 	ldrb	w12, [x12, #1]
    40202cac:	12001f0d 	and	w13, w24, #0xff
    40202cb0:	52800057 	mov	w23, #0x2                   	// #2
    40202cb4:	6b2f01bf 	cmp	w13, w15, uxtb
    40202cb8:	540000c2 	b.cs	40202cd0 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x280>  // b.hs, b.nlast
    40202cbc:	92401d80 	and	x0, x12, #0xff
    40202cc0:	12001d6c 	and	w12, w11, #0xff
    40202cc4:	6b2f019f 	cmp	w12, w15, uxtb
    40202cc8:	2a0b03f8 	mov	w24, w11
    40202ccc:	54fffc69 	b.ls	40202c58 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x208>  // b.plast
    40202cd0:	aa1f03e8 	mov	x8, xzr
    40202cd4:	2a0f03f8 	mov	w24, w15
    40202cd8:	14000008 	b	40202cf8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x2a8>
    40202cdc:	2a1f03f8 	mov	w24, wzr
    40202ce0:	aa1f03e8 	mov	x8, xzr
    40202ce4:	52800077 	mov	w23, #0x3                   	// #3
    40202ce8:	14000004 	b	40202cf8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x2a8>
    40202cec:	2a1f03f8 	mov	w24, wzr
    40202cf0:	aa1f03e8 	mov	x8, xzr
    40202cf4:	52800117 	mov	w23, #0x8                   	// #8
    40202cf8:	a94eabe9 	ldp	x9, x10, [sp, #232]
    40202cfc:	a90a27e8 	stp	x8, x9, [sp, #160]
    40202d00:	a94fa7e8 	ldp	x8, x9, [sp, #248]
    40202d04:	a90b23ea 	stp	x10, x8, [sp, #176]
    40202d08:	f90063e9 	str	x9, [sp, #192]
    40202d0c:	9103a3e8 	add	x8, sp, #0xe8
    40202d10:	910103e0 	add	x0, sp, #0x40
    40202d14:	910283e3 	add	x3, sp, #0xa0
    40202d18:	f9401fe1 	ldr	x1, [sp, #56]
    40202d1c:	9400009c 	bl	40202f8c <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E>
    40202d20:	f94077e8 	ldr	x8, [sp, #232]
    40202d24:	b40000c8 	cbz	x8, 40202d3c <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x2ec>
    40202d28:	f100091f 	cmp	x8, #0x2
    40202d2c:	f9401beb 	ldr	x11, [sp, #48]
    40202d30:	540000a1 	b.ne	40202d44 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x2f4>  // b.any
    40202d34:	aa1f03e8 	mov	x8, xzr
    40202d38:	14000008 	b	40202d58 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x308>
    40202d3c:	2a1f03f7 	mov	w23, wzr
    40202d40:	f9401beb 	ldr	x11, [sp, #48]
    40202d44:	a94f27e8 	ldp	x8, x9, [sp, #240]
    40202d48:	a90ca7e8 	stp	x8, x9, [sp, #200]
    40202d4c:	a95027e8 	ldp	x8, x9, [sp, #256]
    40202d50:	a90da7e8 	stp	x8, x9, [sp, #216]
    40202d54:	52800028 	mov	w8, #0x1                   	// #1
    40202d58:	3900a177 	strb	w23, [x11, #40]
    40202d5c:	3900a578 	strb	w24, [x11, #41]
    40202d60:	a94cabe9 	ldp	x9, x10, [sp, #200]
    40202d64:	a9002568 	stp	x8, x9, [x11]
    40202d68:	a94da7e8 	ldp	x8, x9, [sp, #216]
    40202d6c:	a901216a 	stp	x10, x8, [x11, #16]
    40202d70:	f9001169 	str	x9, [x11, #32]
    40202d74:	a9564ff4 	ldp	x20, x19, [sp, #352]
    40202d78:	a95557f6 	ldp	x22, x21, [sp, #336]
    40202d7c:	a9545ff8 	ldp	x24, x23, [sp, #320]
    40202d80:	a95367fa 	ldp	x26, x25, [sp, #304]
    40202d84:	a9526ffc 	ldp	x28, x27, [sp, #288]
    40202d88:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40202d8c:	9105c3ff 	add	sp, sp, #0x170
    40202d90:	d65f03c0 	ret
    40202d94:	2a1f03f8 	mov	w24, wzr
    40202d98:	aa1f03e8 	mov	x8, xzr
    40202d9c:	52800097 	mov	w23, #0x4                   	// #4
    40202da0:	17ffffd6 	b	40202cf8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x2a8>
    40202da4:	2a1f03f8 	mov	w24, wzr
    40202da8:	aa1f03e8 	mov	x8, xzr
    40202dac:	52800057 	mov	w23, #0x2                   	// #2
    40202db0:	17ffffd2 	b	40202cf8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x2a8>
    40202db4:	710009bf 	cmp	w13, #0x2
    40202db8:	54000161 	b.ne	40202de4 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x394>  // b.any
    40202dbc:	a940a588 	ldp	x8, x9, [x12, #8]
    40202dc0:	a90ea7e8 	stp	x8, x9, [sp, #232]
    40202dc4:	a941a588 	ldp	x8, x9, [x12, #24]
    40202dc8:	a90fa7e8 	stp	x8, x9, [sp, #248]
    40202dcc:	52800037 	mov	w23, #0x1                   	// #1
    40202dd0:	52800028 	mov	w8, #0x1                   	// #1
    40202dd4:	17ffffc9 	b	40202cf8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x2a8>
    40202dd8:	2a1f03f8 	mov	w24, wzr
    40202ddc:	aa1f03e8 	mov	x8, xzr
    40202de0:	17ffffc6 	b	40202cf8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x2a8>
    40202de4:	aa1f03e8 	mov	x8, xzr
    40202de8:	528000d7 	mov	w23, #0x6                   	// #6
    40202dec:	17ffffc3 	b	40202cf8 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E+0x2a8>
    40202df0:	d503201f 	nop
    40202df4:	1007a9a0 	adr	x0, 40212328 <anon.cbe5bd67df0a78360b237d45b75dee21.22.llvm.16067307468115866285+0x80>
    40202df8:	94000dfd 	bl	402065ec <_RNvNtNtCsbcsGJ9IzBgZ_4core9panicking11panic_const23panic_const_rem_by_zero>
    40202dfc:	d503201f 	nop
    40202e00:	1007aa02 	adr	x2, 40212340 <anon.cbe5bd67df0a78360b237d45b75dee21.22.llvm.16067307468115866285+0x98>
    40202e04:	94000aef 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40202e08:	d503201f 	nop
    40202e0c:	1007aa62 	adr	x2, 40212358 <anon.cbe5bd67df0a78360b237d45b75dee21.22.llvm.16067307468115866285+0xb0>
    40202e10:	52800061 	mov	w1, #0x3                   	// #3
    40202e14:	94000aeb 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040202e18 <_ZN4core5array40_$LT$impl$u20$$u5b$T$u3b$$u20$N$u5d$$GT$3map17h8a5701cd35e00332E>:
    40202e18:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40202e1c:	a90157f6 	stp	x22, x21, [sp, #16]
    40202e20:	a9024ff4 	stp	x20, x19, [sp, #32]
    40202e24:	d11d03ff 	sub	sp, sp, #0x740
    40202e28:	f90003ff 	str	xzr, [sp]
    40202e2c:	aa0003f4 	mov	x20, x0
    40202e30:	aa0803f3 	mov	x19, x8
    40202e34:	aa1f03f5 	mov	x21, xzr
    40202e38:	910003f6 	mov	x22, sp
    40202e3c:	a8c20680 	ldp	x0, x1, [x20], #32
    40202e40:	9115c3e8 	add	x8, sp, #0x570
    40202e44:	97fffa70 	bl	40201804 <_ZN11jnox_kernel10native_el015validated_image17h6ca62dc7838e1c92E>
    40202e48:	8b1502c0 	add	x0, x22, x21
    40202e4c:	9115c3e1 	add	x1, sp, #0x570
    40202e50:	52803a02 	mov	w2, #0x1d0                 	// #464
    40202e54:	94000f3a 	bl	40206b3c <memcpy>
    40202e58:	910742b5 	add	x21, x21, #0x1d0
    40202e5c:	f115c2bf 	cmp	x21, #0x570
    40202e60:	54fffee1 	b.ne	40202e3c <_ZN4core5array40_$LT$impl$u20$$u5b$T$u3b$$u20$N$u5d$$GT$3map17h8a5701cd35e00332E+0x24>  // b.any
    40202e64:	910003e1 	mov	x1, sp
    40202e68:	aa1303e0 	mov	x0, x19
    40202e6c:	5280ae02 	mov	w2, #0x570                 	// #1392
    40202e70:	94000f33 	bl	40206b3c <memcpy>
    40202e74:	911d03ff 	add	sp, sp, #0x740
    40202e78:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40202e7c:	a94157f6 	ldp	x22, x21, [sp, #16]
    40202e80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40202e84:	d65f03c0 	ret

0000000040202e88 <_RNvCsfLfy6EI15iL_7___rustc17rust_begin_unwind>:
    40202e88:	d503205f 	wfe
    40202e8c:	17ffffff 	b	40202e88 <_RNvCsfLfy6EI15iL_7___rustc17rust_begin_unwind>

0000000040202e90 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17h89e86ab78413ed11E>:
    40202e90:	d100c3ff 	sub	sp, sp, #0x30
    40202e94:	a9024ffe 	stp	x30, x19, [sp, #32]
    40202e98:	f100083f 	cmp	x1, #0x2
    40202e9c:	54000368 	b.hi	40202f08 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17h89e86ab78413ed11E+0x78>  // b.pmore
    40202ea0:	aa0803f3 	mov	x19, x8
    40202ea4:	d503201f 	nop
    40202ea8:	1007a748 	adr	x8, 40212390 <anon.773058ed228f2edaafa50d5b0d646736.2.llvm.4321263285462747625>
    40202eac:	8b011108 	add	x8, x8, x1, lsl #4
    40202eb0:	a9402909 	ldp	x9, x10, [x8]
    40202eb4:	a9402c08 	ldp	x8, x11, [x0]
    40202eb8:	f9400103 	ldr	x3, [x8]
    40202ebc:	52809608 	mov	w8, #0x4b0                 	// #1200
    40202ec0:	9b082c25 	madd	x5, x1, x8, x11
    40202ec4:	910003e8 	mov	x8, sp
    40202ec8:	aa0903e0 	mov	x0, x9
    40202ecc:	aa0a03e1 	mov	x1, x10
    40202ed0:	2a1f03e2 	mov	w2, wzr
    40202ed4:	52820004 	mov	w4, #0x1000                	// #4096
    40202ed8:	72a02024 	movk	w4, #0x101, lsl #16
    40202edc:	52809606 	mov	w6, #0x4b0                 	// #1200
    40202ee0:	97fffe1e 	bl	40202758 <_ZN11jnox_kernel10native_el012native_stack5build17h97bf43d44c82c79eE>
    40202ee4:	b94003e8 	ldr	w8, [sp]
    40202ee8:	360001a8 	tbz	w8, #0, 40202f1c <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17h89e86ab78413ed11E+0x8c>
    40202eec:	a940a7e8 	ldp	x8, x9, [sp, #8]
    40202ef0:	a9002668 	stp	x8, x9, [x19]
    40202ef4:	f9400fe8 	ldr	x8, [sp, #24]
    40202ef8:	f9000a68 	str	x8, [x19, #16]
    40202efc:	a9424ffe 	ldp	x30, x19, [sp, #32]
    40202f00:	9100c3ff 	add	sp, sp, #0x30
    40202f04:	d65f03c0 	ret
    40202f08:	d503201f 	nop
    40202f0c:	1007a5a2 	adr	x2, 402123c0 <anon.773058ed228f2edaafa50d5b0d646736.4.llvm.4321263285462747625>
    40202f10:	aa0103e0 	mov	x0, x1
    40202f14:	52800061 	mov	w1, #0x3                   	// #3
    40202f18:	94000aaa 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40202f1c:	52800260 	mov	w0, #0x13                  	// #19
    40202f20:	97fffcb9 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>

0000000040202f24 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17h8ae4175834463596E>:
    40202f24:	f81f0ffe 	str	x30, [sp, #-16]!
    40202f28:	f100083f 	cmp	x1, #0x2
    40202f2c:	54000268 	b.hi	40202f78 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17h8ae4175834463596E+0x54>  // b.pmore
    40202f30:	f9400408 	ldr	x8, [x0, #8]
    40202f34:	52800309 	mov	w9, #0x18                  	// #24
    40202f38:	9b092028 	madd	x8, x1, x9, x8
    40202f3c:	f9400508 	ldr	x8, [x8, #8]
    40202f40:	f112c51f 	cmp	x8, #0x4b1
    40202f44:	540000e2 	b.cs	40202f60 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17h8ae4175834463596E+0x3c>  // b.hs, b.nlast
    40202f48:	f9400009 	ldr	x9, [x0]
    40202f4c:	5280960a 	mov	w10, #0x4b0                 	// #1200
    40202f50:	9b0a2420 	madd	x0, x1, x10, x9
    40202f54:	aa0803e1 	mov	x1, x8
    40202f58:	f84107fe 	ldr	x30, [sp], #16
    40202f5c:	d65f03c0 	ret
    40202f60:	d503201f 	nop
    40202f64:	1007a463 	adr	x3, 402123f0 <anon.773058ed228f2edaafa50d5b0d646736.6.llvm.4321263285462747625>
    40202f68:	aa1f03e0 	mov	x0, xzr
    40202f6c:	aa0803e1 	mov	x1, x8
    40202f70:	52809602 	mov	w2, #0x4b0                 	// #1200
    40202f74:	94000d33 	bl	40206440 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>
    40202f78:	d503201f 	nop
    40202f7c:	1007a2e2 	adr	x2, 402123d8 <anon.773058ed228f2edaafa50d5b0d646736.5.llvm.4321263285462747625>
    40202f80:	aa0103e0 	mov	x0, x1
    40202f84:	52800061 	mov	w1, #0x3                   	// #3
    40202f88:	94000a8e 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040202f8c <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E>:
    40202f8c:	b40005a1 	cbz	x1, 40203040 <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E+0xb4>
    40202f90:	b4000582 	cbz	x2, 40203040 <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E+0xb4>
    40202f94:	b9400069 	ldr	w9, [x3]
    40202f98:	36000389 	tbz	w9, #0, 40203008 <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E+0x7c>
    40202f9c:	f9400469 	ldr	x9, [x3, #8]
    40202fa0:	f100093f 	cmp	x9, #0x2
    40202fa4:	54000328 	b.hi	40203008 <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E+0x7c>  // b.pmore
    40202fa8:	8b09140c 	add	x12, x0, x9, lsl #5
    40202fac:	3940618a 	ldrb	w10, [x12, #24]
    40202fb0:	7100055f 	cmp	w10, #0x1
    40202fb4:	540002a1 	b.ne	40203008 <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E+0x7c>  // b.any
    40202fb8:	f940086b 	ldr	x11, [x3, #16]
    40202fbc:	f940018a 	ldr	x10, [x12]
    40202fc0:	eb0b015f 	cmp	x10, x11
    40202fc4:	54000221 	b.ne	40203008 <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E+0x7c>  // b.any
    40202fc8:	3940806a 	ldrb	w10, [x3, #32]
    40202fcc:	f940058d 	ldr	x13, [x12, #8]
    40202fd0:	5280002e 	mov	w14, #0x1                   	// #1
    40202fd4:	9aca21ce 	lsl	x14, x14, x10
    40202fd8:	7101015f 	cmp	w10, #0x40
    40202fdc:	9a9f31ce 	csel	x14, x14, xzr, cc  // cc = lo, ul, last
    40202fe0:	8a0101ce 	and	x14, x14, x1
    40202fe4:	ea0d01df 	tst	x14, x13
    40202fe8:	54000100 	b.eq	40203008 <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E+0x7c>  // b.none
    40202fec:	f9400c6d 	ldr	x13, [x3, #24]
    40202ff0:	b40000cd 	cbz	x13, 40203008 <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E+0x7c>
    40202ff4:	f940098c 	ldr	x12, [x12, #16]
    40202ff8:	eb02019f 	cmp	x12, x2
    40202ffc:	9a82318c 	csel	x12, x12, x2, cc  // cc = lo, ul, last
    40203000:	eb0c01bf 	cmp	x13, x12
    40203004:	54000349 	b.ls	4020306c <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E+0xe0>  // b.plast
    40203008:	aa1f03e9 	mov	x9, xzr
    4020300c:	9100400a 	add	x10, x0, #0x10
    40203010:	52800c0b 	mov	w11, #0x60                  	// #96
    40203014:	f85f814c 	ldur	x12, [x10, #-8]
    40203018:	ea01018c 	ands	x12, x12, x1
    4020301c:	540000a0 	b.eq	40203030 <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E+0xa4>  // b.none
    40203020:	3940214d 	ldrb	w13, [x10, #8]
    40203024:	3600006d 	tbz	w13, #0, 40203030 <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E+0xa4>
    40203028:	f940014d 	ldr	x13, [x10]
    4020302c:	b500010d 	cbnz	x13, 4020304c <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E+0xc0>
    40203030:	91000529 	add	x9, x9, #0x1
    40203034:	f100816b 	subs	x11, x11, #0x20
    40203038:	9100814a 	add	x10, x10, #0x20
    4020303c:	54fffec1 	b.ne	40203014 <_ZN11jnox_kernel10native_el012group_policy13gate_decision17h971dd6f4a7ce24f9E+0x88>  // b.any
    40203040:	52800049 	mov	w9, #0x2                   	// #2
    40203044:	f9000109 	str	x9, [x8]
    40203048:	d65f03c0 	ret
    4020304c:	f85f014a 	ldur	x10, [x10, #-16]
    40203050:	dac0018b 	rbit	x11, x12
    40203054:	5280002c 	mov	w12, #0x1                   	// #1
    40203058:	a900250c 	stp	x12, x9, [x8]
    4020305c:	dac01169 	clz	x9, x11
    40203060:	a901310a 	stp	x10, x12, [x8, #16]
    40203064:	39008109 	strb	w9, [x8, #32]
    40203068:	d65f03c0 	ret
    4020306c:	a900251f 	stp	xzr, x9, [x8]
    40203070:	a901350b 	stp	x11, x13, [x8, #16]
    40203074:	91008500 	add	x0, x8, #0x21
    40203078:	91008461 	add	x1, x3, #0x21
    4020307c:	3900810a 	strb	w10, [x8, #32]
    40203080:	528000e2 	mov	w2, #0x7                   	// #7
    40203084:	14000eae 	b	40206b3c <memcpy>

0000000040203088 <_ZN11jnox_kernel10native_el09extension11transaction11Transaction4open17h176b3adb3fcc68f3E>:
    40203088:	d100c3ff 	sub	sp, sp, #0x30
    4020308c:	a90157fe 	stp	x30, x21, [sp, #16]
    40203090:	a9024ff4 	stp	x20, x19, [sp, #32]
    40203094:	aa0103f4 	mov	x20, x1
    40203098:	aa0003f5 	mov	x21, x0
    4020309c:	aa0803f3 	mov	x19, x8
    402030a0:	52800048 	mov	w8, #0x2                   	// #2
    402030a4:	a900a001 	stp	x1, x8, [x0, #8]
    402030a8:	52800028 	mov	w8, #0x1                   	// #1
    402030ac:	f9000008 	str	x8, [x0]
    402030b0:	f900a402 	str	x2, [x0, #328]
    402030b4:	91028000 	add	x0, x0, #0xa0
    402030b8:	aa0303e1 	mov	x1, x3
    402030bc:	52800c02 	mov	w2, #0x60                  	// #96
    402030c0:	94000e9f 	bl	40206b3c <memcpy>
    402030c4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    402030c8:	f2955568 	movk	x8, #0xaaab
    402030cc:	9bc87e88 	umulh	x8, x20, x8
    402030d0:	d341fd09 	lsr	x9, x8, #1
    402030d4:	d37ff929 	lsl	x9, x9, #1
    402030d8:	8b480528 	add	x8, x9, x8, lsr #1
    402030dc:	cb080288 	sub	x8, x20, x8
    402030e0:	f100091f 	cmp	x8, #0x2
    402030e4:	1a9f07e8 	cset	w8, ne  // ne = any
    402030e8:	390562a8 	strb	w8, [x21, #344]
    402030ec:	54000080 	b.eq	402030fc <_ZN11jnox_kernel10native_el09extension11transaction11Transaction4open17h176b3adb3fcc68f3E+0x74>  // b.none
    402030f0:	52800048 	mov	w8, #0x2                   	// #2
    402030f4:	f9000268 	str	x8, [x19]
    402030f8:	1400000d 	b	4020312c <_ZN11jnox_kernel10native_el09extension11transaction11Transaction4open17h176b3adb3fcc68f3E+0xa4>
    402030fc:	f940aaa2 	ldr	x2, [x21, #336]
    40203100:	528000a8 	mov	w8, #0x5                   	// #5
    40203104:	910402a0 	add	x0, x21, #0x100
    40203108:	910282a3 	add	x3, x21, #0xa0
    4020310c:	390003e8 	strb	w8, [sp]
    40203110:	aa1303e8 	mov	x8, x19
    40203114:	aa1403e1 	mov	x1, x20
    40203118:	52800024 	mov	w4, #0x1                   	// #1
    4020311c:	52800025 	mov	w5, #0x1                   	// #1
    40203120:	52800106 	mov	w6, #0x8                   	// #8
    40203124:	aa1f03e7 	mov	x7, xzr
    40203128:	97fffe4a 	bl	40202a50 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E>
    4020312c:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40203130:	a94157fe 	ldp	x30, x21, [sp, #16]
    40203134:	9100c3ff 	add	sp, sp, #0x30
    40203138:	d65f03c0 	ret

000000004020313c <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7consume17h542295903a9149d1E>:
    4020313c:	d10103ff 	sub	sp, sp, #0x40
    40203140:	a9015ffe 	stp	x30, x23, [sp, #16]
    40203144:	a90257f6 	stp	x22, x21, [sp, #32]
    40203148:	a9034ff4 	stp	x20, x19, [sp, #48]
    4020314c:	aa0803f3 	mov	x19, x8
    40203150:	39456008 	ldrb	w8, [x0, #344]
    40203154:	f9400009 	ldr	x9, [x0]
    40203158:	7100051f 	cmp	w8, #0x1
    4020315c:	fa400924 	ccmp	x9, #0x0, #0x4, eq  // eq = none
    40203160:	54000101 	b.ne	40203180 <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7consume17h542295903a9149d1E+0x44>  // b.any
    40203164:	52800048 	mov	w8, #0x2                   	// #2
    40203168:	f9000268 	str	x8, [x19]
    4020316c:	a9434ff4 	ldp	x20, x19, [sp, #48]
    40203170:	a94257f6 	ldp	x22, x21, [sp, #32]
    40203174:	a9415ffe 	ldp	x30, x23, [sp, #16]
    40203178:	910103ff 	add	sp, sp, #0x40
    4020317c:	d65f03c0 	ret
    40203180:	aa0003f4 	mov	x20, x0
    40203184:	f9400408 	ldr	x8, [x0, #8]
    40203188:	eb01011f 	cmp	x8, x1
    4020318c:	54fffec1 	b.ne	40203164 <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7consume17h542295903a9149d1E+0x28>  // b.any
    40203190:	f940a688 	ldr	x8, [x20, #328]
    40203194:	eb08005f 	cmp	x2, x8
    40203198:	54fffe63 	b.cc	40203164 <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7consume17h542295903a9149d1E+0x28>  // b.lo, b.ul, b.last
    4020319c:	3905629f 	strb	wzr, [x20, #344]
    402031a0:	f9400a96 	ldr	x22, [x20, #16]
    402031a4:	a9495697 	ldp	x23, x21, [x20, #144]
    402031a8:	52800048 	mov	w8, #0x2                   	// #2
    402031ac:	f9000a88 	str	x8, [x20, #16]
    402031b0:	f1000adf 	cmp	x22, #0x2
    402031b4:	540001c1 	b.ne	402031ec <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7consume17h542295903a9149d1E+0xb0>  // b.any
    402031b8:	f940aa82 	ldr	x2, [x20, #336]
    402031bc:	528000a8 	mov	w8, #0x5                   	// #5
    402031c0:	91040280 	add	x0, x20, #0x100
    402031c4:	91028283 	add	x3, x20, #0xa0
    402031c8:	390003e8 	strb	w8, [sp]
    402031cc:	aa1303e8 	mov	x8, x19
    402031d0:	52800024 	mov	w4, #0x1                   	// #1
    402031d4:	52800025 	mov	w5, #0x1                   	// #1
    402031d8:	52800106 	mov	w6, #0x8                   	// #8
    402031dc:	aa1f03e7 	mov	x7, xzr
    402031e0:	97fffe1c 	bl	40202a50 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E>
    402031e4:	f9001a7f 	str	xzr, [x19, #48]
    402031e8:	17ffffe1 	b	4020316c <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7consume17h542295903a9149d1E+0x30>
    402031ec:	91002260 	add	x0, x19, #0x8
    402031f0:	91006281 	add	x1, x20, #0x18
    402031f4:	52800502 	mov	w2, #0x28                  	// #40
    402031f8:	94000e51 	bl	40206b3c <memcpy>
    402031fc:	91040280 	add	x0, x20, #0x100
    40203200:	91010281 	add	x1, x20, #0x40
    40203204:	52800902 	mov	w2, #0x48                  	// #72
    40203208:	94000e4d 	bl	40206b3c <memcpy>
    4020320c:	f900aa97 	str	x23, [x20, #336]
    40203210:	f9000276 	str	x22, [x19]
    40203214:	52800028 	mov	w8, #0x1                   	// #1
    40203218:	a9035668 	stp	x8, x21, [x19, #48]
    4020321c:	17ffffd4 	b	4020316c <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7consume17h542295903a9149d1E+0x30>

0000000040203220 <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7publish17h5849a25ba1e7d5dcE>:
    40203220:	f81e0ffe 	str	x30, [sp, #-32]!
    40203224:	a9014ff4 	stp	x20, x19, [sp, #16]
    40203228:	39456008 	ldrb	w8, [x0, #344]
    4020322c:	aa0003f4 	mov	x20, x0
    40203230:	f8410e89 	ldr	x9, [x20, #16]!
    40203234:	f940000a 	ldr	x10, [x0]
    40203238:	7100051f 	cmp	w8, #0x1
    4020323c:	fa420920 	ccmp	x9, #0x2, #0x0, eq  // eq = none
    40203240:	fa400944 	ccmp	x10, #0x0, #0x4, eq  // eq = none
    40203244:	54000280 	b.eq	40203294 <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7publish17h5849a25ba1e7d5dcE+0x74>  // b.none
    40203248:	aa0003f3 	mov	x19, x0
    4020324c:	f9403c28 	ldr	x8, [x1, #120]
    40203250:	f9400409 	ldr	x9, [x0, #8]
    40203254:	eb08013f 	cmp	x9, x8
    40203258:	540001e1 	b.ne	40203294 <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7publish17h5849a25ba1e7d5dcE+0x74>  // b.any
    4020325c:	aa1403e0 	mov	x0, x20
    40203260:	52801202 	mov	w2, #0x90                  	// #144
    40203264:	94000e36 	bl	40206b3c <memcpy>
    40203268:	d5033fdf 	isb
    4020326c:	d53be028 	mrs	x8, cntpct_el0
    40203270:	f940a669 	ldr	x9, [x19, #328]
    40203274:	eb09011f 	cmp	x8, x9
    40203278:	54000162 	b.cs	402032a4 <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7publish17h5849a25ba1e7d5dcE+0x84>  // b.hs, b.nlast
    4020327c:	f9400289 	ldr	x9, [x20]
    40203280:	f100093f 	cmp	x9, #0x2
    40203284:	54000180 	b.eq	402032b4 <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7publish17h5849a25ba1e7d5dcE+0x94>  // b.none
    40203288:	f9004e68 	str	x8, [x19, #152]
    4020328c:	52800020 	mov	w0, #0x1                   	// #1
    40203290:	14000002 	b	40203298 <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7publish17h5849a25ba1e7d5dcE+0x78>
    40203294:	2a1f03e0 	mov	w0, wzr
    40203298:	a9414ff4 	ldp	x20, x19, [sp, #16]
    4020329c:	f84207fe 	ldr	x30, [sp], #32
    402032a0:	d65f03c0 	ret
    402032a4:	2a1f03e0 	mov	w0, wzr
    402032a8:	52800048 	mov	w8, #0x2                   	// #2
    402032ac:	f9000288 	str	x8, [x20]
    402032b0:	17fffffa 	b	40203298 <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7publish17h5849a25ba1e7d5dcE+0x78>
    402032b4:	d503201f 	nop
    402032b8:	10078a80 	adr	x0, 40212408 <anon.773058ed228f2edaafa50d5b0d646736.8.llvm.4321263285462747625>
    402032bc:	940009ba 	bl	402059a4 <_RNvNtCsbcsGJ9IzBgZ_4core6option13unwrap_failed>

00000000402032c0 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE>:
    402032c0:	f81b0ffd 	str	x29, [sp, #-80]!
    402032c4:	a90167fe 	stp	x30, x25, [sp, #16]
    402032c8:	a9025ff8 	stp	x24, x23, [sp, #32]
    402032cc:	a90357f6 	stp	x22, x21, [sp, #48]
    402032d0:	a9044ff4 	stp	x20, x19, [sp, #64]
    402032d4:	d10ec3ff 	sub	sp, sp, #0x3b0
    402032d8:	eb03005f 	cmp	x2, x3
    402032dc:	54000122 	b.cs	40203300 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x40>  // b.hs, b.nlast
    402032e0:	aa0203f3 	mov	x19, x2
    402032e4:	2a130069 	orr	w9, w3, w19
    402032e8:	92402d29 	and	x9, x9, #0xfff
    402032ec:	b50000a9 	cbnz	x9, 40203300 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x40>
    402032f0:	f100fc3f 	cmp	x1, #0x3f
    402032f4:	540000a8 	b.hi	40203308 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x48>  // b.pmore
    402032f8:	52800029 	mov	w9, #0x1                   	// #1
    402032fc:	14000040 	b	402033fc <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x13c>
    40203300:	3900011f 	strb	wzr, [x8]
    40203304:	1400003f 	b	40203400 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x140>
    40203308:	39400409 	ldrb	w9, [x0, #1]
    4020330c:	3940000a 	ldrb	w10, [x0]
    40203310:	aa092149 	orr	x9, x10, x9, lsl #8
    40203314:	39400c0a 	ldrb	w10, [x0, #3]
    40203318:	3940080b 	ldrb	w11, [x0, #2]
    4020331c:	d370bd6b 	lsl	x11, x11, #16
    40203320:	aa0a616a 	orr	x10, x11, x10, lsl #24
    40203324:	aa090149 	orr	x9, x10, x9
    40203328:	aa0003ea 	mov	x10, x0
    4020332c:	38404d4b 	ldrb	w11, [x10, #4]!
    40203330:	3940140c 	ldrb	w12, [x0, #5]
    40203334:	2a0c216b 	orr	w11, w11, w12, lsl #8
    40203338:	39400d4c 	ldrb	w12, [x10, #3]
    4020333c:	3940094a 	ldrb	w10, [x10, #2]
    40203340:	53103d4a 	lsl	w10, w10, #16
    40203344:	2a0c614a 	orr	w10, w10, w12, lsl #24
    40203348:	2a0b014a 	orr	w10, w10, w11
    4020334c:	aa0a8129 	orr	x9, x9, x10, lsl #32
    40203350:	3940200a 	ldrb	w10, [x0, #8]
    40203354:	d288afeb 	mov	x11, #0x457f                	// #17791
    40203358:	f2a8c98b 	movk	x11, #0x464c, lsl #16
    4020335c:	f2c0204b 	movk	x11, #0x102, lsl #32
    40203360:	f2e0002b 	movk	x11, #0x1, lsl #48
    40203364:	ca0b0129 	eor	x9, x9, x11
    40203368:	aa0a0129 	orr	x9, x9, x10
    4020336c:	b5000469 	cbnz	x9, 402033f8 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x138>
    40203370:	39404009 	ldrb	w9, [x0, #16]
    40203374:	3940440a 	ldrb	w10, [x0, #17]
    40203378:	2a0a2129 	orr	w9, w9, w10, lsl #8
    4020337c:	7100093f 	cmp	w9, #0x2
    40203380:	54000361 	b.ne	402033ec <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x12c>  // b.any
    40203384:	39404809 	ldrb	w9, [x0, #18]
    40203388:	39404c0a 	ldrb	w10, [x0, #19]
    4020338c:	2a0a2129 	orr	w9, w9, w10, lsl #8
    40203390:	7102dd3f 	cmp	w9, #0xb7
    40203394:	540002c1 	b.ne	402033ec <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x12c>  // b.any
    40203398:	aa0003e9 	mov	x9, x0
    4020339c:	38414d2a 	ldrb	w10, [x9, #20]!
    402033a0:	3940052b 	ldrb	w11, [x9, #1]
    402033a4:	2a0b214a 	orr	w10, w10, w11, lsl #8
    402033a8:	39400d2b 	ldrb	w11, [x9, #3]
    402033ac:	39400929 	ldrb	w9, [x9, #2]
    402033b0:	53103d29 	lsl	w9, w9, #16
    402033b4:	2a0b6129 	orr	w9, w9, w11, lsl #24
    402033b8:	2a0a0129 	orr	w9, w9, w10
    402033bc:	7100053f 	cmp	w9, #0x1
    402033c0:	54000161 	b.ne	402033ec <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x12c>  // b.any
    402033c4:	aa0003e9 	mov	x9, x0
    402033c8:	38430d2a 	ldrb	w10, [x9, #48]!
    402033cc:	3940052b 	ldrb	w11, [x9, #1]
    402033d0:	2a0b214a 	orr	w10, w10, w11, lsl #8
    402033d4:	39400d2b 	ldrb	w11, [x9, #3]
    402033d8:	39400929 	ldrb	w9, [x9, #2]
    402033dc:	53103d29 	lsl	w9, w9, #16
    402033e0:	2a0b6129 	orr	w9, w9, w11, lsl #24
    402033e4:	2a0a0129 	orr	w9, w9, w10
    402033e8:	340001e9 	cbz	w9, 40203424 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x164>
    402033ec:	52800069 	mov	w9, #0x3                   	// #3
    402033f0:	39000109 	strb	w9, [x8]
    402033f4:	14000004 	b	40203404 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x144>
    402033f8:	52800049 	mov	w9, #0x2                   	// #2
    402033fc:	39000109 	strb	w9, [x8]
    40203400:	52800069 	mov	w9, #0x3                   	// #3
    40203404:	3900c109 	strb	w9, [x8, #48]
    40203408:	910ec3ff 	add	sp, sp, #0x3b0
    4020340c:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40203410:	a94357f6 	ldp	x22, x21, [sp, #48]
    40203414:	a9425ff8 	ldp	x24, x23, [sp, #32]
    40203418:	a94167fe 	ldp	x30, x25, [sp, #16]
    4020341c:	f84507fd 	ldr	x29, [sp], #80
    40203420:	d65f03c0 	ret
    40203424:	3940d009 	ldrb	w9, [x0, #52]
    40203428:	3940d40a 	ldrb	w10, [x0, #53]
    4020342c:	2a0a2129 	orr	w9, w9, w10, lsl #8
    40203430:	7101013f 	cmp	w9, #0x40
    40203434:	540004e1 	b.ne	402034d0 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x210>  // b.any
    40203438:	3940d809 	ldrb	w9, [x0, #54]
    4020343c:	3940dc0a 	ldrb	w10, [x0, #55]
    40203440:	2a0a2129 	orr	w9, w9, w10, lsl #8
    40203444:	7100e13f 	cmp	w9, #0x38
    40203448:	54000441 	b.ne	402034d0 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x210>  // b.any
    4020344c:	aa0003ea 	mov	x10, x0
    40203450:	38420d49 	ldrb	w9, [x10, #32]!
    40203454:	3940054b 	ldrb	w11, [x10, #1]
    40203458:	aa0b2129 	orr	x9, x9, x11, lsl #8
    4020345c:	39400d4b 	ldrb	w11, [x10, #3]
    40203460:	3940094c 	ldrb	w12, [x10, #2]
    40203464:	d370bd8c 	lsl	x12, x12, #16
    40203468:	aa0b618b 	orr	x11, x12, x11, lsl #24
    4020346c:	aa090169 	orr	x9, x11, x9
    40203470:	aa0a03eb 	mov	x11, x10
    40203474:	38404d6c 	ldrb	w12, [x11, #4]!
    40203478:	3940154d 	ldrb	w13, [x10, #5]
    4020347c:	2a0d218c 	orr	w12, w12, w13, lsl #8
    40203480:	39400d6d 	ldrb	w13, [x11, #3]
    40203484:	3940096b 	ldrb	w11, [x11, #2]
    40203488:	53103d6b 	lsl	w11, w11, #16
    4020348c:	2a0d616b 	orr	w11, w11, w13, lsl #24
    40203490:	2a0c016b 	orr	w11, w11, w12
    40203494:	aa0b8129 	orr	x9, x9, x11, lsl #32
    40203498:	f101013f 	cmp	x9, #0x40
    4020349c:	540001a3 	b.cc	402034d0 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x210>  // b.lo, b.ul, b.last
    402034a0:	3940614b 	ldrb	w11, [x10, #24]
    402034a4:	3940654a 	ldrb	w10, [x10, #25]
    402034a8:	2a0a216a 	orr	w10, w11, w10, lsl #8
    402034ac:	5100054b 	sub	w11, w10, #0x1
    402034b0:	7100417f 	cmp	w11, #0x10
    402034b4:	540000e2 	b.cs	402034d0 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x210>  // b.hs, b.nlast
    402034b8:	531a654b 	lsl	w11, w10, #6
    402034bc:	4b0a0d75 	sub	w21, w11, w10, lsl #3
    402034c0:	ab15012a 	adds	x10, x9, x21
    402034c4:	54000062 	b.cs	402034d0 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x210>  // b.hs, b.nlast
    402034c8:	eb01015f 	cmp	x10, x1
    402034cc:	54000069 	b.ls	402034d8 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x218>  // b.plast
    402034d0:	52800089 	mov	w9, #0x4                   	// #4
    402034d4:	17ffffca 	b	402033fc <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x13c>
    402034d8:	aa0003ea 	mov	x10, x0
    402034dc:	38418d4b 	ldrb	w11, [x10, #24]!
    402034e0:	3940054c 	ldrb	w12, [x10, #1]
    402034e4:	aa0c216b 	orr	x11, x11, x12, lsl #8
    402034e8:	39400d4c 	ldrb	w12, [x10, #3]
    402034ec:	3940094d 	ldrb	w13, [x10, #2]
    402034f0:	d370bdad 	lsl	x13, x13, #16
    402034f4:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    402034f8:	3940154d 	ldrb	w13, [x10, #5]
    402034fc:	38404d4e 	ldrb	w14, [x10, #4]!
    40203500:	aa0b018b 	orr	x11, x12, x11
    40203504:	2a0d21cc 	orr	w12, w14, w13, lsl #8
    40203508:	39400d4d 	ldrb	w13, [x10, #3]
    4020350c:	3940094a 	ldrb	w10, [x10, #2]
    40203510:	53103d4a 	lsl	w10, w10, #16
    40203514:	2a0d614a 	orr	w10, w10, w13, lsl #24
    40203518:	2a0c014a 	orr	w10, w10, w12
    4020351c:	aa0a816a 	orr	x10, x11, x10, lsl #32
    40203520:	b100115f 	cmn	x10, #0x4
    40203524:	54000063 	b.cc	40203530 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x270>  // b.lo, b.ul, b.last
    40203528:	528001a9 	mov	w9, #0xd                   	// #13
    4020352c:	17ffffb4 	b	402033fc <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x13c>
    40203530:	a90107e3 	stp	x3, x1, [sp, #16]
    40203534:	f901dfe8 	str	x8, [sp, #952]
    40203538:	aa1f03e8 	mov	x8, xzr
    4020353c:	f90007e0 	str	x0, [sp, #8]
    40203540:	8b090017 	add	x23, x0, x9
    40203544:	91001158 	add	x24, x10, #0x4
    40203548:	9107c3e9 	add	x9, sp, #0x1f0
    4020354c:	5280002b 	mov	w11, #0x1                   	// #1
    40203550:	8b08012c 	add	x12, x9, x8
    40203554:	a9007d8b 	stp	x11, xzr, [x12]
    40203558:	a9017d9f 	stp	xzr, xzr, [x12, #16]
    4020355c:	a9027d9f 	stp	xzr, xzr, [x12, #32]
    40203560:	9100e108 	add	x8, x8, #0x38
    40203564:	f107011f 	cmp	x8, #0x1c0
    40203568:	3900c19f 	strb	wzr, [x12, #48]
    4020356c:	54ffff21 	b.ne	40203550 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x290>  // b.any
    40203570:	aa0a03f4 	mov	x20, x10
    40203574:	f900f3ea 	str	x10, [sp, #480]
    40203578:	910083f6 	add	x22, sp, #0x20
    4020357c:	910083e0 	add	x0, sp, #0x20
    40203580:	9107c3e1 	add	x1, sp, #0x1f0
    40203584:	52803802 	mov	w2, #0x1c0                 	// #448
    40203588:	94000d6d 	bl	40206b3c <memcpy>
    4020358c:	aa1f03e0 	mov	x0, xzr
    40203590:	2a1f03e9 	mov	w9, wzr
    40203594:	2a1f03e8 	mov	w8, wzr
    40203598:	f900f7ff 	str	xzr, [sp, #488]
    4020359c:	529caa2a 	mov	w10, #0xe551                	// #58705
    402035a0:	72ac8e8a 	movk	w10, #0x6474, lsl #16
    402035a4:	5280070b 	mov	w11, #0x38                  	// #56
    402035a8:	aa1303ec 	mov	x12, x19
    402035ac:	9100e2f7 	add	x23, x23, #0x38
    402035b0:	d100e2b5 	sub	x21, x21, #0x38
    402035b4:	aa1703ef 	mov	x15, x23
    402035b8:	385f0df1 	ldrb	w17, [x15, #-16]!
    402035bc:	385d91ed 	ldurb	w13, [x15, #-39]
    402035c0:	aa0f03ee 	mov	x14, x15
    402035c4:	385d8dd0 	ldrb	w16, [x14, #-40]!
    402035c8:	2a0d220d 	orr	w13, w16, w13, lsl #8
    402035cc:	39400dd0 	ldrb	w16, [x14, #3]
    402035d0:	394009ce 	ldrb	w14, [x14, #2]
    402035d4:	53103dce 	lsl	w14, w14, #16
    402035d8:	2a1061ce 	orr	w14, w14, w16, lsl #24
    402035dc:	2a0d01d0 	orr	w16, w14, w13
    402035e0:	340006b0 	cbz	w16, 402036b4 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x3f4>
    402035e4:	385dd1ed 	ldurb	w13, [x15, #-35]
    402035e8:	aa0f03ee 	mov	x14, x15
    402035ec:	385f91f2 	ldurb	w18, [x15, #-7]
    402035f0:	aa0f03e1 	mov	x1, x15
    402035f4:	385dcdc2 	ldrb	w2, [x14, #-36]!
    402035f8:	385f8c23 	ldrb	w3, [x1, #-8]!
    402035fc:	39400dc4 	ldrb	w4, [x14, #3]
    40203600:	394009ce 	ldrb	w14, [x14, #2]
    40203604:	2a0d204d 	orr	w13, w2, w13, lsl #8
    40203608:	39400c22 	ldrb	w2, [x1, #3]
    4020360c:	aa122072 	orr	x18, x3, x18, lsl #8
    40203610:	53103dce 	lsl	w14, w14, #16
    40203614:	39400823 	ldrb	w3, [x1, #2]
    40203618:	2a0461ce 	orr	w14, w14, w4, lsl #24
    4020361c:	38404c24 	ldrb	w4, [x1, #4]!
    40203620:	385fd1e5 	ldurb	w5, [x15, #-3]
    40203624:	2a052084 	orr	w4, w4, w5, lsl #8
    40203628:	d370bc63 	lsl	x3, x3, #16
    4020362c:	aa026062 	orr	x2, x3, x2, lsl #24
    40203630:	2a0d01cd 	orr	w13, w14, w13
    40203634:	39400c2e 	ldrb	w14, [x1, #3]
    40203638:	39400821 	ldrb	w1, [x1, #2]
    4020363c:	53103c21 	lsl	w1, w1, #16
    40203640:	2a0e602e 	orr	w14, w1, w14, lsl #24
    40203644:	aa120052 	orr	x18, x2, x18
    40203648:	2a0401ce 	orr	w14, w14, w4
    4020364c:	aa0e824e 	orr	x14, x18, x14, lsl #32
    40203650:	394005f2 	ldrb	w18, [x15, #1]
    40203654:	aa122231 	orr	x17, x17, x18, lsl #8
    40203658:	394009f2 	ldrb	w18, [x15, #2]
    4020365c:	d370be52 	lsl	x18, x18, #16
    40203660:	39400de1 	ldrb	w1, [x15, #3]
    40203664:	aa016252 	orr	x18, x18, x1, lsl #24
    40203668:	394015e1 	ldrb	w1, [x15, #5]
    4020366c:	38404de2 	ldrb	w2, [x15, #4]!
    40203670:	aa110251 	orr	x17, x18, x17
    40203674:	2a012052 	orr	w18, w2, w1, lsl #8
    40203678:	394009e1 	ldrb	w1, [x15, #2]
    4020367c:	53103c21 	lsl	w1, w1, #16
    40203680:	39400def 	ldrb	w15, [x15, #3]
    40203684:	2a0f602f 	orr	w15, w1, w15, lsl #24
    40203688:	2a1201ef 	orr	w15, w15, w18
    4020368c:	aa0f822f 	orr	x15, x17, x15, lsl #32
    40203690:	6b0a021f 	cmp	w16, w10
    40203694:	54000181 	b.ne	402036c4 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x404>  // b.any
    40203698:	721d75bf 	tst	w13, #0xfffffff9
    4020369c:	aa0e01ed 	orr	x13, x15, x14
    402036a0:	fa4009a0 	ccmp	x13, #0x0, #0x0, eq  // eq = none
    402036a4:	1a9f07ed 	cset	w13, ne  // ne = any
    402036a8:	2a0d0129 	orr	w9, w9, w13
    402036ac:	37001129 	tbnz	w9, #0, 402038d0 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x610>
    402036b0:	52800029 	mov	w9, #0x1                   	// #1
    402036b4:	9100e2f7 	add	x23, x23, #0x38
    402036b8:	f100e2bf 	cmp	x21, #0x38
    402036bc:	54fff7a2 	b.cs	402035b0 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x2f0>  // b.hs, b.nlast
    402036c0:	14000078 	b	402038a0 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x5e0>
    402036c4:	7100061f 	cmp	w16, #0x1
    402036c8:	54001001 	b.ne	402038c8 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x608>  // b.any
    402036cc:	f100201f 	cmp	x0, #0x8
    402036d0:	54001040 	b.eq	402038d8 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x618>  // b.none
    402036d4:	510011b0 	sub	w16, w13, #0x4
    402036d8:	71000e1f 	cmp	w16, #0x3
    402036dc:	540011a2 	b.cs	40203910 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x650>  // b.hs, b.nlast
    402036e0:	aa1703e1 	mov	x1, x23
    402036e4:	385f8c31 	ldrb	w17, [x1, #-8]!
    402036e8:	39400432 	ldrb	w18, [x1, #1]
    402036ec:	aa122231 	orr	x17, x17, x18, lsl #8
    402036f0:	39400c32 	ldrb	w18, [x1, #3]
    402036f4:	39400822 	ldrb	w2, [x1, #2]
    402036f8:	d370bc42 	lsl	x2, x2, #16
    402036fc:	aa126052 	orr	x18, x2, x18, lsl #24
    40203700:	aa110251 	orr	x17, x18, x17
    40203704:	aa0103f2 	mov	x18, x1
    40203708:	38404e42 	ldrb	w2, [x18, #4]!
    4020370c:	39401423 	ldrb	w3, [x1, #5]
    40203710:	2a032042 	orr	w2, w2, w3, lsl #8
    40203714:	39400e43 	ldrb	w3, [x18, #3]
    40203718:	39400a52 	ldrb	w18, [x18, #2]
    4020371c:	53103e52 	lsl	w18, w18, #16
    40203720:	2a036252 	orr	w18, w18, w3, lsl #24
    40203724:	2a020252 	orr	w18, w18, w2
    40203728:	aa128232 	orr	x18, x17, x18, lsl #32
    4020372c:	f140065f 	cmp	x18, #0x1, lsl #12
    40203730:	54000e83 	b.cc	40203900 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x640>  // b.lo, b.ul, b.last
    40203734:	aa0103f1 	mov	x17, x1
    40203738:	385d8e22 	ldrb	w2, [x17, #-40]!
    4020373c:	aa0103e3 	mov	x3, x1
    40203740:	385e0c64 	ldrb	w4, [x3, #-32]!
    40203744:	385d9025 	ldurb	w5, [x1, #-39]
    40203748:	385dd026 	ldurb	w6, [x1, #-35]
    4020374c:	385e1027 	ldurb	w7, [x1, #-31]
    40203750:	39400e39 	ldrb	w25, [x17, #3]
    40203754:	aa052042 	orr	x2, x2, x5, lsl #8
    40203758:	39400a25 	ldrb	w5, [x17, #2]
    4020375c:	aa072084 	orr	x4, x4, x7, lsl #8
    40203760:	38404e27 	ldrb	w7, [x17, #4]!
    40203764:	2a0620e6 	orr	w6, w7, w6, lsl #8
    40203768:	d370bca5 	lsl	x5, x5, #16
    4020376c:	aa1960a5 	orr	x5, x5, x25, lsl #24
    40203770:	39400e27 	ldrb	w7, [x17, #3]
    40203774:	39400a31 	ldrb	w17, [x17, #2]
    40203778:	53103e31 	lsl	w17, w17, #16
    4020377c:	2a076231 	orr	w17, w17, w7, lsl #24
    40203780:	aa0200a2 	orr	x2, x5, x2
    40203784:	2a060231 	orr	w17, w17, w6
    40203788:	39400c65 	ldrb	w5, [x3, #3]
    4020378c:	aa118051 	orr	x17, x2, x17, lsl #32
    40203790:	39400862 	ldrb	w2, [x3, #2]
    40203794:	d370bc42 	lsl	x2, x2, #16
    40203798:	aa056042 	orr	x2, x2, x5, lsl #24
    4020379c:	aa040042 	orr	x2, x2, x4
    402037a0:	385e5021 	ldurb	w1, [x1, #-27]
    402037a4:	38404c64 	ldrb	w4, [x3, #4]!
    402037a8:	2a012081 	orr	w1, w4, w1, lsl #8
    402037ac:	39400864 	ldrb	w4, [x3, #2]
    402037b0:	53103c84 	lsl	w4, w4, #16
    402037b4:	39400c63 	ldrb	w3, [x3, #3]
    402037b8:	2a036083 	orr	w3, w4, w3, lsl #24
    402037bc:	2a010061 	orr	w1, w3, w1
    402037c0:	aa018041 	orr	x1, x2, x1, lsl #32
    402037c4:	d1000642 	sub	x2, x18, #0x1
    402037c8:	8a020242 	and	x2, x18, x2
    402037cc:	2a110023 	orr	w3, w1, w17
    402037d0:	92402c63 	and	x3, x3, #0xfff
    402037d4:	aa020062 	orr	x2, x3, x2
    402037d8:	b5000942 	cbnz	x2, 40203900 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x640>
    402037dc:	9ad20822 	udiv	x2, x1, x18
    402037e0:	9b128442 	msub	x2, x2, x18, x1
    402037e4:	9ad20a23 	udiv	x3, x17, x18
    402037e8:	9b12c472 	msub	x18, x3, x18, x17
    402037ec:	eb12005f 	cmp	x2, x18
    402037f0:	54000881 	b.ne	40203900 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x640>  // b.any
    402037f4:	b400082f 	cbz	x15, 402038f8 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x638>
    402037f8:	eb0f01df 	cmp	x14, x15
    402037fc:	540007e8 	b.hi	402038f8 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x638>  // b.pmore
    40203800:	ab0e0232 	adds	x18, x17, x14
    40203804:	54000822 	b.cs	40203908 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x648>  // b.hs, b.nlast
    40203808:	f9400fe2 	ldr	x2, [sp, #24]
    4020380c:	eb02025f 	cmp	x18, x2
    40203810:	540007c8 	b.hi	40203908 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x648>  // b.pmore
    40203814:	ab0f0032 	adds	x18, x1, x15
    40203818:	54000702 	b.cs	402038f8 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x638>  // b.hs, b.nlast
    4020381c:	b13ffe5f 	cmn	x18, #0xfff
    40203820:	540006c2 	b.cs	402038f8 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x638>  // b.hs, b.nlast
    40203824:	eb13003f 	cmp	x1, x19
    40203828:	54000683 	b.cc	402038f8 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x638>  // b.lo, b.ul, b.last
    4020382c:	913ffe52 	add	x18, x18, #0xfff
    40203830:	9274ce52 	and	x18, x18, #0xfffffffffffff000
    40203834:	f9400be2 	ldr	x2, [sp, #16]
    40203838:	eb02025f 	cmp	x18, x2
    4020383c:	540005e8 	b.hi	402038f8 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x638>  // b.pmore
    40203840:	eb0c003f 	cmp	x1, x12
    40203844:	540006a3 	b.cc	40203918 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x658>  // b.lo, b.ul, b.last
    40203848:	f100201f 	cmp	x0, #0x8
    4020384c:	540006a2 	b.cs	40203920 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x660>  // b.hs, b.nlast
    40203850:	f94007ec 	ldr	x12, [sp, #8]
    40203854:	8b11018c 	add	x12, x12, x17
    40203858:	eb01029f 	cmp	x20, x1
    4020385c:	9b0b5800 	madd	x0, x0, x11, x22
    40203860:	a900380c 	stp	x12, x14, [x0]
    40203864:	1a9f37ec 	cset	w12, cs  // cs = hs, nlast
    40203868:	0a0d018c 	and	w12, w12, w13
    4020386c:	8b0e002d 	add	x13, x1, x14
    40203870:	eb0d031f 	cmp	x24, x13
    40203874:	1a8c83ec 	csel	w12, wzr, w12, hi  // hi = pmore
    40203878:	2a080188 	orr	w8, w12, w8
    4020387c:	a9014401 	stp	x1, x17, [x0, #16]
    40203880:	a902480f 	stp	x15, x18, [x0, #32]
    40203884:	3900c010 	strb	w16, [x0, #48]
    40203888:	f940f7ec 	ldr	x12, [sp, #488]
    4020388c:	91000580 	add	x0, x12, #0x1
    40203890:	f900f7e0 	str	x0, [sp, #488]
    40203894:	f100e2bf 	cmp	x21, #0x38
    40203898:	aa1203ec 	mov	x12, x18
    4020389c:	54ffe882 	b.cs	402035ac <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x2ec>  // b.hs, b.nlast
    402038a0:	b40001c0 	cbz	x0, 402038d8 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x618>
    402038a4:	f240069f 	tst	x20, #0x3
    402038a8:	1a9f17e9 	cset	w9, eq  // eq = none
    402038ac:	0a080128 	and	w8, w9, w8
    402038b0:	36000188 	tbz	w8, #0, 402038e0 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x620>
    402038b4:	910083e1 	add	x1, sp, #0x20
    402038b8:	f941dfe0 	ldr	x0, [sp, #952]
    402038bc:	52803a02 	mov	w2, #0x1d0                 	// #464
    402038c0:	94000c9f 	bl	40206b3c <memcpy>
    402038c4:	17fffed1 	b	40203408 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x148>
    402038c8:	528000a8 	mov	w8, #0x5                   	// #5
    402038cc:	14000006 	b	402038e4 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x624>
    402038d0:	528000c8 	mov	w8, #0x6                   	// #6
    402038d4:	14000004 	b	402038e4 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x624>
    402038d8:	528000e8 	mov	w8, #0x7                   	// #7
    402038dc:	14000002 	b	402038e4 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x624>
    402038e0:	528001a8 	mov	w8, #0xd                   	// #13
    402038e4:	f941dfe9 	ldr	x9, [sp, #952]
    402038e8:	39000128 	strb	w8, [x9]
    402038ec:	52800068 	mov	w8, #0x3                   	// #3
    402038f0:	3900c128 	strb	w8, [x9, #48]
    402038f4:	17fffec5 	b	40203408 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x148>
    402038f8:	52800168 	mov	w8, #0xb                   	// #11
    402038fc:	17fffffa 	b	402038e4 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x624>
    40203900:	52800128 	mov	w8, #0x9                   	// #9
    40203904:	17fffff8 	b	402038e4 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x624>
    40203908:	52800148 	mov	w8, #0xa                   	// #10
    4020390c:	17fffff6 	b	402038e4 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x624>
    40203910:	52800108 	mov	w8, #0x8                   	// #8
    40203914:	17fffff4 	b	402038e4 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x624>
    40203918:	52800188 	mov	w8, #0xc                   	// #12
    4020391c:	17fffff2 	b	402038e4 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE+0x624>
    40203920:	d503201f 	nop
    40203924:	100758a2 	adr	x2, 40212438 <anon.773058ed228f2edaafa50d5b0d646736.9.llvm.4321263285462747625+0x18>
    40203928:	52800101 	mov	w1, #0x8                   	// #8
    4020392c:	94000825 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040203930 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E>:
    40203930:	b40001a1 	cbz	x1, 40203964 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E+0x34>
    40203934:	8b010008 	add	x8, x0, x1
    40203938:	52800309 	mov	w9, #0x18                  	// #24
    4020393c:	72a12009 	movk	w9, #0x900, lsl #16
    40203940:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    40203944:	3840140b 	ldrb	w11, [x0], #1
    40203948:	b940012c 	ldr	w12, [x9]
    4020394c:	3628006c 	tbz	w12, #5, 40203958 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E+0x28>
    40203950:	d5033fdf 	isb
    40203954:	17fffffd 	b	40203948 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E+0x18>
    40203958:	b900014b 	str	w11, [x10]
    4020395c:	eb08001f 	cmp	x0, x8
    40203960:	54ffff21 	b.ne	40203944 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E+0x14>  // b.any
    40203964:	d65f03c0 	ret

0000000040203968 <_ZN11jnox_kernel11kernel_main17ha0f1dd4d6a7d76bdE>:
    40203968:	d00000a8 	adrp	x8, 40219000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3ce0>
    4020396c:	f9419108 	ldr	x8, [x8, #800]
    40203970:	b4000068 	cbz	x8, 4020397c <_ZN11jnox_kernel11kernel_main17ha0f1dd4d6a7d76bdE+0x14>
    40203974:	d503205f 	wfe
    40203978:	17ffffff 	b	40203974 <_ZN11jnox_kernel11kernel_main17ha0f1dd4d6a7d76bdE+0xc>
    4020397c:	f81f0ffe 	str	x30, [sp, #-16]!
    40203980:	52800608 	mov	w8, #0x30                  	// #48
    40203984:	72a12008 	movk	w8, #0x900, lsl #16
    40203988:	b900011f 	str	wzr, [x8]
    4020398c:	528001a9 	mov	w9, #0xd                   	// #13
    40203990:	5280002a 	mov	w10, #0x1                   	// #1
    40203994:	b81f4109 	stur	w9, [x8, #-12]
    40203998:	b81f810a 	stur	w10, [x8, #-8]
    4020399c:	52800c09 	mov	w9, #0x60                  	// #96
    402039a0:	b81fc109 	stur	w9, [x8, #-4]
    402039a4:	52802029 	mov	w9, #0x101                 	// #257
    402039a8:	b9000109 	str	w9, [x8]
    402039ac:	d503201f 	nop
    402039b0:	100755c0 	adr	x0, 40212468 <anon.773058ed228f2edaafa50d5b0d646736.16.llvm.4321263285462747625+0x18>
    402039b4:	52800361 	mov	w1, #0x1b                  	// #27
    402039b8:	97ffffde 	bl	40203930 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E>
    402039bc:	97fff901 	bl	40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE>

00000000402039c0 <_ZN11jnox_kernel10native_el09extension12before_event17h2ab7ca7e436978d9E.llvm.8080503781627406991>:
    402039c0:	f81f0ffe 	str	x30, [sp, #-16]!
    402039c4:	90000088 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402039c8:	f944e108 	ldr	x8, [x8, #2496]
    402039cc:	f100091f 	cmp	x8, #0x2
    402039d0:	54000260 	b.eq	40203a1c <_ZN11jnox_kernel10native_el09extension12before_event17h2ab7ca7e436978d9E.llvm.8080503781627406991+0x5c>  // b.none
    402039d4:	d0000208 	adrp	x8, 40245000 <_ZN11jnox_kernel10native_el09extension9EVALUATOR17h2aebd11a2f23ffadE+0x3cd0>
    402039d8:	90000089 	adrp	x9, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402039dc:	f945a929 	ldr	x9, [x9, #2896]
    402039e0:	f100053f 	cmp	x9, #0x1
    402039e4:	54000161 	b.ne	40203a10 <_ZN11jnox_kernel10native_el09extension12before_event17h2ab7ca7e436978d9E.llvm.8080503781627406991+0x50>  // b.any
    402039e8:	90000089 	adrp	x9, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402039ec:	f945ad20 	ldr	x0, [x9, #2904]
    402039f0:	f107fc1f 	cmp	x0, #0x1ff
    402039f4:	54000188 	b.hi	40203a24 <_ZN11jnox_kernel10native_el09extension12before_event17h2ab7ca7e436978d9E.llvm.8080503781627406991+0x64>  // b.pmore
    402039f8:	f941a109 	ldr	x9, [x8, #832]
    402039fc:	d503201f 	nop
    40203a00:	100ac94a 	adr	x10, 40219328 <_ZN11jnox_kernel10native_el09extension4ROWS17h71366c1b688cc4d8E.llvm.8080503781627406991>
    40203a04:	5280280b 	mov	w11, #0x140                 	// #320
    40203a08:	9b0b280a 	madd	x10, x0, x11, x10
    40203a0c:	f9007d49 	str	x9, [x10, #248]
    40203a10:	f901a11f 	str	xzr, [x8, #832]
    40203a14:	f84107fe 	ldr	x30, [sp], #16
    40203a18:	d65f03c0 	ret
    40203a1c:	52800340 	mov	w0, #0x1a                  	// #26
    40203a20:	97fff9f9 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    40203a24:	d503201f 	nop
    40203a28:	10075382 	adr	x2, 40212498 <anon.09c3d38f9b7290fd63a7fa379a74bb58.1.llvm.8080503781627406991>
    40203a2c:	52804001 	mov	w1, #0x200                 	// #512
    40203a30:	940007e4 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040203a34 <_ZN11jnox_kernel10native_el09extension3irq17hdd6bb6d12c435e54E>:
    40203a34:	a9be57fe 	stp	x30, x21, [sp, #-32]!
    40203a38:	a9014ff4 	stp	x20, x19, [sp, #16]
    40203a3c:	2a0203f4 	mov	w20, w2
    40203a40:	aa0103f3 	mov	x19, x1
    40203a44:	aa0003f5 	mov	x21, x0
    40203a48:	97ffffde 	bl	402039c0 <_ZN11jnox_kernel10native_el09extension12before_event17h2ab7ca7e436978d9E.llvm.8080503781627406991>
    40203a4c:	2a1403e2 	mov	w2, w20
    40203a50:	aa1503e0 	mov	x0, x21
    40203a54:	52800021 	mov	w1, #0x1                   	// #1
    40203a58:	aa1f03e3 	mov	x3, xzr
    40203a5c:	aa1303e4 	mov	x4, x19
    40203a60:	aa1f03e5 	mov	x5, xzr
    40203a64:	94000112 	bl	40203eac <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991>
    40203a68:	aa0003f5 	mov	x21, x0
    40203a6c:	52807f88 	mov	w8, #0x3fc                 	// #1020
    40203a70:	6a34011f 	bics	wzr, w8, w20
    40203a74:	540000c0 	b.eq	40203a8c <_ZN11jnox_kernel10native_el09extension3irq17hdd6bb6d12c435e54E+0x58>  // b.none
    40203a78:	d5033f9f 	dsb	sy
    40203a7c:	52800208 	mov	w8, #0x10                  	// #16
    40203a80:	72a10028 	movk	w8, #0x801, lsl #16
    40203a84:	b9000114 	str	w20, [x8]
    40203a88:	d5033f9f 	dsb	sy
    40203a8c:	b4000093 	cbz	x19, 40203a9c <_ZN11jnox_kernel10native_el09extension3irq17hdd6bb6d12c435e54E+0x68>
    40203a90:	aa1503e0 	mov	x0, x21
    40203a94:	aa1303e1 	mov	x1, x19
    40203a98:	94000337 	bl	40204774 <_ZN11jnox_kernel10native_el09extension8transfer17h0067d96f2f3d3251E.llvm.8080503781627406991>
    40203a9c:	f1000ebf 	cmp	x21, #0x3
    40203aa0:	1a9f27e0 	cset	w0, cc  // cc = lo, ul, last
    40203aa4:	a9414ff4 	ldp	x20, x19, [sp, #16]
    40203aa8:	a8c257fe 	ldp	x30, x21, [sp], #32
    40203aac:	d65f03c0 	ret

0000000040203ab0 <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE>:
    40203ab0:	a9bd5ffe 	stp	x30, x23, [sp, #-48]!
    40203ab4:	a90157f6 	stp	x22, x21, [sp, #16]
    40203ab8:	a9024ff4 	stp	x20, x19, [sp, #32]
    40203abc:	aa0203f3 	mov	x19, x2
    40203ac0:	aa1f03e8 	mov	x8, xzr
    40203ac4:	52800314 	mov	w20, #0x18                  	// #24
    40203ac8:	72a12014 	movk	w20, #0x900, lsl #16
    40203acc:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40203ad0:	d503201f 	nop
    40203ad4:	10074eea 	adr	x10, 402124b0 <anon.09c3d38f9b7290fd63a7fa379a74bb58.1.llvm.8080503781627406991+0x18>
    40203ad8:	3868694b 	ldrb	w11, [x10, x8]
    40203adc:	b940028c 	ldr	w12, [x20]
    40203ae0:	3628006c 	tbz	w12, #5, 40203aec <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE+0x3c>
    40203ae4:	d5033fdf 	isb
    40203ae8:	17fffffd 	b	40203adc <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE+0x2c>
    40203aec:	91000508 	add	x8, x8, #0x1
    40203af0:	b900012b 	str	w11, [x9]
    40203af4:	f100451f 	cmp	x8, #0x11
    40203af8:	54ffff01 	b.ne	40203ad8 <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE+0x28>  // b.any
    40203afc:	8b010008 	add	x8, x0, x1
    40203b00:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40203b04:	3840140a 	ldrb	w10, [x0], #1
    40203b08:	b940028b 	ldr	w11, [x20]
    40203b0c:	3628006b 	tbz	w11, #5, 40203b18 <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE+0x68>
    40203b10:	d5033fdf 	isb
    40203b14:	17fffffd 	b	40203b08 <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE+0x58>
    40203b18:	b900012a 	str	w10, [x9]
    40203b1c:	eb08001f 	cmp	x0, x8
    40203b20:	54ffff21 	b.ne	40203b04 <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE+0x54>  // b.any
    40203b24:	8b030e75 	add	x21, x19, x3, lsl #3
    40203b28:	52a12016 	mov	w22, #0x9000000             	// #150994944
    40203b2c:	52800417 	mov	w23, #0x20                  	// #32
    40203b30:	b9400288 	ldr	w8, [x20]
    40203b34:	36280068 	tbz	w8, #5, 40203b40 <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE+0x90>
    40203b38:	d5033fdf 	isb
    40203b3c:	17fffffd 	b	40203b30 <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE+0x80>
    40203b40:	b90002d7 	str	w23, [x22]
    40203b44:	f8408660 	ldr	x0, [x19], #8
    40203b48:	97fffa48 	bl	40202468 <_ZN11jnox_kernel10native_el08unsigned17haaccd95f5c5ba763E>
    40203b4c:	eb15027f 	cmp	x19, x21
    40203b50:	54ffff01 	b.ne	40203b30 <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE+0x80>  // b.any
    40203b54:	14000002 	b	40203b5c <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE+0xac>
    40203b58:	d5033fdf 	isb
    40203b5c:	b9400288 	ldr	w8, [x20]
    40203b60:	372fffc8 	tbnz	w8, #5, 40203b58 <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE+0xa8>
    40203b64:	52a12008 	mov	w8, #0x9000000             	// #150994944
    40203b68:	52800149 	mov	w9, #0xa                   	// #10
    40203b6c:	b9000109 	str	w9, [x8]
    40203b70:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40203b74:	a94157f6 	ldp	x22, x21, [sp, #16]
    40203b78:	a8c35ffe 	ldp	x30, x23, [sp], #48
    40203b7c:	d65f03c0 	ret

0000000040203b80 <_ZN11jnox_kernel10native_el09extension5start17h7a1d16f295a7c4b5E>:
    40203b80:	d10743ff 	sub	sp, sp, #0x1d0
    40203b84:	a9197bfd 	stp	x29, x30, [sp, #400]
    40203b88:	a91a5ff8 	stp	x24, x23, [sp, #416]
    40203b8c:	a91b57f6 	stp	x22, x21, [sp, #432]
    40203b90:	a91c4ff4 	stp	x20, x19, [sp, #448]
    40203b94:	f100a01f 	cmp	x0, #0x28
    40203b98:	54000ca3 	b.cc	40203d2c <_ZN11jnox_kernel10native_el09extension5start17h7a1d16f295a7c4b5E+0x1ac>  // b.lo, b.ul, b.last
    40203b9c:	aa0003f3 	mov	x19, x0
    40203ba0:	b202e7e8 	mov	x8, #0xcccccccccccccccc    	// #-3689348814741910324
    40203ba4:	f29999a8 	movk	x8, #0xcccd
    40203ba8:	9bc87c08 	umulh	x8, x0, x8
    40203bac:	d345fd09 	lsr	x9, x8, #5
    40203bb0:	d344fd0a 	lsr	x10, x8, #4
    40203bb4:	eb0a013f 	cmp	x9, x10
    40203bb8:	54000ba2 	b.cs	40203d2c <_ZN11jnox_kernel10native_el09extension5start17h7a1d16f295a7c4b5E+0x1ac>  // b.hs, b.nlast
    40203bbc:	d343fd14 	lsr	x20, x8, #3
    40203bc0:	d5033fdf 	isb
    40203bc4:	d53be028 	mrs	x8, cntpct_el0
    40203bc8:	ab140115 	adds	x21, x8, x20
    40203bcc:	54000b42 	b.cs	40203d34 <_ZN11jnox_kernel10native_el09extension5start17h7a1d16f295a7c4b5E+0x1b4>  // b.hs, b.nlast
    40203bd0:	ab1402bf 	cmn	x21, x20
    40203bd4:	54000b02 	b.cs	40203d34 <_ZN11jnox_kernel10native_el09extension5start17h7a1d16f295a7c4b5E+0x1b4>  // b.hs, b.nlast
    40203bd8:	aa1f03e8 	mov	x8, xzr
    40203bdc:	9104c3e9 	add	x9, sp, #0x130
    40203be0:	5280002a 	mov	w10, #0x1                   	// #1
    40203be4:	d503201f 	nop
    40203be8:	100741cb 	adr	x11, 40212420 <anon.773058ed228f2edaafa50d5b0d646736.9.llvm.4321263285462747625>
    40203bec:	f840856c 	ldr	x12, [x11], #8
    40203bf0:	8b08012d 	add	x13, x9, x8
    40203bf4:	a900a9aa 	stp	x10, x10, [x13, #8]
    40203bf8:	f90001ac 	str	x12, [x13]
    40203bfc:	390061bf 	strb	wzr, [x13, #24]
    40203c00:	91008108 	add	x8, x8, #0x20
    40203c04:	f101811f 	cmp	x8, #0x60
    40203c08:	54ffff21 	b.ne	40203bec <_ZN11jnox_kernel10native_el09extension5start17h7a1d16f295a7c4b5E+0x6c>  // b.any
    40203c0c:	910003e8 	mov	x8, sp
    40203c10:	91022100 	add	x0, x8, #0x88
    40203c14:	9104c3e1 	add	x1, sp, #0x130
    40203c18:	52800c02 	mov	w2, #0x60                  	// #96
    40203c1c:	94000bc8 	bl	40206b3c <memcpy>
    40203c20:	aa1f03e8 	mov	x8, xzr
    40203c24:	9103a3e9 	add	x9, sp, #0xe8
    40203c28:	f828693f 	str	xzr, [x9, x8]
    40203c2c:	91004108 	add	x8, x8, #0x10
    40203c30:	f100c11f 	cmp	x8, #0x30
    40203c34:	54ffffa1 	b.ne	40203c28 <_ZN11jnox_kernel10native_el09extension5start17h7a1d16f295a7c4b5E+0xa8>  // b.any
    40203c38:	aa1f03e8 	mov	x8, xzr
    40203c3c:	910463e9 	add	x9, sp, #0x118
    40203c40:	f8286935 	str	x21, [x9, x8]
    40203c44:	91002108 	add	x8, x8, #0x8
    40203c48:	f100611f 	cmp	x8, #0x18
    40203c4c:	54ffffa1 	b.ne	40203c40 <_ZN11jnox_kernel10native_el09extension5start17h7a1d16f295a7c4b5E+0xc0>  // b.any
    40203c50:	d503201f 	nop
    40203c54:	1007eb76 	adr	x22, 402139c0 <_ZN11jnox_kernel10native_el09extension5STATE17heea3f949cf12c2d5E.llvm.8080503781627406991>
    40203c58:	f90002df 	str	xzr, [x22]
    40203c5c:	52800057 	mov	w23, #0x2                   	// #2
    40203c60:	f9000ad7 	str	x23, [x22, #16]
    40203c64:	910062c0 	add	x0, x22, #0x18
    40203c68:	910003e1 	mov	x1, sp
    40203c6c:	52801d02 	mov	w2, #0xe8                  	// #232
    40203c70:	94000bb3 	bl	40206b3c <memcpy>
    40203c74:	52800078 	mov	w24, #0x3                   	// #3
    40203c78:	52800028 	mov	w8, #0x1                   	// #1
    40203c7c:	a91062df 	stp	xzr, x24, [x22, #256]
    40203c80:	a91122d7 	stp	x23, x8, [x22, #272]
    40203c84:	a9127edf 	stp	xzr, xzr, [x22, #288]
    40203c88:	a9137edf 	stp	xzr, xzr, [x22, #304]
    40203c8c:	a9147ed7 	stp	x23, xzr, [x22, #320]
    40203c90:	f900aadf 	str	xzr, [x22, #336]
    40203c94:	390562df 	strb	wzr, [x22, #344]
    40203c98:	910582c0 	add	x0, x22, #0x160
    40203c9c:	9103a3e1 	add	x1, sp, #0xe8
    40203ca0:	52800602 	mov	w2, #0x30                  	// #48
    40203ca4:	94000ba6 	bl	40206b3c <memcpy>
    40203ca8:	f900cadf 	str	xzr, [x22, #400]
    40203cac:	a91a56d3 	stp	x19, x21, [x22, #416]
    40203cb0:	a91b7ed4 	stp	x20, xzr, [x22, #432]
    40203cb4:	a91c62df 	stp	xzr, x24, [x22, #448]
    40203cb8:	a951a7e8 	ldp	x8, x9, [sp, #280]
    40203cbc:	a91d22df 	stp	xzr, x8, [x22, #464]
    40203cc0:	f94097e8 	ldr	x8, [sp, #296]
    40203cc4:	a91e22c9 	stp	x9, x8, [x22, #480]
    40203cc8:	d503201f 	nop
    40203ccc:	10fe59a8 	adr	x8, 40200800 <native_el0_vectors>
    40203cd0:	a91f7edf 	stp	xzr, xzr, [x22, #496]
    40203cd4:	390802df 	strb	wzr, [x22, #512]
    40203cd8:	d518c008 	msr	vbar_el1, x8
    40203cdc:	d5033fdf 	isb
    40203ce0:	f94002c8 	ldr	x8, [x22]
    40203ce4:	f100091f 	cmp	x8, #0x2
    40203ce8:	54000220 	b.eq	40203d2c <_ZN11jnox_kernel10native_el09extension5start17h7a1d16f295a7c4b5E+0x1ac>  // b.none
    40203cec:	94000221 	bl	40204570 <_ZN11jnox_kernel10native_el09extension7Runtime3arm17h82d6de6888983821E>
    40203cf0:	d00000a0 	adrp	x0, 40219000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3ce0>
    40203cf4:	910c8000 	add	x0, x0, #0x320
    40203cf8:	97fff5de 	bl	40201470 <native_sleep_switch>
    40203cfc:	90000088 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40203d00:	f944e108 	ldr	x8, [x8, #2496]
    40203d04:	f100091f 	cmp	x8, #0x2
    40203d08:	54000120 	b.eq	40203d2c <_ZN11jnox_kernel10native_el09extension5start17h7a1d16f295a7c4b5E+0x1ac>  // b.none
    40203d0c:	90000088 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40203d10:	f945c500 	ldr	x0, [x8, #2952]
    40203d14:	a95c4ff4 	ldp	x20, x19, [sp, #448]
    40203d18:	a95b57f6 	ldp	x22, x21, [sp, #432]
    40203d1c:	a95a5ff8 	ldp	x24, x23, [sp, #416]
    40203d20:	a9597bfd 	ldp	x29, x30, [sp, #400]
    40203d24:	910743ff 	add	sp, sp, #0x1d0
    40203d28:	d65f03c0 	ret
    40203d2c:	52800340 	mov	w0, #0x1a                  	// #26
    40203d30:	97fff935 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    40203d34:	94000001 	bl	40203d38 <_ZN11jnox_kernel10native_el09extension5start28_$u7b$$u7b$closure$u7d$$u7d$17h8c5e8e8762c22bbfE>

0000000040203d38 <_ZN11jnox_kernel10native_el09extension5start28_$u7b$$u7b$closure$u7d$$u7d$17h8c5e8e8762c22bbfE>:
    40203d38:	f81f0ffe 	str	x30, [sp, #-16]!
    40203d3c:	52800340 	mov	w0, #0x1a                  	// #26
    40203d40:	97fff931 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>

0000000040203d44 <_ZN11jnox_kernel10native_el09extension6finish17hd905cea193690701E.llvm.8080503781627406991>:
    40203d44:	d101c3ff 	sub	sp, sp, #0x70
    40203d48:	a9045ffe 	stp	x30, x23, [sp, #64]
    40203d4c:	a90557f6 	stp	x22, x21, [sp, #80]
    40203d50:	a9064ff4 	stp	x20, x19, [sp, #96]
    40203d54:	90000088 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40203d58:	f944e108 	ldr	x8, [x8, #2496]
    40203d5c:	f100091f 	cmp	x8, #0x2
    40203d60:	54000a20 	b.eq	40203ea4 <_ZN11jnox_kernel10native_el09extension6finish17hd905cea193690701E.llvm.8080503781627406991+0x160>  // b.none
    40203d64:	90000093 	adrp	x19, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40203d68:	912d8273 	add	x19, x19, #0xb60
    40203d6c:	52800028 	mov	w8, #0x1                   	// #1
    40203d70:	a940266a 	ldp	x10, x9, [x19]
    40203d74:	a900a7e8 	stp	x8, x9, [sp, #8]
    40203d78:	f9400a68 	ldr	x8, [x19, #16]
    40203d7c:	528000a9 	mov	w9, #0x5                   	// #5
    40203d80:	a901a3ea 	stp	x10, x8, [sp, #24]
    40203d84:	52800048 	mov	w8, #0x2                   	// #2
    40203d88:	a902a3e9 	stp	x9, x8, [sp, #40]
    40203d8c:	52800068 	mov	w8, #0x3                   	// #3
    40203d90:	f9001fe8 	str	x8, [sp, #56]
    40203d94:	d503201f 	nop
    40203d98:	30073940 	adr	x0, 402124c1 <anon.09c3d38f9b7290fd63a7fa379a74bb58.1.llvm.8080503781627406991+0x29>
    40203d9c:	910023e2 	add	x2, sp, #0x8
    40203da0:	528000c1 	mov	w1, #0x6                   	// #6
    40203da4:	528000e3 	mov	w3, #0x7                   	// #7
    40203da8:	97ffff42 	bl	40203ab0 <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE>
    40203dac:	f9402a76 	ldr	x22, [x19, #80]
    40203db0:	b4000336 	cbz	x22, 40203e14 <_ZN11jnox_kernel10native_el09extension6finish17hd905cea193690701E.llvm.8080503781627406991+0xd0>
    40203db4:	aa1f03f7 	mov	x23, xzr
    40203db8:	d503201f 	nop
    40203dbc:	100aab73 	adr	x19, 40219328 <_ZN11jnox_kernel10native_el09extension4ROWS17h71366c1b688cc4d8E.llvm.8080503781627406991>
    40203dc0:	d503201f 	nop
    40203dc4:	50073874 	adr	x20, 402124d2 <anon.09c3d38f9b7290fd63a7fa379a74bb58.1.llvm.8080503781627406991+0x3a>
    40203dc8:	d503201f 	nop
    40203dcc:	70073855 	adr	x21, 402124d7 <anon.09c3d38f9b7290fd63a7fa379a74bb58.1.llvm.8080503781627406991+0x3f>
    40203dd0:	f90007f7 	str	x23, [sp, #8]
    40203dd4:	910023e2 	add	x2, sp, #0x8
    40203dd8:	aa1403e0 	mov	x0, x20
    40203ddc:	528000a1 	mov	w1, #0x5                   	// #5
    40203de0:	52800023 	mov	w3, #0x1                   	// #1
    40203de4:	97ffff33 	bl	40203ab0 <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE>
    40203de8:	f10802ff 	cmp	x23, #0x200
    40203dec:	54000520 	b.eq	40203e90 <_ZN11jnox_kernel10native_el09extension6finish17hd905cea193690701E.llvm.8080503781627406991+0x14c>  // b.none
    40203df0:	910006f7 	add	x23, x23, #0x1
    40203df4:	aa1503e0 	mov	x0, x21
    40203df8:	528000a1 	mov	w1, #0x5                   	// #5
    40203dfc:	aa1303e2 	mov	x2, x19
    40203e00:	52800503 	mov	w3, #0x28                  	// #40
    40203e04:	97ffff2b 	bl	40203ab0 <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE>
    40203e08:	91050273 	add	x19, x19, #0x140
    40203e0c:	eb1702df 	cmp	x22, x23
    40203e10:	54fffe01 	b.ne	40203dd0 <_ZN11jnox_kernel10native_el09extension6finish17hd905cea193690701E.llvm.8080503781627406991+0x8c>  // b.any
    40203e14:	90000088 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40203e18:	f945dd08 	ldr	x8, [x8, #3000]
    40203e1c:	f90007e8 	str	x8, [sp, #8]
    40203e20:	d503201f 	nop
    40203e24:	70073500 	adr	x0, 402124c7 <anon.09c3d38f9b7290fd63a7fa379a74bb58.1.llvm.8080503781627406991+0x2f>
    40203e28:	910023e2 	add	x2, sp, #0x8
    40203e2c:	528000e1 	mov	w1, #0x7                   	// #7
    40203e30:	52800023 	mov	w3, #0x1                   	// #1
    40203e34:	97ffff1f 	bl	40203ab0 <_ZN11jnox_kernel10native_el09extension5print17he9149a3dbeab373dE>
    40203e38:	aa1f03e2 	mov	x2, xzr
    40203e3c:	d503201f 	nop
    40203e40:	1008a614 	adr	x20, 40215300 <_ZN11jnox_kernel10native_el011EXIT_STATUS17h849302c83dc4275cE>
    40203e44:	d503201f 	nop
    40203e48:	50073433 	adr	x19, 402124ce <anon.09c3d38f9b7290fd63a7fa379a74bb58.1.llvm.8080503781627406991+0x36>
    40203e4c:	91000455 	add	x21, x2, #0x1
    40203e50:	b8a27a84 	ldrsw	x4, [x20, x2, lsl #2]
    40203e54:	aa1303e0 	mov	x0, x19
    40203e58:	52800081 	mov	w1, #0x4                   	// #4
    40203e5c:	52800023 	mov	w3, #0x1                   	// #1
    40203e60:	97fff909 	bl	40202284 <_ZN11jnox_kernel10native_el05event17hb7a074d794f18904E>
    40203e64:	f1000ebf 	cmp	x21, #0x3
    40203e68:	aa1503e2 	mov	x2, x21
    40203e6c:	54ffff01 	b.ne	40203e4c <_ZN11jnox_kernel10native_el09extension6finish17hd905cea193690701E.llvm.8080503781627406991+0x108>  // b.any
    40203e70:	b0000088 	adrp	x8, 40214000 <_ZN11jnox_kernel10native_el012CLOCK_DOMAIN17h874e00fa96a4d8f0E.0.llvm.16067307468115866285>
    40203e74:	9138a108 	add	x8, x8, #0xe28
    40203e78:	52800029 	mov	w9, #0x1                   	// #1
    40203e7c:	f9002509 	str	x9, [x8, #72]
    40203e80:	52800069 	mov	w9, #0x3                   	// #3
    40203e84:	f9000109 	str	x9, [x8]
    40203e88:	d503205f 	wfe
    40203e8c:	17ffffff 	b	40203e88 <_ZN11jnox_kernel10native_el09extension6finish17hd905cea193690701E.llvm.8080503781627406991+0x144>
    40203e90:	d503201f 	nop
    40203e94:	10073262 	adr	x2, 402124e0 <anon.09c3d38f9b7290fd63a7fa379a74bb58.1.llvm.8080503781627406991+0x48>
    40203e98:	52804000 	mov	w0, #0x200                 	// #512
    40203e9c:	52804001 	mov	w1, #0x200                 	// #512
    40203ea0:	940006c8 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40203ea4:	52800340 	mov	w0, #0x1a                  	// #26
    40203ea8:	97fff8d7 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>

0000000040203eac <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991>:
    40203eac:	d10603ff 	sub	sp, sp, #0x180
    40203eb0:	a9127bfd 	stp	x29, x30, [sp, #288]
    40203eb4:	a9136ffc 	stp	x28, x27, [sp, #304]
    40203eb8:	a91467fa 	stp	x26, x25, [sp, #320]
    40203ebc:	a9155ff8 	stp	x24, x23, [sp, #336]
    40203ec0:	a91657f6 	stp	x22, x21, [sp, #352]
    40203ec4:	a9174ff4 	stp	x20, x19, [sp, #368]
    40203ec8:	d5033fdf 	isb
    40203ecc:	d53be036 	mrs	x22, cntpct_el0
    40203ed0:	90000088 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40203ed4:	f944e11a 	ldr	x26, [x8, #2496]
    40203ed8:	f1000b5f 	cmp	x26, #0x2
    40203edc:	54003340 	b.eq	40204544 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x698>  // b.none
    40203ee0:	aa0403f9 	mov	x25, x4
    40203ee4:	90000084 	adrp	x4, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40203ee8:	f945c494 	ldr	x20, [x4, #2952]
    40203eec:	f100033f 	cmp	x25, #0x0
    40203ef0:	1a9f07e8 	cset	w8, ne  // ne = any
    40203ef4:	f1000e9f 	cmp	x20, #0x3
    40203ef8:	1a9f27e9 	cset	w9, cc  // cc = lo, ul, last
    40203efc:	4a090108 	eor	w8, w8, w9
    40203f00:	37003228 	tbnz	w8, #0, 40204544 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x698>
    40203f04:	aa0003f8 	mov	x24, x0
    40203f08:	90000088 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40203f0c:	91272108 	add	x8, x8, #0x9c8
    40203f10:	f940e50b 	ldr	x11, [x8, #456]
    40203f14:	f9400100 	ldr	x0, [x8]
    40203f18:	3945411e 	ldrb	w30, [x8, #336]
    40203f1c:	d53be253 	mrs	x19, cntp_cval_el0
    40203f20:	d53be23c 	mrs	x28, cntp_ctl_el0
    40203f24:	b40000f9 	cbz	x25, 40203f40 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x94>
    40203f28:	d0000088 	adrp	x8, 40215000 <jnox_native_el0_journal+0x1e0>
    40203f2c:	f9418908 	ldr	x8, [x8, #784]
    40203f30:	eb14011f 	cmp	x8, x20
    40203f34:	54003081 	b.ne	40204544 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x698>  // b.any
    40203f38:	a950b32d 	ldp	x13, x12, [x25, #264]
    40203f3c:	14000008 	b	40203f5c <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0xb0>
    40203f40:	f100043f 	cmp	x1, #0x1
    40203f44:	54000081 	b.ne	40203f54 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0xa8>  // b.any
    40203f48:	aa1f03ec 	mov	x12, xzr
    40203f4c:	d538402d 	mrs	x13, elr_el1
    40203f50:	14000003 	b	40203f5c <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0xb0>
    40203f54:	aa1f03ec 	mov	x12, xzr
    40203f58:	aa1f03ed 	mov	x13, xzr
    40203f5c:	f10004bf 	cmp	x5, #0x1
    40203f60:	90000088 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40203f64:	d503201f 	nop
    40203f68:	1007d2c7 	adr	x7, 402139c0 <_ZN11jnox_kernel10native_el09extension5STATE17heea3f949cf12c2d5E.llvm.8080503781627406991>
    40203f6c:	5400006c 	b.gt	40203f78 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0xcc>
    40203f70:	b5000245 	cbnz	x5, 40203fb8 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x10c>
    40203f74:	14000013 	b	40203fc0 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x114>
    40203f78:	f10008bf 	cmp	x5, #0x2
    40203f7c:	54000121 	b.ne	40203fa0 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0xf4>  // b.any
    40203f80:	f1000e9f 	cmp	x20, #0x3
    40203f84:	54002e42 	b.cs	4020454c <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x6a0>  // b.hs, b.nlast
    40203f88:	8b140ce9 	add	x9, x7, x20, lsl #3
    40203f8c:	f900ed26 	str	x6, [x9, #472]
    40203f90:	8b1410e9 	add	x9, x7, x20, lsl #4
    40203f94:	5280002a 	mov	w10, #0x1                   	// #1
    40203f98:	a916192a 	stp	x10, x6, [x9, #352]
    40203f9c:	14000007 	b	40203fb8 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x10c>
    40203fa0:	92400a89 	and	x9, x20, #0x7
    40203fa4:	5280002a 	mov	w10, #0x1                   	// #1
    40203fa8:	1ac92149 	lsl	w9, w10, w9
    40203fac:	396f010a 	ldrb	w10, [x8, #3008]
    40203fb0:	2a090149 	orr	w9, w10, w9
    40203fb4:	392f0109 	strb	w9, [x8, #3008]
    40203fb8:	52800069 	mov	w9, #0x3                   	// #3
    40203fbc:	f905c489 	str	x9, [x4, #2952]
    40203fc0:	396f0109 	ldrb	w9, [x8, #3008]
    40203fc4:	f100043f 	cmp	x1, #0x1
    40203fc8:	a9062fec 	stp	x12, x11, [sp, #96]
    40203fcc:	f9002fed 	str	x13, [sp, #88]
    40203fd0:	54000201 	b.ne	40204010 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x164>  // b.any
    40203fd4:	71001d3f 	cmp	w9, #0x7
    40203fd8:	54000200 	b.eq	40204018 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x16c>  // b.none
    40203fdc:	92402448 	and	x8, x2, #0x3ff
    40203fe0:	f100791f 	cmp	x8, #0x1e
    40203fe4:	540003c1 	b.ne	4020405c <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x1b0>  // b.any
    40203fe8:	90000088 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40203fec:	f945b508 	ldr	x8, [x8, #2920]
    40203ff0:	eb0802ca 	subs	x10, x22, x8
    40203ff4:	54000422 	b.cs	40204078 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x1cc>  // b.hs, b.nlast
    40203ff8:	a9047fff 	stp	xzr, xzr, [sp, #64]
    40203ffc:	f9001fff 	str	xzr, [sp, #56]
    40204000:	f9002bff 	str	xzr, [sp, #80]
    40204004:	92800008 	mov	x8, #0xffffffffffffffff    	// #-1
    40204008:	a90723ff 	stp	xzr, x8, [sp, #112]
    4020400c:	140000aa 	b	402042b4 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x408>
    40204010:	71001d3f 	cmp	w9, #0x7
    40204014:	54000241 	b.ne	4020405c <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x1b0>  // b.any
    40204018:	a9047fff 	stp	xzr, xzr, [sp, #64]
    4020401c:	f9001fff 	str	xzr, [sp, #56]
    40204020:	f9002bff 	str	xzr, [sp, #80]
    40204024:	aa1f03f5 	mov	x21, xzr
    40204028:	f9003bff 	str	xzr, [sp, #112]
    4020402c:	52800048 	mov	w8, #0x2                   	// #2
    40204030:	f0000069 	adrp	x9, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204034:	91274129 	add	x9, x9, #0x9d0
    40204038:	f9000128 	str	x8, [x9]
    4020403c:	3905213f 	strb	wzr, [x9, #328]
    40204040:	52800088 	mov	w8, #0x4                   	// #4
    40204044:	a91bfd28 	stp	x8, xzr, [x9, #440]
    40204048:	d51be23f 	msr	cntp_ctl_el0, xzr
    4020404c:	d5033fdf 	isb
    40204050:	92800008 	mov	x8, #0xffffffffffffffff    	// #-1
    40204054:	f9003fe8 	str	x8, [sp, #120]
    40204058:	140000c4 	b	40204368 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x4bc>
    4020405c:	a9047fff 	stp	xzr, xzr, [sp, #64]
    40204060:	f9001fff 	str	xzr, [sp, #56]
    40204064:	f9002bff 	str	xzr, [sp, #80]
    40204068:	2a1f03e8 	mov	w8, wzr
    4020406c:	92800009 	mov	x9, #0xffffffffffffffff    	// #-1
    40204070:	a90727ff 	stp	xzr, x9, [sp, #112]
    40204074:	14000091 	b	402042b8 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x40c>
    40204078:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    4020407c:	f945b908 	ldr	x8, [x8, #2928]
    40204080:	b4002708 	cbz	x8, 40204560 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x6b4>
    40204084:	a94030eb 	ldp	x11, x12, [x7]
    40204088:	9ac80945 	udiv	x5, x10, x8
    4020408c:	a9028be0 	stp	x0, x2, [sp, #40]
    40204090:	f90013e1 	str	x1, [sp, #32]
    40204094:	a900fbe3 	stp	x3, x30, [sp, #8]
    40204098:	b400014b 	cbz	x11, 402040c0 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x214>
    4020409c:	eb05019f 	cmp	x12, x5
    402040a0:	54000101 	b.ne	402040c0 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x214>  // b.any
    402040a4:	aa0403f7 	mov	x23, x4
    402040a8:	aa0703f5 	mov	x21, x7
    402040ac:	2a1f03fd 	mov	w29, wzr
    402040b0:	f9002bff 	str	xzr, [sp, #80]
    402040b4:	92800008 	mov	x8, #0xffffffffffffffff    	// #-1
    402040b8:	a90723ff 	stp	xzr, x8, [sp, #112]
    402040bc:	14000055 	b	40204210 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x364>
    402040c0:	9100058c 	add	x12, x12, #0x1
    402040c4:	eb0c00ac 	subs	x12, x5, x12
    402040c8:	9a8c33ec 	csel	x12, xzr, x12, cc  // cc = lo, ul, last
    402040cc:	7100017f 	cmp	w11, #0x0
    402040d0:	9a851192 	csel	x18, x12, x5, ne  // ne = any
    402040d4:	f000006b 	adrp	x11, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402040d8:	912c616b 	add	x11, x11, #0xb18
    402040dc:	3940017d 	ldrb	w29, [x11]
    402040e0:	cb0a03ea 	neg	x10, x10
    402040e4:	9b0828aa 	madd	x10, x5, x8, x10
    402040e8:	8b0a02ca 	add	x10, x22, x10
    402040ec:	f900316a 	str	x10, [x11, #96]
    402040f0:	ab08014f 	adds	x15, x10, x8
    402040f4:	540023c2 	b.cs	4020456c <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x6c0>  // b.hs, b.nlast
    402040f8:	2a1f03eb 	mov	w11, wzr
    402040fc:	aa1f03ec 	mov	x12, xzr
    40204100:	5280002d 	mov	w13, #0x1                   	// #1
    40204104:	f000006e 	adrp	x14, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204108:	912ca1ce 	add	x14, x14, #0xb28
    4020410c:	f9002dcf 	str	x15, [x14, #88]
    40204110:	1acc21af 	lsl	w15, w13, w12
    40204114:	6a0901ff 	tst	w15, w9
    40204118:	54000181 	b.ne	40204148 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x29c>  // b.any
    4020411c:	8b0c0cf0 	add	x16, x7, x12, lsl #3
    40204120:	f940ee10 	ldr	x16, [x16, #472]
    40204124:	eb0a021f 	cmp	x16, x10
    40204128:	54000108 	b.hi	40204148 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x29c>  // b.pmore
    4020412c:	b85f81d0 	ldur	w16, [x14, #-8]
    40204130:	f94001d1 	ldr	x17, [x14]
    40204134:	eb0a023f 	cmp	x17, x10
    40204138:	1a9f97f1 	cset	w17, hi  // hi = pmore
    4020413c:	6a11021f 	tst	w16, w17
    40204140:	1a8f13ef 	csel	w15, wzr, w15, ne  // ne = any
    40204144:	2a0b01eb 	orr	w11, w15, w11
    40204148:	9100058c 	add	x12, x12, #0x1
    4020414c:	910041ce 	add	x14, x14, #0x10
    40204150:	f1000d9f 	cmp	x12, #0x3
    40204154:	54fffde1 	b.ne	40204110 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x264>  // b.any
    40204158:	aa0403f7 	mov	x23, x4
    4020415c:	f9002bf2 	str	x18, [sp, #80]
    40204160:	aa0703f5 	mov	x21, x7
    40204164:	aa1f03e9 	mov	x9, xzr
    40204168:	910303ec 	add	x12, sp, #0xc0
    4020416c:	9100418c 	add	x12, x12, #0x10
    40204170:	5280002d 	mov	w13, #0x1                   	// #1
    40204174:	d503201f 	nop
    40204178:	1007154e 	adr	x14, 40212420 <anon.773058ed228f2edaafa50d5b0d646736.9.llvm.4321263285462747625>
    4020417c:	f86979cf 	ldr	x15, [x14, x9, lsl #3]
    40204180:	a93fb58d 	stp	x13, x13, [x12, #-8]
    40204184:	12001d70 	and	w16, w11, #0xff
    40204188:	1ac92610 	lsr	w16, w16, w9
    4020418c:	12000210 	and	w16, w16, #0x1
    40204190:	39002190 	strb	w16, [x12, #8]
    40204194:	f81f018f 	stur	x15, [x12, #-16]
    40204198:	91000529 	add	x9, x9, #0x1
    4020419c:	9100818c 	add	x12, x12, #0x20
    402041a0:	f1000d3f 	cmp	x9, #0x3
    402041a4:	54fffec1 	b.ne	4020417c <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x2d0>  // b.any
    402041a8:	8b480942 	add	x2, x10, x8, lsr #2
    402041ac:	52800068 	mov	w8, #0x3                   	// #3
    402041b0:	aa1503e0 	mov	x0, x21
    402041b4:	f900e6a8 	str	x8, [x21, #456]
    402041b8:	910203e8 	add	x8, sp, #0x80
    402041bc:	910303e3 	add	x3, sp, #0xc0
    402041c0:	aa0503fb 	mov	x27, x5
    402041c4:	aa0503e1 	mov	x1, x5
    402041c8:	97fffbb0 	bl	40203088 <_ZN11jnox_kernel10native_el09extension11transaction11Transaction4open17h176b3adb3fcc68f3E>
    402041cc:	f94043e8 	ldr	x8, [sp, #128]
    402041d0:	f100091f 	cmp	x8, #0x2
    402041d4:	54000081 	b.ne	402041e4 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x338>  // b.any
    402041d8:	92800008 	mov	x8, #0xffffffffffffffff    	// #-1
    402041dc:	a90723ff 	stp	xzr, x8, [sp, #112]
    402041e0:	1400000b 	b	4020420c <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x360>
    402041e4:	3942a3e9 	ldrb	w9, [sp, #168]
    402041e8:	f9003fe9 	str	x9, [sp, #120]
    402041ec:	f100051f 	cmp	x8, #0x1
    402041f0:	540000c1 	b.ne	40204208 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x35c>  // b.any
    402041f4:	f9404fe8 	ldr	x8, [sp, #152]
    402041f8:	f9003be8 	str	x8, [sp, #112]
    402041fc:	f94047e8 	ldr	x8, [sp, #136]
    40204200:	f905c6e8 	str	x8, [x23, #2952]
    40204204:	14000002 	b	4020420c <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x360>
    40204208:	f9003bff 	str	xzr, [sp, #112]
    4020420c:	aa1b03e5 	mov	x5, x27
    40204210:	d503201f 	nop
    40204214:	1007bd60 	adr	x0, 402139c0 <_ZN11jnox_kernel10native_el09extension5STATE17heea3f949cf12c2d5E.llvm.8080503781627406991>
    40204218:	910203e8 	add	x8, sp, #0x80
    4020421c:	aa0503e1 	mov	x1, x5
    40204220:	aa1603e2 	mov	x2, x22
    40204224:	97fffbc6 	bl	4020313c <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7consume17h542295903a9149d1E>
    40204228:	f94043e9 	ldr	x9, [sp, #128]
    4020422c:	f100093f 	cmp	x9, #0x2
    40204230:	54000121 	b.ne	40204254 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x3a8>  // b.any
    40204234:	f90027ff 	str	xzr, [sp, #72]
    40204238:	2a1f03e8 	mov	w8, wzr
    4020423c:	a940fbe3 	ldp	x3, x30, [sp, #8]
    40204240:	a9428be0 	ldp	x0, x2, [sp, #40]
    40204244:	f94013e1 	ldr	x1, [sp, #32]
    40204248:	aa1503e7 	mov	x7, x21
    4020424c:	aa1703e4 	mov	x4, x23
    40204250:	14000016 	b	402042a8 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x3fc>
    40204254:	3942a3e8 	ldrb	w8, [sp, #168]
    40204258:	f9003fe8 	str	x8, [sp, #120]
    4020425c:	3942a7e8 	ldrb	w8, [sp, #169]
    40204260:	b940b3ea 	ldr	w10, [sp, #176]
    40204264:	7100015f 	cmp	w10, #0x0
    40204268:	f9405feb 	ldr	x11, [sp, #184]
    4020426c:	9a9f116b 	csel	x11, x11, xzr, ne  // ne = any
    40204270:	f90027eb 	str	x11, [sp, #72]
    40204274:	5200014a 	eor	w10, w10, #0x1
    40204278:	2a1d015d 	orr	w29, w10, w29
    4020427c:	f100053f 	cmp	x9, #0x1
    40204280:	a940fbe3 	ldp	x3, x30, [sp, #8]
    40204284:	a94203e1 	ldp	x1, x0, [sp, #32]
    40204288:	aa1703e4 	mov	x4, x23
    4020428c:	540000a1 	b.ne	402042a0 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x3f4>  // b.any
    40204290:	f9404fe9 	ldr	x9, [sp, #152]
    40204294:	f9003be9 	str	x9, [sp, #112]
    40204298:	f94047e9 	ldr	x9, [sp, #136]
    4020429c:	f905c489 	str	x9, [x4, #2952]
    402042a0:	f9401be2 	ldr	x2, [sp, #48]
    402042a4:	aa1503e7 	mov	x7, x21
    402042a8:	2a0803e9 	mov	w9, w8
    402042ac:	924003a8 	and	x8, x29, #0x1
    402042b0:	a903a7e8 	stp	x8, x9, [sp, #56]
    402042b4:	52800028 	mov	w8, #0x1                   	// #1
    402042b8:	aa1f03f5 	mov	x21, xzr
    402042bc:	aa1f03e9 	mov	x9, xzr
    402042c0:	5280002a 	mov	w10, #0x1                   	// #1
    402042c4:	f000006b 	adrp	x11, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402042c8:	912c816b 	add	x11, x11, #0xb20
    402042cc:	a940356c 	ldp	x12, x13, [x11]
    402042d0:	f100059f 	cmp	x12, #0x1
    402042d4:	fa5601a2 	ccmp	x13, x22, #0x2, eq  // eq = none
    402042d8:	54000088 	b.hi	402042e8 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x43c>  // b.pmore
    402042dc:	f900017f 	str	xzr, [x11]
    402042e0:	9ac9214c 	lsl	x12, x10, x9
    402042e4:	aa150195 	orr	x21, x12, x21
    402042e8:	91000529 	add	x9, x9, #0x1
    402042ec:	9100416b 	add	x11, x11, #0x10
    402042f0:	f1000d3f 	cmp	x9, #0x3
    402042f4:	54fffec1 	b.ne	402042cc <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x420>  // b.any
    402042f8:	aa0703f7 	mov	x23, x7
    402042fc:	a90203e1 	stp	x1, x0, [sp, #32]
    40204300:	aa1a03fd 	mov	x29, x26
    40204304:	f9000ff4 	str	x20, [sp, #24]
    40204308:	aa1e03f4 	mov	x20, x30
    4020430c:	f9001be2 	str	x2, [sp, #48]
    40204310:	aa1303fb 	mov	x27, x19
    40204314:	aa1c03f3 	mov	x19, x28
    40204318:	aa0303fc 	mov	x28, x3
    4020431c:	37000108 	tbnz	w8, #0, 4020433c <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x490>
    40204320:	f94002e8 	ldr	x8, [x23]
    40204324:	b40000c8 	cbz	x8, 4020433c <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x490>
    40204328:	f940e2e8 	ldr	x8, [x23, #448]
    4020432c:	eb0802df 	cmp	x22, x8
    40204330:	54000063 	b.cc	4020433c <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x490>  // b.lo, b.ul, b.last
    40204334:	52800068 	mov	w8, #0x3                   	// #3
    40204338:	f905c488 	str	x8, [x4, #2952]
    4020433c:	aa0403fa 	mov	x26, x4
    40204340:	9400008c 	bl	40204570 <_ZN11jnox_kernel10native_el09extension7Runtime3arm17h82d6de6888983821E>
    40204344:	aa1a03e4 	mov	x4, x26
    40204348:	aa1c03e3 	mov	x3, x28
    4020434c:	aa1303fc 	mov	x28, x19
    40204350:	aa1b03f3 	mov	x19, x27
    40204354:	a9428be0 	ldp	x0, x2, [sp, #40]
    40204358:	aa1403fe 	mov	x30, x20
    4020435c:	a94187f4 	ldp	x20, x1, [sp, #24]
    40204360:	aa1d03fa 	mov	x26, x29
    40204364:	aa1703e7 	mov	x7, x23
    40204368:	f945c488 	ldr	x8, [x4, #2952]
    4020436c:	f1000d1f 	cmp	x8, #0x3
    40204370:	54000102 	b.cs	40204390 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x4e4>  // b.hs, b.nlast
    40204374:	eb08029f 	cmp	x20, x8
    40204378:	54000121 	b.ne	4020439c <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x4f0>  // b.any
    4020437c:	aa1903ea 	mov	x10, x25
    40204380:	b5000179 	cbnz	x25, 402043ac <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x500>
    40204384:	d503201f 	nop
    40204388:	10070d00 	adr	x0, 40212528 <anon.09c3d38f9b7290fd63a7fa379a74bb58.1.llvm.8080503781627406991+0x90>
    4020438c:	94000586 	bl	402059a4 <_RNvNtCsbcsGJ9IzBgZ_4core6option13unwrap_failed>
    40204390:	aa1f03e9 	mov	x9, xzr
    40204394:	aa1f03ea 	mov	x10, xzr
    40204398:	14000006 	b	402043b0 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x504>
    4020439c:	52806809 	mov	w9, #0x340                 	// #832
    402043a0:	d503201f 	nop
    402043a4:	100762ea 	adr	x10, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402043a8:	9b09290a 	madd	x10, x8, x9, x10
    402043ac:	a950a949 	ldp	x9, x10, [x10, #264]
    402043b0:	aa1f03ec 	mov	x12, xzr
    402043b4:	aa1f03eb 	mov	x11, xzr
    402043b8:	f000006d 	adrp	x13, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402043bc:	9129e1ad 	add	x13, x13, #0xa78
    402043c0:	384205ae 	ldrb	w14, [x13], #32
    402043c4:	9acc21ce 	lsl	x14, x14, x12
    402043c8:	aa0b01cb 	orr	x11, x14, x11
    402043cc:	9100058c 	add	x12, x12, #0x1
    402043d0:	f1000d9f 	cmp	x12, #0x3
    402043d4:	54ffff61 	b.ne	402043c0 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x514>  // b.any
    402043d8:	7200035f 	tst	w26, #0x1
    402043dc:	b94000ec 	ldr	w12, [x7]
    402043e0:	f94004ed 	ldr	x13, [x7, #8]
    402043e4:	a95becfd 	ldp	x29, x27, [x7, #440]
    402043e8:	f940e8f2 	ldr	x18, [x7, #464]
    402043ec:	da9f1004 	csinv	x4, x0, xzr, ne  // ne = any
    402043f0:	394560f1 	ldrb	w17, [x7, #344]
    402043f4:	7100019f 	cmp	w12, #0x0
    402043f8:	da9f11a6 	csinv	x6, x13, xzr, ne  // ne = any
    402043fc:	a954bce5 	ldp	x5, x15, [x7, #328]
    40204400:	394800ed 	ldrb	w13, [x7, #512]
    40204404:	d538200c 	mrs	x12, ttbr0_el1
    40204408:	b94160ee 	ldr	w14, [x7, #352]
    4020440c:	f940b4f0 	ldr	x16, [x7, #360]
    40204410:	710001df 	cmp	w14, #0x0
    40204414:	9a9f120e 	csel	x14, x16, xzr, ne  // ne = any
    40204418:	b94170f0 	ldr	w16, [x7, #368]
    4020441c:	f940bce0 	ldr	x0, [x7, #376]
    40204420:	7100021f 	cmp	w16, #0x0
    40204424:	9a9f1010 	csel	x16, x0, xzr, ne  // ne = any
    40204428:	b94180e0 	ldr	w0, [x7, #384]
    4020442c:	7100001f 	cmp	w0, #0x0
    40204430:	f940c4e0 	ldr	x0, [x7, #392]
    40204434:	9a9f1000 	csel	x0, x0, xzr, ne  // ne = any
    40204438:	b4000079 	cbz	x25, 40204444 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x598>
    4020443c:	f940033a 	ldr	x26, [x25]
    40204440:	14000002 	b	40204448 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x59c>
    40204444:	aa1f03fa 	mov	x26, xzr
    40204448:	f0000067 	adrp	x7, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    4020444c:	f945d8e7 	ldr	x7, [x7, #2992]
    40204450:	f10800ff 	cmp	x7, #0x200
    40204454:	54000542 	b.cs	402044fc <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x650>  // b.hs, b.nlast
    40204458:	f0000077 	adrp	x23, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    4020445c:	912d62f7 	add	x23, x23, #0xb58
    40204460:	910004f9 	add	x25, x7, #0x1
    40204464:	f9002ef9 	str	x25, [x23, #88]
    40204468:	f90002e7 	str	x7, [x23]
    4020446c:	52802817 	mov	w23, #0x140                 	// #320
    40204470:	d503201f 	nop
    40204474:	100a75b9 	adr	x25, 40219328 <_ZN11jnox_kernel10native_el09extension4ROWS17h71366c1b688cc4d8E.llvm.8080503781627406991>
    40204478:	9b1764e7 	madd	x7, x7, x23, x25
    4020447c:	a90008e1 	stp	x1, x2, [x7]
    40204480:	a90158f8 	stp	x24, x22, [x7, #16]
    40204484:	a90218e4 	stp	x4, x6, [x7, #32]
    40204488:	a90314fd 	stp	x29, x5, [x7, #48]
    4020448c:	a90450fb 	stp	x27, x20, [x7, #64]
    40204490:	f90028e8 	str	x8, [x7, #80]
    40204494:	f94037e8 	ldr	x8, [sp, #104]
    40204498:	a905c8e8 	stp	x8, x18, [x7, #88]
    4020449c:	f9402be8 	ldr	x8, [sp, #80]
    402044a0:	a906f8e8 	stp	x8, x30, [x7, #104]
    402044a4:	f94027e8 	ldr	x8, [sp, #72]
    402044a8:	a907a0f1 	stp	x17, x8, [x7, #120]
    402044ac:	f9401fe8 	ldr	x8, [sp, #56]
    402044b0:	f90044e8 	str	x8, [x7, #136]
    402044b4:	f9403fe8 	ldr	x8, [sp, #120]
    402044b8:	f90048e8 	str	x8, [x7, #144]
    402044bc:	f94023e8 	ldr	x8, [sp, #64]
    402044c0:	a909bce8 	stp	x8, x15, [x7, #152]
    402044c4:	f9403be8 	ldr	x8, [sp, #112]
    402044c8:	a90aa0eb 	stp	x11, x8, [x7, #168]
    402044cc:	a90bb4f5 	stp	x21, x13, [x7, #184]
    402044d0:	a945a3eb 	ldp	x11, x8, [sp, #88]
    402044d4:	a90ca0eb 	stp	x11, x8, [x7, #200]
    402044d8:	a90da8e9 	stp	x9, x10, [x7, #216]
    402044dc:	a90efcec 	stp	x12, xzr, [x7, #232]
    402044e0:	a91140ee 	stp	x14, x16, [x7, #272]
    402044e4:	a9124ce0 	stp	x0, x19, [x7, #288]
    402044e8:	a91368fc 	stp	x28, x26, [x7, #304]
    402044ec:	a9100cff 	stp	xzr, x3, [x7, #256]
    402044f0:	f9007cff 	str	xzr, [x7, #248]
    402044f4:	52800028 	mov	w8, #0x1                   	// #1
    402044f8:	14000007 	b	40204514 <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991+0x668>
    402044fc:	aa1f03e8 	mov	x8, xzr
    40204500:	f0000069 	adrp	x9, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204504:	f945dd2a 	ldr	x10, [x9, #3000]
    40204508:	b100054a 	adds	x10, x10, #0x1
    4020450c:	da9f314a 	csinv	x10, x10, xzr, cc  // cc = lo, ul, last
    40204510:	f905dd2a 	str	x10, [x9, #3000]
    40204514:	f0000069 	adrp	x9, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204518:	912d4129 	add	x9, x9, #0xb50
    4020451c:	f9000128 	str	x8, [x9]
    40204520:	f9401d20 	ldr	x0, [x9, #56]
    40204524:	a9574ff4 	ldp	x20, x19, [sp, #368]
    40204528:	a95657f6 	ldp	x22, x21, [sp, #352]
    4020452c:	a9555ff8 	ldp	x24, x23, [sp, #336]
    40204530:	a95467fa 	ldp	x26, x25, [sp, #320]
    40204534:	a9536ffc 	ldp	x28, x27, [sp, #304]
    40204538:	a9527bfd 	ldp	x29, x30, [sp, #288]
    4020453c:	910603ff 	add	sp, sp, #0x180
    40204540:	d65f03c0 	ret
    40204544:	52800340 	mov	w0, #0x1a                  	// #26
    40204548:	97fff72f 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    4020454c:	d503201f 	nop
    40204550:	1006fd42 	adr	x2, 402124f8 <anon.09c3d38f9b7290fd63a7fa379a74bb58.1.llvm.8080503781627406991+0x60>
    40204554:	aa1403e0 	mov	x0, x20
    40204558:	52800061 	mov	w1, #0x3                   	// #3
    4020455c:	94000519 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40204560:	d503201f 	nop
    40204564:	1006fd60 	adr	x0, 40212510 <anon.09c3d38f9b7290fd63a7fa379a74bb58.1.llvm.8080503781627406991+0x78>
    40204568:	9400081a 	bl	402065d0 <_RNvNtNtCsbcsGJ9IzBgZ_4core9panicking11panic_const23panic_const_div_by_zero>
    4020456c:	97fffdf3 	bl	40203d38 <_ZN11jnox_kernel10native_el09extension5start28_$u7b$$u7b$closure$u7d$$u7d$17h8c5e8e8762c22bbfE>

0000000040204570 <_ZN11jnox_kernel10native_el09extension7Runtime3arm17h82d6de6888983821E>:
    40204570:	d503201f 	nop
    40204574:	1007a269 	adr	x9, 402139c0 <_ZN11jnox_kernel10native_el09extension5STATE17heea3f949cf12c2d5E.llvm.8080503781627406991>
    40204578:	f9400128 	ldr	x8, [x9]
    4020457c:	3945612a 	ldrb	w10, [x9, #344]
    40204580:	7100015f 	cmp	w10, #0x0
    40204584:	5280380a 	mov	w10, #0x1c0                 	// #448
    40204588:	5280290b 	mov	w11, #0x148                 	// #328
    4020458c:	9a8a116a 	csel	x10, x11, x10, ne  // ne = any
    40204590:	f100011f 	cmp	x8, #0x0
    40204594:	52803508 	mov	w8, #0x1a8                 	// #424
    40204598:	9a8a0108 	csel	x8, x8, x10, eq  // eq = none
    4020459c:	f8686928 	ldr	x8, [x9, x8]
    402045a0:	9105a129 	add	x9, x9, #0x168
    402045a4:	5280060b 	mov	w11, #0x30                  	// #48
    402045a8:	b400026b 	cbz	x11, 402045f4 <_ZN11jnox_kernel10native_el09extension7Runtime3arm17h82d6de6888983821E+0x84>
    402045ac:	f85f812a 	ldur	x10, [x9, #-8]
    402045b0:	91004129 	add	x9, x9, #0x10
    402045b4:	d100416b 	sub	x11, x11, #0x10
    402045b8:	f100055f 	cmp	x10, #0x1
    402045bc:	54ffff61 	b.ne	402045a8 <_ZN11jnox_kernel10native_el09extension7Runtime3arm17h82d6de6888983821E+0x38>  // b.any
    402045c0:	f85f012a 	ldur	x10, [x9, #-16]
    402045c4:	b400014b 	cbz	x11, 402045ec <_ZN11jnox_kernel10native_el09extension7Runtime3arm17h82d6de6888983821E+0x7c>
    402045c8:	d344fd6b 	lsr	x11, x11, #4
    402045cc:	b85f812c 	ldur	w12, [x9, #-8]
    402045d0:	f841052d 	ldr	x13, [x9], #16
    402045d4:	eb0d015f 	cmp	x10, x13
    402045d8:	9a8d314d 	csel	x13, x10, x13, cc  // cc = lo, ul, last
    402045dc:	7100019f 	cmp	w12, #0x0
    402045e0:	9a8a11aa 	csel	x10, x13, x10, ne  // ne = any
    402045e4:	f100056b 	subs	x11, x11, #0x1
    402045e8:	54ffff21 	b.ne	402045cc <_ZN11jnox_kernel10native_el09extension7Runtime3arm17h82d6de6888983821E+0x5c>  // b.any
    402045ec:	eb0a011f 	cmp	x8, x10
    402045f0:	9a8a3108 	csel	x8, x8, x10, cc  // cc = lo, ul, last
    402045f4:	f0000069 	adrp	x9, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402045f8:	912e0129 	add	x9, x9, #0xb80
    402045fc:	f9000928 	str	x8, [x9, #16]
    40204600:	5280002a 	mov	w10, #0x1                   	// #1
    40204604:	d51be248 	msr	cntp_cval_el0, x8
    40204608:	d51be22a 	msr	cntp_ctl_el0, x10
    4020460c:	d5033fdf 	isb
    40204610:	a9402129 	ldp	x9, x8, [x9]
    40204614:	f1000d1f 	cmp	x8, #0x3
    40204618:	da9f3128 	csinv	x8, x9, xzr, cc  // cc = lo, ul, last
    4020461c:	f0000069 	adrp	x9, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204620:	f905e528 	str	x8, [x9, #3016]
    40204624:	d65f03c0 	ret

0000000040204628 <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E>:
    40204628:	f81d0ffe 	str	x30, [sp, #-48]!
    4020462c:	a90157f6 	stp	x22, x21, [sp, #16]
    40204630:	a9024ff4 	stp	x20, x19, [sp, #32]
    40204634:	aa0103f3 	mov	x19, x1
    40204638:	aa0003f4 	mov	x20, x0
    4020463c:	97fffce1 	bl	402039c0 <_ZN11jnox_kernel10native_el09extension12before_event17h2ab7ca7e436978d9E.llvm.8080503781627406991>
    40204640:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204644:	f944e108 	ldr	x8, [x8, #2496]
    40204648:	f100091f 	cmp	x8, #0x2
    4020464c:	54000900 	b.eq	4020476c <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0x144>  // b.none
    40204650:	b0000088 	adrp	x8, 40215000 <jnox_native_el0_journal+0x1e0>
    40204654:	f9418908 	ldr	x8, [x8, #784]
    40204658:	f100091f 	cmp	x8, #0x2
    4020465c:	54000888 	b.hi	4020476c <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0x144>  // b.pmore
    40204660:	f0000069 	adrp	x9, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204664:	f945c529 	ldr	x9, [x9, #2952]
    40204668:	eb08013f 	cmp	x9, x8
    4020466c:	54000801 	b.ne	4020476c <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0x144>  // b.any
    40204670:	f9402275 	ldr	x21, [x19, #64]
    40204674:	f9400276 	ldr	x22, [x19]
    40204678:	f1001abf 	cmp	x21, #0x6
    4020467c:	5400014c 	b.gt	402046a4 <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0x7c>
    40204680:	f10006bf 	cmp	x21, #0x1
    40204684:	540002c0 	b.eq	402046dc <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0xb4>  // b.none
    40204688:	f1001abf 	cmp	x21, #0x6
    4020468c:	540001a1 	b.ne	402046c0 <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0x98>  // b.any
    40204690:	f9400661 	ldr	x1, [x19, #8]
    40204694:	aa1603e0 	mov	x0, x22
    40204698:	aa1403e2 	mov	x2, x20
    4020469c:	97fff42d 	bl	40201750 <_ZN11jnox_kernel10native_el013clock_gettime17h342113c96274c170E>
    402046a0:	1400001a 	b	40204708 <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0xe0>
    402046a4:	f1001ebf 	cmp	x21, #0x7
    402046a8:	54000260 	b.eq	402046f4 <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0xcc>  // b.none
    402046ac:	f10022bf 	cmp	x21, #0x8
    402046b0:	54000081 	b.ne	402046c0 <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0x98>  // b.any
    402046b4:	aa1f03e0 	mov	x0, xzr
    402046b8:	52800025 	mov	w5, #0x1                   	// #1
    402046bc:	14000014 	b	4020470c <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0xe4>
    402046c0:	aa1f03e5 	mov	x5, xzr
    402046c4:	d10026a8 	sub	x8, x21, #0x9
    402046c8:	f100291f 	cmp	x8, #0xa
    402046cc:	928004a8 	mov	x8, #0xffffffffffffffda    	// #-38
    402046d0:	92800bc9 	mov	x9, #0xffffffffffffffa1    	// #-95
    402046d4:	9a883120 	csel	x0, x9, x8, cc  // cc = lo, ul, last
    402046d8:	1400000d 	b	4020470c <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0xe4>
    402046dc:	d503201f 	nop
    402046e0:	10086109 	adr	x9, 40215300 <_ZN11jnox_kernel10native_el011EXIT_STATUS17h849302c83dc4275cE>
    402046e4:	b8287936 	str	w22, [x9, x8, lsl #2]
    402046e8:	52800065 	mov	w5, #0x3                   	// #3
    402046ec:	aa1603e0 	mov	x0, x22
    402046f0:	14000007 	b	4020470c <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0xe4>
    402046f4:	aa1303e0 	mov	x0, x19
    402046f8:	97fff3d0 	bl	40201638 <_ZN11jnox_kernel10native_el011sleep_until17h08dff723cb069a7fE>
    402046fc:	aa0003e8 	mov	x8, x0
    40204700:	aa0103e0 	mov	x0, x1
    40204704:	360001c8 	tbz	w8, #0, 4020473c <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0x114>
    40204708:	aa1f03e5 	mov	x5, xzr
    4020470c:	f9000260 	str	x0, [x19]
    40204710:	aa1403e0 	mov	x0, x20
    40204714:	52800041 	mov	w1, #0x2                   	// #2
    40204718:	aa1503e2 	mov	x2, x21
    4020471c:	aa1603e3 	mov	x3, x22
    40204720:	aa1303e4 	mov	x4, x19
    40204724:	97fffde2 	bl	40203eac <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991>
    40204728:	aa1303e1 	mov	x1, x19
    4020472c:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40204730:	a94157f6 	ldp	x22, x21, [sp, #16]
    40204734:	f84307fe 	ldr	x30, [sp], #48
    40204738:	1400000f 	b	40204774 <_ZN11jnox_kernel10native_el09extension8transfer17h0067d96f2f3d3251E.llvm.8080503781627406991>
    4020473c:	eb140008 	subs	x8, x0, x20
    40204740:	9a8833e8 	csel	x8, xzr, x8, cc  // cc = lo, ul, last
    40204744:	b7f800e8 	tbnz	x8, #63, 40204760 <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0x138>
    40204748:	eb14001f 	cmp	x0, x20
    4020474c:	52800048 	mov	w8, #0x2                   	// #2
    40204750:	9a9f8105 	csel	x5, x8, xzr, hi  // hi = pmore
    40204754:	aa0003e6 	mov	x6, x0
    40204758:	aa1f03e0 	mov	x0, xzr
    4020475c:	17ffffec 	b	4020470c <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0xe4>
    40204760:	aa1f03e5 	mov	x5, xzr
    40204764:	92800940 	mov	x0, #0xffffffffffffffb5    	// #-75
    40204768:	17ffffe9 	b	4020470c <_ZN11jnox_kernel10native_el09extension7syscall17ha666edcaacd5c174E+0xe4>
    4020476c:	52800340 	mov	w0, #0x1a                  	// #26
    40204770:	97fff6a5 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>

0000000040204774 <_ZN11jnox_kernel10native_el09extension8transfer17h0067d96f2f3d3251E.llvm.8080503781627406991>:
    40204774:	a9bf4ffe 	stp	x30, x19, [sp, #-16]!
    40204778:	aa0103f3 	mov	x19, x1
    4020477c:	f1000c1f 	cmp	x0, #0x3
    40204780:	54000080 	b.eq	40204790 <_ZN11jnox_kernel10native_el09extension8transfer17h0067d96f2f3d3251E.llvm.8080503781627406991+0x1c>  // b.none
    40204784:	f100101f 	cmp	x0, #0x4
    40204788:	540002c1 	b.ne	402047e0 <_ZN11jnox_kernel10native_el09extension8transfer17h0067d96f2f3d3251E.llvm.8080503781627406991+0x6c>  // b.any
    4020478c:	97fffd6e 	bl	40203d44 <_ZN11jnox_kernel10native_el09extension6finish17hd905cea193690701E.llvm.8080503781627406991>
    40204790:	b0000088 	adrp	x8, 40215000 <jnox_native_el0_journal+0x1e0>
    40204794:	f9418900 	ldr	x0, [x8, #784]
    40204798:	f100081f 	cmp	x0, #0x2
    4020479c:	54000288 	b.hi	402047ec <_ZN11jnox_kernel10native_el09extension8transfer17h0067d96f2f3d3251E.llvm.8080503781627406991+0x78>  // b.pmore
    402047a0:	52806808 	mov	w8, #0x340                 	// #832
    402047a4:	d503201f 	nop
    402047a8:	100742c9 	adr	x9, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402047ac:	9b082400 	madd	x0, x0, x8, x9
    402047b0:	aa1303e1 	mov	x1, x19
    402047b4:	52806802 	mov	w2, #0x340                 	// #832
    402047b8:	940008e1 	bl	40206b3c <memcpy>
    402047bc:	b00000a0 	adrp	x0, 40219000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3ce0>
    402047c0:	910c8000 	add	x0, x0, #0x320
    402047c4:	97fff32b 	bl	40201470 <native_sleep_switch>
    402047c8:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402047cc:	f944e108 	ldr	x8, [x8, #2496]
    402047d0:	f100091f 	cmp	x8, #0x2
    402047d4:	54000140 	b.eq	402047fc <_ZN11jnox_kernel10native_el09extension8transfer17h0067d96f2f3d3251E.llvm.8080503781627406991+0x88>  // b.none
    402047d8:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402047dc:	f945c500 	ldr	x0, [x8, #2952]
    402047e0:	aa1303e1 	mov	x1, x19
    402047e4:	a8c14ffe 	ldp	x30, x19, [sp], #16
    402047e8:	17fff6f6 	b	402023c0 <_ZN11jnox_kernel10native_el08activate17hc945b2c295390421E>
    402047ec:	d503201f 	nop
    402047f0:	1006ea82 	adr	x2, 40212540 <anon.09c3d38f9b7290fd63a7fa379a74bb58.14.llvm.8080503781627406991>
    402047f4:	52800061 	mov	w1, #0x3                   	// #3
    402047f8:	94000472 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    402047fc:	52800340 	mov	w0, #0x1a                  	// #26
    40204800:	97fff681 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>

0000000040204804 <native_cyclic_idle_sample>:
    40204804:	f81f0ffe 	str	x30, [sp, #-16]!
    40204808:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    4020480c:	f944e108 	ldr	x8, [x8, #2496]
    40204810:	f100091f 	cmp	x8, #0x2
    40204814:	54000200 	b.eq	40204854 <native_cyclic_idle_sample+0x50>  // b.none
    40204818:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    4020481c:	f945a908 	ldr	x8, [x8, #2896]
    40204820:	f100051f 	cmp	x8, #0x1
    40204824:	54000141 	b.ne	4020484c <native_cyclic_idle_sample+0x48>  // b.any
    40204828:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    4020482c:	f945ad08 	ldr	x8, [x8, #2904]
    40204830:	f107fd1f 	cmp	x8, #0x1ff
    40204834:	54000148 	b.hi	4020485c <native_cyclic_idle_sample+0x58>  // b.pmore
    40204838:	d503201f 	nop
    4020483c:	100a5769 	adr	x9, 40219328 <_ZN11jnox_kernel10native_el09extension4ROWS17h71366c1b688cc4d8E.llvm.8080503781627406991>
    40204840:	5280280a 	mov	w10, #0x140                 	// #320
    40204844:	9b0a2508 	madd	x8, x8, x10, x9
    40204848:	f9008100 	str	x0, [x8, #256]
    4020484c:	f84107fe 	ldr	x30, [sp], #16
    40204850:	d65f03c0 	ret
    40204854:	52800340 	mov	w0, #0x1a                  	// #26
    40204858:	97fff66b 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    4020485c:	d503201f 	nop
    40204860:	1006e7c2 	adr	x2, 40212558 <anon.09c3d38f9b7290fd63a7fa379a74bb58.14.llvm.8080503781627406991+0x18>
    40204864:	aa0803e0 	mov	x0, x8
    40204868:	52804001 	mov	w1, #0x200                 	// #512
    4020486c:	94000455 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040204870 <native_cyclic_return>:
    40204870:	f81f0ffe 	str	x30, [sp, #-16]!
    40204874:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204878:	f944e108 	ldr	x8, [x8, #2496]
    4020487c:	f100091f 	cmp	x8, #0x2
    40204880:	54000220 	b.eq	402048c4 <native_cyclic_return+0x54>  // b.none
    40204884:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204888:	f945a908 	ldr	x8, [x8, #2896]
    4020488c:	f100051f 	cmp	x8, #0x1
    40204890:	54000161 	b.ne	402048bc <native_cyclic_return+0x4c>  // b.any
    40204894:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204898:	f945ad00 	ldr	x0, [x8, #2904]
    4020489c:	d5382008 	mrs	x8, ttbr0_el1
    402048a0:	f107fc1f 	cmp	x0, #0x1ff
    402048a4:	54000148 	b.hi	402048cc <native_cyclic_return+0x5c>  // b.pmore
    402048a8:	d503201f 	nop
    402048ac:	100a53e9 	adr	x9, 40219328 <_ZN11jnox_kernel10native_el09extension4ROWS17h71366c1b688cc4d8E.llvm.8080503781627406991>
    402048b0:	5280280a 	mov	w10, #0x140                 	// #320
    402048b4:	9b0a2409 	madd	x9, x0, x10, x9
    402048b8:	f9007928 	str	x8, [x9, #240]
    402048bc:	f84107fe 	ldr	x30, [sp], #16
    402048c0:	d65f03c0 	ret
    402048c4:	52800340 	mov	w0, #0x1a                  	// #26
    402048c8:	97fff64f 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    402048cc:	d503201f 	nop
    402048d0:	1006e502 	adr	x2, 40212570 <anon.09c3d38f9b7290fd63a7fa379a74bb58.14.llvm.8080503781627406991+0x30>
    402048d4:	52804001 	mov	w1, #0x200                 	// #512
    402048d8:	9400043a 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

00000000402048dc <native_extension_evaluate>:
    402048dc:	f81c0ffd 	str	x29, [sp, #-64]!
    402048e0:	a9015ffe 	stp	x30, x23, [sp, #16]
    402048e4:	a90257f6 	stp	x22, x21, [sp, #32]
    402048e8:	a9034ff4 	stp	x20, x19, [sp, #48]
    402048ec:	d10783ff 	sub	sp, sp, #0x1e0
    402048f0:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    402048f4:	f944e108 	ldr	x8, [x8, #2496]
    402048f8:	f100091f 	cmp	x8, #0x2
    402048fc:	54000b20 	b.eq	40204a60 <jnox_native_extension_stop_resume+0x90>  // b.none
    40204900:	f0000069 	adrp	x9, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204904:	91274129 	add	x9, x9, #0x9d0
    40204908:	3945212a 	ldrb	w10, [x9, #328]
    4020490c:	f9400129 	ldr	x9, [x9]
    40204910:	7100055f 	cmp	w10, #0x1
    40204914:	fa420920 	ccmp	x9, #0x2, #0x0, eq  // eq = none
    40204918:	54000a41 	b.ne	40204a60 <jnox_native_extension_stop_resume+0x90>  // b.any
    4020491c:	f100051f 	cmp	x8, #0x1
    40204920:	54000a01 	b.ne	40204a60 <jnox_native_extension_stop_resume+0x90>  // b.any
    40204924:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204928:	f9458916 	ldr	x22, [x8, #2832]
    4020492c:	b10006df 	cmn	x22, #0x1
    40204930:	54000980 	b.eq	40204a60 <jnox_native_extension_stop_resume+0x90>  // b.none
    40204934:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204938:	f944e513 	ldr	x19, [x8, #2504]
    4020493c:	910543e8 	add	x8, sp, #0x150
    40204940:	f0000074 	adrp	x20, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204944:	9129e294 	add	x20, x20, #0xa78
    40204948:	91011d00 	add	x0, x8, #0x47
    4020494c:	91012281 	add	x1, x20, #0x48
    40204950:	52800902 	mov	w2, #0x48                  	// #72
    40204954:	9400087a 	bl	40206b3c <memcpy>
    40204958:	38401697 	ldrb	w23, [x20], #1
    4020495c:	910543e0 	add	x0, sp, #0x150
    40204960:	aa1403e1 	mov	x1, x20
    40204964:	528008e2 	mov	w2, #0x47                  	// #71
    40204968:	94000875 	bl	40206b3c <memcpy>
    4020496c:	71000aff 	cmp	w23, #0x2
    40204970:	54000780 	b.eq	40204a60 <jnox_native_extension_stop_resume+0x90>  // b.none
    40204974:	d503201f 	nop
    40204978:	10078255 	adr	x21, 402139c0 <_ZN11jnox_kernel10native_el09extension5STATE17heea3f949cf12c2d5E.llvm.8080503781627406991>
    4020497c:	a94a26a8 	ldp	x8, x9, [x21, #160]
    40204980:	a900a7e8 	stp	x8, x9, [sp, #8]
    40204984:	f9405aa8 	ldr	x8, [x21, #176]
    40204988:	f9000fe8 	str	x8, [sp, #24]
    4020498c:	910006d4 	add	x20, x22, #0x1
    40204990:	390083f7 	strb	w23, [sp, #32]
    40204994:	910023f6 	add	x22, sp, #0x8
    40204998:	910066c0 	add	x0, x22, #0x19
    4020499c:	910543e1 	add	x1, sp, #0x150
    402049a0:	528011e2 	mov	w2, #0x8f                  	// #143
    402049a4:	94000866 	bl	40206b3c <memcpy>
    402049a8:	a90b53f3 	stp	x19, x20, [sp, #176]
    402049ac:	d50342ff 	msr	daifclr, #0x2
    402049b0:	d5033fdf 	isb

00000000402049b4 <jnox_native_extension_stop_hook>:
    402049b4:	1006d6b0 	adr	x16, 40212488 <jnox_native_extension_stop_cells>
    402049b8:	a9404610 	ldp	x16, x17, [x16]
    402049bc:	ca130210 	eor	x16, x16, x19
    402049c0:	b4000070 	cbz	x16, 402049cc <jnox_native_extension_stop_loop>
    402049c4:	ca130231 	eor	x17, x17, x19
    402049c8:	b5000051 	cbnz	x17, 402049d0 <jnox_native_extension_stop_resume>

00000000402049cc <jnox_native_extension_stop_loop>:
    402049cc:	14000000 	b	402049cc <jnox_native_extension_stop_loop>

00000000402049d0 <jnox_native_extension_stop_resume>:
    402049d0:	d503201f 	nop
    402049d4:	1006dda6 	adr	x6, 40212588 <anon.09c3d38f9b7290fd63a7fa379a74bb58.14.llvm.8080503781627406991+0x48>
    402049d8:	528000a8 	mov	w8, #0x5                   	// #5
    402049dc:	910303f7 	add	x23, sp, #0xc0
    402049e0:	390003e8 	strb	w8, [sp]
    402049e4:	910303e8 	add	x8, sp, #0xc0
    402049e8:	910182c0 	add	x0, x22, #0x60
    402049ec:	910023e3 	add	x3, sp, #0x8
    402049f0:	aa1303e1 	mov	x1, x19
    402049f4:	aa1403e2 	mov	x2, x20
    402049f8:	52800024 	mov	w4, #0x1                   	// #1
    402049fc:	52800025 	mov	w5, #0x1                   	// #1
    40204a00:	52800067 	mov	w7, #0x3                   	// #3
    40204a04:	97fff813 	bl	40202a50 <_ZN11jnox_kernel10native_el016extension_policy18Extension$LT$_$GT$6decide17h818f379aa4d8bc32E>
    40204a08:	9100c2e0 	add	x0, x23, #0x30
    40204a0c:	910182c1 	add	x1, x22, #0x60
    40204a10:	52800902 	mov	w2, #0x48                  	// #72
    40204a14:	9400084a 	bl	40206b3c <memcpy>
    40204a18:	a94b27e8 	ldp	x8, x9, [sp, #176]
    40204a1c:	a913a7e8 	stp	x8, x9, [sp, #312]
    40204a20:	f900a7ff 	str	xzr, [sp, #328]
    40204a24:	d50342df 	msr	daifset, #0x2
    40204a28:	d5033fdf 	isb
    40204a2c:	f94002a8 	ldr	x8, [x21]
    40204a30:	f100091f 	cmp	x8, #0x2
    40204a34:	54000160 	b.eq	40204a60 <jnox_native_extension_stop_resume+0x90>  // b.none
    40204a38:	d503201f 	nop
    40204a3c:	10077c20 	adr	x0, 402139c0 <_ZN11jnox_kernel10native_el09extension5STATE17heea3f949cf12c2d5E.llvm.8080503781627406991>
    40204a40:	910303e1 	add	x1, sp, #0xc0
    40204a44:	97fff9f7 	bl	40203220 <_ZN11jnox_kernel10native_el09extension11transaction11Transaction7publish17h5849a25ba1e7d5dcE>
    40204a48:	910783ff 	add	sp, sp, #0x1e0
    40204a4c:	a9434ff4 	ldp	x20, x19, [sp, #48]
    40204a50:	a94257f6 	ldp	x22, x21, [sp, #32]
    40204a54:	a9415ffe 	ldp	x30, x23, [sp, #16]
    40204a58:	f84407fd 	ldr	x29, [sp], #64
    40204a5c:	d65f03c0 	ret
    40204a60:	52800340 	mov	w0, #0x1a                  	// #26
    40204a64:	97fff5e8 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>

0000000040204a68 <native_extension_stack_if_pending>:
    40204a68:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204a6c:	f944e108 	ldr	x8, [x8, #2496]
    40204a70:	f100091f 	cmp	x8, #0x2
    40204a74:	54000260 	b.eq	40204ac0 <native_extension_stack_if_pending+0x58>  // b.none
    40204a78:	f0000068 	adrp	x8, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204a7c:	91274108 	add	x8, x8, #0x9d0
    40204a80:	39452109 	ldrb	w9, [x8, #328]
    40204a84:	f9400108 	ldr	x8, [x8]
    40204a88:	7100053f 	cmp	w9, #0x1
    40204a8c:	fa420900 	ccmp	x8, #0x2, #0x0, eq  // eq = none
    40204a90:	54000060 	b.eq	40204a9c <native_extension_stack_if_pending+0x34>  // b.none
    40204a94:	aa1f03e0 	mov	x0, xzr
    40204a98:	d65f03c0 	ret
    40204a9c:	d5033fdf 	isb
    40204aa0:	d53be028 	mrs	x8, cntpct_el0
    40204aa4:	f0000069 	adrp	x9, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204aa8:	b000020a 	adrp	x10, 40245000 <_ZN11jnox_kernel10native_el09extension9EVALUATOR17h2aebd11a2f23ffadE+0x3cd0>
    40204aac:	910cc14a 	add	x10, x10, #0x330
    40204ab0:	f9458529 	ldr	x9, [x9, #2824]
    40204ab4:	eb09011f 	cmp	x8, x9
    40204ab8:	9a9f3140 	csel	x0, x10, xzr, cc  // cc = lo, ul, last
    40204abc:	d65f03c0 	ret
    40204ac0:	f81f0ffe 	str	x30, [sp, #-16]!
    40204ac4:	52800340 	mov	w0, #0x1a                  	// #26
    40204ac8:	97fff5cf 	bl	40202204 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>

0000000040204acc <native_server_reselect>:
    40204acc:	f81e0ffe 	str	x30, [sp, #-32]!
    40204ad0:	a9014ff4 	stp	x20, x19, [sp, #16]
    40204ad4:	aa0103f3 	mov	x19, x1
    40204ad8:	aa0003f4 	mov	x20, x0
    40204adc:	97fffbb9 	bl	402039c0 <_ZN11jnox_kernel10native_el09extension12before_event17h2ab7ca7e436978d9E.llvm.8080503781627406991>
    40204ae0:	aa1403e0 	mov	x0, x20
    40204ae4:	52800061 	mov	w1, #0x3                   	// #3
    40204ae8:	aa1f03e2 	mov	x2, xzr
    40204aec:	aa1f03e3 	mov	x3, xzr
    40204af0:	aa1303e4 	mov	x4, x19
    40204af4:	52800025 	mov	w5, #0x1                   	// #1
    40204af8:	97fffced 	bl	40203eac <_ZN11jnox_kernel10native_el09extension6settle17hb6822634c6589f2dE.llvm.8080503781627406991>
    40204afc:	aa0003f4 	mov	x20, x0
    40204b00:	b4000093 	cbz	x19, 40204b10 <native_server_reselect+0x44>
    40204b04:	aa1403e0 	mov	x0, x20
    40204b08:	aa1303e1 	mov	x1, x19
    40204b0c:	97ffff1a 	bl	40204774 <_ZN11jnox_kernel10native_el09extension8transfer17h0067d96f2f3d3251E.llvm.8080503781627406991>
    40204b10:	f1000e9f 	cmp	x20, #0x3
    40204b14:	1a9f27e0 	cset	w0, cc  // cc = lo, ul, last
    40204b18:	a9414ff4 	ldp	x20, x19, [sp, #16]
    40204b1c:	f84207fe 	ldr	x30, [sp], #32
    40204b20:	d65f03c0 	ret

0000000040204b24 <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE>:
    40204b24:	a9be57fe 	stp	x30, x21, [sp, #-32]!
    40204b28:	a9014ff4 	stp	x20, x19, [sp, #16]
    40204b2c:	2a0203f4 	mov	w20, w2
    40204b30:	aa0103f3 	mov	x19, x1
    40204b34:	aa0003f5 	mov	x21, x0
    40204b38:	9400025e 	bl	402054b0 <_ZN11jnox_kernel14native_el0_mmu8space_id17h8fc6c24822472ecbE.llvm.14263334612035470596>
    40204b3c:	f100041f 	cmp	x0, #0x1
    40204b40:	54000521 	b.ne	40204be4 <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE+0xc0>  // b.any
    40204b44:	f1000abf 	cmp	x21, #0x2
    40204b48:	540005e8 	b.hi	40204c04 <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE+0xe0>  // b.pmore
    40204b4c:	528a0008 	mov	w8, #0x5000                	// #20480
    40204b50:	72a00828 	movk	w8, #0x41, lsl #16
    40204b54:	d503201f 	nop
    40204b58:	102e2549 	adr	x9, 40261000 <_ZN11jnox_kernel14native_el0_mmu6SPACES17h746e7fcfb4f25aceE.llvm.14263334612035470596>
    40204b5c:	9b0826a8 	madd	x8, x21, x8, x9
    40204b60:	926aa669 	and	x9, x19, #0xffffffffffc00000
    40204b64:	f150013f 	cmp	x9, #0x400, lsl #12
    40204b68:	54000101 	b.ne	40204b88 <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE+0x64>  // b.any
    40204b6c:	d1500269 	sub	x9, x19, #0x400, lsl #12
    40204b70:	d355fd29 	lsr	x9, x9, #21
    40204b74:	8b093109 	add	x9, x8, x9, lsl #12
    40204b78:	9140092b 	add	x11, x9, #0x2, lsl #12
    40204b7c:	52a00809 	mov	w9, #0x400000              	// #4194304
    40204b80:	528a000a 	mov	w10, #0x5000                	// #20480
    40204b84:	1400000a 	b	40204bac <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE+0x88>
    40204b88:	9281ffe9 	mov	x9, #0xfffffffffffff000    	// #-4096
    40204b8c:	f2bfdfe9 	movk	x9, #0xfeff, lsl #16
    40204b90:	8b090269 	add	x9, x19, x9
    40204b94:	d350fd29 	lsr	x9, x9, #16
    40204b98:	b5000269 	cbnz	x9, 40204be4 <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE+0xc0>
    40204b9c:	9140110b 	add	x11, x8, #0x4, lsl #12
    40204ba0:	52a00029 	mov	w9, #0x10000               	// #65536
    40204ba4:	528a000a 	mov	w10, #0x5000                	// #20480
    40204ba8:	72a0080a 	movk	w10, #0x40, lsl #16
    40204bac:	d34c526c 	ubfx	x12, x19, #12, #9
    40204bb0:	f86c796b 	ldr	x11, [x11, x12, lsl #3]
    40204bb4:	2a2b03ec 	mvn	w12, w11
    40204bb8:	5281886d 	mov	w13, #0xc43                 	// #3139
    40204bbc:	ea0d019f 	tst	x12, x13
    40204bc0:	54000121 	b.ne	40204be4 <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE+0xc0>  // b.any
    40204bc4:	34000054 	cbz	w20, 40204bcc <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE+0xa8>
    40204bc8:	373800eb 	tbnz	w11, #7, 40204be4 <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE+0xc0>
    40204bcc:	8b0a010a 	add	x10, x8, x10
    40204bd0:	92744d68 	and	x8, x11, #0xfffff000
    40204bd4:	8b0a0129 	add	x9, x9, x10
    40204bd8:	eb0a011f 	cmp	x8, x10
    40204bdc:	fa492102 	ccmp	x8, x9, #0x2, cs  // cs = hs, nlast
    40204be0:	540000a3 	b.cc	40204bf4 <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE+0xd0>  // b.lo, b.ul, b.last
    40204be4:	aa1f03e0 	mov	x0, xzr
    40204be8:	a9414ff4 	ldp	x20, x19, [sp, #16]
    40204bec:	a8c257fe 	ldp	x30, x21, [sp], #32
    40204bf0:	d65f03c0 	ret
    40204bf4:	92402e69 	and	x9, x19, #0xfff
    40204bf8:	aa090101 	orr	x1, x8, x9
    40204bfc:	52800020 	mov	w0, #0x1                   	// #1
    40204c00:	17fffffa 	b	40204be8 <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE+0xc4>
    40204c04:	d503201f 	nop
    40204c08:	1006cfc2 	adr	x2, 40212600 <anon.2d7ce5cf085ee3b477e141eaed062738.1.llvm.14263334612035470596>
    40204c0c:	aa1503e0 	mov	x0, x21
    40204c10:	52800061 	mov	w1, #0x3                   	// #3
    40204c14:	9400036b 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040204c18 <_ZN11jnox_kernel14native_el0_mmu12copy_to_user17h9f6ee0e2a7c35599E>:
    40204c18:	f81d0ffe 	str	x30, [sp, #-48]!
    40204c1c:	a90157f6 	stp	x22, x21, [sp, #16]
    40204c20:	a9024ff4 	stp	x20, x19, [sp, #32]
    40204c24:	aa0203f3 	mov	x19, x2
    40204c28:	aa0103f4 	mov	x20, x1
    40204c2c:	aa0003f5 	mov	x21, x0
    40204c30:	940001ac 	bl	402052e0 <_ZN11jnox_kernel14native_el0_mmu6active17hd686f5b0e91753c5E.llvm.14263334612035470596>
    40204c34:	f100041f 	cmp	x0, #0x1
    40204c38:	540002a1 	b.ne	40204c8c <_ZN11jnox_kernel14native_el0_mmu12copy_to_user17h9f6ee0e2a7c35599E+0x74>  // b.any
    40204c3c:	aa0103f6 	mov	x22, x1
    40204c40:	aa0103e0 	mov	x0, x1
    40204c44:	aa1503e1 	mov	x1, x21
    40204c48:	aa1303e2 	mov	x2, x19
    40204c4c:	52800023 	mov	w3, #0x1                   	// #1
    40204c50:	940001e7 	bl	402053ec <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596>
    40204c54:	340001e0 	cbz	w0, 40204c90 <_ZN11jnox_kernel14native_el0_mmu12copy_to_user17h9f6ee0e2a7c35599E+0x78>
    40204c58:	b4000173 	cbz	x19, 40204c84 <_ZN11jnox_kernel14native_el0_mmu12copy_to_user17h9f6ee0e2a7c35599E+0x6c>
    40204c5c:	aa1603e0 	mov	x0, x22
    40204c60:	aa1503e1 	mov	x1, x21
    40204c64:	52800022 	mov	w2, #0x1                   	// #1
    40204c68:	97ffffaf 	bl	40204b24 <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE>
    40204c6c:	f100041f 	cmp	x0, #0x1
    40204c70:	540000e1 	b.ne	40204c8c <_ZN11jnox_kernel14native_el0_mmu12copy_to_user17h9f6ee0e2a7c35599E+0x74>  // b.any
    40204c74:	aa0103e0 	mov	x0, x1
    40204c78:	aa1403e1 	mov	x1, x20
    40204c7c:	aa1303e2 	mov	x2, x19
    40204c80:	940007af 	bl	40206b3c <memcpy>
    40204c84:	52800020 	mov	w0, #0x1                   	// #1
    40204c88:	14000002 	b	40204c90 <_ZN11jnox_kernel14native_el0_mmu12copy_to_user17h9f6ee0e2a7c35599E+0x78>
    40204c8c:	2a1f03e0 	mov	w0, wzr
    40204c90:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40204c94:	a94157f6 	ldp	x22, x21, [sp, #16]
    40204c98:	f84307fe 	ldr	x30, [sp], #48
    40204c9c:	d65f03c0 	ret

0000000040204ca0 <_ZN11jnox_kernel14native_el0_mmu14copy_from_user17h95452b8669d2c3e3E>:
    40204ca0:	f81d0ffe 	str	x30, [sp, #-48]!
    40204ca4:	a90157f6 	stp	x22, x21, [sp, #16]
    40204ca8:	a9024ff4 	stp	x20, x19, [sp, #32]
    40204cac:	aa0203f3 	mov	x19, x2
    40204cb0:	aa0103f4 	mov	x20, x1
    40204cb4:	aa0003f5 	mov	x21, x0
    40204cb8:	9400018a 	bl	402052e0 <_ZN11jnox_kernel14native_el0_mmu6active17hd686f5b0e91753c5E.llvm.14263334612035470596>
    40204cbc:	f100041f 	cmp	x0, #0x1
    40204cc0:	54000281 	b.ne	40204d10 <_ZN11jnox_kernel14native_el0_mmu14copy_from_user17h95452b8669d2c3e3E+0x70>  // b.any
    40204cc4:	aa0103f6 	mov	x22, x1
    40204cc8:	aa0103e0 	mov	x0, x1
    40204ccc:	aa1503e1 	mov	x1, x21
    40204cd0:	aa1303e2 	mov	x2, x19
    40204cd4:	2a1f03e3 	mov	w3, wzr
    40204cd8:	940001c5 	bl	402053ec <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596>
    40204cdc:	340001c0 	cbz	w0, 40204d14 <_ZN11jnox_kernel14native_el0_mmu14copy_from_user17h95452b8669d2c3e3E+0x74>
    40204ce0:	b4000153 	cbz	x19, 40204d08 <_ZN11jnox_kernel14native_el0_mmu14copy_from_user17h95452b8669d2c3e3E+0x68>
    40204ce4:	aa1603e0 	mov	x0, x22
    40204ce8:	aa1503e1 	mov	x1, x21
    40204cec:	2a1f03e2 	mov	w2, wzr
    40204cf0:	97ffff8d 	bl	40204b24 <_ZN11jnox_kernel14native_el0_mmu11translation17hb014aca0dd74262dE>
    40204cf4:	f100041f 	cmp	x0, #0x1
    40204cf8:	540000c1 	b.ne	40204d10 <_ZN11jnox_kernel14native_el0_mmu14copy_from_user17h95452b8669d2c3e3E+0x70>  // b.any
    40204cfc:	aa1403e0 	mov	x0, x20
    40204d00:	aa1303e2 	mov	x2, x19
    40204d04:	9400078e 	bl	40206b3c <memcpy>
    40204d08:	52800020 	mov	w0, #0x1                   	// #1
    40204d0c:	14000002 	b	40204d14 <_ZN11jnox_kernel14native_el0_mmu14copy_from_user17h95452b8669d2c3e3E+0x74>
    40204d10:	2a1f03e0 	mov	w0, wzr
    40204d14:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40204d18:	a94157f6 	ldp	x22, x21, [sp, #16]
    40204d1c:	f84307fe 	ldr	x30, [sp], #48
    40204d20:	d65f03c0 	ret

0000000040204d24 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE>:
    40204d24:	d102c3ff 	sub	sp, sp, #0xb0
    40204d28:	a9057bfd 	stp	x29, x30, [sp, #80]
    40204d2c:	a9066ffc 	stp	x28, x27, [sp, #96]
    40204d30:	a90767fa 	stp	x26, x25, [sp, #112]
    40204d34:	a9085ff8 	stp	x24, x23, [sp, #128]
    40204d38:	a90957f6 	stp	x22, x21, [sp, #144]
    40204d3c:	a90a4ff4 	stp	x20, x19, [sp, #160]
    40204d40:	b4001281 	cbz	x1, 40204f90 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x26c>
    40204d44:	aa0103f3 	mov	x19, x1
    40204d48:	aa0003f5 	mov	x21, x0
    40204d4c:	52800281 	mov	w1, #0x14                  	// #20
    40204d50:	f1000e7f 	cmp	x19, #0x3
    40204d54:	d503201f 	nop
    40204d58:	5006c7e0 	adr	x0, 40212656 <anon.2d7ce5cf085ee3b477e141eaed062738.1.llvm.14263334612035470596+0x56>
    40204d5c:	54001288 	b.hi	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.pmore
    40204d60:	eb13007f 	cmp	x3, x19
    40204d64:	54001241 	b.ne	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.any
    40204d68:	d538424a 	mrs	x10, currentel
    40204d6c:	d53b4229 	mrs	x9, daif
    40204d70:	d5384208 	mrs	x8, spsel
    40204d74:	d5381018 	mrs	x24, sctlr_el1
    40204d78:	910003eb 	mov	x11, sp
    40204d7c:	1000000c 	adr	x12, 40204d7c <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x58>
    40204d80:	f100115f 	cmp	x10, #0x4
    40204d84:	540010e1 	b.ne	40204fa0 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x27c>  // b.any
    40204d88:	2a2903e9 	mvn	w9, w9
    40204d8c:	f27a0d3f 	tst	x9, #0x3c0
    40204d90:	52800461 	mov	w1, #0x23                  	// #35
    40204d94:	d503201f 	nop
    40204d98:	7006c4c0 	adr	x0, 40212633 <anon.2d7ce5cf085ee3b477e141eaed062738.1.llvm.14263334612035470596+0x33>
    40204d9c:	54001081 	b.ne	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.any
    40204da0:	f100051f 	cmp	x8, #0x1
    40204da4:	54001041 	b.ne	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.any
    40204da8:	528200a8 	mov	w8, #0x1005                	// #4101
    40204dac:	72a06008 	movk	w8, #0x300, lsl #16
    40204db0:	8a080308 	and	x8, x24, x8
    40204db4:	b0000209 	adrp	x9, 40245000 <_ZN11jnox_kernel10native_el09extension9EVALUATOR17h2aebd11a2f23ffadE+0x3cd0>
    40204db8:	f941a529 	ldr	x9, [x9, #840]
    40204dbc:	aa090108 	orr	x8, x8, x9
    40204dc0:	b5001068 	cbnz	x8, 40204fcc <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x2a8>
    40204dc4:	d503201f 	nop
    40204dc8:	10fd91c8 	adr	x8, 40200000 <_start>
    40204dcc:	9000650a 	adrp	x10, 40ea4000 <__stack_top>
    40204dd0:	9100014a 	add	x10, x10, #0x0
    40204dd4:	52a06009 	mov	w9, #0x3000000             	// #50331648
    40204dd8:	8b090109 	add	x9, x8, x9
    40204ddc:	52800361 	mov	w1, #0x1b                  	// #27
    40204de0:	eb09015f 	cmp	x10, x9
    40204de4:	d503201f 	nop
    40204de8:	1006c180 	adr	x0, 40212618 <anon.2d7ce5cf085ee3b477e141eaed062738.1.llvm.14263334612035470596+0x18>
    40204dec:	54000e08 	b.hi	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.pmore
    40204df0:	d503201f 	nop
    40204df4:	10071069 	adr	x9, 40213000 <_ZN11jnox_kernel10native_el06FRAMES17hd20826ea19958adeE>
    40204df8:	92402d2d 	and	x13, x9, #0xfff
    40204dfc:	b5000d8d 	cbnz	x13, 40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>
    40204e00:	eb0a013f 	cmp	x9, x10
    40204e04:	54000d42 	b.cs	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.hs, b.nlast
    40204e08:	52a8040d 	mov	w13, #0x40200000            	// #1075838976
    40204e0c:	eb0d011f 	cmp	x8, x13
    40204e10:	54000ce1 	b.ne	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.any
    40204e14:	eb09011f 	cmp	x8, x9
    40204e18:	54000ca2 	b.cs	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.hs, b.nlast
    40204e1c:	52800361 	mov	w1, #0x1b                  	// #27
    40204e20:	eb08019f 	cmp	x12, x8
    40204e24:	54000c43 	b.cc	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.lo, b.ul, b.last
    40204e28:	eb09019f 	cmp	x12, x9
    40204e2c:	54000c02 	b.cs	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.hs, b.nlast
    40204e30:	52800361 	mov	w1, #0x1b                  	// #27
    40204e34:	eb09017f 	cmp	x11, x9
    40204e38:	54000ba3 	b.cc	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.lo, b.ul, b.last
    40204e3c:	eb0a017f 	cmp	x11, x10
    40204e40:	54000b68 	b.hi	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.pmore
    40204e44:	aa0203f4 	mov	x20, x2
    40204e48:	aa1f03eb 	mov	x11, xzr
    40204e4c:	d503201f 	nop
    40204e50:	5006c6cd 	adr	x13, 4021272a <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596+0x7a>
    40204e54:	d503201f 	nop
    40204e58:	1006c44c 	adr	x12, 402126e0 <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596+0x30>
    40204e5c:	9100c2b0 	add	x16, x21, #0x30
    40204e60:	d503201f 	nop
    40204e64:	7006c48f 	adr	x15, 402126f7 <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596+0x47>
    40204e68:	52803a12 	mov	w18, #0x1d0                 	// #464
    40204e6c:	d503201f 	nop
    40204e70:	7006c4b1 	adr	x17, 40212707 <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596+0x57>
    40204e74:	92a00022 	mov	x2, #0xfffffffffffeffff    	// #-65537
    40204e78:	d503201f 	nop
    40204e7c:	3006c4ee 	adr	x14, 40212719 <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596+0x69>
    40204e80:	eb13017f 	cmp	x11, x19
    40204e84:	54000ba0 	b.eq	40204ff8 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x2d4>  // b.none
    40204e88:	8b0b1280 	add	x0, x20, x11, lsl #4
    40204e8c:	f9400400 	ldr	x0, [x0, #8]
    40204e90:	f2400c1f 	tst	x0, #0xf
    40204e94:	540020e1 	b.ne	402052b0 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x58c>  // b.any
    40204e98:	8b020000 	add	x0, x0, x2
    40204e9c:	b140401f 	cmn	x0, #0x10, lsl #12
    40204ea0:	52800221 	mov	w1, #0x11                  	// #17
    40204ea4:	aa0d03e0 	mov	x0, x13
    40204ea8:	54000823 	b.cc	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.lo, b.ul, b.last
    40204eac:	9b125560 	madd	x0, x11, x18, x21
    40204eb0:	f940e401 	ldr	x1, [x0, #456]
    40204eb4:	f100243f 	cmp	x1, #0x9
    40204eb8:	54002022 	b.cs	402052bc <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x598>  // b.hs, b.nlast
    40204ebc:	b4000641 	cbz	x1, 40204f84 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x260>
    40204ec0:	2a1f03e3 	mov	w3, wzr
    40204ec4:	9100056b 	add	x11, x11, #0x1
    40204ec8:	d37ae424 	lsl	x4, x1, #6
    40204ecc:	cb010c84 	sub	x4, x4, x1, lsl #3
    40204ed0:	f940e005 	ldr	x5, [x0, #448]
    40204ed4:	aa1003e6 	mov	x6, x16
    40204ed8:	52a00800 	mov	w0, #0x400000              	// #4194304
    40204edc:	a97d9cc1 	ldp	x1, x7, [x6, #-40]
    40204ee0:	ab070036 	adds	x22, x1, x7
    40204ee4:	540007e2 	b.cs	40204fe0 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x2bc>  // b.hs, b.nlast
    40204ee8:	f85f00d7 	ldur	x23, [x6, #-16]
    40204eec:	ab0702f9 	adds	x25, x23, x7
    40204ef0:	540007e2 	b.cs	40204fec <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x2c8>  // b.hs, b.nlast
    40204ef4:	eb0000ff 	cmp	x7, x0
    40204ef8:	540006e3 	b.cc	40204fd4 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x2b0>  // b.lo, b.ul, b.last
    40204efc:	92402cfa 	and	x26, x7, #0xfff
    40204f00:	52800221 	mov	w1, #0x11                  	// #17
    40204f04:	aa0e03e0 	mov	x0, x14
    40204f08:	b500053a 	cbnz	x26, 40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>
    40204f0c:	f160033f 	cmp	x25, #0x800, lsl #12
    40204f10:	54000628 	b.hi	40204fd4 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x2b0>  // b.pmore
    40204f14:	b4000617 	cbz	x23, 40204fd4 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x2b0>
    40204f18:	eb1902df 	cmp	x22, x25
    40204f1c:	52800221 	mov	w1, #0x11                  	// #17
    40204f20:	aa0e03e0 	mov	x0, x14
    40204f24:	54000448 	b.hi	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>  // b.pmore
    40204f28:	92742f20 	and	x0, x25, #0xfff000
    40204f2c:	91400400 	add	x0, x0, #0x1, lsl #12
    40204f30:	f2402eff 	tst	x23, #0xfff
    40204f34:	9a800320 	csel	x0, x25, x0, eq  // eq = none
    40204f38:	f85f80c1 	ldur	x1, [x6, #-8]
    40204f3c:	eb01001f 	cmp	x0, x1
    40204f40:	540004a1 	b.ne	40204fd4 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x2b0>  // b.any
    40204f44:	384384c1 	ldrb	w1, [x6], #56
    40204f48:	7100043f 	cmp	w1, #0x1
    40204f4c:	540000a1 	b.ne	40204f60 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x23c>  // b.any
    40204f50:	eb0500ff 	cmp	x7, x5
    40204f54:	fa5690a2 	ccmp	x5, x22, #0x2, ls  // ls = plast
    40204f58:	1a9f27e1 	cset	w1, cc  // cc = lo, ul, last
    40204f5c:	14000002 	b	40204f64 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x240>
    40204f60:	2a1f03e1 	mov	w1, wzr
    40204f64:	2a010063 	orr	w3, w3, w1
    40204f68:	f100e084 	subs	x4, x4, #0x38
    40204f6c:	54fffb81 	b.ne	40204edc <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x1b8>  // b.any
    40204f70:	f24004bf 	tst	x5, #0x3
    40204f74:	1a9f17e0 	cset	w0, eq  // eq = none
    40204f78:	0a000060 	and	w0, w3, w0
    40204f7c:	91074210 	add	x16, x16, #0x1d0
    40204f80:	3707f800 	tbnz	w0, #0, 40204e80 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x15c>
    40204f84:	528002e1 	mov	w1, #0x17                  	// #23
    40204f88:	aa0c03e0 	mov	x0, x12
    40204f8c:	14000008 	b	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>
    40204f90:	52800281 	mov	w1, #0x14                  	// #20
    40204f94:	d503201f 	nop
    40204f98:	5006b5e0 	adr	x0, 40212656 <anon.2d7ce5cf085ee3b477e141eaed062738.1.llvm.14263334612035470596+0x56>
    40204f9c:	14000004 	b	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>
    40204fa0:	52800461 	mov	w1, #0x23                  	// #35
    40204fa4:	d503201f 	nop
    40204fa8:	7006b440 	adr	x0, 40212633 <anon.2d7ce5cf085ee3b477e141eaed062738.1.llvm.14263334612035470596+0x33>
    40204fac:	a94a4ff4 	ldp	x20, x19, [sp, #160]
    40204fb0:	a94957f6 	ldp	x22, x21, [sp, #144]
    40204fb4:	a9485ff8 	ldp	x24, x23, [sp, #128]
    40204fb8:	a94767fa 	ldp	x26, x25, [sp, #112]
    40204fbc:	a9466ffc 	ldp	x28, x27, [sp, #96]
    40204fc0:	a9457bfd 	ldp	x29, x30, [sp, #80]
    40204fc4:	9102c3ff 	add	sp, sp, #0xb0
    40204fc8:	d65f03c0 	ret
    40204fcc:	52800461 	mov	w1, #0x23                  	// #35
    40204fd0:	17fffff7 	b	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>
    40204fd4:	52800221 	mov	w1, #0x11                  	// #17
    40204fd8:	aa0e03e0 	mov	x0, x14
    40204fdc:	17fffff4 	b	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>
    40204fe0:	52800201 	mov	w1, #0x10                  	// #16
    40204fe4:	aa0f03e0 	mov	x0, x15
    40204fe8:	17fffff1 	b	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>
    40204fec:	52800241 	mov	w1, #0x12                  	// #18
    40204ff0:	aa1103e0 	mov	x0, x17
    40204ff4:	17ffffee 	b	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>
    40204ff8:	aa1f03eb 	mov	x11, xzr
    40204ffc:	d280e072 	mov	x18, #0x703                 	// #1795
    40205000:	f2e00c12 	movk	x18, #0x60, lsl #48
    40205004:	cb08014a 	sub	x10, x10, x8
    40205008:	d34cfd4c 	lsr	x12, x10, #12
    4020500c:	f2402d5f 	tst	x10, #0xfff
    40205010:	9a8c058c 	cinc	x12, x12, ne  // ne = any
    40205014:	d503201f 	nop
    40205018:	1021ff4d 	adr	x13, 40249000 <_ZN11jnox_kernel14native_el0_mmu6KERNEL17h0d0c136c030dfbd8E>
    4020501c:	d280f06e 	mov	x14, #0x783                 	// #1923
    40205020:	f2e0080e 	movk	x14, #0x40, lsl #48
    40205024:	d503201f 	nop
    40205028:	1020feca 	adr	x10, 40247000 <_ZN11jnox_kernel14native_el0_mmu4HIGH17hd88e6be174b77113E>
    4020502c:	d355fd6f 	lsr	x15, x11, #21
    40205030:	8b0f31af 	add	x15, x13, x15, lsl #12
    40205034:	f240511f 	tst	x8, #0x1fffff
    40205038:	54000081 	b.ne	40205048 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x324>  // b.any
    4020503c:	d3557510 	ubfx	x16, x8, #21, #9
    40205040:	b24005f1 	orr	x17, x15, #0x3
    40205044:	f8307951 	str	x17, [x10, x16, lsl #3]
    40205048:	eb09011f 	cmp	x8, x9
    4020504c:	d34c5110 	ubfx	x16, x8, #12, #9
    40205050:	9a9231d1 	csel	x17, x14, x18, cc  // cc = lo, ul, last
    40205054:	aa080231 	orr	x17, x17, x8
    40205058:	f83079f1 	str	x17, [x15, x16, lsl #3]
    4020505c:	d100058c 	sub	x12, x12, #0x1
    40205060:	9140056b 	add	x11, x11, #0x1, lsl #12
    40205064:	91400508 	add	x8, x8, #0x1, lsl #12
    40205068:	b5fffe2c 	cbnz	x12, 4020502c <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x308>
    4020506c:	aa1f03f6 	mov	x22, xzr
    40205070:	528a000c 	mov	w12, #0x5000                	// #20480
    40205074:	72a0082c 	movk	w12, #0x41, lsl #16
    40205078:	d503201f 	nop
    4020507c:	10217c28 	adr	x8, 40248000 <_ZN11jnox_kernel14native_el0_mmu4UART17h5868ad9ea1d2b8d0E>
    40205080:	d280c0e9 	mov	x9, #0x607                 	// #1543
    40205084:	f2a12009 	movk	x9, #0x900, lsl #16
    40205088:	f2e00c09 	movk	x9, #0x60, lsl #48
    4020508c:	d503201f 	nop
    40205090:	10207b8b 	adr	x11, 40246000 <_ZN11jnox_kernel14native_el0_mmu3GIC17h953a938fd84f0f7cE>
    40205094:	f9000109 	str	x9, [x8]
    40205098:	d280c0e9 	mov	x9, #0x607                 	// #1543
    4020509c:	f2a10009 	movk	x9, #0x800, lsl #16
    402050a0:	f2e00c09 	movk	x9, #0x60, lsl #48
    402050a4:	f9000169 	str	x9, [x11]
    402050a8:	b2700129 	orr	x9, x9, #0x10000
    402050ac:	f9004169 	str	x9, [x11, #128]
    402050b0:	b2400549 	orr	x9, x10, #0x3
    402050b4:	b2400508 	orr	x8, x8, #0x3
    402050b8:	a90127e8 	stp	x8, x9, [sp, #16]
    402050bc:	9000031d 	adrp	x29, 40265000 <_ZN11jnox_kernel14native_el0_mmu6SPACES17h746e7fcfb4f25aceE.llvm.14263334612035470596+0x4000>
    402050c0:	910023bd 	add	x29, x29, #0x8
    402050c4:	d14fffa8 	sub	x8, x29, #0x3ff, lsl #12
    402050c8:	d100211c 	sub	x28, x8, #0x8
    402050cc:	915003a8 	add	x8, x29, #0x400, lsl #12
    402050d0:	913fe117 	add	x23, x8, #0xff8
    402050d4:	b2400568 	orr	x8, x11, #0x3
    402050d8:	f90007e8 	str	x8, [sp, #8]
    402050dc:	a9035bf7 	stp	x23, x22, [sp, #48]
    402050e0:	52803a08 	mov	w8, #0x1d0                 	// #464
    402050e4:	9b0856d9 	madd	x25, x22, x8, x21
    402050e8:	8b161288 	add	x8, x20, x22, lsl #4
    402050ec:	a9402909 	ldp	x9, x10, [x8]
    402050f0:	d503201f 	nop
    402050f4:	102df868 	adr	x8, 40261000 <_ZN11jnox_kernel14native_el0_mmu6SPACES17h746e7fcfb4f25aceE.llvm.14263334612035470596>
    402050f8:	9b0c22cb 	madd	x11, x22, x12, x8
    402050fc:	91400577 	add	x23, x11, #0x1, lsl #12
    40205100:	b24006e8 	orr	x8, x23, #0x3
    40205104:	f9000168 	str	x8, [x11]
    40205108:	f9400fe8 	ldr	x8, [sp, #24]
    4020510c:	f9000568 	str	x8, [x11, #8]
    40205110:	f9400be8 	ldr	x8, [sp, #16]
    40205114:	f9092168 	str	x8, [x11, #4672]
    40205118:	f94007e8 	ldr	x8, [sp, #8]
    4020511c:	f90023eb 	str	x11, [sp, #64]
    40205120:	f9090168 	str	x8, [x11, #4608]
    40205124:	f940e721 	ldr	x1, [x25, #456]
    40205128:	f100243f 	cmp	x1, #0x9
    4020512c:	54000c82 	b.cs	402052bc <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x598>  // b.hs, b.nlast
    40205130:	a90227ea 	stp	x10, x9, [sp, #32]
    40205134:	b4000581 	cbz	x1, 402051e4 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x4c0>
    40205138:	f94023e9 	ldr	x9, [sp, #64]
    4020513c:	91401528 	add	x8, x9, #0x5, lsl #12
    40205140:	f90027e8 	str	x8, [sp, #72]
    40205144:	52800708 	mov	w8, #0x38                  	// #56
    40205148:	9b08643a 	madd	x26, x1, x8, x25
    4020514c:	9140093b 	add	x27, x9, #0x2, lsl #12
    40205150:	a940db22 	ldp	x2, x22, [x25, #8]
    40205154:	f9400321 	ldr	x1, [x25]
    40205158:	f94027e8 	ldr	x8, [sp, #72]
    4020515c:	8b160108 	add	x8, x8, x22
    40205160:	d1500100 	sub	x0, x8, #0x400, lsl #12
    40205164:	94000676 	bl	40206b3c <memcpy>
    40205168:	f9401728 	ldr	x8, [x25, #40]
    4020516c:	eb160109 	subs	x9, x8, x22
    40205170:	54000349 	b.ls	402051d8 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x4b4>  // b.plast
    40205174:	3940c328 	ldrb	w8, [x25, #48]
    40205178:	d503201f 	nop
    4020517c:	1006ae2a 	adr	x10, 40212740 <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596+0x90>
    40205180:	f8687948 	ldr	x8, [x10, x8, lsl #3]
    40205184:	d34cfd2a 	lsr	x10, x9, #12
    40205188:	f2402d3f 	tst	x9, #0xfff
    4020518c:	9a8a0549 	cinc	x9, x10, ne  // ne = any
    40205190:	d34cfeca 	lsr	x10, x22, #12
    40205194:	d15002cb 	sub	x11, x22, #0x400, lsl #12
    40205198:	d355fd60 	lsr	x0, x11, #21
    4020519c:	d356fd6b 	lsr	x11, x11, #22
    402051a0:	b500098b 	cbnz	x11, 402052d0 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x5ac>
    402051a4:	f1000529 	subs	x9, x9, #0x1
    402051a8:	d352fecb 	lsr	x11, x22, #18
    402051ac:	8b00336c 	add	x12, x27, x0, lsl #12
    402051b0:	8b16038d 	add	x13, x28, x22
    402051b4:	9240214e 	and	x14, x10, #0x1ff
    402051b8:	927da96b 	and	x11, x11, #0x3ffffffffff8
    402051bc:	b240058f 	orr	x15, x12, #0x3
    402051c0:	f82b6aef 	str	x15, [x23, x11]
    402051c4:	aa0d010b 	orr	x11, x8, x13
    402051c8:	f82e798b 	str	x11, [x12, x14, lsl #3]
    402051cc:	914006d6 	add	x22, x22, #0x1, lsl #12
    402051d0:	9100054a 	add	x10, x10, #0x1
    402051d4:	54fffe01 	b.ne	40205194 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x470>  // b.any
    402051d8:	9100e339 	add	x25, x25, #0x38
    402051dc:	eb1a033f 	cmp	x25, x26
    402051e0:	54fffb81 	b.ne	40205150 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x42c>  // b.any
    402051e4:	aa1f03e8 	mov	x8, xzr
    402051e8:	a943aff6 	ldp	x22, x11, [sp, #56]
    402051ec:	910006d6 	add	x22, x22, #0x1
    402051f0:	91501569 	add	x9, x11, #0x405, lsl #12
    402051f4:	5288006a 	mov	w10, #0x4003                	// #16387
    402051f8:	8b0a016a 	add	x10, x11, x10
    402051fc:	f908216a 	str	x10, [x11, #4160]
    40205200:	f9401bf7 	ldr	x23, [sp, #48]
    40205204:	aa1703ea 	mov	x10, x23
    40205208:	d280e06c 	mov	x12, #0x703                 	// #1795
    4020520c:	f2e00c0c 	movk	x12, #0x60, lsl #48
    40205210:	9121018b 	add	x11, x12, #0x840
    40205214:	aa0b014b 	orr	x11, x10, x11
    40205218:	9140054a 	add	x10, x10, #0x1, lsl #12
    4020521c:	f8286bab 	str	x11, [x29, x8]
    40205220:	91002108 	add	x8, x8, #0x8
    40205224:	f102011f 	cmp	x8, #0x80
    40205228:	54ffff41 	b.ne	40205210 <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x4ec>  // b.any
    4020522c:	a94207e2 	ldp	x2, x1, [sp, #32]
    40205230:	cb020128 	sub	x8, x9, x2
    40205234:	91404100 	add	x0, x8, #0x10, lsl #12
    40205238:	94000641 	bl	40206b3c <memcpy>
    4020523c:	528a000c 	mov	w12, #0x5000                	// #20480
    40205240:	72a0082c 	movk	w12, #0x41, lsl #16
    40205244:	8b0c039c 	add	x28, x28, x12
    40205248:	915057bd 	add	x29, x29, #0x415, lsl #12
    4020524c:	8b0c02f7 	add	x23, x23, x12
    40205250:	eb1302df 	cmp	x22, x19
    40205254:	54fff441 	b.ne	402050dc <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x3b8>  // b.any
    40205258:	aa1f03e0 	mov	x0, xzr
    4020525c:	d503201f 	nop
    40205260:	102ded08 	adr	x8, 40261000 <_ZN11jnox_kernel14native_el0_mmu6SPACES17h746e7fcfb4f25aceE.llvm.14263334612035470596>
    40205264:	b2500108 	orr	x8, x8, #0x1000000000000
    40205268:	b2400309 	orr	x9, x24, #0x1
    4020526c:	5280088a 	mov	w10, #0x44                  	// #68
    40205270:	5286032b 	mov	w11, #0x3019                	// #12313
    40205274:	72b0132b 	movk	w11, #0x8099, lsl #16
    40205278:	d5033f9f 	dsb	sy
    4020527c:	d518a20a 	msr	mair_el1, x10
    40205280:	d518204b 	msr	tcr_el1, x11
    40205284:	d5182008 	msr	ttbr0_el1, x8
    40205288:	d5033fdf 	isb
    4020528c:	d508871f 	tlbi	vmalle1
    40205290:	d508751f 	ic	iallu
    40205294:	d5033f9f 	dsb	sy
    40205298:	d5033fdf 	isb
    4020529c:	d5181009 	msr	sctlr_el1, x9
    402052a0:	d5033fdf 	isb
    402052a4:	90000208 	adrp	x8, 40245000 <_ZN11jnox_kernel10native_el09extension9EVALUATOR17h2aebd11a2f23ffadE+0x3cd0>
    402052a8:	f901a513 	str	x19, [x8, #840]
    402052ac:	17ffff40 	b	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>
    402052b0:	52800221 	mov	w1, #0x11                  	// #17
    402052b4:	aa0d03e0 	mov	x0, x13
    402052b8:	17ffff3d 	b	40204fac <_ZN11jnox_kernel14native_el0_mmu17install_processes17he77a000a5c6ab97dE+0x288>
    402052bc:	d503201f 	nop
    402052c0:	10068c83 	adr	x3, 40212450 <anon.773058ed228f2edaafa50d5b0d646736.16.llvm.4321263285462747625>
    402052c4:	aa1f03e0 	mov	x0, xzr
    402052c8:	52800102 	mov	w2, #0x8                   	// #8
    402052cc:	9400045d 	bl	40206440 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>
    402052d0:	d503201f 	nop
    402052d4:	10069fa2 	adr	x2, 402126c8 <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596+0x18>
    402052d8:	52800041 	mov	w1, #0x2                   	// #2
    402052dc:	940001b9 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

00000000402052e0 <_ZN11jnox_kernel14native_el0_mmu6active17hd686f5b0e91753c5E.llvm.14263334612035470596>:
    402052e0:	90000208 	adrp	x8, 40245000 <_ZN11jnox_kernel10native_el09extension9EVALUATOR17h2aebd11a2f23ffadE+0x3cd0>
    402052e4:	f941a508 	ldr	x8, [x8, #840]
    402052e8:	b4000288 	cbz	x8, 40205338 <_ZN11jnox_kernel14native_el0_mmu6active17hd686f5b0e91753c5E.llvm.14263334612035470596+0x58>
    402052ec:	aa1f03ec 	mov	x12, xzr
    402052f0:	d2e0002a 	mov	x10, #0x1000000000000       	// #281474976710656
    402052f4:	d538200b 	mrs	x11, ttbr0_el1
    402052f8:	d2e0002d 	mov	x13, #0x1000000000000       	// #281474976710656
    402052fc:	d503201f 	nop
    40205300:	102de80e 	adr	x14, 40261000 <_ZN11jnox_kernel14native_el0_mmu6SPACES17h746e7fcfb4f25aceE.llvm.14263334612035470596>
    40205304:	aa0c03e9 	mov	x9, x12
    40205308:	eb0c011f 	cmp	x8, x12
    4020530c:	540001a0 	b.eq	40205340 <_ZN11jnox_kernel14native_el0_mmu6active17hd686f5b0e91753c5E.llvm.14263334612035470596+0x60>  // b.none
    40205310:	f1000d3f 	cmp	x9, #0x3
    40205314:	540001e0 	b.eq	40205350 <_ZN11jnox_kernel14native_el0_mmu6active17hd686f5b0e91753c5E.llvm.14263334612035470596+0x70>  // b.none
    40205318:	9100052c 	add	x12, x9, #0x1
    4020531c:	aa0e01af 	orr	x15, x13, x14
    40205320:	915055ce 	add	x14, x14, #0x415, lsl #12
    40205324:	8b0a01ad 	add	x13, x13, x10
    40205328:	eb0b01ff 	cmp	x15, x11
    4020532c:	54fffec1 	b.ne	40205304 <_ZN11jnox_kernel14native_el0_mmu6active17hd686f5b0e91753c5E.llvm.14263334612035470596+0x24>  // b.any
    40205330:	d1000581 	sub	x1, x12, #0x1
    40205334:	14000004 	b	40205344 <_ZN11jnox_kernel14native_el0_mmu6active17hd686f5b0e91753c5E.llvm.14263334612035470596+0x64>
    40205338:	aa1f03e0 	mov	x0, xzr
    4020533c:	d65f03c0 	ret
    40205340:	aa0803e1 	mov	x1, x8
    40205344:	eb09011f 	cmp	x8, x9
    40205348:	1a9f07e0 	cset	w0, ne  // ne = any
    4020534c:	d65f03c0 	ret
    40205350:	f81f0ffe 	str	x30, [sp, #-16]!
    40205354:	d503201f 	nop
    40205358:	10069ac2 	adr	x2, 402126b0 <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596>
    4020535c:	52800060 	mov	w0, #0x3                   	// #3
    40205360:	52800061 	mov	w1, #0x3                   	// #3
    40205364:	94000197 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040205368 <_ZN11jnox_kernel14native_el0_mmu6switch17h0d8db83ade90bdd9E>:
    40205368:	f81e0ffe 	str	x30, [sp, #-32]!
    4020536c:	a9014ff4 	stp	x20, x19, [sp, #16]
    40205370:	aa0003f3 	mov	x19, x0
    40205374:	9400004f 	bl	402054b0 <_ZN11jnox_kernel14native_el0_mmu8space_id17h8fc6c24822472ecbE.llvm.14263334612035470596>
    40205378:	f100041f 	cmp	x0, #0x1
    4020537c:	54000241 	b.ne	402053c4 <_ZN11jnox_kernel14native_el0_mmu6switch17h0d8db83ade90bdd9E+0x5c>  // b.any
    40205380:	d53b4228 	mrs	x8, daif
    40205384:	36380288 	tbz	w8, #7, 402053d4 <_ZN11jnox_kernel14native_el0_mmu6switch17h0d8db83ade90bdd9E+0x6c>
    40205388:	aa0103f4 	mov	x20, x1
    4020538c:	97ffffd5 	bl	402052e0 <_ZN11jnox_kernel14native_el0_mmu6active17hd686f5b0e91753c5E.llvm.14263334612035470596>
    40205390:	b4000220 	cbz	x0, 402053d4 <_ZN11jnox_kernel14native_el0_mmu6switch17h0d8db83ade90bdd9E+0x6c>
    40205394:	d5033f9f 	dsb	sy
    40205398:	d5182014 	msr	ttbr0_el1, x20
    4020539c:	d5033fdf 	isb
    402053a0:	97ffffd0 	bl	402052e0 <_ZN11jnox_kernel14native_el0_mmu6active17hd686f5b0e91753c5E.llvm.14263334612035470596>
    402053a4:	eb13003f 	cmp	x1, x19
    402053a8:	1a9f17e8 	cset	w8, eq  // eq = none
    402053ac:	d503201f 	nop
    402053b0:	10069689 	adr	x9, 40212680 <anon.2d7ce5cf085ee3b477e141eaed062738.6.llvm.14263334612035470596>
    402053b4:	6a00011f 	tst	w8, w0
    402053b8:	9a8913e0 	csel	x0, xzr, x9, ne  // ne = any
    402053bc:	52800281 	mov	w1, #0x14                  	// #20
    402053c0:	14000008 	b	402053e0 <_ZN11jnox_kernel14native_el0_mmu6switch17h0d8db83ade90bdd9E+0x78>
    402053c4:	528002c1 	mov	w1, #0x16                  	// #22
    402053c8:	d503201f 	nop
    402053cc:	500694e0 	adr	x0, 4021266a <anon.2d7ce5cf085ee3b477e141eaed062738.5.llvm.14263334612035470596>
    402053d0:	14000004 	b	402053e0 <_ZN11jnox_kernel14native_el0_mmu6switch17h0d8db83ade90bdd9E+0x78>
    402053d4:	528002a1 	mov	w1, #0x15                  	// #21
    402053d8:	d503201f 	nop
    402053dc:	100695c0 	adr	x0, 40212694 <anon.2d7ce5cf085ee3b477e141eaed062738.7.llvm.14263334612035470596>
    402053e0:	a9414ff4 	ldp	x20, x19, [sp, #16]
    402053e4:	f84207fe 	ldr	x30, [sp], #32
    402053e8:	d65f03c0 	ret

00000000402053ec <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596>:
    402053ec:	d10143ff 	sub	sp, sp, #0x50
    402053f0:	f9001bfe 	str	x30, [sp, #48]
    402053f4:	a9044ff4 	stp	x20, x19, [sp, #64]
    402053f8:	f90003e0 	str	x0, [sp]
    402053fc:	3900f3e3 	strb	w3, [sp, #60]
    40205400:	d53b4228 	mrs	x8, daif
    40205404:	37380068 	tbnz	w8, #7, 40205410 <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596+0x24>
    40205408:	2a1f03e0 	mov	w0, wzr
    4020540c:	14000025 	b	402054a0 <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596+0xb4>
    40205410:	aa0203f4 	mov	x20, x2
    40205414:	aa0103f3 	mov	x19, x1
    40205418:	94000026 	bl	402054b0 <_ZN11jnox_kernel14native_el0_mmu8space_id17h8fc6c24822472ecbE.llvm.14263334612035470596>
    4020541c:	b4000420 	cbz	x0, 402054a0 <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596+0xb4>
    40205420:	b40003f4 	cbz	x20, 4020549c <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596+0xb0>
    40205424:	8b140268 	add	x8, x19, x20
    40205428:	d1000508 	sub	x8, x8, #0x1
    4020542c:	eb13011f 	cmp	x8, x19
    40205430:	54fffec3 	b.cc	40205408 <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596+0x1c>  // b.lo, b.ul, b.last
    40205434:	f150027f 	cmp	x19, #0x400, lsl #12
    40205438:	54000063 	b.cc	40205444 <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596+0x58>  // b.lo, b.ul, b.last
    4020543c:	f160011f 	cmp	x8, #0x800, lsl #12
    40205440:	54000143 	b.cc	40205468 <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596+0x7c>  // b.lo, b.ul, b.last
    40205444:	2a1f03e0 	mov	w0, wzr
    40205448:	52820009 	mov	w9, #0x1000                	// #4096
    4020544c:	72a02009 	movk	w9, #0x100, lsl #16
    40205450:	eb09027f 	cmp	x19, x9
    40205454:	54000263 	b.cc	402054a0 <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596+0xb4>  // b.lo, b.ul, b.last
    40205458:	5281ffe9 	mov	w9, #0xfff                 	// #4095
    4020545c:	72a02029 	movk	w9, #0x101, lsl #16
    40205460:	eb09011f 	cmp	x8, x9
    40205464:	540001e8 	b.hi	402054a0 <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596+0xb4>  // b.pmore
    40205468:	9274ce69 	and	x9, x19, #0xfffffffffffff000
    4020546c:	a90123e9 	stp	x9, x8, [sp, #16]
    40205470:	390083ff 	strb	wzr, [sp, #32]
    40205474:	5281ffe8 	mov	w8, #0xfff                 	// #4095
    40205478:	f90007e8 	str	x8, [sp, #8]
    4020547c:	52800028 	mov	w8, #0x1                   	// #1
    40205480:	3900a3e8 	strb	w8, [sp, #40]
    40205484:	910023e0 	add	x0, sp, #0x8
    40205488:	910003e1 	mov	x1, sp
    4020548c:	9100f3e2 	add	x2, sp, #0x3c
    40205490:	97fff466 	bl	40202628 <_ZN105_$LT$core..iter..adapters..step_by..StepBy$LT$I$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h8aacbdb5caf8dc87E>
    40205494:	52000000 	eor	w0, w0, #0x1
    40205498:	14000002 	b	402054a0 <_ZN11jnox_kernel14native_el0_mmu8can_copy17h7694d0533e5a01baE.llvm.14263334612035470596+0xb4>
    4020549c:	52800020 	mov	w0, #0x1                   	// #1
    402054a0:	a9444ff4 	ldp	x20, x19, [sp, #64]
    402054a4:	f9401bfe 	ldr	x30, [sp, #48]
    402054a8:	910143ff 	add	sp, sp, #0x50
    402054ac:	d65f03c0 	ret

00000000402054b0 <_ZN11jnox_kernel14native_el0_mmu8space_id17h8fc6c24822472ecbE.llvm.14263334612035470596>:
    402054b0:	90000208 	adrp	x8, 40245000 <_ZN11jnox_kernel10native_el09extension9EVALUATOR17h2aebd11a2f23ffadE+0x3cd0>
    402054b4:	f941a508 	ldr	x8, [x8, #840]
    402054b8:	eb08001f 	cmp	x0, x8
    402054bc:	540001a2 	b.cs	402054f0 <_ZN11jnox_kernel14native_el0_mmu8space_id17h8fc6c24822472ecbE.llvm.14263334612035470596+0x40>  // b.hs, b.nlast
    402054c0:	f1000c1f 	cmp	x0, #0x3
    402054c4:	540001a2 	b.cs	402054f8 <_ZN11jnox_kernel14native_el0_mmu8space_id17h8fc6c24822472ecbE.llvm.14263334612035470596+0x48>  // b.hs, b.nlast
    402054c8:	d503201f 	nop
    402054cc:	102dd9a8 	adr	x8, 40261000 <_ZN11jnox_kernel14native_el0_mmu6SPACES17h746e7fcfb4f25aceE.llvm.14263334612035470596>
    402054d0:	528a0009 	mov	w9, #0x5000                	// #20480
    402054d4:	72a00829 	movk	w9, #0x41, lsl #16
    402054d8:	9b092008 	madd	x8, x0, x9, x8
    402054dc:	d2e00029 	mov	x9, #0x1000000000000       	// #281474976710656
    402054e0:	8b00c129 	add	x9, x9, x0, lsl #48
    402054e4:	aa080121 	orr	x1, x9, x8
    402054e8:	52800020 	mov	w0, #0x1                   	// #1
    402054ec:	d65f03c0 	ret
    402054f0:	aa1f03e0 	mov	x0, xzr
    402054f4:	d65f03c0 	ret
    402054f8:	f81f0ffe 	str	x30, [sp, #-16]!
    402054fc:	d503201f 	nop
    40205500:	10068d82 	adr	x2, 402126b0 <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596>
    40205504:	52800061 	mov	w1, #0x3                   	// #3
    40205508:	9400012e 	bl	402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

000000004020550c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral>:
    4020550c:	d101c3ff 	sub	sp, sp, #0x70
    40205510:	a9017bfd 	stp	x29, x30, [sp, #16]
    40205514:	a9026ffc 	stp	x28, x27, [sp, #32]
    40205518:	a90367fa 	stp	x26, x25, [sp, #48]
    4020551c:	a9045ff8 	stp	x24, x23, [sp, #64]
    40205520:	a90557f6 	stp	x22, x21, [sp, #80]
    40205524:	a9064ff4 	stp	x20, x19, [sp, #96]
    40205528:	910043fd 	add	x29, sp, #0x10
    4020552c:	b940101a 	ldr	w26, [x0, #16]
    40205530:	52a00229 	mov	w9, #0x110000              	// #1114112
    40205534:	aa0503f3 	mov	x19, x5
    40205538:	aa0403fc 	mov	x28, x4
    4020553c:	aa0303f6 	mov	x22, x3
    40205540:	aa0003f5 	mov	x21, x0
    40205544:	926b0348 	and	x8, x26, #0x200000
    40205548:	d355574a 	ubfx	x10, x26, #21, #1
    4020554c:	7100011f 	cmp	w8, #0x0
    40205550:	52800568 	mov	w8, #0x2b                  	// #43
    40205554:	1a880128 	csel	w8, w9, w8, eq  // eq = none
    40205558:	7100003f 	cmp	w1, #0x0
    4020555c:	528005a9 	mov	w9, #0x2d                  	// #45
    40205560:	9a9f154a 	csinc	x10, x10, xzr, ne  // ne = any
    40205564:	1a891118 	csel	w24, w8, w9, ne  // ne = any
    40205568:	8b05015b 	add	x27, x10, x5
    4020556c:	37b8033a 	tbnz	w26, #23, 402055d0 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0xc4>
    40205570:	aa1f03f7 	mov	x23, xzr
    40205574:	79402ab4 	ldrh	w20, [x21, #20]
    40205578:	eb14037f 	cmp	x27, x20
    4020557c:	54001503 	b.cc	4020581c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x310>  // b.lo, b.ul, b.last
    40205580:	a94056b9 	ldp	x25, x21, [x21]
    40205584:	2a1803e2 	mov	w2, w24
    40205588:	aa1703e3 	mov	x3, x23
    4020558c:	aa1603e4 	mov	x4, x22
    40205590:	aa1903e0 	mov	x0, x25
    40205594:	aa1503e1 	mov	x1, x21
    40205598:	9400041c 	bl	40206608 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix>
    4020559c:	37001d60 	tbnz	w0, #0, 40205948 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    402055a0:	f9400ea3 	ldr	x3, [x21, #24]
    402055a4:	aa1903e0 	mov	x0, x25
    402055a8:	aa1c03e1 	mov	x1, x28
    402055ac:	aa1303e2 	mov	x2, x19
    402055b0:	a9464ff4 	ldp	x20, x19, [sp, #96]
    402055b4:	a94557f6 	ldp	x22, x21, [sp, #80]
    402055b8:	a9445ff8 	ldp	x24, x23, [sp, #64]
    402055bc:	a94367fa 	ldp	x26, x25, [sp, #48]
    402055c0:	a9426ffc 	ldp	x28, x27, [sp, #32]
    402055c4:	a9417bfd 	ldp	x29, x30, [sp, #16]
    402055c8:	9101c3ff 	add	sp, sp, #0x70
    402055cc:	d61f0060 	br	x3
    402055d0:	aa0203f7 	mov	x23, x2
    402055d4:	f10082df 	cmp	x22, #0x20
    402055d8:	540000e2 	b.cs	402055f4 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0xe8>  // b.hs, b.nlast
    402055dc:	b4000156 	cbz	x22, 40205604 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0xf8>
    402055e0:	f10022df 	cmp	x22, #0x8
    402055e4:	54000142 	b.cs	4020560c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x100>  // b.hs, b.nlast
    402055e8:	aa1f03e8 	mov	x8, xzr
    402055ec:	aa1f03e0 	mov	x0, xzr
    402055f0:	14000080 	b	402057f0 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x2e4>
    402055f4:	aa1703e0 	mov	x0, x23
    402055f8:	aa1603e1 	mov	x1, x22
    402055fc:	9400010e 	bl	40205a34 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars>
    40205600:	14000083 	b	4020580c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x300>
    40205604:	aa1f03e0 	mov	x0, xzr
    40205608:	14000081 	b	4020580c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x300>
    4020560c:	aa1703ea 	mov	x10, x23
    40205610:	39400ae9 	ldrb	w9, [x23, #2]
    40205614:	394006e8 	ldrb	w8, [x23, #1]
    40205618:	38404d4b 	ldrb	w11, [x10, #4]!
    4020561c:	3940094c 	ldrb	w12, [x10, #2]
    40205620:	394002ed 	ldrb	w13, [x23]
    40205624:	39400eee 	ldrb	w14, [x23, #3]
    40205628:	d370bd29 	lsl	x9, x9, #16
    4020562c:	394016ef 	ldrb	w15, [x23, #5]
    40205630:	39400d4a 	ldrb	w10, [x10, #3]
    40205634:	53103d8c 	lsl	w12, w12, #16
    40205638:	aa0821a8 	orr	x8, x13, x8, lsl #8
    4020563c:	aa0e6129 	orr	x9, x9, x14, lsl #24
    40205640:	0f05e7e4 	movi	v4.8b, #0xbf
    40205644:	2a0f216b 	orr	w11, w11, w15, lsl #8
    40205648:	2a0a618a 	orr	w10, w12, w10, lsl #24
    4020564c:	aa080128 	orr	x8, x9, x8
    40205650:	2a0b0149 	orr	w9, w10, w11
    40205654:	aa098108 	orr	x8, x8, x9, lsl #32
    40205658:	9e670100 	fmov	d0, x8
    4020565c:	52800028 	mov	w8, #0x1                   	// #1
    40205660:	4e080d03 	dup	v3.2d, x8
    40205664:	927d06c8 	and	x8, x22, #0x18
    40205668:	f100211f 	cmp	x8, #0x8
    4020566c:	0e243400 	cmgt	v0.8b, v0.8b, v4.8b
    40205670:	2f08a400 	uxtl	v0.8h, v0.8b
    40205674:	6f10a401 	uxtl2	v1.4s, v0.8h
    40205678:	2f10a400 	uxtl	v0.4s, v0.4h
    4020567c:	6f20a422 	uxtl2	v2.2d, v1.4s
    40205680:	2f20a421 	uxtl	v1.2d, v1.2s
    40205684:	6f20a405 	uxtl2	v5.2d, v0.4s
    40205688:	2f20a406 	uxtl	v6.2d, v0.2s
    4020568c:	4e231c40 	and	v0.16b, v2.16b, v3.16b
    40205690:	4e231c22 	and	v2.16b, v1.16b, v3.16b
    40205694:	4e231ca1 	and	v1.16b, v5.16b, v3.16b
    40205698:	4e231cc3 	and	v3.16b, v6.16b, v3.16b
    4020569c:	540009c0 	b.eq	402057d4 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x2c8>  // b.none
    402056a0:	aa1703e9 	mov	x9, x23
    402056a4:	f100411f 	cmp	x8, #0x10
    402056a8:	38408d2a 	ldrb	w10, [x9, #8]!
    402056ac:	3940052b 	ldrb	w11, [x9, #1]
    402056b0:	39400d2c 	ldrb	w12, [x9, #3]
    402056b4:	3940092d 	ldrb	w13, [x9, #2]
    402056b8:	3940152e 	ldrb	w14, [x9, #5]
    402056bc:	38404d2f 	ldrb	w15, [x9, #4]!
    402056c0:	39400930 	ldrb	w16, [x9, #2]
    402056c4:	39400d29 	ldrb	w9, [x9, #3]
    402056c8:	d370bdad 	lsl	x13, x13, #16
    402056cc:	aa0b214a 	orr	x10, x10, x11, lsl #8
    402056d0:	53103e10 	lsl	w16, w16, #16
    402056d4:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    402056d8:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    402056dc:	2a096209 	orr	w9, w16, w9, lsl #24
    402056e0:	aa0a018a 	orr	x10, x12, x10
    402056e4:	2a0b0129 	orr	w9, w9, w11
    402056e8:	aa098149 	orr	x9, x10, x9, lsl #32
    402056ec:	9e670125 	fmov	d5, x9
    402056f0:	52800029 	mov	w9, #0x1                   	// #1
    402056f4:	4e080d26 	dup	v6.2d, x9
    402056f8:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    402056fc:	2f08a484 	uxtl	v4.8h, v4.8b
    40205700:	6f10a485 	uxtl2	v5.4s, v4.8h
    40205704:	2f10a484 	uxtl	v4.4s, v4.4h
    40205708:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    4020570c:	2f20a490 	uxtl	v16.2d, v4.2s
    40205710:	6f20a484 	uxtl2	v4.2d, v4.4s
    40205714:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40205718:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    4020571c:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40205720:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40205724:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40205728:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    4020572c:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40205730:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40205734:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40205738:	540004e0 	b.eq	402057d4 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x2c8>  // b.none
    4020573c:	aa1703e9 	mov	x9, x23
    40205740:	0f05e7e4 	movi	v4.8b, #0xbf
    40205744:	38410d2a 	ldrb	w10, [x9, #16]!
    40205748:	3940052b 	ldrb	w11, [x9, #1]
    4020574c:	39400d2c 	ldrb	w12, [x9, #3]
    40205750:	3940092d 	ldrb	w13, [x9, #2]
    40205754:	3940152e 	ldrb	w14, [x9, #5]
    40205758:	38404d2f 	ldrb	w15, [x9, #4]!
    4020575c:	39400930 	ldrb	w16, [x9, #2]
    40205760:	39400d29 	ldrb	w9, [x9, #3]
    40205764:	d370bdad 	lsl	x13, x13, #16
    40205768:	aa0b214a 	orr	x10, x10, x11, lsl #8
    4020576c:	53103e10 	lsl	w16, w16, #16
    40205770:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40205774:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40205778:	2a096209 	orr	w9, w16, w9, lsl #24
    4020577c:	aa0a018a 	orr	x10, x12, x10
    40205780:	2a0b0129 	orr	w9, w9, w11
    40205784:	aa098149 	orr	x9, x10, x9, lsl #32
    40205788:	9e670125 	fmov	d5, x9
    4020578c:	52800029 	mov	w9, #0x1                   	// #1
    40205790:	4e080d26 	dup	v6.2d, x9
    40205794:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40205798:	2f08a484 	uxtl	v4.8h, v4.8b
    4020579c:	6f10a485 	uxtl2	v5.4s, v4.8h
    402057a0:	2f10a484 	uxtl	v4.4s, v4.4h
    402057a4:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    402057a8:	2f20a490 	uxtl	v16.2d, v4.2s
    402057ac:	6f20a484 	uxtl2	v4.2d, v4.4s
    402057b0:	2f20a4a5 	uxtl	v5.2d, v5.2s
    402057b4:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    402057b8:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    402057bc:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    402057c0:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    402057c4:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    402057c8:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    402057cc:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    402057d0:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    402057d4:	4ee28462 	add	v2.2d, v3.2d, v2.2d
    402057d8:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    402057dc:	eb0802df 	cmp	x22, x8
    402057e0:	4ee08440 	add	v0.2d, v2.2d, v0.2d
    402057e4:	5ef1b800 	addp	d0, v0.2d
    402057e8:	9e660000 	fmov	x0, d0
    402057ec:	54000100 	b.eq	4020580c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x300>  // b.none
    402057f0:	cb0802c9 	sub	x9, x22, x8
    402057f4:	8b0802e8 	add	x8, x23, x8
    402057f8:	38c0150a 	ldrsb	w10, [x8], #1
    402057fc:	3101055f 	cmn	w10, #0x41
    40205800:	9a80d400 	cinc	x0, x0, gt
    40205804:	f1000529 	subs	x9, x9, #0x1
    40205808:	54ffff81 	b.ne	402057f8 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x2ec>  // b.any
    4020580c:	8b1b001b 	add	x27, x0, x27
    40205810:	79402ab4 	ldrh	w20, [x21, #20]
    40205814:	eb14037f 	cmp	x27, x20
    40205818:	54ffeb42 	b.cs	40205580 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x74>  // b.hs, b.nlast
    4020581c:	f90007fc 	str	x28, [sp, #8]
    40205820:	37c0011a 	tbnz	w26, #24, 40205840 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x334>
    40205824:	531d7b48 	ubfx	w8, w26, #29, #2
    40205828:	4b1b029b 	sub	w27, w20, w27
    4020582c:	7100051f 	cmp	w8, #0x1
    40205830:	540003cc 	b.gt	402058a8 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x39c>
    40205834:	35000568 	cbnz	w8, 402058e0 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3d4>
    40205838:	2a1f03fc 	mov	w28, wzr
    4020583c:	1400002a 	b	402058e4 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3d8>
    40205840:	a940f2ba 	ldp	x26, x28, [x21, #8]
    40205844:	52b3fc08 	mov	w8, #0x9fe00000            	// #-1612709888
    40205848:	f94002b9 	ldr	x25, [x21]
    4020584c:	2a1803e2 	mov	w2, w24
    40205850:	aa1703e3 	mov	x3, x23
    40205854:	aa1603e4 	mov	x4, x22
    40205858:	0a080388 	and	w8, w28, w8
    4020585c:	aa1903e0 	mov	x0, x25
    40205860:	aa1a03e1 	mov	x1, x26
    40205864:	321c0508 	orr	w8, w8, #0x30
    40205868:	32030108 	orr	w8, w8, #0x20000000
    4020586c:	b90012a8 	str	w8, [x21, #16]
    40205870:	94000366 	bl	40206608 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix>
    40205874:	370006a0 	tbnz	w0, #0, 40205948 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    40205878:	2a1f03f6 	mov	w22, wzr
    4020587c:	4b1b0294 	sub	w20, w20, w27
    40205880:	12003ec8 	and	w8, w22, #0xffff
    40205884:	6b34211f 	cmp	w8, w20, uxth
    40205888:	540001a2 	b.cs	402058bc <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3b0>  // b.hs, b.nlast
    4020588c:	f9401348 	ldr	x8, [x26, #32]
    40205890:	aa1903e0 	mov	x0, x25
    40205894:	52800601 	mov	w1, #0x30                  	// #48
    40205898:	110006d6 	add	w22, w22, #0x1
    4020589c:	d63f0100 	blr	x8
    402058a0:	3607ff00 	tbz	w0, #0, 40205880 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x374>
    402058a4:	14000029 	b	40205948 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    402058a8:	7100091f 	cmp	w8, #0x2
    402058ac:	2a1b03fc 	mov	w28, w27
    402058b0:	540001a1 	b.ne	402058e4 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3d8>  // b.any
    402058b4:	53013f7c 	ubfx	w28, w27, #1, #15
    402058b8:	1400000b 	b	402058e4 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3d8>
    402058bc:	f9400f48 	ldr	x8, [x26, #24]
    402058c0:	f94007e1 	ldr	x1, [sp, #8]
    402058c4:	aa1903e0 	mov	x0, x25
    402058c8:	aa1303e2 	mov	x2, x19
    402058cc:	d63f0100 	blr	x8
    402058d0:	370003c0 	tbnz	w0, #0, 40205948 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    402058d4:	2a1f03f3 	mov	w19, wzr
    402058d8:	f9000abc 	str	x28, [x21, #16]
    402058dc:	1400001c 	b	4020594c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x440>
    402058e0:	2a1b03fc 	mov	w28, w27
    402058e4:	a94056b9 	ldp	x25, x21, [x21]
    402058e8:	2a1f03f4 	mov	w20, wzr
    402058ec:	12003e88 	and	w8, w20, #0xffff
    402058f0:	6b3c211f 	cmp	w8, w28, uxth
    402058f4:	54000102 	b.cs	40205914 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x408>  // b.hs, b.nlast
    402058f8:	f94012a8 	ldr	x8, [x21, #32]
    402058fc:	12005341 	and	w1, w26, #0x1fffff
    40205900:	aa1903e0 	mov	x0, x25
    40205904:	11000694 	add	w20, w20, #0x1
    40205908:	d63f0100 	blr	x8
    4020590c:	3607ff00 	tbz	w0, #0, 402058ec <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3e0>
    40205910:	1400000e 	b	40205948 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    40205914:	aa1903e0 	mov	x0, x25
    40205918:	aa1503e1 	mov	x1, x21
    4020591c:	2a1803e2 	mov	w2, w24
    40205920:	aa1703e3 	mov	x3, x23
    40205924:	aa1603e4 	mov	x4, x22
    40205928:	94000338 	bl	40206608 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix>
    4020592c:	370000e0 	tbnz	w0, #0, 40205948 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    40205930:	f9400ea8 	ldr	x8, [x21, #24]
    40205934:	f94007e1 	ldr	x1, [sp, #8]
    40205938:	aa1903e0 	mov	x0, x25
    4020593c:	aa1303e2 	mov	x2, x19
    40205940:	d63f0100 	blr	x8
    40205944:	36000160 	tbz	w0, #0, 40205970 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x464>
    40205948:	52800033 	mov	w19, #0x1                   	// #1
    4020594c:	2a1303e0 	mov	w0, w19
    40205950:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40205954:	a94557f6 	ldp	x22, x21, [sp, #80]
    40205958:	a9445ff8 	ldp	x24, x23, [sp, #64]
    4020595c:	a94367fa 	ldp	x26, x25, [sp, #48]
    40205960:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40205964:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40205968:	9101c3ff 	add	sp, sp, #0x70
    4020596c:	d65f03c0 	ret
    40205970:	2a1f03f4 	mov	w20, wzr
    40205974:	4b1c0376 	sub	w22, w27, w28
    40205978:	12003e88 	and	w8, w20, #0xffff
    4020597c:	6b36211f 	cmp	w8, w22, uxth
    40205980:	1a9f27f3 	cset	w19, cc  // cc = lo, ul, last
    40205984:	54fffe42 	b.cs	4020594c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x440>  // b.hs, b.nlast
    40205988:	f94012a8 	ldr	x8, [x21, #32]
    4020598c:	12005341 	and	w1, w26, #0x1fffff
    40205990:	aa1903e0 	mov	x0, x25
    40205994:	11000694 	add	w20, w20, #0x1
    40205998:	d63f0100 	blr	x8
    4020599c:	3607fee0 	tbz	w0, #0, 40205978 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x46c>
    402059a0:	17ffffeb 	b	4020594c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x440>

00000000402059a4 <_RNvNtCsbcsGJ9IzBgZ_4core6option13unwrap_failed>:
    402059a4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    402059a8:	910003fd 	mov	x29, sp
    402059ac:	aa0003e2 	mov	x2, x0
    402059b0:	d503201f 	nop
    402059b4:	10066d20 	adr	x0, 40212758 <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596+0xa8>
    402059b8:	52800561 	mov	w1, #0x2b                  	// #43
    402059bc:	9400000f 	bl	402059f8 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking5panic>

00000000402059c0 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>:
    402059c0:	d10103ff 	sub	sp, sp, #0x40
    402059c4:	a9037bfd 	stp	x29, x30, [sp, #48]
    402059c8:	9100c3fd 	add	x29, sp, #0x30
    402059cc:	910023e8 	add	x8, sp, #0x8
    402059d0:	d503201f 	nop
    402059d4:	100065e9 	adr	x9, 40206690 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>
    402059d8:	a90007e0 	stp	x0, x1, [sp]
    402059dc:	b0000020 	adrp	x0, 4020a000 <jnox_native_el0_image+0x3140>
    402059e0:	9124f400 	add	x0, x0, #0x93d
    402059e4:	a90127e8 	stp	x8, x9, [sp, #16]
    402059e8:	910003e8 	mov	x8, sp
    402059ec:	910043e1 	add	x1, sp, #0x10
    402059f0:	a90227e8 	stp	x8, x9, [sp, #32]
    402059f4:	94000006 	bl	40205a0c <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>

00000000402059f8 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking5panic>:
    402059f8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    402059fc:	910003fd 	mov	x29, sp
    40205a00:	52800028 	mov	w8, #0x1                   	// #1
    40205a04:	aa010501 	orr	x1, x8, x1, lsl #1
    40205a08:	94000001 	bl	40205a0c <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>

0000000040205a0c <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>:
    40205a0c:	d10103ff 	sub	sp, sp, #0x40
    40205a10:	a9037bfd 	stp	x29, x30, [sp, #48]
    40205a14:	9100c3fd 	add	x29, sp, #0x30
    40205a18:	910023e8 	add	x8, sp, #0x8
    40205a1c:	a90087e0 	stp	x0, x1, [sp, #8]
    40205a20:	910063e0 	add	x0, sp, #0x18
    40205a24:	a9018be8 	stp	x8, x2, [sp, #24]
    40205a28:	52800028 	mov	w8, #0x1                   	// #1
    40205a2c:	790053e8 	strh	w8, [sp, #40]
    40205a30:	97fff516 	bl	40202e88 <_RNvCsfLfy6EI15iL_7___rustc17rust_begin_unwind>

0000000040205a34 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars>:
    40205a34:	d10183ff 	sub	sp, sp, #0x60
    40205a38:	fd0023ea 	str	d10, [sp, #64]
    40205a3c:	6d0523e9 	stp	d9, d8, [sp, #80]
    40205a40:	91001c08 	add	x8, x0, #0x7
    40205a44:	927df10d 	and	x13, x8, #0xfffffffffffffff8
    40205a48:	cb0001ac 	sub	x12, x13, x0
    40205a4c:	eb0c002b 	subs	x11, x1, x12
    40205a50:	540000e2 	b.cs	40205a6c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x38>  // b.hs, b.nlast
    40205a54:	b4000721 	cbz	x1, 40205b38 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x104>
    40205a58:	f100203f 	cmp	x1, #0x8
    40205a5c:	54001b82 	b.cs	40205dcc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x398>  // b.hs, b.nlast
    40205a60:	aa1f03e9 	mov	x9, xzr
    40205a64:	aa1f03e8 	mov	x8, xzr
    40205a68:	140001d2 	b	402061b0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x77c>
    40205a6c:	d343fd69 	lsr	x9, x11, #3
    40205a70:	b4ffff29 	cbz	x9, 40205a54 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x20>
    40205a74:	eb0001bf 	cmp	x13, x0
    40205a78:	9240096a 	and	x10, x11, #0x7
    40205a7c:	aa1f03e8 	mov	x8, xzr
    40205a80:	54000100 	b.eq	40205aa0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x6c>  // b.none
    40205a84:	cb0d000d 	sub	x13, x0, x13
    40205a88:	aa0003ee 	mov	x14, x0
    40205a8c:	38c015cf 	ldrsb	w15, [x14], #1
    40205a90:	310105ff 	cmn	w15, #0x41
    40205a94:	9a88d508 	cinc	x8, x8, gt
    40205a98:	b10005ad 	adds	x13, x13, #0x1
    40205a9c:	54ffff83 	b.cc	40205a8c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x58>  // b.lo, b.ul, b.last
    40205aa0:	8b0c000e 	add	x14, x0, x12
    40205aa4:	b400056a 	cbz	x10, 40205b50 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x11c>
    40205aa8:	927ded6b 	and	x11, x11, #0x7ffffffffffffff8
    40205aac:	8b0b01cc 	add	x12, x14, x11
    40205ab0:	39c0018b 	ldrsb	w11, [x12]
    40205ab4:	3101057f 	cmn	w11, #0x41
    40205ab8:	1a9fd7eb 	cset	w11, gt
    40205abc:	f100055f 	cmp	x10, #0x1
    40205ac0:	540004a0 	b.eq	40205b54 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    40205ac4:	39c0058d 	ldrsb	w13, [x12, #1]
    40205ac8:	310105bf 	cmn	w13, #0x41
    40205acc:	9a8bd56b 	cinc	x11, x11, gt
    40205ad0:	f100095f 	cmp	x10, #0x2
    40205ad4:	54000400 	b.eq	40205b54 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    40205ad8:	39c0098d 	ldrsb	w13, [x12, #2]
    40205adc:	310105bf 	cmn	w13, #0x41
    40205ae0:	9a8bd56b 	cinc	x11, x11, gt
    40205ae4:	f1000d5f 	cmp	x10, #0x3
    40205ae8:	54000360 	b.eq	40205b54 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    40205aec:	39c00d8d 	ldrsb	w13, [x12, #3]
    40205af0:	310105bf 	cmn	w13, #0x41
    40205af4:	9a8bd56b 	cinc	x11, x11, gt
    40205af8:	f100115f 	cmp	x10, #0x4
    40205afc:	540002c0 	b.eq	40205b54 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    40205b00:	39c0118d 	ldrsb	w13, [x12, #4]
    40205b04:	310105bf 	cmn	w13, #0x41
    40205b08:	9a8bd56b 	cinc	x11, x11, gt
    40205b0c:	f100155f 	cmp	x10, #0x5
    40205b10:	54000220 	b.eq	40205b54 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    40205b14:	39c0158d 	ldrsb	w13, [x12, #5]
    40205b18:	310105bf 	cmn	w13, #0x41
    40205b1c:	9a8bd56b 	cinc	x11, x11, gt
    40205b20:	f100195f 	cmp	x10, #0x6
    40205b24:	54000180 	b.eq	40205b54 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    40205b28:	39c0198a 	ldrsb	w10, [x12, #6]
    40205b2c:	3101055f 	cmn	w10, #0x41
    40205b30:	9a8bd56b 	cinc	x11, x11, gt
    40205b34:	14000008 	b	40205b54 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>
    40205b38:	aa1f03e8 	mov	x8, xzr
    40205b3c:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40205b40:	aa0803e0 	mov	x0, x8
    40205b44:	fd4023ea 	ldr	d10, [sp, #64]
    40205b48:	910183ff 	add	sp, sp, #0x60
    40205b4c:	d65f03c0 	ret
    40205b50:	aa1f03eb 	mov	x11, xzr
    40205b54:	4f00e420 	movi	v0.16b, #0x1
    40205b58:	8b080168 	add	x8, x11, x8
    40205b5c:	5280180a 	mov	w10, #0xc0                  	// #192
    40205b60:	b20083eb 	mov	x11, #0x1000100010001       	// #281479271743489
    40205b64:	1400000c 	b	40205b94 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x160>
    40205b68:	aa1f03f1 	mov	x17, xzr
    40205b6c:	d348fe2f 	lsr	x15, x17, #8
    40205b70:	92009e30 	and	x16, x17, #0xff00ff00ff00ff
    40205b74:	8b0e018e 	add	x14, x12, x14
    40205b78:	cb0d0129 	sub	x9, x9, x13
    40205b7c:	92009def 	and	x15, x15, #0xff00ff00ff00ff
    40205b80:	8b1001ef 	add	x15, x15, x16
    40205b84:	9b0b7df0 	mul	x16, x15, x11
    40205b88:	924005af 	and	x15, x13, #0x3
    40205b8c:	8b50c108 	add	x8, x8, x16, lsr #48
    40205b90:	b5000d8f 	cbnz	x15, 40205d40 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x30c>
    40205b94:	b4fffd49 	cbz	x9, 40205b3c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x108>
    40205b98:	f103013f 	cmp	x9, #0xc0
    40205b9c:	aa0e03ec 	mov	x12, x14
    40205ba0:	9a8a312d 	csel	x13, x9, x10, cc  // cc = lo, ul, last
    40205ba4:	d37df1ae 	lsl	x14, x13, #3
    40205ba8:	f27b15d0 	ands	x16, x14, #0x7e0
    40205bac:	54fffde0 	b.eq	40205b68 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x134>  // b.none
    40205bb0:	d10081cf 	sub	x15, x14, #0x20
    40205bb4:	f10181ff 	cmp	x15, #0x60
    40205bb8:	54000082 	b.cs	40205bc8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x194>  // b.hs, b.nlast
    40205bbc:	aa1f03f1 	mov	x17, xzr
    40205bc0:	aa0c03ef 	mov	x15, x12
    40205bc4:	14000044 	b	40205cd4 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x2a0>
    40205bc8:	d345fdef 	lsr	x15, x15, #5
    40205bcc:	6f00e401 	movi	v1.2d, #0x0
    40205bd0:	6f00e402 	movi	v2.2d, #0x0
    40205bd4:	91010180 	add	x0, x12, #0x40
    40205bd8:	910005f1 	add	x17, x15, #0x1
    40205bdc:	927ee632 	and	x18, x17, #0xffffffffffffffc
    40205be0:	927ee621 	and	x1, x17, #0xffffffffffffffc
    40205be4:	8b12158f 	add	x15, x12, x18, lsl #5
    40205be8:	d1010002 	sub	x2, x0, #0x40
    40205bec:	4c400c10 	ld4	{v16.2d-v19.2d}, [x0]
    40205bf0:	f1001021 	subs	x1, x1, #0x4
    40205bf4:	91020000 	add	x0, x0, #0x80
    40205bf8:	4c400c43 	ld4	{v3.2d-v6.2d}, [x2]
    40205bfc:	6e205a07 	mvn	v7.16b, v16.16b
    40205c00:	6e205a35 	mvn	v21.16b, v17.16b
    40205c04:	6e205a5a 	mvn	v26.16b, v18.16b
    40205c08:	6e205876 	mvn	v22.16b, v3.16b
    40205c0c:	6e205897 	mvn	v23.16b, v4.16b
    40205c10:	6e2058b8 	mvn	v24.16b, v5.16b
    40205c14:	6f7a0614 	ushr	v20.2d, v16.2d, #6
    40205c18:	6f7a0639 	ushr	v25.2d, v17.2d, #6
    40205c1c:	6f7a065b 	ushr	v27.2d, v18.2d, #6
    40205c20:	6f7a047c 	ushr	v28.2d, v3.2d, #6
    40205c24:	6f7a049d 	ushr	v29.2d, v4.2d, #6
    40205c28:	6f7a04be 	ushr	v30.2d, v5.2d, #6
    40205c2c:	6f7906d6 	ushr	v22.2d, v22.2d, #7
    40205c30:	6f7906f7 	ushr	v23.2d, v23.2d, #7
    40205c34:	6f790718 	ushr	v24.2d, v24.2d, #7
    40205c38:	6f7904e7 	ushr	v7.2d, v7.2d, #7
    40205c3c:	6f7906b5 	ushr	v21.2d, v21.2d, #7
    40205c40:	6f79075a 	ushr	v26.2d, v26.2d, #7
    40205c44:	6e205a7f 	mvn	v31.16b, v19.16b
    40205c48:	6f7a0670 	ushr	v16.2d, v19.2d, #6
    40205c4c:	6e2058d1 	mvn	v17.16b, v6.16b
    40205c50:	4ebc1ed2 	orr	v18.16b, v22.16b, v28.16b
    40205c54:	4ebd1ef3 	orr	v19.16b, v23.16b, v29.16b
    40205c58:	4ebe1f16 	orr	v22.16b, v24.16b, v30.16b
    40205c5c:	4eb41ce7 	orr	v7.16b, v7.16b, v20.16b
    40205c60:	4eb91eb4 	orr	v20.16b, v21.16b, v25.16b
    40205c64:	4ebb1f55 	orr	v21.16b, v26.16b, v27.16b
    40205c68:	6f7a04c3 	ushr	v3.2d, v6.2d, #6
    40205c6c:	6f7907e4 	ushr	v4.2d, v31.2d, #7
    40205c70:	6f790625 	ushr	v5.2d, v17.2d, #7
    40205c74:	4e201e46 	and	v6.16b, v18.16b, v0.16b
    40205c78:	4e201e71 	and	v17.16b, v19.16b, v0.16b
    40205c7c:	4e201ed2 	and	v18.16b, v22.16b, v0.16b
    40205c80:	4e201ce7 	and	v7.16b, v7.16b, v0.16b
    40205c84:	4e201e93 	and	v19.16b, v20.16b, v0.16b
    40205c88:	4e201eb4 	and	v20.16b, v21.16b, v0.16b
    40205c8c:	4eb01c84 	orr	v4.16b, v4.16b, v16.16b
    40205c90:	4ea31ca3 	orr	v3.16b, v5.16b, v3.16b
    40205c94:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40205c98:	4ef18646 	add	v6.2d, v18.2d, v17.2d
    40205c9c:	4ee284e2 	add	v2.2d, v7.2d, v2.2d
    40205ca0:	4ef38685 	add	v5.2d, v20.2d, v19.2d
    40205ca4:	4e201c63 	and	v3.16b, v3.16b, v0.16b
    40205ca8:	4e201c84 	and	v4.16b, v4.16b, v0.16b
    40205cac:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40205cb0:	4ee284a2 	add	v2.2d, v5.2d, v2.2d
    40205cb4:	4ee18461 	add	v1.2d, v3.2d, v1.2d
    40205cb8:	4ee28482 	add	v2.2d, v4.2d, v2.2d
    40205cbc:	54fff961 	b.ne	40205be8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x1b4>  // b.any
    40205cc0:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40205cc4:	eb12023f 	cmp	x17, x18
    40205cc8:	5ef1b821 	addp	d1, v1.2d
    40205ccc:	9e660031 	fmov	x17, d1
    40205cd0:	54fff4e0 	b.eq	40205b6c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x138>  // b.none
    40205cd4:	8b100190 	add	x16, x12, x16
    40205cd8:	f9400df2 	ldr	x18, [x15, #24]
    40205cdc:	f9001ff2 	str	x18, [sp, #56]
    40205ce0:	f94009f2 	ldr	x18, [x15, #16]
    40205ce4:	f9001bf2 	str	x18, [sp, #48]
    40205ce8:	f94005f2 	ldr	x18, [x15, #8]
    40205cec:	f90017f2 	str	x18, [sp, #40]
    40205cf0:	f84205f2 	ldr	x18, [x15], #32
    40205cf4:	eb1001ff 	cmp	x15, x16
    40205cf8:	f90013f2 	str	x18, [sp, #32]
    40205cfc:	ad4107e2 	ldp	q2, q1, [sp, #32]
    40205d00:	6e205823 	mvn	v3.16b, v1.16b
    40205d04:	6e205844 	mvn	v4.16b, v2.16b
    40205d08:	6f7a0421 	ushr	v1.2d, v1.2d, #6
    40205d0c:	6f7a0442 	ushr	v2.2d, v2.2d, #6
    40205d10:	6f790463 	ushr	v3.2d, v3.2d, #7
    40205d14:	6f790484 	ushr	v4.2d, v4.2d, #7
    40205d18:	4ea21c82 	orr	v2.16b, v4.16b, v2.16b
    40205d1c:	4ea11c61 	orr	v1.16b, v3.16b, v1.16b
    40205d20:	4e201c21 	and	v1.16b, v1.16b, v0.16b
    40205d24:	4e201c42 	and	v2.16b, v2.16b, v0.16b
    40205d28:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40205d2c:	5ef1b821 	addp	d1, v1.2d
    40205d30:	9e660032 	fmov	x18, d1
    40205d34:	8b110251 	add	x17, x18, x17
    40205d38:	54fffd01 	b.ne	40205cd8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x2a4>  // b.any
    40205d3c:	17ffff8c 	b	40205b6c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x138>
    40205d40:	927e15a9 	and	x9, x13, #0xfc
    40205d44:	f10005ff 	cmp	x15, #0x1
    40205d48:	8b090d8a 	add	x10, x12, x9, lsl #3
    40205d4c:	f9400149 	ldr	x9, [x10]
    40205d50:	aa2903eb 	mvn	x11, x9
    40205d54:	d347fd6b 	lsr	x11, x11, #7
    40205d58:	aa491969 	orr	x9, x11, x9, lsr #6
    40205d5c:	9200c129 	and	x9, x9, #0x101010101010101
    40205d60:	540001e0 	b.eq	40205d9c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x368>  // b.none
    40205d64:	f940054b 	ldr	x11, [x10, #8]
    40205d68:	f10009ff 	cmp	x15, #0x2
    40205d6c:	aa2b03ec 	mvn	x12, x11
    40205d70:	d347fd8c 	lsr	x12, x12, #7
    40205d74:	aa4b198b 	orr	x11, x12, x11, lsr #6
    40205d78:	9200c16b 	and	x11, x11, #0x101010101010101
    40205d7c:	8b090169 	add	x9, x11, x9
    40205d80:	540000e0 	b.eq	40205d9c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x368>  // b.none
    40205d84:	f940094a 	ldr	x10, [x10, #16]
    40205d88:	aa2a03eb 	mvn	x11, x10
    40205d8c:	d347fd6b 	lsr	x11, x11, #7
    40205d90:	aa4a196a 	orr	x10, x11, x10, lsr #6
    40205d94:	9200c14a 	and	x10, x10, #0x101010101010101
    40205d98:	8b090149 	add	x9, x10, x9
    40205d9c:	d348fd2a 	lsr	x10, x9, #8
    40205da0:	92009d29 	and	x9, x9, #0xff00ff00ff00ff
    40205da4:	92009d4a 	and	x10, x10, #0xff00ff00ff00ff
    40205da8:	8b090149 	add	x9, x10, x9
    40205dac:	b20083ea 	mov	x10, #0x1000100010001       	// #281479271743489
    40205db0:	9b0a7d29 	mul	x9, x9, x10
    40205db4:	8b49c108 	add	x8, x8, x9, lsr #48
    40205db8:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40205dbc:	aa0803e0 	mov	x0, x8
    40205dc0:	fd4023ea 	ldr	d10, [sp, #64]
    40205dc4:	910183ff 	add	sp, sp, #0x60
    40205dc8:	d65f03c0 	ret
    40205dcc:	f100803f 	cmp	x1, #0x20
    40205dd0:	54000082 	b.cs	40205de0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x3ac>  // b.hs, b.nlast
    40205dd4:	aa1f03e9 	mov	x9, xzr
    40205dd8:	aa1f03e8 	mov	x8, xzr
    40205ddc:	140000bc 	b	402060cc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x698>
    40205de0:	6f00e400 	movi	v0.2d, #0x0
    40205de4:	4f05e7e3 	movi	v3.16b, #0xbf
    40205de8:	52800028 	mov	w8, #0x1                   	// #1
    40205dec:	6f00e402 	movi	v2.2d, #0x0
    40205df0:	6f00e407 	movi	v7.2d, #0x0
    40205df4:	927d042a 	and	x10, x1, #0x18
    40205df8:	6f00e401 	movi	v1.2d, #0x0
    40205dfc:	6f00e412 	movi	v18.2d, #0x0
    40205e00:	927be829 	and	x9, x1, #0xffffffffffffffe0
    40205e04:	6f00e405 	movi	v5.2d, #0x0
    40205e08:	6f00e406 	movi	v6.2d, #0x0
    40205e0c:	927be82b 	and	x11, x1, #0xffffffffffffffe0
    40205e10:	6f00e404 	movi	v4.2d, #0x0
    40205e14:	6f00e416 	movi	v22.2d, #0x0
    40205e18:	6f00e411 	movi	v17.2d, #0x0
    40205e1c:	6f00e410 	movi	v16.2d, #0x0
    40205e20:	6f00e417 	movi	v23.2d, #0x0
    40205e24:	6f00e414 	movi	v20.2d, #0x0
    40205e28:	6f00e415 	movi	v21.2d, #0x0
    40205e2c:	6f00e413 	movi	v19.2d, #0x0
    40205e30:	6f00e418 	movi	v24.2d, #0x0
    40205e34:	4e080d19 	dup	v25.2d, x8
    40205e38:	91004008 	add	x8, x0, #0x10
    40205e3c:	aa0803ec 	mov	x12, x8
    40205e40:	385f1112 	ldurb	w18, [x8, #-15]
    40205e44:	385f5102 	ldurb	w2, [x8, #-11]
    40205e48:	385f0d8d 	ldrb	w13, [x12, #-16]!
    40205e4c:	aa0c03ef 	mov	x15, x12
    40205e50:	3940098e 	ldrb	w14, [x12, #2]
    40205e54:	38404df0 	ldrb	w16, [x15, #4]!
    40205e58:	394009f1 	ldrb	w17, [x15, #2]
    40205e5c:	39400d83 	ldrb	w3, [x12, #3]
    40205e60:	39400def 	ldrb	w15, [x15, #3]
    40205e64:	d370bdce 	lsl	x14, x14, #16
    40205e68:	aa1221ad 	orr	x13, x13, x18, lsl #8
    40205e6c:	2a022210 	orr	w16, w16, w2, lsl #8
    40205e70:	53103e31 	lsl	w17, w17, #16
    40205e74:	f100816b 	subs	x11, x11, #0x20
    40205e78:	aa0361ce 	orr	x14, x14, x3, lsl #24
    40205e7c:	2a0f622f 	orr	w15, w17, w15, lsl #24
    40205e80:	aa0d01cd 	orr	x13, x14, x13
    40205e84:	2a1001ee 	orr	w14, w15, w16
    40205e88:	aa0e81ad 	orr	x13, x13, x14, lsl #32
    40205e8c:	f9000bed 	str	x13, [sp, #16]
    40205e90:	aa0c03ed 	mov	x13, x12
    40205e94:	38408dae 	ldrb	w14, [x13, #8]!
    40205e98:	39400daf 	ldrb	w15, [x13, #3]
    40205e9c:	394009b0 	ldrb	w16, [x13, #2]
    40205ea0:	38404db1 	ldrb	w17, [x13, #4]!
    40205ea4:	394009b2 	ldrb	w18, [x13, #2]
    40205ea8:	39402582 	ldrb	w2, [x12, #9]
    40205eac:	3940358c 	ldrb	w12, [x12, #13]
    40205eb0:	39400dad 	ldrb	w13, [x13, #3]
    40205eb4:	d370be10 	lsl	x16, x16, #16
    40205eb8:	53103e52 	lsl	w18, w18, #16
    40205ebc:	aa0221ce 	orr	x14, x14, x2, lsl #8
    40205ec0:	2a0c222c 	orr	w12, w17, w12, lsl #8
    40205ec4:	aa0f620f 	orr	x15, x16, x15, lsl #24
    40205ec8:	2a0d624d 	orr	w13, w18, w13, lsl #24
    40205ecc:	aa0e01ee 	orr	x14, x15, x14
    40205ed0:	2a0c01ac 	orr	w12, w13, w12
    40205ed4:	aa0c81cc 	orr	x12, x14, x12, lsl #32
    40205ed8:	f9000fec 	str	x12, [sp, #24]
    40205edc:	aa0803ec 	mov	x12, x8
    40205ee0:	3940090e 	ldrb	w14, [x8, #2]
    40205ee4:	38404d8f 	ldrb	w15, [x12, #4]!
    40205ee8:	39400990 	ldrb	w16, [x12, #2]
    40205eec:	3940050d 	ldrb	w13, [x8, #1]
    40205ef0:	39400111 	ldrb	w17, [x8]
    40205ef4:	39400d12 	ldrb	w18, [x8, #3]
    40205ef8:	39401502 	ldrb	w2, [x8, #5]
    40205efc:	39400d8c 	ldrb	w12, [x12, #3]
    40205f00:	d370bdce 	lsl	x14, x14, #16
    40205f04:	53103e10 	lsl	w16, w16, #16
    40205f08:	aa0d222d 	orr	x13, x17, x13, lsl #8
    40205f0c:	2a0221ef 	orr	w15, w15, w2, lsl #8
    40205f10:	3dc007fa 	ldr	q26, [sp, #16]
    40205f14:	aa1261ce 	orr	x14, x14, x18, lsl #24
    40205f18:	2a0c620c 	orr	w12, w16, w12, lsl #24
    40205f1c:	4e23375a 	cmgt	v26.16b, v26.16b, v3.16b
    40205f20:	aa0d01cd 	orr	x13, x14, x13
    40205f24:	2a0f018c 	orr	w12, w12, w15
    40205f28:	aa0c81ac 	orr	x12, x13, x12, lsl #32
    40205f2c:	aa0803ed 	mov	x13, x8
    40205f30:	6f08a75b 	uxtl2	v27.8h, v26.16b
    40205f34:	2f08a75a 	uxtl	v26.8h, v26.8b
    40205f38:	f90003ec 	str	x12, [sp]
    40205f3c:	38408dac 	ldrb	w12, [x13, #8]!
    40205f40:	39400dae 	ldrb	w14, [x13, #3]
    40205f44:	394009af 	ldrb	w15, [x13, #2]
    40205f48:	38404db0 	ldrb	w16, [x13, #4]!
    40205f4c:	394009b1 	ldrb	w17, [x13, #2]
    40205f50:	39402512 	ldrb	w18, [x8, #9]
    40205f54:	39403502 	ldrb	w2, [x8, #13]
    40205f58:	39400dad 	ldrb	w13, [x13, #3]
    40205f5c:	d370bdef 	lsl	x15, x15, #16
    40205f60:	6f10a77c 	uxtl2	v28.4s, v27.8h
    40205f64:	53103e31 	lsl	w17, w17, #16
    40205f68:	aa12218c 	orr	x12, x12, x18, lsl #8
    40205f6c:	2a022210 	orr	w16, w16, w2, lsl #8
    40205f70:	aa0e61ee 	orr	x14, x15, x14, lsl #24
    40205f74:	2f10a77b 	uxtl	v27.4s, v27.4h
    40205f78:	2f10a75e 	uxtl	v30.4s, v26.4h
    40205f7c:	2a0d622d 	orr	w13, w17, w13, lsl #24
    40205f80:	6f20a79d 	uxtl2	v29.2d, v28.4s
    40205f84:	6f10a75a 	uxtl2	v26.4s, v26.8h
    40205f88:	aa0c01cc 	orr	x12, x14, x12
    40205f8c:	2f20a79c 	uxtl	v28.2d, v28.2s
    40205f90:	91008108 	add	x8, x8, #0x20
    40205f94:	2a1001ad 	orr	w13, w13, w16
    40205f98:	6f20a768 	uxtl2	v8.2d, v27.4s
    40205f9c:	6f20a7c9 	uxtl2	v9.2d, v30.4s
    40205fa0:	aa0d818c 	orr	x12, x12, x13, lsl #32
    40205fa4:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    40205fa8:	6f20a74a 	uxtl2	v10.2d, v26.4s
    40205fac:	2f20a75a 	uxtl	v26.2d, v26.2s
    40205fb0:	2f20a77b 	uxtl	v27.2d, v27.2s
    40205fb4:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    40205fb8:	f90007ec 	str	x12, [sp, #8]
    40205fbc:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    40205fc0:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    40205fc4:	3dc003ff 	ldr	q31, [sp]
    40205fc8:	4efd86d6 	add	v22.2d, v22.2d, v29.2d
    40205fcc:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40205fd0:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    40205fd4:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    40205fd8:	4efc8484 	add	v4.2d, v4.2d, v28.2d
    40205fdc:	4e2337ff 	cmgt	v31.16b, v31.16b, v3.16b
    40205fe0:	4ee884c6 	add	v6.2d, v6.2d, v8.2d
    40205fe4:	2f20a7de 	uxtl	v30.2d, v30.2s
    40205fe8:	4eea8652 	add	v18.2d, v18.2d, v10.2d
    40205fec:	4ee984e7 	add	v7.2d, v7.2d, v9.2d
    40205ff0:	4efa8421 	add	v1.2d, v1.2d, v26.2d
    40205ff4:	4efb84a5 	add	v5.2d, v5.2d, v27.2d
    40205ff8:	6f08a7fd 	uxtl2	v29.8h, v31.16b
    40205ffc:	2f08a7ff 	uxtl	v31.8h, v31.8b
    40206000:	4e391fde 	and	v30.16b, v30.16b, v25.16b
    40206004:	6f10a7bc 	uxtl2	v28.4s, v29.8h
    40206008:	6f10a7e8 	uxtl2	v8.4s, v31.8h
    4020600c:	2f10a7bd 	uxtl	v29.4s, v29.4h
    40206010:	2f10a7fa 	uxtl	v26.4s, v31.4h
    40206014:	4efe8442 	add	v2.2d, v2.2d, v30.2d
    40206018:	2f20a79b 	uxtl	v27.2d, v28.2s
    4020601c:	6f20a79c 	uxtl2	v28.2d, v28.4s
    40206020:	2f20a7bf 	uxtl	v31.2d, v29.2s
    40206024:	6f20a509 	uxtl2	v9.2d, v8.4s
    40206028:	6f20a7bd 	uxtl2	v29.2d, v29.4s
    4020602c:	2f20a74a 	uxtl	v10.2d, v26.2s
    40206030:	6f20a75a 	uxtl2	v26.2d, v26.4s
    40206034:	2f20a508 	uxtl	v8.2d, v8.2s
    40206038:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    4020603c:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    40206040:	4e391fff 	and	v31.16b, v31.16b, v25.16b
    40206044:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    40206048:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    4020604c:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40206050:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    40206054:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    40206058:	4efc8718 	add	v24.2d, v24.2d, v28.2d
    4020605c:	4efb8673 	add	v19.2d, v19.2d, v27.2d
    40206060:	4eff8694 	add	v20.2d, v20.2d, v31.2d
    40206064:	4efd86b5 	add	v21.2d, v21.2d, v29.2d
    40206068:	4ee986f7 	add	v23.2d, v23.2d, v9.2d
    4020606c:	4eea8631 	add	v17.2d, v17.2d, v10.2d
    40206070:	4ee88610 	add	v16.2d, v16.2d, v8.2d
    40206074:	4efa8400 	add	v0.2d, v0.2d, v26.2d
    40206078:	54ffee21 	b.ne	40205e3c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x408>  // b.any
    4020607c:	4ef286e3 	add	v3.2d, v23.2d, v18.2d
    40206080:	4ef68712 	add	v18.2d, v24.2d, v22.2d
    40206084:	eb09003f 	cmp	x1, x9
    40206088:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    4020608c:	4ee28622 	add	v2.2d, v17.2d, v2.2d
    40206090:	4ee58685 	add	v5.2d, v20.2d, v5.2d
    40206094:	4ee686a6 	add	v6.2d, v21.2d, v6.2d
    40206098:	4ee18601 	add	v1.2d, v16.2d, v1.2d
    4020609c:	4ee48664 	add	v4.2d, v19.2d, v4.2d
    402060a0:	4ef28463 	add	v3.2d, v3.2d, v18.2d
    402060a4:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    402060a8:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    402060ac:	4ee68400 	add	v0.2d, v0.2d, v6.2d
    402060b0:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    402060b4:	4ee38400 	add	v0.2d, v0.2d, v3.2d
    402060b8:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    402060bc:	5ef1b800 	addp	d0, v0.2d
    402060c0:	9e660008 	fmov	x8, d0
    402060c4:	54ffd3c0 	b.eq	40205b3c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x108>  // b.none
    402060c8:	b400074a 	cbz	x10, 402061b0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x77c>
    402060cc:	6f00e400 	movi	v0.2d, #0x0
    402060d0:	6f00e401 	movi	v1.2d, #0x0
    402060d4:	aa0903ea 	mov	x10, x9
    402060d8:	0f05e7e2 	movi	v2.8b, #0xbf
    402060dc:	6f00e403 	movi	v3.2d, #0x0
    402060e0:	927df029 	and	x9, x1, #0xfffffffffffffff8
    402060e4:	6f00e404 	movi	v4.2d, #0x0
    402060e8:	4e081d00 	mov	v0.d[0], x8
    402060ec:	52800028 	mov	w8, #0x1                   	// #1
    402060f0:	4e080d05 	dup	v5.2d, x8
    402060f4:	cb090148 	sub	x8, x10, x9
    402060f8:	8b0a000a 	add	x10, x0, x10
    402060fc:	aa0a03ed 	mov	x13, x10
    40206100:	3940094c 	ldrb	w12, [x10, #2]
    40206104:	3940054b 	ldrb	w11, [x10, #1]
    40206108:	38404dae 	ldrb	w14, [x13, #4]!
    4020610c:	394009af 	ldrb	w15, [x13, #2]
    40206110:	39400150 	ldrb	w16, [x10]
    40206114:	39400d51 	ldrb	w17, [x10, #3]
    40206118:	d370bd8c 	lsl	x12, x12, #16
    4020611c:	39401552 	ldrb	w18, [x10, #5]
    40206120:	39400dad 	ldrb	w13, [x13, #3]
    40206124:	53103def 	lsl	w15, w15, #16
    40206128:	aa0b220b 	orr	x11, x16, x11, lsl #8
    4020612c:	aa11618c 	orr	x12, x12, x17, lsl #24
    40206130:	b1002108 	adds	x8, x8, #0x8
    40206134:	2a1221ce 	orr	w14, w14, w18, lsl #8
    40206138:	2a0d61ed 	orr	w13, w15, w13, lsl #24
    4020613c:	9100214a 	add	x10, x10, #0x8
    40206140:	aa0b018b 	orr	x11, x12, x11
    40206144:	2a0e01ac 	orr	w12, w13, w14
    40206148:	aa0c816b 	orr	x11, x11, x12, lsl #32
    4020614c:	9e670166 	fmov	d6, x11
    40206150:	0e2234c6 	cmgt	v6.8b, v6.8b, v2.8b
    40206154:	2f08a4c6 	uxtl	v6.8h, v6.8b
    40206158:	6f10a4c7 	uxtl2	v7.4s, v6.8h
    4020615c:	2f10a4c6 	uxtl	v6.4s, v6.4h
    40206160:	6f20a4f0 	uxtl2	v16.2d, v7.4s
    40206164:	2f20a4d1 	uxtl	v17.2d, v6.2s
    40206168:	6f20a4c6 	uxtl2	v6.2d, v6.4s
    4020616c:	2f20a4e7 	uxtl	v7.2d, v7.2s
    40206170:	4e251e10 	and	v16.16b, v16.16b, v5.16b
    40206174:	4e251e31 	and	v17.16b, v17.16b, v5.16b
    40206178:	4e251cc6 	and	v6.16b, v6.16b, v5.16b
    4020617c:	4e251ce7 	and	v7.16b, v7.16b, v5.16b
    40206180:	4ef08484 	add	v4.2d, v4.2d, v16.2d
    40206184:	4ee68463 	add	v3.2d, v3.2d, v6.2d
    40206188:	4ef18400 	add	v0.2d, v0.2d, v17.2d
    4020618c:	4ee78421 	add	v1.2d, v1.2d, v7.2d
    40206190:	54fffb61 	b.ne	402060fc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x6c8>  // b.any
    40206194:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    40206198:	4ee48461 	add	v1.2d, v3.2d, v4.2d
    4020619c:	eb09003f 	cmp	x1, x9
    402061a0:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    402061a4:	5ef1b800 	addp	d0, v0.2d
    402061a8:	9e660008 	fmov	x8, d0
    402061ac:	54ffcc80 	b.eq	40205b3c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x108>  // b.none
    402061b0:	cb09002a 	sub	x10, x1, x9
    402061b4:	8b090009 	add	x9, x0, x9
    402061b8:	38c0152b 	ldrsb	w11, [x9], #1
    402061bc:	3101057f 	cmn	w11, #0x41
    402061c0:	9a88d508 	cinc	x8, x8, gt
    402061c4:	f100054a 	subs	x10, x10, #0x1
    402061c8:	54ffff81 	b.ne	402061b8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x784>  // b.any
    402061cc:	17fffe5c 	b	40205b3c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x108>

00000000402061d0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8>:
    402061d0:	f1003c29 	subs	x9, x1, #0xf
    402061d4:	9a8933ea 	csel	x10, xzr, x9, cc  // cc = lo, ul, last
    402061d8:	b4001021 	cbz	x1, 402063dc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x20c>
    402061dc:	91001c0b 	add	x11, x0, #0x7
    402061e0:	aa1f03e9 	mov	x9, xzr
    402061e4:	d503201f 	nop
    402061e8:	7006330c 	adr	x12, 4021284b <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596+0x19b>
    402061ec:	927df16b 	and	x11, x11, #0xfffffffffffffff8
    402061f0:	cb00016b 	sub	x11, x11, x0
    402061f4:	14000004 	b	40206204 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x34>
    402061f8:	910005a9 	add	x9, x13, #0x1
    402061fc:	eb01013f 	cmp	x9, x1
    40206200:	54000ee2 	b.cs	402063dc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x20c>  // b.hs, b.nlast
    40206204:	38e9680d 	ldrsb	w13, [x0, x9]
    40206208:	37f802cd 	tbnz	w13, #31, 40206260 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x90>
    4020620c:	4b09016d 	sub	w13, w11, w9
    40206210:	f24009bf 	tst	x13, #0x7
    40206214:	54000080 	b.eq	40206224 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x54>  // b.none
    40206218:	91000529 	add	x9, x9, #0x1
    4020621c:	17fffff8 	b	402061fc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x2c>
    40206220:	91004129 	add	x9, x9, #0x10
    40206224:	eb0a013f 	cmp	x9, x10
    40206228:	540000c2 	b.cs	40206240 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x70>  // b.hs, b.nlast
    4020622c:	8b09000d 	add	x13, x0, x9
    40206230:	a94035ae 	ldp	x14, x13, [x13]
    40206234:	aa0e01ad 	orr	x13, x13, x14
    40206238:	f201c1bf 	tst	x13, #0x8080808080808080
    4020623c:	54ffff20 	b.eq	40206220 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x50>  // b.none
    40206240:	eb01013f 	cmp	x9, x1
    40206244:	54fffdc2 	b.cs	402061fc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x2c>  // b.hs, b.nlast
    40206248:	38e9680d 	ldrsb	w13, [x0, x9]
    4020624c:	37fffd8d 	tbnz	w13, #31, 402061fc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x2c>
    40206250:	91000529 	add	x9, x9, #0x1
    40206254:	eb09003f 	cmp	x1, x9
    40206258:	54ffff81 	b.ne	40206248 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x78>  // b.any
    4020625c:	14000060 	b	402063dc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x20c>
    40206260:	92401dae 	and	x14, x13, #0xff
    40206264:	12001dad 	and	w13, w13, #0xff
    40206268:	386e698e 	ldrb	w14, [x12, x14]
    4020626c:	710011df 	cmp	w14, #0x4
    40206270:	54000300 	b.eq	402062d0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x100>  // b.none
    40206274:	71000ddf 	cmp	w14, #0x3
    40206278:	54000140 	b.eq	402062a0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0xd0>  // b.none
    4020627c:	710009df 	cmp	w14, #0x2
    40206280:	54000c01 	b.ne	40206400 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x230>  // b.any
    40206284:	9100052d 	add	x13, x9, #0x1
    40206288:	eb0101bf 	cmp	x13, x1
    4020628c:	54000ae2 	b.cs	402063e8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x218>  // b.hs, b.nlast
    40206290:	38ed680e 	ldrsb	w14, [x0, x13]
    40206294:	310105df 	cmn	w14, #0x41
    40206298:	54fffb0d 	b.le	402061f8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x28>
    4020629c:	14000059 	b	40206400 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x230>
    402062a0:	9100052e 	add	x14, x9, #0x1
    402062a4:	eb0101df 	cmp	x14, x1
    402062a8:	54000a02 	b.cs	402063e8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x218>  // b.hs, b.nlast
    402062ac:	386e680e 	ldrb	w14, [x0, x14]
    402062b0:	710381bf 	cmp	w13, #0xe0
    402062b4:	54000260 	b.eq	40206300 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x130>  // b.none
    402062b8:	13001dce 	sxtb	w14, w14
    402062bc:	7103b5bf 	cmp	w13, #0xed
    402062c0:	54000301 	b.ne	40206320 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x150>  // b.any
    402062c4:	310185df 	cmn	w14, #0x61
    402062c8:	540006ed 	b.le	402063a4 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x1d4>
    402062cc:	1400004d 	b	40206400 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x230>
    402062d0:	9100052e 	add	x14, x9, #0x1
    402062d4:	eb0101df 	cmp	x14, x1
    402062d8:	54000882 	b.cs	402063e8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x218>  // b.hs, b.nlast
    402062dc:	386e680e 	ldrb	w14, [x0, x14]
    402062e0:	7103c1bf 	cmp	w13, #0xf0
    402062e4:	54000160 	b.eq	40206310 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x140>  // b.none
    402062e8:	13001dce 	sxtb	w14, w14
    402062ec:	7103d1bf 	cmp	w13, #0xf4
    402062f0:	54000241 	b.ne	40206338 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x168>  // b.any
    402062f4:	3101c5df 	cmn	w14, #0x71
    402062f8:	540002ed 	b.le	40206354 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x184>
    402062fc:	14000041 	b	40206400 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x230>
    40206300:	121b09cd 	and	w13, w14, #0xe0
    40206304:	710281bf 	cmp	w13, #0xa0
    40206308:	540004e0 	b.eq	402063a4 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x1d4>  // b.none
    4020630c:	1400003d 	b	40206400 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x230>
    40206310:	510241cd 	sub	w13, w14, #0x90
    40206314:	7100c1bf 	cmp	w13, #0x30
    40206318:	540001e3 	b.cc	40206354 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x184>  // b.lo, b.ul, b.last
    4020631c:	14000039 	b	40206400 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x230>
    40206320:	510385af 	sub	w15, w13, #0xe1
    40206324:	710031ff 	cmp	w15, #0xc
    40206328:	54000302 	b.cs	40206388 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x1b8>  // b.hs, b.nlast
    4020632c:	310101df 	cmn	w14, #0x40
    40206330:	540003ab 	b.lt	402063a4 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x1d4>  // b.tstop
    40206334:	14000033 	b	40206400 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x230>
    40206338:	5103c5ad 	sub	w13, w13, #0xf1
    4020633c:	710009bf 	cmp	w13, #0x2
    40206340:	5280002d 	mov	w13, #0x1                   	// #1
    40206344:	54000608 	b.hi	40206404 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x234>  // b.pmore
    40206348:	310101df 	cmn	w14, #0x40
    4020634c:	5280002e 	mov	w14, #0x1                   	// #1
    40206350:	540003aa 	b.ge	402063c4 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x1f4>  // b.tcont
    40206354:	9100092d 	add	x13, x9, #0x2
    40206358:	eb0101bf 	cmp	x13, x1
    4020635c:	54000462 	b.cs	402063e8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x218>  // b.hs, b.nlast
    40206360:	38ed680d 	ldrsb	w13, [x0, x13]
    40206364:	310105bf 	cmn	w13, #0x41
    40206368:	540002ac 	b.gt	402063bc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x1ec>
    4020636c:	91000d2d 	add	x13, x9, #0x3
    40206370:	eb0101bf 	cmp	x13, x1
    40206374:	540003a2 	b.cs	402063e8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x218>  // b.hs, b.nlast
    40206378:	38ed680e 	ldrsb	w14, [x0, x13]
    4020637c:	310101df 	cmn	w14, #0x40
    40206380:	54fff3cb 	b.lt	402061f8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x28>  // b.tstop
    40206384:	14000027 	b	40206420 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x250>
    40206388:	121f19ad 	and	w13, w13, #0xfe
    4020638c:	7103b9bf 	cmp	w13, #0xee
    40206390:	5280002d 	mov	w13, #0x1                   	// #1
    40206394:	54000381 	b.ne	40206404 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x234>  // b.any
    40206398:	310101df 	cmn	w14, #0x40
    4020639c:	5280002e 	mov	w14, #0x1                   	// #1
    402063a0:	5400012a 	b.ge	402063c4 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x1f4>  // b.tcont
    402063a4:	9100092d 	add	x13, x9, #0x2
    402063a8:	eb0101bf 	cmp	x13, x1
    402063ac:	540001e2 	b.cs	402063e8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x218>  // b.hs, b.nlast
    402063b0:	38ed680e 	ldrsb	w14, [x0, x13]
    402063b4:	310105df 	cmn	w14, #0x41
    402063b8:	54fff20d 	b.le	402061f8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str8converts9from_utf8+0x28>
    402063bc:	5280002e 	mov	w14, #0x1                   	// #1
    402063c0:	5280004d 	mov	w13, #0x2                   	// #2
    402063c4:	f9000509 	str	x9, [x8, #8]
    402063c8:	52800029 	mov	w9, #0x1                   	// #1
    402063cc:	3900410e 	strb	w14, [x8, #16]
    402063d0:	3900450d 	strb	w13, [x8, #17]
    402063d4:	f9000109 	str	x9, [x8]
    402063d8:	d65f03c0 	ret
    402063dc:	a9008500 	stp	x0, x1, [x8, #8]
    402063e0:	f900011f 	str	xzr, [x8]
    402063e4:	d65f03c0 	ret
    402063e8:	f9000509 	str	x9, [x8, #8]
    402063ec:	52800029 	mov	w9, #0x1                   	// #1
    402063f0:	3900411f 	strb	wzr, [x8, #16]
    402063f4:	3900450d 	strb	w13, [x8, #17]
    402063f8:	f9000109 	str	x9, [x8]
    402063fc:	d65f03c0 	ret
    40206400:	5280002d 	mov	w13, #0x1                   	// #1
    40206404:	5280002e 	mov	w14, #0x1                   	// #1
    40206408:	f9000509 	str	x9, [x8, #8]
    4020640c:	52800029 	mov	w9, #0x1                   	// #1
    40206410:	3900410e 	strb	w14, [x8, #16]
    40206414:	3900450d 	strb	w13, [x8, #17]
    40206418:	f9000109 	str	x9, [x8]
    4020641c:	d65f03c0 	ret
    40206420:	5280002e 	mov	w14, #0x1                   	// #1
    40206424:	5280006d 	mov	w13, #0x3                   	// #3
    40206428:	f9000509 	str	x9, [x8, #8]
    4020642c:	52800029 	mov	w9, #0x1                   	// #1
    40206430:	3900410e 	strb	w14, [x8, #16]
    40206434:	3900450d 	strb	w13, [x8, #17]
    40206438:	f9000109 	str	x9, [x8]
    4020643c:	d65f03c0 	ret

0000000040206440 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>:
    40206440:	d10103ff 	sub	sp, sp, #0x40
    40206444:	a9037bfd 	stp	x29, x30, [sp, #48]
    40206448:	9100c3fd 	add	x29, sp, #0x30
    4020644c:	eb02001f 	cmp	x0, x2
    40206450:	540001a9 	b.ls	40206484 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail+0x44>  // b.plast
    40206454:	910003e8 	mov	x8, sp
    40206458:	d503201f 	nop
    4020645c:	100011a9 	adr	x9, 40206690 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>
    40206460:	a9000be0 	stp	x0, x2, [sp]
    40206464:	90000020 	adrp	x0, 4020a000 <jnox_native_el0_image+0x3140>
    40206468:	91278400 	add	x0, x0, #0x9e1
    4020646c:	a90127e8 	stp	x8, x9, [sp, #16]
    40206470:	910023e8 	add	x8, sp, #0x8
    40206474:	a90227e8 	stp	x8, x9, [sp, #32]
    40206478:	910043e1 	add	x1, sp, #0x10
    4020647c:	aa0303e2 	mov	x2, x3
    40206480:	97fffd63 	bl	40205a0c <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>
    40206484:	eb02003f 	cmp	x1, x2
    40206488:	540001e8 	b.hi	402064c4 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail+0x84>  // b.pmore
    4020648c:	eb01001f 	cmp	x0, x1
    40206490:	540001a9 	b.ls	402064c4 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail+0x84>  // b.plast
    40206494:	910003e8 	mov	x8, sp
    40206498:	d503201f 	nop
    4020649c:	10000fa9 	adr	x9, 40206690 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>
    402064a0:	a90127e8 	stp	x8, x9, [sp, #16]
    402064a4:	910023e8 	add	x8, sp, #0x8
    402064a8:	a90007e0 	stp	x0, x1, [sp]
    402064ac:	90000020 	adrp	x0, 4020a000 <jnox_native_el0_image+0x3140>
    402064b0:	91245400 	add	x0, x0, #0x915
    402064b4:	a90227e8 	stp	x8, x9, [sp, #32]
    402064b8:	910043e1 	add	x1, sp, #0x10
    402064bc:	aa0303e2 	mov	x2, x3
    402064c0:	97fffd53 	bl	40205a0c <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>
    402064c4:	910003e8 	mov	x8, sp
    402064c8:	d503201f 	nop
    402064cc:	10000e29 	adr	x9, 40206690 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>
    402064d0:	a90127e8 	stp	x8, x9, [sp, #16]
    402064d4:	910023e8 	add	x8, sp, #0x8
    402064d8:	90000020 	adrp	x0, 4020a000 <jnox_native_el0_image+0x3140>
    402064dc:	9126a800 	add	x0, x0, #0x9aa
    402064e0:	a9000be1 	stp	x1, x2, [sp]
    402064e4:	a90227e8 	stp	x8, x9, [sp, #32]
    402064e8:	910043e1 	add	x1, sp, #0x10
    402064ec:	aa0303e2 	mov	x2, x3
    402064f0:	97fffd47 	bl	40205a0c <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>

00000000402064f4 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice6memchr14memchr_aligned>:
    402064f4:	91001c28 	add	x8, x1, #0x7
    402064f8:	12001c09 	and	w9, w0, #0xff
    402064fc:	927df108 	and	x8, x8, #0xfffffffffffffff8
    40206500:	eb010108 	subs	x8, x8, x1
    40206504:	54000081 	b.ne	40206514 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice6memchr14memchr_aligned+0x20>  // b.any
    40206508:	aa1f03ea 	mov	x10, xzr
    4020650c:	d100404b 	sub	x11, x2, #0x10
    40206510:	14000010 	b	40206550 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice6memchr14memchr_aligned+0x5c>
    40206514:	eb08005f 	cmp	x2, x8
    40206518:	9a88304a 	csel	x10, x2, x8, cc  // cc = lo, ul, last
    4020651c:	b4000122 	cbz	x2, 40206540 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice6memchr14memchr_aligned+0x4c>
    40206520:	aa1f03e8 	mov	x8, xzr
    40206524:	52800020 	mov	w0, #0x1                   	// #1
    40206528:	3868682b 	ldrb	w11, [x1, x8]
    4020652c:	6b09017f 	cmp	w11, w9
    40206530:	540004c0 	b.eq	402065c8 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice6memchr14memchr_aligned+0xd4>  // b.none
    40206534:	91000508 	add	x8, x8, #0x1
    40206538:	eb08015f 	cmp	x10, x8
    4020653c:	54ffff61 	b.ne	40206528 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice6memchr14memchr_aligned+0x34>  // b.any
    40206540:	d100404b 	sub	x11, x2, #0x10
    40206544:	aa0a03e8 	mov	x8, x10
    40206548:	eb0b015f 	cmp	x10, x11
    4020654c:	540002a8 	b.hi	402065a0 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice6memchr14memchr_aligned+0xac>  // b.pmore
    40206550:	b200c3e8 	mov	x8, #0x101010101010101     	// #72340172838076673
    40206554:	b200c3ed 	mov	x13, #0x101010101010101     	// #72340172838076673
    40206558:	b201c3ee 	mov	x14, #0x8080808080808080    	// #-9187201950435737472
    4020655c:	9b087d2c 	mul	x12, x9, x8
    40206560:	f280200d 	movk	x13, #0x100
    40206564:	aa0a03e8 	mov	x8, x10
    40206568:	8b08002a 	add	x10, x1, x8
    4020656c:	a940294f 	ldp	x15, x10, [x10]
    40206570:	ca0c01ef 	eor	x15, x15, x12
    40206574:	ca0c014a 	eor	x10, x10, x12
    40206578:	cb0f01b0 	sub	x16, x13, x15
    4020657c:	cb0a01b1 	sub	x17, x13, x10
    40206580:	aa0f020f 	orr	x15, x16, x15
    40206584:	aa0a022a 	orr	x10, x17, x10
    40206588:	8a0a01ea 	and	x10, x15, x10
    4020658c:	ea2a01df 	bics	xzr, x14, x10
    40206590:	54000081 	b.ne	402065a0 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice6memchr14memchr_aligned+0xac>  // b.any
    40206594:	91004108 	add	x8, x8, #0x10
    40206598:	eb0b011f 	cmp	x8, x11
    4020659c:	54fffe69 	b.ls	40206568 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice6memchr14memchr_aligned+0x74>  // b.plast
    402065a0:	eb08005f 	cmp	x2, x8
    402065a4:	54000100 	b.eq	402065c4 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice6memchr14memchr_aligned+0xd0>  // b.none
    402065a8:	52800020 	mov	w0, #0x1                   	// #1
    402065ac:	3868682a 	ldrb	w10, [x1, x8]
    402065b0:	6b09015f 	cmp	w10, w9
    402065b4:	540000a0 	b.eq	402065c8 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice6memchr14memchr_aligned+0xd4>  // b.none
    402065b8:	91000508 	add	x8, x8, #0x1
    402065bc:	eb08005f 	cmp	x2, x8
    402065c0:	54ffff61 	b.ne	402065ac <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice6memchr14memchr_aligned+0xb8>  // b.any
    402065c4:	aa1f03e0 	mov	x0, xzr
    402065c8:	aa0803e1 	mov	x1, x8
    402065cc:	d65f03c0 	ret

00000000402065d0 <_RNvNtNtCsbcsGJ9IzBgZ_4core9panicking11panic_const23panic_const_div_by_zero>:
    402065d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    402065d4:	910003fd 	mov	x29, sp
    402065d8:	aa0003e2 	mov	x2, x0
    402065dc:	d503201f 	nop
    402065e0:	70061b40 	adr	x0, 4021294b <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596+0x29b>
    402065e4:	52800661 	mov	w1, #0x33                  	// #51
    402065e8:	97fffd09 	bl	40205a0c <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>

00000000402065ec <_RNvNtNtCsbcsGJ9IzBgZ_4core9panicking11panic_const23panic_const_rem_by_zero>:
    402065ec:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    402065f0:	910003fd 	mov	x29, sp
    402065f4:	aa0003e2 	mov	x2, x0
    402065f8:	d503201f 	nop
    402065fc:	10061b40 	adr	x0, 40212964 <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596+0x2b4>
    40206600:	52800e61 	mov	w1, #0x73                  	// #115
    40206604:	97fffd02 	bl	40205a0c <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>

0000000040206608 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix>:
    40206608:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4020660c:	a90157f6 	stp	x22, x21, [sp, #16]
    40206610:	a9024ff4 	stp	x20, x19, [sp, #32]
    40206614:	910003fd 	mov	x29, sp
    40206618:	aa0403f3 	mov	x19, x4
    4020661c:	aa0303f4 	mov	x20, x3
    40206620:	aa0103f5 	mov	x21, x1
    40206624:	7144405f 	cmp	w2, #0x110, lsl #12
    40206628:	540001a0 	b.eq	4020665c <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix+0x54>  // b.none
    4020662c:	f94012a8 	ldr	x8, [x21, #32]
    40206630:	2a0203e1 	mov	w1, w2
    40206634:	aa0003f6 	mov	x22, x0
    40206638:	d63f0100 	blr	x8
    4020663c:	2a0003e8 	mov	w8, w0
    40206640:	aa1603e0 	mov	x0, x22
    40206644:	360000c8 	tbz	w8, #0, 4020665c <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix+0x54>
    40206648:	52800020 	mov	w0, #0x1                   	// #1
    4020664c:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40206650:	a94157f6 	ldp	x22, x21, [sp, #16]
    40206654:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40206658:	d65f03c0 	ret
    4020665c:	b4000114 	cbz	x20, 4020667c <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix+0x74>
    40206660:	f9400ea3 	ldr	x3, [x21, #24]
    40206664:	aa1403e1 	mov	x1, x20
    40206668:	aa1303e2 	mov	x2, x19
    4020666c:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40206670:	a94157f6 	ldp	x22, x21, [sp, #16]
    40206674:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40206678:	d61f0060 	br	x3
    4020667c:	2a1f03e0 	mov	w0, wzr
    40206680:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40206684:	a94157f6 	ldp	x22, x21, [sp, #16]
    40206688:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4020668c:	d65f03c0 	ret

0000000040206690 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>:
    40206690:	d100c3ff 	sub	sp, sp, #0x30
    40206694:	a9027bfd 	stp	x29, x30, [sp, #32]
    40206698:	910083fd 	add	x29, sp, #0x20
    4020669c:	f9400009 	ldr	x9, [x0]
    402066a0:	d503201f 	nop
    402066a4:	700606e8 	adr	x8, 40212783 <anon.2d7ce5cf085ee3b477e141eaed062738.8.llvm.14263334612035470596+0xd3>
    402066a8:	f10fa13f 	cmp	x9, #0x3e8
    402066ac:	540004e3 	b.cc	40206748 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0xb8>  // b.lo, b.ul, b.last
    402066b0:	d28b296c 	mov	x12, #0x594b                	// #22859
    402066b4:	910033ea 	add	x10, sp, #0xc
    402066b8:	5292cff1 	mov	w17, #0x967f                	// #38527
    402066bc:	f2a710cc 	movk	x12, #0x3886, lsl #16
    402066c0:	9280026b 	mov	x11, #0xffffffffffffffec    	// #-20
    402066c4:	5284e20d 	mov	w13, #0x2710                	// #10000
    402066c8:	f2d8bacc 	movk	x12, #0xc5d6, lsl #32
    402066cc:	52828f6e 	mov	w14, #0x147b                	// #5243
    402066d0:	91004d4f 	add	x15, x10, #0x13
    402066d4:	f2e68dac 	movk	x12, #0x346d, lsl #48
    402066d8:	52800c90 	mov	w16, #0x64                  	// #100
    402066dc:	72a01311 	movk	w17, #0x98, lsl #16
    402066e0:	aa0903ea 	mov	x10, x9
    402066e4:	aa0a03f2 	mov	x18, x10
    402066e8:	9bcc7d4a 	umulh	x10, x10, x12
    402066ec:	9100116b 	add	x11, x11, #0x4
    402066f0:	eb11025f 	cmp	x18, x17
    402066f4:	d34bfd4a 	lsr	x10, x10, #11
    402066f8:	1b0dc940 	msub	w0, w10, w13, w18
    402066fc:	53023c02 	ubfx	w2, w0, #2, #14
    40206700:	1b0e7c42 	mul	w2, w2, w14
    40206704:	53117c42 	lsr	w2, w2, #17
    40206708:	1b108040 	msub	w0, w2, w16, w0
    4020670c:	8b224502 	add	x2, x8, w2, uxtw #1
    40206710:	39400043 	ldrb	w3, [x2]
    40206714:	39400442 	ldrb	w2, [x2, #1]
    40206718:	8b202500 	add	x0, x8, w0, uxth #1
    4020671c:	381fd1e3 	sturb	w3, [x15, #-3]
    40206720:	39400003 	ldrb	w3, [x0]
    40206724:	39400400 	ldrb	w0, [x0, #1]
    40206728:	381fe1e2 	sturb	w2, [x15, #-2]
    4020672c:	381ff1e3 	sturb	w3, [x15, #-1]
    40206730:	381fc5e0 	strb	w0, [x15], #-4
    40206734:	54fffd88 	b.hi	402066e4 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x54>  // b.pmore
    40206738:	cb0b03eb 	neg	x11, x11
    4020673c:	f100255f 	cmp	x10, #0x9
    40206740:	540000c8 	b.hi	40206758 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0xc8>  // b.pmore
    40206744:	14000015 	b	40206798 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x108>
    40206748:	5280028b 	mov	w11, #0x14                  	// #20
    4020674c:	aa0903ea 	mov	x10, x9
    40206750:	f100253f 	cmp	x9, #0x9
    40206754:	54000229 	b.ls	40206798 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x108>  // b.plast
    40206758:	53023d4c 	ubfx	w12, w10, #2, #14
    4020675c:	52828f6d 	mov	w13, #0x147b                	// #5243
    40206760:	910033ef 	add	x15, sp, #0xc
    40206764:	1b0d7d8c 	mul	w12, w12, w13
    40206768:	52800c8d 	mov	w13, #0x64                  	// #100
    4020676c:	53117d8c 	lsr	w12, w12, #17
    40206770:	1b0da98a 	msub	w10, w12, w13, w10
    40206774:	d100096d 	sub	x13, x11, #0x2
    40206778:	8b0b01eb 	add	x11, x15, x11
    4020677c:	8b2a250a 	add	x10, x8, w10, uxth #1
    40206780:	3940014e 	ldrb	w14, [x10]
    40206784:	3940054a 	ldrb	w10, [x10, #1]
    40206788:	382d69ee 	strb	w14, [x15, x13]
    4020678c:	381ff16a 	sturb	w10, [x11, #-1]
    40206790:	aa0c03ea 	mov	x10, x12
    40206794:	aa0d03eb 	mov	x11, x13
    40206798:	b4000049 	cbz	x9, 402067a0 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x110>
    4020679c:	b40000ca 	cbz	x10, 402067b4 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x124>
    402067a0:	8b0a0508 	add	x8, x8, x10, lsl #1
    402067a4:	d100056b 	sub	x11, x11, #0x1
    402067a8:	910033e9 	add	x9, sp, #0xc
    402067ac:	39400508 	ldrb	w8, [x8, #1]
    402067b0:	382b6928 	strb	w8, [x9, x11]
    402067b4:	52800288 	mov	w8, #0x14                  	// #20
    402067b8:	aa0103e0 	mov	x0, x1
    402067bc:	52800021 	mov	w1, #0x1                   	// #1
    402067c0:	cb0b0105 	sub	x5, x8, x11
    402067c4:	910033e8 	add	x8, sp, #0xc
    402067c8:	52800022 	mov	w2, #0x1                   	// #1
    402067cc:	8b0b0104 	add	x4, x8, x11
    402067d0:	aa1f03e3 	mov	x3, xzr
    402067d4:	97fffb4e 	bl	4020550c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral>
    402067d8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    402067dc:	9100c3ff 	add	sp, sp, #0x30
    402067e0:	d65f03c0 	ret

00000000402067e4 <memcmp>:
    402067e4:	b40000e2 	cbz	x2, 40206800 <memcmp+0x1c>
    402067e8:	38401408 	ldrb	w8, [x0], #1
    402067ec:	38401429 	ldrb	w9, [x1], #1
    402067f0:	6b090108 	subs	w8, w8, w9
    402067f4:	54000081 	b.ne	40206804 <memcmp+0x20>  // b.any
    402067f8:	f1000442 	subs	x2, x2, #0x1
    402067fc:	54ffff61 	b.ne	402067e8 <memcmp+0x4>  // b.any
    40206800:	2a1f03e8 	mov	w8, wzr
    40206804:	2a0803e0 	mov	w0, w8
    40206808:	d65f03c0 	ret

000000004020680c <__udivti3>:
    4020680c:	d100c3ff 	sub	sp, sp, #0x30
    40206810:	a9027bfd 	stp	x29, x30, [sp, #32]
    40206814:	910083fd 	add	x29, sp, #0x20
    40206818:	910003e8 	mov	x8, sp
    4020681c:	94000005 	bl	40206830 <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem>
    40206820:	a94007e0 	ldp	x0, x1, [sp]
    40206824:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40206828:	9100c3ff 	add	sp, sp, #0x30
    4020682c:	d65f03c0 	ret

0000000040206830 <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem>:
    40206830:	dac01049 	clz	x9, x2
    40206834:	dac0106a 	clz	x10, x3
    40206838:	f100007f 	cmp	x3, #0x0
    4020683c:	11010129 	add	w9, w9, #0x40
    40206840:	dac0100c 	clz	x12, x0
    40206844:	1a89114b 	csel	w11, w10, w9, ne  // ne = any
    40206848:	dac01029 	clz	x9, x1
    4020684c:	1101018a 	add	w10, w12, #0x40
    40206850:	f100003f 	cmp	x1, #0x0
    40206854:	1a8a112f 	csel	w15, w9, w10, ne  // ne = any
    40206858:	6b0f0169 	subs	w9, w11, w15
    4020685c:	54000149 	b.ls	40206884 <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem+0x54>  // b.plast
    40206860:	7100fdff 	cmp	w15, #0x3f
    40206864:	540001c9 	b.ls	4020689c <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem+0x6c>  // b.plast
    40206868:	9ac20809 	udiv	x9, x0, x2
    4020686c:	aa1f03ea 	mov	x10, xzr
    40206870:	aa1f03e1 	mov	x1, xzr
    40206874:	9b028120 	msub	x0, x9, x2, x0
    40206878:	a9002909 	stp	x9, x10, [x8]
    4020687c:	a9010500 	stp	x0, x1, [x8, #16]
    40206880:	d65f03c0 	ret
    40206884:	eb02001f 	cmp	x0, x2
    40206888:	fa03003f 	sbcs	xzr, x1, x3
    4020688c:	54000282 	b.cs	402068dc <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem+0xac>  // b.hs, b.nlast
    40206890:	a9007d1f 	stp	xzr, xzr, [x8]
    40206894:	a9010500 	stp	x0, x1, [x8, #16]
    40206898:	d65f03c0 	ret
    4020689c:	71017d7f 	cmp	w11, #0x5f
    402068a0:	540002a9 	b.ls	402068f4 <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem+0xc4>  // b.plast
    402068a4:	2a0203e9 	mov	w9, w2
    402068a8:	9ac9082a 	udiv	x10, x1, x9
    402068ac:	1b02854b 	msub	w11, w10, w2, w1
    402068b0:	93c0816b 	extr	x11, x11, x0, #32
    402068b4:	9ac9096c 	udiv	x12, x11, x9
    402068b8:	1b02ad8b 	msub	w11, w12, w2, w11
    402068bc:	aa4c814a 	orr	x10, x10, x12, lsr #32
    402068c0:	b3607d60 	bfi	x0, x11, #32, #32
    402068c4:	9ac9080b 	udiv	x11, x0, x9
    402068c8:	9b098160 	msub	x0, x11, x9, x0
    402068cc:	aa0c8169 	orr	x9, x11, x12, lsl #32
    402068d0:	a9002909 	stp	x9, x10, [x8]
    402068d4:	a9017d00 	stp	x0, xzr, [x8, #16]
    402068d8:	d65f03c0 	ret
    402068dc:	eb020000 	subs	x0, x0, x2
    402068e0:	52800029 	mov	w9, #0x1                   	// #1
    402068e4:	da030021 	sbc	x1, x1, x3
    402068e8:	a9007d09 	stp	x9, xzr, [x8]
    402068ec:	a9010500 	stp	x0, x1, [x8, #16]
    402068f0:	d65f03c0 	ret
    402068f4:	7100813f 	cmp	w9, #0x20
    402068f8:	54000422 	b.cs	4020697c <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem+0x14c>  // b.hs, b.nlast
    402068fc:	d37ff829 	lsl	x9, x1, #1
    40206900:	5280080a 	mov	w10, #0x40                  	// #64
    40206904:	d37ff86c 	lsl	x12, x3, #1
    40206908:	510005eb 	sub	w11, w15, #0x1
    4020690c:	4b0f014a 	sub	w10, w10, w15
    40206910:	9acb2129 	lsl	x9, x9, x11
    40206914:	9aca240d 	lsr	x13, x0, x10
    40206918:	9acb218b 	lsl	x11, x12, x11
    4020691c:	9aca244c 	lsr	x12, x2, x10
    40206920:	9aca242e 	lsr	x14, x1, x10
    40206924:	9aca246f 	lsr	x15, x3, x10
    40206928:	f27a015f 	tst	x10, #0x40
    4020692c:	aa0d0129 	orr	x9, x9, x13
    40206930:	aa0c016a 	orr	x10, x11, x12
    40206934:	9a8911c9 	csel	x9, x14, x9, ne  // ne = any
    40206938:	9a8a11ea 	csel	x10, x15, x10, ne  // ne = any
    4020693c:	9aca0929 	udiv	x9, x9, x10
    40206940:	9bc97c4a 	umulh	x10, x2, x9
    40206944:	9b097c6b 	mul	x11, x3, x9
    40206948:	9bc97c6d 	umulh	x13, x3, x9
    4020694c:	9b097c4c 	mul	x12, x2, x9
    40206950:	ab0b014b 	adds	x11, x10, x11
    40206954:	9a8d35aa 	cinc	x10, x13, cs  // cs = hs, nlast
    40206958:	b500090a 	cbnz	x10, 40206a78 <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem+0x248>
    4020695c:	eb0c001f 	cmp	x0, x12
    40206960:	fa0b003f 	sbcs	xzr, x1, x11
    40206964:	540008a3 	b.cc	40206a78 <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem+0x248>  // b.lo, b.ul, b.last
    40206968:	eb0c0000 	subs	x0, x0, x12
    4020696c:	da0b0021 	sbc	x1, x1, x11
    40206970:	a9007d09 	stp	x9, xzr, [x8]
    40206974:	a9010500 	stp	x0, x1, [x8, #16]
    40206978:	d65f03c0 	ret
    4020697c:	52800c0d 	mov	w13, #0x60                  	// #96
    40206980:	d37ff86c 	lsl	x12, x3, #1
    40206984:	5101856e 	sub	w14, w11, #0x61
    40206988:	4b0b01ad 	sub	w13, w13, w11
    4020698c:	aa1f03e9 	mov	x9, xzr
    40206990:	aa1f03ea 	mov	x10, xzr
    40206994:	9ace218e 	lsl	x14, x12, x14
    40206998:	9acd2450 	lsr	x16, x2, x13
    4020699c:	9acd2471 	lsr	x17, x3, x13
    402069a0:	f27a01bf 	tst	x13, #0x40
    402069a4:	aa1001ce 	orr	x14, x14, x16
    402069a8:	52800810 	mov	w16, #0x40                  	// #64
    402069ac:	9a8e122e 	csel	x14, x17, x14, ne  // ne = any
    402069b0:	2a0e03ee 	mov	w14, w14
    402069b4:	910005ce 	add	x14, x14, #0x1
    402069b8:	d37ff832 	lsl	x18, x1, #1
    402069bc:	4b0f0211 	sub	w17, w16, w15
    402069c0:	510005ef 	sub	w15, w15, #0x1
    402069c4:	9ad12424 	lsr	x4, x1, x17
    402069c8:	f27a023f 	tst	x17, #0x40
    402069cc:	9acf224f 	lsl	x15, x18, x15
    402069d0:	9ad12412 	lsr	x18, x0, x17
    402069d4:	aa1201ef 	orr	x15, x15, x18
    402069d8:	9a8f1092 	csel	x18, x4, x15, ne  // ne = any
    402069dc:	6b0d022f 	subs	w15, w17, w13
    402069e0:	540005c3 	b.cc	40206a98 <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem+0x268>  // b.lo, b.ul, b.last
    402069e4:	9ace0a51 	udiv	x17, x18, x14
    402069e8:	2a2f03e6 	mvn	w6, w15
    402069ec:	f27a01ff 	tst	x15, #0x40
    402069f0:	9bd17c52 	umulh	x18, x2, x17
    402069f4:	d341fe25 	lsr	x5, x17, #1
    402069f8:	9b117c44 	mul	x4, x2, x17
    402069fc:	9ac624a5 	lsr	x5, x5, x6
    40206a00:	9b114872 	madd	x18, x3, x17, x18
    40206a04:	9acf2231 	lsl	x17, x17, x15
    40206a08:	d341fc87 	lsr	x7, x4, #1
    40206a0c:	9ac624e6 	lsr	x6, x7, x6
    40206a10:	9acf2252 	lsl	x18, x18, x15
    40206a14:	9acf208f 	lsl	x15, x4, x15
    40206a18:	9a851224 	csel	x4, x17, x5, ne  // ne = any
    40206a1c:	9a9113f1 	csel	x17, xzr, x17, ne  // ne = any
    40206a20:	aa060252 	orr	x18, x18, x6
    40206a24:	9a9211f2 	csel	x18, x15, x18, ne  // ne = any
    40206a28:	9a8f13ef 	csel	x15, xzr, x15, ne  // ne = any
    40206a2c:	ab090229 	adds	x9, x17, x9
    40206a30:	9a0a008a 	adc	x10, x4, x10
    40206a34:	eb0f0000 	subs	x0, x0, x15
    40206a38:	fa120021 	sbcs	x1, x1, x18
    40206a3c:	dac0100f 	clz	x15, x0
    40206a40:	dac01031 	clz	x17, x1
    40206a44:	110101ef 	add	w15, w15, #0x40
    40206a48:	1a8f122f 	csel	w15, w17, w15, ne  // ne = any
    40206a4c:	6b0f017f 	cmp	w11, w15
    40206a50:	54000549 	b.ls	40206af8 <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem+0x2c8>  // b.plast
    40206a54:	7100fdff 	cmp	w15, #0x3f
    40206a58:	54fffb09 	b.ls	402069b8 <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem+0x188>  // b.plast
    40206a5c:	9ac2080b 	udiv	x11, x0, x2
    40206a60:	9b028160 	msub	x0, x11, x2, x0
    40206a64:	ab0b0129 	adds	x9, x9, x11
    40206a68:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40206a6c:	a9002909 	stp	x9, x10, [x8]
    40206a70:	a9017d00 	stp	x0, xzr, [x8, #16]
    40206a74:	d65f03c0 	ret
    40206a78:	ab00004d 	adds	x13, x2, x0
    40206a7c:	d1000529 	sub	x9, x9, #0x1
    40206a80:	9a01006e 	adc	x14, x3, x1
    40206a84:	eb0c01a0 	subs	x0, x13, x12
    40206a88:	da0b01c1 	sbc	x1, x14, x11
    40206a8c:	a9007d09 	stp	x9, xzr, [x8]
    40206a90:	a9010500 	stp	x0, x1, [x8, #16]
    40206a94:	d65f03c0 	ret
    40206a98:	2a3103eb 	mvn	w11, w17
    40206a9c:	9ad1244d 	lsr	x13, x2, x17
    40206aa0:	f27a023f 	tst	x17, #0x40
    40206aa4:	9acb218b 	lsl	x11, x12, x11
    40206aa8:	9ad1246c 	lsr	x12, x3, x17
    40206aac:	aa0d016b 	orr	x11, x11, x13
    40206ab0:	9a8b118b 	csel	x11, x12, x11, ne  // ne = any
    40206ab4:	9acb0a4d 	udiv	x13, x18, x11
    40206ab8:	9bcd7c4b 	umulh	x11, x2, x13
    40206abc:	9b0d7c4c 	mul	x12, x2, x13
    40206ac0:	9b0d2c6b 	madd	x11, x3, x13, x11
    40206ac4:	eb0c001f 	cmp	x0, x12
    40206ac8:	fa0b003f 	sbcs	xzr, x1, x11
    40206acc:	540002a2 	b.cs	40206b20 <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem+0x2f0>  // b.hs, b.nlast
    40206ad0:	d10005ad 	sub	x13, x13, #0x1
    40206ad4:	ab0d0129 	adds	x9, x9, x13
    40206ad8:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40206adc:	ab02000d 	adds	x13, x0, x2
    40206ae0:	9a03002e 	adc	x14, x1, x3
    40206ae4:	eb0c01a0 	subs	x0, x13, x12
    40206ae8:	da0b01c1 	sbc	x1, x14, x11
    40206aec:	a9002909 	stp	x9, x10, [x8]
    40206af0:	a9010500 	stp	x0, x1, [x8, #16]
    40206af4:	d65f03c0 	ret
    40206af8:	eb02001f 	cmp	x0, x2
    40206afc:	fa03003f 	sbcs	xzr, x1, x3
    40206b00:	54ffebc3 	b.cc	40206878 <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem+0x48>  // b.lo, b.ul, b.last
    40206b04:	b1000529 	adds	x9, x9, #0x1
    40206b08:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40206b0c:	eb020000 	subs	x0, x0, x2
    40206b10:	da030021 	sbc	x1, x1, x3
    40206b14:	a9002909 	stp	x9, x10, [x8]
    40206b18:	a9010500 	stp	x0, x1, [x8, #16]
    40206b1c:	d65f03c0 	ret
    40206b20:	ab0d0129 	adds	x9, x9, x13
    40206b24:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40206b28:	eb0c0000 	subs	x0, x0, x12
    40206b2c:	da0b0021 	sbc	x1, x1, x11
    40206b30:	a9002909 	stp	x9, x10, [x8]
    40206b34:	a9010500 	stp	x0, x1, [x8, #16]
    40206b38:	d65f03c0 	ret

0000000040206b3c <memcpy>:
    40206b3c:	f100405f 	cmp	x2, #0x10
    40206b40:	54000723 	b.cc	40206c24 <memcpy+0xe8>  // b.lo, b.ul, b.last
    40206b44:	cb0003ec 	neg	x12, x0
    40206b48:	92400988 	and	x8, x12, #0x7
    40206b4c:	8b080009 	add	x9, x0, x8
    40206b50:	eb09001f 	cmp	x0, x9
    40206b54:	54000422 	b.cs	40206bd8 <memcpy+0x9c>  // b.hs, b.nlast
    40206b58:	f100111f 	cmp	x8, #0x4
    40206b5c:	aa0003ea 	mov	x10, x0
    40206b60:	aa0103eb 	mov	x11, x1
    40206b64:	54000323 	b.cc	40206bc8 <memcpy+0x8c>  // b.lo, b.ul, b.last
    40206b68:	cb01000a 	sub	x10, x0, x1
    40206b6c:	aa0103eb 	mov	x11, x1
    40206b70:	f100815f 	cmp	x10, #0x20
    40206b74:	aa0003ea 	mov	x10, x0
    40206b78:	54000283 	b.cc	40206bc8 <memcpy+0x8c>  // b.lo, b.ul, b.last
    40206b7c:	927e018c 	and	x12, x12, #0x4
    40206b80:	aa0003ed 	mov	x13, x0
    40206b84:	aa0103ee 	mov	x14, x1
    40206b88:	8b0c000a 	add	x10, x0, x12
    40206b8c:	8b0c002b 	add	x11, x1, x12
    40206b90:	aa0c03ef 	mov	x15, x12
    40206b94:	39400dd0 	ldrb	w16, [x14, #3]
    40206b98:	394009d1 	ldrb	w17, [x14, #2]
    40206b9c:	f10011ef 	subs	x15, x15, #0x4
    40206ba0:	394001d2 	ldrb	w18, [x14]
    40206ba4:	394005c3 	ldrb	w3, [x14, #1]
    40206ba8:	910011ce 	add	x14, x14, #0x4
    40206bac:	39000db0 	strb	w16, [x13, #3]
    40206bb0:	390009b1 	strb	w17, [x13, #2]
    40206bb4:	390005a3 	strb	w3, [x13, #1]
    40206bb8:	380045b2 	strb	w18, [x13], #4
    40206bbc:	54fffec1 	b.ne	40206b94 <memcpy+0x58>  // b.any
    40206bc0:	eb0c011f 	cmp	x8, x12
    40206bc4:	540000a0 	b.eq	40206bd8 <memcpy+0x9c>  // b.none
    40206bc8:	3840156c 	ldrb	w12, [x11], #1
    40206bcc:	3800154c 	strb	w12, [x10], #1
    40206bd0:	eb09015f 	cmp	x10, x9
    40206bd4:	54ffffa1 	b.ne	40206bc8 <memcpy+0x8c>  // b.any
    40206bd8:	cb08004b 	sub	x11, x2, x8
    40206bdc:	8b08002a 	add	x10, x1, x8
    40206be0:	927df16c 	and	x12, x11, #0xfffffffffffffff8
    40206be4:	f240095f 	tst	x10, #0x7
    40206be8:	8b0c0128 	add	x8, x9, x12
    40206bec:	540007a1 	b.ne	40206ce0 <memcpy+0x1a4>  // b.any
    40206bf0:	eb08013f 	cmp	x9, x8
    40206bf4:	540000c2 	b.cs	40206c0c <memcpy+0xd0>  // b.hs, b.nlast
    40206bf8:	aa0a03ed 	mov	x13, x10
    40206bfc:	f84085ae 	ldr	x14, [x13], #8
    40206c00:	f800852e 	str	x14, [x9], #8
    40206c04:	eb08013f 	cmp	x9, x8
    40206c08:	54ffffa3 	b.cc	40206bfc <memcpy+0xc0>  // b.lo, b.ul, b.last
    40206c0c:	8b0c0141 	add	x1, x10, x12
    40206c10:	92400962 	and	x2, x11, #0x7
    40206c14:	8b020109 	add	x9, x8, x2
    40206c18:	eb09011f 	cmp	x8, x9
    40206c1c:	540000c3 	b.cc	40206c34 <memcpy+0xf8>  // b.lo, b.ul, b.last
    40206c20:	1400002f 	b	40206cdc <memcpy+0x1a0>
    40206c24:	aa0003e8 	mov	x8, x0
    40206c28:	8b020009 	add	x9, x0, x2
    40206c2c:	eb09001f 	cmp	x0, x9
    40206c30:	54000562 	b.cs	40206cdc <memcpy+0x1a0>  // b.hs, b.nlast
    40206c34:	f100105f 	cmp	x2, #0x4
    40206c38:	540004a3 	b.cc	40206ccc <memcpy+0x190>  // b.lo, b.ul, b.last
    40206c3c:	cb01010a 	sub	x10, x8, x1
    40206c40:	f100815f 	cmp	x10, #0x20
    40206c44:	54000443 	b.cc	40206ccc <memcpy+0x190>  // b.lo, b.ul, b.last
    40206c48:	39400c2a 	ldrb	w10, [x1, #3]
    40206c4c:	3940082b 	ldrb	w11, [x1, #2]
    40206c50:	3940002c 	ldrb	w12, [x1]
    40206c54:	3940042d 	ldrb	w13, [x1, #1]
    40206c58:	39000d0a 	strb	w10, [x8, #3]
    40206c5c:	927e044a 	and	x10, x2, #0xc
    40206c60:	f100115f 	cmp	x10, #0x4
    40206c64:	3900090b 	strb	w11, [x8, #2]
    40206c68:	3900050d 	strb	w13, [x8, #1]
    40206c6c:	3900010c 	strb	w12, [x8]
    40206c70:	54000260 	b.eq	40206cbc <memcpy+0x180>  // b.none
    40206c74:	39401c2b 	ldrb	w11, [x1, #7]
    40206c78:	3940182c 	ldrb	w12, [x1, #6]
    40206c7c:	f100215f 	cmp	x10, #0x8
    40206c80:	3940102d 	ldrb	w13, [x1, #4]
    40206c84:	3940142e 	ldrb	w14, [x1, #5]
    40206c88:	39001d0b 	strb	w11, [x8, #7]
    40206c8c:	3900190c 	strb	w12, [x8, #6]
    40206c90:	3900150e 	strb	w14, [x8, #5]
    40206c94:	3900110d 	strb	w13, [x8, #4]
    40206c98:	54000120 	b.eq	40206cbc <memcpy+0x180>  // b.none
    40206c9c:	39402c2b 	ldrb	w11, [x1, #11]
    40206ca0:	3940282c 	ldrb	w12, [x1, #10]
    40206ca4:	3940202d 	ldrb	w13, [x1, #8]
    40206ca8:	3940242e 	ldrb	w14, [x1, #9]
    40206cac:	39002d0b 	strb	w11, [x8, #11]
    40206cb0:	3900290c 	strb	w12, [x8, #10]
    40206cb4:	3900250e 	strb	w14, [x8, #9]
    40206cb8:	3900210d 	strb	w13, [x8, #8]
    40206cbc:	eb0a005f 	cmp	x2, x10
    40206cc0:	540000e0 	b.eq	40206cdc <memcpy+0x1a0>  // b.none
    40206cc4:	8b0a0108 	add	x8, x8, x10
    40206cc8:	8b0a0021 	add	x1, x1, x10
    40206ccc:	3840142a 	ldrb	w10, [x1], #1
    40206cd0:	3800150a 	strb	w10, [x8], #1
    40206cd4:	eb09011f 	cmp	x8, x9
    40206cd8:	54ffffa1 	b.ne	40206ccc <memcpy+0x190>  // b.any
    40206cdc:	d65f03c0 	ret
    40206ce0:	eb08013f 	cmp	x9, x8
    40206ce4:	54fff942 	b.cs	40206c0c <memcpy+0xd0>  // b.hs, b.nlast
    40206ce8:	aa0a03ed 	mov	x13, x10
    40206cec:	aa0d03f0 	mov	x16, x13
    40206cf0:	394009af 	ldrb	w15, [x13, #2]
    40206cf4:	394005ae 	ldrb	w14, [x13, #1]
    40206cf8:	38404e11 	ldrb	w17, [x16, #4]!
    40206cfc:	39400a12 	ldrb	w18, [x16, #2]
    40206d00:	394001a1 	ldrb	w1, [x13]
    40206d04:	39400da2 	ldrb	w2, [x13, #3]
    40206d08:	d370bdef 	lsl	x15, x15, #16
    40206d0c:	394015a3 	ldrb	w3, [x13, #5]
    40206d10:	39400e10 	ldrb	w16, [x16, #3]
    40206d14:	53103e52 	lsl	w18, w18, #16
    40206d18:	aa0e202e 	orr	x14, x1, x14, lsl #8
    40206d1c:	aa0261ef 	orr	x15, x15, x2, lsl #24
    40206d20:	910021ad 	add	x13, x13, #0x8
    40206d24:	2a032231 	orr	w17, w17, w3, lsl #8
    40206d28:	2a106250 	orr	w16, w18, w16, lsl #24
    40206d2c:	aa0e01ee 	orr	x14, x15, x14
    40206d30:	2a11020f 	orr	w15, w16, w17
    40206d34:	aa0f81ce 	orr	x14, x14, x15, lsl #32
    40206d38:	f800852e 	str	x14, [x9], #8
    40206d3c:	eb08013f 	cmp	x9, x8
    40206d40:	54fffd63 	b.cc	40206cec <memcpy+0x1b0>  // b.lo, b.ul, b.last
    40206d44:	17ffffb2 	b	40206c0c <memcpy+0xd0>

0000000040206d48 <__umodti3>:
    40206d48:	d100c3ff 	sub	sp, sp, #0x30
    40206d4c:	a9027bfd 	stp	x29, x30, [sp, #32]
    40206d50:	910083fd 	add	x29, sp, #0x20
    40206d54:	910003e8 	mov	x8, sp
    40206d58:	97fffeb6 	bl	40206830 <_RNvNtNtCs7yBULlKOBOw_17compiler_builtins3int19specialized_div_rem12u128_div_rem>
    40206d5c:	a94107e0 	ldp	x0, x1, [sp, #16]
    40206d60:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40206d64:	9100c3ff 	add	sp, sp, #0x30
    40206d68:	d65f03c0 	ret

0000000040206d6c <memset>:
    40206d6c:	f100405f 	cmp	x2, #0x10
    40206d70:	540009e3 	b.cc	40206eac <memset+0x140>  // b.lo, b.ul, b.last
    40206d74:	cb0003eb 	neg	x11, x0
    40206d78:	92400968 	and	x8, x11, #0x7
    40206d7c:	8b080009 	add	x9, x0, x8
    40206d80:	eb09001f 	cmp	x0, x9
    40206d84:	54000302 	b.cs	40206de4 <memset+0x78>  // b.hs, b.nlast
    40206d88:	f100111f 	cmp	x8, #0x4
    40206d8c:	aa0003ea 	mov	x10, x0
    40206d90:	54000243 	b.cc	40206dd8 <memset+0x6c>  // b.lo, b.ul, b.last
    40206d94:	0e020c20 	dup	v0.4h, w1
    40206d98:	927e016b 	and	x11, x11, #0x4
    40206d9c:	aa0003ec 	mov	x12, x0
    40206da0:	8b0b000a 	add	x10, x0, x11
    40206da4:	aa0b03ed 	mov	x13, x11
    40206da8:	5e0e0401 	mov	h1, v0.h[3]
    40206dac:	5e0a0402 	mov	h2, v0.h[2]
    40206db0:	5e060403 	mov	h3, v0.h[1]
    40206db4:	3d000180 	str	b0, [x12]
    40206db8:	f10011ad 	subs	x13, x13, #0x4
    40206dbc:	3c003181 	stur	b1, [x12, #3]
    40206dc0:	3c002182 	stur	b2, [x12, #2]
    40206dc4:	3c001183 	stur	b3, [x12, #1]
    40206dc8:	9100118c 	add	x12, x12, #0x4
    40206dcc:	54ffff41 	b.ne	40206db4 <memset+0x48>  // b.any
    40206dd0:	eb0b011f 	cmp	x8, x11
    40206dd4:	54000080 	b.eq	40206de4 <memset+0x78>  // b.none
    40206dd8:	38001541 	strb	w1, [x10], #1
    40206ddc:	eb09015f 	cmp	x10, x9
    40206de0:	54ffffc1 	b.ne	40206dd8 <memset+0x6c>  // b.any
    40206de4:	cb08004a 	sub	x10, x2, x8
    40206de8:	927df148 	and	x8, x10, #0xfffffffffffffff8
    40206dec:	8b080128 	add	x8, x9, x8
    40206df0:	eb08013f 	cmp	x9, x8
    40206df4:	54000102 	b.cs	40206e14 <memset+0xa8>  // b.hs, b.nlast
    40206df8:	12001c2b 	and	w11, w1, #0xff
    40206dfc:	3200c3ec 	mov	w12, #0x1010101             	// #16843009
    40206e00:	1b0c7d6b 	mul	w11, w11, w12
    40206e04:	aa0b816b 	orr	x11, x11, x11, lsl #32
    40206e08:	f800852b 	str	x11, [x9], #8
    40206e0c:	eb08013f 	cmp	x9, x8
    40206e10:	54ffffc3 	b.cc	40206e08 <memset+0x9c>  // b.lo, b.ul, b.last
    40206e14:	92400942 	and	x2, x10, #0x7
    40206e18:	8b020109 	add	x9, x8, x2
    40206e1c:	eb09011f 	cmp	x8, x9
    40206e20:	54000442 	b.cs	40206ea8 <memset+0x13c>  // b.hs, b.nlast
    40206e24:	f100105f 	cmp	x2, #0x4
    40206e28:	540003a3 	b.cc	40206e9c <memset+0x130>  // b.lo, b.ul, b.last
    40206e2c:	927e044a 	and	x10, x2, #0xc
    40206e30:	39000d01 	strb	w1, [x8, #3]
    40206e34:	f100115f 	cmp	x10, #0x4
    40206e38:	8b0a010b 	add	x11, x8, x10
    40206e3c:	39000901 	strb	w1, [x8, #2]
    40206e40:	39000501 	strb	w1, [x8, #1]
    40206e44:	39000101 	strb	w1, [x8]
    40206e48:	54000240 	b.eq	40206e90 <memset+0x124>  // b.none
    40206e4c:	0e020c20 	dup	v0.4h, w1
    40206e50:	f100215f 	cmp	x10, #0x8
    40206e54:	5e0e0401 	mov	h1, v0.h[3]
    40206e58:	5e0a0402 	mov	h2, v0.h[2]
    40206e5c:	5e060403 	mov	h3, v0.h[1]
    40206e60:	3c004100 	stur	b0, [x8, #4]
    40206e64:	3c007101 	stur	b1, [x8, #7]
    40206e68:	3c006102 	stur	b2, [x8, #6]
    40206e6c:	3c005103 	stur	b3, [x8, #5]
    40206e70:	54000100 	b.eq	40206e90 <memset+0x124>  // b.none
    40206e74:	5e0e0401 	mov	h1, v0.h[3]
    40206e78:	5e0a0402 	mov	h2, v0.h[2]
    40206e7c:	3c008100 	stur	b0, [x8, #8]
    40206e80:	5e060403 	mov	h3, v0.h[1]
    40206e84:	3c00b101 	stur	b1, [x8, #11]
    40206e88:	3c00a102 	stur	b2, [x8, #10]
    40206e8c:	3c009103 	stur	b3, [x8, #9]
    40206e90:	eb0a005f 	cmp	x2, x10
    40206e94:	aa0b03e8 	mov	x8, x11
    40206e98:	54000080 	b.eq	40206ea8 <memset+0x13c>  // b.none
    40206e9c:	38001501 	strb	w1, [x8], #1
    40206ea0:	eb09011f 	cmp	x8, x9
    40206ea4:	54ffffc1 	b.ne	40206e9c <memset+0x130>  // b.any
    40206ea8:	d65f03c0 	ret
    40206eac:	aa0003e8 	mov	x8, x0
    40206eb0:	8b020009 	add	x9, x0, x2
    40206eb4:	eb09001f 	cmp	x0, x9
    40206eb8:	54fffb63 	b.cc	40206e24 <memset+0xb8>  // b.lo, b.ul, b.last
    40206ebc:	17fffffb 	b	40206ea8 <memset+0x13c>
