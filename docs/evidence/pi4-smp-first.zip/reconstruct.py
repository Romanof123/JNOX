"""Reconstruct the two sealed replay directories. Run in the extracted archive root."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
manifest = json.loads((root / "members.json").read_text())
if len(manifest) > 128:
    raise ValueError("member limit")
for name, expected in manifest.items():
    path = (root / name).resolve()
    if not path.is_relative_to(root) or path.stat().st_size > 4 * 1024 * 1024:
        raise ValueError(name)
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise ValueError(name)
for run in ("launch1", "launch2"):
    folder = root / run
    for source, target in [(root / "kernel.elf", "kernel.elf"),
                           (root / "kernel8.img", "kernel8.img"),
                           (folder / "serial.raw", "uart.bin")]:
        shutil.copyfile(source, folder / target)
    subprocess.run([sys.executable, str(root / "pi4_smp_replay.py"), str(folder),
                    manifest[run + "/session.json"]], check=True, timeout=30)
