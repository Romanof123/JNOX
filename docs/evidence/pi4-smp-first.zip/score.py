import hashlib,json,pathlib,re,shutil,sys
from pi4_smp_replay import replay, external_score
dig=lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
for folder in map(pathlib.Path,["launch1","launch2"]):
    normalized=[]; ledger=[]
    for log in sorted(folder.glob("observer-*.log")):
        tid=log.stem.split("-")[1]
        cpu=int(re.fullmatch(r"CPU (\d)/TCG",(folder/f"thread-{tid}").read_text())[1])
        pending=None
        for n,line in enumerate(log.read_text().splitlines(),1):
            match=re.fullmatch(r"Taking exception \d+ \[(IRQ|SVC)\] on CPU (\d+)",line)
            if match:
                assert int(match[2])==cpu and pending is None
                pending=(match[1].lower(),n)
            event=re.fullmatch(r"Exception return from AArch64 EL1 to AArch64 EL1 PC (0x[\da-f]+)",line)
            elr=re.fullmatch(r"\.\.\.with ELR (0x[\da-f]+)",line)
            if event or elr:
                kind,first=("eret",n) if event else pending
                pc=(event or elr)[1]
                normalized.append(f"CPU {cpu} {kind} {pc}")
                ledger.append((log.name,first,n,cpu,kind,pc))
                pending=None
        assert pending is None
    (folder/"external.log").write_text("\n".join(normalized)+"\n")
    (folder/"mapping.json").write_text(json.dumps(ledger,indent=2))
    for src,dst in [("kernel.elf","kernel.elf"),("kernel8.img","kernel8.img"),(folder/"serial.raw","uart.bin")]:
        shutil.copyfile(src,folder/dst)
    exitdata=json.loads((folder/"exit.json").read_text())
    assert exitdata["reason"]=="terminal_quiet"
    session=dict(mode="model",run_id=folder.name,elapsed_ns=int(exitdata["elapsed"]*1e9),quiet_ns=1000000000,
        sha256={k:dig(folder/k) for k in ["kernel.elf","kernel8.img","uart.bin","external.log"]})
    manifest=folder/"session.json"
    manifest.write_text(json.dumps(session,indent=2))
    result=replay(folder,dig(manifest))
    (folder/"result.json").write_text(json.dumps(result,indent=2))
    print(folder,result["software"],result["external"],result["software_gaps"],result["products"])
