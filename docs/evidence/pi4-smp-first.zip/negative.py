from pathlib import Path
from pi4_smp_replay import replay,digest
import tempfile,shutil,json
for base in map(Path,["launch1","launch2"]):
    for field,value in [(2,"0"),(5,"2"),(8,"1"),(None,None)]:
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            for name in ("kernel8.img","kernel.elf","external.log","uart.bin"):
                shutil.copyfile(base/name,dest/name)
            uart=dest/"uart.bin"
            lines=uart.read_text().splitlines()
            idx=next(i for i,x in enumerate(lines) if x.split()[:6]==["SW","ROW","1","9","9","1"])
            if field is None:
                del lines[idx]
            else:
                words=lines[idx].split(); words[field]=value; lines[idx]=" ".join(words)
            uart.write_text("\n".join(lines)+"\n")
            manifest=json.loads((base/"session.json").read_text())
            manifest["sha256"]["uart.bin"]=digest(uart.read_bytes())
            m=dest/"session.json"; m.write_text(json.dumps(manifest))
            try:
                replay(dest,digest(m.read_bytes()))
            except ValueError as err:
                print(base,field,value,"rejected",err)
            else:
                raise RuntimeError("accepted corruption")
