import argparse
import json
import os
import pathlib
import selectors
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument("dest", type=pathlib.Path)
p.add_argument("terminal", help="terminal serial line prefix")
p.add_argument("command", nargs="+")
args = p.parse_args()
args.dest.mkdir(exist_ok=False)
start = time.monotonic()
reason = "deadline"
terminal_seen = False
last_serial = start
buf = b""
with (args.dest / "serial.raw").open("xb") as serial, (args.dest / "stderr.raw").open("xb") as err:
    proc = subprocess.Popen(args.command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=err)
    try:
        sel = selectors.DefaultSelector()
        sel.register(proc.stdout, selectors.EVENT_READ)
        while time.monotonic() - start < 30:
            for task in pathlib.Path(f"/proc/{proc.pid}/task").glob("*/comm"):
                try:
                    name = task.read_text().strip()
                    if "/TCG" in name:
                        (args.dest / ("thread-" + task.parent.name)).write_text(name)
                except FileNotFoundError:
                    pass
            if terminal_seen and time.monotonic() - last_serial >= 1:
                reason = "terminal_quiet"
                break
            if not sel.select(0.025):
                continue
            chunk = os.read(proc.stdout.fileno(), 65536)
            if not chunk:
                reason = "process_eof"
                break
            last_serial = time.monotonic()
            serial.write(chunk)
            serial.flush()
            lines = (buf + chunk).split(b"\n")
            buf = lines.pop()
            terminal_seen |= any(line.startswith(tuple(x.encode() for x in args.terminal.split("|"))) for line in lines)
    finally:
        if proc.poll() is None:
            proc.terminate()
        try:
            proc.wait(timeout=1)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        (args.dest / "exit.json").write_text(json.dumps(dict(reason=reason, returncode=proc.returncode,
            terminal_seen=terminal_seen, elapsed=time.monotonic()-start, command=args.command), indent=2))

