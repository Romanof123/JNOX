set -eu
src=$HOME/permit389-fused-c5ab397
out=$HOME/host389-first
dest=/mnt/d/codex/host389-first
cd "$src/src"
i=0
for p in fifo rr; do for s in healthy overrun; do
 pkg="$src/$p-$s/pkg"
 export SITES=$(python3 "$out/qemu_host_phase_sites.py" "$pkg/kernel.elf")
 for mode in stock empty observe observe empty stock; do
 i=$((i+1))
 export POSITION="$out/$(printf %02d "$i")-$p-$s-$mode" MODE="$mode" PLUGIN="$out/host-phase.so"
 mkdir "$POSITION"
 PYTHONPATH="$dest:$src/src/tools" python3 tools/native_el0_capture.py "$POSITION/cap" "$pkg/kernel.elf" "$src/sender.elf" examples/native-safety-admission/sender/src/main.rs c5ab397e93d345a4fef4420fe9cf7fa3e4be97ac --manifest "$pkg/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608 > "$POSITION/boot.log" 2>&1 || echo failure >> "$POSITION/boot.log"
 echo "$POSITION"; tail -c 450 "$POSITION/boot.log"
 done
done; done
