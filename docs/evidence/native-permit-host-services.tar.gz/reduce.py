import json, struct, subprocess, sys, hashlib
from pathlib import Path
base=Path(sys.argv[1])
dest=Path(sys.argv[2])
def symbols(elf):
    out={}
    for line in subprocess.check_output(['aarch64-linux-gnu-nm','-CS',elf],text=True).splitlines():
        a=line.split(None,3)
        if len(a)==4:
            out[a[3]]=(int(a[0],16),int(a[1],16))
    return out
def groups(a,w):
    return [a[i:i+w] for i in range(0,len(a),w)]
def rows(tag):
    return [list(map(int,l[len(tag):].split())) for l in lines if l.startswith(tag+' ')]
def first(items):return next(iter(items),None)
def bracket(r):return r[3:5] if r else None
def interval_state(t,sw):
    state=0
    for v in sw:
        if v[2]<=t<v[3]:return None
        if v[3]<=t:state=v[5]
    return state
allout={}
for cap in sorted(base.glob('*/cap')):
    n=cap.parent.name
    if n.startswith('rollback-'):continue
    original=n.startswith(('default','observer'))
    names=['orig-sender','orig-receiver','orig-supervisor'] if original else ['sender','controller','supervisor']
    meta=json.loads((cap/'launch.json').read_text())
    ram=(cap/'ram.bin').read_bytes()
    def read(addr,size):
        ix=addr-meta['ram_base'];assert ix>=0 and ix+size<=len(ram);return ram[ix:ix+size]
    sp,sz=symbols(cap/'kernel.elf')['jnox_kernel::native_el0_mmu::SPACES']
    private=[]
    for pid,role in enumerate(names):
        data={};root=sp+pid*(sz//3)
        for sym,(addr,size) in symbols(base/(role+'.elf')).items():
            if not sym.startswith(('admission_','safety_')) or '::' in sym:continue
            b=bytearray()
            while len(b)<size:
                va=addr+len(b);page=root
                for shift in (30,21,12):
                    desc=struct.unpack('<Q',read(page+8*((va>>shift)&511),8))[0];assert desc&3==3
                    page=desc&0xfffff000
                offset=va&4095
                b.extend(read(page+offset,min(size-len(b),4096-offset)))
            data[sym]=b.hex() if sym.endswith('bytes') else list(struct.unpack('<'+'Q'*(size//8),b))
        private.append(data)
    lines=(cap/'uart.bin').read_text().splitlines()
    ev=rows('NATIVE SAFETY EVENT');sw=[r for r in ev if r[0]==2];ex=[r for r in ev if r[0]==3]
    pubs=[r for r in ev if r[0]==11];fresh=[r for r in ev if r[0]==12]
    item={'exits':rows('NATIVE EL0 EXIT PID'),'safety_losses':rows('NATIVE SAFETY DROPPED'),'fixed_losses':rows('NATIVE FIXED DROPPED'),'private':private,'device':sw,'expiry':ex}
    allout[n]=item
    if original:
        if ex:
            r=ex[0];d=r[5]+1250000
            item.update(deadline=d,detect_offset=r[2]-d,next_pub_offset=[[p[2]-d,p[3]-d] for p in pubs if p[8]==r[4]+1],near_fresh_offsets=[f[2]-d for f in fresh if f[5]==r[4] and abs(f[2]-d)<350000],enabled_before_expiry=interval_state(d-1,sw))
        continue
    q=[r[1:] for r in rows('NATIVE QUAL ROW')];counts=rows('NATIVE QUAL COUNTS')[0];freq=counts[0]
    heads=[p['admission_header'] for p in private];epoch=heads[0][2];assert all(h[2:4]==[epoch,freq] for h in heads)
    stage={}; jobs=[]
    for i,r in enumerate(q):
        if r[0]==1:stage.setdefault(tuple(r[1:4]),{})[r[4]]=(i,r)
    for (pid,j,ph),st in stage.items():
        if not all(v in st for v in (1,2,3)):continue
        (i,a),(m,b),(z,c)=[st[h] for h in (1,2,3)];bit=1<<pid;t=a[5]
        wait=first(v for v in q[i+1:m] if v[0]==2 and v[1]==62 and v[7]==pid and v[5]&bit and not v[6]&bit)
        ready=first(v for v in q[i+1:m] if v[0]==2 and not v[5]&bit and v[6]&bit)
        dispatch=first(v for v in q[i+1:m] if v[0]==2 and v[8]==pid and v[7]!=pid and v[10])
        end=first(v for v in q[z+1:] if v[0]==2 and v[7]==pid and v[5]&bit and not v[6]&bit)
        next_same=first(v for v in q[z+1:] if v[0]==1 and v[1]==pid and v[4]==2)
        if end and next_same and end[3]>=next_same[6]:end=None
        jobs.append(dict(pid=pid,job=j,phase=ph,target=t,wait=bracket(wait),ready=bracket(ready),dispatch=[dispatch[3],dispatch[10]] if dispatch else None,first_marker=b[6],finish=bracket(end),response=[end[3]-t,end[4]-t] if end else None,stage3_delta=c[6]-t))
    ctrl=[j for j in jobs if j['pid']==1];sender=[j for j in jobs if j['pid']==0]
    completes=[r[2:4] for r in ev if r[0]==10];gaps=[b[1]-a[0] for a,b in zip(completes,completes[1:])]
    inject=[r for r in ev if r[0]==4];fault=[]
    for f in inject:
        det=first(r for r in ex if r[2]>=f[3]);safe=first(v for v in sw if v[2]>=f[3] and v[5]==0)
        if det and safe:fault.append([f[2:4],det[2],safe[2:4],det[2]-f[2],safe[3]-det[2],safe[3]-f[2]])
    sd=private[0];num=sd['admission_sender_count'][0];sr=groups(sd['admission_sender_rows'],10)[:num];bs=groups(sd['admission_sender_bytes'],88)[:num]
    cd=groups(private[1]['admission_controller_rows'],18)
    retries=[(i,any(p[6]==r[6] and p[8]==2**64-11 and bs[k]==bs[i] for k,p in enumerate(sr[:i]))) for i,r in enumerate(sr) if r[9]]
    receives=[r for r in ev if r[0]==7]
    item['receive_bytes_join']=[any(s[6]==r[2] and s[8]==0 and bs[k]==b''.join(v.to_bytes(8,'little') for v in r[4:])[:44].hex() for k,s in enumerate(sr)) for r in receives]
    item['publication_join']=[any(s[6]==r[4] and s[8]==r[5] and (not r[6] or (s[4],s[5])==(r[8],r[9])) for s in sr) for r in pubs]
    item['queue_max']=max([r[5] for r in ev if r[0]==6] or [0])
    item['acquire_error']=[s[7] for s in sr if s[7] not in (0,1<<63)]
    item['private_rejections']=[[i,r[4],r[11],r[12],r[13],r[14]] for i,r in enumerate(cd) if r[3]==0 and r[4] not in (0,1<<63)]
    item['source_issues']=[dict(job=s[0],create=s[2],issue=s[5],retry=s[9]) for s in sr]
    item['irq_returns']=[dict(iar=r[3],cval=r[4],entry=r[1],ret=r[10],idle=r[8],pc=r[6]) for r in q if r[0]==3]
    item['irq_grid_max_upper']=max([r[10]-r[4] for r in q if r[0]==3 and r[3]==30 and r[10] and r[4]>=epoch and (r[4]-epoch)%(freq//400)==0] or [0])
    item['timer_programmed_targets']=[r[4] for r in q if r[0]==5 and r[3] and r[4]==r[5]]
    item['timer_irq_targets']=[r[4] for r in q if r[0]==3 and r[3]==30]
    item['rank_mismatch']=[r for r in q if r[0]==2 and r[6] and r[8]!=next(p for p in (1,0,2) if r[6]&(1<<p))]
    item['job_max_hi']=max(j['response'][1]+freq//400 for j in ctrl if j['phase']==2 and j['response'])
    item['initial_handshake']=[r for r in q if r[0]==2 and r[1] in (21,22) and r[4]<epoch]
    item['irq_masks']=rows('NATIVE INTERFERENCE MASK')
    item['measured_check_lowermax']=max(b[0]-a[1] for a,b in zip(completes,completes[1:]))
    ir=rows('NATIVE INTERFERENCE IRQ');arms=rows('NATIVE INTERFERENCE ARM')
    item.update(qual_counts=counts,jobs=jobs,headers=heads,missing_wait=[(j['pid'],j['job'],j['phase']) for j in jobs if not j['wait'] or not j['ready'] or not j['dispatch']],max_ctrl_lo=max(j['response'][0] if j['response'] else j['stage3_delta'] for j in ctrl),max_ctrl_hi=max((j['response'][1] for j in ctrl if j['response']),default=None),open_ctrl=sum(j['finish']==None for j in ctrl),max_sender_hi=max((j['response'][1] for j in sender if j['response']),default=None),max_complete_gap_upper=max(gaps,default=None),completed_checks=len(completes),enabled18=interval_state(epoch+18*freq//1000,sw),enabled37=interval_state(epoch+37*freq//1000,sw),fault_to_detect_safe=fault,sender_pair_spacing=sr[1][5]-sr[0][5] if len(sr)>1 else None,sender_retries=retries,rearm=[r[7:10] for r in cd if r[7]==2],overrun=private[1]['admission_overrun'],boundary=private[1]['admission_boundary_inputs'],irq_end=rows('NATIVE INTERFERENCE END'),irq_readback=all(a[3]==a[4] for a in arms),irq_completed=sum(r[6]==27 and r[-1]>=r[-2] and r[-2]>=r[1] for r in ir),initial_idle=any(r[0]==2 and r[6]==0 and r[4]<epoch for r in q),lost_publications=sum(r[5]!=0 for r in pubs))
(dest/'observations.json').write_text(json.dumps(allout,separators=(',',':')))
for n,v in allout.items():
    print(n, [v.get(k) for k in ('max_ctrl_lo','max_ctrl_hi','open_ctrl','max_sender_hi','max_complete_gap_upper','enabled18','enabled37','sender_pair_spacing','irq_completed','detect_offset','next_pub_offset')],len(v.get('missing_wait',[])),v.get('fault_to_detect_safe'))
