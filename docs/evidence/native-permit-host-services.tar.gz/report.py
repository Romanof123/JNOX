import json,csv,sys
from pathlib import Path
b=Path(sys.argv[1])
def read(n):return json.loads((b/n).read_text())
ps=read('positions.json'); pairs=read('pairs.json'); guest=read('observations.json')
positions=[]; selected=[]; report=['# QEMU host service intervals / QEMU 호스트 서비스 구간','', '24 serial default-clock cold boots, frozen c5ab397e guest, observer protocol 971c6467. Within each policy/case the order was stock, empty, observe, observe, empty, stock. Every kernel and user executable matched the archived default capture. QEMU 6.2.0 Ubuntu revision 2ubuntu6.31, GCC 11.4.0. Official v6.2.0 header and its peeled commit 44f28df24767cf9dca1ddc9b23157737c4cbb645 returned the same SHA-256 82c233fc6ab1a9649a26b1a4eae69e94ba2452d280bd82076372ea6bd1a0753f. QEMU SHA-256 0a63468782d096485932acf6aa0a69d358b3e3a6f68f655e960e9f5e3fc578d8. Plugin SHA-256 9ff1cf7999df9ea5f24554ce47db32fd8b7819f0020ec59d96ee887fc4cbb645 placeholder.', '','## Guest endpoints / 게스트 종료점','','Full controller release-to-finish bounds in 16 ns guest ticks. Outer host ms includes capture and termination. A0 and B0 are the first two phases. A4 is the designed overrun position. The phase limit is 62,500 ticks.','', '|Position|Host ms|A0 ticks|B0 ticks|A4 ticks|ENABLE 18/37 ms|FIXED dropped|','|---|---:|---:|---:|---:|---|---:|']
report[2]=report[2].replace('9ff1cf7999df9ea5f24554ce47db32fd8b7819f0020ec59d96ee887fc4cbb645 placeholder','9ff1cf7999df9ea5f24554ce47db32fd8b7819f0020ec59d96ee887fc4cbb645').replace('9ff1cf7999df9ea5f24554ce47db32fd8b7819f0020ec59d96ee887fc4cbb645',__import__('hashlib').sha256((b/'host-phase.so').read_bytes()).hexdigest())
for p in ps:
 n=p['position']; g=guest[n]; num=n[:2]
 def bounds(j,ph):
    x,=[x['response'] for x in g['jobs'] if (x['pid'],x['job'],x['phase'])==(1,j,ph)]
    return '–'.join(map(str,x)) if x else 'open'
 report.append(f"|{n}|{p['wall_ms']}|{bounds(0,1)}|{bounds(0,2)}|{bounds(4,1)}|{g['enabled18']}/{g['enabled37']}|{p['fixed_lost']}|")
 if n.endswith('observe'):
    seq=[x for x in pairs if x['position']==num]
    for i in (0,1):
      checks=[x for x in seq if x['phase']==[0,i+1]]
      window=seq[seq.index(checks[0]):seq.index(checks[-1])+1]
      assert [x['label'] for x in window if x['label']]==['CHECK','nested empty','loan35 empty','COMPLETE']
      for x in window:
       if x['label']:selected.append(dict(stage='A0' if i==0 else 'B0',**x))
report+=['','## Observed service intervals / 관측한 서비스 구간','','Across eight observed boots. Wall is the smallest lower bound through the largest upper bound in µs. CPU and RAW show the range of same-thread paired point differences. Switch counts are per interval. The loan service encloses the nested receive. early-services.csv preserves individual intervals, ordinals, thread IDs, and per-function translation overlap.','','|Phase|Service|Wall µs|CPU µs|RAW µs|Translations|Vol./invol. switches|','|---|---|---:|---:|---:|---:|---|']
for stage in ('A0','B0'):
 for label in ('CHECK','loan35 empty','nested empty','COMPLETE'):
    v=[x for x in selected if (x['stage'],x['label'])==(stage,label)]
    def span(m,k):return f"{min(x[m] for x in v)/1000:.2f}–{max(x[k] for x in v)/1000:.2f}"
    report.append(f"|{stage}|{label}|{span('low','high')}|{span('cpu','cpu')}|{span('raw','raw')}|{v[0]['translations']}|{min(x['vol'] for x in v)}–{max(x['vol'] for x in v)} / {max(x['invol'] for x in v)}|")
report+=['','Every A0 deadline failed. All boots retained all three expected exits, 32 COMPLETEs and eight successful publications. At 18 ms ENABLE was low at positions 04, 19 and 22, including one stock control. All reached ENABLE at 37 ms. The plugin series cannot establish a causal effect size. The first CHECK consumed 371–856 µs of vCPU-thread CPU time with zero recorded switches. Later CHECK had zero translation callbacks and one observed voluntary switch in some intervals. Cost includes emulator helpers, translated guest work and probe execution. Translation counts do not measure TCG compilation time. Per-hit median sampling span across observed boots was 1.142–1.183 µs. The true instrumentation cost also includes callback registration and scanning, outside these samples.','','All 2,086 host intervals closed. Zero mmap drops, QUAL and SAFETY drops. FIXED dropped its suffix (278–356 entries per boot). Ordinals beyond the retained prefix have no independently verified operation labels. Other generic calls inside the prefix may also lack a CHECK/COMPLETE label. pairs.json retains all intervals, including unlabeled ones. Host bounds never change the guest score.','','24회 모두 첫 A 위상이 1 ms를 넘었고, 18 ms 시점의 ENABLE은 04·19·22번에서 0이었다. 19번은 원래 QEMU 대조군이었다. 37 ms에는 전부 1이었다. 첫 CHECK에서는 호스트 문맥 전환이 기록되지 않았고 vCPU 스레드 CPU 시간은 371–856 µs였다. 다음 CHECK의 번역 콜백 수는 0이었다. 번역 시간과 관측기 비용 전체를 분리할 수 없다. FIXED 로그의 유실 구간은 명령을 특정하지 않았다.','','## Offline replay / 오프라인 검증','','From the extracted directory run sha256sum -c SHA256SUMS, python3 analyze.py . and python3 reduce.py . . with GNU AArch64 binutils installed, followed by python3 report.py . . The first two reducers verify session file hashes, match frozen executables, pair mmap records and decode guest RAM/UART. The archived argv.json is the actual QEMU command line for each trial.']
(b/'REPORT.en-ko.md').write_text('\n'.join(report)+'\n')
with (b/'early-services.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(selected[0]));w.writeheader();w.writerows(selected)
