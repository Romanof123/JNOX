import csv,hashlib,json,struct,sys,statistics,tarfile
from pathlib import Path
base=Path(sys.argv[1])
results=[]; pairs=[]
for d in sorted(base.glob('[0-9][0-9]-*')):
    num,p,s,mode=d.name.split('-')
    cap=d/'cap'
    lines=(cap/'uart.bin').read_text().splitlines()
    def rows(tag):
        return [list(map(int,l[len(tag):].split())) for l in lines if l.startswith(tag+' ')]
    fixed=rows('NATIVE FIXED EVENT')
    qual=[r[1:] for r in rows('NATIVE QUAL ROW')]
    dec={r[5]:r for r in qual if r[0]==4}
    phase={}; endpoints={}
    for r in qual:
        if r[0]==1 and r[1]==1:
            phase[r[2],r[3],r[4]]=r
            if r[4]==3:endpoints[str((r[2],r[3]))]=r[6]-r[5]
    ev=rows('NATIVE SAFETY EVENT')
    loans=[r for r in ev if r[0]==6]
    fs=[r for r in fixed if r[1] in (59,60,61,63)]
    fl=[r for r in fixed if 33<=r[1]<=36]
    h=json.loads((d/'host.json').read_text())
    session=json.loads((cap/'session.json').read_text())
    assert all(hashlib.sha256((cap/k).read_bytes()).hexdigest()==v for k,v in session['hashes'].items())
    with tarfile.open(base/'frozen'/f'{p}-{s}-default.tgz') as ar:
        for k in ('user.elf','kernel.elf'):
            assert hashlib.sha256(ar.extractfile('./cap/'+k).read()).hexdigest()==session['hashes'][k]
    rec=dict(position=d.name,wall_ms=round((h['end']-h['start'])/1e6,2),exit=rows('NATIVE EL0 EXIT PID'),stage3=endpoints,check_first=endpoints.get('(0, 1)'),second_phase=endpoints.get('(0, 2)'),fixed_lost=rows('NATIVE FIXED DROPPED')[0][0],qual_lost=rows('NATIVE QUAL COUNTS')[0][-1],safety_lost=rows('NATIVE SAFETY DROPPED')[0][0],complete=sum(r[0]==10 for r in ev),published=sum(r[0]==11 and r[5]==0 for r in ev),device=[r[5] for r in ev if r[0]==2])
    results.append(rec)
    if mode=='stock':continue
    data=(d/'hits.bin').read_bytes(); assert len(data)==4097*120
    magic,n,drops,*_=struct.unpack_from('<15Q',data); assert magic==0x4a484f530001 and not drops
    assert bool(n)==(mode=='observe')
    if not n:continue
    hits=list(struct.iter_unpack('<15Q',data))[1:n+1]
    assert all(all(r[j] not in (0,2**64-1) for j in (0,1,2,4,11)) and r[0]<=r[11] and max(r[9:11])<2**64-1 for r in hits)
    stacks={}; ordinal=[0]*3; costs=[]
    for r in hits:
        tag=r[3]; tid=r[4]; region=tag//2;st=stacks.setdefault(tid,[]); costs.append(r[11]-r[0])
        if tag%2==0:
            i=ordinal[region]; ordinal[region]+=1
            label=None; phase_id=None
            if region==0 and i<len(fs):
                f=fs[i]; q=dec.get(f[0])
                if f[1]!=61:
                    assert q and q[1]==f[3] and q[2]==f[1]
                    ph=[(j,k) for (j,k,v),x in phase.items() if v==2 and (j,k,3) in phase and x[6]<=q[4]<=q[6]<=phase[j,k,3][6]]
                    if q[2]==63 and len(ph)==1:label={1:'CHECK',3:'COMPLETE'}.get(q[3]); phase_id=ph[0]
            if region==1 and i<len(fl):
                f=fl[i]; l=loans[i];assert (f[3],f[1])==(l[2],l[3])
                label='loan'+str(f[1])+(' empty' if l[4]==2**64-11 else '')
            if region==2:
                assert st and st[-1][0][3]==2
                if st[-1][2]=='loan35 empty':label='nested empty'
            st.append((r,i,label,phase_id)); continue
        a,i,label,phase_id=st.pop();assert a[3]+1==tag
        pairs.append(dict(position=num,region=region,ordinal=i,label=label,phase=phase_id,tid=tid,low=r[0]-a[11],high=r[11]-a[0],cpu=r[1]-a[1],raw=r[2]-a[2],translations=r[5]-a[5],overlap=[r[j]-a[j] for j in (6,7,8)],vol=r[9]-a[9],invol=r[10]-a[10]))
    rec.update(hits=n,open_pairs=sum(map(len,stacks.values())),probe_median_ns=statistics.median(costs),probe_max_ns=max(costs))
(base/'positions.json').write_text(json.dumps(results,indent=1))
(base/'pairs.json').write_text(json.dumps(pairs,separators=(',',':')))
for r in results:print(r['position'],r['wall_ms'],r['check_first'],r['second_phase'],r['complete'],r['published'],r['device'],r.get('probe_median_ns','-'))
