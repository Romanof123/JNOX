import json,os,subprocess,time
from pathlib import Path
Popen=subprocess.Popen
class Timed(Popen):
    def __init__(self,args,*a,**kw):
        self.guest=isinstance(args,list) and '-qmp' in args
        if self.guest:
            self.out=Path(os.environ['POSITION'])
            mode=os.environ['MODE']
            if mode!='stock':
                args=args+['-plugin',os.environ['PLUGIN']+',out='+str(self.out/'hits.bin')+',mode='+mode+','+os.environ['SITES']]
            (self.out/'argv.json').write_text(json.dumps(args))
            self.start=time.monotonic_ns()
        super().__init__(args,*a,**kw)
    def wait(self,*a,**kw):
        rc=super().wait(*a,**kw)
        if self.guest:
            (self.out/'host.json').write_text(json.dumps(dict(start=self.start,end=time.monotonic_ns(),pid=self.pid,rc=rc)))
            self.guest=False
        return rc
subprocess.Popen=Timed
