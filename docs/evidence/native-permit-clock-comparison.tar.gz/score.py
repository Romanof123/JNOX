import sys,json,collections,hashlib
from pathlib import Path
out,live,archive,prior=map(Path,sys.argv[1:])
def get(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
current=get(out/'observations.json');older=get(prior/'observations.json')
report=['# QEMU clock diagnostic / QEMU 시계 비교','', 'Frozen c5ab397e93d345a4fef4420fe9cf7fa3e4be97ac. Replay order was FIFO healthy, FIFO overrun, RR healthy, RR overrun. Each ran a fresh default clock, then prespecified shifts 0 and 1 (1 and 2 virtual ns per guest instruction). All four original firsts are included. The same kernel bytes, package manifest, role ELFs, phase calendar, scheduler and 62500-tick limit were used within each position. Existing default captures lacked a contemporaneous monotonic host-duration record. New host ms spans QEMU process launch through termination, including UART/QMP terminal capture. Host times do not measure individual guest phases.','', '|Position / clock|Host ms|First A full response lo–hi|Job 4 A lo–hi|Max phase upper|COMPLETE gap upper|Overrun ticks / batches|Grid IRQ upper|','|---|---:|---:|---:|---:|---:|---:|---:|']
rows={}
for pol in ('fifo','rr'):
 for case in ('healthy','overrun'):
  stem=f'{pol}-{case}'; ref=archive/stem/'cap'; lref=get(ref/'launch.json')
  for mode in ('archived','default','0','1'):
   n=f'{stem}-{mode}'; cap=ref if mode=='archived' else live/n/'cap'; x=older[stem] if mode=='archived' else current[n]; lj=get(cap/'launch.json')
   assert lj['kernel_sha256']==lref['kernel_sha256'] and lj['argument_package']==lref['argument_package']
   lines=(cap/'uart.bin').read_text().splitlines()
   def read(tag):return [list(map(int,l[len(tag):].split())) for l in lines if l.startswith(tag+' ')]
   q=[r[1:] for r in read('NATIVE QUAL ROW')];fixed=read('NATIVE FIXED EVENT');events=read('NATIVE SAFETY EVENT')
   ctrl=[a for a in x['jobs'] if a['pid']==1]; jobs=[]
   for j in ctrl:
    k,ph=j['job'],j['phase']; begin=j['first_marker'];end=j['target']+j['stage3_delta']
    fd=[r for r in fixed if begin<r[0]<end and r[3]==1 and r[1]!=62]
    de=[r for r in q if r[0]==4 and r[1:3]==[1,63] and begin<r[4]<end]
    jobs.append(dict(job=k,phase=ph,response=j['response'],start_minus_target=begin-j['target'],stage2_to_3=end-begin,full_fixed_window=end<=fixed[-1][0],fixed_ops=[r[1] for r in fd],fixed_ticks=[r[0]-begin for r in fd],decision_elapsed=[r[6]-r[4] for r in de],status=[r[7] for r in de],irq_intersections=[r[3] for r in q if r[0]==3 and r[1]<=end and r[10]>=begin]))
   timed=None if mode=='archived' else get(cap.parent/'host.json')
   over=x['overrun']; ms='—' if not timed else f"{timed['elapsed_ns']/1e6:.1f}"
   oc=[v for v in jobs if v['job']==4 and v['phase']==1][0]
   h=lambda j:'–'.join(map(str,j['response']))
   report.append(f"|{n}|{ms}|{h(jobs[0])}|{h(oc)}|{x['max_ctrl_hi']}|{x['max_complete_gap_upper']}|{over[1]-over[0]} / {over[2]}|{x['irq_grid_max_upper']}|")
   rows[n]=dict(jobs=jobs,host=timed,kernel=lj['kernel_sha256'],cmd=lj['argv'],exits=x['exits'],availability=[x['enabled18'],x['enabled37']],completes=x['completed_checks'],complete_brackets=[r[2:4] for r in events if r[0]==10],irq_counts=dict(collections.Counter(r[3] for r in q if r[0]==3)),qual_losses=x['qual_counts'][-1],fixed_losses=x['fixed_losses'],safety_losses=x['safety_losses'],overrun=over,missing=x['missing_wait'])
(out/'clock-results.json').write_text(json.dumps(rows,indent=1))
report+=['','## First empty receive / 첫 빈 수신','', 'The first A phase had complete fixed-prefix coverage. Each row lists the stage-2 mark to syscall event offsets in actual issue order (63 CHECK, 35 receive, 61 state, 63 COMPLETE), followed by stage-3 mark and the two SVC63 entry-to-decision durations. All values are 16 ns architectural counter ticks. Consecutive offsets include mixed EL0/EL1 work. The fixed issue timestamp alone cannot isolate loan service cost.','', '|Healthy clock|Issue offsets|Stage 2→3|CHECK / COMPLETE|IRQ intersecting body|','|---|---|---:|---|---|']
for k,v in rows.items():
 if 'healthy' not in k:continue
 j=v['jobs'][0];assert j['full_fixed_window'] and j['fixed_ops']==[63,35,61,63]
 report.append(f"|{k}|{j['fixed_ticks']}|{j['stage2_to_3']}|{j['decision_elapsed']}|{j['irq_intersections']}|")
report+=['','Both instruction-clock healthy runs per policy remained below the phase limit, while all original and fresh default healthy runs exceeded it. The programmed 1.1-ms loop still drove job 4 A beyond the same limit in every overrun run, with fewer loop batches as virtual time per instruction increased. The measured empty body scaled near 2× between shifts while host wall duration did not follow that scaling. This establishes clock-model sensitivity and a positive guest-work control. It does not partition the default-clock excess among translation, host scheduling, IRQ delivery or other emulator costs. No per-PC executed-instruction plugin was found installed. Counter deltas under icount describe virtual time, with timer/idle advancement possible. No instruction count is inferred from full release latency. Each boot exited 71/72/73 with 32 COMPLETEs. Results JSON includes every phase, actual COMPLETE brackets and IRQ intersections. Fixed journal coverage ends at its retained prefix. The diagnostic profiles do not change the original admission verdict.','', '동일 커널에서 기본 시계의 정상 사례는 모두 1 ms 위상 제한을 넘었다. 명령당 1·2 ns인 고정 시계에서는 정상 사례 모두 한도 안에 들었고, 의도적으로 1.1 ms 작업을 넣은 job 4 A는 두 시계 모두 한도를 넘었다. 빈 수신 본문의 단계별 시각은 명령 시계 배율을 따랐다. 기본 시계 초과분에서 호스트 스케줄링과 번역 비용이 각각 차지하는 몫은 분리할 수 없다. 실제 장치나 기존 승인 판정에는 적용하지 않는다.']
(out/'REPORT.en-ko.md').write_text('\n'.join(report)+'\n')
