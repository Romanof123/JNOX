import json,os,subprocess,time
from pathlib import Path
import ordinary_amc_capture as module
mode=os.environ['DIAG_MODE']
if mode!='default':
    i=module.FLAGS.index('tcg')
    module.FLAGS[i:i+1]=['tcg,thread=single','-icount',f'shift={mode},align=off,sleep=off']
Popen=subprocess.Popen
class TimedProcess(Popen):
    def __init__(self,args,*a,**kw):
        self.guest=isinstance(args,list) and '-qmp' in args
        if self.guest:self.start_ns=time.monotonic_ns()
        super().__init__(args,*a,**kw)
    def wait(self,*a,**kw):
        result=super().wait(*a,**kw)
        if self.guest:
            end=time.monotonic_ns()
            Path(os.environ['DIAG_HOST']).write_text(json.dumps(dict(start_ns=self.start_ns,end_ns=end,elapsed_ns=end-self.start_ns,pid=self.pid,rc=result)))
            self.guest=False
        return result
subprocess.Popen=TimedProcess
