set -eu
src=$HOME/permit389-fused-c5ab397
out=$HOME/permit389-clock-diag-c5ab397
dest=/mnt/d/codex/permit389-clock-diag-c5ab397
mkdir -p "$out"
cd "$src/src"
for p in fifo rr; do
 for s in healthy overrun; do
  for mode in default 0 1; do
   n=$p-$s-$mode
   mkdir "$out/$n"
   pkg="$src/$p-$s/pkg"
   cp "$pkg/manifest.json" "$out/$n/manifest.json"
   DIAG_HOST="$out/$n/host.json" DIAG_MODE="$mode" PYTHONPATH="$dest:$src/src/tools" python3 tools/native_el0_capture.py "$out/$n/cap" "$pkg/kernel.elf" "$src/sender.elf" examples/native-safety-admission/sender/src/main.rs c5ab397e93d345a4fef4420fe9cf7fa3e4be97ac --manifest "$pkg/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608 > "$out/$n/boot.log" 2>&1 || echo unresolved >> "$out/$n/boot.log"
   (cd "$out/$n"; tar czf "$dest/$n.tgz" .)
   echo "$n"; cat "$out/$n/boot.log"
  done
 done
done
