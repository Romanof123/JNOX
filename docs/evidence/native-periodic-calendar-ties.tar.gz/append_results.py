import pathlib,json
d=pathlib.Path(__file__).parent
p=d/'verification.en-ko.md'
with p.open('a',encoding='utf-8') as f:
 for r in (d,d/'fixed'):
  for name,v in json.loads((r/'replay.json').read_text()).items():
   if 'hz' in v: print(f"| {name} | {v['miss']} | {v['over']} | {v['cancel']} |",file=f)
 print("""
Baseline and corrected compatibility guests both returned 37 for startup and 43 for EDF. All four linked control-loss cases reached CONTROL END and their existing analysis verdict was nonqualifying for actual delivery. The raw binaries were copied per case before the next build and compared to the recorded launch digest. Timing varies with instrumentation. Physical board behavior, physical WCET and byte-for-byte stack contents at deschedule were outside these measurements.

기준과 수정 버전에서 일반 시작은 37, EDF는 43으로 종료되었다. 두 버전의 기존 RM·DM 손실 제어는 모두 CONTROL END에 도달했으나 실제 전달 요건을 충족하지 못했다. 정책별 커널 바이너리를 다음 빌드 전에 각각 보존했다. 실물 보드와 최악 실행시간, 중단 순간의 전체 스택 바이트는 측정하지 않았다.
""",file=f)
