#include <stdint.h>
#include <jnox/periodic.h>

volatile uint32_t report_result[3];
volatile uint32_t report_bytes[3];
volatile uint32_t report_sequence[3];
volatile uint32_t report_count;
volatile uint32_t active_blocks;
volatile uint32_t completed_blocks[3];
static volatile unsigned char ramp[256];

__attribute__((noinline))
uint32_t crc_ramp(uint32_t crc)
{
    for (unsigned i = 0; i < 256; ++i) {
        crc ^= ramp[i];
        for (unsigned bit = 0; bit < 8; ++bit)
            crc = (crc >> 1) ^ (0xedb88320U & (0U - (crc & 1)));
    }
    return crc;
}

__attribute__((noinline))
uint32_t reduce_batch(unsigned generation, unsigned blocks)
{
    uint32_t crc = 0xffffffffU;
    active_blocks = 0;
    for (unsigned i = 0; i < 256; ++i)
        ramp[i] = (unsigned char)(i + generation);
    for (unsigned n = 1; n <= blocks; ++n) {
        crc = crc_ramp(crc);
        active_blocks = n;
        completed_blocks[generation] = n;
    }
    return ~crc;
}

int main(void)
{
    const uint32_t blocks[3] = {64, 131072, 66};
    const uint32_t expected[3] = {0xe81722f0U, 0xfa914cb6U, 0x82e8647bU};
    for (unsigned g = 0; g < 3; ++g) {
        uint32_t crc = reduce_batch(g, blocks[g]);
        if (crc != expected[g] || completed_blocks[g] != blocks[g])
            return 102;
        report_result[g] = crc;
        report_bytes[g] = blocks[g] * 256;
        report_sequence[g] = g + 1;
        report_count = g + 1;
        if (g < 2 && jnox_periodic_wait_next())
            return 105;
    }
    return 17;
}
