# Fixed CRC input for native periodic dispatch

This is a separately frozen population. Keep the original time-based CRC positions and their evidence. Build fixed_crc.c with the same public SDK and pair it with the identical Rust histogram ELF used for the original #301 positions. Record the repository and toolchain identity, both ELF SHA-256 hashes and disassemblies, source hashes, QEMU command, and the common epoch rule before observing results.

~~~sh
sh "$repo/sdk/native-aarch64/build.sh" fixed_crc.c "$out/fixed_crc.elf"
python3 "$repo/tools/build_native_el0.py" --out "$out/rm" --policy rm \
    --elf "$out/fixed_crc.elf" --periodic 0,100000000,90000000 \
    --peer-elf "$histogram_elf" --peer-periodic 0,120000000,40000000
~~~

Repeat with --policy dm and output "$out/dm", holding ELF bytes and tuples fixed. Freeze first RM plain, RM external exception trace, DM plain, DM external exception trace in that order. Use one Cortex-A72, virt/GICv2, 128 MiB, stock physical timer and original external tracing recipe. A failed or interrupted position retains its original capture and verdict.

Generation 0/1/2 processes 64/131072/66 complete 256-byte ramps, or 16384/33554432/16896 bytes. The bytes in each ramp are (index+generation) modulo 256. Expected CRC-32/ISO-HDLC products in generation order are 0xe81722f0, 0xfa914cb6, 0x82e8647b. Check these u32s in report_result, the lengths in report_bytes, the cumulative block counts per generation in completed_blocks, report_sequence=[1,2,3], report_count=3 and exit 17. active_blocks is the current generation's completed block count. The unchanged Rust neighbor reports 8192/8448/8704 bytes, sixteen bins per generation with each bin 512/528/544 respectively, sequence [1,2,3], count 3 and exit 29.

~~~python
import zlib
for g, n in enumerate((64, 131072, 66)):
    ramp = bytes((i + g) % 256 for i in range(256))
    print(g, n * 256, f"{zlib.crc32(ramp * n):08x}")
~~~

Independently replay the anchored RM/DM calendar, misses, overlaps and completions from raw physical counters. At B1 release require evidence of a real physical IRQ from A1 EL0 with the saved PC mapped inside crc_ramp or the reduction loop in reduce_batch. In DM identify B1 selection, service and report, then A1's saved PC/SP restoration, subsequent progress and verified result. In RM check the higher-ranked A incumbent at B1 release and measure when B1 first runs and completes. Report individually whether A1 spanned its deadline or A2 release, whether B1 met its deadline, and each generation's actual miss or completion. A fixed volume of data establishes the expected product; each deadline and preemption verdict requires observation.
