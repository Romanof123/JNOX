import hashlib,json,pathlib
D=pathlib.Path(__file__).resolve().parent
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
records=[]
for root in (D,D/'fixed'):
    for manifest in sorted((root/'elf').glob('*/manifest.json')):
        m=json.loads(manifest.read_text())
        assert m['commit']=='770c19b147877fb5708e4f044233f73048b1c474'
        kernel=manifest.parent/'kernel.elf'
        assert sha(kernel)==m['kernel_elf_sha256']
        for name,digest in m['source_sha256'].items():
            assert sha(root/'elf'/pathlib.Path(name).name)==digest
        records.append([str(kernel.relative_to(D)),sha(kernel)])
for out in sorted((D/'compat').iterdir()):
    for binary in sorted((out/'binaries').glob('*.elf')):
        name=binary.name.split('.')[0]
        assert sha(binary)==(out/(name+'.sha256')).read_text().split()[0]
        records.append([str(binary.relative_to(D)),sha(binary)])
print(json.dumps(records,indent=2))
