set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
S=$D
D=$(dirname "$S")
cd "$D/fixed-crc-inputs"
echo 'deb9e5a964d78c2a3028322e8b18ea7e85bfeea322845acb33728fb5a4377b6e  SHA256SUMS' | sha256sum -c -
sha256sum -c SHA256SUMS
cd "$HOME/jnox301-calendar-src"
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
sh sdk/native-aarch64/build.sh "$D/fixed-crc-inputs/fixed_crc.c" "$S/elf/fixed_crc.elf"
cp "$D/elf/histogram.elf" "$S/elf/"
for a in "$S"/elf/*.elf; do aarch64-linux-gnu-nm -nS "$a" > "$a.sym"; aarch64-linux-gnu-objdump -d "$a" > "$a.dis"; done
for mode in rm dm; do
 b="$HOME/jnox301-calendar-pkgs/fixed$mode"; out="$S/elf/fixed$mode"; mkdir -p "$out"
 python3 tools/build_native_el0.py --out "$b" --policy "$mode" --elf "$S/elf/fixed_crc.elf" --periodic 0,100000000,90000000 --peer-elf "$S/elf/histogram.elf" --peer-periodic 0,120000000,40000000 > "$out/package.log" 2>&1
 cp "$b/"{kernel.elf,manifest.json,build.log} "$out/"
done
cd "$S"
python3 -c 'import zlib; v=[zlib.crc32(bytes((i+g)%256 for i in range(256))*b) for g,b in enumerate((64,131072,66))]; assert v==[0xe81722f0,0xfa914cb6,0x82e8647b]; print([hex(x) for x in v])' > expected.txt
sha256sum cases capture.py expected.txt elf/*.elf elf/*/kernel.elf > prelaunch.sha256
python3 capture.py > capture.log