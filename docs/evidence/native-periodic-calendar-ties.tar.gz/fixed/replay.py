import json, re, zlib, pathlib, struct
D=pathlib.Path(__file__).parent
NA=(1<<64)-1
results={}
for r in sorted((D/'runs').iterdir()):
 label=r.name; case=label.split('-')[0]
 uart=(r/'uart.log').read_text()
 apps=json.loads((r/'command.json').read_text())['apps']
 ram=json.loads((r/'ram.json').read_text())
 exits=[int(s.split()[-1]) for s in uart.splitlines() if s.startswith('NATIVE EL0 EXIT')]
 assert exits==[dict(fixed_crc=17,crc=17,crc_overrun=17,histogram=29,sleep_backlog=53,yield_report=43,unsupported=59)[a] for a in apps],(label,exits)
 result=results[label]={'exits':exits,'products':[]}
 for a,v in zip(apps,ram):
  vals={k:list(struct.unpack('<'+'I'*(len(h)//8),bytes.fromhex(h))) for k,h in v.items()}
  if a=='unsupported':
   assert vals==dict(recorded_result=[0xffffffff],recorded_errno=[95])
  elif a=='sleep_backlog':
   assert vals['report_count']==[1] and int.from_bytes(bytes.fromhex(v['observed_ns']),'little')>=int.from_bytes(bytes.fromhex(v['request_ns']),'little')
  else:
   assert vals['report_sequence']==[1,2,3] and vals['report_count']==[3]
   sizes=vals['report_bytes']; actual=vals['report_result']
   if a=='fixed_crc':
    assert sizes==[16384,33554432,16896] and vals['completed_blocks']==[64,131072,66]
    expect=[zlib.crc32(bytes((i+g)%256 for i in range(256))*(size//256)) for g,size in enumerate(sizes)]
   elif a.startswith('crc'):
    assert sizes[0]==16384 and sizes[2]==16896 and sizes[1]%256==0
    if a=='crc':assert sizes[1]==16640
    else:
     assert 65<sizes[1]//256<=262144
     duration=int.from_bytes(bytes.fromhex(v['extra_end_ns']),'little')-int.from_bytes(bytes.fromhex(v['extra_start_ns']),'little')
     assert duration>110000000
     result['extra_ns']=duration
    expect=[zlib.crc32(bytes((i+g)%256 for i in range(256))*(size//256)) for g,size in enumerate(sizes)]
   elif a=='histogram':
    assert sizes==[8192,8448,8704]
    expect=[sum(((17*i+g)%256)>>4==b for i in range(n)) for g,n in enumerate(sizes) for b in range(16)]
   else:
    assert sizes==[256]*3
    expect=[16,32,48]
   assert actual==expect,(label,a)
  result['products'].append(vals)
 if case=='unsupported':continue
 def data(kind):return [list(map(int,s.split()[3:])) for s in uart.splitlines() if s.startswith('NATIVE PERIODIC '+kind+' ')]
 epoch,hz,dm=data('CONFIG')[0]; jobs=data('JOB'); rows=data('EVENT')
 assert data('DROPPED')==[[0]] and not data('REJECT') and hz==62500000
 runtime=[dict(g=0,n=0,miss=set(),over=0,exit=0,sleep=0,service=0,cancel=0) for j in jobs]
 saved={}; prev=NA; compare=min(j[4] for j in jobs); commits=[]; switches=[]; first_ready=[]; ties=[]; queue=[]
 for index,row in enumerate(rows):
  cause,now,old,new,start,elapsed,ret,oldcmp,cmp,target,g,release,deadline,order,suspended,exited,pc,sp,rpc,rsp,frame,rframe,status=row[:23]
  assert len(row)==51 and old==prev and oldcmp==compare and (new==NA or ret>=now)
  if old!=NA:
   j=jobs[old]; st=runtime[old]
   assert (g,release,deadline)==(st['g'],j[4]+g*j[5],j[4]+g*j[5]+j[6])
   assert elapsed==now-start and start==prevret
   st['service']+=elapsed
   saved[old]=(pc,sp,frame)
  active=[]; arrivals=[]; compares=[]
  for i,(j,st) in enumerate(zip(jobs,runtime)):
   _,phase,p,d,first,period,dl=j
   assert (first-epoch)*10**9==phase*hz and period*10**9==p*hz and dl*10**9==d*hz
   wasready=st['g']<st['n'] and not st['sleep'] and not st['exit']
   if not st['exit']:
    prior_n=st['n']; wake=st['sleep']
    while first+st['n']*period<=now:
     gen=st['n']; at=first+gen*period
     if gen>st['g']+(old==i and cause in (3,9) and at==now):st['over']+=1
     st['n']+=1
     first_ready.append([i,gen,now-at])
    for gen in range(st['g'],st['n']):
     if first+gen*period+dl<now:st['miss'].add(gen)
    if old==i and cause in (3,9):
     commits.append(dict(slot=i,g=g,completion=now,deadline=deadline,delta=now-deadline))
     st['g']+=1
     if cause==3:
      st['exit']=now; st['cancel']=st['n']-st['g']
    if old==i and cause==2:st['sleep']=target
    if st['sleep']<=now:st['sleep']=0
    if st['n']>st['g'] and not st['sleep'] and not st['exit']:
     active.append(i)
     if not wasready:arrivals.append((max(first+prior_n*period if prior_n==st['g'] else 0,wake),i))
     elif i==old and cause in (1,9):arrivals.append((now,i))
    if not st['exit']:
     compares.append(first+st['n']*period)
     for gen in range(st['g'],st['n']):
      due=first+gen*period+dl
      if gen not in st['miss']:compares.append(due+(due==now))
     if st['sleep']:compares.append(st['sleep'])
   base=23+9*i
   assert row[base:base+3]==[st['g'],st['n'],len(st['miss'])],(label,index,st,row)
   assert row[base+4:base+9]==[st['over'],st['cancel'],st['service'],st['sleep'],st['exit']],(label,index,st,row)
  if old in active and cause not in (1,9):queue.insert(0,old)
  queue.extend(i for _,i in sorted(arrivals))
  assert sorted(queue)==active,(label,index,queue,active)
  want=min(queue,key=lambda i:jobs[i][6 if dm else 5]) if queue else NA
  assert new==want,(label,index,new,want)
  if new!=NA:queue.remove(new)
  packed=0
  for i in queue:packed=packed*16+i+1
  assert order==packed and row[50]==sum(1<<i for i in active)
  assert suspended==sum(1<<i for i,st in enumerate(runtime) if st['sleep']) and exited==sum(1<<i for i,st in enumerate(runtime) if st['exit'])
  assert cmp==min(compares,default=0)
  if new!=NA and new in saved:
   assert saved[new]==(rpc,rsp,rframe),(label,index,saved[new],rpc,rsp,rframe)
  if new!=old:switches.append([index,cause,old,new,now,pc,sp,rpc,rsp])
  prev=new;compare=cmp;prevret=ret
 assert all(st['exit'] for st in runtime)
 result.update(hz=hz,epoch=epoch,mode=dm,miss=[sorted(st['miss']) for st in runtime],over=[st['over'] for st in runtime],cancel=[st['cancel'] for st in runtime],service=[st['service'] for st in runtime],commits=commits,switches=switches,release_observations=first_ready)
 if 'over' in case:
  assert result['miss']==([[1],[1]] if case=='rmover' else [[1],[]]) and result['over'][0]==1
  if case=='dmover':
   change=next(s for s in switches if s[2:4]==[0,1] and s[4]>jobs[1][4]+jobs[1][5])
   if label.endswith('traced'):
    external=(r/'exceptions.log').read_text()
    assert f'with ELR {hex(change[5])}' in external and f'to AArch64 EL0 PC {hex(change[5])}' in external
 elif case=='sleep':assert result['cancel'][0]>=3
 elif case.startswith('fixed'):
  assert result['miss'][1]==([1,2] if case=='fixedrm' and 2 in result['miss'][1] else [1] if case=='fixedrm' else [])
  if dm:
   change=next(s for s in switches if s[1:4]==[4,0,1] and s[4]>=jobs[1][4]+jobs[1][5]); assert next(s for s in switches if s[4]>change[4] and s[3]==0)[7:9]==change[5:7]
   if label.endswith('traced'):
    trace=(r/'exceptions.log').read_text(); assert re.search(r'Taking exception 5 \[IRQ\].*?with ELR '+hex(change[5]),trace,re.S) and 'to AArch64 EL0 PC '+hex(change[5]) in trace
 else:assert not any(result['miss'])
 print(label,result['miss'],result['over'],result['cancel'])
(D/'replay.json').write_text(json.dumps(results,indent=2))