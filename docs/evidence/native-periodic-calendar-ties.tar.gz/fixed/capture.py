import json, re, subprocess as sp, time, pathlib, os, sys
D=pathlib.Path(__file__).resolve().parent
cases={s[0]:[x.split(':')[0] for x in s[2:]] for s in (l.split() for l in (D/'cases').read_text().splitlines())}
order=[n+'-'+m for n in cases for m in ('plain','traced')]
for label in order:
 name,mode=label.split('-');apps=cases[name]; kernel=D/'elf'/name/'kernel.elf';r=D/'runs'/label;r.mkdir()
 sym=sp.check_output(['aarch64-linux-gnu-nm','-S',kernel],text=True)
 base,size=[int(x,16) for x in next(l for l in sym.splitlines() if '6SPACES' in l).split()[:2]]
 stride=0x415000; assert size==stride*len(apps)
 fields=[]
 for i,app in enumerate(apps):
  items={}
  for line in (D/'elf'/(app+'.elf.sym')).read_text().splitlines():
   s=line.split()
   if len(s)==4 and s[-1] in ('report_count','report_result','report_bytes','report_sequence','request_ns','observed_ns','recorded_result','recorded_errno','active_blocks','extra_start_ns','extra_end_ns','completed_blocks'):
    items[s[-1]]=(base+i*stride+5*4096+int(s[0],16)-0x400000,int(s[1],16))
  fields.append(items)
 args=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-no-reboot','-qmp','stdio','-serial','file:'+str(r/'uart.log')]+(['-d','int','-D',str(r/'exceptions.log')] if mode=='traced' else [])+['-kernel',str(kernel)]
 (r/'command.json').write_text(json.dumps(dict(argv=args,fields=fields,apps=apps)))
 with (r/'stderr').open('w') as err,sp.Popen(args,stdin=sp.PIPE,stdout=sp.PIPE,text=True,stderr=err) as p:
  def read():
   while True:
    data=json.loads(p.stdout.readline())
    if 'event' not in data:return data
  def cmd(name,**kw):
   p.stdin.write(json.dumps(dict(execute=name,arguments=kw))+'\n');p.stdin.flush();return read()['return']
  def mem(a,n):
   out=cmd('human-monitor-command',**{'command-line':f'xp /{n}bx {a:#x}'})
   return bytes(int(b,16) for l in out.splitlines() for b in re.findall(r'0x([0-9a-fA-F]{2})\b',l.split(':',1)[1]))
  try:
   read();cmd('qmp_capabilities');start=time.monotonic()
   with (r/'progress.jsonl').open('w') as obs:
    while True:
     print(json.dumps([time.monotonic_ns(),[{k:int.from_bytes(mem(*v[k]),'little') for k in ('report_count','active_blocks') if k in v} for v in fields]]),file=obs,flush=True)
     uart=(r/'uart.log').read_text(errors='replace')
     if uart.count('NATIVE EL0 EXIT')>=len(apps) or 'NATIVE EDF REFUSED' in uart or 'FAULT' in uart or 'FAIL' in uart or time.monotonic()-start>12:break
     time.sleep(.012)
   cmd('stop');(r/'private-stack.hex').write_text(mem(base+5*4096+0x400000+0xff00,256).hex());(r/'ram.json').write_text(json.dumps([{k:mem(*v).hex() for k,v in f.items()} for f in fields]))
   cmd('quit');p.wait(4)
  finally:
   if p.poll() is None:p.kill();p.wait()
   (r/'status').write_text(str(p.returncode))
 print(label,uart[-170:],flush=True)
