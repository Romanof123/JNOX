use super::{native_periodic_policy::{Action, Calendar}, dispatch_policy::DispatchPolicy};
use Action::{Poll, WaitNext, Exit, Yield};
#[derive(Clone, Copy)]
struct Job { release: u64, deadline: u64, done: Option<u64> }

#[test]
fn explicit_generation_histories() {
    let mut verified = 0;
    for p in [DispatchPolicy::RateMonotonic, DispatchPolicy::DeadlineMonotonic] {
        for deadline in [2,4] {
            for t in [4,5,8,9,12,13] {
                for polls in 0..=3 {
                    for commits in 1..=4 {
                        for last in [WaitNext,Exit] {
                            let mut c=Calendar::new(p,[[0,4,deadline]],1_000_000_000,0).unwrap();
                            let mut jobs:Vec<Job>=(0..8).map(|g|Job{release:4*g, deadline:4*g+deadline, done:None}).collect();
                            c.step(0,Poll).unwrap();
                            for _ in 0..polls {c.step(t,Poll).unwrap();}
                            let mut exit=None;
                            for i in 0..commits {
                                if c.owner().is_none(){break;}
                                let action=if i+1==commits {last} else {WaitNext};
                                let j=jobs.iter_mut().find(|j|j.release<=t && j.done.is_none()).unwrap();
                                j.done=Some(t);
                                if action==Exit {exit=Some(t);}
                                c.step(t,action).unwrap();
                                let issued:Vec<_>=jobs.iter().filter(|j| j.release<=t && (exit.is_none() || j.release<t || j.done.is_some())).collect();
                                let overlaps=issued.iter().filter(|j| issued.iter().any(|old| old.release<j.release && old.done.is_none_or(|end|end>j.release))).count();
                                let missed=issued.iter().filter(|j|j.deadline<j.done.unwrap_or(t)).count();
                                let complete=issued.iter().filter(|j|j.done.is_some()).count();
                                let cancelled=if exit.is_some(){issued.len()-complete}else{0};
                                let s=c.slot(0).unwrap();
                                assert_eq!([s.released,s.generation,s.overlaps,s.missed,s.cancelled],[issued.len(),complete,overlaps,missed,cancelled].map(|n|n as u64), "t={t} polls={polls} i={i}");
                                assert_eq!(c.owner(), (exit.is_none() && issued.len()>complete).then_some(0));
                                verified+=1;
                            }
                        }
                    }
                }
            }
        }
    }
    println!("explicit per-generation snapshot comparisons {verified}");
}
#[test]
fn fifo_chronology() {
    for p in [DispatchPolicy::RateMonotonic, DispatchPolicy::DeadlineMonotonic] {
        for a in 0..3 {
            for b in (0..3).filter(|b|*b!=a) {
                let old=3-a-b;
                for dup in 0..=3 {
                    for end in [WaitNext, Exit] {
                        let mut spec=[[0,4,4];3]; spec[b][0]=4;
                        let mut c=Calendar::new(p,spec,1_000_000_000,0).unwrap();
                        c.step(0,Poll).unwrap();
                        if c.owner()!=Some(a) {c.step(0,Yield).unwrap();}
                        assert_eq!(c.owner(),Some(a));
                        for _ in 0..dup {assert_eq!(c.step(4,Poll).unwrap(),Some(a));}
                        let mut queue=vec![old]; // waiting since time zero
                        for id in 0..3 {if id==b || (id==a && end==WaitNext){queue.push(id);}}
                        assert_eq!(c.step(4,end).unwrap(),Some(queue[0]));
                        for id in &queue[1..]{assert_eq!(c.step(4,Yield).unwrap(),Some(*id));}
                    }
                }
            }
        }
    }
}
