set -eu
D=$(cd "$(dirname "$0")" && pwd)
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
cd ~/jnox301-calendar-src
git worktree add --detach ~/jnox301-calendar-main 33ee8c35a62ede54987f9af4ae51d3f2fcea3d35
for source in calendar-main calendar-src; do
 cd "$HOME/jnox301-$source"
 out="$D/compat/$source"; mkdir -p "$out"
 git rev-parse HEAD > "$out/source.txt"
 for app in startup edf control-rm control-dm; do
  build="$HOME/jnox301-calendar-pkgs/$source-$app"
  case $app in
   startup) python3 tools/build_native_el0.py --out "$build" > "$out/$app.build" 2>&1; kernel=$build/kernel.elf;;
   edf) python3 tools/build_native_el0.py --source examples/native-edf/urgent.c --policy edf --job 1,4,1 --out "$build" > "$out/$app.build" 2>&1; kernel=$build/kernel.elf;;
   *) (cd kernel && JNOX_BOARD=virt JNOX_PROFILE=periodic JNOX_APP=$app JNOX_CONTROL_CASE=loss cargo build --locked --release > "$out/$app.build" 2>&1); kernel=$PWD/kernel/target/aarch64-unknown-none/release/jnox-kernel;;
  esac
  mkdir -p "$out/binaries"
  cp "$kernel" "$out/binaries/$app.kernel.elf"
  cmp "$kernel" "$out/binaries/$app.kernel.elf"
  sha256sum "$kernel" > "$out/$app.sha256"
  timeout 4 qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -accel tcg -m 128M -nodefaults -display none -monitor none -serial stdio -kernel "$kernel" > "$out/$app.uart" 2> "$out/$app.stderr" || test "$?" = 124
  if [[ $app = control-* ]]; then python3 tools/control_observations.py loss "$out/$app.uart" > "$out/$app.analysis" 2>&1 || echo $? > "$out/$app.analysis-status"; fi
 done
done