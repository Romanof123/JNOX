#[test]
fn committed_preemption_then_late_owner() {
    for policy in [DispatchPolicy::RateMonotonic,DispatchPolicy::DeadlineMonotonic] {
        let mut c=Calendar::new(policy,[[0,4,4],[4,2,2]],1_000_000_000,0).unwrap();
        assert_eq!(c.step(0,Poll).unwrap(),Some(0));
        assert_eq!(c.step(4,Poll).unwrap(),Some(1));
        assert_eq!(c.step(4,Poll).unwrap(),Some(1));
        assert_eq!(c.step(4,Exit).unwrap(),Some(0));
        let issued=c.slot(1).unwrap();
        assert_eq!((issued.released,issued.generation,issued.cancelled,issued.missed),(1,1,0,0));
        assert_eq!(c.step(5,WaitNext).unwrap(),Some(0));
        let delayed=c.slot(0).unwrap();
        assert_eq!((delayed.released,delayed.generation,delayed.overlaps,delayed.missed),(2,1,1,1));
    }
}
