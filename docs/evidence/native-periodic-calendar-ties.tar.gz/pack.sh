set -euo pipefail
cd "$(dirname "$0")"
find . -path ./source -prune -o -type f ! -name PACKET-SHA256 -print0 | sort -z | xargs -0 sha256sum > PACKET-SHA256
dest=../jnox301-calendar-770c19b-portable.tar.gz
tar --exclude=./source -czf "$dest" .
verify=$(mktemp -d)
tar -xzf "$dest" -C "$verify"
(cd "$verify" && sha256sum -c PACKET-SHA256 > /dev/null && python3 verify_images.py >/dev/null && python3 replay.py >/dev/null && python3 fixed/replay.py >/dev/null)
sha256sum "$dest" > "$dest.sha256"
cat "$dest.sha256"
