set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
cd "$HOME/jnox301-calendar-src"
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH"
test "$(git rev-parse HEAD)" = 770c19b147877fb5708e4f044233f73048b1c474
temp=$(mktemp tools/calendar-review-XXXXXX.rs)
trap 'rm -f "$temp"' EXIT
cat tools/scheduling_tests.rs > "$temp"
printf '\n#[path="%s/calendar_oracle.rs"] mod independent_calendar;\n' "$D" >> "$temp"
rustc --crate-name calendar_review --edition=2024 --test "$temp" -o "$HOME/jnox301-calendar-tests" > "$D/host-build.log" 2>&1
"$HOME/jnox301-calendar-tests" --test-threads=1 --nocapture > "$D/host-results.txt"
