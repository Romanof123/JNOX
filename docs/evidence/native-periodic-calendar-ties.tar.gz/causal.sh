set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH"
cd "$HOME/jnox301-calendar-src"
git worktree add --detach "$HOME/jnox301-calendar-original" 4a0c17a7025d663d90b67535ccc27b594277ec08
for version in src original; do
 cd "$HOME/jnox301-calendar-$version"
 temp=$(mktemp tools/calendar-causal-XXXXXX.rs)
 cat tools/scheduling_tests.rs > "$temp"
 printf '\n#[path="%s/calendar_oracle.rs"] mod independent_calendar;\n' "$D" >> "$temp"
 printf '\nmod causal { use super::{native_periodic_policy::{Action::*,Calendar},dispatch_policy::DispatchPolicy}; include!("%s/causality.rs"); }\n' "$D" >> "$temp"
 rustc --crate-name calendar_causal --edition=2024 --test "$temp" -o "$HOME/jnox301-calendar-causal" > "$D/$version-causal-build.log" 2>&1
 "$HOME/jnox301-calendar-causal" --test-threads=1 --nocapture causal:: > "$D/$version-causal.log"
 if [ "$version" = original ]; then
   if "$HOME/jnox301-calendar-causal" --test-threads=1 independent_calendar:: > "$D/original-oracle.log"; then exit 1; fi
 fi
 rm -f "$temp"
done
