set -euo pipefail
D=$(cd "$(dirname "$0")/.." && pwd)
repo=${1:-"$HOME/jnox301-calendar-src"}
original=4a0c17a7025d663d90b67535ccc27b594277ec08
corrected=770c19b147877fb5708e4f044233f73048b1c474
url=https://github.com/Romanof123/JNOX.git
if [ ! -d "$repo/.git" ]; then
  git clone --no-checkout "$url" "$repo"
  git -C "$repo" fetch origin refs/pull/301/head
  git -C "$repo" checkout --detach "$corrected"
fi
test "$(git -C "$repo" rev-parse HEAD)" = "$corrected"
test "$(git -C "$repo" rev-parse "$original^{tree}")" = ec02297ad448e90453f8a3818bf1fd937d7f324f
test "$(git -C "$repo" rev-parse "$corrected^{tree}")" = fe5d3df5c326eacc4cc40aec74f54cddcbdf2e3e
git -C "$repo" archive "$corrected" | gzip > "$D/input-source.tar.gz"
(cd "$D" && sha256sum -c transport/original-inventory.sha256 >/dev/null)
