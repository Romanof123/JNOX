import sys, os, json, subprocess, re, zipfile, hashlib, platform
from pathlib import Path
root=Path(sys.argv[1]).resolve()
base=Path(__file__).resolve().parent
tools=root/'tools'
cli=tools/'scheduling_evidence.py'
docs=root/'docs'
paths=[docs/('scheduling-release-cases'+s) for s in ('.en.md','.md')]
trace=root/'trace/links.csv'
orig={p:p.read_bytes() for p in [trace]+paths}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()=='bc5732ab0c7613194169453e632d1c38c6079db4'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=root)
guard="""import sys,runpy,os
def audit(event,args):
 if event.startswith('socket.'): raise RuntimeError(event)
sys.addaudithook(audit)
script=sys.argv.pop(1)
sys.path.insert(0,os.path.dirname(script))
sys.argv[0]=script
runpy.run_path(script,run_name='__main__')"""
env=dict(os.environ,PYTHONIOENCODING='utf-8')
def call(args):
 return subprocess.run([sys.executable,'-X','utf8','-B','-I','-S','-c',guard]+list(map(str,args)),cwd=root,capture_output=True,env=env)
results={}
msg='catalog and direct implementation cite EVD-058 without a typed POL-015 evidence link'
def check(name,findings,script=None):
 p=call([script or cli,'--root',root])
 r=json.loads(p.stdout)
 assert (p.returncode,r['findings'])==(int(bool(findings)),findings),(name,p.returncode,r['findings'])
 results[name]=[p.returncode,r['findings']]
 return r
def mutate(lang,cell,third='pending',extra=''):
 for i,p in enumerate(paths):
  t=orig[p].decode('utf-8').replace(chr(13)+chr(10),chr(10))
  row='| POL-015 | '+(cell if i==lang else 'context')+' | '+(third if i==lang else 'pending')+' |'
  t=re.sub(r'^\| POL-015 \|.*$',lambda _:row,t,flags=re.M)
  p.write_text(t+('\n\n'+extra+'\n' if i==lang else ''),encoding='utf-8')
try:
 r=check('intact',[])
 assert len(r['policies'])==18 and 'EVD-057' in r['policies']['POL-014']['claims']['live_switch']
 trace.write_bytes(re.sub(rb'^POL-015,has-partial-policy-evidence,EVD-058\r?\n',b'',orig[trace],flags=re.M))
 check('primary omission',[msg])
 for i,lang in enumerate(['en','ko']):
  link='[EVD-058](a(b)c.md)'
  for key,cell,third,extra,hit in [
   ('inline',r'x \| '+link,'','','yes'),('reference',r'x \| [EVD-058][case]','','[case]: record.md','yes'),
   ('collapsed','[EVD-058][]','','[EVD-058]: record.md','yes'),('shortcut','[EVD-058]','','[EVD-058]: record.md','yes'),
   ('undefined','[EVD-058][case]','','',''),('code','`'+link+'`','','',''),('comment','<!-- '+link+' -->','','',''),
   ('escape',chr(92)+link,'','',''),('image','!'+link,'','',''),('unlinked','EVD-058','','',''),
   ('third','record',link,'',''),('prose','record','','See '+link,''),
   ('other','record','','| Category | Record | Pending |\n|---|---|---|\n| POL-015 | '+link+' | pending |',''),
   ('row outside','record','','| POL-015 | '+link+' | pending |',''),
   ('shared','[EVD-057](x)','','',''),('formatted','[**EVD-058**](x)','','','')]:
   mutate(i,cell,third,extra)
   check(lang+' '+key,[msg] if hit else [])
 for p in paths:p.write_bytes(orig[p])
 trace.write_bytes(re.sub(rb'^POL-014,has-switch-evidence,EVD-057\r?\n',b'',orig[trace],flags=re.M))
 check('mutex omission',[msg.replace('058','057').replace('015','014')])
 for p,b in orig.items():p.write_bytes(b)
 for rev in ['b129f1f','08219c9']:
  script=base/'historical.py'
  script.write_bytes(subprocess.check_output(['git','show',rev+':tools/scheduling_evidence.py'],cwd=root))
  trace.write_bytes(re.sub(rb'^POL-015,has-partial-policy-evidence,EVD-058\r?\n',b'',orig[trace],flags=re.M))
  for key,cell,extra in [('pipe',r'x \| [EVD-058](x)',''),('code','`[EVD-058](x)`',''),('ref','[EVD-058][ref]','[ref]: x')]:
   mutate(0,cell,'pending',extra)
   p=call([script,'--root',root]); results[rev+' '+key]=[p.returncode,json.loads(p.stdout)['findings']]
 script.unlink()
finally:
 for p,b in orig.items():p.write_bytes(b)
for name,args in [('scheduling suite',[tools/'test_scheduling_evidence.py']),('graph suite',[tools/'test_requirement_graph.py']),('graph',[tools/'requirement_graph.py'])]:
 p=call(args); assert p.returncode==0,(name,p.stderr);results[name]=[p.returncode,p.stderr.decode().strip(),len(p.stdout.splitlines())]
probe=base/'probe.py'
probe.write_text("import runpy,sys\nrunpy.run_path(sys.argv[1])\nfor n in ['markdown_it','mdurl']: print(sys.modules[n].__file__)\n")
p=call([probe,cli]); probe.unlink(); assert p.returncode==0
results['imports']=p.stdout.decode().splitlines()
for (pkg,h),f,origin in zip([('markdown_it','355216845c60bd96232cd8d8c40e8f9765cc86f46880e43a8fd22dc1a1a8cab1'),('mdurl','84008a41e51615a49fc9966191ff91509e3c40b939176e643fd50a5c2196b8f8')],sorted((tools/'vendor/scheduling_markdown').glob('*.whl')),results['imports']):
 assert origin.startswith(str(f)+os.sep) and hashlib.sha256(f.read_bytes()).hexdigest()==h
 with zipfile.ZipFile(f) as z:
  licenses={n:z.read(n).decode() for n in z.namelist() if 'LICENSE' in n.upper()}
  assert any('permission is hereby granted' in t.lower() for t in licenses.values())
  results[f.name]=[h,{n:[x for x in t.splitlines() if 'copyright' in x.lower()][:6] for n,t in licenses.items()}]
results['environment']=[platform.platform(),sys.version]
(base/'results.json').write_text(json.dumps(results,indent=2),encoding='utf8')


