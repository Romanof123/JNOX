import sys,subprocess,json,re
from pathlib import Path
root=Path(sys.argv[1]).resolve()
here=Path(__file__).resolve().parent
edge=root/'trace/links.csv'
orig=edge.read_bytes()
assert not subprocess.check_output(['git','diff','--name-only'],cwd=root)
try:
 for rev in ['07fe7ef','b129f1f','08219c9','bc5732a']:
  for p in ['docs/scheduling-release-cases.md','docs/scheduling-release-cases.en.md','trace/links.csv','tools/scheduling_evidence.py']:
   (root/p).write_bytes(subprocess.check_output(['git','show',rev+':'+p],cwd=root))
  for mode in ['intact','omit']:
   if mode=='omit':edge.write_bytes(re.sub(rb'^POL-015,has-partial-policy-evidence,EVD-058\r?\n',b'',edge.read_bytes(),flags=re.M))
   run=subprocess.run([sys.executable,'-X','utf8','-B','-E','-s','-S',str(root/'tools/scheduling_evidence.py')],capture_output=True)
   r=json.loads(run.stdout)
   print(rev,mode,run.returncode,json.dumps(r['findings']))
finally:
 subprocess.run(['git','restore','--','docs/scheduling-release-cases.md','docs/scheduling-release-cases.en.md','trace/links.csv','tools/scheduling_evidence.py'],cwd=root,check=True)
