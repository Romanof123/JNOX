import json,hashlib
from pathlib import Path
out={}
for name in ('pending-a','pending-b'):
 src=Path.home()/'jnox406-lab/426-pending-01'/name
 d=json.loads((src/'result.json').read_bytes())
 d['pcap_sha256']=hashlib.sha256((src/'wire.pcap').read_bytes()).hexdigest()
 d['uart_exits']=[line for line in (src/'uart.log').read_text().splitlines() if 'EXIT PID' in line]
 d['capture_files']=[p.name for p in sorted(src.iterdir()) if p.is_file()]
 out[name]=d
 print(name,{k:d[k] for k in ('epochs','unreaped_id','outstanding_id','ingress_packets','roots','uart_exits')})
Path('/mnt/d/codex/jnox426-replacement/pending-measured.json').write_text(json.dumps(out,indent=2)+'\n')
