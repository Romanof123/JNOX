# Independent pending IRQ evidence / 독립 검증

Both archived native QEMU runs passed the standard-library reader. The directed kernel image SHA-256 is b044f3a99e22a462462a1e7c0ab72404d39390290869c4ff48c817ff39ae0fc7. The per-run JSON records distinct old/new nonces, PCAP and trace hashes, three embedded application identities, and line numbers in the original machine log.

The paused WAIT checkpoint has two ingress records, the EL1 interrupt mask set, and a physical used head of two. The next checkpoint adds one Ethernet record. Its payload matches descriptor 2's DMA bytes and the protected byte record. Both NIC and GIC input assert and the raw pending and device bits read high. The trace interval contains no CPU acknowledgment for IRQ 79. The device mask, transport acknowledgement, GIC pending clear and verified queue reset precede the replacement queue. All 80 new frames and the 60-byte ACK match survivor private memory. Both captures record only the two expected fixture gate writes. Gate files describe the observer's recorded writes. They do not independently audit every possible debugger operation.

두 캡처 모두 이전 드라이버의 인터럽트가 마스크된 종료 대기 구간에서 세 번째 패킷이 도착했고 물리 링의 완료 인덱스가 2에서 3으로 증가했다. 패킷 캡처, DMA 버퍼, 보호된 바이트 기록이 일치했다. IRQ 79의 입력과 pending 비트가 올라갔고 CPU가 해당 IRQ를 인수하기 전에 마스크, 장치 ACK, GIC pending 해제, 큐 리셋이 완료됐다. 새 세대에서 이전 IRQ에 의한 깨움은 관찰되지 않았고 수신 프로세스의 사설 메모리에서 새 패킷 80개와 ACK를 확인했다. 호스트 메모리 쓰기의 검증 범위는 기록된 게이트 쓰기 두 건이다.

Reproduce each offline result with Python 3.8+ and the corresponding capture directory.

```sh
python3 -B reader.py BUILD CAPTURE
```
