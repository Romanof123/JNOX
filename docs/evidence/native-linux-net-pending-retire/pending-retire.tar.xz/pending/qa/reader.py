"""Offline physical-page/ELF and trace reader. Usage: reader.py PACKAGE CAPTURE"""
import hashlib
import io
import json
import re
import struct
import sys
from pathlib import Path


MASK = 0x0000fffffffff000
STAGES = ("preexit", "middle", "spare", "active", "final")


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def load(path):
    return json.loads(path.read_bytes())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def words(data):
    return [x for x, in struct.iter_unpack("<Q", data)]


class Image:
    def __init__(self, path):
        self.data = path.read_bytes()
        raw=self.data
        need(raw[:6]==b"\x7fELF\x02\x01","little endian ELF64")
        kind,arch,_,self.entry,ph,sh,_,_,ps,pn,ss,sn,_=struct.unpack_from("<HHIQQQIHHHHHH",raw,16)
        need((kind,arch)==(2,183),"AArch64 executable")
        self.loads=[]
        for i in range(pn):
            typ,flags,off,va,_,length,_,_=struct.unpack_from("<IIQQQQQQ",raw,ph+i*ps)
            if typ==1 and flags&1:
                self.loads.append((va,raw[off:off+length]))
        sections=[struct.unpack_from("<IIQQQQIIQQ",raw,sh+i*ss) for i in range(sn)]
        self.symbols={}
        for _,typ,_,_,off,length,link,_,_,stride in sections:
            if typ!=2:
                continue
            stringbase=sections[link][4]
            for pos in range(off,off+length,stride):
                name,_,_,_,value,size=struct.unpack_from("<IBBHQQ",raw,pos)
                begin=stringbase+name
                self.symbols[raw[begin:raw.index(0,begin)].decode()]=(value,size)
    def code(self, pc):
        return next(raw[pc-base:pc-base+4] for base, raw in self.loads if base <= pc <= base+len(raw)-4)


class Memory:
    def __init__(self, path):
        self.raw = {k: bytes.fromhex(v) for k, v in load(path).items()}
        self.private = [set() for _ in range(3)]

    def read(self, addr, size):
        return self.raw[f"{addr:x}/{size}"]

    def leaf(self, root, va):
        table = root & MASK
        for shift in (30, 21, 12):
            entry = int.from_bytes(self.read(table + 8*((va >> shift) & 511), 8), "little")
            need(entry & 3 == 3, "invalid translation")
            table = entry & MASK
        return entry

    def region(self, va, size, root=None, slot=None, execute=False):
        data = bytearray()
        while size:
            n = min(size, 4096-va%4096)
            pa = va
            if root is not None:
                desc = self.leaf(root, va)
                need(((desc >> 6)&3, (desc >> 54)&1, (desc >> 53)&1) == ((3,0,1) if execute else (1,1,1)), "private permissions")
                pa = (desc & MASK) + va%4096
                self.private[slot].add(desc & MASK)
            data.extend(self.read(pa,n))
            va += n
            size -= n
        return bytes(data)


def wire(out):
    data = (out/"host.bin").read_bytes()
    host = []
    while data:
        n = int.from_bytes(data[:4], "big")
        need(0 < n <= len(data)-4, "socket length")
        host.append(data[4:4+n])
        data = data[4+n:]
    stream = io.BytesIO((out/"wire.pcap").read_bytes())
    hdr = stream.read(24)
    endian = {b"\xd4\xc3\xb2\xa1":"<", b"\xa1\xb2\xc3\xd4":">"}[hdr[:4]]
    for frame in host:
        _, _, size, orig = struct.unpack(endian+"4I", stream.read(16))
        need(orig == size and stream.read(size) in [bytes(i)+frame for i in (0,10,12)], "PCAP mismatch")
    need(not stream.read(1) and len(host)==84, "PCAP count")
    nonce = (out/"nonce.bin").read_bytes()
    mac = bytes.fromhex(load(out/"launch.json")["mac"].replace(":",""))
    need(len(nonce)==16 and nonce[:8]!=nonce[8:] and all(any(n) for n in (nonce[:8],nonce[8:])), "epoch nonce")
    prefix = mac+bytes.fromhex("024a4e4f580188b5")
    for i,frame in enumerate(host[:-1]):
        seq = i if i<3 else i-3
        expected = prefix+b"JNOXRECV"+(nonce[:8] if i<3 else nonce[8:])+seq.to_bytes(4,"big")
        need(frame==expected+bytes((j+seq)%256 for j in range(34,60+seq%32)), "wire payload")
    need(host[-1]==prefix+b"JNOXACK!"+nonce[8:]+bytes(30), "wire ACK")
    return host


def hardware(out, ring):
    records=[]
    deliveries=[0,0]
    lifecycles=0
    irq=None
    trace_hash=hashlib.sha256()
    pattern = re.compile(rb"memory_region_ops_(read|write) cpu 0 mr \S+ addr (0x[0-9a-f]+) value (0x[0-9a-f]+) size 4")
    with (out/"machine.log").open("rb") as stream:
        for line in stream:
            trace_hash.update(line)
            iar=re.search(rb"gic_cpu_read cpu 0 iface read at 0x0000000c: (0x[0-9a-f]+)",line)
            if iar and int(iar[1],16)&1023==79:
                need(irq is None,"nested NIC interrupt")
                irq=[int(iar[1],16),None,None]
            m = pattern.search(line)
            if m and 0 <= (offset:=int(m[2],16)-0xa003e00)<512:
                value=int(m[3],16)
                records.append((m[1],offset,value))
                if (m[1],offset,value)==(b"write",112,15):
                    lifecycles+=1
                if irq and (m[1],offset)==(b"read",96):
                    irq[1]=value
                if irq and (m[1],offset)==(b"write",100):
                    irq[2]=value
            eoi=re.search(rb"gic_cpu_write cpu 0 iface write at 0x00000010 (0x[0-9a-f]+)",line)
            if eoi and irq:
                need(int(eoi[1],16)==irq[0] and irq[1] is not None,"IAR/EOI")
                if irq[1]&1:
                    need(irq[1]==irq[2] and lifecycles in (1,2),"device acknowledgement")
                    deliveries[lifecycles-1]+=1
                irq=None
    status = [i for i,(op,r,v) in enumerate(records) if (op,r)==(b"write",112)]
    need([records[i][2] for i in status] == [0,1,3,11,15,0]*2,"hardware lifecycles")
    for epoch in (0,6):
        addrs = {}
        sel = None
        for op,r,v in records[status[epoch]:status[epoch+4]]:
            if op==b"write" and r==48:
                sel=v
            if op==b"write" and r in (128,132,144,148,160,164,68,56):
                addrs[sel,r]=v
        for q in range(2):
            for reg,off in ((128,0),(144,512),(160,584)):
                need(addrs[q,reg]+(addrs[q,reg+4]<<32)==ring+4096*q+off,"device ring address")
            need(addrs[q,68]==1 and addrs[q,56]==32,"device queue geometry")
        tail = records[status[epoch+5]+1:status[6] if epoch==0 else None]
        reset = tail.index((b"read",112,0))
        sel = None
        ready = set()
        for op,r,v in tail[reset+1:]:
            if (op,r)==(b"write",48):
                sel=v
            if (op,r,v)==(b"read",68,0):
                ready.add(sel)
        need({0,1} <= ready,"reset/QueueReady readback order")
    need(all(deliveries) and irq is None,"physical NIC interrupt in both lifecycles")
    return dict(machine_log_sha256=trace_hash.hexdigest(),irq79_with_used_buffer_status=deliveries)


def main(pkg,out):
    if (pkg/"native").is_dir(): pkg=pkg/"native"
    manifest=load(pkg/"manifest.json")
    kernel=Image(pkg/"kernel.elf")
    need(digest(kernel.data)==manifest["kernel_elf_sha256"], "linked kernel identity")
    apps=[]
    for i,rec in enumerate(manifest["slots"]):
        app=Image(pkg/rec["elf"])
        need(i==rec["slot"] and digest(app.data)==rec["elf_sha256"] and app.data in kernel.data, "embedded executable")
        apps.append(app)
    need(len({digest(a.data) for a in apps})==len(apps)==3,"role identity")
    (base,size),=[v for k,v in kernel.symbols.items() if "6SPACES" in k and "native_el0_mmu" in k]
    need(size%12288==0,"space geometry")
    roots=[((i+1)<<48)|(base+size//3*i) for i in range(3)]
    ring=kernel.symbols["jnox_linux_net_queue_pool"][0]
    buf=kernel.symbols["jnox_linux_net_packet_buffers"][0]
    packets=wire(out)
    trace=hardware(out,ring)
    directed=pending_checks(out,kernel,apps,roots,packets)
    private=None
    for i,stage in enumerate(STAGES):
        mem=Memory(out/stage/"ram.json")
        def k(name):
            return mem.region(*kernel.symbols[name])
        def u(slot,name):
            return mem.region(*apps[slot].symbols["jnox_restart_"+name],roots[slot],slot)
        roles=words(k("jnox_linux_net_restart_roles"))
        for slot in range(3):
            for start in (slot*7,slot*7+4):
                t,pc,root=roles[start:start+3]
                if t:
                    need(root==roots[slot],"live root/ASID")
                    insn=mem.region(pc-4,4,root,slot,True)
                    need(insn==apps[slot].code(pc-4)==struct.pack("<I",0xd4094021),"saved PC / ELF / SVC")
        d,p,s=[words(u(slot,name)) for slot,name in ((0,"driver"),(1,"peer"),(2,"driver"))]
        grants=words(k("jnox_linux_net_restart_grants"))
        retires=words(k("jnox_linux_net_restart_journal"))
        page=k("jnox_linux_net_queue_pool")
        dma=k("jnox_linux_net_packet_buffers")
        need(u(1,"primary_frame")==packets[0],"old peer delivery")
        if i==0:
            token=d[3]
            need(token and not any(s) and not any(roles[14:]) and d[6]==1,"dormant successor")
            idx,length=struct.unpack_from("<II",page,596)
            avail=struct.unpack_from("<H",page,514)[0]
            used=struct.unpack_from("<H",page,586)[0]
            need(used==2 and 2<=avail<=34 and idx<32 and length==12+len(packets[1]),"pending completion")
            def posted(j):
                return struct.unpack_from("<H",page,516+2*(j%32))[0]
            offered={posted(j) for j in range(used,avail)}
            descriptor=lambda j:struct.unpack_from("<QIHH",page,16*j)
            need(descriptor(idx)==(buf+1536*idx,1530,2,0) and dma[1536*idx+12:1536*idx+length]==packets[1],"unreaped DMA payload")
            watch=grants[idx*3+1]
            need(grants[idx*3:idx*3+3]==[token,watch,1530],"unreaped old grant")
            candidates={j:grants[3*j+1] for j in offered if j!=idx and j<32 and descriptor(j)==(buf+1536*j,1530,2,0) and grants[3*j]==token and grants[3*j+2]==1530}
            need(candidates,"no outstanding distinct descriptor")
        frozen=mem.region(watch,1530,roots[0],0)
        if private is None:
            private=frozen
        need(private==frozen and packets[1] not in frozen,"late or premature copy to old driver")
        if i==1:
            row=retires[:48]
            need(row[:6]==[1,0,1,86,token,15] and row[7:10]==[3,1,1] and row[13:18]==[idx,length,watch,1530,buf+1536*idx],"retirement identity")
            need(row[18] in candidates and row[20]==candidates[row[18]] and row[21]==token,"old posted owner")
            outstanding=row[18]
            need(row[26]==token and row[28]==1 and row[31:42]==[0]*10+[1],"IRQ revoked and reset cleared before admission")
            pending,devstatus=row[29:31]
            need(not any(grants) and not any(page) and not any(dma) and s[1]==1,"middle reset scrub")
        if i>=2:
            new=s[3]
            need(0<token<new and s[10]==token and s[12:18]==[(1<<64)-116]*6 and p[4]==new and p[23:26]==[(1<<64)-13]*3,"successor replay or survivor denial")
            if i==2:
                need(any(grants[j:j+3]==[new,grants[j+1],1530] for j in range(0,96,3)),"fresh RX grant")
        need(u(1,"frames")== (bytes(80*91) if i<3 else b"".join(frame.ljust(91,b"\0") for frame in packets[3:-1])),"peer private 80 payloads")
        need(u(1,"ack")== (packets[-1] if i==4 else bytes(60)),"peer private ACK")
        need(all(not mem.private[a]&mem.private[b] for a,b in ((0,1),(1,2),(0,2))),"aliased private role data")
    need(d[1:3]==[86,86] and s[1:3]==[100,0] and p[1:3]==[100,0] and p[7]==80 and p[26]==60,"terminal private status")
    need(0<roles[0]<roles[4]<=roles[14] and roles[7]<roles[4]<roles[11] and roles[18]>=roles[14],"live process order")
    need(all(p[9+j]>0 and p[16+j]>=p[13+j]+5000000 for j in range(3)) and p[16]<p[14]<=p[17]<p[15]<=p[18],"survivor progress")
    need(not any(page) and not any(grants) and not any(dma),"final release")
    exits=re.findall(rb"(?m)^NATIVE EL0 EXIT PID (\d+) (-?\d+)\r?$",(out/"uart.log").read_bytes())
    need(sorted(exits)==[(b"0",b"86"),(b"1",b"0"),(b"2",b"0")],"native exits")
    return dict(capture=out.name,**directed,**trace,kernel_sha256=digest(kernel.data),
                wire_sha256=digest((out/"wire.pcap").read_bytes()),nonces=(out/"nonce.bin").read_bytes().hex(),
                roots=[hex(r) for r in roots],role_sha256=[digest(a.data) for a in apps],
                tokens=[token,new],unreaped=idx,outstanding=outstanding,
                old_gic_pending_at_retire=pending,old_virtio_interrupt_status_at_retire=devstatus,
                frozen_private_sha256=digest(private),fresh_frames=80,ack_bytes=len(packets[-1]))



def pending_checks(out,kernel,apps,roots,packets):
    names=["preexit","exit-wait","irq-pending","middle","spare","active","final"]
    amounts=[2,2,3,3,3,83,84]
    gateva=apps[1].symbols["jnox_restart_gates"][0]
    journal=[]
    snapshots=[]
    payload=[]
    gatewrites=[]
    for i,name in enumerate(names):
        dest=out/name
        q=load(dest/"qmp.json")
        h=load(dest/"halted.json")
        need(q["status"]["running"] and q["stop_return"]=={} and [c["cpu-index"] for c in q["cpus"]]==[0] and h["status"]=="paused" and not h["running"],"paused single CPU")
        need(load(dest/"ingress.json")["stream_bytes"]==sum(4+len(f) for f in packets[:amounts[i]]),"arrival order")
        mem=Memory(dest/"ram.json")
        k=lambda n:mem.region(*kernel.symbols["jnox_linux_net_"+n])
        state=words(k("pending_retire"))
        journal.append(state)
        payload.append(k("pending_retire_bytes"))
        snapshots.append((words(k("irq_metrics")),words(k("restart_scheduler"))))
        gates=words(mem.region(gateva,16,roots[1],1))
        expected=[0x45584954 if i else 0,0x42494e44 if i>=4 else 0]
        need(gates==expected,"fixture flag states")
        if i in (0,3):
            ix=int(i==3)
            va=gateva+8*ix
            pa=(mem.leaf(roots[1],va)&MASK)+(va%4096)
            data=struct.pack("<Q",(0x45584954,0x42494e44)[ix]).hex()
            need(load(dest/"gate.json")==dict(physical=pa,command=f"M{pa:x},8:{data}",before="00"*8,after=data),"gate write target or data")
            gatewrites.append(pa)
        if i in (1,2):
            ring=k("queue_pool")
            need(struct.unpack_from("<H",ring,586)[0]==i+1,"live physical used head")
            need(not any(words(k("restart_roles"))[14:]),"early new role")
        if i==2:
            idx,size=struct.unpack_from("<II",ring,604)
            need(idx<32 and idx!=struct.unpack_from("<I",ring,596)[0],"distinct third completion")
            addr=kernel.symbols["jnox_linux_net_packet_buffers"][0]+1536*idx
            need(struct.unpack_from("<QIHH",ring,16*idx)==(addr,1530,2,0),"physical third descriptor")
            grant=words(k("restart_grants"))[3*idx:3*idx+3]
            need(grant==[state[1],state[15],1530] and state[13:17]==[idx,size,grant[1],addr],"protected grant binding")
            dma=k("packet_buffers")[1536*idx:1536*idx+size]
            need(size==12+len(packets[2]) and dma[12:]==packets[2] and payload[i]==dma.ljust(1530,b"\0"),"third Ethernet bytes in direct DMA and protected copy")
        if i==3:
            need(words(k("restart_journal"))[26:31]==[state[1],0,1,1,1],"exit retirement pending")
    zero,wait,seen,done=journal[:4]
    need(not any(zero) and wait[0]==1 and wait[1] and wait[2]&128 and wait[3]>0 and wait[5]==wait[4]+wait[3]*5 and wait[6:13]==[0,2,0,0,0,0,0],"masked WAIT")
    need(seen[0]==2 and seen[1:6]==wait[1:6] and wait[4]<=seen[6]<wait[5] and seen[7:13]==[2,3,0,0,1,1] and seen[17]==seen[6]+2*seen[3] and seen[18]==0,"protected IRQ high")
    need(done[:18]==seen[:18] and done[18]>=seen[17] and journal[3:]==[done]*4 and not any(payload[1]) and payload[2:]==[payload[2]]*5,"stable protected observation")
    need(snapshots[1]==snapshots[2] and snapshots[4][0][7]==snapshots[4][1][6]==0 and snapshots[4][0][19]>wait[1],"no old IRQ wake")
    need(len(list(out.glob("*/gate.json")))==2,"recorded write count")
    return dict(third_frame_sha256=digest(packets[2]),third_used_id=idx,used_heads=[2,3],recorded_gate_writes=gatewrites,**pending_trace(out))


def pending_trace(out):
    pattern=re.compile(rb"memory_region_ops_(read|write) cpu 0 mr \S+ addr (0x[0-9a-f]+) value (0x[0-9a-f]+) size 4")
    events=[]
    with (out/"machine.log").open("rb") as stream:
        for n,line in enumerate(stream,1):
            m=pattern.search(line)
            if m:
                op,addr,value=m[1],int(m[2],16),int(m[3],16)
                need(not(op==b"write" and addr==0x8000208 and value&32768),"software-pended NIC IRQ")
                if addr in (0x8000208,0x8000188,0x8000288,0x8000108,0xa003e60,0xa003e64,0xa003e70):
                    events.append((n,op,addr,value))
            for pat,tag in ((rb"virtio_mmio_setting_irq virtio_mmio setting IRQ ([01])$",b"nic"),(rb"gic_set_irq irq 79 level ([01]) cpumask (0x[0-9a-f]+) target (0x[0-9a-f]+)$",b"pin")):
                m=re.search(pat,line)
                if m:
                    if tag==b"pin": need(int(m[2],16)&int(m[3],16)&1,"CPU0 IRQ routing")
                    events.append((n,tag,0,int(m[1])))
            for pat,tag in ((rb"gic_cpu_read cpu 0 iface read at 0x0000000c: (0x[0-9a-f]+)",b"iar"),(rb"gic_cpu_write cpu 0 iface write at 0x00000010 (0x[0-9a-f]+)",b"eoi")):
                m=re.search(pat,line)
                if m and int(m[1],16)&1023==79: events.append((n,tag,0,79))
    starts=[n for n,op,a,v in events if (op,a,v)==(b"write",0xa003e70,15)]
    resets=[n for n,op,a,v in events if (op,a,v)==(b"write",0xa003e70,0) and n>starts[0]]
    stop=resets[0]
    prev=max(n for n,op,a,v in events if op==b"eoi" and n<stop)
    gap=[e for e in events if prev<e[0]<stop]
    def first(op,a,v,after=prev,bit=False):
        return next(n for n,o,addr,val in gap if n>after and (o,addr)==(op,a) and (bool(val&v) if bit else val==v))
    need([v for n,t,a,v in gap if t==b"nic"]==[1,0] and [v for n,t,a,v in gap if t==b"pin"]==[1,0] and not any(t==b"iar" for n,t,a,v in gap),"old edge undelivered")
    rise=first(b"nic",0,1)
    need(first(b"read",0x8000208,0)<rise and first(b"read",0xa003e60,0)<rise,"baseline low")
    high=first(b"pin",0,1,rise)
    pending=first(b"read",0x8000208,32768,high,True)
    status=first(b"read",0xa003e60,1,pending)
    mask=first(b"write",0x8000188,32768,status)
    ack=first(b"write",0xa003e64,1,mask)
    low=first(b"pin",0,0,first(b"nic",0,0,mask))
    clear=first(b"write",0x8000288,32768,max(low,ack))
    for a,maskbits in ((0x8000208,32768),(0x8000108,32768),(0xa003e60,3)):
        need(any(stop<n<resets[1] and op==b"read" and addr==a and not v&maskbits for n,op,addr,v in events),"post-reset readback")
    return dict(trace_lines=dict(nic_high=rise,pin_high=high,pending=pending,mask=mask,ack=ack,pin_low=low,clear=clear,reset=stop),software_pends_irq79=0)
if __name__=="__main__":
    print(json.dumps(main(*(Path(x) for x in sys.argv[1:])),indent=2))



