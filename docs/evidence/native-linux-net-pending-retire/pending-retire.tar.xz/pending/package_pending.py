#!/usr/bin/env python3
"""Create an offline pending-retirement supplement and replay a fresh extraction before publishing."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile

from replay_pending import LABELS, check, files, load, sha

HERE = Path(__file__).resolve().parent
BOARD = "docs/evidence/native-linux-net-irq-board"


def write_json(path, obj):
    path.write_text(json.dumps(obj, sort_keys=True, indent=2) + "\n")


def safe_name(name):
    p = PurePosixPath(name)
    check(not p.is_absolute() and ".." not in p.parts and "\\" not in name, f"invalid member {name}")
    return p


def extract_regular(archive, dest):
    seen = set()
    for member in archive:
        p = dest / safe_name(member.name)
        if member.isdir():
            p.mkdir(parents=True, exist_ok=True)
            continue
        check(member.isfile() and p not in seen, f"unsupported or duplicate member: {member.name}")
        seen.add(p)
        p.parent.mkdir(exist_ok=True, parents=True)
        with archive.extractfile(member) as src, p.open("xb") as out:
            shutil.copyfileobj(src, out)


def git_files(repo, rev, dest, paths):
    check(re.fullmatch("[0-9a-f]{40}", rev), "invalid Git revision")
    data = subprocess.check_output(["git", "-C", str(repo), "archive", rev, "--", *paths])
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        extract_regular(archive, dest)


def copy(src, dest):
    check(src.is_file() and not src.is_symlink(), f"missing original file: {src}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dest)


def tree(src, dst):
    for rel, path in files(src).items():
        copy(path, dst / rel)


def parent_inputs(parent, imported):
    # The ordinary archive may carry one top-level directory. Resolve the
    # imported manifest and its sibling ELF/object files by that same prefix.
    required = {"import.json", "service.elf", "peer.elf", "spare.elf",
                "virtio_net.original.o", "virtio_net.packet.o", "virtio_net.callback.o"}
    required.update(p.name for p in imported.glob("*.o"))
    matched = {}
    with tarfile.open(parent, "r|*") as archive:
        for m in archive:
            p = safe_name(m.name)
            if p.parent.name != "imported" or p.name not in required:
                continue
            check(m.isfile() and p.name not in matched, f"duplicate or invalid parent member {p}")
            with archive.extractfile(m) as stream:
                h = hashlib.sha256()
                for block in iter(lambda: stream.read(1 << 20), b""):
                    h.update(block)
            check(h.hexdigest() == sha(imported / p.name), f"ordinary archive disagrees on {p}")
            matched[p.name] = p.parent.as_posix()
    check(set(matched) == required and len(set(matched.values())) == 1, "ordinary archive provenance")
    return sorted(matched)


def assemble(a, root):
    b = a.build.resolve()
    ordinary = a.ordinary_build.resolve()
    qa = a.qa.resolve()
    for label in LABELS:
        tree(b / label, root / label)
        check((qa / f"{label}.json").is_file(), f"missing independent result {label}")
    check((qa / "reader.py").is_file(), "missing independent reader")
    tree(qa, root / "qa")
    tree(a.vendor / "elftools", root / "vendor/elftools")
    for name in ("build-pending.sh", "pending-measured.py", "pending-measured.json",
                 "replay_pending.py", "package_pending.py"):
        copy(HERE / name, root / name)
    for path in (b / "native").iterdir():
        if path.is_file():
            copy(path, root / "native" / path.name)
    copy(b / "build.log", root / "build.log")
    m = load(b / "native/manifest.json")
    om = load(ordinary / "native/manifest.json")
    check("pending_retirement_test" not in om["linux_source_net_restart"], "ordinary comparator is directed")
    for ds, orig in zip(m["slots"], om["slots"], strict=True):
        check(ds["slot"] == orig["slot"] and ds["elf_sha256"] == orig["elf_sha256"] ==
              sha(ordinary / "native" / orig["elf"]), "EL0 comparator mismatch")
    check(om["kernel_elf_sha256"] == sha(ordinary / "native/kernel.elf"), "ordinary kernel identity")
    copy(ordinary / "native/manifest.json", root / "ordinary/manifest.json")
    sources = files(b / "imported")
    comparator = files(ordinary / "imported")
    check(sources.keys() == comparator.keys(), "incomplete reused import")
    hashes = {}
    for rel, src in sources.items():
        hashes[rel] = sha(src)
        check(hashes[rel] == sha(comparator[rel]), f"ordinary import reuse: {rel}")
        copy(src, root / "imported" / rel)
    matched = parent_inputs(a.parent_archive, b / "imported")
    observers = {}
    for label in LABELS:
        cap = b / label
        rev = (cap / "observer-commit.txt").read_text().strip()
        dest = root / "observer" / rev
        if not dest.exists():
            paths = [str(safe_name(line.split("  ", 1)[1]))
                     for line in (cap / "observer.sha256").read_text().splitlines()]
            paths.extend((BOARD + "/board.json", BOARD + "/virt-net.dtb.gz"))
            git_files(a.repo, rev, dest, sorted(set(paths)))
        observers[label] = rev
    git_files(a.repo, m["commit"], root / "kernel-source",
              ["kernel", "arch", "tools/build_native_el0.py"])
    write_json(root / "bundle.json", {"schema": 1, "issues": [434, 426], "observers": observers,
               "parent_archive": a.parent_archive.name, "parent_archive_sha256": sha(a.parent_archive),
               "parent_checked_members": matched, "ordinary_kernel_sha256": om["kernel_elf_sha256"],
               "ordinary_import_sha256": hashes, "reader_build_arg": a.reader_build_arg})
    write_json(root / "SHA256SUMS.json", {name: sha(p) for name, p in sorted(files(root).items())})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    lab = Path.home() / "jnox406-lab"
    parser.add_argument("--build", type=Path, default=lab / "426-pending-01")
    parser.add_argument("--ordinary-build", type=Path, default=lab / "426-replacement-02")
    parser.add_argument("--parent-archive", required=True, type=Path)
    parser.add_argument("--repo", type=Path, default=lab / "src")
    parser.add_argument("--qa", type=Path, default=HERE / "pending-independent")
    parser.add_argument("--reader-build-arg", choices=(".", "native"), default=".")
    parser.add_argument("--vendor", type=Path, default=Path("/mnt/d/codex/jnox332-release-deps"))
    parser.add_argument("--out", type=Path, required=True)
    a = parser.parse_args()
    out = a.out.resolve()
    report = out.with_name(out.name + ".replay.json")
    check(not out.exists() and not report.exists(), "output archive or replay report already exists")
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=out.parent) as tmp:
        work = Path(tmp)
        root = work / "bundle"
        root.mkdir()
        assemble(a, root)
        archive = work / "pending.tar.xz"
        with tarfile.open(archive, "w:xz", preset=4) as tar:
            for name, path in sorted(files(root).items()):
                tar.add(path, arcname="pending/" + name, recursive=False)
        shutil.rmtree(root)
        with tarfile.open(archive, "r:xz") as tar:
            extract_regular(tar, work / "fresh")
        fresh = work / "fresh/pending"
        decoded = json.loads(subprocess.check_output([sys.executable, "-B", str(fresh / "replay_pending.py")],
                                                      cwd=fresh))
        summary = work / "replay.json"
        write_json(summary, {"archive_sha256": sha(archive), **decoded})
        os.link(archive, out)
        os.link(summary, report)
    print(f"{out}\n{report}")


if __name__ == "__main__":
    main()
