#!/usr/bin/env python3
"""Offline replay for the JNOX #434/#426 directed pending-retirement supplement."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

LABELS = ("pending-a", "pending-b")
STAGES = ("preexit", "exit-wait", "irq-pending", "middle", "spare", "active", "final")
CONTROLS = ["erased old GIC pending bit", "altered third protected DMA bytes",
            "injected third frame before WAIT", "same-root spare", "authorized stale grant",
            "reused nonce", "pending DMA bytes", "removed only masked wired assertion",
            "missing TX QueueReady reset readbacks", "old nonce in replacement delivery",
            "gate outside authorized word"]


def check(ok, message):
    if not ok:
        raise ValueError(message)


def sha(p):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def load(p):
    return json.loads(p.read_bytes())


def files(root):
    paths = {}
    for p in root.rglob("*"):
        check(not p.is_symlink(), f"symlink: {p}")
        if p.is_file():
            paths[p.relative_to(root).as_posix()] = p
    return paths


def replay(root):
    inventory = load(root / "SHA256SUMS.json")
    members = files(root)
    del members["SHA256SUMS.json"]
    check(set(members) == set(inventory), "incomplete member inventory")
    for name, p in members.items():
        check(sha(p) == inventory[name], f"member digest: {name}")
    index = load(root / "bundle.json")
    m = load(root / "native/manifest.json")
    imp = load(root / "imported/import.json")
    check(sha(root / "native/kernel.elf") == m["kernel_elf_sha256"] and
          m["kernel_elf_sha256"] != index["ordinary_kernel_sha256"], "directed kernel identity")
    directed = m["linux_source_net_restart"]["pending_retirement_test"]
    check(directed["scope"] == "EL1 only", "directed profile")
    for slot, role in zip(m["slots"], imp["restart_roles"], strict=True):
        check(sha(root / "native" / slot["elf"]) == slot["elf_sha256"] == role["sha256"] ==
              sha(root / "imported" / role["elf"]) == directed["slot_elf_sha256"][role["role"]],
              "role ELF identities")
    for name, digest in index["ordinary_import_sha256"].items():
        check(sha(root / "imported" / name) == digest, f"reused input {name}")
    env = {**os.environ, "PYTHONPATH": str(root / "vendor"), "PYTHONNOUSERSITE": "1",
           "PYTHONDONTWRITEBYTECODE": "1"}

    def run(*args):
        return json.loads(subprocess.check_output([sys.executable, "-B", *map(str, args)], cwd=root, env=env))

    results, seen = {}, set()
    for label in LABELS:
        cap = root / label
        launch = load(cap / "launch.json")
        rev = (cap / "observer-commit.txt").read_text().strip()
        check(re.fullmatch("[0-9a-f]{40}", rev) and rev == index["observers"][label], "observer revision")
        for line in (cap / "observer.sha256").read_text().splitlines():
            digest, rel = line.split("  ", 1)
            check(inventory.get(f"observer/{rev}/{rel}") == digest, "observer source " + rel)
        for stage in STAGES:
            for name in ("halted.json", "ingress.json", "qmp.json", "ram.json"):
                check((cap / stage / name).is_file(), f"missing {stage}/{name}")
        check(all((cap / stage / "gate.json").is_file() for stage in ("preexit", "middle")), "gate records")
        nonce = (cap / "nonce.bin").read_bytes()
        tokens = {nonce[:8], nonce[8:]}
        check(len(nonce) == 16 and len(tokens) == 2 and not seen.intersection(tokens), "nonce reuse")
        seen.update(tokens)
        data = run(f"observer/{rev}/tools/verify_linux_source_net_restart.py", "--package", "native",
                   "--driver-manifest", "imported/import.json", "--out", label, "--mac", launch["mac"],
                   "--mtu", launch["mtu"], "--replay", "--mutation-tests")
        check(data.pop("rejected_mutations") == CONTROLS, f"{label}: mutation identities or count")
        recorded = load(cap / "result.json")
        check(recorded.pop("rejected_mutations", CONTROLS) == CONTROLS and data == recorded,
              f"{label}: primary JSON mismatch")
        check("masked_pending_retirement" in data, "missing directed evidence")
        independent = run("qa/reader.py", index["reader_build_arg"], label)
        check(independent == load(root / f"qa/{label}.json"), f"{label}: independent JSON mismatch")
        results[label] = {"mutations": CONTROLS, "result": data, "independent": independent}
    return {"parent_archive_sha256": index["parent_archive_sha256"], "kernel_commit": m["commit"],
            "checksummed_members": len(members), "captures": results}


if __name__ == "__main__":
    print(json.dumps(replay(Path(__file__).resolve().parent), indent=2))
