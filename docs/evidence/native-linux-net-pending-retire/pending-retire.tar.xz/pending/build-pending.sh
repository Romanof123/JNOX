#!/bin/bash
set -euo pipefail
b="$HOME/jnox406-lab"; cd "$b/src"; export PATH="$HOME/.cargo/bin:$PATH" CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=1 PYTHONDONTWRITEBYTECODE=1 LC_ALL=C PYTHONPATH=/mnt/d/codex/jnox332-release-deps
exec 9>"$b/run.lock"; flock 9
git checkout -q --detach "$1"; git restore --ignore-skip-worktree-bits --source=HEAD -- drivers examples/linux-source-net-rx examples/linux-source-net-restart sdk tools kernel arch
test -z "$(git status --porcelain --untracked-files=no)"
dest="$b/$2"; mkdir "$dest"
run(){ if ! "$@" >>"$dest/build.log" 2>&1; then grep -Ei 'error:|fatal error|error\[|error |Traceback|undefined symbol|referenced by|cannot find|unsupported|differs|cannot be|not found|unexpected' "$dest/build.log" | tail -85 || :; tail -5 "$dest/build.log"; exit 1; fi; }
cp -a "$b/426-replacement-02/imported" "$dest/imported"
run python3 -B tools/build_native_el0.py --board virt --linux-source-net-restart --linux-source-net-restart-pending-test --policy fifo --priority 8 --peer-priority 8 --peer-priority 8 --elf "$dest/imported/service.elf" --peer-elf "$dest/imported/peer.elf" --peer-elf "$dest/imported/spare.elf" --out "$dest/native"
tail -5 "$dest/build.log"
