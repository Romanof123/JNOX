import pathlib as P,shutil,subprocess as S,json,hashlib
d=P.Path('/mnt/d/codex/.jnox-work/abs192-fresh')
r=P.Path('/home/ywcho/abs192-fresh')
r.mkdir()
apps=['aligned-wake','cbs-wake','aligned-saturated','cbs-saturated']*2
tr=[0,1,1,0,1,0,0,1]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plans=[]
for i,(a,t) in enumerate(zip(apps,tr),1):
 p=r/f'pos{i}';p.mkdir();k=p/'kernel.elf';shutil.copyfile(d/(a+'.elf'),k)
 cmd=['timeout','15s','qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','stdio','-kernel',str(k)]
 if t:cmd+=['-d','int','-D',str(p/'exceptions.log')]
 (p/'plan.json').write_text(json.dumps(dict(position=i,app=a,traced=t,sha256=h(k),argv=cmd)))
 plans.append((p,cmd))
for p,cmd in plans:
 with (p/'uart').open('wb') as o,(p/'stderr').open('wb') as e:ret=S.run(cmd,stdout=o,stderr=e).returncode
 (p/'status').write_text(str(ret));dest=d/p.name;shutil.copytree(p,dest)
 assert all(h(f)==h(dest/f.name) for f in p.iterdir())
 print(p.name,ret,flush=True)
