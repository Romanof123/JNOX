.section .text.boot, "ax"
.global _start
_start:
    nop
.section .rodata, "a"
    .balign 1
    .space 262141, 0x42
.section .data, "aw"
    .byte 0x31, 0x32, 0x33
.section .bss, "aw", %nobits
    .space 1814520
