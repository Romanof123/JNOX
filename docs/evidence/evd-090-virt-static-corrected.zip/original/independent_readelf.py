"""Recompute size domains directly from GNU readelf -W output, independently of JNOX Python modules."""
import hashlib
import json
import re
import sys
from pathlib import Path

folder = Path(__file__).resolve().parent
columns = ("immutable_span", "writable_span", "segment_gap", "ram_span", "immutable_padding",
           "writable_padding", "linker_stack", "load_file", "load_memory", "elf_file")

def measure(listing, binary):
    dump = listing.read_text(encoding="utf-8-sig")
    load_lines = [line.split() for line in dump.splitlines() if line.lstrip().startswith("LOAD ")]
    assert len(load_lines) == 2
    segs = []
    file_addresses = set()
    memory_addresses = set()
    image = binary.read_bytes()
    for fields in load_lines:
        off, va, pa, fs, ms = (int(value, 16) for value in fields[1:6])
        assert va == pa and fs <= ms
        if fs:
            assert len(image[off:off+fs]) == fs
        file_addresses.update(range(off, off+fs))
        memory_addresses.update(range(pa, pa+ms))
        segs.append((pa, fs, ms))
    (beg, x_file, x_mem), (rw, d_file, d_mem) = segs
    assert beg == 0x40200000 and x_file == x_mem
    assert beg+x_mem <= rw and rw+d_mem <= 0x48000000
    names = {}
    for match in re.finditer(r"^\s*\[\s*\d+\]\s+(\.(?:text|rodata|data|bss|stack))\s+\S+\s+([0-9a-fA-F]+)\s+\S+\s+([0-9a-fA-F]+)", dump, re.M):
        name, address, length = match.groups()
        names[name] = (int(address, 16), int(length, 16))
    def section_bytes(selected):
        offsets = set()
        for name in selected:
            if name in names:
                address, size = names[name]
                offsets.update(range(address, address+size))
        return offsets
    rx_sections = section_bytes([".text", ".rodata"])
    rw_sections = section_bytes([".data", ".bss", ".stack"])
    rx = set(range(beg, beg+x_mem))
    writable = set(range(rw, rw+d_mem))
    assert rx_sections <= rx and rw_sections <= writable
    assert names[".stack"][0] + names[".stack"][1] == rw+d_mem
    full_ram = set(range(beg, rw+d_mem))
    gap = full_ram - memory_addresses
    assert len(gap) == rw - (beg+x_mem)
    assert len(full_ram) == x_mem + len(gap) + d_mem
    nums = [x_file, d_mem, len(gap), len(full_ram), len(rx-rx_sections), len(writable-rw_sections),
            names[".stack"][1], len(file_addresses), len(memory_addresses), len(image)]
    return dict(sha256=hashlib.sha256(image).hexdigest(), bytes=dict(zip(columns, nums)),
                physical_ranges=dict(rx=[hex(beg),hex(beg+x_mem)], gap=[hex(beg+x_mem),hex(rw)],
                                     rw=[hex(rw),hex(rw+d_mem)], stack=[hex(names[".stack"][0]), hex(rw+d_mem)]),
                section_bytes={name:x[1] for name,x in names.items()})

result = {}
for v in ["minimal", "fixed-rr"]:
    result[v] = measure(folder/(v+"-readelf.txt"), folder/(v+".elf"))
d = {k:result["fixed-rr"]["bytes"][k]-result["minimal"]["bytes"][k] for k in columns}
result["signed_fixed_rr_minus_minimal"] = d
result["minimal_headroom"] = {"code":262144-result["minimal"]["bytes"]["immutable_span"],
                              "ram":2097152-result["minimal"]["bytes"]["ram_span"]}
ref = json.loads((folder/"checker.json").read_text(encoding="utf-8-sig"))
for a,b in [("minimal","minimal"),("fixed-rr","fixed_rr")]:
    assert result[a]["bytes"] == ref[b]["bytes"]
    assert result[a]["sha256"] == ref[b]["sha256"]
assert d == ref["delta_bytes"]
for name in ("padded-and-sparse", "retain"):
    result[name] = measure(folder/"fixtures"/(name+".readelf"), folder/"fixtures"/(name+".elf"))
assert result["padded-and-sparse"]["bytes"]["immutable_padding"] == 28
print(json.dumps(result,indent=2))
