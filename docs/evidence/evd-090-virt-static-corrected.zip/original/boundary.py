"""Build independent non-executable-by-test AArch64 size fixtures and check CLI exit classes.
Run with python boundary.py SOURCE where SOURCE contains kernel/link.ld (WSL GNU as + rust-lld).
"""
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

record = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve()
fixture_dir = record / "fixtures"
fixture_dir.mkdir(exist_ok=True)
run = subprocess.run
sysroot = Path(subprocess.check_output(["rustc", "+1.95.0", "--print", "sysroot"], text=True).strip())
lld = sysroot / "lib/rustlib/x86_64-pc-windows-msvc/bin/rust-lld.exe"
script = repo / "kernel/link.ld"
variant_script = fixture_dir / "unaligned-bss-end.ld"
variant_script.write_text(script.read_text().replace("        . = ALIGN(8);", ""), encoding="utf-8")
image_cases = {
    "equal": (262144, 2097152, 0, script),
    "code-plus-one": (262145, 2097152, 0, script),
    "ram-plus-one-aligned-step": (262144, 2097168, 0, script),
    "both-over": (262145, 2097168, 0, script),
    "padded-and-sparse": (51, 36912, 1, script),
    "unaligned-bss-end": (51, 36912, 1, variant_script),
}
for name, (code_size, ram_size, unusual, ldscript) in image_cases.items():
    align = 32 if unusual else 1
    rx_text = 4
    rodata = code_size - ((rx_text + align - 1) // align * align)
    rw_start = (code_size + 4095) // 4096 * 4096
    bss_start = (rw_start + 3 + 7) // 8 * 8
    bss_input = ram_size - 16384 - bss_start
    if unusual:
        bss_input -= 7
    asm = f""".section .text.boot, "ax"
.global _start
_start:
    nop
.section .rodata, "a"
    .balign {align}
    .space {rodata}, 0x42
.section .data, "aw"
    .byte 0x31, 0x32, 0x33
.section .bss, "aw", %nobits
    .space {bss_input}
"""
    (fixture_dir / (name + ".s")).write_text(asm, encoding="utf-8")
    run(["wsl", "-e", "aarch64-linux-gnu-as", "-o", name + ".o", name + ".s"], cwd=fixture_dir, check=True)
    run([str(lld), "-flavor", "gnu", "-T", str(ldscript), "-o", name + ".elf", name + ".o"],
        cwd=fixture_dir, check=True)
    ls = run(["wsl", "-e", "readelf", "-W", "-l", "-S", name + ".elf"],
             cwd=fixture_dir, check=True, capture_output=True, text=True)
    (fixture_dir / (name + ".readelf")).write_text(ls.stdout, encoding="utf-8")
    loads = [line.split() for line in ls.stdout.splitlines() if line.lstrip().startswith("LOAD ")]
    rx, rw = loads
    assert int(rx[4], 16) == code_size, (name, rx)
    assert int(rw[3], 16) + int(rw[5], 16) - int(rx[3], 16) == ram_size, (name, rw)
    bss = re.search(r"\.bss\s+NOBITS\s+(\w+)\s+\w+\s+(\w+)", ls.stdout)
    bss_end = sum(int(x, 16) for x in bss.groups())
    assert (bss_end % 8 != 0) == (name == "unaligned-bss-end")
(fixture_dir / "short.elf").write_bytes(b"ELF control")
cases = [
    ("equal", "both-over", 0), ("code-plus-one", "equal", 1),
    ("ram-plus-one-aligned-step", "equal", 1), ("both-over", "equal", 1),
    ("padded-and-sparse", "equal", 0), ("short", "equal", 2),
    ("equal", "short", 2), ("unaligned-bss-end", "equal", 2),
    ("equal", "unaligned-bss-end", 2),
]
results = []
for minimal, fixed, wanted in cases:
    cmd = [sys.executable, "-B", str(repo / "tools/virt_footprint.py"),
           "--minimal", str(fixture_dir / (minimal + ".elf")),
           "--fixed-rr", str(fixture_dir / (fixed + ".elf"))]
    result = run(cmd, capture_output=True, text=True)
    out = json.loads(result.stdout) if result.stdout else None
    results.append(dict(minimal=minimal, comparison=fixed, expected=wanted, actual=result.returncode,
        json_report=out is not None, minimal_within_limit=(out or {}).get("minimal_within_limit"),
        diagnostic=result.stderr.strip().splitlines()[-1:] or None))
print(json.dumps(results, indent=2))
failed = [item for item in results if item["actual"] != item["expected"]]
sys.exit(int(bool(failed)))
