.section .text.boot, "ax"
.global _start
_start:
    nop
.section .rodata, "a"
    .balign 32
    .space 19, 0x42
.section .data, "aw"
    .byte 0x31, 0x32, 0x33
