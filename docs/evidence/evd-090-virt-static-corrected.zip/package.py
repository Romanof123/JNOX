from run_lib import *
import zipfile

archive=ROOT/'evd-090-virt-static-corrected-812cfd80.zip'
inventory=ROOT/'SHA256SUMS'
sidecar=archive.with_suffix('.zip.sha256')
include={'original','source','generated','logs'}
files=sorted(p for p in ROOT.rglob('*') if p.is_file()
             and p not in (archive,inventory,sidecar)
             and (p.parent==ROOT or p.relative_to(ROOT).parts[0] in include)
             and '__pycache__' not in p.parts)
inventory.write_bytes(''.join(sha(p)+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in files).encode())
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in [*files,inventory]:
        z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS').decode().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
print(f'{archive.name} ({archive.stat().st_size} B, {len(files)} hashed files) {sha(archive)}')
sidecar.write_bytes((sha(archive)+'  '+archive.name+'\n').encode())
