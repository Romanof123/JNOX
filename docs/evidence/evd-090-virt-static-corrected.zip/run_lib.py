from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys

ROOT = Path(__file__).resolve().parent
LOG = ROOT / 'logs'
LOG.mkdir(exist_ok=True)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

def run(tag, args, expected=0):
    args = list(map(str,args))
    with (LOG/(tag+'.out')).open('wb') as out, (LOG/(tag+'.err')).open('wb') as err:
        result = subprocess.run(args,cwd=ROOT,stdout=out,stderr=err)
    with (ROOT/'commands.jsonl').open('a',encoding='utf-8') as f:
        print(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                              cwd=str(ROOT),name=tag,argv=args,exit=result.returncode)),file=f)
    if expected is not None and result.returncode != expected:
        raise AssertionError((tag,result.returncode,expected,(LOG/(tag+'.err')).read_text(errors='replace')))
    return result.returncode, (LOG/(tag+'.out')).read_text(encoding='utf-8', errors='replace')

images={'minimal':'original/minimal.elf','fixed-rr':'original/fixed-rr.elf'}
images.update({p.stem:p.relative_to(ROOT).as_posix() for p in sorted((ROOT/'original/fixtures').glob('*.elf'))})
for name in ('independent-bad-start','independent-bad-end','empty-bss','absent-bss','unaligned-empty-bss'):
    images[name]='generated/'+name+'.elf'
