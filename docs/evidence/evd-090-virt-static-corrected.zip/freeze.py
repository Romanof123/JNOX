"""Standalone expectation from readelf text. No footprint code or old measurements."""
from run_lib import *
import re

BASE, CEILING = 0x40200000, 0x48000000
limits={'immutable_span':262144,'ram_span':2097152}

def measure(name,path):
    listing=(LOG/('readelf-'+name+'.out')).read_text()
    if not listing or 'ELF Header:' not in listing:
        return {'invalid':'truncated'}
    for token in ['ELF64','little endian','EXEC (Executable file)','AArch64','0x40200000']:
        assert token in listing[:listing.index('Section Headers:')],(name,token)
    assert re.search(r'Entry point address:\s*0x40200000\b',listing)
    assert re.search(r'Number of program headers:\s*2\b',listing)
    rows=re.findall(r'^\s+LOAD\s+(.+)$',listing,re.M)
    assert len(rows)==2
    segments={}
    byte_length=(ROOT/path).stat().st_size
    for role, flags, row in zip(('rx','rw'),('RE','RW'),rows):
        fields=row.split()
        offset,v,p,fs,ms=map(lambda x:int(x,16),fields[:5]); al=int(fields[-1],16)
        assert ''.join(fields[5:-1])==flags and v==p and fs<=ms and ms>0
        assert offset+fs<=byte_length and BASE<=p<p+ms<=CEILING
        assert al in (0,1) or (al&(al-1)==0 and (offset-v)%al==0)
        segments[role]=dict(address=p,file_offset=offset,filesz=fs,memsz=ms)
    rx,rw=segments.values(); x,y=rx['address'],rw['address']; rxend=x+rx['memsz']; end=y+rw['memsz']
    assert x==BASE and y%4096==0 and rxend<=y and rx['filesz']==rx['memsz']
    assert not rw['filesz'] or rx['file_offset']+rx['filesz']<=rw['file_offset'] or rw['file_offset']+rw['filesz']<=rx['file_offset']
    sections={}; region=[]; details={}
    accepted={'.text':('PROGBITS','AX',rx),'.rodata':('PROGBITS','A',rx),'.data':('PROGBITS','AW',rw),'.bss':('NOBITS','AW',rw),'.stack':('NOBITS','AW',rw)}
    for line in listing.splitlines():
        m=re.match(r'\s*\[\s*\d+\]\s+([.]\S+)\s+(\S+)\s+(\w+)\s+(\w+)\s+(\w+)\s+\w+\s+([A-Z]+)\s+\d+\s+\d+\s+(\d+)',line)
        if not m: continue
        n,k,v,o,s,flags,alignment=m.groups()
        if 'A' not in flags: continue
        addr,off,size=map(lambda x:int(x,16),(v,o,s)); align=int(alignment)
        details[n]=dict(address=addr,offset=off,size=size,type=k,flags=flags,alignment=align)
        if n=='.bss' and (addr%8 or (addr+size)%8):
            return dict(invalid='BSS boundary',bss_start=addr,bss_end=addr+size,bss_alignment=align)
        if not size: continue
        kind,access,segment=accepted[n]
        assert k==kind and set(flags)-set('MSR')==set(access),(n,k,flags)
        assert addr%max(align,1)==0 and segment['address']<=addr<addr+size<=segment['address']+segment['memsz']
        if k=='PROGBITS':
            assert off==segment['file_offset']+addr-segment['address'] and addr+size<=segment['address']+segment['filesz']
        else: assert addr>=segment['address']+segment['filesz']
        assert n not in sections
        sections[n]=dict(address=addr,bytes=size)
        region.append((addr,addr+size,n))
    assert region==sorted(region) and all(a[1]<=b[0] for a,b in zip(region,region[1:]))
    assert [r[2] for r in region]==[n for n in accepted if n in sections]
    assert region[0][0]==BASE and region[0][2]=='.text' and region[-1][2]=='.stack'
    assert region[-1][0]%16==0 and region[-1][1]==end and region[-1][1]-region[-1][0]==16384
    size=lambda n:sections.get(n,{}).get('bytes',0)
    metrics=dict(immutable_span=rxend-x,writable_span=end-y,segment_gap=y-rxend,ram_span=end-x,
                 immutable_padding=rxend-x-size('.text')-size('.rodata'),
                 writable_padding=end-y-size('.data')-size('.bss')-size('.stack'),
                 linker_stack=size('.stack'),load_file=sum(p['filesz'] for p in segments.values()),
                 load_memory=sum(p['memsz'] for p in segments.values()),elf_file=byte_length)
    return dict(sha256=sha(ROOT/path),bytes=metrics,segments=segments,sections=sections,allocated_headers=details)

report={n:measure(n,p) for n,p in images.items()}
assert '.bss' not in report['absent-bss']['allocated_headers']
assert report['empty-bss']['allocated_headers']['.bss']['size']==0
assert report['independent-bad-start']['bss_start']%8 and not report['independent-bad-start']['bss_end']%8
assert not report['independent-bad-end']['bss_start']%8 and report['independent-bad-end']['bss_end']%8
assert report['retain']['bytes']==report['padded-and-sparse']['bytes']
assert report['retain']['sections']==report['padded-and-sparse']['sections']
assert 'R' in report['retain']['allocated_headers']['.rodata']['flags']
pairs=[('minimal','fixed-rr'),('fixed-rr','minimal'),('padded-and-sparse','retain'),('retain','padded-and-sparse')]
for n in images:
    if n not in ('minimal','fixed-rr'):
        pairs.extend([(n,'fixed-rr'),('minimal',n)])
results=[]
for a,b in pairs:
    if 'invalid' in report[a] or 'invalid' in report[b]:
        results.append(dict(minimal=a,fixed_rr=b,exit=2))
    else:
        ma,mb=report[a]['bytes'],report[b]['bytes']
        fits={k:ma[k]<=limit for k,limit in limits.items()}
        results.append(dict(minimal=a,fixed_rr=b,exit=int(not all(fits.values())),fits=fits,
                            delta={k:mb[k]-v for k,v in ma.items()}))
write_json(ROOT/'frozen-independent.json',dict(images=report,expected=results,limits=limits))
print(sha(ROOT/'frozen-independent.json'))
