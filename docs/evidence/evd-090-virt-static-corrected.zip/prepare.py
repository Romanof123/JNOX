from run_lib import *

generated=ROOT/'generated'
generated.mkdir(exist_ok=True)
wl=['wsl','-d','Ubuntu','--']
run('host-python',[sys.executable,'--version'])
run('readelf-version',wl+['readelf','--version'])
run('assembler-version',wl+['aarch64-linux-gnu-as','--version'])
_, sysroot=run('rust-sysroot',['rustc','+1.95.0','--print','sysroot'])
lld=Path(sysroot.strip()) / 'lib/rustlib/x86_64-pc-windows-msvc/bin/rust-lld.exe'
run('linker-version',[lld,'-flavor','gnu','--version'])
(generated/'linker-sha256.txt').write_text(sha(lld)+'  '+str(lld)+'\n')
lock=ROOT/'original/SHA256SUMS'
for line in lock.read_text().splitlines():
    digest, name = line.split(maxsplit=1)
    assert sha(ROOT/'original'/name.lstrip('*'))==digest, name

original=ROOT/'original/fixtures'
link_source=(ROOT/'source/kernel/link.ld').read_text()
asm=(original/'padded-and-sparse.s').read_text()
new={}
new['independent-bad-start']=(asm,link_source.replace('.bss (NOLOAD) : ALIGN(8)', '.bss (NOLOAD) : ALIGN(1)'))
new['independent-bad-end']=(asm.replace('.space 16417','.space 17'),link_source.replace('        . = ALIGN(8);',''))
new['empty-bss']=(asm.replace('    .space 16417',''),link_source)
without_bss=link_source[:link_source.index('    .bss (NOLOAD)')] + link_source[link_source.index('    .stack (NOLOAD)'):]
new['absent-bss']=(asm[:asm.index('.section .bss')],without_bss.replace('/DISCARD/ : {','/DISCARD/ : { *(.bss .bss.* COMMON)'))
new['unaligned-empty-bss']=(asm.replace('    .space 16417',''),link_source.replace('.bss (NOLOAD) : ALIGN(8)', '.bss (NOLOAD) : ALIGN(1)').replace('        . = ALIGN(8);',''))
for name,(a,l) in new.items():
    (generated/(name+'.s')).write_bytes(a.encode()); (generated/(name+'.ld')).write_bytes(l.encode())
for src in sorted(list(original.glob('*.s'))+list(generated.glob('*.s'))):
    name=src.stem
    secscript=src.with_suffix('.ld')
    if not secscript.is_file(): secscript=ROOT/'source/kernel/link.ld'
    rel=lambda p:p.relative_to(ROOT).as_posix()
    prefix='generated/'+name
    run('assemble-'+name,wl+['aarch64-linux-gnu-as','-o',prefix+'.o',rel(src)])
    run('link-'+name,[lld,'-flavor','gnu','-T',rel(secscript),'-o',prefix+'.elf',prefix+'.o'])
equal={p.stem:sha(p)==sha(generated/p.name) for p in original.glob('*.elf') if (generated/p.name).is_file()}
write_json(generated/'bit-identical-original-fixtures.json',equal)
for name,path in images.items():
    if name=='short':
        run('readelf-'+name,wl+['readelf','-W','-h','-l','-S','-s',path],expected=None)
    else:
        run('readelf-'+name,wl+['readelf','-W','-h','-l','-S','-s',path])
