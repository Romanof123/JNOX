from pathlib import Path
import hashlib, json, subprocess, sys, zipfile

root = Path(__file__).resolve().parent
existing = Path('D:/codex/j-nox')
head = '812cfd80c62b8936bfd53e5ff4ffe185195375a3'
evidence = '9b1bc9b8d527d05725f85cb00849a4ef4ccf8a85'
base = '34454f955a30b0d3be0a4dfc73435a344f2dbff9'

def command(name, args, destination=None, cwd=root):
    result = subprocess.run(list(map(str, args)), cwd=cwd, capture_output=True)
    (destination or root.joinpath(name+'.out')).write_bytes(result.stdout)
    root.joinpath(name+'.err').write_bytes(result.stderr)
    with (root/'acquisition.jsonl').open('a', encoding='utf-8') as f:
        print(json.dumps(dict(name=name, args=list(map(str,args)), cwd=str(cwd), exit=result.returncode)),file=f)
    result.check_returncode()
    return result.stdout

def main():
    git = ['git','-C',existing]
    command('archive-source', [*git, 'archive', '--format=zip', head, 'tools', 'docs/scheduling-footprint.en.md', 'kernel/link.ld', 'kernel/.cargo/config.toml', 'kernel/build.rs', 'arch/aarch64/start.S'],root/'source.zip')
    with zipfile.ZipFile(root/'source.zip') as z: z.extractall(root/'source')
    command('base-head-diff',[*git,'diff','--name-status',base,head])
    command('base-head-code-diff',[*git,'diff','--exit-code',base,head,'--','arch','kernel','crates','Cargo.lock','Cargo.toml','rust-toolchain.toml','.cargo','rust-toolchain'])
    command('root-tree',[*git,'ls-tree',head]); command('base-head-commits',[*git,'show','-s','--format=%H %T %P %s',base,head])
    command('evidence-init',['git','init','--bare',root/'evidence.git'])
    evidence_git = ['git','--git-dir',root/'evidence.git']
    command('evidence-fetch',[*evidence_git,'fetch','--depth=1','--filter=blob:none','https://github.com/Romanof123/JNOX.git',evidence])
    command('evidence-tree',[*evidence_git,'ls-tree',evidence,'docs/evidence/evd-090-virt-static-first.zip'])
    command('evidence-extract',[*evidence_git,'show',evidence+':docs/evidence/evd-090-virt-static-first.zip'],root/'original.zip')
    with zipfile.ZipFile(root/'original.zip') as z:
        for name in z.namelist():
            print(name)
        z.extractall(root/'original')
    (root/'package-sha256.txt').write_text(hashlib.sha256((root/'original.zip').read_bytes()).hexdigest()+'  original.zip\n')

if __name__=='__main__': main()
