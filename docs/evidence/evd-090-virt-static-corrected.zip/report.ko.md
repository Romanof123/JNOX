# EVD-090 재검증 · AArch64 virt 정적 메모리 사용량

`812cfd80c62b8936bfd53e5ff4ffe185195375a3`에서 지정된 최소 부팅 이미지가 REQ-009의 두 정적 상한을 모두 충족했다. 수정된 검사기는 #188에서 정한 BSS 경계와 읽기 전용 상수 조건을 두 입력 위치에서 모두 판정했다. 이 결과는 #4와 #21의 VER-009 중 AArch64 virt 정적 항목에 적용된다. 런타임 스택·힙 최고 사용량, 초기화 시간, 실물 보드 지연, 다른 포트에는 별도 측정이 필요하다. [계약](https://github.com/Romanof123/JNOX/blob/812cfd80c62b8936bfd53e5ff4ffe185195375a3/docs/scheduling-footprint.md) · [PR #185](https://github.com/Romanof123/JNOX/pull/185) · [#188](https://github.com/Romanof123/JNOX/issues/188)

| 항목(바이트) | 최소 부팅 | 일반 고정 우선순위 RR | RR − 최소 |
|---|---:|---:|---:|
| 코드와 상수, RX 전체 | 275 | 14,728 | +14,453 |
| RX 시작부터 RW 끝까지 물리 RAM | 20,496 | 115,056 | +94,560 |
| RX와 RW 사이 간격 | 3,821 | 1,656 | −2,165 |
| RW 예약 | 16,400 | 98,672 | +82,272 |
| RX 내부 패딩 | 0 | 0 | 0 |
| RW 내부 패딩 | 8 | 8 | 0 |
| 링크된 부팅 스택 | 16,384 | 16,384 | 0 |
| PT_LOAD 파일 데이터 | 275 | 15,016 | +14,741 |
| PT_LOAD 매핑 메모리 | 16,675 | 113,400 | +96,725 |
| ELF 파일 전체 | 71,128 | 94,096 | +22,968 |

최소 이미지의 RX 여유는 262,144 B 상한까지 261,869 B, RAM 여유는 2,097,152 B 상한까지 2,076,656 B이다. 상한은 최소 이미지에만 적용한다. 두 이미지 모두 진입점과 RX 시작이 `0x40200000`이고 가상·물리 주소가 같은 두 PT_LOAD가 RX, RW 순서로 배치된다. 최소 이미지의 RW 구간은 `[0x40201000,0x40205010)`, RR은 `[0x40204000,0x4021c170)`이다. 각 RAM 예약은 275 + 3,821 + 16,400 B와 14,728 + 1,656 + 98,672 B로 복원된다. 두 이미지 모두 RW 마지막에 16 KiB NOLOAD 부팅 스택을 두며 끝 주소가 스택 심볼과 일치한다. BSS 크기는 각각 8 B와 81,992 B이다. 시작 코드는 이 심볼로 SP를 설정하고 8바이트 단위로 BSS를 지운다. [최소 이미지 readelf](logs/readelf-minimal.out) · [RR readelf](logs/readelf-fixed-rr.out) · [시작 코드](source/arch/aarch64/start.S)

## 출처와 검증 방법

두 실제 릴리스 ELF는 `9b1bc9b8d527d05725f85cb00849a4ef4ccf8a85`의 Git blob `e2a953ca3dd60ff8b6f0b247de11a32ed71502f3`에서 추출했다. 압축 파일 SHA-256은 `8810c8505a82e821f5532d7ff171155f083c09cc633d23d8863bbb0648d72102`이며 내부 체크섬을 모두 확인했다. 최초 빌드 `34454f955a30b0d3be0a4dfc73435a344f2dbff9`와 수정 커밋 사이의 전체 Git 차이는 정적 사용량 문서 두 개, 검사기, 검사기 테스트뿐이다. 커널 빌드 입력이 동일해 두 ELF를 재사용했다. [원본 묶음](https://github.com/Romanof123/JNOX/blob/9b1bc9b8d527d05725f85cb00849a4ef4ccf8a85/docs/evidence/evd-090-virt-static-first.zip) · [전체 변경 파일](base-head-diff.out)

원본은 `kernel/`에서 `cargo +1.95.0 build --target aarch64-unknown-none --release --locked -j1`으로 빌드했다. Cortex-A72, release 최적화 s, 별도 대상 디렉터리를 사용했다. 두 이미지 모두 `JNOX_ARCH=aarch64 JNOX_BOARD=virt`를 설정하고 Cargo 기능 선택을 비웠다. RR에만 `JNOX_PROFILE=fixed JNOX_APP=fixed-rr`를 추가했다. 빌드 스크립트 기록에서 최소 부팅과 일반 fixed-RR 선택을 확인했다. 재검증에는 GNU readelf·GNU as 2.38과 Rust LLD 22.1.2를 사용했다. [원본 매니페스트](original/manifest.json) · [최소 빌드 설정](original/minimal-build-script.txt) · [RR 빌드 설정](original/fixed-rr-build-script.txt)

| 바이너리 | SHA-256 |
|---|---|
| 최소 | `c90b56c85e939df91710124411204c0024ebc054b3a35f314fce7a96967d06be` |
| 일반 fixed-RR | `c852c3f0c53af512c9e3320d256459fa9eb1615a6c7857b25e8c15dc9fde07ec` |

계약과 원본 빌드 매니페스트에 첫 판정의 통과·실패가 표시돼 있었다. 기존 수치 보고서를 열거나 수정 검사기를 실행하기 전에 GNU readelf 출력에서 별도로 계산한 값과 예상 종료 코드를 파일로 확정했다. 이 파일의 SHA-256은 `f6e0446b2538a23f481d1e31ad1064c789c6d824f2d57c665264344a7fbcef58`이다. 30회 실행에서 세그먼트, 크기가 있는 할당 섹션, 해시, 크기, 부호가 있는 차이, 상한 판정, 종료 코드가 모두 일치했다. 실제 커널 두 개에 대한 JSON 전체도 원본 결과와 일치했다. [독립 계산](frozen-independent.json) · [실행 결과](replayed.json) · [명령 기록](commands.jsonl)

## 경계 시험

원본 어셈블리 시험 이미지 7개는 같은 도구로 다시 링크해 바이트 단위로 일치했다. 원본의 잘못된 BSS 끝은 `0x40205029`였다. 별도로 링크한 시험 ELF에서 끝만 정렬된 BSS(`0x40201003`부터 `0x40205028`), 시작만 정렬된 BSS(`0x40201008`부터 `0x40201019`), 정렬되지 않은 빈 BSS(`0x40201003`)를 재현했다. 모두 최소·비교 양쪽 위치에서 BSS 진단과 종료 코드 2를 냈다. 정렬된 빈 BSS와 BSS 생략은 양쪽에서 통과했다. 읽기 전용 상수에 유지 플래그를 추가한 이미지도 두 위치에서 통과했다. 일반 이미지와 유지 플래그 이미지의 상수는 19 B이고 플래그는 각각 A와 AR이다. 할당 섹션 범위와 10개 크기 항목이 모두 같으며 RX 내부 패딩은 28 B, 세그먼트 사이 간격은 4,045 B이다. [재링크 대조](generated/bit-identical-original-fixtures.json) · [유지 플래그 readelf](logs/readelf-retain.out)

두 상한과 정확히 같으면 0, RX가 1 B 초과하면 1, RAM이 16 B 초과하면 1, 모두 초과해도 1을 반환했다. 초과 입력에서도 전체 측정값과 부호 있는 차이를 출력했다. 끝의 스택이 16바이트 정렬이어서 RAM은 16 B가 가능한 첫 초과량이다. 비교 이미지만 상한을 넘을 때에는 0을 반환했다. 잘린 파일은 양쪽 위치에서 2를 반환했다. 전용 검사기 5개와 일반 사용량 검사기 4개 테스트가 모두 통과했다. 게스트는 실행하지 않았다. 원본 묶음에 최초 검사가 정렬되지 않은 BSS를 수용하고 유지 플래그 상수를 거부한 기록이 보존돼 있다. [전용 테스트](logs/suite-test_virt_footprint.py.err) · [일반 테스트](logs/suite-test_scheduling_footprint.py.err) · [최초 BSS 판정](original/boundary-first.log) · [최초 상수 판정](original/retain-first.json)

## 재현

검증 ZIP을 Windows 드라이브에 푼다. Python 3, WSL Ubuntu의 GNU readelf와 aarch64-linux-gnu-as 2.38, Windows MSVC용 Rust 1.95.0을 사용해 그 디렉터리에서 다음 명령을 실행한다. 입력과 출력은 모두 같은 디렉터리에 기록되며 원본 묶음과 측정 소스도 들어 있다.

```powershell
python -B prepare.py
python -B freeze.py
python -B replay.py
```
