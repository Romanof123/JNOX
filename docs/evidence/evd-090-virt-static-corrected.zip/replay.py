from run_lib import *
from collections import Counter

frozen=ROOT/'frozen-independent.json'
assert sha(frozen)=='f6e0446b2538a23f481d1e31ad1064c789c6d824f2d57c665264344a7fbcef58'
oracle=json.loads(frozen.read_text())
out=[]
for row in oracle['expected']:
    a,b=row['minimal'],row['fixed_rr']
    tag='case-'+a+'--'+b
    rc, text=run(tag,[sys.executable,'-B','source/tools/virt_footprint.py','--minimal',images[a],'--fixed-rr',images[b]],row['exit'])
    if rc==2:
        assert not text
        error=(LOG/(tag+'.err')).read_text()
        invalid=next(n for n in (a,b) if 'invalid' in oracle['images'][n])
        assert Path(images[invalid]).name in error
        if invalid!='short': assert 'BSS start and exclusive end must both be 8-byte aligned' in error
    else:
        data=json.loads(text)
        assert not (LOG/(tag+'.err')).read_bytes()
        assert data['schema_version']==1 and data['delta_bytes']==row['delta']
        assert data['minimal_limits_bytes']==oracle['limits'] and data['minimal_within_limit']==row['fits']
        assert data['minimal_meets_reference']==(rc==0)
        for role,n in [('minimal',a),('fixed_rr',b)]:
            for k in ['sha256','segments','sections','bytes']:
                assert data[role][k]==oracle['images'][n][k],(tag,role,k)
    out.append(dict(minimal=a,fixed_rr=b,exit=rc,matched=True))
for suite in ['test_virt_footprint.py','test_scheduling_footprint.py']:
    run('suite-'+suite,[sys.executable,'-B','-m','unittest','discover','-s','source/tools','-p',suite,'-v'])
prod=json.loads((LOG/'case-minimal--fixed-rr.out').read_text())
first=json.loads((ROOT/'original/checker.json').read_text())
write_json(ROOT/'replayed.json',dict(cases=out,exit_counts=dict(Counter(r['exit'] for r in out)),
                                     original_production_report_unchanged=(prod==first)))
assert prod==first
