# Corrected EVD-090 · AArch64 virt static footprint

At `812cfd80c62b8936bfd53e5ff4ffe185195375a3`, the named minimal boot image passes both REQ-009 static engineering ceilings. The corrected checker passes the tested #188 acceptance cases in both argument positions. This decision covers the static part of VER-009 for #4 and #21. Runtime stack or heap peaks, initialization time, hardware latency, and other ports require their own measurements. [Contract](https://github.com/Romanof123/JNOX/blob/812cfd80c62b8936bfd53e5ff4ffe185195375a3/docs/scheduling-footprint.en.md) · [PR #185](https://github.com/Romanof123/JNOX/pull/185) · [#188](https://github.com/Romanof123/JNOX/issues/188)

| Quantity in bytes | Minimal boot | Ordinary fixed RR | RR minus boot |
|---|---:|---:|---:|
| Code and constants, full RX | 275 | 14,728 | +14,453 |
| Physical RAM span through RW end | 20,496 | 115,056 | +94,560 |
| RX-to-RW gap | 3,821 | 1,656 | −2,165 |
| RW memory span | 16,400 | 98,672 | +82,272 |
| Padding within RX | 0 | 0 | 0 |
| Padding within RW | 8 | 8 | 0 |
| Linked boot stack | 16,384 | 16,384 | 0 |
| PT_LOAD file payload | 275 | 15,016 | +14,741 |
| PT_LOAD mapped memory | 16,675 | 113,400 | +96,725 |
| Whole ELF file | 71,128 | 94,096 | +22,968 |

Minimal has 261,869 B remaining under the 262,144 B RX ceiling and 2,076,656 B under the 2,097,152 B RAM ceiling. Only minimal is scored. Each ELF has entry and RX start at `0x40200000` and exactly two ordered identity-mapped loads. Minimal RW occupies `[0x40201000,0x40205010)`; RR occupies `[0x40204000,0x4021c170)`. The minimal span is 275 + 3,821 + 16,400 B and RR is 14,728 + 1,656 + 98,672 B. In each image the terminal 16 KiB NOLOAD stack fits inside RW, with its exclusive end equal to the linked stack-top symbol. The allocated BSS is 8 B for boot and 81,992 B for RR. The startup code loads SP from the stack-top symbol and clears BSS in 8-byte stores. [GNU readelf boot](logs/readelf-minimal.out) · [GNU readelf RR](logs/readelf-fixed-rr.out) · [Startup source](source/arch/aarch64/start.S)

## Provenance and independence

The original release ELFs came from Git blob `e2a953ca3dd60ff8b6f0b247de11a32ed71502f3` at `9b1bc9b8d527d05725f85cb00849a4ef4ccf8a85`. ZIP SHA-256 is `8810c8505a82e821f5532d7ff171155f083c09cc633d23d8863bbb0648d72102`. All entries in its checksum inventory matched. The full Git tree difference from original build `34454f955a30b0d3be0a4dfc73435a344f2dbff9` to corrected head contains the two footprint documents, checker and checker tests. This run reused both production ELFs. [Original evidence](https://github.com/Romanof123/JNOX/blob/9b1bc9b8d527d05725f85cb00849a4ef4ccf8a85/docs/evidence/evd-090-virt-static-first.zip) · [Complete changed-file list](base-head-diff.out)

The archived build used `cargo +1.95.0 build --target aarch64-unknown-none --release --locked -j1` from `kernel/`, Cortex-A72, release opt-level s and separate target directories. Both images use `JNOX_ARCH=aarch64 JNOX_BOARD=virt` and zero Cargo features. Only the comparator adds `JNOX_PROFILE=fixed JNOX_APP=fixed-rr`. Build-script output identifies the ordinary boot and fixed-RR selections. The isolated replay used GNU readelf and GNU as 2.38 and Rust LLD 22.1.2. [Original manifest](original/manifest.json) · [Minimal selection](original/minimal-build-script.txt) · [Comparator selection](original/fixed-rr-build-script.txt)

| Binary | SHA-256 |
|---|---|
| Minimal | `c90b56c85e939df91710124411204c0024ebc054b3a35f314fce7a96967d06be` |
| Ordinary fixed RR | `c852c3f0c53af512c9e3320d256459fa9eb1615a6c7857b25e8c15dc9fde07ec` |

The contract and original build manifest disclose first-round verdict labels. A separate readelf-based calculation froze the measured fields and classifications before consulting the original numeric report or executing the corrected checker. Its SHA-256 is `f6e0446b2538a23f481d1e31ad1064c789c6d824f2d57c665264344a7fbcef58`. Every reported segment, allocated nonempty section, hash, byte field, signed change, limit and exit agreed across 30 invocations. The production report also exactly matched the archived JSON object. [Frozen expectations](frozen-independent.json) · [Results](replayed.json) · [Commands](commands.jsonl)

## Controls

All seven archived assembly fixtures rebuilt byte-for-byte with GNU as and the pinned linker. The original invalid BSS ended at `0x40205029`. Additional separately linked controls isolated a bad start at `0x40201003` with aligned end `0x40205028`, a bad end at `0x40201019` with aligned start `0x40201008`, and an unaligned empty section at `0x40201003`. Each produced exit 2 and a BSS-specific diagnostic in either argument. Both aligned zero-size BSS and absent BSS passed in either argument. Both positions accepted the retained constants; the plain and retained padded images have the same accounting in all ten fields and identical allocated section extents. The 19 B read-only constants have flags A and AR respectively, with 28 B RX padding and 4,045 B between segments. [Relink comparison](generated/bit-identical-original-fixtures.json) · [Retained section listing](logs/readelf-retain.out)

Equality at both ceilings returned 0. RX at 262,145 B returned 1, RAM at 2,097,168 B returned 1, and exceeding both returned 1, with complete signed measurements. The first possible RAM step above the ceiling is 16 B because the terminal stack is 16-byte aligned. A comparison image exceeding either or both ceilings yielded 0 with the valid minimal input. A truncated input yielded 2 in both positions. The strict suite passed 5 tests and the generic scheduling footprint suite passed 4. No guest ran. The immutable first-round logs retain the original unaligned-BSS acceptances and retained-constants rejections. [Strict suite](logs/suite-test_virt_footprint.py.err) · [Generic suite](logs/suite-test_scheduling_footprint.py.err) · [First-round boundary output](original/boundary-first.log) · [First-round retained output](original/retain-first.json)

## Reproduction

Extract the evidence ZIP on a Windows drive. With Python 3, WSL Ubuntu GNU readelf and aarch64-linux-gnu-as 2.38, and the Windows Rust 1.95.0 MSVC toolchain installed, run the following from its root. Each invocation writes inputs and outputs to the extracted directory. The independent results, source and original archive are included for offline review.

```powershell
python -B prepare.py
python -B freeze.py
python -B replay.py
```
