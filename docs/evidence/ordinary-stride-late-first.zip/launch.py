import subprocess as s,hashlib,os,json,time,shutil,re,sys
from pathlib import Path
d=Path(__file__).resolve().parent
cases='lottery1 lottery2 stride lottery-miss stride-delay'.split()
native=Path.home()/'qa200-first-6ed6afb'
native.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for i,k in enumerate(cases):
 p=native/k;p.mkdir(); t=d/'first'/k
 elf=p/'kernel.elf';shutil.copyfile(d/'builds'/k/'kernel.elf',elf)
 cmd=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-m','128M','-accel','tcg','-nodefaults','-display','none','-monitor','none','-serial','file:'+str(p/'uart'),'-d','int','-D',str(p/'exceptions'),'-kernel',str(elf)]
 (p/'freeze.json').write_text(json.dumps(dict(argv=cmd,version=s.check_output([cmd[0],'--version'],text=True),affinity=sorted(os.sched_getaffinity(0)),sha=sha(elf),timeout=25,footer_quiet=.15)))
 with (p/'disassembly').open('wb') as out:s.run(['llvm-objdump','-d',elf],stdout=out,check=True)
 start=time.monotonic();end=None
 with (p/'stdout').open('wb') as out,(p/'stderr').open('wb') as err:
  proc=s.Popen(cmd,stdin=s.DEVNULL,stdout=out,stderr=err)
  while proc.poll() is None and time.monotonic()-start<25:
   if (p/'uart').exists():
    ends=re.findall(rb'^PROP END ([0-9 ]+)\r?\n',(p/'uart').read_bytes(),re.M)
    if ends:end=list(map(int,ends[0].split()));time.sleep(.15);break
   time.sleep(.025)
  if proc.poll() is None:proc.terminate();proc.wait(timeout=5)
 (p/'outcome.json').write_text(json.dumps(dict(footer=end,elapsed=time.monotonic()-start,exit=proc.returncode)))
 sums={a.name:sha(a) for a in p.iterdir()};shutil.copytree(p,t);assert sums=={a.name:sha(a) for a in t.iterdir()}
 (t/'verified.json').write_text(json.dumps(sums,indent=2))
 print(k,end,flush=True)
 if not (end and ((end[0]>0 and end[1:]==[3,0,2,1]) if i==3 else end==[0]*5)):break
