from pathlib import Path
import json,hashlib,sys,re,collections
from elftools.elf.elffile import ELFFile
import score
D=Path(__file__).resolve().parent
def layout(p):
 with p.open('rb') as f:
  elf=ELFFile(f)
  return [(s['p_vaddr'],s['p_flags'],s['p_memsz'],s.data()) for s in elf.iter_segments() if s['p_type']=='PT_LOAD'],elf.get_section_by_name('.text').data()
res={}
assert score.checks() and all(w['within_three_points'] for w in score.calendar()['windows'])
for i,n in enumerate(score.CASES):
 p=D/'first'/n
 for f,h in json.loads((p/'verified.json').read_text()).items():assert hashlib.sha256((p/f).read_bytes()).hexdigest()==h
 r=score.score(n,p/'uart',p/'kernel.elf',p/'exceptions')
 start=r['grants'][0][3] if r['grants'] else None
 rows=r['raw_rows']
 ev=collections.Counter(x[0] for x in score.external(p/'exceptions'))
 res[n]=dict(footer=r['first_guest_record'],grants=r['counts'],service=r['whole_service'],issues=r['findings'],events=dict(ev),first=r['grants'][:1])
 print(n,res[n],flush=True)
 assert not r['parser_errors']
 if i!=3:assert r['complete_arithmetic_and_mechanism_observation']
 else:assert r['first_guest_record']==(446,3,0,2,1) and len(r['findings'])==2
 if i==4:
  stamp=next(x[5] for x in rows if x[:3]==(12,0,0))
  stop=r['grants'][0][5];assert start+7500000<=stamp<=stop
  res[n].update(stamp=stamp,bound=start+7500000)
 for m in ('rng-word','ticket-owner','counter-stop','resume-pc','frozen-client') if not i else ():
  import tempfile
  with tempfile.TemporaryDirectory() as tmp:
   u=Path(tmp)/'uart';u.write_text(score.perturb((p/'uart').read_text(),m))
   assert not score.score(n,u,p/'kernel.elf',p/'exceptions')['complete_arithmetic_and_mechanism_observation']
for n in list(score.CASES)+['legacy']:
 a=D/'builds'/n/'kernel.elf';b=D/'base'/n/'kernel.elf'
 x,y=layout(a);old,txt=layout(b)
 v=dict(whole=a.read_bytes()==b.read_bytes(),load=x==old,text=y==txt)
 print(n,v);res.setdefault(n,{})['elf']=v
(D/'results.json').write_text(json.dumps(res,indent=2))
