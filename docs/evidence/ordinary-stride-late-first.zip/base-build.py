from pathlib import Path
import subprocess as s, shutil, os, json, zipfile, hashlib
d=Path(__file__).resolve().parent
src=d.parent/'qa200-base'
cases='lottery1 lottery2 stride lottery-miss stride-delay'.split()
for n in cases+['legacy']:
 p=d/'base'/n;p.mkdir(parents=True)
 opt=dict(JNOX_BOARD='virt',JNOX_PROFILE='proportional',JNOX_APP=n if n in cases else 'lottery1')
 opt.update({'wrong-control':dict(JNOX_CONTROL_CASE='healthy'),'wrong-board':dict(JNOX_BOARD='pi4'),'wrong-app':dict(JNOX_APP='invalid'),'wrong-profile':dict(JNOX_PROFILE='aperiodic')}.get(n,{}))
 if n=='legacy':opt={'JNOX_BOARD':'virt'}
 cmd=['cargo','+1.95.0','build','--release','--locked','-j1']+(['--features','proportional-bench'] if n in ('legacy','mixed') else [])
 env={k:v for k,v in os.environ.items() if not k.startswith(('JNOX_','RUST','CARGO_TARGET_','CARGO_PROFILE_','CARGO_ENCODED_RUSTFLAGS'))}
 env.update(opt,CARGO_TARGET_DIR=str(d.parent/'qa200-base-target'),CARGO_BUILD_JOBS='1',TEMP=str(p),TMP=str(p))
 r=s.run(cmd,cwd=src/'kernel',env=env,stdout=s.PIPE,stderr=s.STDOUT)
 (p/'build.log').write_bytes(r.stdout)
 (p/'args.json').write_text(json.dumps([cmd,opt,r.returncode]))
 if n in cases+['legacy']:
  assert not r.returncode,r.stdout
  shutil.copyfile(d.parent/'qa200-base-target/aarch64-unknown-none/release/jnox-kernel',p/'kernel.elf')
 else:
  error={'wrong-control':'JNOX_CONTROL_CASE must be unset','wrong-board':'ordinary proportional requires virt','wrong-app':'ordinary proportional requires an explicit','wrong-profile':'invalid aperiodic application','mixed':'ordinary proportional requires virt'}[n]
  assert r.returncode and error.encode() in r.stdout,r.stdout
 print(n,r.returncode,flush=True)

