from pathlib import Path
from elftools.elf.elffile import ELFFile
d=Path(__file__).resolve().parent
def workers(p):
 with p.open('rb') as f:
  e=ELFFile(f);sym=e.get_section_by_name('.symtab');out={}
  for n in 'abc':
   s=sym.get_symbol_by_name('prop_rust_'+n)[0];sec=e.get_section(s['st_shndx']);off=s['st_value']-sec['sh_addr'];out[n]=sec.data()[off:off+s['st_size']]
  return out
for p in (d/'first').iterdir():
 x=workers(p/'kernel.elf');y=workers(d/'base'/p.name/'kernel.elf')
 print(p.name,[(n,x[n]==y[n],len(x[n]),len(y[n]),x[n].count(bytes.fromhex('df4203d5')),x[n].count(bytes.fromhex('ff4203d5'))) for n in x])
