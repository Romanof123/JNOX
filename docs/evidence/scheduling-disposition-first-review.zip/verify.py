import pathlib,subprocess,re,zipfile,hashlib,json,urllib.request,io
p=pathlib.Path('docs/evidence'); out=pathlib.Path('../jnox222-proof')
def sha(b): return hashlib.sha256(b).hexdigest()
def remote(url): return urllib.request.urlopen(url,timeout=90).read()
def archive(doc,raw,base):
 for link in re.findall(r'\]\(([^)]+\.zip)\)',raw):
  b=remote(base+link) if base else (p/link).read_bytes()
  h=sha(b); assert h in raw.lower() or not re.search(r"[0-9a-f]{64}",raw.lower()), (doc,link,h)
  z=zipfile.ZipFile(io.BytesIO(b)); assert z.testzip() is None
  print(doc,link,h, len(z.namelist()),z.namelist()[:4])
  for name in z.namelist():
   if name.endswith(('results.json','summary.json','outcomes.json','outcomes.tsv')):
    print(name,z.read(name)[:650])
for name in ['admitted-telemetry-batch-first','recurring-hierarchical-first','pm-open-tracking-20261124T180640Z']:
 doc=(p/(name+'.en-ko.md')).read_text('utf-8'); archive(name,doc,None)
r=pathlib.Path('docs/scheduling-release-cases.en.md').read_text('utf-8')
for ln in r.splitlines():
 if not ln.startswith(('| POL-004 |','| POL-008 |')): continue
 for url in re.findall(r'\]\((https://github.com/[^)]+)\)',ln):
  if not any(k in url for k in ['periodic-single','reservation-integrated-first','reservation-absolute','reservation-prepared','reservation-worker','reservation-frame-ordinary']): continue
  raw=url.replace('github.com/','raw.githubusercontent.com/').replace('/blob/','/')
  doc=remote(raw).decode(); print(url, doc[:420]); archive(url,doc,raw.rsplit('/',1)[0]+'/')
for f in ['docs/scheduling-release-cases.en.md','docs/scheduling-release-cases.md']:
 old=subprocess.check_output(['git','show','7db3611:'+f]).decode(); new=pathlib.Path(f).read_text('utf-8')
 a=[x for x in old.splitlines() if x.startswith('| POL-')]; b=[x for x in new.splitlines() if x.startswith('| POL-')]; assert len(a)==len(b)==18
 for x,y in zip(a,b):
  before=x.split('|'); after=y.split('|'); assert before[:2]==after[:2] and before[2].strip() in after[2] and before[3:]==after[3:],before[1]
j=(out/'pm/open-items.json').read_bytes(); assert sha(j)=='ea6a3b21c561c1f718e6a37d16cc956332266a0a4ee077f3d820b797b3778468'
rows={x['number']:x for x in json.loads(j)}; mapping=json.loads((out/'pm/primary-issues.json').read_bytes()); assert len(rows)==46 and len(mapping)==15 and sum('pull_request' in x for x in rows.values())==15
doc=(p/'pm-open-tracking-20261124T180640Z.en-ko.md').read_text('utf-8')
for n,i in mapping.items():
 pr=rows[int(n)]; issue=rows[i]; team=[t['name'] for t in pr['labels'] if t['name'].startswith('team:')]; assert len(team)==1 and re.search(fr'/pull/{n}\).*?/issues/{i}\).*?{team[0]}',doc)
 print(n,i,team[0],pr['body'].splitlines()[0][:175])
for f in ['docs/lifecycle.md','docs/lifecycle.en.md']: assert 'evidence/pm-open-tracking-20261124T180640Z.en-ko.md' in pathlib.Path(f).read_text('utf-8')

