import os,json,subprocess as s,uuid
from pathlib import Path
r=Path.home()/'jnox272-corrected';src=r/'src';raw=r/'firsts';raw.mkdir()
tc=Path.home()/'jnox-169-first-e203caa'
plan=[dict(position=str(uuid.uuid4()),mode=m,frame=f) for m in ('off','disabled','active','saturate') for f in (0,1)]
(raw/'plan.json').write_text(json.dumps(plan,indent=2))
for p in plan:
 d=raw/(p['mode']+str(p['frame'])+'-'+p['position']);d.mkdir();g=d/'guest'
 env=dict(os.environ,PATH=str(tc/'cargo/bin')+':'+os.environ['PATH'],CARGO_HOME=str(tc/'cargo'),RUSTUP_HOME=str(tc/'rustup'),CARGO_TARGET_DIR=str(r/'target'),PYTHONDONTWRITEBYTECODE='1',JNOX_APP='mlfq-wake',JNOX_PROFILE='multilevel',JNOX_BOARD='virt',SCHED_APP_TRACE_CAPTURE_DIR=str(g))
 for key in ['JNOX_SCHED_APP_TRACE','JNOX_MULTILEVEL_TRACE']:env.pop(key,None)
 if p['mode']!='off':env['JNOX_SCHED_APP_TRACE']=p['mode']
 if p['frame']:env['JNOX_MULTILEVEL_TRACE']='1'
 def run(cmd,log,cwd=src):
  cmd=list(map(str,cmd))
  with (d/log).open('ab') as fd:
   fd.write((json.dumps(cmd)+'\n').encode());fd.flush();return s.run(cmd,cwd=cwd,env=env,stdout=fd,stderr=s.STDOUT).returncode
 for cmd in [['cargo','+1.95.0','-V'],['rustc','+1.95.0','-Vv'],['git','rev-parse','HEAD'],['git','status','--porcelain']]:run(cmd,'build.log')
 b=run(['cargo','+1.95.0','build','--locked','--release','-j1'],'build.log',src/'kernel')
 boot=run(['python3','tools/qemu_boot.py','--profile','mlfq-wake','--qemu','tools/sched_app_trace_capture.py','--kernel',r/'target/aarch64-unknown-none/release/jnox-kernel'],'boot.log') if not b else -1
 seal=run(['python3','tools/sched_app_trace_decode.py','seal',g,'--build-log',d/'build.log','--boot-log',d/'boot.log'],'seal.log')
 dec=run(['python3','tools/sched_app_trace_decode.py','decode',g],'decode.log')
 print(d.name,b,boot,seal,dec,flush=True)
