import json,re,struct
from pathlib import Path
root=Path.home()/'jnox272-corrected'; out={}
for p in sorted(x for x in (root/'firsts').iterdir() if x.is_dir()):
 g=p/'guest';j=g/'ordinary_multilevel_witness.bin';txt=(g/'int.trace').read_text()
 pcs=list(map(lambda x:int(x,16),re.findall(r'Exception return from .* PC 0x([a-fA-F0-9]+)',txt)))
 if j.exists():
  data=j.read_bytes();n,f=struct.unpack_from('<QQ',data);saved={};nextpc=[];target=None
  for i in range(n):
   r=struct.unpack_from('<131Q',data,16+1048*i)
   if i:saved[r[3]]=(r[8],r[58])
   if r[10]!=4:
    nextpc.append(r[14])
    if r[10] in saved:assert saved[r[10]]==(r[13],r[14])
   if r[0]==2:target=saved[r[3]]
  assert nextpc==pcs;out[p.name]={'full_frame_restores':len(pcs),'blocked_frame_pc':target}
 else:out[p.name]={'eret_pc_sequence':pcs}
(root/'frames.json').write_text(json.dumps(out,indent=2))
