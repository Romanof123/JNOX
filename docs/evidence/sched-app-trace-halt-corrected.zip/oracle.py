import ctypes as C, struct,json,hashlib,re,collections
from pathlib import Path
root=Path.home()/'jnox272-corrected'; first=root/'firsts'
lib=C.CDLL(str(root/'packet.so'));lib.packet.argtypes=[C.c_uint64,C.c_uint64];lib.stream.argtypes=[C.c_uint64,C.c_uint];lib.packet.restype=lib.stream.restype=C.c_uint64
def words(p):return list(struct.unpack('<'+'Q'*(p.stat().st_size//8),p.read_bytes()))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def wake(p):
 g=p/'guest';a=words(g/'mlfq_wake_witness.bin');h=a[:40];rows=[a[40+15*i:55+15*i] for i in range(h[4])];mode=p.name.split('-')[0][:-1]
 u=h[1];W,S,E=h[5],h[8],h[9];assert h[0]==4 and h[2]==h[3]==23*u and u==625000 and h[39]==0
 assert h[17]==lib.packet(4,1) and h[19]==lib.stream(h[32],1)
 for i in range(4):
  d=lib.stream(h[20+i],i);assert d==h[24+i] and lib.packet(d^(h[19] if i==0 else h[28]),h[20+i]+1)==h[28+i]
 b=next(r for r in rows if r[0]==2);w=next(i for i,r in enumerate(rows) if r[0]==3 and r[1]==1); s=next(i for i,r in enumerate(rows[w:],w) if r[9]==0);reset=next(i for i,r in enumerate(rows[w:s+1],w) if r[7]); assert b[2]==0 and b[12]==h[12]==rows[s][13] and rows[w][5]==W and rows[s][10]==S and S<=E<=rows[s+1][5]
 assert b[11]==1 and rows[reset][9]==3 and rows[s][2]==3 and rows[reset][14]==1 and h[33]==8
 late=[r[5]-r[4] for r in rows[w+1:s+1]];gaps=[r[10]-r[5] for r in rows[w:s+1]];pre=rows[reset][6]-rows[w][6];post=rows[s][6]-rows[reset][6]
 assert max(late)<=u and pre<=11*u and post==h[7]<=3*u and sum(gaps)==h[10]<=2*u and 0<=E-S<=u and pre+post+sum(gaps)+E-S==E-W==h[15]<=23*u
 m=json.loads((g/'manifest.json').read_text());l=json.loads((g/'launch.json').read_text());assert sha(g/'manifest.json') in (g/'manifest.sha256').read_text() and all(sha(g/k)==v for k,v in m['artifacts'].items()) and Path(l['argv'][-1])==g/'kernel.elf' and sha(g/'kernel.elf') in (g/'boot.log').read_text()
 symbols=__import__('subprocess').check_output(['aarch64-linux-gnu-nm','-S',g/'kernel.elf'],text=True);timers=[r for r in rows if r[0]==4];assert (g/'int.trace').read_text().count('Taking exception 5 [IRQ]')==len(timers) and words(g/'multilevel_terminal_ctl.bin')==[0]
 z=dict(W=W,S=S,E=E,wall=E-W,raw_witness_only=True,frame=b[12],pre=pre,post=post,gaps=gaps,lateness=late,partial=E-S,receipt=h[28:32],packet_counts=h[20:24],timers=len(timers),run=m['run_uuid'])
 if mode=='off':assert 'jnox_sched_app_trace_v1' not in symbols;return z
 loc=re.search(r'^(\w+) (\w+) \w jnox_sched_app_trace_v1$',symbols,re.M); assert [int(x,16) for x in loc.groups()]==m['symbol']==m['extraction']==[l['trace_address'],l['trace_size']] and m['symbol'][1]==8320
 d=words(g/'trace.bin');n=d[10];rs=[d[16+8*i:24+8*i] for i in range(n)]
 assert d[:5]==[int.from_bytes(b'JNXTRC01','little'),1,128,64,128] and d[7:10]==[100*u,1,1] and not any(d[13:16]+d[16+8*n:])
 if mode=='disabled':assert d[5:7]==[128,0] and d[10:13]==[0,0,0];return z
 # Rebuild record identities from actual accepted lifecycle boundaries, including interleaved dispatch inside IRQ.
 ref=lambda i:0 if i==4 else (1<<32)+i
 expected=[]
 for i,r in enumerate(rows):
  owner,nextid=map(ref,[r[2],r[9]])
  if r[0]==4:expected.append((4,None,owner,owner,30,r[5]))
  if r[0]==2:expected.append((1,r[5],owner,owner,0,0))
  if r[0]==3:expected.append((2,None,owner,ref(0),W,0))
  if nextid:expected.append((3,r[10],owner,nextid,0,0))
  if r[0]==4:expected.append((6,None,owner,owner,30,r[5]))
  if i==s:expected.append((5,E,ref(0),ref(0),h[28],0))
 assert n==(4 if mode=='saturate' else len(expected)) and d[5:7]==[4 if mode=='saturate' else 128,2]
 for i,(r,e) in enumerate(zip(rs,expected)):assert r[0]==i+1 and r[7]==0 and all(y is None or x==y for x,y in zip(r[1:7],e))
 loss=[sum(e[0]!=5 for e in expected[n:]),sum(e[0]==5 for e in expected[n:])];assert d[11:13]==loss
 z.update(loss=loss,commits=n)
 if mode=='active':
  Q=next(r[2] for r in rs if r[1]==2);pairs=[(r[2],next(v[2] for v in rs if v[1]==6 and r[3:7]==v[3:7])) for r in rs if r[1]==4]
  assert W<=Q<=S<=E and all(x<=y for x,y in pairs) and all(x[1]<y[0] for x,y in zip(pairs,pairs[1:]))
  z.update(Q=Q,QW=Q-W,SQ=S-Q,SW=S-W,ES=E-S,timer_durations=[y-x for x,y in pairs],timer_overlap_final=sum(max(0,min(E,y)-max(S,x)) for x,y in pairs))
 return z

out={}
for p in sorted(x for x in first.iterdir() if x.is_dir()):
 g=p/'guest'; q=json.loads((g/'qmp.json').read_text()); pre=q['status'];post=json.loads((g/'halted.json').read_text());assert pre['running'] is True and pre['status']=='running' and [x['cpu-index'] for x in q['cpus']]==[0] and post['running'] is False and post['status']=='paused'
 out[p.name]=wake(p)
(root/'oracle.json').write_text(json.dumps(out,indent=2))
