from pathlib import Path
import os,sys,hashlib,shutil,subprocess as s,time,json,platform
D=Path('/mnt/d/codex/jnox207-independent-f959'); H=Path.home()/'qa207record';H.mkdir()
S=Path.home()/'qa207fresh'; T=Path.home()/'jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin'
os.environ.update(PATH=str(T)+':'+os.environ['PATH'],CARGO_BUILD_JOBS='1',RUST_TEST_THREADS='1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2))
def cmd(*args):return s.check_output(args,text=True).strip()
modes=['default','rust-prepared','rust-stages','selected-return'];apps=['ordinary-pi','ordinary-ceiling']
freeze=dict(head=cmd('git','-C',S,'rev-parse','HEAD'),design='26cf76e29e407522a1aad80bec2b452564644b81',order=[(m,a,t) for m in modes for a in apps for t in ('plain','traced')],criteria='Single attempts. Compare T start+6250, real IRQ PPI30 and enable, in-work actual arithmetic PC before ceiling midpoint, independently reconstruct owners, queues, priorities and selected saved frames, QEMU exceptions/returns, chunk ledger, audit, exits. Preserve failure prefixes. No retries or warmups.',host=platform.uname()._asdict(),fs=cmd('stat','-f','-c','%T',H),deps={})
for name in ['python3','cargo','rustc','qemu-system-aarch64','aarch64-linux-gnu-objdump','aarch64-linux-gnu-nm']:
 p=Path(shutil.which(name)).resolve();freeze['deps'][name]=[str(p),sha(p),cmd(str(p),'--version').splitlines()[0]]
put(D/'freeze.json',freeze)
for m in modes:
 for a in apps:
  b=H/(m+'-'+a);env=os.environ.copy();env.update(JNOX_PROFILE='mutex',JNOX_BOARD='virt',JNOX_APP=a,CARGO_TARGET_DIR=str(b))
  if m!='default':env['JNOX_MUTEX_ANCHOR']=m
  with (D/(b.name+'.build')).open('xb') as f:s.run(['cargo','build','--locked','--offline','--release','-j1'],cwd=S/'kernel',env=env,check=True,stdout=f,stderr=s.STDOUT)
  elf=b/'aarch64-unknown-none/release/jnox-kernel';image=D/'images'/b.name;image.mkdir(parents=True);shutil.copy2(elf,image/'kernel.elf')
  for nm,argv in [('disasm',['aarch64-linux-gnu-objdump','-d']),('symbols',['aarch64-linux-gnu-nm','-n'])]:
   (image/nm).write_bytes(s.check_output([*argv,elf]))
put(D/'frozen-images.json',{str(p.relative_to(D)):sha(p) for p in sorted((D/'images').rglob('kernel.elf'))})
for n,(m,a,t) in enumerate(freeze['order'],1):
 p=H/f'{n:02}-{m}-{a}-{t}';p.mkdir();elf=H/(m+'-'+a)/'aarch64-unknown-none/release/jnox-kernel'
 argv=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','stdio','-kernel',str(elf)]
 if t=='traced':argv+=['-d','int','-D',str(p/'external.log')]
 meta=dict(argv=argv,elf=sha(elf),allowance=15,wall_start=time.time(),mode=m,app=a)
 with (p/'uart').open('xb') as u,(p/'stderr').open('xb') as e:
  start=time.monotonic();q=s.Popen(argv,stdin=s.DEVNULL,stdout=u,stderr=e);meta['pid']=q.pid
  while q.poll() is None and time.monotonic()-start<15 and b'MUTEX END' not in (p/'uart').read_bytes():time.sleep(.01)
  meta['cause']='guest-exit' if q.poll() is not None else ('footer' if b'MUTEX END' in (p/'uart').read_bytes() else 'timeout')
  if q.poll() is None:q.terminate()
  meta.update(status=q.wait(),elapsed=time.monotonic()-start)
 put(p/'result.json',meta);dst=D/'captures'/p.name;shutil.copytree(p,dst)
 sums={x.name:sha(x) for x in p.iterdir()};assert all(sha(dst/k)==v for k,v in sums.items());put(dst/'seal.json',sums);print(p.name,meta['cause'],flush=True)

