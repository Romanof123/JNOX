from pathlib import Path
import collections,re,json,subprocess as s,sys
D=Path(__file__).parent;S=Path.home()/'qa207fresh';N=2**64-1
ref=(S/'docs/evidence/ordinary-mutex-first/replay.py').read_text();ref=ref[ref.index('for p in sorted'):].replace("sorted(H.glob('0*'))","[position]")
rows=[]
for p in sorted((D/'captures').iterdir()):
 meta=json.loads((p/'result.json').read_text());m=meta['mode'];a=meta['app'];d=D/'images'/(m+'-'+a);dis=(d/'disasm').read_text()
 t=collections.defaultdict(list)
 for line in (p/'uart').read_text().splitlines()[3:-1]:
  k,*v=line.split();t[k].append([int(i,16) for i in v])
 ce,reason,*_=t['H'][0];irq=next(e for e in t['E'] if e[2]==5)
 exec(ref,dict(position=p,collections=collections,re=re,N=N))
 if m!='default':
  r=s.run([sys.executable,str(S/'tools/mutex_anchor_replay.py'),str(p/'uart'),'--app',a,'--anchor',m],capture_output=True,text=True);print(r.stdout,r.stderr);assert r.returncode==int(bool(reason))
 sym={l.split()[-1]:int(l.split()[0],16) for l in (d/'symbols').read_text().splitlines() if len(l.split())==3}
 owner=None;sites=[]
 for l in dis.splitlines():
  if match:=re.match(r'^\w+ <([^>]+)>:',l):owner=match[1]
  if re.search(r'\bbl\s+\w+ <.*10priorities17',l):sites.append((owner,l.strip()))
 assert len(sites)==2 and any('choose' in i for i,l in sites) and any('release' in i for i,l in sites)
 q=[3];own=[N,N];wait=[[],[]]
 for e in t['E']:
  op,j,u,b=e[2:6]
  if op==1:
   if own[j]==N:own[j]=u;q.insert(0,u)
   else:wait[j].append(u)
  if op==2:
   assert own[j]==u;own[j]=N
   if wait[j]:own[j]=wait[j].pop(0);q.append(own[j])
   q.insert(0,u)
  if op==3:q.append(u)
  if op==5:q.insert(0,u);q.extend([2,1])
  pri=[2,5,9,0]
  for j,o in enumerate(own):
   if o!=N:pri[o]=max([pri[o]]+([5+4*j] if ce else [pri[w] for w in wait[j]]))
  assert b==max(q,key=lambda i:pri[i]);q.remove(b)
 if p.name.endswith('traced'):
  vec=[int(i,16) for i in re.findall(r'to EL1 PC 0x(\w+)',(p/'external.log').read_text())];assert vec==[sym['sched_vectors']+(0x280 if e[2]==5 else 0x200) for e in t['E']]
 line=next(l.strip() for l in dis.splitlines() if l.strip().startswith(f'{irq[7]:x}:'));T=t['T'][0];armR=t['R'][1+ce][2]
 print('linked',sites,'pc',line)
 rows.append([p.name,reason,irq[20],irq[21],line,armR-T[2],irq[0]-T[2],t['P'][0] if 'P' in t else [],[e[5] for e in t['E']]])
(D/'observations.json').write_text(json.dumps(rows,indent=2))

