# Merged display and protected safety channel
The first ordinary FIFO arrival-before boot and the three original display-verifier boots ran sequentially against separate packages from the same clean local merge. The four native runs used single-vCPU Cortex-A72 QEMU. Source archive, build and launch logs, unedited UART, terminal safety RAM and real before/after screen dumps are included.

| Identity | Git object |
| --- | --- |
| Local integration | 5fda1eff6baaabfc9b073ea6eb9c8616be6a1214 |
| Source tree | 57587b6a29de92b4dbe43ace89698596f6c1035d |
| First parent, #409 including #410 | 541c25f4a866446ff3b2bd8e6054e6a701b8b071 |
| Second parent, #388 | f8a45a5fed37d6acb76e4e212e049502e96862ba |

In the three conflict regions the merge retains both sets of slot checks in kernel/build.rs, exports both SDK modules in sdk/native-aarch64/rust/src/lib.rs and retains both groups of package validation in tools/build_native_el0.py. The original display and safety package shapes each select their own service.

The ordinary FIFO arrival-before run used the unchanged producer, controller and supervisor arguments, priorities 7/6/4, routes 2:0 and 2:1, loan route 0:1, and standard clock. The original #403 per-boot decoder compared all 167 protected UART records with captured kernel RAM, compared 17 queue observations, and recovered exits 71/72/73. Generation 1 sequence 3 raised the register. Sequence 4 was queued at the expiry deadline and remained queued when the controller checked 4,914 ticks later (78.624 µs). The controller latched the fault and switched the register low during CHECK, and the receiver skipped COMMIT. Final output was zero. The general fixed scheduler journal dropped 229 rows. The retained evidence records a late check in a single run. Exact equality, cadence qualification and hardware timing remain open.

The display build received n and q through PL011. Raw repeated QMP PPMs matched both original 320×240 RGB images, with owner/peer exits 0/61. Device absence produced 19/61. The original demo on the headless kernel returned 38. No guest failed and there were no repeat boots.

After extraction run `bash replay.sh` in this directory. Replay needs Python 3, sha256sum and aarch64-linux-gnu-nm. It verifies the Git commit and source bytes, payload and packages, re-scores the included original UART and RAM, checks the original references, and re-reads feedback from all three display boots. All replay commands are offline. For rebuilding, scripts/run.sh in the private workspace and run.sh here contain the serial first-run commands. source/crossprofile.bundle transfers the merge to a Git repository containing both parents.
