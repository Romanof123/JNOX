"""Replay source identities, the original per-boot #403 score and the observed #406 screens and exits."""
import hashlib
import json
import re
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

root = Path(__file__).resolve().parent
revision = "5fda1eff6baaabfc9b073ea6eb9c8616be6a1214"
parents = ["541c25f4a866446ff3b2bd8e6054e6a701b8b071", "f8a45a5fed37d6acb76e4e212e049502e96862ba"]
tree = "57587b6a29de92b4dbe43ace89698596f6c1035d"

def need(ok, message):
    if not ok:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git_hash(kind, data):
    return hashlib.sha1(kind.encode() + b" " + str(len(data)).encode() + b"\0" + data).hexdigest()

def read_json(path):
    return json.loads(path.read_bytes())

source = root / "source"
for ref in [revision, *parents]:
    data = (source / (ref + ".commit")).read_bytes()
    need(git_hash("commit", data) == ref, "commit identity "+ref)
    if ref == revision:
        lines = data.decode().splitlines()
        need(lines[:3] == ["tree " + tree, *["parent " + p for p in parents]], "ordered merge parents and tree")
prod = source / "production"
files = {}
directories = {}
for item in (source/"ls-tree.z").read_bytes().split(b"\0"):
    if not item:
        continue
    header, raw_path = item.split(b"\t", 1)
    mode, kind, oid = header.decode().split()
    name = raw_path.decode()
    need(kind == "blob", "tracked non-blob " + name)
    parts = name.split("/")
    current = directories
    for part in parts[:-1]:
        current = current.setdefault(part, {})
    current[parts[-1]] = (mode, oid)
    if parts[0] in {"arch","boards","examples","kernel","sdk","services","tools","trace","verification"}:
        files[name] = oid

def tree_hash(entries):
    encoded = []
    for name, value in entries.items():
        if isinstance(value, dict):
            mode, oid, sort_key = "40000",tree_hash(value),name.encode()+b"/"
        else:
            mode, oid = value
            sort_key = name.encode()
        encoded.append((sort_key, mode.encode()+b" "+name.encode()+b"\0"+bytes.fromhex(oid)))
    return git_hash("tree", b"".join(e for _, e in sorted(encoded)))

need(tree_hash(directories) == tree, "complete recursive tree")
for path, oid in files.items():
    need(git_hash("blob", (prod/path).read_bytes()) == oid, "production source "+path)
with tarfile.open(root/"original/packet.tar.xz") as packet:
    need(sha((root/"original/packet.tar.xz").read_bytes()) ==
         "6c55e5e85cb37a372929cbc8c4694f3c1a6f7b683a69fdb1cb8e3a893bdacdb7", "original packet")
    for folder in ("scripts","verification"):
        for local in (root/"original"/folder).iterdir():
            if local.is_file():
                archive_path = folder+"/"+local.name
                need(packet.extractfile(archive_path).read() == local.read_bytes(), "archived reference "+archive_path)
with tempfile.TemporaryDirectory() as temp:
    work = Path(temp)
    for name in ("commit","runs","apps","packages","original"):
        (work/name).symlink_to(root/name)
    subprocess.run([sys.executable,"-B",root/"score-safety.py",work], check=True)
    need((work/"safety-observations.json").read_bytes() == (root/"safety-observations.json").read_bytes(),
         "replayed safety verdict")
qa = root / "display-qa"
observer = read_json(qa/"observer.json")
need(sha((prod/"tools/verify_native_display.py").read_bytes()) == observer["verifier_sha256"],"original display verifier")
for pkg in (root/"packages").iterdir():
    manifest = read_json(pkg/"manifest.json")
    need(manifest["commit"] == revision and not manifest["tracked_changes"],"manifest revision")
    for key, path in (("kernel_elf_sha256","kernel.elf"),("build_log_sha256","build.log")):
        need(sha((pkg/path).read_bytes()) == manifest[key], "frozen "+path)
    for slot in manifest["slots"]:
        need(sha((pkg/slot["elf"]).read_bytes()) == slot["elf_sha256"],"slot ELF")
for mode, exits in (("interaction",[[0,0],[1,61]]),("absent",[[0,19],[1,61]]),("headless",[[None,38]])):
    run = qa/mode
    result = read_json(run/"result.json")
    manifest = read_json(qa/("headless-package" if mode == "headless" else "display-package")/"manifest.json")
    need(manifest["commit"] == revision and not manifest["tracked_changes"] and
         result["kernel_sha256"] == manifest["kernel_elf_sha256"] == read_json(run/"launch.json")["kernel_sha256"],
         "display kernel and commit")
    need(result["pass"] and result["qemu_status"] == 0 and result["mode"] == mode, "receipt "+mode)
    for name, checksum in result["hashes"].items():
        need(sha((run/name).read_bytes()) == checksum,"original display file "+name)
    uart = (run/"uart.bin").read_bytes()
    observed = [[int(pid) if pid else None,int(code)] for pid,code in
                re.findall(rb"(?m)^NATIVE EL0 EXIT (?:PID (\d+) )?(-?\d+)\r?\n",uart)]
    need(b"NATIVE EL0 FAULT " not in uart and observed == result["native_exits"] == exits, "terminal roles "+mode)
    if mode != "interaction":
        need(not result["frames"] and not result["input"], "negative control "+mode)
        continue
    need([entry["byte"] for entry in result["input"]] == ["n","q"], "PL011 input")
    for label, checksum in (("before","b6b84c8c880940249528666b1904def4b8d63f30b509fbc7be1aab9cbbfe7fb1"),
                            ("after","5321a7ef2959b06cd4fa32a8262a9ff0490f0462bd7a788b161229dff7ab76f5")):
        frame = (run/(label+".ppm")).read_bytes()
        need(frame == (run/(label+"-repeat.ppm")).read_bytes(),"stable scanout "+label)
        header = re.match(rb"P6\s+320\s+240\s+255\r?\n", frame)
        need(header and len(frame)-header.end() == 320*240*3 and
             sha(frame[header.end():]) == checksum == result["frames"][label]["rgb_sha256"] and
             result["frames"][label]["stable_seconds"] >= .2,"#406 reference RGB "+label)
print(f"PASS integrated tree {tree}, {len(files)} source blobs, one three-role FIFO safety boot and three display boots")
