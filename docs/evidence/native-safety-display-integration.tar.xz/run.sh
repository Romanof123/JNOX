#!/usr/bin/env bash
# One original FIFO three-role #403 boot, then the #406 display tests, with no guest overlap.
set -euo pipefail
base=$(cd -- "$(dirname -- "$0")/.." && pwd)
repo=${REPO:-"$base/repo"}
out=${1:?"usage: run.sh NEW_OUTPUT_DIR"}
mkdir -- "$out"
out=$(realpath "$out")
exec > >(tee "$out/terminal.log") 2>&1
export PATH="$HOME/.cargo/bin:$PATH" LC_ALL=C TZ=UTC CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1
unset RUSTFLAGS CARGO_TARGET_DIR PYTHONPATH
for key in $(compgen -e JNOX_); do unset "$key"; done
exec 9>"$base/serial.lock"
flock -xn 9
rev=5fda1eff6baaabfc9b073ea6eb9c8616be6a1214
tree=57587b6a29de92b4dbe43ace89698596f6c1035d
parents='541c25f4a866446ff3b2bd8e6054e6a701b8b071 f8a45a5fed37d6acb76e4e212e049502e96862ba'
cd "$repo"
test "$(git rev-parse HEAD)" = "$rev"
test "$(git rev-parse 'HEAD^{tree}')" = "$tree"
test "$(git log -1 --format=%P)" = "$parents"
test -z "$(git status --porcelain --untracked-files=no)"
printf '%s\n' "$rev" > "$out/commit"
printf '%s\n' "$tree" "$parents" > "$out/tree-and-parents"
mkdir -p "$out"/{apps,logs,packages,runs,original}
cp "$base"/scripts/{run.sh,score-safety.py} "$out/"
git show 'f8a45a5f:docs/evidence/native-permit-opening-queue.tar.xz' > "$out/original/packet.tar.xz"
(cd "$out/original"; echo '6c55e5e85cb37a372929cbc8c4694f3c1a6f7b683a69fdb1cb8e3a893bdacdb7  packet.tar.xz' | sha256sum -c -; tar xf packet.tar.xz scripts/cold.py scripts/lane.sh verification/check_native.py verification/check_queue.py verification/raw_capture.py verification/native-observations.json)
{ date -u; uname -srm; rustc -Vv; cargo -V; clang --version; python3 -V; qemu-system-aarch64 --version; sha256sum "$(command -v qemu-system-aarch64)"; } > "$out/logs/host.txt"
for role in sender receiver supervisor; do
    (set -x; sh sdk/native-aarch64/build-rust.sh "examples/native-safety-channel/$role/Cargo.toml" "$out/apps/$role.elf") > "$out/logs/$role.build" 2>&1
done
case_name=arrival-before
pkg="$out/packages/fifo-$case_name"
(set -x; python3 tools/build_native_el0.py --out "$pkg" --board virt --policy fifo \
    --elf "$out/apps/sender.elf" --peer-elf "$out/apps/receiver.elf" --peer-elf "$out/apps/supervisor.elf" \
    --arg "$case_name" --peer-arg "$case_name" --peer2-arg "$case_name" \
    --priority 7 --peer-priority 6 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 \
    --safety-channel --safety-boundary) > "$out/logs/fifo-$case_name.build" 2>&1
run="$out/runs/001-default-fifo-$case_name"
mkdir "$run"
cp "$pkg/manifest.json" "$run/"
date -u +%FT%T.%NZ > "$run/start.utc"
rc=0
(set -x; python3 "$out/original/scripts/cold.py" default "$pkg" "$run/cap" "$rev" "$case_name") > "$run/capture.log" 2>&1 || rc=$?
date -u +%FT%T.%NZ > "$run/finish.utc"
printf '%s\n' "$rc" > "$run/capture.status"
safe_status=$rc
if [[ $safe_status == 0 ]]; then
    python3 "$out/score-safety.py" "$out" > "$out/logs/safety-score.log" 2>&1 || safe_status=$?
    cat "$out/logs/safety-score.log"
fi
echo "ordinary three-role safety status $safe_status"
(set -x; sh sdk/native-aarch64/build-rust.sh examples/native-display/Cargo.toml "$out/apps/display.elf") > "$out/logs/display-app.build" 2>&1
(set -x; python3 tools/build_native_el0.py --out "$out/packages/display" --board virt --policy fifo \
    --elf "$out/apps/display.elf" --peer-elf "$out/apps/display.elf" --peer-arg denied \
    --priority 1 --peer-priority 2 --display-service 0) > "$out/logs/display.build" 2>&1
(set -x; python3 tools/build_native_el0.py --out "$out/packages/headless" --board virt --policy fifo \
    --elf "$out/apps/display.elf" --priority 1) > "$out/logs/headless.build" 2>&1
dstatus=0
(set -x; python3 tools/verify_native_display.py --package "$out/packages/display" --headless-package "$out/packages/headless" --out "$out/display-qa") > "$out/logs/display-qa.log" 2>&1 || dstatus=$?
cat "$out/logs/display-qa.log"
printf 'safety %s\ndisplay %s\n' "$safe_status" "$dstatus" | tee "$out/status"
python3 - "$out" "$rev" <<'PY'
import json, sys
from pathlib import Path
out, rev = Path(sys.argv[1]), sys.argv[2]
for label in ("fifo-arrival-before","display","headless"):
    obj = json.loads((out/"packages"/label/"manifest.json").read_text())
    if obj["commit"] != rev or obj["tracked_changes"]:
        raise ValueError("package commit or tracked changes in "+label)
PY
test "$safe_status" = 0 && test "$dstatus" = 0
