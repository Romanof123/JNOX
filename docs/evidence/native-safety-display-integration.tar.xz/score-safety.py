"""Score one stock three-role boot using the original #403 per-boot reducer."""
import json
import runpy
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
ref = root / "original" / "verification"
sys.path.insert(0, str(ref))
from check_native import DECODER_HASH, need, score, sha

revision, = (root / "commit").read_text().splitlines()
item = dict(attempt="001-default-fifo-arrival-before", package="fifo-arrival-before",
            policy="fifo", case="arrival-before", clock="default", revision=revision)
decoder = ref / "raw_capture.py"
need(sha(decoder.read_bytes()) == DECODER_HASH, "original decoder digest")
row = score(root, item, revision, runpy.run_path(str(decoder)))
(root / "safety-observations.json").write_text(json.dumps(row, indent=2) + "\n")
need(row["prior_output_high"] and row["fall_during_expiry_CHECK"] and row["terminal_output"] == 0,
     "high output followed by measured suppression at the expiry CHECK")
need(row["authority_confirmed_fault_and_seq3"] and row["commit_skipped"] and row["ended_on_seq3"]
     and not row["post_seq3_commit_calls"], "latched fault, previous sequence retained")
need(row["independent_opening_rows_compared"] == 17 and row["kernel_journal_rows_matched_in_RAM"] > 0,
     "matched kernel RAM rows and original opening checks")
print(json.dumps({k:row[k] for k in ("calendar","seq4_at_D","check_minus_D","seq4_directly_queued_at_expiry",
      "kernel_journal_rows_matched_in_RAM","independent_opening_rows_compared","terminal_output","fixed_dropped")}))
