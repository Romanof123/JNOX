#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
sha256sum --quiet -c SHA256SUMS
PYTHONDONTWRITEBYTECODE=1 python3 -B replay.py
