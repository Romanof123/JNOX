"""Capture one fixed-calendar stock QEMU boot, including RAM on a wall timeout."""
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import threading
import time

sys.path.insert(0, str(Path.cwd() / "tools"))
from native_el0_capture import command, symbol_address
from ordinary_amc_capture import save, sha
from qemu_capture import request

mode, package, target, revision, case = sys.argv[1:]
pkg, root = Path(package).resolve(), Path(target).resolve()
manifest = json.loads((pkg / "manifest.json").read_text())
assert mode in {"default", "count0"} and case in {"arrival-before", "arrival-same", "arrival-after"}
assert manifest["commit"] == revision and not manifest["tracked_changes"]
assert len(manifest["slots"]) == 3 and manifest["safety_boundary"]["scenario"] == case
assert all(s["argv"] == ["/bin/app",case] and sha(pkg/s["elf"]) == s["elf_sha256"] for s in manifest["slots"])
assert sha(pkg/"kernel.elf") == manifest["kernel_elf_sha256"]
root.mkdir()
for src, name in [(pkg/"kernel.elf", "kernel.elf"), (pkg/"user.elf","user.elf"),
                  (Path("examples/native-safety-channel/sender/src/main.rs"),"probe.c")]:
    shutil.copyfile(src, root/name)
symbols = subprocess.check_output(["aarch64-linux-gnu-nm","-nS",root/"kernel.elf"],text=True)
base = symbol_address(symbols,"_start")
size = symbol_address(symbols,"__stack_top") - base
assert base == 0x40200000 and 0 < size <= 48 << 20
qemu = Path(shutil.which("qemu-system-aarch64")).resolve(strict=True)
argv = command(str(qemu), root, plain=True)
assert argv[argv.index("-smp")+1] == "1" and "-icount" not in argv
if mode == "count0":
    pos = argv.index("-accel")+1
    assert argv[pos] == "tcg"
    argv[pos:pos+1] = ["tcg,thread=single","-icount","shift=0,align=off,sleep=off"]
save(root/"launch.json",dict(version=1,argv=argv,revision=revision,ram_base=base,ram_bytes=size,
     argument_package=manifest,qemu_sha256=sha(qemu),qemu_version=subprocess.check_output([qemu,"--version"],text=True),
     kernel_sha256=sha(root/"kernel.elf"),user_sha256=sha(root/"user.elf"),probe_sha256=sha(root/"probe.c")))
exits = {}
marker = "unobserved"
started = time.time_ns()
proc = None
try:
    with (root/"stderr").open("xb") as stderr:
        proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,stderr=stderr,bufsize=0)
        timer = threading.Timer(55,proc.kill)
        timer.start()
        try:
            if "QMP" not in json.loads(proc.stdout.readline()):
                raise RuntimeError("missing QMP greeting")
            class Pipe:
                write = proc.stdin.write
                readline = proc.stdout.readline
            stream = Pipe()
            request(stream,"qmp_capabilities")
            deadline = time.monotonic()+40
            while proc.poll() is None:
                uart = root/"uart.bin"
                raw = uart.read_bytes() if uart.exists() else b""
                exits = {int(p):int(v) for p,v in re.findall(rb"(?m)^NATIVE EL0 EXIT PID (\d+) (-?\d+)\r?\n",raw)}
                fault = re.search(rb"(?m)^NATIVE EL0 FAULT (\d+)\r?\n",raw)
                if fault:
                    marker = "FAULT "+fault[1].decode()
                elif set(exits) == {0,1,2}:
                    marker = "EXIT "+str(exits[0])
                elif time.monotonic() >= deadline:
                    marker = "TIMEOUT"
                elif len(raw) > 8 << 20:
                    marker = "UART LIMIT"
                else:
                    time.sleep(0.005)
                    continue
                request(stream,"stop")
                request(stream,"pmemsave",val=base,size=size,filename=str(root/"ram.bin"))
                break
        finally:
            timer.cancel()
            timer.join()
except (ValueError,RuntimeError,OSError) as exc:
    marker = f"{marker}: {exc}"
finally:
    if proc is not None:
        if proc.poll() is None:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
    save(root/"session.json",dict(marker=marker,observed_slot_exits=exits,
         started_unix_ns=started,finished_unix_ns=time.time_ns(),
         pid=proc.pid if proc else None,qemu_returncode=proc.returncode if proc else None,
         hashes={p.name:sha(p) for p in sorted(root.iterdir()) if p.is_file()}))
print(marker,exits,flush=True)
sys.exit(int(exits != {0:71,1:72,2:73} or not (root/"ram.bin").is_file()))
