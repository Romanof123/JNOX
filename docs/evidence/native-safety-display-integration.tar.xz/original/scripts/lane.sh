#!/usr/bin/env bash
set -euo pipefail
lab=${LAB_ROOT:-$HOME/permit11-arrival-runs}
packet="$lab/packet"
shared=$(cd "$(dirname "$0")" && pwd)
rev=$1
tree=$2
public=$3
[[ $rev =~ ^[0-9a-f]{40}$ && $tree =~ ^[0-9a-f]{40}$ && $public =~ ^[0-9a-f]{40}$ ]]
export PATH="$HOME/.cargo/bin:$PATH" LC_ALL=C TZ=UTC CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1
unset RUSTFLAGS CARGO_TARGET_DIR PYTHONPATH
for key in $(compgen -e JNOX_); do unset "$key"; done
mkdir -p "$lab"
exec 9>"$lab/serial.lock"
flock -xn 9
[[ ! -e "$packet" && ! -e "$lab/src" ]]
mkdir -p "$packet"/{scripts,apps,source,packages,runs,logs,verification}
cp "$shared"/{lane.sh,cold.py} "$packet/scripts/"
git init -q "$lab/src"
realpath /mnt/d/codex/.jnox-work/policy-v1/.git/objects > "$lab/src/.git/objects/info/alternates"
cd "$lab/src"
areas=(arch boards examples kernel sdk services tools trace verification)
git sparse-checkout init --cone
git sparse-checkout set "${areas[@]}"
git checkout -q --detach "$rev"
[[ $(git rev-parse HEAD) == "$rev" && $(git rev-parse 'HEAD^{tree}') == "$tree" && -z $(git status --short --untracked-files=no) ]]
[[ $(git rev-parse "$public^{tree}") == "$tree" ]]
git cat-file commit "$rev" > "$packet/source/$rev.commit"
git cat-file commit "$public" > "$packet/source/$public.commit"
printf '%s\n' "$public" "$tree" > "$packet/source/public-revision"
git rev-parse HEAD 'HEAD^{tree}' > "$packet/source/revision"
git ls-tree -r "$rev" > "$packet/source/tree.txt"
git archive --format=tar "$rev" "${areas[@]}" > "$packet/source/production.tar"
{ date -u; uname -srm; rustc -Vv; cargo -V; clang --version; python3 -V; qemu-system-aarch64 --version; sha256sum "$(command -v qemu-system-aarch64)"; git --version; } > "$packet/logs/host.txt"
for role in sender receiver supervisor; do
    (set -x; sh sdk/native-aarch64/build-rust.sh "examples/native-safety-channel/$role/Cargo.toml" "$packet/apps/$role.elf") > "$packet/logs/$role.build" 2>&1
done
(cd "$packet/apps" && sha256sum *.elf) > "$packet/apps/SHA256SUMS"
printf 'n\tclock\tpolicy\tcase\tpackage\tbuild_rc\tcapture_rc\tattempt\trevision\n' > "$packet/ledger.tsv"
for policy in fifo rr; do
    extra=()
    [[ $policy != rr ]] || extra+=(--quantum-ticks 625000)
    for case_name in arrival-before arrival-same arrival-after; do
        pkg="$packet/packages/$policy-$case_name"
        (set -x; python3 tools/build_native_el0.py --out "$pkg" --board virt --policy "$policy" --elf "$packet/apps/sender.elf" --peer-elf "$packet/apps/receiver.elf" --peer-elf "$packet/apps/supervisor.elf" --arg "$case_name" --peer-arg "$case_name" --peer2-arg "$case_name" "${extra[@]}" --priority 7 --peer-priority 6 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel --safety-boundary) > "$packet/logs/$policy-$case_name.build" 2>&1
    done
done
n=0
for clock_mode in default count0; do
    for policy in fifo rr; do
        for case_name in arrival-before arrival-same arrival-after; do
            n=$((n+1))
            package="$policy-$case_name"
            pkg="$packet/packages/$package"
            printf -v attempt '%03d-%s-%s' "$n" "$clock_mode" "$package"
            run="$packet/runs/$attempt"
            mkdir "$run"
            cp "$pkg/manifest.json" "$run/"
            date -u +%FT%T.%NZ > "$run/start.utc"
            caprc=0
            (set -x; python3 "$packet/scripts/cold.py" "$clock_mode" "$pkg" "$run/cap" "$rev" "$case_name") > "$run/capture.log" 2>&1 || caprc=$?
            date -u +%FT%T.%NZ > "$run/finish.utc"
            printf '%s\n' "$caprc" > "$run/capture.status"
            printf '%s\t%s\t%s\t%s\t%s\t0\t%s\t%s\t%s\n' "$n" "$clock_mode" "$policy" "$case_name" "$package" "$caprc" "$attempt" "$rev" >> "$packet/ledger.tsv"
            printf '%s capture=%s\n' "$attempt" "$caprc"
        done
    done
done
