"""Read protected UART and each process's ELF symbols through its own saved TTBR."""
import functools
import hashlib
import json
import re
import struct
import subprocess
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


@functools.lru_cache(maxsize=64)
def symtab(path):
    text = subprocess.check_output(["aarch64-linux-gnu-nm", "-CS", "--defined-only", str(path)], text=True)
    result = {}
    for line in text.splitlines():
        fields = line.split(None, 3)
        if len(fields) == 4:
            result[fields[3]] = tuple(int(v, 16) for v in fields[:2])
    return result


def grouped(values, width):
    if len(values) % width:
        raise ValueError("incomplete row")
    return [values[i:i+width] for i in range(0, len(values), width)]


def read_run(root, run):
    policy = case = None
    cap = run / "cap"
    receipt = json.loads((cap / "session.json").read_text())
    launch = json.loads((cap / "launch.json").read_text())
    manifest = json.loads((run / "manifest.json").read_text()) if (run / "manifest.json").exists() else launch["argument_package"]
    lines = (cap / "uart.bin").read_text().splitlines()
    def rows(tag):
        return [list(map(int, line[len(tag)+1:].split())) for line in lines if line.startswith(tag+" ")]
    elf = cap / "kernel.elf"
    apps = [root / "apps" / (n + ".elf") for n in ("sender", "receiver", "supervisor")]
    symbols = symtab(elf)
    base, size = symbols["jnox_kernel::native_el0_mmu::SPACES"]
    if size % (4096*3) or base % 4096:
        raise ValueError("unexpected address-space array")
    roots = [base + pid * (size // 3) for pid in range(3)]
    ram = (cap / "ram.bin").read_bytes()
    def physical(pa, count):
        i = pa - launch["ram_base"]
        if not 0 <= i <= len(ram)-count:
            raise ValueError("physical address outside dump")
        return ram[i:i+count]
    def data(pid, name):
        va, length = symtab(apps[pid])["safety_"+name]
        data = bytearray()
        while len(data) < length:
            cur = va + len(data)
            page = roots[pid]
            for shift in (30,21,12):
                descriptor = int.from_bytes(physical(page+8*((cur>>shift)&511),8), "little")
                if descriptor & 3 != 3:
                    raise ValueError("unmapped private data " + name)
                page = descriptor & 0x0000fffffffff000
            offset = cur % 4096
            data.extend(physical(page+offset, min(length-len(data),4096-offset)))
        return bytes(data)
    def words(pid,name):
        return [v[0] for v in struct.iter_unpack("<Q",data(pid,name))]
    result = dict(policy=policy, case=case, revision=launch["revision"], marker=receipt["marker"],
                  session_hash=digest(cap/"session.json"), roots=roots, kernel=digest(elf), qemu=launch["qemu_sha256"],
                  app_hashes=[digest(p) for p in apps], exits=rows("NATIVE EL0 EXIT PID"),
                  safety_loss=rows("NATIVE SAFETY DROPPED"), fixed_loss=rows("NATIVE FIXED DROPPED"),
                  events=rows("NATIVE SAFETY EVENT"),terminal=int.from_bytes(physical(symbols["jnox_virtual_permit_enable"][0],8),"little"))

    if any(Path(n).name != n or digest(cap/n) != h for n,h in receipt["hashes"].items()):
        raise ValueError("capture file hash")
    required = {"ram.bin", "uart.bin", "kernel.elf", "launch.json"}
    if not required.issubset(receipt["hashes"]):
        raise ValueError("capture hash coverage")
    if result["app_hashes"] != [slot["elf_sha256"] for slot in manifest["slots"]] or manifest != launch["argument_package"]:
        raise ValueError("packaged ELF mismatch")
    for pid, name, count, width in ((0,"sender_rows","sender",11),(1,"received_rows","received",20),(2,"supervisor_rows","supervisor",16)):
        n = words(pid,count+"_count")[0]
        rows_data = grouped(words(pid,name),width)
        if n > len(rows_data):
            raise ValueError("private row count")
        result[name] = rows_data[:n]
        if pid < 2:
            result[count+"_bytes"] = [bytes(v) for v in grouped(data(pid,count+"_bytes"),44)[:n]]
    result["ack"] = words(1,"active_ack")
    result["ipc"] = grouped(words(2,"active_ipc"),4)
    result["epoch"] = words(1,"receiver_header")[2]
    result["launch_args"] = launch["argv"]
    result["roles"] = [slot["argv"] for slot in manifest["slots"]]
    result["policy"] = manifest["policy"]
    return result


