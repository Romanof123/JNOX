"""Read only the frozen #401 evidence packet. Requires Linux, Git and AArch64 GNU nm."""
import argparse
import hashlib
import json
import runpy
import struct
import subprocess
import sys
import zlib
from pathlib import Path


LOCAL = "aa8e7e104033a372eed0675f3b76f7fb9af2a38e"
PUBLIC = "e84ad6ce6543bad37e1e5254f7a9864c838eafd3"
TREE = "2491425ca0abfe0a5d2d044bd94eb54f4c282d13"
RECEIPTS = "f92c25631bc52330bf1848f9929e5901c55300a1eb6af44f02a128fb90acd795"
PAGE_MASK = 0x0000FFFFFFFFF000
EMPTY = (-11) % 2**64
SKIPPED = 1 << 63


def need(condition, message):
    if not condition:
        raise ValueError(message)


def one(items):
    value, = items
    return value


def sha(data):
    return hashlib.sha256(data).hexdigest()


def private_words(ram, base, root, symbol, index, width):
    va, size = symbol
    start = 8 * width * index
    need(start >= 0 and start + 8 * width <= size, "private row index")
    data = bytearray()
    while len(data) < 8 * width:
        address = va + start + len(data)
        page = root
        for shift in (30, 21, 12):
            offset = page - base + 8 * ((address >> shift) & 511)
            need(0 <= offset <= len(ram)-8, "private page table outside dump")
            entry, = struct.unpack_from("<Q", ram, offset)
            need(entry & 3 == 3, "private page descriptor")
            page = entry & PAGE_MASK
        offset = page - base + address % 4096
        length = min(8 * width - len(data), 4096 - address % 4096)
        need(0 <= offset <= len(ram)-length, "private page outside dump")
        data.extend(ram[offset:offset+length])
    return list(struct.unpack(f"<{width}Q", data))


def backing_page(cap, ram, base):
    lines = (cap / "uart.bin").read_text().splitlines()
    def rows(tag):
        return [list(map(int, line[len(tag):].split())) for line in lines if line.startswith(tag)]
    maps = rows("NATIVE LOAN MAP ")
    need(len(maps) == 16 and rows("NATIVE LOAN STATE ") == [[4,4,0,1,0,0,16,0]], "terminal ring")
    need(rows("NATIVE LOAN PAGE ") == [[slot,0,0,0] for slot in range(3)], "terminal pages")
    for i in range(0, 16, 4):
        w, p, r, f = maps[i:i+4]
        writer, reader = w[7], r[8]
        need(writer & 0xC3 == 0x43 and reader == writer | 0x80, "same backing RW -> RO")
        need(w == [1,0,0,0,0,0,0,writer,0,0] and p == [2,0,0,44,writer,0,0,0,0,0] and
             r == [3,1,0,0,0,0,0,0,reader,0] and f == [4,1,0,0,0,reader,0,0,0,0], "mapping chain")
    address = writer & PAGE_MASK
    offset = address - base
    need(0 <= offset <= len(ram)-4096 and ram[offset+44:offset+4096] == bytes(4052), "physical page tail")
    return address, ram[offset:offset+44]


def examine(root, run, decoder):
    a = decoder["read_run"](root, run)
    ev = a["events"]
    def events(kind):
        return [e for e in ev if e[0] == kind]
    def prior(x, y):
        return ev.index(x) < ev.index(y)
    need(a["revision"] == LOCAL and a["safety_loss"] == [[0]] and all(len(e)==10 for e in ev) and
         all(x[1] <= y[1] for x,y in zip(ev,ev[1:])), "lossless ordered safety journal")
    hz = one(events(1))[2]
    need(hz == 62_500_000 and a["exits"] == [[0,71],[1,72],[2,73]], "clock and exits")
    cap = run / "cap"
    ram = (cap / "ram.bin").read_bytes()
    base = json.loads((cap / "launch.json").read_text())["ram_base"]
    pa, physical = backing_page(cap, ram, base)
    symbols = decoder["symtab"](root / "apps/receiver.elf")
    def activation(i):
        return private_words(ram,base,a["roots"][1],symbols["safety_activations"],i,19)
    need(private_words(ram,base,a["roots"][1],symbols["safety_activation_count"],0,1)==[17], "activation count")

    # Match all ring transitions, including occupancy on unsuccessful empty receives.
    fifo = []
    cycle = []
    for e in events(6):
        pid, op, status, actual, arg, out, length, generation = e[2:]
        need(generation == 1, "loan generation")
        if status:
            need([pid,op,status,out,length]==[1,35,EMPTY,0,0] and not fifo, "failed loan")
        else:
            if op == 34:
                need(pid == 0 and not fifo, "FIFO publication")
                fifo.append(arg)
            elif op == 35:
                need(pid == 1 and len(fifo)==1 and fifo.pop()==out and length==44, "FIFO consumption")
            cycle.append((pid, op, out if op in (33,35) else arg))
        need(actual == len(fifo), "post-operation occupancy")
    handles = [4,8,12,16]
    need(cycle == [(pid,op,h) for h in handles for pid,op in ((0,33),(0,34),(1,35),(1,36))], "grant history")
    need(len(events(7))==4 and [e[2] for e in events(7)]==handles, "four protected snapshots")
    need(len(events(11))==4 and [e[4] for e in events(11)]==handles, "four publication brackets")
    pub = events(11)[-1]
    enqueue = one(e for e in events(6) if e[2:5]==[0,34,0] and e[6]==16)
    snap = events(7)[-1]
    recv = one(e for e in events(6) if e[2:5]==[1,35,0] and e[7]==16)
    release = one(e for e in events(6) if e[2:5]==[1,36,0] and e[6]==16)
    need(prior(pub,enqueue) and prior(enqueue,snap) and prior(snap,recv) and prior(recv,release), "handoff order")
    need(not any(e[0] in (4,8,14) or (e[0]==5 and e[3:5]==[59,1] and e[5]==0)
                 for e in ev[ev.index(events(11)[0]):ev.index(release)]), "invalidation/injection during history")
    wire = b"".join(v.to_bytes(8,"little") for v in snap[4:])[:44]
    old_row, row = a["received_rows"][2:]
    old = old_row[17]
    d = old + hz//50
    need([r[2] for r in a["received_rows"]]==handles and old_row[5:7]==[0,0] and
         old_row[9:12]==[1,3,3] and old_row[16:]==[3,old,1,2], "accepted seq3")
    crc, = struct.unpack("<I", wire[40:])
    issue = struct.unpack_from("<Q",wire,24)[0]
    need(wire[:40]==struct.pack("<BBHHHQQQIB3x",1,1,44,1,257,1,4,issue,20,1) and snap[3]==1 and
         crc==zlib.crc32(wire[:40]) and issue == a["epoch"]+39*hz//1000 and old<issue<=d<issue+hz//50, "fresh seq4")
    stage, send = a["sender_rows"][-2:]
    need(stage[3:]==[1,0,1,4,issue,16,0,0] and send[3:]==[2,0,1,4,issue,16,0,0] and
         old_row[8]<stage[1]<=stage[2]<d and stage[2]<=send[1]<=pub[2]<=pub[3]<=send[2] and
         pub[5:]==[0,1,1,4,issue] and issue<=pub[2] and
         a["sender_bytes"][-2:]==[wire,wire] and a["received_bytes"][-1]==wire==physical, "same fully staged frame")
    ack = a["ack"]
    need(ack[:9]==[0x6c617374,3,0,1,3,old,1,1,0] and ack[10:]==[1,3,3,old] and
         old_row[8]<=ack[9]<stage[1] and any(r[7:]==[3,3,1,1,3,3,old,old,1] and r[2]<stage[1]
                                             for r in a["supervisor_rows"]), "controller and authority prior readback")

    expiry = one(events(3))
    c = expiry[2]
    check = one(e for e in events(12) if e[2:]==[c,1,1,3,old,0,1,1])
    status = ev[ev.index(check)+1]
    need(expiry[3:6]==[1,3,old] and status[0]==5 and status[2:]==[1,60,1,0,1,3,old,2], "protected CHECK")
    commits = [e for e in events(5) if e[3:5]==[60,2]]
    need([e[2:8] for e in commits]==[[1,60,2,0,1,n] for n in (1,2,3)] and
         commits[-1][8]==old and commits[-1][1]<stage[1], "all COMMIT statuses, including failures")
    rise, fall = events(2)
    need(rise[4:6]==[0,1] and fall[4:6]==[1,0] and rise[3]<ack[9]<d<c<fall[2]<=fall[3] and
         prior(expiry,fall) and prior(fall,check) and prior(status,snap) and a["terminal"]==0, "output history")
    need(all(any(r[0]==a["epoch"]+ms*hz//1000 and r[7:]==[5,5,1,1,3,3,old,old,1]
                 for r in a["supervisor_rows"]) for ms in (48,65)), "post-expiry authority")
    prev, first, receipt = activation(7), activation(8), activation(row[0])
    need(prev[3]<d and prev[11:]==[3,3,old,3,old,2,1,0] and first[0]==d and first[1]<=c<status[1]<=first[2]
         and first[4:7]==[1,5,1] and first[11:]==[5,3,old,3,old,2,0,1], "protected and private expiry")
    need(row[0] in (8,9) and row[1:3]==[0,16] and row[4:7]==[44,17,SKIPPED] and
         row[9:]==[1,5,3,3,old,1,2,3,old,1,2] and
         first[2]<=receipt[2]<snap[1]<=recv[1]<=release[1]<row[7]<=row[8]<=receipt[3], "private decision order")
    passed = []
    for tick in (d,c):
        need(pub[3]<tick or tick<pub[2], "publication overlaps target tick")
        queued = pub[3]<tick
        if queued:
            need(prior(enqueue,expiry) and not any(e[0]==6 and e[3]==35 for e in ev[ev.index(enqueue)+1:ev.index(status)]),
                 "intermediate receive")
        passed.append(queued)
    need(row[0]==(8 if passed[1] else 9), "receipt activation and queue classification")
    return dict(run=run.name, receipt_sha256=a["session_hash"], kernel_sha256=a["kernel"], D=d, C=c,
                stage_end_minus_D=stage[2]-d, publication_minus_D=[t-d for t in pub[2:4]],
                seq4_queued_at_D=passed[0], seq4_queued_at_C=passed[1], check_minus_D=c-d,
                output_fall_minus_C=[t-c for t in fall[2:4]], private_expiry_operand_minus_C=first[2]-c,
                private_receipt_activation=row[0], receive_snapshot_minus_C=snap[1]-c,
                private_decision_minus_C=row[7]-c, backing_page=hex(pa), frame_crc32=f"{crc:08x}",
                fixed_journal_dropped=one(a["fixed_loss"])[0])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("packet", type=Path)
    root = p.parse_args().packet.resolve()
    paths = {"scripts/provenance.py":"cd38b57f4c91183afdc950f39aca2148194cddd60afc649bb1cd53b83dc856a0",
             "verification/capture.py":"dc0bda0e0c008c4fc702d1b5b988aac8e1a5a1ec3a7bce9236e792ac4a5e7e2f",
             "source/production.tar":"5958e5a32c50372ed400e81a9fdbcd1d6cf8e1f872a6030214ba094d9cbb871c"}
    need(all(sha((root/path).read_bytes())==digest for path,digest in paths.items()), "source/decoder identities")
    need((root/"source/revision").read_text().splitlines()==[LOCAL,TREE] and
         (root/"source/public-revision").read_text().splitlines()==[PUBLIC,TREE], "source identities")
    subprocess.run([sys.executable,"-B",str(root/"scripts/provenance.py"),str(root)],check=True, stdout=sys.stderr)
    runs = sorted((root/"runs").iterdir())
    need(len(runs)==12 and sha(b"".join((r/"cap/session.json").read_bytes() for r in runs))==RECEIPTS, "original twelve receipts")
    decoder = runpy.run_path(str(root/"verification/capture.py"))
    rows = []
    for run in runs:
        try:
            rows.append(examine(root,run,decoder))
        except (ValueError, IndexError, KeyError) as err:
            raise ValueError(f"{run.name}: {err}") from err
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
