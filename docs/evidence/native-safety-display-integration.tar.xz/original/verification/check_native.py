"""Score real queue observations from the revised native arrival lane, without starting a guest."""
import argparse
import csv
import json
import re
import runpy
import struct
import sys
import zlib
from pathlib import Path

from check_queue import backing_page, need, one, private_words, sha, SKIPPED


HERE = Path(__file__).resolve().parent
DECODER_HASH = "dc0bda0e0c008c4fc702d1b5b988aac8e1a5a1ec3a7bce9236e792ac4a5e7e2f"


def opening_heads(events):
    """Match every observer to an independent FIFO replay of completed loan operations."""
    fifo = []
    openings = []
    need(len([e for e in events if e[0]==17])==len([e for e in events if e[0]==12 and e[3]==1]),
         "number of queue snapshots and opening CHECKs")
    for i, e in enumerate(events):
        if e[0] == 6:
            pid, op, status, occupancy, handle, result, length, _ = e[2:]
            if status==0 and op==34:
                need(pid==0, "publisher")
                fifo.append((handle,result))
            elif status==0 and op==35:
                need(pid==1 and fifo and fifo.pop(0)==(result,length), "returned FIFO handle and length")
            need(occupancy==len(fifo), "recorded post-loan occupancy")
        elif e[0]==8 or (e[0]==5 and e[2:6] in ([2,59,1,0],[2,59,3,0])):
            fifo.clear()
        elif e[0]==17:
            previous, following = events[i-1], events[i+1]
            c, generation, sequence, count, handle, length, active, flags = e[2:]
            need(previous[0]==12 and previous[2:6]==[c,1,generation,sequence] and
                 following[0]==5 and following[2:8]==[1,60,1,0,generation,sequence] and
                 following[8]==previous[6], "same masked PID1 opening CHECK")
            need(count==len(fifo) and (handle,length)==(fifo[0] if fifo else (0,0)), "sample vs FIFO reconstruction")
            need(active==1 and flags==previous[9] | (previous[8]<<1), "opening flags")
            openings.append(dict(operand=c,journal_tick=e[1],generation=generation,old_sequence=sequence,
                                 old_issue=previous[6],old_fault=previous[7],new_fault=previous[8],gate=previous[9],
                                 occupancy=count,handle=handle,length=length,active_after=active,flags=flags))
    return openings


def classify_at_d(d, pub, receive_lower, receive_upper):
    if d < pub[2]:
        return "unpublished"
    if pub[3] >= d:
        return "publication-overlaps-D"
    if d < receive_lower:
        return "queued"
    if d > receive_upper:
        return "already-consumed"
    return "receive-overlaps-D"


def check_kernel_journal(ram, base, symbols, events):
    def memory(name):
        marker = f"6safety{len(name)}{name}17h"
        address, size = one(v for k,v in symbols.items() if marker in k or k.endswith(f"::safety::{name}"))
        offset = address - base
        need(0 <= offset <= len(ram)-size, "linked journal outside retained RAM")
        return ram[offset:offset+size]
    used, = struct.unpack("<Q", memory("USED"))
    dropped, = struct.unpack("<Q", memory("DROPPED"))
    data = memory("LOG")
    need(used==len(events) and dropped==0 and len(data)>=used*80, "retained kernel journal count")
    need([list(row) for row in struct.iter_unpack("<10Q",data[:used*80])]==events, "UART vs linked kernel RAM journal")


def score(root, item, rev, decoder):
    run = root/"runs"/item["attempt"]
    cap = run/"cap"
    launch = json.loads((cap/"launch.json").read_text())
    package = root/"packages"/item["package"]
    manifest = json.loads((package/"manifest.json").read_text())
    case = item["case"]
    need(manifest==launch["argument_package"] and manifest["commit"]==rev==launch["revision"]==item["revision"]
         and not manifest["tracked_changes"] and manifest["safety_boundary"]=={
             "scenario":case,"decision_event":12,"opening_queue_event":17,"opening_queue_schema":1} and
         manifest["loan_route"]=={"producer":0,"consumer":1} and manifest["policy"]==item["policy"] and
         not manifest.get("safety_watchdog") and not manifest.get("safety_qualification"), "native package identity")
    need(all(s["argv"]==["/bin/app",case] and s["elf_sha256"]==sha((package/s["elf"]).read_bytes())
             for s in manifest["slots"]) and sha((package/"kernel.elf").read_bytes())==launch["kernel_sha256"],
         "packaged executables and frozen role arguments")
    argv = launch["argv"]
    clock_args = ["tcg"] if item["clock"]=="default" else ["tcg,thread=single","-icount","shift=0,align=off,sleep=off"]
    need(argv[1:-4]==["-machine","virt,gic-version=2","-cpu","cortex-a72","-smp","1","-accel",*clock_args,
                        "-m","128M","-nodefaults","-display","none","-monitor","none","-no-reboot","-qmp","stdio"]
         and argv[-4::2]==["-serial","-kernel"], "stock launch")
    a = decoder["read_run"](root,run)
    ev = a["events"]
    need(a["exits"]==[[0,71],[1,72],[2,73]] and a["safety_loss"]==[[0]] and a["kernel"]==launch["kernel_sha256"]
         and all(len(e)==10 for e in ev) and all(x[1]<=y[1] for x,y in zip(ev,ev[1:])), "complete authenticated records")
    heads = opening_heads(ev)
    hz = one(e for e in ev if e[0]==1)[2]
    need(hz==62_500_000, "counter frequency")
    pubs = [e for e in ev if e[0]==11 and e[5]==0]
    need([e[8] for e in pubs]==[1,2,3,4] and len(a["received_rows"])==4 and len(heads)==17,
         "observed fixed workload")
    prev,pub = pubs[-2:]
    handle, issue = pub[4],pub[9]
    old = prev[9]
    d = old+hz//50
    previous_row = one(r for r in a["received_rows"] if r[2]==prev[4])
    idx = one(i for i,r in enumerate(a["received_rows"]) if r[2]==handle)
    row = a["received_rows"][idx]
    snapshot = one(e for e in ev if e[0]==7 and e[2]==handle)
    release = one(e for e in ev if e[0]==6 and e[2:5]==[1,36,0] and e[6]==handle)
    wire = b"".join(v.to_bytes(8,"little") for v in snapshot[4:])[:44]
    ram = (cap/"ram.bin").read_bytes()
    base = launch["ram_base"]
    check_kernel_journal(ram,base,decoder["symtab"](cap/"kernel.elf"),ev)
    pa, physical = backing_page(cap,ram,base)
    sym = decoder["symtab"](root/"apps/receiver.elf")["safety_activations"]
    def activation(i):
        return private_words(ram,base,a["roots"][1],sym,i,19)
    receipt = activation(row[0])
    need(row[1]==0 and receipt[2]<=snapshot[1]<=release[1]<=row[7]<=row[8]<=receipt[3], "dequeue and private decision bounds")
    stage,send = a["sender_rows"][-2:]
    need(stage[3:]==[1,0,1,4,issue,handle,0,0] and send[3:]==[2,0,1,4,issue,handle,0,0] and
         stage[2]<=pub[2]<=pub[3] and a["sender_bytes"][-2:]==[wire,wire] and a["received_bytes"][idx]==wire==physical and
         wire[:40]==struct.pack("<BBHHHQQQIB3x",1,1,44,1,257,1,4,issue,20,1) and
         int.from_bytes(wire[40:],"little")==zlib.crc32(wire[:40]), "complete CRC-valid wire and physical backing")
    ack = a["ack"]
    need(previous_row[5:7]==[0,0] and previous_row[9:12]==[1,3,3] and previous_row[16:]==[3,old,1,2] and
         ack[:9]==[0x6c617374,3,0,1,3,old,1,1,0] and ack[10:]==[1,3,3,old] and
         ack[9]<stage[1] and any(r[7:]==[3,3,1,1,3,3,old,old,1] and r[2]<stage[1] for r in a["supervisor_rows"]),
         "prior accepted seq3 and high readback")
    need(old<issue<=d<issue+hz//50 and pub[6:]==[1,1,4,issue] and issue<=pub[2], "fresh issued next permit")
    at_d = classify_at_d(d,pub,receipt[2],snapshot[1])
    expiry = [h for h in heads if (h["old_sequence"],h["old_issue"],h["old_fault"],h["new_fault"])==(3,old,0,1)]
    need(len(expiry)<=1, "unique protected opening seq3 expiry")
    h = expiry[0] if expiry else None
    c = h["operand"] if h else None
    result = dict(run=run.name,clock=item["clock"],policy=item["policy"],calendar=case,
                  revision=rev,receipt_sha256=a["session_hash"],kernel_sha256=a["kernel"],qemu_sha256=a["qemu"],
                  frame_handle=handle,frame_length=len(wire),physical_backing=hex(pa),issue=issue,D=d,
                  publication_minus_D=[t-d for t in pub[2:4]],seq4_at_D=at_d,check_minus_D=c-d if h else None,
                  expiry_opening=h,seq4_directly_queued_at_expiry=(h["handle"]==handle and h["length"]==44) if h else None,
                  prior_output_high=True,receiver_activation=row[0],receiver_decision_status=row[5],commit_skipped=row[6]==SKIPPED,
                  receiver_decision_minus_C=row[7]-c if h else None,ended_on_seq3=row[16:18]==[3,old],
                  independent_opening_rows_compared=len(heads),kernel_journal_rows_matched_in_RAM=len(ev),
                  terminal_output=a["terminal"],fixed_dropped=one(a["fixed_loss"])[0])
    result["post_seq3_commit_calls"] = [e[2:] for e in ev if e[0]==5 and e[3:5]==[60,2] and e[1]>previous_row[8]]
    result["output_transitions"] = [dict(before=e[4],after=e[5],store_bounds=e[2:4]) for e in ev if e[0]==2]
    if h:
        k = heads.index(h)
        private = activation(k)
        need(private[2]>=h["journal_tick"],"private expiry operand follows protected queue observation")
        result.update(private_expiry_operand_minus_C=private[2]-c,private_entry_newly_expired=bool(private[6]))
    supervisors = a["supervisor_rows"][-2:]
    result["authority_post_expiry_flags"] = [r[8] for r in supervisors]
    result["authority_confirmed_fault_and_seq3"] = bool(h) and all(
        r[0]==a["epoch"]+ms*hz//1000 and c<=r[1]<=r[2] and r[7:]==[5,5,1,1,3,3,old,old,1]
        for r,ms in zip(supervisors,(48,65)))
    if h:
        target = one(e for e in ev if e[0]==17 and e[1:4]==[h["journal_tick"],c,1])
        fault = one(e for e in ev if e[0]==3 and e[2:6]==[c,1,3,old])
        falls = [e for e in ev if e[0]==2 and e[4:6]==[1,0]]
        rises = [e for e in ev if e[0]==2 and e[4:6]==[0,1]]
        need(len(rises)==len(falls)==1 and rises[0][3]<ack[9], "seq3 prior physical rise")
        fall = falls[0]
        result["fall_during_expiry_CHECK"] = (ev.index(fault)<ev.index(fall)<ev.index(target)-1 and
                                               c<=fall[2]<=fall[3]<=h["journal_tick"])
        result["fall_store_minus_C"] = [t-c for t in fall[2:4]]
    completions = [e for e in ev if e[0]==10]
    need(len(completions)==len(heads) and all(e[2]<=e[3] for e in completions), "complete activation coverage")
    gaps = [(b[2]-a[3],b[3]-a[2]) for a,b in zip(completions,completions[1:])]
    result["largest_intercompletion_gap_bounds"] = [max(g[i] for g in gaps) for i in (0,1)]
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("packet",type=Path)
    p.add_argument("revision")
    args = p.parse_args()
    root = args.packet.resolve()
    need(re.fullmatch("[0-9a-f]{40}",args.revision) and (root/"source/revision").read_text().splitlines()[0]==args.revision,
         "expected freeze")
    with (root/"ledger.tsv").open() as f:
        ledger = list(csv.DictReader(f,delimiter="\t"))
    matrix = [(clock,policy,"arrival-"+case) for clock in ("default","count0") for policy in ("fifo","rr") for case in ("before","same","after")]
    need([(e["clock"],e["policy"],e["case"]) for e in ledger] in (matrix,matrix[:6]),"ordinary-only or both complete clock matrices")
    path = HERE/"raw_capture.py"
    need(sha(path.read_bytes())==DECODER_HASH,"raw memory decoder")
    decoder = runpy.run_path(str(path))
    rows = []
    for entry in ledger:
        try:
            need(entry["build_rc"]==entry["capture_rc"]=="0","original run status")
            rows.append(score(root,entry,args.revision,decoder))
        except (ValueError,IndexError,KeyError,OSError) as exc:
            rows.append(dict(run=entry["attempt"],unscored=str(exc)))
    print(json.dumps(rows,indent=2))
    return int(any("unscored" in r for r in rows))


if __name__=="__main__":
    sys.exit(main())
