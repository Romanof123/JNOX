set -eu
d=/home/ywcho/iv379-73052d1
out=/mnt/d/codex/.jnox-work/next-fixed/379-verifier-73052d1
prior=/home/ywcho/iv379-9271a68/raw
cd "$d"
cp "$out/README.en-ko.md" "$out/seal.sh" raw/
git -C src archive --format=tar.gz --output="$d/raw/sources.tar.gz" HEAD arch boards examples kernel sdk tools trace .gitattributes
git --git-dir=/mnt/d/codex/j-nox/.git show 4637f54cafdbcf417a7efdffc9691e931b7f5b95:docs/native-pipe-ipc.en-ko.md >raw/contract.en-ko.md
git --git-dir=/mnt/d/codex/j-nox/.git show --no-ext-diff --format=fuller 73052d1 >raw/source-correction.patch
git -C src status --short >raw/post-run.status
cp src/examples/native-pipes/writer-rust/Cargo.lock raw/generated-writer-Cargo.lock
mkdir raw/previous
cp "$prior/sdk-shell.log" "$prior/sdk-shell.argv.json" "$prior/package-shell-a-fifo.log" "$prior/README.en-ko.md" raw/previous/
cp "$out/../379-verifier-9271a68/379-9271a68-first.tar.gz.sha256" raw/previous/
for app in writer writer-rust; do aarch64-linux-gnu-objdump -d "raw/$app.elf" >"raw/$app.objdump"; done
{ qemu-system-aarch64 --version; clang --version; ld.lld --version; /home/ywcho/.cargo/bin/rustc -vV; /home/ywcho/.cargo/bin/cargo --version; python3 --version; wc --version; aarch64-linux-gnu-nm --version; uname -a; sha256sum "$(command -v qemu-system-aarch64)"; } >raw/provenance.txt
cd raw
python3 -B replay.py > "$d/replay-before-seal.json"
cmp "$d/replay-before-seal.json" report.json
find . -path '*/target' -prune -o -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum >SHA256SUMS
sha256sum -c SHA256SUMS >"$d/seal-verify.log"
tar --exclude='*/target' -czf "$d/379-73052d1-first.tar.gz" .
cp "$d/379-73052d1-first.tar.gz" "$out/"
cp report.json "$out/"
cd "$out"
sha256sum 379-73052d1-first.tar.gz >379-73052d1-first.tar.gz.sha256
mkdir "$d/replay-fresh"
tar -xzf 379-73052d1-first.tar.gz -C "$d/replay-fresh"
cd "$d/replay-fresh"
sha256sum -c SHA256SUMS >"$d/unpacked-verify.log"
python3 -B replay.py >"$d/unpacked-result.json"
cmp report.json "$d/unpacked-result.json"
wc -l SHA256SUMS
cat "$out/379-73052d1-first.tar.gz.sha256"
ls -lh "$out/379-73052d1-first.tar.gz"
