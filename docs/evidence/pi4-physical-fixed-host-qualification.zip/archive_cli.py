import sys, os, json, hashlib, subprocess, io, zipfile, base64
from pathlib import Path
from fixtures import *
root=Path(__file__).resolve().parent
base=root.parent
repo=base/'pi4-physical-merged-pinned'
doc=repo/'docs/evidence'
hist=base.parent/'batch-bd72722993'
out=root/sys.argv[1]
out.mkdir()
J=lambda p: json.loads(p.read_bytes())
H=lambda b: hashlib.sha256(b).hexdigest()
def put(p,v): p.write_text(json.dumps(v,indent=2)+'\n')
a,b,c,d=[J(doc/f) for f in ('evd-031-raw.json','evd-031.json','evd-014.json','evd-014-package.json')]
data=base64.b64decode(a['data'],validate=True)
assert H(data)==a['sha256']
z=zipfile.ZipFile(io.BytesIO(data))
assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(a['entry_sha256'])
for n in z.namelist(): assert H(z.read(n))==a['entry_sha256'][n],n
for n,h in c['raw_sha256'].items(): assert H((hist/'pi-irq-raw'/n).read_bytes())==h,n
pkg={}
for name in ('fifo','rr','scheduler'):
    fixed=name!='scheduler'
    pp=b['packages'][name] if fixed else d
    boot=base/('pi4-fixed-'+name)/'boot' if fixed else hist/'pi-irq-sd'
    elf=(boot.parent/'target' if fixed else hist/'pi-irq-target')/'aarch64-unknown-none/release/jnox-kernel'
    manifest=(boot/'SHA256SUMS').read_bytes()
    files={n:h for h,n in (line.split('  ') for line in manifest.decode().splitlines())}
    assert all(H((boot/n).read_bytes())==h for n,h in files.items())
    assert all(files[n]==h for n,h in b['firmware_manifest']['files'].items())
    if fixed:
        assert manifest.decode()==pp['staged_manifest'] and H(manifest)==pp['staged_manifest_sha256']
    else:
        assert files==pp['scheduler_sd_manifest']
    assert H(elf.read_bytes())==pp['elf_sha256' if fixed else 'scheduler_elf_sha256']
    assert files['kernel8.img']==pp['kernel8_img_sha256' if fixed else 'scheduler_raw_sha256']
    if not fixed: assert c['image_sha256']==files['kernel8.img'] and c['elf_sha256']==H(elf.read_bytes())
    record=dict(profile='pi4-fixed-'+name if fixed else 'pi4-scheduler',revision=b['revision'] if fixed else d['source'],build_options={'board':'pi4','profile':'fixed','app':'fixed-'+name} if fixed else {'board':'pi4','profile':'scheduler'},elf_sha256=H(elf.read_bytes()),files_sha256=files,firmware_commit=b['firmware_manifest']['commit'],package_manifest_sha256=H(manifest))
    put(out/(name+'-record.json'),record)
    sources=[]
    for i in (1,2):
        raw=z.read(f'pi4-fresh/{name}/run-{i}/uart') if fixed else bytes.fromhex(c['uart_hex'])
        assert raw=={'fifo':FIFO,'rr':RR_A,'scheduler':SCHED}[name]
        if not fixed: assert H(raw)==c['raw_sha256']['uart.bin']
        f=out/f'{name}-original-{i}.bin';f.write_bytes(raw);sources.append(f)
    pkg[name]=(boot,elf,sources,record)
put(out/'integrity.json',dict(archive=a['sha256'],members=a['entry_sha256'],scheduler_members=c['raw_sha256'],sources={n:[str(x) for x in v[:2]] for n,v in pkg.items()}))
def cli(key,name,inputs=None,default=False,want=0,more=(),dest=None):
    boot,elf,sources,record=pkg[name]
    argv=[sys.executable,str(repo/'tools/pi4_serial_capture.py'),'--boot-dir',str(boot),'--elf',str(elf),'--boot-dir-source','archive','--build-record',str(out/(name+'-record.json')),'--output',str(out/(dest or key)),'--replay',*map(str,inputs or sources)]
    if not default: argv+=['--profile',record['profile']]
    argv+=list(map(str,more))
    proc=subprocess.run(argv,capture_output=True)
    put(out/(key+'-call.json'),dict(argv=argv,exit=proc.returncode,stdout=proc.stdout.decode(),stderr=proc.stderr.decode()))
    assert proc.returncode==want,(key,proc.returncode)
    if want in (0,1):
        folder=out/(dest or key); sess=J(folder/'session.json'); ids=[]
        assert sess['mode']=='file_replay' and sess['witness_status']=='unsigned' and sess['board_revision'] is None and sess['eeprom'] is None
        for i,src in enumerate(inputs or sources,1):
            sub=folder/f'run-{i}'; r=J(sub/'result.json'); raw=(sub/'uart.bin').read_bytes(); ledger=[json.loads(line) for line in (sub/'reads.jsonl').read_text().splitlines()]
            assert raw==src.read_bytes() and r['uart_sha256']==H(raw) and r['session_id']==sess['session_id'] and r['run_id']==J(sub/'identity.json')['run_id']
            assert [e['offset'] for e in ledger]==[sum(t['length'] for t in ledger[:j]) for j in range(len(ledger))]
            ids.append(r['run_id'])
        assert len(set(ids))==2
for name in pkg: cli('original-'+name,name)
cli('original-default','scheduler',default=True)
f=out/'constructed-high.bin'; f.write_bytes(RR_HIGH)
cli('constructed-mixed','rr',[pkg['rr'][2][0],f])
cli('wrong-profile','fifo',pkg['rr'][2],want=1)
cli('unsupported','rr',want=2,more=['--profile','pi4-other'])
cli('reuse','rr',want=2,dest='original-rr')
cli('wrong-elf','rr',more=['--elf',pkg['fifo'][1]])
assert 'elf_sha256' in J(out/'wrong-elf/session.json')['build_association']['fields_to_verify']
import shutil
copied=out/'mutated-boot'; shutil.copytree(pkg['rr'][0],copied)
with (copied/'config.txt').open('ab') as s: s.write(b'\n')
cli('stale-manifest','rr',want=2,more=['--boot-dir',copied])
manifest=copied/'SHA256SUMS'
manifest.write_bytes(manifest.read_bytes().replace(pkg['rr'][3]['files_sha256']['config.txt'].encode(),H((copied/'config.txt').read_bytes()).encode()))
cli('stale-record','rr',more=['--boot-dir',copied])
assert set(J(out/'stale-record/session.json')['build_association']['fields_to_verify'])=={'files_sha256','package_manifest_sha256'}
shutil.rmtree(copied)
print('Historical inputs and CLI cases passed',flush=True)
