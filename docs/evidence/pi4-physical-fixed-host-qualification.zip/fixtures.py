"""Independent host stimuli. Nothing touches serial hardware."""
PREFIX = b"JNOX PI4 BOOT\nJNOX PI4 READY\n"


def stream(label, events):
    return PREFIX + b"".join((label + " " + event + "\n").encode("ascii") for event in events.split("|"))


SCHED = stream("SCHED", "LOW RUN|TIMER IRQ|HIGH RUN|LOW RESUMED|PASS")
FIFO = stream("FIXED FIFO", "START|A START|B YIELD|A RESUME|HIGH|A DONE|B SLEEP|B DONE")
RR_A = stream("FIXED RR", "START|A START|HIGH|B START|A DONE|B DONE")
RR_HIGH = stream("FIXED RR", "START|HIGH|A START|B START|A DONE|B DONE")
RR_INVALID = stream("FIXED RR", "START|HIGH|B START|A START|A DONE|B DONE")


def bad_inputs():
    return {
        "wrong_board": RR_A.replace(b"PI4", b"M1", 1),
        "fifo_as_rr": FIFO,
        "missing_final_lf": RR_A[:-1],
        "crlf": RR_A.replace(b"\n", b"\r\n"),
        "unspecified_order": RR_INVALID,
        "duplicated": RR_A.replace(b"FIXED RR HIGH\n", b"FIXED RR HIGH\n" * 2),
        "missing": RR_A.replace(b"FIXED RR HIGH\n", b""),
        "malformed": RR_A.replace(b"HIGH", b"HI\xffH"),
        "trailing": RR_A + b"!",
    }
