import sys, tempfile, json, zipfile, hashlib, subprocess, io, contextlib, types
from pathlib import Path
from unittest.mock import patch
from fixtures import *
root=Path(__file__).resolve().parent
repo=root.parent/'pi4-physical-merged-pinned'
sys.path.insert(0,str(repo/'tools'))
import pi4_serial_capture as cap, qemu_boot as q
out=root/'controls-second';out.mkdir()
J=lambda p:json.loads(p.read_bytes())
H=lambda b:hashlib.sha256(b).hexdigest()
def put(n,v): (out/n).write_text(json.dumps(v,indent=1))
fixed=J(repo/'docs/evidence/evd-031.json');sched=J(repo/'docs/evidence/evd-014-package.json')
archive_report={}
for n in ('fifo','rr','scheduler'):
    rec=J(root/'second'/(n+'-record.json'))
    p=Path('D:/codex/jnox-artifacts/pi4')/('2c8c463/jnox-pi4-scheduler-boot.zip' if n=='scheduler' else '24462f1/jnox-pi4-fixed-'+n+'.zip')
    h=H(p.read_bytes()); expected=sched['scheduler_zip_sha256'] if n=='scheduler' else fixed['packages'][n]['offline_zip_sha256'];assert h==expected
    m={**rec['files_sha256'],'SHA256SUMS':rec['package_manifest_sha256']}
    with zipfile.ZipFile(p) as z:
        assert sorted(z.namelist())==sorted(m)
        for k,v in m.items(): assert H(z.read(k))==v
    archive_report[n]=dict(path=str(p),sha256=h,members=m)
put('distribution-zips.json',archive_report)
ids={}
for f in ['fixed_runtime_observer.py','pi4_serial_capture.py','pi4_transcript.py','qemu_boot.py','test_pi4_serial_capture.py']:
    vals=[subprocess.check_output(['git','-C',repo,'rev-parse',pin+':tools/'+f]).decode().strip() for pin in ('75e833c778cd7469017aa17ff81bb5f22464fa84','ed611730a657b9cc7dda300626bcc8473faa52c9')]
    assert vals[0]==vals[1]; ids[f]=vals[0]
put('git-blobs.json',ids)
N=10**9
records=[]
def check(key,events,profile,verdict,variant=None):
    it=iter(events); t=0; got=[]
    def read(size):
        nonlocal t
        t,blob=next(it)
        assert len(blob)<=size
        if blob: got.append((t,blob))
        return blob
    with tempfile.TemporaryDirectory(dir=out) as td:
        folder=Path(td)
        kw={} if profile is None else {'profile':profile}
        r=cap.observe(folder,read,arm=(1000,0),now=lambda:t,sleep=lambda _:None,**kw)
        assert (r['uart_verdict'],r['matched_variant'])==(verdict,variant),(key,r)
        data=b''.join(b for _,b in got)
        assert (folder/'uart.bin').read_bytes()==data and r['uart_sha256']==H(data)
        ledger=[json.loads(row) for row in (folder/'reads.jsonl').read_text().splitlines()]
        offset=0
        assert len(ledger)==len(got)
        for row,(stamp,blob) in zip(ledger,got):
            assert row==dict(elapsed_ns=stamp,offset=offset,length=len(blob));offset+=len(blob)
        if verdict=='unexpected_bytes':
            options=[RR_A,RR_HIGH]
            expected=next(i for i in range(len(data)) if not any(s.startswith(data[:i+1]) for s in options))
            assert expected==r['first_unexpected_offset']
        records.append(dict(case=key,result=r,read_count=len(ledger)))
for profile,var,raw in [(None,'scheduler',SCHED),('pi4-fixed-fifo','fifo',FIFO),('pi4-fixed-rr','rr-a-first',RR_A),('pi4-fixed-rr','rr-high-first',RR_HIGH)]:
    for i in range(len(raw)+1):
        check(f'{var}-split-{i}',[(0,raw[:i]),(1,raw[i:]),(N+1,b'')],profile,'matched',var)
    check(var+'-bytewise',[(i,bytes([v])) for i,v in enumerate(raw)]+[(2*N,b'')],profile,'matched',var)
for name,raw in bad_inputs().items():
    verdict='timeout' if name=='missing_final_lf' else 'unexpected_bytes'
    for j,parts in enumerate([[raw],list(map(bytes,([v] for v in raw))),[raw[:len(raw)//2],raw[len(raw)//2:]]]):
        check(f'{name}-{j}',[(i,b) for i,b in enumerate(parts)]+[(30*N,b'')],'pi4-fixed-rr',verdict)
for deadline in [30*N-1,30*N,30*N+1]:
    v='timeout' if deadline>30*N else 'matched'
    check('deadline-'+str(deadline),[(0,RR_A[:-1]),(deadline,b'\n'),(deadline+N-1,b''),(deadline+N,b'')],'pi4-fixed-rr',v,'rr-a-first' if v=='matched' else None)
check('quiet-trailing',[(0,RR_A),(N-2,b''),(N-1,b'!')],'pi4-fixed-rr','unexpected_bytes')
check('empty',[(0,b''),(30*N,b'')],None,'timeout')
put('independent-observations.json',records)
class Alive:
    def poll(self):return None
apis=[]
for profile,raw,allow,ok in [('pi4-fixed-rr',RR_A,False,True),('pi4-fixed-rr',RR_HIGH,False,True),('pi4-fixed-rr',RR_INVALID,False,False),('pi4-fixed-fifo',FIFO,False,True),('pi4-scheduler',SCHED,False,True),('pi4-scheduler',SCHED.replace(b'\n',b'\r\n'),False,False),('pi4-scheduler',SCHED.replace(b'\n',b'\r\n'),True,True),('OTHER',q.BOOT_TRANSCRIPT.replace(b'\n',b'\r\n'),True,True)]:
    exp=q.BOOT_TRANSCRIPT if profile=='OTHER' else q.TRANSCRIPTS[profile]
    r=q.observe(Alive(),io.BytesIO(raw),1,exp,allow_crlf=allow,quiet_seconds=0)
    assert (r is None)==ok,(profile,r)
    apis.append([profile,H(raw),allow,r])
put('observer-api.json',apis)
serials=[]
for case in ('two-runs','early-close','read-error','input-eof'):
    instances=[]
    class Fake:
        def __init__(self,**kwargs):self.config=kwargs;self.reset=False;self.done=False;self.closed=False;instances.append(self)
        def open(self):assert self.port=='HOST-FIXTURE' and self.dtr is False and self.rts is False
        def __enter__(self):return self
        def __exit__(self,*_):self.closed=True
        def reset_input_buffer(self):self.reset=True
        def read(self,n):
            assert self.reset
            if self.done and case in ('early-close','read-error'):
                raise (EOFError if case=='early-close' else OSError)('injected read interruption')
            if self.done:return b''
            self.done=True
            return RR_A[:17] if case in ('early-close','read-error') else RR_A
    sess=J(root/'second/original-rr/session.json')
    target=out/('simulated-port-'+case)
    argv=['pi4_serial_capture.py','--port','HOST-FIXTURE','--boot-dir',sess['boot_dir'],'--elf',sess['elf'],'--profile','pi4-fixed-rr','--board-revision','host-fixture','--eeprom','host-fixture','--output',str(target)]
    stdout=io.StringIO();stderr=io.StringIO()
    prompts=[]
    def respond(s):
        prompts.append(s)
        if case=='input-eof': raise EOFError('injected prompt EOF')
        return ''
    with patch.dict(sys.modules,serial=types.SimpleNamespace(Serial=Fake)),patch.object(sys,'argv',argv),patch('builtins.input',respond),contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
        rc=cap.main()
    assert rc==(0 if case=='two-runs' else 2)
    assert all(i.closed and i.config['baudrate']==115200 and i.config['parity']=='N' and i.config['stopbits']==1 and i.config['bytesize']==8 for i in instances)
    assert J(target/'session.json')['witness_status']=='unsigned'
    if case=='two-runs': assert len(instances)==2 and len(prompts)==4 and all(J(target/f'run-{i}/result.json')['matched_variant']=='rr-a-first' for i in (1,2))
    elif case!='input-eof': assert (target/'run-1/uart.bin').read_bytes()==RR_A[:17]
    serials.append(dict(case=case,rc=rc,source='synthetic serial module, host only',argv=argv,prompts=prompts,stdout=stdout.getvalue(),stderr=stderr.getvalue(),configs=[i.config for i in instances]))
put('fake-port-calls.json',serials)
print('passed:',len(records),'collector cases,',len(apis),'qemu observer API calls,',len(serials),'injected port scenarios')

