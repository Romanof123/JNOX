#!/bin/bash
set -euo pipefail
base="$HOME/jnox406-lab"
exec 9>"$base/run.lock"; flock 9
cd "$base/src"
rev=93678bff45406c688d26102b76945cdbc98c321d
git index-pack --stdin </mnt/d/codex/jnox456-integration/freeze.pack
git checkout -q --detach "$rev"
git restore --ignore-skip-worktree-bits --source=HEAD -- kernel arch boards drivers/linux-compat tools sdk examples/linux-source-net-duplex
test "$(git rev-parse HEAD)" = "$rev"
test -z "$(git status --porcelain --untracked-files=no)"
d="$base/456-build-01"; test -d "$d"; exec > >(tee "$d/resume-01.log") 2>&1
printf '%s\n' "$rev" > "$d/source-commit"
export PATH="$HOME/.cargo/bin:$PATH" PYTHONPATH=/mnt/d/codex/jnox332-release-deps PYTHONDONTWRITEBYTECODE=1 CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$d/target" CARGO_NET_OFFLINE=true LC_ALL=C
before="$base/441-combined-duplex-01/imported/import.json"
source=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["source"]["path"])' "$before")
headers=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["header_root"])' "$before")
test -s "$d/imported/import.json" || python3 tools/build_linux_source_virtio_net.py --source "$source" --headers "$headers" --out "$d/imported" --lifecycle-duplex-service
for profile in ordinary tx; do
 arg=(); if [[ "$profile" == tx ]]; then arg=(--arg t); fi
 python3 tools/build_native_el0.py --board virt --policy fifo --linux-source-net-duplex --priority 8 --peer-priority 8 --elf "$d/imported/service.elf" --peer-elf "$d/imported/peer.elf" "${arg[@]}" --out "$d/$profile"
done
verify=tools/verify_linux_source_net_duplex.py
for run in tx-first tx-repeat ordinary; do
 prof=tx; args=(--require-tx-irq)
 if [[ $run == tx-repeat ]]; then args+=(--mtu 1390 --mac 52:54:00:44:10:02); fi
 if [[ $run == ordinary ]]; then prof=ordinary; args=(); fi
 python3 "$verify" --package "$d/$prof" --driver-manifest "$d/imported/import.json" --out "$d/$run-capture" "${args[@]}" --mutation-tests
 python3 "$verify" --package "$d/$prof" --driver-manifest "$d/imported/import.json" --out "$d/$run-capture" "${args[@]}" --replay
done
