import json,pathlib,subprocess
b=pathlib.Path.home()/'jnox406-lab'
j=json.loads((b/'441-combined-duplex-01/imported/import.json').read_bytes())
for s in (j['source']['path'],j['header_root']):print(s,pathlib.Path(s).exists())
print(subprocess.run(['git','-C',str(b/'src'),'cat-file','-t','fcef159'],capture_output=True,text=True).stdout)
