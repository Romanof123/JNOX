#define UTS_RELEASE "6.18.65-0-virt"
