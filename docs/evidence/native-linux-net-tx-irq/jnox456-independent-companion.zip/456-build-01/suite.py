"""Run all three positive replays and isolated corruption controls in serial order."""
import json
from pathlib import Path
import subprocess
import sys


base=Path(__file__).absolute().parent
out=base/'results'
out.mkdir(exist_ok=True)


def run(boot, *extra):
    return subprocess.run([sys.executable,str(base/'reader.py'),boot,*extra],
                          capture_output=True,text=True)


def save(name, data):
    (out/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


boots={}
for label in ('tx-first-v2','tx-repeat-v2','ordinary-v2'):
    proc=run(label)
    if proc.returncode:
        sys.exit(f'{label}\n{proc.stderr}')
    boot=json.loads(proc.stdout)
    save(label+'.json',boot)
    boots[label]=boot
    print(f"{label} {boot['packet_counts']} {boot['trace']['spi79_transactions']} SPI 79 transactions",flush=True)

assert len({row['nonce'] for row in boots.values()})==3
assert [(row['mac'],row['mtu']) for row in boots.values()]==[
    ('52:54:00:44:10:01',1410),('52:54:00:44:10:02',1390),('52:54:00:44:10:01',1410)]
assert boots['tx-first-v2']['identity']['kernel']==boots['tx-repeat-v2']['identity']['kernel']
assert boots['ordinary-v2']['identity']['kernel']!=boots['tx-first-v2']['identity']['kernel']

controls={
    'wire':'reply 31','held-cookie':'held/retired cookie history',
    'generation':'generation / ordinal','used-head':'generation / ordinal','used-id':'unique serial TX owner descriptor',
    'duplicate':'generation / ordinal','callback-pointer':'registered callback and claimed used head',
    'wake':'one contiguous wake','deferred-free':'deferred cookie release',
    'opcode':'executed image instruction','irq-ack':'Virtio interrupt ACK',
}
rejected={}
for name,expected in controls.items():
    proc=run('tx-first-v2','--mutate',name)
    reason=proc.stderr.strip().splitlines()[-1] if proc.stderr.strip() else ''
    if proc.returncode==0 or expected not in reason:
        sys.exit(f'control {name} unexpected outcome {proc.returncode} {reason}')
    rejected[name]=reason
    print(f'rejected {name}: {reason}',flush=True)
save('controls.json',rejected)
