"""Independent, offline QEMU GICv2 / virtio-net interrupt and split-ring reader."""
import hashlib
import json
import re
import struct
from bisect import bisect_right
from collections import Counter


def require(value, label):
    if not value:
        raise ValueError(label)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


KERNELS = {
    True: 'fd97fdb41ba64252bbd49cb50d2adddc401a94589f1a346e8519d53850b21098',
    False: '16bcd0958b246653fc01ac526aaf82def3f0dd94649e5e1ea3cbec5cd974ffa2',
}
SERVICE = '0b67b1328b7bad7ba57011ddda9acff7966089cd52ab9d67c4964757e385e7d1'
LINUX = '05e676f7fc4f91783c961c860b930fae33462348064887eea95be3a440282a29'


def validate_package(root, native, raw, irq_mode):
    launch = json.loads((raw/'launch.json').read_bytes())
    manifest = json.loads((native/'manifest.json').read_bytes())
    imp = json.loads((root/'imported/import.json').read_bytes())
    require(manifest['commit']=='93678bff45406c688d26102b76945cdbc98c321d' and
            not manifest['tracked_changes'], 'product source commit')
    require(digest(root/'definitions/virtio_net.c')==LINUX==imp['upstream']['sha256']==imp['source']['sha256'], 'Linux source hash')
    require(imp['upstream']['commit']=='4700e3adf3b24b39dd4929e9c6d62811ba3ccea8', 'Linux commit')
    kernel=(native/'kernel.elf').read_bytes()
    require(digest(native/'kernel.elf')==KERNELS[irq_mode]==launch['kernel_sha256']==manifest['kernel_elf_sha256'], 'launch image')
    for package, imported, key in [('user.elf','service.elf','user_elf_sha256'),('native_peer.elf','peer.elf','peer_elf_sha256')]:
        image = (native/package).read_bytes()
        require(kernel.count(image)==1 and digest(native/package)==manifest[key]==digest(root/'imported'/imported), 'embedded '+package)
    require(digest(native/'user.elf')==SERVICE, 'pinned service ELF')
    require(digest(root/'imported/import.json')==launch['import_sha256'], 'import hash')
    for obj in ('virtio_net.original.o','virtio_net.packet.o'):
        require(digest(root/'imported'/obj)==imp['objects'][obj]['elf']['sha256'], 'compiled object '+obj)
    require(digest(root/'imported/virtio_net.callback.o')==imp['callback_object']['sha256'],'linked input object')
    require(bool(manifest.get('linux_source_net_tx_irq'))==irq_mode and
            manifest['slots'][0]['argv'][1:]==(['t'] if irq_mode else []), 'IRQ versus polling image choice')
    argv=launch['argv']
    require(argv[argv.index('-machine')+1]=='virt,gic-version=2' and argv[argv.index('-cpu')+1]=='cortex-a72' and
            argv[argv.index('-smp')+1]=='1' and argv[argv.index('-accel')+1]=='tcg', 'AArch64 QEMU configuration')
    return dict(product=manifest['commit'],linux=imp['upstream']['commit'],linux_sha256=LINUX,
                kernel=KERNELS[irq_mode],service=SERVICE,packet_object=digest(root/'imported/virtio_net.packet.o'))


def verify_queue(stage, history, tx, owner, peer, driver, mac, nonce, mtu, mutation):
    require(owner[2]==tx[0]==peer[2]!=0 and owner[3]==peer[3]==int.from_bytes(mac,'big') and
            owner[12]==mtu and tx[3]!=tx[4] and tx[12]==driver['frame_skb'] and tx[6]==driver['skb_xmit_done'],
            'session, original callback, frame owner and configuration')
    if stage=='final':
        require(owner[4]==peer[4]==int.from_bytes(nonce,'big') and
                owner[5:11]==(80,80,80,80,5912,5912) and peer[5:9]==(80,80,5912,5912), 'traffic byte totals')
    idx={'ready':1,'held':2,'overlap':3,'ack':4,'final':6}.get(stage)
    if idx is None:
        return dict(submitted=tx[7],notified=tx[8],retired=tx[9],state=tx[11])
    submitted,notified,retired,descriptor,nsg,length,outstanding,err=history[idx*8:idx*8+8]
    total={'ready':0,'held':1,'overlap':1,'ack':80,'final':80}[stage]
    held=int(stage in ('held','overlap'))
    if mutation=='held-cookie' and stage=='overlap':
        outstanding=0
    require((submitted,notified,retired,outstanding,err)==(total,total-held,total-held,held,0), 'held/retired cookie history')
    require(tx[7:10]==(submitted,notified,retired) and tx[14]==held and tx[11]==2*held, 'live TX cookie lifetime')
    return dict(submitted=submitted,notified=notified,retired=retired,outstanding=outstanding,
                stable_skb=hex(tx[12]),last_descriptor=descriptor,last_sg_count=nsg)


def verify_rows(stage, mem, owner_root, peer_root, driver, peer, kernel, generation, done, used, mutation):
    events=list(struct.iter_unpack('<8Q',mem.read(kernel['jnox_linux_net_tx_irq_events'],8192)))
    callbacks=list(struct.iter_unpack('<8Q',mem.user(owner_root,driver['jnox_duplex_tx_irq'],8192)))
    denial,=struct.unpack('<q',mem.user(peer_root,peer['jnox_duplex_peer_tx_irq_denial'],8))
    require(denial==-13,'peer claim authorization')
    if stage=='ack':
        changes={'generation':(events,0,0),'used-head':(events,4,88),'used-id':(events,5,17),
                 'duplicate':(events,7,3),'callback-pointer':(callbacks,3,4),'wake':(callbacks,5,0),
                 'deferred-free':(callbacks,7,0)}
        if mutation in changes:
            rows,field,value=changes[mutation]
            row=list(rows[1])
            row[field]=value
            rows[1]=tuple(row)
    require(not any(any(row) for row in events[done:]+callbacks[done:]), 'unpublished receipt / callback')
    first_wake=callbacks[0][4] if done else 0
    for i,(event,call) in enumerate(zip(events[:done],callbacks[:done])):
        n=i+1
        require(event[:5]==(generation,n,79,1,n) and event[7]==n,'generation / ordinal / SPI / status / used head / claim')
        require(event[5]==0 and event[6] in (0,1), 'unique serial TX owner descriptor')
        if i in used:
            require(used[i]==(event[5],0),'receipt vs physical used ring')
        require(call[:4]==(generation,i,n,driver['skb_xmit_done']), 'registered callback and claimed used head')
        require(call[4:6]==(first_wake+i,first_wake+n),'one contiguous wake per claimed head')
        require(call[6:]==(0,1),'deferred cookie release after duplicate claim check')
    return dict(claimed=done,wake_delta=done,retired=done,peer_claim=denial,
                simultaneously_pending_rx_sequences=[i for i in range(done) if events[i][6]],
                last_used_head=done,descriptor_ids=sorted({row[5] for row in events[:done]}))


MMIO=re.compile(rb"^memory_region_ops_(read|write) cpu 0 mr \S+ addr (0x[\da-f]+) value (0x[\da-f]+) size (\d+) name '([^']+)'")
AT=re.compile(rb'^0x([\da-f]+):\s+([\da-f]{8})\s+')
EXEC=re.compile(rb'^Trace 0: (\S+) \[[\da-f]+/([\da-f]+)/')


def analyze_trace(raw, native, syms, irq, elf_word, mutation):
    image=native/'user.elf'
    lifecycle=('virtnet_probe','virtnet_open','skb_recv_done','virtnet_poll','start_xmit','virtnet_close','virtnet_remove')
    entry=syms['skb_xmit_done']
    wake=syms['netif_tx_wake_queue']
    # Identify the unique A64 direct branch to the compatibility queue-wake routine.
    tail=None
    for pc in range(entry,entry+172,4):
        op=int.from_bytes(elf_word(image,pc),'little')
        if op>>26==5:
            delta=((op&0x3ffffff)^0x2000000)-0x2000000
            if pc+4*delta==wake:
                require(tail is None,'ambiguous callback wake branch')
                tail=pc
    require(tail is not None,'linked tail branch target')
    rawbytes=(raw/'machine.log').read_bytes()
    lines=rawbytes.splitlines(keepends=True)
    translated={}
    words={}
    blocks={}
    current=None
    executed={name:[] for name in lifecycle+('skb_xmit_done','wake_branch')}
    entries={syms[k]:k for k in lifecycle+('skb_xmit_done',)}
    kicks=[[],[]]
    spi=[]
    chain=[]
    status=[]
    configs={}
    deasserted=False
    reasserted=0
    level=None
    byte=0
    for i,line in enumerate(lines):
        start=byte
        byte+=len(line)
        if line.startswith(b'IN:'):
            current=None
        if m:=AT.match(line):
            pc=int(m[1],16)
            word=int(m[2],16)
            words[pc]=word
            if current is None: current=pc
            blocks.setdefault(current,set()).add(pc)
            if pc in entries or entry<=pc<=tail:
                if mutation=='opcode' and pc==entry: word ^= 1
                require(elf_word(image,pc)==word.to_bytes(4,'little'),'executed image instruction')
                translated[pc]=word
        if m:=EXEC.match(line):
            pc=int(m[2],16)
            if i+1<len(lines) and lines[i+1].startswith(b'Stopped execution of TB chain before'):
                continue
            if pc in entries:
                require(pc in translated,'executed entry without matching translation')
                executed[entries[pc]].append((i,start))
            if tail in blocks.get(pc,()):
                executed['wake_branch'].append((i,start))
        if line.startswith(b'gic_set_irq irq 79 level '):
            level=line.split()[4]==b'1'
            if not level and chain and chain[-1][0]=='ACK': deasserted=True
        if line.startswith(b'gic_acknowledge_irq cpu 0 acknowledged irq 79'):
            require(not chain and level is True,'SPI 79 asserted and unclaimed')
            chain=[('line',i)]
            deasserted=False
        if not (m:=MMIO.match(line)): continue
        action=m[1]; addr=int(m[2],16); val=int(m[3],16); size=int(m[4]); dev=m[5]
        if 0xa003f00<=addr<=0xa003f0b and action==b'read' and dev==b'virtio-mmio':
            for j in range(size): configs[addr+j]=(val>>(8*j))&255
        if addr==0xa003e50 and action==b'write' and dev==b'virtio-mmio':
            require(val in (0,1) and size==4,'virtqueue notification')
            kicks[val].append((i,start))
        if addr==0xa003e70 and action==b'write' and dev==b'virtio-mmio':
            status.append(val)
        if addr==0x801000c and val==79 and action==b'read' and dev==b'gic_cpu':
            require([x[0] for x in chain]==['line'],'physical GICC_IAR')
            chain.append(('IAR',i))
        elif chain and addr==0xa003e60 and action==b'read' and dev==b'virtio-mmio':
            require(val==1 and size==4 and [x[0] for x in chain]==['line','IAR'],'Virtio interrupt status')
            chain.append(('status',i))
        elif chain and addr==0xa003e64 and action==b'write' and dev==b'virtio-mmio':
            if mutation=='irq-ack' and not spi: val ^= 1
            require(val==1 and size==4 and [x[0] for x in chain]==['line','IAR','status'],'Virtio interrupt ACK')
            chain.append(('ACK',i))
        elif addr==0x8010010 and val==79 and action==b'write' and dev==b'gic_cpu':
            require([x[0] for x in chain]==['line','IAR','status','ACK'] and deasserted, 'GICC_EOIR after status ACK and deassertion')
            if level: reasserted+=1
            spi.append((chain[1][1],i))
            chain=[]
    require(not chain and len(spi)>0 and status==[0,1,3,11,15,0],'complete IRQ chains and reset')
    require(len(kicks[1])==80 and kicks[0], 'actual TX kicks')
    overlap=json.loads((raw/'overlap/trace.json').read_bytes())['machine_log_bytes']
    require(kicks[1][0][1]>=overlap,'no TX kick while held through RX overlap')
    require(len(executed['start_xmit'])==80 and all(len(executed[k])==1 for k in ('virtnet_probe','virtnet_open','virtnet_close','virtnet_remove')), 'Linux entry counts')
    require(executed['virtnet_probe'][0]<executed['virtnet_open'][0]<executed['skb_recv_done'][0]<executed['start_xmit'][0] and
            any(executed['start_xmit'][0]<row<kicks[1][0] for row in executed['virtnet_poll']) and
            kicks[1][-1]<executed['virtnet_close'][0]<executed['virtnet_remove'][0], 'independent RX progress and ordered lifecycle')
    launch=json.loads((raw/'launch.json').read_bytes())
    mac=bytes(configs[0xa003f00+i] for i in range(6))
    mtu=configs[0xa003f0a]+(configs[0xa003f0b]<<8)
    require(mac.hex(':')==launch['mac'] and mtu==launch['mtu'],'device MMIO configuration')
    spans=[]
    if irq:
        require(len(executed['skb_xmit_done'])==len(executed['wake_branch'])==80,'original callback and non-NAPI wake path counts')
        ia=[x[0] for x in spi]
        for n,(kick,cb,branch) in enumerate(zip(kicks[1],executed['skb_xmit_done'],executed['wake_branch'])):
            limit=kicks[1][n+1][0] if n+1<len(kicks[1]) else executed['virtnet_close'][0][0]
            require(kick[0]<cb[0]<branch[0]<limit,'TX kick before callback and tail wake')
            first=bisect_right(ia,kick[0])
            segments=[s for s in spi[first:bisect_right(ia,cb[0])] if s[1]<cb[0]]
            require(segments,'hardware IRQ between TX notify and original callback')
            spans.append(len(segments))
    return dict(spi79_transactions=len(spi),reassertions_before_eoi=reasserted,tx_kicks=len(kicks[1]),rx_kicks=len(kicks[0]),
                kernel_status_writes=status,mac_mmio=mac.hex(':'),mtu_mmio=mtu,
                completed_irq_transactions_between_kick_and_callback=dict(Counter(spans)),
                pc_counts={k:len(v) for k,v in executed.items() if irq or k not in ('skb_xmit_done','wake_branch')},
                callback=hex(entry),entry_word=hex(translated[entry]) if irq else None,
                tail_branch=hex(tail),tail_word=hex(translated[tail]) if irq else None,
                tail_target=hex(wake),overlap_capture_byte=overlap,first_tx_kick_byte=kicks[1][0][1],
                polling_callback_filter='enabled' if irq else 'absent')
