"""Independent JNOX #456 TX IRQ replay. Common #441 duplex controls adapted from the independent reader."""
import argparse
import hashlib
import json
import re
import struct
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).absolute().with_name('elftools-0.32.zip')))
from elftools.elf.elffile import ELFFile
from irq import analyze_trace, verify_rows, verify_queue, validate_package

parser = argparse.ArgumentParser()
parser.add_argument('capture', choices=('tx-first-v2','tx-repeat-v2','ordinary-v2'))
parser.add_argument('--root', type=Path, default=Path(__file__).absolute().parent)
parser.add_argument('--mutate', default='')
args = parser.parse_args()
raw = args.root / args.capture
irq_mode = args.capture != 'ordinary-v2'
native = args.root / ('tx' if irq_mode else 'ordinary')
def check(condition, label):
    if not condition:
        raise ValueError(label)

def syms(name):
    with (native/name).open('rb') as stream:
        table = ELFFile(stream).get_section_by_name('.symtab')
        return {s.name:s['st_value'] for s in table.iter_symbols() if s['st_shndx']!='SHN_UNDEF'}

class Memory:
    def __init__(self, path):
        self.data = {}
        for key, encoded in json.loads(path.read_text()).items():
            addr, size = key.split("/")
            addr, block = int(addr,16), bytes.fromhex(encoded)
            check(len(block) == int(size), "RAM length " + key)
            for i, val in enumerate(block):
                check(self.data.setdefault(addr+i,val) == val, "inconsistent overlapping RAM")
    def read(self, addr, n):
        return bytes(self.data[addr+i] for i in range(n))
    def phys(self, root, va):
        table = root
        for shift in (30,21,12):
            entry = int.from_bytes(self.read(table + 8*((va >> shift) & 511),8),"little")
            if entry & 3 != 3:
                raise KeyError("table/page invalid")
            table = entry & 0xfffffffff000
        return table + (va & 4095)
    def user_pages(self, root):
        tables = {root}
        for shift in (30,21,12):
            next_tables = set()
            for table in tables:
                entries = struct.unpack("<512Q", self.read(table,4096))
                for entry in entries:
                    if entry & 1:
                        check(entry & 3 == 3, "unexpected block mapping")
                        if shift != 12 or entry & 64:
                            next_tables.add(entry & 0xfffffffff000)
            tables = next_tables
        return tables
    def user(self, root, va, n):
        buf = bytearray()
        while len(buf) < n:
            addr = va+len(buf)
            length = min(n-len(buf),4096-addr%4096)
            buf.extend(self.read(self.phys(root,addr),length))
        return bytes(buf)
    def words(self, root, va, n):
        return struct.unpack("<"+"Q"*n,self.user(root,va,n*8))


def elf_word(path, pc):
    data = path.read_bytes()
    check(data[:6] == b"\x7fELF\x02\x01" and struct.unpack_from("<H", data, 18)[0] == 183, "AArch64 ELF")
    start = struct.unpack_from("<Q", data, 32)[0]
    stride, count = struct.unpack_from("<HH", data, 54)
    for index in range(count):
        kind, flags, offset, address, _, length, _, _ = struct.unpack_from("<II6Q", data, start + index*stride)
        if kind == 1 and flags & 1 and address <= pc <= address+length-4:
            return data[offset+pc-address:offset+pc-address+4]
    raise ValueError("ELR outside executable file segments")

def sample(name):
    folder = raw / name
    q = json.loads((folder / "qmp.json").read_text())
    h = json.loads((folder / "halted.json").read_text())
    check([c["cpu-index"] for c in q["cpus"]] == [0] and q["status"]["running"] and q["stop_return"] == {} and h["status"] == "paused" and not h["running"], "single stopped CPU")
    return Memory(folder / "ram.json")

def words(mem, symbol, count):
    return struct.unpack("<" + "Q"*count, mem.read(kernel[symbol], count*8))

kernel = syms("kernel.elf")
driver = syms("user.elf")
peer = syms("native_peer.elf")
identity = validate_package(args.root, native, raw, irq_mode)
with (native/'kernel.elf').open('rb') as stream:
    areas = [s for s in ELFFile(stream).get_section_by_name('.symtab').iter_symbols() if 'native_el0_mmu' in s.name and '6SPACES' in s.name]
    area, = areas
    r0, r1 = area['st_value'], area['st_value']+area['st_size']//2

def socket_stream(path):
    data = path.read_bytes()
    out = []
    pos = 0
    while pos < len(data):
        size, = struct.unpack_from(">I", data, pos)
        pos += 4
        check(60 <= size <= 91 and pos + size <= len(data), "socket frame boundary")
        out.append(data[pos:pos+size])
        pos += size
    return out

def verify_pcap(path, frames):
    data = path.read_bytes()
    order = {bytes.fromhex("d4c3b2a1"):"<",bytes.fromhex("a1b2c3d4"):">"}[data[:4]]
    check(struct.unpack_from(order+"I", data, 20)==(1,), "Ethernet PCAP")
    pos = 24
    for frame in frames:
        stored, original = struct.unpack_from(order+"II", data, pos+8)
        pos += 16
        check(stored==original and data[pos:pos+stored] in
              (frame, bytes(10)+frame, bytes(12)+frame), "NIC frame")
        pos += stored
    check(pos == len(data), "extra NIC frames")

launch = json.loads((raw/"launch.json").read_text())
mac = bytes.fromhex(launch["mac"].replace(":",""))
host = bytes.fromhex("024a4e4f5801")
nonce = (raw/"nonce.bin").read_bytes()
check(len(nonce)==8 and any(nonce), "nonce")
requests = socket_stream(raw/"ingress.bin")
replies = socket_stream(raw/"egress.bin")
check(len(requests)==81 and len(replies)==80, "socket record counts")
if args.mutate == "wire":
    replies[31] = replies[31][:-1] + bytes([replies[31][-1] ^ 1])
for seq, reply in enumerate(replies):
    request = requests[seq]
    body = bytes((i+seq)&255 for i in range(34,60+seq%32))
    tag = nonce + seq.to_bytes(4,"big")
    check(request == mac+host+b"\x88\xb5JNOXRECV"+tag+body, "request "+str(seq))
    response = bytes(val ^ nonce[(seq+j)%8] ^ 165 for j,val in enumerate(body))
    check(reply == host+mac+b"\x88\xb6JNOXRESP"+tag+response and response!=body, "reply "+str(seq))
check(requests[-1]==mac+host+b"\x88\xb5JNOXACK!"+nonce+bytes(30), "terminal ACK")
verify_pcap(raw/"wire.pcap", requests[:3]+replies[:3]+
            [packet for pair in zip(requests[3:-1],replies[3:]) for packet in pair]+requests[-1:])

def object_binding():
    from elftools.elf.elffile import ELFFile
    from elftools.elf.relocation import RelocationSection
    candidates=[args.root/"imported"/"virtio_net.packet.o"]
    check(len(candidates)==1,"one upstream packet object under BUILD")
    with candidates[0].open("rb") as obj_stream,(native/"user.elf").open("rb") as img_stream:
        obj,linked=ELFFile(obj_stream),ELFFile(img_stream)
        def item(elf,name):
            sym,=elf.get_section_by_name(".symtab").get_symbol_by_name(name)
            sec=elf.get_section(sym["st_shndx"])
            offset=sym["st_value"]-sec["sh_addr"]
            return sym,sec.data()[offset:offset+sym["st_size"]]
        callbacks=("virtnet_probe","virtnet_open","skb_recv_done","virtnet_poll","start_xmit","skb_xmit_done","virtnet_close","virtnet_remove")
        for name in callbacks:
            sym,original=item(obj,name)
            _,actual=item(linked,name)
            reloc=set()
            for sec in obj.iter_sections():
                if isinstance(sec,RelocationSection) and sec["sh_info"]==sym["st_shndx"]:
                    reloc.update(row["r_offset"]-sym["st_value"] for row in sec.iter_relocations())
            check(original and len(original)==len(actual) and all(
                original[i:i+4]==actual[i:i+4] for i in range(0,len(actual),4) if i not in reloc),"unrelocated Linux instructions "+name)
        ops,_=item(obj,"virtnet_netdev")
        target,_=item(obj,"start_xmit")
        offsets=[]
        for sec in obj.iter_sections():
            if isinstance(sec,RelocationSection) and sec["sh_info"]==ops["st_shndx"]:
                for row in sec.iter_relocations():
                    ref=obj.get_section(sec["sh_link"]).get_symbol(row["r_info_sym"])
                    if row["r_info_type"]==257 and ref["st_shndx"]==target["st_shndx"] and ref["st_value"]+row["r_addend"]==target["st_value"]:
                        offsets.append(row["r_offset"]-ops["st_value"])
        offset,=offsets
        _,data=item(linked,"virtnet_netdev")
        check(struct.unpack_from("<Q",data,offset)==(driver["start_xmit"],),"registered transmit pointer")
        return offset

operation_offset=object_binding()
ring = kernel["jnox_linux_net_queue_pool"]
pool = kernel["jnox_linux_net_packet_buffers"]
token = None
reports = {}
receipt_states = {}
tx_ids = {}
used_slots = {}
for stage,phase,n,published,done in (("ready",3,0,0,0),("held",4,1,1,0),
        ("overlap",5,2,1,0),("completed",5,3,3,3),("ack",6,80,80,80),("final",100,81,80,80)):
    mem = sample(stage)
    owner = mem.words(r0,driver["jnox_duplex_driver"],32)
    app = mem.words(r1,peer["jnox_duplex_peer"],16)
    tx = mem.words(r0,driver["jnox_duplex_tx"],16)
    check(owner[:2]==(0x4455504c44525631,phase) and app[0]==0x4455504c50454552,"fixture identity")
    check(mem.words(r0,driver["virtnet_netdev"]+operation_offset,1)==(driver["start_xmit"],),"live netdev callback")
    token = token or owner[2]
    check(token and token==owner[2]==app[2],"session token")
    rx, trans = (mem.read(ring+i*4096,4096) for i in (0,1))
    def index(data, off):
        return struct.unpack_from("<H",data,off)[0]
    avail = index(rx,514)
    check((index(rx,586),index(trans,514),index(trans,586))==(n,published,done),"ring progress "+stage)
    qtx=mem.words(r0,driver['jnox_duplex_tx_queue'],56)
    checked_queue = verify_queue(stage, qtx, tx, owner, app, driver, mac, nonce, launch['mtu'], args.mutate)
    for seq in range(max(0,done-32),done) if stage != 'final' else ():
        slot=struct.unpack_from('<II',trans,588+8*(seq%32))
        check(used_slots.setdefault(seq,slot)==slot,'used entry changed between stops')
        if seq < published: tx_ids[seq]=index(trans,516+2*(seq%32))
    if irq_mode:
        receipt_states[stage] = verify_rows(stage,mem,r0,r1,driver,peer,kernel,token,done,used_slots,args.mutate)
    protected = set(range(ring,ring+8192,4096)) | set(range(pool,pool+64*1536,4096))
    grant_addr=kernel["jnox_linux_net_lifecycle_grants"]
    protected.update(range(grant_addr & ~4095,grant_addr+32*24,4096))
    grant_rows=list(struct.iter_unpack("<QQQ",mem.read(grant_addr,32*24)))
    posted_ids={index(rx,516+2*(i%32)) for i in range(n,avail)} if stage!="final" else set()
    check(len(posted_ids)==(avail-n if stage!="final" else 0),"unique live RX IDs")
    users = [mem.user_pages(root) for root in (r0,r1)]
    for slot,root,labels,table in ((0,r0,["jnox_duplex_driver","jnox_duplex_tx"],driver),
                                   (1,r1,["jnox_duplex_peer_requests","jnox_duplex_peer_replies"],peer)):
        for name in labels:
            count = 7280 if slot else 128
            for page in range(table[name]//4096,(table[name]+count-1)//4096+1):
                addr = mem.phys(root,page*4096)
                check(addr in users[slot] and addr not in users[1-slot], "private journal "+name)
        check(not protected.intersection(users[slot]),"user DMA alias")
    if irq_mode:
        eventbase=kernel['jnox_linux_net_tx_irq_events']
        private_pages = set(range(eventbase & ~4095, eventbase+8192,4096))
        check(all(not private_pages.intersection(user) for user in users),'user mapping for protected receipt')
    for idx,(epoch,addr,length) in enumerate(grant_rows):
        if idx in posted_ids:
            check(epoch==token and length==1530,"live protected grant")
            for page in range(addr//4096,(addr+length-1)//4096+1):
                pa=mem.phys(r0,page*4096)
                check(pa in users[0] and pa not in users[1],"private RX target")
        else:
            check((epoch,addr,length)==(0,0,0),"retired grant")
    if stage=="held":
        held_grants=dict(enumerate(grant_rows))
    if stage=="overlap":
        check(sum(row==(held_grants[idx]) and row[0]==token for idx,row in enumerate(grant_rows))>=27,"surviving RX grants")
    if stage != "final":
        check(28<=avail-n<=32, "persistent RX postings")
        for i in range(32):
            check(struct.unpack_from("<QIHH",rx,16*i)==(pool+1536*i,1530,2,0),"RX descriptor")
        last_tx = {}
        last_rx = {}
        for seq in range(max(0,n-32),n):
            idx,length = struct.unpack_from("<II",rx,588+8*(seq%32))
            check(idx<32 and length==12+len(requests[seq]),"RX used")
            last_rx[idx]=seq
        for idx,seq in last_rx.items():
            check(mem.read(pool+1536*idx+12,len(requests[seq]))==requests[seq],"RX DMA")
        for seq in range(max(0,published-32),published):
            idx=index(trans,516+2*(seq%32))
            check(idx<32,"TX descriptor ID")
            if seq < done:
                check(struct.unpack_from("<II",trans,588+8*(seq%32))==(idx,0),"TX used ID")
            last_tx[idx]=seq
        for idx,seq in last_tx.items():
            addr=pool+1536*(32+idx)
            check(struct.unpack_from("<QIHH",trans,16*idx)==(addr,len(replies[seq])+12,0,0)
                  and mem.read(addr+12,len(replies[seq]))==replies[seq],"TX DMA")
        if published:
            check(tx[5:10]==(driver["start_xmit"],driver["skb_xmit_done"],published,done,done)
                  and tx[13]==driver["virtnet_netdev"] and tx[14]==int(published!=done),"Linux TX binding and cookie")
    if stage in ("overlap","final"):
        count = 2 if stage=="overlap" else 80
        for label,records in (("requests",requests),("replies",replies)):
            history=mem.user(r1,peer["jnox_duplex_peer_"+label],91*count)
            check(history==b"".join(x.ljust(91,b"\0") for x in records[:count]),"native consumer "+label)
    if stage=="final":
        neg=lambda v:v%(1<<64)
        check(not any(mem.read(pool,64*1536)) and owner[20:25]==(neg(-19),neg(-116),neg(-116),0,0)
              and owner[27]==neg(-116) and owner[31]==0,"removal and revocation")
        check(all(app[i]==neg(-13) for i in (9,10,11,12,14)) and
              mem.user(r1,peer["jnox_duplex_peer_ack"],60)==requests[-1],"peer authority and ACK")
    reports[stage] = dict(ring=[avail,n,published,done],cookie=checked_queue,generation=token)

uart=(raw/"uart.log").read_bytes()
check(b"NATIVE EL0 FAULT" not in uart and sorted(re.findall(rb"(?m)^NATIVE EL0 EXIT PID (\d+) (-?\d+)\r?$",uart))
      ==[(b"0",b"0"),(b"1",b"0")],"native exits")
trace = analyze_trace(raw,native,driver,irq_mode,elf_word,args.mutate)
print(json.dumps(dict(boot=args.capture,profile='tx-irq' if irq_mode else 'polling',nonce=nonce.hex(),mac=launch['mac'],mtu=launch['mtu'],packet_counts=dict(request=80,reply=80,ack=1,reply_bytes=sum(map(len,replies))),identity=identity,stages=reports,receipt_stages=receipt_states,trace=trace,physical_used_sequences=sorted(used_slots)),indent=2))
