# Independent reader companion

First extract jnox456-raw.zip into a new directory. Extract this companion ZIP into the same directory. It adds the independent readers, pinned pyelftools 0.32 zip, upstream source reference and separately saved reviewer output. To replay without a guest:

```sh
cd 456-build-01
PYTHONDONTWRITEBYTECODE=1 python3 suite.py
python3 -c "import json,pathlib; p=pathlib.Path('.'); assert all(json.loads(x.read_bytes()) == json.loads((p/'results'/x.name).read_bytes()) for x in (p/'independent-expected').glob('*.json'))"
```

The suite checks two interrupt boots and the ordinary polling case, then deliberately mutates recorded inputs. The frozen results in independent-expected were produced by the independent reviewer. The two archives are meant to be extracted together.
