#!/usr/bin/env bash
set -euo pipefail
lane=/mnt/d/codex/permit389-hotpath-independent/lane.sh
old=c5e6a374a9cc8107bfadb25db9c71f8d0d1666e2
new=d2bd39091eb2d62523dbfa528d864a8ed260ef33
n=12
root="$HOME/permit389-hotpath-independent"
run() { n=$((n+1)); bash "$lane" boot "$1" "$2" "$3" "$4" "$(printf %03d "$n")"; }
for rev in "$old" "$new"; do
  bash "$lane" checkout "$rev"
  for p in fifo rr; do
    if [ "$rev" = "$new" ]; then
      for s in healthy overrun; do bash "$lane" build "$rev" "$p" "$s" fused; done
    fi
    for s in invalid live; do bash "$lane" build "$rev" "$p" "$s" fused; done
    if [ "$rev" = "$new" ]; then
      bash "$lane" build "$rev" "$p" ordinary loan
      for s in healthy sleep-late recover; do bash "$lane" build "$rev" "$p" "$s" watchdog; done
    fi
    for s in compute-late controller-exit recover-live; do bash "$lane" build "$rev" "$p" "$s" watchdog; done
  done
done
checkout() { git -C "$root/src" checkout --quiet --detach "$1"; }
for p in fifo rr; do for s in healthy overrun; do
  for rev in "$old" "$new" "$new" "$old" "$new" "$old" "$old" "$new"; do checkout "$rev"; run "$rev" "$p" "$s" fused; done
done; done
for p in fifo rr; do
  for rev in "$new" "$old"; do
    checkout "$rev"
    for s in invalid live; do run "$rev" "$p" "$s" fused; done
    run "$rev" "$p" ordinary loan
    for s in healthy sleep-late compute-late controller-exit recover recover-live; do run "$rev" "$p" "$s" watchdog; done
  done
done
