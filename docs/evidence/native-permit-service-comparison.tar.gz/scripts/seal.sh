#!/usr/bin/env bash
set -euo pipefail
root="$HOME/permit389-hotpath-independent"
win=/mnt/d/codex/permit389-hotpath-independent
dst="$root/packet"
mkdir -p "$dst"/{scripts,pkg,host-tests,logs}
for s in lane.sh baseline.sh compare.sh static-tests.sh static-offline.sh seal.sh replay.sh quick.py score.py summarize.py b0.py details.py prologues.py report.py; do cp "$win/$s" "$dst/scripts/$s"; done
cp -al "$root"/{apps,source-bundles,runs} "$dst/"
for dir in "$root"/pkg/*; do
    target="$dst/pkg/$(basename "$dir")"; mkdir -p "$target"; cp -al "$dir"/*.elf "$dir"/manifest.json "$dir"/build.log "$target/"
done
cp "$root"/host-tests/*.log "$dst/host-tests/"
cp -r "$root/sites" "$dst/"
for elf in "$dst"/pkg/*-fused-*/kernel.elf;do
    name=$(basename "$(dirname "$elf")")
    python3 "$dst/scripts/prologues.py" "$elf" > "$dst/sites/$name.disasm"
done
cp "$root"/logs/*.log "$root"/host.txt "$root"/static.log "$dst/logs/"
cp "$win"/{baseline,compare}.log "$dst/logs/"
bash "$dst/scripts/replay.sh" "$dst" > "$dst/logs/replay.log"
cd "$dst"
find . -type f ! -name SHA256SUMS -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > SHA256SUMS
sha256sum --quiet -c SHA256SUMS
tar -czf "$win/native-permit-hotpath-independent.tar.gz" --sort=name .
sha256sum "$win/native-permit-hotpath-independent.tar.gz" > "$win/native-permit-hotpath-independent.sha256"
cp "$dst/REPORT.en-ko.md" "$win/REPORT.en-ko.md"
cp "$dst/results/b0-by-boot.csv" "$win/b0-by-boot.csv"
ls -lh "$win/native-permit-hotpath-independent.tar.gz"
cat "$win/native-permit-hotpath-independent.sha256"
