#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
root=$(realpath "${1:-.}")
python3 "$root/scripts/score.py" "$root"
python3 "$root/scripts/summarize.py" "$root"
python3 "$root/scripts/b0.py" "$root"
python3 "$root/scripts/details.py" "$root"
python3 "$root/scripts/report.py" "$root"

