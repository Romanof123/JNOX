import re, subprocess,sys
elf=sys.argv[1]
symbols=subprocess.check_output(['aarch64-linux-gnu-nm','-nCS',elf],text=True)
assembly=subprocess.check_output(['aarch64-linux-gnu-objdump','-dC',elf],text=True)
for name in ('jnox_kernel::native_el0::safety::service','jnox_kernel::native_el0::loans::service','jnox_kernel::native_el0::loans::channel::LoanIpc::receive','jnox_kernel::native_el0::loans::channel::LoanIpc::receive_queued','jnox_kernel::native_el0::loans::service_other','jnox_kernel::native_el0::safety::Session::control','jnox_kernel::native_el0::safety::Session::commit','jnox_kernel::native_el0::safety::Session::check_at'):
    matches=[l for l in symbols.splitlines() if l.endswith(' '+name)]
    if not matches:continue
    print(matches[0]);mark='<'+name+'>:';lines=assembly.split(mark,1)[1].split('\n\n',1)[0].splitlines()[1:]
    print('\n'.join(lines))
