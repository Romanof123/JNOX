#!/usr/bin/env bash
set -euo pipefail
base="${LAB_ROOT:-$HOME/permit389-hotpath-independent}"
objects="${OBJECTS:-/mnt/d/codex/.jnox-work/policy-v1/.git/objects}"
export PATH="$HOME/.cargo/bin:$PATH"
export LC_ALL=C TZ=UTC CARGO_BUILD_JOBS=1
unset RUSTFLAGS CARGO_TARGET_DIR PYTHONPATH
for n in $(env | sed -n 's/^\(JNOX_[^=]*\)=.*/\1/p'); do unset "$n"; done
command=$1; shift
mkdir -p "$base"/{apps,logs,pkg,runs,source-bundles}
source_root="$base/src"
if [ "$command" = prepare ]; then
    frozen="$HOME/permit389-fused-c5ab397"
    cp "$frozen"/{sender,controller,supervisor}.elf "$base/apps/"
    cp "$frozen"/{sender,controller,supervisor}.build.log "$base/apps/"
    cp /mnt/d/codex/watchdog392-first-r1-c3015b4/worker.elf "$base/apps/"
    git init --quiet "$source_root"
    realpath "$objects" > "$source_root/.git/objects/info/alternates"
    git -C "$source_root" sparse-checkout init --cone
    git -C "$source_root" sparse-checkout set arch boards examples kernel sdk services tools trace verification
    { date -u; uname -a; rustc -Vv; cargo -V; python3 -V; qemu-system-aarch64 --version; command -v qemu-system-aarch64; sha256sum "$(command -v qemu-system-aarch64)"; git --version; lscpu; } > "$base/host.txt"
    exit
fi
rev=$1; shift
[ "${#rev}" = 40 ]
cd "$source_root"
if [ "$command" = checkout ]; then
    git checkout --quiet --detach "$rev"
    test -z "$(git status --short --untracked-files=no)"
    git ls-tree -r "$rev" -- arch boards examples kernel sdk services tools trace verification > "$base/source-bundles/$rev.ls-tree"
    git archive --format=tar.gz -o "$base/source-bundles/$rev.tar.gz" "$rev" arch boards examples kernel sdk services tools trace verification
    exit
fi
test "$(git rev-parse HEAD)" = "$rev"
test -z "$(git status --short --untracked-files=no)"
if [ "$command" = ordinary-apps ]; then
    sh sdk/native-aarch64/build.sh examples/native-loan/producer.c "$base/apps/producer.elf"
    sh sdk/native-aarch64/build-rust.sh examples/native-loan/reader/Cargo.toml "$base/apps/reader.elf"
    exit
fi
policy=$1; caseid=$2; role=$3
pkg="$base/pkg/${rev:0:9}-$role-$policy-$caseid"
q=(); if [ "$policy" = rr ]; then q=(--quantum-ticks 625000); fi
case "$role" in
    fused) args=(--arg "$caseid" --peer-arg "$caseid" --peer-arg fused-phase --peer2-arg "$caseid"); elf=sender; probe=examples/native-safety-admission/sender/src/main.rs; marker=71; slots=(--peer-elf "$base/apps/controller.elf" --peer-elf "$base/apps/supervisor.elf");;
    watchdog) args=(--arg sender --arg "$caseid" --peer-arg controller --peer-arg "$caseid" --peer2-arg supervisor --peer2-arg "$caseid" --safety-watchdog); elf=worker; probe=examples/native-safety-watchdog/src/main.rs; marker=71; slots=(--peer-elf "$base/apps/worker.elf" --peer-elf "$base/apps/worker.elf");;
    loan) args=(); elf=producer; probe=examples/native-loan/producer.c; marker=73; slots=(--peer-elf "$base/apps/reader.elf");;
esac
options=(--priority 6 --peer-priority 7 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel --safety-qualification)
if [ "$role" = loan ]; then options=(--priority 7 --peer-priority 1 --loan-route 0:1); fi
if [ "$command" = build ]; then
    test ! -e "$pkg"
    (set -x; python3 tools/build_native_el0.py --out "$pkg" --board virt --policy "$policy" "${q[@]}" --elf "$base/apps/$elf.elf" "${slots[@]}" "${args[@]}" "${options[@]}") > "$base/logs/$(basename "$pkg").build.log" 2>&1
elif [ "$command" = boot ]; then
    number=$4
    dest="$base/runs/$number-${rev:0:9}-$role-$policy-$caseid"
    mkdir "$dest"
    date -u +%FT%T.%NZ > "$dest/start.utc"
    set +e
    (set -x; python3 tools/native_el0_capture.py "$dest/cap" "$pkg/kernel.elf" "$base/apps/$elf.elf" "$probe" "$rev" --manifest "$pkg/manifest.json" --plain --expect-exit "$marker" --timeout 40 --uart-limit 8388608) > "$dest/capture.log" 2>&1
    result=$?
    date -u +%FT%T.%NZ > "$dest/finish.utc"
    echo "$result" > "$dest/status"
    cat "$dest/capture.log"
    exit "$result"
fi
