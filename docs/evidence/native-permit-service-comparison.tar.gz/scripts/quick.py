import sys
from pathlib import Path
root=Path(sys.argv[1])
for d in sorted((root/'runs').glob('*-fused-*')):
    path=d/'cap/uart.bin'
    if not path.exists():continue
    q=[list(map(int,x.split()[4:])) for x in path.read_text().splitlines() if x.startswith('NATIVE QUAL ROW ')]
    def phase(j,ph):
        mark=[i for i,v in enumerate(q) if v[:5]==[1,1,j,ph,3]]
        if not mark:return None
        row=q[mark[0]]
        ready=next((r for r in q[mark[0]+1:] if r[0]==2 and r[7]==1 and r[5]&2 and not r[6]&2),None)
        if ready:return [ready[k]-row[5] for k in (3,4)]
    print(d.name,phase(0,1),phase(0,2),phase(4,1))
