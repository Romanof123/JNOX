"""Bound B0 intervals using actual scheduler, protected decision, and device records."""
import collections,csv,json,sys
from pathlib import Path
from statistics import median
from score import signed
base=Path(sys.argv[1]);result=base/'results'
items=json.loads((result/'boots.json').read_text())
rows=[]
def delta(x,y):return [max(0,y[0]-x[1]),y[1]-x[0]]
for b in items:
    if not 13<=int(b['run'][:3])<=44:continue
    lines=(base/'runs'/b['run']/'cap/uart.bin').read_text().splitlines()
    def t(tag):return [list(map(int,x[len(tag):].split())) for x in lines if x.startswith(tag+' ')]
    q=t('NATIVE QUAL ROW');s=t('NATIVE SAFETY EVENT');f=t('NATIVE FIXED EVENT')
    p=b['phases'][1]; ready=q[p['ready']];dispatch=q[p['dispatch']];work=q[p['marks'][1]];block=q[p['block']]
    check,complete=[v for v in q[work[0]+1:p['marks'][2]] if v[1:4]==[4,1,63]]
    target=[p['target']]*2
    wake=ready[4:6];start=[dispatch[11],work[7]]
    # The counter before ERET precedes EL0 execution. The user's synchronous
    # stage-2 SVC proves that its resumed code has executed by the entry sample.
    ce,=[v for v in s if v[0]==12 and v[3]==1 and check[5]<=v[2]<=v[1]<=check[7]]
    co,=[v for v in s if v[0]==10 and complete[5]<=v[2]<=v[3]<=complete[7]]
    c=[ce[2],ce[1]];k=co[2:4];finish=block[4:6]
    during=[v for v in s if check[7]<=v[1]<=complete[5]]
    loan,=[v for v in during if v[0]==6 and v[2:4]==[1,35]]
    commits=[v for v in during if v[0]==5 and v[2:5]==[1,60,2]]
    frames=[v for v in during if v[0]==7];releases=[v for v in during if v[0]==6 and v[2:4]==[1,36]]
    op=signed(loan[4]);assert (op==0 and len(commits)==len(releases)==len(frames)==1) or (op==-11 and not commits and not frames and not releases)
    pid1=[v for v in f if v[3]==1 and check[5]<=v[0]<=complete[7]]
    frame_handle=frames[0][2] if frames else None
    frame_seq=frames[0][6] if frames else None
    assert not frames or frame_handle==loan[7]==releases[0][6] and releases[0][4]==0
    d=dict(run=b['run'],policy=b['policy'],case=b['case'],ref=b['rev'],miss=p['lo']>62500,recv=op,handle=frame_handle,sequence=frame_seq,release_status=signed(releases[0][4]) if releases else None,commit_status=signed(commits[0][5]) if commits else None,qual_row_ready=ready[0],qual_row_dispatch=dispatch[0],qual_row_mark=work[0],qual_row_check=check[0],qual_row_complete=complete[0],qual_row_block=block[0],svc_prefix=' '.join(str(v[1]) for v in pid1))
    bands=dict(full=delta(target,finish),to_ready=delta(target,wake),to_dispatch=delta(target,start),ready_to_dispatch=delta(wake,start),dispatch_to_check=delta(start,c),check_to_complete=delta(c,k),complete_to_block=delta(k,finish),check_svc=[check[7]-check[5]]*2,complete_svc=[complete[7]-complete[5]]*2)
    # Inter-service splits use exact qualified syscall end stamps (which precede
    # architectural return) and the source's event append stamps.
    bands['checked_to_recv_journal']=delta(c,[loan[1]]*2)
    if releases:bands['recv_to_release_journal']=[releases[0][1]-loan[1]]*2
    if commits:bands['release_to_commit_journal']=[commits[0][1]-releases[0][1]]*2
    bands['last_loan_or_commit_to_complete']=delta([commits[-1][1] if commits else loan[1]]*2,k)
    for key,val in bands.items():
        assert val[0]<=val[1],(key,val)
        d[key+'_lo'],d[key+'_hi']=val
    rows.append(d)
with (result/'b0-by-boot.csv').open('w',newline='') as out:
    writer=csv.DictWriter(out,fieldnames=list(dict.fromkeys(k for d in rows for k in d)));writer.writeheader();writer.writerows(rows)
tickbands=['full','to_ready','to_dispatch','dispatch_to_check','check_to_complete','complete_to_block']
for ref in ('c5e','d2b'):
 for policy in ('fifo','rr'):
    for case in ('healthy','overrun'):
        vs=[d for d in rows if d['ref'].startswith(ref) and d['policy']==policy and d['case']==case]
        print(ref,policy,case,[(d['recv'],d['miss']) for d in vs],[(min(d[k+'_lo'] for d in vs),max(d[k+'_hi'] for d in vs)) for k in tickbands])
for ref in ('c5e','d2b'):
 for recv in (-11,0):
    vs=[d for d in rows if d['ref'].startswith(ref) and d['recv']==recv]
    if vs:print('class',ref,recv,len(vs),sum(d['miss'] for d in vs),[(min(d[k+'_lo'] for d in vs),max(d[k+'_hi'] for d in vs)) for k in tickbands])

