#!/usr/bin/env bash
set -euo pipefail
root="$HOME/permit389-hotpath-independent"
export PATH="$HOME/.cargo/bin:$PATH"
base=c5e6a374a9cc8107bfadb25db9c71f8d0d1666e2
candidate=d2bd39091eb2d62523dbfa528d864a8ed260ef33
public=f30db111e7b020ec712f268e3e7b0814ab01a926
mkdir -p "$root"/{host-tests,sites}
cd "$root/src"
git diff --exit-code "$candidate" "$public" -- arch boards examples kernel sdk services tools trace verification
git diff --name-status "$candidate" "$public" > "$root/source-bundles/public-differences.txt"
git cat-file -p "$public" > "$root/source-bundles/public-tree.txt"
for rev in "$base" "$candidate";do
  git checkout --quiet --detach "$rev"
  for t in loan_ipc completion_watchdog;do
    p="$root/host-tests/${rev:0:9}-$t"
    (set -x; rustc --edition 2024 --test "kernel/src/$t.rs" -o "$p.elf"; "$p.elf" --test-threads=1) > "$p.log" 2>&1
  done
  for elf in "$root/pkg/${rev:0:9}"-fused-*/kernel.elf;do
    name=$(basename "$(dirname "$elf")")
    python3 tools/qemu_host_phase_sites.py "$elf" > "$root/sites/$name.txt"
    python3 /mnt/d/codex/permit389-hotpath-independent/prologues.py "$elf" > "$root/sites/$name.disasm"
  done
done
