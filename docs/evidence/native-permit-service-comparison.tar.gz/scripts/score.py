"""Independent raw UART/RAM reduction. Run with Python 3 and GNU AArch64 binutils."""
import argparse, collections, functools, hashlib, json, re, struct, subprocess
from pathlib import Path

sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
U=1<<64
def signed(v):return v if v<U//2 else v-U
@functools.lru_cache(None)
def symtab(elf):
    table={}
    for line in subprocess.check_output(['aarch64-linux-gnu-nm','-CS',elf],text=True).splitlines():
        a=line.split(None,3)
        if len(a)==4:
            table[a[3]]=tuple(int(v,16) for v in a[:2])
    return table
def chunks(xs,n):return [xs[k:k+n] for k in range(0,len(xs),n)]
def save(path,obj):path.write_text(json.dumps(obj,indent=1)+'\n')
def analyze(root,run):
    n,ref,role,policy,case=run.name.split('-',4)
    cap=run/'cap'; manifest=root/'pkg'/run.name.split('-',1)[1]/'manifest.json'
    assert (run/'status').read_text().strip()=='0'
    receipt=json.loads((cap/'session.json').read_text())
    for name,h in receipt['hashes'].items():assert sha(cap/name)==h
    launch=json.loads((cap/'launch.json').read_text()); m=json.loads(manifest.read_text())
    assert m==launch['argument_package'] and m['kernel_elf_sha256']==sha(cap/'kernel.elf')
    assert m['tracked_changes']=='' and m['commit']==launch['revision'] and m['commit'].startswith(ref)
    assert launch['qemu_sha256']=='0a63468782d096485932acf6aa0a69d358b3e3a6f68f655e960e9f5e3fc578d8'
    cmd=launch['argv']; assert cmd[1:-4]==['-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-no-reboot','-qmp','stdio'] and cmd[-4]=='-serial' and cmd[-2]=='-kernel'
    lines=(cap/'uart.bin').read_text().splitlines()
    def rows(tag):return [list(map(int,l[len(tag):].split())) for l in lines if l.startswith(tag+' ')]
    apps={'fused':['sender','controller','supervisor'],'watchdog':['worker']*3,'loan':['producer','reader']}[role]
    apppaths=[root/'apps'/(x+'.elf') for x in apps]
    bootdig=[l.split()[-1] for l in lines if re.match(r'^NATIVE EL0 (?:PEER\d? )?ELF ',l)]
    assert [sha(p) for p in apppaths]==bootdig==[slot['elf_sha256'] for slot in m['slots']]
    assert [slot['priority'] for slot in m['slots']]==([7,1] if role=='loan' else [6,7,4])
    assert m['policy']==policy and m['quantum_ticks']==(625000 if policy=='rr' else None)
    if role=='fused':
        assert not m.get('safety_watchdog') and [s['argv'][1:] for s in m['slots']]==[[case],[case,'fused-phase'],[case]]
    if role=='watchdog':assert m.get('safety_watchdog')
    ram=(cap/'ram.bin').read_bytes();ram_base=launch['ram_base']
    spaces,size=symtab(cap/'kernel.elf')['jnox_kernel::native_el0_mmu::SPACES']
    def data(pid,name):
        va,sz=symtab(apppaths[pid])[name];out=bytearray()
        while len(out)<sz:
            addr=va+len(out);page=spaces+pid*(size//len(apps))
            for shift in (30,21,12):
                entry=struct.unpack_from('<Q',ram,page-ram_base+8*((addr>>shift)&511))[0];assert entry&3==3
                page=entry&0xfffff000
            off=addr%4096; amount=min(sz-len(out),4096-off)
            start=page-ram_base+off; assert 0<=start<=len(ram)-amount
            out.extend(ram[start:start+amount])
        return bytes(out)
    def words(pid,name):return list(v[0] for v in struct.iter_unpack('<Q',data(pid,name)))
    exits=rows('NATIVE EL0 EXIT PID')
    out=dict(run=run.name,rev=m['commit'],case=case,role=role,policy=policy,kernel=m['kernel_elf_sha256'],exits=exits)
    if role=='loan':
        r=chunks(words(1,'loan_reads'),4)
        out.update(reads=r,final=signed(words(1,'loan_final_status')[0]),stale=signed(words(1,'loan_stale_status')[0]),full=signed(words(0,'loan_full_status')[0]),attempts=int.from_bytes(data(0,'loan_full_attempts'),'little'),state=rows('NATIVE LOAN STATE'),pages=rows('NATIVE LOAN PAGE'),maprows=rows('NATIVE LOAN MAP'))
        out['passed']=exits==[[0,73],[1,74]] and out['state']==[[8,8,0,2,0,0,34,0]] and all(row[1:]==[0,0,0] for row in out['pages']) and out['full']==-11 and out['stale']==-116 and out['final']==-32 and out['attempts']>=1 and [v[2] for v in r]==[8,11,14,17,20,23,26,29] and [v[3] for v in r]==[220,539,987,1564,2270,3105,4069,5162]
        return out
    q=rows('NATIVE QUAL ROW'); freq,attempt,kept,loss=rows('NATIVE QUAL COUNTS')[0];ev=rows('NATIVE SAFETY EVENT')
    assert freq==62500000 and len(q)==kept==attempt-loss and all(i==r[0] and len(r)==13 for i,r in enumerate(q))
    safeloss=rows('NATIVE SAFETY DROPPED')[0][0]; fixedloss=rows('NATIVE FIXED DROPPED')[0][0]
    writes=[r for r in ev if r[0]==2];out.update(qual_loss=loss,safety_loss=safeloss,fixed_loss=fixedloss,writes=writes)
    if role=='watchdog':
        h=[words(pid,'wd_header') for pid in range(3)]; watchdog=[r for r in ev if r[0]==13];due=[r for r in watchdog if r[2]==4]; late=[r for r in ev if r[0]==5 and r[4]==3 and signed(r[5])==-110]
        sup=chunks(words(2,'wd_supervisor_rows'),13);irqs=[r for r in q if r[1]==3 and r[4]==30]
        due_irqs=[[r for r in irqs if r[2]<=v[6]<=r[11]] for v in due]
        low,sz=symtab(apppaths[1])['wd_compute_loop']
        out.update(headers=h,wd=watchdog,due=due,matched_irq=due_irqs,complete_late=late,supervisor=sup,pair=words(2,'wd_recovery_pair'),inj=words(1,'wd_injection'),loop=[low,low+sz],deadline_math=all(r[9]==r[8]+312501 for r in watchdog if r[2] in (2,3)))
        out['passed']=exits==[[0,71],[1,72],[2,73]] and all(v[-1]==0 for v in h) and not loss and not safeloss and out['deadline_math']
        return out
    h=[words(pid,'admission_header') for pid in range(3)];e=h[0][2];assert all(v[2:4]==[e,freq] for v in h)
    marks={tuple(r[2:6]):r for r in q if r[1]==1}
    def segments(pid,total):
        rowsout=[]
        for i in range(total):
            j,ph=(i//2,1+i%2) if pid==1 else (i,3); bit=1<<pid
            a,b,c=(marks[pid,j,ph,v] for v in (1,2,3))
            target=a[6]; assert a[6]==b[6]==c[6]==e+i*(156250 if pid==1 else 625000)
            nxt=next((v for v in q[c[0]+1:] if v[1]==1 and v[2]==pid),None)
            block=None
            if nxt and nxt[5]==1:
                block=next((v for v in q[nxt[0]+1:] if v[1]==2 and v[2]==62 and v[3]==nxt[8] and v[8]==pid),None)
            elif not nxt and i==total-1:
                block=next((v for v in q[c[0]+1:] if v[1]==2 and v[2]==22 and v[8]==pid),None)
            full=bool(block and block[6]&bit and not block[7]&bit)
            win=q[a[0]+1:b[0]]
            wait=next((v for v in win if v[1]==2 and v[2]==62 and v[8]==pid and v[6]&bit and not v[7]&bit),None)
            ready=next((v for v in win if v[1]==2 and not v[6]&bit and v[7]&bit),None)
            dispatch=next((v for v in win if v[1]==2 and v[9]==pid and v[8]!=pid and v[11]),None)
            rowsout.append(dict(job=j,phase=ph,target=target,lo=max(c[7],block[4] if full else c[7])-target,hi=block[5]-target if full else None,marks=[a[0],b[0],c[0]],block=block[0] if full else None,wait=wait[0] if wait else None,ready=ready[0] if ready else None,dispatch=dispatch[0] if dispatch else None,prewake=bool(wait and wait[5]<target and ready and dispatch)))
        return rowsout
    phase=segments(1,32);sender=segments(0,8)
    fused=[r for r in q if r[1]==4 and r[3]==63];ops=[r for r in ev if r[0]==5 and r[3]==63];completes=[r for r in ev if r[0]==10];checks=[r for r in ev if r[0]==12 and r[3]==1]
    assert len(fused)==len(ops)==64 and len(completes)==len(checks)==32
    for i,(dec,op) in enumerate(zip(fused,ops)):
        ph=phase[i//2]; assert q[ph['marks'][1]][7]<=dec[5]<=dec[7]<=q[ph['marks'][2]][7]
        assert dec[2:5]==op[2:5]==[1,63,(1,3)[i%2]] and dec[8]==op[5]==0 and dec[5]<=op[1]<=dec[7]
        if i%2: assert dec[5]<=completes[i//2][2]<=completes[i//2][3]<=dec[7]
        else: assert dec[5]<=checks[i//2][2]<=checks[i//2][1]<=dec[7]
    gaps=[[b[2]-a[3],b[3]-a[2]] for a,b in zip(completes,completes[1:])]
    sw=lambda t: None if any(r[2]<=t<r[3] for r in writes) else next((r[5] for r in reversed(writes) if r[3]<=t),0)
    sr=chunks(words(0,'admission_sender_rows'),10)[:words(0,'admission_sender_count')[0]]
    raw_frames=chunks(data(0,'admission_sender_bytes'),44)
    rx=[r for r in ev if r[0]==7];pub=[r for r in ev if r[0]==11]
    bytejoins=[any(s[6]==r[2] and s[8]==0 and raw_frames[k]==b''.join(x.to_bytes(8,'little') for x in r[4:])[:44] for k,s in enumerate(sr)) for r in rx]
    pubjoins=[any(s[6]==r[4] and s[8]==r[5] and (not r[6] or (s[4],s[5])==(r[8],r[9])) for s in sr) for r in pub]
    controller=chunks(words(1,'admission_controller_rows'),18)
    loans=[r for r in ev if r[0]==6];decisions=[r for r in ev if r[0]==5]
    rank_bad=[r[0] for r in q if r[1]==2 and r[7] and r[9]!=next(k for k in (1,0,2) if r[7]&(1<<k))]
    controls=[r for r in ev if r[0]==5 and signed(r[5])<0]
    grid=[r[11]-r[5] for r in q if r[1]==3 and r[4]==30 and r[11] and r[5]>=e and not (r[5]-e)%156250]
    out.update(headers=h,phases=phase,sender=sender,complete_gap=gaps,check_gap=[b[2]-a[2] for a,b in zip(checks,checks[1:])],check_service=[r[7]-r[5] for r in fused[::2]],complete_service=[r[7]-r[5] for r in fused[1::2]],entries=[r[2:5] for r in ops],max_grid_irq=max(grid,default=None),protected_complete=len(completes),pub=len(pub),pub_ok=sum(r[5]==0 for r in pub),rx=len(rx),rx_join=bytejoins,pub_join=pubjoins,controller=controller,commit_ok=sum(r[3]==60 and r[4]==2 and r[5]==0 for r in decisions),private_rejections=[signed(r[4]) for r in controller if r[3]==0 and r[4] not in (0,1<<63)],negative_protected=controls,loan_receive=collections.Counter(str(signed(r[4])) for r in loans if r[3]==35),output=[sw(e+18*62500),sw(e+37*62500)],overrun=words(1,'admission_overrun'),rank_bad=rank_bad,first_pair=sr[1][5]-sr[0][5])
    out['misses']=[i for i,r in enumerate(phase) if r['lo']>62500];out['unbounded']=[i for i,r in enumerate(phase) if r['hi'] is None]
    out['functional']=all(v[-1]==0 for v in h) and exits==[[0,71],[1,72],[2,73]] and not loss and not safeloss and not rank_bad and all(bytejoins+pubjoins) and out['protected_complete']==32
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);args=ap.parse_args()
    dest=args.root/'results';dest.mkdir(exist_ok=True);allrows=[]
    for run in sorted((args.root/'runs').iterdir()):
        v=analyze(args.root,run);allrows.append(v);print(run.name,v.get('functional',v.get('passed')),v.get('output'),v.get('misses'))
    save(dest/'boots.json',allrows)
