#!/usr/bin/env bash
set -euo pipefail
lane=/mnt/d/codex/permit389-hotpath-independent/lane.sh
old=c5e6a374a9cc8107bfadb25db9c71f8d0d1666e2
bash "$lane" prepare
bash "$lane" checkout "$old"
n=0
for policy in fifo rr; do for s in healthy overrun; do
  bash "$lane" build "$old" "$policy" "$s" fused
  n=$((n+1)); bash "$lane" boot "$old" "$policy" "$s" fused "$(printf %03d "$n")"
done; done
bash "$lane" ordinary-apps "$old"
for policy in fifo rr; do
  bash "$lane" build "$old" "$policy" ordinary loan
  n=$((n+1)); bash "$lane" boot "$old" "$policy" ordinary loan "$(printf %03d "$n")"
  for s in healthy sleep-late recover; do
     bash "$lane" build "$old" "$policy" "$s" watchdog
     n=$((n+1)); bash "$lane" boot "$old" "$policy" "$s" watchdog "$(printf %03d "$n")"
  done
done
