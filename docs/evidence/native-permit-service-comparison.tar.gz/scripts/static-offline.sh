#!/usr/bin/env bash
set -euo pipefail
root="$HOME/permit389-hotpath-independent"
for elf in "$root"/pkg/*-fused-*/kernel.elf;do
  name=$(basename "$(dirname "$elf")")
  python3 /mnt/d/codex/permit389-hotpath-independent/prologues.py "$elf" > "$root/sites/$name.disasm"
done
PYTHONDONTWRITEBYTECODE=1 python3 /mnt/d/codex/permit389-hotpath-independent/details.py "$root"
for file in "$root"/sites/*-fused-fifo-healthy.disasm;do
  awk '/ [tT] /{s=$0;print s} /sub[[:space:]]+sp|\[sp, #-/{print}' "$file"
done
