import collections,json,statistics,sys
from pathlib import Path
root=Path(sys.argv[1]); boots=json.loads((root/'results/boots.json').read_text())
groups=collections.defaultdict(list)
for b in boots:
    if 13<=int(b['run'][:3])<=44:groups[b['policy'],b['case'],b['rev'][:3]].append(b)
def calc(boots):
    def limits(data):return [min(data),max(data)]
    all_ph=[v for b in boots for v in b['phases']]
    close=sum(v['hi'] is not None for v in all_ph)
    iqs=[b['max_grid_irq'] for b in boots]
    vals=lambda i:[b['phases'][i] for b in boots]
    los=lambda vs:limits([v['lo'] for v in vs])
    his=lambda vs:limits([v['hi'] for v in vs if v['hi'] is not None])
    a0=vals(0)
    return dict(a0lo=los(a0),a0hi=his(a0),a0median=statistics.median(v['hi'] for v in a0),b0fail=sum(v['lo']>62500 for v in vals(1)),b0hi=his(vals(1)),a4lo=los(vals(8)),a4hi=his(vals(8)),phase_all_upper=his(all_ph)[1],phase_all_lower=los(all_ph)[1],fails=sum(v['lo']>62500 for v in all_ph),closed=close,unknown=sum(v['lo']<=62500 and (v['hi'] is None or v['hi']>62500) for v in all_ph),job_upper=max(156250+v['hi'] for v in all_ph if v['phase']==2 and v['hi'] is not None),sender_upper=max(v['hi'] for b in boots for v in b['sender'] if v['hi'] is not None),gap_upper=max(v[1] for b in boots for v in b['complete_gap']),check_gap=max(v for b in boots for v in b['check_gap']),irq=max(iqs),check0=limits([b['check_service'][0] for b in boots]),failed_prewake=sum(not v['prewake'] for v in all_ph),output=[b['output'] for b in boots],commit=[b['commit_ok'] for b in boots],fixed=limits([b['fixed_loss'] for b in boots]),overrun=[b['overrun'] for b in boots],protected=all(b['functional'] for b in boots))
out={'-'.join(k):calc(v) for k,v in groups.items()}
for k,v in out.items(): print(k,v)
(root/'results/summary.json').write_text(json.dumps(out,indent=1)+'\n')
for b in boots:
    if 45<=int(b['run'][:3])<=80 and b['role'] in ('fused','watchdog'):
        if b['role']=='fused':print(b['run'],b['output'],b['commit_ok'],b['private_rejections'],b['first_pair'])
        else:print(b['run'],b['passed'],[(v[6]-v[5],v[7]) for v in b['due']],len(b['complete_late']),b['pair'],b['headers'][2][-1])

