# Restore the original kernel, app and RAM files / 원본 ELF와 RAM 복원

UART, launch arguments, per-session file hashes, and timing CSVs are available immediately after the outer archive is extracted. GNU tar, xz, Python 3.10+ and GNU AArch64 binutils are used by the full replay. From the extracted directory run

```sh
tar -xJf binary-images.tar.xz
sha256sum -c SHA256SUMS
bash scripts/replay.sh .
```

The inner standard sparse tar contains all original ELF images and 80 terminal RAM dumps at their original relative paths. Identical files share hard links. The SHA-256 manifest checks every original file after expansion, including reconstructed sparse zero ranges. Replay regenerates the tables directly from UART and private RAM.

먼저 바깥 묶음을 풀면 UART와 시점별 CSV를 바로 볼 수 있다. 위 명령으로 내부 ELF와 RAM을 원래 위치에 복원하고 원래 파일 해시를 확인한 뒤 전체 데이터를 다시 판독한다.
