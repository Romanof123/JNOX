#!/usr/bin/env bash
set -euo pipefail
w=/mnt/d/codex/permit11-phase-first
export PYTHONDONTWRITEBYTECODE=1 LC_ALL=C
for v in 1 2; do
 if [[ $v = 1 ]]; then
  b=$HOME/permit11-phase-first
  r=1dfa7fa19593fb1cfcdbe6cbc6e2a5964d6616c8
  pub=81b21433dec95f49dfafa6e756b115d7f9db9999
 else
  b=$HOME/permit11-phase-first-v2
  r=9e14367907be90140acb509cc21f9cec55954e96
  pub=595bc751322da0ece3dc7d61d081c11b140b1bc5
 fi
 dest=$b/sealed-v$v
 mkdir -p "$dest"/{source,scripts}
 cd "$b/src"
 git cat-file commit "$r" > "$dest/source/$r.commit"
 git cat-file commit "$pub" > "$dest/source/$pub.commit"
 git ls-tree -r "$r" > "$dest/source/tree.txt"
 git archive --format=tar.gz -o "$dest/source/fixture.tar.gz" "$r" examples/native-safety-channel kernel/src/native_safety_channel.rs sdk/native-safety-channel tools/build_native_el0.py tools/native_el0_capture.py tools/ordinary_amc_capture.py
 test "$(git rev-parse "$r^{tree}")" = "$(git rev-parse "$pub^{tree}")"
 cp "$w"/{decode,score,offset,replay,report,archive,count0,calibrate,neighbors,v2}.py "$dest/scripts/"
 cp "$w"/{lane,lane2,first,seal}.sh "$dest/scripts/"
 cp "$b/packet/choices.log" "$dest/choices.log"
 if [[ $v = 1 ]]; then cp -r "$b/packet/rejected-cli-before-boot" "$dest/"; fi
 cd "$dest"
 python3 scripts/report.py .
 cp REPORT.en-ko.md "$w/REPORT-v$v.en-ko.md"
 find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
 tar --sort=name --mtime=@0 --owner=0 --group=0 --numeric-owner -cJf "$w/native-permit-phase-v$v.tar.xz" .
 mkdir -p "$b/replayed-v$v"
 cd "$b/replayed-v$v"
 tar -xJf "$w/native-permit-phase-v$v.tar.xz"
 sha256sum --quiet -c SHA256SUMS
 python3 scripts/replay.py . > "$w/detached-v$v.txt"
 wc -l "$w/detached-v$v.txt"
done
cd "$w"
sha256sum native-permit-phase-v{1,2}.tar.xz > evidence.sha256
cat evidence.sha256
