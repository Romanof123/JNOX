from pathlib import Path
import subprocess
import json
from offset import pair

work=Path(__file__).resolve().parent
runs=Path.home()/'permit11-phase-first/packet/runs'
for case in ('phase-decision','phase-complete'):
 for p in ('fifo','rr'):
  prefix=f'{p}-{case}-count'
  previous=runs/(prefix+'-first')
  leads=(0,0)
  choices=[]
  for step in range(1,13):
   errors=pair(previous)
   if not any(errors): break
   new=tuple(min(12500,max(0,i+e)) for i,e in zip(leads,errors[::2]))
   if new in choices: break
   choices.append(new)
   name=f'{prefix}-s{step:02d}'
   print(previous.name,leads,errors,'->',new,flush=True)
   subprocess.run(['bash',str(work/'lane.sh'),name,p,case,'count',*(f'{n:05d}' for n in new)],check=True)
   previous=runs/name
   leads=new
  print('selected',previous.name,leads,pair(previous),flush=True)
  for n in (2,3):
   subprocess.run(['bash',str(work/'lane.sh'),f'{prefix}-repeat{n}',p,case,'count',*(f'{i:05d}' for i in leads)],check=True)
