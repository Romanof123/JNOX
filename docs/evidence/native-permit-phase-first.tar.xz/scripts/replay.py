"""Re-create one capture at a time to verify original digests and score every run."""
from pathlib import Path
import hashlib
import json
import shutil
import sys
import tempfile
from decode import read_run
from score import score

def replay(root):
    for f in (root/'blobs').iterdir():
        if hashlib.sha256(f.read_bytes()).hexdigest()!=f.name: raise ValueError(f)
    with tempfile.TemporaryDirectory() as tmp:
        scratch=Path(tmp)
        (scratch/'apps').symlink_to((root/'apps').resolve(),target_is_directory=True)
        for original in sorted((root/'runs').iterdir()):
            run=scratch/original.name
            shutil.copytree(original,run)
            cap=run/'cap'
            for name,item in json.loads((run/'refs.json').read_text()).items():
                dest=cap/name
                if name=='ram.bin':
                    with dest.open('wb') as restored:
                        restored.truncate(item['size'])
                        for n,h in item['pages'].items():
                            restored.seek(4096*int(n))
                            restored.write((root/'blobs'/h).read_bytes())
                else: dest.symlink_to((root/'blobs'/item).resolve())
            d=read_run(scratch,run)
            if not all(d['provenance'].values()) or score(d)!=json.loads((run/'result.json').read_text()): raise ValueError(run)
            shutil.rmtree(run)
            print('verified',original.name)

if __name__=='__main__': replay(Path(sys.argv[1]).resolve())
