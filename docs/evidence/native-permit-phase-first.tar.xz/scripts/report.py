import collections
import json
from pathlib import Path
import sys

root=Path(sys.argv[1])
out=['# Closed-gate expiry and completion / 게이트 폐쇄 후 만료와 완료',
     '',
     'One Cortex-A72, one CPU, QEMU virt and a 62.5 MHz guest counter. The operating-clock and single-thread instruction-clock launches are scored separately. Each row is a distinct cold boot. A tick is 16 ns. The instruction-clock arm uses shift 0. The virtual ENABLE was enabled by real recovery before loss in the measured phase cases.',
     '',
     '단일 Cortex-A72 QEMU 가상 장치의 62.5 MHz 카운터로 각 콜드 부팅을 독립 판정했다. 실제 재무장으로 출력을 올린 뒤 게이트를 닫았다. 실행 클록과 고정 명령 클록을 구분한다. 한 틱은 16 ns이다.',
     '',
     'I is the third accepted wire issue scheduled by the sender. EVENT 7 and the accepted COMMIT occur later. T8=I+1,250,000−1 and T9=T8+312,500. Decision columns give site 3 COMPLETE and the next site 1 CHECK operands minus T8/T9. Retire intervals give both counter endpoints minus those same targets. A [0,1] or [−1,0] observation leaves the equality unresolved. Release upper uses actual requested release to observed final active-store readback. Gap upper covers every consecutive successful retire.',
     '',
     'I는 송신자가 정한 세 번째 허가의 발행 시각이다. 실제 전달·반영은 그 뒤였다. 판정 열은 i8 COMPLETE와 다음 i9 CHECK의 실제 피연산자 편차이고, 완료 열은 active 필드 저장 전후의 시각 편차이다. 구간이 0과 이웃 틱을 함께 포함하면 정확한 일치를 입증할 수 없다. 최대 간격은 전체 완료 쌍에 걸쳐 계산한다.',
     '',
     '|Boot / 부팅|Inputs / 인수|Decision Δ8,Δ9|Retire Δ8 / Δ9|25/5/30 ms upper (ticks)|Release upper|Max gap upper|Safety / scheduler drops|',
     '|---|---|---|---|---|---:|---:|---|']
def j(v): return json.dumps(v,separators=(',',':'))
controls=[]
for r in sorted((root/'runs').iterdir()):
    s=json.loads((r/'result.json').read_text())
    if 'legacy' in s:
        controls.append((r.name,s['legacy']))
        continue
    args=(r/'position').read_text().split()[4:]
    out.append('|'+ '|'.join([r.name,' '.join(args),j(s['decision']),j(s['retire_offsets']),j(s['upper25_5_30']),str(s['release_to_retire'][1]),str(s['max_retire_gap'][1]),f"{s['safety_loss'][0][0]} / {s['scheduler_loss'][0][0]}"])+'|')
out+=['','## Original selectors / 원래 시험','']
for name,s in controls:
    out.append(f"- {name} — next publication offsets {j(s['publications'])}, first latch operand minus D {j(s['latch_offsets'])}, output enabled before expiry {s['initial_enabled']}.")
out+=['','## Replay / 재검증','',
      'Run `python3 scripts/replay.py .` with aarch64-linux-gnu-nm installed. The replayer restores each complete guest RAM image from deduplicated pages, verifies the capture hashes, walks each role’s page tables, checks the three ELF hashes and rescores the original UART. Each result.json contains all decision site IDs, individual private decision samples, the actual arm/close/fault/fall timestamps, selected gaps and signed intervals. Each retire.dis locates the two counter reads around the real store and readback. ELF files and VM RAM contain the synthetic fixture. The packet includes no host-memory dump.',
      '',
      '재생기는 중복 제거한 가상 RAM 페이지를 복원하고 원본 캡처 해시와 ELF를 확인한다. 프로세스별 페이지 표를 따라 수신자 사설 시각과 프레임을 읽고 UART 판정을 반복한다. release 및 완료 간격과 실제 검출·차단·전체 응답의 상한은 개별적으로 확인해야 한다. 고정 클록의 일치는 실제 운용 스케줄링이나 물리 출력에 대한 보장이 아니다.']
(root/'REPORT.en-ko.md').write_text('\n'.join(out)+'\n')
