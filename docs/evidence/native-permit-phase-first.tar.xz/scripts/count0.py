"""Run the repository capture with the public single-thread instruction clock."""
import json
from pathlib import Path
import runpy
import sys

tool = Path(sys.argv.pop(1)).resolve()
if tool.name != 'native_el0_capture.py':
    raise SystemExit('expected native_el0_capture.py')
manifest = json.loads(Path(sys.argv[sys.argv.index('--manifest') + 1]).read_text())
case = manifest['slots'][0]['argv'][1]
if case not in {'phase', 'collision', 'phase-decision', 'phase-complete'}:
    raise SystemExit(f'unexpected scenario {case}')
sys.path.insert(0, str(tool.parent))
from ordinary_amc_capture import FLAGS

idx = FLAGS.index('-accel') + 1
assert FLAGS[idx] == 'tcg' and FLAGS[FLAGS.index('-smp') + 1] == '1' and '-icount' not in FLAGS
FLAGS[idx:idx+1] = ['tcg,thread=single', '-icount', 'shift=0,align=off,sleep=off']
sys.argv[0] = str(tool)
runpy.run_path(str(tool), run_name='__main__')
