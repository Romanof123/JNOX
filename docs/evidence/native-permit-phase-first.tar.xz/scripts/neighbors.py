from pathlib import Path
import subprocess
from offset import pair

scripts=Path(__file__).resolve().parent
runs=Path.home()/'permit11-phase-first/packet/runs'
for policy,base in [('fifo',(424,434)),('rr',(451,463))]:
 for step in (-1,1):
  a,b=base
  if policy=='fifo': b+=step
  else: a+=step
  subprocess.run(['bash',str(scripts/'lane.sh'),f'{policy}-phase-complete-count-neighbor{step:+}',policy,'phase-complete','count',f'{a:05}',f'{b:05}'],check=True)
for case in ('phase-decision','phase-complete'):
 for policy in ('fifo','rr'):
  prior=runs/f'{policy}-{case}-default-first'
  errors=pair(prior)
  leads=[min(12500,max(0,v)) for v in errors[::2]]
  for n in (1,2,3):
   subprocess.run(['bash',str(scripts/'lane.sh'),f'{policy}-{case}-default-selected{n}',policy,case,'default',*(f'{v:05}' for v in leads)],check=True)
