#!/usr/bin/env bash
set -eu
s=/mnt/d/codex/permit11-phase-first/lane.sh
bash "$s" init
for sc in phase collision phase-decision phase-complete; do
 for p in fifo rr; do
  for m in count default; do
   if [[ $sc != phase-* && $m = default ]]; then continue; fi
   echo "$p $sc $m"
   bash "$s" "$p-$sc-$m-first" "$p" "$sc" "$m" 00000 00000
  done
 done
done
