from pathlib import Path
import subprocess
from offset import pair

w=Path(__file__).resolve().parent
b=Path.home()/'permit11-phase-first-v2/packet'
def run(policy,mode,tag,leads,nops):
    name=f'{policy}-phase-complete-{mode}-{tag}'
    args=[name,policy,'phase-complete',mode,*(f'{n:05}' for n in leads),*(f'{n:02}' for n in nops)]
    subprocess.run(['bash',str(w/'lane2.sh'),*args],check=True)
    errors=pair(b/'runs'/name)
    print(name,leads,nops,errors,flush=True)
    return errors
for p in ('fifo','rr'):
    for mode in ('count','default'):
        run(p,mode,'first',(0,0),(0,0))
for p in ('fifo','rr'):
    leads=[0,0]
    nops=[0,0]
    err=pair(b/'runs'/f'{p}-phase-complete-count-first')
    for step in range(1,18):
        for i in (0,1):
            if err[i*2]==0 and err[2*i+1]!=0:
                nops[i]+=1
            leads[i]+=err[i*2]
        err=run(p,'count',f'cal{step:02}',leads,nops)
        if not any(err):
            for n in (2,3):
                assert not any(run(p,'count',f'repeat{n}',leads,nops))
            break
    else: raise ValueError(f'bounded effort reached for {p}')
