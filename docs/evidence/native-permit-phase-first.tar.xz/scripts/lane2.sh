#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:$PATH" LC_ALL=C TZ=UTC CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true
unset RUSTFLAGS CARGO_TARGET_DIR PYTHONPATH
for n in $(compgen -e JNOX_); do unset "$n"; done
b=$HOME/permit11-phase-first-v2
w=/mnt/d/codex/permit11-phase-first
p=$b/packet
r=9e14367907be90140acb509cc21f9cec55954e96
cd "$b/src"
if [[ $1 = init ]]; then
 git checkout -q --detach "$r"
 test "$(git rev-parse HEAD^{tree})" = 0d952fba1fbe920c4da167edbf4a61c9af9b6a9d
 mkdir -p "$p"/{apps,runs}
 for app in sender receiver supervisor; do
  sh sdk/native-aarch64/build-rust.sh "examples/native-safety-channel/$app/Cargo.toml" "$p/apps/$app.elf" > "$p/apps/$app.log" 2>&1
  aarch64-linux-gnu-readelf -hl "$p/apps/$app.elf" > "$p/apps/$app.readelf"
 done
 exit
fi
test "$(git rev-parse HEAD)" = "$r"
test -z "$(git status --porcelain --untracked-files=no)"
read -r tag pol sc mode a z n m <<< "$*"
d=$p/runs/$tag
mkdir "$d"
pkg=$b/packages/$pol-$sc-$a-$z-$n-$m
q=(); extra=(); wrap=()
[[ $pol != rr ]] || q=(--quantum-ticks 625000)
[[ $sc != phase-* ]] || extra=(--peer-arg "$a" --peer-arg "$z" --peer-arg "$n" --peer-arg "$m")
[[ $mode != count ]] || wrap=("$w/count0.py")
if [[ ! -f $pkg/manifest.json ]]; then
 (set -x; python3 tools/build_native_el0.py --out "$pkg" --board virt --policy "$pol" "${q[@]}" --elf "$p/apps/sender.elf" --peer-elf "$p/apps/receiver.elf" --peer-elf "$p/apps/supervisor.elf" --arg "$sc" --peer-arg "$sc" "${extra[@]}" --peer2-arg "$sc" --priority 7 --peer-priority 6 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --safety-channel --loan-route 0:1 --safety-boundary) > "$d/build.log" 2>&1
fi
cp "$pkg/manifest.json" "$d/"
cp "$pkg/build.log" "$d/kernel-build.log"
printf '%s\n' "$*" > "$d/position"
test -z "$(pgrep -x qemu-system-aar || true)"
(set -x; python3 "${wrap[@]}" tools/native_el0_capture.py "$d/cap" "$pkg/kernel.elf" "$p/apps/sender.elf" examples/native-safety-channel/sender/src/main.rs "$r" --manifest "$pkg/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608) > "$d/capture.log" 2>&1
