import struct
import zlib

def score(a):
    e=a['events']
    def rows(k): return [r for r in e if r[0]==k]
    close=[v for v in rows(4) if v[4]==3]
    det=rows(3)
    edges=rows(2)
    safe=[r for r in edges if r[4:6]==[1,0]]
    acts=a['activations']
    comp=rows(10)
    instr=rows(16)
    checks=rows(12)
    hz=a['receiver_header'][3]
    issue=a['received_rows'][2][17]
    D=issue+hz*20//1000
    H=hz*5//1000
    out=dict(issue=issue,deadline=D,period=H,sites=[r[3] for r in checks],safety_loss=a['safety_loss'],scheduler_loss=a['fixed_loss'],protected_transitions=edges)
    joins=[]
    for k,r in enumerate(a['received_rows']):
        wire=bytes.fromhex(a['received_bytes'][k])
        matching=[j for j,s in enumerate(a['sender_rows']) if s[8]==r[2] and s[9:11]==[0,0]]
        reads=[v for v in rows(7) if v[2]==r[2]]
        joins.append(len(matching)==len(reads)==1 and a['sender_bytes'][matching[0]]==wire.hex() and b''.join(q.to_bytes(8,'little') for q in reads[0][4:])[:44]==wire and zlib.crc32(wire[:40])==int.from_bytes(wire[40:],'little'))
    out.update(joins=joins,private_control=a['exact_control'],exits=a['exits'],terminal=a['terminal'],
               delivery_delta=rows(7)[2][1]-issue,commit_delta=a['received_rows'][2][8]-issue)
    if not instr:
        out['legacy']=dict(publications=[[v[2]-D,v[3]-D] for v in rows(11) if v[8]==4],latch_offsets=[v[2]-D for v in det],nearby_checks=[[r[3],r[2]-D,r[7:9]] for r in checks if -H<r[2]-D<=2*H],close=close,initial_enabled=any(r[4:6]==[0,1] and r[3]<det[0][2] for r in edges),last_receive=a['received_rows'][-1])
        return out
    assert hz==62500000 and len(acts)==len(comp)==len(instr) and all(v[4]==0 for v in comp)
    assert all(r[8:]==[1,0] for r in instr) and all(0<=r[2]<=r[3]<=r[1] for r in instr)
    eight,nine=instr[8:10]
    i,j=e.index(eight),e.index(nine)
    f=[r for r in e[:i] if r[0]==12][-1]
    between=[r for r in e[i:j] if r[0]==12]
    g=between[0]
    assert [v[3] for v in between]==[1,3] and f[3]==3
    first=D-1
    second=first+H
    decision=[f[2]-first,g[2]-second]
    retires=[[v[t]-target for t in (2,3)] for v,target in ((eight,first),(nine,second))]
    gate=close[0]
    lat=det[0]
    off=safe[0]
    bounds=[lat[1]-gate[2],off[3]-lat[2],off[3]-gate[2]]
    gap=[max(v[2]-u[3] for u,v in zip(instr,instr[1:])),max(v[3]-u[2] for u,v in zip(instr,instr[1:]))]
    samples=a['phase_samples']
    releases=[r[0] for r in acts]
    releases[8:10]=[r[3] for r in samples]
    release_bounds=[max(v[t]-rel for v,rel in zip(instr,releases)) for t in (2,3)]
    checks_ok=(len(close)==len(safe)==len(det)==1 and len(edges)==2 and edges[0][4:6]==[0,1]
        and edges[0][3]<gate[2]<=gate[3]<lat[2]<=lat[1]<=off[2]
        and not any(r[1]>=gate[2] for r in rows(7)) and len(rows(7))==3
        and any(r[2:5]==[0,33,(1<<64)-32] and r[1]>gate[3] for r in rows(9))
        and a['sender_rows'][3][9]==(1<<64)-32 and a['terminal']==0 and gate[5:8]==[1,3,issue]
        and a['received_rows'][2][5:7]==[0,0] and a['received_rows'][2][16:19]==[3,issue,1]
        and any(r[3:9]==[3,1,0,0,3,2] and r[11:15]==[3,3,issue,issue] for r in a['supervisor_rows']))
    assert all(x[1:4]==a['receiver_header'][1:4] for x in (a['sender_header'],a['supervisor_header']))
    assert a['exits']==[[0,71],[1,72],[2,73]] and a['safety_loss']==[[0]]
    assert all(r[4:7]==[1,3,issue] and r[9]==0 for r in (f,g))
    assert all([r[4],r[5],r[6]]==[1,3,issue] for r in (eight,nine))
    assert all(r[0]==i and r[1]-r[2]==r[3] and r[3]<=r[4]<=r[5]<r[7]<r[9] for i,r in enumerate(samples,8))
    out.update(decision=decision,decision_pair=[f,g],retire_offsets=retires,retire_pair=[eight,nine],
        private_nops=a.get('phase_nops'),app_headers=[a[k] for k in ('sender_header','receiver_header','supervisor_header')],
        intervening_checks=between,closed_gate=checks_ok,private=samples,close=gate,detect=lat,safe=off,
        upper25_5_30=bounds,budget_pass=[b<=m*hz//1000 for b,m in zip(bounds,(25,5,30))],
        release_to_retire=release_bounds,max_retire_gap=gap,selected_gap=[nine[2]-eight[3],nine[3]-eight[2]],
        exact_decision=decision==[0,0] and f[7:9]==[0,0] and g[7:9]==[0,1] and not any(r[0]==12 for r in e[e.index(f)+1:e.index(g)]),
        exact_retire=retires==[[0,0],[0,0]] and eight[7]==0 and nine[7]==1 and g[7:9]==[0,1])
    return out
