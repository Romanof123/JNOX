"""Store unique guest RAM pages and ELF blobs. Preserve complete session hash verification."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
from decode import read_run, symtab
from score import score
import subprocess

def blob(root,data):
    h=hashlib.sha256(data).hexdigest()
    p=root/'blobs'/h
    if not p.exists(): p.write_bytes(data)
    return h

def main(src,dst):
    dst.mkdir(exist_ok=True)
    (dst/'blobs').mkdir(exist_ok=True)
    (dst/'runs').mkdir(exist_ok=True)
    (dst/'apps').mkdir(exist_ok=True)
    for app in (src/'apps').iterdir(): shutil.copy2(app,dst/'apps'/app.name)
    for run in sorted((src/'runs').iterdir()):
        d=dst/'runs'/run.name
        d.mkdir(exist_ok=True)
        facts=read_run(src,run)
        if not all(facts['provenance'].values()): raise ValueError((run.name,facts['provenance']))
        out=score(facts)
        if not all(out['joins']): raise ValueError((run.name,'CRC/handle mismatch'))
        if 'closed_gate' in out and not out['closed_gate']: raise ValueError((run.name,'gate chronology'))
        for f in ('manifest.json','position','kernel-build.log','capture.log','build.log'):
            if (run/f).exists(): shutil.copy2(run/f,d/f)
        cap=d/'cap'
        cap.mkdir(exist_ok=True)
        refs={}
        for f in (run/'cap').iterdir():
            if f.name=='ram.bin':
                data=f.read_bytes()
                pages={}
                for index in range(0,len(data),4096):
                    page=data[index:index+4096]
                    if page!=bytes(4096): pages[index//4096]=blob(dst,page)
                refs['ram.bin']={'size':len(data),'pages':pages}
            elif f.name in ('kernel.elf','user.elf','probe.c'):
                refs[f.name]=blob(dst,f.read_bytes())
            elif f.is_file(): shutil.copy2(f,cap/f.name)
        (d/'refs.json').write_text(json.dumps(refs,sort_keys=True))
        if 'retire_offsets' in out:
            elf=run/'cap/kernel.elf'
            symbol='jnox_kernel::native_el0::safety::Session::retire_boundary_activation'
            start,length=symtab(elf)[symbol]
            dis=subprocess.check_output(['aarch64-linux-gnu-objdump','-d','-C',f'--start-address={start}',f'--stop-address={start+length}',str(elf)],text=True)
            (d/'retire.dis').write_text(dis[dis.index('Disassembly of'):])
        (d/'result.json').write_text(json.dumps(out,sort_keys=True,indent=1)+'\n')

if __name__=='__main__': main(*map(Path,sys.argv[1:]))
