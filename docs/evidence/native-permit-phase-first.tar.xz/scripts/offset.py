from pathlib import Path
import sys

def events(run):
    return [list(map(int,line.split()[3:])) for line in (run/'cap/uart.bin').read_text().splitlines() if line.startswith('NATIVE SAFETY EVENT ')]

def pair(run):
    e=events(run)
    retires=[(i,row) for i,row in enumerate(e) if row[0]==16]
    t= retires[8][1][6]+1250000-1
    if 'phase-decision' in run.name:
        i,j=retires[8][0],retires[9][0]
        first=[r for r in e[:i] if r[0]==12][-1]
        second=[r for r in e[i:j] if r[0]==12][0]
        assert (first[3],second[3])==(3,1)
        return [first[2]-t]*2+[second[2]-t-312500]*2
    return [ret[i]-t-k*312500 for k,(_,ret) in enumerate(retires[8:10]) for i in (2,3)]

if __name__=='__main__':
    for s in sys.argv[1:]:
        d=Path(s)
        if d.is_dir() and (d/'cap/session.json').exists() and ('phase-decision' in d.name or 'phase-complete' in d.name):
            print(d.name,*pair(d))
