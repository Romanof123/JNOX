# Closed-gate expiry and completion / 게이트 폐쇄 후 만료와 완료

One Cortex-A72, one CPU, QEMU virt and a 62.5 MHz guest counter. The operating-clock and single-thread instruction-clock launches are scored separately. Each row is a distinct cold boot. A tick is 16 ns. The instruction-clock arm uses shift 0. The virtual ENABLE was enabled by real recovery before loss in the measured phase cases.

단일 Cortex-A72 QEMU 가상 장치의 62.5 MHz 카운터로 각 콜드 부팅을 독립 판정했다. 실제 재무장으로 출력을 올린 뒤 게이트를 닫았다. 실행 클록과 고정 명령 클록을 구분한다. 한 틱은 16 ns이다.

I is the third accepted wire issue scheduled by the sender. EVENT 7 and the accepted COMMIT occur later. T8=I+1,250,000−1 and T9=T8+312,500. Decision columns give site 3 COMPLETE and the next site 1 CHECK operands minus T8/T9. Retire intervals give both counter endpoints minus those same targets. A [0,1] or [−1,0] observation leaves the equality unresolved. Release upper uses actual requested release to observed final active-store readback. Gap upper covers every consecutive successful retire.

I는 송신자가 정한 세 번째 허가의 발행 시각이다. 실제 전달·반영은 그 뒤였다. 판정 열은 i8 COMPLETE와 다음 i9 CHECK의 실제 피연산자 편차이고, 완료 열은 active 필드 저장 전후의 시각 편차이다. 구간이 0과 이웃 틱을 함께 포함하면 정확한 일치를 입증할 수 없다. 최대 간격은 전체 완료 쌍에 걸쳐 계산한다.

|Boot / 부팅|Inputs / 인수|Decision Δ8,Δ9|Retire Δ8 / Δ9|25/5/30 ms upper (ticks)|Release upper|Max gap upper|Safety / scheduler drops|
|---|---|---|---|---|---:|---:|---|
|fifo-phase-complete-count-first|00000 00000|[426,134]|[[435,436],[421,422]]|[1185864,10,1185869]|1341|313292|0 / 236|
|fifo-phase-complete-count-neighbor+1|00424 00435|[-11,-301]|[[0,0],[-1,0]]|[1497928,10,1497933]|1341|313292|0 / 236|
|fifo-phase-complete-count-neighbor-1|00424 00433|[-11,-299]|[[0,0],[1,2]]|[1497930,10,1497935]|1341|313292|0 / 236|
|fifo-phase-complete-count-repeat2|00424 00434|[-11,-300]|[[0,0],[0,1]]|[1497929,10,1497934]|1341|313292|0 / 236|
|fifo-phase-complete-count-repeat3|00424 00434|[-11,-300]|[[0,0],[0,1]]|[1497929,10,1497934]|1341|313292|0 / 236|
|fifo-phase-complete-count-s01|00435 00421|[-22,-287]|[[-11,-11],[13,14]]|[1497942,10,1497947]|1341|313292|0 / 236|
|fifo-phase-complete-count-s02|00424 00434|[-11,-300]|[[0,0],[0,1]]|[1497929,10,1497934]|1341|313292|0 / 236|
|fifo-phase-complete-default-first|00000 00000|[12213,7373]|[[12388,12392],[15165,15169]]|[1160189,1170,1160376]|153805|327344|0 / 234|
|fifo-phase-complete-default-selected1|12388 12500|[352,-4180]|[[1898,1903],[3347,3352]]|[1159663,1487,1159896]|161649|324434|0 / 233|
|fifo-phase-complete-default-selected2|12388 12500|[479,-3765]|[[2013,2018],[2931,2936]]|[1158548,1481,1158793]|152796|330817|0 / 233|
|fifo-phase-complete-default-selected3|12388 12500|[-4705,-2654]|[[-4667,-4663],[7312,7317]]|[1456681,1936,1456980]|156984|332136|0 / 233|
|fifo-phase-decision-count-first|00000 00000|[425,134]|[[434,435],[421,422]]|[1185863,10,1185868]|1341|313293|0 / 236|
|fifo-phase-decision-count-repeat2|00412 00134|[0,0]|[[11,11],[300,301]]|[1498229,10,1498234]|1341|313293|0 / 236|
|fifo-phase-decision-count-repeat3|00412 00134|[0,0]|[[11,11],[300,301]]|[1498229,10,1498234]|1341|313293|0 / 236|
|fifo-phase-decision-count-s01|00425 00134|[-13,0]|[[-2,-2],[300,301]]|[1498229,10,1498234]|1341|313293|0 / 236|
|fifo-phase-decision-count-s02|00412 00134|[0,0]|[[11,11],[300,301]]|[1498229,10,1498234]|1341|313293|0 / 236|
|fifo-phase-decision-default-first|00000 00000|[14901,8738]|[[15134,15139],[13451,13456]]|[1157901,1414,1158134]|158818|323072|0 / 234|
|fifo-phase-decision-default-selected1|12500 08738|[3994,-424]|[[5359,5364],[7244,7250]]|[1157789,1300,1158038]|165001|323126|0 / 234|
|fifo-phase-decision-default-selected2|12500 08738|[5792,-2776]|[[7075,7080],[1805,1808]]|[1162557,1227,1162796]|183155|327280|0 / 234|
|fifo-phase-decision-default-selected3|12500 08738|[7986,-126]|[[8182,8186],[4666,4672]]|[1152978,1544,1153237]|173192|324702|0 / 234|
|rr-phase-complete-count-first|00000 00000|[454,141]|[[463,463],[450,450]]|[1185783,10,1185788]|1393|313316|0 / 235|
|rr-phase-complete-count-neighbor+1|00452 00463|[-11,-322]|[[-1,0],[0,0]]|[1497820,10,1497825]|1393|313316|0 / 235|
|rr-phase-complete-count-neighbor-1|00450 00463|[-9,-322]|[[1,2],[0,0]]|[1497820,10,1497825]|1393|313316|0 / 235|
|rr-phase-complete-count-repeat2|00451 00463|[-10,-322]|[[0,1],[0,0]]|[1497820,10,1497825]|1393|313316|0 / 235|
|rr-phase-complete-count-repeat3|00451 00463|[-10,-322]|[[0,1],[0,0]]|[1497820,10,1497825]|1393|313316|0 / 235|
|rr-phase-complete-count-s01|00463 00450|[-22,-309]|[[-12,-11],[13,13]]|[1497833,10,1497838]|1393|313316|0 / 235|
|rr-phase-complete-count-s02|00451 00463|[-10,-322]|[[0,1],[0,0]]|[1497820,10,1497825]|1393|313316|0 / 235|
|rr-phase-complete-default-first|00000 00000|[12980,7292]|[[13177,13181],[13289,13295]]|[1164155,1222,1164368]|143920|329235|0 / 234|
|rr-phase-complete-default-selected1|12500 12500|[-847,-5042]|[[-805,-801],[4035,4040]]|[1459615,1546,1459865]|173759|325881|0 / 234|
|rr-phase-complete-default-selected2|12500 12500|[2513,362]|[[3836,3841],[6451,6456]]|[1157798,1275,1158065]|170171|327111|0 / 234|
|rr-phase-complete-default-selected3|12500 12500|[-1251,-5227]|[[-1199,-1195],[1994,1998]]|[1464310,1414,1464562]|167243|322959|0 / 234|
|rr-phase-decision-count-first|00000 00000|[454,141]|[[463,463],[450,450]]|[1185782,10,1185787]|1393|313316|0 / 235|
|rr-phase-decision-count-repeat2|00441 00141|[0,0]|[[10,11],[322,322]]|[1498141,10,1498146]|1393|313316|0 / 235|
|rr-phase-decision-count-repeat3|00441 00141|[0,0]|[[10,11],[322,322]]|[1498141,10,1498146]|1393|313316|0 / 235|
|rr-phase-decision-count-s01|00454 00141|[-13,0]|[[-3,-2],[322,322]]|[1498141,10,1498146]|1393|313316|0 / 235|
|rr-phase-decision-count-s02|00441 00141|[0,0]|[[10,11],[322,322]]|[1498141,10,1498146]|1393|313316|0 / 235|
|rr-phase-decision-default-first|00000 00000|[14280,7473]|[[14462,14466],[10806,10811]]|[1161556,1201,1161761]|162646|335559|0 / 233|
|rr-phase-decision-default-selected1|12500 07473|[-103,3210]|[[-66,-61],[11110,11115]]|[1472924,1596,1473185]|203723|323681|0 / 234|
|rr-phase-decision-default-selected2|12500 07473|[-1756,977]|[[-1723,-1719],[9853,9858]]|[1443813,1706,1444104]|164141|326553|0 / 234|
|rr-phase-decision-default-selected3|12500 07473|[6191,416]|[[7222,7227],[6157,6162]]|[1147833,995,1148033]|173276|334546|0 / 234|

## Original selectors / 원래 시험

- fifo-collision-count-first — next publication offsets [[517,650]], first latch operand minus D [1045], output enabled before expiry False.
- fifo-phase-count-first — next publication offsets [], first latch operand minus D [133], output enabled before expiry True.
- rr-collision-count-first — next publication offsets [[531,664]], first latch operand minus D [1082], output enabled before expiry False.
- rr-phase-count-first — next publication offsets [], first latch operand minus D [140], output enabled before expiry True.

## Replay / 재검증

Run `python3 scripts/replay.py .` with aarch64-linux-gnu-nm installed. The replayer restores each complete guest RAM image from deduplicated pages, verifies the capture hashes, walks each role’s page tables, checks the three ELF hashes and rescores the original UART. Each result.json contains all decision site IDs, individual private decision samples, the actual arm/close/fault/fall timestamps, selected gaps and signed intervals. Each retire.dis locates the two counter reads around the real store and readback. ELF files and VM RAM contain the synthetic fixture. The packet includes no host-memory dump.

재생기는 중복 제거한 가상 RAM 페이지를 복원하고 원본 캡처 해시와 ELF를 확인한다. 프로세스별 페이지 표를 따라 수신자 사설 시각과 프레임을 읽고 UART 판정을 반복한다. release 및 완료 간격과 실제 검출·차단·전체 응답의 상한은 개별적으로 확인해야 한다. 고정 클록의 일치는 실제 운용 스케줄링이나 물리 출력에 대한 보장이 아니다.
