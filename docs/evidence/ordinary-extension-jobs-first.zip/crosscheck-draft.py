import json, re, struct, subprocess
from pathlib import Path
from elftools.elf.elffile import ELFFile
root=Path.home()/'jnox223-first'
ref=json.loads((Path.home()/'jnox223-iv/docs/evidence/evd-026.json').read_text())['independent_verifier']['rows']
for flavor in ('normal','legacy'):
    d=root/(flavor+'.capture')
    with (root/(flavor+'.elf')).open('rb') as stream:
        elf=ELFFile(stream)
        symbols={s.name:s['st_value'] for s in elf.get_section_by_name('.symtab').iter_symbols()}
        stack=next(v for k,v in symbols.items() if 'extension6STACKS' in k)
        if flavor=='normal':
            ro=elf.get_section_by_name('.rodata')
            arrays=[struct.unpack_from('<3Q',ro.data(),p-ro['sh_addr']) for p in [0x40204818,0x40204848]]
            assert arrays==[(18,23,21),(3300,3296,3304)]
    data=(d/'audit.bin').read_bytes()
    n,hz,o,q,e,f,w=struct.unpack_from('<7Q',data)
    assert n==9 and hz==62500000 and q==hz//10 and e==q//4 and f==q//2 and w==2
    rows=list(struct.iter_unpack('<25Q',data[56:]))
    tr=(d/'int.trace').read_text()
    irqs=[int(x,16) for x in re.findall(r'with ELR 0x([0-9a-f]+)',tr)]
    returns=[int(x,16) for x in re.findall(r'Exception return .* PC 0x([0-9a-f]+)',tr)]
    assert tr.count('Taking exception 5 [IRQ]')==len(irqs)==len(returns)==15
    saved={}; cursor=mailbox=produced=consumed=reserved=mon=progress=0
    if flavor=='normal': records=list(struct.iter_unpack('<5Q',(d/'trace.bin').read_bytes()))
    stats=[]
    for i,r in enumerate(rows):
        start=o+i*q
        if flavor=='normal':
            ready=1+2*bool(mailbox)+4*(not mailbox and produced<3)
            if i%3==2:
                job=0; x=arrays[1][mon]; reserved+=x; mon+=1; value=reserved; reason=7
            elif mailbox:
                job=1; x=mailbox; mailbox=0; consumed+=x; value=consumed; reason=6
            else:
                job=2; x=arrays[0][produced]; produced+=1; mailbox=x; value=produced; reason=0
            progress+=job!=0
            assert r[:10]==(i,ready,2 if job==2 else 255,17 if job==2 else 0,0 if job==2 else 255,reason,2 if job else 0,job,1,progress)
            assert records[i]==(i+1,job,x,value,mailbox)
        else:
            assert r[:10]==tuple(ref[i].values())[:10]
        job=r[7] if r[7]!=255 else 3
        name='ext_'+['reserved','fallback','nominee','idle'][job]
        if i%3!=2:
            assert r[23]==30 and r[10]==start+e<=r[11]<=r[15]
            vm='ext_eval_stopped' if flavor=='legacy' and i==4 else 'ext_eval_live'
            assert returns[cursor]==symbols[vm] and irqs[cursor]==r[12]
            assert symbols[vm+'_work']<=r[12]<symbols[vm+'_end']
            assert r[13]==stack+5*16384-848
            assert bool(r[14])==(vm=='ext_eval_live')
            cursor+=1
        else: assert r[10:15]==(0,)*5 and r[23]==255
        assert start<=r[15]<=r[17]<start+f and r[18]==start+q<=r[19]<r[18]+e and r[24]==30
        assert r[21]==stack+(job+1)*16384-848
        pc,work=saved.get(job,(symbols[name],0))
        assert returns[cursor]==r[16]==pc and irqs[cursor]==r[20] and symbols[name+'_work']<=r[20]<symbols[name+'_end']
        assert r[22]>work
        saved[job]=(r[20],r[22]); cursor+=1
        stats.append(dict(slot=i,first=r[17]-start,irq_late=r[19]-r[18],service_ticks=r[19]-r[17],decision=r[5],job=job,frame=hex(r[21]),dispatch=hex(r[16]),interrupted=hex(r[20])))
    assert cursor==15
    print(flavor,json.dumps(stats))
