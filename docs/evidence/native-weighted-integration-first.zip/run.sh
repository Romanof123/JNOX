. /mnt/d/codex/jnox178-independent-0ad1/env.sh
python3 "$d/$1.py" "$2"
