import json,sys,os,subprocess,shutil
from pathlib import Path
b,rev,r=Path(sys.argv[1]),sys.argv[2],Path(sys.argv[3])
data=json.loads(subprocess.check_output(['git','show','0ad1eda8fafdf45d948c3761af938cf18e68df80:docs/evidence/weighted-el1-compat-183.json']))
for key,v in data.items():
 t=b/'el1-target'
 out=b/rev/key
 out.mkdir()
 env=dict(os.environ,**v['selectors'],CARGO_TARGET_DIR=str(t))
 with (out/'build.log').open('w') as f:
  subprocess.run(v['args'],cwd=r/'kernel',env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 shutil.copyfile(next(t.rglob('release/jnox-kernel')),out/'kernel.elf')
 shutil.rmtree(t)
