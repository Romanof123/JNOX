import ast,base64,csv,hashlib,io,json,os,re,subprocess,sys,tarfile,zipfile
from pathlib import Path
d=Path(__file__).resolve().parent;r=Path.cwd();b=Path('/home/ywcho/iv178');e=r/'docs/evidence';h=lambda v:hashlib.sha256(v).hexdigest()
def cap(*a,**kw):return subprocess.check_output(a,**kw)
def git(*a):return cap('git',*a)
out={}
for n in ('native-weighted-first','native-weighted-irq-second','native-el0-startup-first','native-weighted-timer-first','native-weighted-timer-second','native-weighted-timer-third'):
 p=e/(n+'.zip');z=zipfile.ZipFile(p);m=z.read('SHA256SUMS') if 'SHA256SUMS' in z.namelist() else b'';assert z.testzip() is None
 for line in m.decode().splitlines():
  digest,k=line.split(None,1);assert h(z.read(k.lstrip('*').removeprefix('./')))==digest
 out[n]=[h(p.read_bytes()),h(m),len(m.splitlines())]
z=zipfile.ZipFile(e/'native-weighted-irq-second.zip')
a=d/'reference';a.mkdir(exist_ok=True)
for n in ('build.sh','capture.sh','remainder.sh','independent.py'):
 (a/n).write_bytes(z.read(n))
for p in (d/'windows').iterdir():
 if p.name=='fixture':continue
 (a/'first').mkdir(exist_ok=True);(a/'replay').mkdir(exist_ok=True)
 pp=a/'first'/p.name
 if not pp.exists():os.symlink(p/'raw',pp)
 (a/'replay'/(p.name+'.json')).write_bytes((p/'replay.stdout').read_bytes())
 (a/'replay'/(p.name+'.capture-digest')).write_bytes((d/(p.name+'.session-sha')).read_bytes())
(d/'independent.json').write_bytes(cap(sys.executable,str(a/'independent.py')))
out['archive_packages']={}
for app in ('weighted-share','weighted-wake','startup-probe'):
 manifest=json.loads(z.read('packages/'+app+'/manifest.json')); fresh=json.loads(next((d/'build').glob('0ad*/native/'+app+'/manifest.json')).read_bytes())
 assert manifest['source_sha256']==fresh['source_sha256']
 out['archive_packages'][app]={'inputs':fresh['source_sha256'],'compiler':fresh['compiler'],'linker':fresh['linker'],'rust':fresh['rust'],'cargo':fresh['cargo']}
def rows(ref):return list(csv.reader(git('show',ref+':trace/links.csv').decode().splitlines()))[1:]
m,hd=rows('HEAD^1'),rows('HEAD')
expect={('CHG-088','affects','REQ-'+x) for x in ('002','005','008','014','020','023')}
assert len(set(map(tuple,hd)))==len(hd) and set(map(tuple,hd))==set(map(tuple,m))|expect
out['graph']=[len(m),len(hd)];out['merge']=git('show','-s','--format=%H %P %T').decode().strip();out['merge_base']=git('merge-base','HEAD^1','HEAD^2').decode().strip()
s=subprocess.run([sys.executable,'tools/scheduling_evidence.py'],capture_output=True);out['scheduling_evidence_exit']=s.returncode;(d/'scheduling-evidence.txt').write_bytes(s.stdout+s.stderr)
(d/'combined.diff').write_bytes(git('diff','HEAD^1','HEAD','--','kernel','sdk','tools','trace'))
j=json.loads((e/'evd-049.json').read_bytes());ar=j['archive']; parts=[]
for n in ar['parts']:
 x=json.loads((e/n).read_bytes());v=base64.b64decode(x['base64']);assert h(v)==x['sha256'];parts.append(v)
raw=b''.join(parts);assert h(raw)==ar['sha256']
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:xz') as t:t.extractall(b/'control49',filter='data')
p=b/'control49/vr49-fresh';m=(p/'MANIFEST.sha256').read_bytes();assert h(m)==j['manifest_sha256']
for line in m.decode().splitlines():
 v,k=line.split('  ',1);assert h((p/k).read_bytes())==v
(d/'el1-independent.txt').write_bytes(cap(sys.executable,'-B','verify.py',cwd=p))
compat=json.loads((e/'weighted-el1-compat-183.json').read_bytes())
sys.path.insert(0,str(r/'tools'));from vruntime_observer import validate
out['el1']={}
for key,v in compat.items():
 for n,obs in v['archived_uart'].items():
  if n=='EVD-022':
   blob=json.loads((e/'evd-022.json').read_bytes())['harness_output'];uart=ast.literal_eval(re.search(r'UART \(\d+ bytes\) = (.+)',blob)[1]);assert validate(uart)
  else:
   files=[path for path in p.rglob('*') if path.is_file() and path.name.startswith('uart') and h(path.read_bytes())==obs['sha256']]
   assert files,n
   uart=files[0].read_bytes();args=[sys.executable,'tools/weighted_replay.py',str(files[0])]+(['--wake'] if 'wake' in key else [])+(['--diagnostic'] if 'trace' in key else [])
   (d/(n+'.replay')).write_bytes(cap(*args))
  assert h(uart)==obs['sha256'];out['el1'][n]=h(uart)
(d/'audit.json').write_text(json.dumps(out,indent=2))
