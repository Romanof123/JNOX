import hashlib,zipfile,json,sys,subprocess,os
from pathlib import Path
h=lambda b:hashlib.sha256(b).hexdigest()
d=Path(__file__).resolve().parent
name=sys.argv[1]
z=d/(name+'.zip')
assert h(z.read_bytes())==(d/(name+'.archive-sha')).read_text().strip()
with zipfile.ZipFile(z) as a:
 m=json.loads(a.read('members.json'))
 assert set(a.namelist())==set(m)|{'members.json'}
 for k,(size,digest) in m.items():
  data=a.read(k); assert len(data)==size and h(data)==digest
 dest=(d/'windows' if os.name=='nt' else Path('/home/ywcho/iv178/linux'))/name
 a.extractall(dest)
if name!='fixture':
 replay='native_el0_replay' if name.startswith('startup') else 'native_weighted_replay'
 pin=(d/(name+'.session-sha')).read_text().strip()
 assert h((dest/'raw/session.json').read_bytes())==pin
 p=subprocess.run([sys.executable,str(d/'tools'/(replay+'.py')),str(dest/'raw'),pin],capture_output=True)
 assert p.returncode==int((dest/'replay.exit').read_text())
 assert p.stdout.replace(b'\r\n',b'\n')==(dest/'replay.stdout').read_bytes()
 assert p.stderr.replace(b'\r\n',b'\n')==(dest/'replay.stderr').read_bytes()
print('PASS',name,len(m))
