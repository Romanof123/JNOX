. /mnt/d/codex/jnox178-independent-0ad1/env.sh
mkdir -p "$b" "$d/build"
for id in af952e34cea8fbe0aef5c7b4cb1f945a2884fff5 a941dcad57d5fb2aa7f2853cfa8d7ef0df72d308 0ad1eda8fafdf45d948c3761af938cf18e68df80; do
if test -d "$b/$id/native"; then continue; fi
git checkout -q --detach "$id"
mkdir -p "$b/$id"
for app in weighted-share weighted-wake startup-probe; do
if test "$id" = a941dcad57d5fb2aa7f2853cfa8d7ef0df72d308 && test "$app" != startup-probe; then continue; fi
if test "$id" = a941dcad57d5fb2aa7f2853cfa8d7ef0df72d308; then python3 tools/build_native_el0.py --out "$b/pkg/$app"; else python3 tools/build_native_el0.py --out "$b/pkg/$app" --app "$app"; fi
done
mv "$b/pkg" "$b/$id/native"
if test "$id" != af952e34cea8fbe0aef5c7b4cb1f945a2884fff5; then
python3 "$d/el1.py" "$b" "$id" "$r"
fi
done
