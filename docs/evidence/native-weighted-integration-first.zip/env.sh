set -eu
export RUSTUP_HOME=/home/ywcho/jnox-169-first-e203caa/rustup CARGO_HOME=/home/ywcho/jnox-169-first-e203caa/cargo
export PATH="$CARGO_HOME/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.95.0 CARGO_BUILD_JOBS=1 PYTHONPATH=/home/ywcho/jnox-169-first-e203caa/deps
r=/home/ywcho/jnox178-iv-combined
b=/home/ywcho/iv178
d=/mnt/d/codex/jnox178-independent-0ad1
cd "$r"
