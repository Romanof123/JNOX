import hashlib,zipfile,json,sys,subprocess,os
from pathlib import Path
import elftools
assert elftools.__version__=='0.32'
assert subprocess.check_output([sys.executable,'-c','import elftools;print(elftools.__version__)']).strip()==b'0.32'
h=lambda b:hashlib.sha256(b).hexdigest()
d=Path(__file__).resolve().parent;b=Path('/home/ywcho/iv178');r=Path.cwd()
rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert rev.startswith('0ad1eda')
name=sys.argv[1]; dest=b/'positions'/name; dest.mkdir(parents=True)
if name=='fixture':
 (dest/'test').write_text('cross-reader')
else:
 arm,clock=name.split('-'); startup=arm=='startup'
 app='startup-probe' if startup else 'weighted-'+arm
 pkg=b/rev/'native'/app
 tool='native_el0' if startup else 'native_weighted'
 source=r/'examples/portability'/('native_startup_probe.c' if startup else 'native_weighted_monitor.c')
 argv=[sys.executable,'tools/'+tool+'_capture.py']+([] if startup else [arm,clock])+[str(dest/'raw'),str(pkg/'kernel.elf'),str(pkg/'user.elf'),str(source),rev]
 def call(cmd,stem):
  (dest/(stem+'.command')).write_text(json.dumps(cmd))
  p=subprocess.run(cmd,capture_output=True)
  for suffix,data in [('stdout',p.stdout),('stderr',p.stderr),('exit',str(p.returncode).encode())]: (dest/(stem+'.'+suffix)).write_bytes(data)
 call(argv,'capture')
 pin=h((dest/'raw/session.json').read_bytes());(d/(name+'.session-sha')).write_text(pin+'\n')
 assert pin==(dest/'capture.stdout').read_text().strip()
 call([sys.executable,'tools/'+tool+'_replay.py',str(dest/'raw'),pin],'replay')
 for k in ('build.log','manifest.json'): (dest/k).write_bytes((pkg/k).read_bytes())
 for k in ('native_el0_capture','native_el0_replay','native_weighted_capture','native_weighted_replay','native_weighted_math','native_weighted_trace','ordinary_amc_capture','qemu_capture','native_weighted_timer','build_kernel','build_native_el0'):
  (dest/(k+'.py')).write_bytes((r/'tools'/(k+'.py')).read_bytes())
z=d/(name+'.zip')
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as a:
 m={}
 for p in sorted(dest.rglob('*')):
  if p.is_file():
   k=p.relative_to(dest).as_posix();data=p.read_bytes();a.writestr(k,data);m[k]=[len(data),h(data)]
 a.writestr('members.json',json.dumps(m))
(d/(name+'.archive-sha')).write_text(h(z.read_bytes())+'\n')
