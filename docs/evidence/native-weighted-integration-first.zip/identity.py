import io,json,hashlib,zipfile,subprocess,sys,os,shutil
from pathlib import Path
from elftools.elf.elffile import ELFFile
h=lambda v:hashlib.sha256(v).hexdigest()
b=Path('/home/ywcho/iv178');d=Path(__file__).resolve().parent;r=Path.cwd()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
main=subprocess.check_output(['git','rev-parse','HEAD^1'],text=True).strip();ref='af952e34cea8fbe0aef5c7b4cb1f945a2884fff5'
z=zipfile.ZipFile('docs/evidence/native-weighted-irq-second.zip')
out={}
def elf(data):
 e=ELFFile(io.BytesIO(data));t=e.get_section_by_name('.text')
 return dict(sha=h(data),entry=e.header.e_entry,loads=[dict(s.header,sha=h(s.data())) for s in e.iter_segments() if s.header.p_type=='PT_LOAD'],text=[t.header.sh_addr,t.header.sh_size,h(t.data())],sections={s.name:h(s.data()) for s in e.iter_sections() if s.name})
for rev in [main,ref,head]:
 for path in (b/rev).rglob('*.elf'):
  if 'target' in path.parts:continue
  key=str(path.relative_to(b/rev)); dest=d/'build'/rev/key
  dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
  for log in ['build.log','manifest.json']:
   if (path.parent/log).exists():shutil.copyfile(path.parent/log,dest.parent/log)
  out.setdefault(key,{})[rev[:7]]=elf(path.read_bytes())
  for cmd,suffix in [(['aarch64-linux-gnu-readelf','-hlSW'],'.readelf'),(['aarch64-linux-gnu-objdump','-dC'],'.dis')]:
   with dest.with_suffix(suffix).open('w') as f:subprocess.run(cmd+[str(path)],stdout=f,check=True)
for app,n in [('weighted-share','share-default'),('weighted-wake','wake-default'),('startup-probe','startup-default')]:
 for k in ['kernel.elf','user.elf']:
  out['native/'+app+'/'+k]['archive']=elf(z.read('first/'+n+'/'+k))
for k,variants in out.items():
 print(k)
 for rev,v in variants.items(): print(rev,v['text'],[s['sha'][:15] for s in v['loads']])
(d/'binaries.json').write_text(json.dumps(out,indent=2))
