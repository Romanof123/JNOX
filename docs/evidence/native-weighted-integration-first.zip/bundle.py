import hashlib,json,sys,zipfile,os,subprocess
from pathlib import Path
d=Path(__file__).resolve().parent
h=lambda b:hashlib.sha256(b).hexdigest()
out=d/'integration-first-0ad1eda.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as a:
 files=[]
 for p in d.rglob('*'):
  rel=p.relative_to(d)
  if rel.parts[0] in ('tools','deps','windows') or rel.parts[:2] in [('reference','first'),('reference','replay')] or p==out or not p.is_file():continue
  files.append((rel.as_posix(),p.read_bytes()))
 files.append(('environment.txt',subprocess.check_output(['bash','-c','which python3 rustc cargo clang ld.lld qemu-system-aarch64; rustc -vV; cargo -V; clang --version; ld.lld --version; python3 -c "import elftools;print(elftools.__version__)"'])))
 for n,v in files:a.writestr(n,v)
 a.writestr('SHA256SUMS',''.join(h(v)+'  '+n+'\n' for n,v in files))
(d/'integration-first-0ad1eda.sha256').write_text(h(out.read_bytes())+'  '+out.name+'\n')
