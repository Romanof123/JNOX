"""Independently inspect retained RAM, external exceptions and the supplied replay reports."""
import hashlib
import json
import struct
import sys
from pathlib import Path
from elftools.elf.elffile import ELFFile

base = Path(__file__).resolve().parent
order = ["share-default", "wake-default", "share-icount3", "wake-icount3", "startup-default"]
reports = {}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for name in order:
    case = base / "first" / name
    record = json.loads((case / "session.json").read_bytes())
    expected = (base / "replay" / (name + ".capture-digest")).read_text().strip()
    assert digest(case / "session.json") == expected
    for filename, want in record["hashes"].items():
        assert digest(case / filename) == want
    scored = json.loads((base / "replay" / (name + ".json")).read_bytes())
    launch = json.loads((case / "launch.json").read_bytes())
    trace = (case / "exceptions.log").read_text()
    assert trace.startswith("Exception return from AArch64 EL1 to AArch64 EL0 PC 0x400000\n")
    counts = {key: trace.count(part) for key, part in
              (("EL0_returns", "Exception return"), ("IRQs", "[IRQ]"), ("SVCs", "[SVC]"))}
    info = dict(session_sha256=expected, kernel_sha256=launch["kernel_sha256"], user_sha256=launch["user_sha256"],
                raw_terminal=record["marker"], external_counts=counts)
    reports[name] = info
    if name == "startup-default":
        assert counts == {"EL0_returns": 2, "IRQs": 0, "SVCs": 2}
        assert (scored["entry"], scored["write_result"], scored["stdout_bytes"], scored["exit_status"]) == (0x400000, -38, 0, 37)
        info.update(entry=scored["entry"], write=scored["write_result"], errno=scored["final_symbols"]["__jnox_errno_location.initial_thread_errno"][0], stdout_bytes=0, exit_status=37)
        continue
    with (case / "kernel.elf").open("rb") as fp:
        sym = ELFFile(fp).get_section_by_name(".symtab").get_symbol_by_name("native_vruntime_journal")[0]
        offset = sym["st_value"] - launch["ram_base"]
        size = sym["st_size"]
    raw = (case / "ram.bin").read_bytes()
    rows = list(struct.iter_unpack("<16Q", raw[offset:offset+size]))
    head = rows[0]
    assert head[0] == 1 and head[1] == 3 and head[7:9] == (0, 0)
    assert head[3:5] == (62500000, 625000)
    rows = rows[1:1+head[6]]
    q = head[4]
    h, g = 5*q//4, q//4
    stops = [r for r in rows if r[0] == 3]
    irqs = [r for r in stops if r[4] == 0x480]
    assert len(irqs) == counts["IRQs"] and len(stops) == counts["EL0_returns"] == counts["IRQs"]+counts["SVCs"]
    assert all(r[8] == 30 and r[7] & 7 == 5 and r[1] >= r[6] for r in irqs)
    assert all(r[8] == 2**64-1 for r in stops if r[4] == 0x400)
    first_irq = irqs[0]
    assert first_irq[2:5] == (0, 1, 0x480)
    checks = []
    for i, r in enumerate(stops):
        assert r[13] == r[1]-r[5]
        gap = 0 if i == 0 else r[5]-stops[i-1][1]
        assert gap >= 0
        if gap > g or r[13] > h or (r[4] == 0x480 and r[6] == r[5]+q and r[13] < q):
            checks.append(dict(lease=i+1, gap=gap, elapsed=r[13]))
    info.update(first_irq=dict(iar=first_irq[8], control=first_irq[7], compare=first_irq[6], entry=first_irq[1], interrupted_pc=hex(first_irq[9])),
                frequency=head[3], quantum=q, H=h, G=g, journal_events=head[6], stop_checks=checks, replay_misses=scored["timing_misses"],
                exit_statuses=[r[4] for r in rows if r[0] == 4 and r[3] == 1], final_service=list(head[12:14]))
    assert sorted(info["exit_statuses"]) == [41,42]
    if name.startswith("share"):
        first = stops[:36]
        assert head[11] == len(first) == 36 and all(r[4] == 0x480 for r in first)
        misses = [{"closure":i, "discrepancy":2*r[14]-r[15]} for i,r in enumerate(first, 1) if not -h <= 2*r[14]-r[15] <= 2*h]
        a,b = first[-1][14:16]
        final_bound = a+b >= 36*q and abs(2*a-b)*36*q <= 2*h*(a+b)
        info.update(share=dict(closures=36, A=a, B=b, terminal_share_bound=final_bound, prefix_misses=misses,
                               excluded_tail_service=[head[12]-a,head[13]-b]))
        assert final_bound
    else:
        windows = []
        for n,r in enumerate(scored["wake_rounds"], 1):
            d,i,w,ret,lo,hi = [r[k] for k in ("target","irq","wake","return","sample_low","sample_high")]
            interval = [i-d, w-i, ret-w, hi-ret, hi-d]
            limits = [g,g,h+2*g,g,h+5*g]
            assert d<=i<=w<=ret<=lo<=hi and all(v<=bound for v,bound in zip(interval,limits))
            assert r["a_solo"] >= 3*q and r["full"] in [3,4] and r["intervening"] <= 1
            windows.append(dict(round=n, I_minus_D=interval[0],W_minus_I=interval[1],R_minus_W=interval[2],
                                S_high_minus_R=interval[3],S_high_minus_D=interval[4],S_low=lo,S_high=hi,
                                A_solo=r["a_solo"],A_full=r["full"],intervening_A=r["intervening"]))
        assert len(windows) == head[10] == 3
        info["wake_rounds"] = windows
    assert (bool(checks) or bool(info.get("share",{}).get("prefix_misses"))) == bool(scored["timing_misses"])
print(json.dumps(reports, indent=2))