set -eu
base=/mnt/d/codex/.jnox-work/next-fixed/weighted183-independent-b-receipt
cd "$base/src"
rev=$(git rev-parse HEAD)
arm=$1
clock=$2
target="$base/first/$arm-$clock"
if [ "$arm" = startup ]; then
    p="$base/packages/startup-probe"
    python3 tools/native_el0_capture.py "$target" "$p/kernel.elf" "$p/user.elf" examples/portability/native_startup_probe.c "$rev"
else
    p="$base/packages/weighted-$arm"
    python3 tools/native_weighted_capture.py "$arm" "$clock" "$target" "$p/kernel.elf" "$p/user.elf" examples/portability/native_weighted_monitor.c "$rev"
fi