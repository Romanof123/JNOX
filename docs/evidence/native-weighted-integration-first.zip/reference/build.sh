set -eu
base=/mnt/d/codex/.jnox-work/next-fixed/weighted183-independent-b-receipt
git clone --quiet --shared --no-checkout /mnt/d/codex/j-nox "$base/src"
git -C "$base/src" -c core.autocrlf=false checkout --quiet --detach af952e34cea8fbe0aef5c7b4cb1f945a2884fff5
git -C "$base/src" status --short
mkdir "$base/packages" "$base/first" "$base/replay"
cd "$base/src"
export RUSTUP_HOME=/home/ywcho/jnox-169-first-e203caa/rustup CARGO_HOME=/home/ywcho/jnox-169-first-e203caa/cargo
export PATH="$CARGO_HOME/bin:$PATH" CARGO_BUILD_JOBS=1
rustc +1.95.0 --version
for app in weighted-share weighted-wake startup-probe; do
    python3 tools/build_native_el0.py --out "$base/packages/$app" --app "$app"
done