set -u
base=/mnt/d/codex/.jnox-work/next-fixed/weighted183-independent-b-receipt
cd "$base/src"
export PYTHONPATH=/home/ywcho/jnox-169-first-e203caa/deps
for pos in share-default wake-default share-icount3 wake-icount3 startup-default; do
    arm=${pos%-*}
    clock=${pos#*-}
    if [ "$pos" != share-default ]; then
        bash "$base/capture.sh" "$arm" "$clock" >"$base/replay/$pos.capture-digest"
        echo "$pos capture $?"
    else
        echo e57ad789ca11fe342b83778a65b2d2e27fd05876fdc04d8731bbc8aa4762794d >"$base/replay/$pos.capture-digest"
    fi
    replay=native_weighted_replay
    if [ "$arm" = startup ]; then replay=native_el0_replay; fi
    python3 "tools/$replay.py" "$base/first/$pos" "$(cat "$base/replay/$pos.capture-digest")" >"$base/replay/$pos.json" 2>"$base/replay/$pos.stderr"
    code=$?
    echo "$code" >"$base/replay/$pos.exit"
    echo "$pos replay $code"
    cat "$base/replay/$pos.stderr"
done