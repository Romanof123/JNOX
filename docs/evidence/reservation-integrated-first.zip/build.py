from pathlib import Path
import os,subprocess as s,shutil,json,hashlib
d=Path(__file__).parent;idx={}
for app in ['aligned-wake','cbs-wake','aligned-saturated','cbs-saturated']:
 p=d/'images'/app;p.mkdir(parents=True);base={k:v for k,v in os.environ.items() if not k.startswith(('JNOX_','RUST','CARGO_'))}
 cfg=dict(JNOX_BOARD='virt',JNOX_PROFILE='reservation',JNOX_APP=app);base.update(cfg,CARGO_TARGET_DIR=str(p/'target'))
 argv=['cargo','+1.95.0','build','--release','--locked','-j1']
 with (p/'build.log').open('xb') as f:r=s.run(argv,cwd=d/'source/kernel',env=base,stdout=f,stderr=s.STDOUT)
 if r.returncode:raise SystemExit((app,r.returncode))
 elf=p/'kernel.elf';shutil.copy2(p/'target/aarch64-unknown-none/release/jnox-kernel',elf);fl='/mnt/d/'+elf.as_posix()[3:]
 for name,cmd in [('disassembly',['aarch64-linux-gnu-objdump','-dC']),('map',['readelf','-aW'])]:
  (p/name).write_bytes(s.check_output(['wsl','--',*cmd,fl]))
 idx[app]=dict(selectors=cfg,argv=argv,elf_sha256=hashlib.sha256(elf.read_bytes()).hexdigest(),compiler=s.check_output(['rustc','+1.95.0','-vV'],text=True))
(d/'builds.json').write_text(json.dumps(idx,indent=2))
