from pathlib import Path
import os,hashlib,json,subprocess as s,shutil,time
d=Path(__file__).parent;h=Path.home()/'jnox-172-68b4b4c';h.mkdir()
q=Path('/usr/bin/qemu-system-aarch64')
dig=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
order=['aligned-wake','cbs-wake','aligned-saturated','cbs-saturated']*2;trace=[False,True,True,False,True,False,False,True]
items=[]
for i,(app,tr) in enumerate(zip(order,trace),1):
 p=h/f'{i:02}-{app}';p.mkdir();f=p/'kernel.elf';shutil.copy2(d/'images'/app/'kernel.elf',f)
 argv=['timeout','15s',str(q),'-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','stdio','-kernel',str(f)]
 if tr:argv+=['-d','int','-D',str(p/'exceptions.log')]
 items.append(dict(position=i,app=app,trace=tr,argv=argv,elf=dig(f),path=str(p)))
freeze=dict(source='68b4b4c88bcb669133528ae7d845ee9468c9efc3',qemu=dig(q),version=s.check_output([q,'--version'],text=True),builds=json.loads((d/'builds.json').read_text()),tools={f:dig(d/f) for f in ['first.py','audit.py','ledger.py','replay.py']},plans=items)
(h/'freeze.json').write_text(json.dumps(freeze,indent=2));shutil.copy2(h/'freeze.json',d/'freeze.json')
for i in items:
 p=Path(i['path']);start=time.monotonic();i['start_utc']=time.time()
 with (p/'uart').open('xb') as uart,(p/'stderr').open('xb') as err:r=s.run(i['argv'],stdin=s.DEVNULL,stdout=uart,stderr=err,cwd=p)
 i.update(status=r.returncode,elapsed=time.monotonic()-start,uart=dig(p/'uart'))
 (p/'meta.json').write_text(json.dumps(i,indent=2));shutil.copytree(p,d/'raw'/p.name)
 print(p.name,(p/'uart').read_text().splitlines()[-2:],flush=True)
