from pathlib import Path
import json,traceback
from audit import compact,oracle
d=Path(__file__).parent;h=Path.home()/'jnox-172-68b4b4c'
for p in sorted(h.glob('[0-9]*')):
 if not (p/'meta.json').exists():continue
 m=json.loads((p/'meta.json').read_text());raw=(p/'uart').read_text().splitlines()
 try:
  assert raw[:3]==['JNOX M1 BOOT','JNOX M1 READY','RSRV RAW 3'] and raw[-1]=='RSRV END'
  rows=[list(map(int,l.split())) for l in raw[3:-1]];r=compact(p,m['app'],rows)
  r['terminal']=rows[-1];r['horizon_completed']=rows[-1][4]==0;r['records']=len(rows)
  r['periods']={}
  for g in r['grants']:
   i=g['owner'];key=f"{i}-{oracle(m['app'])[g['slot']]['alloc'][i][3]}";r['periods'].setdefault(key,[]).append([g['slot'],g['upper'],g['allocation_upper']])
 except Exception:r={'error':traceback.format_exc(),'terminal':raw[-2:]}
 (d/'raw'/p.name/'audit.json').write_text(json.dumps(r,indent=2));print(p.name,r.get('error',''),r['terminal'],r.get('flags'),len(r.get('grants',[])))
