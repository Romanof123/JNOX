#!/usr/bin/env bash
set -euo pipefail
shared=$(cd "$(dirname "$0")" && pwd)
previous=/mnt/d/codex/permit11-arrival-runs
lab="$HOME/permit403-integration"
[[ ! -e "$lab/launch.start.utc" ]]
mkdir -p "$shared/original" "$lab/component/"
cp "$previous"/{lane.sh,cold.py} "$shared/original/"
for file in lane.sh cold.py; do
    cmp "$previous/$file" "$shared/original/$file"
done
(cd "$shared/original" && sha256sum lane.sh cold.py) > "$shared/original.sha256"
git init -q "$lab/component/src"
realpath /mnt/d/codex/.jnox-work/policy-v1/.git/objects > "$lab/component/src/.git/objects/info/alternates"
git -C "$lab/component/src" sparse-checkout init --cone
git -C "$lab/component/src" cat-file -t 6c753cd
for file in "$shared"/{component.sh,launch.sh,original/lane.sh}; do bash -n "$file"; done
python3 - "$shared" <<'PY'
import ast, pathlib, sys
root = pathlib.Path(sys.argv[1])
for file in ('component_cold.py', 'original/cold.py'):
    ast.parse((root/file).read_text())
PY
cat "$shared/original.sha256"
