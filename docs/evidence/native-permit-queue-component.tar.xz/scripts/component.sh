#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:$PATH" LC_ALL=C TZ=UTC CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1
unset RUSTFLAGS CARGO_TARGET_DIR PYTHONPATH
for key in $(compgen -e JNOX_); do unset "$key"; done
shared=$(cd "$(dirname "$0")" && pwd)
lab="$HOME/permit403-integration/component"
packet="$lab/packet"
rev=$1
tree=$2
[[ $rev =~ ^[0-9a-f]{40}$ && $tree =~ ^[0-9a-f]{40}$ ]]
[[ ! -e "$packet" ]]
mkdir -p "$packet"/{scripts,apps,source,packages,runs,logs,verification}
cp "$shared"/{component.sh,component_cold.py,launch.sh} "$packet/scripts/"
areas=(arch boards examples kernel sdk services tools trace verification)
cd "$lab/src"
git sparse-checkout set "${areas[@]}"
git checkout -q --detach "$rev"
[[ $(git rev-parse HEAD) == "$rev" && $(git rev-parse 'HEAD^{tree}') == "$tree" && -z $(git status --short) ]]
git cat-file commit "$rev" > "$packet/source/$rev.commit"
git rev-parse HEAD 'HEAD^{tree}' > "$packet/source/revision"
git ls-tree -r "$rev" > "$packet/source/tree.txt"
git archive --format=tar "$rev" "${areas[@]}" > "$packet/source/production.tar"
{ date -u; uname -srm; rustc -Vv; cargo -V; clang --version; python3 -V; qemu-system-aarch64 --version; sha256sum "$(command -v qemu-system-aarch64)"; git --version; } > "$packet/logs/host.txt"
date -u +%FT%T.%NZ > "$packet/logs/app.start.utc"
(set -x; sh sdk/native-aarch64/build-rust.sh examples/native-permit-queue-contract/Cargo.toml "$packet/apps/queue-contract.elf") > "$packet/logs/app.build" 2>&1
date -u +%FT%T.%NZ > "$packet/logs/app.finish.utc"
(cd "$packet/apps" && sha256sum *.elf) > "$packet/apps/SHA256SUMS"
printf 'n\tclock\tpolicy\tcase\tpackage\tbuild_rc\tcapture_rc\tattempt\trevision\n' > "$packet/ledger.tsv"
n=0
for policy in fifo rr; do
    extra=()
    [[ $policy != rr ]] || extra+=(--quantum-ticks 625000)
    for case_name in before exact after; do
        n=$((n+1))
        package="$policy-$case_name"
        pkg="$packet/packages/$package"
        printf -v attempt '%03d-default-%s' "$n" "$package"
        run="$packet/runs/$attempt"
        mkdir "$run"
        date -u +%FT%T.%NZ > "$run/build.start.utc"
        buildrc=0
        (set -x; python3 tools/build_native_el0.py --out "$pkg" --board virt --policy "$policy" --elf "$packet/apps/queue-contract.elf" --arg "$case_name" --priority 7 "${extra[@]}") > "$packet/logs/$package.build" 2>&1 || buildrc=$?
        date -u +%FT%T.%NZ > "$run/build.finish.utc"
        printf '%s\n' "$buildrc" > "$run/build.status"
        caprc=unattempted
        if [[ $buildrc == 0 ]]; then
            cp "$pkg/manifest.json" "$run/"
            date -u +%FT%T.%NZ > "$run/start.utc"
            caprc=0
            (set -x; python3 "$packet/scripts/component_cold.py" "$pkg" "$run/cap" "$rev" "$policy" "$case_name") > "$run/capture.log" 2>&1 || caprc=$?
            date -u +%FT%T.%NZ > "$run/finish.utc"
        fi
        printf '%s\n' "$caprc" > "$run/capture.status"
        printf '%s\tdefault\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$n" "$policy" "$case_name" "$package" "$buildrc" "$caprc" "$attempt" "$rev" >> "$packet/ledger.tsv"
        printf '%s build=%s capture=%s\n' "$attempt" "$buildrc" "$caprc"
    done
done
