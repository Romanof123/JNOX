#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1 LC_ALL=C TZ=UTC
shared=$(cd "$(dirname "$0")" && pwd)
packet="$HOME/permit403-integration/component/packet"
checks=/mnt/d/codex/permit403-component-first
cp "$shared"/{seal.py,replay.sh,seal_component.sh} "$packet/scripts/"
cp "$checks"/{verify.py,read_capture.py,reference.py,provenance.py,boots.json,mutations.json,source-identity.json} "$packet/verification/"
for name in "$checks"/*.md; do
    if [[ -f "$name" ]]; then cp "$name" "$packet/verification/"; fi
done
rsync -aS --exclude target/ --exclude __pycache__/ "$packet/" "$shared/component/packet/"
python3 -B "$shared/seal.py" "$packet" "$shared"
