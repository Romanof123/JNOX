#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C TZ=UTC CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1
shared=$(cd "$(dirname "$0")" && pwd)
lab="$HOME/permit403-integration"
rev=$1
tree=$2
[[ $rev =~ ^[0-9a-f]{40}$ && $tree =~ ^[0-9a-f]{40}$ ]]
[[ $(git -C "$lab/component/src" rev-parse "$rev^{tree}") == "$tree" ]]
exec 7>"$lab/serial.lock"
flock -xn 7
[[ ! -e "$lab/launch.start.utc" && ! -e "$lab/arrivals/packet" && ! -e "$lab/component/packet" ]]
date -u +%FT%T.%NZ > "$lab/launch.start.utc"
for lane in component arrivals; do
    rc=0
    printf '%s %s starting\n' "$(date -u +%FT%T.%NZ)" "$lane"
    if [[ $lane == component ]]; then
        bash "$shared/component.sh" "$rev" "$tree" || rc=$?
    else
        # This points to the original runner and cold.py without substituting flags or calendar.
        LAB_ROOT="$lab/arrivals" bash "$shared/original/lane.sh" "$rev" "$tree" "$rev" || rc=$?
    fi
    printf '%s %s lane rc=%s\n' "$(date -u +%FT%T.%NZ)" "$lane" "$rc"
    printf '%s\n' "$rc" > "$lab/$lane.status"
    if [[ -d "$lab/$lane/packet" ]]; then
        mkdir -p "$shared/$lane/packet"
        rsync -aS --exclude target/ --exclude __pycache__/ "$lab/$lane/packet/" "$shared/$lane/packet/"
        date -u +%FT%T.%NZ > "$shared/$lane/copied.utc"
    fi
done
date -u +%FT%T.%NZ > "$lab/launch.finish.utc"
