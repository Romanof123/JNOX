"""Write a deduplicated GNU sparse archive, extract into an empty directory and replay it."""
from hashlib import sha256
import os
from pathlib import Path
import shutil
import subprocess
import sys

packet, output = map(lambda name: Path(name).resolve(),sys.argv[1:3])
lane = packet.parent.name
work = packet.parent / "offline-seal"
work.mkdir()
stage, extracted = work / "stage", work / "extracted"
stage.mkdir()
extracted.mkdir()
known = {}
checksums = []
def sha(path):
    return sha256(path.read_bytes()).hexdigest()
for src in sorted(packet.rglob("*")):
    relative = src.relative_to(packet)
    if "target" in relative.parts or "__pycache__" in relative.parts or not src.is_file():
        continue
    fingerprint = sha(src)
    dest = stage / relative
    dest.parent.mkdir(exist_ok=True,parents=True)
    if fingerprint in known:
        os.link(known[fingerprint],dest)
    elif src.name == "ram.bin":
        subprocess.run(["cp","--sparse=always","--reflink=never",src,dest],check=True)
        assert sha(dest) == fingerprint
    else:
        os.link(src,dest)
    known[fingerprint] = dest
    checksums.append(f"{fingerprint}  {relative}\n")
(stage / "SHA256SUMS").write_text("".join(checksums))
paths = sorted((p.relative_to(stage) for p in stage.rglob("*") if p.is_file()),key=lambda p:(p.name,str(p)))
order = work/"order.bin"
order.write_bytes(b"".join(os.fsencode(p)+b"\0" for p in paths))
archive = output/f"permit403-{lane}-first.tar.xz"
with archive.open("xb") as dest:
    tar = subprocess.Popen(["tar","--sparse","--format=gnu","--owner=0","--group=0","--numeric-owner","--mtime=@0",
                            "-C",stage,"--null","-T",order,"-cf","-"],stdout=subprocess.PIPE)
    compress = subprocess.run(["xz","-T1","-6","-c"],stdin=tar.stdout,stdout=dest)
    tar.stdout.close()
    if tar.wait() or compress.returncode:
        raise RuntimeError("archive creation failed")
out_sha = sha(archive)
(output/f"{archive.name}.sha256").write_text(f"{out_sha}  {archive.name}\n")
print(f"{out_sha}  {archive.name} ({archive.stat().st_size} bytes, {len(checksums)} original files)",flush=True)
subprocess.run(["tar","-xJf",archive,"-C",extracted],check=True)
assert (stage/"SHA256SUMS").read_bytes() == (extracted/"SHA256SUMS").read_bytes()
with (output/f"permit403-{lane}-fresh-replay.log").open("x") as result:
    subprocess.run(["bash","scripts/replay.sh","."],cwd=extracted,stdout=result,stderr=subprocess.STDOUT,check=True)
print((output/f"permit403-{lane}-fresh-replay.log").read_text(),end="")
shutil.copyfile(stage/"SHA256SUMS",output/lane/"packet"/"SHA256SUMS")
