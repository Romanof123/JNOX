"""Verify the frozen Git objects, source bytes, packages, first boots and captures offline."""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

LOCAL = "a69bc6948c1d57c6df89d395e9307de5e0c6d6dc"
PUBLIC = "4ae1c136988b8cd811f472267bfad3b4eb27d2f3"
TREE = "a851e772eff77659b16d9a372de6d353be803757"
AREAS = set("arch boards examples kernel sdk services tools trace verification".split())
ORIGINAL_LANE = "8ba9e411df7d95d66d666e1b4901c7c91764b6ae629ef1bc88a99614de49c580"
ORIGINAL_COLD = "ebe944c083c51120eff0d700e5e7e733626b255c19c414a36c5e231aac6e9d22"

def git_hash(kind, data):
    return hashlib.sha1(f"{kind} {len(data)}\0".encode() + data).hexdigest()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

root = Path(sys.argv[1]).resolve()
lane = sys.argv[2]
assert lane in {"component","arrivals"}
component = lane == "component"
source = root / "source"
assert (source / "revision").read_text().splitlines() == [LOCAL,TREE]
assert (root / "identities.txt").read_text().splitlines()[:3] == [
    "built_local_commit=" + LOCAL, "public_source_commit=" + PUBLIC, "identical_tree=" + TREE]
for rev in (LOCAL, PUBLIC):
    raw = (source / f"{rev}.commit").read_bytes()
    assert git_hash("commit", raw) == rev and raw.startswith(f"tree {TREE}\n".encode())
with tempfile.TemporaryDirectory() as temp:
    subprocess.run(["git", "init", "-q", temp], check=True)
    subprocess.run(["git", "-C", temp, "update-index", "--index-info"], input=(source/"tree.txt").read_bytes(), check=True)
    assert subprocess.check_output(["git", "-C", temp, "write-tree", "--missing-ok"],text=True).strip() == TREE
    index = subprocess.check_output(["git","-C",temp,"ls-files","--stage","-z"]).split(b"\0")
expected = {}
for line in filter(None, index):
    header, name = line.split(b"\t", 1)
    path = name.decode()
    if path.split("/")[0] in AREAS:
        expected[path] = header.split()[1].decode()
with tarfile.open(source / "production.tar") as archive:
    files = {m.name:git_hash("blob",archive.extractfile(m).read()) for m in archive if m.isfile()}
assert files == expected
roles = ["queue-contract"] if component else ["sender","receiver","supervisor"]
app_hashes = [sha(root / "apps" / (role+".elf")) for role in roles]
assert len(set(app_hashes)) == len(roles)
cases = ["before","exact","after"] if component else ["arrival-before","arrival-same","arrival-after"]
timings = ["default"] if component else ["default","count0"]
matrix = [(clock,policy,case) for clock in timings for policy in ["fifo","rr"] for case in cases]
with (root / "ledger.tsv").open() as f:
    rows = list(csv.DictReader(f, delimiter="\t"))
assert [(r["clock"],r["policy"],r["case"]) for r in rows] == matrix
pids, qemus = set(), set()
previous_finish = 0
for n, (r, (clock, policy, case)) in enumerate(zip(rows, matrix), 1):
    package = f"{policy}-{case}"
    name = f"{n:03d}-{clock}-{package}"
    assert (r["n"],r["package"],r["attempt"],r["revision"]) == (str(n),package,name,LOCAL)
    assert r["capture_rc"] == r["build_rc"] == "0"
    run, pkg = root/"runs"/name, root/"packages"/package
    cap = run/"cap"
    assert (run/"start.utc").read_text() < (run/"finish.utc").read_text()
    assert (run/"capture.status").read_text().strip() == "0"
    m, launch, session = map(read, (pkg/"manifest.json", cap/"launch.json", cap/"session.json"))
    assert m == launch["argument_package"] == read(run/"manifest.json")
    assert m["commit"] == launch["revision"] == LOCAL and m["tracked_changes"] == ""
    assert m["board"] == "virt" and m["app"] == "process" and m["policy"] == policy 
    assert m["quantum_ticks"] == (None if policy=="fifo" else 625000)
    assert sha(pkg/"build.log") == m["build_log_sha256"]
    slots = m["slots"]
    assert [s["priority"] for s in slots] == ([7] if component else [7,6,4])
    assert [s["elf_sha256"] for s in slots] == app_hashes
    assert {s["input"]["sha256"] for s in slots} == set(m["source_sha256"].values()) == set(app_hashes)
    assert all(s["slot"] == idx and s["argv"] == ["/bin/app",case] and
               sha(pkg/s["elf"]) == app_hashes[idx] for idx,s in enumerate(slots))
    if not component:
        assert m["safety_boundary"] == dict(scenario=case, decision_event=12, opening_queue_event=17, opening_queue_schema=1)
        assert m["loan_route"] == {"producer":0,"consumer":1} and m["ipc_routes"] == [{"caller":2,"server":0},{"caller":2,"server":1}]
    assert launch["ram_base"] == 0x40200000 and (cap/"ram.bin").stat().st_size == launch["ram_bytes"]
    assert sha(cap/"kernel.elf") == sha(pkg/"kernel.elf") == launch["kernel_sha256"] == m["kernel_elf_sha256"]
    assert sha(cap/"user.elf") == launch["user_sha256"] == app_hashes[0]
    assert sha(cap/"probe.c") == launch["probe_sha256"]
    probe = "examples/native-permit-queue-contract/src/main.rs" if component else "examples/native-safety-channel/sender/src/main.rs"
    assert git_hash("blob",(cap/"probe.c").read_bytes()) == expected[probe]
    assert session["marker"] == "EXIT 71" and session["observed_slot_exits"] == ({"0":71} if component else {"0":71,"1":72,"2":73})
    assert set(session["hashes"]) == {p.name for p in cap.iterdir() if p.is_file() and p.name != "session.json"}
    assert all(sha(cap/name)==value for name,value in session["hashes"].items())
    pid = session["pid"]
    assert pid not in pids and previous_finish < session["started_unix_ns"] <= session["finished_unix_ns"]
    previous_finish = session["finished_unix_ns"]
    pids.add(pid)
    qemus.add(launch["qemu_sha256"])
    argv = launch["argv"]
    base = ["-machine","virt,gic-version=2","-cpu","cortex-a72","-smp","1","-accel"]
    clock_argv = ["tcg"] if clock=="default" else ["tcg,thread=single","-icount","shift=0,align=off,sleep=off"]
    tail = ["-m","128M","-nodefaults","-display","none","-monitor","none","-no-reboot","-qmp","stdio","-serial"]
    assert argv[1:-3] == base+clock_argv+tail and argv[-3].endswith("/cap/uart.bin") and argv[-2]=="-kernel" and argv[-1].endswith("/cap/kernel.elf")
assert len(qemus)==1
if component:
    history = root/"preflight"
    with (history/"ledger.tsv").open() as handle:
        original = list(csv.DictReader(handle,delimiter="\t"))
    assert [(e["attempt"],e["capture_rc"],e["build_rc"]) for e in original] == [(r["attempt"],"1","0") for r in rows]
    for r in rows:
        log = (history/r["attempt"]/"capture.log").read_text()
        assert 'assert (manifest["commit"], manifest["tracked_changes"], manifest["policy"]) == (rev, False, policy)' in log
        assert log.rstrip().endswith("AssertionError")
else:
    assert sha(root/"scripts/lane.sh")==ORIGINAL_LANE and sha(root/"scripts/cold.py")==ORIGINAL_COLD
    assert (source/"public-revision").read_text().splitlines()==[LOCAL,TREE]
print(f"{lane}: {len(files)} source blobs, complete Git tree and both commit objects verified.")
print(f"{len(app_hashes)} distinct application ELF(s), six packages, {len(rows)} serial guest boots with raw RAM/UART and first-launch receipts verified.")
