#!/usr/bin/env bash
set -euo pipefail
shared=$(cd "$(dirname "$0")" && pwd)
lab="$HOME/permit403-integration"
local_rev=a69bc6948c1d57c6df89d395e9307de5e0c6d6dc
public_rev=4ae1c136988b8cd811f472267bfad3b4eb27d2f3
tree=a851e772eff77659b16d9a372de6d353be803757
for lane in component arrivals; do
    src="$lab/$lane/src"
    packet="$lab/$lane/packet"
    [[ $(git -C "$src" rev-parse HEAD) == "$local_rev" && $(git -C "$src" rev-parse 'HEAD^{tree}') == "$tree" ]]
    [[ $(git -C "$src" rev-parse "$public_rev^{tree}") == "$tree" ]]
    [[ -z $(git -C "$src" status --porcelain --untracked-files=no) ]]
    git -C "$src" cat-file commit "$public_rev" > "$packet/source/$public_rev.commit"
    {
        echo "built_local_commit=$local_rev"
        echo "public_source_commit=$public_rev"
        echo "identical_tree=$tree"
        echo "repository=https://github.com/Romanof123/JNOX"
        echo "working_tree_before_each_package=tracked_changes empty"
        echo "kernel_and_role_builds=serial; CARGO_BUILD_JOBS=1"
        if [[ $lane == arrivals ]]; then
            echo "original_lane_public_parameter=$local_rev"
            echo 'The original unmodified runner received the clean local commit as both revision arguments. Its source/public-revision records that invocation. The distinct upstream commit is recorded above and verified from source/*.commit against the same Git tree.'
        else
            echo 'All six initial capture preflights rejected the manifest encoding before launching QEMU. Their scripts, receipts and logs are in preflight/. Each original package then booted exactly once using the corrected external preflight check.'
        fi
    } > "$packet/identities.txt"
    cp "$shared"/{identity.py,prepare.sh,prepare_identity.sh,launch.sh} "$packet/scripts/"
    for file in launch.start.utc launch.finish.utc "$lane.status"; do cp "$lab/$file" "$packet/logs/outer.$file"; done
    git -C "$src" status --porcelain > "$packet/logs/checkout.post-build-status"
    while IFS= read -r -d '' lock; do
        mkdir -p "$packet/logs/generated/$(dirname "$lock")"
        cp "$src/$lock" "$packet/logs/generated/$lock"
    done < <(git -C "$src" ls-files --others --exclude-standard -z -- 'examples/**/Cargo.lock')
    python3 -B "$packet/scripts/identity.py" "$packet" "$lane" > "$packet/verification/identity.txt"
    cat "$packet/verification/identity.txt"
done
