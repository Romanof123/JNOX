#!/usr/bin/env bash
# The first capture preflight rejected the empty tracked_changes string before starting QEMU.
# Preserve each preflight verbatim, then boot each original package once using the corrected check.
set -euo pipefail
export LC_ALL=C TZ=UTC PYTHONDONTWRITEBYTECODE=1
shared=$(cd "$(dirname "$0")" && pwd)
lab="$HOME/permit403-integration"
packet="$lab/component/packet"
exec 7>"$lab/serial.lock"
flock -x 7
[[ -f "$lab/launch.finish.utc" && ! -e "$packet/preflight" ]]
cd "$lab/component/src"
rev=$(git rev-parse HEAD)
for run in "$packet"/runs/*; do
    [[ ! -e "$run/cap" && $(cat "$run/capture.status") == 1 ]]
    grep -Fq 'assert (manifest["commit"], manifest["tracked_changes"], manifest["policy"]) == (rev, False, policy)' "$run/capture.log"
done
mkdir "$packet/preflight"
cp "$packet/ledger.tsv" "$packet/scripts/component_cold.py" "$packet/preflight/"
cp "$shared/component_first_boot.sh" "$shared/component_cold.py" "$packet/scripts/"
newledger="$packet/ledger.first-boots.tsv"
head -1 "$packet/preflight/ledger.tsv" > "$newledger"
while IFS=$'\t' read -r n clock_mode policy case_name package buildrc preflightrc attempt source_rev; do
    run="$packet/runs/$attempt"
    saved="$packet/preflight/$attempt"
    mkdir "$saved"
    cp "$run"/{capture.log,capture.status,start.utc,finish.utc} "$saved/"
    [[ "$buildrc" == 0 && "$preflightrc" == 1 && "$rev" == "$source_rev" ]]
    date -u +%FT%T.%NZ > "$run/start.utc"
    caprc=0
    (set -x; python3 "$packet/scripts/component_cold.py" "$packet/packages/$package" "$run/cap" "$rev" "$policy" "$case_name") > "$run/capture.log" 2>&1 || caprc=$?
    date -u +%FT%T.%NZ > "$run/finish.utc"
    printf '%s\n' "$caprc" > "$run/capture.status"
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$n" "$clock_mode" "$policy" "$case_name" "$package" "$buildrc" "$caprc" "$attempt" "$rev" >> "$newledger"
    printf '%s first-guest capture=%s\n' "$attempt" "$caprc"
done < <(tail -n +2 "$packet/preflight/ledger.tsv")
mv "$newledger" "$packet/ledger.tsv"
rsync -aS --exclude target/ --exclude __pycache__/ "$packet/" "$shared/component/packet/"
date -u +%FT%T.%NZ > "$shared/component/first-boots-copied.utc"
