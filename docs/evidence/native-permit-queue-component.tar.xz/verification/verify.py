#!/usr/bin/env python3
"""Offline, Python standard library only. Usage: verify.py PACKET --commit SHA --out DIR"""
import argparse
import copy
import json
import re
import struct
import sys
import zlib
from pathlib import Path

from read_capture import Capture, Reject, digest, equal, need, rows, words
from reference import AGAIN, CANDIDATE, D, EPOCH, HZ, I, OFFSETS, expected
from provenance import inspect_source


def take_component(c):
    def s(name):
        return c.usym("permit_queue_" + name)

    def used(name):
        count, = words(s(name))
        return count

    def counted(name, count, width):
        full = rows(s(name),width)
        need(0 < count <= len(full), f"capacity of {name}")
        need(not any(any(row) for row in full[count:]), f"unused {name} tail")
        return full[:count]

    nevents, nmaps = used("event_count"), used("map_count")
    events = counted("events",nevents,10)
    maps = counted("maps",nmaps,10)
    event_loss, = words(s("event_loss"))
    # Cross the report sink independently and read the source modules' own
    # initialized backing buffers and accounting from their linked symbols.
    for module, name, n, result, loss in [
        ("6safety", "3LOG", "4USED", events, event_loss),
        ("5loans", "11TRANSITIONS", "6STORED", maps, 0),
    ]:
        actual_count, = words(c.usym(module+n, True))
        actual_lost, = words(c.usym(module+"7DROPPED", True))
        equal(actual_count, len(result), "service backing count " + module)
        equal(actual_lost, loss, "service backing loss " + module)
        actual_rows = rows(c.usym(module+name, True),10)
        need(actual_count <= len(actual_rows), "service backing bounds")
        for j, row in enumerate(result):
            equal(actual_rows[j], row, f"{module} actual journal vs report row {j}")
    page_rows = rows(s("pages"),4)
    equal(len(page_rows),12,"report PAGE rows")
    framebytes = s("frames")
    equal(len(framebytes),88,"two 44-byte frames")
    backing=c.usym("native_el0_mmu5PAGES",True)
    equal(len(backing),3*4096,"modeled loan backing capacity")
    equal(backing[:44],framebytes[44:],"mapped backing versus received bytes")
    need(not any(backing[44:]),"zeroed loan tail and unused pages")
    equal(words(c.usym("native_el0_mmu6ACCESS",True)),[0]*9,"terminal fixture access map")
    equal(words(c.usym("7OPERAND",True)),[D+3],"terminal supplied counter input")
    return dict(header=words(s("header")), info=rows(s("info"),7), ring=rows(s("ring"),8),
                pages=[page_rows[i:i+3] for i in range(0,12,3)], maps=maps,
                attempts=rows(s("attempts"),7,"q")[0], events=events, event_loss=event_loss,
                frames=[framebytes[:44],framebytes[44:]], register=words(c.usym("jnox_virtual_permit_enable"))[0])


def verify_contract(case, raw):
    goal = expected(case)
    for name in ("header","info","ring","pages","maps","attempts","events","event_loss","register"):
        if isinstance(goal[name], list):
            equal(len(raw[name]), len(goal[name]), "count " + name)
            for i, (actual, wanted) in enumerate(zip(raw[name],goal[name])):
                equal(actual, wanted, f"{name}[{i}]")
        else:
            equal(raw[name],goal[name],name)
    equal(len(raw["frames"]),2,"frame count")
    for i, frame in enumerate(raw["frames"]):
        equal(len(frame),44,"frame size")
        equal(zlib.crc32(frame[:40]), int.from_bytes(frame[40:],"little"), "independent CRC32")
        equal(frame,goal["frames"][i],f"frame {i} field values")
    t = D + OFFSETS[case]
    events = raw["events"]
    # Preserve zero-based source row indexes. Several rows share an operand;
    # the producer's array order, not a timestamp sort, determines causality.
    def index(test):
        found = [i for i,r in enumerate(events) if test(r)]
        equal(len(found),1,"unique causal witness")
        return found[0]

    chain = {
        "seq3_commit":index(lambda r:r[0]==5 and r[3:6]==[60,2,0] and r[7]==3),
        "publication":index(lambda r:r[0]==11 and r[8]==4),
        "opening_check":index(lambda r:r[0]==12 and r[2:4]==[t,1]),
        "opening_queue":index(lambda r:r[0]==17 and r[2]==t),
        "snapshot":index(lambda r:r[0]==7 and r[2]==16),
        "receive":index(lambda r:r[0]==6 and r[3]==35 and r[7]==16),
        "release":index(lambda r:r[0]==6 and r[3]==36 and r[6]==16),
        "commit":index(lambda r:r[0]==5 and r[1]==t and r[3:5]==[60,2]),
        "complete":index(lambda r:r[0]==10 and r[1]==t),
    }
    equal(list(chain.values()),sorted(set(chain.values())),"causal ordering")
    deny = [i for i,r in enumerate(events) if r[0]==3]
    device = [{"index":i,"tick":r[1],"before":r[4],"readback":r[5]} for i,r in enumerate(events) if r[0]==2]
    check = events[chain["opening_check"]]
    peek = events[chain["opening_queue"]]
    commit = events[chain["commit"]]
    return {"fixed_input_hz":HZ,"case_operand":t,"expiry_tick":D,"offset_from_D":t-D,
            "prior":{"seq":check[5],"issue":check[6],"age_at_open":t-check[6]},
            "candidate":{"seq":4,"issue":CANDIDATE,"publication":events[chain["publication"]][2:4],
                         "signed_age_at_open":t-CANDIDATE,"handle":peek[6],"length":peek[7],
                         "wire_hex":raw["frames"][0].hex(), "crc32":f"{zlib.crc32(raw['frames'][0][:40]):08x}"},
            "queue_at_check": {"ring_before":raw["ring"][0],"ring_after":raw["ring"][1],
                               "page":raw["pages"][0][0],"event17":peek},
            "arbitration":{"pre_fault":check[7],"post_fault":check[8],"device_after_check":(raw["info"][2][4]>>1)&1,
                           "receive":raw["attempts"][0],"release":raw["attempts"][1],"commit":raw["attempts"][2],
                           "accepted_sequence": commit[7], "accepted_issue":commit[8], "permit":events[chain["complete"]][8],
                           "recovery_count":commit[9]},
            "same_generation_refusals":raw["attempts"][5:],"all_attempts":raw["attempts"],"terminal_register":raw["register"],
            "causal_rows":chain,"expiry_rows":deny,"device_writes":device,"safety_rows":len(events),
            "map_rows":len(raw["maps"]),"safety_dropped":raw["event_loss"],"map_dropped":raw["ring"][-1][-1]}


def semantic_mutations(case, raw):
    # Each substitution starts from an accepted captured record.
    tick = D + OFFSETS[case]
    def change_event(kind, index, value, *, site=None):
        def apply(v):
            candidates = [r for r in v["events"] if r[0]==kind and r[1]==tick and (site is None or r[3]==site)]
            need(len(candidates) >= 1, "mutation target")
            candidates[0][index]=value
        return apply

    def bad_crc_both(v):
        v["frames"] = [f[:-1] + bytes([f[-1]^128]) for f in v["frames"]]

    def crc_valid_wrong_id(v):
        frame=bytearray(v["frames"][0])
        frame[16:24]=(7).to_bytes(8,"little")
        frame[40:]=struct.pack("<I",zlib.crc32(frame[:40]))
        v["frames"]=[bytes(frame)]*2

    def reordering(v):
        es = v["events"]
        indices = [i for i,e in enumerate(es) if e[0] in (12,17) and e[1]==tick]
        a,b=indices[:2]
        es[a],es[b] = es[b],es[a]

    mutations = {
        "opposite_lt_le_boundary": change_event(12,8,int(tick<D),site=1),
        "opening_operand_desynchronized":change_event(17,2,tick+10),
        "wrong_front_same_slot_old_generation": change_event(17,6,12),
        "check_after_lookahead_at_same_tick":reordering,
        "queue_removed_by_observer":lambda v:v["ring"][1].__setitem__(2,0),
        "wrong_queued_grant_generation":lambda v:v["pages"][0][0].__setitem__(2,12),
        "simultaneous_writer_and_reader":lambda v:v["maps"][14].__setitem__(7,1),
        "protected_prior_substituted":change_event(12,6,CANDIDATE,site=1),
        "unexpected_recovery_count":lambda v:next(r for r in v["events"] if r[0]==5 and r[1]==tick and r[3:5]==[60,2]).__setitem__(9,9),
        "wrong_command_refusal":lambda v:v["attempts"].__setitem__(5,0),
        "wrong_commit_status":lambda v:v["attempts"].__setitem__(2,-110),
        "truncated_safety_tail":lambda v:v["events"].pop(),
        "lost_safety_rows":lambda v:v.__setitem__("event_loss",1),
        "suppressed_virtual_device_transition":lambda v:next(r for r in v["events"] if r[0]==2).__setitem__(5,0),
        "terminal_enable_forged":lambda v:v.__setitem__("register",1),
        "crc_corrupted_both_frames":bad_crc_both,
        "crc_valid_wrong_seq_in_both_frames":crc_valid_wrong_id,
    }
    result={}
    for name, mutate in mutations.items():
        modified=copy.deepcopy(raw)
        mutate(modified)
        try:
            verify_contract(case,modified)
        except Reject as error:
            result[name]=str(error)
        else:
            raise Reject("mutation escaped: " + name)
    return result


def memory_mutations(c):
    # Byte-level controls bypass refreshed session hashes, directly challenging
    # the reads from the service journal, MMU and original kernel trace in RAM.
    sp=words(c.ksym("jnox_native_startup_slots"))[1]
    argv1=words(c.virtual(sp,24))[2]
    def original_symbol(fragment):
        return c.user_pa(c.user.locate(fragment,True)[0])

    mutations={
        "raw_bad_actual_exit_status":(c.k.locate("jnox_native_el0_journal")[0]+9*8,c.outer_trace),
        "raw_actual_scheduler_clock_corrupted":(c.k.locate("native_el09DECISIONS",True)[0],c.outer_trace),
        "raw_argv_actual_character_corrupted":(c.user_pa(argv1),c.outer_trace),
        "raw_live_root_descriptor_invalid":(c.root_addr,c.outer_trace),
        "raw_service_log_disagrees_with_copied_report":(original_symbol("6safety3LOG"), lambda:take_component(c)),
        "raw_production_mapping_token_corrupted":(original_symbol("5loans11TRANSITIONS"), lambda:take_component(c)),
        "raw_supplied_counter_mutated":(original_symbol("7OPERAND"), lambda:take_component(c)),
        "raw_retained_loan_backing_altered":(original_symbol("native_el0_mmu5PAGES")+41, lambda:take_component(c)),
    }
    results={}
    original=c.ram
    try:
        for name,(address,check) in mutations.items():
            c.ram=bytearray(original)
            c.ram[address-c.base]^=1
            try:
                check()
            except Reject as error:
                results[name]=str(error)
            else:
                raise Reject("raw memory mutation escaped: "+name)
    finally:
        c.ram=original
    return results


def write(path, data):
    path.write_bytes((json.dumps(data,indent=2,ensure_ascii=False)+"\n").encode("utf8"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("packet",type=Path)
    parser.add_argument("--commit",required=True)
    parser.add_argument("--out",required=True,type=Path)
    args=parser.parse_args()
    need(re.fullmatch("[0-9a-f]{40}",args.commit),"supply full frozen git commit")
    source=inspect_source(args.packet,args.commit)
    result=[]
    mutations={}
    case_list=[(p,c) for p in ("fifo","rr") for c in OFFSETS]
    for i,(policy,case) in enumerate(case_list,1):
        capture=Capture(args.packet,args.commit,policy,case,i)
        equal(capture.hashes["probe.c"],source["main_sha256"],"captured Rust harness versus archived source tree")
        outer=capture.outer_trace()
        component=take_component(capture)
        summary=verify_contract(case,component)
        key=f"{policy}-{case}"
        print(key, "OK", len(component["events"]), flush=True)
        mutations[key]={**semantic_mutations(case,component),**memory_mutations(capture)}
        result.append({"boot":key,"kernel_policy":policy,"source":args.commit,"artifact_digests":capture.hashes,
                       "scheduler":outer,"component":summary})
    equal(len({r["artifact_digests"]["user.elf"] for r in result}),1,"common workload")
    equal(len({r["artifact_digests"]["probe.c"] for r in result}),1,"common harness source")
    equal(len({r["artifact_digests"]["ram.bin"] for r in result}),6,"six distinct memory images")
    for ii in range(3):
        equal(result[ii]["component"],result[ii+3]["component"],"policy-independent protected results")
    args.out.mkdir(parents=True,exist_ok=True)
    write(args.out / "boots.json",result)
    write(args.out / "mutations.json",mutations)
    write(args.out / "source-identity.json",source)


if __name__ == "__main__":
    try:
        main()
    except (Reject,OSError,KeyError,struct.error) as error:
        sys.exit(f"REJECT: {error}")
