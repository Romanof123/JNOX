"""Verify the archived source against Git's binary blob, tree and commit encodings."""
import hashlib
import tarfile
from pathlib import PurePosixPath

from read_capture import equal, need, digest


def object_id(kind, data):
    return hashlib.sha1(kind.encode() + b" " + str(len(data)).encode() + b"\0" + data).hexdigest()


def tree_id(node):
    entries = []
    for name, item in node.items():
        if isinstance(item, dict):
            mode, oid, sort = "40000", tree_id(item), name + "/"
        else:
            mode, oid = item
            sort = name
        entries.append((sort.encode(),mode.encode()+b" "+name.encode()+b"\0"+bytes.fromhex(oid)))
    return object_id("tree",b"".join(v for _,v in sorted(entries)))


def inspect_source(packet, commit):
    folder = packet / "source"
    revision, wanted = (folder/"revision").read_text().split()
    equal(revision,commit,"source archive revision")
    payload=(folder/(commit+".commit")).read_bytes()
    equal(object_id("commit",payload),commit,"binary Git commit")
    equal(payload.splitlines()[0].decode(),"tree "+wanted,"Git commit root tree")
    root = {}
    blobs = {}
    for line in (folder/"tree.txt").read_text(encoding="utf8").splitlines():
        meta, name = line.split("\t",1)
        mode, kind, oid = meta.split()
        equal(kind,"blob","tree listing object type")
        p = PurePosixPath(name)
        node = root
        for part in p.parts[:-1]:
            node = node.setdefault(part,{})
        need(p.name not in node,"duplicate git tree entry")
        node[p.name] = (mode,oid)
        blobs[name] = oid
    equal(tree_id(root), wanted, "reconstructed recursive Git root tree")
    app = "examples/native-permit-queue-contract/"
    core = {"kernel/src/native_safety_channel.rs","kernel/src/native_loan_ipc.rs","kernel/src/loan_ipc.rs",
            app+"src/main.rs",app+"src/evidence.rs",app+"src/native_el0_mmu.rs",app+"src/configure.rs",
            app+"Cargo.toml","sdk/native-safety-channel/src/lib.rs"}
    items={}
    archived=set()
    with tarfile.open(folder/"production.tar") as files:
        for member in files:
            if member.isdir():
                continue
            need(member.isfile() and member.name not in archived,"duplicate/nonregular archive member")
            content=files.extractfile(member).read()
            equal(object_id("blob",content),blobs.get(member.name),"archived blob "+member.name)
            archived.add(member.name)
            if member.name in core:
                items[member.name]={"git_blob":blobs[member.name],"sha256":digest(content)}
    equal(set(items),core,"required component/production sources")
    return {"build_commit":commit,"git_tree":wanted,"listed_blobs":len(blobs),"verified_archived_blobs":len(archived),
            "reviewed_sources":items,"main_sha256":items[app+"src/main.rs"]["sha256"]}
