"""Read a stopped AArch64 guest directly from the ELF symbol table and physical RAM."""
import hashlib
import json
import struct
from pathlib import Path


class Reject(ValueError):
    pass


def need(test, message):
    if not test:
        raise Reject(message)


def equal(got, expected, label):
    if got != expected:
        raise Reject(f"{label}: expected {expected!r}, saw {got!r}")


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def rows(raw, width, scalar="Q"):
    size = struct.calcsize("<" + scalar * width)
    need(len(raw) % size == 0, "misaligned row extent")
    return [list(row) for row in struct.iter_unpack("<" + scalar * width, raw)]


def words(raw):
    return list(struct.unpack("<" + "Q" * (len(raw) // 8), raw))


class Elf:
    def __init__(self, raw):
        self.raw = raw
        equal(raw[:7], b"\x7fELF\x02\x01\x01", "little-endian ELF64")
        header = struct.unpack_from("<HHIQQQIHHHHHH", raw, 16)
        equal(header[:2], (2, 183), "AArch64 executable")
        self.entry = header[3]
        _, phoff, shoff = header[3:6]
        self.loads = []
        for index in range(header[9]):
            seg = struct.unpack_from("<IIQQQQQQ", raw, phoff + index * header[8])
            if seg[0] == 1:
                self.loads.append(seg)
        sections = [struct.unpack_from("<IIQQQQIIQQ", raw, shoff + i * header[10]) for i in range(header[11])]
        self.syms = {}
        for section in sections:
            if section[1] != 2:
                continue
            strings = sections[section[6]]
            table = raw[strings[4]:strings[4] + strings[5]]
            for address in range(section[4], section[4] + section[5], section[9]):
                key, _, _, shndx, va, size = struct.unpack_from("<IBBHQQ", raw, address)
                if key and shndx:
                    end = table.index(0, key)
                    name = table[key:end].decode("utf8")
                    self.syms.setdefault(name, []).append((va, size))

    def locate(self, query, partial=False):
        matches = [item for name, values in self.syms.items()
                   if (query in name if partial else name == query) for item in values]
        equal(len(matches), 1, f"symbol multiplicity {query}")
        return matches[0]


class Capture:
    def __init__(self, root, commit, policy, case, ordinal):
        run = root / "runs" / f"{ordinal:03}-default-{policy}-{case}"
        cap = run / "cap"
        pkg = root / "packages" / f"{policy}-{case}"
        self.policy, self.case = policy, case
        self.features = {}
        session = json.loads((cap / "session.json").read_text())
        launch = json.loads((cap / "launch.json").read_text())
        self.session = session
        self.launch = launch
        manifest = json.loads((pkg / "manifest.json").read_text())
        names = set(session["hashes"])
        need({"kernel.elf","user.elf","probe.c","uart.bin","ram.bin","launch.json","stderr"} <= names,
             "session lacks required raw artifact")
        self.hashes = {}
        for name, expected in session["hashes"].items():
            equal(Path(name).name, name, "session member name")
            actual = digest((cap / name).read_bytes())
            equal(actual, expected, "session digest " + name)
            self.hashes[name] = actual
        equal(session["marker"], "EXIT 71", "capture terminal marker")
        equal(session["observed_slot_exits"], {"0":71}, "capture process exit")
        equal(session["qemu_returncode"], 0, "host capture exit")
        equal((run/"capture.status").read_text().strip(),"0","capture driver status")
        equal((run/"build.status").read_text().strip(),"0","build status")
        equal(json.loads((run/"manifest.json").read_text()),manifest,"run manifest")
        host=(root/"logs"/"host.txt").read_text()
        need(launch["qemu_sha256"]+"  "+launch["argv"][0] in host and launch["qemu_version"].splitlines()[0] in host,
             "external emulator identity")
        equal(manifest, launch["argument_package"], "packager/launch identity")
        equal(manifest["commit"], commit, "package source revision")
        equal(launch["revision"], commit, "capture source revision")
        equal(manifest["tracked_changes"], "", "clean tracked source")
        equal((manifest["app"], manifest["board"], manifest["policy"]), ("process", "virt", policy), "package mode")
        equal(manifest["quantum_ticks"], 625000 if policy == "rr" else None, "real kernel quantum")
        equal(len(manifest["slots"]), 1, "real EL0 process count")
        slot, = manifest["slots"]
        equal((slot["slot"], slot["argv"], slot["priority"], slot["elf"]),
              (0, ["/bin/app", case], 7, "user.elf"), "slot identity")
        equal(manifest["kernel_elf_sha256"], self.hashes["kernel.elf"], "packaged kernel")
        equal(slot["elf_sha256"], self.hashes["user.elf"], "packaged user")
        equal(digest((pkg/"build.log").read_bytes()),manifest["build_log_sha256"],"kernel build log")
        equal(digest((root/"apps"/"queue-contract.elf").read_bytes()),self.hashes["user.elf"],"common built workload")
        for filename, field in [("user.elf","user_sha256"),("kernel.elf","kernel_sha256"),("probe.c","probe_sha256")]:
            equal(self.hashes[filename], launch[field], "launch hash of " + filename)
            if (pkg / filename).exists():
                equal(digest((pkg / filename).read_bytes()), self.hashes[filename], "package copy " + filename)
        argv = launch["argv"]
        equal(Path(argv[0]).name, "qemu-system-aarch64", "emulator")
        flags = ["-machine", "virt,gic-version=2", "-cpu", "cortex-a72", "-smp", "1",
                 "-accel", "tcg", "-m", "128M", "-nodefaults", "-display", "none",
                 "-monitor", "none", "-no-reboot", "-qmp", "stdio", "-serial"]
        equal(argv[1:1 + len(flags)], flags, "ordinary default QEMU launch")
        tail = argv[1 + len(flags):]
        need(len(tail) == 3 and tail[0].startswith("file:") and tail[0].endswith("/uart.bin")
             and tail[1] == "-kernel" and tail[2].endswith("/kernel.elf"), "capture endpoints")
        self.uart = (cap / "uart.bin").read_text(encoding="ascii").splitlines()
        self.k = Elf((cap / "kernel.elf").read_bytes())
        self.user = Elf((cap / "user.elf").read_bytes())
        self.probe = (cap / "probe.c").read_bytes()
        self.ram = (cap / "ram.bin").read_bytes()
        self.base = self.k.locate("_start")[0]
        equal(self.base, 0x40200000, "linked RAM origin")
        equal(self.base, launch["ram_base"], "captured RAM origin")
        equal(len(self.ram), self.k.locate("__stack_top")[0] - self.base, "linked RAM extent")
        equal(len(self.ram), launch["ram_bytes"], "captured RAM extent")
        self.root_addr = self.k.locate("native_el0_mmu6SPACES", True)[0]
        equal(self.ksym("jnox_native_el0_image"), self.user.raw, "actual embedded workload in captured RAM")
        for elf, reader in [(self.k, self.physical), (self.user, self.virtual)]:
            for _, flags, off, va, _, size, _, _ in elf.loads:
                if flags & 1 and size:
                    equal(digest(reader(va, size)), digest(elf.raw[off:off + size]), "loaded executable code")

    def physical(self, addr, size):
        off = addr - self.base
        need(size >= 0 and 0 <= off <= len(self.ram) - size, f"physical RAM bounds {addr:#x}/{size}")
        return self.ram[off:off + size]

    def user_pa(self, va):
        table = self.root_addr
        for shift in (30,21,12):
            index = (va >> shift) & 511
            desc, = struct.unpack("<Q", self.physical(table + index * 8, 8))
            equal(desc & 3, 3, "valid AArch64 page-table descriptor")
            table = desc & 0xfffff000
        need(desc & (1 << 6), "EL0 access to leaf")
        return table + (va & 4095)

    def virtual(self, va, size):
        out = bytearray()
        while size:
            n = min(4096 - (va & 4095), size)
            out.extend(self.physical(self.user_pa(va), n))
            size -= n
            va += n
        return bytes(out)

    def ksym(self, name, partial=False):
        return self.physical(*self.k.locate(name, partial))

    def usym(self, name, partial=False):
        return self.virtual(*self.user.locate(name, partial))

    def uart_rows(self, prefix):
        return [[int(x) for x in line[len(prefix):].split()] for line in self.uart if line.startswith(prefix + " ")]

    def outer_trace(self):
        need(not any("FAULT" in s or "NATIVE QUAL " in s or "NATIVE SAFETY " in s for s in self.uart),
             "unexpected fault or protected-service records in outer kernel")
        equal(self.uart.count("NATIVE EL0 ELF " + self.hashes["user.elf"]), 1, "boot workload digest")
        equal(self.uart_rows("NATIVE EL0 EXIT"), [[71]], "UART exit")
        startup = words(self.ksym("jnox_native_startup_slots"))
        entry, sp, length, argc = startup
        equal((entry, sp + length, argc), (self.user.entry, 0x1011000, 2), "startup slots")
        tail = self.virtual(sp, length)
        nargs, p0, p1, endv, endenv = struct.unpack_from("<5Q", tail)
        equal((nargs, endv, endenv), (2,0,0), "live startup header")
        args = []
        for ptr in (p0, p1):
            need(sp <= ptr < sp + length, "argv pointer bounds")
            args.append(tail[ptr-sp:tail.index(0,ptr-sp)].decode("ascii"))
        equal(args, ["/bin/app", self.case], "actual process argv")
        header, *journal = rows(self.ksym("jnox_native_el0_journal"), 16)
        equal(header[:8], [1,3,0,len(self.user.raw),entry,sp,0x1001000,0x1011000], "kernel terminal journal header")
        equal(header[9:11], [71,1], "kernel terminal exit")
        equal(header[15], 2, "kernel observed argc")
        need(header[13] & 1 and header[14] & 0xfffff000 == self.root_addr, "live MMU and TTBR address")
        n = header[8]
        need(1 <= n < 8, "full bounded kernel exception journal")
        seen = journal[:n]
        equal([r[7] for r in seen], [1], "actual outer SVCs")
        r, = seen
        equal((r[0],r[1],r[2],r[3]>>26,r[3]&65535,r[4]&31,r[8],r[11],r[12]),
              (0,0x400,4,0x15,0x4a01,0,71,0,2), "real lower EL0 exit exception")
        equal(r[13], self.k.locate("native_el0_vectors")[0], "actual exit vector")
        equal(r[14] & 0xfffff000, self.root_addr, "exit active TTBR0")
        exit_insn = 0xd4000001 | (0x4a01 << 5)
        equal(self.virtual(r[5]-4,4), exit_insn.to_bytes(4,"little"), "executed SVC #0x4a01")
        svc = []
        for _, flags, _, va, _, size, _, _ in self.user.loads:
            if flags & 1:
                for offset,(insn,) in enumerate(struct.iter_unpack("<I",self.virtual(va,size))):
                    need(insn & 0xfff00000 != 0xd5300000, "unexpected MRS in isolated executable")
                    if insn & 0xffe0001f == 0xd4000001:
                        svc.append((va+4*offset,insn))
        equal(svc,[(r[5]-4,exit_insn)],"sole compiled SVC is the captured exit")
        fixed_used, = words(self.ksym("native_el07RECORDS", True))
        fixed_loss, = words(self.ksym("native_el07DROPPED", True))
        fixed = rows(self.ksym("native_el09DECISIONS", True),21)[:fixed_used]
        equal((fixed_loss,self.uart_rows("NATIVE FIXED DROPPED")), (0,[[0]]), "fixed journal loss")
        equal(self.uart_rows("NATIVE FIXED EVENT"), fixed, "real scheduler RAM/UART")
        need(2 <= len(fixed) < 128 and all(a[0]<=b[0] for a,b in zip(fixed,fixed[1:])), "fixed journal count/clock")
        equal([row[1] for row in fixed],[0,3],"only actual fixed scheduler decisions")
        equal(fixed[-1][15],fixed[-1][0]-fixed[0][0],"physical counter charged to PID0")
        no_pid = 2**64-1
        equal((fixed[0][1], fixed[0][3:5], fixed[0][7:9]), (0,[no_pid,0],[entry,sp]), "fixed start")
        equal((fixed[-1][1], fixed[-1][3:5]), (3,[0,no_pid]), "fixed exit")
        if self.policy == "fifo":
            equal(fixed[0][11], 0, "FIFO no slice")
            equal(fixed[0][18],0,"FIFO no remaining quantum")
        else:
            # A single runnable RR process can retain a quantum without an armed rotation.
            equal(fixed[0][18], 625000, "live RR quantum")
        return {"startup_argv": args, "outer_svc": [r[7] for r in seen], "real_sched_ticks": [row[0] for row in fixed],
                "start_remaining_ticks": fixed[0][18], "exit_pc": hex(r[5]), "exit_status": 71,
                "sole_svc_instruction_va":hex(svc[0][0]),"fixture_executable_mrs_count":0}
