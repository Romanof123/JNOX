"""Independent decoded-wire, queue and protected-decision reference for the six fixed fixtures."""
import struct
import zlib

HZ = 62_500_000
EPOCH = 1_000_000
WINDOW = HZ * 20 // 1000
PAIR = HZ * 10 // 1000
I = EPOCH + 2 * PAIR
CANDIDATE = I + HZ * 19 // 1000
D = I + WINDOW
MASK = (1 << 64) - 1
AGAIN = (-11) & MASK
OFFSETS = {"before": -1, "exact": 0, "after": 1}


def wire(sequence, issue):
    prefix = struct.pack("<8B3QIB3x", 1,1,44,0,1,0,1,1, 1,sequence,issue,20,1)
    return prefix + struct.pack("<I", zlib.crc32(prefix))


class Reference:
    def __init__(self, case):
        self.events = []
        self.maps = []
        self.t = EPOCH - 1
        self.streak = self.seq = self.last = self.prior = self.device = self.fault = 0
        self.handle = 0
        self.queued = False
        self.tick = D + OFFSETS[case]
        self.emit(1, HZ, self.t, 0)
        self.result(2,59,1,0)
        self.ordinary_permit(1,EPOCH)
        self.ordinary_permit(2,EPOCH+PAIR)
        self.t = EPOCH + 3 * PAIR // 2
        self.eligibility(2,0,1)
        self.result(2,59,2,0)
        self.open()
        self.check(4)
        self.eligibility(1,1,1)
        self.drive(1)
        self.result(1,60,4,0)
        self.complete()
        self.ordinary_permit(3,I)
        self.t = CANDIDATE + 1
        self.publish(4,CANDIDATE)
        self.t = self.tick
        self.open()
        self.consume(4,CANDIDATE)
        self.commit(4,CANDIDATE)
        # The second receive charges the remaining activation budget and finds
        # the ring empty. A third receive is refused before the loan journal.
        self.emit(6,1,35,AGAIN,0,0,0,0,1)
        self.complete()
        self.t = D + 2
        self.eligibility(2,0,0)
        self.result(2,59,2,AGAIN)
        self.open()
        self.check(4)
        self.result(1,60,4,AGAIN)
        self.complete()
        self.t = D + 3
        self.drive(0)
        self.emit(8,1,1,self.seq,self.last)

    def emit(self, kind, *data):
        self.events.append([kind,self.t,*data,*([0] * (8 - len(data)))])

    def result(self, role, op, command, status):
        self.emit(5,role,op,command,status,1,self.seq,self.last,self.streak)

    def eligibility(self, role, pending, accepted):
        self.emit(15,self.t,role,1,self.prior,self.last,self.streak,pending,accepted)

    def drive(self, new):
        if self.device != new:
            self.emit(2,self.t,self.t,self.device,new)
            self.device = new

    def check(self, site):
        was = self.fault
        if self.seq and not self.fault and self.t - self.last >= WINDOW:
            self.fault = 1
            self.emit(3,self.t,1,self.seq,self.last)
            self.drive(0)
        self.emit(12,self.t,site,1,self.seq,self.last,was,self.fault,1)

    def open(self):
        self.check(1)
        handle = self.handle if self.queued else 0
        length = 44 if self.queued else 0
        self.emit(17,self.t,1,self.seq,int(self.queued),handle,length,1,1+2*self.fault)
        self.result(1,60,1,0)

    def publish(self, sequence, issue):
        # One outstanding slot is repeatedly acquired/released. Generation is
        # carried above the two slot bits, so old grants cannot name new loans.
        self.handle = sequence << 2
        self.emit(6,0,33,0,0,0,self.handle,0,1)
        self.emit(11,self.t,self.t,self.handle,0,1,1,sequence,issue)
        self.emit(6,0,34,0,1,self.handle,44,0,1)
        self.maps.extend([[1,0,0,0,0,0,0,1,0,0], [2,0,0,44,1,0,0,0,0,0]])
        self.queued = True

    def consume(self, sequence, issue):
        packed = wire(sequence,issue) + bytes(4)
        self.emit(7,self.handle,1,*struct.unpack("<6Q", packed))
        self.emit(6,1,35,0,0,0,self.handle,44,1)
        self.emit(6,1,36,0,0,self.handle,0,0,1)
        self.maps.extend([[3,1,0,0,0,0,0,0,2,0], [4,1,0,0,0,2,0,0,0,0]])
        self.queued = False

    def commit(self, sequence, issue):
        self.check(2)
        if self.fault:
            self.result(1,60,2,AGAIN)
            return
        self.check(0x102)
        self.check(0x202)
        assert 0 <= self.t - issue < WINDOW
        self.streak = 2 if self.streak and issue-self.last == PAIR else 1
        self.prior, self.last, self.seq = self.last, issue, sequence
        self.result(1,60,2,0)

    def complete(self):
        self.check(3)
        self.result(1,60,3,0)
        self.emit(10,self.t,self.t,0,1,self.seq,self.last,1,self.streak)

    def ordinary_permit(self, sequence, issue):
        self.t = issue
        self.publish(sequence,issue)
        self.t = issue + 1
        self.open()
        self.consume(sequence,issue)
        self.commit(sequence,issue)
        self.complete()


def expected(case):
    ref = Reference(case)
    t = ref.tick
    positive = t < D
    flags = 3 if positive else 5
    seq, issue = (4,CANDIDATE) if positive else (3,I)
    ring = [[3,4,1,1,1,1,14,0], [3,4,1,1,1,1,14,0], [4,4,0,1,1,1,16,0], [4,4,0,1,0,0,16,0]]
    info = [[0,I+1,HZ,1,3,3,I], [0,CANDIDATE+1,HZ,1,3,3,I], [0,t,HZ,1,flags,3,I],
            [0,t,HZ,1,flags,seq,issue], [0,D+2,HZ,1,flags,seq,issue], [0,D+3,HZ,1,4,seq,issue]]
    pages = [[[s,2,16,44] if st < 2 and s == 0 else [s,0,0,0] for s in range(3)] for st in range(4)]
    return dict(header=[0x51435031,1,OFFSETS[case]+2,HZ,EPOCH,I,CANDIDATE,D,CANDIDATE+1,t,16,71],
                info=info, ring=ring, pages=pages, maps=ref.maps, events=ref.events, event_loss=0,
                attempts=[0,0,0 if positive else -11,-11,-11,-11,-11],
                frames=[wire(4,CANDIDATE)]*2, register=0)
