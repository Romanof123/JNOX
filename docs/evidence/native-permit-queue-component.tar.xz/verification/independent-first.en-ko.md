# Independent AArch64 component readback / AArch64 구성요소 독립 판독

All six ordinary QEMU boots passed. Both FIFO and RR accepted the queued next permit at D−1. At D and D+1 the protected CHECK latched the fault, disabled the modeled output, and retained the previous accepted permit before the controller read the queued frame. Guest PID 0 exited 71 in each boot. [#403 acceptance criteria](https://github.com/Romanof123/JNOX/issues/403)

QEMU 일반 게스트 6회 모두 통과했다. FIFO와 RR 모두 D−1에서 큐의 새 허가 프레임을 수락했다. D와 D+1에서는 보호 CHECK가 고장을 래치하고 가상 출력을 끈 뒤 기존 허가를 유지했다. 컨트롤러가 큐에서 새 프레임을 읽기 전에 차단이 끝났다. 실제 게스트 프로세스 PID 0은 매번 71로 종료했다.

| Policy / 정책 | CHECK operand / 입력 틱 | Old age / 기존 입력 나이 | Output after CHECK / 직후 출력 | Receive, release, COMMIT / 결과 | Accepted seq, issue, recovery count / 수락 순번·시각·연속 횟수 | Safety rows / 보호 기록 |
|---|---:|---:|---:|---|---|---:|
| FIFO, RR | 3,499,999 | 1,249,999 | 1 | 0, 0, 0 | 4, 3,437,500, 1 | 91 each |
| FIFO, RR | 3,500,000 | 1,250,000 | 0 | 0, 0, −11 | 3, 2,250,000, 2 | 90 each |
| FIFO, RR | 3,500,001 | 1,250,001 | 0 | 0, 0, −11 | 3, 2,250,000, 2 | 90 each |

### Time and identity / 시간과 입력 식별

At the fixture frequency of 62,500,000 Hz the 20 ms window spans 1,250,000 ticks. Generation 1 sequences 1 and 2 were issued at 1,000,000 and 1,625,000. Supervisor REARM and controller consumption at 1,937,500 changed the independent virtual register from 0 to 1. Sequence 3 was issued at 2,250,000 and accepted one tick later. The expiry under test is its issue tick plus 1,250,000. All prior and candidate frames carry permit 1.

시험 클록의 62.5 MHz에서 20 ms는 1,250,000틱이다. 세대 1의 순번 1·2는 각각 1,000,000틱과 1,625,000틱에 발행했다. 감독자와 컨트롤러가 1,937,500틱에 재무장 명령을 전달·소비하면서 레지스터가 0에서 1로 바뀌었다. 순번 3은 2,250,000틱에 발행했고 다음 틱에 수락했다. 이 입력의 만료 시각 D는 3,500,000틱이다. 기존 입력과 새 입력의 permit 값은 모두 1이다.

The candidate carried sequence 4 and issue 3,437,500. Its successful publication bracket was [3,437,501, 3,437,501]. The sender's frame, receiver's private copy, retained loan backing and the service's receive snapshot agree on all 44 bytes. The independently calculated IEEE CRC-32 is `a4e995ad`. Each opening CHECK and event 17 share the supplied operand and accepted sequence 3. The front contained one 44-byte grant with handle 16, slot 0, loan generation 4. Both surrounding channel reports contain head 3, tail 4, occupancy 1 and the same queued page. Both retained exactly 14 map operations at that point. The reader map and revoke raised the total to 16, head advanced to 4, the slot became free and occupancy reached zero.

새 입력의 순번은 4, 발행 시각은 3,437,500이고 실제 큐 등록 전후의 시험 시각은 모두 3,437,501이었다. 송신자 프레임, 수신자의 사본, 대여 페이지의 잔여 데이터, 서비스 수신 기록의 44바이트가 일치했다. 별도로 계산한 CRC-32는 `a4e995ad`다. CHECK와 이벤트 17은 같은 판정 틱과 기존 순번 3을 기록했다. 큐 선두에는 대여 세대 4, 핸들 16, 슬롯 0, 길이 44인 항목 한 개가 있었다. CHECK 전후 head·tail은 3·4, 점유량은 1, 매핑 작업 수는 14로 같았다. 수신 매핑과 해제 후에야 작업 수가 16이 되고 head는 4가 되었으며 큐와 슬롯이 비었다.

### Chronology and commands / 판정 순서와 명령

Journal indexes below start at zero. The fixed counter held the same value throughout each candidate activation. Array order establishes the order among records sharing a timestamp. Both policies produced the same arrays.

아래 기록 번호는 0부터 센다. 후보 입력을 처리하는 동안 시험 시계를 고정했으므로 동일한 시각을 가진 기록의 순서는 원본 배열의 위치로 판별했다. 두 정책의 구성요소 기록이 일치했다.

| Case / 조건 | Publish / 등록 | Latch, output off / 래치·차단 | CHECK, queue front / 판정·선두 | Snapshot, receive, release / 복사·수신·해제 | COMMIT, COMPLETE |
|---|---:|---|---|---|---|
| D−1 | 63 | output off at teardown 89 | 65, 66 | 68, 69, 70 | 74, 78 |
| D, D+1 | 63 | 65, 66 | 67, 68 | 70, 71, 72 | 74, 78 |

Expiry immediately inhibited the virtual device even though the candidate itself was 62,500 or 62,501 ticks old. The later COMMIT returned −11 (EAGAIN) through its already-faulted precondition. The second receive found the ring empty. A third call exhausted the activation's two-receive allowance and returned −11 before the loan journal. At D+2, same-generation supervisor REARM and controller consumption both returned −11 in all six cases. At D+3, endpoint teardown closed both roles and all terminal register words read zero. The D−1 capture retained output 1 through D+2 and switched it off at teardown.

정각과 한 틱 후에는 새 입력 자체의 나이가 각각 62,500틱, 62,501틱이었지만 기존 입력의 만료가 즉시 출력을 차단했다. 이후 COMMIT은 이미 고장이 래치되어 −11(EAGAIN)을 반환했다. 두 번째 수신은 빈 큐를 확인했고 세 번째 시도는 활성화당 두 번의 수신 한도에 걸려 대여 기록을 남기기 전에 −11을 반환했다. 여섯 실행 모두 D+2에서 같은 세대 재무장 요청과 컨트롤러의 소비 요청이 −11이었다. D+3 종료 후 생산자와 소비자 모두 닫혔고 최종 레지스터 값은 0이었다. D−1에서는 D+2까지 출력이 1이었고 종료 처리에서 0이 되었다.

### Scope and replay / 적용 범위와 재검증

Each boot ran a single ordinary AArch64 process on QEMU virt, one Cortex-A72 vCPU, default TCG clock. The ELF links the shipping Rust safety service, loan service and ring. Its private fixture supplies three role IDs, page access tokens, and a fixed atomic counter. One linked SVC instruction at `0x40001c` executed the actual EXIT. The executable contains zero MRS instructions. The outer EL1 scheduler recorded its ordinary guest-counter readings, and the exception journal retained the actual exit trap. The supplied ±1 ticks establish deterministic arbitration; physical-counter equality for the three-process production path remains open under #401. These boots provide no physical actuator, hardware page revocation between roles, hardware timing bound or 1 ms phase-budget measurement. [Frozen app and sources](https://github.com/Romanof123/JNOX/tree/4ae1c136988b8cd811f472267bfad3b4eb27d2f3/examples/native-permit-queue-contract) · [#401](https://github.com/Romanof123/JNOX/issues/401)

QEMU virt에서 Cortex-A72 vCPU 한 개와 기본 TCG 시계로 부팅했다. 일반 AArch64 프로세스 하나가 실제 Rust 보호 서비스·대여 서비스·링 코드를 링크했고, 시험 코드가 역할 ID 세 개, 페이지 접근 권한, 고정 시각을 제공했다. 실제 커널로 진입하는 SVC 명령은 `0x40001c`의 종료 호출 한 개이며 앱 실행 코드에 MRS 명령은 없었다. 외부 EL1 스케줄러와 예외 기록은 일반 게스트 카운터를 사용했다. 세 프로세스 실경로의 물리 카운터 정각 판정은 #401에 남아 있다. 이 구성요소 시험의 범위에는 실물 액추에이터, 역할 간 하드웨어 페이지 해제, 실기기 최악 지연 및 1 ms 위상 예산이 포함되지 않는다.

The reader resolves original kernel and app symbols from ELF64, compares the embedded workload and executable bytes with captured RAM, and walks live page tables for PID 0. It validates the archived Git commit, reconstructs the full root tree from 1,971 listed blobs, validates 719 archived blobs and matches every captured harness to the archived Rust source. Build revision `a69bc6948c1d57c6df89d395e9307de5e0c6d6dc` and public source revision `4ae1c136988b8cd811f472267bfad3b4eb27d2f3` name the identical Git tree `a851e772eff77659b16d9a372de6d353be803757`. The shared workload SHA-256 is `6b2a4d0f4534ac2db2b2938fafa36e216b8e7512c77db1746098bb330254999d`. The register, originally stored service journals and exported evidence were read independently from the terminal image. All safety and loan transition drop counts were zero. The independent model checks every safety row and every map row. Seventeen semantic substitutions and eight byte-level RAM corruptions per raw capture all failed the verifier, giving 150 rejected mutations.

판독기는 ELF64 심볼과 PID 0의 실제 페이지 테이블로 종료 RAM을 읽고 적재된 실행 코드와 내장 사용자 ELF를 대조했다. Git 객체 목록 1,971개에서 전체 루트 트리를 다시 만들고 보존된 소스 719개를 검증했으며 여섯 부팅의 시험 소스를 원본과 대조했다. 로컬 빌드 커밋과 공개 커밋은 위의 동일한 트리를 가리킨다. 원본 서비스 로그, 매핑 기록, 출력 레지스터, 시험 프로그램이 내보낸 기록을 각각 판독했다. 누락된 서비스·매핑 기록은 0개였다. 각 실행에서 판정값 변이 17개와 RAM 바이트 변이 8개를 적용했고 총 150개 모두 거부했다.

Run from the independent verifier directory against the component packet. Python 3 uses its standard library. The unlaunched external preflight attempts are preserved separately. The six completed guest captures supply the evidence above.

구성요소 패킷을 인수로 독립 판독기 디렉터리에서 다음 명령을 실행한다. Python 3 표준 라이브러리만 사용한다. 게스트가 시작되지 않은 사전 점검 기록은 별도 보존했으며 위 표는 완료된 게스트 캡처 여섯 개에서 얻었다.

```sh
python3 -B verify.py /path/to/component/packet --commit a69bc6948c1d57c6df89d395e9307de5e0c6d6dc --out /tmp/permit403-replay
```
