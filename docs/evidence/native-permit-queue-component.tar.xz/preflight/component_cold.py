"""Capture one isolated PID0 contract process and preserve RAM on a wall timeout."""
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import threading
import time

sys.path.insert(0, str(Path.cwd() / "tools"))
from native_el0_capture import command, symbol_address
from ordinary_amc_capture import save, sha
from qemu_capture import request

pkg, root = map(lambda name: Path(name).resolve(), sys.argv[1:3])
rev, policy, case = sys.argv[3:]
manifest = json.loads((pkg / "manifest.json").read_text())
assert (manifest["commit"], manifest["tracked_changes"], manifest["policy"]) == (rev, False, policy)
assert len(manifest["slots"]) == 1
primary = manifest["slots"][0]
assert primary["argv"] == ["/bin/app", case] and primary["priority"] == 7
assert primary["elf_sha256"] == sha(pkg / "user.elf")
assert manifest["kernel_elf_sha256"] == sha(pkg / "kernel.elf")
root.mkdir()
for source, name in [(pkg / "kernel.elf", "kernel.elf"), (pkg / "user.elf", "user.elf"),
                     (Path("examples/native-permit-queue-contract/src/main.rs"), "probe.c")]:
    shutil.copyfile(source, root / name)
symbols = subprocess.check_output(["aarch64-linux-gnu-nm", "-nS", root / "kernel.elf"], text=True)
base = symbol_address(symbols, "_start")
size = symbol_address(symbols, "__stack_top") - base
assert base == 0x40200000 and 0 < size <= 16 << 20
qemu = Path(shutil.which("qemu-system-aarch64")).resolve(strict=True)
argv = command(str(qemu), root, plain=True)
assert argv[argv.index("-smp") + 1] == "1" and "-icount" not in argv
save(root / "launch.json", dict(version=1, argv=argv, revision=rev, ram_base=base, ram_bytes=size,
     argument_package=manifest, qemu_sha256=sha(qemu),
     qemu_version=subprocess.check_output([qemu, "--version"], text=True),
     kernel_sha256=sha(root / "kernel.elf"), user_sha256=sha(root / "user.elf"), probe_sha256=sha(root / "probe.c")))
marker = "unobserved"
proc = None
started = time.time_ns()
exits = {}
try:
    with (root / "stderr").open("xb") as stderr:
        proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr, bufsize=0)
        timer = threading.Timer(55, proc.kill)
        timer.start()
        try:
            if "QMP" not in json.loads(proc.stdout.readline()):
                raise RuntimeError("missing QMP greeting")
            class Pipe:
                write = proc.stdin.write
                readline = proc.stdout.readline
            stream = Pipe()
            request(stream, "qmp_capabilities")
            deadline = time.monotonic() + 40
            while proc.poll() is None:
                uart = root / "uart.bin"
                raw = uart.read_bytes() if uart.exists() else b""
                terminal = re.search(rb"(?m)^NATIVE EL0 (EXIT -?\d+|FAULT \d+)\r?\n", raw)
                if terminal:
                    marker = terminal[1].decode()
                    if marker.startswith("EXIT "):
                        exits[0] = int(marker.split()[1])
                elif len(raw) > 8 << 20:
                    marker = "UART LIMIT"
                elif time.monotonic() >= deadline:
                    marker = "TIMEOUT"
                else:
                    time.sleep(0.005)
                    continue
                request(stream, "stop")
                request(stream, "pmemsave", val=base, size=size, filename=str(root / "ram.bin"))
                break
        finally:
            timer.cancel()
            timer.join()
except (ValueError, RuntimeError, OSError) as exc:
    marker = f"{marker}: {exc}"
finally:
    if proc is not None:
        if proc.poll() is None:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
    save(root / "session.json", dict(marker=marker, observed_slot_exits=exits,
         started_unix_ns=started, finished_unix_ns=time.time_ns(), pid=proc.pid if proc else None,
         qemu_returncode=proc.returncode if proc else None,
         hashes={path.name:sha(path) for path in sorted(root.iterdir()) if path.is_file()}))
print(marker, exits, flush=True)
sys.exit(int(marker != "EXIT 71" or not (root / "ram.bin").is_file()))
