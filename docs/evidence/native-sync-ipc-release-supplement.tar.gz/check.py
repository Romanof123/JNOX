import hashlib
import itertools
import json
import re
import struct
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
cap = root / "capture"
package = root / "package"
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def symbols(path):
    text = subprocess.check_output(["aarch64-linux-gnu-nm", "-nS", path], text=True)
    return {w[3]: (int(w[0], 16), int(w[1], 16)) for line in text.splitlines()
            if len(w := line.split()) == 4}

def symbol_containing(table, fragment):
    only, = [value for name, value in table.items() if fragment in name]
    return only

session = json.loads((cap / "session.json").read_text())
for name, expected in session["hashes"].items():
    assert digest(cap / name) == expected, name
manifest = json.loads((package / "manifest.json").read_text())
assert manifest["commit"] == "6f51e0b138c9dd613a18cddc53495673c7f71c1b" and not manifest["tracked_changes"]
assert manifest["policy"] == "rr" and manifest["quantum_ticks"] == 625000
assert manifest["ipc_routes"] == [{"caller": 0, "server": 2}]
assert [slot["priority"] for slot in manifest["slots"]] == [7, 4, 1]
assert all(slot["elf_sha256"] == digest(root / "operational.elf") for slot in manifest["slots"])
assert digest(package / "kernel.elf") == manifest["kernel_elf_sha256"] == digest(cap / "kernel.elf")
assert digest(cap / "kernel.elf") == (root / "preboot.sha256").read_text().split()[0]

uart = (cap / "uart.bin").read_text()
assert "NATIVE FIXED DROPPED 0" in uart and "FAULT" not in uart
exits = [int(x) for x in re.findall(r"NATIVE EL0 EXIT PID \d+ (\d+)", uart)]
assert exits == [51, 52, 53]
events = [[int(word) for word in line.split()[3:]] for line in uart.splitlines()
          if line.startswith("NATIVE FIXED EVENT")]
idle = (1 << 64) - 1
owners = [key for key, _ in itertools.groupby(row[4] for row in events)]
assert owners == [0, 2, 0, 1, 2, idle]
assert any(r[1] == 21 and r[3:5] == [0, 2] and r[12] == 1 for r in events)
assert any(r[1] == 23 and r[3:5] == [2, 0] and r[12:14] == [1, 2] for r in events)
assert any(r[1] == 3 and r[3:5] == [0, 1] and r[12] == 2 for r in events)
assert events[-1][12:15] == [idle] * 3

ram = (cap / "ram.bin").read_bytes()
ram_base = json.loads((cap / "launch.json").read_text())["ram_base"]
kernel_syms = symbols(cap / "kernel.elf")
def read64(pa):
    return struct.unpack_from("<Q", ram, pa - ram_base)[0]

spaces, size = symbol_containing(kernel_syms, "6SPACES")
va, case_size = symbols(root / "operational.elf")["ipc_case"]
assert case_size == struct.calcsize("<6q11Q")
page = spaces + size // 3  # Slot 1, the medium-priority worker.
for shift in [30, 21, 12]:
    desc = read64(page + 8 * ((va >> shift) & 511))
    assert desc & 3 == 3
    page = desc & 0x0000fffffffff000
checksum = struct.unpack_from("<6q11Q", ram, page - ram_base + (va & 4095))[-1]
assert checksum == 133693440
pool, size = symbol_containing(kernel_syms, "9ENDPOINTS")
assert size == 3 * 80 + 16
for slot in range(3):
    address = pool + slot * 80
    index = address - ram_base
    assert ram[index+72:index+74] == b"\0\0"  # Retired, not awaiting RECEIVE.
    assert ram[index+64] == 2 and read64(address) == 0  # No request or completion.
assert read64(pool + 3 * 80) == 1
print(json.dumps({"cold_rr": "pass", "owner_runs": [0, 2, 0, 1, 2, "idle"],
                  "exits": exits, "medium_checksum": checksum, "rr_quantum": 625000,
                  "endpoint_pool_bytes": size, "terminal_outstanding": 0,
                  "tokens_issued": 1, "fixed_dropped": 0, "kernel_sha256": digest(cap / "kernel.elf")}, indent=2))
