#!/bin/bash
set -euxo pipefail
out=$(cd "$(dirname "$0")" && pwd)
src=${JNOX_SOURCE:-$HOME/iv365-first-src}
first=${FIRST_PACKET:-$HOME/iv365-first-evidence}
source "$HOME/.cargo/env"
export PYTHONPATH="${JNOX_PYTHON_DEPS:-$HOME/jnox-169-first-e203caa/deps}" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true
cd "$src"
rev=$(git rev-parse HEAD)
test "$rev" = 6f51e0b138c9dd613a18cddc53495673c7f71c1b
test -z "$(git status --porcelain --untracked-files=no)"
git show "$rev:kernel/src/sync_ipc.rs" > "$out/sync_ipc.rs"
test "$(git hash-object "$out/sync_ipc.rs")" = ac9fdcd4d43488f9269cd6c229b8cc0ee0fec9da
rustc -vV > "$out/rustc.txt"
host_bin=$(mktemp)
trap 'rm -f "$host_bin"' EXIT
rustc --edition 2021 "$out/reply_exit.rs" -o "$host_bin"
"$host_bin" | tee "$out/host.stdout"
cp "$first/controls/operational.elf" "$first/controls/operational.c" "$out/"
test "$(sha256sum "$out/operational.elf" | cut -d' ' -f1)" = dbb5092fb977d42ffa4a8d0751452f45297a4419b7e28613ebb6bc65c8e1cb1e
test "$(git hash-object "$out/operational.c")" = 5048ebadc64d7e64bccf63bc3e1f279f364e3ca4
python3 tools/build_native_el0.py --elf "$out/operational.elf" --policy rr --priority 7 --arg high --peer-elf "$out/operational.elf" --peer-priority 4 --peer-arg medium --peer-elf "$out/operational.elf" --peer-priority 1 --peer2-arg low --ipc-route 0:2 --quantum-ticks 625000 --out "$out/package" > "$out/package.log" 2>&1
sha256sum "$out/package/kernel.elf" > "$out/preboot.sha256"
python3 tools/native_el0_capture.py "$out/capture" "$out/package/kernel.elf" "$out/operational.elf" "$out/operational.c" "$rev" --plain --manifest "$out/package/manifest.json" --expect-exit 51 --timeout 7 > "$out/capture.log" 2>&1
