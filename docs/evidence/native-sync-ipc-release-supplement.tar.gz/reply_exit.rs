mod sync_ipc;
use sync_ipc::SyncIpc;

const BASE: [u8; 2] = [7, 1];

fn run(reply_first: bool, consume_before_exit: bool) {
    let mut ipc = SyncIpc::new([2, 0]);
    ipc.call(0, 1, 0x11, 30, 1).unwrap();
    ipc.receive(1, 2).unwrap();
    let old = ipc.take(1).unwrap();
    assert_eq!(old.x2, 0x11);
    assert_eq!(ipc.priorities(BASE), [7, 7]);

    let reply_status = if reply_first {
        let status = ipc.reply(1, old.x1, 0x22, 10);
        assert_eq!(status, Ok(()));
        assert_eq!(ipc.priorities(BASE), BASE);
        if consume_before_exit {
            let completed = ipc.take(0).unwrap();
            assert_eq!((completed.status, completed.x1), (0, 0x22));
            assert_eq!(ipc.take(0), None);
        }
        ipc.exit(0, 10);
        status
    } else {
        ipc.exit(0, 10);
        let status = ipc.reply(1, old.x1, 0x22, 10);
        assert_eq!(status, Err(-116));
        status
    };

    assert_eq!(ipc.priorities(BASE), BASE);
    assert_eq!(ipc.take(0), None);
    assert_eq!(ipc.next_deadline(), None);
    ipc.restart(0).unwrap();
    assert_eq!(ipc.take(0), None);
    ipc.call(0, 1, 0x33, 30, 11).unwrap();
    ipc.receive(1, 12).unwrap();
    let new = ipc.take(1).unwrap();
    assert_ne!(old.x1, new.x1);
    assert_eq!(new.x2, 0x33);
    assert_eq!(ipc.reply(1, old.x1, 0xff, 13), Err(-116));
    assert!(ipc.blocked(0));
    assert_eq!(ipc.take(0), None);
    ipc.reply(1, new.x1, 0x44, 14).unwrap();
    let fresh = ipc.take(0).unwrap();
    assert_eq!((fresh.status, fresh.x1), (0, 0x44));
    assert_eq!(ipc.reply(1, new.x1, 0xff, 15), Err(-116));
    assert_eq!(ipc.priorities(BASE), BASE);
    assert_eq!(ipc.next_deadline(), None);
    assert!((0..2).all(|slot| !ipc.blocked(slot) && ipc.take(slot).is_none()));
    println!("reply_first={reply_first} consumed_before_exit={consume_before_exit} timestamp=10 reply={reply_status:?} old_token={} new_token={} stale=-116 fresh={} residual=0", old.x1, new.x1, fresh.x1);
}

fn main() {
    run(true, true);
    run(true, false);
    run(false, false);
}
