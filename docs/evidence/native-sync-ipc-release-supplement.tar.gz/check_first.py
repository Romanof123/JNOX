"""Check the frozen first-verifier container and its raw per-file digests without extracting it."""
import hashlib
import sys
import tarfile

expected_digest = "5a733c3b2545ca551eeb1f453f7e9f92982bf00d712f25f4ee5c6ab2a23da0ee"
with open(sys.argv[1], "rb") as f:
    assert hashlib.sha256(f.read()).hexdigest() == expected_digest
with tarfile.open(sys.argv[1], mode="r|gz") as archive:
    actual = {}
    for entry in archive:
        if not entry.isfile():
            continue
        with archive.extractfile(entry) as file:
            data = file.read()
        if entry.name == "./evidence-files.sha256":
            rows = data.decode().splitlines()
        else:
            actual[entry.name] = hashlib.sha256(data).hexdigest()
    expected = dict((name, digest) for digest, name in (row.split(maxsplit=1) for row in rows))
    assert expected == actual
print(f"sealed packet and {len(actual)} file hashes passed")
