set -eux
cd ~/v311
git -C src fetch -q --depth 1 https://github.com/Romanof123/JNOX.git b1be51a958ccc7bab7fcadd703ece4d353f0e12f
git -C src worktree add --detach ../baseline FETCH_HEAD
mkdir -p e/legacy/runs
export RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo
export PATH=$CARGO_HOME/bin:$PATH
cd baseline
python3 tools/build_native_el0.py --out ../e/legacy/default --elf ../e/elf/sensor.elf
python3 tools/build_native_el0.py --out ../e/legacy/probe
cd ..
python3 - <<'PY'
import debug,json
from pathlib import Path
old=debug.D
debug.D=old/'legacy';debug.runs=debug.D/'runs'
cfg=json.loads((old/'freeze.json').read_text())
for n in ['default','probe']:cfg['commands'][n][-1]=str(debug.D/n/'kernel.elf')
(debug.D/'freeze.json').write_text(json.dumps(cfg))
for n in ['default','probe']:
 debug.run(n)
 def entry(f):return next(x for l in f.read_text().splitlines() if (x:=json.loads(l)).get('event')=='entry')
 assert entry(debug.runs/(n+'.debug.jsonl'))==entry(old/'runs'/(n+'.debug.jsonl'))
 print('identical baseline entry '+n)
PY