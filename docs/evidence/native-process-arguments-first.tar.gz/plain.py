import pathlib as P,subprocess as S,json,time,hashlib
e=P.Path.home()/'v311/e'; src=e.parent/'src'
names='coop first-peer first-rust default mixed probe'.split()
term=[2,2,3,1,2,1]
flags='-machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -accel tcg -m 128M -nodefaults -display none -monitor none -no-reboot'.split()
commands={n:['qemu-system-aarch64',*flags,'-serial','stdio','-kernel',str(e/n/'kernel.elf')] for n in names}
(e/'freeze.json').write_text(json.dumps(dict(commands=commands,order=names,revision=S.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),manifest_hashes={n:hashlib.sha256((e/n/'manifest.json').read_bytes()).hexdigest() for n in names},observation=['_start','yield SVC and successor','__jnox_exit'],boot_timeout=120,debugger_timeout=180),indent=2))
for n,count in zip(names,term):
 path=e/'runs'/(n+'.uart')
 with path.open('wb') as out,(e/'runs'/(n+'.stderr')).open('wb') as err,S.Popen(commands[n],stdout=out,stderr=err) as proc:
  try:
   t=time.monotonic()+120
   while sum(x.startswith(b'NATIVE EL0 EXIT') for x in path.read_bytes().splitlines())<count:
    assert time.monotonic()<t and proc.poll() is None
    time.sleep(.01)
  finally:
   proc.terminate();proc.wait(3)