import json,struct,hashlib,subprocess as S
from pathlib import Path
from debug import tail,args
e=Path.home()/'v311/e'; runs=e/'runs'; rows=[]
for n in ['coop','first-peer','first-rust','default','mixed','probe']:
 m=json.loads((e/n/'manifest.json').read_text()); replay=json.loads((runs/(n+'.replay.json')).read_text())
 events=[json.loads(x) for x in (runs/(n+'.debug.jsonl')).read_text().splitlines()][1:]
 for ev in [v for v in events if v['event']=='entry']:
  i=ev['slot']; a=m['slots'][i].get('argv') if n!='probe' else ['/bin/native_startup_probe','8','13']; sp,b=tail(a); assert ev['sp']==sp and ev['tail']==b.hex()
  end=next(v for v in events if v.get('slot')==i and v['event']=='exit'); f=end['data']; y=[v for v in events if v['event']=='return' and v['slot']==i]
  if n=='probe':assert struct.unpack('<II',bytes.fromhex(f['products']))==(16,13) and end['code']==37
  else:
   lens=struct.unpack('<16I',bytes.fromhex(f['sensor_lengths']))
   assert list(lens)==[len(x.encode()) for x in a]+[0]*(16-len(a))
   label=a[4].encode() if len(a)>1 else b''
   assert bytes.fromhex(f['sensor_label'])==label+bytes(1024-len(label)) and f['sensor_argc']==len(a)
   low,hi=map(int,a[2:4]) if len(a)>1 else (0,0); count=hi-low
   assert f['sensor_count']==count and f['sensor_yields']==len(y)==count//4
   assert f['sensor_sum']==(sum(range(low,hi)) if len(a)>1 and a[1]=='sum' else 0)
   if count and a[1]=='minmax':assert [f['sensor_min'],f['sensor_max']]==[low,hi-1]
   assert end['code']==(0 if not count else 29 if a[1]=='minmax' else 43 if i==2 else 17)
  rows.append(dict(case=n,slot=i,sp=hex(sp),tail=len(b),argv=a,code=end['code'],count=f.get('sensor_count'),sum=f.get('sensor_sum'),min=f.get('sensor_min'),max=f.get('sensor_max'),returns=len(y)))
(e/'observations.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
print((e/'controls/stack-corrected-run.log').read_text())
print('all guest data matched',len(rows))
