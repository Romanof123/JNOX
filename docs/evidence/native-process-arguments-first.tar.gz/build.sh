set -eux
export RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo
export PATH=$CARGO_HOME/bin:$PATH
cd ~/v311/src
e=$HOME/v311/e
mkdir -p "$e/elf"
sh sdk/native-aarch64/build.sh examples/native-argv/sensor.c "$e/elf/sensor.elf"
sh sdk/native-aarch64/build-rust.sh examples/native-argv-rust/Cargo.toml "$e/elf/rust.elf"
for f in "$e"/elf/*.elf; do aarch64-linux-gnu-objdump -d "$f" > "$f.dis"; done
p=(--elf "$e/elf/sensor.elf" --arg sum --arg 16 --arg 32 --arg 'west rack')
q=(--peer-elf "$e/elf/sensor.elf" --peer-arg minmax --peer-arg 64 --peer-arg 96)
b(){ python3 tools/build_native_el0.py --out "$e/$1" "${@:2}"; }
b coop "${p[@]}" "${q[@]}" --peer-arg ''
b first-peer --policy fifo --priority 1 --peer-priority 7 "${p[@]}" "${q[@]}" --peer-arg xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
b first-rust --policy fifo --priority 1 --peer-priority 2 --peer-priority 7 "${p[@]}" "${q[@]}" --peer-arg '' --peer-elf "$e/elf/rust.elf" --peer2-arg sum --peer2-arg 240 --peer2-arg 256 --peer2-arg='-동쪽 센서'
b default --elf "$e/elf/sensor.elf"
b mixed --elf "$e/elf/sensor.elf" "${q[@]}" --peer-arg ''
b probe