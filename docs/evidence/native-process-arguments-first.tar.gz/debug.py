import json,struct,socket,subprocess as S,time,sys
from pathlib import Path
D=Path.home()/'v311/e'; runs=D/'runs'
args=[['/bin/app','sum','16','32','west rack'],['/bin/app','minmax','64','96',''],['/bin/app','sum','240','256','-동쪽 센서']]
def tail(a):
 legacy=len(a)==1 or 'probe' in a[0]; o=48 if legacy else (len(a)+3)*8
 bs=[v.encode()+b'\0' for v in a]; n=80 if legacy else (o+sum(map(len,bs))+15)//16*16
 sp=0x1011000-n; b=bytearray(n); struct.pack_into('<Q',b,0,len(a))
 for i,v in enumerate(bs):struct.pack_into('<Q',b,8+i*8,sp+o);b[o:o+len(v)]=v;o+=len(v)
 return sp,bytes(b)
def symbols(f):
 return {w[3]:(int(w[0],16),int(w[1],16)) for l in S.check_output(['aarch64-linux-gnu-nm','-S',f],text=True).splitlines() if len(w:=l.split())==4}
def run(n):
 slotargs={'coop':args[:2],'first-peer':[args[0],args[1][:-1]+['x'*32]],'first-rust':args,'default':[['/bin/app']],'mixed':[['/bin/app'],args[1]],'probe':[['/bin/native_startup_probe','8','13']]}[n]
 tails=[tail(a) for a in slotargs]; syms=[symbols(D/n/f) for f in ['user.elf','native_peer.elf','native_peer2.elf'][:len(tails)]]
 sock=str(runs/(n+'.sock')); cmd=json.loads((D/'freeze.json').read_text())['commands'][n]+['-S','-gdb','unix:'+sock+',server=on,wait=off']
 out=runs/(n+'.debug.jsonl'); t=time.monotonic()+180
 with out.open('x') as log,(runs/(n+'.debug-uart')).open('wb') as u,(runs/(n+'.debug-stderr')).open('wb') as err,S.Popen(cmd,stdout=u,stderr=err) as p:
  def emit(x):log.write(json.dumps(x)+'\n');log.flush()
  emit({'command':cmd}); s=socket.socket(socket.AF_UNIX);s.settimeout(10)
  try:
   while not Path(sock).exists():assert time.monotonic()<t;time.sleep(.01)
   s.connect(sock)
   def rsp(c):
    assert time.monotonic()<t
    b=c.encode();s.sendall(b'$'+b+b'#'+('%02x'%(sum(b)%256)).encode()); assert s.recv(1)==b'+',(c,'ack'); assert s.recv(1)==b'$'
    b=bytearray()
    while (x:=s.recv(1))!=b'#':assert x;b+=x
    z=s.recv(2,socket.MSG_WAITALL);assert int(z,16)==sum(b)%256;s.sendall(b'+');return b.decode()
   def mem(a,n):return bytes.fromhex(rsp(f'm{a:x},{n:x}'))
   def reg(a):return int.from_bytes(bytes.fromhex(rsp(f'p{a:x}')),'little')
   points={0x400000,0x400014}
   if n not in ('probe','default'):points|={0x400078,0x40007c}
   if n=='first-rust':points|={0x401018,0x40101c}
   def bp(pc,on):assert rsp(f'{"Z" if on else "z"}1,{pc:x},4')=='OK'
   rsp('qSupported:multiprocess+;xmlRegisters=aarch64');rsp('qXfer:features:read:target.xml:0,fff')
   for a in points:bp(a,True)
   exited=[];saved={}; first=[]
   while len(exited)<len(tails):
    stop=rsp('c'); assert stop.startswith(('T05','S05')),stop
    regs=bytes.fromhex(rsp('g'));sp,pc=struct.unpack_from('<QQ',regs,31*8)
    assert pc in points,(hex(pc),stop)
    active=[i for i,(a,b) in enumerate(tails) if mem(a,len(b))==b]; assert len(active)==1,active
    i=active[0]; ypc=0x401018 if i==2 else 0x400078
    if pc==0x400000:
     first.append(i); assert sp==tails[i][0];emit(dict(event='entry',slot=i,sp=sp,pc=pc,tail=mem(sp,len(tails[i][1])).hex()))
    elif pc==0x400014:
     exited.append(i);fields={}
     for k,(a,l) in syms[i].items():
      if k.startswith('sensor_') or k=='products':
       b=mem(a,l);fields[k]=b.hex() if k in ('sensor_label','sensor_lengths','products') else int.from_bytes(b,'little')
     emit(dict(event='exit',slot=i,pc=pc,sp=sp,code=int.from_bytes(regs[:8],'little'),data=fields))
    elif pc in (ypc,ypc+4):
     if pc==ypc:saved[i]=sp
     else:assert saved[i]==sp
     emit(dict(event='yield' if pc==ypc else 'return',slot=i,sp=sp,pc=pc))
    if len(exited)==len(tails):break
    bp(pc,False);assert rsp('s').startswith(('T05','S05'));bp(pc,True)
   assert first=={'first-peer':[1,0],'first-rust':[2,1,0]}.get(n,list(range(len(tails)))),first
  finally:p.terminate();p.wait(3);s.close()
if __name__=='__main__':
 for n in sys.argv[1:]:run(n)