set -ux
cd ~/v311
e=$PWD/e
export PYTHONPATH=$HOME/jnox-169-first-e203caa/deps
cd src
for n in coop first-peer first-rust default mixed probe; do
 src=examples/native-argv/sensor.c; opts=(--manifest "$e/$n/manifest.json"); code=17
 case $n in default|mixed) code=0;; probe) code=37; src=examples/portability/native_startup_probe.c; opts=();; esac
 if [[ $n == coop ]]; then opts+=(--arg sum --arg 16 --arg 32 --arg 'west rack' --peer-arg minmax --peer-arg 64 --peer-arg 96 --peer-arg ''); fi
 timeout 120 python3 tools/native_el0_capture.py "$e/runs/$n.capture" "$e/$n/kernel.elf" "$e/$n/user.elf" "$src" "$(git rev-parse HEAD)" --expect-exit "$code" "${opts[@]}" >"$e/runs/$n.digest" 2>"$e/runs/$n.capture-stderr"
 python3 tools/native_el0_replay.py "$e/runs/$n.capture" "$(cat "$e/runs/$n.digest")" >"$e/runs/$n.replay.json" 2>"$e/runs/$n.replay-stderr"
done
export RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup
"$HOME/jnox-169-first-e203caa/cargo/bin/rustc" --edition 2021 --test kernel/src/native_stack.rs -o "$e/stack-tests" >"$e/unit-original.log" 2>&1