import os,hashlib,json,subprocess as S,shutil,struct
from pathlib import Path
from itertools import product
d=Path.home()/'v311'; e=d/'e'; src=d/'src'; h=e/'controls';h.mkdir()
base=Path.home()/'jnox-169-first-e203caa';os.environ.update(RUSTUP_HOME=str(base/'rustup'),CARGO_HOME=str(base/'cargo'),PATH=str(base/'cargo/bin')+':'+os.environ['PATH'])
def run(name,cmd,ok,env=None,cwd=src):
 p=S.run(cmd,cwd=cwd,env=env,stdout=S.PIPE,stderr=S.STDOUT,timeout=100)
 (h/(name+'.log')).write_bytes(p.stdout)
 with (h/'commands.jsonl').open('a') as f:f.write(json.dumps(dict(name=name,argv=list(map(str,cmd)),rc=p.returncode,env={k:v for k,v in (env or {}).items() if k.startswith(('JNOX_','CARGO_TARGET_DIR'))}))+'\n')
 assert (p.returncode==0)==ok,(name,p.stdout[-1500:])
 return p
f=e/'elf/sensor.elf'; hd=hashlib.sha256(f.read_bytes()).hexdigest()
def pack(name,opts,ok=True):
 out=h/name
 run('pack-'+name,['python3','tools/build_native_el0.py','--out',out,*opts],ok,dict(os.environ,JNOX_NATIVE_ARGV2_HEX='notinherited'))
 if not ok:assert not out.exists();return
 return json.loads((out/'manifest.json').read_text())
options=['--arg','--peer-arg','--peer2-arg'];sel=['--elf',f,'--peer-elf',f,'--peer-elf',f]
for bits in product((0,1),repeat=3):
 xs=[['/bin/app']+([''] if b else []) for b in bits]
 flags=[item for i in [2,0,1] if bits[i] for item in (options[i],'')]
 m=pack('mask'+''.join(map(str,bits)),flags+sel)
 assert [x['argv'] for x in m['slots']]==xs
for name,values,ok in [('count15',['']*15,True),('count16',['']*16,False),('bytes1024',['x'*1023],True),('bytes1025',['x'*1024],False),('utf8fit',['x'*1020+'한'],True),('utf8over',['x'*1021+'한'],False),('literal',['"q",\n $PATH','-west','e\u0301','é'],True)]:
 m=pack(name,['--elf',f,*['--arg='+x for x in values]],ok)
 if ok:assert m['slots'][0]['argv']==['/bin/app',*values]
for n,args in [('missing-peer',['--elf',f,'--peer-arg','a']),('missing-peer2',['--elf',f,'--peer-elf',f,'--peer2-arg','']),('probe',['--arg',''])]:pack(n,args,False)
assert pack('source',['--source','examples/native-argv/sensor.c','--arg','a'])['slots'][0]['argv']==['/bin/app','a']
env=dict(os.environ,JNOX_BOARD='virt',JNOX_PROFILE='native',JNOX_APP='process',JNOX_NATIVE_ELF=str(f),JNOX_NATIVE_ELF_SHA256=hd,CARGO_TARGET_DIR=str(h/'raw-target'))
def raw(name,change,ok):return run('raw-'+name,['python3','tools/build_kernel.py','--arch','aarch64'],ok,dict(env,**change))
for n,x,ok in [('absent',None,True),('zero','00',True),('emptyarg','010000',True),('empty','',False),('odd','0',False),('nonhex','gg',False),('overrun','01020061',False),('trail','0000',False),('nul','01010000',False),('utf8','010100ff',False),('count','10'+'0000'*16,False),('budget','010004'+'61'*1024,False),('size','00'*2000,False)]:
 raw(n,{} if x is None else {'JNOX_NATIVE_ARGV0_HEX':x},ok)
raw('absent-peer',{'JNOX_NATIVE_ARGV1_HEX':'00'},False)
probe=e/'probe/user.elf'
raw('probe',dict(JNOX_APP='startup-probe',JNOX_NATIVE_ELF=str(probe),JNOX_NATIVE_ELF_SHA256=hashlib.sha256(probe.read_bytes()).hexdigest(),JNOX_NATIVE_ARGV0_HEX='00'),False)
peer=dict(JNOX_NATIVE_PEER_ELF=str(f),JNOX_NATIVE_PEER_ELF_SHA256=hd)
for label in ['one','two']:
 raw(label,dict(peer,JNOX_NATIVE_ARGV1_HEX='010300'+label.encode().hex()),True)
 shutil.copyfile(h/'raw-target/aarch64-unknown-none/release/jnox-kernel',h/('raw-'+label+'.elf'))
 assert pack('peer-'+label,['--elf',f,'--peer-elf',f,'--peer-arg',label])['slots'][1]['argv']==['/bin/app',label]
assert (h/'raw-one.elf').read_bytes()!=(h/'raw-two.elf').read_bytes()
run('stack-corrected-compile',['rustc','--edition','2021','--test',e/'corrected-stack.rs','-o',h/'stack-tests'],True)
run('stack-corrected-run',[h/'stack-tests'],True)
print('host controls passed')