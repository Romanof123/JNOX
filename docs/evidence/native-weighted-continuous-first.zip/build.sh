set -eu
export PATH="$HOME/.cargo/bin:$PATH"
D=/mnt/d/codex/weighted-328-first
cd "$D"
for arm in share wake; do
unzip -p /mnt/d/codex/jnox-328-archive/docs/evidence/native-weighted-integration-first.zip build/0ad1eda8fafdf45d948c3761af938cf18e68df80/native/weighted-$arm/kernel.elf > old-$arm.elf
n=closures:36
if [ "$arm" = wake ]; then n=wakes:3; fi
python3 /mnt/d/codex/weighted-328-first/src/tools/build_native_el0.py --out "$D/candidate-$arm" --policy weighted --weighted-continuous --weighted-notify "$n" --quantum-ticks 625000 --elf "$D/user.elf" --weight 1 --arg A --arg "$arm" --peer-elf "$D/user.elf" --peer-weight 2 --peer-arg B --peer-arg "$arm"
done
