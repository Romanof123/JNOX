from pathlib import Path
import sys, hashlib, subprocess as sp, shutil, json, zipfile, platform, os, argparse
D=Path(__file__).resolve().parent
O=Path('/mnt/d/codex/jnox-328-archive')
sys.path.insert(0,str(O/'tools'))
import native_weighted_capture as cap
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v): p.write_text(json.dumps(v,indent=2))
qemu=Path(shutil.which('qemu-system-aarch64')).resolve()
probe=O/'examples/portability/native_weighted_monitor.c'
rows=[]
for arm in ['share','wake']:
 for clock in ['default','icount3']:
  for kind in ['old','candidate']:
   name='%02d-%s-%s-%s'%(len(rows)+1,arm,clock,kind)
   root=D/name
   kernel=(D/('old-'+arm+'.elf')) if kind=='old' else D/('candidate-'+arm)/'kernel.elf'
   rev='0ad1eda8fafdf45d948c3761af938cf18e68df80' if kind=='old' else 'bf9aaefd7d08f50823699c2737c7845c6cafff69'
   syms=sp.check_output(['aarch64-linux-gnu-nm','-nS',kernel],text=True)
   rows.append(dict(name=name,kernel=str(kernel),sha256=sha(kernel),revision=rev,argv=cap.qemu_command(str(qemu),root,clock),ram=[cap.symbol_address(syms,s) for s in ['_start','__stack_top']],arm=arm,clock=clock,kind=kind))
assert not any((D/r['name']).exists() for r in rows)
orig=cap.TERMINAL
save(D/'freeze.json',dict(positions=rows,qemu=str(qemu),sha256=sha(qemu),version=sp.check_output([qemu,'--version'],text=True),host=platform.uname()._asdict(),cpus=sorted(os.sched_getaffinity(0)),user=sha(D/'user.elf'),build=(D/'build.sh').read_text(),driver=sha(Path(__file__)),candidate_terminal='NATIVE EL0 EXIT PID 1 <status> or NATIVE EL0 FAIL <code>',old_terminal=orig.decode()))
for row in rows:
 name=row['name']; root=D/name
 cap.TERMINAL=orig if row['kind']=='old' else rb'(?m)^NATIVE EL0 (EXIT PID 1 -?[0-9]+|FAIL [^\r\n]+)\r?\n'
 cap.SUCCESS='END' if row['kind']=='old' else 'EXIT PID 1 42'
 args=argparse.Namespace(root=root,revision=row['revision'],arm=row['arm'],clock=row['clock'],kernel=Path(row['kernel']),user=D/'user.elf',probe=probe,nm='aarch64-linux-gnu-nm',qemu=str(qemu),timer_observation=False)
 code=cap.capture(args); print(name,code,flush=True)
 pin=sha(root/'session.json')
 if row['kind']=='old':
  proc=sp.run([sys.executable,str(O/'tools/native_weighted_replay.py'),str(root),pin],capture_output=True)
  (root/'replay.txt').write_bytes(proc.stdout+proc.stderr)
  (root/'replay-exit.txt').write_text(str(proc.returncode))
 z=D/(name+'.zip')
 with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=3) as f:
  for p in sorted(root.iterdir()): f.write(p,p.name)
 with zipfile.ZipFile(z) as f:
  for p in root.iterdir(): assert hashlib.sha256(f.read(p.name)).hexdigest()==sha(p)
 with (D/'pins.txt').open('a') as f: f.write(f'{name} session {pin} zip {sha(z)}\n')