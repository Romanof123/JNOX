from pathlib import Path
import sys,json,hashlib,struct,tarfile,base64,io,subprocess,os
D=Path(__file__).resolve().parent
O=Path('/mnt/d/codex/jnox-328-archive')
sys.path[:0]=[str(D/'deps'),str(O/'tools')]
import native_el0_replay as nr
r={}
class ASIDSnapshot(nr.Snapshot):
 def leaf(self,root,va):return super().leaf(root&nr.PA_MASK,va)
for n in ['startup','weighted']:
 p=D/('control-'+n);mem=ASIDSnapshot(0x40200000,(p/'ram.bin').read_bytes())
 k=nr.elf_file((p/'kernel.elf').read_bytes());app=nr.elf_file((p/'user.elf').read_bytes())
 jp,size=nr.symbol(k,'jnox_native_el0_journal'); rows=list(struct.iter_unpack('<16Q',mem.read(jp,size)))
 root=rows[0][14];assert root>>48==1 and mem.leaf(root,0x1200000) is None
 if n=='startup':
  try:
   nr.replay(p,hashlib.sha256((p/'session.json').read_bytes()).hexdigest())
  except Exception as e:r['legacy_startup_replay']=str(e)
  # Audit raw startup data with the candidate's ASID-tagged TTBR.
  rep=nr.audit((p/'kernel.elf').read_bytes(),(p/'user.elf').read_bytes(),mem)
  nr.trace_check((p/'exceptions.log').read_bytes(),rep)
  rep.pop('page_descriptors');r[n]=rep
 else:
  addr,size=nr.symbol(app,'primary_total');assert int.from_bytes(nr.vread(mem,root,addr,size),'little')==17
  es=[list(map(int,l.split()[3:])) for l in (p/'uart.bin').read_text().splitlines() if l.startswith('NATIVE WEIGHTED EVENT')]
  assert all(e[16]==0 for e in es if e[3]==0) and [e[0] for e in es]==[0,1,2,4,1,3]
  assert rows[0][9]==17
  r[n]=dict(exit=17,primary_total=17,solo_timer_armed=False,no_notification_mapping=True)
r['options']={}
src=D/'src'; elf=D/'user.elf'
base=['python3',str(src/'tools/build_native_el0.py'),'--out',str(D/'rejection-output'),'--elf',str(elf),'--policy','weighted','--weight','1','--quantum-ticks','625000']
for key,args in {'no_cont':['--weighted-notify','wakes:3'],'double_cont':['--weighted-continuous']*2,'double_notify':['--weighted-continuous','--weighted-notify','wakes:3','--weighted-notify','wakes:4'],'zero':['--weighted-continuous','--weighted-notify','wakes:0'],'overflow':['--weighted-continuous','--weighted-notify','closures:18446744073709551616'],'invalid':['--weighted-continuous','--weighted-notify','wake:3'],'board':['--weighted-continuous','--board','pi4'],'nonweighted':['--weighted-continuous']}.items():
 cmd=base.copy()
 if key=='nonweighted':cmd[7]='rr';del cmd[8:10]
 p=subprocess.run(cmd+args,capture_output=True,text=True)
 assert p.returncode==2,(key,p.stderr)
 r['options'][key]=p.stderr.strip().splitlines()[-1]
evid=src/'docs/evidence'
raw=b''
for p in sorted(evid.glob('evd-049-raw-*.json')):
 x=json.loads(p.read_text());part=base64.b64decode(x['base64']);assert hashlib.sha256(part).hexdigest()==x['sha256'];raw+=part
with tarfile.open(fileobj=io.BytesIO(raw)) as f:
 for m in f:
  dest=D/'linked'/m.name;assert dest.resolve().is_relative_to((D/'linked').resolve())
  if m.isfile():dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(f.extractfile(m).read())
v=D/'linked/vr49-fresh'
r['linked']={}
for p in sorted(v.glob('*/uart')):
 name=p.parent.name;args=(['--wake'] if 'wake' in name else [])+(['--diagnostic'] if 'trace' in name else [])
 s=subprocess.run([sys.executable,src/'tools/weighted_replay.py',p,*args],capture_output=True,text=True)
 assert s.returncode==0,s.stderr
 r['linked'][name]=s.stdout
(D/'controls.json').write_text(json.dumps(r,indent=2))