from pathlib import Path
import sys,subprocess,os,json,hashlib
D=Path(__file__).resolve().parent
exe=next((D/'candidate-share/target/release/build').glob('*/build-script-build'))
env=dict(os.environ,JNOX_NATIVE_POLICY='weighted',JNOX_NATIVE_WEIGHTED_CONTINUOUS='1',JNOX_PROFILE='native',JNOX_BOARD='virt',TARGET='aarch64-unknown-none',OUT_DIR='/tmp')
tests={'zero':{'JNOX_NATIVE_WEIGHTED_NOTIFY':'closures:0'},'overflow':{'JNOX_NATIVE_WEIGHTED_NOTIFY':'wakes:18446744073709551616'},'invalid':{'JNOX_NATIVE_WEIGHTED_NOTIFY':'wrong:1'},'foreignboard':{'JNOX_BOARD':'pi4'},'foreignpolicy':{'JNOX_NATIVE_POLICY':'rr'},'foreignprofile':{'JNOX_PROFILE':'fixed'},'badcontinuous':{'JNOX_NATIVE_WEIGHTED_CONTINUOUS':'0'},'withoutcontinuous':{'JNOX_NATIVE_WEIGHTED_CONTINUOUS':None,'JNOX_NATIVE_WEIGHTED_NOTIFY':'wakes:3'}}
out={}
for n,v in tests.items():
 e=env|v
 q=subprocess.run([exe],env={k:v for k,v in e.items() if v is not None},capture_output=True,text=True,cwd=D/'src/kernel')
 assert q.returncode!=0
 out[n]=dict(changes=v,status=q.returncode,stderr=q.stderr)
(D/'raw-options.json').write_text(json.dumps(out,indent=2))
for n,data in out.items():print(n,data['stderr'].splitlines()[-2])
q=subprocess.run([sys.executable,D/'linked/vr49-fresh/verify.py'],capture_output=True,text=True)
(D/'linked-verifier.txt').write_text(q.stdout+q.stderr)
assert q.returncode==0