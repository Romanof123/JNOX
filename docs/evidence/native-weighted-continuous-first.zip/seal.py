from pathlib import Path
import json,zipfile,hashlib
D=Path(__file__).resolve().parent
report='''# Independent first cold comparison of #328

Candidate bf9aaefd7d08f50823699c2737c7845c6cafff69. Frozen plan 431bd709616a94ce70f86ccfdaa15e2d079a62ca. Historical native comparator 0ad1eda8fafdf45d948c3761af938cf18e68df80. All eight first attempts used the pinned application 9d3c6350a04536da091dd7bc77cfdcc81729f8baa431d6315e5258c28da67206. See freeze.json for the exact image SHA-256, command, kernel RAM extent, host affinity, machine and clock for every arm. QEMU 6.2.0, SHA-256 0a63468782d096485932acf6aa0a69d358b3e3a6f68f655e960e9f5e3fc578d8. Every position was sealed separately before advancing.

| First | Binary | Arm | Outcome |
|---|---|---|---|
| 01 | archived | share/default | timing FAIL. Lease 16 charged 979311 ticks vs H 781250; discrepancy 1939782 vs 2H 1562500. |
| 02 | candidate | share/default | PASS. 36 physical closures, A 8861981 ticks, B 17658819 ticks. |
| 03 | archived | share/icount3 | PASS |
| 04 | candidate | share/icount3 | PARTIAL. QEMU PID 942. 36 IRQ, two SVC and 38 EL0 returns in external trace. UART ends during event 8. No RAM, no terminal UART or full arithmetic proof. |
| 05 | archived | wake/default | PASS |
| 06 | candidate | wake/default | PASS. Three complete wake triples, A received 2452880 / 2479041 / 2471623 ticks in the blocked intervals. |
| 07 | archived | wake/icount3 | PASS |
| 08 | candidate | wake/icount3 | PASS. Each blocked interval had 2496584 ticks of A service. |

Both complete wake arms recorded three full A closures plus one distinct shortened deadline IRQ in each sleep. The candidate scores join all actual external IRQ/SVC and ERET PCs to raw RAM journal rows, replay rational service and ready floor, process frames, deadlines, return values, private memory and clock intervals. Each complete candidate position returned 41/42 and reported zero dropped rows. All measured candidate grants (including tails), preceding gaps, per-wake worst endpoints and share prefix/terminal bounds passed on those three complete observations. Each position's score retains the exact horizon and tail. Raw first observations and original comparator scores are included. The original replay recorded four import failures during the serial collector because its PYTHONPATH did not resolve; all four were rescored with the historical reader using the same pinned sessions, no second guest. The Windows checkout of historical scripts and diagnostic probe.c used CRLF line endings. Execution semantics and archived application and kernel binary bytes were preserved.

04 stderr shows observer PID 863 sent SIGTERM; the recorded OSError was [Errno 61] No data available. The observer had already started QEMU and collected external transitions. Native Linux observes D: as /mnt/d, 9p with aname=drvfs. A traceback and failing syscall/path were not retained by the historical observer. The outcome cannot establish the event that produced ENODATA. The two final SVCs at ELF exit-wrapper PC 0x400020 do not establish exit argument values or private product state.

Original startup control reached exit 37 and recovered products (16,13), errno 38, write -38 and zero stdout. The original startup reader rejects an ASID-tagged TTBR in its bare-PA walker. The ASID-aware walker reran its original data and trace predicates. Ordinary weighted control ran the supplied cooperative report at weight 3, kept solo timer unarmed, completed its sleep and returned its private result 17. Neither control mapped the completion page. The generic capture exit-37 comparison returns nonzero for this planned exit 17, scored independently. Eight EVD-049 linked historical UARTs passed the candidate decoder, all eight passed the historical RAM verifier and its five rejection controls, with zero fresh EL1 launches. The packaging and raw build rejection evidence is in controls.json and raw-options.json. Earlier pre-guest build setup attempts had a shell stdin parse error, Windows worktree path unsupported in WSL and a control CLI invocation missing its required quantum. A clean clone of the same candidate was used; exact tracked_changes is empty in its manifests.

Original historical records persist: #177 first four failed including one missing RAM, #183 share/default lease 7 and 10 and prefix 7 failed, #178 integration wake/default lease 14 exceeded H by 109296. #184 first two raw sessions lost, second cohort one position acquired with official replay unavailable, third cohort two retained and passing. Current first comparator timing failure and candidate 04 incomplete are separate observations. This report covers only the frozen virtual configuration and does not establish repeatability, physical WCET or causal attribution.
'''
(D/'first-report.md').write_text(report)
files=[*D.glob('0*.zip'),*D.glob('*-official.txt'),*D.glob('*-score.json'),*D.glob('*.sh'),*D.glob('*.py'),D/'freeze.json',D/'controls.json',D/'raw-options.json',D/'linked-verifier.txt',D/'pins.txt',D/'filesystem.txt',D/'first-report.md']
for n in ('control-startup','control-weighted'):files.extend((D/n).glob('*'))
for n in ('candidate-share','candidate-wake','control-startup-build','control-weighted-build'):
 files.extend((D/n).glob('*.json'));files.extend((D/n).glob('*.log'))
z=D/'first-evidence.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=4) as f:
 for p in sorted(set(files)):f.write(p,p.relative_to(D))
with zipfile.ZipFile(z) as f:assert not f.testzip()
for p in [D/'first-report.md',z]:print(p.name,hashlib.sha256(p.read_bytes()).hexdigest(),p.stat().st_size)