import pathlib,sys,subprocess,json,os
D=pathlib.Path(__file__).parent
env=dict(os.environ,PYTHONPATH=str(D/'deps'))
for ln in (D/'pins.txt').read_text().splitlines():
 n,_,pin,_,z=ln.split()
 if n.endswith('old'):
  p=subprocess.run([sys.executable,'/mnt/d/codex/jnox-328-archive/tools/native_weighted_replay.py',str(D/n),pin],env=env,capture_output=True)
  (D/(n+'-official.txt')).write_bytes(p.stdout+p.stderr)
  print(n,p.returncode,(p.stdout+p.stderr)[:160])
 else:
  es=[list(map(int,l.split()[3:])) for l in (D/n/'uart.bin').read_text().splitlines() if l.startswith('NATIVE WEIGHTED EVENT')]
  print(n,'over H',[(e[4],e[6]) for e in es[1:] if e[6]>781250], 'over G',[(e[14],e[15]-e[1]) for e in es[1:] if e[15]-e[1]>156250])