set -eu
D=/mnt/d/codex/weighted-328-first
O=/mnt/d/codex/jnox-328-archive/tools
export PATH="$HOME/.cargo/bin:$PATH"
export PYTHONPATH="$D/deps"
cd "$D"
python3 src/tools/build_native_el0.py --out "$D/control-weighted-build" --source "$D/src/examples/portability/native_cooperative_report.c" --policy weighted --weight 3 --quantum-ticks 625000
rev=bf9aaefd7d08f50823699c2737c7845c6cafff69
python3 "$O/native_el0_capture.py" "$D/control-startup" "$D/control-startup-build/kernel.elf" "$D/control-startup-build/user.elf" "$D/src/examples/portability/native_startup_probe.c" "$rev"
python3 "$O/native_el0_replay.py" "$D/control-startup" "$(sha256sum "$D/control-startup/session.json" | cut -d' ' -f1)" > "$D/control-startup-official.txt" || true
python3 "$O/native_el0_capture.py" "$D/control-weighted" "$D/control-weighted-build/kernel.elf" "$D/control-weighted-build/user.elf" "$D/src/examples/portability/native_cooperative_report.c" "$rev" || true
findmnt -T "$D" -o TARGET,SOURCE,FSTYPE,OPTIONS > "$D/filesystem.txt"
