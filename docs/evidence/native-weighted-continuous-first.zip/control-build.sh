set -eu
export PATH="$HOME/.cargo/bin:$PATH"
D=/mnt/d/codex/weighted-328-first
cd "$D"
python3 src/tools/build_native_el0.py --out "$D/control-startup-build"
python3 src/tools/build_native_el0.py --out "$D/control-weighted-build" --source "$D/src/examples/portability/native_startup_probe.c" --policy weighted --weight 3 --arg 8 --arg 13
