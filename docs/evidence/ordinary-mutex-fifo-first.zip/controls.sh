set -eux
cd ~/jnox277-first/evidence
for app in ordinary-pi ordinary-ceiling; do
 mkdir "$app"
 cp "../$app/aarch64-unknown-none/release/jnox-kernel" "$app/kernel.elf"
 sha256sum "$app/kernel.elf"
 for mode in plain trace; do
 args=(); if [ "$mode" = trace ]; then args=(-d int -D "$app/exceptions.log"); fi
 rc=0
 timeout -k 2s 15s qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -accel tcg -m 128M -nodefaults -display none -monitor none -serial stdio "${args[@]}" -kernel "$app/kernel.elf" </dev/null > "$app/$mode.uart" 2>"$app/$mode.stderr" || rc=$?
 echo "$rc" > "$app/$mode.rc"
 done
done
