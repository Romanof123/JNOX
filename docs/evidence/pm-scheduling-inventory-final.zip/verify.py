from pathlib import Path
import json,hashlib,re,subprocess,sys,zipfile
from datetime import datetime,timedelta
p=Path(__file__).resolve().parent
head=p.parent/'jnox245-final-links'
base=p.parent/'jnox245-final-base'
def get(name): return json.loads((p/name).read_bytes())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
m=get('follow/collection.json')
page,=m['pages']
rows=get('follow/page-1.json')
issues={r['number'] for r in rows if 'pull_request' not in r}
prs={r['number'] for r in rows if 'pull_request' in r}
old={r['number'] for r in get('original/open-items.json')}
assert (len(issues),len(prs),len(rows))==(32,18,50)
assert old < issues|prs and (issues|prs)-old=={245}
assert all(len([a for a in r['labels'] if a['name'].startswith('team:')])==1 for r in rows)
assert page['status']==200 and page['headers']['Link'] is None and page['headers']['Date']=='Tue, 24 Nov 2026 19:54:01 GMT'
assert page['headers']['ETag'] and page['headers']['X-GitHub-Request-Id'] and page['size']==len(rows) and sha(p/'follow/page-1.json')==page['sha256']
assert sha(head/'docs/evidence/pm-open-tracking-pagination-follow-up.zip')=='54047c1d8cc797b859186e8cf0ecbc8c9a8bfdd3fd4192a973929a05949e7e7e'
audit=subprocess.check_output([sys.executable,'-B',base/'tools/open_tracking.py',p/'follow/page-1.json'],encoding='utf8')
assert audit.splitlines()==(p/'follow/audit.txt').read_text('utf8').splitlines()
assert set(map(int,m['primary']))==prs
for n,i in m['primary'].items():
    line=next(x for x in audit.splitlines() if x.startswith(f'PR #{n}:'))
    assert i in issues and str(i) in re.findall(r'#(\d+)',line.split(':')[1])
for name in ['README.md','README.ko.md']:
    assert 'https://github.com/Romanof123/JNOX/issues/6)' in (head/name).read_text('utf8') and 6 in issues
for name in ['docs/lifecycle.md','docs/lifecycle.en.md']:
    dest='evidence/pm-open-tracking-20261124T194750Z.en-ko.md'
    assert dest in (head/name).read_text('utf8') and (head/'docs'/dest).is_file()
s=(head/'docs'/dest).read_text('utf8')
for name in re.findall(r'\]\(([^)]+)\)',s):
    if not name.startswith(('https:','#')): assert ((head/'docs'/dest).parent/name).is_file(),name
print('Follow-up checks passed. Headers, body hash, ZIP digest, 50 unique items, 18 reciprocal primary pairs and one team per item, README/lifecycle links and relative report targets.')
