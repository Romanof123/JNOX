# Replay the twelve cold boots / 콜드 부팅 12건 재검증

Read the measured results in [REPORT.en-ko.md](REPORT.en-ko.md). This archive contains the original launch commands, signed process exit records, full linked kernel RAM snapshots and UART streams. The three role executables and six packages are in `apps/` and `packages/`. The same per-case package was used under each clock. Build commands and compiler versions are in `logs/`. The nine archived source directories are the inputs to the native build.

On Linux with Python 3, Git, GNU coreutils and AArch64 GNU binutils, run the following command from the extracted directory.

```sh
bash scripts/replay.sh .
```

The replay checks every sealed file hash, reconstructs the shared Git tree and both commit objects, verifies the source blobs and role inputs, validates the original QEMU commands, and regenerates all twelve observation records. The seven interval controls and six capture controls run offline.

압축을 푼 폴더에서 위 명령을 실행하면 실제 RAM·UART 기록을 다시 읽어 12건의 관측값을 바이트 단위로 대조한다. 로컬·공개 커밋의 공통 트리, 원본 파일 해시, 역할별 ELF, 실행 명령과 종료 코드도 확인한다. 두 클록은 사례·정책별로 동일한 커널 패키지를 사용했다. 측정 결과는 [영문·한국어 보고서](REPORT.en-ko.md)에 있다.

| Source identity / 소스 | SHA |
|---|---|
| Local frozen commit / 로컬 | `aa8e7e104033a372eed0675f3b76f7fb9af2a38e` |
| Public commit / 공개 | `e84ad6ce6543bad37e1e5254f7a9864c838eafd3` |
| Shared Git tree / 공통 트리 | `2491425ca0abfe0a5d2d044bd94eb54f4c282d13` |
