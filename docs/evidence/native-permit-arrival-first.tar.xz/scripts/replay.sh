#!/usr/bin/env bash
set -euo pipefail
root=$(realpath "${1:-.}")
cd "$root"
export PYTHONDONTWRITEBYTECODE=1 LC_ALL=C
tmp=$(mktemp)
trap 'rm -f "$tmp"' EXIT
sha256sum --quiet -c SHA256SUMS
python3 -B scripts/provenance.py .
python3 -B verification/verify.py . > "$tmp"
cmp "$tmp" verification/observations.json
python3 -B verification/interval_controls.py
python3 -B verification/capture_controls.py .
echo 'All twelve original observations reproduced from the extracted packet.'
