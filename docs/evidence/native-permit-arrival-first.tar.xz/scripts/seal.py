"""Seal the measured run packet into a lossless sparse GNU tar."""
from hashlib import sha256
from pathlib import Path
import os, shutil, subprocess, sys

root,out=map(Path,sys.argv[1:])
root=root.resolve()
out=out.resolve()
view=root.parent/'transfer-view'
view.mkdir()
dedup={}
manifest=[]
def digest(p):
    h=sha256()
    with p.open('rb') as fi:
        for block in iter(lambda:fi.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
for original in sorted(root.rglob('*')):
    name=original.relative_to(root)
    if not original.is_file() or 'target' in name.parts or '__pycache__' in name.parts:
        continue
    dest=view/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    hashval=digest(original)
    if name.name=='ram.bin' and hashval not in dedup:
        subprocess.run(['cp','--reflink=never','--sparse=always',original,dest],check=True)
        assert digest(dest)==hashval
    elif hashval in dedup:os.link(dedup[hashval],dest)
    else:os.link(original,dest)
    dedup[hashval]=dest
    manifest.append((name,hashval))
check=view/'SHA256SUMS'
check.write_text(''.join(h+'  '+str(n)+'\n' for n,h in manifest))
paths=[n for n,h in manifest]+[Path('SHA256SUMS')]
def order(n):
    return (n.name,str(n))
lst=root.parent/'transfer-order'
lst.write_bytes(b''.join(os.fsencode(str(n))+b'\0' for n in sorted(paths,key=order)))
archive=out/'native-permit-arrival-first.tar.xz'
with archive.open('xb') as f:
    tar=subprocess.Popen(['tar','--sparse','--format=gnu','--owner=0','--group=0','--numeric-owner',
        '--mtime=@0','-C',view,'--null','-T',lst,'-cf','-'],stdout=subprocess.PIPE)
    comp=subprocess.run(['xz','-T1','-9e','-c'],stdin=tar.stdout,stdout=f)
    tar.stdout.close()
    if tar.wait() or comp.returncode:raise RuntimeError('compression failed')
receipt=digest(archive)+'  '+archive.name+'\n'
(out/(archive.name+'.sha256')).write_text(receipt)
print(receipt.strip(),archive.stat().st_size,'bytes',len(manifest),'original hashes',flush=True)
verify=root.parent/'transfer-replay'
verify.mkdir()
subprocess.run(['tar','-xJf',archive,'-C',verify],check=True)
assert (verify/'SHA256SUMS').read_bytes()==check.read_bytes()
subprocess.run(['sha256sum','--quiet','-c','SHA256SUMS'],cwd=verify,check=True)
print('Clean-extraction hashes verified.',flush=True)
subprocess.run(['bash','scripts/replay.sh','.'],cwd=verify,check=True)
