"""Reconstruct the frozen Git tree and audit the twelve original launch identities."""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile


def git_object(kind, data):
    return hashlib.sha1(f"{kind} {len(data)}\0".encode() + data).hexdigest()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


root = Path(sys.argv[1]).resolve()
source = root/"source"
rev, tree = (source/"revision").read_text().splitlines()
public, public_tree = (source/"public-revision").read_text().splitlines()
assert public_tree == tree
for sha in (rev,public):
    raw = (source/f"{sha}.commit").read_bytes()
    assert git_object("commit",raw) == sha and raw.startswith(f"tree {tree}\n".encode())
with tempfile.TemporaryDirectory() as temp:
    subprocess.run(["git","init","-q",temp],check=True)
    subprocess.run(["git","-C",temp,"update-index","--index-info"],input=(source/"tree.txt").read_bytes(),check=True)
    rebuilt = subprocess.check_output(["git","-C",temp,"write-tree","--missing-ok"],text=True).strip()
    assert rebuilt == tree
    listed = subprocess.check_output(["git","-C",temp,"ls-files","--stage","-z"]).split(b"\0")
expected = {}
areas = set("arch boards examples kernel sdk services tools trace verification".split())
for line in filter(None,listed):
    header, name = line.split(b"\t",1)
    path = name.decode()
    if path.split("/")[0] in areas:
        expected[path] = header.split()[1].decode()
with tarfile.open(source/"production.tar") as archive:
    files = {m.name:git_object("blob",archive.extractfile(m).read()) for m in archive if m.isfile()}
assert files == expected
role_hashes = [digest(root/"apps"/(name+".elf")) for name in ("sender","receiver","supervisor")]
with (root/"ledger.tsv").open() as handle:
    runs = list(csv.DictReader(handle, delimiter="\t"))
cases = ["arrival-before","arrival-same","arrival-after"]
matrix = [(clock,policy,case) for clock in ("default","count0") for policy in ("fifo","rr") for case in cases]
assert [(r["clock"],r["policy"],r["case"]) for r in runs] == matrix
kernel_names = {}
qemus = set()
for num,(r,(clock,policy,case)) in enumerate(zip(runs,matrix),1):
    assert r["n"] == str(num) and r["build_rc"] == r["capture_rc"] == "0" and r["revision"] == rev
    run = root/"runs"/r["attempt"]
    cap = run/"cap"
    pkg = root/"packages"/r["package"]
    receipt = json.loads((cap/"session.json").read_text())
    launch = json.loads((cap/"launch.json").read_text())
    m = json.loads((pkg/"manifest.json").read_text())
    assert m == launch["argument_package"] == json.loads((run/"manifest.json").read_text())
    assert m["commit"] == rev == launch["revision"] and not m["tracked_changes"]
    assert m["policy"] == policy and m["board"] == "virt"
    assert m["loan_route"] == {"producer":0,"consumer":1} and m["ipc_routes"] == [{"caller":2,"server":0},{"caller":2,"server":1}]
    assert m["safety_boundary"] == {"scenario":case,"decision_event":12}
    assert [s["priority"] for s in m["slots"]] == [7,6,4]
    assert [s["elf_sha256"] for s in m["slots"]] == role_hashes
    assert set(m["source_sha256"].values()) == set(role_hashes)
    for slot in m["slots"]:
        assert slot["argv"] == ["/bin/app",case] and digest(pkg/slot["elf"]) == role_hashes[slot["slot"]]
    kernel = digest(cap/"kernel.elf")
    assert kernel == launch["kernel_sha256"] == m["kernel_elf_sha256"] == digest(pkg/"kernel.elf")
    assert kernel_names.setdefault((policy,case),kernel) == kernel
    assert digest(cap/"user.elf") == launch["user_sha256"] == role_hashes[0]
    assert (cap/"ram.bin").stat().st_size == launch["ram_bytes"] and launch["ram_base"] == 0x40200000
    assert receipt["marker"] == "EXIT 71" and receipt["observed_slot_exits"] == {"0":71,"1":72,"2":73}
    assert set(receipt["hashes"]) == {p.name for p in cap.iterdir() if p.is_file() and p.name!="session.json"}
    assert all(digest(cap/n) == h for n,h in receipt["hashes"].items())
    args = launch["argv"]
    base = ["-machine","virt,gic-version=2","-cpu","cortex-a72","-smp","1","-accel"]
    timing = ["tcg"] if clock == "default" else ["tcg,thread=single","-icount","shift=0,align=off,sleep=off"]
    tail = ["-m","128M","-nodefaults","-display","none","-monitor","none","-no-reboot","-qmp","stdio","-serial"]
    assert args[1:-3] == base+timing+tail and args[-3].endswith("/cap/uart.bin") and args[-2]=="-kernel" and args[-1].endswith("/cap/kernel.elf")
    qemus.add(launch["qemu_sha256"])
assert len(qemus) == 1 and len(kernel_names) == 6
print(f"Verified {len(files)} source blobs, two commit identities, three role ELFs, six packages and twelve QEMU launches with RAM, UART and signed exit receipts.")
