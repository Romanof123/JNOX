"""Counterfactuals modify decoded host memory only, leaving all archived captures intact."""
from copy import deepcopy
from pathlib import Path
import sys
from capture import read_run
from verify import verify

root = Path(sys.argv[1])
run = root/"runs"/"001-default-fifo-arrival-before"
actual = read_run(root,run)
baseline = verify(actual)
if not all(v for k,v in baseline["tests"].items() if k!="expiry_by_controller_at_D"):
    raise ValueError("baseline")
def rejected(label, mutate):
    record = deepcopy(actual)
    mutate(record)
    try:
        flagged = not verify(record)["tests"][label]
    except ValueError:
        flagged = True
    if not flagged:
        raise AssertionError(label)
def corrupt(a):
    sender = next(i for i,r in enumerate(a["sender_rows"]) if r[3]==2 and r[6]==4)
    raw = bytearray(a["sender_bytes"][sender])
    raw[-1] ^= 1
    a["sender_bytes"][sender] = bytes(raw)
def bad_crc(a):
    handle = baseline["handle"]
    snap = next(e for e in a["events"] if e[0]==7 and e[2]==handle)
    snap[-1] ^= 1
rejected("three_identical_44_byte_copies",corrupt)
rejected("wire_crc",bad_crc)
rejected("actual_handle_handoff",lambda a: a["events"].remove(next(e for e in a["events"] if e[0]==6 and e[2:5]==[1,36,0] and e[6]==baseline["handle"])))
rejected("acknowledged_high_before_staging",lambda a:a["ack"].__setitem__(7,0))
rejected("one_rise_then_one_fall_at_expiry",lambda a:a.update(terminal=1))
rejected("authority_observed_fault_seq3",lambda a:a["supervisor_rows"][-1].__setitem__(8,3))
print("6 archived-capture counterfactuals detected")
