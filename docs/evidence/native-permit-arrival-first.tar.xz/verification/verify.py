"""Offline evidence checks. Reads a sealed capture directory and prints JSON."""
import argparse
import csv
import json
import struct
import zlib
from pathlib import Path

from capture import read_run


def single(records):
    if len(records) != 1:
        raise ValueError(f"expected one observation, got {len(records)}")
    return records[0]


def position(lo, hi, tick):
    if hi < lo:
        raise ValueError("reversed interval")
    if hi < tick:
        return "before"
    if lo > tick:
        return "after"
    return "equal" if lo == hi else "indeterminate"


def verify(a):
    ev = a["events"]
    def events(kind):
        return [e for e in ev if e[0] == kind]
    if any(len(e) != 10 for e in ev) or a["safety_loss"] != [[0]]:
        raise ValueError("incomplete safety journal")
    hz = single(events(1))[2]
    if hz != 62500000:
        raise ValueError("counter frequency")
    epoch = a["epoch"]
    old = epoch + hz//50
    deadline = old + hz//50
    sent_index = single([i for i,s in enumerate(a["sender_rows"]) if s[3] == 2 and s[5:7] == [1,4] and s[8] and s[9:11] == [0,0]])
    sender = a["sender_rows"][sent_index]
    staged_index = single([i for i,s in enumerate(a["sender_rows"]) if s[3]==1 and s[5:7]==[1,4]])
    staged = a["sender_rows"][staged_index]
    handle = sender[8]
    pub = single([p for p in events(11) if p[4] == handle and p[5] == 0])
    snap = single([s for s in events(7) if s[2] == handle])
    acquire = single([e for e in events(6) if e[2:5] == [1,35,0] and e[7:9] == [handle,44]])
    release = single([e for e in events(6) if e[2:5] == [1,36,0] and e[6] == handle])
    enqueue = single([e for e in events(6) if e[2:5] == [0,34,0] and e[6] == handle])
    ridx = single([i for i,r in enumerate(a["received_rows"]) if r[2] == handle])
    receiver = a["received_rows"][ridx]
    wire = b"".join(q.to_bytes(8,"little") for q in snap[4:])[:44]
    vals = struct.unpack("<BBHHHQQQIB3sI",wire)
    issue = vals[7]
    expiry = single([e for e in events(3) if e[3:6] == [1,3,old]])
    check = single([e for e in events(12) if e[2] == expiry[2] and e[4:9] == [1,3,old,0,1]])
    operand = check[2]
    outputs = events(2)
    completions = events(10)
    gaps = [(b[2]-a_[3],b[3]-a_[2]) for a_,b in zip(completions,completions[1:])]
    transitions = [e[4:6] for e in outputs]
    ack = a["ack"]
    selector = a["roles"][0][-1]
    planned = {"arrival-before":39,"arrival-same":40,"arrival-after":41}[selector]
    predicates = {
        "frozen_application_calendar": sender[0]==epoch+planned*hz//1000 and all(len(args)==2 and args[-1]==selector for args in a["roles"]),
        "complete_activation_series": len(completions)==17 and all(c[2]<=c[3] for c in completions) and all(low>=0 and high>=low for low,high in gaps),
        "acknowledged_high_before_staging": ack[:9]==[0x6c617374,3,0,1,3,old,1,1,0] and ack[10:]==[1,3,3,old] and old<=ack[9]<staged[1] and ack[9]<deadline and a["ipc"][:2]==[[1,0x6c617374,3,0],[0,0x696e707574,0x696e707574,0]],
        "authority_live_seq3_at_23ms": any(r[0]==epoch+23*hz//1000 and r[7:9]==[3,3] and r[9:13]==[1,1,3,3] and r[13:]==[old,old,1] and r[2]<=staged[1] for r in a["supervisor_rows"]),
        "same_staged_grant": staged[0]==epoch+39*hz//1000 and staged[8]==handle and staged[9]==0 and staged[2]<=pub[2] and a["sender_bytes"][staged_index]==wire,
        "three_identical_44_byte_copies": sender[8]==receiver[2]==handle and receiver[4]==44 and a["sender_bytes"][sent_index]==wire==a["received_bytes"][ridx],
        "valid_semantics_at_D": vals[:7]==(1,1,44,1,257,1,4) and issue==epoch+39*hz//1000 and vals[8:11]==(20,1,bytes(3)) and 0 <= deadline-issue < hz//50,
        "wire_crc": zlib.crc32(wire[:40]) == vals[-1],
        "publication_header": pub[6:] == [1,1,4,issue] and snap[3] == 1,
        "actual_handle_handoff": ev.index(pub)<ev.index(enqueue)<ev.index(snap)<ev.index(acquire)<ev.index(release) and release[1]<=receiver[7],
        "prior_accepted_seq3": any(r[5:7]==[0,0] and r[9]==1 and r[16:18]==[3,old] and r[8]<pub[2] for r in a["received_rows"]),
        "open_gate_and_prior_rise": any(e[2]<pub[2] and e[4:]==[1,3,old,0,0,1] for e in events(12)) and transitions==[[0,1],[1,0]] and outputs[0][3]<pub[2],
        "expiry_by_controller_at_D": check[3]==1 and operand==deadline and check[9]==1,
        "fault_before_private_decision": check[1]<=receiver[7] and receiver[5:7]==[17,1<<63] and receiver[9:12]==[1,5,3],
        "no_successful_seq4_commit": not any(e[2:6]==[1,60,2,0] and e[6:8]==[1,4] for e in events(5)),
        "one_rise_then_one_fall_at_expiry": transitions==[[0,1],[1,0]] and ev.index(expiry)<ev.index(outputs[1])<ev.index(check) and outputs[1][2]>=operand>=deadline and a["terminal"]==0,
        "authority_observed_fault_seq3": all(any(r[0]==epoch+ms*hz//1000 and r[7:9]==[5,5] and r[9:13]==[1,1,3,3] and r[13:]==[old,old,1] and r[1]>=operand for r in a["supervisor_rows"]) for ms in (48,65)),
        "normal_exit_codes": a["exits"]==[[0,71],[1,72],[2,73]],
    }
    return dict(tests=predicates, actual_publish=pub[2:4], kernel_snapshot_tick=snap[1], expiry_operand=operand, staged_bounds=staged[:3], stage_minus_target=[staged[1]-staged[0],staged[2]-staged[0]], D=deadline, epoch=epoch, check_site=check[3], check_minus_D=operand-deadline,
                publish_minus_D=[x-deadline for x in pub[2:4]], publish_vs_D=position(*pub[2:4],deadline),
                publish_minus_expiry=[x-operand for x in pub[2:4]], publish_vs_expiry=position(*pub[2:4],operand), receipt_minus_D=snap[1]-deadline,
                receipt_minus_publish=[snap[1]-pub[3],snap[1]-pub[2]], receipt_minus_expiry=snap[1]-operand,
                private_decision_minus_expiry=receiver[7]-operand, output_transitions=transitions,
                completion_gap_max_ticks=[max(v[i] for v in gaps) for i in (0,1)] if gaps else None,
                completion_gaps_proven_over_5ms=sum(lo>hz//200 for lo,hi in gaps),
                completion_gaps_ambiguous_at_5ms=sum(lo<=hz//200<hi for lo,hi in gaps),
                completion_count=len(completions), handle=handle, seq4_hex=wire.hex(),
                revision=a["revision"], session_sha256=a["session_hash"], kernel_sha256=a["kernel"], app_sha256=a["app_hashes"], roles=a["roles"], policy=a["policy"], qemu_argv=a["launch_args"],
                safety_loss=a["safety_loss"], fixed_loss=a["fixed_loss"], terminal=a["terminal"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("packet",type=Path)
    root = parser.parse_args().packet
    attempts = []
    with (root/"ledger.tsv").open() as ledger:
        for entry in csv.DictReader(ledger, delimiter="\t"):
            record = {"ledger":entry}
            attempts.append(record)
            try:
                record["observation"] = verify(read_run(root,root/"runs"/entry["attempt"]))
            except (OSError, ValueError, IndexError, KeyError) as exc:
                record["unscored"] = str(exc)
    print(json.dumps({"attempts":attempts}, indent=2))


if __name__ == "__main__":
    main()



