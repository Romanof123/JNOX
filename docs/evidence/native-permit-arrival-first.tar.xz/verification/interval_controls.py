"""Check equality classification against synthetic interval arithmetic only."""
from verify import position

for interval, expected in (
    ((97,99,100),"before"),
    ((100,100,100),"equal"),
    ((99,100,100),"indeterminate"),
    ((99,101,100),"indeterminate"),
    ((100,101,100),"indeterminate"),
    ((101,102,100),"after"),
):
    if position(*interval) != expected:
        raise AssertionError(interval)
try:
    position(100,99,100)
except ValueError:
    pass
else:
    raise AssertionError("inverted bracket accepted")
print("7 interval classification controls passed")
