#!/usr/bin/env bash
set -eu
raw=/home/ywcho/v376-ipv4-05b26e7-first
src=/home/ywcho/v376-ipv4-05b26e7-checkout
cd "$src"
case "$1" in
tap)
  ns=jnx376v05b
  ip netns add "$ns"
  trap 'ip netns del "$ns"' EXIT
  ip -n "$ns" link set lo up
  ip netns exec "$ns" ip tuntap add dev jnx0 mode tap
  ip -n "$ns" addr add 10.0.2.2/24 dev jnx0
  ip -n "$ns" link set jnx0 up
  (ip -n "$ns" -br addr; ip -n "$ns" route) > "$raw/tap-config.txt"
  test -z "$(ip -n "$ns" route show default)"
  test "$(ip -n "$ns" link | awk '/^[0-9]+:/ {print $2}' | xargs)" = "lo: jnx0:"
  prefix=(ip netns exec "$ns")
  tap=(--isolated-tap jnx0)
  ;;
slirp) prefix=(); tap=();;
esac
for pol in fifo rr; do
  dir="$raw/$pol-$1-first"
  "${prefix[@]}" python3 examples/native-inet-sockets/peer.py "$raw/$pol" "$dir" "${tap[@]}" --timeout 20 > "$dir-peer.log" 2>&1 && ret=0 || ret=$?
  echo "$pol-$1-peer $ret" | tee -a "$raw/status.txt"
  if [[ -f "$dir/ram.bin" ]]; then
    PYTHONPATH=/home/ywcho/jnox-169-first-e203caa/deps python3 examples/native-inet-sockets/private_results.py "$raw/$pol" "$dir" "$raw/tcp.elf" "$raw/udp.elf" > "$dir/private.json" 2>"$dir/private.stderr" && ret=0 || ret=$?
    echo "$pol-$1-private $ret" | tee -a "$raw/status.txt"
  fi
  cat "$dir/status.json" || cat "$dir-peer.log"
done
