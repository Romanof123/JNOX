#!/usr/bin/env bash
set -euo pipefail
src=/home/ywcho/v376-ipv4-05b26e7-checkout
raw=/home/ywcho/v376-ipv4-05b26e7-first
scripts=$(cd "$(dirname "$0")" && pwd)
source "$HOME/.cargo/env"
export CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true
cd "$src"
sh sdk/native-aarch64/build.sh --local-socket "$scripts/resources.c" "$raw/resources.elf" > "$raw/build-resources.log" 2>&1
for pol in fifo rr; do
    args=()
    if [[ $pol == rr ]]; then args=(--quantum-ticks 625000); fi
    pkg="$raw/pkg-resources-$pol"
    python3 tools/build_native_el0.py --out "$pkg" --policy "$pol" --elf "$raw/resources.elf" --priority 4 --arg a --peer-elf "$raw/resources.elf" --peer-priority 4 --peer-arg b --peer-elf "$raw/broker.elf" --peer-priority 7 --peer2-arg 3 --ipc-route 1:0 --ipc-route 0:2 --ipc-route 1:2 --socket-service 2 --net-service 2 "${args[@]}" > "$raw/pkg-resources-$pol.log" 2>&1
    ret=0
    python3 "$scripts/resource-boot.py" "$pkg" "$raw/cap-resources-$pol" "$src" > "$raw/resources-$pol.log" 2>&1 || ret=$?
    echo "resources-$pol $ret" | tee -a "$raw/status.txt"
done
