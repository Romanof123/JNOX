"""Capture a bounded three-slot resource workload using only the isolated QEMU user profile."""
import json, re, sys, subprocess, tempfile, time
from pathlib import Path
pkg,out,src=map(Path,sys.argv[1:])
sys.path.insert(0,str(src/'examples/native-inet-sockets'))
from peer import capture_ram
out.mkdir()
meta=json.loads((pkg/'manifest.json').read_text())
with tempfile.TemporaryDirectory() as tmp:
    qmp=Path(tmp)/'qmp'
    argv=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-no-reboot','-serial','file:'+str(out/'uart'),'-qmp',f'unix:{qmp},server=on,wait=off','-kernel',str(pkg/'kernel.elf'),'-global','virtio-mmio.force-legacy=false','-netdev','user,id=lan,restrict=on','-device','virtio-net-device,netdev=lan,mac=52:54:00:12:34:56']
    (out/'launch.json').write_text(json.dumps(dict(argv=argv,kernel_sha256=meta['kernel_elf_sha256']),indent=2))
    with (out/'qemu.log').open('x') as log:
        proc=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=log,stderr=log)
        try:
            deadline=time.monotonic()+12
            while time.monotonic()<deadline:
                uart=(out/'uart').read_text(errors='replace') if (out/'uart').exists() else ''
                if len(re.findall(r'NATIVE EL0 EXIT PID ',uart))==3 or 'NATIVE EL0 FAULT' in uart: break
                time.sleep(.04)
            capture_ram(qmp,out/'ram.bin')
        finally:
            proc.terminate()
            proc.wait(timeout=5)
exits=re.findall(r'NATIVE EL0 EXIT PID (\d+) (-?\d+)',(out/'uart').read_text())
print(exits)
assert exits==[('0','81'),('1','82'),('2','0')]
