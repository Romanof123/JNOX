"""Offline, digest-bound verification of private guest results and independent Ethernet captures."""
import collections
import hashlib
import json
import re
import struct
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
sys.path.insert(0, str(root / "source/tools"))
from native_amc_roots import linked_roots
from native_el0_replay import Snapshot, elf_file, permissions, symbol, vread

rev = "05b26e7407f1901e9213280846f295b12d681024"
host, guest = bytes((10,0,2,2)), bytes((10,0,2,15))
hexmac = bytes.fromhex("525400123456")
sent = [bytes((85,i,10*i)) for i in [1,2,3,4]] + [b"DONE"]
received = [bytes((82,i,10*i)) for i in [1,4,3,0]]
full = [bytes((82,i,10*i)) for i in [1,2,3,4,0]]

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def journal(p):
    return [json.loads(line) for line in p.read_text().splitlines()]

def ethernet(path, tap):
    raw = path.read_bytes()
    assert raw[:4] == bytes.fromhex("d4c3b2a1") and struct.unpack_from("<I",raw,20)[0]==1
    pos=24
    while pos<len(raw):
        sec,usec,size,original=struct.unpack_from("<IIII",raw,pos)
        frame=raw[pos+16:pos+16+size]
        assert len(frame)==original==size
        pos+=16+size
        offsets=[10,12] if tap else [0]
        matches=[n for n in offsets if frame[n+12:n+14] in (b"\x08\x00",b"\x08\x06",b"\x86\xdd")]
        assert len(matches)==1, frame.hex()
        n=matches[0]
        yield n,frame[n:]
    assert pos==len(raw)

def decode(path,tap=False):
    # Only TCP/UDP traffic between the two declared IPv4 endpoints is evaluated.
    traffic=[]
    headers=collections.Counter()
    arp=set()
    for n,frame in ethernet(path,tap):
        headers[n]+=1
        if frame[12:14]==b"\x08\x06":
            arp.add((frame[20:22],frame[28:32],frame[38:42]))
        if frame[12:14]!=b"\x08\x00": continue
        ip=frame[14:]
        ihl=(ip[0]&15)*4
        total,=struct.unpack_from("!H",ip,2)
        assert ip[0]>>4==4 and 20<=ihl<=total<=len(ip)
        src,dst=ip[12:16],ip[16:20]
        if {src,dst}!={guest,host}: continue
        assert (frame[6:12]==hexmac)==(src==guest)
        seg=ip[ihl:total]
        if ip[9] not in (6,17): continue
        sp,dp=struct.unpack_from("!HH",seg)
        if ip[9]==17:
            length,=struct.unpack_from("!H",seg,4)
            assert length==len(seg)
            data=seg[8:]; flags=0
        else:
            h=(seg[12]>>4)*4
            assert 20<=h<=len(seg)
            flags=seg[13];data=seg[h:]
        traffic.append(dict(proto=ip[9],out=src==guest,sp=sp,dp=dp,flags=flags,data=data,frame=frame))
    assert (b"\x00\x01",guest,host) in arp and (b"\x00\x02",host,guest) in arp
    return traffic,dict(headers)

def wire(traffic, host_in):
    udp=[row for row in traffic if row['proto']==17]
    outgoing=[r for r in udp if r['out']]
    incoming=[r for r in udp if not r['out']]
    assert [r['data'] for r in outgoing]==sent and all((r['sp'],r['dp'])==(43003,43004) for r in outgoing)
    assert [r['data'] for r in incoming]==host_in and all((r['sp'],r['dp'])==(43004,43003) for r in incoming)
    flows=collections.defaultdict(list)
    for r in traffic:
        if r['proto']==6:
            ports=(r['sp'],r['dp']) if r['out'] else (r['dp'],r['sp'])
            flows[ports].append(r)
    assert len(flows)==3
    proof={}
    for (gp,hp),flow in flows.items():
        outdata=b"".join(r['data'] for r in flow if r['out'])
        indata=b"".join(r['data'] for r in flow if not r['out'])
        typ={b"GUEST/out":"outbound",b"GUEST/accepted":"accepted",b"ARM!":"reset"}[outdata]
        assert indata=={"outbound":b"HOST/outbound","accepted":b"HOST/inbound","reset":b""}[typ]
        assert (gp==43001 if typ=="accepted" else hp==43002)
        initiator=(typ!="accepted")
        assert any(r['out']==initiator and r['flags']&0x12==2 for r in flow)
        assert any(r['out']!=initiator and r['flags']&0x12==0x12 for r in flow)
        fin=[r['out'] for r in flow if r['flags']&1]
        rst=[r['out'] for r in flow if r['flags']&4]
        if typ=='reset':
            arm=next(i for i,r in enumerate(flow) if r['data']==b'ARM!')
            assert any(not r['out'] and r['flags']&4 for r in flow[arm+1:])
            assert not fin
        else:
            assert set(fin)=={True,False} and not rst
        proof[typ]=dict(guest_port=gp,host_port=hp,guest_payload=outdata.decode(),host_payload=indata.decode(),fin_directions=fin,reset_directions=rst)
    assert set(proof)=={'outbound','accepted','reset'}
    return proof,incoming

def extract(pkg,cap,policy):
    meta=json.loads((pkg/'manifest.json').read_text())
    launch=json.loads((cap/'launch.json').read_text())
    kernel=pkg/'kernel.elf'
    assert meta['commit']==rev and meta['tracked_changes']=='' and meta['policy']==policy
    assert meta['quantum_ticks']==(625000 if policy=='rr' else None)
    assert digest(kernel)==launch['kernel_sha256']==meta['kernel_elf_sha256']
    argv=launch['argv']
    assert argv[argv.index('-smp')+1]=='1' and argv[argv.index('-cpu')+1]=='cortex-a72'
    slots=[pkg/s['elf'] for s in meta['slots']]
    assert all(digest(f)==s['elf_sha256'] for f,s in zip(slots,meta['slots']))
    mem=Snapshot(0x40000000,(cap/'ram.bin').read_bytes())
    assert len(mem.raw)==128<<20
    roots=linked_roots(kernel,len(slots))
    assert len(set(roots))==len(slots)
    def private(slot,name):
        va,n=symbol(elf_file(slots[slot].read_bytes()),name)
        for a in range(va&~4095,va+n,4096): permissions(mem,roots[slot],a,'user rw')
        return list(struct.unpack('<'+'q'*(n//8),vread(mem,roots[slot],va,n)))
    uart=(cap/'uart').read_text()
    assert 'NATIVE EL0 FAULT' not in uart
    exits=[list(map(int,row)) for row in re.findall(r'NATIVE EL0 EXIT PID (\d+) (-?\d+)',uart)]
    device=[list(map(int,line.split()[3:])) for line in uart.splitlines() if line.startswith('NATIVE NET DEVICE ')]
    return meta,argv,mem,private,exits,device

def ring(mem,kernel):
    va,size=symbol(elf_file(kernel.read_bytes()),'jnox_native_net_queues')
    assert size==32768 and va%4096==0
    res=[]
    for i in (0,1):
        q=va+i*(size//2)
        for j in range(8):
            addr,length,flags,nxt=struct.unpack('<QIHH',mem.read(q+16*j,16))
            assert q<=addr and addr+length<=q+size//2 and flags==(0 if i else 2) and nxt==0
        res.append([struct.unpack('<H',mem.read(q+off,2))[0] for off in (130,154)])
    return res

def normal(pol,kind):
    name=f'{pol}-{kind}-first'
    pkg,cap=root/pol,root/name
    meta,argv,mem,priv,exits,dev=extract(pkg,cap,pol)
    assert meta['socket_service']=={'slot':2,'authorized_clients':[0,1]} and meta['net_service']['slot']==2
    assert exits==[[0,75],[1,76],[2,0]] and dev[0][2]>0 and dev[0][3]==dev[0][4]>0 and dev[0][-1]==0
    netdev=argv[argv.index('-netdev')+1]
    if kind=='slirp': assert 'hostfwd=tcp:127.0.0.1:' in netdev
    elif kind=='tap': assert netdev=='tap,id=lan,ifname=jnx0,script=no,downscript=no'
    else: assert re.fullmatch(r'socket,id=lan,connect=127\.0\.0\.1:\d+',netdev)
    rings=ring(mem,pkg/'kernel.elf')
    assert rings[0][0]==8+dev[0][2] and rings[1]==[dev[0][3],dev[0][4]]
    tcp,udp,activity=priv(0,'inet_tcp_result'),priv(1,'inet_udp_result'),priv(2,'inet_activity')
    assert activity[1]>0 and activity[2]==2 and activity[3]>0
    assert tcp[:3]==[4,9,13] and 1<=tcp[3]<=3 and tcp[4:]==[0,12,14,0,4,-1,104,1]
    assert udp[:10]==[3,3,3,3,1,4,3,0,0x0a000202,43004] and udp[10]>0 and udp[11:]==[1,0,0,0,0]
    assert json.loads((cap/'private.json').read_text())=={'inet_tcp_result':tcp,'inet_udp_result':udp}
    assert json.loads((cap/'status.json').read_text())==dict(tcp='complete',udp='complete',guest_exits=exits)
    peer=journal(cap/'peer.jsonl')
    def observed(kind,field='data'):
        return [bytes.fromhex(e[field]) for e in peer if e['kind']==kind]
    assert observed('udp_before_relay')==sent[:-1] and observed('udp_final_rx')==sent[-1:]
    assert observed('udp_after_relay')==(full if kind=='wire' else received)
    assert observed('tcp_abortive_close','received')==[b'ARM!'] and observed('tcp_out_rx')==[b'GUEST/out']
    assert observed('tcp_in_rx')==[b'GUEST/accepted'] and b''.join(observed('tcp_out_tx'))==b'HOST/outbound'
    src={tuple(e['peer']) for e in peer if e['kind'] in ['udp_before_relay','udp_after_relay','udp_final_rx']}
    assert len(src)==1
    src=next(iter(src))
    assert (src[0]=='127.0.0.1' and src[1]>0 if kind=='slirp' else src==('10.0.2.15',43003))
    traffic,header=decode(cap/'wire.pcap',kind=='tap')
    flows,incoming=wire(traffic,received)
    proof=dict(exits=exits,tcp=tcp,udp=udp,activity=activity,device=dev,rings=rings,flows=flows,pcap_prefix_counts=header,host_udp_observed_sender=src)
    if kind=='wire':
        side=root/(name+'-host')
        before,bhdr=decode(side/'peer.pcap')
        other,pre=wire(before,full)
        assert other==flows
        actual={r['data'][1]:r['frame'] for r in pre}
        decisions=journal(side/'link.jsonl')
        assert [(r['id'],r['action']) for r in decisions]==[(1,'pass'),(2,'drop'),(3,'hold'),(4,'pass-and-release'),(0,'pass')]
        assert all(bytes.fromhex(r['frame'])==actual[r['id']] for r in decisions)
        assert [r['frame'] for r in incoming]==[actual[i] for i in [1,4,3,0]]
        assert '0 packets dropped by kernel' in (side/'tcpdump.log').read_text()
        assert 'default' not in (side/'namespace.txt').read_text()
        proof['prelink_udp_payloads']=[r['data'].hex() for r in pre]
        proof['postlink_udp_payloads']=[r['data'].hex() for r in incoming]
        proof['discarded_ethernet_sha256']=hashlib.sha256(actual[2]).hexdigest()
    else: assert observed('udp_drop','original')==[sent[1]]
    return proof

def control(pol,kind):
    name=f'{kind}-{pol}'
    pkg,cap=root/('pkg-'+name),root/('cap-'+name)
    meta,argv,mem,priv,exits,dev=extract(pkg,cap,pol)
    if kind=='resources':
        assert exits==[[0,81],[1,82],[2,0]] and len(dev)==1
        a,b,activity=priv(0,'resources'),priv(1,'resources'),priv(2,'inet_activity')
        assert a==[-95,-95,-95,-22,64,65,66,67,-24,0,-98,-90,64,65,66,67]+[0]*8
        assert b==[-9,-23,64,64,65,-23,66,67,-24]+[0]*15
        assert activity[1]>0 and activity[2]==2 and activity[3]>0
        return dict(exits=exits,device=dev,owner=a,contender=b,activity=activity)
    actual=[priv(i,'receipts') for i in (0,1)]
    if kind=='enabled':
        assert exits==[[0,51],[1,52]] and actual==[[-13]*3+[0]*3,[-11,-90,-11,-90,-90,0]] and len(dev)==1
    else: assert exits==[[0,51],[1,51]] and actual==[[-38]*3+[0]*3]*2 and not dev
    return dict(exits=exits,private=actual,device=dev)

res={}
for policy in ('fifo','rr'):
    for mode in ('slirp','tap','wire'):
        res[f'{policy}-{mode}']=normal(policy,mode)
    for mode in ('enabled','local','plain','resources'):
        res[f'{policy}-{mode}']=control(policy,mode)
print(json.dumps(res,indent=2))
