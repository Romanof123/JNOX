import argparse, hashlib, importlib.util, json, os, re, subprocess, tempfile, time
from pathlib import Path
a=argparse.ArgumentParser()
a.add_argument('package',type=Path)
a.add_argument('out', type=Path)
a.add_argument('mode',choices=['enabled','plain','local'])
a.add_argument('source',type=Path)
x=a.parse_args()
x.out.mkdir()
syms = lambda f: subprocess.check_output(['aarch64-linux-gnu-nm','-S',str(f)],text=True)
import sys
sys.path.insert(0, str(x.source/'tools'))
from native_amc_roots import linked_roots
from native_el0_replay import Snapshot, elf_file, permissions, symbol, vread
import struct
peer = importlib.util.spec_from_file_location("frozen_peer",x.source/'examples/native-inet-sockets/peer.py')
m=importlib.util.module_from_spec(peer)
peer.loader.exec_module(m)
kernel=x.package/'kernel.elf'
meta=json.loads((x.package/'manifest.json').read_text())
assert hashlib.sha256(kernel.read_bytes()).hexdigest()==meta['kernel_elf_sha256']
count=len(meta['slots'])
with tempfile.TemporaryDirectory() as tmp:
    sock=Path(tmp)/'qmp'
    argv=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-no-reboot','-serial','file:'+str(x.out/'uart'),'-qmp',f'unix:{sock},server=on,wait=off','-kernel',str(kernel)]
    if x.mode=='enabled':
        argv.extend(['-global','virtio-mmio.force-legacy=false','-netdev','user,id=lan,restrict=on','-device','virtio-net-device,netdev=lan,mac=52:54:00:12:34:56'])
    (x.out/'launch.json').write_text(json.dumps(dict(argv=argv,kernel_sha256=meta['kernel_elf_sha256']),indent=2))
    with (x.out/'qemu.log').open('w') as log:
        proc=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=log,stderr=log)
        try:
            start=time.monotonic()
            while time.monotonic()-start<8 and proc.poll() is None:
                uart=(x.out/'uart').read_bytes() if (x.out/'uart').exists() else b''
                if len(re.findall(rb'NATIVE EL0 EXIT PID (\d+) (-?\d+)\r?\n',uart))==count or b'NATIVE EL0 FAULT' in uart: break
                time.sleep(.03)
            m.capture_ram(sock,x.out/'ram.bin')
        finally:
            proc.terminate()
            proc.wait(timeout=5)
mem=Snapshot(0x40000000,(x.out/'ram.bin').read_bytes())
roots=linked_roots(kernel,count)
app=(x.package/'user.elf').read_bytes()
va,size=symbol(elf_file(app),'receipts')
rows=[]
for i in range(count):
    permissions(mem,roots[i],va,'user rw')
    assert hashlib.sha256(app).hexdigest()==meta['slots'][i]['elf_sha256']
    rows.append(struct.unpack('<6q',vread(mem,roots[i],va,size)))
uart=(x.out/'uart').read_text()
exits=[(int(p),int(c)) for p,c in re.findall(r'NATIVE EL0 EXIT PID (\d+) (-?\d+)',uart)]
r=dict(mode=x.mode,exits=exits,receipts=rows,device=[s for s in uart.splitlines() if 'NATIVE NET DEVICE' in s])
(x.out/'control.json').write_text(json.dumps(r,indent=2))
print(r)
assert all(row[:3]==((-13,-13,-13) if i==0 and x.mode=='enabled' else (-11,-90,-11) if x.mode=='enabled' else (-38,-38,-38)) for i,row in enumerate(rows))
assert exits==[(i,52 if x.mode=='enabled' and i==1 else 51) for i in range(count)]
assert bool(r['device'])==(x.mode=='enabled')
