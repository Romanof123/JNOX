#!/usr/bin/env bash
set -euo pipefail
raw=/home/ywcho/v376-ipv4-05b26e7-first
export FIXTURE_SRC=/home/ywcho/v376-ipv4-05b26e7-checkout
scripts=$(cd "$(dirname "$0")" && pwd)
label=${1:-wire-first}
ns=jnx376layer2
ip netns add "$ns"
trap 'ip netns del "$ns"' EXIT
ip -n "$ns" link set lo up
ip netns exec "$ns" ip tuntap add dev jnx0 mode tap
ip -n "$ns" addr add 10.0.2.2/24 dev jnx0
ip -n "$ns" link set jnx0 up
test -z "$(ip -n "$ns" route show default)"
test "$(ip -n "$ns" link | awk '/^[0-9]+:/ {print $2}' | xargs)" = "lo: jnx0:"
for pol in fifo rr; do
    dir="$raw/$pol-$label"
    side="$dir-host"
    mkdir "$side"
    ip netns exec "$ns" python3 "$scripts/link.py" "$side" > "$side/link.log" 2>&1 &
    linkpid=$!
    until [[ -s "$side/port" ]]; do kill -0 "$linkpid"; sleep .03; done
    export LINK_PORT=$(cat "$side/port")
    (ip -n "$ns" -br addr; ip -n "$ns" route) > "$side/namespace.txt"
    ip netns exec "$ns" tcpdump -ni jnx0 -s 0 -U -w "$side/peer.pcap" > "$side/tcpdump.log" 2>&1 &
    dumppid=$!
    until grep -q 'listening on' "$side/tcpdump.log"; do kill -0 "$dumppid"; sleep .03; done
    ret=0
    ip netns exec "$ns" python3 "$scripts/wire-peer.py" "$raw/$pol" "$dir" --isolated-tap jnx0 --timeout 18 > "$dir-peer.log" 2>&1 || ret=$?
    sleep 1.1
    kill -INT "$dumppid"
    wait "$dumppid"
    if kill -0 "$linkpid" 2>/dev/null; then kill "$linkpid"; fi
    wait "$linkpid" || true
    echo "$pol-$label-peer $ret" | tee -a "$raw/status.txt"
    ret=0
    PYTHONPATH=/home/ywcho/jnox-169-first-e203caa/deps python3 "$FIXTURE_SRC/examples/native-inet-sockets/private_results.py" "$raw/$pol" "$dir" "$raw/tcp.elf" "$raw/udp.elf" > "$dir/private.json" 2>"$dir/private.stderr" || ret=$?
    echo "$pol-$label-private $ret" | tee -a "$raw/status.txt"
done
