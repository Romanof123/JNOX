#!/usr/bin/env bash
set -euo pipefail
base=$(cd "$(dirname "$0")" && pwd)
stage=/home/ywcho/v376-ipv4-05b26e7-packet
archive=376-ipv4-corrected-05b26e7.tar.gz
export PYTHONPATH=/home/ywcho/jnox-169-first-e203caa/deps PYTHONDONTWRITEBYTECODE=1
cp "$base"/{replay.py,REPORT.en-ko.md,seal.sh} "$stage/"
cd "$stage"
python3 replay.py > replay.json
find . -type f ! -name SHA256SUMS -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > SHA256SUMS
# A sparse archive preserves all 14 exact RAM snapshots.
tar -Scf - . | gzip -1 > "$base/$archive"
cp replay.json SHA256SUMS revision.txt status.txt platform.txt "$base/"
cd "$base"
sha256sum "$archive" > "$archive.sha256"
sha256sum -c "$archive.sha256"
verify=$(mktemp -d /home/ywcho/v376-ipv4-05b26e7-clean.XXXXXXXX)
cd "$verify"
tar xzf "$base/$archive"
sha256sum -c SHA256SUMS > "$base/extracted-sha256-verified.txt"
python3 replay.py > "$base/extracted-replay.json"
cmp replay.json "$base/extracted-replay.json"
printf 'Clean extraction %s\nVerified files %s\nBoot positions %s\nReplay SHA-256 %s\nArchive bytes %s\nArchive SHA-256 %s\n' "$verify" "$(wc -l < "$base/extracted-sha256-verified.txt")" "$(python3 -c 'import json;print(len(json.load(open("replay.json"))))')" "$(sha256sum replay.json)" "$(stat -c %s "$base/$archive")" "$(cat "$base/$archive.sha256")" > "$base/clean-extraction.txt"
cat "$base/clean-extraction.txt"
