#!/usr/bin/env bash
set -euo pipefail
raw=/home/ywcho/v376-ipv4-05b26e7-first
src=/home/ywcho/v376-ipv4-05b26e7-checkout
stage=/home/ywcho/v376-ipv4-05b26e7-packet
base=$(cd "$(dirname "$0")" && pwd)
mkdir -p "$stage/source" "$stage/previous"
rsync -a --exclude=app-target --exclude=target --link-dest="$raw" "$raw/" "$stage/"
git -c safe.directory="$src" -C "$src" archive 05b26e7407f1901e9213280846f295b12d681024 arch boards kernel sdk services examples tools trace verification docs/native-ipv4-socket-service.en-ko.md | tar xf - -C "$stage/source"
git -c safe.directory="$src" -C "$src" diff 906fdd0 05b26e7 > "$stage/correction.patch"
prior=/mnt/d/codex/.jnox-work/376-ipv4-first-906fdd0
cp "$prior"/{REPORT.en-ko.md,376-ipv4-first-906fdd0.tar.gz.sha256,extracted-replay.json} "$stage/previous/"
cp "$prior/issue-376-live.md" "$stage/issue-376-record.md"
cp "$base"/{run-workload.sh,link.py,wire-peer.py,wire.sh,resources.c,resources.sh,resource-boot.py,stage.sh} "$stage/"
