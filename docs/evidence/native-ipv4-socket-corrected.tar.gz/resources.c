#include <arpa/inet.h>
#include <errno.h>
#include <jnox/ipc.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <time.h>

volatile long resources[24];

static int result(int value) { return value < 0 ? -errno : value; }

static int exchange(unsigned word) {
    jnox_ipc_response r = jnox_ipc_call(0, word, UINT64_MAX);
    return r.status == 0 && r.word == word;
}

static int respond(unsigned word) {
    jnox_ipc_request r = jnox_ipc_receive();
    return r.status == 0 && r.word == word && jnox_ipc_reply(r.token, word) == 0;
}

static int owner(void) {
    int fd[4];
    resources[0] = result(socket(10, SOCK_DGRAM, 0));
    resources[1] = result(socket(AF_INET, SOCK_STREAM, IPPROTO_UDP));
    resources[2] = result(socket(AF_INET, SOCK_SEQPACKET, 0));
    resources[3] = result(socket(AF_UNIX, SOCK_STREAM, 0));
    if (resources[0] != -95 || resources[1] != -95 ||
        resources[2] != -95 || resources[3] != -22) return 121;

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(43351);
    addr.sin_addr.s_addr = htonl(0x0a00020f);
    for (int i = 0; i < 4; ++i) {
        fd[i] = socket(AF_INET, SOCK_DGRAM, 0);
        resources[4+i] = result(fd[i]);
        if (fd[i] < 0) return 122;
    }
    resources[8] = result(socket(AF_INET, SOCK_DGRAM, 0));
    resources[9] = result(bind(fd[0], (struct sockaddr *)&addr, sizeof addr));
    resources[10] = result(bind(fd[1], (struct sockaddr *)&addr, sizeof addr));
    char bytes[33] = {0};
    resources[11] = result(sendto(fd[0], bytes, sizeof bytes, 0, (struct sockaddr *)&addr, sizeof addr));
    if (resources[8] != -24 || resources[9] != 0 || resources[10] != -98 ||
        resources[11] != -90) return 123;
    if (!respond(11)) return 124;
    jnox_ipc_request switch_phase = jnox_ipc_receive();
    if (switch_phase.status || switch_phase.word != 12) return 125;
    for (int i = 0; i < 4; ++i) if (close(fd[i]) < 0) return 126;
    for (int i = 0; i < 4; ++i) {
        resources[12+i] = result(socket(AF_INET, SOCK_STREAM, 0));
        if (resources[12+i] < 0) return 127;
    }
    if (jnox_ipc_reply(switch_phase.token,12) || !respond(13)) return 128;
    return 81; /* Exit while holding four TCP transports. */
}

static int contender(void) {
    int fd[4];
    if (!exchange(11)) return 131;
    resources[0] = result(close(67));
    resources[1] = result(socket(AF_INET, SOCK_DGRAM, 0));
    if (resources[0] != -9 || resources[1] != -23 || !exchange(12)) return 132;
    int restored = socket(AF_INET, SOCK_DGRAM, 0);
    resources[2] = result(restored);
    if (restored < 0 || close(restored) < 0) return 133;
    for (int i = 0; i < 2; ++i) {
        resources[3+i] = result(fd[i] = socket(AF_INET, SOCK_STREAM, 0));
        if (fd[i] < 0) return 134;
    }
    resources[5] = result(socket(AF_INET, SOCK_STREAM, 0));
    if (resources[5] != -23 || !exchange(13)) return 135;
    const struct timespec delay = {0, 2000000};
    for (int i = 2; i < 4; ++i) {
        for (int j = 0; j < 200; ++j) {
            fd[i] = socket(AF_INET, SOCK_STREAM, 0);
            if (fd[i] >= 0 || errno != 23) break;
            clock_nanosleep(CLOCK_MONOTONIC, 0, &delay, 0);
        }
        resources[4+i] = result(fd[i]);
        if (fd[i] < 0) return 136;
    }
    resources[8] = result(socket(AF_INET, SOCK_STREAM, 0));
    if (resources[8] != -24) return 137;
    for (int i = 0; i < 4; ++i) if (close(fd[i]) < 0) return 138;
    return 82;
}

int main(int argc, char **argv) {
    if (argc != 2 || jnox_socket_broker(2) < 0) return 139;
    return argv[1][0] == 'a' ? owner() : contender();
}
