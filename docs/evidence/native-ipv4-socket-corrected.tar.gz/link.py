"""Forward complete Ethernet frames between an isolated TAP and QEMU socket backend."""
import argparse, fcntl, json, os, selectors, socket, struct
from pathlib import Path

def relay_id(frame):
    if frame[12:14] != b'\x08\x00' or frame[23:24] != b'\x11':
        return None
    if frame[26:34] != bytes([10, 0, 2, 2, 10, 0, 2, 15]):
        return None
    offset = 14 + 4 * (frame[14] & 15)
    sport,dport,length,_ = struct.unpack_from('!HHHH',frame,offset)
    payload=frame[offset+8:offset+length]
    if (sport,dport,length)!=(43004,43003,11) or payload[0]!=ord('R'):
        return None
    assert payload[1] in range(5) and payload[2] == 10 * payload[1]
    return payload[1]

out=Path(__import__('sys').argv[1])
tap=os.open('/dev/net/tun',os.O_RDWR)
fcntl.ioctl(tap,0x400454ca,struct.pack('16sH',b'jnx0',0x1002))
with socket.socket() as server:
    server.bind(('127.0.0.1',0))
    server.listen(1)
    (out/'port').write_text(str(server.getsockname()[1]))
    stream,_=server.accept()
with stream,selectors.DefaultSelector() as sel,(out/'link.jsonl').open('x') as log:
    sel.register(tap,selectors.EVENT_READ)
    sel.register(stream,selectors.EVENT_READ)
    buffer=bytearray()
    held=None
    while True:
        for key,event in sel.select():
            if key.fileobj is stream:
                b=stream.recv(65536)
                if not b:
                    assert not buffer and held is None
                    raise SystemExit(0)
                buffer.extend(b)
                while len(buffer)>=4:
                    n,=struct.unpack_from('!I',buffer)
                    assert 14<=n<=2048
                    if len(buffer)<4+n: break
                    assert os.write(tap,buffer[4:4+n])==n
                    del buffer[:4+n]
            else:
                frame=os.read(tap,2048)
                seq=relay_id(frame)
                action={2:'drop',3:'hold',4:'pass-and-release'}.get(seq,'pass')
                if seq is not None:
                    log.write(json.dumps(dict(id=seq,action=action,frame=frame.hex()))+'\n')
                    log.flush()
                if seq==2: continue
                if seq==3:
                    assert held is None
                    held=frame
                    continue
                stream.sendall(struct.pack('!I',len(frame))+frame)
                if seq==4:
                    assert held is not None
                    stream.sendall(struct.pack('!I',len(held))+held)
                    held=None
