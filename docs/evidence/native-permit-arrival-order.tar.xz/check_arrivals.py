"""Apply the immutable original icount witness to the six corrected #401 counted-clock captures."""
import argparse
import hashlib
import json
import runpy
import struct
import tarfile
import tempfile
from pathlib import Path

PREVIOUS = "f9bdd14b2e0e4273c48ad31ba4dbcd60d218e0cdff8b32adf404f8df96b2741e"
CHECKER = "e49b630509a879208a77ce6f9d8486fd304ae0c62e7c5678f87a35512b792297"
REVISION = "aa8e7e104033a372eed0675f3b76f7fb9af2a38e"
QEMU = "0a63468782d096485932acf6aa0a69d358b3e3a6f68f655e960e9f5e3fc578d8"
PINS = {
    "007-count0-fifo-arrival-before": "1f842300c80cdcc5e7077c8aa2e0982b1e9972af0ad79a696dc933ad544a9028",
    "008-count0-fifo-arrival-same":   "27740e70d478bc8ea2657a0071d4f3e82fca54e780d944e699130bba04f02250",
    "009-count0-fifo-arrival-after":  "da7247e98c68fd906fe65d1c967ad24e38441f4f14f7463f9447e9284eaba7b2",
    "010-count0-rr-arrival-before":  "e765f3ae28edce98e4912a44d6a0b2cf46c53429e52056edd95bd33a24b352f3",
    "011-count0-rr-arrival-same":    "77d31b6b8a0c74a4b72305f34de4ccdb2fb088264c275c1cdf41a5e3c741963e",
    "012-count0-rr-arrival-after":   "7bd8884f2ff7c75c0cbdb00b21225ca7cd7510a74b14665495bc2d8a53286bf8",
}
# Byte-identical ranges from both earlier FIFO/RR collision kernels. Half-open virtual addresses.
RANGES = {
    (0x4020124c, 0x40201318): "9d05eb3f1c92b7b729aff9673979225e21179951db4dd37dd918c3b4cd57322b",
    (0x4020131c, 0x402013e0): "091a43d3461dcd8eb368f99969e170f0fef44f740fddbb85bf3d60afce25b33f",
}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def one(items):
    value, = items
    return value


def linked_ranges(data):
    need(data[:6]==b"\x7fELF\x02\x01" and struct.unpack_from("<H",data,18)[0]==183,"AArch64 ELF")
    off, = struct.unpack_from("<Q",data,32)
    ent_size,count = struct.unpack_from("<HH",data,54)
    segments = [struct.unpack_from("<IIQQQQQQ",data,off+i*ent_size) for i in range(count)]
    result = {}
    for (start,end),expected in RANGES.items():
        p=one(s for s in segments if s[0]==1 and s[1]&1 and s[3]<=start<end<=s[3]+s[5])
        offset=p[2]+start-p[3]
        value=sha(data[offset:offset+end-start])
        need(value==expected,"linked save/restore bytes")
        result[f"{start:#x}..{end:#x}"]=value
    return result


def read_run(root,name,pin,disassemble):
    cap=root/"runs"/name/"cap"
    session=(cap/"session.json").read_bytes()
    need(sha(session)==pin,"original session")
    h=json.loads(session)["hashes"]
    ls=(cap/"launch.json").read_bytes()
    elf=(cap/"kernel.elf").read_bytes()
    uart=(cap/"uart.bin").read_bytes()
    need([sha(data) for data in (ls,elf,uart)]==[h[n] for n in ("launch.json","kernel.elf","uart.bin")],"input hashes")
    j=json.loads(ls)
    a=j["argument_package"]
    scenario=name[name.index("arrival-"):]
    policy=name.split("-")[2]
    need(j["revision"]==a["commit"]==REVISION and a["tracked_changes"]=="" and j["qemu_sha256"]==QEMU and
         a["kernel_elf_sha256"]==j["kernel_sha256"]==h["kernel.elf"] and
         a["loan_route"]=={"producer":0,"consumer":1} and a["policy"]==policy and
         [s["argv"] for s in a["slots"]]==[["/bin/app",scenario]]*3 and
         a["safety_boundary"]=={"scenario":scenario,"decision_event":12} and
         not a.get("safety_qualification") and not a.get("safety_watchdog"),"package identity")
    argv=j["argv"]
    need(argv[1:-4]==["-machine","virt,gic-version=2","-cpu","cortex-a72","-smp","1","-accel","tcg,thread=single",
                       "-icount","shift=0,align=off,sleep=off","-m","128M","-nodefaults","-display","none","-monitor",
                       "none","-no-reboot","-qmp","stdio"] and argv[-4::2]==["-serial","-kernel"],"clock model")
    lines=uart.decode().splitlines()
    rs=[list(map(int,l.split()[3:])) for l in lines if l.startswith("NATIVE SAFETY EVENT ")]
    need(all(len(e)==10 for e in rs) and one(e for e in rs if e[0]==1)[2]==62500000 and
         [l for l in lines if l.startswith("NATIVE SAFETY DROPPED ")]==["NATIVE SAFETY DROPPED 0"],"journal")
    pub=one(e for e in rs if e[0]==11 and e[5:9]==[0,1,1,4])
    expiry=one(e for e in rs if e[0]==3)
    check=one(e for e in rs if e[0]==12 and e[2]==expiry[2] and e[3:6]==[1,1,3])
    status=rs[rs.index(check)+1]
    rise,fall=[e for e in rs if e[0]==2]
    need(expiry[3:6]==[1,3,check[6]] and check[7:]==[0,1,1] and status[0]==5 and
         status[2:9]==[1,60,1,0,1,3,check[6]] and rise[4:6]==[0,1] and fall[4:6]==[1,0] and
         rise[3]<expiry[2]<=fall[2]<=fall[3],"live seq3 authenticated PID1 CHECK")
    b,a_tick,c=pub[2],pub[3],check[2]
    need(b<=a_tick and (a_tick<c or c<b),"strict interval order")
    d=check[6]+1250000
    return dict(run=name,session_sha256=pin,kernel_sha256=h["kernel.elf"],vector_ranges=linked_ranges(elf),
                linked=disassemble(cap/"kernel.elf"),seq4_handle=pub[4],deadline=d,publish_offsets=[b-d,a_tick-d],
                check_offset=c-d,order="publication-first" if a_tick<c else "CHECK-first",
                minimum_observed_separation_ticks=c-a_tick if a_tick<c else b-c)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("earlier_order_packet",type=Path)
    p.add_argument("restored_arrival_root",type=Path)
    args=p.parse_args()
    need(sha(args.earlier_order_packet.read_bytes())==PREVIOUS,"previous order packet")
    with tarfile.open(args.earlier_order_packet,"r:xz") as archive:
        checker=archive.extractfile("check_guest.py").read()
    need(sha(checker)==CHECKER,"previous checker")
    with tempfile.TemporaryDirectory() as temp:
        file=Path(temp)/"pinned.py"
        file.write_bytes(checker)
        disassemble=runpy.run_path(str(file))["disassemble"]
        rows=[read_run(args.restored_arrival_root,name,pin,disassemble) for name,pin in PINS.items()]
    print(json.dumps(rows,sort_keys=True,indent=2))
