extern crate jnox_safety_channel as safety;
fn main() {
 let k = 62_500u64;
 for (f,d,s,expected) in [(0,25*k,30*k,[true,true,true]),(0,25*k+1,30*k,[false,true,true]),(0,25*k-1,30*k,[true,false,true]),(0,25*k,30*k+1,[true,false,false]),(0,25*k+1,30*k+1,[false,true,false])] {
  let t=safety::response_timing(f,d,s,1000*k).unwrap();
  let seen=[t.detected_within_25ms,t.inhibited_within_5ms,t.total_within_30ms];
  println!("{f} {d} {s} {seen:?}"); assert_eq!(seen,expected);
 }
 for n in [5*k,5*k+1] { let ok=safety::within_ms(0,n,1000*k,5).unwrap();println!("5ms {n} {ok}");assert_eq!(ok,n==5*k); }
}