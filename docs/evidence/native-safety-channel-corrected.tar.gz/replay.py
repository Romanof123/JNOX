from pathlib import Path
import sys,struct,json,re,hashlib
r=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(r/'src/tools'))
from native_el0_replay import Snapshot,vread,symbol,elf_file
from native_amc_roots import linked_roots
out=r/'decoded';out.mkdir(exist_ok=True)
roles=['sender','receiver','supervisor']
apps=[elf_file((r/'raw'/f'{x}.elf').read_bytes()) for x in roles]
spec=[{'sender_header':0,'sender_rows':11,'sender_bytes':44},{'receiver_header':0,'activations':19,'received_rows':20,'received_bytes':44,'exact_clock_control':0,'exact_rearm_control':0},{'supervisor_header':0,'supervisor_rows':16,'live_startup':0}]
summary=[]
for c in sorted((r/'raw').glob('*-*/cap')):
 if not (c/'session.json').exists():continue
 name=c.parent.name
 meta=json.loads((c/'launch.json').read_text())
 ram=Snapshot(meta['ram_base'],(c/'ram.bin').read_bytes())
 elf=elf_file((c/'kernel.elf').read_bytes())
 roots=linked_roots(c/'kernel.elf',3)
 raw={'roots':roots}
 for i,items in enumerate(spec):
  def get(n):
   va,size=symbol(apps[i],'safety_'+n)
   return vread(ram,roots[i],va,size)
  for n,w in items.items():
   b=get(n)
   if not w: raw[n]=list(struct.unpack('<'+'Q'*(len(b)//8),b));continue
   typ='activation' if n=='activations' else n.split('_')[0]
   count=int.from_bytes(get(typ+'_count'),'little')
   bytes_=n.endswith('_bytes')
   sz=w*(1 if bytes_ else 8)
   assert count*sz<=len(b)
   raw[n]=[b[j*sz:(j+1)*sz].hex() if bytes_ else list(struct.unpack_from('<'+'Q'*w,b,j*sz)) for j in range(count)]
 uart=(c/'uart.bin').read_text()
 ev=[list(map(int,line.split()[3:])) for line in uart.splitlines() if line.startswith('NATIVE SAFETY EVENT ')]
 raw['events']=ev
 drops={k:int(re.search('NATIVE '+k+r' DROPPED (\d+)',uart)[1]) for k in ('FIXED','SAFETY')}
 a=raw['activations']; comp=[x for x in ev if x[0]==10]; assert len(a)==len(comp)
 # Lower/upper bounds for each elapsed operation, using the COMPLETE entry/exit bracket.
 def sweep(vec):return [max(z[i] for z in vec) for i in (0,1)] if vec else []
 rt=sweep([(z[2]-v[0],z[3]-v[0]) for v,z in zip(a,comp)])
 gap=sweep([(y[2]-x[3],y[3]-x[2]) for x,y in zip(comp,comp[1:])])
 def events(k):return [x for x in ev if x[0]==k]
 faults=events(4); latch=events(3); dev=events(2)
 loss=[]
 for f in faults:
  det=next((x for x in latch if x[2]>=f[3]),None)
  if det:
   safe=next((x for x in dev if x[2]>=det[2] and x[4:6]==[1,0]),None)
   if safe and any(x[4:6]==[0,1] and x[3]<=f[2] for x in dev):
    loss.append(dict(cmd=f[4],fault=f[2:4],detect=[det[2],det[1]],safe=safe[2:4],bounds=[det[1]-f[2],safe[3]-det[2],safe[3]-f[2]],ordered=f[3]<=det[2]<=det[1]<=safe[2]))
 terminal=int.from_bytes(ram.read(symbol(elf,'jnox_virtual_permit_enable')[0],8),'little')
 exits=re.findall(r'NATIVE EL0 EXIT PID (\d+) (\d+)',uart)
 row=dict(name=name,hz=raw['receiver_header'][3],drops=drops,exits=exits,activations=len(a),response=rt,gap=gap,loss=loss,terminal=terminal,transitions=[x[2:6] for x in dev],issues=[x[7] for x in raw['sender_rows']],headers=[raw[t+'_header'] for t in roles],clock=raw['exact_clock_control'],rearm=raw['exact_rearm_control'],startup=raw['live_startup'])
 raw['summary']=row;summary.append(row)
 (out/(name+'.json')).write_text(json.dumps(raw))
(out/'summary.json').write_text(json.dumps(summary,indent=1))
for x in summary:print(x['name'],x['activations'],x['response'],x['gap'],[t['bounds'] for t in x['loss']],x['headers'][2][4:])