set -eu
export PATH="$HOME/.cargo/bin:$PATH"
r=/home/ywcho/permit388-corrected-b741028
d=/mnt/d/codex/permit388-corrected-b741028
rev=b741028b2b81cb188b5bc9ebe2ab2707b4488aed
mkdir -p "$r/src" "$r/raw" "$d/raw"
git -C "$r/src" init -q; git -C "$r/src" fetch -q --depth=1 /mnt/d/codex/j-nox "$rev"; git -C "$r/src" checkout -q --detach FETCH_HEAD
cd "$r/src"
app=examples/native-safety-channel
for role in sender receiver supervisor; do sh sdk/native-aarch64/build-rust.sh "$app/$role/Cargo.toml" "$r/raw/$role.elf"; done
cp "$r"/raw/*.elf "$d/raw/"
for policy in fifo rr; do
 q=(); if [[ $policy = rr ]]; then q=(--quantum-ticks 625000); fi
 for s in healthy observed live-startup silence phase collision invalid saturation queued delayed restart early boundary one no-rearm bad-spacing; do
  p="$r/raw/$policy-$s"; mkdir -p "$p"
  echo "START $policy $s"
  python3 tools/build_native_el0.py --out "$p/pkg" --board virt --policy "$policy" "${q[@]}" --elf "$r/raw/sender.elf" --peer-elf "$r/raw/receiver.elf" --peer-elf "$r/raw/supervisor.elf" --arg "$s" --peer-arg "$s" --peer2-arg "$s" --priority 7 --peer-priority 6 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --safety-channel --loan-route 0:1 >"$p/build.log" 2>&1 && python3 tools/native_el0_capture.py "$p/cap" "$p/pkg/kernel.elf" "$r/raw/sender.elf" "$app/sender/src/main.rs" "$rev" --manifest "$p/pkg/manifest.json" --plain --expect-exit 71 --timeout 25 >"$p/capture.log" 2>&1 || echo FAIL
  mkdir -p "$d/raw/$policy-$s"; cp -r "$p/cap" "$p/pkg/kernel.elf" "$p/pkg/manifest.json" "$p"/*.log "$d/raw/$policy-$s/" || true
 done
done
