"""Verify the surviving receipt. Optionally verify the #183 archive supplied as argument."""
import hashlib
import json
import sys
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parent
def sha(raw):
    return hashlib.sha256(raw).hexdigest()

for line in (root / "SHA256SUMS").read_text().splitlines():
    digest, name = line.split("  ", 1)
    assert sha((root / name).read_bytes()) == digest, name
transcript = json.loads((root / "execution-transcript.json").read_bytes())
console = (root / "first-console.txt").read_bytes().decode()
assert console == transcript[2]["command_receipt"]["output"]
env, n = json.JSONDecoder().raw_decode(console)
assert env == json.loads((root / "recorded-environment.json").read_bytes())
cases = json.loads((root / "positions.json").read_bytes())
lines = console[n:].strip().splitlines()
for i, (case, mode) in enumerate(zip(cases, ["plain", "instrumented"])):
    assert case["position"] == i+1 and case["mode"] == mode
    assert len(case["printed_session_sha256"]) == 64 and case["printed_session_sha256"] == lines[4*i]
    assert case["uart"] == lines[4*i+1:4*i+4]
    assert lines[8+i] == f"{mode} replay exit {case['observed_replay_exit']}"
    assert not case["original_raw_directory_available"]
assert len(cases) == 2 and len(lines) == 10
manifest_bytes = (root / "original-manifest.json").read_bytes()
assert sha(manifest_bytes) == env["original_manifest_sha256"]
m = json.loads(manifest_bytes)
assert m["commit"] == env["binary_revision"]
assert env["inputs_sha256"] == {"kernel.elf":m["kernel_elf_sha256"], "user.elf":m["user_elf_sha256"], "probe.c":m["source_sha256"]["examples/portability/native_weighted_monitor.c"]}
if len(sys.argv) > 1:
    archive = Path(sys.argv[1])
    assert sha(archive.read_bytes()) == env["published_archive_sha256"]
    with ZipFile(archive) as z:
        assert z.read("packages/weighted-share/manifest.json") == manifest_bytes
        for name, expected in env["inputs_sha256"].items():
            assert sha(z.read("first/share-default/"+name)) == expected
print("Receipt and transcript verified. First raw sessions unavailable. Independent timing UNOBSERVED.")
