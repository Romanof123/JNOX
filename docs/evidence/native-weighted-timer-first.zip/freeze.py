import hashlib
import json
import os
from pathlib import Path
import io
import subprocess
import tarfile
from zipfile import ZipFile

ROOT = Path("/tmp/jnox186-first-58e9350f")
BASE = Path("/mnt/d/codex/.jnox-work/next-fixed")
SRC = BASE / "timer186-independent-first"
CACHED = BASE / "weighted183-independent-b-receipt/packages/weighted-share"
OBSERVER = "58e9350f3d8b63f04786a181dbfe4132dd2031a5"
BINARY = "af952e34cea8fbe0aef5c7b4cb1f945a2884fff5"
QEMU = "0a63468782d096485932acf6aa0a69d358b3e3a6f68f655e960e9f5e3fc578d8"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def cmd(*args):
    return subprocess.check_output(args, text=True).strip()

gitdir = Path("/mnt/d/codex/j-nox/.git/worktrees/timer186-independent-first")
git = ["git", "--git-dir", str(gitdir)]
assert cmd(*git, "rev-parse", "HEAD") == OBSERVER
assert not (ROOT / "record/first/plain").exists() and not (ROOT / "record/first/instrumented").exists()
ROOT.mkdir(exist_ok=True)
evidence = ROOT / "record"
evidence.mkdir(exist_ok=True)
inputs = ROOT / "inputs"
inputs.mkdir(exist_ok=True)
(evidence / "first").mkdir(exist_ok=True)
(evidence / "replay").mkdir(exist_ok=True)
archive_bytes = subprocess.check_output([*git, "archive", OBSERVER, "tools"])
with tarfile.open(fileobj=io.BytesIO(archive_bytes)) as src_tar:
    src_tar.extractall(ROOT)
archive = SRC / "docs/evidence/native-weighted-irq-second.zip"
with ZipFile(archive) as z:
    sums = {row.split(None, 1)[1].strip().lstrip("*"): row.split()[0] for row in z.read("SHA256SUMS").decode().splitlines()}
    manifest_name = "packages/weighted-share/manifest.json"
    manifest_bytes = z.read(manifest_name)
    assert sha(manifest_bytes) == sums[manifest_name]
    assert manifest_bytes == (CACHED / "manifest.json").read_bytes()
    (evidence / "original-manifest.json").write_bytes(manifest_bytes)
    manifest = json.loads(manifest_bytes)
    assert manifest["commit"] == BINARY
    expected = {"kernel.elf":manifest["kernel_elf_sha256"], "user.elf":manifest["user_elf_sha256"], "probe.c":manifest["source_sha256"]["examples/portability/native_weighted_monitor.c"]}
    for name, digest in expected.items():
        member = "first/share-default/" + name
        data = z.read(member)
        assert sha(data) == digest == sums[member]
        if name != "probe.c":
            assert (CACHED / name).read_bytes() == data
        else:
            assert (SRC / "examples/portability/native_weighted_monitor.c").read_bytes().replace(b"\r\n",b"\n") == data
        (inputs / name).write_bytes(data)
    orig = json.loads(z.read("first/share-default/launch.json"))
    assert orig["qemu_sha256"] == QEMU == sha(Path("/usr/bin/qemu-system-aarch64").read_bytes())
import elftools
facts = dict(binary_revision=BINARY, observer_revision=OBSERVER, published_archive_sha256=sha(archive.read_bytes()), source_members="first/share-default/{kernel.elf,user.elf,probe.c}", inputs_sha256=expected, original_manifest_sha256=sha(manifest_bytes), qemu_sha256=QEMU, qemu_package=cmd("dpkg-query","-W","qemu-system-arm"), qemu_version=cmd("/usr/bin/qemu-system-aarch64","--version"), host_kernel=cmd("uname","-srmo"), sched_inheritance=cmd("chrt","-p","0"), host_affinity=sorted(os.sched_getaffinity(0)), host_cgroup=Path("/proc/self/cgroup").read_text(), pyelftools=elftools.__version__, positions=["share/default plain","share/default instrumented"], watchdog_s=20, repeats=0, observer_tool_sha256={p.name:sha(p.read_bytes()) for p in (ROOT/"tools").glob("native_weighted*.py")}, excluded_from_share="two SDK exit tail leases")
(evidence / "freeze.json").write_text(json.dumps(facts, indent=2)+"\n")
print(json.dumps(facts, indent=2))
