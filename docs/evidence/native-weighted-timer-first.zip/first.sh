#!/bin/sh
set -eu
export PYTHONPATH=/home/ywcho/jnox-169-first-e203caa/deps
root=/tmp/jnox186-first-58e9350f
scriptdir=/mnt/d/codex/.jnox-work/next-fixed/timer186-independent-first-receipt
python3 "$scriptdir/freeze.py"
cd "$root"
rev=af952e34cea8fbe0aef5c7b4cb1f945a2884fff5
for lane in plain instrumented; do
    set --
    if [ "$lane" = instrumented ]; then set -- --timer-observation; fi
    set +e
    python3 tools/native_weighted_capture.py share default "record/first/$lane" inputs/kernel.elf inputs/user.elf inputs/probe.c "$rev" "$@" >"record/replay/$lane.capture-digest" 2>"record/replay/$lane.capture-stderr"
    status=$?
    set -e
    echo "$status" >"record/replay/$lane.capture-exit"
    cat "record/replay/$lane.capture-digest"
    cat "record/first/$lane/uart.bin" || true
done
for lane in plain instrumented; do
    set +e
    python3 tools/native_weighted_replay.py "record/first/$lane" "$(cat "record/replay/$lane.capture-digest")" >"record/replay/$lane.json" 2>"record/replay/$lane.stderr"
    status=$?
    set -e
    echo "$status" >"record/replay/$lane.exit"
    echo "$lane replay exit $status"
    cat "record/replay/$lane.stderr"
done
