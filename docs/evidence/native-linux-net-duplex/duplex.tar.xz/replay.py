#!/usr/bin/env python3
"""Offline source, descriptor, packet and execution verification for two native duplex boots."""
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys

sys.dont_write_bytecode = True
from evidence_io import checksums, read, regular, require, sha

VERIFIER = "tools/verify_linux_source_net_duplex.py"
BOARD = "docs/evidence/native-linux-net-irq-board"
PROFILE = "drivers/linux-compat/profiles/virtio-net.json"
STAGES = ("ready","held","overlap","completed","ack","final")
RAW = {"net.events","ingress.bin","egress.bin","nonce.bin","wire.pcap","machine.log","uart.log","stderr.log",
       "launch.json","observer-commit.txt","observer.sha256"}
CONTROLS = {"pcap","used","peer","grant"}
LINUX = "4700e3adf3b24b39dd4929e9c6d62811ba3ccea8"
LINUX_HASH = "05e676f7fc4f91783c961c860b930fae33462348064887eea95be3a440282a29"
HEADERS_HASH = "901bb6ced9321e225b59395161f80a66146e3beaa9252f94c6430f545c84806b"


def git_identity(file, kind, oid):
    data = file.read_bytes()
    require(hashlib.sha1(f"{kind} {len(data)}\0".encode() + data).hexdigest() == oid, f"Git {kind} identity {file}")


def build_evidence(root, name):
    base = root / "builds" / name
    native, imported = base / "native", base / "imported"
    pkg, imp = read(native / "manifest.json"), read(imported / "import.json")
    rev = pkg["commit"]
    require(re.fullmatch("[0-9a-f]{40}", rev) and sha(native / "manifest.json") == name and
            (pkg["tracked_changes"], pkg["board"], pkg["app"], pkg["policy"]) == ("", "virt", "process", "fifo") and
            imp["mode"] == "lifecycle-duplex-service" and len(pkg["slots"]) == 2,
            "native lifecycle build")
    require(pkg["linux_source_net_duplex"]["queue_pairs"] == 1 and
            (pkg["linux_source_net_duplex"]["rx_queue"],pkg["linux_source_net_duplex"]["tx_queue"]) == (0,1),
            "registered RX/TX queue pair")
    sources = root / "source/jnox" / rev
    git_identity(sources / "commit.raw", "commit", rev)
    require(sha(native / "kernel.elf") == pkg["kernel_elf_sha256"] and
            sha(native / "build.log") == pkg["build_log_sha256"], "kernel digest or build log")
    kernel = (native / "kernel.elf").read_bytes()
    argv = pkg["package_argv"]
    require("--linux-source-net-duplex" in argv and
            [argv[i+1] for i,k in enumerate(argv) if k in ("--elf","--peer-elf")] ==
            [s["input"]["path"] for s in pkg["slots"]], "selected ELF arguments")
    roles = []
    peer = imp["irq_peer"]
    spec = importlib.util.spec_from_file_location("linked_native_roots", regular(sources, "tools/native_amc_roots.py"))
    roots_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(roots_module)
    roots = roots_module.linked_roots(native / "kernel.elf", len(pkg["slots"]))
    for slot, (s, role, src, elf, digest, map_hash) in enumerate(zip(pkg["slots"], ("driver","peer"),
            ("examples/linux-source-net-duplex/driver.c", peer["source"]), ("service.elf","peer.elf"),
            (imp["service"]["sha256"], peer["elf"]["sha256"]), (imp["link_map_sha256"],peer["link_map_sha256"]))):
        app = regular(native, s["elf"])
        obj = ("driver.o","irq_peer.o")[slot]
        require((s["slot"],s["argv"],s["priority"]) == (slot,["/bin/app"],8) and src in imp["input_sha256_by_object"][obj],
                f"{role} slot or source")
        require(sha(app) == sha(imported / elf) == s["input"]["sha256"] == s["elf_sha256"] == digest ==
                pkg["source_sha256"][s["input"]["path"]] and app.read_bytes() in kernel and
                sha(imported / Path(elf).with_suffix(".map")) == map_hash, f"{role} link or embedded ELF")
        require(s.get("expected_ttbr0_el1", roots[slot]) == roots[slot], f"{role} linked address-space root")
        roles.append({"role": role, "slot": slot, "sha256": digest, "source": src,
                      "linked_ttbr0_el1": hex(roots[slot]), "map_sha256": map_hash})
    require(roles[0]["linked_ttbr0_el1"] != roles[1]["linked_ttbr0_el1"], "two distinct slot roots")
    for filename, item in imp["objects"].items():
        require(sha(regular(imported, filename)) == item["sha256"], f"object {filename}")
    for key in ("driver_object", "callback_object"):
        item = imp[key]
        require(sha(regular(imported, item["filename"])) == item["sha256"], key)
    for name in imp["input_sha256_by_object"]:
        regular(imported, name)
    index = read(base / "source-index.json")
    files = index["compiler_inputs"]
    require(set(files) == set(imp["input_sha256"]) and sha(sources / PROFILE) == imp["profile_sha256"],
            "compiler file inventory or import profile")
    profile = read(sources / PROFILE)
    require(profile["upstream"] == imp["upstream"] and profile["headers"] == imp["header_profile"], "intake source profile")
    upstream = imp["upstream"]
    require(upstream["commit"] == LINUX and upstream["sha256"] == imp["source"]["sha256"] == LINUX_HASH and
            upstream["path"] == "drivers/net/virtio_net.c", "pinned original Linux source")
    git_identity(regular(root, files[upstream["path"]]), "blob", upstream["git_blob_sha1"])
    header_root = root / "source/linux-headers" / HEADERS_HASH
    ledger = read(header_root / "tree.json")
    whole = hashlib.sha256()
    for path, digest in sorted(ledger.items()):
        whole.update(path.encode() + b"\0" + bytes.fromhex(digest))
    require(len(ledger) == 9403 and whole.hexdigest() == imp["header_tree_sha256"] == HEADERS_HASH, "header tree identity")
    for path, digest in profile["headers"]["generated_sha256"].items():
        require(ledger[path] == digest == sha(regular(header_root / "files", path)), f"generated header {path}")
    for path, target in files.items():
        digest = imp["input_sha256"][path]
        require(sha(regular(root, target)) == digest, f"compiler input {path}")
        if path.startswith("headers/"):
            require(ledger[path[8:]] == digest, f"header provenance {path}")
    for path, digest in pkg["kernel_build"]["config_sha256"].items():
        require(sha(regular(sources, path)) == digest, f"kernel configuration {path}")
    return {"source_commit": rev, "linux_commit": LINUX, "linux_tu_sha256": LINUX_HASH,
            "header_tree_sha256": HEADERS_HASH, "compiler_input_count": len(files), "roles": roles,
            "import_sha256": sha(imported / "import.json"), "kernel_sha256": pkg["kernel_elf_sha256"],
            "objects": {n:sha(imported / n) for n in ("virtio_net.original.o","virtio_net.packet.o","virtio_net.callback.o")}}


def python(root, args, **opts):
    env = dict(os.environ, LC_ALL="C", PYTHONPATH=str(root / "vendor"),
               PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1")
    env.pop("PYTHONOPTIMIZE", None)
    return subprocess.check_output([sys.executable, "-B", *args], cwd=root, env=env, **opts)


def observer_args(case,launch):
    base = "builds/"+case["build"]
    return [f"observers/{case['observer_commit']}/{VERIFIER}","--replay","--mutation-tests",
            "--package",base+"/native","--driver-manifest",base+"/imported/import.json","--out","captures/"+case["label"],
            "--mac",launch["mac"],"--mtu",str(launch["mtu"])]


def socket_frames(path):
    raw = path.read_bytes()
    frames = []
    cursor = 0
    while cursor < len(raw):
        length, = struct.unpack_from(">I",raw,cursor)
        cursor += 4
        require(60 <= length <= 1518 and cursor+length <= len(raw),"truncated Ethernet socket stream")
        frames.append(raw[cursor:cursor+length])
        cursor += length
    return frames


def peer_views(base,cap,identity,ingress,egress):
    ram = {}
    for key,encoded in read(cap/"final/ram.json").items():
        address,length = key.split("/")
        addr,chunk = int(address,16),bytes.fromhex(encoded)
        require(len(chunk) == int(length),"physical RAM read size")
        for offset,value in enumerate(chunk):
            require(ram.setdefault(addr+offset,value)==value,"conflicting physical observations")
    mask = 0xfffffffff000
    def physical(addr,size):
        return bytes(ram[pa] for pa in range(addr,addr+size))
    def user(va,n):
        data = bytearray()
        while n:
            table = int(identity["roles"][1]["linked_ttbr0_el1"],16)&mask
            for shift in (30,21,12):
                entry = int.from_bytes(physical(table+8*((va>>shift)&511),8),"little")
                require(entry&3 == 3,"peer address translation")
                table = entry&mask
            length = min(n,4096-va%4096)
            data.extend(physical(table+va%4096,length))
            va += length
            n -= length
        return bytes(data)
    symbols = subprocess.check_output(["aarch64-linux-gnu-nm","-S","--defined-only",base/"native/native_peer.elf"],text=True)
    fields = (("jnox_duplex_peer_requests",b"".join(f.ljust(91,b"\0") for f in ingress[:-1])),
              ("jnox_duplex_peer_replies",b"".join(f.ljust(91,b"\0") for f in egress)),
              ("jnox_duplex_peer_ack",ingress[-1]))
    result = {}
    for name,packets in fields:
        row, = [line.split() for line in symbols.splitlines() if line.split()[-1:]==[name]]
        va,n = int(row[0],16),int(row[1],16)
        data = user(va,n)
        require(data == packets,f"final peer memory {name} differs from socket bytes")
        result[name] = {"virtual_address":hex(va),"size":n,"sha256":hashlib.sha256(data).hexdigest()}
    return result


def replay(root):
    members = checksums(root)
    cases,builds,nonces = {},{},set()
    specs = read(root/"bundle.json")["cases"]
    require(len(specs)==2,"two cold boots")
    for case in specs:
        label,bid,rev = (case[k] for k in ("label","build","observer_commit"))
        require(label not in cases and re.fullmatch(r"[A-Za-z0-9][\w.-]*",label) and
                re.fullmatch("[0-9a-f]{64}",bid) and re.fullmatch("[0-9a-f]{40}",rev),"case identity")
        base,cap,obs = root/"builds"/bid,root/"captures"/label,root/"observers"/rev
        if bid not in builds:
            builds[bid] = build_evidence(root,bid)
        identity = builds[bid]
        git_identity(obs/"commit.raw","commit",rev)
        require((cap/"observer-commit.txt").read_text().strip() == rev and case["build_commit"] == identity["source_commit"],
                "source and capture commit binding")
        measured = {}
        for line in (cap/"observer.sha256").read_text().splitlines():
            digest,name = line.split("  ",1)
            require(name not in measured,"duplicate frozen module")
            measured[name]=digest
        for path in (obs/"tools").glob("*.py"):
            require(sha(path) == measured["tools/"+path.name],f"frozen observer module {path}")
        launch = read(cap/"launch.json")
        board = read(obs/BOARD/"board.json")
        require(launch["kernel_sha256"]==identity["kernel_sha256"] and launch["import_sha256"]==identity["import_sha256"] and
                hashlib.sha256(gzip.decompress((obs/BOARD/"virt-net.dtb.gz").read_bytes())).hexdigest()==board["sha256"],
                "launch and pinned board provenance")
        if "qemu_sha256" in launch:
            require(launch["qemu_sha256"]==board["qemu_sha256"],"recorded QEMU identity")
        nonce=(cap/"nonce.bin").read_bytes()
        require(len(nonce)==8 and nonce not in nonces,"independent boot nonce")
        nonces.add(nonce)
        inventory = set(RAW)|set(STAGES)
        if case["raw_result_json"]:
            inventory.add("result.json")
        require({p.name for p in cap.iterdir()}==inventory,"raw capture inventory")
        for stage in STAGES:
            require({p.name for p in (cap/stage).iterdir()}=={"ram.json","qmp.json","halted.json","trace.json"},"checkpoint extent")
        argv = observer_args(case,launch)
        result = json.loads(python(root,argv))
        original = read(root/"observations"/label/"capture-stdout.log")
        require(result==original and set(result["rejected"]) >= CONTROLS,"capture stdout and observer mutation verdicts")
        if case["raw_result_json"]:
            require(original==read(cap/"result.json"),"recorded capture JSON")
        independent = json.loads(python(root,case["independent_argv"]))
        require(independent==read(root/"qa"/(label+".json")) and independent["nonce"]==nonce.hex() and
                independent["entries"]==result["original_entries"] and result["queue_notifications"][1]==80,
                "full independent reader stdout")
        ingress,egress = (socket_frames(cap/file) for file in ("ingress.bin","egress.bin"))
        require(len(ingress)==result["incoming_frames"]==81 and len(egress)==result["reply_frames"]==80,
                "two framed socket streams")
        peer = peer_views(base,cap,identity,ingress,egress)
        checkpoints={}
        for name in STAGES:
            checkpoints[name]={"trace_bytes":read(cap/name/"trace.json")["machine_log_bytes"],
                               "independent_rx_avail_used_tx_avail_used":independent["stages"][name]}
        cases[label]={"build_commit":identity["source_commit"],"observer_commit":rev,"nonce":nonce.hex(),
                      "mac":launch["mac"],"mtu":launch["mtu"],"qemu_sha256_at_capture":launch.get("qemu_sha256"),
                      "pinned_board_qemu_sha256":board["qemu_sha256"],"board_dtb_sha256":board["sha256"],
                      "capture_stdout_sha256":sha(root/"observations"/label/"capture-stdout.log"),
                      "ingress_sha256":sha(cap/"ingress.bin"),"egress_sha256":sha(cap/"egress.bin"),
                      "pcap_sha256":sha(cap/"wire.pcap"),"checkpoints":checkpoints,"final_peer_memory":peer,
                      "observer":result,"independent":independent,"observer_argv":["python3","-B",*argv],
                      "independent_argv":["python3","-B",*case["independent_argv"]]}
    return {"checksummed_members":members,"builds":builds,"captures":cases}


if __name__ == "__main__":
    print(json.dumps(replay(Path(__file__).resolve().parent),indent=2))
