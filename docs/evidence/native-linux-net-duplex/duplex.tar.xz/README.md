# Native Linux-source full-duplex NIC evidence

Extract into an empty Linux directory and run `python3 -B replay.py`. The offline replay uses Python 3.10 or newer, GNU nm and aarch64-linux-gnu-nm. Pyelftools 0.32 and its license are bundled.

| Boot | Build commit | Frozen observer | MAC | MTU |
|---|---|---|---|---|
| cold-01 | cb2ec7625818c3cfcbfb6d70aad2f5915a2a93fb | cb2ec7625818c3cfcbfb6d70aad2f5915a2a93fb | 52:54:00:44:10:01 | 1410 |
| cold-02 | cb2ec7625818c3cfcbfb6d70aad2f5915a2a93fb | cb2ec7625818c3cfcbfb6d70aad2f5915a2a93fb | 52:54:00:44:10:52 | 1490 |

Each capture retains six stopped checkpoints, the protected RX grant table, RX/TX ring and DMA contents, two private address spaces, trace byte offsets, raw length-prefixed ingress and egress streams, Ethernet PCAP, UART, QEMU execution and device traces, and the exact launch command. The held and overlap stops permit checking RX progress while the first submitted TX descriptor is still unnotified. The launch records identify the executable path. They omit a capture-time QEMU executable digest. The board's separately pinned executable digest is identified in the report.

The archive retains the original capture stdout under observations/, the captured kernel and both embedded role ELFs, object files, maps, and the pinned original Linux translation unit. Each build's source index maps every recorded compiler dependency to archived bytes. The header tree digest ledger covers all 9,403 pinned files and the compiled subset is present. Replay compares the original stdout and all four corruption outcomes to the frozen observer result. It separately recomputes the independent reader's retained JSON, reads both 80-slot histories and the final ACK directly from the peer's translated RAM, and compares them with the two external streams. In each checkpoint summary the four indices are RX available, RX used, TX available and TX used. The final indices summarize completed traffic; terminal release is checked from scrubbed rings.

Individual offline commands from the extracted directory follow.

```sh
PYTHONPATH=vendor python3 -B observers/cb2ec7625818c3cfcbfb6d70aad2f5915a2a93fb/tools/verify_linux_source_net_duplex.py --replay --mutation-tests --package builds/8ba4bd5b0d97eefdba9c96e197f834674f8b7f5e535cf5722149e18acfcbad89/native --driver-manifest builds/8ba4bd5b0d97eefdba9c96e197f834674f8b7f5e535cf5722149e18acfcbad89/imported/import.json --out captures/cold-01 --mac 52:54:00:44:10:01 --mtu 1410
PYTHONPATH=vendor python3 -B qa/replay.py builds/8ba4bd5b0d97eefdba9c96e197f834674f8b7f5e535cf5722149e18acfcbad89 captures/cold-01 source/linux/4700e3adf3b24b39dd4929e9c6d62811ba3ccea8/drivers/net/virtio_net.c
PYTHONPATH=vendor python3 -B observers/cb2ec7625818c3cfcbfb6d70aad2f5915a2a93fb/tools/verify_linux_source_net_duplex.py --replay --mutation-tests --package builds/8ba4bd5b0d97eefdba9c96e197f834674f8b7f5e535cf5722149e18acfcbad89/native --driver-manifest builds/8ba4bd5b0d97eefdba9c96e197f834674f8b7f5e535cf5722149e18acfcbad89/imported/import.json --out captures/cold-02 --mac 52:54:00:44:10:52 --mtu 1490
PYTHONPATH=vendor python3 -B qa/replay.py builds/8ba4bd5b0d97eefdba9c96e197f834674f8b7f5e535cf5722149e18acfcbad89 captures/cold-02 source/linux/4700e3adf3b24b39dd4929e9c6d62811ba3ccea8/drivers/net/virtio_net.c
```
