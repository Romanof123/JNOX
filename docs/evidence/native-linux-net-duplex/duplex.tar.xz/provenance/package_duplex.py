#!/usr/bin/env python3
"""Package a pair of completed native Linux-source full-duplex NIC boots."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import stat
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
from evidence_io import archive, copy, export, extract, git, read, regular, require, sha, write
from replay import BOARD, HEADERS_HASH, LINUX, PROFILE, RAW, STAGES, VERIFIER, observer_args

PM = Path(__file__).resolve().parent
LAB = Path.home() / "jnox406-lab"
KNOWN_SOURCE = {"arch/aarch64", "kernel", "boards", "examples/linux-source-net-duplex", PROFILE}
BUILD_TOOLS = ["tools/build_linux_source_virtio_net.py", "tools/build_native_el0.py", "tools/build_kernel.py"]


def tool_closure(repo, rev, entrypoints):
    """Follow imports only among Python modules tracked under tools/ at this revision."""
    paths = {p for p in git(repo, "ls-tree", "-r", "--name-only", rev, "--", "tools").decode().splitlines()
             if re.fullmatch(r"tools/[A-Za-z_][A-Za-z_0-9]*\.py", p)}
    selected, pending = set(), list(entrypoints)
    while pending:
        path = pending.pop()
        if path in selected:
            continue
        require(path in paths, f"missing tracked Python tool {rev}:{path}")
        selected.add(path)
        code = git(repo, "show", f"{rev}:{path}")
        for node in ast.walk(ast.parse(code)):
            if isinstance(node, ast.Import):
                names = [n.name for n in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                names = [node.module]
            else:
                continue
            for name in names:
                dependency = "tools/" + name.split(".")[0] + ".py"
                if dependency in paths and dependency not in selected:
                    pending.append(dependency)
    return selected


def header_ledger(headers, dest):
    dest.mkdir(parents=True, exist_ok=True)
    if (dest / "tree.json").exists():
        return
    records = {}
    for root, dirs, files in os.walk(headers, followlinks=False):
        directory = Path(root)
        for name in dirs:
            require(stat.S_ISDIR((directory / name).lstat().st_mode), f"linked header directory {directory / name}")
        for name in files:
            file = directory / name
            require(stat.S_ISREG(file.lstat().st_mode), f"linked or irregular header {file}")
            records[file.relative_to(headers).as_posix()] = sha(file)
    whole = hashlib.sha256()
    for name, digest in sorted(records.items()):
        whole.update(name.encode() + b"\0" + bytes.fromhex(digest))
    require(len(records) == 9403 and whole.hexdigest() == HEADERS_HASH, "pinned compiler header tree differs")
    write(dest / "tree.json", records)


def add_build(stage, args, build, bid):
    dest = stage / "builds" / bid
    m, imp = read(regular(build, "native/manifest.json")), read(regular(build, "imported/import.json"))
    require(m["tracked_changes"] == "" and imp["mode"] == "lifecycle-duplex-service" and
            m["linux_source_net_duplex"]["queue_pairs"] == 1, "expected clean native duplex build")
    native = ["manifest.json", "kernel.elf", "user.elf", "native_peer.elf", "build.log"]
    for name in native:
        copy(regular(build, Path("native") / name), dest / "native" / name)
    copy(regular(build, "build.log"), dest / "build.log")
    objects = set(imp["input_sha256_by_object"]) | set(imp["objects"]) | {imp[k]["filename"] for k in ("callback_object","driver_object")}
    for name in objects | {"service.elf","peer.elf","service.map","peer.map","import.json"}:
        require(Path(name).name == name, f"unexpected intake filename {name}")
        copy(regular(build, Path("imported") / name), dest / "imported" / name)
    rev = m["commit"]
    require(re.fullmatch("[0-9a-f]{40}", rev) and imp["header_tree_sha256"] == HEADERS_HASH, "commit or header profile")
    headers = args.headers or Path(imp["header_root"])
    source = args.linux_source or Path(imp["source"]["path"])
    hdir = stage / "source/linux-headers" / HEADERS_HASH
    header_ledger(headers, hdir)
    for path, digest in imp["header_profile"]["generated_sha256"].items():
        copy(regular(headers, path), hdir / "files" / path, digest)
    tracked = KNOWN_SOURCE | tool_closure(args.repo, rev, BUILD_TOOLS)
    inputs = {}
    for name, digest in imp["input_sha256"].items():
        path = Path(name)
        require(".." not in path.parts, f"invalid compiler path {name}")
        if name.startswith("headers/"):
            rel = path.relative_to("headers")
            target = hdir / "files" / rel
            copy(regular(headers, rel), target, digest)
        elif name == imp["upstream"]["path"]:
            require(imp["upstream"]["commit"] == LINUX and name == "drivers/net/virtio_net.c", "upstream input")
            target = stage / "source/linux" / LINUX / name
            copy(source, target, digest)
        elif path.is_absolute():
            require(path.parent.name == "build" and path.suffix in (".h",".inc"), f"unrecognized generated input {name}")
            target = dest / "imported" / path.name
            copy(regular(build, Path("imported") / path.name), target, digest)
        else:
            tracked.add(name)
            target = stage / "source/jnox" / rev / path
        inputs[name] = target.relative_to(stage).as_posix()
    export(args.repo, rev, tracked, stage / "source/jnox" / rev)
    write(dest / "source-index.json", {"commit": rev, "compiler_inputs": inputs})
    return m


def package(stage,args):
    require(len(args.case)==2 and len({c[0] for c in args.case})==2,"two separately labeled cold boots")
    cases,rows,commands=[],[],[]
    copy(args.independent_dir/"replay.py",stage/"qa/replay.py")
    for label,location,commit,rev,log in args.case:
        require(re.fullmatch(r"[A-Za-z0-9][\w.-]*",label) and all(re.fullmatch("[0-9a-f]{40}",r) for r in (commit,rev)),
                "case label and full Git identities")
        build = Path(location)
        cap = build/label
        stdout = Path(log)
        require(cap.is_dir() and not cap.is_symlink() and not (cap/"failure.json").exists(),"completed cold capture")
        require(stdout.parent.parent.resolve()==build.resolve() and stdout.parent.name.startswith("observer.")
                and stdout.name=="output.log" and sha(regular(stdout.parent,"observer.sha256"))==sha(regular(cap,"observer.sha256")),
                "capture stdout must belong to its observed frozen helper set")
        manifest = regular(build,"native/manifest.json")
        bid=sha(manifest)
        require(read(manifest)["commit"]==commit and regular(cap,"observer-commit.txt").read_text().strip()==rev,
                "explicit build and capture-time Git commit")
        if not (stage/"builds"/bid).exists():
            add_build(stage,args,build,bid)
        obs = stage/"observers"/rev
        if not obs.exists():
            files = tool_closure(args.repo,rev,[VERIFIER])|{BOARD+"/board.json",BOARD+"/virt-net.dtb.gz"}
            export(args.repo,rev,files,obs)
        dest=stage/"captures"/label
        require({p.name for p in cap.iterdir() if p.is_dir()}==set(STAGES),"six duplex checkpoints")
        for name in RAW:
            copy(regular(cap,name),dest/name)
        raw_result=(cap/"result.json").is_file()
        if raw_result:
            copy(regular(cap,"result.json"),dest/"result.json")
        for which in STAGES:
            for name in ("trace.json","ram.json","qmp.json","halted.json"):
                copy(regular(cap,Path(which)/name),dest/which/name)
        copy(stdout,stage/"observations"/label/"capture-stdout.log")
        copy(regular(args.independent_dir,label+".json"),stage/"qa"/(label+".json"))
        read_stdout=read(stdout)
        require("rejected" in read_stdout and read_stdout["reply_frames"]==80,f"original observer stdout {label}")
        independent=["qa/replay.py","builds/"+bid,"captures/"+label,"source/linux/"+LINUX+"/drivers/net/virtio_net.c"]
        case={"label":label,"build":bid,"build_commit":commit,"observer_commit":rev,"raw_result_json":raw_result,
              "capture_stdout_origin":stdout.as_posix(),"independent_argv":independent}
        cases.append(case)
        launch=read(dest/"launch.json")
        rows.append(f"| {label} | {commit} | {rev} | {launch['mac']} | {launch['mtu']} |")
        for argv in (observer_args(case,launch),independent):
            commands.append("PYTHONPATH=vendor "+shlex.join(["python3","-B",*argv]))
    for file in (args.vendor/"elftools").rglob("*.py"):
        rel=file.relative_to(args.vendor)
        copy(regular(args.vendor,rel),stage/"vendor"/rel)
    regular(stage,"vendor/elftools/elf/elffile.py")
    for name in ("LICENSE","METADATA"):
        rel=Path("pyelftools-0.32.dist-info")/name
        copy(regular(args.vendor,rel),stage/"vendor"/rel)
    for file in ("replay.py","evidence_io.py"):
        copy(PM/file,stage/file)
    copy(PM/"package_duplex.py",stage/"provenance/package_duplex.py")
    copy(args.build_script,stage/"provenance/build.sh")
    copy(args.capture_script,stage/"provenance/capture.sh")
    copy(args.license,stage/"source/GPL-2.0")
    for note in args.report_note:
        require(note.suffix.lower() in (".md",".txt"),"text QA report")
        copy(note,stage/"qa/notes"/note.name)
    write(stage/"bundle.json",{"format":1,"cases":cases})
    (stage/"README.md").write_text(
        "# Native Linux-source full-duplex NIC evidence\n\nExtract into an empty Linux directory and run `python3 -B replay.py`. "
        "The offline replay uses Python 3.10 or newer, GNU nm and aarch64-linux-gnu-nm. Pyelftools 0.32 and its license are bundled.\n\n"
        "| Boot | Build commit | Frozen observer | MAC | MTU |\n|---|---|---|---|---|\n"+"\n".join(rows)+
        "\n\nEach capture retains six stopped checkpoints, the protected RX grant table, RX/TX ring and DMA contents, "
        "two private address spaces, trace byte offsets, raw length-prefixed ingress and egress streams, Ethernet PCAP, UART, "
        "QEMU execution and device traces, and the exact launch command. The held and overlap stops permit checking RX progress "
        "while the first submitted TX descriptor is still unnotified. The launch records identify the executable path. "
        "They omit a capture-time QEMU executable digest. The board's separately pinned executable digest is identified in the report.\n\n"
        "The archive retains the original capture stdout under observations/, the captured kernel and both embedded role ELFs, "
        "object files, maps, and the pinned original Linux translation unit. Each build's source index maps every recorded compiler "
        "dependency to archived bytes. The header tree digest ledger covers all 9,403 pinned files and the compiled subset is present. "
        "Replay compares the original stdout and all four corruption outcomes to the frozen observer result. It separately recomputes "
        "the independent reader's retained JSON, reads both 80-slot histories and the final ACK directly from the peer's translated "
        "RAM, and compares them with the two external streams. In each checkpoint summary the four indices are RX available, RX used, "
        "TX available and TX used. The final indices summarize completed traffic; terminal release is checked from scrubbed rings.\n\n"
        "Individual offline commands from the extracted directory follow.\n\n```sh\n"+"\n".join(commands)+"\n```\n",encoding="utf-8")
    members=sorted(p for p in stage.rglob("*") if p.is_file())
    (stage/"SHA256SUMS").write_text("".join(f"{sha(p)}  {p.relative_to(stage).as_posix()}\n" for p in members))


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--case",nargs=5,action="append",required=True,metavar=("LABEL","BUILD","BUILD_SHA","OBSERVER_SHA","ORIGINAL_STDOUT"))
    cli.add_argument("--output",type=Path,required=True)
    cli.add_argument("--repo",type=Path,default=LAB/"src")
    cli.add_argument("--linux-source",type=Path)
    cli.add_argument("--headers",type=Path)
    cli.add_argument("--license",type=Path,default=PM.parent/"jnox424-pm/GPL-2.0")
    cli.add_argument("--vendor",type=Path,default=PM.parent/"jnox332-release-deps")
    cli.add_argument("--independent-dir",type=Path,default=PM.parent/"jnox441-independent")
    cli.add_argument("--report-note",type=Path,action="append",default=[])
    cli.add_argument("--build-script",type=Path,default=PM.parent/"jnox426-lifecycle/build.sh")
    cli.add_argument("--capture-script",type=Path,default=PM.parent/"jnox426-lifecycle/capture.sh")
    args=cli.parse_args()
    output=args.output.absolute()
    require(not output.exists(),f"output exists {output}")
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="jnox-duplex-offline-") as tmp,tempfile.TemporaryDirectory(
            prefix=".jnox441-",dir=output.parent) as pubroot:
        work,pub=Path(tmp),Path(pubroot)/"release"
        stage=work/"bundle"
        stage.mkdir()
        pub.mkdir()
        package(stage,args)
        tar=pub/"duplex.tar.xz"
        archive(stage,tar)
        fresh=work/"extracted"
        extract(tar,fresh)
        result=json.loads(subprocess.check_output([sys.executable,"-B","replay.py"],cwd=fresh))
        write(pub/"result.json",result)
        copy(fresh/"README.md",pub/"README.md")
        digest=sha(tar)
        (pub/(tar.name+".sha256")).write_text(f"{digest}  {tar.name}\n")
        require(not output.exists(),f"output appeared during packaging {output}")
        pub.rename(output)
        print(f"{digest}  {output/tar.name}")


if __name__=="__main__":
    main()
