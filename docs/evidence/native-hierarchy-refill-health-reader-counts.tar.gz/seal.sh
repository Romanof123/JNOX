set -eu
find cases outputs -type f > members
ls *.py *.json *.md *.log seal.sh >> members
sort -u members -o members
xargs -d '\n' sha256sum < members > MEMBER-SHA256
tar -czf reader-a242-first.tar.gz -T members MEMBER-SHA256
mkdir recheck
tar xf reader-a242-first.tar.gz -C recheck
(cd recheck && sha256sum -c MEMBER-SHA256 > ../verification.log)
dest=/mnt/d/codex/.jnox-work/next-fixed/340-verification-a242
mkdir -p "$dest"
cp reader-a242-first.tar.gz reader-supplement.en-ko.md "$dest/"
sha256sum reader-a242-first.tar.gz reader-supplement.en-ko.md "$dest"/*
