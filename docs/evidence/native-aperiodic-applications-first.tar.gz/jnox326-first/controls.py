from pathlib import Path
import subprocess as s, json, os
base=Path.home()/'v326'
src=base/'src'
a=str(base/'raw/service.elf'); b=str(base/'raw/background.elf')
out=[]
for name,policy,opts in [
 ('duplicate','polling',['--server-slot-ms','50','--server-slot-ms','50','--server-budget','2,5']),('zero-slot','polling',['--server-slot-ms','0','--server-budget','2,5']),('quota','polling',['--server-slot-ms','50','--server-budget','3,2']),('zero-credit','sporadic',['--server-slot-ms','50','--server-budget','2,5','--server-credits','0']),('too-many-credit','sporadic',['--server-slot-ms','50','--server-budget','2,5','--server-credits','9']),('incompatible-credit','deferrable',['--server-slot-ms','50','--server-budget','2,5','--server-credits','1']),('third','polling',['--server-slot-ms','50','--server-budget','2,5','--peer-elf',b]),('board','polling',['--server-slot-ms','50','--server-budget','2,5','--board','pi4']),('overflow','polling',['--server-slot-ms',str(2**63),'--server-budget','2,5'])]:
 cmd=['python3','tools/build_native_el0.py','--out',str(base/('negative-'+name)),'--elf',a,'--peer-elf',b,'--policy',policy]+opts
 p=s.run(cmd,cwd=src,capture_output=True,text=True);out.append([name,cmd,p.returncode,p.stderr.strip().splitlines()[-1]]);assert p.returncode==2
for name,extra,expect in [('legacy-ss2',{'JNOX_PROFILE':'aperiodic','JNOX_APP':'a-ss2'},True),('direct-invalid',{'JNOX_PROFILE':'native','JNOX_APP':'process','JNOX_NATIVE_POLICY':'sporadic','JNOX_NATIVE_SERVER_SLOT_MS':'50','JNOX_NATIVE_SERVER_BUDGET':'2,5','JNOX_NATIVE_SERVER_CREDITS':'9'},False)]:
 cmd=['python3','tools/build_kernel.py','--arch','aarch64'];env={**os.environ,**extra,'JNOX_BOARD':'virt','CARGO_TARGET_DIR':str(base/name)}
 p=s.run(cmd,cwd=src,capture_output=True,text=True,env=env); (Path(__file__).parent/(name+'.log')).write_text(p.stdout+p.stderr); out.append([name,cmd,extra,p.returncode]);print(name,p.returncode,file=__import__('sys').stderr)
print(json.dumps(out,indent=2))

