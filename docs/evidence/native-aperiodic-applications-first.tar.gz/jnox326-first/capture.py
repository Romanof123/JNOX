import pathlib, subprocess as sp, os, time, socket, json, tarfile, hashlib, sys
root=pathlib.Path.home()/'v326'
raw=root/'raw'
for name,policy,cap in [('polling','polling',0),('deferrable','deferrable',0),('sporadic-two','sporadic',2),('sporadic-one','sporadic',1),('traced-two','sporadic',2)]:
 d=raw/name if name!='polling' else raw/'first-polling'
 d.mkdir(exist_ok=False)
 pkg=raw/('pkg-'+('sporadic-two' if name=='traced-two' else name))
 cmd=['python3','tools/build_native_el0.py','--out',str(pkg),'--policy',policy,'--server-slot-ms','50','--server-budget','2,5','--elf',str(raw/'service.elf'),'--peer-elf',str(raw/'background.elf')]+(['--server-credits',str(cap)] if cap else [])
 if not pkg.exists():sp.run(cmd,cwd=root/'src',check=True,stdout=(d/'pack.log').open('w'),stderr=sp.STDOUT)
 (d/'build-command.json').write_text(json.dumps(cmd))
 cmd=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-qmp','unix:'+str(d/'qmp.sock')+',server=on,wait=off','-no-reboot','-serial','file:'+str(d/'uart'),' -kernel'.strip(),str(pkg/'kernel.elf')]
 if name=='traced-two':cmd+=['-d','int','-D',str(d/'trace')]
 (d/'command.json').write_text(json.dumps(cmd))
 p=sp.Popen(cmd,stderr=(d/'stderr').open('w')); s=socket.socket(socket.AF_UNIX)
 for i in range(200):
  try:s.connect(str(d/'qmp.sock'));break
  except OSError:time.sleep(.02)
 f=s.makefile('rwb',buffering=0);f.readline()
 def op(action,args={}):
  f.write((json.dumps(dict(execute=action,arguments=args))+'\n').encode())
  while True:
   item=json.loads(f.readline())
   if 'return' in item:return item['return']
   if 'error' in item:raise ValueError(item)
 op('qmp_capabilities')
 for i in range(800):
  if (d/'uart').exists() and b'NATIVE SERVER DROPPED' in (d/'uart').read_bytes():time.sleep(.2);break
  time.sleep(.05)
 op('stop'); op('pmemsave',dict(val=0x40000000,size=128<<20,filename=str(d/'ram')));op('quit');p.wait()
 archive=pathlib.Path('/mnt/d/codex/jnox326-first')/(name+'.tar.gz')
 with tarfile.open(archive,'w:gz',compresslevel=1) as t:
  for path in [*d.iterdir(),*pkg.iterdir()]:
   if path.is_file():t.add(path,arcname=('guest/' if path.parent==d else 'package/')+path.name)
 print(name,hashlib.sha256(archive.read_bytes()).hexdigest(),flush=True)
