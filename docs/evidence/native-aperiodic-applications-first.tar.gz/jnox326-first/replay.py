from pathlib import Path
import struct, subprocess, re, json, mmap
raw=Path.home()/'v326/raw'
def sym(path):
 return {s[2]:int(s[0],16) for l in subprocess.check_output(['aarch64-linux-gnu-nm','-n',path],text=True).splitlines() if len(s:=l.split())==3}
res={}
for name in ['first-polling','deferrable','sporadic-two','sporadic-one','traced-two']:
 d=raw/name
 lines=(d/'uart').read_text().splitlines()
 def rows(tag):return [list(map(int,l.split()[3:])) for l in lines if l.startswith('NATIVE SERVER '+tag+' ')]
 ev=rows('EVENT');cr=rows('CREDITS');_,kind,E,F,H,ms,Q,P,cap=rows('CONFIG')[0]
 q=2; credits=[]; expected=0; issues=[]; checks=[]; grants=[]; first10=[]; wake=[]; origins={}; clocks=[{},{}]; saved={}; lastdest=None; crossings=[]; sleep=[]; due=[None,None]; exited=0; active=False
 def ck(ok,msg):
  if not ok:issues.append(msg)
 for r,c in zip(ev,cr):
  i,reason,entry,decision,op,arg,ret,src,dst,exp,cell,skip,oldcmp,cmp,spill,ready,woke,wa,wb,ex,grid,debit,surrender,before,pre,after,pc,sp,root,target,tsp,restored,stamp,idle,prevstamp,occ,arm=r
  ck(before==q and expected==exp and not skip,f'{i} before/skip')
  if i and lastdest in (0,1):ck(src==lastdest and root==origins[src], f'{i} src root')
  if src in (0,1):saved[src]=(pc,sp)
  if reason==2 and op==7:due[src]=wa;sleep.append(cell)
  if reason==2 and op==1:exited|=1<<src
  dw=sum(1<<k for k,t in enumerate(due) if t is not None and t<=decision)
  for k in range(2):
   if dw>>k&1:due[k]=None
  mask=sum(1<<k for k in range(2) if due[k] is None and not exited>>k&1)
  ck((mask,dw,exited)==(ready,woke,ex),f'{i} readiness')
  if surrender:
   active=False
   if kind==0:q=0
  ck(q==pre,f'{i} pre')
  if grid:
   expected=cell+1
   if kind<2 and cell%P==0:q=Q
   if kind==2:
    q+=sum(a for t,a in credits if t<=cell);credits=[p for p in credits if p[0]>cell]
   if kind==0 and not ready&1:q=0
   active=bool(q and ready&1)
   ck(active==bool(debit),f'{i} debit')
   if active:
    grants.append(cell);q-=1
    if kind==2:
     if len(credits)==cap:credits[-1]=(cell+P,credits[-1][1]+1)
     else:credits.append((cell+P,1))
  ck(q==after and credits==list(zip(c[2::2],c[3::2])),f'{i} credits')
  if kind==2:ck(q+sum(a for _,a in credits)==Q,f'{i} conservation')
  ck(dst==(3 if ex==3 else 0 if active and ready&1 else 1 if cell<2**64-1 and ready&2 else 2),f'{i} selection')
  if dst<2:
   if dst in saved:ck((target,tsp)==saved[dst],f'{i} saved frame')
   origins.setdefault(dst,restored);ck(origins[dst]==restored,f'{i} restored root')
  if woke&1:wake.append(cell)
  if src<2 and reason==2 and op==6:clocks[src][cell]=clocks[src].get(cell,0)+1
  if i and (decision-E)//H!=(entry-E)//H:crossings.append([i,'entry-decision'])
  if dst!=3 and (stamp-E)//H!=(decision-E)//H:crossings.append([i,'decision-return'])
  lastdest=dst
 ram=mmap.mmap((d/'ram').open('rb').fileno(),0,access=mmap.ACCESS_READ) if False else (d/'ram').read_bytes()
 def word(pa):return struct.unpack_from('<Q',ram,pa-0x40000000)[0]
 products=[]
 for pid,elf in enumerate(['service','background']):
  ss=sym(raw/(elf+'.elf'))
  def get(key,n=1):
   va=ss[key];pa=origins[pid]&0xfffff000
   for shift in (30,21,12):pa=word(pa+8*((va>>shift)&511))&0xfffff000
   return [word(pa+(va&4095)+8*j) for j in range(n)]
  product={s:get(s)[0] for s in ['start_ns','end_ns','private_batches','private_blocks']+(['initial_checksum','request_ns','wake_ns'] if pid==0 else [])}; product['result']=get('private_result',9 if pid else 1);b=product['private_blocks'];ck(b==4096*product['private_batches'] and b>0,'batches')
  ck(product['result']==[v*b for v in ([1,8,28,56,70,56,28,8,1] if pid else [5559680])],'product')
  ck(product['end_ns']-product['start_ns']>=(900000000 if pid else 650000000),'duration')
  if not pid:ck(product['initial_checksum']==32640 and product['request_ns']==product['start_ns']+125000000 and product['wake_ns']>=product['request_ns'],'sleep')
  products.append(product)
 trace=None
 if (d/'trace').exists():
  tr=(d/'trace').read_text(); pcs=[int(n,16) for n in re.findall(r'Exception return from AArch64 EL1 to AArch64 EL0 PC 0x([a-f0-9]+)',tr)];expectedpcs=[r[29] for r in ev if r[8]<2];trace={'el0_returns':len(pcs),'all_pcs_match':pcs==expectedpcs,'interrupts':tr.count('Taking exception 5 [IRQ]'),'svcs':tr.count('Taking exception 2 [SVC]')}
 res[name]=dict(rows=len(ev),issues=issues,grants=grants,sleep=sleep,wake=wake,crossings=crossings,dropped=rows('DROPPED'),occupied=rows('OCCUPIED'),clocks=clocks,products=products,roots=origins,trace=trace,exits=[l for l in lines if 'EL0 EXIT' in l])
print(json.dumps(res,indent=2))
