$p='D:/codex/mail201-a667'
foreach($rev in 'parent','candidate'){
Set-Location $(if($rev -eq 'parent'){'D:/codex/jnox201-qa/kernel'}else{'D:/codex/mail201-src/kernel'})
$env:JNOX_BOARD='virt'
Remove-Item Env:JNOX_PROFILE,Env:JNOX_APP -ErrorAction SilentlyContinue
foreach($app in 'periodic-bench','aperiodic-bench','cbs-bench','cbs-wake-bench'){
cargo +1.95.0 build --locked --release -j1 -vv --features $app *> "$p/$rev-$app.build"
if($LASTEXITCODE){throw "build failed $rev/$app"}
Copy-Item target/aarch64-unknown-none/release/jnox-kernel "$p/$rev-$app.elf"
}
if(1){
$env:JNOX_PROFILE='reservation'
foreach($app in 'aligned-wake','cbs-wake','aligned-saturated','cbs-saturated'){
$env:JNOX_APP=$app
cargo +1.95.0 build --locked --release -j1 -vv *> "$p/$rev-$app.build"
if($LASTEXITCODE){throw "build failed $rev/$app"}
Copy-Item target/aarch64-unknown-none/release/jnox-kernel "$p/$rev-$app.elf"
}
}
}


