from pathlib import Path
import zipfile,hashlib,io,json
p=Path(__file__).parent
def sha(b):return hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(p.with_suffix('.zip')) as z:
 for row in z.read('SHA256SUMS').decode().splitlines():
  h,n=row.split('  ',1);assert sha(z.read(n))==h
 for i in range(1,9):
  meta=json.loads(z.read(f'pos{i}-verified.json'));raw=z.read(f'pos{i}.zip');assert sha(raw)==meta['zip']
  with zipfile.ZipFile(io.BytesIO(raw)) as nested:
   assert {n:sha(nested.read(n)) for n in nested.namelist()}==meta['files']
print(len(z.namelist()),sha(p.with_suffix('.zip').read_bytes()))
