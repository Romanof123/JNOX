from pathlib import Path
import subprocess as s,sys,json
d=Path(__file__).parent
for p in sorted(d.glob('pos[1-8]')):
 r=s.run([sys.executable,str(d.parent/'mail201-src/tools/reservation_handoff.py'),str(p/'uart')],capture_output=True)
 print(p.name,r.returncode,r.stderr.decode(),flush=True)
 (d/(p.name+'-official.json')).write_bytes(r.stdout)
 assert r.returncode==0,r.stdout

