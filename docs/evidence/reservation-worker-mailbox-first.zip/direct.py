from pathlib import Path
import json
p=Path(__file__).parent
out=[]
for f in sorted(p.glob('pos[1-8]/uart')):
 rows=[list(map(int,l.split())) for l in f.read_text().splitlines()[3:-1]]
 def t(n):return [r for r in rows if r[0]==n]
 rec=t(24)[1]; z=rows[-1]; epoch=t(2)[0][4]; grants=[]
 for q in t(10):
  id=q[3];slot=q[2]; pick=lambda tag:next(r for r in t(tag) if r[2:4]==[slot,id])
  ret=pick(12); cnt=pick(8); charge=pick(19)
  assert ret[1]==q[4] and q[6]-q[4]==q[7] and q[4]<=q[5]<=q[6] and cnt[5]>cnt[4]
  if slot==0:assert ret[6]==1 and cnt[4]==0 and cnt[6]==0xa19 and charge[5]==q[7] and id==0
  grants.append([slot,id,q[7],charge[4],charge[5]])
 out.append(dict(position=f.parent.name,mask=rec[5],epoch=epoch,stop=z,first_charge=grants[:1],replayed=len(grants),initial_marker_delta=(t(10)[0][5]-epoch if t(10) else None),prep_slack=epoch-t(36)[0][1]))
(p/'direct.json').write_text(json.dumps(out,indent=2))
