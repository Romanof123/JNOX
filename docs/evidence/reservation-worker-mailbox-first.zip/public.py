from pathlib import Path
import hashlib,zipfile,json
p=Path(__file__).parent
def sha(b):return hashlib.sha256(b).hexdigest()
keep=set('criteria.txt freeze.txt change.diff build.ps1 launch.py ledger.py replay.py audit.py score.py direct.py sections.py identity.py layout.py linked.py official.py report.py public.py verify.py qemu.txt tools.txt review.sh'.split())
files=[f for f in sorted(p.iterdir()) if f.is_file() and (f.name in keep or f.suffix in ('.json','.elf','.dis','.symbols','.md','.zip'))]
manifest={f.name:sha(f.read_bytes()) for f in files}
with zipfile.ZipFile(p.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,f.name)
 z.writestr('SHA256SUMS',''.join(v+'  '+k+'\n' for k,v in manifest.items()))
