import pathlib as P,json,hashlib,subprocess as s
from elftools.elf.elffile import ELFFile
p=P.Path(__file__).parent;rows={}
for f in sorted(p.glob('*.elf')):
 with f.open('rb') as b:
  e=ELFFile(b); rows[f.stem]=dict(entry=e.header.e_entry,loads=[[v.header.p_offset,v.header.p_vaddr,v.header.p_paddr,v.header.p_filesz,v.header.p_memsz,v.header.p_flags,v.header.p_align,hashlib.sha256(v.data()).hexdigest()] for v in e.iter_segments() if v.header.p_type=='PT_LOAD'],sections={v.name:[v.header.sh_addr,v.header.sh_size] for v in e.iter_sections() if v.header.sh_flags&2})
 if 'bench' not in f.name:
  for tool,args,ext in [('objdump',['-d'],'dis'),('nm',['-nSC'],'symbols')]:
   (p/(f.stem+'.'+ext)).write_bytes(s.check_output(['aarch64-linux-gnu-'+tool,*args,str(f)]))
(p/'layouts.json').write_text(json.dumps(rows,indent=2))
for k in rows:
 if k.startswith('candidate-'):print(k,rows[k]==rows[k.replace('candidate-','parent-')],rows[k]['loads']==rows[k.replace('candidate-','parent-')]['loads'])
