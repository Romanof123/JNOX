from pathlib import Path
from elftools.elf.elffile import ELFFile
import hashlib,json
p=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
res={}
for f in sorted(p.glob('*.elf')):
 with f.open('rb') as stream:
  e=ELFFile(stream)
  sections={s.name:dict(addr=s['sh_addr'],size=s['sh_size'],type=s['sh_type'],sha256=None if s['sh_type']=='SHT_NOBITS' else sha(s.data())) for s in e.iter_sections() if s['sh_flags']&2}
  fields={}
  for sym in e.get_section_by_name('.symtab').iter_symbols():
   for key in ['MAILBOXES','GENERATION','GOAL','ACTION','FIRST','POINTER']:
    if 'ordinary_reservations' in sym.name and str(len(key))+key+'17h' in sym.name:
     s=e.get_section(sym['st_shndx']);off=sym['st_value']-s['sh_addr'];size=sym['st_size']
     data=s.data()[off:off+size] if s['sh_type']!='SHT_NOBITS' else bytes(size)
     fields[key]=dict(address=sym['st_value'],size=size,section=s.name,words=[int.from_bytes(data[i:i+8],'little') for i in range(0,size,8)])
  if 'bench' not in f.name and f.name.startswith('candidate'):
   assert fields['MAILBOXES']['words']==[2**64-1,0,2**64-1,0,0]*2
  res[f.stem]=dict(sections=sections,fields=fields)
(p/'sections.json').write_text(json.dumps(res,indent=2))
