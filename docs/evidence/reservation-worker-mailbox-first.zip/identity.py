from pathlib import Path
import hashlib,json
from elftools.elf.elffile import ELFFile
p=Path(__file__).parent
def extract(f,name):
 with f.open('rb') as b:
  elf=ELFFile(b); sym=elf.get_section_by_name('.symtab').get_symbol_by_name(name)[0]
  sect=elf.get_section(sym['st_shndx']); off=sym['st_value']-sect['sh_addr'];return sect.data()[off:off+sym['st_size']]
def sha(b):return hashlib.sha256(b).hexdigest()
results={}
for c in sorted(p.glob('candidate-*.elf')):
 parent=p/c.name.replace('candidate-','parent-');app=c.stem[10:]
 o=dict(candidate=sha(c.read_bytes()),parent=sha(parent.read_bytes()))
 if 'bench' not in app:
  for name in ['reservation_rust_work','reservation_worker_a','reservation_worker_b']:
   a,b=extract(c,name),extract(parent,name)
   o[name]=dict(length=len(a),candidate=sha(a),base=sha(b))
 results[app]=o
(p/'identity.json').write_text(json.dumps(results,indent=2))
