from pathlib import Path
import hashlib,json
from audit import compact,oracle
p=Path(__file__).parent
out=[]
for i in range(1,9):
 d=p/f'pos{i}';plan=json.loads((d/'plan.json').read_text());app=plan['app']; lines=(d/'uart').read_text().splitlines()
 assert lines[:3]==['JNOX M1 BOOT','JNOX M1 READY','RSRV RAW 3'] and lines[-1]=='RSRV END' and (d/'status').read_text()=='124'
 assert hashlib.sha256((d/'kernel.elf').read_bytes()).hexdigest()==plan['sha256'] and bool(plan['traced'])==(d/'exceptions.log').exists()
 rows=[list(map(int,l.split())) for l in lines[3:-1]]; a=compact(d,app,rows)
 a.update(position=i,app=app,terminal=rows[-1],completed=rows[-1][4]==0,periods={})
 for g in a['grants']:
  o=g['owner'];k=str(o)+'-'+str(oracle(app)[g['slot']]['alloc'][o][3])
  a['periods'].setdefault(k,[]).append([g['slot'],g['upper'],g['allocation_upper']])
 out.append(a);print(i,a['terminal'],len(a['grants']),a['violations'])
(p/'sealed.json').write_text(json.dumps(out,indent=2))
