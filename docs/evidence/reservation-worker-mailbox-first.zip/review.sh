set -eu
cd /mnt/d/codex/mail201-a667
while [ ! -f pos8-verified.json ]; do sleep 2; done
qemu-system-aarch64 --version > qemu.txt
for script in layout identity sections linked score direct official; do /usr/bin/python3 "$script.py"; done
