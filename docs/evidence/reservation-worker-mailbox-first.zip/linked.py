from pathlib import Path
import re,json
p=Path(__file__).parent;out={}
for c in sorted(p.glob('candidate-*.symbols')):
 b=p/c.name.replace('candidate-','parent-');app=c.stem[10:]
 def metrics(f):
  sym=f.read_text().splitlines()
  def size(name):
   row=next((line for line in sym if line.endswith(name) or (name=='4idle17' and name in line)),None)
   return int(row.split()[1],16) if row else 0
  return {k:size(k) for k in ('::irq','4idle17','::Runtime::close','::WITNESS','::Runtime::validate_first_frame','::Runtime::ledger_at','reservation_rust_work')}
 out[app]=dict(candidate=metrics(c),base=metrics(b))
(p/'linked-metrics.json').write_text(json.dumps(out,indent=2))
