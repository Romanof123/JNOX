from pathlib import Path
import json
p=Path(__file__).parent
def load(name): return json.loads((p/(name+'.json')).read_text())
s=load('sealed'); d=load('direct'); l=load('layouts'); fields=load('sections'); metrics=load('linked-metrics')
success=sum(r['completed'] for r in s);grants=sum(len(r['grants']) for r in s)
lines=['# Reservation worker mailbox / 예약 작업자 메일박스 검증','',f'**{success}/8 first boots completed the full scheduling horizon. / 최초 부팅 8건 중 {success}건이 전체 스케줄을 완료했다.** Required 8/8. Inclusive dispatch bound remains 62,500 ticks (1 ms at 62.5 MHz). / 통과 기준은 8/8이며 개시 상한은 1 ms 그대로다.','','Candidate a667736b639ef9cbe156d9d9978f40a15cadbb91, prospective plan b16ee652fc8e4633ec7563eeaff89d9f4546fe29, technical base a4d2f340020f7e8666d04a113040207805bbfc9a. Fresh locked Windows Rust 1.95 single-job builds. Eight serial Ubuntu ext4 QEMU 6.2 Cortex-A72 TCG guests with original physical timer and timeout. / 윈도우 단일 작업 빌드 후 WSL ext4에서 정해진 순서로 최초 8회 실행했다.','','|Pos|App|Trace|Terminal slot/status/reason|Mask|Worker−epoch|Returned grants|First charge|','|---:|---|---|---|---:|---:|---:|---:|']
for a,b in zip(s,d):
 z=a['terminal']; tag='/'.join(str(z[i]) for i in (2,4,5));lines.append(f"|{a['position']}|{a['app']}|{a['position'] in (2,3,5,8)}|{tag}|{a['flags']}|{a.get('first_offset','—')}|{len(a['grants'])}|{b['first_charge'][0][2] if b['first_charge'] else '—'}|")
lines+=['','## First-grant intervals in counter ticks / 최초 승인 구간별 카운터 틱','','|Pos|Epoch→IRQ|IRQ→source end|Source end→before|Before→post|Post→armed|Armed→selection|Selection→pre-ERET|Pre-ERET→worker|','|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
keys='irq_offset source_reads source_end_to_pre commit_duration commit_to_arm arm_to_selection selection_to_preeret return_to_marker'.split()
for a in s:lines.append('|'+str(a['position'])+'|'+'|'.join(str(a.get(k,'—')) for k in keys)+'|')
lines+=['','Technical-base position 1 intervals were 25410, 6970, 16956, 3142, 6856, 3018, 2260, 3781 ticks; position 5 intervals were 24540, 6518, 12044, 2580, 4695, 1669, 1973, 2665. These historical samples come from the prospective plan. / 기준 빌드의 1·5번 구간은 사전 계획서의 기록이다. 조건별 1회 관측이므로 배치 변경의 실행 시간 효과를 분리할 수 없다.','',f'{grants} measured grants joined to their saved return, ordered Rust marker, physical cutoff or SVC trap, progress count/checksum, elapsed charge and cumulative owner/deadline allocation. Full horizons include wake/recovery and retirement checks. Traced positions also compare QEMU exceptions/ERET. Raw terminal operands, per-grant bounds, period ledgers and trace joins are in sealed.json. / 실측 승인 {grants}건의 실제 복귀·Rust 표지·선점 또는 SVC·진행값·기한별 누적 과금을 확인했다. 종료 및 복구 관측은 원본 UART와 sealed.json에 있다.','','## Linked layout / 연결 바이너리 배치','','|App|Base validator bytes|New validator bytes|Base worker bytes|New worker bytes|Mailbox base address|Data section bytes, base→new|','|---|---:|---:|---:|---:|---:|---|']
for app,m in metrics.items():
 mb=fields['candidate-'+app]['fields']['MAILBOXES']; sec=mb['section']; a=fields['parent-'+app]['sections'][sec]['size'];b=fields['candidate-'+app]['sections'][sec]['size']
 lines.append(f"|{app}|{m['base']['::Runtime::validate_first_frame']}|{m['candidate']['::Runtime::validate_first_frame']}|{m['base']['reservation_rust_work']}|{m['candidate']['reservation_rust_work']}|{mb['address']:#x}|{a}→{b}|")
lines+=['','In all four candidate images, two 40-byte worker records initialize generation/action/goal/first/progress at offsets 0/8/16/24/32 to MAX/0/MAX/0/null. Source access ordering preserves release goal, relaxed action/reset and release generation, acquire worker generation, release marker, acquire pointer and null check before snapshot. Candidate and base disassembly, symbols and allocated-section SHA-256 are included. / 네 바이너리에서 작업자당 40바이트의 5개 개별 원자값과 초기값, 게시 순서 및 스냅샷 널 검사를 확인했다.','','## Legacy controls / 기존 대조군','']
for app in ('periodic-bench','aperiodic-bench','cbs-bench','cbs-wake-bench'):
 ca=l['candidate-'+app];ba=l['parent-'+app];assert ca['entry']==ba['entry'] and ca['loads']==ba['loads']
 lines.append(f'- {app} matched entry and every PT_LOAD header and byte. / 진입점 및 모든 적재 세그먼트 일치.')
lines+=['','0/4 changed loads triggered a legacy control boot. / 적재 내용이 바뀐 벤치는 0/4종이었다.']
(p/'report.en-ko.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
