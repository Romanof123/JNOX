import subprocess as s,sys,pathlib as p,zipfile,hashlib,re,collections,tempfile
out=p.Path(__file__).parent
root=p.Path(sys.argv[1]).resolve()
py=sys.executable
cli='tools/qualify_ordinary_mutex.py'
def run(cmd):
 r=s.run(cmd,cwd=root,capture_output=True,text=True,encoding='utf8',errors='replace')
 print('COMMAND',*cmd,'EXIT',r.returncode);print(r.stdout[-2500:],r.stderr[-1000:]);return r
data=[]
with tempfile.TemporaryDirectory() as td:
 td=p.Path(td); paths=[]
 for i,f in enumerate(('first','integration')):
  ref='317d7365:docs/evidence/ordinary-timed-chain-'+f+'.zip'
  blob=s.check_output(['git','show',ref],cwd=root)
  path=td/(f+'.zip');path.write_bytes(blob);paths.append(str(path)); print(f,hashlib.sha256(blob).hexdigest())
  result=run([py,cli,str(path)]); labels=['PI/plain','PI/traced','ceiling/plain','ceiling/traced']; assert result.returncode==i and result.stdout.splitlines()==[label+(' UNQUALIFIED reason=16' if i and label.endswith('traced') else ' QUALIFIED') for label in labels]+[f'qualified={4-2*i}/4']
  with zipfile.ZipFile(path) as z:
   files={n:z.read(n) for n in z.namelist() if n.startswith(('ordinary-pi/','ordinary-ceiling/')) and n.endswith(('plain.uart','trace.uart','exceptions.log'))}; data.append(files)
   for protocol in ('pi','ceiling'):
    for mode in ('plain','trace'):
     base='ordinary-'+protocol+'/'
     rows=collections.defaultdict(list)
     for line in files[base+mode+'.uart'].decode().splitlines()[3:-1]:
      k,*v=line.split();rows[k].append([int(a,16) for a in v])
     irq,=[e for e in rows['E'] if e[2]==5]
     if mode=='trace':
      tr=files[base+'exceptions.log'].decode()
      assert [int(v,16) for v in re.findall(r'with ELR 0x([0-9a-f]+)',tr)]==[e[7] for e in rows['E']]
      assert [int(v,16) for v in re.findall(r'Exception return .*?PC 0x([0-9a-f]+)',tr)]==[r[1] for r in rows['R']]
     print(protocol,mode,'reason',rows['H'][0][1],'IRQ PC',hex(irq[7]),'completed chunks',irq[20],'work flag',irq[21],'last C',rows['C'][-1:],'HIGH',rows['HIGH'])
 assert run([py,'tools/qualify_ordinary_mutex_regression.py',*paths]).returncode==0
 for cmd in ([py,'-B','-m','unittest','discover','-s','tools','-p','test_mutex_anchor_replay.py'],[py,'-B','-m','unittest','discover','-s','tools','-p','test_requirement_graph.py'],[py,'tools/requirement_graph.py']):
  assert run(cmd).returncode==0
 assert run([py,cli,'docs/evidence/ordinary-amc-first.zip']).returncode==2
 def control(name,files):
  path=td/(name+'.zip')
  with zipfile.ZipFile(path,'w') as z:
   for n,b in files.items():z.writestr(n,b)
   z.writestr('SHA256SUMS','\n'.join(hashlib.sha256(b).hexdigest()+'  '+n for n,b in files.items()))
  return run([py,cli,str(path)])
 files=data[1].copy(); key='ordinary-pi/trace.uart'
 original=files[key]; committed=next(l for l in data[0][key].splitlines() if l.startswith(b'HIGH '))
 files[key]=re.sub(rb'(?m)^HIGH [^\r\n]+',committed,original)
 result=control('inconsistent-archived-summary',files)
 print('expected invalid for completed HIGH snapshot before work; observed',result.returncode)
 assert result.returncode==2 and result.stdout==''; files=data[1].copy(); del files['ordinary-ceiling/trace.uart'];assert control('missing-uart',files).returncode==2
 for tag in (b'B',b'A',b'M',b'K'):
  files=data[1].copy(); key='ordinary-ceiling/trace.uart'
  row=next(l for l in data[0][key].splitlines() if l.startswith(tag+b' '))
  files[key]=re.sub(rb'(?m)^'+tag+rb' [^\r\n]+',row,files[key])
  result=control('mixed-'+tag.decode(),files)
  assert result.returncode==2 and result.stdout==''
 files=data[1].copy(); key='ordinary-ceiling/trace.uart'
 lines=files[key].decode().splitlines()
 marker=int([l for l in lines if l.startswith('R ')][-1].split()[3],16)
 partial=[]
 for l in lines:
  fields=l.split()
  if fields[0]=='H': fields[5]=f'{128:016x}'
  if fields[0]=='E' and int(fields[3],16)==5: fields[21:23]=[f'{128:016x}',f'{1:016x}']
  if fields[0]=='K': fields[1]=f'{marker:016x}'
  if fields[0]=='B': partial.extend(f'C {256*k:016x} {2176*k:016x}' for k in range(1,129))
  partial.append(' '.join(fields))
 files[key]=('\n'.join(partial)+'\n').encode(); result=control('constructed-midpoint',files)
 assert result.returncode==1 and 'ceiling/traced UNQUALIFIED reason=16' in result.stdout and 'qualified=2/4' in result.stdout
 files[key]=re.sub(rb'(?m)^B [^\r\n]+',next(l for l in data[0][key].splitlines() if l.startswith(b'B ')),files[key])
 result=control('constructed-midpoint-premature-batch',files); assert result.returncode==2 and result.stdout==''
