"""Score one immutable native permit capture, entirely offline."""
import argparse
import json
import struct
import zlib
from pathlib import Path

from decode import read_run

HZ = 62_500_000
AGAIN = 2**64 - 11


def evaluate(a):
    checks = dict(a["provenance"])
    events = a["events"]
    def rows(kind):
        return [v for v in events if v[0] == kind]
    def calls(prefix):
        return [v for v in rows(5) if v[2:2+len(prefix)] == prefix]
    def require(name, condition):
        checks[name] = bool(condition)

    case = a["case"]
    if case not in ("rearm-15", "rearm-20"):
        raise ValueError("unexpected selector " + case)
    ms = int(case[-2:])
    observer = a["manifest"].get("safety_boundary") or {}
    observed = bool(observer)
    if observed:
        require("observer schema and selector",observer.get("scenario")==case and observer.get("rearm_eligibility_event")==15)
    issued = a["received_rows"][:2]
    require("complete safety journal", a["safety_loss"] == [[0]] and all(len(v)==10 for v in events))
    require("cold low output and original frequency",len(rows(1))==1 and rows(1)[0][2]==HZ and rows(1)[0][4]==0)
    require("agreeing process clocks", all(a[k+"_header"][2:4]==a["receiver_header"][2:4] for k in ("sender","supervisor")) and a["receiver_header"][3]==HZ)
    require("two successful private accepts",len(issued)==2 and all(v[5:7]==[0,0] for v in issued))
    require("frozen source", a["revision"]=="047184a4c13ecc3f9bc74c4f94a04658e2b3ccc6")
    require("private selectors and app completion", a["exits"]==[[0,71],[1,72],[2,73]] and a["sender_header"][4:]==[0] and a["receiver_header"][4:]==a["supervisor_header"][4:]==[0,0] and all(a[k+"_header"][1]==(35 if ms==15 else 36) for k in ("sender","receiver","supervisor")) and all(v[15]==1 for v in a["supervisor_rows"]))
    first, second = [v[17] for v in issued]
    require("scheduled 10 ms pair",first == a["receiver_header"][2] and second-first == 625000)
    target = first + ms*62500
    planned,lead,wake,actual = a["rearm_launch"]
    require("private recorded target and wake",planned==target and wake==planned-lead and actual>=wake and 0<=lead<=12500)
    require("recorded lead matches packaged supervisor argument",lead==int(a["manifest"]["slots"][2]["argv"][2]))
    argv=a["launch_argv"]
    engineering="-icount" in argv
    require("single CPU and documented timing mode", a["stock_launch"] or engineering and argv[1:-4]==["-machine","virt,gic-version=2","-cpu","cortex-a72","-smp","1","-accel","tcg,thread=single","-icount","shift=0,align=off,sleep=off","-m","128M","-nodefaults","-display","none","-monitor","none","-no-reboot","-qmp","stdio"])
    private = [v for v in a["supervisor_rows"] if v[3]==2]
    command, = calls([2,59,2])
    generation = command[6]
    require("open gate in fresh generation",len(calls([2,59,1,0]))==1 and calls([2,59,1,0])[0][6]==generation and calls([2,59,1,0])[0][1]<issued[0][7] and not any(v[1]<command[1] for v in rows(4)))
    commits = [v for v in calls([1,60,2,0]) if v[1]<command[1]]
    require("two protected commits preceding first command",len(commits)==2)
    for idx,(v,k) in enumerate(zip(issued,commits),1):
        raw = bytes.fromhex(a["received_bytes"][idx-1])
        wire = struct.unpack("<BBHHHQQQIB3sI",raw)
        require(f"valid private and sender bytes {idx}",wire==(1,1,44,1,257,generation,idx,v[17],20,1,bytes(3),zlib.crc32(raw[:40])) and any(w[8]==v[2] and w[9:]==[0,0] and h==raw.hex() for w,h in zip(a["sender_rows"],a["sender_bytes"])))
        handle = v[2]
        rx = [z for z in rows(7) if z[2]==handle]
        pubs = [z for z in rows(11) if z[4:7]==[handle,0,1]]
        acquire = [z for z in rows(6) if z[2:5]==[1,35,0] and z[7:9]==[handle,44]]
        release = [z for z in rows(6) if z[2:5]==[1,36,0] and z[6]==handle]
        require(f"protected loan snapshot matches both private copies {idx}",len(rx)==len(pubs)==len(acquire)==len(release)==1 and b"".join(word.to_bytes(8,"little") for word in rx[0][4:])[:44]==raw and pubs[0][3]<=rx[0][1]<=acquire[0][1]<=release[0][1]<=v[7])
        require(f"protected accepted commit {idx}",k[6:]==[generation,idx,v[17],idx] and v[7]<=k[1]<=v[8] and v[18]==1)
    require("supervisor private command return", len(private)==1 and private[0][6]==2**63 and private[0][1]<=command[1]<=private[0][2] and private[0][5]==command[5] and private[0][4]==generation)
    accepted = command[5]==0
    require("first command result",command[5] in (0,AGAIN) and command[7:]==[2,second,2])
    require("private gate open, output low, and pending result",len(private)==1 and private[0][7]&15==1 and private[0][8]&15==(9 if accepted else 1))
    require("no earlier output rise",not any(v[5]==1 and v[2]<command[1] for v in rows(2)))
    sup = [v for v in rows(15) if v[3]==2]
    ctl = [v for v in rows(15) if v[3]==1]
    operand = sup[0][2] if len(sup)==1 else None
    if observed:
        require("authenticated supervisor eligibility operand",len(sup)==1 and sup[0][4:]==[generation,first,second,2,0,int(accepted)] and private[0][1]<=operand<=sup[0][1]<=command[1])
        require("result follows real first-pair freshness",operand is not None and accepted==(second<=operand<first+1250000))
    rises = [v for v in rows(2) if v[4:6]==[0,1]]
    consumed = calls([1,60,4,0])
    expired_queued = accepted and ms==20 and operand is not None and operand < first+1250000 and not consumed
    if expired_queued:
        checks_after = [v for v in rows(12) if v[2]>=command[1] and v[4:7]==[generation,2,second]]
        activations = [v for v in a["activations"] if v[2]>=command[1]]
        require("accepted pending then expired before controller service",bool(checks_after and activations) and checks_after[0][2]>=first+1250000 and activations[0][2]>=first+1250000 and activations[0][5]&10==0 and not ctl and not calls([1,60,4]))
        require("no transient output or retained pending",not rows(2) and a["terminal"]==0 and all((v[5]|v[11])&10==0 for v in activations))
    elif accepted:
        require("consumption and protected rise", len(consumed)==len(rises)==1 and command[1]<=rises[0][2]<=rises[0][3]<=consumed[0][1] and consumed[0][6:]==[generation,2,second,2])
        require("independent enabled private readback",any(v[8]&2 for v in a["supervisor_rows"]) or any(v[10]&2 for v in a["received_rows"]))
        if observed:
            require("controller consumes pending fresh pair", len(ctl)==1 and ctl[0][4:]==[generation,first,second,2,1,1] and command[1]<=ctl[0][2]<first+1250000 and ctl[0][2]<=rises[0][2])
    else:
        require("no consumption and protected output remains low", not rises and not consumed and all((v[7]|v[8])&8==0 for v in private) and a["terminal"]==0 and all(not(v[8]&2) for v in a["supervisor_rows"]))
        if observed:
            require("no controller eligibility without pending command",not ctl)
    completions = rows(10)
    require("all activation completion brackets",len(completions)==len(a["activations"])==17 and all(v[2]<=v[3] and v[4]==0 for v in completions))
    gaps = [(b[2]-x[3],b[3]-x[2]) for x,b in zip(completions,completions[1:])]
    response = [(e[2]-act[0],e[3]-act[0]) for act,e in zip(a["activations"],completions)]
    timing = {key:[max(x[i] for x in vals) for i in (0,1)] for key,vals in (("gap",gaps),("response",response))}
    deviation = None if operand is None else operand-target
    return dict(timing_ticks=timing,expired_queued=expired_queued,safety_dropped=a["safety_loss"][0][0],kernel_sha256=a["kernel"],app_sha256=a["app_hashes"],session_sha256=a["session_hash"],supervisor_evidence=sup,controller_evidence=ctl,supervisor_return=command,output_transitions=rows(2),private_command=private[0],generation=generation,issues=[first,second],case=case,clock="count0" if engineering else "default",policy=a["policy"],source=a["revision"],operand=operand,attempted=private[0][0],target=target,attempted_deviation=private[0][0]-target,operand_deviation=deviation,accepted=accepted,lead=lead,wake=wake,actual_wake=actual,checks=checks,exact=all(checks.values()) and deviation==0 and accepted==(ms==15))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("packet",type=Path)
    parser.add_argument("run",type=Path)
    args=parser.parse_args()
    result=evaluate(read_run(args.packet,args.run))
    print(json.dumps(result,indent=2))
    raise SystemExit(int(not all(result["checks"].values())))







