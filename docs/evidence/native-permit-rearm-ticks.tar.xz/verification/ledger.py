"""Verify every recorded attempt, including failures, in the original order."""
import csv
import subprocess
import json
import sys
from pathlib import Path

from decode import read_run
from replay import evaluate


def replay_ledger(root):
    with (root/"ledger.tsv").open() as stream:
        entries = list(csv.DictReader(stream,delimiter="\t"))
    result = []
    for ordinal,entry in enumerate(entries,1):
        run = root/"runs"/entry["attempt"]
        if int(entry["n"])!=ordinal or not run.is_dir():
            raise ValueError("ledger order or directory mismatch")
        result_row = dict(entry)
        if entry["build_rc"]!="0":
            result_row.update(status="build failed before guest",verified=False,exact=False)
            result.append(result_row)
            continue
        try:
            outcome = evaluate(read_run(root,run))
            result_row.update(outcome)
            revision_match=entry.get("revision")==outcome["source"]==(run/"revision").read_text().strip()
            outcome["checks"]["recorded source revision"]=revision_match
            matching = (entry["clock"],entry["policy"],entry["case"],int(entry["lead_ticks"])) == (outcome["clock"],outcome["policy"],outcome["case"],outcome["lead"])
            result_row["checks"]["ledger fields match actual capture"] = matching
            result_row["verified"] = matching and all(outcome["checks"].values()) and entry["capture_rc"]==entry["build_rc"]=="0"
            result_row["exact"] &= result_row["verified"]
        except (OSError,IndexError,KeyError,ValueError,subprocess.CalledProcessError) as error:
            result_row.update(error=str(error),verified=False,exact=False)
        result.append(result_row)
    return result


if __name__=="__main__":
    rows = replay_ledger(Path(sys.argv[1]))
    print(json.dumps(rows,indent=2))
    expected_failure = (bool(rows) and rows[0]["n"]=="1" and rows[0]["build_rc"]=="1" and rows[0]["capture_rc"]=="NA"
                        and rows[0].get("revision")=="6fbb5033c4f110b7a9941e4a74a1ea82e4e94fff")
    complete = len(rows)==25 and expected_failure and all(r["verified"] for r in rows[1:])
    if complete:
        for policy in ("fifo","rr"):
            for case in ("rearm-15","rearm-20"):
                samples=[r for r in rows if r["policy"]==policy and r["case"]==case and r["exact"]]
                complete &= len(samples)==3 and len({r["kernel_sha256"] for r in samples})==1 and len({r["session_sha256"] for r in samples})==3
    sys.exit(int(not complete))


