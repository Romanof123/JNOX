# Native REARM observations / 네이티브 재무장 관측

Independent raw replay verified all 24 completed boots. All twelve counted-clock equality samples met their respective decision and output criteria (three cold boots at each of four FIFO/RR positions). All eight original guest captures were late. Both one-tick-early commands queued, then expired before controller service. Both one-tick-late commands were refused. The normal-clock runs provide no exact sample or worst-case timing bound.

독립 재검증에서 완료된 24회 부팅 모두 통과했다. 명령 수 기반 클록의 네 조건에서 각각 세 번씩 정확히 일치했다. 원래의 게스트 캡처 8회는 모두 늦었다. 두 정책에서 1틱 이른 명령은 대기 후 제어기 처리 전에 만료됐고, 1틱 늦은 명령은 거부됐다. 기본 클록에서 정확한 일치나 최악 시간 한계는 관측되지 않았다.

From the extracted packet root, run `PYTHONDONTWRITEBYTECODE=1 python3 verification/ledger.py . > replay.json`, then `cmp replay.json verification/ledger.json`. The reader requires Python 3 and GNU aarch64-linux-gnu-nm on PATH. It reads each original private memory space via its saved page tables and checks receipt, guest and package hashes.

Each ordinal is an original build or capture attempt. Timing deviation is the authenticated supervisor eligibility operand minus the nominal target, in 62.5 MHz counter ticks (16 ns each). A blank operand means the capture does not establish a decision time.

각 번호는 최초 기록 순서대로 보존한 빌드 또는 캡처 시도이다. 편차는 인증된 감독자의 실제 판정 시각에서 목표 시각을 뺀 값이다. 62.5 MHz에서 1틱은 16 ns이며, 빈 칸은 판정 시각의 근거가 없음을 뜻한다.

Original packaging refusal: local `6fbb5033c4f110b7a9941e4a74a1ea82e4e94fff`, public `732a7368cdeccfe520ceaf43ec794f5648ef0cbe`, tree `8c052aa494698fce5d0b2b69e3f6eecf3b8fb3ca`. The kernel build rejected the selectors before any guest boot.

Corrected guest source: local `047184a4c13ecc3f9bc74c4f94a04658e2b3ccc6`, public `15ec61c5acca83a4db251eee37bc5d560ec5b360`, tree `5c8ec0db0e4d146d4e2f36c13fbc322e6cc87f08`. 첫 번째 빌드에서 커널이 시나리오 인자를 거부했다. 해당 시도에는 게스트 관측값이 없다. 수정본에서는 커널 빌드의 인자 검사를 갱신했다.

| # | Clock | Policy | Case | Lead | Target | Operand | Δ ticks | Result / 결과 |
|---:|---|---|---|---:|---:|---:|---:|---|
| 1 | default | fifo | rearm-15 | 0 |  |  |  | Build failed / 빌드 실패 |
| 2 | default | fifo | rearm-15 | 0 | 4654683 | 4666055 | 11372 | Accepted / 수락 |
| 3 | default | fifo | rearm-20 | 0 | 5027895 | 5041562 | 13667 | Refused / 거부 |
| 4 | default | rr | rearm-15 | 0 | 4676529 | 4686225 | 9696 | Accepted / 수락 |
| 5 | default | rr | rearm-20 | 0 | 5021281 | 5035386 | 14105 | Refused / 거부 |
| 6 | count0 | fifo | rearm-15 | 0 | 4480861 | 4481097 | 236 | Accepted / 수락 |
| 7 | count0 | fifo | rearm-20 | 0 | 4793361 | 4793600 | 239 | Refused / 거부 |
| 8 | count0 | rr | rearm-15 | 0 | 4480877 | 4481124 | 247 | Accepted / 수락 |
| 9 | count0 | rr | rearm-20 | 0 | 4793377 | 4793627 | 250 | Refused / 거부 |
| 10 | count0 | fifo | rearm-15 | 236 | 4480861 | 4480861 | 0 | Accepted / 수락 (exact / 일치) |
| 11 | count0 | fifo | rearm-20 | 239 | 4793361 | 4793361 | 0 | Refused / 거부 (exact / 일치) |
| 12 | count0 | rr | rearm-15 | 247 | 4480877 | 4480877 | 0 | Accepted / 수락 (exact / 일치) |
| 13 | count0 | rr | rearm-20 | 250 | 4793377 | 4793377 | 0 | Refused / 거부 (exact / 일치) |
| 14 | count0 | rr | rearm-20 | 250 | 4793377 | 4793377 | 0 | Refused / 거부 (exact / 일치) |
| 15 | count0 | rr | rearm-15 | 247 | 4480877 | 4480877 | 0 | Accepted / 수락 (exact / 일치) |
| 16 | count0 | fifo | rearm-20 | 239 | 4793361 | 4793361 | 0 | Refused / 거부 (exact / 일치) |
| 17 | count0 | fifo | rearm-15 | 236 | 4480861 | 4480861 | 0 | Accepted / 수락 (exact / 일치) |
| 18 | count0 | fifo | rearm-15 | 236 | 4480861 | 4480861 | 0 | Accepted / 수락 (exact / 일치) |
| 19 | count0 | fifo | rearm-20 | 239 | 4793361 | 4793361 | 0 | Refused / 거부 (exact / 일치) |
| 20 | count0 | rr | rearm-15 | 247 | 4480877 | 4480877 | 0 | Accepted / 수락 (exact / 일치) |
| 21 | count0 | rr | rearm-20 | 250 | 4793377 | 4793377 | 0 | Refused / 거부 (exact / 일치) |
| 22 | count0 | fifo | rearm-20 | 240 | 4793361 | 4793360 | -1 | Queued, expired, output low / 대기 후 만료·출력 꺼짐 |
| 23 | count0 | fifo | rearm-20 | 238 | 4793361 | 4793362 | 1 | Refused / 거부 |
| 24 | count0 | rr | rearm-20 | 251 | 4793377 | 4793376 | -1 | Queued, expired, output low / 대기 후 만료·출력 꺼짐 |
| 25 | count0 | rr | rearm-20 | 249 | 4793377 | 4793378 | 1 | Refused / 거부 |

The positive path requires two CRC-valid accepted set permits, supervisor acceptance, controller consumption and a protected ENABLE rise with readback. The negative path requires refusal, a clear pending bit and sustained low output. Event 15 supplies the original operand. Default-clock observations and instruction-counted observations are scored separately.

수락 판정에는 CRC가 유효한 두 허가의 커밋, 감독자의 수락, 제어기의 명령 소비 및 보호된 출력 상승과 읽기 확인이 필요하다. 거부 판정에는 명령 거부, 대기 비트 해제 및 낮은 출력 유지가 필요하다. 이벤트 15가 원본 시각을 제공한다. 기본 클록과 명령 수 기반 클록의 관측은 별도로 판정한다.

The complete predicate results are in `ledger.json`.

## Completion timing / 완료 시각

Event 10 brackets the completion call. For successive brackets [a,b] and [c,d], the gap lies in [c−b,d−a]. Response is measured from scheduled activation release to the completion bracket. Values below are maxima across captured runs. A lower bound above 5 ms conclusively misses the completion-gap requirement. Equality results do not qualify overall timing.

이벤트 10의 완료 호출 구간으로 연속 완료 사이의 보수적 하한과 상한을 계산했다. 응답 시간은 예정된 활성화 시각부터 완료 구간까지다. 하한이 5 ms를 넘으면 완료 간격 조건에 실패한다. 경계값 일치와 전체 프로파일의 타이밍 통과 여부는 별도 결과다.

|Clock|Boots with gap lower bound > 5 ms|Maximum gap lower–upper (ms)|Maximum release-to-COMPLETE lower–upper (ms)|
|---|---:|---:|---:|
|default|4/4|5.259616–5.262096|2.763248–2.808272|
|count0|20/20|5.012464–5.013008|0.021840–0.022096|
