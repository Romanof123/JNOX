"""Render the ledger's measured distinctions in English and Korean."""
import json
import sys
from pathlib import Path


def report(rows):
    lines = [
        "# Native REARM observations / 네이티브 재무장 관측",
        "",
        "Independent raw replay verified all 24 completed boots. All twelve counted-clock equality samples met their respective decision and output criteria (three cold boots at each of four FIFO/RR positions). All eight original guest captures were late. Both one-tick-early commands queued, then expired before controller service. Both one-tick-late commands were refused. The normal-clock runs provide no exact sample or worst-case timing bound.",
        "",
        "독립 재검증에서 완료된 24회 부팅 모두 통과했다. 명령 수 기반 클록의 네 조건에서 각각 세 번씩 정확히 일치했다. 원래의 게스트 캡처 8회는 모두 늦었다. 두 정책에서 1틱 이른 명령은 대기 후 제어기 처리 전에 만료됐고, 1틱 늦은 명령은 거부됐다. 기본 클록에서 정확한 일치나 최악 시간 한계는 관측되지 않았다.",
        "",
        "From the extracted packet root, run `PYTHONDONTWRITEBYTECODE=1 python3 verification/ledger.py . > replay.json`, then `cmp replay.json verification/ledger.json`. The reader requires Python 3 and GNU aarch64-linux-gnu-nm on PATH. It reads each original private memory space via its saved page tables and checks receipt, guest and package hashes.",
        "",
        "Each ordinal is an original build or capture attempt. Timing deviation is the authenticated supervisor eligibility operand minus the nominal target, in 62.5 MHz counter ticks (16 ns each). A blank operand means the capture does not establish a decision time.",
        "",
        "각 번호는 최초 기록 순서대로 보존한 빌드 또는 캡처 시도이다. 편차는 인증된 감독자의 실제 판정 시각에서 목표 시각을 뺀 값이다. 62.5 MHz에서 1틱은 16 ns이며, 빈 칸은 판정 시각의 근거가 없음을 뜻한다.",
        "",
        "Original packaging refusal: local `6fbb5033c4f110b7a9941e4a74a1ea82e4e94fff`, public `732a7368cdeccfe520ceaf43ec794f5648ef0cbe`, tree `8c052aa494698fce5d0b2b69e3f6eecf3b8fb3ca`. The kernel build rejected the selectors before any guest boot.",
        "",
        "Corrected guest source: local `047184a4c13ecc3f9bc74c4f94a04658e2b3ccc6`, public `15ec61c5acca83a4db251eee37bc5d560ec5b360`, tree `5c8ec0db0e4d146d4e2f36c13fbc322e6cc87f08`. 첫 번째 빌드에서 커널이 시나리오 인자를 거부했다. 해당 시도에는 게스트 관측값이 없다. 수정본에서는 커널 빌드의 인자 검사를 갱신했다.",
        "",
        "| # | Clock | Policy | Case | Lead | Target | Operand | Δ ticks | Result / 결과 |",
        "|---:|---|---|---|---:|---:|---:|---:|---|",
    ]
    for v in rows:
        if v["build_rc"]!="0":
            outcome="Build failed / 빌드 실패"
        elif not v.get("verified"):
            outcome="Incomplete evidence / 관측 미확인"
        else:
            outcome = "Accepted / 수락" if v["accepted"] else "Refused / 거부"
            if v.get("expired_queued"):
                outcome = "Queued, expired, output low / 대기 후 만료·출력 꺼짐"
            if v.get("exact"):
                outcome+=" (exact / 일치)"
        fields=[v["n"],v["clock"],v["policy"],v["case"],v["lead_ticks"],v.get("target",""),v.get("operand",""),v.get("operand_deviation",""),outcome]
        lines.append("| "+" | ".join(str(x) if x is not None else "" for x in fields)+" |")
    lines.extend(["","The positive path requires two CRC-valid accepted set permits, supervisor acceptance, controller consumption and a protected ENABLE rise with readback. The negative path requires refusal, a clear pending bit and sustained low output. Event 15 supplies the original operand. Default-clock observations and instruction-counted observations are scored separately.",
                  "","수락 판정에는 CRC가 유효한 두 허가의 커밋, 감독자의 수락, 제어기의 명령 소비 및 보호된 출력 상승과 읽기 확인이 필요하다. 거부 판정에는 명령 거부, 대기 비트 해제 및 낮은 출력 유지가 필요하다. 이벤트 15가 원본 시각을 제공한다. 기본 클록과 명령 수 기반 클록의 관측은 별도로 판정한다.",
                  "","The complete predicate results are in `ledger.json`."])
    lines.extend(["","## Completion timing / 완료 시각","","Event 10 brackets the completion call. For successive brackets [a,b] and [c,d], the gap lies in [c−b,d−a]. Response is measured from scheduled activation release to the completion bracket. Values below are maxima across captured runs. A lower bound above 5 ms conclusively misses the completion-gap requirement. Equality results do not qualify overall timing.","","이벤트 10의 완료 호출 구간으로 연속 완료 사이의 보수적 하한과 상한을 계산했다. 응답 시간은 예정된 활성화 시각부터 완료 구간까지다. 하한이 5 ms를 넘으면 완료 간격 조건에 실패한다. 경계값 일치와 전체 프로파일의 타이밍 통과 여부는 별도 결과다.","","|Clock|Boots with gap lower bound > 5 ms|Maximum gap lower–upper (ms)|Maximum release-to-COMPLETE lower–upper (ms)|","|---|---:|---:|---:|"])
    for mode in ("default","count0"):
        timings=[r["timing_ticks"] for r in rows if r.get("verified") and r["clock"]==mode]
        maximum=lambda k:"–".join(f"{max(t[k][i] for t in timings)/62500:.6f}" for i in (0,1))
        if timings:
            lines.append(f"|{mode}|{sum(t['gap'][0]>312500 for t in timings)}/{len(timings)}|{maximum('gap')}|{maximum('response')}|")
    return "\n".join(lines)+"\n"


if __name__=="__main__":
    print(report(json.loads(Path(sys.argv[1]).read_text())),end="")




