#!/usr/bin/env bash
set -euo pipefail
lab=${LAB_ROOT:-$HOME/permit11-rearm-runs}
shared=/mnt/d/codex/permit11-rearm-runs
dest="$lab/packet"
export PATH="$HOME/.cargo/bin:$PATH" LC_ALL=C TZ=UTC CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1
unset RUSTFLAGS CARGO_TARGET_DIR PYTHONPATH
for key in $(compgen -e JNOX_); do unset "$key"; done
action=$1
shift
if [[ $action == prepare ]]; then
    rev=$1
    [[ "$rev" =~ ^[0-9a-f]{40}$ && ! -e "$lab" ]]
    mkdir -p "$dest"/{scripts,apps,source,packages,runs,logs}
    cp "$shared"/{lane.sh,count0.py,operand.py} "$dest/scripts/"
    git init -q "$lab/src"
    realpath /mnt/d/codex/.jnox-work/policy-v1/.git/objects > "$lab/src/.git/objects/info/alternates"
    cd "$lab/src"
    git sparse-checkout init --cone
    areas=(arch boards examples kernel sdk services tools trace verification)
    git sparse-checkout set "${areas[@]}"
    git checkout -q --detach "$rev"
    [[ $(git rev-parse HEAD) = "$rev" && -z $(git status --short --untracked-files=no) ]]
    [[ $(git rev-parse HEAD^{tree}) = 8c052aa494698fce5d0b2b69e3f6eecf3b8fb3ca ]]
    git cat-file commit "$rev" > "$dest/source/$rev.commit"
    git rev-parse HEAD HEAD^{tree} > "$dest/source/revision"
    git ls-tree -r "$rev" > "$dest/source/tree.txt"
    git archive --format=tar "$rev" "${areas[@]}" > "$dest/source/production.tar"
    { date -u; uname -srm; rustc -Vv; cargo -V; clang --version; python3 -V; qemu-system-aarch64 --version; sha256sum "$(command -v qemu-system-aarch64)"; git --version; } > "$dest/logs/host.txt"
    for role in sender receiver supervisor; do
        (set -x; sh sdk/native-aarch64/build-rust.sh "examples/native-safety-channel/$role/Cargo.toml" "$dest/apps/$role.elf") > "$dest/logs/$role.build" 2>&1
    done
    (cd "$dest/apps" && sha256sum *.elf) > "$dest/apps/SHA256SUMS"
    printf 'n\tclock\tpolicy\tcase\tlead_ticks\tpackage\tbuild_rc\tcapture_rc\tattempt\n' > "$dest/ledger.tsv"
    echo "prepared $rev"
    exit
fi
[[ $action == run && $# == 4 ]]
policy=$1; fixture=$2; mode=$3; lead=$4
[[ $policy == fifo || $policy == rr ]]
[[ $fixture == rearm-15 || $fixture == rearm-20 ]]
[[ $mode == default || $mode == count0 ]]
[[ $lead =~ ^(0|[1-9][0-9]{0,4})$ ]] && (( lead <= 12500 )) || exit 76
cd "$lab/src"
rev=$(head -1 "$dest/source/revision")
[[ $(git rev-parse HEAD) == "$rev" && -z $(git status --short --untracked-files=no) ]]
exec 9>"$lab/serial.lock"
flock -x 9
n=$(wc -l < "$dest/ledger.tsv")
printf -v tag '%03d-%s-%s-%s-lead%d' "$n" "$mode" "$policy" "$fixture" "$lead"
run="$dest/runs/$tag"; mkdir "$run"
pkg="$dest/packages/$policy-$fixture-lead$lead"
date -u +%FT%T.%NZ > "$run/start.utc"
extra=()
[[ $policy != rr ]] || extra+=(--quantum-ticks 625000)
printf -v lead_arg "%05d" "$lead"
extra+=(--peer2-arg "$lead_arg")
brc=0
if [[ ! -f "$pkg/manifest.json" ]]; then
    (set -x; python3 tools/build_native_el0.py --out "$pkg" --board virt --policy "$policy" --elf "$dest/apps/sender.elf" --peer-elf "$dest/apps/receiver.elf" --peer-elf "$dest/apps/supervisor.elf" --arg "$fixture" --peer-arg "$fixture" --peer2-arg "$fixture" "${extra[@]}" --priority 7 --peer-priority 6 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel --safety-boundary) > "$run/build.log" 2>&1 || brc=$?
else
    echo "Reuse $pkg; same input ELF and manifest for this case, policy and lead" > "$run/build.log"
fi
caprc=NA
if [[ $brc == 0 ]]; then
    cp "$pkg/manifest.json" "$run/"
    wrapper=()
    [[ $mode != count0 ]] || wrapper=("$dest/scripts/count0.py")
    caprc=0
    (set -x; python3 "${wrapper[@]}" tools/native_el0_capture.py "$run/cap" "$pkg/kernel.elf" "$dest/apps/sender.elf" examples/native-safety-channel/sender/src/main.rs "$rev" --manifest "$pkg/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608) > "$run/capture.log" 2>&1 || caprc=$?
fi
date -u +%FT%T.%NZ > "$run/finish.utc"
echo "$brc" > "$run/build.status"
echo "$caprc" > "$run/capture.status"
echo "$rev" > "$run/revision"
printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$n" "$mode" "$policy" "$fixture" "$lead" "$(basename "$pkg")" "$brc" "$caprc" "$tag" "$rev" >> "$dest/ledger.tsv"
printf '%s brc=%s capture=%s\n' "$tag" "$brc" "$caprc"
if [[ $brc != 0 ]]; then tail -5 "$run/build.log"; exit 1; fi
if [[ -f "$run/cap/uart.bin" ]]; then python3 "$dest/scripts/operand.py" "$run"; fi
[[ $caprc = 0 ]]
