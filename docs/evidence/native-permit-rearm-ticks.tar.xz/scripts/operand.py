"""Report the observed supervisor operand from this single fixture capture."""
import json
from pathlib import Path
import sys
run = Path(sys.argv[1])
config = json.loads((run/'manifest.json').read_text())
fixture = config['safety_boundary']['scenario']
lines=(run/'cap/uart.bin').read_bytes().decode('ascii','replace').splitlines()
events=[list(map(int,x.split()[3:])) for x in lines if x.startswith('NATIVE SAFETY EVENT ')]
observed=[r for r in events if r[0]==15 and r[3]==2]
hz=[r[2] for r in events if r[0]==1]
if len(observed)!=1 or hz!=[62500000]:
    print(f"unscored: {len(observed)} PID2 eligibility rows; counter frequency {hz}");sys.exit(0)
r,=observed
target=r[5]+(15 if fixture=='rearm-15' else 20)*62500
result=dict(fixture=fixture,hz=hz[0],first_issue=r[5],second_issue=r[6],target=target,
    protected_operand=r[2],delta=r[2]-target,eligible=r[9],caller=r[3],gen=r[4],streak=r[7],pending=r[8],
    exits=[x for x in lines if x.startswith('NATIVE EL0 EXIT PID')])
(run/'operand.json').write_text(json.dumps(result,indent=1)+'\n')
print(f"delta={result['delta']:+d} eligible={r[9]} PID={r[3]} gen={r[4]} streak={r[7]} exits={result['exits']}")
