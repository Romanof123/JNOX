"""Bound successive real CHECK decisions and protected COMPLETE intervals per original boot."""
import csv,sys
from pathlib import Path
root=Path(sys.argv[1])
fields=['attempt','clock','policy','fixture','checks','max_check_gap_ticks','check_gaps_gt_5ms','completes','max_complete_gap_lower_ticks','max_complete_gap_upper_ticks','complete_gaps_definitely_gt_5ms','complete_gaps_straddling_5ms','safety_dropped','fixed_dropped']
w=csv.DictWriter(sys.stdout,fields,lineterminator='\n');w.writeheader()
for row in csv.DictReader((root/'ledger.tsv').open(),delimiter='\t'):
    if row['capture_rc']!='0':continue
    lines=(root/'runs'/row['attempt']/'cap/uart.bin').read_text().splitlines()
    events=[list(map(int,x.split()[3:])) for x in lines if x.startswith('NATIVE SAFETY EVENT ')]
    hz,=[r[2] for r in events if r[0]==1];assert hz==62500000;limit=hz//200
    ck=[r[2] for r in events if r[0]==12 and r[3]==1]
    cm=[(r[2],r[3]) for r in events if r[0]==10]
    assert len(ck)==len(cm)>1 and all(a<=b for a,b in cm)
    gaps=[b-a for a,b in zip(ck,ck[1:])]
    cgs=[(b[0]-a[1],b[1]-a[0]) for a,b in zip(cm,cm[1:])]
    d=lambda prefix: next(int(s.split()[-1]) for s in lines if s.startswith(prefix))
    w.writerow(dict(attempt=row['attempt'],clock=row['clock'],policy=row['policy'],fixture=row['case'],checks=len(ck),max_check_gap_ticks=max(gaps),check_gaps_gt_5ms=sum(g>limit for g in gaps),completes=len(cm),max_complete_gap_lower_ticks=max(x for x,y in cgs),max_complete_gap_upper_ticks=max(y for x,y in cgs),complete_gaps_definitely_gt_5ms=sum(x>limit for x,y in cgs),complete_gaps_straddling_5ms=sum(x<=limit<y for x,y in cgs),safety_dropped=d('NATIVE SAFETY DROPPED '),fixed_dropped=d('NATIVE FIXED DROPPED ')))
