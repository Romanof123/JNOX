#!/usr/bin/env bash
set -euo pipefail
lab=$HOME/permit11-rearm-runs
dest=$lab/packet
shared=/mnt/d/codex/permit11-rearm-runs
old=6fbb5033c4f110b7a9941e4a74a1ea82e4e94fff
new=$1; tree=$2; public=${3:-$new}
[[ $new =~ ^[a-f0-9]{40}$ && $tree =~ ^[a-f0-9]{40}$ && $public =~ ^[a-f0-9]{40}$ ]]
export PATH="$HOME/.cargo/bin:$PATH" LC_ALL=C TZ=UTC CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1
unset RUSTFLAGS CARGO_TARGET_DIR PYTHONPATH
for key in $(compgen -e JNOX_); do unset "$key"; done
cd "$lab/src"
[[ $(git rev-parse HEAD) = "$old" && $(git rev-parse "$new^{tree}") = "$tree" && $(git rev-parse "$public^{tree}") = "$tree" ]]
[[ $(wc -l < "$dest/ledger.tsv") = 2 ]]
if [[ ! -e "$dest/prelaunch-$old" ]]; then
 [[ -f "$dest/packages/fifo-rearm-15-lead0/build.log" ]]
mkdir "$dest/prelaunch-$old"
for f in source apps; do mv "$dest/$f" "$dest/prelaunch-$old/$f"; mkdir "$dest/$f"; done
mv "$dest/packages/fifo-rearm-15-lead0" "$dest/packages/failed-$old-fifo-rearm-15-lead0"
mv "$dest/scripts/lane.sh" "$dest/prelaunch-$old/lane.sh"
for role in sender receiver supervisor; do mv "$dest/logs/$role.build" "$dest/prelaunch-$old/$role.build"; done
fi
cp "$shared"/{lane.sh,refreeze.sh,first.sh} "$dest/scripts/"
git cat-file commit 732a7368cdeccfe520ceaf43ec794f5648ef0cbe > "$dest/prelaunch-$old/source/732a7368cdeccfe520ceaf43ec794f5648ef0cbe.commit"
git diff --exit-code "$old" 732a7368cdeccfe520ceaf43ec794f5648ef0cbe
git checkout -q --detach "$new"
[[ -z $(git status --short --untracked-files=no) ]]
for r in "$new" "$public"; do git cat-file commit "$r" > "$dest/source/$r.commit"; done
git rev-parse HEAD HEAD^{tree} > "$dest/source/revision"
git ls-tree -r HEAD > "$dest/source/tree.txt"
git archive --format=tar HEAD arch boards examples kernel sdk services tools trace verification > "$dest/source/production.tar"
git diff "$old" "$new" -- arch boards examples kernel sdk services tools trace verification > "$dest/source/correction.diff"
for role in sender receiver supervisor; do
    (set -x; sh sdk/native-aarch64/build-rust.sh "examples/native-safety-channel/$role/Cargo.toml" "$dest/apps/$role.elf") > "$dest/logs/$role.build" 2>&1
done
(cd "$dest/apps" && sha256sum *.elf) > "$dest/apps/SHA256SUMS"
cp "$dest/ledger.tsv" "$dest/prelaunch-$old/initial-ledger.tsv"
python3 - "$dest/ledger.tsv" "$old" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); old=sys.argv[2]; h,row=p.read_text().splitlines(); cols=row.split('\t')
cols[5]='failed-'+old+'-'+cols[5]; p.write_text(h+'\trevision\n'+'\t'.join(cols+[old])+'\n')
PY
echo "$old" > "$dest/runs/001-default-fifo-rearm-15-lead0/revision"
echo "Corrected freeze $new, tree $tree, public $public"
