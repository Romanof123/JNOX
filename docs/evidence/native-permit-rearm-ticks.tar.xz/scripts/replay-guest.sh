#!/usr/bin/env bash
set -euo pipefail
root=$(realpath "${1:-.}")
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
cd "$root"
export PYTHONDONTWRITEBYTECODE=1 LC_ALL=C
python3 verification/ledger.py . > "$tmp/ledger.json"
cmp "$tmp/ledger.json" verification/ledger.json
python3 verification/report.py "$tmp/ledger.json" > "$tmp/report.md"
cmp "$tmp/report.md" verification/REPORT.en-ko.md
python3 scripts/timing.py . > "$tmp/timing.csv"
cmp "$tmp/timing.csv" timing.csv
echo '25 attempts and all guest report, verification and timing bytes reproduced.'
