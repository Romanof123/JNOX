#!/usr/bin/env bash
set -euo pipefail
lane=/mnt/d/codex/permit11-rearm-runs/lane.sh
# Direct measurements from attempts 006–009, used only for their corresponding fixtures.
bash "$lane" run fifo rearm-15 count0 236
bash "$lane" run fifo rearm-20 count0 239
bash "$lane" run rr rearm-15 count0 247
bash "$lane" run rr rearm-20 count0 250
