#!/usr/bin/env bash
set -euo pipefail
lane=/mnt/d/codex/permit11-rearm-runs/lane.sh
# Two fresh QEMU processes per previously observed equality package.
bash "$lane" run rr rearm-20 count0 250
bash "$lane" run rr rearm-15 count0 247
bash "$lane" run fifo rearm-20 count0 239
bash "$lane" run fifo rearm-15 count0 236
bash /mnt/d/codex/permit11-rearm-runs/observed-leads.sh
# Fixed neighboring ticks only on these two 20 ms fixture builds.
bash "$lane" run fifo rearm-20 count0 240
bash "$lane" run fifo rearm-20 count0 238
bash "$lane" run rr rearm-20 count0 251
bash "$lane" run rr rearm-20 count0 249
