#!/usr/bin/env bash
set -euo pipefail
script=$(cd "$(dirname "$0")" && pwd)/lane.sh
for mode in default count0; do
    for policy in fifo rr; do
        for fixture in rearm-15 rearm-20; do
            bash "$script" run "$policy" "$fixture" "$mode" 0
        done
    done
done
