"""Fixed engineering clock for the two deadline fixtures; preserve stock capture/launch receipts."""
import json
from pathlib import Path
import runpy
import sys

tool = Path(sys.argv.pop(1)).resolve()
if tool.name != "native_el0_capture.py":
    raise SystemExit("expected the repository's ordinary capture script")
manifest = json.loads(Path(sys.argv[sys.argv.index("--manifest") + 1]).read_text())
if manifest.get("safety_boundary", {}).get("scenario") not in {"rearm-15", "rearm-20"}:
    raise SystemExit("requires a rearm boundary fixture")
sys.path.insert(0, str(tool.parent))
from ordinary_amc_capture import FLAGS
idx = FLAGS.index("-accel") + 1
assert FLAGS[idx] == "tcg" and "-icount" not in FLAGS and FLAGS[FLAGS.index("-smp") + 1] == "1"
FLAGS[idx:idx+1] = ["tcg,thread=single", "-icount", "shift=0,align=off,sleep=off"]
sys.argv[0] = str(tool)
runpy.run_path(str(tool), run_name="__main__")
