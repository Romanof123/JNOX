"""Replay both host control surfaces against the corrected frozen source archive on x86-64 Linux."""
import argparse
import hashlib
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

from verify_package import BLOBS, require

SOURCE_SHA = "d0adc967edaf7bf0cc79525946b0b5a2682c55d83444c7255801adb6af2f620b"
BUILD_RS_SHA = "f891b6d683de99ed402a3c7fa1df27452558facb4b58a4108f180c4cec422eaf"
here = Path(__file__).resolve().parent


def compare(expected_name, verifier, *arguments):
    output = subprocess.check_output([sys.executable, "-B", str(here / verifier), *map(str, arguments)])
    require(output == (here / expected_name).read_bytes(), expected_name + " replay differs")
    print(expected_name, hashlib.sha256(output).hexdigest())


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("production_tar", type=Path)
    args = parser.parse_args()
    for line in (here / "SHA256SUMS").read_text().splitlines():
        digest, name = line.split("  ", 1)
        require(Path(name).name == name and (here / name).is_file(), name)
        require(hashlib.sha256((here / name).read_bytes()).hexdigest() == digest, name)
    require(hashlib.sha256(args.production_tar.read_bytes()).hexdigest() == SOURCE_SHA, "source archive")
    with tempfile.TemporaryDirectory() as temp, tarfile.open(args.production_tar, "r:") as archive:
        src = Path(temp)
        require(hashlib.sha256(archive.extractfile("kernel/build.rs").read()).hexdigest() == BUILD_RS_SHA,
                "corrected build.rs")
        for name in BLOBS:
            path = src / name
            path.parent.mkdir(exist_ok=True, parents=True)
            path.write_bytes(archive.extractfile(name).read())
        compare("python-results.json", "verify_package.py", "--source", src)
    compare("rust-results.json", "verify_rust_env.py", here / "prebuilt-build-scripts.tar.xz",
            here / "original-cargo-refusal.log")
