"""Execute the frozen native CLI and inspect its arguments just before a kernel build would start."""
import argparse
import contextlib
import hashlib
import io
import json
import runpy
import subprocess
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

ORIGINAL="6fbb5033c4f110b7a9941e4a74a1ea82e4e94fff"
CORRECTED="047184a4c13ecc3f9bc74c4f94a04658e2b3ccc6"
BLOBS={
    "arch/aarch64/target":"c55e986c579ae101390b1118844d113c4552539c",
    "kernel/.cargo/config.toml":"e9a9f7433e5fe38a28c91cbaac631a206032ed2a",
    "kernel/Cargo.lock":"d2a4a401ce2a2fdbb065bd5ad173fa45d64c3c37",
    "kernel/Cargo.toml":"6d96bd7fa9a25770fdfdbd708bcb62ff4dfc7706",
    "tools/build_kernel.py":"a729eeb9abbaf0163d6834a99d5d5de006aef8ef",
    "tools/build_native_el0.py":"f47240651eb3d3487fb64d63f40562f117411920",
    "tools/native_amc_roots.py":"ad813138cbfe0ed0813747962c696af156a05a79",
    "tools/native_extension_program.py":"ff19321ba54ce155eeceb9c404626f7ebf53815c",
    "tools/native_hierarchy.py":"974f6e53b767f84205028e40bbc8c9437a682ca2",
    "tools/native_lottery_admission.py":"5661e778c76d98271c1705fe0f2ecb58f48125f5",
    "tools/native_shell_rom.py":"45dccf31c03bca46271e47d63d3202da87cd1c9e",
}


def require(ok,message):
    if not ok: raise ValueError(message)


def frozen(repo,source,dest):
    for path,digest in BLOBS.items():
        if repo:
            data=subprocess.check_output(["git","-C",str(repo),"show",f"{CORRECTED}:{path}"])
            earlier=subprocess.check_output(["git","-C",str(repo),"rev-parse",f"{ORIGINAL}:{path}"]).decode().strip()
            require(earlier==digest,path)
        else:
            data=(source/path).read_bytes()
        oid=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
        require(oid==digest,path)
        local=dest/path
        local.parent.mkdir(exist_ok=True,parents=True)
        local.write_bytes(data)


SELECT="one matching boundary selector for all three slots"
EXTRA="only a rearm boundary permits one optional supervisor lead"
LEAD="supervisor lead must be 1 to 5 ASCII decimal digits in the range 0..12500 ticks"


def cases():
    for s in ("phase","collision","rearm-15","rearm-20"):
        for v in ([None] if s in ("phase","collision") else [None,"0","00000","00007","1","12500"]):
            yield f"{s}/{v if v is not None else 'omitted'}", [[s],[s],[s] if v is None else [s,v]],None
    for s in ("Phase","rearm","rearm-10","rearm-15x","REARM-20",""):
        yield f"bad-selector/{s}",[[s],[s],[s]],SELECT
    s="rearm-15"
    for n,slots,e in [
        ("no selectors",[[],[],[]],SELECT),
        ("sender role disagrees",[["rearm-20"],[s],[s]],SELECT),
        ("receiver role disagrees",[[s],["rearm-20"],[s]],SELECT),
        ("supervisor role disagrees",[[s],[s],["rearm-20"]],SELECT),
        ("receiver selector missing",[[s],[],[s]],SELECT),
        ("supervisor selector missing",[[s],[s],[]],SELECT),
        ("sender extra",[[s,"7"],[s],[s]],SELECT),
        ("receiver extra",[[s],[s,"7"],[s]],SELECT),
        ("supervisor two leads",[[s],[s],[s,"7","8"]],EXTRA),
        ("all roles extra",[[s,"7"],[s,"7"],[s,"7"]],SELECT),
        ("phase with lead",[["phase"],["phase"],["phase","0"]],EXTRA),
        ("collision with lead",[["collision"],["collision"],["collision","0"]],EXTRA),
        ("legacy selectors disagree",[["phase"],["collision"],["phase"]],SELECT),
    ]: yield n,slots,e
    for v in ("12501","99999","012500","000000","１２","١","١٢","+1","-1","-0",""," 1","1 ","1.0","1_0","0x1"):
        yield f"bad-lead/{v!r}", [[s],[s],[s,v]], LEAD


def wire(argv):
    data=[s.encode() for s in argv]
    return (bytes([len(data)])+b"".join(len(v).to_bytes(2,"little")+v for v in data)).hex()


class AtBuild(Exception):
    pass


def exercise(root,el,idx,name,slots,err,policy):
    path=root/"tools/build_native_el0.py"
    out=root/f"out-{idx}-{policy}"
    argv=[str(path),"--out",str(out),"--elf",str(el[0]),"--peer-elf",str(el[1]),"--peer-elf",str(el[2]),
          "--policy",policy,"--priority","6","--peer-priority","7","--peer-priority","4",
          "--loan-route","0:1","--safety-channel","--safety-boundary"]
    if policy=="rr": argv+=["--quantum-ticks","625000"]
    for option,values in zip(("--arg","--peer-arg","--peer2-arg"),slots):
        argv.extend(f"{option}={s}" for s in values)
    result=dict(case=name,policy=policy,slots=slots)
    # These informational reads are outside selector validation. Never record fictitious versions or cleanliness.
    versions={("git","rev-parse","HEAD"):CORRECTED,("git","status","--porcelain","--untracked-files=no"):"host-test fixture",
              ("rustc","-vV"):"not queried",("cargo","--version"):"not queried"}
    def provenance(cmd,**kwargs):
        return versions[tuple(cmd)]
    def stop(cmd,**kw):
        require(cmd==[sys.executable,"tools/build_kernel.py","--arch","aarch64"],"unexpected child command")
        state=sys._getframe(1).f_locals
        meta,env=state["metadata"],kw["env"]
        require(meta["package_argv"]==argv and meta["policy"]==policy,"package selection")
        require([slot["argv"] for slot in meta["slots"]]==[["/bin/app",*s] for s in slots],"slot argv")
        wanted={"scenario":slots[0][0],"decision_event":12}
        if slots[0][0].startswith("rearm-"):
            wanted.update(rearm_eligibility_event=15,supervisor_lead_ticks=int(slots[2][1]) if len(slots[2])==2 else 0)
        require(meta["safety_boundary"]==wanted,"boundary metadata")
        require(env["JNOX_NATIVE_SAFETY_BOUNDARY"]==env["JNOX_NATIVE_SAFETY_CHANNEL"]=="1","safety env")
        wires=[env[f"JNOX_NATIVE_ARGV{i}_HEX"] for i in range(3)]
        require(wires==[wire(s) for s in slots],"wire encoding")
        require(all((out/slot["elf"]).read_bytes()==el[i].read_bytes() for i,slot in enumerate(meta["slots"])),
                "input identity")
        result.update(outcome="stopped-before-kernel-child",safety_boundary=wanted,slot_wire_hex=wires)
        raise AtBuild
    stderr=io.StringIO()
    with patch.object(sys,"argv",argv), patch.object(subprocess,"check_output",provenance), \
         patch.object(subprocess,"run",stop), contextlib.redirect_stderr(stderr):
        try: runpy.run_path(str(path),run_name="__main__")
        except AtBuild:
            require(err is None,name+": unexpected acceptance")
            require(out.is_dir() and not (out/"manifest.json").exists(),name+": stop boundary")
        except SystemExit as exc:
            msg=stderr.getvalue().splitlines()[-1].partition(": error: ")[2]
            require(exc.code==2 and err and err in msg and not out.exists(),name+": "+msg)
            result.update(outcome="refused",error=msg,output_created=False)
        else: raise ValueError("kernel boundary missed")
    return result


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument("--git",type=Path,help="repository containing both frozen objects (read-only)")
    g.add_argument("--source",type=Path,help="restored frozen source tree")
    args=p.parse_args()
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp)
        frozen(args.git,args.source,root)
        sys.path.insert(0,str(root/"tools"))
        el=[root/f"fixture-{i}.bin" for i in range(3)]
        for i,path in enumerate(el): path.write_bytes(f"host-only fixture {i}\n".encode())
        rows=[exercise(root,el,i,n,ss,err,policy) for policy in ("fifo","rr")
              for i,(n,ss,err) in enumerate(cases())]
    print(json.dumps(dict(original=ORIGINAL,corrected=CORRECTED,python_blob=BLOBS["tools/build_native_el0.py"],
                          cases=rows),ensure_ascii=True,indent=1,sort_keys=True))
