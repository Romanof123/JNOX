# Native permit rearm package arguments · 패키지 인자 검증

The Python packager accepted valid rearm inputs at both frozen revisions. The original Rust build script rejected them. The corrected Rust build script accepted the same selector and lead combinations under FIFO and RR. Each layer has a distinct observed endpoint.

| Host entry point | Cases per policy | Observed endpoint |
|---|---:|---|
| Python CLI, shared by both revisions | 14 accepted, 35 refused | Accepted arguments reached the intercepted kernel-builder call. Invalid arguments exited with argparse status 2 before the output directory existed. |
| Corrected Rust build script | 14 accepted, 44 refused | Valid arguments emitted the boundary cfg and wrote `native_schedule.rs`, then stopped on an intentionally missing primary ELF. Rejected inputs produced the expected diagnostic before either output. |
| Original Rust build script | 2 accepted, 2 refused | `phase` and `collision` reached the missing-image check. Both rearm selectors hit the original selector assertion. |

The corrected guard accepts a common `phase`, `collision`, `rearm-15` or `rearm-20` selector for all three roles. Only the two rearm scenarios accept one optional supervisor lead. Both policies exercised omitted, `0`, `00000`, `00007`, `1` and `12500` for each rearm selector. The packager preserved the supplied spelling on the wire. Its metadata recorded 0 for omission and 7 for `00007`. The decision event was 12 for all scenarios. Rearm metadata also identified eligibility event 15.

The refusal cases include unknown and mismatched selectors, absent role selectors, misplaced and excess arguments, six-digit strings, `12501`, Unicode digits, signs and whitespace. Rust also received eight malformed wire vectors and a fourth role argument. The per-case JSON records the outcomes and diagnostics.

The first actual Cargo invocation for FIFO `rearm-15` at zero lead reached the old assertion at `build.rs:689:9`, which admitted only matching phase or collision selectors. The raw log is included. The independent Python replay ran the frozen CLI entry with three inert file fixtures, stubbed four provenance reads and intercepted the first kernel-builder call. It checked in-memory metadata, slot arguments, encoded bytes and copied files. Direct Rust replay ran the pinned prior-build Linux executables in private output directories with an empty tool search path. These controls cover host packaging guards. Guest service behavior and successful kernel builds have separate evidence in the enclosing campaign.

## 한국어

두 리비전의 Python 패키저는 동일한 인자를 받아들였다. 첫 리비전에서는 실제 Cargo 실행이 FIFO `rearm-15`의 리드 0을 처리하다 `build.rs:689:9`에서 중단됐다. 기존 Rust 검사기는 세 역할에 일치하는 `phase` 또는 `collision`만 허용했다. 수정 후 FIFO와 RR에서 각각 Python 49건, Rust 58건을 확인했다. 원본 Rust 실행 파일도 정책별로 4건을 대조했다.

정책별 Python 검사에서는 유효한 14건이 커널 빌더 호출 직전까지 도달했다. 나머지 35건은 출력 디렉터리 생성 전에 거부됐다. 수정된 Rust 실행 파일에서는 유효한 14건이 경계 설정과 스케줄 파일을 생성한 후 의도적으로 생략한 기본 ELF 검사에서 멈췄다. 44건은 그 전에 해당 오류를 냈다. 이 가운데 9건은 인코딩 손상 또는 네 번째 역할 인자를 직접 주입한 사례다.

`rearm-15`와 `rearm-20`은 세 역할의 선택자가 일치할 때 감독자에게만 리드 한 개를 허용했다. 생략과 0, 앞자리 0, 최댓값 12500을 확인했다. `00007`은 전송 시 그대로 보존되고 메타데이터에는 7로 기록됐다. 임계 초과, 6자리, 유니코드 숫자, 부호 및 역할 불일치는 거부됐다. 기존 `phase`와 `collision`은 추가 리드 없이 통과했다. 이번 재실행의 관측 범위는 호스트 패키징 검사까지다.

## Frozen inputs and replay · 입력 및 재현

| Input | Identifier |
|---|---|
| Original commit | `6fbb5033c4f110b7a9941e4a74a1ea82e4e94fff` |
| Corrected commit | `047184a4c13ecc3f9bc74c4f94a04658e2b3ccc6` |
| Common Python packager Git blob | `f47240651eb3d3487fb64d63f40562f117411920` |
| Original and corrected kernel/build.rs blobs | `95b9d5cc0888c599b5878cb3c559f54f4e504d86`, `d3229ccb5fdc1b402f482f88bcdcbb320be1761b` |
| Original raw Cargo log SHA-256 | `9073e9a6b60a6e69214122e5af1cfe47873dc7d59b3c1809921d3feeb4f4cdaa` |
| Corrected source/production.tar SHA-256 | `d0adc967edaf7bf0cc79525946b0b5a2682c55d83444c7255801adb6af2f620b` |

On x86-64 Linux, run from the restored campaign root. The supplement includes both compressed host executables and their digest checks. The script verifies its manifest and the frozen sources, reruns both suites in temporary directories, and compares both JSON outputs byte for byte.

```sh
python3 -B host-controls/replay.py source/production.tar
```
