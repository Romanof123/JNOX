"""Check precompiled, SHA-pinned x86-64 Linux build scripts directly, with a closed child PATH."""
import argparse
import hashlib
import json
import subprocess
import tarfile
import tempfile
from pathlib import Path

from verify_package import CORRECTED, EXTRA, LEAD, ORIGINAL, cases, require, wire

HASHES = {
    "original": "568288647e8d31bd10ffb56560f2632921f587833e55835734dc682b57a83e3c",
    "corrected": "87bfbcdd31f9719f606480fff030e2bd07349d7c273ac81105ed933a3b77cd6d",
}
LOG_HASH = "9073e9a6b60a6e69214122e5af1cfe47873dc7d59b3c1809921d3feeb4f4cdaa"
ORIGINAL_REJECTION = "boundary observations require matching phase or collision arguments"
MATCH = "boundary observations require matching selectors for three slots"
UNKNOWN = "unknown boundary observation selector"
OPTION = "only rearm accepts one supervisor lead"
SENTINEL = "missing JNOX_NATIVE_ELF"
CFG = "cargo::rustc-cfg=jnox_native_safety_boundary"


def read_inputs(bundle, directory):
    binaries = {}
    with tarfile.open(bundle, "r:xz") as archive:
        require(sorted(archive.getnames()) == sorted(HASHES), "unexpected binary members")
        for label, expected in HASHES.items():
            entry = archive.getmember(label)
            require(entry.isfile() and entry.size < 2_000_000, "unexpected executable entry")
            data = archive.extractfile(entry).read()
            require(hashlib.sha256(data).hexdigest() == expected, label + " executable checksum")
            path = directory / label
            path.write_bytes(data)
            path.chmod(0o700)
            binaries[label] = path
    return binaries


def check(binary, policy, name, wires, expected):
    with tempfile.TemporaryDirectory() as temp:
        env = dict(PATH="/no-child-tools", OUT_DIR=temp, TARGET="aarch64-unknown-none",
                   JNOX_BOARD="virt", JNOX_PROFILE="native", JNOX_APP="process",
                   JNOX_NATIVE_POLICY=policy, JNOX_NATIVE_PRIORITIES="6,7,4",
                   JNOX_NATIVE_SAFETY_CHANNEL="1", JNOX_NATIVE_SAFETY_BOUNDARY="1",
                   JNOX_NATIVE_LOAN_ROUTE="0:1", JNOX_NATIVE_PEER_ELF="one",
                   JNOX_NATIVE_PEER_ELF_SHA256="0" * 64, JNOX_NATIVE_PEER2_ELF="two",
                   JNOX_NATIVE_PEER2_ELF_SHA256="0" * 64)
        if policy == "rr":
            env["JNOX_NATIVE_QUANTUM_TICKS"] = "625000"
        env.update({f"JNOX_NATIVE_ARGV{i}_HEX": value for i, value in enumerate(wires)})
        run = subprocess.run([binary], cwd=temp, env=env, capture_output=True, text=True, timeout=10)
        cfg = CFG in run.stdout.splitlines()
        files = sorted(path.name for path in Path(temp).iterdir())
        passed = expected == SENTINEL
        require(run.returncode == 101 and expected in run.stderr.splitlines(), f"{policy}/{name}: {run.stderr}")
        require(cfg == passed and files == (["native_schedule.rs"] if passed else []), name + ": stop boundary")
        return dict(build_script=binary.name, case=name, policy=policy, slot_wire_hex=wires,
                    emitted_boundary_cfg=cfg, output_files=files, diagnostic=expected,
                    outcome="passed-guard-missing-image" if passed else "refused",
                    exit_status=run.returncode)


def exercise(binaries):
    rows = []
    for policy in ("fifo", "rr"):
        for name, slots, error in cases():
            if error is None:
                expected = SENTINEL
            elif name.startswith("bad-selector/"):
                expected = UNKNOWN
            else:
                expected = {LEAD: LEAD, EXTRA: OPTION}.get(error, MATCH)
            rows.append(check(binaries["corrected"], policy, name, [wire(s) for s in slots], expected))
        valid = [wire(["rearm-15"])] * 3
        # These wire-level inputs bypass the CLI encoder.
        for name, raw, message in (
            ("odd-length", "0", "invalid argument vector hex length (up to 2080 digits)"),
            ("non-hex", "0g", "invalid hex digit"),
            ("too-many", "10", "at most 15 extra arguments"),
            ("missing-length", "01", "missing argument length"),
            ("truncated", "018000", "truncated argument"),
            ("NUL", "01010000", "argument contains NUL"),
            ("non-UTF8", "010100ff", "invalid UTF-8"),
            ("trailing-bytes", "0000", "trailing argument bytes"),
        ):
            rows.append(check(binaries["corrected"], policy, "wire/" + name, valid[:2] + [raw], "slot 2: " + message))
        rows.append(check(binaries["corrected"], policy, "fourth-slot-present", valid + [valid[0]], MATCH))
        for selector in ("phase", "collision", "rearm-15", "rearm-20"):
            expected = SENTINEL if selector in ("phase", "collision") else ORIGINAL_REJECTION
            rows.append(check(binaries["original"], policy, selector, [wire([selector])] * 3, expected))
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("bundle", type=Path)
    parser.add_argument("original_build_log", type=Path)
    args = parser.parse_args()
    log = args.original_build_log.read_bytes()
    require(hashlib.sha256(log).hexdigest() == LOG_HASH, "first failed Cargo log hash")
    require(b"panicked at build.rs:689:9:" in log and ORIGINAL_REJECTION.encode() in log, "first failed Cargo refusal")
    with tempfile.TemporaryDirectory() as temp:
        rows = exercise(read_inputs(args.bundle, Path(temp)))
    print(json.dumps(dict(original=ORIGINAL, corrected=CORRECTED, build_log_sha256=LOG_HASH,
                          binary_sha256=HASHES, cases=rows), indent=1, sort_keys=True))
