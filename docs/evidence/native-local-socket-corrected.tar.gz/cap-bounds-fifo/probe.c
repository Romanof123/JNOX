#include <errno.h>
#include <jnox/ipc.h>
#include <sys/un.h>
#include <time.h>

volatile long observed[64];
volatile unsigned observed_count;
static const struct sockaddr_un service = {AF_UNIX,"/012345678901234567890123456789"};
static const struct sockaddr_un gate = {AF_UNIX,"/gate"};
static const struct sockaddr_un origin = {AF_UNIX,"/origin"};

static int check(long actual, long expected) {
    observed[observed_count++] = actual;
    return actual == expected;
}
#define EXPECT(actual, expected) do { if (!check((actual), (expected))) return 80; } while (0)
static long outcome(long r) { return r < 0 ? -errno : r; }
static long openfd(int kind) { return outcome(socket(AF_UNIX, kind, 0)); }
static long named(int fd, const struct sockaddr_un *n) {
    return outcome(bind(fd, (const struct sockaddr *)n, sizeof(*n)));
}
static long linkto(int fd, const struct sockaddr_un *n) {
    return outcome(connect(fd, (const struct sockaddr *)n, sizeof(*n)));
}
static long put(int fd, const struct sockaddr_un *n, unsigned char byte) {
    return outcome(sendto(fd, &byte, 1, 0, (const struct sockaddr *)n, sizeof(*n)));
}
static long take(int fd, int flags) {
    unsigned char byte = 0;
    long len = outcome(recv(fd, &byte, 1, flags));
    return len == 1 ? byte : len;
}
static long rpc(uint64_t word) {
    jnox_ipc_response r = jnox_ipc_call(2, word, UINT64_MAX);
    return r.status ? r.status : (long)r.word;
}
#define TAG(t) ((uint64_t)(t) << 56)
static uint64_t begin(unsigned op, unsigned fd, unsigned arg, unsigned plen) {
    return TAG(0x11) | ((uint64_t)op<<48) | ((uint64_t)fd<<40) |
           ((uint64_t)arg<<32) | ((uint64_t)plen<<24);
}
static int bounds(int owner) {
    if (owner == 0) {
        EXPECT(openfd(SOCK_DGRAM),64);
        EXPECT(openfd(SOCK_STREAM),65);
        EXPECT(named(64,&gate),0);
        EXPECT(named(65,&service),0);
        EXPECT(outcome(listen(65,2)),0);
        EXPECT(take(64,0),41);
        EXPECT(openfd(SOCK_DGRAM),-23); /* all eight objects are live */
        EXPECT(outcome(accept(65,0,0)),66);
        EXPECT(take(66,0),51);
        EXPECT(outcome(close(66)),0);
        EXPECT(openfd(SOCK_DGRAM),66);
        EXPECT(outcome(close(66)),0);
        EXPECT(put(64,&origin,42),1);
        EXPECT(outcome(accept(65,0,0)),66);
        EXPECT(take(66,0),52);
        EXPECT(outcome(close(66)),0);
        EXPECT(outcome(accept(65,0,0)),66);
        EXPECT(take(66,0),53);
    } else {
        EXPECT(jnox_ipc_trap(37,0,0,0).status,-13);
        /* A normal wire request must look up fd 1 in this caller's table. */
        EXPECT(rpc(begin(9,1,0,0)),0);
        EXPECT(rpc(TAG(0x13)),-9);
        EXPECT(openfd(SOCK_DGRAM),64);
        EXPECT(named(64,&origin),0);
        for (int fd=65; fd<=67; ++fd) EXPECT(openfd(SOCK_STREAM|SOCK_NONBLOCK),fd);
        EXPECT(openfd(SOCK_DGRAM),-24);
        EXPECT(linkto(65,&service),0);
        EXPECT(linkto(66,&service),0);
        EXPECT(linkto(67,&service),-11);
        EXPECT(outcome(send(65,"3",1,0)),1);
        EXPECT(outcome(send(66,"4",1,0)),1);
        EXPECT(put(64,&gate,41),1);
        EXPECT(take(64,0),42);
        EXPECT(linkto(67,&service),0);
        EXPECT(outcome(send(67,"5",1,0)),1);
    }
    return 60+owner;
}
static int death(int owner) {
    if (owner == 0) {
        EXPECT(openfd(SOCK_SEQPACKET),64);
        EXPECT(named(64,&service),0);
        EXPECT(outcome(listen(64,2)),0);
        EXPECT(outcome(accept(64,0,0)),65);
        for (unsigned char b=1; b<=4; ++b) EXPECT(outcome(send(65,&b,1,0)),1);
        EXPECT(outcome(send(65,"x",1,MSG_DONTWAIT)),-11);
        EXPECT(outcome(send(65,"y",1,0)),1);   /* resumes when first record drains */
        EXPECT(outcome(send(65,"z",1,0)),-32); /* resumes on owner exit */
        EXPECT(take(65,0),0);
        EXPECT(openfd(SOCK_DGRAM),66);
        EXPECT(named(66,&origin),0);            /* exit released the bound pathname */
    } else {
        EXPECT(openfd(SOCK_SEQPACKET),64);
        EXPECT(named(64,&origin),0);
        EXPECT(linkto(64,&service),0);
        EXPECT(take(64,0),1);
        EXPECT(openfd(SOCK_DGRAM),65);
        EXPECT(rpc(begin(2,1,0,7)),0);
        EXPECT(rpc(TAG(0x12) | 0x666564636261ULL),0);
        EXPECT(rpc(begin(2,1,0,7)),-16);
        /* Exit with four records unread, two live descriptors and a partial bind. */
    }
    return 62+owner;
}
static int cancel(int owner) {
    EXPECT(openfd(SOCK_DGRAM),64);
    EXPECT(named(64,owner ? &origin : &gate),0);
    if (owner == 0) {
        EXPECT(rpc(begin(7,0,1,0)),0);
        struct timespec now;
        EXPECT(clock_gettime(CLOCK_MONOTONIC,&now),0);
        uint64_t deadline = (uint64_t)now.tv_sec*1000000000 + now.tv_nsec + 150000000;
        jnox_ipc_response r = jnox_ipc_call(2,TAG(0x13),deadline);
        EXPECT(r.status,-110);
        EXPECT(rpc(TAG(0x16)),0);
        EXPECT(put(64,&origin,71),1);
        EXPECT(take(64,0),72);
        EXPECT(take(64,MSG_DONTWAIT),-11);
    } else {
        for (int n=0; n<4; ++n) EXPECT(put(64,&origin,81+n),1);
        for (int n=0; n<4; ++n) EXPECT(take(64,0),81+n);
        EXPECT(take(64,0),71);
        EXPECT(put(64,&gate,72),1);
    }
    return 64+owner;
}
int main(int argc, char **argv) {
    if (argc != 2 || jnox_socket_broker(2) < 0) return 79;
    int owner = argv[1][0]-'0';
    if (owner < 0 || owner > 1) return 79;
    switch (argv[1][1]) {
        case 'b': return bounds(owner);
        case 'd': return death(owner);
        case 'c': return cancel(owner);
        default: return 79;
    }
}
