#!/usr/bin/env bash
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
cd "$src"
cp "$prep/edge.c" "$raw/edge.c"
run cc-edge sh sdk/native-aarch64/build.sh --local-socket "$raw/edge.c" "$raw/edge.elf"
for policy in fifo rr; do
    for test in bounds death cancel; do
        case "$test" in bounds) want=60;; death) want=62;; cancel) want=64;; esac
        guest "$test-$policy" "$policy" "$want" "$raw/edge.elf" "$raw/edge.c" --arg "0${test:0:1}" --priority 7 --peer-elf "$raw/edge.elf" --peer-arg "1${test:0:1}" --peer-priority 4 --peer-elf "$raw/broker.elf" --peer2-arg 3 --peer-priority 1 --socket-service 2 --ipc-route 0:2 --ipc-route 1:2 || true
    done
done
for suite in local ipc; do
    file=services/socket/src/local.rs
    [[ "$suite" == ipc ]] && file=kernel/src/sync_ipc.rs
    run "compile-$suite" rustc --edition 2021 --test "$file" -o "$raw/$suite-tests"
    run "host-$suite" "$raw/$suite-tests" --nocapture
done
