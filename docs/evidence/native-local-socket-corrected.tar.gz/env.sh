#!/usr/bin/env bash
set -euo pipefail
source "$HOME/.cargo/env"
export CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true
export PYTHONPATH="${PYTHONPATH:-}:$HOME/jnox-169-first-e203caa/deps"
rev=70f2ab812d1d0a444da04c0f8ecdf1f568d533d7
tree=b704fbf0af36762d30205ddd3e0a09511325017b
raw=${RAW:-$HOME/v376-70f2ab8-verifier}
src=${SRC:-$HOME/v376-70f2ab8-checkout}
export CARGO_TARGET_DIR="$raw/app-target"
run() {
    local tag=$1 status=0
    shift
    printf '%q ' "$@" >> "$raw/commands.sh"
    echo >> "$raw/commands.sh"
    "$@" > "$raw/$tag.log" 2>&1 || status=$?
    echo "$tag $status" | tee -a "$raw/status.txt"
    if ((status)); then tail -20 "$raw/$tag.log"; fi
    return "$status"
}
guest() {
    local name=$1 pol=$2 expect=$3 program=$4 source=$5
    shift 5
    local q=()
    if [[ $pol == rr ]]; then q=(--quantum-ticks 625000); fi
    run "pkg-$name" python3 tools/build_native_el0.py --out "$raw/pkg-$name" --policy "$pol" "${q[@]}" --elf "$program" "$@" || return
    run "cap-$name" python3 tools/native_el0_capture.py "$raw/cap-$name" "$raw/pkg-$name/kernel.elf" "$program" "$source" "$rev" --plain --manifest "$raw/pkg-$name/manifest.json" --expect-exit "$expect" --timeout 18 || return
    awk '/EXIT PID|FAULT|DROPPED/' "$raw/cap-$name/uart.bin"
}
