#![no_std]
#[path="/home/ywcho/v376-70f2ab8-checkout/services/socket/src/local.rs"] mod local;
use local::Local;
const CLIENTS: usize = 3;
const PATH: usize = 31;
const PAYLOAD: usize = 64;
const BUFFER: usize = PATH + PAYLOAD;

#[derive(Clone, Copy)]
struct Request {
    op: u8, fd: u8, arg: u8, path: usize, payload: usize, nonblock: bool,
    bytes: [u8; BUFFER], used: usize,
}

impl Request {
    fn begin(w: u64) -> Result<Self, i32> {
        let [reserved, flags, payload, path, arg, fd, op, _] = w.to_le_bytes();
        let valid = match op {
            1 => fd == 0 && path == 0 && payload == 0,
            2 | 3 => path > 0 && arg == 0 && payload == 0,
            4 | 8 => path == 0 && payload == 0,
            5 | 9 => path == 0 && payload == 0 && arg == 0,
            6 => arg == 0,
            7 => usize::from(arg) <= PAYLOAD && path == 0 && payload == 0,
            _ => false,
        };
        if !valid || reserved != 0 || flags > 1 || usize::from(path) > PATH ||
            usize::from(payload) > PAYLOAD { return Err(-22); }
        Ok(Self { op, fd, arg, path: path.into(), payload: payload.into(), nonblock: flags != 0,
            bytes: [0; BUFFER], used: 0 })
    }

    fn chunk(&mut self, w: u64) -> Result<u64, i32> {
        let data = w.to_le_bytes();
        let left = self.path + self.payload - self.used;
        let n = left.min(6);
        if n == 0 || usize::from(data[6]) != self.used || data[n..6].iter().any(|&v| v != 0) {
            return Err(-22);
        }
        self.bytes[self.used..self.used + n].copy_from_slice(&data[..n]);
        self.used += n;
        Ok(0)
    }
}

#[derive(Clone, Copy)]
struct Response {
    bytes: [u8; BUFFER],
    count: usize, full: usize, path: usize,
}
impl Response {
    fn read(&self, offset: usize) -> Result<u64, i32> {
        let len = self.count + self.path;
        if offset >= len { return Err(-22); }
        let n = (len - offset).min(6);
        let mut data = [0; 8];
        data[..n].copy_from_slice(&self.bytes[offset..offset+n]);
        Ok(u64::from_le_bytes(data))
    }
}

#[derive(Clone, Copy)]
struct Client {
    request: Option<Request>, response: Option<Response>, pending: Option<u64>,
}
const EMPTY: Client = Client { request: None, response: None, pending: None };

// app.ld places .data.* in the process-private RW load. Initialize the live
// socket table in its final location, without constructing it on the EL0 stack.
#[link_section = ".data.socket_service"]
#[no_mangle]
pub static mut SERVICE: Local = Local::new();
#[no_mangle]
pub static mut CLIENT_STATE: [Client; CLIENTS] = [EMPTY; CLIENTS];

