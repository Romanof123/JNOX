#!/usr/bin/env bash
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
cd "$src"
# Cargo's release strip removed debug sections from the first layout witness.
# Extract only the definitions into an unlinked inspection object. No guest runs.
python3 - "$src" "$raw" <<'PY'
from pathlib import Path
import sys
src,raw=map(Path,sys.argv[1:])
s=(src/"services/socket/src/main.rs").read_text()
lo=s.index("const CLIENTS:")
hi=s.index("fn execute(")
prefix='#![no_std]\n#[path="'+str(src/"services/socket/src/local.rs")+'"] mod local;\nuse local::Local;\n'
types=s[lo:hi].replace("static mut SERVICE:", "#[no_mangle]\npub static mut SERVICE:").replace("static mut CLIENT_STATE:", "#[no_mangle]\npub static mut CLIENT_STATE:")
(raw/"broker-types.rs").write_text(prefix+types)
PY
run broker-types rustc --edition 2021 -C opt-level=3 -C debuginfo=2 --target aarch64-unknown-none-softfloat --crate-name jnox_local_socket --crate-type lib --emit=obj "$raw/broker-types.rs" -o "$raw/broker-types.o"
python3 "$prep/layout.py" "$raw" > "$raw/layout.json"
