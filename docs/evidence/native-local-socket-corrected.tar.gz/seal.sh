#!/usr/bin/env bash
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
packet=$(mktemp -d "$HOME/v376-corrected-packet.XXXXXXXX")
archive="$prep/376-corrected-70f2ab8.tar.gz"
mkdir "$packet/history" "$packet/source"
cp "$prep"/{edge.c,edge.sh,env.sh,first.sh,issue-376.md,layout.py,layout.sh,offline-types.sh,REPORT.en-ko.md,replay.py,seal.sh,trace.py,verify.py} "$packet"
cp "$prep"/../376-first-independent/376-first-e7d3ded.tar.gz* "$packet/history"
(cd "$packet/history" && sha256sum -c 376-first-e7d3ded.tar.gz.sha256)
cp "$raw"/{commands.sh,platform.txt,revision.txt,contract.md,status.txt,results.json,layout.json,layout-broker.elf,layout-kernel.o,layout-kernel.rs,broker-types.rs,broker-types.o,endpoint-types.rs} "$packet"
cp "$raw"/*.log "$packet"
git -C "$src" archive "$rev" arch boards examples kernel sdk services tools trace verification | tar -x -C "$packet/source"
git -C "$src" show --no-ext-diff --format=fuller "$rev" > "$packet/correction.patch"
git -C "$src" rev-parse HEAD 'HEAD^' 'HEAD^{tree}' > "$packet/commit-parent-tree.txt"
git -C "$src" status --porcelain --untracked-files=no > "$packet/source-status.txt"
cd "$raw"
for c in cap-* trace-*; do
    if [[ -d $c ]]; then cp -a "$c" "$packet"; fi
done
for p in pkg-*; do
    if [[ -d $p ]]; then
        mkdir "$packet/$p"
        cp "$p"/*.elf "$p/manifest.json" "$p/build.log" "$packet/$p"
    fi
done
cat > "$packet/observer-command.sh" <<'EOF'
python3 trace.py /home/ywcho/v376-70f2ab8-checkout /home/ywcho/v376-70f2ab8-verifier stream-fifo dgram-fifo seq-fifo bounds-fifo death-fifo cancel-fifo stream-rr dgram-rr seq-rr bounds-rr death-rr cancel-rr
EOF
cat > "$packet/observer-bootstrap-notes.txt" <<'EOF'
The first shell wrapper supplied an empty source path across the PowerShell/WSL quoting boundary. It stopped importing native_el0_capture before any QEMU launch. Passing the explicit absolute paths launched the twelve first register captures.
The initial linked layout witness omitted DWARF from the release binary. The offline unlinked object includes DWARF and was used for layout.json. Neither witness was used as a workload ELF in any boot.
EOF
cd "$packet"
PYTHONDONTWRITEBYTECODE=1 python3 verify.py . > "$raw/recheck.json"
cmp "$raw/recheck.json" results.json
find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
sha256sum -c --quiet SHA256SUMS
tar -czf "$archive" .
cd "$prep"
sha256sum "$(basename "$archive")" > "$(basename "$archive").sha256"
cp "$packet"/{commands.sh,results.json,status.txt,commit-parent-tree.txt} "$prep"
sha256sum -c "$(basename "$archive").sha256"
echo "$packet"
