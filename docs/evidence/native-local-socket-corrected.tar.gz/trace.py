"""Collect broker-return and reply-register observations on a separate boot of each frozen kernel."""
import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

args = argparse.ArgumentParser()
args.add_argument("source", type=Path)
args.add_argument("raw", type=Path)
args.add_argument("cases", nargs="+")
cfg = args.parse_args()
sys.path.insert(0, str(cfg.source / "tools"))
import native_el0_capture as capture

for case in cfg.cases:
    pkg = cfg.raw / ("pkg-" + case)
    raw = cfg.raw / ("cap-" + case)
    out = cfg.raw / ("trace-" + case)
    manifest = json.loads((pkg / "manifest.json").read_text())
    dis = subprocess.check_output(["aarch64-linux-gnu-objdump","-d",pkg/"native_peer2.elf"],text=True)
    main = dis.split("<main>:",1)[1]
    addresses = [int(x,16) for x in re.findall(r"^\s*([0-9a-f]+):\s+d4094021\s+svc",main,re.M)]
    # The first SVC in main is SVC 37, followed by the four reply sites.
    assert len(addresses)==5
    points = [addresses[0]+4, *addresses[1:]]
    filt = ",".join(f"0x{x:x}+4" for x in points)
    def command(qemu, directory, plain):
        base = capture.command(qemu, directory, True)
        return base+["-singlestep","-d","cpu,nochain","-dfilter",filt,"-D",str(directory/"registers.log")]
    marker = json.loads((raw/"session.json").read_text())["marker"]
    run = argparse.Namespace(root=out,kernel=pkg/"kernel.elf",user=pkg/"user.elf",probe=raw/"probe.c",
        revision=manifest["commit"],manifest=pkg/"manifest.json",arg=[],peer_arg=[],peer2_arg=[],
        plain=True,expect_exit=int(marker.split()[1]),timeout=45,qemu="qemu-system-aarch64",
        nm="aarch64-linux-gnu-nm")
    rc = capture.capture(run,command_factory=command)
    print(case, rc, flush=True)
    if rc: raise SystemExit(rc)
