#ifndef JNOX_ERRNO_H
#define JNOX_ERRNO_H
#define EPERM 1
#define ESRCH 3
#define EAGAIN 11
#define EBUSY 16
#define EDEADLK 35
#define EINTR 4
#define EFAULT 14
#define EOVERFLOW 75
#define EINVAL 22
#define ENOSYS 38
#define ENOTSUP 95
#define EBADF 9
#define EIO 5
#define EACCES 13
#define EMFILE 24
#define EPIPE 32
#define EWOULDBLOCK EAGAIN
#define EMSGSIZE 90
#define EOPNOTSUPP ENOTSUP
#define EADDRINUSE 98
#define EISCONN 106
#define ENOTCONN 107
#define ECONNREFUSED 111
#define ETIMEDOUT 110
int *__jnox_errno_location(void);
#define errno (*__jnox_errno_location())
#endif
