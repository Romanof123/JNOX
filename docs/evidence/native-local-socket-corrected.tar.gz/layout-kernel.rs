#![no_std]
include!("endpoint-types.rs");
#[no_mangle]
pub static LAYOUT: SyncIpc<3> = SyncIpc::with_broker([4,4,0],2);
