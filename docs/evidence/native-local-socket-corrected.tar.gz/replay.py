"""Cold-boot the archived release images serially, then compare their observations with the first captures."""
import argparse
import json
import subprocess
import sys
from pathlib import Path
from verify import EXITS, MODES, REV, capture, trace

p=argparse.ArgumentParser(description=__doc__)
p.add_argument("packet",type=Path)
p.add_argument("output",type=Path)
args=p.parse_args()
packet,out=args.packet.resolve(),args.output.resolve()
out.mkdir()
layout=json.loads((packet/"layout.json").read_text())
expected=json.loads((packet/"results.json").read_text())
for mode in MODES:
    for policy in ("fifo","rr"):
        case=mode+"-"+policy
        pkg=out/("pkg-"+case)
        pkg.symlink_to(packet/pkg.name,target_is_directory=True)
        cap=out/("cap-"+case)
        subprocess.run([sys.executable,packet/"source/tools/native_el0_capture.py",cap,pkg/"kernel.elf",
            pkg/"user.elf",packet/cap.name/"probe.c",REV,"--plain","--manifest",pkg/"manifest.json",
            "--expect-exit",str(EXITS[mode][0]),"--timeout","45"],check=True)
        actual=capture(pkg,cap,mode,layout)
        first=expected[case]
        for field in ("kernel","exits","slot_results","last_token","terminal"):
            assert actual[field]==first[field], (case,field)
        subprocess.run([sys.executable,packet/"trace.py",packet/"source",out,case],check=True)
        trdir=out/("trace-"+case)
        verify_again=capture(pkg,trdir,mode,layout)
        r,_=trace(trdir,mode,verify_again["last_token"])
        for field in ("calls","caller_counts","reply_attempts","unanswered_timed_out","verified_wire_commits"):
            assert r[field]==first["register_replay"][field], (case,field)
        print(case,actual["exits"],"matched",flush=True)
