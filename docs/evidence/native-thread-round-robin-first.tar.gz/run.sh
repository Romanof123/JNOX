set -eu
cd ~/rr316ind
E=$PWD/e
cp ~/jnox314-3d53da8/evidence/capture.py "$E/"
sed -i '/if re.search(rb/i\    if len(re.findall(rb"NATIVE EL0 EXIT PID [0-9]+ -?[0-9]+\\r?\\n",uart))>=2:break' "$E/capture.py"
cp build.sh "$E/"
order="rr-plain rr-traced coop-plain coop-traced early-exit-traced idle-join-traced early-wake-traced late-wake-traced late-create-traced errno-traced reuse-traced sensorcoop-traced processrr-traced"
echo "$order" > "$E/order"
qemu-system-aarch64 --version > "$E/qemu-version"
findmnt -T "$E" > "$E/filesystem"
find "$E" -name '*.elf' -exec sha256sum {} + > "$E/frozen.hashes"
for app in stream sensor prime; do aarch64-linux-gnu-objdump -d "$E/$app.elf" > "$E/$app.dis"; aarch64-linux-gnu-nm -nS "$E/$app.elf" > "$E/$app.sym"; done
sha256sum "$E"/{capture.py,order,*.dis,*.sym,qemu-version,frozen.hashes} > "$E/freeze"
python3 "$E/capture.py" "$E" $order | tee "$E/runs.log"
