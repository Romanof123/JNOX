set -ex
source ~/jnox314-3d53da8/env.sh
cd ~/rr316ind/src
E=$HOME/rr316ind/e
sh sdk/native-aarch64/build-rust.sh examples/native-threads-rust/Cargo.toml "$E/energy.elf"
for n in rustcoop rustrr; do
 f=(--threads 2); [[ $n == rustrr ]] && f+=(--policy rr --quantum-ticks 625000)
 python3 tools/build_native_el0.py --out "$E/$n" --elf "$E/energy.elf" "${f[@]}"
done
aarch64-linux-gnu-nm -nS "$E/energy.elf" > "$E/energy.sym"
python3 "$E/capture.py" "$E" rustcoop-traced rustrr-traced
