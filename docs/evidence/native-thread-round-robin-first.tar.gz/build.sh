set -eux
source ~/jnox314-3d53da8/env.sh
cd ~/rr316ind/src
E=$HOME/rr316ind/e
git rev-parse HEAD > "$E/revision"
git archive --format=tar.gz -o "$E/source.tar.gz" HEAD
sh sdk/native-aarch64/build.sh examples/native-thread-rr/stream.c "$E/stream.elf"
sh sdk/native-aarch64/build.sh examples/native-threads/sensor.c "$E/sensor.elf"
sh sdk/native-aarch64/build.sh examples/native-fixed/prime_low.c "$E/prime.elf"
for n in rr coop early-exit idle-join early-wake late-wake late-create errno reuse sensorcoop processrr; do
  flags=(--threads 2 --policy rr --quantum-ticks 625000); app=stream
  case $n in coop) flags=(--threads 2);; rr) ;; reuse) app=sensor;; sensorcoop) app=sensor; flags=(--threads 2);; processrr) app=prime; flags=(--policy rr --priority 1 --peer-elf "$E/prime.elf" --peer-priority 1 --quantum-ticks 625000);; *) flags+=(--arg "$n");; esac
  python3 tools/build_native_el0.py --out "$E/$n" --elf "$E/$app.elf" "${flags[@]}" > "$E/$n.build" 2>&1 || { cat "$E/$n.build"; exit 1; }
done
