from pathlib import Path
import struct,re,json
D=Path(__file__).parent; score={}
for r in sorted((D/'runs').iterdir()):
 n=r.name; u=(r/'uart.log').read_text()
 def rows(prefix):return [list(map(int,l[len(prefix)+1:].split())) for l in u.splitlines() if l.startswith(prefix+' ')]
 a=rows('NATIVE THREAD EVENT'); b=rows('NATIVE THREAD RR EVENT')
 z=score[n]={}
 if not a:
  assert rows('NATIVE EL0 EXIT PID')==[[0,12],[1,12]]; z['process_exits']=[12,12];continue
 assert rows('NATIVE THREAD DROPPED')==[[0]]
 z.update(rows=len(a),dropped=0,exit=rows('NATIVE EL0 EXIT')[0][0])
 assert len(set(x[26] for x in a))==1
 stacks=rows('NATIVE THREAD STACK')
 for x in a:
  for tid,pc,sp,err in ((x[2],*x[10:13]),(x[3],*x[13:16])):
   if pc: assert stacks[tid][1]<=sp<=stacks[tid][2] and sp%16==0 and err==stacks[tid][3]
 if n.endswith('traced'):
  t=(r/'exceptions.log').read_text();eret=[int(v,16) for v in re.findall(r'EL1 to AArch64 EL0 PC (0x[0-9a-f]+)',t)]
  assert eret==[x[13] for x in a if x[13]]
  irq=[int(v,16) for v in re.findall(r'Taking exception 5 \[IRQ\]\n...from EL0 to EL1\n[^\n]*\n...with ELR (0x[0-9a-f]+)',t)]
  assert irq==[x[10] for x in a if x[1]==2]
  assert t.count('acknowledged irq 30')==sum(x[1] in (2,3) for x in a)
  z.update(external_eret=len(eret),external_ppi30=t.count('acknowledged irq 30'))
 if b:
  assert rows('NATIVE THREAD RR CONFIG')==[[62500000,625000]] and len(a)==len(b)
  totals=[0,0];rot=[]
  for i,(x,y) in enumerate(zip(a,b)):
   if i:
    assert y[4]==x[0]
    if x[2]<2:
     assert y[3]==a[i-1][27] and y[5]==y[4]-y[3]
     totals[x[2]]+=y[5]
    else: assert y[5]==0
   assert totals==y[10:12]
   if y[7]:rot.append(dict(index=i,old=x[2],new=x[3],pc=hex(x[10]),sp=hex(x[11]),restore_pc=hex(x[13]),restore_sp=hex(x[14]),late=y[6],segment=y[5]))
  assert rows('NATIVE THREAD RR SERVICE')==[totals]
  z.update(service=totals,rotations=rot,overdue_range=([min(i['late'] for i in rot),max(i['late'] for i in rot)] if rot else []))
 mem=(r/'space.raw').read_bytes()
 def val(addr,fmt):
  page=0; base=a[0][26]&0xfffff000
  for shift in (30,21,12):
   desc=struct.unpack_from('<Q',mem,page+8*((addr>>shift)&511))[0];assert desc&3==3
   page=(desc&0xfffff000)-base
  return list(struct.unpack_from('<'+fmt,mem,page+(addr&4095)))
 if n.startswith('rust'):
  assert val(0x402000,'II')==[32640,5559680] and val(0x402408,'256I')==[i*i for i in range(256)];assert z['exit']==29;continue
 assert z['exit']==17
 if n.startswith(('reuse','sensorcoop')):
  assert val(0x402c50,'QQI')==[3,5,32640] and val(0x402c68,'QQI')==[0x402000,0x402420,3]
  for i in (0,1):
   assert val(0x402004+1056*i,'256I')==[j+i+1 for j in range(256)]
  z.update(handles=[3,5],stale_error=3);continue
 mb,wb=(1,1) if n.startswith('idle') else (32768 if n.startswith('late-create') else 16384,1 if n.startswith('early-exit') else 16384)
 assert val(0x403028,'I')==[mb] and val(0x4040b0,'I')==[wb] and val(0x403020,'Q')==[mb*522240] and val(0x403030,'16Q')==[wb*256]*16 and val(0x4040b8,'Q')==[0x402000]
 z.update(blocks=[mb,wb],checksum=mb*522240,bins=val(0x403030,'16Q'),joined=hex(0x402000))
 if n.startswith('rr-'):
  for k,el in enumerate(rot[:4]):
   assert el['old']==k%2 and el['new']==1-k%2
   assert (0x400308<=int(el['pc'],16)<0x400364) if k%2==0 else (0x400364<=int(el['pc'],16)<0x4003c4)
   if k: assert el['restore_pc']==rot[k-1]['pc'] and el['restore_sp']==rot[k-1]['sp']
 if n.startswith('coop'):
  x=next(x for x in a if x[3]==1); assert x[4]==11 and x[19]==4 and not any(x[1]==2 for x in a)
 if n.startswith('early-exit'):
  j=next(i for i,x in enumerate(a) if x[4]==12);assert not any(x[1]==2 for x in a[j+1:]); z['solo_ticks_after_exit']=a[-1][0]-a[j][27];assert z['solo_ticks_after_exit']>625000*3
 if 'wake-' in n or n.startswith('idle'):
  due,wake=val(0x4040c0,'QQ');assert wake>=due
  j=next(i for i,x in enumerate(a) if x[4]==7); x=a[j+1]; y=b[j+1]
  z.update(sleep_ns=[due,wake],wake_row=j+1,wake_origin=x[1],wake_turn_changed=y[7],wake_entry_minus_expiry=(x[0]-y[2] if y[2] else None))
  if n.startswith('idle'): assert x[1]==3 and a[j][19:21]==[4,3] and x[3]==1
  else: assert x[1]==2 and y[7]==int(n.startswith('late')) and any(t[4]==6 for t in a) if False else x[1]==2 and y[7]==int(n.startswith('late'))
 if n.startswith('late-create'):
  j=next(i for i,x in enumerate(a) if x[4]==10);assert b[j][4]>b[j][2] and b[j+1][7]==1;z['create_overdue']=b[j][6]
 if n.startswith('errno'):
  assert val(0x4040b4,'I')==[22] and val(0x4040d0,'I')==[38] and len(rot)>=2;z['errno']=[22,38]
print(json.dumps(score,indent=2))
