#!/bin/bash
set -eu
e=$HOME/iv365-first-evidence
src=$HOME/iv365-first-src
source "$HOME/.cargo/env"
cp "$src/kernel/src/sync_ipc.rs" "$e/layout_model.rs"
cat >> "$e/layout_model.rs" <<'RS'
#[no_mangle] pub fn slot_flags(s:&Slot) -> u64 {
 (s.alive as u64) | ((s.receiving as u64)<<1) | ((s.request.is_some() as u64)<<2) | ((s.completion.is_some() as u64)<<3)
}
#[no_mangle] pub static SLOT_LAYOUT:[usize;9] = [core::mem::size_of::<Slot>(),core::mem::offset_of!(Slot,alive),core::mem::offset_of!(Slot,receiving),core::mem::offset_of!(Slot,request),core::mem::offset_of!(Slot,completion),core::mem::offset_of!(SyncIpc<2>,slots),core::mem::offset_of!(SyncIpc<3>,slots),core::mem::offset_of!(SyncIpc<2>,last_token),core::mem::offset_of!(SyncIpc<3>,last_token)];
RS
sed -i '1i#![no_std]' "$e/layout_model.rs"
rustc --edition 2021 -C opt-level=3 --target aarch64-unknown-none-softfloat --crate-type lib --emit=obj="$e/layout_model.o" "$e/layout_model.rs"
aarch64-linux-gnu-objdump -dr --disassemble=slot_flags "$e/layout_model.o" > "$e/layout-flags.txt"
aarch64-linux-gnu-objdump -s -j .rodata.SLOT_LAYOUT "$e/layout_model.o" >> "$e/layout-flags.txt"
cat "$e/layout-flags.txt"
