#!/usr/bin/env python3
"""Read final native RAM, verify private EL0 page mappings and fixed UART, and check candidate hash."""
import hashlib,itertools,json,re,struct,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1])
sha="6f51e0b138c9dd613a18cddc53495673c7f71c1b"
no=(1<<64)-1
def load(path): return json.loads(path.read_text())
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def sym(elf):
    rows=subprocess.check_output(["aarch64-linux-gnu-nm","-nS",str(elf)],text=True).splitlines()
    return {w[3]:(int(w[0],16),int(w[1],16)) for l in rows if len(w:=l.split())==4}
def find(s,part): return next(v for n,v in s.items() if part in n)
def read64(mem,offs): return struct.unpack_from("<Q",mem,offs)[0]
def slot_data(d,k,elf,n,i,name,fmt):
    start,size=find(k,"6SPACES")
    va,num=sym(elf)[name]; assert struct.calcsize(fmt)==num
    page=start+i*(size//n)
    for shift in [30,21,12]:
        desc=read64(d,page-0x40200000+8*((va>>shift)&511)); assert desc&3==3
        page=desc&0x0000fffffffff000
    return list(struct.unpack_from(fmt,d,page-0x40200000+(va&4095)))
all_data={}
cases=[("", "fifo",[41,42]),("", "rr",[41,42]),("", "same-no-route",[81,83]),("", "receiver-fifo",[41,42]),("", "receiver-rr",[41,42]),("independent","fifo",[61,62,63]),("independent","rr",[61,62,63]),("controls","disabled",[64,64]),("controls","donation",[51,52,53]),("controls","timeout",[54,55]),("controls","death",[56,57]),("controls","nested",[58,59,60])]
for group,tag,expected in cases:
    base=root/group; package=base/("package-"+tag); cap=base/("capture-"+tag)
    p=load(package/"manifest.json"); session=load(cap/"session.json")
    assert p["commit"]==sha and not p["tracked_changes"]
    for name,h in session["hashes"].items(): assert digest(cap/name)==h, name
    assert digest(cap/"kernel.elf")==p["kernel_elf_sha256"]
    for slot in p["slots"]:
        assert digest(package/slot["elf"])==slot["elf_sha256"]
    guest_hashes=re.findall(r"^NATIVE EL0 (?:PEER2? )?ELF ([0-9a-f]{64})$", (cap/"uart.bin").read_text(), re.M)
    assert guest_hashes==[slot["elf_sha256"] for slot in p["slots"]]
    k=sym(cap/"kernel.elf"); mem=(cap/"ram.bin").read_bytes()
    uart=(cap/"uart.bin").read_text()
    exits=[int(x) for i,x in re.findall(r"NATIVE EL0 EXIT PID (\d+) (-?\d+)",uart)]
    assert expected==exits and "NATIVE FIXED DROPPED 0" in uart and "FAULT" not in uart
    rows=[[int(w) for w in l.split()[3:]] for l in uart.splitlines() if l.startswith("NATIVE FIXED EVENT ")]
    assert rows[-1][4]==no and rows[-1][12:15]==[no]*3
    result={"exits":exits,"fixed_rows":len(rows),"kernel_sha256":p["kernel_elf_sha256"],"ram_bytes":len(mem),"first_observation_dropped":0,
      "owner_runs":[id if id!=no else "idle" for id,grp in itertools.groupby(r[4] for r in rows)],"terminal_owner":"idle","terminal_ready":[]}
    n=len(exits)
    if tag not in ("disabled","same-no-route"):
        pa,sz=find(k,"9ENDPOINTS"); offset=pa-0x40200000; assert sz==n*80+16
        flags=[[mem[offset+80*i+72],mem[offset+80*i+73],mem[offset+80*i+64],read64(mem,offset+80*i)] for i in range(n)]
        assert flags==[[0,0,2,0]]*n, flags
        result.update(endpoint_pool_bytes=sz,terminal_slots=[{"alive":False,"waiting_receive":False,"call_outstanding":False,"completion_outstanding":False} for _ in flags],tokens_issued=read64(mem,offset+n*80))
    if group=="" and tag!="same-no-route":
        if tag.startswith("receiver-"):
            assert [r[1] for r in rows[:3]]==[0,22,21] and [r[4] for r in rows[:3]]==[1,0,1]
            result["arrival"]="server_waiting"
        else:
            assert [r[1] for r in rows[:3]]==[0,21,22] and [r[4] for r in rows[:3]]==[0,1,1]
            result["arrival"]="caller_queued"
        client,server=[package/slot["elf"] for slot in p["slots"]]
        request=slot_data(mem,k,client,n,0,"ipc_request_word","<Q")[0]
        actual=slot_data(mem,k,client,n,0,"ipc_reply_word","<Q")[0]
        status=slot_data(mem,k,client,n,0,"ipc_call_status","<q")[0]
        captured=slot_data(mem,k,server,n,1,"ipc_server_words","<3Q")
        statuses=slot_data(mem,k,server,n,1,"ipc_reply_statuses","<3q")
        assert request==0x040101010200012c and actual==0x000404010101082e and status==0 and captured==[1,request,actual] and statuses==[-116,0,-116]
        result.update(client_request=hex(request),client_reply=hex(actual),client_status=status,server_words=[hex(w) for w in captured],server_reply_statuses=statuses,peak_outstanding_calls=1)
    if group=="independent":
        assert rows[0][12:14]==[2,1] and rows[1][1:5]==[21,0,0,1] and rows[1][12]==2
        assert any(r[1]==23 and r[3:5]==[1,0] and r[12:14]==[2,1] for r in rows)
        result.update(peak_outstanding_calls=2)
    if group=="controls" and tag!="disabled":
        reports=[]
        for i,slot in enumerate(p["slots"]):
            f=slot_data(mem,k,package/slot["elf"],n,i,"ipc_case","<6q11Q")
            reports.append(dict(call_status=f[:2],receive_status=f[2:4],reply_status=f[4:6],call_result=f[6:8],received=f[8:10],token=f[10:12],start_ns=f[12],end_ns=f[13],deadline_ns=f[14],after_wait_ns=f[15],checksum=f[16]))
        result.update(app_reports=reports,peak_outstanding_calls=2 if tag=="nested" else 1)
        if tag=="timeout":
            a,b=reports; assert a["call_status"]==[-110,0] and b["reply_status"]==[-116,0]
            assert a["after_wait_ns"]>=a["deadline_ns"] and b["after_wait_ns"]>=a["deadline_ns"]+50000000
            result["client_observed_timeout_after_deadline_ns"]=a["after_wait_ns"]-a["deadline_ns"]
        if tag=="donation":
            assert result["owner_runs"]==[0,2,0,1,2,"idle"] and reports[1]["checksum"]==133693440
            assert any(r[1]==21 and r[3:5]==[0,2] and r[12]==1 for r in rows)
            assert any(r[1]==3 and r[3:5]==[0,1] and r[12]==2 for r in rows)
        if tag=="death": assert reports[0]["call_status"]==[-32,-32]
        if tag=="nested":
            assert -35 in reports[2]["call_status"] and -1 in reports[2]["reply_status"]
    all_data[(group or "official")+"/"+tag]=result
print(json.dumps(all_data,indent=2))
