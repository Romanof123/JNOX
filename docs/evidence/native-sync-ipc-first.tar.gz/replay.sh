#!/bin/bash
set -eu
d=$HOME/iv365-first-evidence
prep=/mnt/d/codex/.jnox-work/365-first-independent
cp "$prep"/{baseline.sh,layout.sh,REPORT.en-ko.md} "$d"
python3 - "$d/report.py" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
s=p.read_text()
s=s.replace('("", "rr",[41,42]),','("", "rr",[41,42]),("", "same-no-route",[81,83]),')
s=s.replace('if tag!="disabled":','if tag not in ("disabled","same-no-route"):')
s=s.replace('if group=="":','if group=="" and tag!="same-no-route":')
s=s.replace('    k=sym(cap/"kernel.elf");', '''    for slot in p["slots"]:
        assert digest(package/slot["elf"])==slot["elf_sha256"]
    guest_hashes=re.findall(r"^NATIVE EL0 (?:PEER2? )?ELF ([0-9a-f]{64})$", (cap/"uart.bin").read_text(), re.M)
    assert guest_hashes==[slot["elf_sha256"] for slot in p["slots"]]
    k=sym(cap/"kernel.elf");''')
p.write_text(s)
PY
python3 "$d/report.py" "$d" > "$d/results.json"
(cd "$d" && cp "$prep/replay.sh" . && find . -type f ! -path '*/target/*' ! -path './app-target/*' ! -name host ! -name host-tests ! -name evidence-files.sha256 -print0 | sort -z | xargs -0 sha256sum > evidence-files.sha256 && sha256sum -c evidence-files.sha256 > /dev/null)
artifact=/mnt/d/codex/.jnox-work/365-first-independent/365-first-6f51e0b.tar.gz
tar --exclude=target --exclude=app-target --exclude=host-tests --exclude=host -C "$d" -czf "$artifact" .
cp "$d/results.json" "$prep/results.json"
cd "$prep"
sha256sum "$(basename "$artifact")" > 365-first-6f51e0b.tar.gz.sha256
cat 365-first-6f51e0b.tar.gz.sha256
ls -lh "$artifact"
