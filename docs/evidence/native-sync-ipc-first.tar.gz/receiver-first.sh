#!/bin/bash
set -eu
src=$HOME/iv365-first-src
d=$HOME/iv365-first-evidence
source "$HOME/.cargo/env"
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true
cd "$src"
sha=$(git rev-parse HEAD)
git branch frozen-first-365 "$sha"
git bundle create "$d/candidate.bundle" refs/heads/frozen-first-365 ^04d699c8a445fc837a423c96ba35825810550c4b
git bundle verify "$d/candidate.bundle" > "$d/candidate-verify.txt" 2>&1
echo 'Receiver already waiting. Priorities C slot0 1, Rust slot1 7, route 0:1. First dispatch 1; receive 1→0; call 0→1; private request/reply/negative statuses unchanged. Both fifo and rr, quantum 625000.' > "$d/receiver-first-freeze.txt"
cp /mnt/d/codex/.jnox-work/365-first-independent/receiver-first.sh "$d"
for mode in fifo rr; do
  args=(); if [ "$mode" = rr ]; then args+=(--quantum-ticks 625000); fi
  tag=receiver-$mode
  python3 tools/build_native_el0.py --elf "$d/client.elf" --peer-elf "$d/server.elf" --policy "$mode" --priority 1 --peer-priority 7 --ipc-route 0:1 "${args[@]}" --out "$d/package-$tag" >"$d/package-$tag.log"
  python3 tools/native_el0_capture.py "$d/capture-$tag" "$d/package-$tag/kernel.elf" "$d/client.elf" examples/native-sync-ipc/client.c "$sha" --plain --manifest "$d/package-$tag/manifest.json" --expect-exit 41 --timeout 7 >"$d/capture-$tag.log"
  awk '/NATIVE FIXED EVENT/{print $5,$7,$8}/EXIT PID/{print $0}' "$d/capture-$tag/uart.bin"
done
