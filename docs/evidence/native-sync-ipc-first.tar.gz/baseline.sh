#!/bin/bash
set -euo pipefail
src=$HOME/iv365-first-src
d=$HOME/iv365-first-evidence
source "$HOME/.cargo/env"
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true
cd "$src"
python3 tools/build_native_el0.py --elf "$d/client.elf" --peer-elf "$d/server.elf" --policy fifo --priority 7 --peer-priority 1 --out "$d/package-same-no-route" > "$d/no-route-build.log"
python3 tools/native_el0_capture.py "$d/capture-same-no-route" "$d/package-same-no-route/kernel.elf" "$d/client.elf" examples/native-sync-ipc/client.c "$(git rev-parse HEAD)" --plain --manifest "$d/package-same-no-route/manifest.json" --expect-exit 81 --timeout 7 > "$d/no-route-capture.log"
aarch64-linux-gnu-size -A "$d/package-same-no-route/kernel.elf" "$d/package-fifo/kernel.elf" > "$d/size-comparison.txt"
tail -4 "$d/capture-same-no-route/uart.bin"
cat "$d/size-comparison.txt"
