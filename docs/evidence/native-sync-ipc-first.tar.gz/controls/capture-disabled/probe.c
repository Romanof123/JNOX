#include <jnox/ipc.h>
int main(void) {
    if (jnox_ipc_call(1, 7, UINT64_MAX).status != -38) return 131;
    if (jnox_ipc_receive().status != -38) return 132;
    if (jnox_ipc_reply(0, 0) != -38) return 133;
    return 64;
}
