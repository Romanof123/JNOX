#!/bin/bash
set -euo pipefail
src=$HOME/iv365-first-src
d=$HOME/iv365-first-evidence
e=$d/controls
prep=/mnt/d/codex/.jnox-work/365-first-independent
mkdir -p "$e"
cp "$prep"/{disabled.c,controls.rs,controls.sh} "$e"
cp /mnt/d/codex/.jnox-work/ipc-365-runtime-cases/examples/native-sync-ipc/cases/{operational.c,README.md} "$e"
sha256sum "$e"/{disabled.c,controls.rs,controls.sh,operational.c,README.md} > "$e/frozen-inputs.sha256"
sha=$(git -C "$src" rev-parse HEAD)
source "$HOME/.cargo/env"
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$d/app-target" CARGO_NET_OFFLINE=true
cd "$src"
exec > >(tee -a "$e/run.log") 2>&1
run(){ local tag=$1; shift; printf '%q ' "$@" >>"$e/commands"; echo >>"$e/commands"; local rc=0; "$@" >"$e/$tag.log" 2>&1 || rc=$?; echo "$tag $rc" | tee -a "$e/status"; if [ "$rc" -ne 0 ]; then tail -25 "$e/$tag.log"; fi; return "$rc"; }
run host-build rustc --edition 2021 "$e/controls.rs" -o "$e/host"
run host "$e/host"
run disabled sh sdk/native-aarch64/build.sh "$e/disabled.c" "$e/disabled.elf"
run case-build sh sdk/native-aarch64/build.sh "$e/operational.c" "$e/operational.elf"
probe(){
 local tag=$1 elf=$2 c=$3 want=$4
 shift 4
 run package-"$tag" python3 tools/build_native_el0.py --elf "$elf" --policy fifo --priority 7 "$@" --out "$e/package-$tag" || return
 run capture-"$tag" python3 tools/native_el0_capture.py "$e/capture-$tag" "$e/package-$tag/kernel.elf" "$elf" "$c" "$sha" --plain --manifest "$e/package-$tag/manifest.json" --expect-exit "$want" --timeout 7 || :
 tail -4 "$e/capture-$tag/uart.bin"
}
probe disabled "$e/disabled.elf" "$e/disabled.c" 64 --peer-elf "$e/disabled.elf" --peer-priority 1
app=$e/operational.elf
c=$e/operational.c
probe donation "$app" "$c" 51 --arg high --peer-elf "$app" --peer-priority 4 --peer-arg medium --peer-elf "$app" --peer-priority 1 --peer2-arg low --ipc-route 0:2
probe timeout "$app" "$c" 54 --arg timeout --peer-elf "$app" --peer-priority 1 --peer-arg late --ipc-route 0:1
probe death "$app" "$c" 56 --arg orphan --peer-elf "$app" --peer-priority 1 --peer-arg depart --ipc-route 0:1
probe nested "$app" "$c" 58 --arg root --peer-elf "$app" --peer-priority 4 --peer-arg relay --peer-elf "$app" --peer-priority 1 --peer2-arg leaf --ipc-route 0:1 --ipc-route 1:2 --ipc-route 2:0
