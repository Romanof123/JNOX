#[path = "/home/ywcho/iv365-first-src/kernel/src/sync_ipc.rs"] mod transport;
use transport::SyncIpc;
const INF:u64 = u64::MAX;
const BASE:[u8;3] = [20,75,2];
fn main() {
    for first in [0usize,1] {
        let second = 1 - first;
        for receive_before in [true,false] {
            let mut k = SyncIpc::new([4,4,0]);
            if receive_before { k.receive(2,1).unwrap(); }
            k.call(first,2,200 + first as u64,9,2).unwrap();
            k.call(second,2,200 + second as u64,INF,3).unwrap();
            if !receive_before { k.receive(2,3).unwrap(); }
            let a=k.take(2).unwrap();
            assert_eq!(a.x2,200+first as u64);
            assert_eq!(k.priorities(BASE),[20,75,75]);
            k.receive(2,4).unwrap();
            let b=k.take(2).unwrap();
            assert_eq!(b.x2,200+second as u64);
            assert_ne!(a.x1,b.x1);
            k.reply(2,b.x1,0x9000+second as u64,8).unwrap();
            assert_eq!(k.priorities(BASE),[20,75,BASE[first]]);
            assert_eq!(k.reply(2,a.x1,0x3000,9),Err(-116));
            let x=k.take(first).unwrap();
            let y=k.take(second).unwrap();
            assert_eq!((x.status,x.x1),(-110,0));
            assert_eq!((y.status,y.x1),(0,0x9000+second as u64));
            assert!((0..3).all(|pid| !k.blocked(pid) && k.take(pid).is_none()));
            assert_eq!(k.next_deadline(),None);
            assert_eq!(k.priorities(BASE),BASE);
            println!("arrival={first},{second} receive_first={receive_before} overlap=2 exact_reply=timeout pending=0 priorities=base");
        }
    }
    for at in [8u64,9,10] {
        let mut k=SyncIpc::new([2,0]);
        k.call(0,1,44,9,2).unwrap();
        k.receive(1,3).unwrap();
        let token=k.take(1).unwrap().x1;
        k.exit(1,at);
        let expected=if at < 9 {-32} else {-110};
        assert_eq!(k.take(0).unwrap().status,expected);
        assert!(k.take(0).is_none()); assert_eq!(k.priorities([15,1]),[15,1]);
        k.restart(1).unwrap();
        assert_eq!(k.reply(1,token,5,11),Err(-116));
        println!("server_death={at} deadline=9 result={expected} stale_after_restart=-116");
    }
    for at in [8u64,9,10] {
        let mut k=SyncIpc::new([2,0]);
        k.call(0,1,44,9,2).unwrap(); k.receive(1,3).unwrap();
        let token=k.take(1).unwrap().x1;
        k.exit(0,at);
        assert!(k.take(0).is_none()); assert_eq!(k.priorities([15,1]),[15,1]);
        assert_eq!(k.next_deadline(),None); k.restart(0).unwrap();
        assert_eq!(k.reply(1,token,5,11),Err(-116));
        k.call(0,1,55,INF,12).unwrap(); k.receive(1,13).unwrap();
        let next=k.take(1).unwrap(); assert_ne!(next.x1,token); assert_eq!(next.x2,55);
        k.reply(1,next.x1,99,14).unwrap(); let output=k.take(0).unwrap();
        assert_eq!((output.status,output.x1),(0,99)); assert!(k.take(0).is_none());
        assert!((0..2).all(|pid| !k.blocked(pid)));
        println!("caller_death={at} deadline=9 stale_after_reuse=-116 new_completion=99 pending=0");
    }
    for cancelled in [0usize,1] {
        let mut k=SyncIpc::new([4,4,0]); let survive=1-cancelled;
        k.call(cancelled,2,256,9,0).unwrap(); k.call(survive,2,511,INF,1).unwrap();
        k.advance(9); k.receive(2,10).unwrap(); let msg=k.take(2).unwrap();
        assert_eq!(msg.x2,511); assert_eq!(k.take(cancelled).unwrap().status,-110);
        k.reply(2,msg.x1,33,11).unwrap(); assert_eq!(k.take(survive).unwrap().x1,33);
        assert_eq!(k.next_deadline(),None);
        assert!((0..3).all(|pid| !k.blocked(pid) && k.take(pid).is_none()));
        println!("queued_expiry={cancelled} surviving_word=511 pending=0");
    }
}
