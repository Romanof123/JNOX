#![no_std]
#![no_main]
use core::{panic::PanicInfo, time::Duration};
use jnox_native::{exit, ipc::{call, receive, reply}, sleep_until};
#[panic_handler] fn panic(_: &PanicInfo<'_>) -> ! { exit(119) }
#[no_mangle]
pub extern "C" fn main(_: i32, _: *const *const u8) -> i32 {
    let (outer, first) = receive().unwrap();
    if first != 0xacf02a11070733b6 { return 111; }
    if call(2, outer, u64::MAX) != Ok(outer ^ 0xf7298a1) { return 112; }
    if reply(outer, first ^ 0x1122334455667788).is_err() { return 113; }
    if reply(outer, 0) != Err(-116) { return 114; }
    let (stale, deadline) = receive().unwrap();
    if sleep_until(Duration::from_nanos(deadline + 150000000)).is_err() { return 115; }
    if reply(stale, 29) != Err(-116) { return 116; }
    let (next, word) = receive().unwrap();
    if word != 0x4d3a9 || reply(next, word * 2).is_err() { return 117; }
    let (_, abandoned) = receive().unwrap();
    if abandoned != 0x0deade11 { return 118; }
    62
}
