#include <jnox/ipc.h>
int main(void) {
    if (jnox_ipc_call(0, 7, UINT64_MAX).status != -35) return 121;
    jnox_ipc_request nested = jnox_ipc_receive();
    if (nested.status) return 122;
    if (jnox_ipc_reply(nested.word, 0) != -1) return 123;
    if (jnox_ipc_call(1, 0, UINT64_MAX).status != -13) return 124;
    if (jnox_ipc_reply(nested.token, nested.word ^ 0xf7298a1ULL)) return 125;
    if (jnox_ipc_reply(nested.token, 3) != -116) return 126;
    return 63;
}
