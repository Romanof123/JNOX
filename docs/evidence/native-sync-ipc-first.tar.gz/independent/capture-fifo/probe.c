#include <jnox/ipc.h>
#include <time.h>
static uint64_t now(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t) != 0) return 0;
    return (uint64_t)t.tv_sec * 1000000000 + (uint64_t)t.tv_nsec;
}
int main(void) {
    uint64_t a = 0xacf02a11070733b6ULL;
    jnox_ipc_response first = jnox_ipc_call(1, a, UINT64_MAX);
    if (first.status || first.word != (a ^ 0x1122334455667788ULL)) return 101;
    uint64_t start = now(), deadline = start + 150000000;
    if (!start) return 102;
    jnox_ipc_response expiry = jnox_ipc_call(1, deadline, deadline);
    if (expiry.status != -110 || now() < deadline) return 103;
    jnox_ipc_response subsequent = jnox_ipc_call(1, 0x4d3a9ULL, UINT64_MAX);
    if (subsequent.status || subsequent.word != 0x9a752ULL) return 104;
    jnox_ipc_response abandoned = jnox_ipc_call(1, 0x0deade11ULL, UINT64_MAX);
    if (abandoned.status != -32) return 105;
    if (jnox_ipc_call(1, 13, UINT64_MAX).status != -32) return 106;
    return 61;
}
