#!/bin/bash
set -euo pipefail
src=$HOME/iv365-first-src
d=$HOME/iv365-first-evidence
e=$d/independent
prep=/mnt/d/codex/.jnox-work/365-first-independent
mkdir -p "$e/rust/src"
cp "$prep"/{high.c,medium.c,additional.sh} "$e"
cp "$prep/server.rs" "$e/rust/src/main.rs"
cp "$prep/manifest.toml" "$e/rust/Cargo.toml"
sha256sum "$e"/{high.c,medium.c,rust/src/main.rs,rust/Cargo.toml,additional.sh} > "$e/frozen-source.sha256"
sha=$(git -C "$src" rev-parse HEAD)
exec > >(tee -a "$e/run.log") 2>&1
source "$HOME/.cargo/env"
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$d/app-target" CARGO_NET_OFFLINE=true
cd "$src"
run(){ local tag=$1; shift; printf '%q ' "$@" >>"$e/commands"; echo >>"$e/commands"; local rc=0; "$@" >"$e/$tag.log" 2>&1 || rc=$?; echo "$tag $rc" | tee -a "$e/status"; if [ "$rc" -ne 0 ]; then tail -25 "$e/$tag.log"; fi; return "$rc"; }
run high sh sdk/native-aarch64/build.sh "$e/high.c" "$e/high.elf"
run low sh sdk/native-aarch64/build-rust.sh "$e/rust/Cargo.toml" "$e/low.elf"
run medium sh sdk/native-aarch64/build.sh "$e/medium.c" "$e/medium.elf"
for policy in fifo rr; do
  args=(); if [ "$policy" = rr ]; then args+=(--quantum-ticks 625000); fi
  run "package-$policy" python3 tools/build_native_el0.py --elf "$e/high.elf" --peer-elf "$e/low.elf" --peer-elf "$e/medium.elf" --policy "$policy" --priority 90 --peer-priority 10 --peer-priority 50 --ipc-route 0:1 --ipc-route 1:2 --ipc-route 2:0 "${args[@]}" --out "$e/package-$policy" || continue
  run "capture-$policy" python3 tools/native_el0_capture.py "$e/capture-$policy" "$e/package-$policy/kernel.elf" "$e/high.elf" "$e/high.c" "$sha" --plain --manifest "$e/package-$policy/manifest.json" --expect-exit 61 --timeout 6 || :
  if test -f "$e/capture-$policy/uart.bin"; then tail -7 "$e/capture-$policy/uart.bin"; fi
done
