#!/bin/bash
set -euo pipefail
src=$HOME/iv365-first-src
d=$HOME/iv365-first-evidence
sha=6f51e0b138c9dd613a18cddc53495673c7f71c1b
prep=/mnt/d/codex/.jnox-work/365-first-independent
mkdir "$d" "$src"
cp "$prep/freeze.txt" "$d/freeze.txt"
cp "$prep/official.sh" "$d/official.sh"
exec > >(tee -a "$d/run.log") 2>&1
source "$HOME/.cargo/env"
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$d/app-target"
export CARGO_NET_OFFLINE=true
windows_repo=/mnt/d/codex/j-nox/.git
git -C "$src" init -q
echo "$windows_repo/objects" > "$src/.git/objects/info/alternates"
cd "$src"
git sparse-checkout init --cone
git sparse-checkout set arch boards examples kernel sdk tools trace verification
git -c advice.detachedHead=false checkout -q --detach "$sha"
git rev-parse HEAD HEAD^{tree}
run(){ local tag=$1; shift; printf '%q ' "$@" >>"$d/commands"; echo >>"$d/commands"; local rc=0; "$@" >"$d/$tag.log" 2>&1 || rc=$?; echo "$tag $rc" | tee -a "$d/status"; if [ "$rc" -ne 0 ]; then tail -30 "$d/$tag.log"; fi; return "$rc"; }
run host-build rustc --edition 2021 --test kernel/src/sync_ipc.rs -o "$d/host-tests" && run host-test "$d/host-tests" --nocapture || :
run c sh sdk/native-aarch64/build.sh examples/native-sync-ipc/client.c "$d/client.elf"
run rust sh sdk/native-aarch64/build-rust.sh examples/native-sync-ipc/server/Cargo.toml "$d/server.elf"
sha256sum "$d/client.elf" "$d/server.elf"
for policy in fifo rr; do
  args=(); if [ "$policy" = rr ]; then args+=(--quantum-ticks 625000); fi
  run "package-$policy" python3 tools/build_native_el0.py --elf "$d/client.elf" --peer-elf "$d/server.elf" --policy "$policy" --priority 7 --peer-priority 1 --ipc-route 0:1 "${args[@]}" --out "$d/package-$policy" || continue
  run "capture-$policy" python3 tools/native_el0_capture.py "$d/capture-$policy" "$d/package-$policy/kernel.elf" "$d/client.elf" examples/native-sync-ipc/client.c "$sha" --plain --manifest "$d/package-$policy/manifest.json" --expect-exit 41 --timeout 8 || :
  if test -f "$d/capture-$policy/uart.bin"; then tail -25 "$d/capture-$policy/uart.bin"; fi
done
