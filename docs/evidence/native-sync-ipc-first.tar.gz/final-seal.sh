#!/bin/bash
set -eu
d=$HOME/iv365-first-evidence
prep=/mnt/d/codex/.jnox-work/365-first-independent
cp "$prep/final-seal.sh" "$d"
python3 - "$d" <<'PY'
from pathlib import Path
import sys
d=Path(sys.argv[1])
f=d/"report.py"; s=f.read_text()
s=s.replace('("", "same-no-route",[81,83]),','("", "same-no-route",[81,83]),("", "receiver-fifo",[41,42]),("", "receiver-rr",[41,42]),')
s=s.replace('        client,server=', '''        if tag.startswith("receiver-"):
            assert [r[1] for r in rows[:3]]==[0,22,21] and [r[4] for r in rows[:3]]==[1,0,1]
            result["arrival"]="server_waiting"
        else:
            assert [r[1] for r in rows[:3]]==[0,21,22] and [r[4] for r in rows[:3]]==[0,1,1]
            result["arrival"]="caller_queued"
        client,server=''')
f.write_text(s)
f=d/"REPORT.en-ko.md"; s=f.read_text()
s=s.replace('Ten fresh single-core','Twelve fresh single-core').replace('Ten boots provide','Twelve boots provide').replace('열 번의 최초','열두 번의 최초').replace('All ten UARTs','All twelve UARTs')
s=s.replace('| Independent FIFO and RR', '| Receiver-first official FIFO and RR | 41,42 in each | Same official app hashes and route, priorities 1/7. Both traces begin with owner 1, blocking RECEIVE 1→0, then CALL 0→1. Original official FIFO and RR begin with owner 0, CALL 0→1, then RECEIVE. All four RAM snapshots have the same request, token, reply and signed statuses. |\n| Independent FIFO and RR')
s=s.replace('## Offline replay','''## Source provenance

The included `candidate.bundle` contains exactly one commit above public base `04d699c8a445fc837a423c96ba35825810550c4b`. In a repository with the base, verify with `git bundle verify candidate.bundle` and import with `git fetch ./candidate.bundle refs/heads/frozen-first-365`. Independently compared public integration `de768c0675cfd410c001bd95bdf6bff79c5780b4` has the identical complete kernel, SDK, tools and examples trees to the frozen commit. Public role fixture `d8ee6d7204812463d3439541a3f5cfb7e217efcb` has identical operational.c Git blob `5048ebadc64d7e64bccf63bc3e1f279f364e3ca4`. The manifest names the verified local commit.

## Offline replay''')
f.write_text(s)
PY
python3 "$d/report.py" "$d" > "$d/results.json"
cd "$d"
find . -type f ! -path '*/target/*' ! -path './app-target/*' ! -name host ! -name host-tests ! -name evidence-files.sha256 -print0 | sort -z | xargs -0 sha256sum > evidence-files.sha256
sha256sum -c evidence-files.sha256 > /dev/null
tag=365-first-6f51e0b
tar --exclude=target --exclude=app-target --exclude=host-tests --exclude=host -czf "$prep/$tag.final.tar.gz" .
testdir=$(mktemp -d)
tar -xzf "$prep/$tag.final.tar.gz" -C "$testdir"
(cd "$testdir" && sha256sum -c evidence-files.sha256 > /dev/null && python3 report.py . | cmp - results.json)
cp "$d/results.json" "$prep/results.json"
cp "$d/REPORT.en-ko.md" "$prep/REPORT.en-ko.md"
cd "$prep"
sha256sum "$tag.final.tar.gz" > "$tag.final.tar.gz.sha256"
cat "$tag.final.tar.gz.sha256"
wc -c "$tag.final.tar.gz"
