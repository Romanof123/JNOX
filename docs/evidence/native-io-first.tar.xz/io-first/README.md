# JNOX native I/O first captures

This packet contains seven completed QEMU AArch64 virt guest runs and the earlier host-only X11 packaging failure. All measurements use one Cortex-A72 vCPU under TCG. The display service uses a guest RAM framebuffer on QEMU and polled PL011 serial input. The X11 run displays a remote window on an external Xvfb server. The diagnostic runs execute the native C shell. Physical-device behavior and a guest-resident X server require separate evidence.

## Offline replay

Verify the external SHA-256 sidecar, then extract the archive into an empty directory. Run `python3 -B io-first/replay.py` there. Python's standard library is sufficient. The verifier recomputes the internal file inventory, package and UART identities, image contents and profile-specific outcomes using the retained capture data.

## Source provenance

The build manifests name local commits. Each published commit below has the same complete Git root tree as its measured local commit. The evidence preserves the build-time revision. These runs were acquired before publication.

| Runs | Measured local commit | Published revision | Common Git root tree |
|---|---|---|---|
| #406 RAMFB and #407 remote X11 | `bdfb68cbebdf713c86107c8a9e608e3177d4a219` | [Public source](https://github.com/Romanof123/JNOX/tree/669d88c1bd2e12434bab3fe09c9ebeaf726ebab5) | `f538bc1b0b7f6d8777df483d482615da9f2a9cb7` |
| #408 shell diagnostics | `a154c7727f4ebdccdceee84b7cc2418a3119fb04` | [Public source](https://github.com/Romanof123/JNOX/tree/d9e098f856a6b30f0f31dea5cc28c05b8f69980a) | `172025caa3df35e14d2571a157aa49d9ec86b0bd` |

The `source` directory retains the actual capture programs, their reducer dependencies, and selected guest sources extracted from the measured commits. The published trees contain the complete build inputs.

## Retained observations

- **#406 RAMFB.** Three capture directories retain original kernel UART, QEMU invocation and outcome. The interactive case contains two original QMP PPM snapshots per state and lossless PNG copies. The verifier checks all 76,800 RGB pixels against the host drawing oracle for each state, the recorded stability intervals, and the recorded PL011 input sequence `n`, `q`. The owner exits 0 and the denied peer 61. The same kernel without RAMFB exits 19 and 61. The single-process package without the display service exits 38 with RAMFB present. Both frozen kernel ELFs, the native executables and their original manifests are included.
- **#407 remote X11.** The client's mapped 240 by 160 window occupies (32,32) on the 320 by 240 Xvfb screen. Original root-window PNGs preserve both visible states. The lower rectangle changes from red to blue after a recorded button-1 XTEST input. The original guest UART identifies the native client and network broker and records both exits 0. The original live observer recorded two-way relay counts and rejection of an invalid authentication cookie. The packet contains both exact native process ELFs. The measured kernel digest is retained in the status record. Its temporary package embedded an ephemeral X11 credential and was discarded. The retained status is an allowlisted derivative with the original digest. Only credential-free ELF and scheduler/device/exit records occur in the included raw UART. The packet contains no wire payloads or Xauthority files.
- **#407 first host preflight.** The first packaging attempt stopped when the host C linker could not find `liblto_plugin.so`. The retained excerpt quotes the relevant compiler lines. Both relay byte counts were zero and no guest launched. The subsequent successful reference capture is a separate attempt.
- **#408 shell diagnostics.** Each case retains raw UART, the original invocation, process status, the packaged kernel and all slot ELFs, a ROM and its manifest. The interactive operator entered `dmesg` twice and then `exit`. Both reads returned the same two initial records. The scripted pipeline produced 2, then reported four lifecycle records and two overwrites; repeating the read preserved the snapshot. The denied probe wrote a permission denial to its own stderr, exited 1, and produced a pipeline count of 0. Guest arguments in the display and shell manifests were checked against the declared commands before packaging.

Runtime-only facts such as elapsed intervals, relay counts, invalid-cookie rejection and input injection come from the original capture records. The offline replay verifies their recorded values and re-evaluates the retained pixels, native images and UART. Issue #410 has a separate capture.
