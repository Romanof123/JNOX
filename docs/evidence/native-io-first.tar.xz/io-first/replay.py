#!/usr/bin/env python3
"""Replay the retained JNOX display, remote X11 and kernel-log observations offline."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import sys
import zlib

sys.dont_write_bytecode = True

DISPLAY_REV = "bdfb68cbebdf713c86107c8a9e608e3177d4a219"
KLOG_REV = "a154c7727f4ebdccdceee84b7cc2418a3119fb04"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def png_rgb(path):
    # Both original capture programs use 8-bit RGB and PNG filter zero.
    data = path.read_bytes()
    require(data.startswith(b"\x89PNG\r\n\x1a\n"), f"{path}: PNG signature")
    pos = 8
    compressed = bytearray()
    chunks = []
    while pos < len(data):
        length = int.from_bytes(data[pos:pos + 4], "big")
        kind = data[pos+4:pos+8]
        payload = data[pos+8:pos+8+length]
        crc = data[pos+8+length:pos+12+length]
        require(len(crc) == 4 and int.from_bytes(crc, "big") == zlib.crc32(kind + payload), "PNG CRC")
        chunks.append(kind)
        if kind == b"IHDR":
            require(struct.unpack(">IIBBBBB", payload) == (320, 240, 8, 2, 0, 0, 0), "PNG format")
        if kind == b"IDAT":
            compressed.extend(payload)
        pos += 12 + length
    require(chunks == [b"IHDR", b"IDAT", b"IEND"], "unexpected capture PNG structure")
    raw = zlib.decompress(compressed)
    require(len(raw) == 961 * 240 and not any(raw[::961]), "PNG rows")
    return b"".join(raw[p+1:p+961] for p in range(0, len(raw), 961))


def boot_ids(raw, hashes):
    require(raw.startswith(b"JNOX M1 BOOT\nJNOX M1 READY\n") and b"NATIVE EL0 FAULT" not in raw, "boot or fault")
    identities = re.findall(rb"(?m)^NATIVE EL0 (?:PEER2? )?ELF ([0-9a-f]{64})\n", raw)
    require([s.decode() for s in identities] == hashes, "booted ELF identities do not match packaged slots")


def package(path, revision, raw):
    manifest = read(path / "manifest.json")
    require((manifest["commit"], manifest["tracked_changes"], manifest["board"], manifest["policy"])
            == (revision, "", "virt", "fifo"), f"{path}: build provenance")
    require(digest(path / "kernel.elf") == manifest["kernel_elf_sha256"], "kernel ELF digest")
    hashes = [digest(path / slot["elf"]) for slot in manifest["slots"]]
    require(hashes == [s["elf_sha256"] for s in manifest["slots"]], "package ELF digests")
    boot_ids(raw, hashes)
    return manifest


def check_display(root):
    from verify_native_display import expected_rgb, observed_exits
    base = root / "display"
    require(digest(root / "source/tools/verify_native_display.py") ==
            read(base / "observer.json")["verifier_sha256"], "display observer identity")
    for mode, expected in (("interaction", [(0, 0), (1, 61)]), ("absent", [(0, 19), (1, 61)]),
                           ("headless", [(None, 38)])):
        case = base / mode
        result, launch = read(case / "result.json"), read(case / "launch.json")
        for name, value in result["hashes"].items():
            require(digest(case / name) == value, f"{mode}/{name}: capture digest")
        uart = (case / "uart.bin").read_bytes()
        manifest = package(base / ("headless-package" if mode == "headless" else "display-package"), DISPLAY_REV, uart)
        require(result["kernel_sha256"] == launch["kernel_sha256"] == manifest["kernel_elf_sha256"], "capture kernel")
        require((result["mode"], result["pass"], result["qemu_status"]) == (mode, True, 0), "capture result")
        require(observed_exits(uart) == expected == [tuple(x) for x in result["native_exits"]], "guest exits")
        require(("ramfb,id=screen" in launch["argv"]) == (mode != "absent"), "RAMFB device presence")
        require(("display_service" in manifest) == (mode != "headless"), "display service selection")
        if mode != "headless":
            require(manifest["display_service"]["slot"] == 0 and manifest["slots"][1]["argv"] == ["/bin/app", "denied"],
                    "display access-control roles")
        if mode == "interaction":
            require([i["byte"] for i in result["input"]] == ["n", "q"] and
                    result["input"][0]["seconds"] < result["input"][1]["seconds"], "PL011 input sequence")
            for name, changed in (("before", False), ("after", True)):
                rgb = expected_rgb(changed)
                frame = result["frames"][name]
                require(frame["stable_seconds"] >= 0.2 and frame["rgb_sha256"] == hashlib.sha256(rgb).hexdigest(),
                        f"{name}: oracle or stability interval")
                for suffix in (".ppm", "-repeat.ppm"):
                    require((case / (name + suffix)).read_bytes() == b"P6\n320 240\n255\n" + rgb, f"{name}: scanout")
                require(png_rgb(case / (name + ".png")) == rgb, f"{name}: PNG pixels")
            print("PASS #406 interaction: both 76,800-pixel RAMFB states, repeat samples, PL011 n/q, owner 0 and denied peer 61")
        elif mode == "absent":
            print("PASS #406 absent RAMFB: same enabled kernel, owner 19 and denied peer 61")
        else:
            print("PASS #406 disabled service: RAMFB present, single-process exit 38")


def check_x11(root):
    failed = root / "x11/preflight"
    pre = read(failed / "outcome.json")
    require(pre["result"] == "failed" and pre["stage"] == "host guest-packaging" and not pre["guest_launched"] and
            pre["relay"] == {"to_server": 0, "to_guest": 0}, "first X11 preflight outcome")
    require("liblto_plugin.so not found" in (failed / "linker-excerpt.txt").read_text(), "first linker diagnostic")
    print("RECORDED #407 first preflight: host linker plugin missing, zero relay bytes, no guest launch")
    case = root / "x11/reference"
    status = read(case / "status.json")
    require(status["result"] == "passed" and status["invalid_cookie_rejected"] is True, "X reference result/auth")
    pkg = status["package"]
    require(pkg["commit"] == DISPLAY_REV and pkg["tracked_changes"] == "" and pkg["policy"] == "fifo", "X build provenance")
    require(pkg["socket_service"] == {"slot": 1, "authorized_clients": [0]} and pkg["net_service"]["slot"] == 1,
            "X process service configuration")
    hashes = [digest(case / "client.elf"), digest(case / "broker.elf")]
    require(hashes == [pkg["sha256"]["client"], pkg["sha256"]["broker"]] and
            pkg["sha256"]["kernel"] == "3583ae75a5cc1db16218629660da63692821edad1e3511a30ba5c4b77a8eabd7",
            "X ELF identities")
    raw = (case / "uart").read_bytes()
    boot_ids(raw, hashes)
    require(re.findall(rb"(?m)^NATIVE EL0 EXIT PID (\d+) (-?\d+)\n", raw) == [(b"0", b"0"), (b"1", b"0")] and
            status["guest_exits"] == [[0, 0], [1, 0]] and re.search(rb"(?m)^NATIVE NET DEVICE 1 ", raw), "X UART")
    require(status["relay"]["to_guest"] > 0 and status["relay"]["to_server"] > 0, "X relay traffic")
    require(status["geometry"] == [32, 32, 240, 160] and status["border_px"] == 0 and
            status["title"] == "JNOX X11 Mosaic" and status["window_id"] > 0, "X mapped window")
    require(status["input_method"] == "XTEST button 1 press/release" and status["input_relative_xy"] == [128, 110], "X input")
    for name, accent in (("before", "e85c50"), ("after", "498cf0")):
        image = case / (name + ".png")
        rgb = png_rgb(image)
        frame = status["frames"][name]
        require(digest(image) == frame["png_sha256"] and frame["matched_pixels"] == 240 * 160, "X frame identity")
        for y in range(160):
            for x in range(240):
                color = "182840"
                if 16 <= x < 80 and 16 <= y < 144:
                    color = "20b8a0"
                elif 96 <= x < 224 and 16 <= y < 64:
                    color = "f4b644"
                elif 96 <= x < 224 and 80 <= y < 144:
                    color = accent
                pos = 3 * ((y + 32) * 320 + x + 32)
                require(rgb[pos:pos+3] == bytes.fromhex(color), f"X {name} window pixel ({x},{y})")
    print("PASS #407 remote Xvfb: both 38,400-pixel window states, XTEST click, bidirectional TCP, client 0 and broker 0")


def check_klog(root):
    from verify_native_dmesg import verify
    for mode in ("interactive", "scripted", "denied"):
        case = root / "dmesg" / mode
        raw = (case / "capture/uart.bin").read_bytes()
        manifest = package(case / "package", KLOG_REV, raw)
        command = read(case / "capture/command.json")
        require(command["case"] == mode and command["kernel_sha256"] == manifest["kernel_elf_sha256"] and
                (case / "status").read_text().strip() == "0", "dmesg capture identity")
        rom = case / "package/native_shell.rom"
        require(digest(rom) == manifest["rom_sha256"], "ROM digest")
        entry, = manifest["rom_files"]
        data = rom.read_bytes()[entry["offset"]:entry["offset"] + entry["length"]]
        require(entry["name"] == "sample.txt" and data == b"one\ntwo\n" and
                hashlib.sha256(data).hexdigest() == entry["sha256"], "sample file identity")
        verify(raw, mode)
        if mode == "interactive":
            require((case / "capture/input.bin").read_bytes() == b"dmesg\ndmesg\nexit\n", "actual serial commands")
            coverage = "two live dmesg commands, identical snapshots, shell exit 0"
        else:
            require(raw.count(b"dmesg records=4 dropped=2\n") == 2, "repeated post-pipeline snapshots")
            coverage = ("child PID 1 stderr permission denial, exit 1, four retained records and two dropped" if mode == "denied"
                        else "cat | wc output 2, three clean exits, four retained records and two dropped")
        print(f"PASS #408 {mode}: {coverage}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", type=Path, default=Path(__file__).resolve().parent)
    root = parser.parse_args().root.resolve()
    checks = (root / "SHA256SUMS").read_text().splitlines()
    listed = set()
    for line in checks:
        value, name = line.split("  ", 1)
        require(name not in listed and digest(root / name) == value, f"inventory mismatch: {name}")
        listed.add(name)
    require(listed == {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()} - {"SHA256SUMS"},
            "unexpected or missing archive members")
    sys.path.insert(0, str(root / "source/tools"))
    check_display(root)
    check_x11(root)
    check_klog(root)
    print(f"PASS {len(checks)} file digests, 7 guest runs, 1 host preflight")


if __name__ == "__main__":
    main()
