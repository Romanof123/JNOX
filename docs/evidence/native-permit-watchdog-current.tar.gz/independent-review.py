from pathlib import Path
import json,struct,re,hashlib,subprocess
root=Path(__file__).resolve().parent
def sym(path):
    lines=subprocess.check_output(["llvm-nm","-S",path],text=True).splitlines()
    return {x[3]:(int(x[0],16),int(x[1],16)) for l in lines if len(x:=l.split())==4}
for d in sorted((root/"captures").iterdir()):
    ram=(d/"ram.bin").read_bytes()
    launch=json.loads((d/"launch.json").read_text())
    pkg=root/("pkg-"+d.name)
    manifest=json.loads((pkg/"manifest.json").read_text())
    assert launch["argument_package"]==manifest
    for f,h in json.loads((d/"session.json").read_text())["hashes"].items():
        assert hashlib.sha256(ram if f=="ram.bin" else (d/f).read_bytes()).hexdigest()==h
    assert (d/"kernel.elf").read_bytes()==(pkg/"kernel.elf").read_bytes()
    worker=(root/"worker.elf").read_bytes()
    assert all((pkg/name).read_bytes()==worker for name in ["user.elf","native_peer.elf","native_peer2.elf"]) and (d/"user.elf").read_bytes()==worker
    assert manifest["commit"]=="c5e6a374a9cc8107bfadb25db9c71f8d0d1666e2"
    ks=sym(d/"kernel.elf")
    rootpt,size=next(v for k,v in ks.items() if "native_el0_mmu6SPACES" in k)
    ws=sym(d/"user.elf")
    def row(pid,name,width,index=0):
        va=ws[name][0]+index*width*8
        page=rootpt+pid*(size//3)
        for shift in (30,21,12):
            desc,=struct.unpack_from("<Q",ram,page-launch["ram_base"]+8*((va>>shift)&511))
            assert desc&3==3
            page=desc&0x0000fffffffff000
        return struct.unpack_from("<"+"Q"*width,ram,page-launch["ram_base"]+(va&4095))
    lines=(d/"uart.bin").read_text().splitlines()
    def parse(prefix):
        return [list(map(int,l[len(prefix):].split())) for l in lines if l.startswith(prefix)]
    events=parse("NATIVE SAFETY EVENT ")
    irq=parse("NATIVE QUAL ROW ")
    wd=[r for r in events if r[0]==13]
    assert all(r[9]-r[8]==312501 for r in wd if r[2] in (2,3))
    assert parse("NATIVE EL0 EXIT PID ")==[[0,71],[1,72],[2,73]]
    assert parse("NATIVE SAFETY DROPPED ")==[[0]]
    assert all(row(i,"wd_header",6)[5]==0 for i in range(3))
    s=[row(2,"wd_supervisor_rows",13,i) for i in range(12)]
    c=[row(1,"wd_controller_rows",12,i) for i in range(29)]
    inj=row(1,"wd_injection",12)
    assert all(x[12]==0 for x in s)
    reg=[(r[2],r[3],r[4],r[5]) for r in events if r[0]==2]
    dues=[]
    for x in wd:
        if x[2]!=4: continue
        q,=[r for r in irq if r[1]==3 and r[5]==x[5] and r[2]<=x[6]<=r[11]]
        off=next(r for r in reg if r[0]>=x[6] and r[3]==0)
        dues.append((x[5],q[2]-x[5],x[6]-x[5],off[0]-x[5],off[1]-x[5],q[4],q[6],hex(q[7])))
    print(d.name,"irq(D,entry/decision/write/readback minus D,IAR,task,PC)",dues,"output",[r[3] for r in reg],"first/final supervisor flags",s[1][4],s[-1][4],"injection guard,late",inj[:2],inj[9],"pair delta", (lambda p:p[1]-p[0])(row(2,"wd_recovery_pair",5)))
    if "healthy" in d.name:
        stamps=[r[8] for r in wd if r[2] in (2,3)]
        print("healthy all",len(c),"post-target max,over1ms",max(x[9]-x[0] for x in c),sum(x[9]-x[0]>62500 for x in c),"interval max",max(b-a for a,b in zip(stamps,stamps[1:])),"qual phase end max",max(r[7]-r[6] for r in irq if r[1]==1 and r[2]==1 and r[5]==3))
