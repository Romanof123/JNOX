from pathlib import Path
import json,struct,subprocess,re,sys
root=Path(sys.argv[1])
for d in sorted(p for p in root.iterdir() if p.is_dir()):
 if not (d/'session.json').exists():continue
 log=(d/'uart.bin').read_text(errors='replace').splitlines()
 events=[list(map(int,x.split()[3:])) for x in log if len(x.split())==13 and x.startswith('NATIVE SAFETY EVENT ')]
 irq=[list(map(int,x.split()[3:])) for x in log if len(x.split())==16 and x.startswith('NATIVE QUAL ROW ') and x.split()[4]=='3']
 wd=[r for r in events if r[0]==13]
 due=[r for r in wd if r[2]==4]
 wr=[r[2:6] for r in events if r[0]==2]
 z={'marker':json.loads((d/'session.json').read_text())['marker'],'exits':[x for x in log if x.startswith('NATIVE EL0 EXIT')],'safety_drop':[x for x in log if x.startswith('NATIVE SAFETY DROPPED')],'wd_due':due,'wd_deadline_math':all(r[-1]==r[-2]+312501 for r in wd if r[2] in (2,3)),'register':wr,'irq':[[r for r in irq if r[2]<=v[6]<=r[-2] or r[5]==v[5]] for v in due],'roles_exit':[r for r in events if r[0]==8],'complete_late':[r for r in events if r[0]==5 and r[5]==2**64-110]}
 if (d/'ram.bin').exists():
  ram=(d/'ram.bin').read_bytes();base=json.loads((d/'launch.json').read_text())['ram_base']
  nm=subprocess.check_output(['llvm-nm','-S',d/'kernel.elf'],text=True)
  start,size=map(lambda x:int(x,16),re.search(r'([a-f0-9]+) ([a-f0-9]+) b \S+native_el0_mmu6SPACES',nm).groups())
  def rd(pid,va,n):
   page=start+pid*(size//3)
   for sh in [30,21,12]:
    desc=struct.unpack_from('<Q',ram,page-base+8*((va>>sh)&511))[0];assert desc&3==3
    page=desc&0xfffff000
   return struct.unpack_from('<'+'Q'*n,ram,page-base+(va&4095))
  z['headers']=[rd(i,0x406030,6) for i in range(3)]
  z['injection']=rd(1,0x4068f0,12);z['pair']=rd(2,0x406060,5)
  z['supervisor']=[rd(2,0x4063f0+104*k,13) for k in range(12)]
  z['sender']=[rd(0,0x4061c0+80*k,10) for k in range(7)]
  z['controller']=[rd(1,0x406950+96*k,12) for k in range(29)]
 (d/'first-observations.json').write_text(json.dumps(z,indent=1))
 print(d.name,z['marker'],[h[-1] for h in z.get('headers',[])],z.get('injection',[])[:2],[(r[6]-r[5],r[7]) for r in due],z.get('pair'),[(r[2],r[3]) for r in wr])