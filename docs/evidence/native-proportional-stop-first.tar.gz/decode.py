from pathlib import Path
import json,re,struct,subprocess,hashlib
b=Path(__file__).resolve().parent
d=b/"control/first"
def cmd(*args):return subprocess.check_output(args,text=True)
symbols=cmd("nm","-S",d/"kernel.elf").splitlines()
def sym(name):
    matches=[s.split() for s in symbols if name in s.split()[-1]]
    assert len(matches)==1
    return int(matches[0][0],16)
lines=(d/"uart.bin").read_text().splitlines()
pred,ev,fault=[list(map(int,l.split()[3:])) for l in lines if l.startswith("NATIVE PROP")]
assert lines[-1]=="NATIVE EL0 FAULT 24"
base=sym(" _start") if False else int(json.loads((d/"launch.json").read_text())["ram_base"])
r=(d/"ram0.bin").read_bytes()
assert r==(d/"ram1.bin").read_bytes()
def words(addr,n):return list(struct.unpack_from("<"+"Q"*n,r,addr-base))
assert words(sym("FIRST_REJECTION"),9)==[1]+pred
assert words(sym("GUARD_EVENT"),6)==ev
arm=words(next(int(s.split()[0],16) for s in symbols if s.endswith(" native_weighted_arm")),10)
assert pred==[17,10,1,0,0,0,ev[2]-arm[3],0] and arm[0]==fault[2]==0 and fault[1]==1
assert arm[4]==fault[4]==arm[1]+arm[3] and arm[8]==fault[6] and arm[5]&3==fault[5]==1
frame_sig=struct.pack("<5Q",fault[9],fault[8],fault[7],fault[10],4)
frames=[base+m.start()-248 for m in re.finditer(re.escape(frame_sig),r) if (base+m.start()-248)%16==0 and words(base+m.start()-248+64,1)==[8]]
assert len(frames)==1
regs=[json.loads((d/f"cpu{i}.json").read_text()) for i in range(2)]
pc=[int(re.search("PC=([0-9a-f]+)",c["registers"])[1],16) for c in regs]
assert pc[0]==pc[1] and regs[1]["host_ns"]>regs[0]["host_ns"]
def phys(va):
    table=fault[6]&0x0000fffffffff000
    for shift in [30,21,12]:
        entry=words(table+8*((va>>shift)&511),1)[0]
        assert entry&3==3
        table=entry&0x0000fffffffff000
    return table+(va&4095)
svc=fault[7]-4
mapped=phys(svc)
ins=struct.unpack_from("<I",r,mapped-base)[0]
assert ins&0xffe0001f==0xd4000001
print(json.dumps(dict(predicate=pred,event=ev,fault=fault,arm=arm,frame=hex(frames[0]),x=words(frames[0],31),svc=hex(svc),svc_pa=hex(mapped),instruction=hex(ins),park=hex(pc[0]),sample_elapsed_ns=regs[1]["host_ns"]-regs[0]["host_ns"],identical_ram=True),indent=2))
