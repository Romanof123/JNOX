import pathlib,subprocess,json,os
b=pathlib.Path("/home/ywcho/iv338-3bdc-park")
old=b.parent/"iv338-f3be-git"
os.chdir(b/"src")
os.environ["PATH"]=str(pathlib.Path.home()/".cargo/bin")+":"+os.environ["PATH"]
os.environ["RUSTUP_TOOLCHAIN"]="1.95.0"
for case in ["seed1","seed2","stable","dynlot","dynstride","solo","legacy"]:
    args=json.loads((old/("build-"+case+".log")).read_text().splitlines()[0])
    args[args.index("--out")+1]=str(b/("pkg-"+case))
    with (b/("build-"+case+".log")).open("w") as f:
        print(args,file=f,flush=True)
        subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)
    with (b/("compare-"+case+".log")).open("w") as f:
        p=subprocess.run(["python3","verification/native-proportional-stop/compare_loads.py",old/("pkg-"+case)/"kernel.elf",b/("pkg-"+case)/"kernel.elf"],stdout=f,stderr=subprocess.STDOUT)
    print(case,p.returncode,flush=True)
