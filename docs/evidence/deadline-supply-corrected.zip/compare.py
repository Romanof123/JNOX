from analyze import *
def sections(b):
 import struct
 off=struct.unpack_from('<Q',b,40)[0];size,num,si=struct.unpack_from('<HHH',b,58)
 rows=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*size) for i in range(num)]
 st=rows[si];names=b[st[4]:st[4]+st[5]]
 return {names[r[0]:].split(b'\0')[0].decode():b[r[4]:r[4]+r[5]] for r in rows if r[1]==1 and r[2]&2}
results=[]
for r in json.loads(z.read('manifest.json')):
 old=z.read(r['case']+'/kernel.elf');new=(base/'wsl'/r['case']/'kernel.elf').read_bytes();a=sections(old);b=sections(new)
 results.append(dict(case=r['case'],elf_sha=sha(new),load_sha=sha(load(new)),baseline_load=r['load_sha256'],new_load_bytes=len(load(new)),old_load_bytes=len(load(old)),identical_load=load(old)==load(new),sections={k:[len(a[k]),len(b[k]),a[k]==b[k]] for k in a.keys()&b.keys()}))
(base/'wsl-compare.json').write_text(json.dumps(results,indent=2))
for r in results:print(r['case'],r['identical_load'],r['sections']['.text'],r['sections'].get('.rodata'))
