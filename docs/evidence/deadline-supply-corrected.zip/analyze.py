import pathlib,zipfile,json,struct,re,hashlib
base=pathlib.Path(__file__).parent
repo=pathlib.Path('D:/codex/jnox-independent-608')
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(b):
 off=struct.unpack_from('<Q',b,32)[0];size,num=struct.unpack_from('<HH',b,54)
 rows=[struct.unpack_from('<IIQQQQQQ',b,off+i*size) for i in range(num)]
 return b''.join(b[r[2]:r[2]+r[5]] for r in rows if r[0]==1)
z=zipfile.ZipFile(repo/'docs/evidence/deadline-cooperative-legacy-loads.zip')
hashes=[]
for r in json.loads(z.read('manifest.json')):
 app,mode=r['case'].rsplit('-',1);old=z.read(r['case']+'/kernel.elf');new=(base/('cold-'+mode+'-'+app)/'kernel.elf').read_bytes()
 assert sha(old)==r['elf_sha256'] and sha(load(old))==r['load_sha256']
 hashes.append(dict(case=r['case'],baseline_elf=sha(old),candidate_elf=sha(new),baseline_load=sha(load(old)),candidate_load=sha(load(new)),same_load=load(old)==load(new)))
(base/'legacy-hashes.json').write_text(json.dumps(hashes,indent=2))
print('identical loads',[(r['case'],r['same_load']) for r in hashes])
summary={}
for d in sorted(base.glob('cold-*-ordinary-*')):
 txt=(d/'uart').read_text();rows=lambda tag:[[int(x) for x in l.split()[1:]] for l in txt.splitlines() if l.startswith(tag+' ')]
 conf,=rows('CONFIG');hz,s,q,*_=conf;events=rows('D');js=rows('J');jobs=rows('JOB');stop=rows('A_STOP');pr=rows('A_PROGRESS');result=rows('RESULT')
 name=d.name;sup='supply' in name;trace='-trace-' in name;ref='refuse' in name
 ex=(d/'exceptions.log').read_text()
 kinds=re.findall(r'Taking exception \d+ \[(IRQ|SVC)\]',ex)
 if ref: assert not jobs and not kinds and conf[5]==(9 if 'llf' in name else 8)
 else: assert 'ORDINARY DEADLINE FINISHED' in txt
 details=dict(config=conf,elf=sha((d/'kernel.elf').read_bytes()),exceptions=kinds,stop=stop,progress=pr)
 if sup and not ref:
  assert stop==[[s+hz//4]] and pr[0][2]>pr[0][0]==pr[0][1]>0 and result[0][0]==sum(i*i for i in range(1,65))
 if trace and not ref:
  assert kinds==['IRQ' if e[0]==1 else 'SVC' for e in events]
  assert [e[12] for e in events]==[int(v,16) for v in re.findall(r'with ELR (0x\w+)',ex)]
  observed=[int(v,16) for v in re.findall(r'Exception return .*? PC (0x\w+)',ex)][1:]
  assert observed==[e[14] for e in events][:len(observed)] and len(observed)>=len(events)-1
  counts=[0]*3; ticks=[0]*3; grid=0;completed=[];slack=[];paused={}
  for i,e in enumerate(events):
   kind,k,g,t,prog,iar,rest,entry,h,out,dst,fp,pc,df,dp,queue,rel,exhaust,miss=e
   j=js[i*3:i*3+3]
   assert len(j)==3 and k==(entry-s)//q and g==grid and t==s+q*g and not miss
   if out<3:
    ticks[out]+=k-events[i-1][1];counts[out]+=entry-rest
   assert ticks==[r[3] for r in j] and counts==[r[4] for r in j]
   if kind==1:
    assert iar&1023==30 and prog==t and g==k;grid+=1
    if out<3 and dst!=out:paused[out]=(fp,pc)
   else:
    assert k<grid and out not in completed; completed.append(out);delta=s+q*jobs[out][2]-entry; assert delta>=0;slack.append(delta)
   if dst in paused:assert paused.pop(dst)==(df,dp)
  assert sorted(completed)==list(range(len(jobs)))
  details.update(completion=completed,margin_counts=slack,phases=[[x[0],x[1],x[9],x[10]] for x in events],service_counts=counts)
  if sup:
   assert [(e[0],e[9],e[10]) for e in events]==[(1,3,0),(1,0,4),(1,4,0),(2,0,1),(2,1,3)] or len(events)>5
   for i in (0,1):
    blocks=js[-3+i][5];n=blocks*64;m=2**64;val=((pow(33,n,32*m)-1)//32+(i+1)*pow(33,n,m))%m
    assert val==result[0][2+i]
   details.update(reservation_counts=events[2][7]-events[2][6],frame_pc=events[1][11:13],blocks=[j[5] for j in js[-3:-1]],products=result[0][2:])
  elif 'edf' in name:
   assert events[0][10]==0 and events[1][10]==2 and completed==[2,0,1]
   if 'overrun' in name:assert any(e[17]&1 and any(r[9]==0 and r[7]>e[7] for r in events[i+1:]) for i,e in enumerate(events))
  else:
   assert all(e[10]==1 for e in events[:6]) and events[6][10]==0 and events[7][10]==1
   if 'overload' in name:assert events[8][10]==2 and events[9][10]==1 and js[8*3+2][2]==-2
 summary[name]=details
(base/'independent-rows.json').write_text(json.dumps(summary,indent=2))
