import os,pathlib,subprocess,sys,shutil,hashlib
base=pathlib.Path(__file__).parent
repo=pathlib.Path('D:/codex/jnox-independent-608')
apps=['ordinary-edf-supply-refuse','ordinary-llf-supply-refuse','ordinary-edf-supply','ordinary-llf-supply']
if 'legacy' in sys.argv: apps=['ordinary-edf','ordinary-llf','ordinary-llf-overload','ordinary-edf-overrun']
for mode in ['trace','plain']:
 for app in apps:
  dest=base/(mode+'-'+app);dest.mkdir()
  env=dict(os.environ,JNOX_BOARD='virt',JNOX_PROFILE='deadline',JNOX_APP=app)
  if mode=='trace':env['JNOX_DEADLINE_TRACE']='1'
  else:env.pop('JNOX_DEADLINE_TRACE',None)
  with (dest/'build.log').open('wb') as f:subprocess.run(['cargo','build','--locked','--release','-j1'],cwd=repo/'kernel',env=env,stdout=f,stderr=f,check=True)
  elf=dest/'kernel.elf';shutil.copy2(repo/'kernel/target/aarch64-unknown-none/release/jnox-kernel',elf)
  unix='/mnt/d/codex/'+base.name+'/'+dest.name
  cmd=['wsl','python3','/mnt/d/codex/'+repo.name+'/tools/qemu_boot.py','--kernel',unix+'/kernel.elf','--profile','deadline','--runs','1','--timeout','10','--capture-dir',unix+'/raw']
  (dest/'command.txt').write_text(' '.join(cmd)+'\n'+str({k:v for k,v in env.items() if k.startswith('JNOX_')})+'\n'+hashlib.sha256(elf.read_bytes()).hexdigest())
  with (dest/'harness.log').open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=f)
  print(dest.name,r.returncode,flush=True)
