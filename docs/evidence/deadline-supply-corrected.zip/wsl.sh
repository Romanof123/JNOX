set -eu
src=/mnt/d/codex/jnox-independent-608
out=/mnt/d/codex/jnox-608-independent-evidence/wsl
export CARGO_HOME=/home/ywcho/jnox-169-first-e203caa/cargo RUSTUP_HOME=/home/ywcho/jnox-169-first-e203caa/rustup
export PATH="$CARGO_HOME/bin:$PATH" CARGO_TARGET_DIR=$(mktemp -d)
cd "$src/kernel"
mkdir -p "$out"
rustc -vV > "$out/toolchain.txt"
for app in ordinary-edf ordinary-llf ordinary-llf-overload ordinary-edf-overrun coop-events coop-single; do
 profile=deadline; modes="plain trace"
 case "$app" in coop-*) profile=fixed; modes=plain;; esac
 for mode in $modes; do
  d="$out/$app-$mode"; mkdir "$d"
  opts=("JNOX_BOARD=virt" "JNOX_PROFILE=$profile" "JNOX_APP=$app")
  if [[ $mode == trace ]]; then opts+=(JNOX_DEADLINE_TRACE=1); fi
  (set -x; env "${opts[@]}" cargo +1.95.0 build --locked --release -j1) > "$d/build.log" 2>&1
  cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" "$d/kernel.elf"
 done
done