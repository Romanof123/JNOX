import subprocess,pathlib,sys,os,shutil,hashlib
base=pathlib.Path(__file__).parent
repo=pathlib.Path('D:/codex/jnox-independent-608')
apps=['ordinary-edf-supply-refuse','ordinary-llf-supply-refuse','ordinary-edf-supply','ordinary-llf-supply']
legacy='legacy' in sys.argv
if legacy:apps=['ordinary-edf','ordinary-llf','ordinary-llf-overload','ordinary-edf-overrun','coop-events','coop-single']
for mode in ['trace','plain']:
 for app in apps:
  coop=app.startswith('coop')
  if coop and mode=='trace':continue
  dest=base/('cold-'+mode+'-'+app);dest.mkdir();elf=dest/'kernel.elf'
  if legacy:
   env=dict(os.environ,JNOX_BOARD='virt',JNOX_PROFILE='fixed' if coop else 'deadline',JNOX_APP=app)
   if mode=='trace':env['JNOX_DEADLINE_TRACE']='1'
   with (dest/'build.log').open('wb') as f:subprocess.run(['cargo','build','--locked','--release','-j1'],cwd=repo/'kernel',env=env,stdout=f,stderr=f,check=True)
   shutil.copy2(repo/'kernel/target/aarch64-unknown-none/release/jnox-kernel',elf)
  else:shutil.copy2(base/(mode+'-'+app)/'kernel.elf',elf)
  unix='/mnt/d/codex/'+base.name+'/'+dest.name
  cmd=['wsl','timeout','4','qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-accel','tcg','-smp','1','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','stdio','-d','int','-D',unix+'/exceptions.log','-kernel',unix+'/kernel.elf']
  (dest/'command.txt').write_text(' '.join(cmd)+'\n'+hashlib.sha256(elf.read_bytes()).hexdigest())
  with (dest/'uart').open('wb') as f,(dest/'stderr').open('wb') as e:r=subprocess.run(cmd,stdout=f,stderr=e)
  print(dest.name,(dest/'uart').read_bytes()[-120:],flush=True)

