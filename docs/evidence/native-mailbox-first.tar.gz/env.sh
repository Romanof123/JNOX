#!/usr/bin/env bash
set -euo pipefail
export PATH="${HOME}/.cargo/bin:${PATH}"
export LC_ALL=C
export PYTHONDONTWRITEBYTECODE=1
export JNOX_VERIFY_WORK="${JNOX_VERIFY_WORK:-${HOME}/jnox-367-first}"
