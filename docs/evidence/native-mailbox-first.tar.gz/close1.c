#include <jnox/mailbox.h>
int main(void) {
    return jnox_mailbox_send(0, 10, 0) == -13 ? 74 : 94;
}
