#include <jnox/mailbox.h>
#include <time.h>
int main(void) {
    const struct timespec wait = {.tv_sec=0,.tv_nsec=400000000};
    if (clock_nanosleep(CLOCK_MONOTONIC, 0, &wait, 0)) return 83;
    const uint64_t words[] = {0, UINT64_MAX, 0xff00112233445566ULL, 0x7000000000000000ULL};
    for (int i=0; i<4; ++i) {
        jnox_mailbox_result r = jnox_mailbox_receive(0);
        if (r.status || r.word!=words[i]) return 84+i;
    }
    return jnox_mailbox_receive(0).status == -11 ? 72 : 88;
}
