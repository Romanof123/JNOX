#include <jnox/mailbox.h>
int main(void) {
    for (int i=0;i<4;i++) if (jnox_mailbox_send(1, (uint64_t)i, 0)) return 81;
    if (jnox_mailbox_send(1, 0xa55a, UINT64_MAX) != -32) return 82;
    if (jnox_mailbox_send(1, 0x9876, 0) != -32) return 83;
    return 73;
}
