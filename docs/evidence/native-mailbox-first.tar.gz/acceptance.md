# IPC-002 independent acceptance

Frozen before source review and execution. Target is native AArch64 single-core QEMU virt, real C/Rust ELF package, FIFO and RR. Sources are Romanof123/JNOX #367 and #24.

| Case | Required observation |
| --- | --- |
| A | For both policies rebuild the supplied C and Rust examples and boot the native package. PID 0 exits 51, PID 1 exits 52. Verify actual selected routes, policy and ELF identities. |
| B | Four words with distinct values enqueue in order. Zero-deadline fifth send returns EAGAIN. A fifth word submitted with a finite deadline expires ETIMEDOUT before drain. Only the original four return, in order and exactly once. Empty immediate receive returns EAGAIN. |
| C | Before a pending sender's deadline, dequeue commits exactly one saved word, with preserved ring/waiter FIFO; at equality and afterwards timeout wins and the word never appears. Verify independent waiters, UINT64_MAX waiting, direct handoff to an already waiting receiver and one wakeup/result per wait. |
| D | Empty finite receive times out at equality and a later send remains available. Explicit capability direction rejects the inverse. A receiver reads its own endpoint. An absent or wrong profile cannot silently grant mailbox operations. |
| E | Sender exit cancels its pending word but preserves already committed words; owner exit discards slots and cancels pending waiters. A delivered or expired result cannot be delivered a second time. Measure actual peak and terminal slots/pending waiters, if instrumented. |
| F | Check sync-only, mailbox-only and mixed declared routes with native packaging. Replay the earlier synchronous example for FIFO and RR, verifying its declared exit statuses. Scope every claim by guest, host or source. |

Record commit, tree cleanliness, exact commands, pass/fail statuses, raw stdout, SHA-256 and gaps. Guest exit codes alone do not establish overflow, ordering or cleanup.
