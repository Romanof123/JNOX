#include <jnox/mailbox.h>
int main(void) {
    if (jnox_mailbox_send(0, 0x543, 0) != -38) return 95;
    return jnox_mailbox_receive(0).status == -38 ? 75 : 96;
}
