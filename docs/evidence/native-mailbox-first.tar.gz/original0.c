#include <jnox/mailbox.h>
#include <time.h>
int main(void) {
    const uint64_t words[] = {0, UINT64_MAX, 0xff00112233445566ULL, 0x7000000000000000ULL};
    for (int i=0; i<4; ++i) if (jnox_mailbox_send(1, words[i], 0)) return 81;
    if (jnox_mailbox_send(1, 0xdeadbeefUL, 0) != -11) return 82;
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts)) return 83;
    uint64_t now = (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
    if (jnox_mailbox_send(1, 0x5555, now + 100000000) != -110) return 84;
    return 71;
}
