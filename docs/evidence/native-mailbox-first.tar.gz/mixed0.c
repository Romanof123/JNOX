#include <jnox/ipc.h>
#include <jnox/mailbox.h>
#include <stdint.h>
int main(void) {
    if (jnox_ipc_call(1, 4, 0).status != -13) return 91;
    if (jnox_mailbox_send(1, 0xcafe1234abcdef01ULL, 0) != 0) return 92;
    jnox_ipc_request req = jnox_ipc_receive();
    if (req.status || req.word != 25) return 93;
    if (jnox_ipc_reply(req.token, req.word + 17) != 0) return 94;
    return 61;
}
