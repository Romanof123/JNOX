#!/usr/bin/env bash
set -euo pipefail
E=$(cd "$(dirname "$0")"; pwd)
source "$E/env.sh"
if [[ ! -e "$JNOX_VERIFY_WORK/.git" ]]; then
    git clone -q --no-checkout "${JNOX_VERIFY_GIT:-https://github.com/Romanof123/JNOX.git}" "$JNOX_VERIFY_WORK"
    if ! git -C "$JNOX_VERIFY_WORK" cat-file -e 1f9a56354e5b8fa04251fc5101e28ec0d83dad85^{commit} 2>/dev/null; then
        git -C "$JNOX_VERIFY_WORK" cat-file -e ced837c6349a62cee081bf537b0d5a347a86995f^{commit}
        git -C "$JNOX_VERIFY_WORK" index-pack --stdin < "$E/local-source.pack"
    fi
    git -C "$JNOX_VERIFY_WORK" checkout -q --detach 1f9a56354e5b8fa04251fc5101e28ec0d83dad85
fi
cd "$JNOX_VERIFY_WORK"
test "$(git rev-parse HEAD^{tree})" = b50b4ce3969715a3229924011f976ef5fee794eb
out="${JNOX_VERIFY_OUT:-$HOME/mb367-first-build}"
mkdir -p "$out"
sh sdk/native-aarch64/build.sh examples/native-mailbox/sender.c "$out/sender.elf"
sh sdk/native-aarch64/build-rust.sh examples/native-mailbox/receiver/Cargo.toml "$out/receiver.elf"
sh sdk/native-aarch64/build.sh examples/native-sync-ipc/client.c "$out/client.elf"
sh sdk/native-aarch64/build-rust.sh examples/native-sync-ipc/server/Cargo.toml "$out/server.elf"
for app in mixed0 mixed1 original0 original1 close0 close1 disabled; do
    sh sdk/native-aarch64/build.sh "$E/$app.c" "$out/$app.elf"
done
for kind in ${CASES:-mail sync mixed original close disabled}; do
    for policy in fifo rr; do
        flags=()
        [[ "$policy" == fifo ]] || flags+=(--quantum-ticks 625000)
        if [[ "$kind" == mail ]]; then
            a=sender; b=receiver; status=51; priority=7; peer=1
            source=examples/native-mailbox/sender.c; flags+=(--mailbox-route 0:1)
        elif [[ "$kind" == sync ]]; then
            a=client; b=server; status=41; priority=7; peer=1
            source=examples/native-sync-ipc/client.c; flags+=(--ipc-route 0:1)
        elif [[ "$kind" == mixed ]]; then
            a=mixed0; b=mixed1; status=61; priority=1; peer=7
            source="$E/mixed0.c"; flags+=(--ipc-route 1:0 --mailbox-route 0:1)
        elif [[ "$kind" == original ]]; then
            a=original0; b=original1; status=71; priority=7; peer=1
            source="$E/original0.c"; flags+=(--mailbox-route 0:1)
        elif [[ "$kind" == close ]]; then
            a=close0; b=close1; status=73; priority=7; peer=1
            source="$E/close0.c"; flags+=(--mailbox-route 0:1)
        else
            a=disabled; b=disabled; status=75; priority=7; peer=1
            source="$E/disabled.c"; flags+=(--ipc-route 0:1)
        fi
        pkg="$out/$kind-$policy"
        python3 tools/build_native_el0.py --out "$pkg" --policy "$policy" --priority "$priority" --peer-priority "$peer" --elf "$out/$a.elf" --peer-elf "$out/$b.elf" "${flags[@]}"
        python3 tools/native_el0_capture.py "$out/cap-$kind-$policy" "$pkg/kernel.elf" "$pkg/user.elf" "$source" "$(git rev-parse HEAD)" --plain --expect-exit "$status"
        tail -3 "$out/cap-$kind-$policy/uart.bin"
    done
done
