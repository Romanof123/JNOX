use mailbox_ipc::MailboxIpc;
mod mailbox_ipc;

type Mail = MailboxIpc<3>;
const NO_WAIT: u64 = 0;
const FOREVER: u64 = u64::MAX;
fn done(m: &mut Mail, p: usize, status: i32, word: u64) {
    let result = m.take(p).unwrap();
    assert_eq!((result.status, result.x1, result.x2), (status, word, 0));
    assert!(m.take(p).is_none());
    assert!(!m.blocked(p));
}
fn filled() -> Mail {
    let mut m = Mail::new([4, 4, 0]);
    for w in 1..=4 {
        m.send(0, 2, w, NO_WAIT, 0).unwrap();
        done(&mut m, 0, 0, 0);
        assert_eq!(m.occupancy(2), w as usize);
    }
    assert_eq!(m.high_water(2), 4);
    m
}
fn drain(m: &mut Mail, now: u64, expected: &[u64]) {
    for &w in expected {
        m.receive(2, NO_WAIT, now).unwrap();
        done(m, 2, 0, w);
    }
    assert_eq!(m.receive(2, NO_WAIT, now), Err(-11));
    assert_eq!((m.occupancy(2), m.high_water(2)), (0,4));
}
fn main() {
    for tick in [9,10,11] {
        let mut m=filled();
        assert_eq!(m.send(0,2,0xdead,NO_WAIT,1),Err(-11));
        m.send(1,2,11,10,2).unwrap();
        assert!(m.blocked(1)); assert_eq!(m.next_deadline(),Some(10));
        assert_eq!(m.send(1,2,0xdeaf,FOREVER,2),Err(-16));
        m.send(0,2,22,FOREVER,3).unwrap();
        m.receive(2,0,tick).unwrap();
        done(&mut m,2,0,1);
        done(&mut m,1,if tick<10 {0} else {-110},0);
        assert_eq!((m.occupancy(2),m.high_water(2)),(4,4));
        if tick<10 {drain(&mut m,tick,&[2,3,4,11,22]);} else {drain(&mut m,tick,&[2,3,4,22]);}
        done(&mut m,0,0,0); assert_eq!(m.next_deadline(),None);
        println!("sender release={} cutoff=10 timed_status={} queue_at_release=4 terminal=0 peak=4",tick,if tick<10 {0} else {-110});
    }
    for when in [7,8,9] {
        let mut m=Mail::new([4,4,0]); m.receive(2,8,1).unwrap();
        assert!(m.blocked(2));
        m.send(0,2,u64::MAX,0,when).unwrap();
        done(&mut m,0,0,0);
        if when<8 {done(&mut m,2,0,u64::MAX);assert_eq!(m.high_water(2),0);}
        else {done(&mut m,2,-110,0);m.receive(2,0,when).unwrap();done(&mut m,2,0,u64::MAX);assert_eq!(m.high_water(2),1);}
        assert_eq!(m.occupancy(2),0);
        println!("receiver send={} cutoff=8 terminal=0 peak={}",when,m.high_water(2));
    }
    let mut m=filled();
    m.send(0,2,100,FOREVER,0).unwrap();m.send(1,2,101,FOREVER,1).unwrap();
    m.exit(0,2); assert!(m.take(0).is_none()); assert!(!m.blocked(0));
    drain(&mut m,2,&[1,2,3,4,101]); done(&mut m,1,0,0);
    assert_eq!(m.send(0,2,102,0,2),Err(-3));
    println!("sender exit preserved=[1,2,3,4] discarded=100 promoted=101 dead sender=-3");
    for at in [9,10,11] {
        let mut m=filled(); m.send(0,2,100,10,0).unwrap(); m.send(1,2,99,FOREVER,0).unwrap();
        m.exit(2,at); done(&mut m,0,if at<10 {-32} else {-110},0); done(&mut m,1,-32,0);
        assert_eq!((m.occupancy(2),m.high_water(2)),(0,4));
        assert_eq!(m.send(0,2,103,FOREVER,at),Err(-32)); assert_eq!(m.receive(2,0,at),Err(-3));
        m.exit(2,at); assert!(m.take(0).is_none()); assert!(m.take(1).is_none());
        println!("owner closure={} cutoff=10 terminal=0 peak=4 waiters=0",at);
    }
    let mut m=Mail::new([4,0,0]); assert_eq!(m.send(2,0,111,0,0),Err(-13));
    assert_eq!(m.send(1,2,111,0,0),Err(-13)); assert_eq!(m.send(0,3,111,0,0),Err(-22));
    m.receive(2,FOREVER,0).unwrap(); assert_eq!(m.next_deadline(),None);
    m.advance(u64::MAX); assert!(m.blocked(2)); m.send(0,2,0,FOREVER,u64::MAX).unwrap();
    done(&mut m,2,0,0); done(&mut m,0,0,0); assert_eq!(m.high_water(2),0);
    println!("reverse/undeclared=-13 unavailable id=-22 UINT64_MAX wait resumed once; direct word=0 peak=0");
}
