#include <jnox/ipc.h>
#include <jnox/mailbox.h>
#include <stdint.h>
int main(void) {
    if (jnox_mailbox_send(0, 4, 0) != -13) return 95;
    jnox_mailbox_result r = jnox_mailbox_receive(UINT64_MAX);
    if (r.status || r.word != 0xcafe1234abcdef01ULL) return 96;
    jnox_ipc_response reply = jnox_ipc_call(0, 25, UINT64_MAX);
    if (reply.status || reply.word != 42) return 97;
    return 62;
}
