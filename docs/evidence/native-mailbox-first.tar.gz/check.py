#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import sys

root = Path(sys.argv[1])
names = {"mail":(51,52), "mixed":(61,62), "original":(71,72), "sync":(41,42), "close":(73,74), "disabled":(75,75)}
none = 2**64 - 1
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def symbols(path):
    return subprocess.check_output(["aarch64-linux-gnu-nm","-Sn",str(path)],text=True)
def variable(elf, key):
    hits = [row.split() for row in symbols(elf).splitlines() if row.split()[-1]==key]
    assert len(hits)==1, (key,hits)
    return int(hits[0][0],16),int(hits[0][1],16)
def decode(cap, pkg, kind):
    kernel = symbols(pkg/"kernel.elf")
    [(start,size)] = [(int(a,16),int(b,16)) for a,b in re.findall(r"(?m)^([0-9a-f]+) ([0-9a-f]+) . \S*native_el0_mmu6SPACES\S*$",kernel)]
    raw = (cap/"ram.bin").read_bytes()
    base = json.loads((cap/"launch.json").read_text())["ram_base"]
    def read(pa):
        i = pa - base
        assert 0 <= i <= len(raw)-8
        return struct.unpack_from("<Q",raw,i)[0]
    keys = [["mailbox_send_status","mailbox_send_times"],["mailbox_received","mailbox_empty_status","mailbox_reading_sum"]] if kind=="mail" else [["ipc_request_word","ipc_call_status","ipc_reply_word"],["ipc_server_words","ipc_reply_statuses"]]
    result = {}
    for pid,syms in enumerate(keys):
        elf = pkg/("native_peer.elf" if pid else "user.elf")
        for key in syms:
            va,count=variable(elf,key)
            words=[]
            for v in range(va,va+count,8):
                tab=start+pid*(size//2)
                for shift in (30,21,12):
                    desc=read(tab+8*((v >> shift)&511))
                    assert desc & 3 == 3
                    tab=desc & 0xfffff000
                val=read(tab+(v&4095))
                if "status" in key and val>=2**63: val-=2**64
                words.append(val)
            result[key]=words
    if kind=="mail":
        assert result["mailbox_send_status"]==[0,0,0,0,-11,-110,0]
        start,due,resumed=result["mailbox_send_times"]
        assert due-start==100000000 and resumed>=due
        assert result["mailbox_received"]==[(i<<32)+v for i,v in enumerate([300,512,257,1025,88],1)]
        assert result["mailbox_empty_status"]==[-11] and result["mailbox_reading_sum"]==[2182]
    else:
        req,reply=result["ipc_request_word"][0], result["ipc_reply_word"][0]
        assert req==sum(n<<(16*i) for i,n in enumerate([300,512,257,1025]))
        assert reply==0x000404010101082e
        assert result["ipc_call_status"]==[0] and result["ipc_reply_statuses"]==[-116,0,-116]
        assert result["ipc_server_words"][1:]==[req,reply]
    return result

all_rows=[]
for kind,expected in names.items():
    for policy in ("fifo","rr"):
        name=f"{kind}-{policy}"; cap=root/("cap-"+name); pkg=root/name
        uart=(cap/"uart.bin").read_text(); man=json.loads((pkg/"manifest.json").read_text())
        assert man["policy"]==policy and man["board"]=="virt" and man["tracked_changes"]==""
        assert man["commit"]=="1f9a56354e5b8fa04251fc5101e28ec0d83dad85"
        assert man["kernel_elf_sha256"]==digest(pkg/"kernel.elf")==digest(cap/"kernel.elf")
        assert man["slots"][0]["elf_sha256"]==digest(pkg/"user.elf") and man["slots"][0]["elf_sha256"] in uart
        assert man["slots"][1]["elf_sha256"]==digest(pkg/"native_peer.elf") and man["slots"][1]["elf_sha256"] in uart
        assert re.findall(r"(?m)^NATIVE EL0 EXIT PID (\d+) (\d+)$",uart)==[("0",str(expected[0])),("1",str(expected[1]))]
        assert "NATIVE FIXED DROPPED 0\n" in uart and "FAULT" not in uart
        rows=[list(map(int,s.split())) for s in re.findall(r"(?m)^NATIVE FIXED EVENT (.*)$",uart)]
        assert rows and all(len(r)==21 for r in rows)
        states=[list(map(int,s.split())) for s in re.findall(r"(?m)^NATIVE MAILBOX STATE (.*)$",uart)]
        want_states = [] if kind in ("sync","disabled") else [[0,0,0],[1,0,0 if kind=="mixed" else 4]]
        assert states==want_states, (name,states)
        if kind in ("mail","original"):
            sends=[r for r in rows if r[1]==24]; gets=[r for r in rows if r[1]==25]
            assert len(sends)==(7 if kind=="mail" else 6) and len(gets)==(6 if kind=="mail" else 5)
            assert all(r[3:5]==[0,0] for r in sends[:5]) and sends[5][3:5]==[0,1]
            assert any(r[1]==4 and r[3:5]==[none,0] and r[0]>=sends[5][11]>sends[5][0] for r in rows)
            if kind=="mail":
                assert sends[6][3:5]==[0,none] and gets[0][3:5]==[1,0]
                assert any(r[1]==3 and r[3:5]==[0,1] and gets[0][0]<r[0]<gets[1][0] for r in rows)
            else:
                assert any(r[1]==3 and r[3]==0 and r[0]<gets[0][0] for r in rows)
        if kind=="mixed":
            assert [r[1] for r in rows].count(24)==2 and [r[1] for r in rows].count(21)==2
            assert any(r[1]==25 and r[3:5]==[1,0] for r in rows)
        if kind=="close":
            assert any(r[1]==3 and r[3:5]==[1,0] for r in rows)
        output=dict(case=name,exits=expected,endpoint_state=states,events=len(rows),kernel=man["kernel_elf_sha256"],user=man["slots"][0]["elf_sha256"],peer=man["slots"][1]["elf_sha256"],uart=digest(cap/"uart.bin"),ram=digest(cap/"ram.bin"))
        if kind in ("mail","sync"): output["private"]=decode(cap,pkg,kind)
        all_rows.append(output)
print(json.dumps(all_rows,indent=2))
