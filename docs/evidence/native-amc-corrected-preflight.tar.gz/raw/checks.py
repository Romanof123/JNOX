import hashlib, json, os, pathlib, shlex, subprocess, sys
p=pathlib.Path
root=p(__file__).resolve().parent
raw=root/'raw'
source=root/'source'
out=source/'output/native-amc'
sha=lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
for name in ['within-lo','normal-hi']:
    package=out/name
    orig=source/'examples/native-amc/config'/(name+'.json')
    manifest=json.loads((package/'manifest.json').read_text())
    assert manifest['amc']==json.loads(orig.read_text())
    assert manifest['amc_input']['sha256']==sha(orig)
    assert manifest['amc_canonical']['sha256']==sha(package/'amc-v1.txt')
    assert manifest['kernel_elf_sha256']==sha(package/'kernel.elf')
    assert manifest['tracked_changes']=='' and manifest['commit']=='84af5040cdf3d969484897e10c45926515075717'
    assert len(manifest['slots'])=={'within-lo':2,'normal-hi':4}[name]
    for slot,task in zip(manifest['slots'],manifest['amc']['tasks']):
        assert slot['amc_task']==task and slot['argv']==['/bin/app',*task['argv'][0]]
        assert slot['elf_sha256']==sha(package/slot['elf'])==sha(out/('slot%s.elf'%slot['slot']))
    (raw/(name+'.product-check')).write_text(f'verified package inputs, ordered slot hashes and argv for {len(manifest["slots"])} slots, canonical and kernel digests\n')
valid=out/'within-lo/amc-v1.txt'
bad=root/'invalid-budget-canonical.txt'
wire=valid.read_text()
assert wire.count('task LO 1 2 2 3 16 1 1')==1
bad.write_text(wire.replace('task LO 1 2 2 3 16 1 1','task LO 1 0 2 3 16 1 1'))
for label,case,canonical,n,extra in [
    ('raw-invalid-budget','within-lo',bad,2,None),
    ('raw-stale-digest','within-lo',valid,2,None),
    ('raw-fifth','normal-hi',out/'normal-hi/amc-v1.txt',4,'slot0.elf')
]:
    overrides=dict(JNOX_PROFILE='native', JNOX_APP='process', JNOX_BOARD='virt', JNOX_NATIVE_POLICY='amc', JNOX_NATIVE_AMC_MANIFEST=str(canonical), JNOX_NATIVE_AMC_SHA256=sha(valid) if label=='raw-stale-digest' else sha(canonical), CARGO_TARGET_DIR=str(root/'raw-target'/label))
    if label=='raw-stale-digest':
        overrides['JNOX_NATIVE_AMC_SHA256']='0'*64
    for i in range(n):
        key=['JNOX_NATIVE_ELF','JNOX_NATIVE_PEER_ELF','JNOX_NATIVE_PEER2_ELF','JNOX_NATIVE_PEER3_ELF'][i]
        path=out/f'slot{i}.elf'
        overrides[key]=str(path); overrides[key+'_SHA256']=sha(path)
    if extra:
        overrides['JNOX_NATIVE_PEER4_ELF']=str(out/extra)
        overrides['JNOX_NATIVE_PEER4_ELF_SHA256']=sha(out/extra)
    cmd=[sys.executable,'tools/build_kernel.py','--arch','aarch64']
    (raw/(label+'.command')).write_text('env '+' '.join(shlex.quote(k+'='+v) for k,v in overrides.items())+' '+shlex.join(cmd)+'\n')
    env={k:v for k,v in os.environ.items() if not k.startswith(('JNOX_','CARGO_FEATURE_')) and k not in ('CARGO_BUILD_TARGET','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS')}
    env.update(overrides,PATH='/home/ywcho/.cargo/bin:'+env['PATH'])
    result=subprocess.run(cmd,cwd=source,env=env,capture_output=True)
    (raw/(label+'.stdout')).write_bytes(result.stdout)
    (raw/(label+'.stderr')).write_bytes(result.stderr)
    (raw/(label+'.exit')).write_text(str(result.returncode)+'\n')
    print(label, result.returncode, '\n'.join(result.stderr.decode(errors='replace').splitlines()[-8:]),flush=True)
