#!/bin/bash
set -eu
root=/home/ywcho/jnox348-84af5040.IOlusAAn
mkdir -p "$root/raw" "$root/source"
exec > >(tee "$root/raw/summary.log") 2>&1
cd "$root/source"
git init -q
git remote add origin https://github.com/Romanof123/JNOX.git
git fetch --depth 1 origin 84af5040cdf3d969484897e10c45926515075717
git checkout -q --detach FETCH_HEAD
test "$(git rev-parse HEAD)" = 84af5040cdf3d969484897e10c45926515075717
git rev-parse HEAD
findmnt -T . -no SOURCE,FSTYPE
git status --porcelain
export PATH="/home/ywcho/.cargo/bin:$PATH"
for name in clang ld.lld rustc cargo python3 aarch64-linux-gnu-nm; do
    command -v "$name"
    "$name" --version | head -n 1
done
date -u --iso-8601=seconds
out=output/native-amc
mkdir -p "$out"
run() {
    local label=$1; shift
    local e="$root/raw/$label"
    printf '%q ' "$@" > "$e.command"; echo >> "$e.command"
    cat "$e.command"
    set +e
    "$@" > "$e.stdout" 2> "$e.stderr"
    rc=$?
    set -e
    echo "$rc" > "$e.exit"
    echo "$label exit=$rc"
    if [ "$rc" != 0 ]; then tail -n 18 "$e.stderr"; fi
}
for slot in 0 1 2 3; do
    run "slot$slot" sh sdk/native-aarch64/build.sh "examples/native-amc/slot$slot.c" "$out/slot$slot.elf"
done
if [ -f "$out/slot0.elf" ] && [ -f "$out/slot1.elf" ] && [ -f "$out/slot2.elf" ] && [ -f "$out/slot3.elf" ]; then
    sha256sum "$out"/slot*.elf | tee "$root/raw/elf-sha256.txt"
    pack=(python3 tools/build_native_el0.py --policy amc --elf "$out/slot0.elf" --peer-elf "$out/slot1.elf")
    more=(--peer-elf "$out/slot2.elf" --peer-elf "$out/slot3.elf")
    run invalid-budget "${pack[@]}" --out "$out/invalid-budget" --amc-manifest examples/native-amc/config/invalid-budget.json
    run fifth "${pack[@]}" "${more[@]}" --peer-elf "$out/slot0.elf" --out "$out/fifth" --amc-manifest examples/native-amc/config/normal-hi.json
    run within-lo "${pack[@]}" --out "$out/within-lo" --amc-manifest examples/native-amc/config/within-lo.json
    run normal-hi "${pack[@]}" "${more[@]}" --out "$out/normal-hi" --amc-manifest examples/native-amc/config/normal-hi.json
    find "$out" -maxdepth 3 -type f -exec sha256sum {} + | sort -k2 > "$root/raw/all-output-sha256.txt"
fi
git status --porcelain
date -u --iso-8601=seconds
