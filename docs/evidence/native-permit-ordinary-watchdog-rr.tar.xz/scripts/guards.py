"""Exercise the CLI and its real downstream Cargo/build.rs guards serially."""
import os, re, runpy, shlex, subprocess, sys, tempfile
from pathlib import Path
from unittest.mock import patch

root = Path(sys.argv[1]).resolve()
src = root / "src"
os.chdir(src)
sys.path.insert(0, str(src / "tools"))
invocation = shlex.split((root / "logs/ordinary-fifo-healthy.build").read_text().splitlines()[0].removeprefix("+ "))
assert Path(invocation[0]).name == "python3"
argv = invocation[1:]
artifact = root / "guard-results.txt"
results = []

def expect_error(name, cmd, why, env=None):
    p = subprocess.run(cmd, env=env, text=True, capture_output=True)
    assert p.returncode != 0 and why in p.stdout+p.stderr, (name, p.returncode, (p.stdout+p.stderr)[-2200:])
    results.append(f"{name} refused ({p.returncode}): {why}")

class BuildCall(Exception):
    pass

original = subprocess.run
def capture(cmd, *args, **kwargs):
    if isinstance(cmd, list) and "tools/build_kernel.py" in cmd:
        raise BuildCall(cmd, kwargs["env"].copy())
    return original(cmd, *args, **kwargs)

with tempfile.TemporaryDirectory(dir=root) as tmp:
    argv[argv.index("--out") + 1] = tmp + "/valid"
    for name in ["no-channel","duplicate","wrong-rank","boundary"]:
        a = argv[:]
        a[a.index("--out") + 1] = tmp + "/" + name
        if name == "no-channel":
            a.remove("--safety-channel")
            why = "--safety-watchdog requires --safety-channel"
        elif name == "duplicate":
            a.append("--safety-watchdog")
            why = "--safety-watchdog requires --safety-channel"
        elif name == "wrong-rank":
            a[a.index("--peer-priority") + 1] = "5"
            why = "priorities must order controller > sender > supervisor"
        else:
            for flag in ("--arg","--peer-arg","--peer2-arg"):
                while flag in a:
                    i=a.index(flag);del a[i:i+2]
                a += [flag, "phase"]
            a += ["--safety-boundary"]
            why = "excludes --safety-boundary"
        expect_error("package "+name, [sys.executable, *a], why)
        assert not Path(tmp, name).exists()
    try:
        sys.argv = argv
        with patch("subprocess.run", capture):
            runpy.run_path(str(src / argv[0]), run_name="__main__")
    except BuildCall as at:
        cmd, env = at.args
    else:
        raise AssertionError("packager did not reach the kernel build")
    for change, value, why in [
        ("JNOX_NATIVE_SAFETY_CHANNEL", None, "safety watchdog requires the protected channel"),
        ("JNOX_NATIVE_SAFETY_BOUNDARY", "1", "excludes boundary fixtures"),
        ("JNOX_NATIVE_PRIORITIES", "7,6,4", "priorities must order controller > sender > supervisor"),
    ]:
        e=env.copy()
        if value is None: del e[change]
        else: e[change]=value
        expect_error("kernel "+change, cmd, why, e)
    binary = tmp + "/model"
    original(["rustc","--edition=2021","--test","kernel/src/completion_watchdog.rs","-o",binary],check=True)
    model = original([binary],text=True,capture_output=True,check=True).stdout
    results.append(model.strip())
artifact.write_text("\n".join(results)+"\n")
print(artifact.read_text())
