#!/usr/bin/env bash
set -euo pipefail
rev=${1:?source revision}
lab="$HOME/permit402-$rev"
mkdir -p "$lab"
cd "$lab"
exec 9>"$lab/lane.lock"
flock -n 9
test ! -e "$lab/src"
export PATH="$HOME/.cargo/bin:$PATH" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1 LC_ALL=C TZ=UTC
unset RUSTFLAGS CARGO_TARGET_DIR
for var in $(compgen -e JNOX_); do unset "$var"; done
git init -q src
realpath /mnt/d/codex/.jnox-work/policy-v1/.git/objects > src/.git/objects/info/alternates
git -C src sparse-checkout init --cone
git -C src sparse-checkout set arch boards examples kernel sdk services tools trace verification
git -C src checkout --detach -q "$rev"
cd "$lab/src"
git rev-parse HEAD 'HEAD^{tree}' > "$lab/source.txt"
mkdir -p "$lab"/{apps,logs,runs,packages}
{ uname -a; qemu-system-aarch64 --version; python3 -V; rustc -Vv; cargo -V; sha256sum "$(command -v qemu-system-aarch64)"; } > "$lab/host.txt"
for kind in ordinary qualification; do
 features=()
 if [[ $kind = ordinary ]]; then features=(--features ordinary); fi
 sh sdk/native-aarch64/build-rust.sh "${features[@]}" examples/native-safety-watchdog/Cargo.toml "$lab/apps/$kind.elf" >"$lab/logs/$kind.app" 2>&1 || { cat "$lab/logs/$kind.app"; exit 11; }
done
for kind in ordinary qualification; do
 scenarios=(healthy sleep-late compute-late)
 extra=()
 if [[ $kind = qualification ]]; then scenarios=(healthy); extra=(--safety-qualification); fi
 for policy in fifo rr; do
  quantum=()
  if [[ $policy = rr ]]; then quantum=(--quantum-ticks 625000); fi
  for scenario in "${scenarios[@]}"; do
   id="$kind-$policy-$scenario"
   pkg="$lab/packages/$id"
   elf="$lab/apps/$kind.elf"
   (set -x; python3 tools/build_native_el0.py --out "$pkg" --board virt --policy "$policy" "${quantum[@]}" --elf "$elf" --peer-elf "$elf" --peer-elf "$elf" --arg sender --arg "$scenario" --peer-arg controller --peer-arg "$scenario" --peer2-arg supervisor --peer2-arg "$scenario" --priority 6 --peer-priority 7 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel --safety-watchdog "${extra[@]}") >"$lab/logs/$id.build" 2>&1 || { tail -60 "$lab/logs/$id.build"; exit 12; }
   dest="$lab/runs/$id"; mkdir "$dest"
   date -u +%FT%T.%NZ > "$dest/start.utc"
   rc=0
   (set -x; python3 tools/native_el0_capture.py "$dest/cap" "$pkg/kernel.elf" "$elf" examples/native-safety-watchdog/src/main.rs "$rev" --manifest "$pkg/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608) >"$dest/capture.log" 2>&1 || rc=$?
   date -u +%FT%T.%NZ > "$dest/finish.utc"
   echo "$rc" > "$dest/status"
   printf '%s %s\n' "$id" "$rc" | tee -a "$lab/ledger"
  done
 done
done
git status --short --untracked-files=no
