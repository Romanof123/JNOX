#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:$PATH" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1
root="$HOME/permit402-$1"
exec 9>"$root/lane.lock"; flock -n 9
cd "$root/src"
python3 /mnt/d/codex/permit402-ordinary-watchdog/guards.py "$root"
