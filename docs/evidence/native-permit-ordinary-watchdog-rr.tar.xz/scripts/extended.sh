#!/usr/bin/env bash
set -euo pipefail
rev=${1:?}
lab="$HOME/permit402-$rev"
cd "$lab/src"
test "$(git rev-parse HEAD)" = "$rev"
test -z "$(git status --short --untracked-files=no)"
exec 9>"$lab/lane.lock"
flock -n 9
test "$(wc -l < "$lab/ledger")" = 8
export PATH="$HOME/.cargo/bin:$PATH" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1 LC_ALL=C TZ=UTC
unset RUSTFLAGS CARGO_TARGET_DIR
for var in $(compgen -e JNOX_); do unset "$var"; done
elf="$lab/apps/ordinary.elf"
for policy in fifo rr; do
 quantum=()
 if [[ $policy = rr ]]; then quantum=(--quantum-ticks 625000); fi
 for scenario in controller-exit recover recover-live; do
  id="ordinary-$policy-$scenario"
  pkg="$lab/packages/$id"; test ! -e "$pkg"
  (set -x; python3 tools/build_native_el0.py --out "$pkg" --board virt --policy "$policy" "${quantum[@]}" --elf "$elf" --peer-elf "$elf" --peer-elf "$elf" --arg sender --arg "$scenario" --peer-arg controller --peer-arg "$scenario" --peer2-arg supervisor --peer2-arg "$scenario" --priority 6 --peer-priority 7 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel --safety-watchdog) > "$lab/logs/$id.build" 2>&1
  dest="$lab/runs/$id"; mkdir "$dest"; rc=0
  date -u +%FT%T.%NZ > "$dest/start.utc"
  (set -x; python3 tools/native_el0_capture.py "$dest/cap" "$pkg/kernel.elf" "$elf" examples/native-safety-watchdog/src/main.rs "$rev" --manifest "$pkg/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608) > "$dest/capture.log" 2>&1 || rc=$?
  date -u +%FT%T.%NZ > "$dest/finish.utc"; echo "$rc" > "$dest/status"
  printf '%s %s\n' "$id" "$rc" | tee -a "$lab/ledger"
 done
done
