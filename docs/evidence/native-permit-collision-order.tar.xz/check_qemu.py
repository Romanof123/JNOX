"""Check official Ubuntu 6.2 source members, all applied-patch file headers and the cited upstream hashes."""
import argparse
import hashlib
import json
import re
import tarfile
from pathlib import Path

ORIG = "qemu_6.2+dfsg.orig.tar.xz"
QUILT = "qemu_6.2+dfsg-2ubuntu6.31.debian.tar.xz"
ORIG_SHA = "470d4202ab6302f184bf934008d2306c144d3221aa3b8ceb8a710414755af61b"
QUILT_SHA = "97dd9f9b065452e02b00f87e70e94d9f6369716de7d739ae605240d2522183a2"
REV = "44f28df24767cf9dca1ddc9b23157737c4cbb645"
FILES = ("target/arm/cpu.c","target/arm/helper.c","target/arm/translate-a64.c","util/qemu-timer.c",
         "softmmu/cpus.c","softmmu/icount.c","accel/tcg/tcg-accel-ops.c","accel/tcg/translator.c",
         "accel/tcg/translate-all.c","accel/tcg/cpu-exec.c","include/exec/gen-icount.h","docs/devel/tcg-icount.rst")


def need(ok, label):
    if not ok:
        raise ValueError(label)


def sha(data):
    return hashlib.sha256(data).hexdigest()


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archives",type=Path)
    parser.add_argument("--also-upstream",type=Path,help="optional upstream files in commit-relative paths")
    args=parser.parse_args()
    pins=json.loads((Path(__file__).parent/"upstream-pins.json").read_text())
    need(sorted(pins)==sorted(FILES),"source pin set")
    for name, h in ((ORIG,ORIG_SHA),(QUILT,QUILT_SHA)):
        need(sha((args.archives/name).read_bytes())==h,name)
    remaining=set(FILES)
    with tarfile.open(args.archives/ORIG,"r|xz") as archive:
        for member in archive:
            path=member.name.removeprefix("qemu-6.2+dfsg/")
            if path in remaining:
                data=archive.extractfile(member).read()
                need(sha(data)==pins[path],path)
                if args.also_upstream:
                    need((args.also_upstream/path).read_bytes()==data,path+" upstream")
                remaining.remove(path)
    need(not remaining,"incomplete Ubuntu source archive")
    with tarfile.open(args.archives/QUILT) as archive:
        series=archive.extractfile("debian/patches/series").read().decode().splitlines()
        patches=[r.split("#",1)[0].split()[0] for r in series if r.split("#",1)[0].strip()]
        for name in patches:
            patch=archive.extractfile("debian/patches/"+name).read().decode(errors="replace")
            headers=re.findall(r"^(?:---|\+\+\+|rename from|rename to)\s+(\S+)",patch,re.M)
            need(not any(h==p or h.endswith("/"+p) for h in headers for p in FILES),name)
    need(len(patches)==209,"quilt series")
    print(json.dumps(dict(upstream=REV,orig_sha256=ORIG_SHA,debian_sha256=QUILT_SHA,
                          unchanged_files=len(pins),quilt_entries=len(patches)),sort_keys=True))
