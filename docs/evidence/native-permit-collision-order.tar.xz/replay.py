"""Replay using the two frozen campaign archives, and official Ubuntu source archives in a cache directory."""
import argparse
import hashlib
import subprocess
import sys
import tempfile
from pathlib import Path

PHASE = "b87f47d99067701deb1f99abc10099f96070aa0c1a24879e93909146567b4017"
REARM = "d83937a537964d345f3b90b4fd54744855f42b88d4c3abfabe84291f6fb7215d"


def match(path, expected):
    if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        raise ValueError("input checksum: "+path.name)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("phase_archive",type=Path)
    p.add_argument("rearm_archive",type=Path)
    p.add_argument("ubuntu_source_dir",type=Path)
    a=p.parse_args()
    here=Path(__file__).resolve().parent
    for line in (here/"SHA256SUMS").read_text().splitlines():
        h,n=line.split("  ",1)
        if Path(n).name!=n: raise ValueError("manifest path")
        match(here/n,h)
    match(a.phase_archive,PHASE)
    match(a.rearm_archive,REARM)
    subprocess.run([sys.executable,"-B",here/"check_qemu.py",a.ubuntu_source_dir],check=True)
    with tempfile.TemporaryDirectory() as temp:
        phase, rearm = Path(temp)/"phase",Path(temp)/"rearm"
        for d,archive in ((phase,a.phase_archive),(rearm,a.rearm_archive)):
            d.mkdir()
            subprocess.run(["tar","-xJf",archive.resolve(),"-C",d],check=True)
        guest=subprocess.check_output([sys.executable,"-B",here/"check_guest.py","--phase-root",phase,
                                      "--rearm-root",rearm])
        if guest!=(here/"guest-witnesses.json").read_bytes(): raise ValueError("guest replay differs")
        print("Four linked kernels; two collision receipts:",hashlib.sha256(guest).hexdigest())
