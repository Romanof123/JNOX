"""Recheck four archived kernels, two native collision receipts and the minimum SVC-entry witness."""
import argparse
import hashlib
import json
import re
import struct
import subprocess
import tempfile
import shutil
import zlib
from pathlib import Path

RUNS = {
    "fifo-collision-count-first": "92b56be2e45f4b4652a55bfe4c996cdf12e2bb7123c5d1fbd050795e7a85c1bc",
    "rr-collision-count-first": "2b7ca62fd1b40a16ec0e60a5ce30ce8dfcb132c9a935966e6951c1e34d2523ec",
    "006-count0-fifo-rearm-15-lead0": "4964d8c7092bc139c51c854a39b28049cb879df2c57f4faa62a9c3a5b4864766",
    "008-count0-rr-rearm-15-lead0": "b190ef4a57c84d48f8a4e1e407f9df2c1c451fb876f6a2d922560d76342926f4",
}
QEMU = "0a63468782d096485932acf6aa0a69d358b3e3a6f68f655e960e9f5e3fc578d8"


def need(value, name):
    if not value:
        raise ValueError(name)
    return value


def one(items):
    a, = items
    return a


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def disassemble(kernel):
    cmd = ["aarch64-linux-gnu-objdump"]
    text = subprocess.check_output(cmd + ["-dC", "--no-show-raw-insn", kernel], text=True)
    vector = subprocess.check_output(cmd + ["-D", "--start-address=0x40200c00", "--stop-address=0x40200c04", kernel], text=True)
    need(re.search(r"40200c00:\s+14000193\s+b\s+4020124c ", vector), "lower-A64 sync vector")
    insn = {}
    funcs = {}
    fn = None
    for line in text.splitlines():
        symbol = re.fullmatch(r"\w+ <(.*)>:", line)
        if symbol:
            fn = symbol[1]
            funcs[fn] = []
        m = re.match(r"\s*([\da-f]+):\s+([a-z][a-z0-9.]*)\s*(.*)$", line)
        if m:
            address = int(m[1], 16)
            instruction = m[2] + " " + m[3].split("//")[0].strip()
            insn[address] = instruction.strip()
            if fn:
                funcs[fn].append(address)
    def body(end):
        return one(v for k, v in funcs.items() if k.endswith(end))
    def pc(candidates, sub):
        return one(i for i in candidates if sub in insn[i])
    service = body("::loans::service_other")
    pub = pc(service, "::LoanIpc::publish>")
    before, after = [i for i in service if "cntpct_el0" in insn[i]]
    need(before < pub < after and insn[before - 4] == insn[after - 4] == "isb", "publication anchors")
    tail = pc(body("::LoanIpc::publish"), "stlr ")
    need([insn[tail + d] for d in (-12, -8, -4, 0)] ==
         ["str x20, [x8, x10, lsl #3]", "add x8, x25, #0x1", "add x10, x19, #0x90", "stlr x8, [x10]"], "tail release")
    check = pc(body("::safety::service"), "Session::check_at>") - 8
    need(insn[check] == "mrs x0, cntpct_el0" and insn[check+4] == "mov x1, x20" and
         insn[check-4] == "isb" and insn[check-12] == "cmp x21, #0x1", "actual PID1 operand")
    # Verify the complete linear lower-A64 sync save, including sixteen executed pair stores.
    need(insn[0x4020124c] == "msr daifset, #0xf" and
         all(insn[a].split()[0] in {"msr","sub","stp","str","mrs","mov"}
             for a in range(0x4020124c,0x40201318,4)), "no bypass in lower-A64 sync entry")
    for i in range(16):
        args = f"q{2*i}, q{2*i+1}, [sp, #{304 + i*32}]"
        need(insn[0x402012c0 + 4*i] == "stp " + args and
             insn[0x40201354 + 4*i] == "ldp " + args, "frame save/restore")
    need("<native_el0_sync>" in insn[0x40201318] and insn[0x402013dc]=="eret", "handler and successful return")
    sync = body("native_el0_sync")
    return dict(publish_before=hex(before), call_publish=hex(pub), tail_release=hex(tail),
                publish_after=hex(after), controller_operand=hex(check), check_call=hex(check+8),
                loan_dispatch=hex(pc(sync,"::loans::service>")), safety_dispatch=hex(pc(sync,"::safety::service>")),
                scheduler_poll=hex(pc(sync,"::fixed_dispatch>")), vector="0x40200c00", mask="0x4020124c",
                mandatory_pair_stores=["0x402012c0","0x402012fc"], pair_stores=16,
                restore_pair_loads=["0x40201354","0x40201390"], eret="0x402013dc")


def symbols(elf):
    text = subprocess.check_output(["aarch64-linux-gnu-nm","-CS","--defined-only",elf],text=True)
    return {fields[3]:tuple(map(lambda v:int(v,16),fields[:2]))
            for l in text.splitlines() if len(fields:=l.split(None,3))==4}


def private_rows(root, cap, launch):
    ram = (cap/"ram.bin").read_bytes()
    base = launch["ram_base"]
    spaces, size = symbols(cap/"kernel.elf")["jnox_kernel::native_el0_mmu::SPACES"]
    need(size % (3 * 4096) == 0 and spaces % 4096 == 0, "page-table roots")
    def physical(addr, n):
        i=addr-base
        need(0<=i<=len(ram)-n,"RAM bounds")
        return ram[i:i+n]
    def read(pid, symbol, app):
        start, n = app["safety_"+symbol]
        data = bytearray()
        while len(data)<n:
            v=start+len(data)
            table=spaces+pid*(size//3)
            for shift in (30,21,12):
                pte=int.from_bytes(physical(table+8*((v>>shift)&511),8),"little")
                need(pte&3==3,"mapped app data")
                table=pte&0x0000fffffffff000
            pos=v%4096
            data.extend(physical(table+pos,min(4096-pos,n-len(data))))
        return bytes(data)
    result=[]
    for pid, role, prefix, width in [(0,"sender","sender",11),(1,"receiver","received",20)]:
        elf=root/"apps"/(role+".elf")
        app=symbols(elf)
        count=int.from_bytes(read(pid,prefix+"_count",app),"little")
        need(0<count<=64, "bounded private rows")
        words=struct.Struct("<"+"Q"*width)
        rows=list(words.iter_unpack(read(pid,prefix+"_rows",app)))[:count]
        frames=read(pid,prefix+"_bytes",app)
        index=one(i for i,r in enumerate(rows) if (r[5:7]==(1,4) if pid==0 else r[2]==16))
        result.append((rows[index],frames[44*index:44*(index+1)]))
    return result


def collision(root, cap, events, lines, launch):
    def event(kind, predicate=lambda r:True):
        return one(r for r in events if r[0]==kind and predicate(r))
    p=event(11,lambda r:r[7:9]==[1,4])
    freq=event(1)[2]
    old=event(11,lambda r:r[7:9]==[1,3])[9]
    D=old+freq*20//1000
    e=event(3)
    c=event(12,lambda r:r[2]==e[2] and r[3]==1)
    check=event(5,lambda r:r[1]>c[1] and r[2:5]==[1,60,1] and
                all(x[0]!=12 for x in events[events.index(c)+1:events.index(r)]))
    receipt=event(7,lambda r:r[2]==p[4])
    frame=b"".join(x.to_bytes(8,"little") for x in receipt[4:])[:44]
    enq=event(6,lambda r:r[2:5]==[0,34,0] and r[6]==p[4])
    recv=event(6,lambda r:r[2:5]==[1,35,0] and r[7:9]==[p[4],44])
    release=event(6,lambda r:r[2:5]==[1,36,0] and r[6]==p[4])
    need(events.index(p)<events.index(enq)<events.index(e)<events.index(c)<events.index(check)
         <events.index(receipt)<events.index(recv)<events.index(release),"receipt order")
    need(freq==62500000 and p[2]<=p[3]<e[2] and p[4:]==[16,0,1,1,4,D] and
         c[2:]==[e[2],1,1,3,old,0,1,1] and e[3:6]==[1,3,old] and check[5:9]==[0,1,3,old],
         "same-generation successful publication and expiry at a gated PID1 CHECK")
    need(enq[5]==1 and enq[-1]==recv[-1]==release[-1]==1 and recv[5]==0,"occupancy/handle join")
    sender, receiver=private_rows(root,cap,launch)
    sr,sb=sender
    rr,rb=receiver
    need(sb==rb==frame and sr[5:]==(1,4,D,16,0,0) and rr[4:7]==(44,17,1<<63) and
         rr[9:14]==(1,5,3,3,old) and rr[16:18]==(3,old) and
         zlib.crc32(frame[:40])==int.from_bytes(frame[40:],"little"),"private frame/rejection")
    outs=[r for r in events if r[0]==2]
    need(event(1)[4]==0 and not outs,"original initial-low control")
    exits=[list(map(int,l.split()[-2:])) for l in lines if l.startswith("NATIVE EL0 EXIT PID ")]
    need(exits==[[0,71],[1,72],[2,95]],"original exits")
    return dict(deadline=D, wire_issue_seq3=old, wire_issue_seq4=p[9], handle=p[4], bracket=p[2:4],
                check=c[2], bracket_offsets=[p[2]-D,p[3]-D], check_offset=c[2]-D,
                lower_separation_ticks=c[2]-p[3], active_generation=1, previous_sequence=3,
                sender_and_receiver_frame_hex=frame.hex(), private_rejection=rr[5], commit_skipped=True,
                initial_enable=0, output_transitions=len(outs), exits=exits,
                safety_dropped=0, fixed_dropped=one(int(l.split()[-1]) for l in lines if l.startswith("NATIVE FIXED DROPPED ")))


def verify_original(root, run, pin):
    cap=root/"runs"/run/"cap"
    need(digest(cap/"session.json")==pin,run+" receipt")
    hashes=json.loads((cap/"session.json").read_bytes())["hashes"]
    for name, value in hashes.items():
        need(Path(name).name==name and digest(cap/name)==value,name+" original hash")
    j=json.loads((cap/"launch.json").read_bytes())
    a=j["argument_package"]
    lines=(cap/"uart.bin").read_text().splitlines()
    events=[list(map(int,l.split()[3:])) for l in lines if l.startswith("NATIVE SAFETY EVENT ")]
    args=j["argv"]
    need(args[1:11]==["-machine","virt,gic-version=2","-cpu","cortex-a72","-smp","1","-accel",
                       "tcg,thread=single","-icount","shift=0,align=off,sleep=off"] and
         args[11:-4]==["-m","128M","-nodefaults","-display","none","-monitor","none","-no-reboot","-qmp","stdio"] and
         args[-4::2]==["-serial","-kernel"] and j["qemu_sha256"]==QEMU and
         a["kernel_elf_sha256"]==j["kernel_sha256"]==hashes["kernel.elf"] and a["commit"]==j["revision"] and
         a["tracked_changes"]=="" and a["policy"] in run and a["loan_route"]=={"producer":0,"consumer":1} and
         a["safety_boundary"]["decision_event"]==12 and not a.get("safety_watchdog") and
         not a.get("safety_qualification"),"configuration")
    slots=a["slots"]
    need([s["priority"] for s in slots]==[7,6,4] and
         [digest(root/"apps"/(r+".elf")) for r in ["sender","receiver","supervisor"]]==[s["elf_sha256"] for s in slots],
         "role binaries")
    need([l for l in lines if l.startswith("NATIVE SAFETY DROPPED ")]==["NATIVE SAFETY DROPPED 0"] and
         all(len(r)==10 for r in events) and one(r[2] for r in events if r[0]==1)==62500000,"journal")
    result=dict(run=run,policy=a["policy"],revision=j["revision"],session_sha256=pin,kernel_sha256=hashes["kernel.elf"],
                uart_sha256=hashes["uart.bin"],linked=disassemble(cap/"kernel.elf"))
    if "collision" in run:
        need(all(s["argv"]==["/bin/app","collision"] for s in slots),"collision selectors")
        result["observed"]=collision(root,cap,events,lines,j)
    return result


def verify(root, run, pin):
    d = root/"runs"/run
    if (d/"cap/kernel.elf").is_file():
        return verify_original(root, run, pin)
    # The phase v1 packet represents the original ELF/probe/RAM using SHA-addressed blobs.
    refs = json.loads((d/"refs.json").read_bytes())
    need(set(refs)=={"kernel.elf","user.elf","probe.c","ram.bin"}, "phase restore members")
    def blob(h):
        need(re.fullmatch("[0-9a-f]{64}",h),"blob name")
        data=(root/"blobs"/h).read_bytes()
        need(hashlib.sha256(data).hexdigest()==h,"blob hash")
        return data
    with tempfile.TemporaryDirectory() as tmp:
        temp=Path(tmp)
        (temp/"apps").symlink_to((root/"apps").resolve(),target_is_directory=True)
        cap=temp/"runs"/run/"cap"
        shutil.copytree(d/"cap",cap)
        for name, ref in refs.items():
            if name=="ram.bin":
                size=ref["size"]
                need(0<size<=32*1024*1024,"RAM size")
                with (cap/name).open("wb") as out:
                    out.truncate(size)
                    for index,h in ref["pages"].items():
                        offset=4096*int(index)
                        data=blob(h)
                        need(0<=offset<size and len(data)==min(4096,size-offset),"RAM page bounds")
                        out.seek(offset)
                        out.write(data)
            else:
                (cap/name).write_bytes(blob(ref))
        return verify_original(temp,run,pin)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase-root",type=Path,required=True)
    parser.add_argument("--rearm-root",type=Path,required=True)
    args=parser.parse_args()
    print(json.dumps([verify(args.phase_root if "collision" in k else args.rearm_root,k,v) for k,v in RUNS.items()],
                     indent=2,sort_keys=True))
