set -eu
D=$HOME/jnox312-424a/packet
cd "$HOME/jnox312-424a/repo"
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
mkdir -p "$D/elf" "$D/runs"
git rev-parse HEAD > "$D/source.txt"
git status --porcelain >> "$D/source.txt"
git archive HEAD examples/native-edf examples/native-edf-rust sdk/native-aarch64 tools/build_native_el0.py kernel/src/native_edf.rs | gzip > "$D/source.tar.gz"
{ qemu-system-aarch64 --version; clang --version; rustc -Vv; cargo -V; df -h "$D"; } > "$D/tools.txt"
for app in batch urgent; do sh sdk/native-aarch64/build.sh examples/native-edf/$app.c "$D/elf/$app.elf"; done
sh sdk/native-aarch64/build-rust.sh examples/native-edf-rust/Cargo.toml "$D/elf/histogram.elf"
for app in "$D"/elf/*.elf; do aarch64-linux-gnu-nm -nS "$app" > "$app.sym"; aarch64-linux-gnu-objdump -d "$app" > "$app.dis"; done
for name in principal one high junk timed; do
args=(--policy edf --elf "$D/elf/batch.elf")
case $name in principal) n=32768;; one) n=1;; high) n=65537;; junk) n=2x;; esac
if [[ $name != timed ]]; then args+=(--arg=--blocks --arg "$n"); fi
args+=(--job 0,8,2)
if [[ $name == principal ]]; then args+=(--peer-elf "$D/elf/histogram.elf" --peer-job 0,12,8 --peer-elf "$D/elf/urgent.elf" --peer-job 1,4,1); fi
python3 tools/build_native_el0.py --out "$D/elf/$name" "${args[@]}"
done
