import json,re,struct,pathlib,hashlib
D=pathlib.Path(__file__).resolve().parent
out={}
for r in sorted((D/'runs').iterdir()):
 u=(r/'uart.log').read_text()
 def rows(k):return [list(map(int,l.split())) for l in re.findall('^NATIVE EDF '+k+' (.*)$',u,re.M)]
 S,Q,hz=rows('CONFIG')[0];ev=rows('EVENT')
 assert rows('DROPPED')==[[0]] and all(e[19]==0 for e in ev)
 status=[int(x.split()[-1]) for x in u.splitlines() if 'NATIVE EL0 EXIT' in x]
 def le(h):return int.from_bytes(bytes.fromhex(h),'little')
 prod=[]
 for i,f in enumerate(json.loads((r/'ram.json').read_text())):
  h=f['private_result']; v=le(h) if i!=1 else list(struct.unpack('<16I',bytes.fromhex(h)))
  prod.append([le(f['private_progress']),v])
 exits={e[3]:e[1] for e in ev if e[0]==3}
 a=[exits[i]-S for i in range(len(exits))]
 m=[Q*k-x for k,x in zip([8,12,4],a)]
 assert min(m)>=0
 extra={}
 if r.name.startswith('principal'):
  assert status==[17,29,43] and prod==[[32768,17112760320],[128,[32768]*16],[8,2048]]
  assert [e[4] for e in ev if e[3]!=e[4]]==[0,2,0,1,2**64-1]
  irq,ret=ev[1:3]
  assert irq[2:5]==[1,0,2] and irq[11]==4 and ret[0]==3
  assert irq[20:22]==ret[22:24]==[0x4001e8,0x1010f40] and irq[34]==ret[35]==0x402141c0
  fr=[json.loads(l) for l in (r/'frames.jsonl').read_text().splitlines()]
  observed={le(w)-1 for _,w,b in fr if struct.unpack('<QQ',bytes.fromhex(b))==tuple(irq[20:22])}
  assert len(observed)==1
  count=observed.pop()
  progress=[json.loads(l)[1] for l in (r/'progress.jsonl').read_text().splitlines()]
  later=[v[0] for v in progress if v[2]==8 and count<v[0]<32768]
  assert later
  extra=dict(saved_blocks=count,later_blocks=later,irq_lateness=irq[1]-irq[8],frame=hex(irq[34]),PC=hex(irq[20]),SP=hex(irq[21]))
  if r.name.endswith('traced'):
   t=(r/'exceptions.log').read_text()
   first=t.index('...with ELR 0x4001e8')
   pieces=['PC=0000000040201c80','X21='+format(count+1,'016x'),'acknowledged irq 30','Exception return from AArch64 EL1 to AArch64 EL0 PC 0x400000','Taking exception 2 [SVC]','...with ELR 0x400020','PC=0000000040202354','X09=0000000001010f40 X10=00000000004001e8','Exception return from AArch64 EL1 to AArch64 EL0 PC 0x4001e8']
   for piece in pieces:first=t.index(piece,first)+len(piece)
 elif r.name.startswith('timed'):
  n,total=prod[0];assert status==[17] and 0<n<=65536 and total==522240*n and a[0]>=hz*.16
 elif r.name.startswith('one'):assert status==[17] and prod==[[1,522240]]
 else:assert status==[105] and prod==[[0,0]]
 out[r.name]=dict(epoch=S,Q=Q,hz=hz,exits=exits,elapsed=a,margins=m,products=prod,status=status,**extra)
print(json.dumps(out,indent=2))

