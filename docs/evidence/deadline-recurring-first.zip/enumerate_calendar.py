import itertools, json

def schedule(jobs, mask, policy):
    left=[x[2] for x in jobs]
    out=[]
    for k in range(17):
        if any(left[i] and k>=d for i,(r,d,c) in enumerate(jobs)):
            return None
        candidates=[i for i,(r,d,c) in enumerate(jobs) if r<=k and left[i]]
        if k==16: break
        if not candidates or mask >> k & 1:
            out.append(None); continue
        job=min(candidates,key=lambda i:(jobs[i][1]-(left[i]+k if policy=='llf' else 0),i))
        left[job]-=1
        out.append(job)
    return out

calendars=intervals=0
for h in range(1,9):
    for off in range(h):
        for p in range(1,h+3):
            for w in range(1,p+1):
                starts=list(range(off,h,p))
                withheld={k for a in starts for k in range(a,min(h,a+w))}
                mask=sum(1<<k for k in range(off,h) if (k-off)%p<w)
                assert withheld=={k for k in range(h) if mask>>k&1}
                calendars+=1
                for a in range(h+1):
                    for b in range(a,h+1):
                        assert sum(k not in withheld for k in range(a,b))==b-a-((mask>>a)&((1<<(b-a))-1)).bit_count()
                        intervals+=1
jobs=[(0,13,9),(10,16,1)]
tight=[(0,10,9)]
result={'small_calendars':calendars,'intervals':intervals,'policies':{}}
for p in ('edf','llf'):
    s=schedule(jobs,514,p)
    assert [k for k,x in enumerate(s) if x==0]==[0,2,3,4,5,6,7,8,10]
    assert [k for k,x in enumerate(s) if x==1]==[11]
    assert all(schedule(tight,m,p) is not None for m in (0,2))
    assert schedule(tight,514,p) is None
    result['policies'][p]=s
print(json.dumps(result,indent=2))
