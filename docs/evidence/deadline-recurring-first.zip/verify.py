import gzip, json, re, struct, sys
from pathlib import Path

root = Path(sys.argv[1])
def words(path):
    data = path.read_bytes()
    return list(struct.unpack('<' + 'Q'*(len(data)//8), data))

def verify(d):
    c = d/'capture'
    assert (d/'capture-status').read_text().strip() == '0'
    u = (d/'uart.raw').read_bytes()
    assert u == (c/'uart.bin').read_bytes()
    s = u.decode().splitlines()
    def rows(name):
        return [list(map(int, line.split()[1:])) for line in s if line.startswith(name+' ')]
    audit = words(c/'audit.bin')
    launch = words(c/'deadline_recurring_launch.bin')
    count, = words(c/'ordinary_deadline_row_count.bin')
    assert rows('CALENDAR')[0][:4] == [1,8,1,514]
    terminal = s[-1]
    if 'normal' not in d.name:
        assert count == 0 and not any(audit+launch)
        assert words(c/'deadline_restore_count.bin')==[0] and not any(words(c/'ordinary_deadline_rows.bin'))
        assert not (c/'int.trace').read_bytes().strip()
        if 'owner' in d.name:
            assert rows('OWNER_CAP')[0][-3:]==[4,3,0] and rows('SUPPLY')[0][1:3]==[1,0]
        else:
            assert rows('SUPPLY')[0][1:3]==[1,1]
            assert rows('CONFIG')[0][5]==(8 if 'edf' in d.name else 9)
        assert 'REFUSED' in terminal
        return dict(terminal=terminal,launch=launch,calendar=rows('CALENDAR'),supply=rows('SUPPLY'),cap=rows('OWNER_CAP'))
    f,S,Q,*_ = rows('CONFIG')[0]
    assert f==10*Q and rows('A_STOP')==[[S+10*Q+Q//2]]
    D=rows('D'); J=rows('J'); events=rows('OWNER_EVENT')
    assert count==len(D)==len(events)==13 and len(J)==3*count
    buf=words(c/'ordinary_deadline_rows.bin')
    stride=buf.index(D[1][3], 30)-3
    assert all(buf[i*stride:i*stride+19]==row for i,row in enumerate(D))
    rowbytes=(c/'ordinary_deadline_rows.bin').read_bytes()
    for i in range(count):
        off=i*stride*8+160
        for j in range(3):
            assert [int.from_bytes(rowbytes[off+16*k:off+16*k+16],'little',signed=True) for k in range(6)]==J[i*3+j]
            off+=96
    assert words(c/'deadline_restore_count.bin')==[D[-1][6]]
    trace=(c/'int.trace').read_text()
    actual=[int(x,16) for x in re.findall(r'Exception return .* PC 0x([\da-f]+)',trace)]
    assert actual[1:]==[r[14] for r in D[:-1]]
    asm=gzip.open(d/'disassembly.gz','rt').read()
    assert re.search(r'bl\s+[\da-f]+ <deadline_recurring_reduce>\n[^\n]+str\s+x0',asm)
    assert 'ret' in asm.split('<deadline_recurring_reduce>:',1)[1].split('\n\n',1)[0]
    a=rows('RECURRING_RETURN')
    assert audit==sum(a,[]) and len(a)==2
    slots=[]; progresses=[]
    service_top,size=rows('SUPPLY')[0][3:5]
    for i,k in enumerate((1,9)):
        r,t=D[k:k+2]; p=J[3*k][-1]; progresses.append(p)
        assert r[9:11]==[0,4] and t[9:11]==[4,0] and r[11:13]==t[13:15]
        assert service_top-size<=r[13]<service_top and service_top-size<=a[i][3]<service_top
        assert r[11]<service_top-size and J[3*(k+1)][-1]==p
        first,last=64*i+1,64*i+64
        assert a[i][:3]==[i+1,first,last] and a[i][4]==sum(n*n for n in range(first,last+1))
        assert r[8]<=a[i][5]<S+(k+1)*Q and r[7]<r[8]<t[6]<t[7]
        slots.append(dict(slot=k,worker_frame=r[11],worker_pc=r[12],selected_service=r[13:15],restored_worker=t[13:15],entry=r[7],restore=t[6],exit=t[7],returned=a[i][5]))
    work=rows('RECURRING_WORK')
    assert 0<progresses[0]<progresses[1]<work[0][1] and work[1][1]>0
    for idx,b,v in work:
        # x -> 33*x+1; 32*x+1 -> 33*(32*x+1) mod 2**69
        mod=1<<69
        assert ((pow(33,b*64,mod)*(32*(idx+1)+1)-1)%mod)//32==v
    assert [r[0] for r in D]==[1]*11+[2]*2
    assert D[11][7]>=S+10*Q+Q//2 and D[11][7]<S+13*Q and D[12][7]<S+16*Q
    assert D[12][7]>=D[12][6]+f*30//1000
    irq_offsets=[]
    for i,r in enumerate(D[:11]):
        assert r[3]==r[4]==S+i*Q and r[3]<=r[7]<r[3]+Q
        irq_offsets.append(r[7]-r[3])
    assert all(D[i][3]==S+11*Q and D[i][7]<D[i][3] for i in (11,12))
    times=[r[7] for r in D]
    changes=[t for i,(t,r) in enumerate(zip(times,D)) if i+1<count and r[9]!=r[10]]
    aligned=[max(sum(S+k*Q<=t<S+(k+1)*Q for t in ts) for k in range(17)) for ts in (times,changes)]
    assert rows('RECURRING_SLOT_PEAK')==[[*aligned,3]]
    def peak(ts,w):
        starts={S,S+17*Q-w}|{max(S,min(t,S+17*Q-w)) for t in ts}
        return max(sum(x<=t<x+w for t in ts) for x in starts)
    widths={1,17*Q,Q}|{y-x+1 for x in times for y in times if y>=x}
    sampled=[]
    for w in sorted(widths):
        pe,pc=peak(times,w),peak(changes,w)
        bound=min(17,1+(w-1+Q-1)//Q)+2
        assert pc<=pe<=bound
        sampled.append([w,pe,pc,bound])
    pe,pc=peak(times,Q),peak(changes,Q)
    assert rows('OWNER_PEAK')==[[count,len(changes),pe,pc,4]]
    return dict(terminal=terminal,S=S,Q=Q,irq_offsets=irq_offsets,returns=a,launch=launch,worker=work,progress=progresses,handoffs=slots,event_peak=pe,owner_peak=pc,all_width_breakpoints=sampled)

res={}
for case in sorted(root.glob('[0-9][0-9]-*')):
    try: res[case.name]=verify(case)
    except Exception as e:
        import traceback
        res[case.name]={'error':traceback.format_exc()}
print(json.dumps(res,indent=2))
