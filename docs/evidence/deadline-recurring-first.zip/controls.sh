set -eu
root=$HOME/jnox274-rec
cd "$root"
export CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup RUSTUP_TOOLCHAIN=1.95.0
export PATH="$CARGO_HOME/bin:/usr/bin:/bin"
dest=$HOME/j274-controls
mkdir "$dest"
export CARGO_TARGET_DIR=$dest/target
rustc +1.95.0 -Vv > "$dest/rust.txt"
qemu-system-aarch64 --version > "$dest/qemu.txt"
git diff --stat FETCH_HEAD HEAD > "$dest/main-diff.txt"
rustc +1.95.0 --edition=2024 --cfg jnox_ordinary_deadline --test tools/deadline_supply_tests.rs -o "$dest/tests"
"$dest/tests" > "$dest/host-tests.log"
python3 tools/build_kernel.py > "$dest/boot-build.log" 2>&1
elf=$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel
cp "$elf" "$dest/boot.elf"
python3 tools/qemu_boot.py --kernel "$elf" --profile boot --capture-dir "$dest/boot-guest" > "$dest/boot.log" 2>&1
cd "$root/kernel"
cargo +1.95.0 build --locked --release -j1 --features deadline-bench > "$dest/bench-build.log" 2>&1
cp "$elf" "$dest/bench.elf"
python3 "$root/tools/qemu_boot.py" --kernel "$elf" --profile deadline --capture-dir "$dest/bench-guest" > "$dest/bench.log" 2>&1
for mode in cap wrong-profile; do
  if [ "$mode" = cap ]; then export JNOX_DEADLINE_OWNER_CAP=4; else unset JNOX_DEADLINE_OWNER_CAP; export JNOX_APP=ordinary-edf-recurring; fi
  if cargo +1.95.0 build --locked --release -j1 > "$dest/invalid-$mode.log" 2>&1; then exit 1; fi
done
