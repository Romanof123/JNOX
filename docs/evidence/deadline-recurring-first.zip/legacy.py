import os,sys,json,zipfile,subprocess as sp,hashlib,shutil,struct
from pathlib import Path
src=Path.home()/'jnox274-rec'
dest=Path.home()/'j274-legacy'
dest.mkdir(exist_ok=True)
archive=src/'docs/evidence/strict-class-owner-window-combined.zip'
z=zipfile.ZipFile(archive)
raw=dest/'raw.py'
raw.write_text(z.read('raw.py').decode().replace("p.Path.home()/'jnox262-combined/src/tools'","p.Path.home()/'jnox274-rec/tools'"))
def sha(b):return hashlib.sha256(b).hexdigest()
def load(b):
    phoff=struct.unpack_from('<Q',b,32)[0]
    plen,pnum=struct.unpack_from('<HH',b,54)
    segments=[]
    for i in range(pnum):
        t,flags,off,vaddr,paddr,n,mem,align=struct.unpack_from('<IIQQQQQQ',b,phoff+i*plen)
        if t==1: segments.append([vaddr,paddr,n,mem,flags,sha(b[off:off+n])])
    return segments
summary={}
names=[n for n in z.namelist() if n.startswith('originals/ordinary-') and n.endswith('/record.json')]
assert len(names)==24
for name in names:
    prefix=name.rsplit('/',1)[0]; key=prefix.split('/')[1]; d=dest/key; d.mkdir()
    env=os.environ.copy()
    env.update({k:v for k,v in json.loads(z.read(name))['env'].items() if k.startswith('JNOX_')})
    env['CARGO_TARGET_DIR']=str(dest/'target')
    (d/'selectors.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith('JNOX_')}))
    with (d/'build.log').open('wb') as f:
        rc=sp.call(['python3','tools/build_kernel.py'],cwd=src,env=env,stdout=f,stderr=sp.STDOUT)
    if rc: summary[key]={'build':rc};continue
    elf=d/'kernel.elf'
    shutil.copyfile(dest/'target/aarch64-unknown-none/release/jnox-kernel',elf)
    orig=z.read(prefix+'/kernel.elf'); new=elf.read_bytes()
    with (d/'observation.log').open('wb') as f:
        rc=sp.call(['python3',str(raw),str(elf),str(d/'guest')],cwd=src,stdout=f,stderr=sp.STDOUT)
    old=z.read(prefix+'/guest/uart.bin').decode().splitlines()
    cur=(d/'guest/uart.bin').read_text().splitlines()
    def tags(lines):return [l.split()[0] for l in lines if l.strip()]
    def text_hash(b):
        from tempfile import TemporaryDirectory
        with TemporaryDirectory() as td:
            t=Path(td); (t/'in').write_bytes(b)
            sp.run(['aarch64-linux-gnu-objcopy','-O','binary','-j','.text',t/'in',t/'out'],check=True)
            return sha((t/'out').read_bytes())
    summary[key]=dict(build=0,capture=rc,terminal=[old[-1],cur[-1]],same_fields=tags(old)==tags(cur),old_sha=sha(orig),new_sha=sha(new),old_text=text_hash(orig),new_text=text_hash(new),old_load=load(orig),new_load=load(new))
    (dest/'summary.json').write_text(json.dumps(summary,indent=2))
    print(key,rc,old[-1]==cur[-1],flush=True)
