#![allow(dead_code)]
#[path="/home/ywcho/jnox274-rec/kernel/src/deadline_jobs.rs"] mod deadline_jobs;
#[path="/home/ywcho/jnox274-rec/kernel/src/deadline_policy.rs"] mod deadline_policy;
#[path="/home/ywcho/jnox274-rec/kernel/src/ready_queue.rs"] mod ready_queue;
mod ordinary_deadline { pub fn counter()->u64 {unreachable!()} }
use deadline_policy::{DeadlineScheduler,DeadlinePolicy};
use deadline_jobs::*;
fn main() {
    let mut cases=0;
    for offset in 0..16 {
        for period in 1..=17 {
            for width in 1..=period {
                let mask=recurring_mask(offset,period,width).unwrap();
                let mut slots=[false;16];
                for start in (offset..16).step_by(period as usize) {
                    for k in start..(start+width).min(16) {slots[k as usize]=true;}
                }
                for policy in [DeadlinePolicy::Edf,DeadlinePolicy::Llf] {
                    for table in [&RECURRING[..],&RECURRING_TIGHT[..]] {
                        let mut model=DeadlineScheduler::<3>::new(policy,0,1).unwrap();
                        let mut left=[0u64;3];
                        let mut incumbent=None;
                        let mut admitted=true;
                        for k in 0..=16 {
                            if table.iter().any(|j|j.deadline==k && left[j.id]!=0){admitted=false;break}
                            if k==16 {break}
                            let withheld=slots[k as usize];
                            if withheld {model.withhold(k).unwrap();}
                            for j in table.iter().filter(|j|j.release==k) {
                                left[j.id]=j.cost; model.release(k,j.id,j.cost,j.deadline).unwrap();
                            }
                            if withheld {continue}
                            let chosen=table.iter().filter(|j|left[j.id]>0).min_by_key(|j|{
                                let rank=if policy==DeadlinePolicy::Edf {j.deadline as i64} else {j.deadline as i64-k as i64-left[j.id] as i64};
                                (rank,Some(j.id)!=incumbent,j.id)
                            }).map(|j|j.id);
                            assert_eq!(model.decide(k).unwrap(),chosen);
                            incumbent=chosen;
                            if let Some(i)=chosen {left[i]-=1;if left[i]==0{model.complete(k+1,i).unwrap();incumbent=None;}}
                        }
                        assert_eq!(admit_with_supply(policy,table,1000,200,mask).is_ok(),admitted);
                        cases+=1;
                    }
                }
            }
        }
    }
    println!("{cases} calendar/policy/table slot sequences matched through completion or first miss");
}
