from pathlib import Path
import collections,json,struct,zipfile
root=Path.home()/'j274-legacy'
archive=Path.home()/'jnox274-rec/docs/evidence/strict-class-owner-window-combined.zip'
def sections(b):
    shoff=struct.unpack_from('<Q',b,40)[0]
    size,count,idx=struct.unpack_from('<HHH',b,58)
    def header(i):return struct.unpack_from('<IIQQQQIIQQ',b,shoff+i*size)
    off,n=header(idx)[4:6]; strings=b[off:off+n]
    out={}
    for i in range(count):
        name,typ,flags,addr,off,n,*_=header(i)
        if flags&2 and typ!=8:out[strings[name:].split(b'\0')[0].decode()]=b[off:off+n]
    return out
out={}
with zipfile.ZipFile(archive) as z:
    for d in root.glob('ordinary-*'):
        old=sections(z.read('originals/'+d.name+'/kernel.elf'))
        new=sections((d/'kernel.elf').read_bytes())
        out[d.name]={k:dict(old=len(v),new=len(new[k]),different_bytes=sum(x!=y for x,y in zip(v,new[k]))+abs(len(v)-len(new[k]))) for k,v in old.items()}
print(json.dumps(out,indent=2))
