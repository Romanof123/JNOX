set -eu
source ~/.cargo/env
cd ~/pi322iv
e=/mnt/d/codex/pi322-independent
d=$e/d905
q=$HOME/arm-speed-lab-tools/qemu-11.1.3/build/qemu-system-aarch64
for p in fifo rr; do
 python3 tools/package_pi4.py --kernel "$d/$p/kernel8.img" --output "$d/boot-$p" --firmware-dir /mnt/d/codex/.jnox-work/batch-bd72722993/pi-irq-sd >"$d/package-$p.log"
 (cd "$d/boot-$p"; sha256sum -c SHA256SUMS) >>"$d/package-$p.log"
 cmp "$d/$p/kernel8.img" "$d/boot-$p/kernel8.img"
 tick=()
 if test "$p" = rr; then tick=(--quantum-ticks 1250000); fi
 python3 tools/build_native_el0.py --out "$d/virt-$p" --policy "$p" "${tick[@]}" --elf "$e/low.elf" --priority 2 --peer-elf "$e/high.elf" --peer-priority 2 >"$d/virt-$p.log" 2>&1
 timeout 5 "$q" -M virt,gic-version=2 -cpu cortex-a72 -accel tcg -display none -serial stdio -kernel "$d/virt-$p/kernel.elf" >"$d/virt-$p.uart" 2>"$d/virt-$p.stderr" || test "$?" = 124
done
(cd kernel; env JNOX_BOARD=pi4 JNOX_PROFILE=fixed JNOX_APP=fixed-fifo CARGO_TARGET_DIR="$d/linked-target" cargo build --release --locked -j1) >"$d/linked-build.log" 2>&1
aarch64-linux-gnu-objcopy -O binary "$d/linked-target/aarch64-unknown-none/release/jnox-kernel" "$d/linked.img"
python3 tools/qemu_boot.py --profile pi4-fixed-fifo --kernel "$d/linked.img" --qemu "$q" --runs 1 --capture-dir "$d/linked-capture" >"$d/linked-smoke.log" 2>&1
