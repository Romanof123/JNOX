from pathlib import Path
import subprocess as s,os,json,hashlib
e=Path('/mnt/d/codex/pi322-independent');d=e/'d905'; src=Path.home()/'pi322iv'; args=['python3','tools/build_native_el0.py','--out',str(d/'negative-output')]
opts=['--board','pi4','--policy','fifo','--elf',str(e/'low.elf'),'--priority','2','--peer-elf',str(e/'high.elf'),'--peer-priority','2']
for name,changes in [('board',{1:'bogus'}),('policy',{3:'edf'}),('elf',{5:'/etc/hostname'}),('count',{})]:
 a=opts.copy()
 for i,v in changes.items():a[i]=v
 if name=='count':a=a[:8]
 r=s.run(args+a,cwd=src,stdout=s.PIPE,stderr=s.STDOUT);(d/('refuse-'+name+'.log')).write_bytes(r.stdout); print(name,r.returncode,r.stdout[-90:]);assert r.returncode
env=dict(os.environ,JNOX_BOARD='pi4',JNOX_PROFILE='native',JNOX_APP='process',JNOX_NATIVE_POLICY='fifo',JNOX_NATIVE_ELF=str(e/'low.elf'),JNOX_NATIVE_ELF_SHA256=hashlib.sha256((e/'low.elf').read_bytes()).hexdigest(),JNOX_NATIVE_PRIORITIES='2,2',JNOX_NATIVE_PEER_ELF=str(e/'high.elf'),JNOX_NATIVE_PEER_ELF_SHA256=hashlib.sha256((e/'high.elf').read_bytes()).hexdigest(),CARGO_TARGET_DIR=str(d/'reject-target'))
for n,key,value,features in [('count','JNOX_NATIVE_PEER_ELF',None,[]),('policy','JNOX_NATIVE_POLICY','edf',[]),('feature','JNOX_NATIVE_POLICY','fifo',['--features','fifo-bench'])]:
 en=env.copy()
 if value is None: del en[key]
 else:en[key]=value
 a=['cargo','build','--locked','--release','-j1']+features
 r=s.run(a,cwd=src/'kernel',env=en,stdout=s.PIPE,stderr=s.STDOUT);(d/('refuse-cargo-'+n+'.log')).write_bytes(r.stdout);assert r.returncode;print('cargo',n,r.stdout[-150:])
for name in ['low','high']:
 data=(e/(name+'.elf')).read_bytes(); (d/(name+'8.elf')).write_bytes(data+b'\0'*(8388608-len(data)))
a=opts.copy();a[5]=str(d/'low8.elf');a[9]=str(d/'high8.elf');args[-1]=str(d/'max-link')
with (d/'max-link.log').open('wb') as log:s.run(args+a,cwd=src,stdout=log,stderr=s.STDOUT,check=True)
print('max', (d/'max-link/kernel8.img').stat().st_size)
