import subprocess as sp,pathlib as pl,time,json,sys
base=pl.Path('/mnt/d/codex/pi322-independent/d905')
q=str(pl.Path.home()/'arm-speed-lab-tools/qemu-11.1.3/build/qemu-system-aarch64')
p,mode=sys.argv[1:]; d=base/(p+'-'+mode); d.mkdir()
elf=base/p/'kernel.elf'
syms=sp.check_output(['nm','-nC',elf],text=True)
(d/'symbols').write_text(syms)
top=int(next(s.split()[0] for s in syms.splitlines() if s.endswith(' __stack_top')),16)
args=[q,'-M','raspi4b','-accel','tcg','-display','none','-serial','file:uart','-kernel',str(base/p/'kernel8.img'),'-monitor','stdio']
if mode=='traced':args+=['-d','int','-D','exceptions']
(d/'argv.json').write_text(json.dumps(args));(d/'qemu-version').write_bytes(sp.check_output([q,'--version']))
with (d/'monitor').open('wb') as out,(d/'stderr').open('wb') as err:
 proc=sp.Popen(args,cwd=d,stdin=sp.PIPE,stdout=out,stderr=err)
 time.sleep(4)
 cmds=['stop','info cpus']+[s for i in range(4) for s in ('cpu '+str(i),'info registers')]+[f'pmemsave 0x02000000 {top-0x02000000:#x} live.bin','quit']
 (d/'monitor-input').write_text('\n'.join(cmds)+'\n')
 proc.communicate(('\n'.join(cmds)+'\n').encode(),timeout=20)
 print(proc.returncode,(d/'uart').read_text()[-900:],list(d.glob('live.bin')))
