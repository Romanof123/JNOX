from pathlib import Path
import struct,re,json,subprocess as sp
d=Path('/mnt/d/codex/pi322-independent/d905')
for p in ('fifo','rr'):
 elf=d/p/'kernel.elf'; raw=(d/p/'kernel8.img').read_bytes(); eb=elf.read_bytes()
 h=sp.check_output(['readelf','-WlS',elf],text=True); (d/p/'elf-headers.txt').write_text(h)
 ends=[]
 for off,va,pa,fs,ms in re.findall(r'LOAD\s+(0x\w+)\s+(0x\w+)\s+(0x\w+)\s+(0x\w+)\s+(0x\w+)',h):
  off,va,pa,fs,ms=map(lambda v:int(v,16),(off,va,pa,fs,ms)); i=pa-0x80000; assert raw[i:i+fs]==eb[off:off+fs]; ends.append(i+fs)
 assert max(ends)==len(raw)
 for m in ('plain','traced'):
  root=d/(p+'-'+m); b=(root/'live.bin').read_bytes(); symbols=(root/'symbols').read_text(); base=0x2000000
  sy=lambda word:int(next(s.split()[0] for s in symbols.splitlines() if word in s),16)
  Q=lambda a:struct.unpack_from('<Q',b,a-base)[0]
  space=sy('6SPACES17h'); end=sy(' __bss_end'); roots=[space,space+(end-space)//2]; assert end-space==2*0x415000
  def walk(root,va):
   tab=root
   for sh in (30,21,12):
    ent=Q(tab+8*((va>>sh)&511))
    if not ent&1:return None
    tab=ent&0xfffff000
   return (tab+(va&4095),ent)
  vals=[]; rows=[]
  for idx,r in enumerate(roots):
   addrs=[0x400000,0x401000,0x402000,0x1000000,0x1001000,0x1010fff,0x1011000,0x2000000,sy('__native_rw_start'),sy('__stack_top')-4,sy('__stack_top'),0xfe200000,0xfe201000,0xff841000,0xff842000,0x9000000,0x8000000,0x8010000]
   table={hex(v):walk(r,v) for v in addrs}; rows.append(table)
   for v in [0x1000000,0x1011000,sy('__stack_top'),0x9000000,0x8000000,0x8010000]:assert walk(r,v) is None
   for v,ap,pxn,uxn in [(0x400000,3,1,0),(0x401000,3,1,1),(0x402000,1,1,1),(0x1001000,1,1,1),(0x2000000,2,0,1),(sy('__native_rw_start'),0,1,1),(sy('__stack_top')-4,0,1,1)]+[(v,0,1,1) for v in addrs[11:15]]:
    pa,t=walk(r,v); assert ((t>>6)&3,(t>>53)&1,(t>>54)&1)==(ap,pxn,uxn),(hex(v),hex(t))
    if v<0x2000000: assert t&2048
    if v>=0x2000000: assert pa==v
   priv=walk(r,0x402000)[0]; assert walk(r,priv)[1]>>6&3==0
   vals.append((priv,struct.unpack_from('<I',b,priv-base)[0]))
  assert vals[0][0]!=vals[1][0] and [v for _,v in vals]==[78498,70435]
  exits=struct.unpack_from('<ii',b,sy('::EXIT_STATUS')-base); assert exits==(12,77)
  lines=(root/'uart').read_text(); ev=[list(map(int,l.split()[3:])) for l in lines.splitlines() if l.startswith('NATIVE FIXED EVENT')]; sw=[x for x in ev if x[1]==4]
  assert len(sw)==0 if p=='fifo' else [x[3:5] for x in sw[:2]]==[[0,1],[1,0]]
  saved={}; worker=[(0x400470,0x4004d0),(0x400030,0x4000a0)]
  for x in sw:
   old,new=x[3:5]; pc,stack=x[5:7]; assert worker[old][0]<=pc<worker[old][1] and walk(roots[old],stack)
   if new in saved:assert x[7:9]==saved[new]
   saved[old]=[pc,stack]
  if m=='traced':
   tr=(root/'exceptions').read_text(); assert set(re.findall(r'on CPU (\d+)',tr))=={'0'}
   for x in sw:assert f'with ELR {x[5]:#x}' in tr and f'to AArch64 EL0 PC {x[7]:#x}' in tr
  info=dict(roots=roots,results=vals,exits=exits,rotations=len(sw),cpus=re.findall(r' PC=([\da-f]+)',(root/'monitor').read_text()),translation=rows)
  (root/'inspection.json').write_text(json.dumps(info,indent=2));print(p,m,vals,exits,len(sw))
