#!/usr/bin/env bash
set -euo pipefail
owner=${1:?WSL username required}
rootdir=$(cd "$(dirname "$0")" && pwd)
userhome=$(getent passwd "$owner" | cut -d: -f6)
export RAW=$userhome/v376-ipv4-906fdd0-first SRC=$userhome/v376-ipv4-906fdd0-checkout
export PYTHONPATH=$userhome/jnox-169-first-e203caa/deps
ns=jnox-v376-906fdd0-$$
ip netns add "$ns"
trap 'ip netns del "$ns"' EXIT
ip -n "$ns" link set lo up
ip netns exec "$ns" ip tuntap add dev jnx0 mode tap user "$owner"
ip -n "$ns" addr add 10.0.2.2/24 dev jnx0
ip -n "$ns" link set jnx0 up
{ ip -n "$ns" -br addr; ip -n "$ns" route; ip netns exec "$ns" ip tuntap; } > "$RAW/tap-root-config.txt"
for policy in fifo rr; do
    ip netns exec "$ns" bash "$rootdir/run-position.sh" "$policy" "$policy-tap-root" --isolated-tap jnx0 --timeout 10
done
