#!/usr/bin/env bash
set -euo pipefail
base=$(cd "$(dirname "$0")" && pwd)
src=$HOME/v376-ipv4-906fdd0-checkout
raw=$HOME/v376-ipv4-906fdd0-first
packet=$HOME/v376-ipv4-906fdd0-packet
mkdir -p "$packet/source"
cd "$raw"
tar --exclude=app-target --exclude=target -cf - . | tar -xf - -C "$packet"
cd "$src"
git archive 906fdd07e36fa9e2e6d53ba5aee412bd31e580b4 arch boards kernel sdk services examples tools trace verification docs/native-ipv4-socket-service.en-ko.md | tar -xf - -C "$packet/source"
cp "$base"/{issue-376-live.md,replay.py,control.py,controls.c,controls-verifier-draft.c,controls.sh,tap.sh,tap-root.sh,run-position.sh,REPORT.en-ko.md,seal.sh} "$packet"
cp "$src/services/inet/Cargo.lock" "$packet/service.Cargo.lock"
export PYTHONPATH=$HOME/jnox-169-first-e203caa/deps PYTHONDONTWRITEBYTECODE=1
cd "$packet"
python3 replay.py > replay.json
find . -type f ! -name 'SHA256SUMS' -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
sha256sum -c SHA256SUMS > "$base/verified-sha256.txt"
tar -czf "$base/376-ipv4-first-906fdd0.tar.gz" .
cd "$base"
sha256sum 376-ipv4-first-906fdd0.tar.gz > 376-ipv4-first-906fdd0.tar.gz.sha256
cp "$packet"/{revision.txt,platform.txt,replay.json,status.txt,SHA256SUMS} "$base"
wc -c 376-ipv4-first-906fdd0.tar.gz
cat 376-ipv4-first-906fdd0.tar.gz.sha256
