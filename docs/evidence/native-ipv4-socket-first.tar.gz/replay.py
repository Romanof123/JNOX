"""Offline replay from a digest-checked first-candidate packet. Run at packet root."""
import hashlib
import json
from pathlib import Path
import re
import struct
import sys

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'source' / 'tools'))
from native_amc_roots import linked_roots
from native_el0_replay import Snapshot, elf_file, permissions, symbol, vread

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

def packets(path):
    wire = path.read_bytes()
    assert wire[:4] == bytes.fromhex('d4c3b2a1') and struct.unpack_from('<I', wire, 20) == (1,)
    p = 24
    frames = []
    while p < len(wire):
        _, _, length, total = struct.unpack_from('<IIII', wire, p)
        assert length == total and len(wire) >= p + 16 + length and length >= 14
        frames.append(wire[p+16:p+16+length])
        p += 16 + length
    assert p == len(wire)
    return frames

def read_slot(mem, root_id, image, name):
    va, n = symbol(elf_file(image.read_bytes()), name)
    for address in range(va & ~4095, va + n, 4096):
        permissions(mem, root_id, address, 'user rw')
    return vread(mem, root_id, va, n)

def longs(data):
    return list(struct.unpack('<' + 'q' * (len(data)//8), data))

def queues(mem, kernel):
    addr, extent = symbol(elf_file(kernel.read_bytes()), 'jnox_native_net_queues')
    assert addr % 4096 == 0 and extent == 32768
    rows = []
    for direction in (0, 1):
        q = addr + direction * extent // 2
        descriptors = [struct.unpack('<QIHH', mem.read(q+16*i,16)) for i in range(8)]
        assert all(q <= address < q+extent//2 and address+length <= q+extent//2 and flags==(2 if direction==0 else 0) and next_id==0 for address,length,flags,next_id in descriptors)
        available = struct.unpack('<H',mem.read(q+130,2))[0]
        used = struct.unpack('<H',mem.read(q+154,2))[0]
        rows.append(dict(direction='tx' if direction else 'rx',available=available,used=used))
    return rows, mem.read(descriptors[0][0]+12,descriptors[0][1]-12)

def position(pkg, cap, mode):
    manifest = json.loads((pkg / 'manifest.json').read_text())
    kernel = pkg / 'kernel.elf'
    launch = json.loads((cap / 'launch.json').read_text())
    assert manifest['commit'] == '906fdd07e36fa9e2e6d53ba5aee412bd31e580b4'
    assert digest(kernel)==manifest['kernel_elf_sha256']==launch['kernel_sha256']
    argv=launch['argv']
    assert argv[argv.index('-smp')+1]=='1' and argv[argv.index('-cpu')+1]=='cortex-a72'
    assert all(digest(pkg/s['elf'])==s['elf_sha256'] for s in manifest['slots'])
    roots=linked_roots(kernel,len(manifest['slots']))
    mem=Snapshot(0x40000000,(cap/'ram.bin').read_bytes())
    assert len(mem.raw)==128<<20
    uart=(cap/'uart').read_text()
    exits=[list(map(int, pair)) for pair in re.findall(r'NATIVE EL0 EXIT PID (\d+) (-?\d+)',uart)]
    net=[list(map(int,s.split()[3:])) for s in uart.splitlines() if s.startswith('NATIVE NET DEVICE ')]
    report=dict(exits=exits,device=net)
    if mode!='main':
        rows=[longs(read_slot(mem,r,pkg/'user.elf','receipts')) for r in roots]
        if mode=='enabled':
            assert exits==[[0,51],[1,52]] and rows==[[-13]*3+[0]*3,[-11,-90,-11,-90,-90,0]]
        else:
            assert exits==[[0,51],[1,51]] and rows==[[-38]*3+[0]*3]*2
        assert bool(net)==(mode=='enabled')
        report['private']=rows
        return report
    assert 'virtio-mmio.force-legacy=false' in argv
    netdev=argv[argv.index('-netdev')+1]
    assert netdev=='tap,id=lan,ifname=jnx0,script=no,downscript=no' or netdev=='user,id=lan,net=10.0.2.0/24,host=10.0.2.2,hostfwd=tcp:127.0.0.1:43001-10.0.2.15:43001'
    tcp=longs(read_slot(mem,roots[0],pkg/'user.elf','inet_tcp_result'))
    udp=longs(read_slot(mem,roots[1],pkg/'native_peer.elf','inet_udp_result'))
    assert tcp==[0]*12 and udp==[3]+[0]*14+[-32] and exits==[[0,103],[1,113],[2,85]]
    assert json.loads((cap/'private.json').read_text())==dict(inet_tcp_result=tcp,inet_udp_result=udp)
    broker=pkg/'native_peer2.elf'
    names=[s.name for s in elf_file(broker.read_bytes()).get_section_by_name('.symtab').iter_symbols() if '6FRAMES17h' in s.name]
    assert len(names)==1
    storage=read_slot(mem,roots[2],broker,names[0])
    # The linked Tx::flush and main instructions in broker.disasm give these private offsets.
    length=struct.unpack_from('<Q',storage,0)[0]
    assert length==42 and storage[1546]==1 and storage[3066]==1
    raw_frames=packets(cap/'wire.pcap')
    frames=[]
    header_lengths=[]
    for data in raw_frames:
        # QEMU 6.2 filter-dump includes vnet headers on TAP but labels the pcap Ethernet.
        # Match this frozen capture's known Ethernet types and zero vnet metadata.
        possible=[n for n in ([10,12] if netdev.startswith('tap,') else [0])
                  if data[:n]==bytes(n) and data[n+12:n+14] in (bytes.fromhex('0806'),bytes.fromhex('0800'),bytes.fromhex('86dd'))]
        assert len(possible)==1
        header_lengths.append(possible[0])
        frames.append(data[possible[0]:])
    ring, tx=queues(mem,kernel)
    assert ring[1]['available']==ring[1]['used']==1
    assert tx==storage[32:32+length] and tx in frames
    assert tx[12:14]==b'\x08\x06' and tx[20:22]==b'\x00\x01'
    assert tx[28:32]==bytes([10,0,2,15]) and tx[38:42]==bytes([10,0,2,2])
    assert all(frame[12:14] != b'\x08\x00' for frame in frames)
    assert net[0][3:5]==[1,1] and net[0][-1]==0
    assert (cap/'peer.jsonl').read_bytes()==b''
    report.update(private={'tcp':tcp,'udp':udp},queues=ring,
                  device_frames=len(frames),capture_prefix_bytes=header_lengths,ethertypes=[p[12:14].hex() for p in frames],
                  tx_arp=tx.hex(),tx_pending=length,tx_error=storage[1546],frames_error=storage[3066])
    return report

out={}
for policy in ('fifo','rr'):
    for name in ('slirp-first','tap-root'):
        cap=f'{policy}-{name}'
        out[cap]=position(root/policy,root/cap,'main')
    for mode in ('enabled','local','plain'):
        name=f'{mode}-{policy}'
        out[name]=position(root/f'pkg-{name}',root/f'cap-{name}',mode)
print(json.dumps(out,indent=2))
