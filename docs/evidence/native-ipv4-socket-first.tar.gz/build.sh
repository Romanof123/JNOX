#!/usr/bin/env bash
set -euo pipefail
rev=906fdd07e36fa9e2e6d53ba5aee412bd31e580b4
src=${SRC:-$HOME/v376-ipv4-906fdd0-checkout}
raw=${RAW:-$HOME/v376-ipv4-906fdd0-first}
mkdir "$src" "$raw"
git -C "$src" init -q
echo "${OBJECTS:-/mnt/d/codex/j-nox/.git/objects}" > "$src/.git/objects/info/alternates"
cd "$src"
git sparse-checkout init --cone
git sparse-checkout set arch boards examples kernel sdk services tools trace verification
git -c advice.detachedHead=false checkout -q --detach "$rev"
git rev-parse HEAD 'HEAD^{tree}' 'HEAD^' > "$raw/revision.txt"
test "$(git rev-parse HEAD)" = "$rev"
test -z "$(git status --porcelain --untracked-files=no)"
git show "$rev:docs/native-ipv4-socket-service.en-ko.md" > "$raw/guide.md"
cp examples/native-inet-sockets/README.md "$raw/workload.md"
cp "$(realpath "$0")" "$raw/build.sh"
source "$HOME/.cargo/env"
export CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$raw/app-target"
export PYTHONPATH="${PYTHONPATH:-}:$HOME/jnox-169-first-e203caa/deps"
(date -u; uname -a; rustc -Vv; cargo -V; qemu-system-aarch64 --version; clang --version; python3 -V; ip -V) > "$raw/platform.txt"
run() {
  local tag=$1 status=0
  shift
  printf '%q ' "$@" >> "$raw/commands.sh"
  echo >> "$raw/commands.sh"
  "$@" > "$raw/$tag.log" 2>&1 || status=$?
  echo "$tag $status" | tee -a "$raw/status.txt"
  if ((status)); then tail -45 "$raw/$tag.log"; fi
  return "$status"
}
app=examples/native-inet-sockets
run cc sh sdk/native-aarch64/build.sh --local-socket "$app/tcp.c" "$raw/tcp.elf"
run rust sh sdk/native-aarch64/build-rust.sh --local-socket "$app/udp/Cargo.toml" "$raw/udp.elf"
sha256sum services/inet/Cargo.lock > "$raw/lock-before.sha256"
run broker sh sdk/native-aarch64/build-rust.sh services/inet/Cargo.toml "$raw/broker.elf"
sha256sum --check "$raw/lock-before.sha256"
for pol in fifo rr; do
    quantum=()
    if [[ $pol == rr ]]; then quantum=(--quantum-ticks 625000); fi
    run "pkg-$pol" python3 tools/build_native_el0.py --out "$raw/$pol" --policy "$pol" --elf "$raw/tcp.elf" --priority 4 --peer-elf "$raw/udp.elf" --peer-priority 4 --peer-elf "$raw/broker.elf" --peer-priority 7 --peer2-arg 3 --ipc-route 0:2 --ipc-route 1:2 --socket-service 2 --net-service 2 "${quantum[@]}"
done
