#!/usr/bin/env bash
set -euo pipefail
rootdir=$(cd "$(dirname "$0")" && pwd)
raw=$HOME/v376-ipv4-906fdd0-first
src=$HOME/v376-ipv4-906fdd0-checkout
source "$HOME/.cargo/env"
cd "$src"
export CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONPATH=$HOME/jnox-169-first-e203caa/deps
cp "$rootdir/controls.c" "$raw/controls.c"
sh sdk/native-aarch64/build.sh "$raw/controls.c" "$raw/controls.elf" > "$raw/build-control.log" 2>&1
for pol in fifo rr; do
    quantum=()
    if [[ $pol == rr ]]; then quantum=(--quantum-ticks 625000); fi
    for mode in enabled local plain; do
        name=$mode-$pol
        case "$mode" in
            enabled) args=(--arg c --peer-elf "$raw/controls.elf" --peer-arg b --peer-priority 7 --ipc-route 0:1 --socket-service 1 --net-service 1) ;;
            local) args=(--arg d --peer-elf "$raw/controls.elf" --peer-arg d --peer-priority 7 --ipc-route 0:1 --socket-service 1) ;;
            plain) args=(--arg d --peer-elf "$raw/controls.elf" --peer-arg d --peer-priority 7) ;;
        esac
        python3 tools/build_native_el0.py --out "$raw/pkg-$name" --policy "$pol" --elf "$raw/controls.elf" --priority 4 "${quantum[@]}" "${args[@]}" > "$raw/pkg-$name.log" 2>&1
        ret=0
        python3 "$rootdir/control.py" "$raw/pkg-$name" "$raw/cap-$name" "$mode" "$src" > "$raw/control-$name.log" 2>&1 || ret=$?
        echo "$name $ret" | tee -a "$raw/status.txt"
    done
done
