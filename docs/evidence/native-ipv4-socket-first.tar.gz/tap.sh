#!/usr/bin/env bash
set -euo pipefail
owner=${1:?WSL username required}
rootdir=$(cd "$(dirname "$0")" && pwd)
raw=${RAW:-$(getent passwd "$owner" | cut -d: -f6)/v376-ipv4-906fdd0-first}
ns=jnox-v376-906fdd0-$$
ip netns add "$ns"
trap 'ip netns del "$ns"' EXIT
ip -n "$ns" link set lo up
ip netns exec "$ns" ip tuntap add dev jnx0 mode tap user "$owner"
ip -n "$ns" addr add 10.0.2.2/24 dev jnx0
ip -n "$ns" link set jnx0 up
{ ip -n "$ns" -br addr; ip -n "$ns" route; ip netns exec "$ns" ip tuntap; } > "$raw/tap-config.txt"
for policy in fifo rr; do
    ip netns exec "$ns" runuser -u "$owner" -- bash "$rootdir/run-position.sh" "$policy" "$policy-tap-first" --isolated-tap jnx0 --timeout 12
done
