#include <stdint.h>

volatile long receipts[6];
static unsigned char frame[1514];

static long net_call(unsigned op, unsigned length) {
    register uint64_t x0 __asm__("x0") = (uintptr_t) frame;
    register uint64_t x1 __asm__("x1") = length;
    register uint64_t x8 __asm__("x8") = op;
    __asm__ volatile("svc #0x4a01" : "+r"(x0), "+r"(x1) : "r"(x8) : "x2", "x3", "cc", "memory");
    return (long) x0;
}

int main(int argc, char **argv) {
    if (argc != 2) return 90;
    char role = argv[1][0];
    receipts[0] = net_call(38, sizeof frame);
    receipts[1] = net_call(39, 13);
    receipts[2] = net_call(40, 0);
    if (role == 'b') {
        receipts[3] = net_call(38, 13);
        receipts[4] = net_call(39, 1515);
        return receipts[0] == -11 && receipts[1] == -90 && receipts[2] == -11
            && receipts[3] == -90 && receipts[4] == -90 ? 52 : 92;
    }
    long expected = role == 'c' ? -13 : -38;
    return receipts[0] == expected && receipts[1] == expected && receipts[2] == expected ? 51 : 91;
}
