from pathlib import Path
import hashlib, json, re
p = Path(__file__).resolve().parent
for name, expected in json.loads((p/'manifest.json').read_text()).items():
    assert hashlib.sha256((p/name).read_bytes()).hexdigest() == expected, name
for number, pcs, target, count in [('79',['4020127c','40201260']*2,'40201440',10),('110',['40201278'],'40201a98',8)]:
    log = (p/(number+'-exceptions.log')).read_text()
    assert re.findall(r'with ELR 0x([0-9a-f]+)', log) == pcs
    listing = (p/(number+'-disassembly.txt')).read_text()
    assert len(re.findall(r'\bbl\s+'+target+r'\b',listing)) == count
print('Hashes, original IRQ PCs, direct fail call counts verified.')
