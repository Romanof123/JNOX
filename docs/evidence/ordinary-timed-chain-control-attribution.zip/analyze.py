from pathlib import Path
from collections import defaultdict
from hashlib import sha256
import json,re,subprocess,sys,zipfile,io,struct
repo=Path(sys.argv[1]); commit='317d7365ad966441453eabb38aeab1c78e751f7b'
read=lambda p:subprocess.check_output(['git','-C',str(repo),'show',commit+':'+p])
out={}
for cohort,slug in [('feature','first'),('combined','integration')]:
    data=read('docs/evidence/ordinary-timed-chain-'+slug+'.zip')
    h=sha256(data).hexdigest()
    assert h=={'feature':'001d81b80f4e5635676bd6c2f13b31f03d4077e9ff132f226deec726f79353e7','combined':'fa89510c77757edbcbd70c300c69663f5e7220d31a1303f84015c6207db362fd'}[cohort]
    z=zipfile.ZipFile(io.BytesIO(data)); assert z.testzip() is None
    for selector in ['pi','ceiling','chain']:
        prefix='ordinary-'+selector+'/'; elf=z.read(prefix+'kernel.elf'); asm=z.read(prefix+'linked.asm').decode().splitlines()
        phoff=struct.unpack_from('<Q',elf,32)[0]; phsize,count=struct.unpack_from('<HH',elf,54)
        loads=[]
        for i in range(count):
            typ,flags,offset,va,pa,size,mem,align=struct.unpack_from('<II6Q',elf,phoff+i*phsize)
            if typ==1: loads.append([va,pa,flags,size,mem,sha256(elf[offset:offset+size]).hexdigest()])
        for mode in ['plain','trace']:
            rows=defaultdict(list)
            for l in z.read(prefix+mode+'.uart').decode().splitlines():
                k,*v=l.split()
                if k in ['E','R','K','T','H','B','HIGH','A','M','P','C']:rows[k].append([int(s,16) for s in v])
            e=rows['E'];r=rows['R']; i=next(i for i,x in enumerate(e) if x[2]==5); irq=e[i]; t=rows['T'][0]; start,cv=t[1:3]; pc=irq[7]
            def instr(address):
                j=next(j for j,l in enumerate(asm) if re.match(r'^\s*%x:'%address,l))
                return [next(l.strip() for l in reversed(asm[:j]) if l.endswith('>:')),asm[j].strip()]
            if mode=='trace' and selector!='chain':
                ext=z.read(prefix+'exceptions.log').decode()
                assert [int(x,16) for x in re.findall(r'with ELR 0x([0-9a-f]+)',ext)]==[x[7] for x in e]
                assert [int(x,16) for x in re.findall(r'Exception return .*?PC 0x([0-9a-f]+)',ext)]==[x[1] for x in r]
            out['/'.join([cohort,selector,mode])]=dict(zip_sha=h,elf_sha=sha256(elf).hexdigest(),loads=loads,start=start,target=cv,entry=irq[0],late=irq[0]-cv,restore=r[i],restore_minus_start=r[i][2]-start,entry_minus_restore=irq[0]-r[i][2],prev_event=e[i-1],irq=irq,instr=instr(pc),prev_restore_instr=instr(r[i][1]),chunks=irq[20],in_work=irq[21],header=rows['H'][0],markers=rows['K'],ledger_rows=len(rows['C']),outputs={k:rows[k] for k in ['B','HIGH','A','M','P']})
for s in ['pi','ceiling','chain']:
    assert all(out['feature/'+s+'/plain'][k]==out['combined/'+s+'/plain'][k] for k in ['elf_sha','loads'])
print(json.dumps(out,indent=2))
