/usr/bin/python3 src/tools/native_idle_markers.py spec --kernel "$k/kernel.elf" --plugin marker.so --output markers.bin > spec
echo 'iv343-control-01, iv343-observer-01 once each. Archived flags, four running reads, 90ms sleep, 105s gate and 150s emergency watchdog; one setup TID query, default sampler, no additional providers. See capture source and historical launch.'
sha256sum marker.so spec
/usr/bin/python3 src/tools/native_idle_delivery_capture.py control --out iv343-control-01 --kernel "$k/kernel.elf"
set +e
/usr/bin/python3 src/tools/native_idle_delivery_capture.py observed --out iv343-observer-01 --kernel "$k/kernel.elf" --plugin "$(cat spec)"
echo "observer_exit=$?"
/usr/bin/python3 src/tools/native_idle_delivery_report.py --control iv343-control-01 --observed iv343-observer-01 --preflight preflight/preflight.json --wait-calibration calibration/wait-calibration.json --kernel "$k/kernel.elf" --apps "$k/user.elf" "$k/native_peer.elf" "$k/native_peer2.elf" --markers markers.bin > result.json
echo "report_exit=$?"
