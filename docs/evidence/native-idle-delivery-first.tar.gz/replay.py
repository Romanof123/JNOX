import sys,json,os
from pathlib import Path
from argparse import Namespace
p=Path.cwd()
sys.path.insert(0,str(p/'src/tools'))
import native_idle_delivery_report as r
full='_ZN11jnox_kernel14native_el0_mmu6SPACES17h746e7fcfb4f25aceE.llvm.14211063895235707904'
original=r.symbol
def exact(table,name):
    assert name=='6SPACES'
    return original(table,full)
r.symbol=exact
k=p/'upstream/packages/wake'
args=Namespace(control=p/'iv343-control-01',observed=p/'iv343-observer-01',kernel=k/'kernel.elf',apps=[k/n for n in ['user.elf','native_peer.elf','native_peer2.elf']],markers=p/'markers.bin',wait_calibration=p/'calibration/wait-calibration.json',preflight=p/'preflight/preflight.json')
try:
    result=r.analyze(args)
    (p/'offline-report.json').write_text(json.dumps(result,indent=2))
except Exception:
    import traceback
    traceback.print_exc()
src=(p/'upstream/audit.py').read_text().split('for d in sorted((root/')[0]
ns={'__file__':str(p/'upstream/audit.py')}
exec(src,ns)
for d in [args.control,args.observed]:
    root=p/'replay'/d.name
    root.mkdir(parents=True)
    for f in d.iterdir():
        (root/f.name).symlink_to(f)
    (root/'outcome').write_text(str(json.loads((d/'outcome.json').read_text())))
    root2=root.parent/(d.name+'-view')
    root2.mkdir()
    (root2/'wake-trace').symlink_to(root)
    try:
        result=ns['audit'](root2/'wake-trace')
        (root/'replay.json').write_text(json.dumps(result,indent=2))
    except Exception:
        import traceback
        traceback.print_exc()
