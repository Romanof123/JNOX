set -eu
cd ~/iv343-first
exec > freeze.log 2>&1
set -x
echo 'Prequalification diagnostics: GitHub CLI gh missing on PowerShell; WSL rg missing; /usr/include/qemu-plugin.h absent (candidate uses its own stock ABI declarations); output directory did not exist before creation.'
mkdir upstream
tar -xzf src/docs/evidence/native-hierarchy-refill-health-first.tar.gz -C upstream
(cd upstream && sha256sum -c MEMBER-SHA256 > ../archive.check)
a=upstream/packages/wake
k=~/iv340-a1a6-first/packages/wake
for f in kernel.elf user.elf native_peer.elf native_peer2.elf manifest.json; do cmp "$a/$f" "$k/$f"; done
cmp upstream/raw/wake-trace/launch.json ~/iv340-a1a6-first/raw/wake-trace/launch.json
sha256sum src/docs/evidence/*.gz "$k"/*.elf /usr/bin/qemu-system-aarch64
uname -a
id
df -T .
cat /proc/sys/kernel/random/boot_id
date -u
cc -O2 -Wall -Wextra -shared -fPIC -o marker.so src/tools/native_idle_markers.c
nm -D /usr/bin/qemu-system-aarch64 > qemu.symbols
for sym in $(nm -D marker.so | awk '/ U qemu_plugin/{print $2}'); do grep -w "$sym" qemu.symbols; done
/usr/bin/python3 src/tools/native_idle_delivery_capture.py preflight --out preflight
/usr/bin/python3 src/tools/native_idle_wait_calibration.py --out calibration || echo insufficient_calibration
/usr/bin/python3 src/tools/native_idle_markers.py spec --kernel "$k/kernel.elf" --plugin marker.so --output markers.bin > spec
echo 'iv343-control-01, iv343-observer-01 once each. Archived flags, four running reads, 90ms sleep, 105s gate and 150s emergency watchdog; one setup TID query, default sampler, no additional providers. See capture source and historical launch.'
sha256sum marker.so spec
/usr/bin/python3 src/tools/native_idle_delivery_capture.py control --out iv343-control-01 --kernel "$k/kernel.elf"
set +e
/usr/bin/python3 src/tools/native_idle_delivery_capture.py observed --out iv343-observer-01 --kernel "$k/kernel.elf" --plugin "$(cat spec)"
echo "observer_exit=$?"
/usr/bin/python3 src/tools/native_idle_delivery_report.py --control iv343-control-01 --observed iv343-observer-01 --preflight preflight/preflight.json --wait-calibration calibration/wait-calibration.json --kernel "$k/kernel.elf" --apps "$k/user.elf" "$k/native_peer.elf" "$k/native_peer2.elf" --markers markers.bin > result.json
echo "report_exit=$?"
