#!/usr/bin/env bash
set -euo pipefail
t=$(cd "${1:?extracted packet directory}" && pwd)
out=${2:?new results directory}
mkdir "$out"
out=$(cd "$out" && pwd)
export PYTHONDONTWRITEBYTECODE=1
python3 "$t/first/reduce.py" "$t" "$out"
cmp "$t/first/boots.json" "$out/boots.json"
cmp "$t/first/mutations.json" "$out/mutations.json"
# Historical comparison writes two fresh JSON files in a separate directory.
mkdir "$out/historical"
ln -s "$t/historical/packages" "$out/historical/packages"
ln -s "$t/historical/runs" "$out/historical/runs"
python3 "$t/scripts/historical-check.py" "$out/historical" "$t/first/reduce.py"
for p in fifo rr; do cmp "$t/historical/$p-review.json" "$out/historical/$p-review.json"; done
