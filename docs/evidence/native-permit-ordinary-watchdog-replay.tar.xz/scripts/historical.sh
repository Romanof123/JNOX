#!/usr/bin/env bash
set -euo pipefail
rev=$1
lab="$HOME/permit402-$rev"; src="$lab/src"; out="$lab/historical"
cd "$src"; exec 9>"$lab/lane.lock"; flock -n 9
test ! -e "$out"; mkdir -p "$out"/{apps,packages,runs}
export PATH="$HOME/.cargo/bin:$PATH" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1 LC_ALL=C TZ=UTC
for var in $(compgen -e JNOX_); do unset "$var"; done
test "$(git rev-parse HEAD)" = "$rev"; test -z "$(git status --short --untracked-files=no)"
elf="$out/apps/original.elf"; cp "$HOME/permit389-hotpath-independent/apps/worker.elf" "$elf"
echo "be0d42e614cb76aa21733f0726a63a4aedab1d23fa4fcfe971b8d54e9f3aba07  $elf" | sha256sum -c -
for policy in fifo rr; do
 id="qualification-$policy-healthy"
 pkg="$out/packages/$id"; dest="$out/runs/$id"; mkdir "$dest"
 quantum=(); if [[ $policy = rr ]]; then quantum=(--quantum-ticks 625000); fi
 (set -x; python3 tools/build_native_el0.py --board virt --policy "$policy" "${quantum[@]}" --out "$pkg" --elf "$elf" --peer-elf "$elf" --peer-elf "$elf" --arg sender --arg healthy --peer-arg controller --peer-arg healthy --peer2-arg supervisor --peer2-arg healthy --priority 6 --peer-priority 7 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel --safety-qualification --safety-watchdog) >"$dest/build.log" 2>&1
 date -u +%FT%T.%NZ >"$dest/start.utc"; rc=0
 (set -x; python3 tools/native_el0_capture.py "$dest/cap" "$pkg/kernel.elf" "$elf" examples/native-safety-watchdog/src/main.rs "$rev" --manifest "$pkg/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608) >"$dest/capture.log" 2>&1 || rc=$?
 date -u +%FT%T.%NZ >"$dest/finish.utc"; echo "$rc" >"$dest/status"
 echo "$policy $rc"
done
