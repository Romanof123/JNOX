import importlib.util,json,sys
from pathlib import Path
root=Path(sys.argv[1]); spec=importlib.util.spec_from_file_location('standalone',sys.argv[2])
replay=importlib.util.module_from_spec(spec);spec.loader.exec_module(replay)
wanted='be0d42e614cb76aa21733f0726a63a4aedab1d23fa4fcfe971b8d54e9f3aba07'
for policy in ('fifo','rr'):
    name='qualification-'+policy+'-healthy'
    d=replay.reduce_one(replay.load(root,name))
    assert d['images']['user_sha']==wanted and len(d['heartbeats'])==29
    (root/(policy+'-review.json')).write_text(json.dumps(d,indent=2)+'\n')
    print(policy,d['images']['user_sha'],len(d['heartbeats']))
