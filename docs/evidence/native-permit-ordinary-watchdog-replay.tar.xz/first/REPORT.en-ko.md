# Independent readback of the first 14 #402 boots / 최초 14회 독립 판독

At source `98163cbef9d436e1216eb53c3f86faaf23d6e2aa`, the ordinary three-role image enabled its virtual output on FIFO and RR, autonomously inhibited it on all eight induced heartbeat timeouts, and held it down through each late COMPLETE. Both healthy ordinary boots completed all 29 scheduled phases without a 5 ms heartbeat break. Both exceeded the separate 1 ms phase budget. Each of the 14 terminal register words read zero. All three role exits were 71, 72, 73 in each boot. [Acceptance criteria](https://github.com/Romanof123/JNOX/issues/402)

일반 FIFO·RR 두 정책 모두 정상 입력 두 개와 재무장으로 가상 출력을 켰다. 의도적으로 완료를 누락한 여덟 실행 모두 타이머 경로에서 차단했고, 늦은 COMPLETE도 거절했다. 정상 실행은 각각 29회 완료하며 5 ms 간격을 지켰고 1 ms 위상 예산은 초과했다. 14회 모두 종료 후 독립 가상 출력 레지스터 값은 0이었고 세 역할의 종료값은 각각 71, 72, 73이었다.

## Per-boot measurements / 부팅별 측정값

All times below are counter ticks at 62,500,000 Hz. A 5 ms interval contains 312,500 ticks. The last allowed interval ends at that tick. The first disallowed tick D for a protected completion L is L + 312,501. Each maximum below uses consecutive successful protected completions **within one generation**. The eight deliberately broken chains appear in the next table. The phase column counts completed phases whose post-COMPLETE observation already exceeded 62,500 ticks after the scheduled target. In ordinary mode that observation comes from SVC61 after SVC60 and establishes a lower bound on full phase completion time.

모든 값은 62.5 MHz 카운터 틱이다. 허용되는 마지막 간격은 312,500틱이고, 최초 금지 틱 D는 실제 완료 L + 312,501이다. 최대 간격은 같은 세대에서 연속 성공한 완료만 사용했다. 의도적으로 끊은 간격은 다음 표에 별도로 표시했다. 위상 초과 수는 예정 목표에서 완료 후 상태를 관찰하기까지 이미 62,500틱을 넘긴 횟수다. 일반 모드에서는 SVC60 이후 SVC61을 호출하므로 전체 위상 소요시간의 하한이다.

| Boot / 부팅 | Protected completions / 완료 | Max gap / 최대 간격 | Post-sample >1 ms / 위상 초과 | Max target→post / 최대 소요 |
| --- | ---: | ---: | ---: | ---: |
| ordinary FIFO healthy | 29 | 172441 | 2 | 73463 |
| ordinary FIFO sleep-late | 8 | 174608 | 1 | 71902 |
| ordinary FIFO compute-late | 8 | 173102 | 2 | 81146 |
| ordinary RR healthy | 29 | 172668 | 2 | 75798 |
| ordinary RR sleep-late | 8 | 168121 | 2 | 72617 |
| ordinary RR compute-late | 8 | 171082 | 2 | 73315 |
| qualification FIFO healthy | 29 | 231742 | 2 | 102207 |
| qualification RR healthy | 29 | 181604 | 2 | 72268 |
| ordinary FIFO controller-exit | 8 | 176805 | 2 | 75536 |
| ordinary FIFO recover | 22 | 168150 | 2 | 80395 |
| ordinary FIFO recover-live | 22 | 174935 | 2 | 84297 |
| ordinary RR controller-exit | 8 | 181845 | 2 | 107917 |
| ordinary RR recover | 22 | 178887 | 1 | 79792 |
| ordinary RR recover-live | 22 | 174019 | 2 | 85648 |

Healthy ordinary FIFO/RR maximum protected gaps were 2.759056 / 2.762688 ms. The largest target-to-post samples were 1.175408 / 1.212768 ms. Even the protected completion itself exceeded 1 ms in one FIFO phase and two RR phases. The largest target-to-initial-observation lags were 26,974 / 27,516 ticks. The largest protected-completion-to-post-sample delays were 6,989 / 8,523 ticks. These are separate per-column maxima that can occur in different phases. The ordinary worker samples the raw counter before monotonic time, computes a rounded-up absolute sleep target and rechecks the counter after wake. Actual time to observation includes sampling skew, dispatch and execution. The captures give no WCET or physical-device admission. In the qualification healthy pair the target-to-stage-3-entry maxima were 103,837 / 73,270 ticks, with two exceedances each.

정상 일반 FIFO·RR의 실제 완료 간격 최댓값은 각각 2.759056 / 2.762688 ms였다. 예정 목표에서 완료 후 관측까지의 최댓값은 1.175408 / 1.212768 ms였다. 커널 내부 완료 자체가 1 ms를 넘긴 위상도 FIFO 1개, RR 2개였다. 예정 목표에서 첫 관측까지의 최대 지연은 26,974 / 27,516틱, 보호 완료에서 사후 관측까지의 최대 지연은 6,989 / 8,523틱이었다. 각 최대치는 서로 다른 위상에서 나올 수 있다. 원시 카운터와 단조 시계 표본 사이의 시간차, 절대 대기, 디스패치와 실행 시간이 실측에 포함된다. WCET와 실물 장치 수용성은 별도 검증 대상이다.

## Timeout and output / 만료 및 출력

Every injection started with generation 1, accepted sequence 2 with permit 1, primed and enabled, following authenticated supervisor and controller rearm. The protected timeout source was 30 on every row below. The kernel sets that source after reading the GIC IAR and matching the timer interrupt ID. The device register write/readback bracket falls after the timeout decision and before the late controller call entry. At each sticky fault the stored last completion stayed intact, due cleared, pending rearm cleared, both fault bits set, and the accepted issue remained the previous protected COMMIT's issue. All eight late SVC60 COMPLETEs returned −110. Same-generation supervisor REARM returned −11. The retained permit was younger than 20 ms at the heartbeat timeout in all eight.

각 주입 전 세대 1, 순번 2, 허가값 1을 보호 채널에서 수락했고 실제 출력·감시가 켜진 상태였다. 아래 여덟 판정 모두 GIC의 타이머 인터럽트 ID를 확인한 커널 분기에서 출처 30을 남겼다. 출력 차단 쓰기와 읽기 확인은 만료 판정 후, 늦은 완료 호출 진입 전에 끝났다. 마지막 완료 시각과 이미 수락된 허가 입력은 유지됐고 감시 기한과 재무장 대기는 해제됐다. 두 고장 비트가 켜졌으며 여덟 번 모두 늦은 COMPLETE는 −110, 같은 세대 재무장은 −11이었다. 만료 시점의 입력 자체는 여덟 번 모두 20 ms 유효 기간 안에 있었다.

| Ordinary case / 일반 사례 | Last L | Due D | Source-30 decision / 판정 | Decision−D | Register 1→0 [before, after] / 출력 | Late entry / 늦은 호출 |
| --- | ---: | ---: | ---: | ---: | --- | ---: |
| FIFO sleep | 5007159 | 5319660 | 5324142 | 4482 | [5325430, 5325439] | 5782470 |
| FIFO compute | 5015403 | 5327904 | 5331874 | 3970 | [5332931, 5332936] | 5864057 |
| RR sleep | 5014194 | 5326695 | 5329780 | 3085 | [5330927, 5330932] | 5785678 |
| RR compute | 5362183 | 5674684 | 5682500 | 7816 | [5683212, 5683217] | 6194724 |
| FIFO recover | 4947169 | 5259670 | 5263568 | 3898 | [5264908, 5264916] | 5728909 |
| FIFO recover-live | 4941841 | 5254342 | 5257813 | 3471 | [5259097, 5259106] | 5720449 |
| RR recover | 4954072 | 5266573 | 5270290 | 3717 | [5271349, 5271355] | 5733771 |
| RR recover-live | 4813600 | 5126101 | 5129290 | 3189 | [5130416, 5130421] | 5588333 |

The ordinary images deliberately omit the qualification IRQ/compare journal. Their 128 fixed scheduling records ended before D in **all eight** timeouts. Across 14 boots the fixed journal dropped 129–385 later records. Independent source-30, counter, sequence, timeout status and physical RAM register evidence survives. Raw fault-time IAR, actual CVAL, ELR, IRQ entry/return and precise idle-versus-loop PC are unavailable from these ordinary captures. The binary contains a finite calibrated compute loop without an SVC or counter read, and the sleeping branch requests monotonic sleep. The role readbacks bound injection and refusal. Neither scenario supplies an ordinary fault-time PC or the cause of the delay after D. The earlier qualification archive contains direct PC and comparator witnesses for its own runs.

일반 이미지에는 시험 전용 IRQ·비교기 로그가 없다. 일반 고장 여덟 번 모두 고정 스케줄러 기록 128행이 D 전에 끝났고, 전체 14회에서 이 로그의 누락 수는 129~385행이었다. 보호 로그의 출처 30, 판정·출력 틱, 수락된 입력, 오류값과 실제 RAM 레지스터는 판독했다. 고장 순간의 원시 IAR·실제 CVAL·중단 PC·IRQ 진입/복귀, 유휴 명령과 계산 루프 중 어디에서 중단됐는지는 이번 일반 기록으로 확정할 수 없다. 계산 경로에는 SVC·카운터 읽기가 없는 유한 루프가 있고 수면 경로에는 단조 시계 대기가 있다. 이전 시험 프로필의 PC·비교기 관측은 해당 과거 실행에 귀속된다.

## Endpoint, recovery and package ABI / 종료·복구·패키지 ABI

- FIFO/RR controller exit while active produced source-1 endpoint decisions at 5,098,399 / 5,281,263, before their respective D of 5,270,833 / 5,435,155. Both inhibited the register, rejected later OPEN and REARM with −32 and retained sequence 2. Healthy runs held enabled through the last supervisor observation and cleared on sender teardown.
- Scheduled recovery accepted generation 2 OPEN after fault and initially read flags 1, then primed on a real completion. Both generation-2 wire pairs were exactly 625,000 ticks apart. Explicit generation-2 supervisor and controller rearm drove 0→1, and teardown drove 1→0. The live issue pairs measured 625,026 FIFO and 620,077 RR ticks, signed errors +26 / −4,923 from 10 ms. Both permitted new heartbeats but refused REARM with −11 and stayed inhibited.
- 종료 사례는 FIFO·RR 모두 감독자가 이미 출력을 켠 뒤 실제 제어기가 먼저 종료했다. D 전 출처 1로 차단하고 이후 OPEN과 REARM을 −32로 거절했다. 정상 사례의 마지막 감독자 표본에서 출력이 켜져 있었고 정리 단계에서 꺼졌다.
- 두 예정 복구에서는 새 OPEN 직후 미준비 상태, 실제 완료 후 준비 상태를 거쳤다. 두 입력 간격이 정확히 625,000틱일 때 명시적 재무장으로 출력을 복구했다. 실측 쌍의 간격은 FIFO 625,026틱과 RR 620,077틱이었다. 새 세대의 감시는 갱신됐지만 두 경우 모두 재무장은 −11로 거절됐다.

Local instruction decoding resolved every SVC site in both current worker ELFs. The ordinary ELF contained no site selecting 62 or 63. The qualification ELF retained both. The ordinary packages had no qualification-journal symbols or UART rows. Their retained fixed-trace prefixes include clock/sleep services, real controller SVC60 followed immediately by controller SVC61 on 15–16 recorded occasions per boot, and targeted protected command records throughout. Every successful heartbeat joined exactly one authenticated controller COMPLETE, its EL1 timestamp and bracket, one controller-private post-sample, and its preceding scheduled phase. Packet comparisons joined the sender's 44 bytes, protected receiver snapshot and CRC, successful release, authenticated COMMIT and subsequent protected permit identity. Each completed phase logged one receive attempt. The worker resets its shared command allowance on phase A. Generation changes and per-phase command results fit one command per observed 5 ms job. Adversarial competing-command combinations were outside this workload.

두 현재 ELF의 SVC 위치는 모두 해독됐다. 일반 ELF에는 62·63을 선택하는 위치가 없으며 시험용 ELF에는 두 번호가 모두 있다. 일반 이미지에서 시험 전용 커널 저널 심볼과 UART 행은 없었다. 보존된 스케줄러 앞부분에서 실제 시계·대기 호출과 제어기의 60→61 연속 호출을 부팅마다 15~16번 확인했다. 모든 성공 완료를 인증된 제어 호출·커널 완료 시각과 구간·해당 위상의 제어기 전용 사후 표본에 연결했다. 송신 원본, 수신 44바이트와 CRC, 대여 해제, 보호 COMMIT, 이후 허가 식별자까지 대조했다. 완료한 위상마다 수신 시도 한 번이 기록됐고 관측된 5 ms 작업마다 공유 명령 예산은 한 번 이하였다. 전체 명령 경합 조합은 이번 부하 범위를 벗어난다.

The historical #392 qualifier worker SHA-256 was `be0d42e614cb76aa21733f0726a63a4aedab1d23fa4fcfe971b8d54e9f3aba07` at source `c5e6a374a9cc8107bfadb25db9c71f8d0d1666e2`. I read both historical healthy UARTs and disassembled that archived ELF. Its FIFO/RR runs had 29 source-63 heartbeats, 0→1→0, three expected exits and zero safety-journal loss. The rebuilt qualifier worker `cb21362b13cb4961030cc3d4f61a0585da7e6b67106e911e0d35b9b7adea9b5c` reproduced that interface and output in this 14-boot set. The ordinary worker hash was `baffc3437f5e4589d9bb92cc499b22950333a4f6b472ec8cffe30077ca118be3`. Byte-identical historical ELF execution on the new kernel requires separate captures. [Historical raw archive at the reviewed revision](https://github.com/Romanof123/JNOX/blob/fc3bfd6830e284a1bf925e2595a56932e6ebcd42/docs/evidence/native-permit-watchdog-current.tar.gz)

이전 #392 시험용 ELF와 원본 정상 UART를 대조했다. FIFO·RR 모두 출처 63인 완료 29회, 출력 0→1→0, 세 역할 종료값, 보호 로그 무누락이 현재 재빌드한 시험용 패키지와 일치했다. 기존 ELF와 현재 시험용 ELF의 바이트 해시는 다르며, 기존 바이너리 자체를 새 커널에서 실행한 근거는 별도 캡처에 해당한다.

## Offline replay / 오프라인 재판독

The reducer used kernel ELF symbol addresses and walked the terminal MMU tables for each private process. It compared all protected rows and drops to UART, checked session hashes and package image copies, checked sequential UTC capture intervals, and read the terminal atomic register directly. It reconstructed all 252 protected completion ticks, first-disallowed deadlines, same-generation gaps, accepted permit identities, device-write brackets and target-to-post delays. The 14 runs are first-position samples at this frozen revision. Eleven semantic mutations of decoded in-memory copies were rejected, including a coherently altered accepted identity in both privileged COMPLETE records, an early timeout, a false timer source and an altered active prerequisite. The original bytes were opened read-only. [Reducer](reduce.py) · [Per-boot raw tick derivations](boots.json) · [Mutation outcomes](mutations.json)

커널 ELF 심볼과 종료 시점 실제 페이지 테이블을 따라 역할별 전용 메모리를 읽었다. 보호 기록 전체와 누락 수를 UART와 대조했고 이미지 해시, 순차 UTC 부팅 구간, 종료 시 가상 레지스터를 확인했다. 252회 성공 완료의 틱, 각 D와 세대 내 간격, 수락 입력, 장치 전환 구간을 재구성했다. 메모리 사본에 수락 식별자 동시 변경·이른 판정·출처 변경·주입 전 비활성 등 11개 변형을 가하자 모두 검증에서 탈락했다. 실제 경계 틱 동시 호출, 모든 경합 조합, 독립 20 ms 만료의 재현 및 타 플랫폼·실물 타이밍은 이 14회가 검증하는 범위를 벗어난다.

Run in a Linux environment with Python 3, GNU nm, and aarch64-linux-gnu-objdump. Supply the frozen directory containing ledger, runs and packages, and an existing writable directory for the two result JSON files.

```sh
python3 reduce.py /path/to/first14 /path/to/results
```

Each `heartbeats` array in boots.json records phase index, generation, protected completion L, D, sequence, issue tick, permit, private post-COMPLETE tick and scheduled target, in that order. Register brackets contain before, after, old, read-back value. The unsigned sentinel 18446744073709551615 marks an absent protected timestamp. Fixed scheduler loss counts are separate from safety-journal loss.
