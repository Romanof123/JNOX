#!/usr/bin/env python3
"""Offline first-capture verifier. Python 3, GNU nm and aarch64-linux-gnu-objdump."""
import collections
import copy
import hashlib
import json
import re
import struct
import subprocess
import sys
import zlib
from pathlib import Path

U = (1 << 64) - 1
ETIMEDOUT, EAGAIN, EPIPE = (1 << 64) - 110, (1 << 64) - 11, (1 << 64) - 32
COMMIT = '98163cbef9d436e1216eb53c3f86faaf23d6e2aa'
CASES = ['healthy', 'sleep-late', 'compute-late', 'controller-exit', 'recover', 'recover-live']

class Reject(Exception):
    pass

def require(test, why):
    if not test:
        raise Reject(why)

def unique(rows, why):
    require(len(rows) == 1, why)
    return rows[0]

def symbols(path):
    rows = subprocess.check_output(['nm', '-Sn', str(path)], text=True)
    return {m[4]: (int(m[1], 16), int(m[2], 16)) for m in
            re.finditer(r'^([0-9a-f]+) ([0-9a-f]+) (\S) (\S+)$', rows, re.M)}

def resolve(table, key):
    return unique([v for n, v in table.items() if key in n], 'ambiguous/missing symbol '+key)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def uart_words(lines, prefix):
    return [[int(n) for n in line[len(prefix):].split()] for line in lines if line.startswith(prefix+' ')]

def scan_binary(path):
    asm = subprocess.check_output(['aarch64-linux-gnu-objdump', '-d', str(path)], text=True)
    ins = [(int(m[1],16), m[2], m[3].split('//')[0].strip()) for m in
           re.finditer(r'^\s*([0-9a-f]+):\s+[0-9a-f]{8}\s+(\w+(?:\.\w+)?)[ \t]*(.*?)$', asm, re.M)]
    uses, unknown = [], []
    for i, (pc, op, operands) in enumerate(ins):
        if op != 'svc':
            continue
        nr = None
        for _, prev, args in reversed(ins[max(0,i-20):i]):
            if re.match(r'^[wx]8,', args):
                if prev == 'mov' and re.fullmatch(r'[wx]8, #(?:0x[0-9a-f]+|\d+)', args):
                    nr = int(args.split('#')[1], 0)
                break
            if prev in ('bl','blr','ret','b','br') or prev.startswith('b.') or prev.startswith(('cb','tb')):
                break
        if nr is None:
            unknown.append(hex(pc))
        else:
            uses.append(nr)
    addr, size = resolve(symbols(path), 'wd_compute_loop')
    body = [op for pc,op,_ in ins if addr <= pc < addr+size]
    require(len(body)*4 == size and 'svc' not in body and 'mrs' not in body and 'bl' not in body, 'compute symbol body')
    return sorted(set(uses)), unknown, [addr,addr+size], body

def load(root, name):
    cap = root/'runs'/name/'cap'
    package = root/'packages'/name
    session = json.loads((cap/'session.json').read_text())
    for filename, digest in session['hashes'].items():
        require(sha(cap/filename) == digest, 'session hash '+filename)
    launch = json.loads((cap/'launch.json').read_text())
    manifest = json.loads((package/'manifest.json').read_text())
    require(launch['argument_package'] == manifest, 'manifest/launch')
    require(launch['revision'] == manifest['commit'] == COMMIT and manifest['tracked_changes']=='', 'revision')
    args = launch['argv']
    require(args[args.index('-smp')+1]=='1' and args[args.index('-machine')+1]=='virt,gic-version=2', 'machine')
    require(launch['kernel_sha256'] == manifest['kernel_elf_sha256'] == sha(cap/'kernel.elf') == sha(package/'kernel.elf'), 'kernel copies')
    for slot in manifest['slots']:
        require(slot['elf_sha256'] == sha(package/slot['elf']) == sha(cap/'user.elf') == launch['user_sha256'], 'workload copies')
    mode, policy, case = name.split('-',2)
    require(manifest['policy']==policy and manifest['safety_watchdog']['mode']==mode, 'mode')
    require([s['argv'][1:] for s in manifest['slots']] == [[role,case] for role in ('sender','controller','supervisor')], 'packed roles')
    ram = (cap/'ram.bin').read_bytes()
    require(len(ram)==launch['ram_bytes'], 'capture size')
    base = launch['ram_base']
    k = symbols(cap/'kernel.elf')
    app = symbols(cap/'user.elf')
    def take(address, length):
        start = address-base
        require(0<=start<=len(ram)-length,'RAM bounds')
        return ram[start:start+length]
    def words(sym, size=None):
        address, length=resolve(k,sym)
        raw = take(address,length if size is None else size)
        return list(struct.unpack('<'+'Q'*(len(raw)//8), raw))
    def rows(sym, n, w):
        return [list(v) for v in struct.iter_unpack('<'+'Q'*w, take(resolve(k,sym)[0], n*w*8))]
    # The root of each process is the first table in its Space. Walk the live
    # three levels using the runtime descriptors, independent of image_ram placement.
    spaces, size=resolve(k,'native_el0_mmu6SPACES')
    def read_user(role, sym, columns=None):
        va,length=app[sym]
        raw=bytearray()
        while length:
            table=spaces+role*(size//3)
            for shift in (30,21,12):
                (desc,) = struct.unpack('<Q',take(table+((va>>shift)&511)*8,8))
                require(desc & 3 == 3,'EL0 table descriptor')
                table=desc & 0xfffff000
            offset=va&4095
            n=min(length,4096-offset)
            raw.extend(take(table+offset,n))
            va+=n
            length-=n
        if columns:
            return [list(v) for v in struct.iter_unpack('<'+'Q'*columns,raw)]
        return bytes(raw)
    lines = (cap/'uart.bin').read_text().splitlines()
    def verify_table(prefix, stem, cnt, width, drop, drop_prefix):
        n=words(cnt)[0]
        require(n<=resolve(k,stem)[1]//(8*width), 'RAM row count')
        data=rows(stem,n,width)
        require(uart_words(lines,prefix)==data,'UART/RAM '+prefix)
        lost=words(drop)[0]
        require(uart_words(lines,drop_prefix)==[[lost]], 'UART/RAM drop counter')
        return data,lost
    safety,lost=verify_table('NATIVE SAFETY EVENT','6safety3LOG','6safety4USED',10,'6safety7DROPPED','NATIVE SAFETY DROPPED')
    fixed,fixed_lost=verify_table('NATIVE FIXED EVENT','native_el09DECISIONS','native_el07RECORDS',21,'native_el07DROPPED','NATIVE FIXED DROPPED')
    require(lost==0, 'lost safety rows')
    require(uart_words(lines,'NATIVE EL0 EXIT PID')==[[0,71],[1,72],[2,73]],'role exits')
    qual = []
    if mode=='qualification':
        n=words('permit_trace8ATTEMPTS')[0]
        require(uart_words(lines,'NATIVE QUAL COUNTS')==[[safety[0][2],n,n,0]] and n<=1024,'qualification loss')
        qual=rows('permit_trace4ROWS',n,12)
        require(uart_words(lines,'NATIVE QUAL ROW')==[[i]+row for i,row in enumerate(qual)],'UART/RAM qualifier')
    else:
        require(not any('permit_trace' in s for s in k) and not any(line.startswith('NATIVE QUAL ') for line in lines),'qualification instrumentation in ordinary')
    return dict(name=name,mode=mode,policy=policy,case=case,ram_sha=sha(cap/'ram.bin'),uart_sha=sha(cap/'uart.bin'),
                user_sha=sha(cap/'user.elf'),kernel_sha=sha(cap/'kernel.elf'), events=safety,
                fixed=fixed,fixed_lost=fixed_lost,qual=qual,register=words('jnox_virtual_permit_enable')[0],
                headers=[read_user(i,'wd_header',6)[0] for i in range(3)],
                controller=read_user(1,'wd_controller_rows',12),inject=read_user(1,'wd_injection',12)[0],
                sender=read_user(0,'wd_sender_rows',10),wire=read_user(0,'wd_sender_bytes'),
                supervisor=read_user(2,'wd_supervisor_rows',13),pair=read_user(2,'wd_recovery_pair',5)[0],
                calibration=read_user(1,'wd_calibration',4)[0],
                binary=scan_binary(cap/'user.elf'), start=(cap.parent/'start.utc').read_text().strip(),
                finish=(cap.parent/'finish.utc').read_text().strip())

def reduce_one(d):
    ev=d['events']
    select=lambda k:[r for r in ev if r[0]==k]
    mode,case=d['mode'],d['case']
    ordinary=mode=='ordinary'
    op=60 if ordinary else 63
    boot=unique(select(1),'boot')
    hz=boot[2]; epoch=d['headers'][0][3]
    require(hz>0 and boot[4]==d['register']==0, 'initial and terminal register')
    require(all(h==[0x57444231,i,CASES.index(case)+1,epoch,hz,0] for i,h in enumerate(d['headers'])), 'per-slot private headers')
    require(all(x[1]<=y[1] for x,y in zip(ev,ev[1:])), 'nonmonotonic kernel journal')
    require(not select(3), 'separate frame expiry')
    auth=select(5)
    require(all((r[2],r[3]) in ((1,60),(1,op),(2,59)) for r in auth),'role/ABI')
    require(all(r[3]==op for r in auth if r[2]==1 and r[4] in (1,3)), 'controller phase ABI')
    num,unknown,loop,body=d['binary']
    require(60 in num and 61 in num and (not ordinary or not ({62,63}&set(num))) and (ordinary or {62,63}<=set(num)), 'binary callsites')
    require((not ordinary or {2,5,60,61}<=set(r[1] for r in d['fixed'])), 'observed ordinary clock/sleep/control/info services')
    if ordinary:
        require(not unknown, 'ordinary unresolved syscall site '+str(unknown))
    # Each successful COMPLETE is bracketed by the privileged kind-10 record
    # and corresponds to one private post-service sample for the same activation.
    completions=select(10); ok=[r for r in completions if r[4]==0]
    hb=[r for r in select(13) if r[2] in (2,3)]
    commands=[r for r in auth if r[2:5]==[1,op,3]]
    require(len(hb)==len(ok) and len(commands)==len(completions),'heartbeat/completion counts')
    for a,c in zip(commands,completions):
        require(a[5:9]==[c[4],c[5],c[6],c[7]] and c[2]<=a[1]<=c[3]<=c[1], 'authenticated COMPLETE and bracket')
    private=[(i,r) for i,r in enumerate(d['controller']) if r[9] not in (0,1 << 63)]
    require(len(private)==len(ok), 'private completion sample count')
    health=case=='healthy'; exitcase=case=='controller-exit'
    recovery=case in ('recover','recover-live')
    expected=list(range(29)) if health else list(range(8))+(list(range(15,29)) if recovery else [])
    require([i for i,r in private]==expected,'scheduled activations '+str([i for i,r in private]))
    beats=[]; gaps=[]; gap_per_gen=collections.defaultdict(list); phase=[]; start_lag=[]; post_skew=[]
    for (i,r),w,c in zip(private,hb,ok):
        target=epoch+i*hz//400
        require(r[0]==target and target<=r[1]<=c[2]<=w[6]<=c[3]<=r[9], 'protected completion / user sample / raw target')
        require(r[2]==w[3]==c[5] and c[6]==r[11], 'phase identity')
        phase.append(r[9]-target);start_lag.append(r[1]-target);post_skew.append(r[9]-w[6])
        beats.append([i,w[3],w[6],w[9],c[6],c[7],c[8],r[9],target])
    prev=(U,U); generation=0; latched=False
    for r in select(13):
        kind,g,old_l,old_d,t,src,new_l,new_d=r[2:]
        require((old_l,old_d)==prev, 'prior L/D recurrence')
        if kind==1:
            require(g==generation+1 and src==59 and (new_l,new_d)==(U,U),'fresh OPEN')
            generation=g; latched=False
        elif kind in (2,3):
            require(g==generation and src==op and not latched and new_l==t and new_d==t+hz*5//1000+1 and
                    (kind==2)==(old_l==U), 'due tick or prime/renew source')
            if kind==3:
                require(old_l<=t<old_d, 'past-due renewal')
                gaps.append(t-old_l);gap_per_gen[g].append(t-old_l)
        elif kind==4:
            require(g==generation and not latched and src==30 and t>=old_d and new_l==old_l and new_d==U,'physical IRQ timeout')
            latched=True
        elif kind==6:
            require(g==generation and src==1 and new_l==old_l and new_d==U, 'endpoint retirement')
            latched=True
        else:
            raise Reject('unexpected watchdog transition')
        prev=(new_l,new_d)
    require(sum(r[2]==1 for r in select(13))==1+recovery,'OPEN count')
    down=select(2)
    for r in down: require(r[2]<=r[3]<=r[1],'atomic bracket')
    expect_regs=[[0,1],[1,0]]*(2 if case=='recover' else 1)
    require([r[4:6] for r in down]==expect_regs, 'physical register transitions')
    # Decode successful packets and join raw protected COMMITs to successful
    # receives, original sender bytes, field identity and the last accepted permit.
    packets={}
    for r in select(7):
        b=struct.pack('<6Q',*r[4:10])[:44]
        g,seq,issue=struct.unpack_from('<QQQ',b,8)
        require(b[:8]==bytes.fromhex('01012c0001000101') and b[32:40]==bytes.fromhex('1400000001000000') and
                int.from_bytes(b[40:44],'little')==zlib.crc32(b[:40]), 'received wire/CRC')
        require(any(d['wire'][44*i:44*i+44]==b and sr[2:5]==[g,seq,issue] and sr[7:9]==[0,0]
                    for i,sr in enumerate(d['sender'])), 'received packet provenance')
        require(any(p[4]==r[2] and p[5:]==[0,1,g,seq,issue] and p[3]<=r[1] for p in select(11)), 'kernel publish/receive')
        require((g,seq) not in packets,'duplicate wire record')
        packets[g,seq]=(issue,r[1],r[2])
    commits=[r for r in auth if r[2:6]==[1,60,2,0]]
    for r in commits:
        key=(r[6],r[7]); pkt=packets.get(key)
        require(pkt and r[8]==pkt[0] and pkt[1]<=r[1], 'accepted wire identity')
        require(any(x[2:5]==[1,36,0] and x[6]==pkt[2] and pkt[1]<=x[1]<=r[1] for x in select(6)), 'successful loan release before COMMIT')
    def last_accepted(t,g):
        return next((r[7:9]+[1] for r in reversed(commits) if r[6]==g and r[1]<=t),[0,0,0])
    for c in completions:
        require(c[6:9]==last_accepted(c[2],c[5]), 'protected COMPLETE retained identity')
    sup=d['supervisor']
    require(all(r[0]<=r[1]<=r[2] and r[12]==0 for r in sup),'supervisor readback')
    active=lambda flags: flags&63==19
    inhibited=lambda flags: flags&62==36
    require(active(sup[1][4]) and sup[1][3]==1 and sup[1][5]==2,'pre-stimulus active readback')
    require(last_accepted(sup[1][1],1)[:2]==sup[1][5:7],'active accepted identity')
    require(any(r[2:7]==[2,59,2,0,1] for r in auth) and any(r[2:8]==[1,60,4,0,1,2] for r in auth),'generation 1 rearm')
    for i,s in private:
        # Only one receive attempt per active phase. Open and rearm share
        # the A/B job budget; OPEN synchronization is observed in worker code.
        require(sum(1 for r in select(6) if r[2:4]==[1,35] and s[1]<=r[1]<=s[9])==1, 'loan attempts per completed phase')
    command_jobs=collections.Counter()
    local_generation=0
    for i,s in private:
        if s[2]!=local_generation:
            command_jobs[i//2]+=1
            local_generation=s[2]
        if s[7]!=(1<<63):
            command_jobs[i//2]+=1
    require(max(command_jobs.values(),default=0)<=1, 'combined local OPEN/REARM job budget')
    prefix_pairs=sum(a[1]==60 and b[1]==61 and a[3:5]==b[3:5]==[1,1]
                     for a,b in zip(d['fixed'],d['fixed'][1:]))
    if ordinary:
        require(prefix_pairs>0,'controller SVC60 followed by SVC61 in retained fixed trace')
    executed=collections.Counter((r[1]-epoch)//(hz//200) for r in auth if r[2:5]==[1,60,4])
    require(all(n<=1 for n in executed.values()), 'protected rearm budget')
    faults=[r for r in select(13) if r[2]==4]
    refused=[r for r in completions if r[4]!=0]
    death=unique([r for r in select(13) if r[2]==6], 'endpoint count')
    exitrow=unique(select(8),'exit row')
    require(death[6]<=exitrow[1] and exitrow[2]==(1 if exitcase else 0), 'dead endpoint role')
    fault=None
    if health:
        require(not faults and not refused and all(active(r[4]) for r in sup[1:]) and
                down[1][2]>=sup[-1][2] and death[6]<=down[1][2], 'healthy through teardown')
    else:
        inj=d['inject']; require(inj[0:2]==[1,1] and active(inj[3]) and inj[4:7]==[1,2,sup[1][6]] and
                                  inj[7]==private[7][1][9] and inj[2]>inj[7],'injection precondition')
        require(inhibited(sup[2][4]) and sup[2][5:7]==inj[5:7], 'retained identity / fault')
        require(any(r[2:8]==[2,59,2,EPIPE if exitcase else EAGAIN,1,2] for r in auth), 'late same generation REARM')
        if exitcase:
            require(not faults and not refused and inj[9]==(1 << 63) and death[4:6]==hb[-1][8:10]
                    and inj[2]<=death[6]<=down[1][2] and death[6]<death[5]
                    and any(r[2:6]==[2,59,1,EPIPE] for r in auth),'exit case')
        else:
            f=unique(faults,'one autonomous timeout')
            late=unique(refused,'one late COMPLETE')
            require(f[3]==1 and inj[2]<f[6] and f[6]<=down[1][2]<=down[1][3]<late[2]<=inj[10] and
                    late[4:9]==[ETIMEDOUT,1,2,inj[6],1] and inj[9]==ETIMEDOUT and inhibited(inj[11]), 'late refusal and ordered inhibit')
            require(last_accepted(f[6],1)==[2,inj[6],1] and f[6]-inj[6]<hz*20//1000,'expiry unrelated to frame age')
            require(all(inhibited(r[4]) and r[5:7]==inj[5:7] for r in sup if f[6]<=r[1] and r[3]==1), 'retained fault/sequence')
            if case=='compute-late':
                probe,fastest,goal,rounds=d['calibration']
                require(probe==65536 and fastest>0 and rounds==inj[8] and rounds==max(probe,min(32000000,(goal*probe+fastest-1)//fastest)), 'compute workload calibration')
            fault=dict(last=f[4],due=f[5],observed=f[6],source=f[7],late_entry=late[2],late_status=-110,
                       enable_to_inhibit=down[1][2:4],detection_late=f[6]-f[5],sample_before=inj[2],sample_after=inj[10],
                       permit=[1,2,inj[6],1],frame_age=f[6]-inj[6],fixed_trace_end=d['fixed'][-1][0],
                       fixed_trace_spans_fault=d['fixed'][-1][0]>=f[6])
    if recovery:
        p=d['pair']; spacing=p[1]-p[0]; eligible=spacing*1000==hz*10 and 0<=(p[2]-p[0])*1000<hz*20
        require(int(eligible)==(case=='recover') and all(p[j]==packets[2,j+1][0] for j in (0,1)),'recovery spacing')
        require(any(r[2:7]==[2,59,1,0,2] for r in auth) and sup[4][10:12]==[2,1], 'recovery fresh unprimed OPEN')
        req=unique([r for r in auth if r[2:5]==[2,59,2] and r[6]==2],'generation 2 REARM')
        require(req[5]==(0 if eligible else EAGAIN) and sup[-1][4] & 2 == (2 if eligible else 0), 'recovery decision')
        if eligible:
            require(any(r[2:7]==[1,60,4,0,2] and req[1]<r[1] for r in auth) and down[2][2]>req[1],'new explicit controller REARM')
    else: spacing=None
    qual_finishes=[r[6]-r[5] for r in d['qual'] if r[:2]==[1,1] and r[4]==3]
    if not ordinary:
        require(len(qual_finishes)==29 and len([r for r in d['qual'] if r[0]==3 and r[3]&1023==30])>0,'qualifier phase/IRQ')
    return dict(name=d['name'],source=COMMIT,start=d['start'],finish=d['finish'],images={k:d[k] for k in ('kernel_sha','user_sha','ram_sha','uart_sha')},
                frequency=hz,heartbeats=beats,gaps_ticks=gaps,gaps_by_generation=gap_per_gen,register_brackets=[r[2:6] for r in down],
                protected_commits=[[r[6],r[7],r[8],1] for r in commits],fault=fault,endpoint=[exitrow[2],death[6],death[4],death[5]],
                gen2_issue_spacing=spacing,phase_response=dict(target_to_post_sample_ticks=phase,start_observation_lag_ticks=start_lag,
                    protected_to_post_sample_ticks=post_skew,complete_phase_over_1ms_at_least=sum(x*1000>hz for x in phase),
                    qualification_target_to_finish_entry_ticks=qual_finishes),fixed_rows=len(d['fixed']),fixed_dropped=d['fixed_lost'],
                svc60_then_61_retained_pairs=prefix_pairs,local_command_jobs=dict(command_jobs),safety_rows=len(ev),safety_dropped=0,qual_rows=len(d['qual']),syscalls=num,unknown_number_sites=unknown,compute_loop=loop)

if __name__=='__main__':
    root=Path(sys.argv[1]); out=Path(sys.argv[2]); reports=[]; cache={}
    ledger=[line.split() for line in (root/'ledger').read_text().splitlines()]
    require(len(ledger)==14 and len({e[0] for e in ledger})==14, 'expected first 14 ledger entries')
    for name,rc in ledger:
        print(name,flush=True)
        require(rc=='0','capture return code')
        data=load(root,name)
        if reports: require(reports[-1]['finish']<data['start'],'serial capture schedule')
        reports.append(reduce_one(data));cache[name]=data
    (out/'boots.json').write_text(json.dumps(reports,indent=2)+'\n')
    checks=[('off-by-one',13,lambda r:r[2]==2,9,1),('replace IRQ source',13,lambda r:r[2]==4,7,30),
            ('spoof active output',2,lambda r:r[4:6]==[0,1],5,1),('allow late COMPLETE',10,lambda r:r[4]==ETIMEDOUT,4,ETIMEDOUT),
            ('replace accepted issue',10,lambda r:r[4]==ETIMEDOUT,7,1),('fabricate refresh',13,lambda r:r[2]==3,4,1),
            ('early timeout decision',13,lambda r:r[2]==4,6,None),('duplicate receive',6,lambda r:r[2:4]==[1,35],None,None)]
    mutations={}
    for label,kind,predicate,index,change in checks:
        d=copy.deepcopy(cache['ordinary-fifo-compute-late'])
        r=next(r for r in d['events'] if r[0]==kind and predicate(r))
        if index is None: d['events'].insert(d['events'].index(r),r.copy())
        elif change is None: r[index]=r[5]-1
        else: r[index]^=change
        try: reduce_one(d)
        except Reject as err: mutations[label]=str(err)
        else: raise Reject('accepted mutant '+label)
    for label,case in [('inactive injection','compute-late'),('coherent but wrong accepted identity','sleep-late'),('altered second live issue','recover-live')]:
        d=copy.deepcopy(cache['ordinary-fifo-'+case])
        if case=='compute-late':
            d['inject'][3] &= ~2
        elif case=='sleep-late':
            for r in d['events']:
                if r[0]==5 and r[5]==ETIMEDOUT: r[8]+=1
                if r[0]==10 and r[4]==ETIMEDOUT: r[7]+=1
        else:
            d['pair'][1]+=1
        try: reduce_one(d)
        except Reject as err: mutations[label]=str(err)
        else: raise Reject('accepted mutant '+label)
    (out/'mutations.json').write_text(json.dumps(mutations,indent=2)+'\n')
