from elftools.elf.elffile import ELFFile
import json,hashlib
from pathlib import Path
H=lambda b:hashlib.sha256(b).hexdigest()
def sig(p):
 with open(p,'rb') as f:
  elf=ELFFile(f);return dict(entry=elf.header.e_entry,loads=[(dict(s.header),H(s.data())) for s in elf.iter_segments() if s.header.p_type=='PT_LOAD'])
out={}
for n in ['eevdf-bench','eevdf-wake-bench','eevdf-dynamic-bench','telemetry']:
 old=Path('controls/169/first/kernel.elf' if n=='telemetry' else 'controls/169/verification/source-'+n+'.elf')
 new=Path('first-run/capture/kernel.elf' if n=='telemetry' else 'controls/'+n+'.elf')
 out[n]=dict(old=sig(old),new=sig(new),equal=sig(old)==sig(new))
print(json.dumps(out,indent=2))
