"""Replay the preserved single-vCPU capture. Run with Python 3 (without -O)."""
import json
import re
import struct
from pathlib import Path
from fractions import Fraction
from math import ceil

base = Path(__file__).resolve().parent
raw = base / "raw"
data = (raw / "audit.bin").read_bytes()
assert __debug__ and len(data) == 41536
version, count, sleeps, answers, hz, quantum, total, reported = struct.unpack_from("<8Q", data)
assert (version,count,sleeps,answers,total) == (1,128,16,16,128) and quantum == hz//100
rows = [struct.unpack_from("<36Q3q",data,64+312*i) for i in range(count)]
wakes = [struct.unpack_from("<12Q",data,40000+96*i) for i in range(sleeps)]
symbols = {s[3]:int(s[0],16) for line in (base/"symbols.txt").read_text().splitlines() if len(s:=line.split()) == 4}
pcs = [symbols["ee_"+name] for name in "abc"]
stack = next(value for name,value in symbols.items() if "5eevdf6STACKS" in name)
events = (raw/"int.trace").read_text().split("Taking exception ")
def return_pc(block):
    return [int(pc,16) for pc in re.findall(r"Exception return .* PC (0x[0-9a-f]+)",block)]
assert return_pc(events[0]) == [pcs[0]]
blocks = iter(events[1:])
def exception(kind, pc):
    block = next(blocks)
    assert block.startswith(kind) and int(re.search(r"with ELR (0x\w+)",block)[1],16) == pc
    if kind.startswith("2"):
        assert "ESR 0x15/0x56000001" in block
    return return_pc(block)
weights = [2,2,1]
runtime = [0,0,0]
progress = [0,0,0]
charge = [0,0,0]
ideal = [Fraction(0)]*3
peak = [Fraction(0)]*3
wake_due = None
expected_restore = pcs.copy()
next_return = [pcs[0]]
sleep_count = 0
delays = []
ticks = []
owners = []
mask = 7
switches = 0
def snapshot():
    return tuple(x for t in range(3) for x in (runtime[t],runtime[t]+1,weights[t],1))
for i,r in enumerate(rows):
    t,quota,ready,n,d = r[:5]
    start,compare,irq,pc,frame,restore,work = r[17:24]
    if i == wake_due:
        mask = 7
        w = wakes[sleep_count-1]
        assert w[4] == i and w[6:8] == (sum(runtime[:2]),4)
        runtime[2] = max(runtime[2],ceil(Fraction(sum(runtime[:2]),4)))
    active = [j for j in range(3) if mask & 1<<j]
    assert (quota,ready,n,d) == (1,mask,sum(runtime[j] for j in active),sum(weights[j] for j in active))
    assert snapshot() == r[5:17]
    eligible = [j for j in active if runtime[j]*d <= n*weights[j]]
    assert t == min(eligible,key=lambda j:(Fraction(runtime[j]+1,weights[j]),j))
    assert next_return == [restore] and restore == expected_restore[t]
    assert pcs[t] <= pc < pcs[t]+0x50 and compare == start+quantum <= irq
    assert stack+0x4000*t <= frame < stack+0x4000*(t+1) and work > progress[t]
    assert i == 0 or start >= rows[i-1][19]
    owners.append(t)
    switches += int(i>0 and owners[i-1] != t)
    progress[t] = work
    expected_restore[t] = pc
    next_return = exception("5 [IRQ]",pc)
    runtime[t] += 1
    assert snapshot() == r[24:36]
    charge[t] += 1
    for j in active:
        ideal[j] += Fraction(weights[j],d)
    for j in range(3):
        error = charge[j]-ideal[j]
        assert error*20 == r[36+j]
        peak[j] = max(peak[j],abs(error))
    if t == 2 and wake_due is not None and i >= wake_due:
        w = wakes[sleep_count-1]
        assert w[8:10] == (i,i) and w[11] == i-wake_due
        assert rows[wake_due-1][19] <= w[5] <= rows[wake_due][17]
        assert start <= w[10] < compare and restore == w[2] and frame == w[3]
        delays.append(i-wake_due)
        ticks.append(w[10]-w[5])
        wake_due = None
    if t == 2 and sleep_count < 16:
        w = wakes[sleep_count]
        assert next_return == [pc] and w[0] == i and w[2] == symbols["ee_c_wake"] and w[3] == frame
        assert irq <= w[1] <= rows[i+1][17]
        next_return = exception("2 [SVC]",w[2])
        expected_restore[2] = w[2]
        wake_due = i+2+sleep_count%4
        sleep_count += 1
        mask = 3
assert not next_return and list(blocks) == [] and len(ticks)==16
assert max(peak)*20 == reported and max(peak)<=20 and max(ticks)<=8*quantum and max(delays)<=6
def ranks(values):
    return [sorted(values)[ceil(p*len(values)/100)-1] for p in (50,95,99,100)]
print(json.dumps(dict(grants=charge,owners="".join("ABC"[t] for t in owners),irq=128,svc=16,task_switches=switches,peak_abs_error_quanta=[float(x) for x in peak],wake_delays_grants=delays,wake_delays_counts=ticks,nearest_rank_p50_p95_p99_max_grants=ranks(delays),nearest_rank_p50_p95_p99_max_counts=ranks(ticks),frequency=hz,quantum_counts=quantum,max_physical_quanta=max(ticks)/quantum,max_ms=1000*max(ticks)/hz),indent=2))
