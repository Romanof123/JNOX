from pathlib import Path
import json,struct,re,math
from fractions import Fraction as F
h=Path(__file__).resolve().parent;p=h/'first'
blob=(p/'journal.bin').read_bytes()
_,state,fail,hz,Q,E,N,wakes,responses,done,stack,cap=struct.unpack_from('<12Q',blob)
rows=[struct.unpack_from('<33Q',blob,96+i*264) for i in range(N)]
first=struct.unpack_from('<8Q',blob,len(blob)-64)
def audit(rows,first,allowed_fair,allowed_response):
 assert (state,fail,hz,wakes,responses,done,stack,cap)==(2,0,Q*100,8,8,3,16384,512)
 ready={0,1,2};weights=[2,1,1];request=[2*Q,Q,Q//2];runtime=[0]*3;remaining=request.copy()
 waits=0;releases={};seen={};prev_end=E;gaps=[];results={};window=[[ [0]*3,[F(0)]*3 ] for _ in range(5)]
 expected=[];frame={};pending=None;changed=None;preempted=set();resumed=set();ring=[11,7,23,5,19,3,29,13,2,31,17,37,41,43,47,53]
 for k,r in enumerate(rows):
  idx,owner,mask,start,target,stop,cause,sfp,spc,rfp,rpc=r[:11];x0,x1,x2,x3,wake,stamp,after,num,den,iar=r[11:21]
  assert idx==k and mask==sum(1<<i for i in ready) and start>=prev_end and stop>start
  eligible=[i for i in ready if F(runtime[i],weights[i])<=F(sum(runtime[j] for j in ready),sum(weights[j] for j in ready))]
  assert owner==min(eligible,key=lambda i:(F(runtime[i]+remaining[i],weights[i]),i))
  assert (num,den)==(sum(runtime[j] for j in ready),sum(weights[j] for j in ready))
  for i in range(3):assert tuple(r[21+4*i:25+4*i])==(runtime[i],runtime[i]+remaining[i],weights[i],remaining[i])
  if owner in frame:assert (rfp,rpc)==frame[owner]
  if owner in preempted:resumed.add(owner)
  frame[owner]=(sfp,spc);expected.extend([('eret',rpc),('irq' if cause==1 else 'svc',spc)])
  compare=start+min(Q,remaining[owner]);assert target==(min(compare,pending[1]) if pending else compare)
  for j,(actual,ideal) in enumerate(window):
   t=E+8*j*Q;overlap=max(0,min(stop,t+32*Q)-max(start,t))
   actual[owner]+=overlap
   for i in ready:ideal[i]+=F(overlap*weights[i],den)
  dt=stop-start;runtime[owner]+=dt;remaining[owner]=(remaining[owner]-dt-1)%request[owner]+1;gaps.append(start-prev_end);prev_end=stop
  if owner==2 and len(releases)>len(seen):
   seq=len(seen)+1
   if start<=first[seq-1]<=stop:seen[seq]=first[seq-1]
  if cause==1:
   assert iar==30 and stop>=target;preempted.add(owner)
  elif cause==2:
   assert owner==2 and x0==waits+1 and not pending; waits+=1;due=E+8*waits*Q
   assert rows[k+1][3]<due
   pending=(waits,due);ready.remove(2)
   if waits==5:
    # Preserve B's signed lag to the previous rational reference for weight 1->2.
    ref=F(runtime[0]+runtime[1],3);before=runtime[1];runtime[1]+=math.ceil(ref);weights[1]=2;remaining[1]=request[1]=2*Q
    changed=dict(row=k,next=k+1,reference=str(ref),before=before,after=runtime[1],lag_residual=str(runtime[1]-before-ref))
  else:
   assert cause==3 and x0==owner;ready.remove(owner)
   if owner==2:
    vals=[sum((j+1)*ring[(j+i)%16] for j in range(16)) for i in range(1,9)]
    assert (x1,x2,x3)==(128,sum(vals),sum(i*v for i,v in enumerate(vals,1)))
   else:
    assert x1>0 and x1%64==0 and x1<2**38 and 2 in results
    cycle=[ring[(3*n+5*owner)%16] for n in range(112)];loops,tail=divmod(x1,112);wei=[v*(1+n%7) for n,v in enumerate(cycle)]
    assert (x2,x3)==(loops*sum(cycle)+sum(cycle[:tail]),loops*sum(wei)+sum(wei[:tail]))
   results[owner]=[x1,x2,x3]
  if wake:
   assert cause==1 and pending==(wake,E+8*Q*wake) and stop>=pending[1] and stamp>=stop
   releases[wake]=(pending[1],stamp);pending=None
   ref=F(sum(runtime[j] for j in ready),sum(weights[j] for j in ready))
   runtime[2]=max(runtime[2],math.ceil(ref*weights[2]));ready.add(2)
  assert after==sum(1<<i for i in ready)
 assert not ready and resumed.issuperset({0,1}) and len(seen)==len(releases)==8
 ev=[];lines=(p/'exceptions.log').read_text().splitlines()
 for i,line in enumerate(lines):
  if 'Taking exception' in line:
   kind='irq' if '[IRQ]' in line else 'svc';assert '[IRQ]' in line or '[SVC]' in line
   elr=next(x for x in lines[i+1:i+8] if 'with ELR' in x);ev.append((kind,int(elr.split()[-1],16)))
  if line.startswith('Exception return'):ev.append(('eret',int(line.split()[-1],16)))
 assert ev==expected
 wx=[]
 for a,i in window:
  errs=[x-y for x,y in zip(a,i)];assert sum(a)>=28*Q and all(abs(x)<=allowed_fair for x in errs),'fair bound'
  wx.append(dict(delivered=sum(a),actual=a,ideal=list(map(str,i)),errors=list(map(str,errs))))
 latency=[]
 for i,(due,wake) in releases.items():
  work=seen[i];assert due<=wake<=work and work-due<=allowed_response,'response bound'
  latency.append([i,due,wake,work,work-due,work-wake])
 return dict(rows=N,frequency=hz,q=Q,E=E,change=changed,gaps=gaps,windows=wx,latency=latency,work=results,exceptions={kind:sum(k==kind for k,pc in ev) for kind in ['irq','svc','eret']})
r=audit(rows,first,4*Q,4*Q);r['offline_controls']={}
for n,args in [('zero fairness',(rows,first,0,4*Q)),('zero response',(rows,first,4*Q,0)),('missing response',(rows,[0,*first[1:]],4*Q,4*Q))]:
 try:audit(*args)
 except AssertionError as e:r['offline_controls'][n]='rejected '+str(e)
 else:raise RuntimeError(n)
(h/'independent.json').write_text(json.dumps(r,indent=2));print(r['change'],r['work'],r['exceptions'],r['offline_controls'])

