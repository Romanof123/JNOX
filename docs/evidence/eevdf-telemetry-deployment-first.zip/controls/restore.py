import json,io,zipfile,hashlib,base64
from pathlib import Path
r=Path('source/docs/evidence'); dest=Path('controls')
H=lambda b:hashlib.sha256(b).hexdigest()
for n in ['023','034','039','169']:
 p=dest/n;p.mkdir()
 if n=='169':
  b=(r/'ordinary-eevdf-first.zip').read_bytes();assert H(b)=='148e362e5e14c37e1d351df6180f10ae37a5fece35f7ef7ff7655e843c40c452';zipfile.ZipFile(io.BytesIO(b)).extractall(p);continue
 j=json.loads((r/f'evd-{n}.json').read_text())
 if n=='023':
  for k,v in j['raw_base64'].items():
   b=base64.b64decode(v);assert H(b)==j['sha256'][k];(p/k).write_bytes(b)
  continue
 b=base64.b64decode(j['zip_base64'] if n=='034' else j['archive']['data']);assert H(b)==(j['zip_sha256'] if n=='034' else j['archive']['sha256'])
 z=zipfile.ZipFile(io.BytesIO(b));spec=j.get('files',j.get('entry_sha256'));assert set(z.namelist())==set(spec)
 for k,v in spec.items():assert H(z.read(k))==(v['sha256'] if isinstance(v,dict) else v)
 z.extractall(p)
