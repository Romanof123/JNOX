from pathlib import Path
from fractions import Fraction as F
import re,struct,json,math
p=Path('controls/023');blob=(p/'audit.bin').read_bytes()
assert len(blob)==4000 and struct.unpack_from('<8Q',blob)==(1,12,2,2,62500000,625000,18,25)
rows=[struct.unpack_from('<36Q3q',blob,64+312*i) for i in range(12)]
wakes=[struct.unpack_from('<12Q',blob,3808+96*i) for i in range(2)]
ss={x[-1]:int(x[0],16) for l in Path('controls/023-symbols').read_text().splitlines() if len(x:=l.split())>=3}
base=next(v for k,v in ss.items() if '5eevdf6STACKS' in k)
w=[1,2,1];req=[1,8,4];n=[0]*3;rem=req.copy();err=[F(0)]*3;prog=[0]*3;resume=[ss['ee_'+c] for c in 'abc'];seq=[];summary=[]
def tuples():return tuple(y for i in range(3) for y in (n[i],n[i]+rem[i],w[i],rem[i]))
for k,row in enumerate(rows):
 owner,g,mask,num,den=row[:5];ready=[0,1] if k in (3,7) else [0,1,2]
 if k==2:req[2]=rem[2]=2
 if k==3:
  ref=F(sum(n[:2]),sum(w[:2]));n[0]=math.ceil(n[0]+ref);w[0]=req[0]=rem[0]=2
 if k in (4,8):
  wake=wakes[k==8];ref=F(sum(n[:2]),sum(w[:2]));assert ref==F(wake[6],wake[7]);n[2]=max(n[2],math.ceil(w[2]*ref))
 assert mask==sum(1<<i for i in ready) and (num,den)==(sum(n[i] for i in ready),sum(w[i] for i in ready))
 assert row[5:17]==tuples();elig=[i for i in ready if F(n[i],w[i])<=F(num,den)]
 assert owner==min(elig,key=lambda i:(F(n[i]+rem[i],w[i]),i)) and g==[1,1,1,3,2,2,1,1,1,2,2,1][k]
 if k==1:assert 0 not in elig and F(n[0]+rem[0],w[0])<F(n[owner]+rem[owner],w[owner])
 start,compare,irq,pc,frame,restored,progress=row[17:24]
 assert compare==start+625000*g and compare<=irq<compare+625000 and restored==resume[owner] and progress>prog[owner]
 assert pc==ss['ee_'+'abc'[owner]+'_work'] and base+16384*owner<=frame<base+16384*(owner+1)
 seq += [('return',restored),('IRQ',pc)];resume[owner]=pc;prog[owner]=progress
 if k in (2,6):
  wake=wakes[k==6];assert wake[0]==k and wake[2]==ss['ee_c_wake'] and wake[3]==frame
  seq += [('return',pc),('SVC',wake[2])];resume[2]=wake[2]
 n[owner]+=g;rem[owner]-=g
 if rem[owner]==0:rem[owner]=req[owner]
 for i in ready:err[i]+=g*(int(owner==i)-F(w[i],den))
 assert row[24:36]==tuples() and tuple(x*20 for x in err)==row[36:]
 summary.append(dict(row=k,owner=owner,grant=g,irq_pc=pc,restored_pc=restored,frame=frame,errors20=row[36:]))
events=[]
for l in (p/'int.trace').read_text().splitlines():
 if 'Taking exception' in l:kind=re.search(r'\[(IRQ|SVC)\]',l)[1]
 if 'with ELR' in l:events.append((kind,int(l.split()[-1],16)))
 if l.startswith('Exception return'):events.append(('return',int(l.split()[-1],16)))
assert events==seq
latencies=[]
for j,wake in enumerate(wakes):
 r=rows[wake[8]];assert wake[5]<=r[17]<=wake[10]<r[18] and r[22]==ss['ee_c_wake'] and wake[11]==[4,5][j]
 latencies.append(wake[10]-wake[5])
assert latencies==[2843013,3643095]
print(json.dumps(dict(rows=summary,latencies=latencies,wakes=wakes,trace_events=len(events)),indent=2))
