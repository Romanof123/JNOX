"""Portable offline replay. Run python verify.py beside raw/ and symbols.txt."""
import json
import re
import struct
from fractions import Fraction
from math import ceil
from pathlib import Path

here = Path(__file__).resolve().parent
raw = here / "raw"
def document(name):
    return json.loads((raw / name).read_text())

def chunks(seq, size):
    assert len(seq) % size == 0
    return [seq[i:i + size] for i in range(0, len(seq), size)]

def words(file, length):
    return struct.unpack("<" + "Q" * length, (raw / file).read_bytes())

def ranks(values):
    return [sorted(values)[ceil(len(values) * p / 100) - 1] for p in (50, 95, 99, 100)]

def replay():
    assert __debug__, "run without -O"
    table = {line.split()[-1]: line.split() for line in (here / "symbols.txt").read_text().splitlines() if len(line.split()) >= 3}
    def addr(name):
        return int(table[name][0], 16)
    launch = document("launch.json")
    for prefix, symbol, size in [("audit", "eevdf_witness", 81856), ("trace", "eevdf_updates", 1184)]:
        assert addr(symbol) == launch[prefix + "_address"]
        assert int(table[symbol][1], 16) == launch[prefix + "_size"] == size
    assert launch["trace_symbol"] == "eevdf_updates"
    assert document("qmp.json")["status"]["running"] and len(document("qmp.json")["cpus"]) == 1
    assert document("exit.json")["qemu_status"] == 0
    assert (raw / "uart.bin").read_bytes() == b"JNOX M1 BOOT\nJNOX M1 READY\nEEVDF BEGIN\nEEVDF DYNAMIC STOP\nEEVDF DYNAMIC PASS\n"
    witness = words("audit.bin", 8 + 39*256 + 12*20)
    version, count, sleeps, responses, freq, quantum, total, peak = witness[:8]
    assert (version, count, sleeps, responses, total) == (1,256,20,20,256)
    assert quantum == freq // 100 > 0
    rows = chunks(witness[8:8+39*256], 39)
    wakes = chunks(witness[-240:], 12)
    updates = iter(chunks(words("trace.bin", 148), 37))
    lines = iter((raw / "int.trace").read_text().splitlines())
    def event(restore, kind, elr):
        assert next(lines) == f"Exception return from AArch64 EL1 to AArch64 EL1 PC {restore:#x}"
        assert next(lines) == ("Taking exception 5 [IRQ]" if kind == 0 else "Taking exception 2 [SVC]")
        assert next(lines) == "...from EL1 to EL1"
        esr = next(lines)
        assert re.fullmatch(r"\.\.\.with ESR 0x[0-9a-f]+/0x[0-9a-f]+", esr)
        if kind:
            assert esr == f"...with ESR 0x15/{0x56000000+kind:#x}"
        assert next(lines) == f"...with ELR {elr:#x}"
        vector = addr("sched_vectors") + (0x200 if kind else 0x280)
        assert next(lines) == f"...to EL1 PC {vector:#x} PSTATE 0x3c5"
    tasks = [[0,1,w,1] for w in (2,2,1)]
    slices = [1,1,1]
    ready = [0,1,2]
    def ref():
        return tuple(sum(tasks[j][k] for j in ready) for k in (0,2))
    def tuples():
        return tuple(x for t in tasks for x in t)
    due = None
    response = None
    completed = 0
    service = [0]*3
    ideal = [Fraction(0)]*3
    progress = [1]*3
    restores = [addr("ee_"+c) for c in "abc"]
    base = addr(next(name for name in table if "eevdf6STACKS" in name))
    all_errors, waits, delays, configs, arrivals = [], [], [], [], []
    latest = 0
    for i,row in enumerate(rows):
        owner, quota, mask, n, d = row[:5]
        start, compare, irq, pc, frame, restore, work = row[17:24]
        if i == due:
            wake = wakes[completed-1]
            assert wake[4] == i and wake[6:8] == ref()
            assert latest <= wake[5] <= start
            latest = wake[5]
            shift = max(0, ceil(Fraction(*ref()) * tasks[2][2]) - tasks[2][0])
            tasks[2][0] += shift
            tasks[2][1] += shift
            ready.append(2)
            due, response = None, wake
            arrivals.append(i)
        assert row[5:17] == tuples() and (n,d) == ref()
        eligible = [j for j in ready if Fraction(tasks[j][0], tasks[j][2]) <= Fraction(n,d)]
        assert owner == min(eligible, key=lambda j: (Fraction(tasks[j][1], tasks[j][2]),j))
        assert mask == sum(1 << j for j in ready) and quota == 1
        assert latest <= start and compare == start + quantum and compare <= irq < compare + quantum
        latest = irq
        assert restore == restores[owner] and frame == base + (owner+1)*16384 - 16 - 832
        worker = "ee_" + "abc"[owner]
        assert addr(worker + "_work") <= pc < addr(worker + "_svc") and pc % 4 == 0
        assert work > progress[owner]
        event(restore, 0, pc)
        progress[owner], restores[owner] = work, pc
        if owner == 2 and response is not None:
            assert restore == addr("ee_c_wake")
            first, tick, stamp, wait = response[8:]
            assert first == tick == i and wait == i-response[4]
            assert response[5] <= start <= stamp < compare
            waits.append(wait)
            delays.append(stamp-response[5])
            response = None
        for j in ready:
            ideal[j] += Fraction(tasks[j][2],d)
        service[owner] += 1
        t = tasks[owner]
        t[0] += 1
        t[3] -= 1
        if not t[3]:
            t[3] = slices[owner]
            t[1] += slices[owner]
        assert row[24:36] == tuples()
        errors = [(s-f)*60 for s,f in zip(service,ideal)]
        assert errors == [x if x < 2**63 else x-2**64 for x in row[36:]]
        all_errors.extend(abs(int(e)) for e in errors)
        if owner == 2 and completed < 20:
            wake = wakes[completed]
            completed += 1
            requests = {5:(2,3),9:(0,3),13:(3,3),17:(3,0)}
            source = pc
            if completed in requests:
                u = next(updates)
                w,s = requests[completed]
                admit = int(w != 0 and s != 0)
                assert u[:2] == (completed,i+1) and latest <= u[2] <= wake[1]
                assert u[3:9] == (addr("ee_c_config_return"),frame,0,w,s,admit)
                assert u[9:11] == ref() and u[13:25] == tuples()
                event(source,2,u[3])
                source, latest = u[3], u[2]
                if admit:
                    runtime = ceil(tasks[0][0] + (w-tasks[0][2])*Fraction(*ref()))
                    tasks[0] = [runtime,runtime+s,w,s]
                    slices[0] = s
                assert u[11:13] == ref() and u[25:] == tuples()
                configs.append(list(u[:13]))
            assert wake[0] == i and latest <= wake[1]
            latest = wake[1]
            assert wake[2:4] == (addr("ee_c_wake"),frame)
            event(source,1,wake[2])
            restores[2] = wake[2]
            ready.remove(2)
            due = i+2+(completed-1)%4
    assert next(lines,None) is None and next(updates,None) is None
    assert completed == len(delays) == len(arrivals) == 20 and due is response is None
    assert len(all_errors) == 768 and peak == max(all_errors)
    assert all(x <= 1200 for x in ranks(all_errors))
    assert all(x <= 8 for x in ranks(waits))
    assert all(x <= 10*quantum for x in ranks(delays))
    return dict(grants=service, frequency=freq, quantum=quantum, wake_arrivals=arrivals,
                requests=configs, error_sixtieths=ranks(all_errors), intervening=waits,
                intervening_ranks=ranks(waits), physical_counts=delays, physical_ranks=ranks(delays),
                physical_quantum_ranks=[str(Fraction(x,quantum)) for x in ranks(delays)])
if __name__ == "__main__":
    print(json.dumps(replay(),indent=2))
