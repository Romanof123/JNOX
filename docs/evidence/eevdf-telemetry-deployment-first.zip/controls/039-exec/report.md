# First independent dynamic EEVDF review

PASS on the first and only guest launch. Frozen source 05a8f2d8358d7a9d442e24521a7664fcda8f27c5, ELF SHA-256 ce4584a03795a0a386c30e24c1281e3e24e0b1ce1ce84eca6400015e98b62f95. Ubuntu QEMU 6.2.0, single virtual Cortex-A72, TCG. The boot harness accepted the original 77 UART bytes. QMP observed the live guest and saved both named ranges before host termination. The seven original files were copied byte-for-byte from D:/dynamic-fresh/raw to the portable raw/ directory.

The replay derives each eligible set, earliest deadline with task-ID ties, grant charge, wake clamp and configuration transition from initial conditions. It checks every unreduced reference, tuple, restore PC, interrupted PC, stack frame address, progress counter and timer bound against the original records. A/B/C received 122/94/40 grants. Each of 20 C wake arrivals followed the declared cyclic absence; each eventual dispatch restored C at its SVC return, with the worker's counter sample in that dispatch's timer interval.

The linked C disassembly loads target zero and selects weight/slice arguments using its sleep counter. Sleeps 5/9/13/17 yielded (2,3) accepted, (0,3) rejected, (3,3) accepted and (3,0) rejected. The exception stream includes 256 IRQs, 20 SVC #1 and four SVC #2, with matching ELRs and return destinations. Each config record falls between the corresponding IRQ and blocking SVC timestamps, carries C's stack-frame address, and matches the independently computed pre/post state. Both refused requests preserve all reported tuples and the reference.

| Sample | p50 | p95 | p99 | Maximum | Limit at each rank |
|---|---:|---:|---:|---:|---:|
| Absolute weighted service error, in sixtieths (768) |108|246|256|266|1200|
| Intervening grants (20) |3|6|6|6|8|
| Wake to first worker sample, counter ticks (20) |2283129|4487839|4599989|4599989|6250000|

CNTFRQ was 62,500,000 Hz and each grant was 625,000 ticks. The longest wake delay was 73.599824 ms. These nearest ranks describe this single virtual guest run. The journal records handler-observed arguments, frame pointers and guest timestamps. QEMU exception tracing independently supplies exception types, ESRs, ELRs, vectors and return PCs. The capture omits per-trap raw register files, frame contents, per-instruction counter timestamps and hardware measurements.

Run python verify.py in this directory to recompute summary.json using Python's standard library. The recorded launch paths identify the original machine. Offline replay uses paths relative to the verifier.
