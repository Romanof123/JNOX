from pathlib import Path
import subprocess as sp,os,hashlib,shutil,tarfile,json,struct
d=Path(__file__).parent;h=Path.home()/'jnox-169-first-e203caa'
env={**os.environ,'CARGO_HOME':str(h/'cargo'),'RUSTUP_HOME':str(h/'rustup'),'PATH':str(h/'cargo/bin')+':'+os.environ['PATH']}
def cmd(name,args,cwd,extra={},bad=False):
 r=sp.run(args,cwd=cwd,env={**env,**extra},stdout=sp.PIPE,stderr=sp.STDOUT);(h/(name+'.log')).write_bytes(r.stdout)
 assert (r.returncode!=0)==bad,(name,r.stdout[-850:]);return r
base={'JNOX_BOARD':'virt','JNOX_PROFILE':'eevdf','JNOX_APP':'telemetry'}
s=h/'src';cmd('host-build',['rustc','+1.95.0','--edition=2024','--test','tools/scheduling_tests.rs','-o',str(h/'policy-tests')],s)
cmd('host-eevdf',[str(h/'policy-tests'),'eevdf'],s)
for name,over,features in [('app',{'JNOX_APP':'invalid'},[]),('board',{'JNOX_BOARD':'pi4'},[]),('case',{'JNOX_CONTROL_CASE':'healthy'},[]),('trace',{'JNOX_FIXED_TRACE':'1'},[]),('feature',{},['--features','eevdf-bench'])]:
 cmd('reject-'+name,['cargo','+1.95.0','build','--locked','--release','-j1',*features],s/'kernel',{**base,**over,'CARGO_TARGET_DIR':str(h/'invalids'/name)},True)
for rev in ['prior','source']:
 ref=h/'baseline-source';ref.mkdir()
 with tarfile.open(d/(rev+'.tar')) as t:t.extractall(ref)
 for feat in ['eevdf-bench','eevdf-wake-bench','eevdf-dynamic-bench']:
  tgt=h/'bench-target';cmd(rev+'-'+feat,['cargo','+1.95.0','build','--locked','--release','-j1','--features',feat],ref/'kernel',{'JNOX_BOARD':'virt','CARGO_TARGET_DIR':str(tgt)})
  shutil.copy2(tgt/'aarch64-unknown-none/release/jnox-kernel',h/(rev+'-'+feat+'.elf'));tgt.rename(h/(rev+'-'+feat+'-build'))
 ref.rename(h/('baseline-'+rev))
for p in sorted(h.glob('prior-*.elf')):
 q=h/p.name.replace('prior-','source-');b=p.read_bytes();v=q.read_bytes()
 def image(blob):
  off=struct.unpack_from('<Q',blob,32)[0];n,c=struct.unpack_from('<HH',blob,54);parts=[]
  for i in range(c):
   x=struct.unpack_from('<II6Q',blob,off+i*n)
   if x[0]==1:parts.append((x,hashlib.sha256(blob[x[2]:x[2]+x[5]]).hexdigest()))
  return struct.unpack_from('<Q',blob,24)[0],parts
 print(p.name,'elf equal',b==v,'loads+entry equal',image(b)==image(v))
