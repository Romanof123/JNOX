from pathlib import Path
from elftools.elf.elffile import ELFFile
import json,struct,io
h=Path.home()/'jnox-169-first-e203caa'
p=h/'legacy-comparison.json';m=json.loads(p.read_text())
for k,r in m.items():
 for v in ['prior','source']:
  e=ELFFile(io.BytesIO((h/(v+'-'+k+'.elf')).read_bytes()));sec=e.get_section_by_name('.rodata');b=sec.data();addr=sec.header.sh_addr;ptr,n,line,col=struct.unpack_from('<QQII',b,320);r[v]['location']=[b[ptr-addr:ptr-addr+n].decode(),line,col];print(k,v,r[v]['location'])
p.write_text(json.dumps(m,indent=2))
