from pathlib import Path
from elftools.elf.elffile import ELFFile
import hashlib,json,io,struct
h=Path.home()/'jnox-169-first-e203caa';d=Path(__file__).parent
res={}
for f in sorted(h.glob('prior-*.elf')):
 feat=f.stem[6:];r={}
 for rev in ['prior','source']:
  b=(h/(rev+'-'+feat+'.elf')).read_bytes();e=ELFFile(io.BytesIO(b));r[rev]=dict(elf=hashlib.sha256(b).hexdigest(),entry=e.header.e_entry,sections={x.name:[x.header.sh_addr,x.header.sh_size,hashlib.sha256(x.data()).hexdigest()] for x in e.iter_sections() if x.name in ['.text','.rodata','.data','.bss']},loads=[hashlib.sha256(x.data()).hexdigest() for x in e.iter_segments() if x.header.p_type=='PT_LOAD'])
  if rev=='prior':old=e
 new=e;diff={}
 for name in ['.text','.rodata','.data']:
  a=old.get_section_by_name(name).data();b=new.get_section_by_name(name).data();diff[name]=dict(sizes=[len(a),len(b)],changes=sum(x!=y for x,y in zip(a,b)),first_offsets=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y][:20])
 r['diff']=diff;res[feat]=r;print(feat,diff)
(h/'legacy-comparison.json').write_text(json.dumps(res,indent=2))
