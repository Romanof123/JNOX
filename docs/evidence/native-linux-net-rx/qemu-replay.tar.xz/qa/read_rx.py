"""Independent frozen-evidence reader. Requires Python 3 and GNU nm."""
import hashlib
import json
import re
import struct
import subprocess
import sys
from pathlib import Path


def check(test, detail):
    if not test:
        raise ValueError(detail)


def symbols(path):
    listing = subprocess.check_output(["nm", "-n", str(path)], text=True)
    return {name: int(addr, 16) for addr, name in re.findall(
        r"^([0-9a-f]+) [a-zA-Z] (\S+)$", listing, re.M)}


def sections(path):
    blob = path.read_bytes()
    offset, = struct.unpack_from("<Q", blob, 40)
    stride, count, string_index = struct.unpack_from("<HHH", blob, 58)
    headers = [struct.unpack_from("<IIQQQQIIQQ",blob,offset+i*stride) for i in range(count)]
    strings = headers[string_index]
    names = blob[strings[4]:strings[4]+strings[5]]
    return {names[h[0]:].split(b"\0",1)[0].decode(): (h[3], blob[h[4]:h[4]+h[5]]) for h in headers}


def certify(root, service):
    imported = root/"imported"
    linked = sections(root/"native/user.elf")
    check((imported/"service.elf").read_bytes() == (root/"native/user.elf").read_bytes(), "service differs")
    text_va, text = linked[".text"]
    peer_va, peer_text = sections(root/"native/native_peer.elf")[".text"]
    for name in ("add_recvbuf_small","virtnet_rq_get_buf"):
        pc = service[name]
        check(not peer_va <= pc < peer_va+len(peer_text), "peer executable alias")
        source = sections(imported/"virtio_net.packet.o")
        sec = ".text."+name
        raw = source[sec][1]
        reloc = source[".rela"+sec][1]
        words = {offset for offset, info, addend in struct.iter_unpack("<QQq",reloc)}
        for i in range(0,len(raw),4):
            if i not in words:
                start = pc-text_va+i
                check(raw[i:i+4] == text[start:start+4], "instruction mismatch "+name)


def frames(blob, pcap):
    start = 24 if pcap else 0
    if pcap:
        check(blob[:4] == bytes.fromhex("d4c3b2a1") and
              struct.unpack_from("<I", blob, 20)[0] == 1, "PCAP header")
    result = []
    while start < len(blob):
        if pcap:
            size, original = struct.unpack_from("<II", blob, start + 8)
            check(size == original, "truncated packet")
            start += 16
        else:
            size, = struct.unpack_from(">I", blob, start)
            start += 4
        check(0 < size <= len(blob) - start, "invalid frame length")
        result.append(blob[start:start + size])
        start += size
    return result


class Ram:
    def __init__(self, path):
        self.ranges = []
        for key, value in json.loads(path.read_text()).items():
            addr, size = key.split("/")
            data = bytes.fromhex(value)
            check(len(data) == int(size), "snapshot range")
            self.ranges.append((int(addr, 16), data))

    def read(self, addr, size):
        data = bytearray()
        while len(data) < size:
            found = [(base, block) for base, block in self.ranges
                     if base <= addr < base + len(block)]
            check(found, f"missing RAM at {addr:x}")
            base, block = max(found, key=lambda item: item[0] + len(item[1]))
            part = block[addr-base:addr-base+size-len(data)]
            data.extend(part)
            addr += len(part)
        return bytes(data)

    def entry(self, root, va):
        table = root
        for shift in (30, 21, 12):
            entry, = struct.unpack("<Q", self.read(table + 8*((va >> shift) & 511), 8))
            if entry & 3 != 3:
                return None
            table = entry & 0xfffffffff000
        return table + (va & 4095), entry


def review(run, service, peer, native):
    log = (run / "machine.log").read_text()
    nonce = (run / "nonce.bin").read_bytes()
    packets = frames((run / "wire.pcap").read_bytes(), True)
    check(len(nonce) == 8 and len(packets) == 81, "frame count or nonce")
    check(packets == frames((run / "host-to-guest.bin").read_bytes(), False)
          and not (run / "guest-to-host.bin").stat().st_size, "socket capture mismatch")
    mac = re.search(r"mac=([0-9a-f:]{17})", (run/"launch.json").read_text()).group(1)
    header = bytes.fromhex(mac.replace(":","") + "024a4e4f580188b5")
    for i, packet in enumerate(packets[:-1]):
        prefix = header + b"JNOXRECV" + nonce + i.to_bytes(4, "big")
        check(len(packet) == 60 + i%32 and packet.startswith(prefix), f"data {i}")
    check(packets[-1] == header + b"JNOXACK!" + nonce + bytes(30), "ACK content")

    entries = {}
    for name in ("add_recvbuf_small", "virtnet_rq_get_buf"):
        pc = service[name]
        count = len(re.findall(r"^Trace \d+: .*\[\w+/%016x/" % pc, log, re.M))
        check(count == 113 if name == "add_recvbuf_small" else count >= 81, name)
        entries[name] = {"pc":hex(pc), "entry_events":count}

    events = re.findall(r"memory_region_ops_(read|write) cpu 0 mr \S+ addr (0x\w+) value (0x\w+) size 4 name 'virtio-mmio'", log)
    cfg = {}
    selected = None
    resets = []
    for op, addr, value in events:
        offset = int(addr, 16) - 0xa003e00
        value = int(value, 16)
        if op == "write" and offset == 0x30:
            selected = value
        if op == "write" and selected == 0:
            cfg[offset] = value
        if offset == 0x70 and op == "write" and value == 0:
            resets = []
        if op == "read" and offset in (0x70, 0x44):
            resets.append((offset, selected, value))
    check([(o,v) for o,s,v in resets] == [(0x70,0),(0x44,0),(0x44,0)]
          and [s for o,s,v in resets[1:]] == [0,1], "reset readback")
    n = cfg[0x38]
    check(n == 32 and cfg[0x44] == 1 and all(cfg[i] == 0 for i in (0x84,0x94,0xa4)), "queue addresses")
    observations = {}
    for stage, completed in (("ready",0),("active",80),("final",81)):
        ram = Ram(run / stage / "ram.json")
        service_root, peer_root = 0x40258000, 0x4066d000
        mmio = 0x0a003000
        owner_mapping = ram.entry(service_root, mmio)
        peer_mapping = ram.entry(peer_root, mmio)
        check(owner_mapping and owner_mapping[0] == mmio and not (owner_mapping[1] & 0x40), "service MMIO")
        check(peer_mapping is None or not (peer_mapping[1] & 0x40), "peer MMIO")
        def peer_read(name, size):
            va = peer[name]
            out = bytearray()
            while len(out) < size:
                mapped = ram.entry(peer_root, va)
                check(mapped and mapped[1] & 0x40, "peer user page")
                owner = ram.entry(service_root, va)
                check(owner is None or owner[0] != mapped[0], "peer aliases service VA")
                chunk = min(size-len(out),4096-(va%4096))
                out.extend(ram.read(mapped[0], chunk))
                va += chunk
            return bytes(out)
        memory = peer_read("jnox_rx_peer_frames", 80*91)
        for i, packet in enumerate(packets[:-1]):
            expected = packet if completed else bytes(len(packet))
            check(memory[i*91:i*91+len(packet)] == expected, f"{stage} peer frame {i}")
        check(peer_read("jnox_rx_peer_ack",60) == (packets[-1] if completed==81 else bytes(60)), "peer ACK")
        available, = struct.unpack("<H", ram.read(cfg[0x90]+2,2))
        used, = struct.unpack("<H", ram.read(cfg[0xa0]+2,2))
        check((available,used) == (n+completed,completed), "queue indices")
        for j in range(max(0,completed-n),completed):
            slot = j % n
            head, size = struct.unpack("<II",ram.read(cfg[0xa0]+4+8*slot,8))
            check(head == slot and size == 12+len(packets[j]), "used ring entry")
            addr, capacity, flags, nxt = struct.unpack("<QIHH",ram.read(cfg[0x80]+16*head,16))
            check(flags==2 and capacity>=size and (stage == "final" or ram.read(addr+12,size-12)==packets[j]), f"{stage} DMA contents {j} {addr:x} flags={flags}")
        observations[stage] = {"available":available,"used":used,"available_laps":available//n,"used_laps":used//n}
    identity = json.loads((run/"launch.json").read_text())["identities"]
    for key, path in (("kernel_sha256",native/"kernel.elf"),("package_sha256",native/"manifest.json")):
        check(identity[key]==hashlib.sha256(path.read_bytes()).hexdigest(),key)
    uart = (run/"uart.log").read_text()
    for label, filename in (("NATIVE EL0 ELF","user.elf"), ("NATIVE EL0 PEER ELF","native_peer.elf")):
        check(label+" "+hashlib.sha256((native/filename).read_bytes()).hexdigest() in uart, "boot identity")
    check(identity["import_sha256"] == hashlib.sha256((native.parent/"imported/import.json").read_bytes()).hexdigest(), "import identity")
    return {"nonce":nonce.hex(),"callbacks":entries,"queue0":observations,"data_frames":80,"ack_frames":1}


def main():
    root = Path(sys.argv[1])
    native = root/"native"
    service = symbols(native/"user.elf")
    peer = symbols(native/"native_peer.elf")
    certify(root, service)
    results = {run:review(root/run,service,peer,native) for run in ("capture-a","capture-b")}
    check(results["capture-a"]["nonce"] != results["capture-b"]["nonce"], "reused nonce")
    Path(sys.argv[2]).write_text(json.dumps(results,indent=2)+"\n")

if __name__ == "__main__":
    main()





