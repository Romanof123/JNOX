import json, subprocess as s, sys, os, re, hashlib
from pathlib import Path
r=Path(sys.argv[1]).resolve()
out=Path(__file__).resolve().parent
base="07fe7ef3c444a207f9ce4e013eff06aeb7b7cdc1"
head="b129f1fde2bbe54ccf8521bdbd9b67bb1c407f85"
def run(*cmd):
    return s.run(cmd,cwd=r,capture_output=True,env=dict(os.environ,PYTHONIOENCODING="utf8"))
def git(*cmd):
    p=run("git",*cmd)
    assert not p.returncode,p.stderr
    return p.stdout
def checkout(rev):
    git("checkout","-q",rev)
t=r/"trace/links.csv"
docs=[r/"docs"/("scheduling-release-cases"+x) for x in [".md",".en.md"]]
results=[]; healthy=None
msg="catalog and direct implementation cite EVD-058 without a typed POL-015 evidence link"
def audit(name,wanted,ref=None):
    global healthy
    p=run(sys.executable,"tools/scheduling_evidence.py")
    j=json.loads(p.stdout)
    classes={k:v["classification"] for k,v in j["policies"].items()}
    if healthy is None: healthy=j
    result=dict(name=name,rc=p.returncode,findings=j["findings"],pass_expected=p.returncode==bool(wanted) and j["findings"]==([msg] if wanted else []),classes=classes if ref is None else classes==ref,policies=len(classes),evidence=len(j["evidence"]))
    results.append(result)
    return classes,j
def drop():
    v=t.read_bytes();t.write_bytes(re.sub(rb"(?m)^POL-015,has-partial-policy-evidence,EVD-058\r?\n",b"",v))
for rev,label in [(base,"old"),(head,"candidate")]:
    checkout(rev)
    with t.open("ab") as f: f.write(b"POL-014,has-partial-policy-evidence,EVD-057\n")
    c,j=audit(label+" healthy",False)
    if label=="candidate": results[-1]["full_equal_old"]=j==healthy
    drop()
    c,j=audit(label+" missing",True)
    git("restore","trace/links.csv")
with t.open("ab") as f: f.write(b"POL-014,has-partial-policy-evidence,EVD-057\n")
drop()
original=[p.read_text(encoding="utf-8") for p in docs]
link=re.compile(r"\[EVD-058\]\([^)]+\)")
for case in ["KO-only","EN-only","shared-context","remaining-physical","unrelated-prose","wrong-family","reordered-canonical-row","escaped-pipe-recorded-cell"]:
    for i,(p,src) in enumerate(zip(docs,original)):
        lines=src.splitlines()
        idx=next(k for k,x in enumerate(lines) if x.startswith("| POL-015 |"))
        row=lines[idx]; citation=link.search(row).group()
        lines[idx]=link.sub("",row)
        if case==["KO-only","EN-only"][i]: lines[idx]=row
        if case=="shared-context":
            lines[idx]=lines[idx].replace("POL-015 |","POL-015 | [EVD-041](shared.md)")
        if case=="remaining-physical": lines[idx]=lines[idx].rstrip("|")+" Physical: "+citation+" |"
        if case=="unrelated-prose": lines.append("POL-015 "+citation)
        if case=="wrong-family":
            n=next(k for k,x in enumerate(lines) if x.startswith("| POL-010 |"));lines[n]=lines[n].replace("POL-010 |","POL-010 | "+citation)
        if case=="reordered-canonical-row": lines.insert(idx-1,lines.pop(idx));lines[idx-1]=row
        if case=="escaped-pipe-recorded-cell": lines[idx]=row.replace("POL-015 |","POL-015 | A \\| B;")
        p.write_text("\n".join(lines)+"\n",encoding="utf-8")
    audit(case,case in ["KO-only","EN-only","reordered-canonical-row","escaped-pipe-recorded-cell"],c)
git("restore","docs/scheduling-release-cases.md","docs/scheduling-release-cases.en.md","trace/links.csv")
for name,cmd in [("scheduling unit suite",["-m","unittest","discover","-s","tools","-p","test_scheduling_evidence.py","-v"]),("requirement graph units",["-m","unittest","discover","-s","tools","-p","test_requirement_graph.py","-v"]),("requirement graph",["tools/requirement_graph.py"])]:
    p=run(sys.executable,*cmd)
    results.append(dict(name=name,rc=p.returncode,stderr=p.stderr.decode("utf8")[-4000:],stdout_lines=len(p.stdout.splitlines())))
(out/"healthy-control.json").write_text(json.dumps(results,indent=2),encoding="utf8")
for x in results: print(x["name"],x["rc"],x.get("pass_expected"),x.get("full_equal_old",""))

