import hashlib,struct,zipfile,json,re,requests
from pathlib import Path
from urllib.parse import urljoin
head='0e82a75dca989d744103f685ef12554ecbc0b526'
base='fc8d9b2d2db1508b70e455b22846e3fb06f4af61'
raw='https://raw.githubusercontent.com/Romanof123/JNOX/'
sha=lambda b:hashlib.sha256(b).hexdigest()
words='d53be029 b40002c8 8b080928 eb09011f 54000263 d503201f 10138269 08dffd2a 3500018a d503201f 10173dca d5033fdf d53be02b eb08017f 54000142 88dffd4b 3500010b d5033fdf 08dffd2b 34ffff0b 52800040 d4000021 d4200020 97fffef8 528ea220 97fffbf0'
for name,digest,expected in [('gic','bc1e9c33329d76283ee6fef5f20154e06f7074e65e59379ceb690622505fb495',[(16971,3758),(17038,3904)]),('sparse','6448322726161ae31e1cf27b7945f27ca2048238c4bd784c6b8c9a3e98b1f468',[(22613,5766),(24596,3970)])]:
    p=Path(name+'.zip')
    if not p.exists(): p.write_bytes(requests.get(raw+base+'/docs/evidence/pi4-mg2-'+name+'-first.zip').content)
    assert sha(p.read_bytes())==digest
    z=zipfile.ZipFile(p)
    entry=lambda suffix:z.read(next(n for n in z.namelist() if n.endswith('/'+suffix)))
    elf=entry('kernel.elf')
    assert sha(elf)=='8660010cca701e54f23a6af3c1782dd24bfd8da66d345147b5b4daba95f0002f'
    off=struct.unpack_from('<Q',elf,32)[0]
    size,count=struct.unpack_from('<HH',elf,54)
    for i in range(count):
        kind,flags,fileoff,vaddr,_,length=struct.unpack_from('<IIQQQQ',elf,off+i*size)
        if kind==1 and vaddr<=0x820f0 and 0x82158<=vaddr+length:
            assert struct.unpack_from('<26I',elf,fileoff+0x820f0-vaddr)==tuple(int(w,16) for w in words.split())
            break
    else: raise AssertionError('missing code')
    for i,n in enumerate(sorted(n for n in z.namelist() if n.endswith('terminal-ram.bin'))):
        ram=z.read(n)
        read=lambda a,k:struct.unpack_from('<'+'Q'*k,ram,a-0x8d000)
        j=0xa9178+6944
        count,lost=read(j+96*72,2)
        assert count>=7 and lost==0
        rows=[read(j+k*72,9) for k in range(count)]
        tr,rt=rows[3],rows[6]
        assert (tr[0],tr[1],tr[6],tr[8])==(0,2,65535,4) and (rt[:3],rt[8])==((0,2,2),3)
        f=read(tr[2],40)
        assert (f[9],f[10],f[31],f[39])==(0xa9154,1,0x82148,rt[4]) and tr[3]==f[31] and rows[0][2]==62500000
        sample=f[8]-4*rows[0][2]
        pair=(sample-rt[3],rt[4]-sample)
        assert pair==expected[i]
        print(name,n,hex(tr[2]),f[8],sample,pair)
diff=requests.get('https://api.github.com/repos/Romanof123/JNOX/compare/'+base+'...'+head).json()['files']
assert len(diff)==7 and all(x['filename'].startswith('docs/') and x['filename'].endswith('.md') for x in diff)
urls=set()
for change in diff:
    for line in change['patch'].splitlines():
        if line.startswith('+'):
            for link in re.findall(r'\]\(([^)]+)\)',line):
                u=urljoin(raw+head+'/'+change['filename'],link).replace('https://github.com/Romanof123/JNOX/blob/',raw).replace('https://github.com/Romanof123/JNOX/issues/','https://api.github.com/repos/Romanof123/JNOX/issues/')
                urls.add(u)
for u in sorted(urls):
    r=requests.get(u,timeout=30)
    r.raise_for_status()
    print(r.status_code,u)
    if '/issues/' in u: print(r.json()['state'],r.json()['title'])
    else: Path('source-'+u.rsplit('/',1)[-1]).write_bytes(r.content)

