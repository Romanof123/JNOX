set -eu
cd ~/jnox204-iv
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
d=/mnt/d/codex/jnox204-qa-record
for c in global partitioned clustered; do
 cp -r results/$c "$d/"
 for i in 1 2; do
  set +e
  python3 tools/pi4_migration_capture.py run results/$c "$(cat results/$c-build/freeze.digest)" "$i" > "$d/$c-$i.digest"
  rr=$?
  set -e
  cp -r results/$c/first-$i "$d/$c/"
  (cd results/$c/first-$i && sha256sum * ) > "$d/$c-$i.manifest"
  (cd "$d/$c/first-$i" && sha256sum -c "$d/$c-$i.manifest") > "$d/$c-$i.reopen"
  set +e
  python3 tools/pi4_migration_replay.py "$d/$c" "$i" "$(cat "$d/$c-$i.digest")" > "$d/$c-$i.replay"
  rp=$?
  set -e
  echo "$c $i capture=$rr replay=$rp" >> "$d/status.txt"
 done
done