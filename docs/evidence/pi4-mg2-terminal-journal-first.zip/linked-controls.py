from pathlib import Path
import re,struct,json
import unicorn as uc
from unicorn.arm64_const import *
D=Path(__file__).parent
out=[]
for case in ('global','partitioned','clustered'):
 p=D/case
 asm=(p/'disassembly.txt').read_text()
 block=asm.split('<jnox_kernel::pi4_migration_log::terminal>:\n')[1].split('\n\n')[0]
 def addr(pattern):
  return [int(n,16) for n in re.findall(r'^\s*([0-9a-f]+):.*?'+pattern,block,re.M)]
 entry=int(block.split(':')[0].strip(),16)
 log=int(re.search(r'adr\s+x\d+, ([a-f0-9]+) <jnox_kernel::pi4_migration_log::LOG>',block)[1],16)
 invalid=int(re.search(r'adr\s+x\d+, ([a-f0-9]+) <[^>]*INVALID',block)[1],16)
 release=addr(r'\bstlr\s')
 assert len(release)==2
 for free,cpu,sealed in [(0,0,0),(1,0,0),(2,0,0),(2,1,0),(2,2,0),(2,0,1)]:
  u=uc.Uc(uc.UC_ARCH_ARM64,uc.UC_MODE_ARM)
  u.mem_map(0x80000,0x90000)
  u.mem_write(0x80000,(p/'kernel8.img').read_bytes())
  count=96-free
  u.mem_write(log+6912,struct.pack('<QQ',count,0))
  u.mem_write(log+6936,bytes([sealed]))
  words=lambda base:struct.pack('<8Q',*range(base,base+8))
  for reg,val in [(UC_ARM64_REG_SP,0xf8000),(UC_ARM64_REG_X0,cpu),(UC_ARM64_REG_X1,0xf0000),(UC_ARM64_REG_X2,0xf0100),(UC_ARM64_REG_LR,0xff000)]:
   u.reg_write(reg,val)
  u.mem_write(0xf0000,words(100));u.mem_write(0xf0100,words(200))
  pubs=[]
  def written(u,kind,address,size,value,data):
   if address==log+6912:
    row=bytes(u.mem_read(log+72*(value-1),72))
    pubs.append([u.reg_read(UC_ARM64_REG_PC),value,list(struct.unpack('<9Q',row))])
  u.hook_add(uc.UC_HOOK_MEM_WRITE,written)
  u.emu_start(entry,0xff000,count=20000)
  assert u.reg_read(UC_ARM64_REG_PC)==0xff000
  final,lost=struct.unpack('<QQ',u.mem_read(log+6912,16))
  bad=bool(cpu or sealed)
  n=0 if bad else free
  assert (final,lost,bytes(u.mem_read(invalid,1)))==(count+n,0 if bad else 2-free,bytes([bad]))
  assert pubs==[[release[i],count+i+1,list(range(100*(i+1),100*(i+1)+8))+[[13,9][i]]] for i in range(n)]
  out.append(dict(case=case,free=free,cpu=cpu,sealed=sealed,used=final,lost=lost,invalid=bad,publications=pubs))
print(json.dumps(dict(unicorn=uc.__version__,cases=out),indent=2))
