import subprocess, sys, tarfile
from pathlib import Path
from tempfile import TemporaryDirectory
p=Path(__file__).parent
with tarfile.open(p/'edf-plain.tar.gz') as t:
 rows=t.extractfile('uart.bin').read().decode().splitlines()
def check(name,i,col,val):
 lines=list(rows); n=next(j for j,row in enumerate(lines) if f' EVENT {i} ' in row)
 fields=lines[n].split(); fields[4+col]=str(val); lines[n]=' '.join(fields)
 with TemporaryDirectory() as d:
  f=Path(d)/'mutated';f.write_text('\n'.join(lines)+'\n'); r=subprocess.run([sys.executable,str(p/'corrected.py'),str(f)],capture_output=True,text=True)
  print(name,r.returncode,r.stderr.strip()+r.stdout.strip());assert r.returncode
check('late return',2,16,22346403)
check('repeated IRQ cell',4,3,1)
check('service unsupported SVC',3,6,42)
check('compute unsupported SVC',1,6,18)
q=10
assert max(sum(x<=y<x+q for y in [0,10,20]) for x in [0,10,20])==1
print('half-open exact-Q exclusion passed')