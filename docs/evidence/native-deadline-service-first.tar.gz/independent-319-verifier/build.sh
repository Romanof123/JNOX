set -eux
. ~/.cargo/env
cd ~/ind319/checkout
o=~/ind319/evidence
mkdir -p "$o"
sh sdk/native-aarch64/build.sh examples/native-llf/checksum.c "$o/A.elf"
sh sdk/native-aarch64/build-rust.sh examples/native-weighted-rust/Cargo.toml "$o/B.elf"
sh sdk/native-aarch64/build.sh examples/native-deadline-service/service.c "$o/S.elf"
for f in "$o"/*.elf; do llvm-objdump -d "$f" > "$f.dis"; llvm-nm -an "$f" > "$f.sym"; done
for name in edf llf alt edf-cap edf-demand llf-cap llf-demand edf-old llf-old; do
 policy=${name%%-*}; cells=1,3; cap=6; job=0,12,1
 case $name in alt) cells=2,4; policy=edf;; *-cap) cap=5;; *-demand) job=0,2,2;; esac
 args=(--deadline-service-elf "$o/S.elf" --deadline-service-cells "$cells" --deadline-switch-cap "$cap")
 case $name in *-old) args=();; esac
 python3 tools/build_native_el0.py --out "$o/$name" --policy "$policy" --elf "$o/A.elf" --job "$job" --peer-elf "$o/B.elf" --peer-job 0,13,4 "${args[@]}"
done