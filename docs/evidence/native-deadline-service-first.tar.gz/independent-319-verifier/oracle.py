import json, math, re, struct, subprocess, sys, gzip, tarfile
from pathlib import Path
from collections import defaultdict
root=Path(sys.argv[1])
def sym(path,needle):
 return int(next(l.split()[0] for l in path.read_text().splitlines() if needle in l),16)
def run(name,package):
 with tarfile.open(root/(name+'.tar.gz')) as t:
  get=lambda f:t.extractfile(f).read()
  u=get('uart.bin').decode(); ram=gzip.decompress(get('ram.gz')); regs=get('regs').decode(); traced='traced' in name
  if traced: trace=get('exceptions.log').decode(); samples=json.loads(get('progress.json'))
 base=sym(root/package/'kernel.sym','mmu6SPACES'); unpack=lambda fmt,pa:struct.unpack_from('<'+fmt,ram,pa-0x40000000)
 def pa(s,va):
  table=base+s*0x415000
  for shift in (30,21,12):
   desc,=unpack('Q',table+8*((va>>shift)&511));assert desc&3==3;table=desc&0xfffff000
  return table+(va&4095)
 def read(s,tag,fmt):
  va=sym(root/('ABS'[s]+'.elf.sym'),' '+tag);return unpack(fmt,pa(s,va))
 def rows(tag):
  return [list(map(int,x.split())) for x in re.findall(r'RECURRING '+tag+r' (.+)',u)]
 def pc():
  return int(re.search(r'PC=([0-9a-f]+)',regs)[1],16)
 assert len(ram)==128*1024**2 and 'EL1h' in regs
 files=['A','B']+([] if name.endswith('old') else ['S'])
 import hashlib
 for a in files: assert hashlib.sha256((root/(a+'.elf')).read_bytes()).hexdigest() in u
 a=read(0,'private_blocks','I')+read(0,'private_result','Q')
 b=read(1,'private_progress','I')+read(1,'private_result','9I')
 assert pa(0,0x402000)!=pa(1,0x402000)
 if rows('REFUSED'):
  reason=10 if name.endswith('cap') else 8
  assert rows('REFUSED')==[[reason,0,0]] and not rows('ARM') and not rows('EVENT') and 'FAULT 14' in u
  assert not any(a+b+read(2,'service_receipt_count','I'))
  return dict(reason=reason,terminal_pc=hex(pc()),private_products='all zero')
 assert a==(16,8355840) and b==(67108864,)+tuple(math.comb(8,k)*262144 for k in range(9))
 assert 'EXIT PID 0 17' in u and 'EXIT PID 1 197' in u
 if name.endswith('old'):assert 'RECURRING' not in u and 'DROPPED 0' in u;return dict(A=a,B=b)
 cells=([2,4] if name=='alternate-plain' else [1,3]);policy='llf' if name.startswith('llf') else 'edf'
 v,S,Q,hz,mask,cap=rows('CONFIG')[0];assert (v,Q*10,hz,mask,cap)==(1,hz,62500000,sum(1<<k for k in cells),6)
 assert rows('JOB')==[[0,0,12,1],[1,0,13,4]] and rows('ARM')[0][0]<S==rows('ARM')[0][1]
 assert len({pa(i,0x402000) for i in range(3)})==3
 assert read(2,'service_receipt_count','I')==(2,) and read(2,'service_wait_ordinal','2i')[1]==1
 receipts=[]
 for i,k in enumerate(cells):
  f=64*i+1;l=f+63
  row=unpack('6IQ',pa(2,sym(root/'S.elf.sym',' service_receipts')+32*i))
  assert row==(i,k,f,l,64,0,sum(j*j for j in range(f,l+1)));receipts.append(row)
 assert 'EXIT PID 2 41' in u
 ev=rows('EVENT');assert rows('END')==[[0,len(ev),0]]
 own=3; changes=[];frames={};due=[12,13];rem=[1,4];saved_regular=[];restored=[];irq=[];svc=[];lastret=0;ex={};occ=defaultdict(int);gaps=[]
 for idx,r in enumerate(ev):
  seq,kind,t,k,src,dst,op,spc,ssp,dpc,dsp,sx,dx,old,nxt,arm,ret,begin,used,ordinal,ra,rb,fifo,term,fail=r
  assert seq==idx and not fail and src==own and t>=lastret and (t-S)//Q==k and begin==lastret and used==(t-begin if idx else 0)
  occ[src]+=used
  if src<3:frames[src]=(spc,ssp);assert 0x400000<=spc<0x401000 and 0x1001000<=ssp<0x1011000
  if kind==1:
   assert op==30 and len(irq)==k and old==S+k*Q;irq.append(k)
   if src<2:rem[src]=max(1,rem[src]-1)
   if k in cells:assert dst==2;svc.append(k);assert dx==cells.index(k)
   if src<2 and dst==2:saved_regular.append((src,spc,ssp,k))
  else:
   assert kind==2 and old==S+(k+1)*Q
   if src==2:assert (op,sx if op==1 else 0,dst)==((1,41,3) if k==cells[-1] else (18,0,3))
   else:assert op==1 and k not in cells and sx==[17,197][src] and t<=S+due[src]*Q;ex[src]=t;rem[src]=0
  if dst<3:
   if dst in frames:assert frames[dst]==(dpc,dsp)
   for s,pc0,sp0,k0 in saved_regular:
    if dst==s and (dpc,dsp)==(pc0,sp0) and k>k0:restored.append((s,k0,k,hex(pc0),hex(sp0)))
   if dst<2:
    assert k not in cells and rem[dst]
    ranks={j:due[j] if policy=='edf' else due[j]-k-rem[j] for j in range(2) if rem[j]}
    assert ranks[dst]==min(ranks.values())
  if dst!=4:
   assert (ret-S)//Q==k and t<=ret<nxt==S+(k+1)*Q
   if kind==1:assert t<=arm<=ret
   else:assert arm==0
   gaps.append(ret-t)
   if dst!=src:changes.append(t)
  else:assert (term,ret,nxt)==(1,0,0) and idx==len(ev)-1 and k>cells[-1]
  own=dst;lastret=ret
 assert svc==cells and restored and set(ex)=={0,1}
 assert [(r[3],r[6]) for r in ev if r[1]==2 and r[4]==2]==[(cells[0],18),(cells[1],1)]
 assert all(ev[i+1][4]==3 and ev[i+1][3]==r[3]+1 for i,r in enumerate(ev) if r[4]==2)
 peak=max(sum(x<=y<x+Q for y in changes) for x in changes);assert peak<=6
 ext=None
 if traced:
  entries=re.findall(r'Taking exception \d+ \[(IRQ|SVC)\]\n\.\.\.from EL(\d) to EL1.*?with ELR 0x([0-9a-f]+)',trace,re.S)
  assert len(entries)==len(ev)
  for (kind,el,pc0),r in zip(entries,ev):
   assert kind==('IRQ' if r[1]==1 else 'SVC') and int(el)==(1 if r[4]==3 else 0)
   if el=='0':assert int(pc0,16)==r[7]
  assert [int(x,16) for x in re.findall(r'Exception return from AArch64 EL1 to AArch64 EL0 PC 0x([0-9a-f]+)',trace)]==[r[9] for r in ev if r[5]<3]
  vals=[s[1] for s in samples];assert vals==sorted(vals) and 0<vals[-1]<=b[0]
  plateau=[(v,len(list(g))) for v,g in __import__('itertools').groupby(vals) if 0<v<67108864];ext={'entries':len(entries),'last_live_progress':vals[-1],'interior_plateaus':[(v,n) for v,n in plateau if n>=5]}
 return dict(A=a,B=b,receipts=receipts,epoch=S,exit=ex,margin=[S+due[j]*Q-ex[j] for j in range(2)],restored=restored,occupancy=occ,handler_gaps=gaps,peak=peak,external=ext)
if __name__=='__main__':
 for name,p in [('edf-plain','edf'),('edf-traced','edf'),('llf-plain','llf'),('llf-traced','llf'),('alternate-plain','alt')]+[(n,n) for n in ('edf-cap','edf-demand','llf-cap','llf-demand','edf-old','llf-old')]:
  print(json.dumps(dict(position=name,details=run(name,p))),flush=True)