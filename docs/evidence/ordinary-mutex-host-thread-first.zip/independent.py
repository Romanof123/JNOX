import json,re,struct,sys,hashlib
from pathlib import Path
root=Path(sys.argv[1])
results=[]
for directory in sorted(root.glob('0*')):
    rows={}
    for line in (directory/'uart').read_text().splitlines()[3:-1]:
        key,*vals=line.split()
        rows.setdefault(key,[]).append([int(x,16) for x in vals])
    ce,reason,ne,nr,nc=rows['H'][0]
    events,returns=rows['E'],rows['R']
    assert len(events)==ne==nr==len(returns)
    trace=(directory/'external.log').read_text().splitlines()
    assert len(trace)==6*ne
    for i,(e,r) in enumerate(zip(events,returns)):
        ret,kind,level,esr,elr,vec=trace[6*i:6*i+6]
        assert ret.endswith(' PC '+hex(r[1])) and elr.endswith(' '+hex(e[7]))
        assert kind=='Taking exception '+('5 [IRQ]' if e[2]==5 else '2 [SVC]')
        assert level=='...from EL1 to EL1' and re.fullmatch(r'\.\.\.with ESR 0x[0-9a-f]+/0x[0-9a-f]+',esr)
        assert vec=='...to EL1 PC '+('0x40201280' if e[2]==5 else '0x40201200')+' PSTATE 0x3c5'
        if i: assert r[:2]==events[i-1][10:12] and r[2]>=events[i-1][1]
    n,=[i for i,e in enumerate(events) if e[2:6]==[1,ce,0,0] and e[19]==0]
    k,=[i for i,e in enumerate(events) if e[2]==5]
    e,irq=events[n],events[k]
    low,priority,lo,hi,size=rows['S'][0]
    dest=[0x40202480,0x40202554][ce]
    f,start,target,rb,ctl,iar,irqctl,icv=rows['T'][0]
    assert (f,target-start,rb,ctl,iar,irqctl,icv)==(62500000,6250,target,1,30,5,target)
    assert k==n+1 and low==0 and priority==2 and size==832 and lo<=e[6]<=hi-size and e[6]%16==0
    assert e[6:8]==[e[10],dest] and e[11]==dest and e[23:25]==[1,1] and e[14+ce]==0
    assert irq[4]==0 and irq[23]==1 and lo<=irq[6]<=hi-size and irq[8]&128==0 and irq[0]>=max(target,returns[k][2])
    out=dict(position=directory.name,reason=reason,irq_chunks=irq[20],active=irq[21],final_chunks=nc,eret_ordinal=k+1,nr=nr,irq_elr=hex(irq[7]),return_pc=hex(dest),frame=hex(e[6]))
    marker=directory/'marker.bin'
    if marker.exists():
        data=marker.read_bytes()
        count,invalid,rw,rc=struct.unpack_from('<4Q',data)
        assert len(data)==98336 and 0<count<=2048 and not invalid and not any(data[32+48*count:]) and rw>0 and rc>0
        rr=list(struct.iter_unpack('<6Q',data[32:32+48*count]))
        tid=rr[0][2]
        assert tid>0 and all(s<6 and v==0 and t==tid and a<=b for s,v,t,a,c,b in rr)
        assert all(p[5]<=q[3] and p[4]<=q[4] for p,q in zip(rr,rr[1:]))
        ids=[r[0] for r in rr]
        starts=[i for i,s in enumerate(ids) if s==0]
        assert len(starts)==nr and [s for s in ids if s in (0,1)]==[0,1]*nr and all(ids[i:i+2]==[0,1] for i in starts)
        a=starts[k]+1
        b,=[i for i,s in enumerate(ids) if s==5]
        assert a<b<(starts+[count])[k+1] and ids[a+1:b] in ([],[2],[2,3],[2,3,4])
        assert 2 in ids[a+1:b] or irq[7]==dest
        assert (4 not in ids[a+1:b] or irq[21]==1) and (3 in ids[a+1:b] or irq[21]==0) and (irq[20]==0 or 4 in ids[a+1:b])
        out.update(tid=tid,vcpu=0,res=[rw,rc],raw=rr[a-1:b+1],intervals={})
        for q in rr[a+1:b+1]:
            p=rr[a]
            w=[max(0,q[3]-p[5]-2*rw),q[5]-p[3]+2*rw]
            c=[max(0,q[4]-p[4]-2*rc),q[4]-p[4]+2*rc]
            out['intervals'][q[0]]=[w,c,[w[0]-c[1],w[1]-c[0]]]
    results.append(out)
print(json.dumps(results,indent=2))
