set -eu
cd ~/jnox290-independent-EIigwQ
w=$PWD
cd src
export CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup
export PATH=$CARGO_HOME/bin:$PATH RUSTUP_TOOLCHAIN=1.95.0
sed -e 's/"int",/"in_asm,cpu,int,nochain", "-trace", "gic_acknowledge_irq",/' tools/native_el0_capture.py > "$w/capture.py"
export PYTHONPATH=$PWD/tools:$HOME/jnox288-independent.OPNpyt/deps/usr/lib/python3/dist-packages
for n in legacy-startup clock; do
 if [ "$n" = legacy-startup ]; then probe=examples/portability/native_startup_probe.c; expected=37; args=(); else probe=examples/portability/clock_checksum.c; expected=0; args=(--clock-app); fi
 buildargs=(); if [ "$n" = clock ]; then buildargs=(--source "$probe"); fi
 python3 tools/build_native_el0.py --out "$w/$n-package" "${buildargs[@]}"
 digest=$(python3 tools/native_el0_capture.py "$w/$n-run" "$w/$n-package/kernel.elf" "$w/$n-package/user.elf" "$probe" "$(git rev-parse HEAD)" --expect-exit "$expected")
 python3 tools/native_el0_replay.py "$w/$n-run" "$digest" "${args[@]}" > "$w/$n.replay"
done
