set -eu
cd ~/jnox290-independent-EIigwQ
w=$PWD
cd src
export CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup
export PATH=$CARGO_HOME/bin:$PATH RUSTUP_TOOLCHAIN=1.95.0
sed -e 's/"int",/"in_asm,cpu,int,nochain", "-trace", "gic_acknowledge_irq",/' tools/native_el0_capture.py > "$w/capture.py"
export PYTHONPATH=$PWD/tools
for n in c rust; do
 if [ "$n" = c ]; then
 probe=examples/portability/periodic_report.c
 sh sdk/native-aarch64/build.sh "$probe" "$w/c.elf"
 else
 probe=examples/native-periodic-rust/src/main.rs
 sh sdk/native-aarch64/build-rust.sh examples/native-periodic-rust/Cargo.toml "$w/rust.elf"
 fi
 python3 tools/build_native_el0.py --out "$w/$n-package" --elf "$w/$n.elf"
 python3 "$w/capture.py" "$w/$n-run" "$w/$n-package/kernel.elf" "$w/$n-package/user.elf" "$probe" "$(git rev-parse HEAD)" --expect-exit 0 || true
 cat "$w/$n-run/uart.bin"
done
