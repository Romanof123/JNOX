import json,subprocess,sys,hashlib
from pathlib import Path
p=Path.cwd(); f=p/'first'; a=Path.home()/'iv340-a1a6-first/packages/wake'
c=f/'iv343-control-01'; o=f/'iv343-observer-01'
args=[sys.executable,'tools/native_idle_delivery_report.py','--control',str(c),'--observed',str(o),'--preflight',str(f/'preflight/preflight.json'),'--wait-calibration',str(f/'calibration/wait-calibration.json'),'--kernel',str(a/'kernel.elf'),'--markers',str(f/'markers.bin'),'--apps',*[str(a/n) for n in ('user.elf','native_peer.elf','native_peer2.elf')]]
def run(name,argv):
    r=subprocess.run(argv,capture_output=True);(p/(name+'.json')).write_bytes(r.stdout);(p/(name+'.stderr')).write_bytes(r.stderr); print(name,r.returncode,flush=True);return r.returncode,json.loads(r.stdout)
rc,r=run('public-report',args);assert rc==0
assert not r['limitations'] and not r['natural_late_records'] and 'trial_bounds' in r['wait_calibration']
for which,scored,lag in [('control',29,22179),('observed',30,16244)]:
    v=r[which]; assert v['products']['match'] and v['health']['health']['scored']==scored and v['health']['health']['max_lag']==lag and v['health']['health']['late']==0
    old=json.loads((f/'offline-report.json').read_text())[which]
    for key in ('health','timing','products','reporter_wake_rows','reporter_sleep_rows'):assert old[key]==v[key]
orig=(c/'symbols').read_text(); s=next(l for l in orig.splitlines() if '6SPACES' in l)
for name,line,reason in [('absent','','missing'),('ambiguous',s+'\n'+s,'ambiguous'),('address',s.replace('40234000','40234008'),'differs'),('size',s.replace('c3f000','c3eff8'),'size'),('type',s.replace(' b ',' d '),'storage')]:
    d=p/name;d.mkdir()
    for file in c.iterdir():
        if file.name!='symbols':(d/file.name).symlink_to(file)
    (d/'symbols').write_text(orig.replace(s,line)); argv=args.copy();argv[3]=str(d)
    rc,report=run(name,argv);assert rc==2 and reason in report['reason']
h=json.loads((o/'host.json').read_text()); pf=json.loads((f/'preflight/preflight.json').read_text()); cal=json.loads((f/'calibration/wait-calibration.json').read_text())
for key in ['boot_id','platform','uid']:assert h[key]==cal[key]==pf[key]
assert h['allowed_cpus']==pf['allowed_cpus']==cal['allowed_before']==cal['allowed_after']
cal['boot_id']='different-boot';trial=p/'mismatch-trial.json';trial.write_text(json.dumps(cal));argv=args.copy();argv[argv.index('--wait-calibration')+1]=str(trial);rc,bad=run('identity-control',argv);assert rc==0 and 'trial_bounds' not in (bad['wait_calibration'] or {})
print('qualified, matched originals; every deliberate failure retained')
