#!/usr/bin/env bash
set -euo pipefail
revision=$1
arrivals=$2
component=$3
here=$(cd "$(dirname "$0")" && pwd)
pairs=()
for policy in fifo rr; do
    for scenario in before same after; do
        pkg="$arrivals/$policy-arrival-$scenario"
        pairs+=(--present "$pkg/manifest.json" "$pkg/kernel.elf")
    done
    for scenario in before exact after; do
        pkg="$component/$policy-$scenario"
        pairs+=(--absent "$pkg/manifest.json" "$pkg/kernel.elf")
    done
done
exec python3 -B "$here/verify_symbols.py" --revision "$revision" "${pairs[@]}"
