"""Check linked symbols against independent expected inclusion in existing native packages."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def check(revision, nm, manifest_path, image, expected):
    m = json.loads(manifest_path.read_text())
    data = image.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    boundary = m.get("safety_boundary", {})
    role_args = [s["argv"][1:] for s in m["slots"]]
    arrival = (len(role_args) == 3 and role_args[0] == role_args[1] == role_args[2]
               and role_args[0] in (["arrival-before"], ["arrival-same"], ["arrival-after"])
               and boundary.get("scenario") == role_args[0][0])
    if (m["commit"] != revision or m["tracked_changes"] or m["kernel_elf_sha256"] != digest
            or data[:6] != b"\x7fELF\x02\x01" or int.from_bytes(data[18:20], "little") != 183):
        raise ValueError(f"{image}: image provenance or AArch64 ELF mismatch")
    if expected != arrival:
        raise ValueError(f"{manifest_path}: role argv/manifest disagree with requested expectation")
    subset = {k: v for k, v in boundary.items() if k.startswith("opening_queue")}
    if subset != ({"opening_queue_event": 17, "opening_queue_schema": 1} if expected else {}):
        raise ValueError(f"{manifest_path}: observer manifest mismatch")
    raw = subprocess.check_output([nm, "--defined-only", image], text=True)
    if "jnox_native_el0_journal" not in raw or (m.get("safety_channel") and "jnox_virtual_permit_enable" not in raw):
        raise ValueError(f"{image}: expected native symbol table missing")
    observer = [line for line in raw.splitlines() if "observe_opening_queue" in line]
    if len(observer) != int(expected):
        raise ValueError(f"{image}: unexpected observer symbols {observer}")
    return dict(kernel_sha256=digest, policy=m["policy"], argv=role_args, expected=expected,
                safety_boundary=boundary, observer_symbols=observer)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--revision", required=True)
    p.add_argument("--nm", default="aarch64-linux-gnu-nm")
    for mode in ("present", "absent"):
        p.add_argument("--" + mode, type=Path, nargs=2, action="append", default=[],
                       metavar=("MANIFEST", "KERNEL_ELF"))
    a = p.parse_args()
    if not (a.present or a.absent):
        p.error("supply one or more manifest/image pairs with the independently expected result")
    rows = [check(a.revision, a.nm, m, elf, expected) for expected, pairs in ((True, a.present), (False, a.absent))
            for m, elf in pairs]
    print(json.dumps(dict(commit=a.revision, checks=rows), indent=2))
