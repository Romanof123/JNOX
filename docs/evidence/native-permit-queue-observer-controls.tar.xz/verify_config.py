"""Exercise the frozen Python packager and host Rust build script without building a guest."""
import argparse
import contextlib
import hashlib
import io
import itertools
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from unittest.mock import patch

sys.dont_write_bytecode = True
ARRIVALS = ("arrival-before", "arrival-same", "arrival-after")
BOUNDARY = ("channel", "boundary")
CFG = "cargo::rustc-cfg=jnox_native_safety_arrival_observation"
MATCH = ("one matching boundary selector", "matching selectors for three slots")
UNIT = "tests::opening_queue_reads_the_published_front_without_consuming_it"


def require(value, message):
    if not value:
        raise ValueError(message)


def cases():
    for roles in itertools.product(ARRIVALS, repeat=3):
        yield "/".join(roles), [[s] for s in roles], BOUNDARY, None if len(set(roles)) == 1 else MATCH
    for scenario in ("phase", "phase-decision", "phase-complete", "collision", "rearm-15", "rearm-20"):
        yield scenario, [[scenario]] * 3, BOUNDARY, None
    for modes in ((), ("channel",), ("channel", "watchdog"), ("channel", "qualification"),
                  ("channel", "qualification", "watchdog")):
        yield "+".join(modes) or "no-safety", [[ARRIVALS[0]]] * 3, modes, None
    for index in range(3):
        for change in ("missing", "extra"):
            roles = [[ARRIVALS[0]] for _ in range(3)]
            roles[index] = [] if change == "missing" else [ARRIVALS[0], "0"]
            error = MATCH if (change, index) != ("extra", 2) else (
                "only a rearm boundary permits", "only rearm accepts one supervisor lead")
            yield f"{change}-role-{index}", roles, BOUNDARY, error
    for spelling in ("Arrival-before", "arrival", "arrival-after "):
        yield "unknown-" + repr(spelling), [[spelling]] * 3, BOUNDARY, (
            MATCH[0], "unknown boundary observation selector")
    yield "fourth-selector", [[ARRIVALS[0]]] * 4, BOUNDARY, (
        "slot 3: arguments require a supplied ordinary application", MATCH[1])
    yield "without-channel", [[ARRIVALS[0]]] * 3, ("boundary",), (
        "single-check --safety-channel", "single-check protected channel")
    yield "boundary-watchdog", [[ARRIVALS[0]]] * 3, (*BOUNDARY, "watchdog"), (
        "excludes --safety-boundary", "excludes boundary fixtures")
    yield "boundary-qualification", [[ARRIVALS[0]]] * 3, (*BOUNDARY, "qualification"), (
        "single-check --safety-channel", "single-check protected channel")


def wire(strings):
    data = [s.encode("utf-8") for s in strings]
    return (bytes([len(data)]) + b"".join(len(s).to_bytes(2, "little") + s for s in data)).hex()


def package_test(pkg, root, images, out, case, policy, head):
    name, roles, modes, error = case
    argv = [str(pkg.__file__), "--out", str(out), "--elf", str(images[0]),
            "--peer-elf", str(images[1]), "--peer-elf", str(images[2]), "--policy", policy,
            "--priority", "6", "--peer-priority", "7", "--peer-priority", "4", "--loan-route", "0:1"]
    if policy == "rr":
        argv += ["--quantum-ticks", "625000"]
    argv += ["--safety-" + mode for mode in modes]
    for option, values in zip(("--arg", "--peer-arg", "--peer2-arg", "--peer3-arg"), roles):
        argv += [f"{option}={value}" for value in values]
    versions = {("git", "rev-parse", "HEAD"): head,
                ("git", "status", "--porcelain", "--untracked-files=no"): "host selector fixture",
                ("rustc", "-vV"): "host selector fixture", ("cargo", "--version"): "host selector fixture"}
    seen = []

    def kernel_stub(cmd, cwd, env, **kwargs):
        require(cmd == [sys.executable, "tools/build_kernel.py", "--arch", "aarch64"] and cwd == root,
                "unexpected child from Python packager")
        require([env.get(f"JNOX_NATIVE_ARGV{i}_HEX") for i in range(4)] ==
                [wire(r) if r else None for r in (roles + [[], [], [], []])[:4]], "argv encoding")
        require({k for k in env if k.startswith("JNOX_NATIVE_SAFETY_")} ==
                {"JNOX_NATIVE_SAFETY_" + mode.upper() for mode in modes}, "unexpected safety selector")
        seen.append(True)
        fake = Path(env["CARGO_TARGET_DIR"]) / "aarch64-unknown-none/release/jnox-kernel"
        fake.parent.mkdir(parents=True)
        fake.write_bytes(b"HOST CONFIG FIXTURE; NOT A KERNEL")

    stderr = io.StringIO()
    with patch.object(sys, "argv", argv), patch.object(pkg, "output", lambda cmd, *args: versions[tuple(cmd)]), \
            patch.object(subprocess, "run", kernel_stub), contextlib.redirect_stderr(stderr), \
            contextlib.redirect_stdout(io.StringIO()):
        try:
            pkg.main()
        except SystemExit as exc:
            detail = stderr.getvalue().splitlines()[-1].partition(": error: ")[2]
            require(exc.code == 2 and error and error[0] in detail and not seen and not out.exists(),
                    f"{name}: unexpected packager rejection {detail}")
            return {"refusal": detail}
    require(not error and seen == [True], f"{name}: unexpected packager result")
    manifest = json.loads((out / "manifest.json").read_text())
    boundary = manifest.get("safety_boundary", {})
    require([s["argv"] for s in manifest["slots"]] == [["/bin/app", *r] for r in roles], "manifest role argv")
    expected = "boundary" in modes and roles[0][0] in ARRIVALS
    expected_meta = {"opening_queue_event": 17, "opening_queue_schema": 1} if expected else {}
    require({k: v for k, v in boundary.items() if k.startswith("opening_queue")} == expected_meta,
            f"{name}: manifest observer contract {boundary}")
    require(("safety_boundary" in manifest) == ("boundary" in modes), f"{name}: boundary metadata")
    if "boundary" in modes:
        require(boundary["scenario"] == roles[0][0] and boundary["decision_event"] == 12, "check metadata")
    return {"boundary_manifest": boundary}


def rust_test(binary, images, out, case, policy):
    name, roles, modes, error = case
    out.mkdir()
    env = {"PATH": os.environ["PATH"], "LC_ALL": "C", "TARGET": "aarch64-unknown-none", "OUT_DIR": str(out),
           "JNOX_BOARD": "virt", "JNOX_PROFILE": "native", "JNOX_APP": "process", "JNOX_NATIVE_POLICY": policy,
           "JNOX_NATIVE_PRIORITIES": "6,7,4", "JNOX_NATIVE_LOAN_ROUTE": "0:1"}
    if policy == "rr":
        env["JNOX_NATIVE_QUANTUM_TICKS"] = "625000"
    env.update({"JNOX_NATIVE_SAFETY_" + m.upper(): "1" for m in modes})
    env.update({f"JNOX_NATIVE_ARGV{i}_HEX": wire(r) for i, r in enumerate(roles) if r})
    for img, role in zip(images, ("", "PEER_", "PEER2_")):
        key = "JNOX_NATIVE_" + role + "ELF"
        env[key], env[key + "_SHA256"] = str(img), hashlib.sha256(img.read_bytes()).hexdigest()
    result = subprocess.run([binary], cwd=out, env=env, capture_output=True, text=True, timeout=10)
    if error:
        require(result.returncode != 0 and error[1] in result.stderr and not any(out.iterdir()),
                f"{name}: unexpected build.rs rejection {result.stderr}")
    else:
        require(result.returncode == 0 and (out / "native_schedule.rs").is_file(),
                f"{name}: build.rs {result.stderr}")
    count = result.stdout.splitlines().count(CFG)
    expected = not error and "boundary" in modes and roles[0][0] in ARRIVALS
    require(count == int(bool(expected)), f"{name}: unexpected build.rs cfg count {count}")
    return {"exit": result.returncode, "observer_cfg": bool(count), "refusal": error[1] if error else None}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", required=True, type=Path)
    p.add_argument("--revision", required=True, help="Full frozen commit")
    args = p.parse_args()
    head = subprocess.check_output(["git", "-C", args.repo, "rev-parse", args.revision + "^{commit}"],
                                   text=True).strip()
    require(head == args.revision and len(head) == 40, "supply full immutable commit")
    with tempfile.TemporaryDirectory(prefix="permit-opening-config-") as directory:
        temp = Path(directory)
        archive = temp / "source.tar"
        subprocess.run(["git", "-C", args.repo, "archive", "--format=tar", "-o", archive, head,
                        "arch", "kernel", "tools"], check=True)
        root = temp / "source"
        root.mkdir()
        subprocess.run(["tar", "-xf", archive, "-C", root], check=True)
        sys.path.insert(0, str(root / "tools"))
        import build_native_el0 as pkg
        require(pkg.ROOT == root, "unexpected packager import")
        kernel = root / "kernel"
        compiler = subprocess.check_output(["rustc", "-vV"], cwd=kernel, text=True).strip()
        builder = temp / "build-script"
        subprocess.run(["rustc", "--edition=2024", "build.rs", "-o", builder], cwd=kernel, check=True,
                       env={**os.environ, "CARGO_MANIFEST_DIR": str(kernel)})
        unit = temp / "loan-unit"
        subprocess.run(["rustc", "--edition=2024", "--test", "src/loan_ipc.rs", "--cfg", "jnox_native_safety_channel",
                        "--cfg", "jnox_native_safety_downstream", "-o", unit], cwd=kernel, check=True)
        focused = subprocess.check_output([unit, "--exact", UNIT], text=True)
        require("1 passed" in focused and UNIT + " ... ok" in focused, "focused observer test missing")
        all_tests = subprocess.check_output([unit], text=True)
        images = [temp / f"slot{i}.bin" for i in range(3)]
        for i, img in enumerate(images):
            img.write_bytes(bytes([i]) * 128)
        rows = []
        for policy in ("fifo", "rr"):
            for i, case in enumerate(cases()):
                rows.append({"policy": policy, "case": case[0],
                             "packager": package_test(pkg, root, images, temp / f"package-{policy}{i}", case, policy, head),
                             "build_rs": rust_test(builder, images, temp / f"guard-{policy}{i}", case, policy)})
        print(json.dumps(dict(commit=head, source_archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                              scope="Host packager with kernel child stub; real host build.rs on inert input bytes; Rust units",
                              compiler=compiler, focused=focused.splitlines(), loan_suite=all_tests.splitlines(),
                              script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), cases=rows), indent=2))


if __name__ == "__main__":
    main()
