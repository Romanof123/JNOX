# Native opening queue observer validation

Frozen commit `a69bc6948c1d57c6df89d395e9307de5e0c6d6dc`. Both selector paths agreed in 102 FIFO and RR cases. Six matching arrival packages enabled the observer. Twenty-two valid controls omitted it and both selector paths rejected all 74 invalid cases. The focused queue-front test passed and the full host loan module suite passed all seven tests. The complete matrix and unit outputs are in `config.json`.

The twelve linked AArch64 kernels were already available from the serial integration lane. All six three-role arrival kernels contain the observer function. All six one-role component kernels use the ordinary native kernel configuration and omit it. The three-role phase, REARM, watchdog and qualification checks cover configuration and manifest behavior. The checked packages and their individual ELF hashes appear in `symbols.json`. This host validation executed zero additional guest boots.

동일한 고정 커밋에서 FIFO와 RR 구성 102건을 두 경로로 대조했다. 세 역할의 도착 조건이 일치한 6건에서 관측을 활성화했다. 유효한 대조군 22건에서는 비활성 상태였으며, 나머지 잘못된 구성 74건은 모두 거부됐다. 호스트 큐 단위 시험 7건이 통과했다. 실제 연결된 도착 커널 6개에서 관측 함수 심벌을 확인했고, 단일 역할 기본 커널 6개에서는 심벌이 없었다. 세 역할의 phase, REARM, watchdog, qualification에 대해서는 패키지 메타데이터와 빌드 설정을 확인했다.

Run on Linux after the serial build and capture lane. Use a Git repository containing the frozen commit, Python 3, Git, tar, GNU sha256sum and the kernel's installed Rust toolchain. The linked-image check also uses GNU nm with AArch64 support.

```sh
validation="$PWD"
revision=a69bc6948c1d57c6df89d395e9307de5e0c6d6dc
python3 -B "$validation/verify_config.py" --repo "$WSL_CHECKOUT" --revision "$revision" > "$validation/config.json"
```

The script extracts its source from the specified Git commit. It checks FIFO and RR, all 27 triples of the three arrival names, missing and extra role arguments, case and whitespace errors, a fourth role selector, incompatible profiles and controls for phase, collision, REARM, ordinary safety, watchdog and qualification. Each case passes through both the Python CLI and the independently invoked host build script. The CLI writes a manifest using a stubbed kernel child. The real build script validates synthetic, hash-bound input files. Neither path executes a guest. The JSON contains the build script status, emitted observer configuration, relevant manifest fields and both Rust unit outputs.

The focused unit check can also run by itself. Start in the frozen checkout's `kernel` directory. The test publishes two grants in reverse slot order, with a zero-length front grant, samples repeatedly and checks actual receive order.

```sh
work=$(mktemp -d)
rustc --edition=2024 --test src/loan_ipc.rs --cfg jnox_native_safety_channel --cfg jnox_native_safety_downstream -o "$work/loan-unit"
"$work/loan-unit" --exact tests::opening_queue_reads_the_published_front_without_consuming_it
```

For existing image/manifest pairs, state the expected inclusion for each input. Repeat either argument as needed. The report covers only the images supplied.

```sh
python3 -B "$validation/verify_symbols.py" --revision "$revision" \
  --present "$arrival/manifest.json" "$arrival/kernel.elf" \
  --absent "$control/manifest.json" "$control/kernel.elf" > "$validation/symbols.json"
```

The symbol check verifies the clean manifest revision, SHA-256 of the supplied AArch64 ELF, the three role arguments, observer metadata and the actual defined symbol table. Known native symbols establish that the input retains its symbol table before testing the observer's inclusion.

To reproduce the complete twelve-image matrix, point the wrapper at the two package directories in the captured lanes.

```sh
bash check_linked_lane.sh "$revision" "$arrivals_packet/packages" "$component_packet/packages" > symbols.json
```
