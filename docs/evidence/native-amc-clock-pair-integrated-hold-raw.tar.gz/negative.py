from run import *
import os
root=p/'neg';root.mkdir()
def one(name,i,fn):
 d=root/name;d.mkdir();sub=d/f'first-{i}';sub.mkdir()
 for f in co.iterdir():
    if f.is_file():(d/f.name).symlink_to(f)
 old=co/sub.name; session=json.load(open(old/'session.json'));ram=bytearray((old/'ram.bin').read_bytes());u=(old/'uart.bin').read_text();la=json.load(open(old/'launch.json'));base=la['ram_base']
 for f in old.iterdir():
    if f.name not in ['ram.bin','uart.bin','session.json']:(sub/f.name).symlink_to(f)
 def nums(tag):return [list(map(int,l.split(' '+tag+' ')[1].split())) for l in u.splitlines() if 'AMC '+tag+' ' in l]
 a,n,w,_=nums('INTERVALS')[0];read=lambda addr:struct.unpack_from('<Q',ram,addr-base)[0];put=lambda addr,val:struct.pack_into('<Q',ram,addr-base,val)
 rows=[list(struct.unpack_from('<23Q',ram,a-base+j*184)) for j in range(n)]
 def change(j,col,value):put(a+j*184+col*8,value)
 if i<=4:
    j=next(j for j,v in enumerate(rows) if v[4:6]==[1,0] and v[7]>=3125000)
    if fn=='ppi':change(j,1,29)
    if fn=='absent':change(j,0,2);change(j,1,6)
    if fn=='owner':change(j,4,2)
    if fn=='pair':
       pa,_,stride=nums('RESULTS')[0];addr=pa+16*stride+912+8;put(addr,read(addr)+16)
    if fn=='iar-upper':change(j,1,30+(1<<10))
 elif i==5:
    _,ix,ar,ln,_=nums('CLOCK_EVIDENCE')[0];off=read(ix+16);put(ar+off+8,1)
 else:
    j=next(j for j,r in enumerate(rows) if (r[4],r[13])==(0,1));k=next(j for j,r in enumerate(rows) if (r[4],r[13])==(1,0))
    if fn=='op':change(j,1,6)
    if fn=='invent-IRQ':change(j,0,1);change(j,1,30)
    if fn=='invent-SVC':change(j,0,2);change(j,1,6);change(j,19,1)
    if fn=='order':change(j,2,rows[j][9]-1)
    if fn=='charge':change(j,7,rows[j][7]+1)
    if fn=='restore':change(k,15,rows[k][15]+4)
    if fn=='root':change(k,21,rows[k][12])
    if fn=='pair':
       _,ix,ar,ln,_=nums('CLOCK_EVIDENCE')[0];off=read(ix+16);addr=ar+off+32+4*8;put(addr,read(addr)+16)
 (sub/'ram.bin').write_bytes(ram);(sub/'uart.bin').symlink_to(old/'uart.bin')
 session['hashes']['ram.bin']=sha(sub/'ram.bin');(sub/'session.json').write_text(json.dumps(session,indent=2)+'\n')
 cmd=[sys.executable,str(score),'report',str(d/'cohort.json'),sha(d/'cohort.json'),str(i),sha(sub/'session.json')]
 rc=go('neg-'+name,cmd);raw=json.load(open(p/('neg-'+name+'.stdout')));return dict(name=name,i=i,rc=rc,issues=raw.get('issues'),detail=raw.get('detail'),status=raw.get('status'),ram=session['hashes']['ram.bin'],session=sha(sub/'session.json'))
cases=[(i,n) for i in range(1,5) for n in ('ppi','absent','owner','pair','iar-upper')]+[(5,'fallback')]+[(6,n) for n in ('op','invent-IRQ','invent-SVC','order','charge','restore','root','pair')]
records=[]
for i,n in cases:
 r=one(str(i)+'-'+n,i,n);records.append(r);print(i,n,r['rc'],str(r['issues'] or r['detail'])[:92],flush=True)
(p/'negatives.json').write_text(json.dumps(records,indent=2))
