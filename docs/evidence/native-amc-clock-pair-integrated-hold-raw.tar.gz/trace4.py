from run import *
for i in (4,):
 old=co/f'first-{i}'; src=(old/'exceptions.log').read_text()
 for kind,fragment in [('vector4','')]:
    d=p/'neg'/f'{i}-trace-{kind}';d.mkdir();sub=d/old.name;sub.mkdir()
    for f0 in co.iterdir():
      if f0.is_file():(d/f0.name).symlink_to(f0)
    for f0 in old.iterdir():
      if f0.name not in ('exceptions.log','session.json'):(sub/f0.name).symlink_to(f0)
    if kind=='label':
       altered,count=re.subn(r'Taking exception 5 \[IRQ\](?=\n\.\.\.from EL0 to EL1)', 'Taking exception 5 [SVC]',src)
    else:
       altered,count=re.subn(r'(Taking exception 5 \[IRQ\]\n\.\.\.from EL0 to EL1\n\.\.\.with ESR [^\n]+\n\.\.\.with ELR [^\n]+\n\.\.\.to EL1 PC )0x40202480',r'\g<1>0x40202400',src)
    if not count:continue
    (sub/'exceptions.log').write_text(altered);s=json.load(open(old/'session.json'));s['hashes']['exceptions.log']=sha(sub/'exceptions.log');(sub/'session.json').write_text(json.dumps(s))
    rc=go('bad-trace-'+str(i)+kind,[sys.executable,str(score),'report',str(d/'cohort.json'),sha(d/'cohort.json'),str(i),sha(sub/'session.json')]);print(i,kind,count,rc)
