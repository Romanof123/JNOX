import hashlib, json, sys, subprocess, re,struct
from pathlib import Path
p=Path.cwd();f=p/'first';co=f/'cohort';sdk=p/'src/tools/native_clock_pair_controls.py';score=p/'src/tools/native_amc_clock_report.py'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def go(name,cmd):
 r=subprocess.run(cmd,capture_output=True);(p/(name+'.stdout')).write_bytes(r.stdout);(p/(name+'.stderr')).write_bytes(r.stderr);return r.returncode
if __name__=='__main__':
 print('sdk',go('sdk',[sys.executable,str(sdk)]))
 seal=sha(co/'cohort.json')
 summary={}
 for i in range(1,7):
    folder=co/f'first-{i}';label='public-'+str(i)
    rc=go(label,[sys.executable,str(score),'report',str(co/'cohort.json'),seal,str(i),sha(folder/'session.json')]);j=json.load(open(p/(label+'.stdout')));summary[i]=[rc,j.get('status'),j.get('issues')];print(i,summary[i],j.get('control_handoff'));assert rc==0
 (p/'public.json').write_text(json.dumps(summary,indent=2))
 print('independent',go('independent',[sys.executable,str(f/'decode.py')]))
 for i in (1,2,3,4,6):
    z=co/f'first-{i}';u=(z/'uart.bin').read_text();a,n,w,_=map(int,re.search(r'AMC INTERVALS (.*)',u)[1].split());ram=(z/'ram.bin').read_bytes();la=json.loads((z/'launch.json').read_bytes());rows=list(struct.iter_unpack('<23Q',ram[a-la['ram_base']:a-la['ram_base']+n*w*8]))
    if i==6:
       for x,r in enumerate(rows):
          if (r[4],r[13]) in ((0,1),(1,0)):print(x,r,rows[x-1])
    else:
       target=next((x,r) for x,r in enumerate(rows) if r[4:6]==(1,0) and r[7]>=3125000);print(i,target[0],target[1][:10])
