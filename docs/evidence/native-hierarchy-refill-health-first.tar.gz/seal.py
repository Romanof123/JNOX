from pathlib import Path
import hashlib,tarfile
root=Path('.')
def digest(f):
 h=hashlib.sha256()
 for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk)
 return h.hexdigest()
files=[]
for p in root.rglob('*'):
 if not p.is_file() or p.is_symlink():continue
 if p.parts[0] in ('src','original','control-target','independent-model','upstream-tests') or 'target' in p.parts or p.name in ('health-tests','MEMBER-SHA256') or p.suffix=='.gz':continue
 files.append(p)
manifest=Path('MEMBER-SHA256')
with manifest.open('w') as m:
 for p in sorted(files):
  with p.open('rb') as f:m.write(digest(f)+'  '+str(p)+'\n')
output=Path('idle-refill-health-first-a1a6.tar.gz')
with tarfile.open(output,'x:gz',compresslevel=6) as tar:
 for p in sorted(files+[manifest]):tar.add(p,arcname=str(p),recursive=False)
with tarfile.open(output) as tar:
 for line in manifest.read_text().splitlines():
  expected,name=line.split('  ',1)
  with tar.extractfile(name) as f:assert digest(f)==expected
 assert tar.extractfile(str(manifest)).read()==manifest.read_bytes()
with output.open('rb') as f:print(digest(f),output,len(files))
