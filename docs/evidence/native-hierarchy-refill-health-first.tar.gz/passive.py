from pathlib import Path
import re,json
for d in Path('raw').glob('*-passive'):
 l=(d/'exceptions').read_text().splitlines()
 rows=[list(map(int,s.split()[3:])) for s in (d/'uart').read_text().splitlines() if s.startswith('NATIVE HIERARCHY EVENT ')]
 def matching(s):return [i+1 for i,v in enumerate(l) if re.search(s,v)]
 seq={k:matching(v) for k,v in {'rise':'^gic_set_irq irq 30 level 1 cpumask 0x1','best':'^gic_update_bestirq cpu 0 irq 30','cpu_line':'^gic_update_set_irq cpu\\[0\\]: irq = 1','timer_condition':'^arm_gt_recalc gt recalc: timer 0 irqstate 1','exception':'^Taking exception 5 \\[IRQ\\]','ack':'^gic_acknowledge_irq cpu 0 acknowledged irq 30'}.items()}
 expected=[r[0] for r in rows if r[1]==1]; assert all(len(x)==len(expected) for x in seq.values()),{k:len(v) for k,v in seq.items()}
 chain=[]
 for i,row in enumerate(expected):
  event={k:v[i] for k,v in seq.items()}; assert list(event.values())==sorted(event.values())
  chain.append(dict(row=row,log_lines=event))
 (d/'provider-order.json').write_text(json.dumps(chain,indent=2))
 print(d,len(chain))
