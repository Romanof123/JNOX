#!/usr/bin/env python3
import sys,os,subprocess,signal,json
from pathlib import Path
dst=Path(os.environ["GROUP_CAPTURE_DIR"]);dst.mkdir()
argv=["/usr/bin/qemu-system-aarch64",*sys.argv[1:]];(dst/"launch.json").write_text(json.dumps(argv))
p=subprocess.Popen(argv,stdout=subprocess.PIPE);signal.signal(signal.SIGTERM,lambda *a:p.terminate())
with (dst/"uart.bin").open("wb") as out:
 while b:=os.read(p.stdout.fileno(),4096):out.write(b);sys.stdout.buffer.write(b);sys.stdout.buffer.flush()
p.wait()
