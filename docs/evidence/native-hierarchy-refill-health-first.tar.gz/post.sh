set -u
cd ~/iv340-a1a6-first
while test ! -f raw/swap-passive/outcome; do sleep 3; done
bash controls.sh > controls.log 2>&1
echo $? > controls.status
python3 audit.py > audit.log 2>&1
python3 samples.py > samples.log 2>&1
echo $? > samples.status
python3 health_audit.py > health-audit.log 2>&1
echo $? > health-audit.status
export PATH="$HOME/.cargo/bin:$PATH" RUSTUP_TOOLCHAIN=1.95.0
rustc --test --edition=2024 src/kernel/src/hierarchy_refill_health.rs -o host-controls/health-tests && host-controls/health-tests > host-controls/health-tests.log
