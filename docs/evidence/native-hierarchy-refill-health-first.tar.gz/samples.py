from pathlib import Path
import json,struct,re,subprocess,collections
h=Path(__file__).parent;m=json.loads((h/'metrics.json').read_text())
r=['# Native hierarchy first records / 네이티브 계층형 최초 검증','', 'Candidate b276a2ed8e9715fc6ced057b84681d77ccead755 against main 3906f6fcfe53f106b3f63c7080399a5fa4495dbf. Frozen ae7a0bddf8754e4fcb855ae04846015f6fe0c3e0. WSL ext4, single A72 TCG virt/GICv2 CPU, 62,500,000 Hz. All ten natural cold boots completed with original products and exits. Two plain firsts missed the frozen idle IRQ bound. Release timing verdict FAIL. No reruns or delayed IRQ injection.','', '열 번의 네이티브 최초 부팅에서 최종 산출물과 종료값은 모두 일치했다. 포화 및 교환 일반 부팅에서 실제 유휴 IRQ가 1,953,125틱 상한을 초과하여 전체 시간 판정은 실패다. 재실행 및 인위적인 지연 주입은 없었다.','', '|Position|Rows|Max IRQ lag|Max observation gap|Quota grants N|Positive overhead sum|True idle recoveries|Parent throttle windows|','|---|---:|---:|---:|---:|---:|---:|---:|']
supp={}
for c in ['saturated','swap','child-leaf','wake','single']:
 for mode in ['plain','trace']:
  name=c+'-'+mode; a=m[name];d=h/'raw'/name
  r+=['|'+ '|'.join(map(str,[name,a['rows'],max(i[2] for i in a['irq']),a['max_spacing'],len(a['grants']),a['positive_overruns'],len(a['idle']),len(set(p[1] for p in a['parent']))]))+'|']
  n=len(a['products']);b=(d/'samples').read_bytes();stride=8+960*n;samples=[]
  for pos in range(0,len(b),stride):
   snap=b[pos:pos+stride]; row=[]
   for i,v in enumerate(a['products']):
    frame=snap[8+n*128+i*832:];pc=struct.unpack_from('<Q',frame,264)[0];spsr=struct.unpack_from('<Q',frame,256)[0];sp=struct.unpack_from('<Q',frame,272)[0]
    x9=struct.unpack_from('<Q',frame,72)[0];off=8+128*i;field=int.from_bytes(snap[off:off+4],'little')
    row.append(dict(id=v['id'],frame_pc=pc,frame_sp=sp,spsr=spsr,ramp_counter=x9 if v['id'] in ('crc','energy') and 0x4004a0<=pc<=0x400554 else None,private_hist_bytes=field if v['id']=='histogram' else None))
   samples.append(row)
  (d/'sample-decode.json').write_text(json.dumps(samples))
  ledger=json.loads((d/'ledger.json').read_text())
  if c in ('saturated','swap','child-leaf','wake'):
   id=2 if c!='wake' else 1;fields=[s[id]['ramp_counter'] if c!='wake' else s[id]['private_hist_bytes'] for s in samples];vals=sorted(set(v for v in fields if v is not None and v>0));assert len(vals)>=2
  if c=='single':
   pcs={k['pc'][0] for k in ledger if k['kind']==1 and k['src']==0}
   valid=[s[0] for s in samples if s[0]['frame_pc'] in pcs]
   assert valid and all(v['spsr']&0x9f==0 for v in valid)
   assert len(set(v['ramp_counter'] for v in valid if v['ramp_counter']))>=2
   supp[name]=dict(samples=len(valid),first=valid[0],last=valid[-1],etries=a.get('external_entries'))
  if c=='wake':
   prod=a['products'][0];j=0
   for (k,slot,w,pc),(jrow,slot2,t) in zip(a['sleep'],a['wake']):
    assert slot==slot2==0 and t>=w
    nxt=next(v for v in ledger[k+1:] if v['target']==0)
    assert nxt['pc'][1]==pc and nxt['row']>=jrow
    assert any(v['src'] in (1,2) and v['physical_service']>0 for v in ledger[k+1:jrow+1])
    mem=(d/'ram.bin').read_bytes(); domain=[struct.unpack_from('<Q',mem,int(l.split()[0],16)-0x40200000)[0] for l in (d/'symbols').read_text().splitlines() if '12CLOCK_DOMAIN' in l]; epoch=next(v for v in domain if v!=62500000); assert w==epoch+(prod['deadline'][j]+15)//16; assert prod['deadline'][j]==(ledger[k-1]['entry']-epoch)*16+40000000
    j+=1
   assert j==3
  if c=='child-leaf':assert any(x[1]==0 for x in a['child']) and any(x[1]==1 and x[0]>a['child'][0][0] for x in a['leaf'])
  if c=='saturated':assert len(set(v[1] for v in a['parent']))>=3 and sum(x[1]>0 for x in a['grants'])>=2 and len(a['idle'])>=3
  if c=='swap':assert a['parent']
(h/'single-frame-proof.json').write_text(json.dumps(supp,indent=2))
