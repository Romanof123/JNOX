pkg() { python3 tools/build_native_el0.py --out "$out/$1" --policy hierarchy --hierarchy "examples/native-hierarchy/$2.json" --elf "$out/$3.elf" --peer-elf "$out/$4.elf" --peer-elf "$out/$5.elf"; }
pkg saturated baseline crc histogram energy
pkg swap baseline energy histogram crc
pkg child-leaf child-leaf crc histogram energy
pkg wake baseline reporter histogram energy
echo '{"period_ticks":15625000,"parents":[15625000],"children":[[0,15625000]],"leaves":[[0,3906250]]}' > "$out/single.json"
python3 tools/build_native_el0.py --out "$out/single" --policy hierarchy --hierarchy "$out/single.json" --elf "$out/crc.elf"
python3 tools/build_native_el0.py --out "$out/default" --elf "$out/crc.elf"
