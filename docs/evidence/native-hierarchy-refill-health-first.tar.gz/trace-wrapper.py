#!/usr/bin/env python3
from pathlib import Path
import sys,runpy
t=Path(__file__).parent/'src/tools'
sys.path.insert(0,str(t));runpy.run_path(str(t/'group_capture.py'),run_name='__main__')
