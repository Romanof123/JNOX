set -eu
cd ~/iv340-a1a6-first/src
export PATH="$HOME/.cargo/bin:$PATH" RUSTUP_TOOLCHAIN=1.95.0
e=$HOME/iv340-a1a6-first/controls
mkdir "$e"
chmod +x ../plain-wrapper.py
for flavor in plain traced; do
 for app in ordinary-groups ordinary-groups-recurring; do
  d=$e/$flavor-$app;mkdir "$d";unset JNOX_GROUP_TRACE
  wrap=$HOME/iv340-a1a6-first/plain-wrapper.py
  if [ "$flavor" = traced ]; then export JNOX_GROUP_TRACE=1;wrap=../trace-wrapper.py;chmod +x "$wrap";fi
  (cd kernel && JNOX_PROFILE=groups JNOX_APP=$app cargo build --locked --release -j1 --target-dir "$HOME/iv340-a1a6-first/control-target") >"$d/build" 2>&1
  cp ../control-target/aarch64-unknown-none/release/jnox-kernel "$d/kernel.elf"
  GROUP_CAPTURE_DIR="$d/raw" python3 tools/qemu_boot.py --profile "$app" --runs 1 --kernel "$d/kernel.elf" --qemu "$wrap" >"$d/boot" 2>&1 && status=0 || status=$?
  echo "$status" > "$d/status"
  aarch64-linux-gnu-nm -Sn "$d/kernel.elf" > "$d/symbols"
 done
done
cp ../precedent/record/verify.py "$e/verify.py"
sed -i "/traced=(raw\/'audit.bin').exists()/a\ if not traced:continue" "$e/verify.py"
python3 "$e/verify.py" > "$e/legacy-ledger.log"
for f in ordinary-groups ordinary-groups-recurring; do
 set --; case "$f" in *recurring) set -- --recurring;; esac
 python3 tools/group_replay.py "$@" --audit "$e/traced-$f/raw/audit.bin" >> "$e/replay"
done
python3 tools/group_replay.py --fixture >> "$e/replay"
rustc --edition=2024 --test tools/hierarchy_tests.rs -o ../upstream-tests && ../upstream-tests > "$e/host.log"
cp ../precedent/record/model.rs "$e/model.rs"
rustc --edition=2024 "$e/model.rs" -o ../independent-model && ../independent-model >> "$e/host.log"
