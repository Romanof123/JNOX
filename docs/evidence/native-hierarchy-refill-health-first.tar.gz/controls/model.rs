#[path="../src/kernel/src/hierarchy_policy.rs"] mod policy;
use policy::Hierarchy;
const PATH:[[usize;3];3]=[[0,2,5],[0,3,6],[1,4,7]];
fn step(b:&mut [i64;8], caps:[i64;8], owner:Option<usize>, end:u64,p:u64){
 if let Some(w)=owner {for n in PATH[w] {b[n]-=1;}}
 if end%p==0 {for n in 0..8 {b[n]=(b[n]+caps[n]).min(caps[n]);}}
}
fn first(b:[i64;8],mask:usize)->Option<usize>{(0..3).find(|&w| mask&(1<<w)!=0 && PATH[w].iter().all(|&n| b[n]>0))}
fn main(){
 let mut checks=0;
 for p in 3..=10 {let caps=[1,(p-1) as i64,2,1,2,1,2,1];let mut b=caps;
 let mut h=Hierarchy::new(0,p,[1,p-1],[(0,2),(0,1),(1,2)],[(0,1),(1,2),(2,1)]).unwrap();
 let mut t=0;
 for i in 0..100 {for mask in 0..8 {let ready=std::array::from_fn(|w| mask&(1<<w)!=0);
 let mut sim=b; let mut future=t; let expect=if mask==0 {None} else {while first(sim,mask).is_none(){future+=1;step(&mut sim,caps,None,future,p);}Some(future)};
 assert_eq!(h.next_actionable(t,&ready),expect); checks+=1;}
 let mask=1+(i*17%7);let ready=std::array::from_fn(|w| mask&(1<<w)!=0);let owner=first(b,mask);
 let g=h.grant_at(t,p,&ready);assert_eq!(g.map(|v|v.2),owner);
 if let Some(w)=owner {assert_eq!(h.next_actionable(t,&ready),None);let duration=1+(i*11%13) as u64;
 for _ in 0..duration {t+=1;step(&mut b,caps,Some(w),t,p);}
 let debt=PATH[w].map(|n|(-b[n]).max(0) as u64);assert_eq!(h.finish_at(t).unwrap().2,debt);assert_eq!(h.next_actionable(t-1,&ready),None);
 }else{t+=1;step(&mut b,caps,None,t,p);}}}
 let m=u64::MAX;
 for dist in 1..=16 {for p in 1..=8 {for quota in 1..=p {let s=m-dist;
 let mut h=Hierarchy::new(s,p,[quota],[(0,p)],[(0,p)]).unwrap();let g=h.grant_at(s,p,&[true]).unwrap().3;
 h.finish_at(s+g).unwrap();for q in g..=dist {let answer=(q..dist).find(|&offset|offset/p>0 || g<quota).map(|v|s+v);
 assert_eq!(h.next_actionable(s+q,&[true]),answer);checks+=1;}}}}
 println!("independent mask and horizon queries passed: {checks}");}

