from pathlib import Path
import subprocess as sp,json,re,time,sys,struct,traceback
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here/'src/tools'))
from qemu_capture import request
from ordinary_amc_capture import FLAGS,sha
R=here/'raw'; R.mkdir(exist_ok=True)
def boot(case,mode,n,original=False):
 d=R/(('original-' if original else '')+case+'-'+mode);d.mkdir()
 k=(here/'original' if original else here)/'packages'/case/'kernel.elf'; sy=sp.check_output(['nm','-Sn',k],text=True);(d/'symbols').write_text(sy)
 def sym(s):
  return int(next(l.split()[0] for l in sy.splitlines() if s in l),16)
 base=sym(' _start'); end=sym(' __stack_top'); spaces=sym('6SPACES'); frames=sym('6FRAMES');stride=0x415000
 argv=['/usr/bin/qemu-system-aarch64',*FLAGS,'-qmp','stdio','-serial','file:'+str(d/'uart'),'-kernel',str(k)]
 if mode=='passive':argv+=['-trace','events='+str(here/'providers'),'-d','int','-D',str(d/'exceptions')]
 if mode=='trace':argv+=['-d','int','-D',str(d/'exceptions')]
 (d/'launch.json').write_text(json.dumps(dict(argv=argv,kernel=sha(k),qemu=sha(Path(argv[0])))))
 p=sp.Popen(argv,stdin=sp.PIPE,stdout=sp.PIPE,stderr=(d/'stderr').open('wb'),bufsize=0)
 class Pipe:write=p.stdin.write;readline=p.stdout.readline
 try:
  assert 'QMP' in json.loads(p.stdout.readline());request(Pipe,'qmp_capabilities')
  start=time.monotonic(); seq=0
  while True:
   u=(d/'uart').read_bytes();done=(b'NATIVE EL0 EXIT ' in u if n==1 else len(re.findall(rb'NATIVE EL0 EXIT PID \d+ -?\d+\r?\n',u))==n)
   if done and not original and case!='default':done=b'NATIVE HIERARCHY HEALTH END 1\n' in u.replace(b'\r',b'')
   if done or time.monotonic()-start>105 or b'NATIVE EL0 FAULT' in u:break
   # Record without stop, timestamps delimit each sampling round.
   with (d/'samples').open('ab') as f:
    f.write(struct.pack('<d',time.monotonic()-start))
    for addr,size in [(spaces+i*stride+0x7000,128) for i in range(n)]+[(frames,832*n)]:
     request(Pipe,'pmemsave',val=addr,size=size,filename=str(d/'scratch'))
     f.write((d/'scratch').read_bytes())
   seq+=1;time.sleep(.09)
  request(Pipe,'stop');(d/'regs').write_text(request(Pipe,'human-monitor-command',**{'command-line':'info registers'}))
  request(Pipe,'pmemsave',val=base,size=end-base,filename=str(d/'ram.bin'))
  (d/'outcome').write_text(str((done,seq,time.monotonic()-start)))
 finally:p.terminate();p.wait()
 print(case,mode,(d/'outcome').read_text(),flush=True)

for c in ('saturated','swap'):
 boot(c,'plain',3,True)
 boot(c,'plain',3)
for c,m,n in [('saturated','trace',3),('swap','trace',3),('child-leaf','plain',3),('child-leaf','trace',3),('wake','plain',3),('wake','trace',3),('single','plain',1),('single','trace',1),('default','plain',1),('saturated','passive',3),('swap','passive',3)]:
 boot(c,m,n)
