from pathlib import Path
import struct,re,json,hashlib
root=Path(__file__).parent
path=[[0,2,5],[0,3,6],[1,4,7],[]]
for d in sorted(root.glob('*/')):
 if not (d/'boot').exists():continue
 recurring='recurring' in d.name
 raw=d/'raw'
 traced=(raw/'audit.bin').exists()
 trace=(raw/('int.trace' if traced else 'run-1/exceptions.log')).read_text()
 uart=(raw/('uart.bin' if traced else 'run-1/uart')).read_text().splitlines()
 total=0;acks=[]
 if recurring:
  for r in range(1,4):
   v=sum(i+r for i in range(1,257));total+=v;acks+=[f'GROUP ACK {r} {v:016x} {total:016x}']
 assert uart==['JNOX M1 BOOT','JNOX M1 READY']+(['GROUP RECURRING'] if recurring else [])+['GROUP BLOCK','GROUP WAKE']+acks+['GROUP PEER','GROUP RESUME','GROUP RETURN']
 syms=(d/'symbols').read_text()
 def addr(name):return int(re.search(r'^([0-9a-f]+) \w+ \w .*'+name,syms,re.M)[1],16)
 stack=addr('group_runtime6STACKS');enter=addr('fixed_runtime_enter');idle=addr('fixed_runtime_idle')
 flow=[(0,3,0),(2,0,1),(3,1,0)]+([(1,0,2),(1,2,3),(1,3,0)]*2 if recurring else [])+[(1,0,2),(4,2,3),(1,3,0),(4,0,1),(4,1,3)]
 returns=[int(x,16) for x in re.findall(r'Exception return .* PC 0x([0-9a-f]+)',trace)]
 entries=trace.split('Taking exception ')[1:]
 assert len(returns)==len(flow)==len(entries)+1
 pcs=[enter]*3+[idle];frames={};ledger=[]; mask=7
 if traced:
  header,*rows=struct.iter_unpack('<15Q',(raw/'audit.bin').read_bytes())
  count,p=header[:2];assert count==len(flow)
  origin=last=rows[0][0];caps=[p//4,p//2]+[p]*6;bal=caps[:];due=0
  assert idle<=int(re.search(r'PC=([0-9a-f]+)',(raw/'registers.txt').read_text())[1],16)<idle+8
 for k,(event,old,new) in enumerate(flow):
  if k:
   entry=entries[k-1]
   assert ('[IRQ]' if event==1 else '[SVC]') in entry
   if event!=1:assert int(re.search(r'ESR \w+/0x([a-f0-9]+)',entry)[1],16)&65535=={2:2,3:3,4:1}[event]
   pcs[old]=int(re.search(r'with ELR 0x([a-f0-9]+)',entry)[1],16)
  assert returns[k]==pcs[new]
  if not traced:continue
  t,src,prev,charge,arg,nxt,comp,ready,rest,save,prevcomp,over,*debts=rows[k]
  if event==2:mask&=~1
  if event==3:mask|=1
  if event==4:mask&=~(1<<old)
  assert (src,prev,nxt,ready,arg)==(event,old,new,mask,0)
  assert 0<=t-last<=8*p and prevcomp==due and charge==(t-last if old!=3 else 0)
  assert over==(max(0,t-due) if old!=3 else 0)
  if event==1:assert 0<=t-due<=p//8
  delta=[charge if n in path[old] else 0 for n in range(8)]
  for n in range(8):
   cursor=last
   while cursor<t:
    boundary=origin+((cursor-origin)//p+1)*p
    stop=min(t,boundary)
    if n in path[old]:bal[n]-=stop-cursor
    if stop==boundary:bal[n]=min(caps[n],bal[n]+caps[n])
    cursor=stop
  assert debts==([max(0,-bal[n]) for n in path[old]] if old<3 else [0]*3)
  def elig(b):return [w for w in range(3) if mask>>w&1 and min(b[n] for n in path[w])>0]
  elig_now=elig(bal)
  assert new==(elig_now or [3])[0]
  boundary=origin+((t-origin)//p+1)*p
  if new<3:expected=min(boundary,t+min(bal[n] for n in path[new]))
  elif mask:
   shadow=bal[:];expected=boundary
   while True:
    shadow=[min(q,x+q) for q,x in zip(caps,shadow)]
    if elig(shadow):break
    expected+=p
  else:expected=0
  assert comp==expected
  if k:assert (save-stack)//16384==old and save%16==0;frames[old]=save
  assert (rest-stack)//16384==new and rest%16==0 and frames.get(new,rest)==rest
  ledger.append(dict(k=k,source=src,old=old,new=new,window=(t-origin)//p,mask=mask,elapsed=t-last,charge=delta,balances=bal[:],debt=debts,irq_lag=t-due if event==1 else None,compare=comp,restore_pc=hex(returns[k]),saved=hex(save),restored=hex(rest)))
  last=t;due=comp
 if traced:
  stops=[r for r in ledger if r['source']==1 and r['old']==0]
  assert all(r['balances'][0]<=0 and r['balances'][3]>0 for r in stops)
  if recurring:
   assert len({r['window'] for r in stops})==3 and sum(r['debt'][0]>0 for r in stops)>=2
   assert sum(r['old']==2 and r['source']==1 and r['balances'][1]<=0 for r in ledger)==2
  (d/'ledger.json').write_text(json.dumps(ledger,indent=2))
  print(d.name,p,[(r['window'],r['debt'][0]) for r in stops],max(r['irq_lag'] or 0 for r in ledger),[r['elapsed'] for r in ledger if r['old']==3 and r['k']])
 print(d.name,len(returns),'returns;',len(acks),'ACKs')

