from pathlib import Path
p=Path('original/audit.py').read_text().replace("case,mode=d.name.rsplit('-',1); p=package/case","name=d.name.removeprefix('original-'); case,mode=name.rsplit('-',1); package=root/('original/packages' if d.name.startswith('original-') else 'packages'); p=package/case").replace("m['commit']=='b276a2ed8e9715fc6ced057b84681d77ccead755'","m['commit']==('b276a2ed8e9715fc6ced057b84681d77ccead755' if d.name.startswith('original-') else 'a1a6a2f7440342125e257825775d4f2caacf0cd6')").replace("if mode=='trace':","if mode in ('trace','passive'):")
Path('audit.py').write_text(p)
s=Path('original/summarize.py').read_text().split("r+=['','Full per-row")[0]
s+="(h/'single-frame-proof.json').write_text(json.dumps(supp,indent=2))\n"
Path('samples.py').write_text(s)
p=Path('original/controls.sh').read_text().replace('iv333prep','iv340-a1a6-first')
Path('controls.sh').write_text(p)
