from pathlib import Path
import re,json,struct,subprocess as sp,sys
sys.path.insert(0,'src/tools')
from read_hierarchy_health import TIMER
results={}
for d in sorted(Path('raw').glob('*')):
 if not (d/'outcome').exists():continue
 u=(d/'uart').read_text(); rows=[list(map(int,l.split()[3:])) for l in u.splitlines() if l.startswith('NATIVE HIERARCHY EVENT ')]
 if not rows:continue
 timers=[dict(zip(TIMER,map(int,l.split()[3:]))) for l in u.splitlines() if l.startswith('NATIVE HIERARCHY TIMER ')]
 signals=[]; misses=[];readbacks=[];scope={}
 for i,e in enumerate(rows):
  if e[1]!=1:continue
  lag=e[3]-e[13]
  if not 0<=lag<=1953125:misses.append(dict(row=i,source=e[8],D=e[13],E=e[3],lag=lag,pc=hex(e[19]),charge=e[17]))
  if not timers:continue
  a,t=timers[i-1],timers[i]
  assert t['old_arm_seq']==a['arm_seq']==i and t['elr']==e[19] and (t['spsr']&15)==(5 if e[8]==3 else 0) and t['iar']&1023==30
  assert a['post_cval']==e[13]==t['entry_cval'] and a['post_ctl']&3==t['entry_ctl']&3==1
  assert a['arm_before']<=a['arm_after']<=e[3]==t['earliest_irq']<=t['entry_counter']
  if e[8]==3:
   assert rows[i-1][46]==t['idle_landing']<=t['last_before_unmask']<=t['earliest_irq'] and t['daif_before_unmask']&128 and not t['spsr']&128
   readbacks.append(dict(row=i,arm=a,entry=t))
  if t['outcome'] in [2,3,4]:signals.append(dict(row=i,arm=a,entry=t))
 if timers:
  name=d.name.rsplit('-',1)[0]; ex={'saturated':[237,70,179],'swap':[179,70,237],'child-leaf':[237,70,179],'wake':[7,70,179],'single':[237]}[name]
  argv=[sys.executable,'src/tools/read_hierarchy_health.py',d/'uart']
  for v in ex:argv+=['--expect-exit',str(v)]
  p=sp.run(argv,capture_output=True);(d/'reader.json').write_bytes(p.stdout or p.stderr);scope=json.loads(p.stdout);scope['reader_exit']=p.returncode
  (d/'idle-readbacks.json').write_text(json.dumps(readbacks))
 results[d.name]=dict(original_gates=misses,health=scope,violations=signals)
Path('health-audit.json').write_text(json.dumps(results,indent=2))
print([(k,v['original_gates']) for k,v in results.items()])
