from pathlib import Path
import sys,re,subprocess as sp,json
src=Path('src/tools')
sys.path.insert(0,str(src))
import read_hierarchy_health as r
loc=Path('host-controls')
def emit(line,tag,vals):
 return ('NATIVE HIERARCHY '+tag+' '+' '.join(map(str,vals))+'\n').encode()
base=Path('raw/saturated-plain/uart').read_bytes().replace(b'\r',b'').splitlines(keepends=True)
def rows(tag):
 return [list(map(int,l.split()[3:])) for l in base if l.startswith(('NATIVE HIERARCHY '+tag+' ').encode())]
events=rows('EVENT'); timers=rows('TIMER')
hs=list(map(int,next(l for l in base if l.startswith(b'NATIVE HIERARCHY HEALTH 1 ')).split()[3:]))
i=next(t[0] for t in timers if t[-1]==1)
e,a=timers[i],timers[i-1]
def case(name,lines,expect):
 path=loc/(name+'.uart');path.write_bytes(b''.join(lines));p=sp.run([sys.executable,src/'read_hierarchy_health.py',path,'--expect-exit','237','--expect-exit','70','--expect-exit','179'],capture_output=True)
 (loc/(name+'.json')).write_bytes(p.stdout or p.stderr)
 return dict(name=name,want=expect,actual=p.returncode,pass_control=p.returncode==expect)
def fixture(lag,drop=False,overflow=False,break_seq=False):
 ev=[v[:] for v in events[:i+1]]; ts=[v[:] for v in timers[:i+1]]
 d=a[3];t=ts[i]; t[11]=ev[i][3]=d+lag;t[14]=d+lag+10
 outcome=3 if lag<0 else 2 if lag>1953125 else 1;t[-1]=outcome
 pre=[v for v in ts if v[-1] in (1,2)];h=hs[:];h[3:]=[i+1,sum(v[1]==1 for v in ev),len(pre),int(outcome==3),0,int(outcome==2),max(0,lag),int(overflow),i+1,i if drop else i+1,int(drop)]
 if overflow:h[3]=2**64-1
 first=[0] if outcome==1 else [1,i,h[4],outcome,*ts[i-1][1:10],*t[11:21],int(outcome==2),max(0,lag)]
 if break_seq:first[4]=1
 tail=[l for l in base if l.startswith(b'NATIVE EL0 EXIT ')]
 out=[next(l for l in base if l.startswith(b'NATIVE HIERARCHY CONFIG '))]
 for row,trow in zip(ev[:h[-2]],ts[:h[-2]]):out.extend([emit(None,'EVENT',row),emit(None,'TIMER',trow)])
 return out+[emit(None,'DROPPED',[h[-1]]),emit(None,'HEALTH',h),emit(None,'FIRST',first),*tail,b'NATIVE HIERARCHY HEALTH END 1\n']
cases=[case('exact_zero',fixture(0),0),case('equality',fixture(1953125),0),case('one_over',fixture(1953126),1),case('early',fixture(-1),1),case('overflow',fixture(0,overflow=True),1),case('lost_first',fixture(4201556,drop=True),1),case('lost_wrong_arm',fixture(4201556,drop=True,break_seq=True),2),case('truncated',base[:-1],2),case('false_terminal',[Path('host-controls/false-terminal-artificial-uart').read_bytes()],2)]
Path('reader-cases.json').write_text(json.dumps(cases,indent=2));print(cases)
