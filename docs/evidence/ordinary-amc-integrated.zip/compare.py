import hashlib,json,io,zipfile
from pathlib import Path
from elftools.elf.elffile import ELFFile
H=lambda b:hashlib.sha256(b).hexdigest()
def check(a,b):
 def ld(raw):
  e=ELFFile(io.BytesIO(raw))
  return e.header.e_entry,[(s.header.p_vaddr,s.header.p_paddr,s.header.p_flags,s.header.p_filesz,s.header.p_memsz,s.header.p_align,s.data()) for s in e.iter_segments() if s.header.p_type=='PT_LOAD']
 ea,la=ld(a); eb,lb=ld(b)
 return {'current_sha256':H(a),'reference_sha256':H(b),'whole_equal':a==b,'entry':hex(ea),'entry_equal':ea==eb,'load_equal':la==lb,'changed_load_bytes':sum(sum(x!=y for x,y in zip(i[-1],j[-1]))+abs(len(i[-1])-len(j[-1])) for i,j in zip(la,lb)),'section_changes':sections(a,b)}
def sections(a,b):
 ea=ELFFile(io.BytesIO(a));eb=ELFFile(io.BytesIO(b));res={}
 for sec in ea.iter_sections():
  if not sec.header.sh_flags&2 or sec.header.sh_type=='SHT_NOBITS':continue
  old=eb.get_section_by_name(sec.name)
  if old is not None and sec.data()!=old.data():res[sec.name]=sum(x!=y for x,y in zip(sec.data(),old.data()))+abs(sec.data_size-old.data_size)
 return res
res={}
for c in ('exact-lo','exact-hi','over-hi','pi','ceiling','legacy','wake'):
 if c.startswith('exact') or c=='over-hi':b=Path('finite',c,'kernel.elf').read_bytes()
 elif c=='wake':b=zipfile.ZipFile('src/docs/evidence/pi4-smp-first.zip').read('kernel.elf')
 else:b=Path('prior157-'+c+'.elf').read_bytes()
 res[c]=check(Path('src-'+c+'.elf').read_bytes(),b)
print(json.dumps(res,indent=2))
