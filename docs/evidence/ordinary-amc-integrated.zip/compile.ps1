param($root)
$ErrorActionPreference='Stop'
$entries=@(
@('src','exact-lo','virt','amc','exact-lo','','',0),@('src','exact-hi','virt','amc','exact-hi','','',0),@('src','over-hi','virt','amc','over-hi','','',0),
@('src','pi','virt','mutex','ordinary-pi','','',0),@('src','ceiling','virt','mutex','ordinary-ceiling','','',0),@('src','wake','pi4','smp','directed-wake','','',0),@('src','legacy','virt','','','amc-bench','',0),
@('prior157','pi','virt','mutex','ordinary-pi','','',0),@('prior157','ceiling','virt','mutex','ordinary-ceiling','','',0),@('prior157','legacy','virt','','','amc-bench','',0),
@('src','invalid-pi4','pi4','amc','exact-hi','','',101),@('src','invalid-mutex','virt','mutex','exact-hi','','',101),@('src','invalid-amc-mutex','virt','amc','ordinary-pi','','',101),@('src','invalid-feature','virt','amc','exact-hi','amc-bench','',101),@('src','invalid-anchor','virt','amc','exact-hi','','selected-return',101),@('src','invalid-smp','virt','smp','exact-lo','','',101))
foreach($entry in $entries){
 $rev,$label,$board,$profile,$app,$feature,$anchor,$expected=$entry
 cd "$root/$rev/kernel"; $env:JNOX_BOARD=$board;$env:JNOX_PROFILE=$profile;$env:JNOX_APP=$app;$env:JNOX_MUTEX_ANCHOR=$anchor
 foreach($k in 'JNOX_PROFILE','JNOX_APP','JNOX_MUTEX_ANCHOR'){if(-not [Environment]::GetEnvironmentVariable($k)){Remove-Item "Env:$k" -ErrorAction SilentlyContinue}}
 $env:CARGO_TARGET_DIR="$root/target-$rev-$label"
 $opts=@('build','--release','--locked','-j1');if($feature){$opts+=@('--features',$feature)}
 cargo +1.95.0 @opts *> "$root/$rev-$label.build.log"
 $rc=$LASTEXITCODE;"$rev $label exit=$rc"|Tee-Object -Append "$root/build-status.txt"
 if($rc -ne $expected){throw "$label rc=$rc"}
 if($rc -eq 0){Copy-Item "$env:CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" "$root/$rev-$label.elf"}
}

