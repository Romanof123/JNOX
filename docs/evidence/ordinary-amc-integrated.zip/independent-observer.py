from pathlib import Path
import re,json
out={}
for case in ['exact-lo','exact-hi','over-hi']:
 p=Path('integrated',case,'first')
 lines=(p/'uart.bin').read_text().splitlines()
 def rows(tag):return [[int(x) for x in line.split()[2:]] for line in lines if line.startswith('AMR '+tag+' ')]
 owners=[r[1] for r in rows('GRANT')]
 assert owners==([0,1,0] if case=='exact-lo' else [0,1,1,1,3,0])
 result={'owners':owners}
 if case!='exact-lo':
  c,=rows('COMPLETE'); f,=rows('FROZEN')
  b6=rows('GRANT')[-1][9]
  irq=rows('IRQ')[-1]; retire=rows('RETIRE')[-1]
  trace=(p/'exceptions.log').read_text().split('Taking exception 2 [SVC]')
  assert len(trace)==2
  pcs=[int(n,16) for n in re.findall(r'(?:with ELR|to AArch64 EL1 PC) (0x[0-9a-f]+)',trace[1])]
  assert pcs==[c[8],c[11],irq[8]] and 'Taking exception 5 [IRQ]' in trace[1]
  assert c[:5]==[5,0,2,8,36] and f==[5,0,2,8,36,c[5],irq[6]]
  assert c[5]<=c[6]<b6<=irq[6]<=retire[6]
  assert retire[:6]==[6,0,2,1,0,8] and len(rows('GRANT'))==len(rows('RETIRE'))==6
  result.update(pcs=[hex(x) for x in pcs], task=c[5], svc=c[6], b6=b6, irq=irq[6], retirement=retire[6])
 out[case]=result
print(json.dumps(out,indent=2))
