set -eu
r=/mnt/d/codex/.jnox-work/next-fixed/amc-165-independent
d=$(mktemp -d /tmp/independent-amc165-XXXXXX)
cd "$d"
export PYTHONDONTWRITEBYTECODE=1
for c in exact-lo exact-hi over-hi; do
 h=$(python3 "$r/src/tools/ordinary_amc_capture.py" freeze "$c" "$c" "$r/src-$c.elf" /usr/bin/qemu-system-aarch64 6a336318e265785b5c0d8df3b5a8649632520919)
 echo "$h" > "$c.freeze"
done
for c in exact-lo exact-hi over-hi; do
 python3 "$r/src/tools/ordinary_amc_capture.py" run "$c" "$(cat "$c.freeze")" > "$c.session" || true
 aarch64-linux-gnu-objdump -d "$c/kernel.elf" > "$c.dis"
 tail -2 "$c/first/uart.bin"
done
cp -r "$d" "$r/integrated"