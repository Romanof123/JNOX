import requests,json,sys,concurrent.futures
from pathlib import Path
d=Path(__file__).parent
base='https://api.github.com/repos/Romanof123/JNOX/'
def get(path):
    out=[];url=base+path+'?per_page=100'
    while url:
        r=requests.get(url,timeout=30);r.raise_for_status();out+=r.json();url=r.links.get('next',{}).get('url')
    return out
comments=get('issues/comments')
def timeline(n):
    return [dict(pr=n,source_id=e.get('source',{}).get('issue',{}).get('number'),event=e.get('event'),created_at=e.get('created_at'),url=e.get('url') or e.get('source',{}).get('issue',{}).get('html_url')) for e in get(f'issues/{n}/timeline') if e.get('event') in ['cross-referenced','connected','merged']]
if __name__=='__main__':
    nums=[73,92,98,128,147,155,168]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex: rows=sum(ex.map(timeline,nums),[])
    print(rows)
    (d/'timeline.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
    (d/'comments-local.json').write_text(json.dumps(comments,ensure_ascii=False),encoding='utf8')
