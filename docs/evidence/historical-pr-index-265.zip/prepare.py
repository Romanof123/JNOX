"""Prepare the compact public inputs, using snapshot REST pages, public comments and a Git clone."""
from pathlib import Path
import sys, json, re, hashlib, subprocess
d=Path(__file__).resolve().parent
snap,repo=map(Path,sys.argv[1:3])
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def git(*args):
    result=subprocess.run(['git','-C',str(repo),*args],capture_output=True,encoding='utf8',errors='replace')
    return result.stdout.strip() if result.returncode==0 else None
def refs(body):
    # Exclude fragments, external URLs, code, link captions for external targets.
    body=re.sub(r'\[([^\]]+)\]\((https?://[^ )]+)\)',lambda m:' '+m[2]+' ',body)
    urls=re.findall(r'https?://[^\s<>()[\]]+',body)
    ids={int(n) for url in urls for n in re.findall(r'^https?://(?:api\.)?github\.com/(?:repos/)?Romanof123/JNOX/(?:pulls?|issues)/(\d+)\b',url,re.I)}
    prose=re.sub(r'https?://[^\s<>()[\]]+|[\w.-]+/[\w.-]+#\d+',' ',body)
    ids.update(int(x) for x in re.findall(r'(?<![\w#])#(\d+)(?![0-9A-Za-z_])',prose))
    return sorted(n for n in ids if 1<=n<=265)
files=sorted(snap.glob('issues-*.json'))+sorted(snap.glob('pulls-*.json'))
source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
def pages(prefix): return [x for f in files if f.name.startswith(prefix) for x in read(f) if x['number']<=265]
issues={x['number']:x for x in pages('issues') if 'pull_request' not in x}
pulls={x['number']:x for x in pages('pulls')}
assert set(issues)|set(pulls)==set(range(1,266)) and len(pulls)==160 and len(issues)==105
items={}
for n,x in sorted({**issues,**pulls}.items()):
    r={k:x[k] for k in ('number','title','html_url','state','created_at','updated_at','closed_at')}
    r['type']='pr' if n in pulls else 'issue'
    r['refs']=refs(x['body'] or '')
    r['labels']=[v['name'] for v in x['labels']]
    if n in pulls:
        r.update(head=x['head']['sha'],base_tip=x['base']['sha'],merged_at=x['merged_at'],github_merge_field=x['merge_commit_sha'])
        merge=x['merge_commit_sha'] if x['merged_at'] else None
        if merge:
            names=git('diff','--name-only',merge+'^1',merge)
        else:
            names=git('diff','--name-only',r['base_tip']+'...'+r['head'])
        if names is None: r['file_scope']='unavailable'
        elif not names: r['file_scope']='empty delta'
        else:
            files_changed=names.splitlines()
            r['file_scope']='Markdown only' if all(f.lower().endswith('.md') for f in files_changed) else 'includes non-Markdown'
            r['path_count']=len(files_changed)
    items[n]=r
comments=[dict(item=int(x['issue_url'].split('/')[-1]),url=x['html_url'],created=x['created_at'],updated=x['updated_at'],refs=refs(x['body'])) for x in read(d/'comments-local.json') if int(x['issue_url'].split('/')[-1])<=265 and x['updated_at']<=max(v['updated_at'] for v in items.values())]
payload=dict(baseline='eb3d00e4d70738ba37099275575a94bceb03b04b',raw_page_sha256=source,items=list(items.values()),comments=comments)
(d/'input.json').write_text(json.dumps(payload,ensure_ascii=False,indent=1)+'\n',encoding='utf8')


