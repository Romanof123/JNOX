"""Replay: python replay.py (Python 3.9+, no network)."""
from pathlib import Path
import json,csv,collections
D=Path(__file__).resolve().parent
j=json.loads((D/'input.json').read_text('utf8')); ps={x['number']:x for x in j['items'] if x['type']=='pr'}; iss={x['number']:x for x in j['items'] if x['type']=='issue'}
A={}
for line in (D/'attribution.txt').read_text('utf-8-sig').splitlines():
    if line.strip() and not line.startswith('#'):
        n,*targets=map(int,line.split());A[n]=targets
assert set(A)==set(ps) and all(i in iss for v in A.values() for i in v)
root='https://github.com/Romanof123/JNOX'
board=root+'/blob/2c5bf56ce5105561c7f5743f962f4cca94c12372/docs/evidence/pm-tracking-20261124T203216Z.en-ko.md'
notes={73:'Default repository language and README links.',92:'Bilingual README evidence pointers.',98:'Bilingual README project introduction.',155:'CHG-074 / REQ-008. Later #21 comment identifies the integration; it does not identify an originating issue.',168:'Safety concept comparison documentation.',128:'PR body names #115 and #119; each names its issue (#113 and #116 respectively).',147:'PR body names #144; #144 names #94.',170:'PR body names #159; #159 names #34.'}
via={128:{113:115,116:119},147:{94:144},170:{34:159}}
def fmt(nums):return ' '.join(map(str,sorted(nums)))
def csvout(name,rows):
    with (D/name).open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
E=[];P=[];I=[];classes=collections.Counter()
for n,p in ps.items():
    primary=p['state']=='open'; known=A[n]; links=[]
    for i,t in iss.items():
        f=i in p['refs']; b=n in t['refs']
        co=[c['url'] for c in j['comments'] if (c['item']==i and n in c['refs']) or (c['item']==n and i in c['refs'])]
        v=via.get(n,{}).get(i); evidence=[]
        if not (f or b or co or v or i in known):continue
        if f:evidence.append(p['html_url'])
        if b:evidence.append(t['html_url'])
        evidence+=co
        if v:
            assert v in p['refs'] and i in ps[v]['refs']
            evidence += [p['html_url'],ps[v]['html_url']]
        if i in known and primary and n not in (258,265):evidence.append(board)
        kind='reciprocal bodies' if f and b else 'PR body only' if f else 'issue body only' if b else 'linked PR chain' if v else 'comment' if co else 'unestablished'
        role=('verified open primary' if primary else 'retrospective shared scope' if len(known)>1 else 'retrospective work issue') if i in known else 'context / mention'
        E.append(dict(pr=n,issue=i,role=role,body_evidence=kind,pr_body=int(f),issue_body=int(b),via_pr=v or '',sources=' '.join(dict.fromkeys(evidence))))
        if i in known:links.append(kind)
    kind=' / '.join(dict.fromkeys(links)) or 'origin unestablished'
    classes[kind]+=1
    outcome='merged' if p['merged_at'] else p['state'] if primary else 'closed without merge'
    sources=(board if n not in (258,265) else p['html_url']) if primary else ''
    P.append(dict(pr=n,url=p['html_url'],title=p['title'],created=p['created_at'],last_updated=p['updated_at'],closed=p['closed_at'],merged=p['merged_at'],outcome=outcome,source_sha=p['head'],source_url=root+'/commit/'+p['head'],merge_sha=p['github_merge_field'] if p['merged_at'] else '',merge_url=root+'/commit/'+p['github_merge_field'] if p['merged_at'] else '',snapshot_base_tip=p['base_tip'],file_scope=p['file_scope'],path_count=p.get('path_count',''),attributed_work_issues=fmt(known),relationship_evidence=kind,open_primary_source=sources,pr_to_pr_refs=fmt(set(p['refs'])&ps.keys()-{n}),note=notes.get(n,'')))
for i,t in iss.items():
    es=[e for e in E if e['issue']==i]
    I.append(dict(issue=i,url=t['html_url'],original_question_or_work_title=t['title'],state=t['state'],created=t['created_at'],last_updated=t['updated_at'],closed=t['closed_at'],labels=' | '.join(t['labels']),attributed_prs=fmt(e['pr'] for e in es if e['role']!='context / mention'),all_related_prs=fmt(e['pr'] for e in es),other_issue_refs=fmt(set(t['refs'])&iss.keys()-{i})))
csvout('prs.csv',P);csvout('issues.csv',I);csvout('edges.csv',E)
assert len(P)==160 and len(I)==105 and collections.Counter(r['outcome'] for r in P)=={'merged':138,'closed without merge':2,'open':20}
print('PR evidence',classes,'edges',len(E),'attributed',sum(bool(x['attributed_work_issues']) for x in P),'Markdown only',sum(x['file_scope']=='Markdown only' for x in P))
print('open evidence',collections.Counter(x['relationship_evidence'] for x in P if x['outcome']=='open'))
