import collections,copy,hashlib,json,os,re,shlex,struct,subprocess,sys,tarfile
from pathlib import Path
here=Path(__file__).resolve().parent;src=here/'source';raw=here/'raw'
old=Path('/home/ywcho/jnox348-offline-f898843.i2bxhHpT')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def obj(p):return json.loads(p.read_bytes())
def save(n,x):(raw/n).write_text(json.dumps(x,indent=2)+'\n')
def archive_check(f,h):
    assert sha(f)==h
    blob=subprocess.check_output(['git','rev-parse','HEAD^:'+str(f.relative_to(src))],cwd=src).decode().strip()
    assert subprocess.check_output(['git','hash-object',str(f)],cwd=src).decode().strip()==blob
    with tarfile.open(f) as tf:
        for row in tf.extractfile('SHA256SUMS').read().decode().splitlines():
            expect,name=row.split('  ',1);assert hashlib.sha256(tf.extractfile(name).read()).hexdigest()==expect
    return blob
a1=src/'docs/evidence/native-amc-applications-first.tar.gz';a2=src/'docs/evidence/native-amc-overlap-first-replay.tar.gz'
blobs=[archive_check(a1,'28d9d30d1b7ed7d848118f90cdd5d59291c73fa9934ea1033c7887d52b35e561'),archive_check(a2,'97e286c596e67c0bfa5d025bc11cb5756b69fce5e531665e1e761b44badb0029')]
with tarfile.open(a1) as t:
    original=json.load(t.extractfile('session-index.json'));firstreport=hashlib.sha256(t.extractfile('REPORT.en-ko.md').read()).hexdigest()
with tarfile.open(a2) as t:
    formal=json.load(t.extractfile('controls/manifest.json'));genuine=json.load(t.extractfile('genuine.json'))
def cli(label,folder,expected):
    ses=folder/'session.json';assert sha(ses)==expected
    for n,h in obj(ses)['hashes'].items():assert sha(folder/n)==h
    cmd=[sys.executable,'tools/native_amc_report.py','report',str(folder),expected]
    run=subprocess.run(cmd,cwd=src,capture_output=True)
    (raw/(label+'.command')).write_text(shlex.join(cmd)+'\n');(raw/(label+'.exit')).write_text(str(run.returncode)+'\n')
    (raw/(label+'.stdout')).write_bytes(run.stdout);(raw/(label+'.stderr')).write_bytes(run.stderr)
    try:rep=json.loads(run.stdout);status=rep['status'];issues=rep['issues'];unknown=rep['unknown']
    except ValueError:status='error';issues=[run.stderr.decode().strip()];unknown=[]
    return dict(exit=run.returncode,status=status,issues=issues,unknown=unknown,session=expected)
def records(f):
    fields=collections.defaultdict(list)
    for l in (f/'uart.bin').read_text().splitlines():
        p=l.split()
        if p[:2]==['NATIVE','AMC']:fields[p[2]].append(tuple(map(int,p[3:])))
    ra,n,width,lost=fields['INTERVALS'][0];addr=ra-obj(f/'launch.json')['ram_base'];ram=(f/'ram.bin').read_bytes()
    return fields,list(struct.iter_unpack('<23Q',ram[addr:addr+n*width*8])),addr
def inspect(f):
    u,rr,_=records(f); _,E,hz,q,*_=u['CONFIG'][0];due=E+q
    indices=[i for i in range(1,len(rr)-1) if rr[i-1][17]==due and rr[i][17]>due]
    assert len(indices)==1
    i,=indices;prev,cur,nxt=rr[i-1:i+2]; at=next(e[1] for e in u['LIFE'] if e[0]==7)
    low=max(cur[2],due);high=nxt[2] if nxt[0]==3 else nxt[3]
    assert low<=at<=high and at==next(e[1] for e in u['LIFE'] if e[0]==2)
    assert cur[13]==nxt[4] and high<=nxt[2]
    return dict(due=due,index=i,prior_calendar=prev[17],selected_calendar=cur[17],exception=cur[:2],CVAL=cur[9],entry=cur[2],next_exception=nxt[:2],next_entry=nxt[2],next_return_start=nxt[3],bounds=(low,high),fault_refusal=at)
actual={};neg={};brackets={};new={};cross={}
for label,orig in original.items():
    f=old/'original/captures'/label;actual[label]=cli(label,f,orig['session_sha256'])
    actual[label]['first']=orig['status'];actual[label]['prior_replay']=genuine['results'][label]['corrected']
    if label.startswith('overlap-'):brackets[label]=inspect(f)
    if label in ('staggered-trace','normal-hi-trace'):
        u,rr,_=records(f); _,epoch,hz,q,count,*_=u['CONFIG'][0]; b=epoch+q*(5 if label.startswith('staggered') else 2)
        crossing=next(r for r in rr if r[4:6]==(1,0) and r[7]>=q);c=next(e[1] for e in u['LIFE'] if e[0]==9)
        irq=[r[2] for r in rr if r[:2]==(1,30) and r[4:6]==(1,0)]
        ext=[(1 if t==b'5' else 2,int(pc,16)) for t,pc in re.findall(rb'Taking exception (2|5) \[(?:SVC|IRQ)\]\r?\n\.\.\.from EL0 to EL1\r?\n(?:\.\.\.with ESR [^\n]+\n)?\.\.\.with ELR (0x[0-9a-fA-F]+)',(f/'exceptions.log').read_bytes())]
        assert ext==[(r[0],r[10]) for r in rr if r[0] in (1,2) and r[4]<count] and not irq and crossing[:2]==(2,6) and crossing[19]==2
        cross[label]=dict(b=b,SVC=crossing[2],used=crossing[7],CVAL=crossing[9],commit=c,HI1_PPI30=irq,matched_external_events=len(ext))
for record in formal:
    mode,name=record['case'].split('-',1);f=old/'checked-synthetic'/mode/name
    neg[record['case']]=cli('negative-'+record['case'],f,record['synthetic']);neg[record['case']]['previous']=record['status']
for mode in ('plain','trace'):
    f=old/'original/captures'/('overlap-'+mode)
    u,rr,addr=records(f); r0=brackets['overlap-'+mode];i=r0['index'];due=r0['due'];src_ram=(f/'ram.bin').read_bytes()
    for opt in ('missing','ambiguous'):
        dst=here/'ram-controls'/(mode+'-'+opt);dst.mkdir(parents=True)
        for p in f.iterdir():
            if p.name not in ('session.json','ram.bin'):(dst/p.name).hardlink_to(p)
        ram=bytearray(src_ram);edits=[]
        if opt=='missing':
            # Every occurrence of the b1 postdecision calendar is removed.
            edits=[(j,due+1) for j,v in enumerate(rr) if v[17]==due]
        else:
            # Add a second due-to-later transition in a subsequent unrelated decision.
            j=next(k for k in range(i+2,len(rr)-1) if rr[k][17]>due and rr[k+1][17]>due)
            edits=[(j,due)]
        for j,value in edits:struct.pack_into('<Q',ram,addr+(23*j+17)*8,value)
        (dst/'ram.bin').write_bytes(ram);ses=obj(f/'session.json');ses['hashes']['ram.bin']=sha(dst/'ram.bin');(dst/'session.json').write_text(json.dumps(ses,indent=2)+'\n')
        k=mode+'-'+opt;new[k]=cli('ram-'+k,dst,sha(dst/'session.json'));new[k]['edited_calendar_count']=len(edits);new[k]['original_session']=original['overlap-'+mode]['session_sha256']
print('results',collections.Counter(r['status'] for r in actual.values()),collections.Counter(r['status'] for r in neg.values()),collections.Counter(r['status'] for r in new.values()),flush=True)
print('brackets',brackets,'crossings',cross,flush=True)
save('verified.json',dict(reader='bba5355fbc9846a571c95514fdd89e27c59920d1',source_archives=[sha(a1),sha(a2)],archive_blobs=blobs,original_report=firstreport,authentic=actual,prior_falsifications=neg,additional_ram_controls=new,brackets=brackets,crossings=cross))
