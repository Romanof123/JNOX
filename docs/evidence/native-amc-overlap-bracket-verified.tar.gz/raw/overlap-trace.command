/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/original/captures/overlap-trace 1f9044384fbf08d8071a2b0586ad7e1851924e23f28ee91df302691e523466b3
