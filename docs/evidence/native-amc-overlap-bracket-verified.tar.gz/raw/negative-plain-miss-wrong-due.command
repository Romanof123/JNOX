/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/checked-synthetic/plain/miss-wrong-due 3e4fb63223e3defaa3c536d1040ea141bfb022b4a187d5968431bc826df1c2e1
