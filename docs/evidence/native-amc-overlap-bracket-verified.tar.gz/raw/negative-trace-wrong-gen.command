/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/checked-synthetic/trace/wrong-gen 9d4351cdea2684dfa62979a8cc78715d8d4b8fb50c5abe56a3c26a206499346e
