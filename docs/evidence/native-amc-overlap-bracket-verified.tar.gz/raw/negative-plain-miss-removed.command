/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/checked-synthetic/plain/miss-removed 4d63b3a56a5dd611223b57ef5e301ea9cd64476e54d855b846b05b1e4ea94742
