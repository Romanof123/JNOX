/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/original/captures/overlap-plain f7b514aed503df1cda5adc34aefec2b40c762d5556de9e8819e5dfb77510cc5f
