/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/original/captures/refusal-plain 52650eb3f0e7909b7e7443c482c470dfc0c514035becedffd81d8357c01c5e9e
