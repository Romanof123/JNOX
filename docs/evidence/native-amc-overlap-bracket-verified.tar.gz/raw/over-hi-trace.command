/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/original/captures/over-hi-trace ba7c242cd1c7eae476d9fab7ec1993d14cd2dc048720821fac9bdb52ad46afd7
