/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/checked-synthetic/plain/late-peer cae9e49a3bef98a7b6a79390640457cc273100028245e504363cff2cddefe070
