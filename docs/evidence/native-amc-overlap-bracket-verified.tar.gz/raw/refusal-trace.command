/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/original/captures/refusal-trace 9113f01ac448e82b1b3509f9eef01b04a78012bb99504ec0a362d8c3b09378d1
