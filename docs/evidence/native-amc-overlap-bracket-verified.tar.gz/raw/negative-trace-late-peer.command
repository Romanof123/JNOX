/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/checked-synthetic/trace/late-peer b2a94e0ed6257cfac25eb648e66bf322a6510405ac78dceb14aa4c052f6bf1ed
