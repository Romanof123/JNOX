/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/original/captures/within-lo-plain e927ebdacafec49741543310ed28c81d9d55a7c304c571c8e9628dbcae03f326
