/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/checked-synthetic/trace/miss-wrong-due 4582336c3e7e6e76e4f60c0fc8a88a98a3b408454fbfd8e4458a0c1af044cfa1
