/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/checked-synthetic/trace/miss-removed 4522fb5b054888b8d93b15c9d3424f4c04ec75f3bd75b6def5436201fb25f20f
