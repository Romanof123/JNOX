/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/original/captures/over-hi-plain d2602f443c11ff65be5616ca75cadf69569d9a911efdf91ad7b4b031280c5ab4
