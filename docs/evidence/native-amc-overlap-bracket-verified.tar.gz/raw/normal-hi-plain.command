/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/original/captures/normal-hi-plain fc3ab046ba434333ac0a008bdf9744128c494252d8de4dcdcfb5c14582aa5de7
