/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/original/captures/staggered-plain d682cf1d7d3551a22973cbdce442d84073e11f97680287f3f11987d482e41fa7
