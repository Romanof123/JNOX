/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-bba5355.TdFwsWP1/ram-controls/trace-ambiguous 21a755fcc7af8caf3bf03217a1ba1164d26f422afb6bf9f9ad6579a3bf332f27
