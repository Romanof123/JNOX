/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/original/captures/within-lo-trace 6f45b33c0ac75e4f73013585805962aa65976ce81c1a90dd9ac8693b0c0db755
