/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-offline-f898843.i2bxhHpT/checked-synthetic/plain/wrong-gen 81a50198ef733ad7d12f956d7285ecceda13b59e5079df25acda6f5269f2f235
