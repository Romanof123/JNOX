set -eu
cd /home/ywcho/jnox348-bba5355.TdFwsWP1
mkdir source raw
cd source
git init -q
git remote add origin https://github.com/Romanof123/JNOX.git
git fetch -q --depth=3 origin bba5355fbc9846a571c95514fdd89e27c59920d1
git checkout -q --detach FETCH_HEAD
git log --oneline -3
git diff HEAD^ HEAD -- tools/native_amc_report.py
git ls-tree -r --name-only HEAD^ docs/evidence | grep 'native-amc'