set -eu
D=/home/ywcho/jnox-328-supplement
mkdir "$D"
cd "$D"
cp /mnt/d/codex/weighted-328-first/{supplement-run.py,score.py} .
cp -r /mnt/d/codex/weighted-328-first/deps .
mkdir tools
cp /mnt/d/codex/jnox-328-archive/tools/*.py tools/
python3 supplement-run.py
