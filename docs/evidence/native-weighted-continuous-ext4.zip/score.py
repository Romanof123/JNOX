from pathlib import Path
import hashlib,struct,sys,re,json,subprocess
from fractions import Fraction as F
D=Path(__file__).resolve().parent
sys.path[:0]=[str(D/'deps'),'/mnt/d/codex/jnox-328-archive/tools']
from native_el0_replay import elf_file,symbol,Snapshot,vread,permissions,PA_MASK
from native_weighted_replay import stable_work
Q,H,G=625000,781250,156250
NONE=2**64-1
def run(p):
 u=(p/'uart.bin').read_text()
 log=(p/'exceptions.log').read_text()
 rows=lambda name:[list(map(int,l.split()[3:])) for l in u.splitlines() if l.startswith('NATIVE WEIGHTED '+name+' ')]
 es,xs,cs=map(rows,['EVENT','EXCEPTION','CLOCK'])
 freq,q,mode,horizon,count,epoch=rows('CONTINUOUS')[0]
 assert [freq,q,count]==[62500000,Q,2] and [mode,horizon] in ([1,36],[2,3]) and rows('DROPPED')==[[0]]
 arm=['share','wake'][mode-1]
 digest=hashlib.sha256((p/'user.elf').read_bytes()).hexdigest()
 assert digest=='9d3c6350a04536da091dd7bc77cfdcc81729f8baa431d6315e5258c28da67206' and u.count('ELF '+digest)==2
 assert rows('SLOT')==[[0,1,3],[1,2,3]]
 assert [bytes.fromhex(s).decode() for s in re.findall(r'NATIVE WEIGHTED HEX (\w+)',u)]==['/bin/app','A',arm,'/bin/app','B',arm]
 k=elf_file((p/'kernel.elf').read_bytes()); app=elf_file((p/'user.elf').read_bytes())
 mem=Snapshot(0x40200000,(p/'ram.bin').read_bytes())
 # RAM-backed journals and terminal UART must agree byte-for-byte.
 for name,items in [('ROWS',es),('EXCEPTIONS',xs),('CLOCKS',cs)]:
  if not items: continue
  sy=[s for s in k.get_section_by_name('.symtab').iter_symbols() if 'native_weighted' in s.name and name in s.name]
  if not sy: sy=[s for s in k.get_section_by_name('.symtab').iter_symbols() if 'weighted' in s.name and name in s.name]
  assert len(sy)==1,(name,[s.name for s in sy])
  raw=b''.join(struct.pack('<'+'Q'*len(r),*r) for r in items)
  assert mem.read(sy[0]['st_value'],len(raw))==raw
 tt=[next(e[42] for e in es if e[3]==i) for i in range(2)]
 roots=[t&PA_MASK for t in tt]
 assert [t>>48 for t in tt]==[1,2]
 result,size=symbol(app,'native_weighted_result');assert size==224
 prods=[]
 for i,r in enumerate(roots):
  v=struct.unpack('<28Q',vread(mem,r,result,size))
  assert v[:3]==(1,i+1,mode) and v[4]>0 and v[-1]==41+i
  stable_work(i,*v[3:8]);prods.append(v)
  assert v[8]==(3 if i==1 and mode==2 else 0)
  if mode==2 and i==1: assert v[4]==6
  permissions(mem,r,0x1200000,'user r')
  assert vread(mem,r,0x1200000,4096)==b'\1'+bytes(4095)
  flagpa=mem.leaf(r,0x1200000)&PA_MASK
  tables=[(r,0)]
  for level in (0,1,2):
   nxt=[]
   for table,base in tables:
    for slot,(desc,) in enumerate(struct.iter_unpack('<Q',mem.read(table,4096))):
     if not desc&1:continue
     assert desc&3==3
     va=base+(slot<<(30-9*level))
     if level<2:nxt.append((desc&PA_MASK,va))
     elif desc&PA_MASK==flagpa:assert (desc>>6&3)!=1 and (desc>>6&3)!=3 or va==0x1200000
   tables=nxt
  for seg in app.iter_segments():
   if seg['p_type']!='PT_LOAD' or not seg['p_memsz']: continue
   va=seg['p_vaddr']
   if seg['p_flags'] in (4,5): assert vread(mem,r,va,seg['p_filesz'])==seg.data()
   else:
    for a in range(va,va+seg['p_memsz'],4096):
     permissions(mem,r,a,'user rw'); assert mem.leaf(r,a)&PA_MASK != mem.leaf(roots[1-i],a)&PA_MASK
  for a in range(0x1001000,0x1011000,4096):
   permissions(mem,r,a,'user rw');assert mem.leaf(r,a)&PA_MASK != mem.leaf(roots[1-i],a)&PA_MASK
 assert mem.leaf(roots[0],0x1200000)==mem.leaf(roots[1],0x1200000)
 trace=re.findall(r'Taking exception \d+ \[(IRQ|SVC)\]\s+\.\.\.from EL0 to EL1\s+\.\.\.with ESR [^\n]+\s+\.\.\.with ELR (0x\w+)',log)
 returns=list(map(lambda h:int(h,16),re.findall(r'Exception return from AArch64 EL1 to AArch64 EL0 PC (0x\w+)',log)))
 assert len(xs)==len(es)-1==len(trace) and returns==[e[19] for e in es if e[3]!=NONE]
 ready={0,1};vr=[F(0),F(0)];service=[0,0];floor=F(0);weights=[1,2];sleep={};counts=[0,0];miss=[];hrow=None;clock=[];rounds=[];prefix=[]; saved={0:(0x400000,es[0][20]),1:None}; leases=[]
 for j,(old,e,x,t) in enumerate(zip(es,es[1:],xs,trace),1):
  cause,I,owner,selected,seq,R,bill,deadline,C,expiry,priorwake=e[:11]
  assert seq==j and (owner,R,C)==(old[3],old[15],old[16])
  assert bill==I-R>0 and expiry==R+Q and C==min([expiry]+list(sleep.values())) and priorwake==min(sleep.values(),default=0)
  assert old[39]&3==1 and old[42]==tt[owner] and old[15]<=old[40]<=I
  assert mem.read(old[41],4)==bytes.fromhex('e0039fd6')
  assert (x[0],x[3],x[4],x[6],x[7],x[8])==(I,owner,C,tt[owner],e[17],e[18]) and int(t[1],16)==x[7]
  assert old[38]==e[37]
  saved[owner]=(e[17],e[18])
  if cause==4:
   assert t[0]=='IRQ' and x[1:3]==[1,30] and x[5]&7==5 and x[12]==30 and x[13]>=I and I>=C
   counts[0]+=C==expiry
  else:
   assert t[0]=='SVC' and x[1:3]==[2,{6:6,2:7,3:1}[cause]] and x[11]==0 and vread(mem,roots[owner],x[7]-4,4)==bytes.fromhex('214009d4')
  gap=0 if j==1 else R-old[1]
  if bill>H or not 0<=gap<=G:miss.append(['lease',seq,bill,gap])
  leases.append(dict(seq=seq,owner=owner,R=R,C=C,I=I,charge=bill,gap=None if j==1 else gap,reason=cause))
  assert owner in ready
  service[owner]+=bill;vr[owner]+=F(bill,weights[owner]);floor=max(floor,min(vr[i] for i in ready))
  if cause in (2,3):
   ready.remove(owner)
   if ready:floor=max(floor,min(vr[i] for i in ready))
   if cause==2:sleep[owner]=deadline;assert deadline>I
  due=[i for i,d in sleep.items() if d<=I and cause==4]
  assert e[12]==sum(1<<i for i in due)
  for i in due:
   del sleep[i];vr[i]=max(vr[i],floor);ready.add(i);counts[1]+=1
  if ready:
   floor=max(floor,min(vr[i] for i in ready))
   assert selected==min(ready,key=lambda i:(vr[i],i))
   if saved[selected]: assert tuple(e[19:21])==saved[selected]
   assert I<=e[15] and (cause!=4 or x[13]<=e[15])
  else:assert selected==NONE
  assert e[11]==sum(1<<i for i in ready) and e[24:26]==service
  assert [F(e[a])+F(e[a+1],e[a+2]) for a in [21,27,30]]==[floor,*vr]
  assert e[43:45]==counts and e[45]==int(counts[mode-1]>=horizon)
  if e[45] and hrow is None:hrow=j
  if mode==1 and (hrow is None or j==hrow):
   assert ready=={0,1} and cause==4
   delta=2*service[0]-service[1];prefix.append(delta)
   if not -H<=delta<=2*H:miss.append(['prefix',j,delta])
  if cause in (2,6):
   ret=next(z for z in es[j:] if z[3]==owner)
   assert ret[19]==e[17] and ret[20]==e[18] and ret[46]==0
   if cause==6:clock.append((I,e[15],x[10],e[17]))
 assert hrow is not None and not ready
 if mode==1:
  a,b=es[hrow][24:26]
  if a+b<36*Q or abs(F(a,a+b)-F(1,3))>F(2*H,108*Q):miss.append(['share',a,b])
 else:
  assert len(cs)==len(clock)==6
  intervals=[];targets=[]
  for n in range(3):
   triple=prods[1][9+n*6:15+n*6];ns=[s*10**9+v for s,v in zip(triple[::2],triple[1::2])]
   assert ns[1]-ns[0]==40000000
   tick=lambda n:epoch+(n*freq+10**9-1)//10**9
   targets.append(tick(ns[1]))
   for m,ns1 in enumerate((ns[0],ns[2])):
    ci=n*2+m;i,r,ptr,pc=clock[ci];c=cs[ci]
    assert c[0]==1 and c[1]==i and i<=c[2]<=r and c[3]==0 and c[4]==pc
    assert 0x1001000<=ptr<0x1011000-15 and ptr%8==0
    lo=max(tick(ns1),i);hi=min(tick(ns1+1)-1,r);assert lo<=hi
    intervals.append([lo,hi])
  for n,(j,s) in enumerate((j,s) for j,s in enumerate(es) if s[0]==2):
   k=next(k for k in range(j+1,len(es)) if es[k][12]==2)
   w=es[k];t=next(t for t in range(k,len(es)) if es[t][3]==1)
   assert s[7]==targets[n]==w[8] and t-k<=1
   segment=es[j+1:k+1];assert all(e[2]==0 for e in segment)
   full=sum(e[0]==4 and e[8]==e[9] for e in segment)
   elapsed=sum(e[6] for e in segment)
   D0,I,W,R=s[7],w[1],w[13],es[t][15]
   lo,hi=intervals[n*2+1]
   ds=[I-D0,W-I,R-W,hi-R,hi-D0]
   if not (3<=full<=4 and elapsed>=3*Q and D0<=I<=W<=R<=lo and all(a<=b for a,b in zip(ds,[G,G,H+2*G,G,H+5*G]))):miss.append(['wake',n+1,ds,elapsed,full])
   rounds.append(dict(D=D0,I=I,W=W,R=R,S=[lo,hi],full=full,A_service=elapsed,deadline_partial=w[8]<w[9],prior_A=t-k,delta=ds))
 return dict(misses=miss,products=prods,leases=leases,horizon_index=hrow,horizon_service=es[hrow][24:26],tail=leases[hrow:],prefix=prefix,rounds=rounds)
if __name__=='__main__':
 for p in sorted(D.glob('0*-candidate')):
  if not (p/'ram.bin').exists(): print(p.name,'missing RAM');continue
  r=run(p);(D/(p.name+'-score.json')).write_text(json.dumps(r,indent=2));print(p.name,r['misses'],r['horizon_service'],r['rounds'])