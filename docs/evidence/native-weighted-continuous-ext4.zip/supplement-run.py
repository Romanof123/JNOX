from pathlib import Path
import os,sys,shutil,subprocess as sp,traceback,time,json,hashlib,zipfile,contextlib
D=Path(__file__).resolve().parent
B=Path('/mnt/d/codex/weighted-328-first'); dest=B/'supplement'
dest.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2))
def fs(p):return sp.check_output(['findmnt','-T',p,'-no','TARGET,SOURCE,FSTYPE,OPTIONS'],text=True).strip()
assert ' ext4 ' in fs(D)
q=Path(shutil.which('qemu-system-aarch64')).resolve()
source=json.loads((B/'freeze.json').read_text())
assert sha(q)==source['sha256'] and sorted(os.sched_getaffinity(0))==source['cpus']
sys.path[:0]=[str(D/'tools'),str(D/'deps')]
os.environ['PYTHONPATH']=os.pathsep.join(sys.path[:2]);os.environ['TMPDIR']=str(D/'tmp');(D/'tmp').mkdir()
import native_weighted_capture as cap
from native_weighted_replay import replay
from score import run
first=[]
for label,pos in [('supp-01-comparator',2),('supp-02-candidate',3)]:
 r=source['positions'][pos];root=D/label; orig=B/r['name'];k=D/(label+'.elf');shutil.copyfile(orig/'kernel.elf',k)
 assert sha(k)==r['sha256']
 shutil.copyfile(orig/'user.elf',D/'user.elf');assert sha(D/'user.elf')==source['user']
 shutil.copyfile(orig/'probe.c',D/'probe.c')
 argv=cap.qemu_command(str(q),root,'icount3')
 assert [s.replace(str(orig),str(root)) for s in r['argv']]==argv
 from native_el0_replay import elf_file
 assert elf_file(k.read_bytes())['e_entry']==elf_file((orig/'kernel.elf').read_bytes())['e_entry']
 first.append(dict(label=label,r=r,argv=argv,kernel=sha(k),user=sha(D/'user.elf'),entry=elf_file(k.read_bytes())['e_entry']))
put(D/'freeze.json',dict(plan='be655161737953d4c34999e08ae1ed142fdbecef',filesystem=fs(D),host_affinity=sorted(os.sched_getaffinity(0)),qemu=sha(q),timeout_seconds=20,positions=first,driver=sha(Path(__file__)),score=sha(D/'score.py'),tmp=fs(D/'tmp')))
def stage(log,name,fn):
 start=time.time_ns()
 try:
  res=fn()
 except Exception:
  res=dict(error=traceback.format_exc())
 log.append(dict(stage=name,start_ns=start,end_ns=time.time_ns(),result=res))
 return res
for item in first:
 name=item['label'];r=item['r'];root=D/name;cur=D/(name+'-meta');cur.mkdir();log=[]
 old=r['kind']=='old'
 def capture():
  import argparse
  if not old:cap.TERMINAL=rb'(?m)^NATIVE EL0 (EXIT PID 1 -?[0-9]+|FAIL [^\r\n]+)\r?\n';cap.SUCCESS='EXIT PID 1 42'
  # Preserve the original observer; decorate its caught exception formatting at outer scope through a traceback on errors if available.
  arg=argparse.Namespace(root=root,revision=r['revision'],arm='share',clock='icount3',kernel=D/(name+'.elf'),user=D/'user.elf',probe=D/'probe.c',nm='aarch64-linux-gnu-nm',qemu=str(q),timer_observation=False)
  with (cur/'capture.stdout').open('w') as out,(cur/'capture.stderr').open('w') as err,contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
   return cap.capture(arg)
 stage(log,'capture',capture)
 pin=sha(root/'session.json') if (root/'session.json').exists() else None
 def score(p):
  assert sha(p/'session.json')==pin
  return replay(p,pin) if old else run(p)
 result=stage(log,'source-score',lambda:score(root))
 put(cur/'score.json',result);put(cur/'stages.json',log)
 manifest={p.name:sha(p) for p in sorted(root.iterdir()) if p.is_file()}
 put(cur/'raw-sha256.json',manifest)
 z=D/(name+'.zip')
 def seal():
  with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as f:
   for p in [*root.iterdir(),*cur.iterdir(),D/'freeze.json']:f.write(p,p.relative_to(D))
  return sha(z)
 digest=stage(log,'archive',seal);(D/(name+'.pin')).write_text(str(digest))
 def transfer():
  shutil.copyfile(z,dest/z.name);assert sha(dest/z.name)==digest;return digest
 stage(log,'transfer',transfer)
 def reopen():
  with zipfile.ZipFile(dest/z.name) as f:
   assert f.testzip() is None
   for n,h in manifest.items():assert hashlib.sha256(f.read(name+'/'+n)).hexdigest()==h
   f.extractall(dest/('reopen-'+name))
  post=score(dest/('reopen-'+name)/name);assert post==result
  return dict(session=pin,sha256=digest,status='PASS' if not post.get('timing_misses',post.get('misses',[])) else 'FAIL')
 stage(log,'destination-reopen-and-replay',reopen)
 put(dest/(name+'-stages.json'),log)
 print(name,[(x['stage'],x['result'] if x['stage']!='source-score' else 'see score') for x in log],flush=True)