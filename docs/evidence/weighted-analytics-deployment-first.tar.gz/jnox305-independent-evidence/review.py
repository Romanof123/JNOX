from capture import *
from fractions import Fraction
import score
def review(root,label):
 case=label.split('-')[0];var=variants[case];apps=cases[case];r=root/'runs'/label; uart=(r/'uart.log').read_text(errors='replace')
 rows=[list(map(int,l.split()[3:])) for l in uart.splitlines() if l.startswith('NATIVE WEIGHTED EVENT') and len(l.split())==42]
 if not (r/'ram.json').exists():return dict(partial=True,rows=len(rows),failure=(r/'failure').read_text(),prefix_last=rows[-1] if rows else None)
 score.D=root
 basic=score.score(label)
 clocks=[list(map(int,l.split()[3:])) for l in uart.splitlines() if l.startswith('NATIVE WEIGHTED CLOCK')]
 raw=json.loads((r/'ram.json').read_text());mapped=json.loads((r/'mapped.json').read_text())
 def field(i,k):return int.from_bytes(bytes.fromhex(raw[i][k]),'little')
 def domain(n):return int.from_bytes(next(r.glob('*CLOCK_DOMAIN*.'+str(n)+'.bin')).read_bytes(),'little')
 epoch,hz=domain(0),domain(1); identities=[json.loads((r/(a+'-guest-text.json')).read_text()) for a in apps]
 manifest=json.loads((bundle/var/'manifest.json').read_text()); record=json.loads((bundle/'build.json').read_text()); cmd=json.loads((r/'command.json').read_text()); launches=[json.loads(x.read_text()) for x in (out/'launches').glob(var+'-*.json')]
 checks=dict(kernel=digest(bundle/var/'kernel.elf')==manifest['kernel_elf_sha256']==cmd['kernel'],qemu=any(l['argv']==mapped['argv'][:-1] and l['kernel_sha256']==cmd['kernel'] for l in launches),manifest=digest(bundle/var/'manifest.json')==record['packages'][var],slot=all(s['elf_sha256']==record['clients'][a]==cmd['slots'][i] and s['weight']==w and s['slot']==i and s['elf_sha256'] in uart for i,(s,(a,w)) in enumerate(zip(manifest['slots'],json.loads((bundle/'profile.json').read_text())['variants'][var]))),mapped_text=all(len(m)>0 and all(b[-1] for b in m) for m in identities),exits=basic['exit']==[expected[a][2] for a in apps],domains=hz==62500000)
 rowsbin=next(r.glob('*weighted4ROWS*.bin')).read_bytes()
 checks['physical_journal']=rowsbin[:len(rows)*312]==b''.join(struct.pack('<39Q',*b) for b in rows) and len(rows)==int.from_bytes(next(r.glob('*weighted4USED*.bin')).read_bytes(),'little') and basic['dropped']==int.from_bytes(next(r.glob('*weighted4LOST*.bin')).read_bytes(),'little')==0
 frame={};errors=[];productive={};saved={}
 for i,a in enumerate(apps):
  k={'checksum':'checksum_stream','histogram':'histogram_stream','energy':'measure_energy'}.get(a)
  if k:
   sym=next(l for l in (root/'elf'/(a+'.elf.sym')).read_text().splitlines() if l.endswith(' '+k));start,size=[int(v,16) for v in sym.split()[:2]]
   productive[a]=sum(b[0]==4 and b[2]==i and start<=b[17]<start+size for b in rows)
 for j,b in enumerate(rows):
  if b[2]<len(apps):saved[b[2]]=b[17:19];frame[b[2]]=b[37]
  if b[3] in saved and (saved[b[3]]!=b[19:21] or frame[b[3]]!=b[38]):errors.append(j)
 cont=[(j,b[6],b[15]-b[1]) for j,b in enumerate(rows[1:],1) if rows[j-1][11].bit_count()>1]
 basic.update(identities=checks,epoch=epoch,frequency=hz,saved_frame_errors=errors,productive_interrupts=productive,contended_over_H=[x for x in cont if x[1]>781250],contended_gap_over_G=[x for x in cont if x[2]>156250],kernel_sha256=cmd['kernel'])
 if case=='wake':
  dl,ob=[struct.unpack('<3Q',bytes.fromhex(raw[1][k])) for k in ('report_deadline_ns','report_observed_ns')]
  basic['private_clocks']=[(d,o,d==(pre[1]-epoch)*16+40000000,o==(post[1]-epoch)*16,epoch+(d+15)//16==wake['target']) for d,o,pre,post,wake in zip(dl,ob,clocks[::2],clocks[1::2],basic['wake'])]
 if case=='overflow':
  first=next(b for b in rows if b[3]==0);post=clocks[0]; block=next(b for b in rows if b[0]==2 and b[2]==0); end=next(b for b in rows if b[2]==0)
  basic['overflow_control']=dict(epoch=epoch,now_bound=[first[15],post[1]],target=epoch+10**19,target_fits=epoch+10**19<2**64,signed_distance=epoch+10**19-post[1]>2**63-1,SDK=field(0,'overflow_return'),normal=field(0,'normal_return'),deadline=field(0,'request_ns'),observed=field(0,'observed_ns'),first_postcall_clock=post,uninterrupted_through_clock=first[15]<=post[1]<=end[1] and first[14]==end[4] and first[16]==end[8],lease=first[14],compare=first[16],other_sleep_requests=sum(b[0]==2 for b in rows)-1,valid_wait=block[7]==epoch+(field(0,'request_ns')+15)//16 and field(0,'observed_ns')>=field(0,'request_ns'))
 return basic
for root in (D,D/'supplement'):
 if root.exists():
  c={}
  for label in order:
   if (root/'runs'/label).exists():
    try:c[label]=review(root,label)
    except Exception:c[label]={'score_failure':traceback.format_exc()}
  save(root/'review.json',c)
