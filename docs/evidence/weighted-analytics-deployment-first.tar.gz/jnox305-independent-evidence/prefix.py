from capture import *
from fractions import Fraction
res={}
for case in ('swap','triple'):
 n=len(cases[case]); weights=[2,1] if n==2 else [1,2,3]; target=36 if n==2 else 60
 path=D/'runs'/(case+'-default')/'uart.log'; raw=path.read_bytes()
 rows=[list(map(int,l.split()[3:])) for l in raw.split(b'\n')[:-1] if l.startswith(b'NATIVE WEIGHTED EVENT') and len(l.split())==42]
 srv=[0]*n;errors=[]; win=0
 for j,(a,b) in enumerate(zip(rows,rows[1:]),1):
  if j>target:break
  vr=[Fraction(s,w) for s,w in zip(srv,weights)]
  elapsed=b[1]-a[15]; pid=a[3]
  if not(b[0]==4 and a[11]==b[11]==2**n-1):break
  win+=1
  if not(pid==min(range(n),key=lambda i:(vr[i],i)) and b[2]==pid and a[14]==b[4] and a[15]==b[5] and a[16]==b[8]==a[15]+625000 and b[6]==elapsed and 625000<=elapsed<=781250 and 0<=b[15]-b[1]<=156250):errors.append([j,'selection/physical'])
  srv[pid]+=elapsed; vr=[Fraction(s,w) for s,w in zip(srv,weights)]
  if not(srv==b[24:24+n] and b[3]==min(range(n),key=lambda i:(vr[i],i)) and all(v==b[27+3*i]+Fraction(b[28+3*i],b[29+3*i]) for i,v in enumerate(vr)) and min(vr)==b[21]+Fraction(b[22],b[23])):errors.append([j,'service/runtime'])
  if n==2 and not -781250<=2*srv[1]-srv[0]<=1562500:errors.append([j,'prefix'])
  if n==3 and max(vr)-min(vr)>781250:errors.append([j,'spread'])
 res[case]=dict(complete_uart_rows=len(rows),observed_window=win,required=target,errors=errors,service=srv)
save(D/'partial-prefix.json',res)
