import os, sys, json, time, struct, hashlib, subprocess as sp, zlib, math, traceback, re
from pathlib import Path
D=Path(__file__).resolve().parent
repo=Path.home()/'jnox305-independent'
out=Path.home()/'jnox305-pkgs'
bundle=out/'deployment'
cases={'share':['checksum','histogram'],'swap':['checksum','histogram'],'triple':['checksum','histogram','energy'],'wake':['checksum','reporter'],'overflow':['overflow','checksum']}
variants={'share':'pair','swap':'swap','triple':'triple','wake':'timed','overflow':'overflow'}
order=[k+'-default' for k in cases]
expected={'checksum':(2**27,zlib.crc32(bytes(range(256))*524288),237),'histogram':(2**29,[2097152*math.comb(8,k) for k in range(9)],70),'energy':(2**30,4194304*sum(x*x for x in range(-128,128)),179),'reporter':(3,7,7),'overflow':(3,32640,61)}
def save(p,x):p.write_text(json.dumps(x,indent=2))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def symbols(p):return sp.check_output(['aarch64-linux-gnu-nm','-S',p],text=True)
def run(label):
 case=label.split('-')[0]; var=variants[case]; apps=cases[case]; pkg=bundle/var; r=D/'runs'/label; r.mkdir()
 kernel=pkg/'kernel.elf'; data=kernel.read_bytes()
 def hdr(i):return struct.unpack_from('<IIQQQQQQ',data,struct.unpack_from('<Q',data,32)[0]+56*i)
 load=next(hdr(i) for i in range(struct.unpack_from('<H',data,56)[0]) if hdr(i)[0]==1 and hdr(i)[5]>=256)
 _,_,off,_,pa,*_=load
 syms=symbols(kernel); (r/'kernel.sym').write_text(syms)
 base,size=[int(t,16) for t in next(l for l in syms.splitlines() if '6SPACES' in l).split()[:2]]
 assert size==len(apps)*0x415000
 fields=[]; slots=[]
 for i,app in enumerate(apps):
  elf=pkg/['user.elf','native_peer.elf','native_peer2.elf'][i]; assert digest(elf)==digest(bundle/'clients'/(app+'.elf'))
  sym=symbols(elf); (D/'elf'/(app+'.elf.sym')).write_text(sym)
  (D/'elf'/(app+'.elf.dis')).write_bytes(sp.check_output(['aarch64-linux-gnu-objdump','-d',elf]))
  fields.append({s[3]:[base+i*0x415000+5*4096+int(s[0],16)-0x400000,int(s[1],16)] for l in sym.splitlines() if len(s:=l.split())==4 and s[3] in ('private_progress','private_result','report_deadline_ns','report_observed_ns','normal_return','overflow_return','request_ns','observed_ns')})
  slots.append(digest(elf))
 cmd=['python3','tools/weighted_analytics.py','boot','--out',str(out),'--variant',var]
 save(r/'command.json',dict(cmd=cmd,slots=slots,kernel=digest(kernel),fields=fields))
 with (r/'uart.log').open('wb') as uart,(r/'stderr').open('wb') as err,sp.Popen(cmd,cwd=repo,stdout=uart,stderr=err,stdin=sp.DEVNULL) as p:
  try:
   proc=Path('/proc')/str(p.pid); start=time.monotonic(); ram=None
   while time.monotonic()-start<180 and p.poll() is None:
    if ram is None and 'qemu-system' in os.readlink(proc/'exe'):
     with (proc/'mem').open('rb',buffering=0) as mem:
      for l in (proc/'maps').read_text().splitlines():
       lo,hi=map(lambda x:int(x,16),l.split()[0].split('-'))
       if hi-lo>=128*1024**2 and 'rw' in l.split()[1]:
        try:mem.seek(lo+pa-0x40000000); match=mem.read(256)==data[off:off+256]
        except OSError:continue
        if match:
         ram=lo;save(r/'mapped.json',dict(mapping=l,physical=pa,bytes=data[off:off+256].hex(),argv=(proc/'cmdline').read_bytes().decode().split(chr(0))));break
    if (r/'uart.log').read_bytes().count(b'NATIVE EL0 EXIT')>=len(apps) and b'\n' in (r/'uart.log').read_bytes().split(b'NATIVE EL0 EXIT')[-1]:break
    time.sleep(.03)
   if ram is None:raise ValueError('RAM identity not found')
   with (proc/'mem').open('rb',buffering=0) as mem:
    def read(addr,n):mem.seek(ram+addr-0x40000000);return mem.read(n).hex()
    for i,app in enumerate(apps):
     elf=(bundle/'clients'/(app+'.elf')).read_bytes()
     table=struct.unpack_from('<Q',elf,32)[0]; entries=struct.unpack_from('<H',elf,56)[0]
     mapped=[]
     for index in range(entries):
      ty,flags,off2,va,_,length,_,_=struct.unpack_from('<IIQQQQQQ',elf,table+index*56)
      if ty==1 and flags&1 and length:
       actual=bytes.fromhex(read(base+i*0x415000+5*4096+va-0x400000,length)); want=elf[off2:off2+length]; mapped.append([va,length,hashlib.sha256(actual).hexdigest(),actual==want])
     save(r/(app+'-guest-text.json'),mapped)
    save(r/'ram.json',[{k:read(*v) for k,v in f.items()} for f in fields])
    for l in syms.splitlines():
     s=l.split()
     if len(s)==4 and any(k in s[3] for k in ('8weighted4ROWS','8weighted4USED','8weighted4LOST','CLOCK_DOMAIN','8weighted6CLOCKS','8weighted10CLOCK_USED')):
      (r/(s[3]+'.bin')).write_bytes(bytes.fromhex(read(int(s[0],16),int(s[1],16))))
  finally:
   if p.poll() is None:p.terminate();p.wait(10)
if __name__=='__main__':
 (D/'runs').mkdir();(D/'elf').mkdir()
 save(D/'prelaunch.json',dict(order=order,expected=expected,watchdog_s=180,boot='documented operator, stdin closed, serial captured, read-only parent /proc/pid/mem matching kernel PT_LOAD bytes',checkout=sp.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),hashes={n:digest(D/n) for n in ('capture.py','score.py','first-order.md')},build=digest(bundle/'build.json'),argv_template=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','stdio','-no-reboot','-kernel','deployment/{variant}/kernel.elf']))
 for label in order:
  try:run(label)
  except Exception:(D/'runs'/label/'failure').write_text(traceback.format_exc())

