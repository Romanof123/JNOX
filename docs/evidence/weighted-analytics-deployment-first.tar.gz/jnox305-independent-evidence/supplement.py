from capture import *
import shutil
S=Path.home()/'jnox305-supplement'
S.mkdir()
for n in ('capture.py','score.py','first-order.md'):shutil.copyfile(D/n,S/n)
(S/'runs').mkdir();(S/'elf').mkdir()
fixed=[label for label in order if (D/'runs'/label/'failure').exists()]
save(S/'supplement-order.json',dict(reason='first observer failure; preserve every original',positions=fixed))
os.chdir(S)
import capture
capture.D=S
for label in fixed:
 try:capture.run(label)
 except Exception:(S/'runs'/label/'failure').write_text(traceback.format_exc())
shutil.copytree(S,D/'supplement')
