set -eu
source ~/.cargo/env
base=$HOME/permit389-first-fbbb
dest=/mnt/d/codex/permit389-first-fbbb
cd "$base/src"
rev=$(git rev-parse HEAD)
app=examples/native-safety-channel
for role in sender receiver supervisor; do sh sdk/native-aarch64/build-rust.sh "$app/$role/Cargo.toml" "$base/orig-$role.elf" > "$base/orig-$role.log" 2>&1; done
cp "$base"/orig-*.elf "$base"/orig-*.log "$dest/"
qemu-system-aarch64 -machine help > "$base/qemu-machines.txt"
qemu-system-aarch64 -accel tcg,help > "$base/qemu-tcg.txt" 2>&1 || true
for mode in observer default; do
 for p in fifo rr; do
  q=(); if [[ $p == rr ]]; then q=(--quantum-ticks 625000); fi
  cases=(collision phase); if [[ $mode == default ]]; then cases=(healthy collision phase); fi
  for a in "${cases[@]}"; do
   n=$mode-$p-$a; mkdir "$base/$n"; x=(); if [[ $mode == observer ]]; then x=(--safety-boundary); fi
   (set -x; python3 tools/build_native_el0.py --out "$base/$n/pkg" --board virt --policy "$p" "${q[@]}" --elf "$base/orig-sender.elf" --peer-elf "$base/orig-receiver.elf" --peer-elf "$base/orig-supervisor.elf" --arg "$a" --peer-arg "$a" --peer2-arg "$a" --priority 7 --peer-priority 6 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel "${x[@]}") > "$base/$n/build.log" 2>&1 || { tail "$base/$n/build.log"; cp -r "$base/$n" "$dest/"; exit 1; }
   if [[ $mode == observer ]]; then export PYTHONPATH="$dest:$base/src/tools" PERMIT_OBSERVER=1; else unset PERMIT_OBSERVER PYTHONPATH; fi
   (set -x; python3 tools/native_el0_capture.py "$base/$n/cap" "$base/$n/pkg/kernel.elf" "$base/orig-sender.elf" "$app/sender/src/main.rs" "$rev" --manifest "$base/$n/pkg/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608) > "$base/$n/boot.log" 2>&1 || echo UNRESOLVED >> "$base/$n/boot.log"
   (cd "$base/$n"; tar -czf "$dest/$n.tgz" cap pkg/kernel.elf pkg/manifest.json build.log boot.log)
   echo "$n"; tail -1 "$base/$n/boot.log"
  done
 done
done
