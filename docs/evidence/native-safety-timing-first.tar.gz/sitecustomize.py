import os
if os.getenv('PERMIT_OBSERVER'):
    import ordinary_amc_capture as module
    index=module.FLAGS.index('tcg')
    module.FLAGS[index:index+1]=['tcg,thread=single','-icount','shift=0,align=off,sleep=off']
