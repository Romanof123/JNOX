#!/usr/bin/env bash
set -euo pipefail
scripts=/mnt/d/codex/permit397-active-first
rev=3dac7eff2fa4b405d59f09bca105c56ca8b599ba
bash "$scripts/lane.sh" checkout "$rev"
bash "$scripts/lane.sh" apps "$rev"
bash "$scripts/lane.sh" matrix "$rev"
