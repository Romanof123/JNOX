"""Render a bilingual, first-attempt report from independently verified scores."""
import json
from pathlib import Path
import sys

root=Path(sys.argv[1])
scores=json.loads((root/"results/by-boot.json").read_text())
trials=json.loads((root/"results/mutation-tests.json").read_text())
active=[s for s in scores if "reject_age" in s]
frames=[s for s in active if s["case"]!="wrong-owner"]
authority=[s for s in active if s["case"]=="wrong-owner"]
misses=sum(s["completion_gap_max"][0]>312500 for s in scores)
fixed=[s["fixed_loss"][0][0] for s in scores]
age=lambda v: f'{v/62500:.6f}'
def span(k):
    vals=[s[k] for s in active];return f'{min(vals)}–{max(vals)} ticks ({age(min(vals))}–{age(max(vals))} ms)'
report=[
"# IPC-010 · First active-receiver cohort / 활성 수신기 최초 검증",
"## Result / 판정",
f"All 40 original cold boots passed their fixed functional criteria. The 34 single-frame cases returned the intended local error and skipped protected COMMIT. The two role cases returned signed −13 for PID 2’s argument-free SVC 33 while PID 0 held a staged writer. All 36 continued to a valid sequence 4 with the output high and then an accepted sequence 5 withdrawal. Four ordinary control boots retained their expected behavior. All exit triplets were 71/72/73. The terminal virtual ENABLE register was zero in every RAM image.",
"독립 부팅 40회가 모두 첫 시도에서 사전에 정한 기능 기준을 충족했다. 프레임 34건은 지정한 로컬 오류로 거부되어 커널 COMMIT을 건너뛰었다. 권한 시험 2건에서는 송신 슬롯 0이 자기 쓰기 권한을 보유한 동안 슬롯 2의 인자 없는 acquire가 −13으로 거부됐다. 활성 시험 36건은 정상 순번 4 수락과 출력 ON을 확인한 후 순번 5에서 출력을 해제했다. 기존 정상·혼합 오류 대조군은 각 정책에서 한 번씩 실행했다.",
f"The booted private revision was `3dac7eff2fa4b405d59f09bca105c56ca8b599ba`. Its public source counterpart is `85f9828f66ac766a13b73ced05b5bb90a4898104`. Both Git commit objects name the same complete tree `ef8cbc4b83bd65bc5bb47e3275d1f665404df58f`. Replay verifies the commit object bytes, reconstructs the root tree from its entire recursive manifest, and verifies the Git blob of every archived build-source file. Raw captures retain the SHA actually compiled. [Public source](https://github.com/Romanof123/JNOX/tree/85f9828f66ac766a13b73ced05b5bb90a4898104) · [Frozen criteria](https://github.com/Romanof123/JNOX/issues/397)",
"실제 캡처 기록은 빌드한 커밋을 가리킨다. 공개 커밋과 실행 커밋은 같은 전체 소스 트리를 공유한다. 소스 비교·검증에는 두 커밋 객체, 전체 트리 목록, 빌드에 쓰인 디렉터리의 소스 파일을 사용했다.",
"## Platform and measurement / 실행 조건 및 측정",
"Stock QEMU 6.2.0, virt GICv2, Cortex-A72, one CPU, TCG, 128 MiB, 62,500,000 Hz. FIFO and RR used the ordinary safety-channel packages, priorities 7/6/4, synchronous 2→0 and 2→1 routes, loan route 0→1, and RR quantum 625,000 ticks. Every UART was collected from a new QEMU process. The packaged manifests retain exact selectors and flags, binary hashes, and the QEMU command. All first attempts, build and capture receipts, and full terminal RAM images are included. The protected safety journal lost zero entries across the cohort.",
f"Each decision used a sampled live counter. Sequence 1–3 and test/follow-up frame issue ticks were scheduled bench stimuli. The prior accepted issue was {span('reject_age')} old at the refusal and {span('next_age')} old at the following accepted decision. The old-issue limit was strictly less than 1,250,000 ticks. Every seq4 wire issue was independently fresh at the live clock. A kernel output transition bracket and protected INFO values established virtual output state. No external device was instrumented.",
f"발행 시각은 시험 일정에서 구성했고, 판정 시각은 실제 카운터에서 읽었다. 이전 허가가 신선한 조건은 1,250,000틱 미만으로 검사했다. 커널 INFO와 장치 변경 이벤트로 거부 전후 출력 상태를 대조했다. 스케줄러의 고정 길이 추적 버퍼에는 부팅당 {min(fixed)}–{max(fixed)}건의 드롭이 있었으며 보호된 안전 이벤트의 드롭은 전부 0건이었다.",
f"The original release-to-completion and inter-completion 5 ms limits remain unchanged. All {misses} of the 40 boots had at least one inter-completion interval whose conservative lower bound exceeded 312,500 ticks. The largest upper bounds were {max(s['response_max'][1] for s in scores)} ticks for response and {max(s['completion_gap_max'][1] for s in scores)} ticks for consecutive completions. This is a functional virtual-device result. Native timing, WCET, hardware behavior and product qualification remain open.",
"원래의 5 ms 시간 기준을 그대로 적용했다. 연속 COMPLETE 사이 간격은 아래 표처럼 기준을 넘었으며, 실물 하드웨어·WCET·제품 승인은 이 기능 검증의 범위 밖이다.",
"## First run per policy and selector / 정책·입력별 최초 부팅",
"Ages are integer ticks since the preceding accepted seq3 issue. SKIP is the recorded 2⁶³ sentinel. The two CRC columns are stored and independently calculated IEEE CRC-32 over bytes 0–39. G is the genuine configured generation. The packet’s per-boot JSON includes complete bytes, read and release handles, private sequence/issue/permit/recovery, protected fields, live decision samples, output writes, fixed scheduler losses, and kernel ELF and session hashes.",
"age는 앞서 수락한 seq3 발행 시각부터 센 틱이다. CRC는 프레임에 기록된 값과 실제 수신 바이트로 독립 계산한 값을 각각 표시한다. 프레임 거부 시 두 보호 COMPLETE에서 이전 순번·발행 시각·허가·복구 값이 유지됐고, 그 사이 COMMIT과 출력 전환도 없었다.",
"|Boot / 부팅|G|Local status / 로컬|COMMIT|Refusal age / 거부|Next seq4 age / 후속|Wire CRC / 계산 CRC|Fixed drops|Max COMPLETE gap lower..upper, ticks|",
"|---|---:|---|---|---:|---:|---|---:|---|"]
for s in scores:
    gap="..".join(map(str,s["completion_gap_max"]))
    if "stored_crc" in s:
        verdict=str(s["local"]);commit="SKIP";crc=f'{s["stored_crc"]:08x} / {s["calculated_crc"]:08x}'
    elif "denial_kernel" in s:
        verdict="PID 2 / −13";commit="SVC 33";crc="–"
    else:
        verdict="normal control";commit="–";crc="–"
    report.append(f'|{s["name"]}|{s.get("generation","–")}|{verdict}|{commit}|{s.get("reject_age","–")}|{s.get("next_age","–")}|{crc}|{s["fixed_loss"][0][0]}|{gap}|')
for s in scores:
    if s["response_max"][0]>312500:
        bounds=s["response_max"]
        report.append(f'{s["name"]} also exceeded the 5 ms release-to-COMPLETE response limit at {bounds[0]}–{bounds[1]} ticks ({age(bounds[0])}–{age(bounds[1])} ms). The largest upper completion-gap bound for the cohort was {age(max(v["completion_gap_max"][1] for v in scores))} ms. 이 부팅에서는 완료 간격뿐 아니라 릴리스부터 COMPLETE까지의 응답 시간도 5 ms를 초과했다.')
report.extend([
"## Endpoint authority and controls / 종단 권한 및 대조군",
"Kernel event 9 identifies the actual denied caller, operation and result. The supervisor’s own return and before/after snapshots bracket the kernel event. PID 0’s successful stage and publication rows, authenticated loan events, the protected byte snapshot and the receiver’s private copy all join to the same handle. PID 2 received synchronization words only. The early-denied SVC 33 has no post-loan type-6 event. A different PID releasing the owner’s handle (SVC 36) was outside this frozen native case.",
"커널 이벤트 9의 실제 호출 주체·연산·거부 코드를 감독 프로세스 전후 상태와 비교했다. 원 소유자가 단계별로 기록한 동일 핸들의 생성·게시·수신·해제를 묶었다. 다른 PID가 소유자의 핸들로 SVC 36을 호출하는 경우는 이 네이티브 시험에서 관찰하지 않았다.",
"|Policy|Generation|Staged/published/received handle|Supervisor bracket|Protected denial tick|PID / SVC / signed status|",
"|---|---:|---:|---|---:|---|"])
for s in authority:
    w=s["denial_private"];e=s["denial_kernel"]
    report.append(f'|{s["policy"]}|{s["generation"]}|{s["handle"]}|{w[1]}..{w[2]}|{e[1]}|{e[2]} / {e[3]} / −13|')
for s in scores:
    if s["case"] in ("healthy","invalid"):
        report.append(f'{s["policy"].upper()} {s["case"]} · Original receiver-local code sequence `{s["decision_codes"]}`.')
report.extend([
"Local codes are Length 1, CRC 2, Format 3, Generation 7, Sequence 8, Future 9, Expired 10, IssueOrder 11, NeedsOpen 17. Older-generation cases first genuinely operated generation 1 and then opened generation 2 at the scheduled +35 ms, with the new pair at +40/+50 ms and REARM at +55 ms. The duplicate/reordered/gap values were distinct at 3/2/5. The expired-candidate case reached its own wire-age check with the prior permit still fresh. The unchanged mixed invalid run includes post-latch NeedsOpen and has separate control status.",
f"The offline checker rejected all {len(trials)} deliberately altered record sets. They cover bytes, CRC, transported length, local reason, COMMIT, advancement, recovery, prior faults and freshness, subsequent freshness, authorized history, future issue, absent/incorrect PID identity, original handle continuity, protected prior permit, and an intervening fault. Perturbations were in-memory copies used by replay. The original captured files retain their SHA-256 digests.",
f"오프라인 재검증기는 기록 사본에 가한 {len(trials)}개 변형을 모두 탐지했다. 원본 RAM·UART에는 손대지 않았다. 정상 및 혼합 오류의 기존 결과는 위 코드열에서 확인할 수 있다.",
"## Offline replay / 오프라인 재검증",
"After unpacking the .tar.xz with GNU tar, run the following commands from the archive root. The replay uses Python 3.10 or later and GNU AArch64 binutils. Only the selected output directory is written. Compare generated JSON byte-for-byte with the supplied results.",
"```sh\nsha256sum --quiet -c SHA256SUMS\nPYTHONDONTWRITEBYTECODE=1 python3 scripts/replay.py . ../ipc397-replayed\ndiff -qr results ../ipc397-replayed\n```",
"원본 해시를 확인한 뒤 위 명령으로 RAM 페이지 테이블·ELF 심볼·UART를 다시 읽는다. 40개 원본 부팅의 JSON과 변형 검증 결과를 묶음 안의 결과와 바이트 단위로 대조할 수 있다."])
blocks=[]
for paragraph in report:
    if blocks and paragraph.startswith("|") and blocks[-1].startswith("|"):
        blocks[-1]+="\n"+paragraph
    else:
        blocks.append(paragraph)
(root/"REPORT.en-ko.md").write_text("\n\n".join(blocks)+"\n",encoding="utf8")
