"""Offline verdicts. Does not build a frame, send IPC, launch a guest, or use the DUT decoder."""
import struct
import zlib

SKIP=1<<63
MOD=1<<64
ERR={"bad-crc":2,"bad-header-crc":2,"bad-length":1,"bad-version":3,
     "bad-type":3,"bad-channel":3,"bad-data-id":3,"bad-validity":3,
     "bad-permit":3,"bad-reserved":3,"duplicate":8,"reordered":8,
     "gap":8,"old-generation":7,"future-issue":9,"expired-issue":10,"issue-order":11}
FIELDS=("version","type","length","channel","data","generation","sequence","issue","validity","permit","reserved","crc")


def unpack(h):
    return dict(zip(FIELDS,struct.unpack("<BBHHHQQQIB3sI",bytes.fromhex(h))))


def wire(case,h,g,issue,prior,hz):
    values=unpack(h)
    base=(1,1,44,1,257,g,4,issue,20,1,bytes(3))
    expected=dict(zip(FIELDS,base))
    changes={"bad-crc":("permit",0),"bad-header-crc":("version",0),
             "bad-length":("length",43),"bad-version":("version",2),"bad-type":("type",2),
             "bad-channel":("channel",2),"bad-data-id":("data",258),"bad-validity":("validity",19),
             "bad-permit":("permit",2),"bad-reserved":("reserved",b"\1\0\0"),
             "duplicate":("sequence",3),"reordered":("sequence",2),"gap":("sequence",5),
             "old-generation":("generation",1),"future-issue":("issue",prior+25*hz//1000),
             "expired-issue":("issue",prior-20*hz//1000),"issue-order":("issue",prior)}
    if case in changes:
        field,value=changes[case]
        expected[field]=value
    raw=bytes.fromhex(h)
    wanted=values.pop("crc")
    calc=zlib.crc32(raw[:40])
    correct=calc==wanted
    checksum_expected=case not in ("bad-crc","bad-header-crc")
    if not checksum_expected:
        clean=bytearray(raw[:40])
        clean[36 if case=="bad-crc" else 0]=1
        checksum_ok=not correct and zlib.crc32(clean)==wanted
    else:
        checksum_ok=correct
    return values==expected,checksum_ok,wanted,calc


def evaluate(a):
    tests=dict(a["provenance"])
    def t(name,ok):
        tests[name]=bool(ok)
    c=a["case"]; ev=a["events"]; s=a["sender_rows"]; r=a["received_rows"]
    def event(k):
        return [v for v in ev if v[0]==k]
    def fresh(i,v):
        return 0<=(v-i)*1000<hz*20
    def on(tick):
        state=0
        for v in event(2):
            if v[2]<=tick<v[3]: return None
            if v[3]<=tick: state=v[5]
        return state
    def no_disruption(early,late):
        return not any(early<=v[1]<=late and
                       (v[0] in (2,3,4) or v[0]==5 and v[2:5]==[2,59,1] and v[5]==0)
                       for v in ev)
    def committed(v):
        return v[0]==5 and v[2:5]==[1,60,2]
    def exactly(rows,label):
        t(label,len(rows)==1)
        return rows[0] if rows else None
    sh=a["sender_header"];rh=a["receiver_header"];uh=a["supervisor_header"]
    epoch,hz=rh[2:4]
    out={"case":c,"policy":a["policy"],"tests":tests,"hz":hz,"epoch":epoch,"first_exits":a["exits"],
         "terminal":a["terminal"],"safety_loss":a["safety_loss"],"fixed_loss":a["fixed_loss"],
         "decision_codes":[v[5] for v in r], "kernel":a["kernel"],"session":a["session_hash"]}
    t("all three original exit codes",a["exits"]==[[0,71],[1,72],[2,73]] and a["marker"]=="EXIT 71")
    t("agreeing clocks, selectors and zero app errors",sh[:1]==[0x53465030] and rh[:1]==[0x53465031] and uh[:1]==[0x53465032] and sh[1:4]==rh[1:4]==uh[1:4] and sh[4:]==[0] and rh[4:]==uh[4:]==[0,0] and hz==62500000)
    t("complete safety trace",a["safety_loss"]==[[0]] and all(len(v)==10 for v in ev) and len(a["activations"])==len(event(10))==17)
    if len(a["activations"])==len(event(10)) and len(event(10))>1:
        spans=[(e[2]-v[0],e[3]-v[0]) for v,e in zip(a["activations"],event(10))]
        gaps=[(b[2]-v[3],b[3]-v[2]) for v,b in zip(event(10),event(10)[1:])]
        out["response_max"]=[max(v[i] for v in spans) for i in (0,1)]
        out["completion_gap_max"]=[max(v[i] for v in gaps) for i in (0,1)]
    t("terminal virtual output low",a["terminal"]==0)
    t("supervisor observations",bool(a["supervisor_rows"]) and all(v[15]==1 for v in a["supervisor_rows"]))
    # Validate the three copies using the actual grant ID, never a sequence-only match.
    sender={}
    for k,v in enumerate(s):
        if v[3]!=1 and v[8] and v[9:11]==[0,0]:
            sender[v[8]]=a["sender_bytes"][k]
    pub=event(11);rx=event(7)
    out["joins"]=[]
    for k,v in enumerate(r):
        handle=v[2];h=a["received_bytes"][k]
        records=[z for z in rx if z[2]==handle]
        pubs=[z for z in pub if z[4]==handle and z[5]==0]
        read=[z for z in event(6) if z[2:5]==[1,35,0] and z[7]==handle and z[8]==44]
        release=[z for z in event(6) if z[2:5]==[1,36,0] and z[6]==handle]
        booljoin=(v[4]==44 and v[3]==0x01600000+(handle&3)*4096 and (handle&3)<3 and sender.get(handle)==h
                  and len(records)==len(pubs)==len(read)==len(release)==1
                  and b"".join(q.to_bytes(8,"little") for q in records[0][4:])[:44].hex()==h
                  and pubs[0][3]<=records[0][1]<=read[0][1]<=release[0][1]<=v[7]<=v[8])
        out["joins"].append(booljoin)
    t("every received frame joins sender, kernel and receiver by handle and time",len(rx)==len(r)>0 and all(out["joins"]))
    commits=[v for v in ev if committed(v)]
    good=[v for v in r if v[5:7]==[0,0]]
    t("private and protected commit chronology",len(commits)==len(good) and all(v[7]<=k[1]<=v[8] and [v[9],v[16],v[17],v[19]]==k[6:10] and k[5]==0 for v,k in zip(good,commits)))
    t("all local rejections skip commit and preserve last accepted data",all(v[6]==SKIP and v[12:16]==v[16:20] and not any(v[7]<=k[1]<=v[8] for k in commits) for v in r if v[5]))
    if c in ("healthy","invalid"):
        if c=="healthy":
            t("ordinary healthy control",len(r)==7 and [v[16] for v in good]==list(range(1,8)) and good[-1][18]==0 and [v[5] for v in event(2)]==[1,0])
        else:
            codes=[v[5] for v in r]
            t("ordinary invalid remains mixed, first three accepted then distinct live or latched refusals",len(good)==3 and codes[:3]==[0,0,0] and 2 in codes and 3 in codes and 17 in codes and [v[5] for v in event(2)]==[1,0])
        return out
    g=2 if c=="old-generation" else 1
    offset_ms=40 if g==2 else 0
    prior=epoch+(20+offset_ms)*hz//1000
    ack=a["active_ack"]; ip=a["active_ipc"]
    t("private and protected live LAST_SAMPLE confirmation",ack[:9]==[0x6c617374,3,0,g,3,prior,1,1,0] and ack[10:]==[g,3,3,prior] and fresh(prior,ack[9]) and on(ack[9])==1)
    t("supervisor checked LAST_SAMPLE and authorized bounded sender release",ip[:2]==[[1,0x6c617374,3,0],[0,0x696e707574,0x696e707574,0]])
    opens=[v for v in event(5) if v[2:6]==[2,59,1,0]]
    rearm=[v for v in event(5) if v[2:7]==[2,59,2,0,g]]
    t("actual OPEN and REARM in configured generation",any(v[6]==g for v in opens) and len(rearm)==1 and rearm[0][1]<ack[9] and any(v[2:7]==[1,60,4,0,g] and v[1]<ack[9] for v in event(5)))
    accepted=[v for v in good if v[9]==g]
    t("positive sequence progression", [v[16] for v in accepted]==[1,2,3,4,5])
    if g==2:
        t("genuine preceding authorized generation", [v[6] for v in opens]==[1,2] and [v[16] for v in good if v[9]==1]==[1,2,3] and any(v[5]==1 and v[1]<opens[-1][1] for v in event(2)))
    a3=exactly([v for v in accepted if v[16]==3],"one prior accepted seq3")
    a4=exactly([v for v in accepted if v[16]==4],"one following accepted seq4")
    a5=exactly([v for v in accepted if v[16]==5],"one final accepted seq5")
    if not a3 or not a4 or not a5: return out
    t("nominal prior issue period and seq3 enabled",len(accepted)>=3 and accepted[1][17]-accepted[0][17]==hz//100 and a3[17:20]==[prior,1,2] and a3[9:12]==[g,3,3] and on(a3[8])==1)
    next_issue=epoch+(offset_ms+(24 if c=="wrong-owner" else 30))*hz//1000
    valid4=wire("normal",a["received_bytes"][r.index(a4)],g,next_issue,prior,hz)
    t("following seq4 independently valid at real decision",all(valid4[:2]) and a4[12:16]==a3[16:20] and a4[17:19]==[next_issue,1] and next_issue>prior and fresh(prior,a4[7]) and fresh(next_issue,a4[7]) and on(a4[7])==on(a4[8])==1 and a4[9:12]==[g,3,4])
    withdrawal=unpack(a["received_bytes"][r.index(a5)])
    t("seq5 withdrawal at device",withdrawal["permit"]==0 and withdrawal["sequence"]==5 and withdrawal["generation"]==g and withdrawal["crc"]==zlib.crc32(bytes.fromhex(a["received_bytes"][r.index(a5)])[:40]) and a5[18:20]==[0,0] and a5[9:12]==[g,1,5] and any(a5[7]<=z[2]<=z[3]<=a5[8] and z[4:6]==[1,0] for z in event(2)) and on(a5[8])==0)
    out.update(generation=g,prior_issue=prior,next_issue=next_issue,next_decision=a4[7],next_age=a4[7]-prior,seq5=a5[16:20])
    def intact(earliest, latest):
        previously=[x for x in event(10) if a3[7]<=x[2] and x[3]<earliest]
        subsequently=[x for x in event(10) if latest<x[2] and x[3]<a4[7]]
        out["protected_completions"]=[previously[-1] if previously else None,subsequently[0] if subsequently else None]
        return all(v is not None and v[4:]==[0,g,3,prior,1,2] for v in out["protected_completions"])
    if c=="wrong-owner":
        w=a["wrong_owner"]
        records=[v for v in event(9) if v[2:6]==[2,33,MOD-13,g]]
        d=exactly(records,"kernel records argument-free denied acquire by actual PID 2")
        staged=[(i,v) for i,v in enumerate(s) if v[3]==1]; published=[(i,v) for i,v in enumerate(s) if v[3]==2]
        t("successful staging and publication use original handle",len(staged)==len(published)==1 and staged[0][1][8]==published[0][1][8]==a4[2] and staged[0][1][9:]==published[0][1][9:]==[0,0] and a["sender_bytes"][staged[0][0]]==a["sender_bytes"][published[0][0]]==a["received_bytes"][r.index(a4)])
        t("private authority result and protected prior state",len(w)==14 and w[0]==1 and w[3:]==[MOD-13,g,g,3,3,3,3,prior,prior,1,SKIP] and fresh(prior,w[1]) and fresh(prior,w[2]) and on(w[1])==on(w[2])==1)
        t("staging protocol before genuine protected denial then successful publication",bool(d and staged and published) and
          staged[0][1][2]<=w[1]<=d[1]<=w[2]<=published[0][1][1]<a4[7] and ip[2:]==[[0,0x737461676564,0x737461676564,0],[0,0x7075626c697368,0x7075626c697368,0]]
          and any(v[2:5]==[0,33,0] and v[7]==a4[2] and v[1]<d[1] for v in event(6))
          and any(v[2:5]==[0,34,0] and v[6]==a4[2] and v[1]>d[1] for v in event(6)))
        t("no receiver-local or post-loan record for the denied acquire",not any(v[5] for v in r) and not any(v[2:4]==[2,33] for v in event(6)))
        t("no disruption before accepted seq4",no_disruption(a3[8],a4[8]))
        t("independent kernel permit and recovery before and after denial",bool(d) and intact(w[1],w[2]))
        out.update(denial_kernel=d,denial_private=w,handle=a4[2],reject_decision=d[1] if d else None,reject_age=(d[1]-prior) if d else None,local=None,commit=None)
        return out
    bad=exactly([v for v in r if v[5]],"one independently observable rejection")
    if bad is None: return out
    i=r.index(bad); side=a["active_received"][i]; raw=a["received_bytes"][i]
    t("single sender release and publication after live acknowledgement",
      any(z[4]==10 and z[8]==bad[2] and ack[9]<=z[1]<=z[2]<bad[7] for z in s) and
      any(z[4]==bad[2] and ack[9]<=z[2]<=z[3]<bad[7] for z in pub))
    ok,crcok,stored,calc=wire(c,raw,g,epoch+(offset_ms+24)*hz//1000,prior,hz)
    t("exact independent field expectations and zlib CRC",ok and crcok)
    t("declared predicate observed and protected commit skipped",bad[5:7]==[ERR[c],SKIP])
    t("prior accepted issue fresh through negative decision",a3[8]<=ack[9]<bad[7]<a4[7] and fresh(prior,bad[7]) and fresh(prior,bad[8]) and on(bad[7])==on(bad[8])==1)
    t("unchanged private and protected state before and after rejection",bad[12:16]==bad[16:20]==a3[16:20] and side==[g,1,0,bad[7],g,3,3,prior,g,1,0,bad[8],g,3,3,prior] and bad[9:12]==[g,3,3])
    t("independent kernel permit and recovery before and after rejection",intact(bad[7],bad[8]))
    t("no commit, fault, transition or gate intervention before good input",not any(bad[7]<=z[1]<=bad[8] for z in commits) and no_disruption(a3[8],a4[8]))
    field=unpack(raw)
    if c=="future-issue": t("candidate issue in future",field["issue"]>bad[7])
    elif c=="expired-issue": t("candidate expired while prior stays fresh",field["issue"]<=bad[7] and not fresh(field["issue"],bad[7]) and fresh(prior,bad[7]))
    elif c=="issue-order": t("candidate age valid but equals prior issue",field["issue"]==prior and fresh(field["issue"],bad[7]))
    out.update(handle=bad[2],raw_hex=raw,stored_crc=stored,calculated_crc=calc,private_before=bad[12:16],private_after=bad[16:20],protected=side,local=bad[5],commit=bad[6],reject_decision=bad[7],reject_age=bad[7]-prior)
    return out
