#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:$PATH" LC_ALL=C TZ=UTC CARGO_BUILD_JOBS=1
unset RUSTFLAGS CARGO_TARGET_DIR PYTHONPATH
for name in $(compgen -e JNOX_); do unset "$name"; done
base=/home/ywcho/permit397-active-first
win=/mnt/d/codex/permit397-active-first
action=$1
if [[ $action = prepare ]]; then
    mkdir -p "$base"/{src,packet,packages}
    git init --quiet "$base/src"
    readlink -f /mnt/d/codex/.jnox-work/policy-v1/.git/objects > "$base/src/.git/objects/info/alternates"
    git -C "$base/src" sparse-checkout init --cone
    git -C "$base/src" sparse-checkout set arch boards kernel sdk tools examples services trace verification
    { date -u; uname -a; rustc -Vv; cargo -V; python3 -V; qemu-system-aarch64 --version; sha256sum "$(command -v qemu-system-aarch64)"; git --version; } > "$base/packet/host.txt"
    exit
fi
cd "$base/src"
rev=$2
[[ "$rev" =~ ^[0-9a-f]{40}$ ]]
if [[ $action = checkout ]]; then
    git checkout --quiet --detach "$rev"
    git diff --exit-code
    revdir="$base/packet/source"
    mkdir -p "$revdir"
    git show -s --pretty=raw "$rev" > "$revdir/commit.txt"
    dirs=(arch boards examples kernel sdk services tools trace verification)
    git ls-tree -r "$rev" -- "${dirs[@]}" > "$revdir/tree.txt"
    git archive --format=tar "$rev" "${dirs[@]}" > "$revdir/production.tar"
    exit
fi
[[ $(git rev-parse HEAD) = "$rev" ]]
[[ -z $(git status --porcelain --untracked-files=no) ]]
dest="$base/packet"; apps="$dest/apps"
app=examples/native-safety-channel
if [[ $action = apps ]]; then
    mkdir "$apps"
    for role in sender receiver supervisor; do
        (set -x; sh sdk/native-aarch64/build-rust.sh "$app/$role/Cargo.toml" "$apps/$role.elf") > "$apps/$role.log" 2>&1
    done
    exit
fi
[[ $action = matrix ]]
policies=(fifo rr)
cases=(bad-crc bad-header-crc bad-length bad-version bad-type bad-channel bad-data-id bad-validity bad-permit bad-reserved duplicate reordered gap old-generation future-issue expired-issue issue-order wrong-owner healthy invalid)
mkdir "$dest/runs"
printf 'ordinal\tpolicy\tcase\tbuild\tcapture\n' > "$dest/ledger.tsv"
n=0
for policy in "${policies[@]}"; do
    q=(); if [[ $policy = rr ]]; then q=(--quantum-ticks 625000); fi
    for caseid in "${cases[@]}"; do
        n=$((n+1)); printf -v tag '%02d-%s-%s' "$n" "$policy" "$caseid"
        run="$dest/runs/$tag"; pkg="$base/packages/$tag"
        mkdir "$run"; date -u +%FT%T.%NZ > "$run/start.utc"
        prior=$(pgrep -a -x qemu-system-aar || true)
        if [[ -n $prior ]]; then printf '%s\n' "$prior" >&2; exit 90; fi
        printf 'START %s\n' "$tag"
        caprc=NA; buildrc=0
        (set -x; python3 tools/build_native_el0.py --out "$pkg" --board virt --policy "$policy" "${q[@]}" --elf "$apps/sender.elf" --peer-elf "$apps/receiver.elf" --peer-elf "$apps/supervisor.elf" --arg "$caseid" --peer-arg "$caseid" --peer2-arg "$caseid" --priority 7 --peer-priority 6 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --safety-channel --loan-route 0:1) > "$run/build.log" 2>&1 || buildrc=$?
        if [[ $buildrc = 0 ]]; then
            cp "$pkg/manifest.json" "$run/manifest.json"
            cp "$pkg/build.log" "$run/kernel-build.log"
            caprc=0
            (set -x; python3 tools/native_el0_capture.py "$run/cap" "$pkg/kernel.elf" "$apps/sender.elf" "$app/sender/src/main.rs" "$rev" --manifest "$pkg/manifest.json" --plain --expect-exit 71 --timeout 25 --uart-limit 8388608) > "$run/capture.log" 2>&1 || caprc=$?
        fi
        date -u +%FT%T.%NZ > "$run/finish.utc"
        printf '%s\t%s\t%s\t%s\t%s\n' "$n" "$policy" "$caseid" "$buildrc" "$caprc" >> "$dest/ledger.tsv"
        printf 'FINISH %s build=%s capture=%s\n' "$tag" "$buildrc" "$caprc"
        if [[ -f "$run/cap/uart.bin" ]]; then
            grep -E '^NATIVE EL0 EXIT PID|^NATIVE SAFETY DROPPED' "$run/cap/uart.bin" || true
        fi
    done
done
