"""Independent replay of a sealed #397 cohort. Writes only to the output directory."""
import argparse
import copy
import csv
import hashlib
import json
import tarfile
from pathlib import Path

from decode import read_run
from score import ERR, evaluate


def save(path,obj):
    path.write_text(json.dumps(obj,sort_keys=True,indent=1)+"\n",encoding="utf8")


def mutations(records):
    trials=[]
    def check(case,name,alter,required):
        data=copy.deepcopy(records[("fifo",case)])
        alter(data)
        dropped=[k for k,v in evaluate(data)["tests"].items() if not v]
        if required not in dropped:
            raise ValueError("replay accepted perturbation: "+name)
        trials.append(dict(case=case,change=name,required_failed_check=required,all_failed_checks=dropped))
    def bad(a):
        return next(i for i,v in enumerate(a["received_rows"]) if v[5])
    def put(container,i,value):
        container[i]=value
    def replace_at(a,name,i,j,value):
        a[name][i][j]=value
    def changed(s,i):
        b=bytearray.fromhex(s); b[i]^=1
        return b.hex()
    check("bad-crc","receiver copy changed",lambda a:put(a["received_bytes"],bad(a),changed(a["received_bytes"][bad(a)],38)),"every received frame joins sender, kernel and receiver by handle and time")
    check("bad-channel","stored CRC changed",lambda a:put(a["received_bytes"],bad(a),changed(a["received_bytes"][bad(a)],40)),"exact independent field expectations and zlib CRC")
    check("bad-length","transport truncated",lambda a:replace_at(a,"received_rows",bad(a),4,43),"every received frame joins sender, kernel and receiver by handle and time")
    check("duplicate","latch returned NeedsOpen",lambda a:replace_at(a,"received_rows",bad(a),5,17),"declared predicate observed and protected commit skipped")
    check("reordered","attempted COMMIT mislabelled successful",lambda a:replace_at(a,"received_rows",bad(a),6,0),"declared predicate observed and protected commit skipped")
    check("gap","private accepted sequence advanced",lambda a:replace_at(a,"received_rows",bad(a),16,4),"unchanged private and protected state before and after rejection")
    check("bad-version","private recovery changed",lambda a:replace_at(a,"received_rows",bad(a),19,0),"all local rejections skip commit and preserve last accepted data")
    check("bad-type","device faulted before decision",lambda a:replace_at(a,"active_received",bad(a),5,5),"unchanged private and protected state before and after rejection")
    check("bad-reserved","prior stale exactly at 20 ms",lambda a:replace_at(a,"received_rows",bad(a),7,a["received_rows"][bad(a)][13]+1250000),"prior accepted issue fresh through negative decision")
    check("bad-permit","following seq4 decision at old expiry",lambda a:replace_at(a,"received_rows",bad(a)+1,7,a["received_rows"][bad(a)][13]+1250000),"following seq4 independently valid at real decision")
    check("old-generation","removed prior generation OPEN from raw journal",lambda a:a["events"].remove(next(e for e in a["events"] if e[0]==5 and e[2:7]==[2,59,1,0,1])),"genuine preceding authorized generation")
    check("future-issue","receiver time later than allegedly future wire issue",lambda a:replace_at(a,"received_rows",bad(a),7,a["sender_rows"][bad(a)][7]+1),"candidate issue in future")
    check("wrong-owner","dropped protected denial record",lambda a:a["events"].remove(next(e for e in a["events"] if e[0]==9 and e[2:4]==[2,33])),"kernel records argument-free denied acquire by actual PID 2")
    check("wrong-owner","wrong PID in kernel denial",lambda a:put(next(e for e in a["events"] if e[0]==9 and e[2:4]==[2,33]),2,0),"kernel records argument-free denied acquire by actual PID 2")
    check("wrong-owner","owner published a different handle",lambda a:put(next(s for s in a["sender_rows"] if s[3]==2),8,999),"successful staging and publication use original handle")
    check("issue-order","protected completion's permit changed",lambda a:put(next(z for z in a["events"] if z[0]==10 and z[2]>a["received_rows"][bad(a)][8]),8,0),"independent kernel permit and recovery before and after rejection")
    check("expired-issue","post-rejection fault inserted",lambda a:a["events"].append([3,a["received_rows"][bad(a)][8]+1,0,0,0,0,0,0,0,0]),"no commit, fault, transition or gate intervention before good input")
    return trials


def blob_hash(data):
    return hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()


def source_check(root):
    source=root/"source"
    expected={line.split("\t",1)[1]:line.split()[2] for line in (source/"tree.txt").read_text().splitlines()}
    found={}
    with tarfile.open(source/"production.tar") as archive:
        for item in archive.getmembers():
            if item.isfile(): found[item.name]=blob_hash(archive.extractfile(item).read())
            elif item.issym(): found[item.name]=blob_hash(item.linkname.encode())
    if found!=expected:
        raise ValueError("archived production source differs from frozen Git blobs")
    complete=(source/"complete-tree.txt").read_text().splitlines()
    if not set((source/"tree.txt").read_text().splitlines()).issubset(complete):
        raise ValueError("build inputs are absent from the complete recursive tree")
    from collections import defaultdict
    tree={}
    for line in complete:
        left,name=line.split("\t",1); mode,kind,obj=left.split()
        tree[name]=(mode,bytes.fromhex(obj))
    while any("/" in name for name in tree):
        maximum=max(name.count("/") for name in tree)
        groups=defaultdict(dict)
        for name in list(tree):
            if name.count("/")==maximum:
                parent,leaf=name.rsplit("/",1)
                groups[parent][leaf]=tree.pop(name)
        for parent,items in groups.items():
            tree[parent]=("40000",git_tree(items))
    tree_sha=git_tree(tree).hex()
    for sha in ("3dac7eff2fa4b405d59f09bca105c56ca8b599ba","85f9828f66ac766a13b73ced05b5bb90a4898104"):
        raw=(source/(sha+".commit")).read_bytes()
        actual=hashlib.sha1(b"commit "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
        if actual!=sha or raw.splitlines()[0]!=b"tree "+tree_sha.encode():
            raise ValueError("source identity mismatch "+sha)
    return tree_sha


def git_tree(items):
    order=sorted(items,key=lambda n:(n+("/" if items[n][0]=="40000" else "")).encode())
    raw=b"".join(items[n][0].encode()+b" "+n.encode()+b"\0"+items[n][1] for n in order)
    return hashlib.sha1(b"tree "+str(len(raw)).encode()+b"\0"+raw).digest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("root",type=Path)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    root=args.root.resolve(); out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=True); (out/"decoded").mkdir(exist_ok=True)
    tree=source_check(root)
    records={}; scores=[]; retired=[]
    with (root/"ledger.tsv").open() as f:
        ledger=list(csv.DictReader(f,delimiter="\t"))
    cases=list(ERR)+["wrong-owner","healthy","invalid"]
    if [(x["policy"],x["case"]) for x in ledger]!=[(p,c) for p in ("fifo","rr") for c in cases]:
        raise ValueError("incomplete first-attempt ledger")
    for row in ledger:
        tag=f'{int(row["ordinal"]):02d}-{row["policy"]}-{row["case"]}'
        run=root/"runs"/tag
        if row["build"]!="0" or row["capture"]!="0":
            retired.append(tag)
        try:
            data=read_run(root,run); summary=evaluate(data)
            if data["revision"]!="3dac7eff2fa4b405d59f09bca105c56ca8b599ba":
                raise ValueError("unexpected capture revision")
            save(out/"decoded"/(tag+".json"),data)
            records[(row["policy"],row["case"])]=data
            summary["name"]=tag
            scores.append(summary)
        except Exception as err:
            scores.append(dict(name=tag,error=repr(err),tests={"raw decode succeeded":False}))
    save(out/"by-boot.json",scores)
    rejected=sorted(set(retired+[s["name"] for s in scores if not all(s["tests"].values())]))
    if rejected:
        raise SystemExit("REPLAY FAILED: "+", ".join(rejected))
    trials=mutations(records)
    save(out/"mutation-tests.json",trials)
    print(f"{len(scores)} original boots verified; {len(trials)} replay mutations rejected; source tree {tree}")


if __name__=="__main__":
    main()
