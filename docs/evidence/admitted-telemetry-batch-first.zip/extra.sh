set -eu
r=$HOME/iv214e015
out=/mnt/d/codex/jnox214-review-independent
export PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR=$r/extra-build JNOX_PROFILE=batch JNOX_BOARD=virt JNOX_BATCH_TRACE=1
for p in sjf srtf hrrn; do
 cd "$r/src/kernel"
 export JNOX_APP=batch-$p
 d=$r/ev/legacy-trace-$p
 mkdir "$d"
 cargo build --locked --release > "$d/build" 2>&1
 cd "$d"
 cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" kernel.elf
 timeout 10s qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -accel tcg -smp 1 -m 128M -nographic -nic none -monitor none -serial file:uart.log -d int -D irq.log -kernel kernel.elf > host 2>&1 || test $? -eq 124
 sha256sum kernel.elf uart.log irq.log build host > SHA256SUMS
 cp -r "$d" "$out/"
 PYTHONPATH="$r/src/tools" python3 -c 'import batch_runtime_observer as v,sys; assert v.validate(open("uart.log","rb").read(),sys.argv[1].encode())' batch-$p
done
