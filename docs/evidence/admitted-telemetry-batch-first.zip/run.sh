set -eu
out=/mnt/d/codex/jnox214-review-independent
r=$HOME/iv214e015
mkdir -p "$r/src" "$r/ev"
tar -C "$out/src" --exclude=.git -cf - . | tar -C "$r/src" -xf -
export PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR=$r/build JNOX_BOARD=virt JNOX_PROFILE=batch JNOX_BATCH_WORKLOAD=telemetry
cd "$r/src/kernel"
(rustc -Vv; cargo -V; qemu-system-aarch64 --version; stat -f -c %T .) > "$r/ev/tools"
for mode in normal trace; do for policy in sjf srtf hrrn; do
 dir=$r/ev/$mode-$policy
 mkdir "$dir"
 export JNOX_APP=batch-$policy
 if [ "$mode" = trace ]; then export JNOX_BATCH_TRACE=1; else unset JNOX_BATCH_TRACE; fi
 cargo build --locked --release > "$dir/build" 2>&1
 cp "$r/build/aarch64-unknown-none/release/jnox-kernel" "$dir/kernel.elf"
 (cd "$dir"; set +e; timeout 10s qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -accel tcg -smp 1 -m 128M -nographic -nic none -monitor none -serial file:uart.log -d int -D irq.log -kernel kernel.elf > host 2>&1; echo $? > exit; sha256sum kernel.elf uart.log irq.log build host exit > SHA256SUMS)
 cp -r "$dir" "$out/"
done; done