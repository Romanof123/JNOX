set -eu
out=/mnt/d/codex/jnox214-review-independent
r=$HOME/iv214e015
export PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo CARGO_BUILD_JOBS=1 JNOX_BOARD=virt JNOX_PROFILE=batch
mkdir -p "$r/base" "$out/legacy"
tar -xf "$out/base.tar" -C "$r/base"
cp "$r/ev/tools" "$out/tools.txt"
for p in sjf srtf hrrn; do for tree in base src; do
 cd "$r/$tree/kernel"
 export JNOX_APP=batch-$p CARGO_TARGET_DIR=$r/legacy-$tree
 cargo build --release --locked > "$out/legacy/$tree-$p.log" 2>&1
 cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" "$out/legacy/$tree-$p.elf"
done; done
cd "$r/src"
rustc --edition=2024 --test tools/scheduling_tests.rs -o "$r/tests" > "$out/compile-tests.log" 2>&1
"$r/tests" --test-threads=1 > "$out/tests.log"
cd kernel
export JNOX_APP=batch-sjf
if JNOX_BATCH_WORKLOAD=bad cargo build --release --locked > "$out/bad-workload.log" 2>&1; then exit 1; fi
if env -u JNOX_APP -u JNOX_PROFILE JNOX_BATCH_WORKLOAD=telemetry cargo build --release --locked > "$out/bad-profile.log" 2>&1; then exit 1; fi