struct Summary {
    count: u64,
    min: u16,
    max: u16,
    sum: u64,
    at_least_42: u64,
}

enum InputError {
    Empty = 3,
    Invalid = 4,
}

fn summarize(frame: &[u8]) -> Result<Summary, InputError> {
    if frame.is_empty() {
        return Err(InputError::Empty);
    }
    let mut summary = Summary {
        count: 0,
        min: u16::MAX,
        max: 0,
        sum: 0,
        at_least_42: 0,
    };
    let mut value = 0u16;
    let mut has_digit = false;
    for &byte in frame {
        match byte {
            b'0'..=b'9' => {
                value = value
                    .checked_mul(10)
                    .and_then(|v| v.checked_add(u16::from(byte - b'0')))
                    .ok_or(InputError::Invalid)?;
                has_digit = true;
            }
            b'\n' if has_digit => {
                // The largest admitted frame contains only 32 bytes of u16 records.
                summary.count += 1;
                summary.sum += u64::from(value);
                summary.min = summary.min.min(value);
                summary.max = summary.max.max(value);
                summary.at_least_42 += u64::from(value >= 42);
                value = 0;
                has_digit = false;
            }
            _ => return Err(InputError::Invalid),
        }
    }
    if has_digit {
        Err(InputError::Invalid)
    } else {
        Ok(summary)
    }
}

fn main(){
    let bad: &[&[u8]] = &[b"\n",b"7",b"+7\n",b"-1\n",b"1 \n",b"1\r\n",b"1\0\n",b"0\n\n",b"11\n65536\n",b"65540\n",b"999999999\n",b"\xff\n"];
    for f in bad { assert!(matches!(summarize(f),Err(InputError::Invalid))); }
    assert!(matches!(summarize(b""),Err(InputError::Empty)));
    for i in 0..=65535 {
        let frame=format!("000{i}\n");
        let s=summarize(frame.as_bytes()).ok().unwrap();
        assert_eq!((s.count,s.min,s.max,s.sum,s.at_least_42),(1,i as u16,i as u16,i as u64,u64::from(i>=42)));
    }
    let s=summarize(b"0\n".repeat(16).as_slice()).ok().unwrap();assert_eq!(s.count,16);
    println!("65536 valid u16 values with leading zeros; 12 malformed frames; empty frame; 32-byte maximum-record-count frame passed");
}