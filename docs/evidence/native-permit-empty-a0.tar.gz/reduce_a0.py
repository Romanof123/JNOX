"""Offline A-phase counter joins for the frozen #389 four-arm capture packet."""
import argparse
import csv
import hashlib
import io
import json
import lzma
import statistics
import sys
import tarfile
from collections import Counter, defaultdict
from pathlib import Path


PACKET = "899be455ecc6ac46ef9fd8c87715858c51c62eecda628ce3a60e859bdd87612c"
MANIFEST = "fe0fa8c67e58b5ec93bb2f7c4c8607209825662765dcd4dbdc305b1bab275ce7"
ARMS = {"52e4a8b23":"base", "94c54b7da":"crc", "ca5e50add":"inline", "e007c569f":"both"}
U = 2**64
SKIP = 2**63
HZ = 62_500_000


class Refused(ValueError):
    pass


def need(ok, why):
    if not ok:
        raise Refused(why)


def only(values, why):
    need(len(values) == 1, f"{why}: expected one, found {len(values)}")
    return values[0]


def order(*points):
    need(all(a <= b for a,b in zip(points,points[1:])), "counter order")


def sha(x):
    return hashlib.sha256(x).hexdigest()


def selected(name):
    return (name in ("SHA256SUMS", "results/phases.csv", "results/boots.json") or
            (name.startswith("runs/") and "-fused-" in name and
             name.endswith(("/cap/uart.bin","/cap/session.json","/cap/launch.json"))))


def source_files(path):
    if path.is_dir():
        raw = (path/"SHA256SUMS").read_bytes()
        need(sha(raw) == MANIFEST, "source manifest SHA-256")
        names = [line.split("  ",1)[1].removeprefix("./") for line in raw.decode().splitlines()]
        docs = {n:(path/n).read_bytes() for n in ["SHA256SUMS", *names] if selected(n)}
    else:
        need(sha(path.read_bytes()) == PACKET, "source archive SHA-256")
        docs = {}
        with lzma.open(path,"rb") as raw, tarfile.open(fileobj=raw,mode="r|",bufsize=256*1024) as tf:
            for m in tf:
                name = m.name.removeprefix("./")
                if selected(name):
                    need(m.isfile() and name not in docs, "duplicate/nonregular source input")
                    docs[name] = tf.extractfile(m).read()
    need(sha(docs["SHA256SUMS"]) == MANIFEST, "source manifest SHA-256")
    for line in docs["SHA256SUMS"].decode("utf8").splitlines():
        digest, name = line.split("  ",1)
        name = name.removeprefix("./")
        if selected(name):
            need(sha(docs[name]) == digest, f"source member SHA-256: {name}")
    return docs


def receipt(docs, boot):
    run = boot["run"]
    base = f"runs/{run}/cap/"
    session = json.loads(docs[base+"session.json"])
    uart, launch = docs[base+"uart.bin"], docs[base+"launch.json"]
    need(session["marker"] == "EXIT 71", "session terminal")
    need(sha(uart) == session["hashes"]["uart.bin"], "receipt UART SHA-256")
    need(sha(launch) == session["hashes"]["launch.json"], "receipt launch SHA-256")
    launch = json.loads(launch)
    manifest = launch["argument_package"]
    need(launch["revision"] == manifest["commit"] == boot["rev"] and not manifest["tracked_changes"],
         "revision join")
    need(manifest["policy"] == boot["policy"] and manifest["slots"][1]["argv"][1:] ==
         [boot["case"],"fused-phase"] and boot["functional"], "boot identity")
    return uart


def journals(uart):
    widths = {"NATIVE QUAL ROW":13, "NATIVE QUAL COUNTS":4, "NATIVE SAFETY EVENT":10,
              "NATIVE SAFETY DROPPED":1, "NATIVE FIXED EVENT":21, "NATIVE FIXED DROPPED":1,
              "NATIVE EL0 EXIT PID":2}
    groups = defaultdict(list)
    for line in uart.decode("ascii").splitlines():
        for tag,width in widths.items():
            if line.startswith(tag):
                parts = line[len(tag):].split()
                need(len(parts) == width and all(v.isdecimal() for v in parts), "bad UART record")
                row = list(map(int,parts))
                need(max(row) < U, "non-u64 UART value")
                groups[tag].append(row)
                break
    q,s,f = (groups[k] for k in ("NATIVE QUAL ROW","NATIVE SAFETY EVENT","NATIVE FIXED EVENT"))
    need(groups["NATIVE QUAL COUNTS"] == [[HZ,len(q),len(q),0]] and q, "QUAL count or loss")
    need(all(i==v[0] for i,v in enumerate(q)), "QUAL ordinal")
    need(groups["NATIVE SAFETY DROPPED"] == [[0]] and s[0][0]==1 and s[0][2]==HZ, "SAFETY count/loss")
    need(groups["NATIVE EL0 EXIT PID"] == [[0,71],[1,72],[2,73]], "terminal receipts")
    order(*(r[1] for r in s))
    order(*(r[0] for r in f))
    loss = only(groups["NATIVE FIXED DROPPED"], "FIXED loss")[0]
    return q,s,f,loss


def fixed_split(f, loss, lo, hi, op, multiple=False):
    seen = [r for r in f if lo <= r[0] <= hi and r[1]==op and r[3]==1]
    if seen:
        need(multiple or len(seen)==1, f"ambiguous SVC{op}")
        return seen[0][0]
    need(loss and f[-1][0] < hi, f"missing retained SVC{op}")
    return None


def bands(a, b, start, stop):
    return max(0,start-b), stop-a


def analyze(boot, index, trace, reference):
    q,s,f,loss = trace
    run = boot["run"]
    pos, short, _, policy, case = run.split("-")
    job = index//2
    ctl = boot["controller"][index]
    epoch = boot["headers"][1][2]
    target = epoch + 312_500*job
    marks = [v for v in q if v[1:5]==[1,1,job,1]]
    need([v[5] for v in marks]==[1,2,3] and all(v[6]==target and v[10]==0 for v in marks)
         and len(ctl)==18 and ctl[0]==target and boot["headers"][1][3]==HZ, "RAM/marker epoch or ordinal")
    arm,stage,end = marks
    span = q[arm[0]+1:stage[0]]
    wait = only([v for v in span if v[1:3]==[2,62] and v[3]==arm[8] and v[6]&2 and not v[7]&2
                 and v[8]==1], "pretarget wait")
    ready = only([v for v in span if v[1]==2 and not v[6]&2 and v[7]&2], "ready")
    dispatch = only([v for v in span if v[1]==2 and v[8]!=1 and v[9]==1], "dispatch")
    need(ready[0]==dispatch[0] and dispatch[2]==4 and dispatch[12]==arm[9], "scheduler/return PC")
    irq = only([v for v in span if v[1]==3 and v[4]==30 and v[5]==target], "target IRQ")
    cmp = [v for v in q[:irq[0]] if v[1]==5][-1]
    need(cmp[4:7]==[1,target,target] and cmp[7]&3==1 and irq[6]&7==5 and irq[9]==1
         and wait[0]<irq[0]<ready[0], "armed comparator/idle IRQ")
    order(wait[5],target,irq[2],irq[3],ready[4],ready[5],irq[11],dispatch[11],stage[7])
    order(cmp[2],cmp[3],irq[2])
    nextarm = only([v for v in q[end[0]+1:] if v[1:6]==[1,1,job,2,1]], "next B arm")
    park = only([v for v in q[nextarm[0]+1:] if v[1:3]==[2,62] and v[3]==nextarm[8]
                 and v[8]==1 and v[6]&2 and not v[7]&2], "post-phase park")
    order(end[7],end[8],nextarm[7],nextarm[8],park[4],park[5])
    check,complete = [v for v in q[stage[0]+1:end[0]] if v[1:4]==[4,1,63]]
    need(check[4]==1 and complete[4]==3 and check[8]==complete[8]==0, "fused decisions")
    events = [r for r in s if stage[7]<=r[1]<=end[7]]
    recv = only([v for v in events if v[0]==6 and v[2:4]==[1,35]], "receive")
    need(recv[4]==ctl[3] and recv[4] in (0,U-11), "RAM receive status")
    a = dict(run=run, position=int(pos), order_block=(int(pos)-1)//8+1 if case=="healthy" else "",
             rev=boot["rev"],arm=ARMS[short],policy=policy,case=case,phase=f"A{job}",job=job,
             state="empty" if recv[4]==U-11 else "frame",fixed_dropped=loss)
    # The source report provides independent phase/row and park cross-checks.
    for key,value in dict(nominal=target,stage1=arm[0],stage2=stage[0],stage3=end[0],
                          wait_row=wait[0],ready_row=ready[0],dispatch_row=dispatch[0],block_row=park[0],
                          phase_lo=park[4]-target,phase_hi=park[5]-target,check_row=check[0],
                          complete_row=complete[0],receive_journal=recv[1]).items():
        need(reference[key]==str(value), f"source phase CSV: {key}")
    if a["state"]=="frame":
        need(reference["kind"]!="empty", "frame inventory")
        return a
    need(reference["kind"]=="empty" and [v[0] for v in events]==[12,5,6,12,5,10] and
         [v for v in q[stage[0]+1:end[0]] if v[1]==4]==[check,complete], "empty event sequence")
    ck,cks,_,co,cos,fin = events
    need(ck[3]==1 and co[3]==3 and cks[2:6]==[1,63,1,0] and cos[2:6]==[1,63,3,0]
         and ck[4:7]==cks[6:9]==co[4:7]==cos[6:9]==fin[5:8] and fin[4]==0
         and recv[9]==ck[4] and recv[5:9]==[0,0,0,0], "empty protected state")
    need(ctl[4:7]==[SKIP,SKIP,0] and ctl[11:13]==ctl[13:15]==fin[6:8], "RAM empty result/state")
    need(ctl[7:10]==([1,0,SKIP] if job==0 else [SKIP]*3), "private session-open identity")
    order(stage[7],check[5],check[6],ck[2],ck[1],cks[1],ctl[1],check[7],recv[1],
          complete[5],complete[6],fin[2],co[2],co[1],cos[1],fin[3],fin[1],ctl[2],complete[7],end[7])
    t35 = fixed_split(f,loss,check[7],recv[1],35)
    info = fixed_split(f,loss,recv[1],complete[5],61,multiple=True)
    a.update(private_open=int(job==0),private_fault=ctl[17],private_sequence=ctl[13],
             injected_overrun=int(case=="overrun" and job==4), qual_wait=wait[0],qual_irq=irq[0],
             qual_compare=cmp[0],qual_ready=ready[0],qual_dispatch=dispatch[0],qual_park=park[0],
             target=target,irq_entry=irq[2],irq_snapshot=irq[3],irq_pre_eret=irq[11],
             ready_lo=ready[4],ready_hi=ready[5],dispatch_pre_eret=dispatch[11],stage2=stage[7],
             check_entry=check[5],check_before=check[6],check_operand=ck[2],check_audit=ck[1],
             check_status=cks[1],ram_check=ctl[1],check_after=check[7],fixed35=t35,
             fixed35_observed=int(t35 is not None),recv_audit=recv[1],fixed61=info,
             fixed61_observed=int(info is not None),complete_entry=complete[5],complete_before=complete[6],
             complete_service_start=fin[2],complete_operand=co[2],complete_audit=co[1],
             complete_status=cos[1],complete_service_end=fin[3],ram_complete=ctl[2],complete_after=complete[7],
             stage3=end[7],next_arm=nextarm[7],park_lo=park[4],park_hi=park[5])
    times = {
        "target_irq":(target,irq[2]), "irq_ready_before":(irq[2],ready[4]),
        "ready_decision_width":(ready[4],ready[5]), "ready_after_user_eret":(ready[5],dispatch[11]),
        "user_eret_stage2":(dispatch[11],stage[7]),"stage2_check":(stage[7],check[5]),
        "target_check_entry":(target,check[5]), "check_service":(check[5],check[7]),
        "check_entry_pre":(check[5],check[6]),"check_pre_operand":(check[6],ck[2]),
        "check_operand_audit":(ck[2],ck[1]), "check_audit_status":(ck[1],cks[1]),
        "check_status_ram":(cks[1],ctl[1]), "check_ram_after":(ctl[1],check[7]),
        "check_after_recv":(check[7],recv[1]), "recv_complete_entry":(recv[1],complete[5]),
        "complete_service":(complete[5],complete[7]),"complete_after_stage3":(complete[7],end[7]),
        "stage3_next_arm":(end[7],nextarm[7]),"next_arm_park_before":(nextarm[7],park[4]),
        "park_width":(park[4],park[5])}
    for name,(start,stop) in times.items():
        a[name+"_ticks"]=stop-start
    for name,(lo,hi) in {"target_ready":(target,target),"ready_user":(ready[4],ready[5]),
            "user_check":(dispatch[11],stage[7]),"irq_ready":(irq[2],irq[2]),
            "complete_after_park":(complete[7],complete[7]),"target_park":(target,target)}.items():
        left,right = {"target_ready":ready[4:6],"ready_user":(dispatch[11],stage[7]),
                      "user_check":(check[5],check[5]),"irq_ready":ready[4:6],
                      "complete_after_park":park[4:6],"target_park":park[4:6]}[name]
        a[name+"_lo_ticks"],a[name+"_hi_ticks"]=bands(lo,hi,left,right)
    for label,stamp,start,finish in [("35",t35,check[7],recv[1]),("61",info,recv[1],complete[5])]:
        # If the fixed prefix is exhausted, the primary journal still brackets each missing split.
        earliest = stamp if stamp is not None else max(start,f[-1][0])
        latest = stamp if stamp is not None else finish
        order(start,earliest,latest,finish)
        first,second = ("check_after_svc35","svc35_recv") if label=="35" else ("recv_info","info_complete")
        a[first+"_lo_ticks"],a[first+"_hi_ticks"]=earliest-start,latest-start
        a[second+"_lo_ticks"],a[second+"_hi_ticks"]=finish-latest,finish-earliest
        if stamp is not None:
            a[first+"_ticks"],a[second+"_ticks"]=stamp-start,finish-stamp
    return a


def save(path, rows):
    names = list(dict.fromkeys(k for r in rows for k in r))
    with path.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=names,lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def summarize(rows):
    # First make an equally weighted median for each boot, cohort, metric.
    by_boot=defaultdict(list)
    for row in rows:
        if row["state"]!="empty": continue
        cohort = "A0" if row["job"]==0 else ("injected_A4" if row["injected_overrun"] else "later_empty_A")
        for k,v in row.items():
            if k.endswith("_ticks"):
                key=(row["case"],row["policy"],row["arm"],row["run"],cohort,k)
                by_boot[key].append(v)
    groups=defaultdict(list)
    for (case,policy,arm,run,cohort,k),vals in by_boot.items():
        for p,a in ((policy,arm),(policy,"all"),("all","all")):
            groups[case,p,a,cohort,k].append((len(vals),min(vals),statistics.median(vals),max(vals)))
    return [dict(case=case,policy=p,arm=a,cohort=c,metric=k,boots=len(points),
                 phases=sum(v[0] for v in points),min_us=min(v[1] for v in points)/62.5,
                 median_of_boot_medians_us=statistics.median(v[2] for v in points)/62.5,
                 max_us=max(v[3] for v in points)/62.5)
            for (case,p,a,c,k),points in sorted(groups.items())]


def contrasts(rows):
    cases={(r["policy"],r["order_block"],r["arm"]):r for r in rows if r["case"]=="healthy" and r["job"]==0}
    output=[]
    for policy in ("fifo","rr"):
        for block in range(1,5):
            for old,new in [("base","inline"),("crc","both")]:
                before,after=cases[policy,block,old],cases[policy,block,new]
                low=after["target_park_lo_ticks"]-before["target_park_hi_ticks"]
                high=after["target_park_hi_ticks"]-before["target_park_lo_ticks"]
                record=dict(policy=policy,order_block=block,before=old,after=new,
                            before_run=before["run"],after_run=after["run"],
                            target_park_delta_lo_us=low/62.5,target_park_delta_hi_us=high/62.5)
                for k in ("target_check_entry","check_service","check_audit_status","check_after_svc35","svc35_recv"):
                    record[k+"_delta_us"]=(after[k+"_ticks"]-before[k+"_ticks"])/62.5
                output.append(record)
    return output


def main():
    from mutation_checks import exercise
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("source",type=Path)
    p.add_argument("output",type=Path)
    args=p.parse_args()
    need(not args.output.exists() or (args.output.is_dir() and not any(args.output.iterdir())), "select empty output")
    docs=source_files(args.source)
    boots=json.loads(docs["results/boots.json"])
    refs={(r["run"],r["phase"]):r for r in csv.DictReader(io.StringIO(docs["results/phases.csv"].decode()))}
    fused=[b for b in boots if b["role"]=="fused"]
    need(len(boots)==56 and len(fused)==48 and len({b["run"] for b in fused})==48 and
         Counter(b["case"] for b in fused)=={"healthy":32,"overrun":8,"invalid":8}, "campaign inventory")
    rows=[]
    for boot in fused:
        uart=receipt(docs,boot)
        trace=journals(uart)
        for i in range(0,32,2):
            phase=f"A{i//2}"
            rows.append(analyze(boot,i,trace,refs[boot["run"],phase]))
    tests=exercise(docs,fused,refs,receipt,journals,analyze,Refused)
    args.output.mkdir(parents=True,exist_ok=True)
    save(args.output/"empty-a-phases.csv",rows)
    save(args.output/"boot-weighted.csv",summarize(rows))
    save(args.output/"healthy-paired.csv",contrasts(rows))
    save(args.output/"refusals.csv",tests)
    print(f"{len(fused)} fused boots; {len(rows)} phase-A positions; {sum(r['state']=='empty' for r in rows)} empty; "
          f"{len(tests)} refusal controls")


if __name__=="__main__":
    try: main()
    except (ValueError,KeyError,IndexError,OSError,tarfile.TarError) as exc:
        sys.exit(f"refused: {exc}")
