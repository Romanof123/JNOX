"""Recompute authenticated RAM rows with the frozen packet's original ELF/page-table reader."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source",type=Path,help="fully restored source packet")
    base=parser.parse_args().source.resolve()
    scorer=base/"scripts/score.py"
    if hashlib.sha256(scorer.read_bytes()).hexdigest()!="3087643ae910448933d982edf9f460981961d6913ad27f60605854d9f6496970":
        raise ValueError("wrong source scorer")
    spec=importlib.util.spec_from_file_location("source_score",scorer)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    boots=[b for b in json.loads((base/"results/boots.json").read_bytes()) if b["role"]=="fused"]
    if len(boots)!=48:
        raise ValueError("wrong source cohort")
    for boot in boots:
        fresh=module.analyze(base,base/"runs"/boot["run"])
        if not fresh["functional"] or any(fresh[k]!=boot[k] for k in ("headers","phases","controller")):
            raise ValueError("source RAM mismatch: "+boot["run"])
    print("48 authenticated fused RAM/ELF decodes matched 1536 controller rows, phase brackets and role headers")


if __name__=="__main__":
    main()
