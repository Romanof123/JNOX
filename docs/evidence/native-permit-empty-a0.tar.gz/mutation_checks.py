"""In-memory mutations of receipt 001. Each must fail at the named layer."""
from copy import deepcopy


def exercise(docs, boots, refs, receipt, journals, analyze, refused):
    boot=next(b for b in boots if b["run"].startswith("001-"))
    ref=refs[boot["run"],"A0"]
    uart=receipt(docs,boot)
    trace=journals(uart)
    original=analyze(boot,0,trace,ref)
    tests=[]
    def expect(name, why, action):
        try: action()
        except refused as e:
            if why not in str(e):
                raise RuntimeError(f"{name}: unexpected error {e}") from e
            tests.append(dict(control=name,result="refused",reason=str(e)))
        else: raise RuntimeError(f"{name}: accepted")
    key=f"runs/{boot['run']}/cap/uart.bin"
    expect("modified UART with authentic receipt","receipt UART SHA-256",
           lambda: receipt({**docs,key:uart[:-1]},boot))
    expect("truncated terminator","terminal receipts",lambda: journals(uart[:uart.rfind(b"NATIVE EL0 EXIT PID")]))
    expect("lost SAFETY event","SAFETY count/loss",lambda: journals(uart.replace(b"NATIVE SAFETY DROPPED 0",b"NATIVE SAFETY DROPPED 1")))
    expect("duplicate QUAL ordinal","QUAL ordinal",lambda: journals(uart.replace(b"NATIVE QUAL ROW 1 ",b"NATIVE QUAL ROW 0 ",1)))
    for name, field, column, value, why in [
        ("wrong IRQ compare","qual_irq",5,0,"target IRQ"),
        ("comparator hardware mismatch","qual_compare",6,0,"armed comparator"),
        ("wrong eligible controller","qual_ready",7,1,"ready:"),
        ("wrong resume PC","qual_dispatch",12,0,"scheduler/return PC"),
        ("park mask remains runnable","qual_park",7,3,"post-phase park"),
    ]:
        changed=deepcopy(trace)
        changed[0][original[field]][column]=value
        expect(name,why,lambda: analyze(boot,0,changed,ref))
    no_recv=deepcopy(trace)
    no_recv[1][:]=[v for v in no_recv[1] if v[1]!=original["recv_audit"]]
    expect("missing empty loan","receive:",lambda: analyze(boot,0,no_recv,ref))
    no_fixed=deepcopy(trace)
    no_fixed[2][:]=[v for v in no_fixed[2] if v[0]!=original["fixed35"]]
    expect("missing SVC35 inside intact fixed prefix","missing retained SVC35",lambda: analyze(boot,0,no_fixed,ref))
    changed=deepcopy(boot)
    changed["controller"][0][1]=original["check_entry"]-1
    expect("private CHECK readback out of bracket","counter order",lambda: analyze(changed,0,trace,ref))
    changed=deepcopy(boot)
    changed["controller"][0][7]=2**63
    expect("missing private session open","private session-open identity",lambda: analyze(changed,0,trace,ref))
    expect("source cross-check wrong end","source phase CSV: phase_hi",
           lambda: analyze(boot,0,trace,{**ref,"phase_hi":"0"}))
    return tests
