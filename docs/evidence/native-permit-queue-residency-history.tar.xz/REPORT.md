# JNOX #401 sealed capture readback

The next complete, CRC-valid permit occupied the ring at nominal deadline D in **4 of 12** captures. It occupied the ring at the protected opening CHECK operand C in **8 of 12**. Every C was later than D. The old permit's expiry condition was already true at D, but the gate was open, the fault was clear, and the virtual ENABLE output was still high. The first fault decision and the output fall occurred later, within the same CHECK service.

| Raw run | Head at D | Head at C | C − D | Private expiry operand − C | Seq4 private decision − C |
|---|---:|---:|---:|---:|---:|
| 001 default FIFO before | 16 | 16 | 4,033 | 2,414 | 6,432 |
| 002 default FIFO same | empty | 16 | 15,159 | 2,094 | 6,072 |
| 003 default FIFO after | empty | empty | 11,623 | 2,667 | 381,466 |
| 004 default RR before | 16 | 16 | 13,132 | 3,102 | 9,761 |
| 005 default RR same | empty | 16 | 25,693 | 3,826 | 10,484 |
| 006 default RR after | empty | empty | 4,197 | 2,200 | 386,228 |
| 007 count0 FIFO before | 16 | 16 | 134 | 79 | 482 |
| 008 count0 FIFO same | empty | 16 | 919 | 78 | 482 |
| 009 count0 FIFO after | empty | empty | 139 | 80 | 375,465 |
| 010 count0 RR before | 16 | 16 | 141 | 83 | 500 |
| 011 count0 RR same | empty | 16 | 956 | 82 | 499 |
| 012 count0 RR after | empty | empty | 146 | 84 | 375,482 |

Times are guest ticks of 16 ns. D is the accepted seq3 wire issue plus 1,250,000 ticks. The private expiry operand is the first post-CHECK INFO tick passed to the receiver's `begin_activation`. The private decision column gives the separate seq4 acceptance-clock sample. Both times come from the receiver's private RAM. Neither is a timestamp of a private memory store.

## How the queue was reconstructed

The zero-loss safety journal accounts for every successful grant, publication, receive and release, in four cycles with handles 4, 8, 12 and 16. Each publication raised the recorded occupancy to one. Each receive returned that handle with length 44 and reduced occupancy to zero. The queue began empty, its terminal head and tail were both four, and the high-water mark was one. All 16 page-mapping operations were reported, with zero lost. Each cycle changed the same slot from writer-writable to unmapped, then reader-read-only to unmapped. The last cycle identifies physical address `0x40ec0000` in all 12 dumps. Its terminal contents matched the seq4 frame and all 4,052 tail bytes were zero.

The same seq4 handle and 44 bytes matched the sender's staged and publish rows, the kernel's full receive snapshot, the receiver's private copy and the physical backing page. Gen 1, seq 4, the seq4 permit bit, the wire issue, validity and CRC all checked. The sender completed staging before D in all 12. Its actual publication was bracketed separately, so a staged frame could still be solely writer-owned at D.

For each positive result, the entire publication interval preceded the target tick. The post-CHECK receiver activation sampled its entry clock before calling receive. Its private entry clock exceeded C. The successful receive snapshot therefore belongs to a later serialized service. The lifetime check excludes intermediate successful dequeues, channel invalidations and exits, additional publications, and all intermediate COMMIT calls including failed ones. Guard refusals before ring access can be silent. The four later successful receives of the original handle in the after calendar belong to activation 9. The other eight belong to activation 8. These are occupancy inferences from actual ring operations rather than direct historical head samples taken at D or C.

The old accepted seq3 and gate-open, enabled state were recorded by the receiver and authority before staging. Activation 7 ended with ENABLE high and private fault clear before D. Activation 8 targeted D, used the protected CHECK at C, and sampled flags 5, open gate and latched fault, before processing a frame. Its private expiry flag was set. All 12 seq4 decisions recorded error 17 (NeedsOpen) and skipped COMMIT. The entire journal contained exactly three COMMIT calls, all accepted for seq1 through seq3. Two later authority readbacks retained gen1, seq3, the old issue and flags 5. Terminal ENABLE read zero. The generic scheduler journals dropped 229–233 rows. This proof uses the complete loan-MMU and safety journals and the per-PID memory dumps.

## Previous and new coverage

The original #401 verifier already checked three complete wire copies, CRC, the publication and protected receipt order, earlier seq3 and high output, later fault, the skipped seq4 COMMIT, and the private seq4 decision clock relative to expiry. It already reported the before/same/after offsets. It did not score FIFO occupancy at D or C, the MMU transitions or underlying page, every COMMIT status, or the private `begin_activation` clock. The published counted-clock appendix separately authenticated the publication/CHECK operand order for six kernels. This readback introduces no new guest runs or timing settings.

## Frozen source and offline replay

* Measured local commit `aa8e7e104033a372eed0675f3b76f7fb9af2a38e`, public commit `e84ad6ce6543bad37e1e5254f7a9864c838eafd3`, shared Git tree `2491425ca0abfe0a5d2d044bd94eb54f4c282d13`.
* Archived production source SHA-256 `5958e5a32c50372ed400e81a9fdbcd1d6cf8e1f872a6030214ba094d9cbb871c`. The pinned original provenance reader verifies 712 source blobs, both commits, three role ELFs, six packages, twelve launches and their receipts.
* `kernel/src/loan_ipc.rs:196–217,240–274,302–349` defines queued pages, the successful removal path, invalidation and exit. `kernel/src/native_loan_ipc.rs:72–101,117–132,152–164` brackets publication and reports occupancy. `kernel/src/native_safety_channel.rs:113–130,183–216,303–345,355–396` defines the protected event fields and state transitions. `examples/native-safety-channel/receiver/src/main.rs:70–143,337–439` defines the independent private clock samples.

From this report directory on Linux or WSL, point the checker at the original #401 packet containing `runs`, `source`, `apps`, `scripts` and `verification`. It uses the checked original RAM decoder and independently scores the raw journal, physical frame, private activation history, and service ordering. Python 3, Git and GNU AArch64 nm are required.

```sh
python3 -B check_queue.py "$HOME/permit11-arrival-runs/packet" > /tmp/permit401-readback.json
cmp observations.json /tmp/permit401-readback.json
```
