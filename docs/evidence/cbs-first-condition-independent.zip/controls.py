from pathlib import Path
import hashlib, json, os, subprocess, sys
d=Path(__file__).resolve().parent
w=d.parent/'cbs187-independent-d6a68bf'
src=Path.home()/'jnox-cbs187-blind-d6a68bf/01-plain-source'
verify=d/'checks'
verify.mkdir(exist_ok=True)
env={'PATH':str(Path.home()/'jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')+':/usr/bin:/bin','HOME':str(Path.home()),
     'PYTHONPATH':str(Path.home()/'jnox-169-first-e203caa/deps'),'PYTHONDONTWRITEBYTECODE':'1','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}
commands={}
def run(name,argv,cwd,expected=0,overrides=None,output=None):
    effective={**env,**(overrides or {})}
    process=subprocess.run(argv,cwd=cwd,env=effective,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (verify/(output or name+'.out')).write_bytes(process.stdout)
    (verify/(name+'.err')).write_bytes(process.stderr)
    commands[name]={'argv':argv,'cwd':str(cwd),'env':effective,'expected':expected,'actual':process.returncode}
    (verify/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    if expected!=process.returncode:
        print(process.stderr.decode(),process.stdout.decode()[:400],flush=True)
        raise SystemExit('unexpected status '+name)
    print(name,process.returncode,flush=True)
for n in ('01-plain','02-condition'):
    receipt=json.loads((d/n/'freeze.json').read_bytes())['receipt.json']
    args=['/usr/bin/python3','-B',str(src/'tools/cbs_condition_observer.py'),str(d/n),receipt]
    run(n,args,src,output=n+'.json')
    if n=='01-plain':
        run('bad-receipt',args[:-1]+['0'*64],src,1)
run('dictionary-tests',['/usr/bin/python3','-B','-m','unittest','-v','test_cbs_condition_observer'],src/'tools')
run('independent',['/usr/bin/python3','-B',str(d/'replay.py'),str(d),str(w)],src,output='independent.json')
for name,features,value in [('wrong-value','cbs-bench','2'),('wrong-bench','cbs-wake-bench','1'),('extra-feature','cbs-bench,sched-bench','1')]:
    run(name,['cargo','build','--locked','--release','-j1','--features',features],src/'kernel',101,
        {'JNOX_CBS_CONDITION':value,'CARGO_TARGET_DIR':str(Path.home()/'jnox-cbs187-blind-d6a68bf'/('ctrl-'+name))})
    assert b'JNOX_CBS_CONDITION=1 requires only cbs-bench on AArch64 virt' in (verify/(name+'.err')).read_bytes()

