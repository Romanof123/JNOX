"""Replay the frozen #187 captures and the independent EVD-029 reference offline.

Use Python 3 with pyelftools. First argument is the extracted package.
Second argument is the d6a68bf repository root.
"""
import base64
import hashlib
import io
import json
import re
import struct
import sys
from pathlib import Path
from elftools.elf.elffile import ELFFile

DATA = Path(sys.argv[1])
REPO = Path(sys.argv[2])
FREEZES = {
    '01-plain': '25fdbec2f46b76b6d0f0105f302c59da9fc728cfba9d45579299c0a85d84b939',
    '02-condition': 'c7212192a2b7cc4986bebdeefec3cbb5f2333109f9cec9702817ef0310bb1bee',
    '03-wake': 'e60f5c56515f73f0a1eb09420902a9678251e80e9a267192ee2cef5658a55715',
    '04-preselector': '0c2b98d7d070afc0ee12573f16de8fd2fefa4ad97fa99c35339b8db4a90bcea7',
}
BASIC = b'JNOX M1 BOOT\nJNOX M1 READY\nCBS A FIRST\nCBS B FIRST\nCBS IDLE\nCBS A RESUMED\nCBS B RESUMED\nCBS TIMER STOP\nCBS PASS\n'
WAKE = b'JNOX M1 BOOT\nJNOX M1 READY\nCBS WAKE TIMER STOP\nCBS WAKE PASS\n'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def check(test, reason):
    if not test:
        raise ValueError(reason)
def read_elf(folder):
    elf = ELFFile(io.BytesIO((folder/'kernel.elf').read_bytes()))
    check(elf.elfclass == 64 and elf.little_endian and elf['e_machine']=='EM_AARCH64','wrong architecture')
    return elf
def symbol(elf,name):
    matches=elf.get_section_by_name('.symtab').get_symbol_by_name(name)
    check(matches and len(matches)==1, name)
    return matches[0]['st_value'],matches[0]['st_size']
def trace(raw):
    lines=iter(raw.decode('ascii').splitlines())
    events=[]
    def match(line,pattern):
        m=re.fullmatch(pattern,line)
        check(m, 'unexpected trace: '+line)
        return m
    for line in lines:
        if line.startswith('Exception return'):
            pc=match(line,r'Exception return from AArch64 EL1 to AArch64 EL1 PC (0x[0-9a-f]+)')[1]
            events.append(('eret',int(pc,16),None))
            continue
        entry=match(line,r'Taking exception (5 \[IRQ\]|2 \[SVC\])(?: on CPU 0)?')[1]
        kind='irq' if entry.startswith('5') else 'svc'
        check(next(lines)=='...from EL1 to EL1','wrong exception level')
        syndrome=match(next(lines),r'\.\.\.with ESR (0x[0-9a-f]+/0x[0-9a-f]+)')[1]
        check(syndrome in ('0x0/0x0','0x15/0x5600001d') and (kind!='svc' or syndrome=='0x15/0x5600001d'),'wrong syndrome')
        line=next(lines)
        if line.startswith('...with SPSR '):
            line=next(lines)
        pc=match(line,r'\.\.\.with ELR (0x[0-9a-f]+)')[1]
        vector=match(next(lines),r'\.\.\.to EL1 PC (0x[0-9a-f]+) PSTATE 0x3c5')[1]
        events.append((kind,int(pc,16),int(vector,16)))
    return events
def model(reservations,releases,count):
    balance=[0,0]
    due=[0,0]
    work=[0,0]
    result=[]
    def allocations():
        return (balance[0],due[0],balance[1],due[1])
    for tick in range(count):
        mask=0
        for owner,demand in releases.get(tick,[]):
            capacity,period=reservations[owner]
            check(work[owner]==0,'release into pending work')
            if tick>=due[owner] or balance[owner]*period > capacity*(due[owner]-tick):
                balance[owner],due[owner]=capacity,tick+period
            work[owner]=demand
            mask |= 1<<owner
        before=allocations()
        eligible=[]
        for owner,(capacity,period) in enumerate(reservations):
            if work[owner] and (balance[owner] or due[owner]<=tick):
                available=balance[owner] or capacity
                deadline=due[owner]+(period if not balance[owner] else 0)
                check(deadline>tick,'missed logical deadline')
                eligible.append((deadline,owner,available))
        owner=2
        if eligible:
            deadline,owner,available=min(eligible)
            due[owner]=deadline
            balance[owner]=available-1
            work[owner]-=1
        result.append((tick,mask,*before,owner,*allocations()))
    return result
def loads(elf):
    fields=('p_offset','p_vaddr','p_paddr','p_filesz','p_memsz','p_flags','p_align')
    return [{**{k:s[k] for k in fields},'sha256':sha(s.data())} for s in elf.iter_segments() if s['p_type']=='PT_LOAD']
def basic(folder):
    elf=read_elf(folder)
    ev=trace((folder/'exceptions.log').read_bytes())
    sched=[x[6] for x in model([(1,3),(1,4)],{0:[(0,3),(1,3)]},5)]
    check(sched==[0,1,2,0,1] and len(ev)==10,'incorrect basic grants/events')
    check((folder/'uart').read_bytes()==BASIC,'incorrect basic UART')
    check(json.loads((folder/'identity.json').read_bytes())['runner_exit']==0,'runner exit')
    check((folder/'runner.log').read_text().splitlines()[-2:]==['  PASS (host stopped QEMU after the quiet window)','PASS: 1 cold boot(s)'],'missing quiet stop')
    vector=symbol(elf,'sched_vectors')[0]+640
    saved={}
    for t,g in enumerate(sched):
        role=['cbs_a','cbs_b','cbs_idle'][g]
        pc=saved.get(role,symbol(elf,role)[0])
        check(ev[2*t]==('eret',pc,None),'incorrect saved-PC ERET')
        kind,irq,dst=ev[2*t+1]
        check(kind=='irq' and dst==vector and irq%4==0 and symbol(elf,role+'_begin')[0]<=irq<symbol(elf,role+'_end')[0], 'incorrect basic IRQ')
        saved[role]=irq
    return {'uart_bytes':len(BASIC),'lines':len(BASIC.splitlines()),'grants':sched,'events':ev,'irq_count':5,
            'resumed_saved_pc':[hex(ev[6][1]),hex(ev[8][1])],'timer_stop_and_pass':True,'quiet_seconds':0.1}
def wake(audit,ev,uart,launch,qmp,exited,elf=None):
    rows=list(struct.iter_unpack('<24Q',audit))
    check(len(rows)==34 and uart==WAKE,'wake rows or UART')
    check(launch['audit_size']==len(audit) and qmp['status']['running'] and len(qmp['cpus'])==1 and exited['qemu_status'] in (0,-15),'wake capture identity')
    releases={t:[(0,1)] for t in (0,4,5,13,22)}
    releases.update({23:[(0,100)],1:[(1,100)]})
    expected=model([(2,8),(1,4)],releases,34)
    grants=[r[6] for r in expected]
    blocks=[0,4,8,14,22]
    resume=[4,8,14,22,23]
    if elf:
        names=['cbs_wake_a','cbs_wake_b','cbs_wake_idle']
        ranges=[symbol(elf,name) for name in names]
        entries=[base for base,size in ranges]
        resume_pc=symbol(elf,'cbs_wake_a_resume')[0]
        vector=symbol(elf,'sched_vectors')[0]
        check(symbol(elf,'cbs_wake_witness')==(launch['audit_address'],len(audit)),'wrong journal location')
    else:
        # Old record embeds the witness and trace but does not include its ELF.
        entries=[rows[0][14],rows[1][14],ev[2][1]]
        resume_pc=rows[0][21]
        vector=ev[1][2]-512
    check(len(set(entries))==3,'distinct entries')
    saved_pc=entries[:]
    interrupted=[False]*3
    frames=[None]*3
    progress=[0]*3
    events=[]
    lates=[]
    epoch,quantum=rows[0][11:13]
    check(quantum>0,'zero quantum')
    for r,policy in zip(rows,expected):
        t,grant=r[0],r[6]
        check(r[:11]==policy, 'policy row '+str(t))
        end=epoch+(t+1)*quantum
        check(r[11:14]==(epoch,quantum,end) and end<=r[16]<end+quantum, 'timer row '+str(t))
        lates.append(r[16]-end)
        check(r[14]==saved_pc[grant], 'wrong dispatch PC')
        frame=r[15] if interrupted[grant] else r[15]-16
        if frames[grant] is None: frames[grant]=frame
        check(frames[grant]==frame, 'wrong dispatched frame')
        events.append(('eret',r[14],None))
        if t in resume:
            check(grant==0 and r[14]==resume_pc,'wrong SVC resume')
        irq_owner=grant
        if t in blocks:
            check(grant==0 and end-quantum<=r[20]<end and r[21]==resume_pc and r[22]>progress[0], 'wrong blocking SVC')
            events.append(('svc',resume_pc,vector+512))
            events.append(('eret',saved_pc[2],None))
            progress[0]=r[22]
            interrupted[0]=True
            saved_pc[0]=resume_pc
            irq_owner=2
        else:
            check(r[20:23]==(0,0,0), 'spurious SVC')
        check(r[17]==irq_owner and r[19]>progress[irq_owner] and r[18]%4==0,'wrong IRQ owner/progress')
        if elf:
            begin,size=ranges[irq_owner]
            check(begin<=r[18]<begin+size,'IRQ PC outside linked function')
        if frames[irq_owner] is None: frames[irq_owner]=r[23]
        check(frames[irq_owner]==r[23] and r[23]%16==0, 'wrong IRQ frame')
        interrupted[irq_owner]=True
        saved_pc[irq_owner]=r[18]
        progress[irq_owner]=r[19]
        events.append(('irq',r[18],vector+640))
    check(len(set(frames))==3 and all(progress) and events==ev and len(events)==78,'ordered wake PC or frames mismatch')
    return {'rows':len(rows),'grants':grants,'blocks':blocks,'resumes':resume,'B_slots':[i for i,g in enumerate(grants) if g==1],
            'idle_grants':grants.count(2),'frames':frames,'events':events,'eret_count':39,'irq_count':34,'svc_count':5,
            'epoch':epoch,'quantum':quantum,'lateness_ticks':lates,'elf_bound':elf is not None}
for folder,digest in FREEZES.items():
    d=DATA/folder
    check(sha((d/'freeze.json').read_bytes())==digest,folder+' freeze')
    manifest=json.loads((d/'freeze.json').read_bytes())
    measured={p.relative_to(d).as_posix():sha(p.read_bytes()) for p in d.rglob('*') if p.is_file() and p!=d/'freeze.json'}
    check(measured==manifest,'missing, modified or extra file '+folder)
out={'freeze_sha256':FREEZES}
out['basic']={k:basic(DATA/k) for k in ['01-plain','02-condition']}
out['pt_loads']={k:loads(read_elf(DATA/k)) for k in FREEZES}
out['ordinary_pt_loads_equal']=out['pt_loads']['01-plain']==out['pt_loads']['04-preselector']
out['ordinary_full_elf_equal']=(DATA/'01-plain/kernel.elf').read_bytes()==(DATA/'04-preselector/kernel.elf').read_bytes()
check(out['ordinary_pt_loads_equal'],'ordinary binary PT_LOAD regression')
fresh=DATA/'03-wake/capture'
def j(path):
    return json.loads(path.read_bytes())
out['wake']=wake((fresh/'audit.bin').read_bytes(),trace((fresh/'int.trace').read_bytes()),(fresh/'uart.bin').read_bytes(),
                 j(fresh/'launch.json'),j(fresh/'qmp.json'),j(fresh/'exit.json'),read_elf(DATA/'03-wake'))
ref=j(REPO/'docs/evidence/evd-029.json')
raw={k:base64.b64decode(v,validate=True) for k,v in ref['raw_base64'].items()}
check({k:sha(v) for k,v in raw.items()}==ref['sha256'],'EVD-029 original artifact hashes')
out['evd_029']=wake(raw['audit.bin'],trace(raw['int.trace']),raw['uart.bin'],json.loads(raw['launch.json']),json.loads(raw['qmp.json']),json.loads(raw['exit.json']))
check(out['wake']['grants']==ref['independent_verifier']['grants']==out['evd_029']['grants'],'reference grants')
check(out['evd_029']['blocks']==ref['independent_verifier']['svc_slots'] and out['evd_029']['lateness_ticks']==ref['independent_verifier']['irq_lateness_ticks'],'reference verifier')
out['all_ordered_event_addresses_equal_reference']=out['wake']['events']==out['evd_029']['events']
out['reference_elf_sha256']=ref['elf_sha256']
print(json.dumps(out,indent=2))

