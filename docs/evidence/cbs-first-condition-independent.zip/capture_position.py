from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys, time
from datetime import datetime, timezone

disk = Path(__file__).resolve().parent
runroot = Path.home() / 'jnox-cbs187-blind-d6a68bf'
source = runroot / 'source'
target = runroot / 'target'
chain = ['01-plain', '02-condition', '03-wake', '04-preselector']
pos = sys.argv[1]
index = chain.index(pos)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
def hashes(directory):
    return {p.relative_to(directory).as_posix(): sha(p) for p in sorted(directory.rglob('*')) if p.is_file() and p != directory/'freeze.json'}
def check(directory):
    recorded=json.loads((directory/'freeze.json').read_bytes())
    assert recorded == hashes(directory), 'durable first-position manifest mismatch'
    print(directory.name,sha(directory/'freeze.json'),'reopened',len(recorded),'files',flush=True)
if sys.argv[2:] == ['verify']:
    check(disk/pos)
    sys.exit(0)
if index:
    check(disk/chain[index-1])
keep = disk / pos
assert not keep.exists()
runroot.mkdir(exist_ok=True)
local = runroot / pos
local.mkdir()
keep.mkdir()
assert not source.exists() and not target.exists()
toolchain = Path.home()/'jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin'
env = {'PATH':f'{toolchain}:/usr/bin:/bin','HOME':str(Path.home()),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','CARGO_TARGET_DIR':str(target),'PYTHONDONTWRITEBYTECODE':'1'}
if pos == '02-condition':
    env['JNOX_CBS_CONDITION']='1'
revision = '495a7d9d5f2514d3cef44c69be2cc90b7441094e' if index == 3 else 'd6a68bf504d0ce15a09c38220e10ff2a02c60a91'
archive = disk / ('preselector.tar' if index==3 else 'candidate.tar')
feature = 'cbs-wake-bench' if index==2 else 'cbs-bench'
build = ['cargo','build','--locked','--release','-j1','--features',feature]
def logged(cmd, directory, output):
    with (local/output).open('wb') as log:
        return subprocess.run(cmd,env=env,cwd=directory,stdout=log,stderr=subprocess.STDOUT).returncode
def utc():
    return datetime.now(timezone.utc).isoformat()
meta={'revision':revision,'source_archive_sha256':sha(archive),'environment':env,'source':str(source),'build_cwd':str(source/'kernel'),'build_argv':build,'start_utc':utc()}
try:
    source.mkdir()
    subprocess.run(['tar','xf',str(archive),'-C',str(source)],check=True)
    meta['versions']={cmd[0]:subprocess.check_output(cmd,env=env,text=True).strip() for cmd in (['cargo','-Vv'],['rustc','-Vv'],['qemu-system-aarch64','--version'],['uname','-a'])}
    meta['build_exit']=logged(build,source/'kernel','build.log')
    if meta['build_exit'] == 0:
        elf=local/'kernel.elf'
        shutil.copyfile(target/'aarch64-unknown-none/release/jnox-kernel',elf)
        meta['elf_sha256_before']=sha(elf)
        if index<3:
            args=['/usr/bin/python3','-B',str(source/'tools/qemu_boot.py'),'--kernel',str(elf),'--runs','1','--profile','cbs-wake' if index==2 else 'cbs']
            if index==2:
                env['CBS_WAKE_CAPTURE_DIR']=str(local/'capture')
                args.extend(['--timeout','15','--qemu',str(source/'tools/cbs_wake_capture.py')])
            else:
                shutil.copyfile(source/'kernel/src/cbs_condition_v1.csv',local/'sites.csv')
                args.extend(['--capture-dir',str(local/'capture')])
                if index==1:
                    args.append('--cbs-diagnostic')
            meta.update(runner_argv=args,runner_cwd=str(source))
            meta['runner_exit']=logged(args,source,'runner.log')
            if index<2:
                for name in ('uart','exceptions.log'):
                    shutil.copyfile(local/'capture/run-1'/name,local/name)
                pid=int(re.search(rb'^  QEMU PID = (\d+)$',(local/'runner.log').read_bytes(),re.M)[1])
                receipt={'revision':revision,'image_kind':'diagnostic' if index==1 else 'plain','runner_exit':meta['runner_exit'],'pid':pid,
                         'hashes':{n:sha(local/n) for n in ('kernel.elf','sites.csv','uart','exceptions.log','runner.log')}}
                dump(local/'receipt.json',receipt)
        meta['elf_sha256_after']=sha(elf)
finally:
    meta['end_utc']=utc()
    dump(local/'identity.json',meta)
    for path in local.iterdir():
        if path.is_dir(): shutil.copytree(path,keep/path.name)
        else: shutil.copyfile(path,keep/path.name)
    digest=hashes(local)
    assert hashes(keep)==digest
    dump(keep/'freeze.json',digest)
    check(keep)
    print(json.dumps({k:v for k,v in meta.items() if k in ('build_exit','runner_exit','elf_sha256_before')}),flush=True)
    for name in ('build.log','runner.log'):
        if (keep/name).exists(): print((keep/name).read_text(),flush=True)
    if source.exists(): source.rename(runroot/(pos+'-source'))
    if target.exists(): target.rename(runroot/(pos+'-target'))
if meta.get('build_exit',1)!=0: sys.exit(2)

