import json, hashlib, zipfile
from pathlib import Path
from fractions import Fraction
root = Path(__file__).parent
def sha(b):
    return hashlib.sha256(b).hexdigest()
results = {}
for position in ('preflight','plain','instrumented'):
    p = root/'receipt'/position
    archive = p/'position.zip'
    m = json.loads((p/'manifest.json').read_bytes())
    assert sha(archive.read_bytes()) == m['archive_sha256'] == (p/'position.zip.sha256').read_text().split()[0]
    assert m['session_sha256'] == (p/'capture-session.sha256').read_text().split()[0]
    w = json.loads((p/'windows-reopen.stdout').read_bytes())
    assert w['manifest_sha256'] == sha((p/'manifest.json').read_bytes())
    with zipfile.ZipFile(archive) as z:
        assert z.namelist() == [i['name'] for i in m['members']]
        for i in m['members']:
            b = z.read(i['name'])
            assert sha(b) == i['sha256'] and len(b) == i['size']
        if position == 'preflight':
            continue
        z.extractall(root/'reopened'/position)
        j = json.loads(z.read('replay.stdout'))
        rows = []; ab = [0,0]; prev = None; gaps = []; diffs = []; Q=625000; H=781250
        for c in j['closures']:
            r, k, i = c['start'], c['compare'], c['stop']
            gap = 0 if prev is None else r-prev
            assert 0 <= gap <= 156250
            gaps.append(gap); prev = i
            ab[c['pid']] += i-r
            if c['cause'] == 'irq':
                diff = 2*ab[0]-ab[1]
                assert -H <= diff <= 2*H and Q <= i-r <= H and k-r == Q
                diffs.append(diff)
                rows.append(dict(lease=c['lease'], R=r,C=k,I=i,service=i-r,late=i-k,gap=gap,A=ab[0],B=ab[1],delta=diff))
        assert len(rows)==36 and gaps == j['gaps']
        a,b=rows[-1]['A'], rows[-1]['B']; t=a+b
        assert t>=36*Q and abs(Fraction(a,t)-Fraction(1,3))<=Fraction(2*H,108*Q)
        obs=j.get('timer_observation',{}); host={}
        if obs:
            assert len(obs['irqs'])==36
            for row, irq in zip(rows,obs['irqs']):
                assert [row[k] for k in ('lease','R','C','I')] == [irq[k] for k in ('lease','guest_R','guest_C','guest_I')]
                assert all(isinstance(x,dict) for x in irq['host_points'].values()) and len(irq['host_points'])==6
            for key in ('cval_to_ppi_us','ppi_to_cpu_line_us','ppi_to_iar_us','ppi_to_handler_disable_us'):
                vals=[v[key] for v in obs['irqs']]
                host[key]=[min(v[0] for v in vals),max(v[1] for v in vals)]
        results[position]=dict(service=[min(x['service'] for x in rows),max(x['service'] for x in rows)],gap=max(gaps),prefix=[min(diffs),max(diffs)],A=a,B=b,T=t,share=a/t,host=host,rows=rows)
(root/'independent.json').write_text(json.dumps(results,indent=2))
for p,result in results.items(): print(p,{k:v for k,v in result.items() if k!='rows'})
