import json,re,struct,sys
from pathlib import Path
sys.path.insert(0,'src/tools')
from native_el0_replay import Snapshot,vread
for n in ('c','rust'):
 raw=Path(n+'-tail.log').read_text()
 blocks=[(m.start(),{k:int(v,16) for k,v in re.findall(r'(PC|X\d\d|SP)=([0-9a-f]+)',m.group())}) for m in re.finditer(r' PC=[^\n]+\n(?:X[^\n]+\n){10}PSTATE=[^\n]+',raw)]
 def hits(pc):return [(i,r) for i,r in blocks if r['PC']==pc]
 def vals(pc,k):return [r[k] for _,r in hits(pc)]
 due=hits(0x402029c0)[0][1]; irqs=hits(0x40202a8c); start=hits(0x4020265c)
 assert len(irqs)==len(start)==len(hits(0x40201be8))==len(hits(0x402029fc))==3
 clock=hits(0x402026fc); epoch=clock[0][1]['X08']; hz=clock[0][1]['X21']
 waits=[]
 for j,((pos,b),(end,a)) in enumerate(zip(start,irqs)):
  t=b['X08']; assert b['X09']<t<=a['X11'] and a['X13']==t and a['X12']==1 and a['X09']==30
  ns=lambda tick:(tick-epoch)*10**9//hz
  target=ns(t); observed=ns(clock[j+1][1]['X09']); assert observed>=target
  assert pos<hits(0x40201be8)[j][0]<end<hits(0x402029fc)[j][0]<clock[j+1][0]
  waits.append([t,a['X11'],target,observed])
 assert waits[1][0]-waits[0][0]==waits[2][0]-waits[1][0]==hz*40//1000
 assert due['X08']==waits[0][0]<=due['X09']
 pos=hits(0x402029c0)[0][0]; assert irqs[0][0]<pos<start[1][0]
 roots=vals(0x402029fc,'X08'); assert len(set(roots))==1
 frame=vals(0x4020265c,'X19'); assert len(set(frame))==1
 prevPC=0x400168 if n=='c' else 0x400524
 calls=hits(prevPC); assert len(calls)==(5 if n=='c' else 4) and all(r['X00']==0 for _,r in calls[-4:])
 for i,r in calls:
  assert 'EL0 PC '+hex(prevPC) in raw[max(0,i-2500):i]
 assert raw.count('gic_acknowledge_irq cpu 0 acknowledged irq 30')==3
 sp=vals(0x40041c if n=='c' else 0x40028c,'SP')[0]
 snap=Snapshot(0x40200000,Path(n+'-run/ram.bin').read_bytes())
 total=struct.unpack('<I',vread(snap,roots[0],sp+12,4))[0]; assert total==6
 if n=='c':
  assert vals(0x4001c8,'X00')==[22]
  assert struct.unpack('<qq',vread(snap,roots[0],sp+32,16))==(17,23)
  assert struct.unpack('<I',vread(snap,roots[0],0x402000,4))[0]==4
 else: assert vals(0x40006c,'X01')==[75]
 assert len(set(vals(0x40201be8,'SP')))==1 and vals(0x40201be8,'SP')[0]!=vals(0x4020265c,'SP')[0]
 print(json.dumps(dict(app=n,frequency=hz,epoch=epoch,rows_target_tick_IRQ_tick_target_ns_read_ns=waits,repeated_target_tick=due['X08'],repeat_entry_tick=due['X09'],restored_TTBR0=hex(roots[0]),pinned_SVC_frame=hex(frame[0]),EL1_idle_SP=hex(vals(0x40201be8,'SP')[0]),EL0_post_sleep_PC=hex(prevPC),report_VA=hex(sp+12),RAM_report=total)))
