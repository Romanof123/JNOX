
c-run/kernel.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000040201bd4 <native_sleep_switch>:
    40201bd4:	a9bf7bf3 	stp	x19, x30, [sp, #-16]!
    40201bd8:	910003f3 	mov	x19, sp
    40201bdc:	9100001f 	mov	sp, x0
    40201be0:	d50342ff 	msr	daifclr, #0x2
    40201be4:	d5033fdf 	isb

0000000040201be8 <native_sleep_idle>:
    40201be8:	d503207f 	wfi
    40201bec:	17ffffff 	b	40201be8 <native_sleep_idle>
    40201bf0:	94000393 	bl	40202a3c <native_sleep_irq>
    40201bf4:	b40000c0 	cbz	x0, 40201c0c <native_sleep_idle+0x24>
    40201bf8:	100000c9 	adr	x9, 40201c10 <native_sleep_idle+0x28>
    40201bfc:	d5184029 	msr	elr_el1, x9
    40201c00:	d5384009 	mrs	x9, spsr_el1
    40201c04:	b2790129 	orr	x9, x9, #0x80
    40201c08:	d5184009 	msr	spsr_el1, x9
    40201c0c:	d69f03e0 	eret
    40201c10:	9100027f 	mov	sp, x19

0000000040201c14 <native_sleep_resume>:
    40201c14:	a8c17bf3 	ldp	x19, x30, [sp], #16
    40201c18:	d65f03c0 	ret

0000000040201c1c <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE>:
    40201c1c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    40201c20:	a9016ffc 	stp	x28, x27, [sp, #16]
    40201c24:	a90267fa 	stp	x26, x25, [sp, #32]
    40201c28:	a9035ff8 	stp	x24, x23, [sp, #48]
    40201c2c:	a90457f6 	stp	x22, x21, [sp, #64]
    40201c30:	a9054ff4 	stp	x20, x19, [sp, #80]
    40201c34:	d10f83ff 	sub	sp, sp, #0x3e0
    40201c38:	d53be008 	mrs	x8, cntfrq_el0
    40201c3c:	b5000068 	cbnz	x8, 40201c48 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x2c>
    40201c40:	52800100 	mov	w0, #0x8                   	// #8
    40201c44:	94000191 	bl	40202288 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    40201c48:	aa1f03e9 	mov	x9, xzr
    40201c4c:	d5033fdf 	isb
    40201c50:	d53be02a 	mrs	x10, cntpct_el0
    40201c54:	9000214b 	adrp	x11, 40629000 <_ZN11jnox_kernel9BSS_PROBE17h33657fc229f3152bE>
    40201c58:	9000214c 	adrp	x12, 40629000 <_ZN11jnox_kernel9BSS_PROBE17h33657fc229f3152bE>
    40201c5c:	f9000988 	str	x8, [x12, #16]
    40201c60:	9000216c 	adrp	x12, 4062d000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3fe0>
    40201c64:	9101018c 	add	x12, x12, #0x40
    40201c68:	f900056a 	str	x10, [x11, #8]
    40201c6c:	52800308 	mov	w8, #0x18                  	// #24
    40201c70:	72a12008 	movk	w8, #0x900, lsl #16
    40201c74:	5280002a 	mov	w10, #0x1                   	// #1
    40201c78:	f900018a 	str	x10, [x12]
    40201c7c:	52869c0b 	mov	w11, #0x34e0                	// #13536
    40201c80:	f900058a 	str	x10, [x12, #8]
    40201c84:	f9000d8b 	str	x11, [x12, #24]
    40201c88:	d503201f 	nop
    40201c8c:	1002dbaa 	adr	x10, 40207800 <jnox_native_el0_image+0x3510>
    40201c90:	52a1200b 	mov	w11, #0x9000000             	// #150994944
    40201c94:	3869694c 	ldrb	w12, [x10, x9]
    40201c98:	b940010d 	ldr	w13, [x8]
    40201c9c:	3628006d 	tbz	w13, #5, 40201ca8 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x8c>
    40201ca0:	d5033fdf 	isb
    40201ca4:	17fffffd 	b	40201c98 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x7c>
    40201ca8:	91000529 	add	x9, x9, #0x1
    40201cac:	b900016c 	str	w12, [x11]
    40201cb0:	f1003d3f 	cmp	x9, #0xf
    40201cb4:	54ffff01 	b.ne	40201c94 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x78>  // b.any
    40201cb8:	aa1f03e9 	mov	x9, xzr
    40201cbc:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    40201cc0:	d503201f 	nop
    40201cc4:	7002da4b 	adr	x11, 4020780f <jnox_native_el0_image+0x351f>
    40201cc8:	3869696c 	ldrb	w12, [x11, x9]
    40201ccc:	b940010d 	ldr	w13, [x8]
    40201cd0:	3628006d 	tbz	w13, #5, 40201cdc <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0xc0>
    40201cd4:	d5033fdf 	isb
    40201cd8:	17fffffd 	b	40201ccc <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0xb0>
    40201cdc:	91000529 	add	x9, x9, #0x1
    40201ce0:	b900014c 	str	w12, [x10]
    40201ce4:	f101013f 	cmp	x9, #0x40
    40201ce8:	54ffff01 	b.ne	40201cc8 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0xac>  // b.any
    40201cec:	14000002 	b	40201cf4 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0xd8>
    40201cf0:	d5033fdf 	isb
    40201cf4:	b9400109 	ldr	w9, [x8]
    40201cf8:	372fffc9 	tbnz	w9, #5, 40201cf0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0xd4>
    40201cfc:	52a12008 	mov	w8, #0x9000000             	// #150994944
    40201d00:	52800149 	mov	w9, #0xa                   	// #10
    40201d04:	b9000109 	str	w9, [x8]
    40201d08:	d503201f 	nop
    40201d0c:	10012f33 	adr	x19, 402042f0 <jnox_native_el0_image>
    40201d10:	910783e8 	add	x8, sp, #0x1e0
    40201d14:	aa1303e0 	mov	x0, x19
    40201d18:	52869c01 	mov	w1, #0x34e0                	// #13536
    40201d1c:	52a00802 	mov	w2, #0x400000              	// #4194304
    40201d20:	52a01003 	mov	w3, #0x800000              	// #8388608
    40201d24:	97fff8d9 	bl	40200088 <_ZN11jnox_kernel10native_elf4plan17h48bee63ee2c6fe6fE>
    40201d28:	394843e8 	ldrb	w8, [sp, #528]
    40201d2c:	71000d1f 	cmp	w8, #0x3
    40201d30:	54000061 	b.ne	40201d3c <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x120>  // b.any
    40201d34:	52800080 	mov	w0, #0x4                   	// #4
    40201d38:	94000154 	bl	40202288 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    40201d3c:	910043e0 	add	x0, sp, #0x10
    40201d40:	910783e1 	add	x1, sp, #0x1e0
    40201d44:	52803a02 	mov	w2, #0x1d0                 	// #464
    40201d48:	94000803 	bl	40203d54 <memcpy>
    40201d4c:	f940ebe8 	ldr	x8, [sp, #464]
    40201d50:	f150011f 	cmp	x8, #0x400, lsl #12
    40201d54:	54000361 	b.ne	40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>  // b.any
    40201d58:	f940efe1 	ldr	x1, [sp, #472]
    40201d5c:	f100243f 	cmp	x1, #0x9
    40201d60:	540028a2 	b.cs	40202274 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x658>  // b.hs, b.nlast
    40201d64:	52800048 	mov	w8, #0x2                   	// #2
    40201d68:	3907cbe8 	strb	w8, [sp, #498]
    40201d6c:	52800028 	mov	w8, #0x1                   	// #1
    40201d70:	7903e3e8 	strh	w8, [sp, #496]
    40201d74:	f1000c3f 	cmp	x1, #0x3
    40201d78:	54000241 	b.ne	40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>  // b.any
    40201d7c:	aa1f03e9 	mov	x9, xzr
    40201d80:	d37ae428 	lsl	x8, x1, #6
    40201d84:	cb010d0a 	sub	x10, x8, x1, lsl #3
    40201d88:	910783e8 	add	x8, sp, #0x1e0
    40201d8c:	91004108 	add	x8, x8, #0x10
    40201d90:	910043eb 	add	x11, sp, #0x10
    40201d94:	f90007ea 	str	x10, [sp, #8]
    40201d98:	b400018a 	cbz	x10, 40201dc8 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1ac>
    40201d9c:	f1000d3f 	cmp	x9, #0x3
    40201da0:	54000100 	b.eq	40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>  // b.none
    40201da4:	3869690c 	ldrb	w12, [x8, x9]
    40201da8:	3940c16d 	ldrb	w13, [x11, #48]
    40201dac:	9100e16b 	add	x11, x11, #0x38
    40201db0:	91000529 	add	x9, x9, #0x1
    40201db4:	d100e14a 	sub	x10, x10, #0x38
    40201db8:	6b0c01bf 	cmp	w13, w12
    40201dbc:	54fffee0 	b.eq	40201d98 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x17c>  // b.none
    40201dc0:	528000a0 	mov	w0, #0x5                   	// #5
    40201dc4:	94000131 	bl	40202288 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    40201dc8:	2a1f03e8 	mov	w8, wzr
    40201dcc:	910043e9 	add	x9, sp, #0x10
    40201dd0:	91006136 	add	x22, x9, #0x18
    40201dd4:	d0000034 	adrp	x20, 40207000 <jnox_native_el0_image+0x2d10>
    40201dd8:	91174294 	add	x20, x20, #0x5d0
    40201ddc:	52804017 	mov	w23, #0x200                 	// #512
    40201de0:	528007b8 	mov	w24, #0x3d                  	// #61
    40201de4:	52863c19 	mov	w25, #0x31e0                	// #12768
    40201de8:	8b19027a 	add	x26, x19, x25
    40201dec:	d28f0dfb 	mov	x27, #0x786f                	// #30831
    40201df0:	f2ac25db 	movk	x27, #0x612e, lsl #16
    40201df4:	f2cd2c5b 	movk	x27, #0x6962, lsl #32
    40201df8:	d28dc5dc 	mov	x28, #0x6e2e                	// #28206
    40201dfc:	f2ae8dfc 	movk	x28, #0x746f, lsl #16
    40201e00:	f2c5ccbc 	movk	x28, #0x2e65, lsl #32
    40201e04:	f2edcd5c 	movk	x28, #0x6e6a, lsl #48
    40201e08:	aa1403fd 	mov	x29, x20
    40201e0c:	394007a9 	ldrb	w9, [x29, #1]
    40201e10:	394003aa 	ldrb	w10, [x29]
    40201e14:	aa092149 	orr	x9, x10, x9, lsl #8
    40201e18:	39400faa 	ldrb	w10, [x29, #3]
    40201e1c:	39400bab 	ldrb	w11, [x29, #2]
    40201e20:	d370bd6b 	lsl	x11, x11, #16
    40201e24:	aa0a616a 	orr	x10, x11, x10, lsl #24
    40201e28:	aa090149 	orr	x9, x10, x9
    40201e2c:	7100f13f 	cmp	w9, #0x3c
    40201e30:	54fffc88 	b.hi	40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>  // b.pmore
    40201e34:	aa1f03ea 	mov	x10, xzr
    40201e38:	910103b4 	add	x20, x29, #0x40
    40201e3c:	d10102f7 	sub	x23, x23, #0x40
    40201e40:	cb09030b 	sub	x11, x24, x9
    40201e44:	8b09034c 	add	x12, x26, x9
    40201e48:	386a698d 	ldrb	w13, [x12, x10]
    40201e4c:	340000ad 	cbz	w13, 40201e60 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x244>
    40201e50:	9100054a 	add	x10, x10, #0x1
    40201e54:	eb0a017f 	cmp	x11, x10
    40201e58:	54fffb40 	b.eq	40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>  // b.none
    40201e5c:	17fffffb 	b	40201e48 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x22c>
    40201e60:	f100395f 	cmp	x10, #0xe
    40201e64:	54000481 	b.ne	40201ef4 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x2d8>  // b.any
    40201e68:	8b090269 	add	x9, x19, x9
    40201e6c:	8b190129 	add	x9, x9, x25
    40201e70:	3940052a 	ldrb	w10, [x9, #1]
    40201e74:	3940012b 	ldrb	w11, [x9]
    40201e78:	39400d2c 	ldrb	w12, [x9, #3]
    40201e7c:	aa0903ed 	mov	x13, x9
    40201e80:	38404dae 	ldrb	w14, [x13, #4]!
    40201e84:	aa0a216a 	orr	x10, x11, x10, lsl #8
    40201e88:	3940092b 	ldrb	w11, [x9, #2]
    40201e8c:	d370bd6b 	lsl	x11, x11, #16
    40201e90:	aa0c616b 	orr	x11, x11, x12, lsl #24
    40201e94:	3940152c 	ldrb	w12, [x9, #5]
    40201e98:	2a0c21cc 	orr	w12, w14, w12, lsl #8
    40201e9c:	aa0a016a 	orr	x10, x11, x10
    40201ea0:	39400dab 	ldrb	w11, [x13, #3]
    40201ea4:	394009ad 	ldrb	w13, [x13, #2]
    40201ea8:	53103dad 	lsl	w13, w13, #16
    40201eac:	2a0b61ab 	orr	w11, w13, w11, lsl #24
    40201eb0:	3940252d 	ldrb	w13, [x9, #9]
    40201eb4:	2a0c016b 	orr	w11, w11, w12
    40201eb8:	38408d2c 	ldrb	w12, [x9, #8]!
    40201ebc:	aa0b814a 	orr	x10, x10, x11, lsl #32
    40201ec0:	aa0d218b 	orr	x11, x12, x13, lsl #8
    40201ec4:	39400d2c 	ldrb	w12, [x9, #3]
    40201ec8:	3940092d 	ldrb	w13, [x9, #2]
    40201ecc:	d370bdad 	lsl	x13, x13, #16
    40201ed0:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40201ed4:	aa0b018b 	orr	x11, x12, x11
    40201ed8:	3940152c 	ldrb	w12, [x9, #5]
    40201edc:	39401129 	ldrb	w9, [x9, #4]
    40201ee0:	2a0c2129 	orr	w9, w9, w12, lsl #8
    40201ee4:	aa098169 	orr	x9, x11, x9, lsl #32
    40201ee8:	eb1b013f 	cmp	x9, x27
    40201eec:	fa5c0140 	ccmp	x10, x28, #0x0, eq  // eq = none
    40201ef0:	540000a0 	b.eq	40201f04 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x2e8>  // b.none
    40201ef4:	f10102ff 	cmp	x23, #0x40
    40201ef8:	aa1403fd 	mov	x29, x20
    40201efc:	54fff882 	b.cs	40201e0c <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1f0>  // b.hs, b.nlast
    40201f00:	1400007d 	b	402020f4 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x4d8>
    40201f04:	3707f5e8 	tbnz	w8, #0, 40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>
    40201f08:	aa1d03e8 	mov	x8, x29
    40201f0c:	38404d09 	ldrb	w9, [x8, #4]!
    40201f10:	3940050a 	ldrb	w10, [x8, #1]
    40201f14:	2a0a2129 	orr	w9, w9, w10, lsl #8
    40201f18:	39400d0a 	ldrb	w10, [x8, #3]
    40201f1c:	39400908 	ldrb	w8, [x8, #2]
    40201f20:	53103d08 	lsl	w8, w8, #16
    40201f24:	2a0a6108 	orr	w8, w8, w10, lsl #24
    40201f28:	2a090108 	orr	w8, w8, w9
    40201f2c:	71001d1f 	cmp	w8, #0x7
    40201f30:	54fff481 	b.ne	40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>  // b.any
    40201f34:	aa1d03e8 	mov	x8, x29
    40201f38:	38408d09 	ldrb	w9, [x8, #8]!
    40201f3c:	3940050a 	ldrb	w10, [x8, #1]
    40201f40:	aa0a2129 	orr	x9, x9, x10, lsl #8
    40201f44:	39400d0a 	ldrb	w10, [x8, #3]
    40201f48:	3940090b 	ldrb	w11, [x8, #2]
    40201f4c:	d370bd6b 	lsl	x11, x11, #16
    40201f50:	aa0a616a 	orr	x10, x11, x10, lsl #24
    40201f54:	3940150b 	ldrb	w11, [x8, #5]
    40201f58:	38404d0c 	ldrb	w12, [x8, #4]!
    40201f5c:	aa090149 	orr	x9, x10, x9
    40201f60:	2a0b218a 	orr	w10, w12, w11, lsl #8
    40201f64:	39400d0b 	ldrb	w11, [x8, #3]
    40201f68:	39400908 	ldrb	w8, [x8, #2]
    40201f6c:	53103d08 	lsl	w8, w8, #16
    40201f70:	2a0b6108 	orr	w8, w8, w11, lsl #24
    40201f74:	2a0a0108 	orr	w8, w8, w10
    40201f78:	aa088128 	orr	x8, x9, x8, lsl #32
    40201f7c:	f100091f 	cmp	x8, #0x2
    40201f80:	54fff201 	b.ne	40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>  // b.any
    40201f84:	aa1d03e8 	mov	x8, x29
    40201f88:	38420d09 	ldrb	w9, [x8, #32]!
    40201f8c:	aa0803ea 	mov	x10, x8
    40201f90:	385f8d4b 	ldrb	w11, [x10, #-8]!
    40201f94:	385f910c 	ldurb	w12, [x8, #-7]
    40201f98:	385fd10d 	ldurb	w13, [x8, #-3]
    40201f9c:	3940050e 	ldrb	w14, [x8, #1]
    40201fa0:	39400d0f 	ldrb	w15, [x8, #3]
    40201fa4:	39400910 	ldrb	w16, [x8, #2]
    40201fa8:	aa0e2129 	orr	x9, x9, x14, lsl #8
    40201fac:	39400d4e 	ldrb	w14, [x10, #3]
    40201fb0:	aa0c216b 	orr	x11, x11, x12, lsl #8
    40201fb4:	3940094c 	ldrb	w12, [x10, #2]
    40201fb8:	d370be10 	lsl	x16, x16, #16
    40201fbc:	aa0f620f 	orr	x15, x16, x15, lsl #24
    40201fc0:	38404d50 	ldrb	w16, [x10, #4]!
    40201fc4:	2a0d220d 	orr	w13, w16, w13, lsl #8
    40201fc8:	d370bd8c 	lsl	x12, x12, #16
    40201fcc:	aa0e618c 	orr	x12, x12, x14, lsl #24
    40201fd0:	39400d4e 	ldrb	w14, [x10, #3]
    40201fd4:	3940094a 	ldrb	w10, [x10, #2]
    40201fd8:	53103d4a 	lsl	w10, w10, #16
    40201fdc:	2a0e614a 	orr	w10, w10, w14, lsl #24
    40201fe0:	aa0b018b 	orr	x11, x12, x11
    40201fe4:	2a0d014a 	orr	w10, w10, w13
    40201fe8:	aa0a8175 	orr	x21, x11, x10, lsl #32
    40201fec:	3940150a 	ldrb	w10, [x8, #5]
    40201ff0:	38404d0b 	ldrb	w11, [x8, #4]!
    40201ff4:	aa0901e9 	orr	x9, x15, x9
    40201ff8:	2a0a216a 	orr	w10, w11, w10, lsl #8
    40201ffc:	3940090b 	ldrb	w11, [x8, #2]
    40202000:	53103d6b 	lsl	w11, w11, #16
    40202004:	39400d08 	ldrb	w8, [x8, #3]
    40202008:	2a086168 	orr	w8, w11, w8, lsl #24
    4020200c:	2a0a0108 	orr	w8, w8, w10
    40202010:	aa088129 	orr	x9, x9, x8, lsl #32
    40202014:	ab150128 	adds	x8, x9, x21
    40202018:	54ffed42 	b.cs	40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>  // b.hs, b.nlast
    4020201c:	f100613f 	cmp	x9, #0x18
    40202020:	54ffed01 	b.ne	40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>  // b.any
    40202024:	52869c09 	mov	w9, #0x34e0                	// #13536
    40202028:	eb09011f 	cmp	x8, x9
    4020202c:	54ffeca8 	b.hi	40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>  // b.pmore
    40202030:	8b150260 	add	x0, x19, x21
    40202034:	d503201f 	nop
    40202038:	1002bd81 	adr	x1, 402077e8 <jnox_native_el0_image+0x34f8>
    4020203c:	52800302 	mov	w2, #0x18                  	// #24
    40202040:	9400066f 	bl	402039fc <memcmp>
    40202044:	35ffebe0 	cbnz	w0, 40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>
    40202048:	38410fa8 	ldrb	w8, [x29, #16]!
    4020204c:	394007a9 	ldrb	w9, [x29, #1]
    40202050:	39400faa 	ldrb	w10, [x29, #3]
    40202054:	aa092108 	orr	x8, x8, x9, lsl #8
    40202058:	39400ba9 	ldrb	w9, [x29, #2]
    4020205c:	d370bd29 	lsl	x9, x9, #16
    40202060:	aa0a6129 	orr	x9, x9, x10, lsl #24
    40202064:	aa080128 	orr	x8, x9, x8
    40202068:	394017a9 	ldrb	w9, [x29, #5]
    4020206c:	38404faa 	ldrb	w10, [x29, #4]!
    40202070:	2a092149 	orr	w9, w10, w9, lsl #8
    40202074:	39400faa 	ldrb	w10, [x29, #3]
    40202078:	39400bab 	ldrb	w11, [x29, #2]
    4020207c:	53103d6b 	lsl	w11, w11, #16
    40202080:	2a0a616a 	orr	w10, w11, w10, lsl #24
    40202084:	2a090149 	orr	w9, w10, w9
    40202088:	aa098108 	orr	x8, x8, x9, lsl #32
    4020208c:	f94007e9 	ldr	x9, [sp, #8]
    40202090:	aa1603ea 	mov	x10, x22
    40202094:	f85f814b 	ldur	x11, [x10, #-8]
    40202098:	eb0b010b 	subs	x11, x8, x11
    4020209c:	3940614c 	ldrb	w12, [x10, #24]
    402020a0:	7a402980 	ccmp	w12, #0x0, #0x0, cs  // cs = hs, nlast
    402020a4:	54000181 	b.ne	402020d4 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x4b8>  // b.any
    402020a8:	f940014c 	ldr	x12, [x10]
    402020ac:	8b0b018d 	add	x13, x12, x11
    402020b0:	eb0c01bf 	cmp	x13, x12
    402020b4:	fa5521a0 	ccmp	x13, x21, #0x0, cs  // cs = hs, nlast
    402020b8:	540000e1 	b.ne	402020d4 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x4b8>  // b.any
    402020bc:	b100657f 	cmn	x11, #0x19
    402020c0:	540000a8 	b.hi	402020d4 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x4b8>  // b.pmore
    402020c4:	9100616b 	add	x11, x11, #0x18
    402020c8:	f85f014c 	ldur	x12, [x10, #-16]
    402020cc:	eb0c017f 	cmp	x11, x12
    402020d0:	540000a9 	b.ls	402020e4 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x4c8>  // b.plast
    402020d4:	9100e14a 	add	x10, x10, #0x38
    402020d8:	f100e129 	subs	x9, x9, #0x38
    402020dc:	54ffe720 	b.eq	40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>  // b.none
    402020e0:	17ffffed 	b	40202094 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x478>
    402020e4:	52800028 	mov	w8, #0x1                   	// #1
    402020e8:	f10102ff 	cmp	x23, #0x40
    402020ec:	54ffe8e2 	b.cs	40201e08 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1ec>  // b.hs, b.nlast
    402020f0:	14000002 	b	402020f8 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x4dc>
    402020f4:	3607e668 	tbz	w8, #0, 40201dc0 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x1a4>
    402020f8:	6f00e400 	movi	v0.2d, #0x0
    402020fc:	ad1d83e0 	stp	q0, q0, [sp, #944]
    40202100:	5281f613 	mov	w19, #0xfb0                 	// #4016
    40202104:	72a02033 	movk	w19, #0x101, lsl #16
    40202108:	910ec3e8 	add	x8, sp, #0x3b0
    4020210c:	d0000001 	adrp	x1, 40204000 <memset+0x7c>
    40202110:	9103b421 	add	x1, x1, #0xed
    40202114:	91008100 	add	x0, x8, #0x20
    40202118:	52800122 	mov	w2, #0x9                   	// #9
    4020211c:	9400070e 	bl	40203d54 <memcpy>
    40202120:	52800034 	mov	w20, #0x1                   	// #1
    40202124:	9100c268 	add	x8, x19, #0x30
    40202128:	a91e23f4 	stp	x20, x8, [sp, #480]
    4020212c:	910783f5 	add	x21, sp, #0x1e0
    40202130:	910042a0 	add	x0, x21, #0x10
    40202134:	910ec3e1 	add	x1, sp, #0x3b0
    40202138:	52800522 	mov	w2, #0x29                  	// #41
    4020213c:	94000706 	bl	40203d54 <memcpy>
    40202140:	9100e6a0 	add	x0, x21, #0x39
    40202144:	2a1f03e1 	mov	w1, wzr
    40202148:	528002e2 	mov	w2, #0x17                  	// #23
    4020214c:	9400078e 	bl	40203f84 <memset>
    40202150:	d5034fdf 	msr	daifset, #0xf
    40202154:	d51be23f 	msr	cntp_ctl_el0, xzr
    40202158:	d51be33f 	msr	cntv_ctl_el0, xzr
    4020215c:	d5033fdf 	isb
    40202160:	52a10028 	mov	w8, #0x8010000             	// #134283264
    40202164:	b900011f 	str	wzr, [x8]
    40202168:	52a10009 	mov	w9, #0x8000000             	// #134217728
    4020216c:	b900013f 	str	wzr, [x9]
    40202170:	d5033f9f 	dsb	sy
    40202174:	d5033fdf 	isb
    40202178:	b900013f 	str	wzr, [x9]
    4020217c:	b900011f 	str	wzr, [x8]
    40202180:	5280100a 	mov	w10, #0x80                  	// #128
    40202184:	72a1000a 	movk	w10, #0x800, lsl #16
    40202188:	b940014b 	ldr	w11, [x10]
    4020218c:	1201796b 	and	w11, w11, #0xbfffffff
    40202190:	b900014b 	str	w11, [x10]
    40202194:	5280100b 	mov	w11, #0x80                  	// #128
    40202198:	390e794b 	strb	w11, [x10, #926]
    4020219c:	52a8000b 	mov	w11, #0x40000000            	// #1073741824
    402021a0:	b902014b 	str	w11, [x10, #512]
    402021a4:	b900814b 	str	w11, [x10, #128]
    402021a8:	5280008a 	mov	w10, #0x4                   	// #4
    402021ac:	72a1002a 	movk	w10, #0x801, lsl #16
    402021b0:	52801feb 	mov	w11, #0xff                  	// #255
    402021b4:	b900014b 	str	w11, [x10]
    402021b8:	b9000134 	str	w20, [x9]
    402021bc:	b9000114 	str	w20, [x8]
    402021c0:	d5033f9f 	dsb	sy
    402021c4:	d5033fdf 	isb
    402021c8:	910043e0 	add	x0, sp, #0x10
    402021cc:	910783e1 	add	x1, sp, #0x1e0
    402021d0:	52800a02 	mov	w2, #0x50                  	// #80
    402021d4:	97fff9b2 	bl	4020089c <_ZN11jnox_kernel14native_el0_mmu7install17h1b461f360fadccbbE>
    402021d8:	b5000460 	cbnz	x0, 40202264 <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x648>
    402021dc:	d5384248 	mrs	x8, currentel
    402021e0:	d5381015 	mrs	x21, sctlr_el1
    402021e4:	d5382014 	mrs	x20, ttbr0_el1
    402021e8:	f100111f 	cmp	x8, #0x4
    402021ec:	54000401 	b.ne	4020226c <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x650>  // b.any
    402021f0:	360003f5 	tbz	w21, #0, 4020226c <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x650>
    402021f4:	5281f600 	mov	w0, #0xfb0                 	// #4016
    402021f8:	72a02020 	movk	w0, #0x101, lsl #16
    402021fc:	52800a01 	mov	w1, #0x50                  	// #80
    40202200:	52800022 	mov	w2, #0x1                   	// #1
    40202204:	97fff961 	bl	40200788 <_ZN11jnox_kernel14native_el0_mmu10user_range17hd9e60a9ff18ef9c3E>
    40202208:	36000320 	tbz	w0, #0, 4020226c <_ZN11jnox_kernel10native_el03run17h50df8840a2606aeeE+0x650>
    4020220c:	f0002148 	adrp	x8, 4062d000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3fe0>
    40202210:	91012108 	add	x8, x8, #0x48
    40202214:	52a00809 	mov	w9, #0x400000              	// #4194304
    40202218:	f9000d09 	str	x9, [x8, #24]
    4020221c:	f9001113 	str	x19, [x8, #32]
    40202220:	52820009 	mov	w9, #0x1000                	// #4096
    40202224:	72a02009 	movk	w9, #0x100, lsl #16
    40202228:	9101426a 	add	x10, x19, #0x50
    4020222c:	f9001509 	str	x9, [x8, #40]
    40202230:	f900190a 	str	x10, [x8, #48]
    40202234:	52800089 	mov	w9, #0x4                   	// #4
    40202238:	f9002d09 	str	x9, [x8, #88]
    4020223c:	f9003115 	str	x21, [x8, #96]
    40202240:	f9003514 	str	x20, [x8, #104]
    40202244:	52800029 	mov	w9, #0x1                   	// #1
    40202248:	f9003909 	str	x9, [x8, #112]
    4020224c:	52800049 	mov	w9, #0x2                   	// #2
    40202250:	f9000109 	str	x9, [x8]
    40202254:	52a00800 	mov	w0, #0x400000              	// #4194304
    40202258:	5281f601 	mov	w1, #0xfb0                 	// #4016
    4020225c:	72a02021 	movk	w1, #0x101, lsl #16
    40202260:	97fffd68 	bl	40201800 <native_el0_enter>
    40202264:	528000c0 	mov	w0, #0x6                   	// #6
    40202268:	94000008 	bl	40202288 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    4020226c:	528000e0 	mov	w0, #0x7                   	// #7
    40202270:	94000006 	bl	40202288 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    40202274:	d503201f 	nop
    40202278:	1000fbc3 	adr	x3, 402041f0 <anon.942724a4c970943425c58f68468d0017.5.llvm.10821731386268321571>
    4020227c:	aa1f03e0 	mov	x0, xzr
    40202280:	52800102 	mov	w2, #0x8                   	// #8
    40202284:	94000533 	bl	40203750 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>

0000000040202288 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>:
    40202288:	a9bf4ffe 	stp	x30, x19, [sp, #-16]!
    4020228c:	aa1f03e8 	mov	x8, xzr
    40202290:	52800313 	mov	w19, #0x18                  	// #24
    40202294:	72a12013 	movk	w19, #0x900, lsl #16
    40202298:	f0002149 	adrp	x9, 4062d000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3fe0>
    4020229c:	91012129 	add	x9, x9, #0x48
    402022a0:	f9000520 	str	x0, [x9, #8]
    402022a4:	5280008a 	mov	w10, #0x4                   	// #4
    402022a8:	f900012a 	str	x10, [x9]
    402022ac:	d5033f9f 	dsb	sy
    402022b0:	52a12009 	mov	w9, #0x9000000             	// #150994944
    402022b4:	d503201f 	nop
    402022b8:	7002acaa 	adr	x10, 4020784f <jnox_native_el0_image+0x355f>
    402022bc:	3868694b 	ldrb	w11, [x10, x8]
    402022c0:	b940026c 	ldr	w12, [x19]
    402022c4:	3628006c 	tbz	w12, #5, 402022d0 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E+0x48>
    402022c8:	d5033fdf 	isb
    402022cc:	17fffffd 	b	402022c0 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E+0x38>
    402022d0:	91000508 	add	x8, x8, #0x1
    402022d4:	b900012b 	str	w11, [x9]
    402022d8:	f100451f 	cmp	x8, #0x11
    402022dc:	54ffff01 	b.ne	402022bc <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E+0x34>  // b.any
    402022e0:	9400000a 	bl	40202308 <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E>
    402022e4:	b9400268 	ldr	w8, [x19]
    402022e8:	36280068 	tbz	w8, #5, 402022f4 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E+0x6c>
    402022ec:	d5033fdf 	isb
    402022f0:	17fffffd 	b	402022e4 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E+0x5c>
    402022f4:	52a12008 	mov	w8, #0x9000000             	// #150994944
    402022f8:	52800149 	mov	w9, #0xa                   	// #10
    402022fc:	b9000109 	str	w9, [x8]
    40202300:	d503205f 	wfe
    40202304:	17ffffff 	b	40202300 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E+0x78>

0000000040202308 <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E>:
    40202308:	d100c3ff 	sub	sp, sp, #0x30
    4020230c:	f90013fe 	str	x30, [sp, #32]
    40202310:	52800308 	mov	w8, #0x18                  	// #24
    40202314:	72a12008 	movk	w8, #0x900, lsl #16
    40202318:	b7f80060 	tbnz	x0, #63, 40202324 <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E+0x1c>
    4020231c:	14000007 	b	40202338 <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E+0x30>
    40202320:	d5033fdf 	isb
    40202324:	b9400109 	ldr	w9, [x8]
    40202328:	372fffc9 	tbnz	w9, #5, 40202320 <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E+0x18>
    4020232c:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202330:	528005aa 	mov	w10, #0x2d                  	// #45
    40202334:	b900012a 	str	w10, [x9]
    40202338:	f100001f 	cmp	x0, #0x0
    4020233c:	b9001bff 	str	wzr, [sp, #24]
    40202340:	52800269 	mov	w9, #0x13                  	// #19
    40202344:	b202e7ea 	mov	x10, #0xcccccccccccccccc    	// #-3689348814741910324
    40202348:	f29999aa 	movk	x10, #0xcccd
    4020234c:	da80540c 	cneg	x12, x0, mi  // mi = first
    40202350:	5280014b 	mov	w11, #0xa                   	// #10
    40202354:	a900ffff 	stp	xzr, xzr, [sp, #8]
    40202358:	910023ed 	add	x13, sp, #0x8
    4020235c:	f1004d3f 	cmp	x9, #0x13
    40202360:	54000328 	b.hi	402023c4 <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E+0xbc>  // b.pmore
    40202364:	9bca7d8e 	umulh	x14, x12, x10
    40202368:	d343fdce 	lsr	x14, x14, #3
    4020236c:	1b0bb1cf 	msub	w15, w14, w11, w12
    40202370:	321c05ef 	orr	w15, w15, #0x30
    40202374:	382969af 	strb	w15, [x13, x9]
    40202378:	d1000529 	sub	x9, x9, #0x1
    4020237c:	f100299f 	cmp	x12, #0xa
    40202380:	aa0e03ec 	mov	x12, x14
    40202384:	54fffec2 	b.cs	4020235c <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E+0x54>  // b.hs, b.nlast
    40202388:	91000529 	add	x9, x9, #0x1
    4020238c:	910023ea 	add	x10, sp, #0x8
    40202390:	52a1200b 	mov	w11, #0x9000000             	// #150994944
    40202394:	3869694c 	ldrb	w12, [x10, x9]
    40202398:	b940010d 	ldr	w13, [x8]
    4020239c:	3628006d 	tbz	w13, #5, 402023a8 <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E+0xa0>
    402023a0:	d5033fdf 	isb
    402023a4:	17fffffd 	b	40202398 <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E+0x90>
    402023a8:	91000529 	add	x9, x9, #0x1
    402023ac:	b900016c 	str	w12, [x11]
    402023b0:	f100513f 	cmp	x9, #0x14
    402023b4:	54ffff01 	b.ne	40202394 <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E+0x8c>  // b.any
    402023b8:	f94013fe 	ldr	x30, [sp, #32]
    402023bc:	9100c3ff 	add	sp, sp, #0x30
    402023c0:	d65f03c0 	ret
    402023c4:	d503201f 	nop
    402023c8:	1002a4c2 	adr	x2, 40207860 <jnox_native_el0_image+0x3570>
    402023cc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    402023d0:	52800281 	mov	w1, #0x14                  	// #20
    402023d4:	940002e0 	bl	40202f54 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

00000000402023d8 <native_el0_sync>:
    402023d8:	d103c3ff 	sub	sp, sp, #0xf0
    402023dc:	a9097bfd 	stp	x29, x30, [sp, #144]
    402023e0:	a90a6ffc 	stp	x28, x27, [sp, #160]
    402023e4:	a90b67fa 	stp	x26, x25, [sp, #176]
    402023e8:	a90c5ff8 	stp	x24, x23, [sp, #192]
    402023ec:	a90d57f6 	stp	x22, x21, [sp, #208]
    402023f0:	a90e4ff4 	stp	x20, x19, [sp, #224]
    402023f4:	d538c008 	mrs	x8, vbar_el1
    402023f8:	d5382017 	mrs	x23, ttbr0_el1
    402023fc:	d5386016 	mrs	x22, far_el1
    40202400:	f0002149 	adrp	x9, 4062d000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3fe0>
    40202404:	f940413a 	ldr	x26, [x9, #128]
    40202408:	f110003f 	cmp	x1, #0x400
    4020240c:	54003001 	b.ne	40202a0c <native_el0_sync+0x634>  // b.any
    40202410:	d503201f 	nop
    40202414:	10ff5f78 	adr	x24, 40201000 <native_el0_vectors>
    40202418:	eb18011f 	cmp	x8, x24
    4020241c:	54002f81 	b.ne	40202a0c <native_el0_sync+0x634>  // b.any
    40202420:	aa0003f3 	mov	x19, x0
    40202424:	f9408c08 	ldr	x8, [x0, #280]
    40202428:	f100111f 	cmp	x8, #0x4
    4020242c:	54002f01 	b.ne	40202a0c <native_el0_sync+0x634>  // b.any
    40202430:	39440268 	ldrb	w8, [x19, #256]
    40202434:	7200111f 	tst	w8, #0x1f
    40202438:	54002ea1 	b.ne	40202a0c <native_el0_sync+0x634>  // b.any
    4020243c:	f9407e68 	ldr	x8, [x19, #248]
    40202440:	9266d508 	and	x8, x8, #0xfffffffffc00ffff
    40202444:	52894029 	mov	w9, #0x4a01                	// #18945
    40202448:	72aa8009 	movk	w9, #0x5400, lsl #16
    4020244c:	eb09011f 	cmp	x8, x9
    40202450:	54002de1 	b.ne	40202a0c <native_el0_sync+0x634>  // b.any
    40202454:	f9408660 	ldr	x0, [x19, #264]
    40202458:	52800081 	mov	w1, #0x4                   	// #4
    4020245c:	2a1f03e2 	mov	w2, wzr
    40202460:	97fff8ca 	bl	40200788 <_ZN11jnox_kernel14native_el0_mmu10user_range17hd9e60a9ff18ef9c3E>
    40202464:	34002d40 	cbz	w0, 40202a0c <native_el0_sync+0x634>
    40202468:	9281fffc 	mov	x28, #0xfffffffffffff000    	// #-4096
    4020246c:	f2bfdffc 	movk	x28, #0xfeff, lsl #16
    40202470:	f9408a68 	ldr	x8, [x19, #272]
    40202474:	8b1c0109 	add	x9, x8, x28
    40202478:	f140413f 	cmp	x9, #0x10, lsl #12
    4020247c:	54002c88 	b.hi	40202a0c <native_el0_sync+0x634>  // b.pmore
    40202480:	92400d08 	and	x8, x8, #0xf
    40202484:	b5002c48 	cbnz	x8, 40202a0c <native_el0_sync+0x634>
    40202488:	f9402279 	ldr	x25, [x19, #64]
    4020248c:	f100073f 	cmp	x25, #0x1
    40202490:	540000e1 	b.ne	402024ac <native_el0_sync+0xd4>  // b.any
    40202494:	f9400268 	ldr	x8, [x19]
    40202498:	eb28c11f 	cmp	x8, w8, sxtw
    4020249c:	54002bc1 	b.ne	40202a14 <native_el0_sync+0x63c>  // b.any
    402024a0:	aa1f03e0 	mov	x0, xzr
    402024a4:	5280005b 	mov	w27, #0x2                   	// #2
    402024a8:	140000df 	b	40202824 <native_el0_sync+0x44c>
    402024ac:	f1001b3f 	cmp	x25, #0x6
    402024b0:	540010e0 	b.eq	402026cc <native_el0_sync+0x2f4>  // b.none
    402024b4:	f1001f3f 	cmp	x25, #0x7
    402024b8:	54001a61 	b.ne	40202804 <native_el0_sync+0x42c>  // b.any
    402024bc:	f9400268 	ldr	x8, [x19]
    402024c0:	928002a0 	mov	x0, #0xffffffffffffffea    	// #-22
    402024c4:	5280003b 	mov	w27, #0x1                   	// #1
    402024c8:	f100051f 	cmp	x8, #0x1
    402024cc:	54001ac1 	b.ne	40202824 <native_el0_sync+0x44c>  // b.any
    402024d0:	f9400668 	ldr	x8, [x19, #8]
    402024d4:	f100051f 	cmp	x8, #0x1
    402024d8:	54001a61 	b.ne	40202824 <native_el0_sync+0x44c>  // b.any
    402024dc:	f9400a74 	ldr	x20, [x19, #16]
    402024e0:	aa1403e0 	mov	x0, x20
    402024e4:	52800201 	mov	w1, #0x10                  	// #16
    402024e8:	2a1f03e2 	mov	w2, wzr
    402024ec:	97fff8a7 	bl	40200788 <_ZN11jnox_kernel14native_el0_mmu10user_range17hd9e60a9ff18ef9c3E>
    402024f0:	34001960 	cbz	w0, 4020281c <native_el0_sync+0x444>
    402024f4:	f160029f 	cmp	x20, #0x800, lsl #12
    402024f8:	b26aa7e8 	mov	x8, #0xffffffffffc00000    	// #-4194304
    402024fc:	f00020a9 	adrp	x9, 40619000 <_ZN11jnox_kernel14native_el0_mmu9STACK_RAM17hea56fe12f71dda0dE.llvm.10821731386268321571>
    40202500:	91000129 	add	x9, x9, #0x0
    40202504:	9a9c3108 	csel	x8, x8, x28, cc  // cc = lo, ul, last
    40202508:	d503201f 	nop
    4020250c:	100ad7aa 	adr	x10, 40218000 <_ZN11jnox_kernel14native_el0_mmu9IMAGE_RAM17h5e31979acdec2fe2E.llvm.10821731386268321571>
    40202510:	9a893149 	csel	x9, x10, x9, cc  // cc = lo, ul, last
    40202514:	8b080128 	add	x8, x9, x8
    40202518:	8b140109 	add	x9, x8, x20
    4020251c:	39400528 	ldrb	w8, [x9, #1]
    40202520:	3940012a 	ldrb	w10, [x9]
    40202524:	aa082148 	orr	x8, x10, x8, lsl #8
    40202528:	39400d2a 	ldrb	w10, [x9, #3]
    4020252c:	3940092b 	ldrb	w11, [x9, #2]
    40202530:	d370bd6b 	lsl	x11, x11, #16
    40202534:	aa0a616a 	orr	x10, x11, x10, lsl #24
    40202538:	aa080148 	orr	x8, x10, x8
    4020253c:	3940152a 	ldrb	w10, [x9, #5]
    40202540:	aa0903eb 	mov	x11, x9
    40202544:	38404d6c 	ldrb	w12, [x11, #4]!
    40202548:	2a0a218a 	orr	w10, w12, w10, lsl #8
    4020254c:	39400d6c 	ldrb	w12, [x11, #3]
    40202550:	3940096b 	ldrb	w11, [x11, #2]
    40202554:	53103d6b 	lsl	w11, w11, #16
    40202558:	2a0c616b 	orr	w11, w11, w12, lsl #24
    4020255c:	2a0a016a 	orr	w10, w11, w10
    40202560:	aa0a8108 	orr	x8, x8, x10, lsl #32
    40202564:	928002a0 	mov	x0, #0xffffffffffffffea    	// #-22
    40202568:	5280003b 	mov	w27, #0x1                   	// #1
    4020256c:	b7f815c8 	tbnz	x8, #63, 40202824 <native_el0_sync+0x44c>
    40202570:	3940252a 	ldrb	w10, [x9, #9]
    40202574:	aa0903eb 	mov	x11, x9
    40202578:	38408d6c 	ldrb	w12, [x11, #8]!
    4020257c:	aa0a218a 	orr	x10, x12, x10, lsl #8
    40202580:	39400d6c 	ldrb	w12, [x11, #3]
    40202584:	3940096d 	ldrb	w13, [x11, #2]
    40202588:	d370bdad 	lsl	x13, x13, #16
    4020258c:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40202590:	aa0a018a 	orr	x10, x12, x10
    40202594:	39403529 	ldrb	w9, [x9, #13]
    40202598:	38404d6c 	ldrb	w12, [x11, #4]!
    4020259c:	2a092189 	orr	w9, w12, w9, lsl #8
    402025a0:	39400d6c 	ldrb	w12, [x11, #3]
    402025a4:	3940096b 	ldrb	w11, [x11, #2]
    402025a8:	53103d6b 	lsl	w11, w11, #16
    402025ac:	2a0c616b 	orr	w11, w11, w12, lsl #24
    402025b0:	2a090169 	orr	w9, w11, w9
    402025b4:	aa098149 	orr	x9, x10, x9, lsl #32
    402025b8:	52993fea 	mov	w10, #0xc9ff                	// #51711
    402025bc:	72a7734a 	movk	w10, #0x3b9a, lsl #16
    402025c0:	eb0a013f 	cmp	x9, x10
    402025c4:	54001308 	b.hi	40202824 <native_el0_sync+0x44c>  // b.pmore
    402025c8:	f000212a 	adrp	x10, 40629000 <_ZN11jnox_kernel9BSS_PROBE17h33657fc229f3152bE>
    402025cc:	f940054a 	ldr	x10, [x10, #8]
    402025d0:	f90007ea 	str	x10, [sp, #8]
    402025d4:	f000212a 	adrp	x10, 40629000 <_ZN11jnox_kernel9BSS_PROBE17h33657fc229f3152bE>
    402025d8:	f940094a 	ldr	x10, [x10, #16]
    402025dc:	9bc87d5c 	umulh	x28, x10, x8
    402025e0:	9b087d5d 	mul	x29, x10, x8
    402025e4:	9b097d54 	mul	x20, x10, x9
    402025e8:	9bc97d55 	umulh	x21, x10, x9
    402025ec:	5299401b 	mov	w27, #0xca00                	// #51712
    402025f0:	72a7735b 	movk	w27, #0x3b9a, lsl #16
    402025f4:	aa1403e0 	mov	x0, x20
    402025f8:	aa1503e1 	mov	x1, x21
    402025fc:	52994002 	mov	w2, #0xca00                	// #51712
    40202600:	72a77342 	movk	w2, #0x3b9a, lsl #16
    40202604:	aa1f03e3 	mov	x3, xzr
    40202608:	94000507 	bl	40203a24 <__udivti3>
    4020260c:	9bdb7c08 	umulh	x8, x0, x27
    40202610:	9b1b2028 	madd	x8, x1, x27, x8
    40202614:	9b1b7c09 	mul	x9, x0, x27
    40202618:	eb090289 	subs	x9, x20, x9
    4020261c:	da0802a8 	sbc	x8, x21, x8
    40202620:	aa080128 	orr	x8, x9, x8
    40202624:	f100011f 	cmp	x8, #0x0
    40202628:	1a9f07e8 	cset	w8, ne  // ne = any
    4020262c:	f94007e9 	ldr	x9, [sp, #8]
    40202630:	ab0903a9 	adds	x9, x29, x9
    40202634:	9a9c378a 	cinc	x10, x28, cs  // cs = hs, nlast
    40202638:	ab000129 	adds	x9, x9, x0
    4020263c:	9a01014a 	adc	x10, x10, x1
    40202640:	ab080128 	adds	x8, x9, x8
    40202644:	9a8a3549 	cinc	x9, x10, cs  // cs = hs, nlast
    40202648:	b5000e69 	cbnz	x9, 40202814 <native_el0_sync+0x43c>
    4020264c:	d5033fdf 	isb
    40202650:	d53be029 	mrs	x9, cntpct_el0
    40202654:	eb08013f 	cmp	x9, x8
    40202658:	54001b42 	b.cs	402029c0 <native_el0_sync+0x5e8>  // b.hs, b.nlast
    4020265c:	f0002154 	adrp	x20, 4062d000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3fe0>
    40202660:	91008294 	add	x20, x20, #0x20
    40202664:	52800029 	mov	w9, #0x1                   	// #1
    40202668:	a9002289 	stp	x9, x8, [x20]
    4020266c:	a9015e93 	stp	x19, x23, [x20, #16]
    40202670:	d51be248 	msr	cntp_cval_el0, x8
    40202674:	d51be229 	msr	cntp_ctl_el0, x9
    40202678:	d5033fdf 	isb
    4020267c:	d5033fdf 	isb
    40202680:	d53be028 	mrs	x8, cntpct_el0
    40202684:	f9400289 	ldr	x9, [x20]
    40202688:	f100053f 	cmp	x9, #0x1
    4020268c:	540019e1 	b.ne	402029c8 <native_el0_sync+0x5f0>  // b.any
    40202690:	f9400689 	ldr	x9, [x20, #8]
    40202694:	eb09011f 	cmp	x8, x9
    40202698:	54001983 	b.cc	402029c8 <native_el0_sync+0x5f0>  // b.lo, b.ul, b.last
    4020269c:	a9412289 	ldp	x9, x8, [x20, #16]
    402026a0:	d51be23f 	msr	cntp_ctl_el0, xzr
    402026a4:	d5033fdf 	isb
    402026a8:	5280004a 	mov	w10, #0x2                   	// #2
    402026ac:	a900268a 	stp	x10, x9, [x20]
    402026b0:	f9000a88 	str	x8, [x20, #16]
    402026b4:	52805008 	mov	w8, #0x280                 	// #640
    402026b8:	72a10008 	movk	w8, #0x800, lsl #16
    402026bc:	52a80009 	mov	w9, #0x40000000            	// #1073741824
    402026c0:	b9000109 	str	w9, [x8]
    402026c4:	d5033f9f 	dsb	sy
    402026c8:	140000c3 	b	402029d4 <native_el0_sync+0x5fc>
    402026cc:	f9400268 	ldr	x8, [x19]
    402026d0:	f100051f 	cmp	x8, #0x1
    402026d4:	540009c1 	b.ne	4020280c <native_el0_sync+0x434>  // b.any
    402026d8:	f9400674 	ldr	x20, [x19, #8]
    402026dc:	f0002128 	adrp	x8, 40629000 <_ZN11jnox_kernel9BSS_PROBE17h33657fc229f3152bE>
    402026e0:	f9400508 	ldr	x8, [x8, #8]
    402026e4:	f0002129 	adrp	x9, 40629000 <_ZN11jnox_kernel9BSS_PROBE17h33657fc229f3152bE>
    402026e8:	f9400935 	ldr	x21, [x9, #16]
    402026ec:	d5033fdf 	isb
    402026f0:	d53be029 	mrs	x9, cntpct_el0
    402026f4:	eb08013d 	subs	x29, x9, x8
    402026f8:	540008e3 	b.cc	40202814 <native_el0_sync+0x43c>  // b.lo, b.ul, b.last
    402026fc:	b4001915 	cbz	x21, 40202a1c <native_el0_sync+0x644>
    40202700:	9ad50ba8 	udiv	x8, x29, x21
    40202704:	b7f80888 	tbnz	x8, #63, 40202814 <native_el0_sync+0x43c>
    40202708:	f90007e8 	str	x8, [sp, #8]
    4020270c:	5280003b 	mov	w27, #0x1                   	// #1
    40202710:	aa1403e0 	mov	x0, x20
    40202714:	52800201 	mov	w1, #0x10                  	// #16
    40202718:	52800022 	mov	w2, #0x1                   	// #1
    4020271c:	97fff81b 	bl	40200788 <_ZN11jnox_kernel14native_el0_mmu10user_range17hd9e60a9ff18ef9c3E>
    40202720:	340014c0 	cbz	w0, 402029b8 <native_el0_sync+0x5e0>
    40202724:	52994008 	mov	w8, #0xca00                	// #51712
    40202728:	72a77348 	movk	w8, #0x3b9a, lsl #16
    4020272c:	9b087fa0 	mul	x0, x29, x8
    40202730:	9bc87fa1 	umulh	x1, x29, x8
    40202734:	aa1503e2 	mov	x2, x21
    40202738:	aa1f03e3 	mov	x3, xzr
    4020273c:	940004ba 	bl	40203a24 <__udivti3>
    40202740:	52994002 	mov	w2, #0xca00                	// #51712
    40202744:	72a77342 	movk	w2, #0x3b9a, lsl #16
    40202748:	aa1f03e3 	mov	x3, xzr
    4020274c:	94000605 	bl	40203f60 <__umodti3>
    40202750:	aa0003e8 	mov	x8, x0
    40202754:	aa1f03e0 	mov	x0, xzr
    40202758:	f160029f 	cmp	x20, #0x800, lsl #12
    4020275c:	b26aa7e9 	mov	x9, #0xffffffffffc00000    	// #-4194304
    40202760:	f00020aa 	adrp	x10, 40619000 <_ZN11jnox_kernel14native_el0_mmu9STACK_RAM17hea56fe12f71dda0dE.llvm.10821731386268321571>
    40202764:	9100014a 	add	x10, x10, #0x0
    40202768:	9a9c3129 	csel	x9, x9, x28, cc  // cc = lo, ul, last
    4020276c:	d503201f 	nop
    40202770:	100ac48b 	adr	x11, 40218000 <_ZN11jnox_kernel14native_el0_mmu9IMAGE_RAM17h5e31979acdec2fe2E.llvm.10821731386268321571>
    40202774:	9a8a316a 	csel	x10, x11, x10, cc  // cc = lo, ul, last
    40202778:	8b090149 	add	x9, x10, x9
    4020277c:	8b140129 	add	x9, x9, x20
    40202780:	f94007ec 	ldr	x12, [sp, #8]
    40202784:	d368fd8a 	lsr	x10, x12, #40
    40202788:	3900152a 	strb	w10, [x9, #5]
    4020278c:	d358fd8a 	lsr	x10, x12, #24
    40202790:	39000d2a 	strb	w10, [x9, #3]
    40202794:	d350fd8a 	lsr	x10, x12, #16
    40202798:	3900092a 	strb	w10, [x9, #2]
    4020279c:	d348fd8a 	lsr	x10, x12, #8
    402027a0:	3900052a 	strb	w10, [x9, #1]
    402027a4:	3900012c 	strb	w12, [x9]
    402027a8:	d368fd0a 	lsr	x10, x8, #40
    402027ac:	3900352a 	strb	w10, [x9, #13]
    402027b0:	aa0903ea 	mov	x10, x9
    402027b4:	38008d48 	strb	w8, [x10, #8]!
    402027b8:	d358fd0b 	lsr	x11, x8, #24
    402027bc:	39000d4b 	strb	w11, [x10, #3]
    402027c0:	d348fd0b 	lsr	x11, x8, #8
    402027c4:	3900252b 	strb	w11, [x9, #9]
    402027c8:	d360fd8b 	lsr	x11, x12, #32
    402027cc:	38004d2b 	strb	w11, [x9, #4]!
    402027d0:	d350fd0b 	lsr	x11, x8, #16
    402027d4:	3900094b 	strb	w11, [x10, #2]
    402027d8:	d360fd0b 	lsr	x11, x8, #32
    402027dc:	38004d4b 	strb	w11, [x10, #4]!
    402027e0:	d378fd8b 	lsr	x11, x12, #56
    402027e4:	39000d2b 	strb	w11, [x9, #3]
    402027e8:	d370fd8b 	lsr	x11, x12, #48
    402027ec:	3900092b 	strb	w11, [x9, #2]
    402027f0:	d378fd09 	lsr	x9, x8, #56
    402027f4:	39000d49 	strb	w9, [x10, #3]
    402027f8:	d370fd08 	lsr	x8, x8, #48
    402027fc:	39000948 	strb	w8, [x10, #2]
    40202800:	14000008 	b	40202820 <native_el0_sync+0x448>
    40202804:	928004a0 	mov	x0, #0xffffffffffffffda    	// #-38
    40202808:	14000006 	b	40202820 <native_el0_sync+0x448>
    4020280c:	928002a0 	mov	x0, #0xffffffffffffffea    	// #-22
    40202810:	14000004 	b	40202820 <native_el0_sync+0x448>
    40202814:	92800940 	mov	x0, #0xffffffffffffffb5    	// #-75
    40202818:	14000002 	b	40202820 <native_el0_sync+0x448>
    4020281c:	928001a0 	mov	x0, #0xfffffffffffffff2    	// #-14
    40202820:	5280003b 	mov	w27, #0x1                   	// #1
    40202824:	f1001f5f 	cmp	x26, #0x7
    40202828:	528000e8 	mov	w8, #0x7                   	// #7
    4020282c:	9a883348 	csel	x8, x26, x8, cc  // cc = lo, ul, last
    40202830:	a951266d 	ldp	x13, x9, [x19, #272]
    40202834:	a94fae6a 	ldp	x10, x11, [x19, #248]
    40202838:	f940866c 	ldr	x12, [x19, #264]
    4020283c:	f940226e 	ldr	x14, [x19, #64]
    40202840:	a940426f 	ldp	x15, x16, [x19]
    40202844:	f9400a71 	ldr	x17, [x19, #16]
    40202848:	52808012 	mov	w18, #0x400                 	// #1024
    4020284c:	a90823f2 	stp	x18, x8, [sp, #128]
    40202850:	a90727ea 	stp	x10, x9, [sp, #112]
    40202854:	a9062fec 	stp	x12, x11, [sp, #96]
    40202858:	a90537ee 	stp	x14, x13, [sp, #80]
    4020285c:	a9043ff0 	stp	x16, x15, [sp, #64]
    40202860:	a90347e0 	stp	x0, x17, [sp, #48]
    40202864:	a9026ff8 	stp	x24, x27, [sp, #32]
    40202868:	a9015ff6 	stp	x22, x23, [sp, #16]
    4020286c:	f0002149 	adrp	x9, 4062d000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3fe0>
    40202870:	91010129 	add	x9, x9, #0x40
    40202874:	8b081d2a 	add	x10, x9, x8, lsl #7
    40202878:	f94047eb 	ldr	x11, [sp, #136]
    4020287c:	f900414b 	str	x11, [x10, #128]
    40202880:	f94043eb 	ldr	x11, [sp, #128]
    40202884:	f900454b 	str	x11, [x10, #136]
    40202888:	f9403feb 	ldr	x11, [sp, #120]
    4020288c:	f900494b 	str	x11, [x10, #144]
    40202890:	f9403beb 	ldr	x11, [sp, #112]
    40202894:	f9004d4b 	str	x11, [x10, #152]
    40202898:	f94037eb 	ldr	x11, [sp, #104]
    4020289c:	f900514b 	str	x11, [x10, #160]
    402028a0:	f94033eb 	ldr	x11, [sp, #96]
    402028a4:	f900554b 	str	x11, [x10, #168]
    402028a8:	f9402feb 	ldr	x11, [sp, #88]
    402028ac:	f900594b 	str	x11, [x10, #176]
    402028b0:	f9402beb 	ldr	x11, [sp, #80]
    402028b4:	f9005d4b 	str	x11, [x10, #184]
    402028b8:	f94027eb 	ldr	x11, [sp, #72]
    402028bc:	f900614b 	str	x11, [x10, #192]
    402028c0:	f94023eb 	ldr	x11, [sp, #64]
    402028c4:	f900654b 	str	x11, [x10, #200]
    402028c8:	f9401feb 	ldr	x11, [sp, #56]
    402028cc:	f900694b 	str	x11, [x10, #208]
    402028d0:	f9401beb 	ldr	x11, [sp, #48]
    402028d4:	f9006d4b 	str	x11, [x10, #216]
    402028d8:	f94017eb 	ldr	x11, [sp, #40]
    402028dc:	f900714b 	str	x11, [x10, #224]
    402028e0:	f94013eb 	ldr	x11, [sp, #32]
    402028e4:	f900754b 	str	x11, [x10, #232]
    402028e8:	f9400feb 	ldr	x11, [sp, #24]
    402028ec:	f900794b 	str	x11, [x10, #240]
    402028f0:	f9400beb 	ldr	x11, [sp, #16]
    402028f4:	f9007d4b 	str	x11, [x10, #248]
    402028f8:	d5033abf 	dmb	ishst
    402028fc:	91000508 	add	x8, x8, #0x1
    40202900:	f9002128 	str	x8, [x9, #64]
    40202904:	f100073f 	cmp	x25, #0x1
    40202908:	54000481 	b.ne	40202998 <native_el0_sync+0x5c0>  // b.any
    4020290c:	aa1f03e8 	mov	x8, xzr
    40202910:	52800314 	mov	w20, #0x18                  	// #24
    40202914:	72a12014 	movk	w20, #0x900, lsl #16
    40202918:	f9400269 	ldr	x9, [x19]
    4020291c:	f000214a 	adrp	x10, 4062d000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3fe0>
    40202920:	9101214a 	add	x10, x10, #0x48
    40202924:	f9002149 	str	x9, [x10, #64]
    40202928:	52800029 	mov	w9, #0x1                   	// #1
    4020292c:	f9002549 	str	x9, [x10, #72]
    40202930:	52800069 	mov	w9, #0x3                   	// #3
    40202934:	f9000149 	str	x9, [x10]
    40202938:	d5033f9f 	dsb	sy
    4020293c:	d503201f 	nop
    40202940:	5000c7c9 	adr	x9, 4020423a <anon.942724a4c970943425c58f68468d0017.5.llvm.10821731386268321571+0x4a>
    40202944:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    40202948:	3868692b 	ldrb	w11, [x9, x8]
    4020294c:	b940028c 	ldr	w12, [x20]
    40202950:	3628006c 	tbz	w12, #5, 4020295c <native_el0_sync+0x584>
    40202954:	d5033fdf 	isb
    40202958:	17fffffd 	b	4020294c <native_el0_sync+0x574>
    4020295c:	91000508 	add	x8, x8, #0x1
    40202960:	b900014b 	str	w11, [x10]
    40202964:	f100411f 	cmp	x8, #0x10
    40202968:	54ffff01 	b.ne	40202948 <native_el0_sync+0x570>  // b.any
    4020296c:	f9400260 	ldr	x0, [x19]
    40202970:	97fffe66 	bl	40202308 <_ZN11jnox_kernel10native_el07decimal17h1e9b2661b492b3c8E>
    40202974:	b9400288 	ldr	w8, [x20]
    40202978:	36280068 	tbz	w8, #5, 40202984 <native_el0_sync+0x5ac>
    4020297c:	d5033fdf 	isb
    40202980:	17fffffd 	b	40202974 <native_el0_sync+0x59c>
    40202984:	52a12008 	mov	w8, #0x9000000             	// #150994944
    40202988:	52800149 	mov	w9, #0xa                   	// #10
    4020298c:	b9000109 	str	w9, [x8]
    40202990:	d503205f 	wfe
    40202994:	17ffffff 	b	40202990 <native_el0_sync+0x5b8>
    40202998:	a94e4ff4 	ldp	x20, x19, [sp, #224]
    4020299c:	a94d57f6 	ldp	x22, x21, [sp, #208]
    402029a0:	a94c5ff8 	ldp	x24, x23, [sp, #192]
    402029a4:	a94b67fa 	ldp	x26, x25, [sp, #176]
    402029a8:	a94a6ffc 	ldp	x28, x27, [sp, #160]
    402029ac:	a9497bfd 	ldp	x29, x30, [sp, #144]
    402029b0:	9103c3ff 	add	sp, sp, #0xf0
    402029b4:	d65f03c0 	ret
    402029b8:	928001a0 	mov	x0, #0xfffffffffffffff2    	// #-14
    402029bc:	17ffff9a 	b	40202824 <native_el0_sync+0x44c>
    402029c0:	aa1f03e0 	mov	x0, xzr
    402029c4:	17ffff97 	b	40202820 <native_el0_sync+0x448>
    402029c8:	f0002140 	adrp	x0, 4062d000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3fe0>
    402029cc:	91008000 	add	x0, x0, #0x20
    402029d0:	97fffc81 	bl	40201bd4 <native_sleep_switch>
    402029d4:	f9400288 	ldr	x8, [x20]
    402029d8:	f100091f 	cmp	x8, #0x2
    402029dc:	54000261 	b.ne	40202a28 <native_el0_sync+0x650>  // b.any
    402029e0:	f0002148 	adrp	x8, 4062d000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3fe0>
    402029e4:	f9401508 	ldr	x8, [x8, #40]
    402029e8:	eb13011f 	cmp	x8, x19
    402029ec:	540001e1 	b.ne	40202a28 <native_el0_sync+0x650>  // b.any
    402029f0:	aa1f03e0 	mov	x0, xzr
    402029f4:	f9400a88 	ldr	x8, [x20, #16]
    402029f8:	d5182008 	msr	ttbr0_el1, x8
    402029fc:	d5033fdf 	isb
    40202a00:	f0002148 	adrp	x8, 4062d000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3fe0>
    40202a04:	f900111f 	str	xzr, [x8, #32]
    40202a08:	17ffff86 	b	40202820 <native_el0_sync+0x448>
    40202a0c:	52800040 	mov	w0, #0x2                   	// #2
    40202a10:	97fffe1e 	bl	40202288 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    40202a14:	52800060 	mov	w0, #0x3                   	// #3
    40202a18:	97fffe1c 	bl	40202288 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>
    40202a1c:	d503201f 	nop
    40202a20:	10026d80 	adr	x0, 402077d0 <jnox_native_el0_image+0x34e0>
    40202a24:	94000378 	bl	40203804 <_RNvNtNtCsbcsGJ9IzBgZ_4core9panicking11panic_const23panic_const_div_by_zero>
    40202a28:	52800120 	mov	w0, #0x9                   	// #9
    40202a2c:	97fffe17 	bl	40202288 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>

0000000040202a30 <native_el0_unexpected>:
    40202a30:	f81f0ffe 	str	x30, [sp, #-16]!
    40202a34:	52800020 	mov	w0, #0x1                   	// #1
    40202a38:	97fffe14 	bl	40202288 <_ZN11jnox_kernel10native_el04fail17ha40e71bba598b946E>

0000000040202a3c <native_sleep_irq>:
    40202a3c:	52800188 	mov	w8, #0xc                   	// #12
    40202a40:	72a10028 	movk	w8, #0x801, lsl #16
    40202a44:	b9400109 	ldr	w9, [x8]
    40202a48:	1200252a 	and	w10, w9, #0x3ff
    40202a4c:	710fed5f 	cmp	w10, #0x3fb
    40202a50:	54000069 	b.ls	40202a5c <native_sleep_irq+0x20>  // b.plast
    40202a54:	aa1f03e0 	mov	x0, xzr
    40202a58:	d65f03c0 	ret
    40202a5c:	7100795f 	cmp	w10, #0x1e
    40202a60:	54000241 	b.ne	40202aa8 <native_sleep_irq+0x6c>  // b.any
    40202a64:	d5033fdf 	isb
    40202a68:	d53be02b 	mrs	x11, cntpct_el0
    40202a6c:	f000214a 	adrp	x10, 4062d000 <_ZN11jnox_kernel10native_el04IDLE17h1ac306f1a0b52f1aE+0x3fe0>
    40202a70:	9100814a 	add	x10, x10, #0x20
    40202a74:	a940354c 	ldp	x12, x13, [x10]
    40202a78:	f100059f 	cmp	x12, #0x1
    40202a7c:	fa4d0160 	ccmp	x11, x13, #0x0, eq  // eq = none
    40202a80:	1a9f37e0 	cset	w0, cs  // cs = hs, nlast
    40202a84:	7100041f 	cmp	w0, #0x1
    40202a88:	54000121 	b.ne	40202aac <native_sleep_irq+0x70>  // b.any
    40202a8c:	a9412d4c 	ldp	x12, x11, [x10, #16]
    40202a90:	d51be23f 	msr	cntp_ctl_el0, xzr
    40202a94:	d5033fdf 	isb
    40202a98:	5280004d 	mov	w13, #0x2                   	// #2
    40202a9c:	a900314d 	stp	x13, x12, [x10]
    40202aa0:	f900094b 	str	x11, [x10, #16]
    40202aa4:	14000002 	b	40202aac <native_sleep_irq+0x70>
    40202aa8:	aa1f03e0 	mov	x0, xzr
    40202aac:	d5033f9f 	dsb	sy
    40202ab0:	b9000509 	str	w9, [x8, #4]
    40202ab4:	d5033f9f 	dsb	sy
    40202ab8:	d65f03c0 	ret
