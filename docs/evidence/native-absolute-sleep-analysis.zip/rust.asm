
rust.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000400000 <_start>:
  400000:	aa1f03fd 	mov	x29, xzr
  400004:	aa1f03fe 	mov	x30, xzr
  400008:	f94003e0 	ldr	x0, [sp]
  40000c:	910023e1 	add	x1, sp, #0x8
  400010:	94000005 	bl	400024 <main>

0000000000400014 <__jnox_exit>:
  400014:	93407c00 	sxtw	x0, w0
  400018:	d2800028 	mov	x8, #0x1                   	// #1
  40001c:	d4094021 	svc	#0x4a01
  400020:	d4200000 	brk	#0x0

0000000000400024 <main>:
  400024:	d10143ff 	sub	sp, sp, #0x50
  400028:	a9025ffe 	stp	x30, x23, [sp, #32]
  40002c:	a90357f6 	stp	x22, x21, [sp, #48]
  400030:	a9044ff4 	stp	x20, x19, [sp, #64]
  400034:	d2f00000 	mov	x0, #0x8000000000000000    	// #-9223372036854775808
  400038:	2a1f03e1 	mov	w1, wzr
  40003c:	940000ac 	bl	4002ec <_ZN11jnox_native11sleep_until17hf961894e31cbd60dE>
  400040:	7100081f 	cmp	w0, #0x2
  400044:	540000e1 	b.ne	400060 <main+0x3c>  // b.any
  400048:	52800020 	mov	w0, #0x1                   	// #1
  40004c:	a9444ff4 	ldp	x20, x19, [sp, #64]
  400050:	a94357f6 	ldp	x22, x21, [sp, #48]
  400054:	a9425ffe 	ldp	x30, x23, [sp, #32]
  400058:	910143ff 	add	sp, sp, #0x50
  40005c:	d65f03c0 	ret
  400060:	2a0003e8 	mov	w8, w0
  400064:	52800020 	mov	w0, #0x1                   	// #1
  400068:	35ffff28 	cbnz	w8, 40004c <main+0x28>
  40006c:	71012c3f 	cmp	w1, #0x4b
  400070:	54fffee1 	b.ne	40004c <main+0x28>  // b.any
  400074:	52994015 	mov	w21, #0xca00                	// #51712
  400078:	910043e8 	add	x8, sp, #0x10
  40007c:	72a77355 	movk	w21, #0x3b9a, lsl #16
  400080:	940000ae 	bl	400338 <_ZN11jnox_native14monotonic_time17h4e6653f707baeb21E>
  400084:	b9401be8 	ldr	w8, [sp, #24]
  400088:	6b15011f 	cmp	w8, w21
  40008c:	540000e1 	b.ne	4000a8 <main+0x84>  // b.any
  400090:	52800040 	mov	w0, #0x2                   	// #2
  400094:	a9444ff4 	ldp	x20, x19, [sp, #64]
  400098:	a94357f6 	ldp	x22, x21, [sp, #48]
  40009c:	a9425ffe 	ldp	x30, x23, [sp, #32]
  4000a0:	910143ff 	add	sp, sp, #0x50
  4000a4:	d65f03c0 	ret
  4000a8:	528dfff6 	mov	w22, #0x6fff                	// #28671
  4000ac:	f9400bf3 	ldr	x19, [sp, #16]
  4000b0:	528b4017 	mov	w23, #0x5a00                	// #23040
  4000b4:	72a72716 	movk	w22, #0x3938, lsl #16
  4000b8:	72a04c57 	movk	w23, #0x262, lsl #16
  4000bc:	b9000fff 	str	wzr, [sp, #12]
  4000c0:	6b16011f 	cmp	w8, w22
  4000c4:	540001a9 	b.ls	4000f8 <main+0xd4>  // b.plast
  4000c8:	b100067f 	cmn	x19, #0x1
  4000cc:	54001040 	b.eq	4002d4 <main+0x2b0>  // b.none
  4000d0:	52920009 	mov	w9, #0x9000                	// #36864
  4000d4:	91000673 	add	x19, x19, #0x1
  4000d8:	72b8d8e9 	movk	w9, #0xc6c7, lsl #16
  4000dc:	0b090114 	add	w20, w8, w9
  4000e0:	aa1303e0 	mov	x0, x19
  4000e4:	2a1403e1 	mov	w1, w20
  4000e8:	94000081 	bl	4002ec <_ZN11jnox_native11sleep_until17hf961894e31cbd60dE>
  4000ec:	7100081f 	cmp	w0, #0x2
  4000f0:	54000100 	b.eq	400110 <main+0xec>  // b.none
  4000f4:	14000072 	b	4002bc <main+0x298>
  4000f8:	0b170114 	add	w20, w8, w23
  4000fc:	aa1303e0 	mov	x0, x19
  400100:	2a1403e1 	mov	w1, w20
  400104:	9400007a 	bl	4002ec <_ZN11jnox_native11sleep_until17hf961894e31cbd60dE>
  400108:	7100081f 	cmp	w0, #0x2
  40010c:	54000d81 	b.ne	4002bc <main+0x298>  // b.any
  400110:	910043e8 	add	x8, sp, #0x10
  400114:	94000089 	bl	400338 <_ZN11jnox_native14monotonic_time17h4e6653f707baeb21E>
  400118:	b9401be8 	ldr	w8, [sp, #24]
  40011c:	6b15011f 	cmp	w8, w21
  400120:	540000e1 	b.ne	40013c <main+0x118>  // b.any
  400124:	528000a0 	mov	w0, #0x5                   	// #5
  400128:	a9444ff4 	ldp	x20, x19, [sp, #64]
  40012c:	a94357f6 	ldp	x22, x21, [sp, #48]
  400130:	a9425ffe 	ldp	x30, x23, [sp, #32]
  400134:	910143ff 	add	sp, sp, #0x50
  400138:	d65f03c0 	ret
  40013c:	f9400be9 	ldr	x9, [sp, #16]
  400140:	6b14011f 	cmp	w8, w20
  400144:	1a9f27e8 	cset	w8, cc  // cc = lo, ul, last
  400148:	eb13013f 	cmp	x9, x19
  40014c:	1a9f27e9 	cset	w9, cc  // cc = lo, ul, last
  400150:	1a890108 	csel	w8, w8, w9, eq  // eq = none
  400154:	360000e8 	tbz	w8, #0, 400170 <main+0x14c>
  400158:	528000c0 	mov	w0, #0x6                   	// #6
  40015c:	a9444ff4 	ldp	x20, x19, [sp, #64]
  400160:	a94357f6 	ldp	x22, x21, [sp, #48]
  400164:	a9425ffe 	ldp	x30, x23, [sp, #32]
  400168:	910143ff 	add	sp, sp, #0x50
  40016c:	d65f03c0 	ret
  400170:	b9400fe8 	ldr	w8, [sp, #12]
  400174:	aa1303e0 	mov	x0, x19
  400178:	2a1403e1 	mov	w1, w20
  40017c:	11000508 	add	w8, w8, #0x1
  400180:	b9000fe8 	str	w8, [sp, #12]
  400184:	9400005a 	bl	4002ec <_ZN11jnox_native11sleep_until17hf961894e31cbd60dE>
  400188:	7100081f 	cmp	w0, #0x2
  40018c:	54000141 	b.ne	4001b4 <main+0x190>  // b.any
  400190:	6b16029f 	cmp	w20, w22
  400194:	540001c9 	b.ls	4001cc <main+0x1a8>  // b.plast
  400198:	b100067f 	cmn	x19, #0x1
  40019c:	540009c0 	b.eq	4002d4 <main+0x2b0>  // b.none
  4001a0:	52920008 	mov	w8, #0x9000                	// #36864
  4001a4:	91000673 	add	x19, x19, #0x1
  4001a8:	72b8d8e8 	movk	w8, #0xc6c7, lsl #16
  4001ac:	0b080294 	add	w20, w20, w8
  4001b0:	14000008 	b	4001d0 <main+0x1ac>
  4001b4:	528000e0 	mov	w0, #0x7                   	// #7
  4001b8:	a9444ff4 	ldp	x20, x19, [sp, #64]
  4001bc:	a94357f6 	ldp	x22, x21, [sp, #48]
  4001c0:	a9425ffe 	ldp	x30, x23, [sp, #32]
  4001c4:	910143ff 	add	sp, sp, #0x50
  4001c8:	d65f03c0 	ret
  4001cc:	0b170294 	add	w20, w20, w23
  4001d0:	aa1303e0 	mov	x0, x19
  4001d4:	2a1403e1 	mov	w1, w20
  4001d8:	94000045 	bl	4002ec <_ZN11jnox_native11sleep_until17hf961894e31cbd60dE>
  4001dc:	7100081f 	cmp	w0, #0x2
  4001e0:	540006e1 	b.ne	4002bc <main+0x298>  // b.any
  4001e4:	910043e8 	add	x8, sp, #0x10
  4001e8:	94000054 	bl	400338 <_ZN11jnox_native14monotonic_time17h4e6653f707baeb21E>
  4001ec:	b9401be8 	ldr	w8, [sp, #24]
  4001f0:	6b15011f 	cmp	w8, w21
  4001f4:	54fff980 	b.eq	400124 <main+0x100>  // b.none
  4001f8:	f9400be9 	ldr	x9, [sp, #16]
  4001fc:	6b14011f 	cmp	w8, w20
  400200:	1a9f27e8 	cset	w8, cc  // cc = lo, ul, last
  400204:	eb13013f 	cmp	x9, x19
  400208:	1a9f27e9 	cset	w9, cc  // cc = lo, ul, last
  40020c:	1a890108 	csel	w8, w8, w9, eq  // eq = none
  400210:	3707fa48 	tbnz	w8, #0, 400158 <main+0x134>
  400214:	b9400fe8 	ldr	w8, [sp, #12]
  400218:	6b16029f 	cmp	w20, w22
  40021c:	11000908 	add	w8, w8, #0x2
  400220:	b9000fe8 	str	w8, [sp, #12]
  400224:	54000109 	b.ls	400244 <main+0x220>  // b.plast
  400228:	b100067f 	cmn	x19, #0x1
  40022c:	54000540 	b.eq	4002d4 <main+0x2b0>  // b.none
  400230:	52920008 	mov	w8, #0x9000                	// #36864
  400234:	91000673 	add	x19, x19, #0x1
  400238:	72b8d8e8 	movk	w8, #0xc6c7, lsl #16
  40023c:	0b080294 	add	w20, w20, w8
  400240:	14000002 	b	400248 <main+0x224>
  400244:	0b170294 	add	w20, w20, w23
  400248:	aa1303e0 	mov	x0, x19
  40024c:	2a1403e1 	mov	w1, w20
  400250:	94000027 	bl	4002ec <_ZN11jnox_native11sleep_until17hf961894e31cbd60dE>
  400254:	7100081f 	cmp	w0, #0x2
  400258:	54000321 	b.ne	4002bc <main+0x298>  // b.any
  40025c:	910043e8 	add	x8, sp, #0x10
  400260:	94000036 	bl	400338 <_ZN11jnox_native14monotonic_time17h4e6653f707baeb21E>
  400264:	b9401be8 	ldr	w8, [sp, #24]
  400268:	6b15011f 	cmp	w8, w21
  40026c:	54fff5c0 	b.eq	400124 <main+0x100>  // b.none
  400270:	f9400be9 	ldr	x9, [sp, #16]
  400274:	6b14011f 	cmp	w8, w20
  400278:	1a9f27e8 	cset	w8, cc  // cc = lo, ul, last
  40027c:	eb13013f 	cmp	x9, x19
  400280:	1a9f27e9 	cset	w9, cc  // cc = lo, ul, last
  400284:	1a890108 	csel	w8, w8, w9, eq  // eq = none
  400288:	3707f688 	tbnz	w8, #0, 400158 <main+0x134>
  40028c:	b9400fe8 	ldr	w8, [sp, #12]
  400290:	11000d08 	add	w8, w8, #0x3
  400294:	b9000fe8 	str	w8, [sp, #12]
  400298:	b9400fe8 	ldr	w8, [sp, #12]
  40029c:	7100191f 	cmp	w8, #0x6
  4002a0:	52800108 	mov	w8, #0x8                   	// #8
  4002a4:	1a8803e0 	csel	w0, wzr, w8, eq  // eq = none
  4002a8:	a9444ff4 	ldp	x20, x19, [sp, #64]
  4002ac:	a94357f6 	ldp	x22, x21, [sp, #48]
  4002b0:	a9425ffe 	ldp	x30, x23, [sp, #32]
  4002b4:	910143ff 	add	sp, sp, #0x50
  4002b8:	d65f03c0 	ret
  4002bc:	52800080 	mov	w0, #0x4                   	// #4
  4002c0:	a9444ff4 	ldp	x20, x19, [sp, #64]
  4002c4:	a94357f6 	ldp	x22, x21, [sp, #48]
  4002c8:	a9425ffe 	ldp	x30, x23, [sp, #32]
  4002cc:	910143ff 	add	sp, sp, #0x50
  4002d0:	d65f03c0 	ret
  4002d4:	52800060 	mov	w0, #0x3                   	// #3
  4002d8:	a9444ff4 	ldp	x20, x19, [sp, #64]
  4002dc:	a94357f6 	ldp	x22, x21, [sp, #48]
  4002e0:	a9425ffe 	ldp	x30, x23, [sp, #32]
  4002e4:	910143ff 	add	sp, sp, #0x50
  4002e8:	d65f03c0 	ret

00000000004002ec <_ZN11jnox_native11sleep_until17hf961894e31cbd60dE>:
  4002ec:	b7f80200 	tbnz	x0, #63, 40032c <_ZN11jnox_native11sleep_until17hf961894e31cbd60dE+0x40>
  4002f0:	f81e0fe0 	str	x0, [sp, #-32]!
  4002f4:	2a0103e8 	mov	w8, w1
  4002f8:	910003e2 	mov	x2, sp
  4002fc:	52800020 	mov	w0, #0x1                   	// #1
  400300:	52800021 	mov	w1, #0x1                   	// #1
  400304:	aa1f03e3 	mov	x3, xzr
  400308:	a900fbe8 	stp	x8, x30, [sp, #8]
  40030c:	94000081 	bl	400510 <clock_nanosleep>
  400310:	52800048 	mov	w8, #0x2                   	// #2
  400314:	7100001f 	cmp	w0, #0x0
  400318:	f9400bfe 	ldr	x30, [sp, #16]
  40031c:	2a0003e1 	mov	w1, w0
  400320:	1a9f0100 	csel	w0, w8, wzr, eq  // eq = none
  400324:	910083ff 	add	sp, sp, #0x20
  400328:	d65f03c0 	ret
  40032c:	2a1f03e0 	mov	w0, wzr
  400330:	52800961 	mov	w1, #0x4b                  	// #75
  400334:	d65f03c0 	ret

0000000000400338 <_ZN11jnox_native14monotonic_time17h4e6653f707baeb21E>:
  400338:	d100c3ff 	sub	sp, sp, #0x30
  40033c:	a9024ff4 	stp	x20, x19, [sp, #32]
  400340:	aa0803f3 	mov	x19, x8
  400344:	92800008 	mov	x8, #0xffffffffffffffff    	// #-1
  400348:	910003e1 	mov	x1, sp
  40034c:	52800020 	mov	w0, #0x1                   	// #1
  400350:	a900fbe8 	stp	x8, x30, [sp, #8]
  400354:	f90003e8 	str	x8, [sp]
  400358:	94000062 	bl	4004e0 <clock_gettime>
  40035c:	34000160 	cbz	w0, 400388 <_ZN11jnox_native14monotonic_time17h4e6653f707baeb21E+0x50>
  400360:	52994014 	mov	w20, #0xca00                	// #51712
  400364:	72a77354 	movk	w20, #0x3b9a, lsl #16
  400368:	9400001e 	bl	4003e0 <__jnox_errno_location>
  40036c:	b9400008 	ldr	w8, [x0]
  400370:	2900227f 	stp	wzr, w8, [x19]
  400374:	b9000a74 	str	w20, [x19, #8]
  400378:	a9424ff4 	ldp	x20, x19, [sp, #32]
  40037c:	f9400bfe 	ldr	x30, [sp, #16]
  400380:	9100c3ff 	add	sp, sp, #0x30
  400384:	d65f03c0 	ret
  400388:	f94003e8 	ldr	x8, [sp]
  40038c:	b7f80188 	tbnz	x8, #63, 4003bc <_ZN11jnox_native14monotonic_time17h4e6653f707baeb21E+0x84>
  400390:	f94007f4 	ldr	x20, [sp, #8]
  400394:	52994009 	mov	w9, #0xca00                	// #51712
  400398:	72a77349 	movk	w9, #0x3b9a, lsl #16
  40039c:	eb09029f 	cmp	x20, x9
  4003a0:	540000e2 	b.cs	4003bc <_ZN11jnox_native14monotonic_time17h4e6653f707baeb21E+0x84>  // b.hs, b.nlast
  4003a4:	f9000268 	str	x8, [x19]
  4003a8:	b9000a74 	str	w20, [x19, #8]
  4003ac:	a9424ff4 	ldp	x20, x19, [sp, #32]
  4003b0:	f9400bfe 	ldr	x30, [sp, #16]
  4003b4:	9100c3ff 	add	sp, sp, #0x30
  4003b8:	d65f03c0 	ret
  4003bc:	52800028 	mov	w8, #0x1                   	// #1
  4003c0:	52994014 	mov	w20, #0xca00                	// #51712
  4003c4:	72a77354 	movk	w20, #0x3b9a, lsl #16
  4003c8:	b9000268 	str	w8, [x19]
  4003cc:	b9000a74 	str	w20, [x19, #8]
  4003d0:	a9424ff4 	ldp	x20, x19, [sp, #32]
  4003d4:	f9400bfe 	ldr	x30, [sp, #16]
  4003d8:	9100c3ff 	add	sp, sp, #0x30
  4003dc:	d65f03c0 	ret

00000000004003e0 <__jnox_errno_location>:
  4003e0:	d503201f 	nop
  4003e4:	1000e0e0 	adr	x0, 402000 <__jnox_errno_location.initial_thread_errno>
  4003e8:	d65f03c0 	ret

00000000004003ec <open>:
  4003ec:	d100c3ff 	sub	sp, sp, #0x30
  4003f0:	a90093e3 	stp	x3, x4, [sp, #8]
  4003f4:	f90003e2 	str	x2, [sp]
  4003f8:	a9019be5 	stp	x5, x6, [sp, #24]
  4003fc:	f90017e7 	str	x7, [sp, #40]
  400400:	340000e1 	cbz	w1, 40041c <open+0x30>
  400404:	d0000008 	adrp	x8, 402000 <__jnox_errno_location.initial_thread_errno>
  400408:	528002c9 	mov	w9, #0x16                  	// #22
  40040c:	12800000 	mov	w0, #0xffffffff            	// #-1
  400410:	b9000109 	str	w9, [x8]
  400414:	9100c3ff 	add	sp, sp, #0x30
  400418:	d65f03c0 	ret
  40041c:	aa1f03e1 	mov	x1, xzr
  400420:	aa1f03e2 	mov	x2, xzr
  400424:	aa1f03e3 	mov	x3, xzr
  400428:	52800048 	mov	w8, #0x2                   	// #2
  40042c:	d4094021 	svc	#0x4a01
  400430:	b7f80060 	tbnz	x0, #63, 40043c <open+0x50>
  400434:	9100c3ff 	add	sp, sp, #0x30
  400438:	d65f03c0 	ret
  40043c:	4b0003e8 	neg	w8, w0
  400440:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  400444:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  400448:	b9000128 	str	w8, [x9]
  40044c:	9100c3ff 	add	sp, sp, #0x30
  400450:	d65f03c0 	ret

0000000000400454 <read>:
  400454:	aa1f03e3 	mov	x3, xzr
  400458:	52800068 	mov	w8, #0x3                   	// #3
  40045c:	93407c00 	sxtw	x0, w0
  400460:	d4094021 	svc	#0x4a01
  400464:	b7f80040 	tbnz	x0, #63, 40046c <read+0x18>
  400468:	d65f03c0 	ret
  40046c:	4b0003e8 	neg	w8, w0
  400470:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  400474:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  400478:	b9000128 	str	w8, [x9]
  40047c:	d65f03c0 	ret

0000000000400480 <write>:
  400480:	aa1f03e3 	mov	x3, xzr
  400484:	52800088 	mov	w8, #0x4                   	// #4
  400488:	93407c00 	sxtw	x0, w0
  40048c:	d4094021 	svc	#0x4a01
  400490:	b7f80040 	tbnz	x0, #63, 400498 <write+0x18>
  400494:	d65f03c0 	ret
  400498:	4b0003e8 	neg	w8, w0
  40049c:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  4004a0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  4004a4:	b9000128 	str	w8, [x9]
  4004a8:	d65f03c0 	ret

00000000004004ac <close>:
  4004ac:	aa1f03e1 	mov	x1, xzr
  4004b0:	aa1f03e2 	mov	x2, xzr
  4004b4:	93407c00 	sxtw	x0, w0
  4004b8:	aa1f03e3 	mov	x3, xzr
  4004bc:	528000a8 	mov	w8, #0x5                   	// #5
  4004c0:	d4094021 	svc	#0x4a01
  4004c4:	b7f80040 	tbnz	x0, #63, 4004cc <close+0x20>
  4004c8:	d65f03c0 	ret
  4004cc:	4b0003e8 	neg	w8, w0
  4004d0:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  4004d4:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  4004d8:	b9000128 	str	w8, [x9]
  4004dc:	d65f03c0 	ret

00000000004004e0 <clock_gettime>:
  4004e0:	aa1f03e2 	mov	x2, xzr
  4004e4:	aa1f03e3 	mov	x3, xzr
  4004e8:	93407c00 	sxtw	x0, w0
  4004ec:	528000c8 	mov	w8, #0x6                   	// #6
  4004f0:	d4094021 	svc	#0x4a01
  4004f4:	b7f80040 	tbnz	x0, #63, 4004fc <clock_gettime+0x1c>
  4004f8:	d65f03c0 	ret
  4004fc:	4b0003e8 	neg	w8, w0
  400500:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  400504:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  400508:	b9000128 	str	w8, [x9]
  40050c:	d65f03c0 	ret

0000000000400510 <clock_nanosleep>:
  400510:	aa1f03e3 	mov	x3, xzr
  400514:	528000e8 	mov	w8, #0x7                   	// #7
  400518:	93407c00 	sxtw	x0, w0
  40051c:	93407c21 	sxtw	x1, w1
  400520:	d4094021 	svc	#0x4a01
  400524:	4b0003e0 	neg	w0, w0
  400528:	d65f03c0 	ret
