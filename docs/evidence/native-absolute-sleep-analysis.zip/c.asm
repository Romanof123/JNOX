
c.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000400000 <_start>:
  400000:	aa1f03fd 	mov	x29, xzr
  400004:	aa1f03fe 	mov	x30, xzr
  400008:	f94003e0 	ldr	x0, [sp]
  40000c:	910023e1 	add	x1, sp, #0x8
  400010:	94000058 	bl	400170 <main>

0000000000400014 <__jnox_exit>:
  400014:	93407c00 	sxtw	x0, w0
  400018:	d2800028 	mov	x8, #0x1                   	// #1
  40001c:	d4094021 	svc	#0x4a01
  400020:	d4200000 	brk	#0x0

0000000000400024 <__jnox_errno_location>:
  400024:	d503201f 	nop
  400028:	1000fec0 	adr	x0, 402000 <__jnox_errno_location.initial_thread_errno>
  40002c:	d65f03c0 	ret

0000000000400030 <open>:
  400030:	d100c3ff 	sub	sp, sp, #0x30
  400034:	a90093e3 	stp	x3, x4, [sp, #8]
  400038:	f90003e2 	str	x2, [sp]
  40003c:	a9019be5 	stp	x5, x6, [sp, #24]
  400040:	f90017e7 	str	x7, [sp, #40]
  400044:	340000e1 	cbz	w1, 400060 <open+0x30>
  400048:	d0000008 	adrp	x8, 402000 <__jnox_errno_location.initial_thread_errno>
  40004c:	528002c9 	mov	w9, #0x16                  	// #22
  400050:	12800000 	mov	w0, #0xffffffff            	// #-1
  400054:	b9000109 	str	w9, [x8]
  400058:	9100c3ff 	add	sp, sp, #0x30
  40005c:	d65f03c0 	ret
  400060:	aa1f03e1 	mov	x1, xzr
  400064:	aa1f03e2 	mov	x2, xzr
  400068:	aa1f03e3 	mov	x3, xzr
  40006c:	52800048 	mov	w8, #0x2                   	// #2
  400070:	d4094021 	svc	#0x4a01
  400074:	b7f80060 	tbnz	x0, #63, 400080 <open+0x50>
  400078:	9100c3ff 	add	sp, sp, #0x30
  40007c:	d65f03c0 	ret
  400080:	4b0003e8 	neg	w8, w0
  400084:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  400088:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  40008c:	b9000128 	str	w8, [x9]
  400090:	9100c3ff 	add	sp, sp, #0x30
  400094:	d65f03c0 	ret

0000000000400098 <read>:
  400098:	aa1f03e3 	mov	x3, xzr
  40009c:	52800068 	mov	w8, #0x3                   	// #3
  4000a0:	93407c00 	sxtw	x0, w0
  4000a4:	d4094021 	svc	#0x4a01
  4000a8:	b7f80040 	tbnz	x0, #63, 4000b0 <read+0x18>
  4000ac:	d65f03c0 	ret
  4000b0:	4b0003e8 	neg	w8, w0
  4000b4:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  4000b8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  4000bc:	b9000128 	str	w8, [x9]
  4000c0:	d65f03c0 	ret

00000000004000c4 <write>:
  4000c4:	aa1f03e3 	mov	x3, xzr
  4000c8:	52800088 	mov	w8, #0x4                   	// #4
  4000cc:	93407c00 	sxtw	x0, w0
  4000d0:	d4094021 	svc	#0x4a01
  4000d4:	b7f80040 	tbnz	x0, #63, 4000dc <write+0x18>
  4000d8:	d65f03c0 	ret
  4000dc:	4b0003e8 	neg	w8, w0
  4000e0:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  4000e4:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  4000e8:	b9000128 	str	w8, [x9]
  4000ec:	d65f03c0 	ret

00000000004000f0 <close>:
  4000f0:	aa1f03e1 	mov	x1, xzr
  4000f4:	aa1f03e2 	mov	x2, xzr
  4000f8:	93407c00 	sxtw	x0, w0
  4000fc:	aa1f03e3 	mov	x3, xzr
  400100:	528000a8 	mov	w8, #0x5                   	// #5
  400104:	d4094021 	svc	#0x4a01
  400108:	b7f80040 	tbnz	x0, #63, 400110 <close+0x20>
  40010c:	d65f03c0 	ret
  400110:	4b0003e8 	neg	w8, w0
  400114:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  400118:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  40011c:	b9000128 	str	w8, [x9]
  400120:	d65f03c0 	ret

0000000000400124 <clock_gettime>:
  400124:	aa1f03e2 	mov	x2, xzr
  400128:	aa1f03e3 	mov	x3, xzr
  40012c:	93407c00 	sxtw	x0, w0
  400130:	528000c8 	mov	w8, #0x6                   	// #6
  400134:	d4094021 	svc	#0x4a01
  400138:	b7f80040 	tbnz	x0, #63, 400140 <clock_gettime+0x1c>
  40013c:	d65f03c0 	ret
  400140:	4b0003e8 	neg	w8, w0
  400144:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  400148:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  40014c:	b9000128 	str	w8, [x9]
  400150:	d65f03c0 	ret

0000000000400154 <clock_nanosleep>:
  400154:	aa1f03e3 	mov	x3, xzr
  400158:	528000e8 	mov	w8, #0x7                   	// #7
  40015c:	93407c00 	sxtw	x0, w0
  400160:	93407c21 	sxtw	x1, w1
  400164:	d4094021 	svc	#0x4a01
  400168:	4b0003e0 	neg	w0, w0
  40016c:	d65f03c0 	ret

0000000000400170 <main>:
  400170:	d101c3ff 	sub	sp, sp, #0x70
  400174:	b0000008 	adrp	x8, 401000 <main+0xe90>
  400178:	b000000a 	adrp	x10, 401000 <main+0xe90>
  40017c:	91006108 	add	x8, x8, #0x18
  400180:	9100a14a 	add	x10, x10, #0x28
  400184:	a9057bfd 	stp	x29, x30, [sp, #80]
  400188:	910143fd 	add	x29, sp, #0x50
  40018c:	a9064ff4 	stp	x20, x19, [sp, #96]
  400190:	a9402109 	ldp	x9, x8, [x8]
  400194:	a940294b 	ldp	x11, x10, [x10]
  400198:	a90223e9 	stp	x9, x8, [sp, #32]
  40019c:	a9012beb 	stp	x11, x10, [sp, #16]
  4001a0:	b9000fff 	str	wzr, [sp, #12]
  4001a4:	97ffffa0 	bl	400024 <__jnox_errno_location>
  4001a8:	52800088 	mov	w8, #0x4                   	// #4
  4001ac:	910043e2 	add	x2, sp, #0x10
  4001b0:	910083e3 	add	x3, sp, #0x20
  4001b4:	52800021 	mov	w1, #0x1                   	// #1
  4001b8:	52800033 	mov	w19, #0x1                   	// #1
  4001bc:	b9000008 	str	w8, [x0]
  4001c0:	52800020 	mov	w0, #0x1                   	// #1
  4001c4:	97ffffe4 	bl	400154 <clock_nanosleep>
  4001c8:	7100581f 	cmp	w0, #0x16
  4001cc:	54000641 	b.ne	400294 <main+0x124>  // b.any
  4001d0:	97ffff95 	bl	400024 <__jnox_errno_location>
  4001d4:	b9400008 	ldr	w8, [x0]
  4001d8:	52800033 	mov	w19, #0x1                   	// #1
  4001dc:	7100111f 	cmp	w8, #0x4
  4001e0:	540005a1 	b.ne	400294 <main+0x124>  // b.any
  4001e4:	f94013e8 	ldr	x8, [sp, #32]
  4001e8:	f100451f 	cmp	x8, #0x11
  4001ec:	54000541 	b.ne	400294 <main+0x124>  // b.any
  4001f0:	f94017e8 	ldr	x8, [sp, #40]
  4001f4:	f1005d1f 	cmp	x8, #0x17
  4001f8:	540004e1 	b.ne	400294 <main+0x124>  // b.any
  4001fc:	d10043a1 	sub	x1, x29, #0x10
  400200:	52800020 	mov	w0, #0x1                   	// #1
  400204:	97ffffc8 	bl	400124 <clock_gettime>
  400208:	34000060 	cbz	w0, 400214 <main+0xa4>
  40020c:	52800053 	mov	w19, #0x2                   	// #2
  400210:	14000021 	b	400294 <main+0x124>
  400214:	f85f83a8 	ldur	x8, [x29, #-8]
  400218:	528b4014 	mov	w20, #0x5a00                	// #23040
  40021c:	72a04c54 	movk	w20, #0x262, lsl #16
  400220:	528dfff3 	mov	w19, #0x6fff                	// #28671
  400224:	72a72713 	movk	w19, #0x3938, lsl #16
  400228:	8b140109 	add	x9, x8, x20
  40022c:	eb13011f 	cmp	x8, x19
  400230:	f81f83a9 	stur	x9, [x29, #-8]
  400234:	540001ad 	b.le	400268 <main+0xf8>
  400238:	928dffea 	mov	x10, #0xffffffffffff9000    	// #-28672
  40023c:	f85f03a9 	ldur	x9, [x29, #-16]
  400240:	f2b8d8ea 	movk	x10, #0xc6c7, lsl #16
  400244:	8b0a0108 	add	x8, x8, x10
  400248:	92f0000a 	mov	x10, #0x7fffffffffffffff    	// #9223372036854775807
  40024c:	eb0a013f 	cmp	x9, x10
  400250:	f81f83a8 	stur	x8, [x29, #-8]
  400254:	54000061 	b.ne	400260 <main+0xf0>  // b.any
  400258:	52800073 	mov	w19, #0x3                   	// #3
  40025c:	1400000e 	b	400294 <main+0x124>
  400260:	91000528 	add	x8, x9, #0x1
  400264:	f81f03a8 	stur	x8, [x29, #-16]
  400268:	d10043a2 	sub	x2, x29, #0x10
  40026c:	910083e3 	add	x3, sp, #0x20
  400270:	52800020 	mov	w0, #0x1                   	// #1
  400274:	52800021 	mov	w1, #0x1                   	// #1
  400278:	97ffffb7 	bl	400154 <clock_nanosleep>
  40027c:	350000a0 	cbnz	w0, 400290 <main+0x120>
  400280:	d10083a1 	sub	x1, x29, #0x20
  400284:	52800020 	mov	w0, #0x1                   	// #1
  400288:	97ffffa7 	bl	400124 <clock_gettime>
  40028c:	340000e0 	cbz	w0, 4002a8 <main+0x138>
  400290:	52800093 	mov	w19, #0x4                   	// #4
  400294:	2a1303e0 	mov	w0, w19
  400298:	a9464ff4 	ldp	x20, x19, [sp, #96]
  40029c:	a9457bfd 	ldp	x29, x30, [sp, #80]
  4002a0:	9101c3ff 	add	sp, sp, #0x70
  4002a4:	d65f03c0 	ret
  4002a8:	f85e03a8 	ldur	x8, [x29, #-32]
  4002ac:	f85f03a9 	ldur	x9, [x29, #-16]
  4002b0:	eb09011f 	cmp	x8, x9
  4002b4:	5400006a 	b.ge	4002c0 <main+0x150>  // b.tcont
  4002b8:	528000b3 	mov	w19, #0x5                   	// #5
  4002bc:	17fffff6 	b	400294 <main+0x124>
  4002c0:	540000a1 	b.ne	4002d4 <main+0x164>  // b.any
  4002c4:	f85e83a8 	ldur	x8, [x29, #-24]
  4002c8:	f85f83a9 	ldur	x9, [x29, #-8]
  4002cc:	eb09011f 	cmp	x8, x9
  4002d0:	54ffff4b 	b.lt	4002b8 <main+0x148>  // b.tstop
  4002d4:	b9400fe8 	ldr	w8, [sp, #12]
  4002d8:	d10043a2 	sub	x2, x29, #0x10
  4002dc:	910083e3 	add	x3, sp, #0x20
  4002e0:	52800020 	mov	w0, #0x1                   	// #1
  4002e4:	52800021 	mov	w1, #0x1                   	// #1
  4002e8:	11000508 	add	w8, w8, #0x1
  4002ec:	b9000fe8 	str	w8, [sp, #12]
  4002f0:	97ffff99 	bl	400154 <clock_nanosleep>
  4002f4:	34000060 	cbz	w0, 400300 <main+0x190>
  4002f8:	528000d3 	mov	w19, #0x6                   	// #6
  4002fc:	17ffffe6 	b	400294 <main+0x124>
  400300:	f85f83a8 	ldur	x8, [x29, #-8]
  400304:	8b140109 	add	x9, x8, x20
  400308:	eb13011f 	cmp	x8, x19
  40030c:	f81f83a9 	stur	x9, [x29, #-8]
  400310:	5400016d 	b.le	40033c <main+0x1cc>
  400314:	928dffea 	mov	x10, #0xffffffffffff9000    	// #-28672
  400318:	f85f03a9 	ldur	x9, [x29, #-16]
  40031c:	f2b8d8ea 	movk	x10, #0xc6c7, lsl #16
  400320:	8b0a0108 	add	x8, x8, x10
  400324:	92f0000a 	mov	x10, #0x7fffffffffffffff    	// #9223372036854775807
  400328:	eb0a013f 	cmp	x9, x10
  40032c:	f81f83a8 	stur	x8, [x29, #-8]
  400330:	54fff940 	b.eq	400258 <main+0xe8>  // b.none
  400334:	91000528 	add	x8, x9, #0x1
  400338:	f81f03a8 	stur	x8, [x29, #-16]
  40033c:	d10043a2 	sub	x2, x29, #0x10
  400340:	910083e3 	add	x3, sp, #0x20
  400344:	52800020 	mov	w0, #0x1                   	// #1
  400348:	52800021 	mov	w1, #0x1                   	// #1
  40034c:	97ffff82 	bl	400154 <clock_nanosleep>
  400350:	35fffa00 	cbnz	w0, 400290 <main+0x120>
  400354:	d10083a1 	sub	x1, x29, #0x20
  400358:	52800020 	mov	w0, #0x1                   	// #1
  40035c:	97ffff72 	bl	400124 <clock_gettime>
  400360:	35fff980 	cbnz	w0, 400290 <main+0x120>
  400364:	f85e03a9 	ldur	x9, [x29, #-32]
  400368:	f85f03a8 	ldur	x8, [x29, #-16]
  40036c:	eb08013f 	cmp	x9, x8
  400370:	54fffa4b 	b.lt	4002b8 <main+0x148>  // b.tstop
  400374:	540000c1 	b.ne	40038c <main+0x21c>  // b.any
  400378:	f85e83aa 	ldur	x10, [x29, #-24]
  40037c:	f85f83a9 	ldur	x9, [x29, #-8]
  400380:	eb09015f 	cmp	x10, x9
  400384:	54fff9ab 	b.lt	4002b8 <main+0x148>  // b.tstop
  400388:	14000002 	b	400390 <main+0x220>
  40038c:	f85f83a9 	ldur	x9, [x29, #-8]
  400390:	b9400fea 	ldr	w10, [sp, #12]
  400394:	8b14012b 	add	x11, x9, x20
  400398:	eb13013f 	cmp	x9, x19
  40039c:	1100094a 	add	w10, w10, #0x2
  4003a0:	b9000fea 	str	w10, [sp, #12]
  4003a4:	f81f83ab 	stur	x11, [x29, #-8]
  4003a8:	5400014d 	b.le	4003d0 <main+0x260>
  4003ac:	928dffea 	mov	x10, #0xffffffffffff9000    	// #-28672
  4003b0:	f2b8d8ea 	movk	x10, #0xc6c7, lsl #16
  4003b4:	8b0a0129 	add	x9, x9, x10
  4003b8:	92f0000a 	mov	x10, #0x7fffffffffffffff    	// #9223372036854775807
  4003bc:	eb0a011f 	cmp	x8, x10
  4003c0:	f81f83a9 	stur	x9, [x29, #-8]
  4003c4:	54fff4a0 	b.eq	400258 <main+0xe8>  // b.none
  4003c8:	91000508 	add	x8, x8, #0x1
  4003cc:	f81f03a8 	stur	x8, [x29, #-16]
  4003d0:	d10043a2 	sub	x2, x29, #0x10
  4003d4:	910083e3 	add	x3, sp, #0x20
  4003d8:	52800020 	mov	w0, #0x1                   	// #1
  4003dc:	52800021 	mov	w1, #0x1                   	// #1
  4003e0:	97ffff5d 	bl	400154 <clock_nanosleep>
  4003e4:	35fff560 	cbnz	w0, 400290 <main+0x120>
  4003e8:	d10083a1 	sub	x1, x29, #0x20
  4003ec:	52800020 	mov	w0, #0x1                   	// #1
  4003f0:	97ffff4d 	bl	400124 <clock_gettime>
  4003f4:	35fff4e0 	cbnz	w0, 400290 <main+0x120>
  4003f8:	f85e03a8 	ldur	x8, [x29, #-32]
  4003fc:	f85f03a9 	ldur	x9, [x29, #-16]
  400400:	eb09011f 	cmp	x8, x9
  400404:	54fff5ab 	b.lt	4002b8 <main+0x148>  // b.tstop
  400408:	540000a1 	b.ne	40041c <main+0x2ac>  // b.any
  40040c:	f85e83a8 	ldur	x8, [x29, #-24]
  400410:	f85f83a9 	ldur	x9, [x29, #-8]
  400414:	eb09011f 	cmp	x8, x9
  400418:	54fff50b 	b.lt	4002b8 <main+0x148>  // b.tstop
  40041c:	b9400fe8 	ldr	w8, [sp, #12]
  400420:	11000d08 	add	w8, w8, #0x3
  400424:	b9000fe8 	str	w8, [sp, #12]
  400428:	b9400fe8 	ldr	w8, [sp, #12]
  40042c:	7100191f 	cmp	w8, #0x6
  400430:	540001c1 	b.ne	400468 <main+0x2f8>  // b.any
  400434:	97fffefc 	bl	400024 <__jnox_errno_location>
  400438:	b9400008 	ldr	w8, [x0]
  40043c:	528000f3 	mov	w19, #0x7                   	// #7
  400440:	7100111f 	cmp	w8, #0x4
  400444:	54fff281 	b.ne	400294 <main+0x124>  // b.any
  400448:	f94013e8 	ldr	x8, [sp, #32]
  40044c:	f100451f 	cmp	x8, #0x11
  400450:	54fff221 	b.ne	400294 <main+0x124>  // b.any
  400454:	f94017e8 	ldr	x8, [sp, #40]
  400458:	f1005d1f 	cmp	x8, #0x17
  40045c:	528000e8 	mov	w8, #0x7                   	// #7
  400460:	1a8803f3 	csel	w19, wzr, w8, eq  // eq = none
  400464:	17ffff8c 	b	400294 <main+0x124>
  400468:	528000f3 	mov	w19, #0x7                   	// #7
  40046c:	17ffff8a 	b	400294 <main+0x124>
