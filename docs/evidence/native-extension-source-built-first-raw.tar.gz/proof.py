import os,json,hashlib,itertools
from pathlib import Path
from elftools.elf.elffile import ELFFile
o=Path(os.environ['out'])
def h(b):return hashlib.sha256(b).hexdigest()
def load(path):
 with path.open('rb') as f:
  e=ELFFile(f);return {s.name:(s['sh_addr'],s['sh_flags'],s.data()) for s in e.iter_sections() if s['sh_flags']&2}
for g in 'ab':
 d=o/g;print('POSITION',g)
 record=json.loads((d/'link/inputs.json').read_text());print('record keys',list(record)); flags=json.loads((d/'link/invocation.json').read_text())['argv']
 for mode in ('ordinary','dormant','active'):
  meta=json.loads((d/'link'/(mode+'.json')).read_text())
  argv=meta['argv'][1:-1]; print(mode,'differences from baseline argv at',[(i,v) for i,v in enumerate(argv) if v!=flags[i]],'constant option',argv[2])
  assert len(argv)==len(flags) and argv[2]=='--fix-cortex-a53-843419'
 print('standalone full ELF',h((o/(g+'-standalone')/'kernel.elf').read_bytes())==h((d/'ordinary/kernel.elf').read_bytes()))
 ims=[load(d/n/'kernel.elf') for n in ('ordinary','dormant','active')]
 for name in sorted(set.union(*(set(i) for i in ims))):
  s=[im.get(name) for im in ims]
  if s[0]==s[1]==s[2]:continue
  print(name,[(hex(j[0]),j[1],len(j[2]),j[2].hex() if len(j[2])<=64 else h(j[2])) if j else None for j in s])
 for r in record['inputs']:
  blobs=list((d/'link/blobs').glob(r['sha256']+'*'))
  assert len(blobs)==1 and h(blobs[0].read_bytes())==r['sha256']
 print('independently hashed ordered input blobs',len(record['inputs']))
