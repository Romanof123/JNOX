from pathlib import Path
d=Path.home()/'rel380-1c74146'
s=(d/'run.py').read_text()
exec(s[:s.index('apps=[')]+s[s.index('def capture('):s.index('for app in apps[5:]')])
def sdk(app,source,options=(),rust=False):
    tool='sdk/native-aarch64/build-rust.sh' if rust else 'sdk/native-aarch64/build.sh'
    assert run('sdk-'+app,['sh',tool,*options,source,R/(app+'.elf')])==0
def ordinary(name,options,minimum,slots):
    pkg=R/('package-'+name)
    assert run('package-'+name,['python3','tools/build_native_el0.py','--out',pkg,*options])==0
    capture(name,pkg,minimum,slots)
def elf(app):return R/(app+'.elf')
for name in ('authority-owner','authority-peer'):
    sdk(name,R/(name+'.c'),['--pipes'])
package('authority-fifo','fifo',['authority-owner','authority-peer'],['--fifo-grant','0:1:1','--pipe-link','0:3:1:3','--pipe-link','1:4:0:4'],2,[7,4])
sdk('sensor','examples/native-argv/sensor.c')
ordinary('default',['--elf',elf('sensor'),'--arg','sum','--arg','16','--arg','32','--arg','west rack'],1,1)
sdk('server','examples/native-local-sockets/server.c',['--local-socket'])
sdk('client','examples/native-local-sockets/client/Cargo.toml',['--local-socket'],True)
sdk('broker','services/socket/Cargo.toml',[],True)
routes=['--socket-service','2','--ipc-route','0:2','--ipc-route','1:2']
ordinary('local',['--policy','fifo','--elf',elf('server'),'--arg','stream','--priority','7','--peer-elf',elf('client'),'--peer-priority','4','--peer-arg','stream','--peer-elf',elf('broker'),'--peer-priority','1','--peer2-arg','3',*routes],3,3)
sdk('tcp','examples/native-inet-sockets/tcp.c',['--local-socket'])
sdk('udp','examples/native-inet-sockets/udp/Cargo.toml',['--local-socket'],True)
sdk('inet','services/inet/Cargo.toml',[],True)
pkg=R/'package-inet'
assert run('package-inet',['python3','tools/build_native_el0.py','--out',pkg,'--policy','fifo','--elf',elf('tcp'),'--priority','4','--peer-elf',elf('udp'),'--peer-priority','4','--peer-elf',elf('inet'),'--peer-priority','7','--peer2-arg','3',*routes,'--net-service','2'])==0
run('inet-tap',['unshare','--user','--map-root-user','--net','sh',R/'net.sh',pkg,R/'boot-inet'])
print('END-EXTRA',flush=True)
