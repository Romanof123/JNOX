"""Offline first-position analysis. No QEMU, network or checkout needed."""
import json, re, struct, zlib, hashlib, subprocess, pathlib, sys
from pathlib import Path
R=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
rev='1c741462b46309c45965140ae27191f8b538ff3d'
def digest(d):return hashlib.sha256(d).hexdigest()
def word(b):return int.from_bytes(b,'little',signed=True)
def req(b,msg):
    if not b:raise ValueError(msg)
def stream(data):
    seqs=[0,0];crcs=[[],[]]
    req(len(data)==8192,'record extent')
    for o in range(0,len(data),512):
        rec=data[o:o+512]
        origin,seq=rec[:2]
        req(origin<2 and seq==seqs[origin] and seq<8,'origin or ordinal')
        expected=bytes([origin,seq])+bytes((97*origin+31*seq+17*i+(i>>3))%256 for i in range(2,508))
        crc=zlib.crc32(expected)
        req(rec==expected+struct.pack('<I',crc),'record content/CRC')
        seqs[origin]+=1; crcs[origin].append(crc)
    req(seqs==[8,8],'record counts')
    return crcs
def symbols(path):
    return {p[3]:(int(p[0],16),int(p[1],16)) for l in path.read_text().splitlines() if len(p:=l.split())==4 and all(c in '0123456789abcdef' for c in p[0])}
def check(mode,policy,name=None):
    name=name or mode+'-'+policy
    c=R/('boot-'+name); p=R/('package-'+name)
    man=json.loads((p/'manifest.json').read_text())
    req(man['commit']==rev and man['tracked_changes']=='' and man['policy']==policy and man['pipes'],'manifest context')
    req(digest((p/'kernel.elf').read_bytes())==man['kernel_elf_sha256'],'kernel hash')
    apps=['writer','writer-rust','reader'] if mode=='named' else ['anon-writer','anon-reader']
    raw=(c/'ram.bin').read_bytes(); launch=json.loads((c/'capture.json').read_text())
    lo,hi=launch['lo'],launch['hi']
    req(len(raw)==hi-lo,'RAM length')
    uart=(c/'uart.bin').read_text()
    for pid,app in enumerate(apps):
        slot=man['slots'][pid]
        req(digest((R/(app+'.elf')).read_bytes())==slot['elf_sha256']==digest((p/slot['elf']).read_bytes()),'user digest')
        hdr=(R/('readelf-'+app+'.log')).read_text()
        flags=[''.join(l.split()[6:-1]) for l in hdr.splitlines() if l.lstrip().startswith('LOAD ')]
        req(flags==['RE','R','RW'],'application LOADs')
        req(slot['elf_sha256'] in uart,'uart boot digest')
    spaces=[v for k,v in symbols(c/'kernel.nm').items() if 'native_el0_mmu6SPACES' in k]
    req(len(spaces)==1,'private spaces'); base,size=spaces[0]
    stride,rem=divmod(size,len(apps)); req(rem==0,'space stride')
    roots=[base+pid*stride for pid in range(len(apps))]
    def translate(pid,va):
        tbl=roots[pid]
        for shift in (30,21,12):
            d=struct.unpack_from('<Q',raw,tbl-lo+((va>>shift)&511)*8)[0]
            req(d&3==3,'valid leaf/table')
            tbl=d&0xfffff000
        req(d&64 and d&(1<<54) and not d&128,'RW private data')
        return tbl+(va&4095)
    anchors=[translate(pid,0x403000) for pid in range(len(apps))]
    req(len(set(anchors))==len(apps),'distinct private output pages')
    def data(pid,sym):
        va,n=symbols(R/('nm-'+apps[pid]+'.log'))[sym]
        out=bytearray()
        while len(out)<n:
            addr=va+len(out); pa=translate(pid,addr)
            count=min(n-len(out),4096-(addr&4095))
            out.extend(raw[pa-lo:pa-lo+count])
        return bytes(out)
    result={'roots':roots,'physical_rw_pages':anchors,'capture_label':launch['capture']}
    states=[[int(i) for i in l.split()[3:]] for l in uart.splitlines() if l.startswith('NATIVE PIPE STATE 1 ')]
    req(len(states)==4 and all(row[3:9]==[0]*6 for row in states),'final refs/objects/bytes')
    peaks=[row[-1] for row in states]; req(peaks==([1,1,1,2048] if mode=='named' else [4,1,0,0]),'peak occupancy')
    exits=dict((int(k),int(v)) for k,v in re.findall(r'^NATIVE EL0 EXIT PID (\d+) (-?\d+)$',uart,re.M))
    req(list(exits.values())==([61,62,63] if mode=='named' else [64,65]),'process exits')
    result.update(exits=exits,peaks=peaks,final_states=states,scheduler_events_dropped=int(re.search('NATIVE FIXED DROPPED (\\d+)',uart)[1]))
    if mode=='named':
        rec=data(2,'pipe_received'); crcs=stream(rec)
        calls=word(data(2,'pipe_reads')); sizes=struct.unpack('<128H',data(2,'pipe_read_sizes'))[:calls]
        req(calls<=128 and sizes[-1]==0 and all(0<v<=137 for v in sizes[:-1]) and sum(sizes)==8192,'read sizes and EOF')
        req([word(data(2,n)) for n in ['pipe_records','pipe_eof']]==[16,1],'reader records')
        req([word(data(0,n)) for n in ['c_full_rc','c_full_errno','c_write_count']]==[-1,11,8],'full return and C count')
        req(word(data(1,'rust_write_count'))==8,'Rust count')
        for i,n in enumerate(['c_writer_crc','rust_writer_crc']):
            req(tuple(crcs[i])==struct.unpack('<8I',data(i,n)),'writer CRCs')
        order=[list(rec[i:i+2]) for i in range(0,len(rec),512)]
        mutations=[('short extent',rec[:-1]),('shorter record/duplicate record',rec[512:]+rec[-512:]),('content corruption',rec[:210]+bytes([rec[210]^1])+rec[211:]),('trailer corruption',rec[:-1]+bytes([rec[-1]^1]))]
        for label,mut in mutations:
            try: stream(mut)
            except ValueError: pass
            else:raise ValueError(label+' failed to reject')
        result.update(total_bytes=len(rec),sha256=digest(rec),read_sizes=sizes,order=order,writer_crcs=crcs,c_full_rc=-1,c_full_errno=11,controls_rejected=[k for k,v in mutations])
    else:
        sub=data(1,'anon_data')
        vals=[word(data(1,k)) for k in ['anon_eof','anon_epipe_rc','anon_epipe_errno','anon_done']]
        req(sub==b'rainfall' and vals==[0,-1,32,1] and word(data(0,'anon_writer_steps'))==2,'anonymous bytes/close/EOF/EPIPE')
        result.update(bytes=sub.decode(),eof=vals[0],epipe_rc=vals[1],epipe_errno=vals[2],done=vals[3],steps=2)
    return result
