set -eu
d=/home/ywcho/rel380-1c74146
out=/mnt/d/codex/.jnox-work/next-fixed/380-release-1c74146
cd "$d"
cp "$out/README.en-ko.md" "$out/seal.sh" raw/
cp suite.log extra.log follow.log raw/
cp replay-2.json raw/report.json
git -C src status --short > raw/post-run.status
git -C src diff --exit-code
git -C src archive --format=tar.gz --output="$d/raw/sources.tar.gz" HEAD arch boards examples kernel sdk services tools .gitattributes
mkdir -p raw/prior
for rev in 9271a68 73052d1; do
    cp "$d/verified-$rev.log" "$d/replay-$rev.json" raw/prior/
    cmp "$d/prior-$rev/report.json" "$d/replay-$rev.json"
done
sha256sum src/docs/evidence/native-pipe-ipc-{first,corrected}.tar.gz > raw/prior/archive-hashes.txt
cp "$d/prior-9271a68/sdk-shell.log" raw/prior/first-sdk-shell.log
cp "$d/prior-9271a68/README.en-ko.md" raw/prior/first.en-ko.md
cp "$d/prior-73052d1/README.en-ko.md" raw/prior/corrected.en-ko.md
sha256sum writer*-*.text >raw/prior/writer-text-hashes.txt
{ qemu-system-aarch64 --version; clang --version; ld.lld --version; /home/ywcho/.cargo/bin/rustc -vV; /home/ywcho/.cargo/bin/cargo --version; python3 --version; wc --version; uname -a; } > raw/provenance.txt
cd raw
python3 -B replay.py > "$d/preseal.json"
cmp "$d/preseal.json" report.json
find . -name target -prune -o -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum >SHA256SUMS
sha256sum -c SHA256SUMS >"$d/raw-check.log"
tar --exclude='*/target' -czf "$d/native-pipe-ipc-release-supplement.tar.gz" .
cp "$d/native-pipe-ipc-release-supplement.tar.gz" report.json "$out/"
cd "$out"
sha256sum native-pipe-ipc-release-supplement.tar.gz > native-pipe-ipc-release-supplement.tar.gz.sha256
mkdir -p "$d/clean-replay"
tar -xzf native-pipe-ipc-release-supplement.tar.gz -C "$d/clean-replay"
cd "$d/clean-replay"
sha256sum -c SHA256SUMS >"$d/clean-check.log"
python3 -B replay.py >"$d/clean.json"
cmp report.json "$d/clean.json"
wc -l SHA256SUMS
cat "$out/native-pipe-ipc-release-supplement.tar.gz.sha256"
ls -l "$out/native-pipe-ipc-release-supplement.tar.gz"
