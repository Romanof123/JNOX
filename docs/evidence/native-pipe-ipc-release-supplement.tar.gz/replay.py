"""Offline release replay, including private per-process memory and packaging controls."""
import json, re, struct
from shell_replay import R, check, req, rev, digest, qmp, Memory, rows, shell, contention, elf_symbols, elf_phdr_data

def setup(name, pkg=None):
    c=R/('boot-'+name); p=R/('package-'+(pkg or name))
    m=Memory(c,p)
    man=json.loads((p/'manifest.json').read_text())
    req(man['commit']==rev and man['tracked_changes']=='' and man['board']=='virt','provenance')
    req(digest((p/'kernel.elf').read_bytes())==man['kernel_elf_sha256'],'kernel')
    if (c/'capture.json').exists(): qmp(c)
    uart=(c/('uart.bin' if (c/'uart.bin').exists() else 'uart')).read_text()
    req('FAULT' not in uart and 'PANIC' not in uart,'guest fault')
    for slot in man['slots']:
        req(digest((p/slot['elf']).read_bytes())==slot['elf_sha256'] and slot['elf_sha256'] in uart,'slot')
    def data(pid,key,fmt=None):
        va,n=elf_symbols(p/man['slots'][pid]['elf'])[key]
        b=m.user(pid,va,n)
        return list(struct.unpack('<'+fmt,b)) if fmt else b
    return data,uart,man

def private_rights(name,expected_exit):
    data,u,man=setup(name)
    own=data(0,'release_owner','24i'); peer=data(1,'release_peer','6i')
    req(own[:11]==[-1,6,1900,148,-1,11,0,0,2048,-1,24],'guest FIFO partial/full/EOF/fd limit')
    req(peer==[-1,13,-1,13,-1,1],'foreign read/write access and unlink')
    ex=dict(rows(u,'NATIVE EL0 EXIT PID ')); req(ex=={0:expected_exit,1:69},'controlled exits')
    states=rows(u,'NATIVE PIPE STATE 1 ')
    if expected_exit==68:
        req(own[11:15]==[-1,23,0,1] and all(s[2:8]==[0]*6 for s in states),'guest object limit and exit retirement')
    else:
        req(any(s[2:4]==[1,1] for s in states),'retained first fixture outcome')
    return dict(owner=own,foreign=peer,exits=ex,final_states=states)

def integration():
    data,u,man=setup('default')
    vals={k:int.from_bytes(data(0,'sensor_'+k),'little') for k in ['argc','count','sum','yields']}
    req(vals==dict(argc=5,count=16,sum=376,yields=4) and 'NATIVE EL0 EXIT 17' in u and not man.get('pipes', False),'ordinary default')
    server,u,man=setup('local')
    srv=server(0,'socket_server_result','12q'); cli=server(1,'socket_client_result','12q')
    req(srv==[1,1,2080,64,3,16,45,0,0,32,1,0] and cli==[1,7,57,0,0,-11,32,0,1,0,0,0],'AF_UNIX stream result')
    req(dict(rows(u,'NATIVE EL0 EXIT PID '))=={0:73,1:74,2:0} and not man.get('pipes', False),'local exits')
    net,u,man=setup('inet-private','inet'); cap=R/'boot-inet-private'
    tcp=net(0,'inet_tcp_result','12q'); udp=net(1,'inet_udp_result','16q')
    req(tcp[:3]==[4,9,13] and 1<=tcp[3]<=3 and tcp[4:]==[0,12,14,0,4,-1,104,1],'TCP')
    req(udp[:10]==[3,3,3,3,1,4,3,0,0x0a000202,43004] and udp[10]>0 and udp[11:]==[1,0,0,0,0],'UDP')
    launch=json.loads((cap/'launch.json').read_text()); status=json.loads((cap/'status.json').read_text())
    req(man['kernel_elf_sha256']==launch['kernel_sha256'] and not man.get('pipes', False) and 'tap,id=lan,ifname=jnx0,script=no,downscript=no' in launch['argv'],'separate TAP package')
    req(status=={'guest_exits':[[0,75],[1,76],[2,0]],'tcp':'complete','udp':'complete'} and dict(rows(u,'NATIVE EL0 EXIT PID '))=={0:75,1:76,2:0},'inet exits')
    ev=[json.loads(l) for l in (cap/'peer.jsonl').read_text().splitlines()]
    def vals_for(k,field='data'):return [bytes.fromhex(e[field]) for e in ev if e['kind']==k]
    req(vals_for('tcp_out_rx')==[b'GUEST/out'] and vals_for('tcp_in_rx')==[b'GUEST/accepted'] and vals_for('tcp_abortive_close','received')==[b'ARM!'],'TCP host')
    req(vals_for('udp_before_relay')==[bytes((85,i,10*i)) for i in (1,2,3,4)] and vals_for('udp_after_relay')==[bytes((82,i,10*i)) for i in (1,4,3,0)] and vals_for('udp_final_rx')==[b'DONE'],'UDP host')
    return dict(default=vals,af_unix=dict(server=srv,client=cli),inet=dict(tcp=tcp,udp=udp,status=status,pcap_sha256=digest((cap/'wire.pcap').read_bytes())))

def main():
    result={'source':rev,'tree':(R/'commit.txt').read_text().splitlines()[1],'shell':{}}
    for case,p,mode in [('a','fifo','normal'),('b','rr','combined'),('unknown','fifo','normal'),('missing','rr','combined'),('a','fifo','probe')]:
        names=({'normal':['shell','cat','wc'],'probe':['shell','probe-cat','probe-wc'],'combined':['combined-'+a for a in ('shell','cat','wc')]})[mode]
        label='shell-'+('probe' if mode=='probe' else case)+'-'+p
        out=shell(case,p,label,names)
        if mode=='probe':
            data,u,man=setup(label)
            fds=[data(i,'child_fds','8i') for i in (1,2)]
            req(fds==[[1,0,-1,9,-1,9,-1,9],[0,0,-1,9,-1,9,-1,9]],'child-side standard FDs, directions and parent numbers absent')
            out['child_fds']=fds
        result['shell'][label]=out
    qmp(R/'boot-anon-rr'); result['anonymous']=check('anon','rr')
    result['competing_writers']=contention('fifo')
    for app,pc in [('writer',0x401694),('writer-rust',0x400200)]:
        req(elf_phdr_data(R/(app+'.elf'),pc,4)==bytes.fromhex('02408052'),'record-length argument')
    result['foreign_and_limits']={n:private_rights(n,e) for n,e in [('authority-fifo',100),('authority-fixed-fifo',68)]}
    result['integration_controls']=integration()
    req('6 passed; 0 failed' in (R/'host-controls.log').read_text(),'host controls')
    return result

if __name__=='__main__': print(json.dumps(main(),indent=2))
