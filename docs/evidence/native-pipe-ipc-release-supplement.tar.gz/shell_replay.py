"""Offline independent replay of IPC-007. Uses only the extracted packet and Python."""
from pathlib import Path
import struct, json, re, sys
from streams import R, check, symbols, digest, req, rev

NO=(1<<64)-1
COMMANDS={'a':'cat sample.txt | wc -l','b':'cat sample.txt | wc -l','missing':'cat missing.txt | wc -l',
          'unknown':'cat sample.txt | missing -l','malformed':'cat sample.txt |'}
def rows(uart,tag):
    return [list(map(int,l[len(tag):].split())) for l in uart.splitlines() if l.startswith(tag)]
def qmp(c):
    a=json.loads((c/'capture.json').read_text())
    q=json.loads((c/'running.json').read_text())
    h=json.loads((c/'stopped.json').read_text())
    req(a['capture']=='terminal' and q['status']['running'] and len(q['cpus'])==1 and q['cpus'][0]['cpu-index']==0 and not h['running'] and h['status']=='paused','running CPU0, paused extraction')
def elf_phdr_data(file,va,n):
    b=file.read_bytes()
    phoff=struct.unpack_from('<Q',b,32)[0]
    ents,num=struct.unpack_from('<HH',b,54)
    for i in range(num):
        tag,flags,off,start,pa,fsz,msz,al=struct.unpack_from('<II6Q',b,phoff+i*ents)
        if tag==1 and start<=va and va+n<=start+fsz:
            return b[off+va-start:off+va-start+n]
    raise ValueError('ELF address')
def elf_symbols(file):
    b=file.read_bytes()
    shoff=struct.unpack_from('<Q',b,40)[0]
    ents,num=struct.unpack_from('<HH',b,58)
    ss=[struct.unpack_from('<IIQQQQIIQQ',b,shoff+i*ents) for i in range(num)]
    ret={}
    for sec in ss:
        if sec[1]!=2:continue
        st=ss[sec[6]]; strings=b[st[4]:st[4]+st[5]]
        for off in range(sec[4],sec[4]+sec[5],sec[9]):
            ix,info,other,ndx,va,size=struct.unpack_from('<IBBHQQ',b,off)
            name=strings[ix:strings.index(0,ix)].decode()
            if name and size:ret[name]=(va,size)
    return ret
class Memory:
    def __init__(self,c,p):
        count=len(json.loads((p/'manifest.json').read_text())['slots'])
        self.data=(c/'ram.bin').read_bytes()
        cap=json.loads((c/'capture.json').read_text()) if (c/'capture.json').exists() else {'lo':0x40000000,'hi':0x40000000+len(self.data)}
        self.lo=cap['lo'];self.hi=cap['hi']
        self.syms=elf_symbols(p/'kernel.elf')
        req(len(self.data)==self.hi-self.lo,'physical memory extent')
        base,n=self.sym('native_el0_mmu6SPACES')
        req(n%count==0,'private spaces')
        self.roots=[base+n//count*i for i in range(count)]
    def sym(self,key):
        matches=[v for k,v in self.syms.items() if key in k]
        req(len(matches)==1,'unique symbol '+key)
        return matches[0]
    def physical(self,pa,n):
        req(self.lo<=pa<=pa+n<=self.hi,'physical range')
        return self.data[pa-self.lo:pa-self.lo+n]
    def kernel(self,key):
        return self.physical(*self.sym(key))
    def translate(self,pid,va,access):
        tbl=self.roots[pid]
        for shift in (30,21,12):
            d=struct.unpack('<Q',self.physical(tbl+((va>>shift)&511)*8,8))[0]
            req(d&3==3,'three valid descriptors')
            tbl=d&0xfffff000
        req(d&64 and d&(1<<54) and bool(d&128)==(access=='ro'),'user data permissions')
        return tbl+(va&4095)
    def user(self,pid,va,n,access='rw'):
        out=bytearray()
        while n:
            take=min(n,4096-(va&4095))
            out.extend(self.physical(self.translate(pid,va,access),take))
            va+=take;n-=take
        return bytes(out)
def shell(case,policy,label=None,apps=None):
    name=label or f'shell-{case}-{policy}'; c=R/('boot-'+name); p=R/('package-'+name)
    qmp(c);m=Memory(c,p)
    man=json.loads((p/'manifest.json').read_text())
    uart=(c/'uart.bin').read_bytes(); u=uart.decode()
    req('FAULT' not in u and 'PANIC' not in u,'faulted guest')
    req(man['commit']==rev and man['tracked_changes']=='' and man['board']=='virt' and man['policy']==policy and man['pipes'] and man['exec_names']==['sh','cat','wc'],'frozen shell manifest')
    req(digest((p/'kernel.elf').read_bytes())==man['kernel_elf_sha256'],'kernel digest')
    req(man['slots'][0]['argv']==['/bin/app',COMMANDS[case]] and not man['pipe_links'],'real shell argv and dynamic wiring')
    req([s['priority'] for s in man['slots']]==[7,4,4],'shell priorities')
    apps=apps or ['shell','cat','wc']
    for pid,app in enumerate(apps):
        sl=man['slots'][pid]
        req(digest((R/(app+'.elf')).read_bytes())==sl['elf_sha256']==digest((p/sl['elf']).read_bytes()) and sl['elf_sha256'] in u,'app digests')
        req([''.join(l.split()[6:-1]) for l in (R/('readelf-'+app+'.log')).read_text().splitlines() if l.lstrip().startswith('LOAD ')]==['RE','R','RW'],'user LOADs')
    pages=[m.translate(i,elf_symbols(R/(app+'.elf'))[sym][0],'rw') for i,(app,sym) in enumerate(zip(apps,('shell_result','cat_result','wc_result')))]
    req(len(set(pages))==3,'separate private RAM')
    rom=(p/man['rom_image']).read_bytes()
    source='b' if case=='b' else 'a'
    content=(R/f'input-{source}.txt').read_bytes(); host=(R/f'wc-{source}.bin').read_bytes()
    req(host==(str(content.count(b'\n'))+'\n').encode(),'GNU wc artifact')
    req(rom[:8]==b'JNOXROM1' and int.from_bytes(rom[8:12],'little')==1 and rom[16:48].rstrip(b'\0')==b'sample.txt','catalog')
    off,n=struct.unpack_from('<II',rom,48)
    req(len(rom)==8192 and rom[off:off+n]==content and n==len(content) and man['rom_files']==[dict(name='sample.txt',offset=off,length=n,sha256=digest(content))],'file bytes')
    req(digest(rom)==man['rom_sha256'] and m.kernel('jnox_native_shell_rom')==rom and all(m.user(i,0x1800000,len(rom),'ro')==rom for i in range(3)),'RO ROM mappings')
    events=rows(u,'NATIVE FIXED EVENT ')
    req(rows(u,'NATIVE FIXED DROPPED ')==[[0]] and events[0][3:5]==[NO,0] and events[-1][4]==NO and all(e[0]<=f[0] for e,f in zip(events,events[1:])),'complete scheduling history')
    children=rows(u,'NATIVE SHELL CHILD ')
    startup=list(struct.iter_unpack('<4Q',m.kernel('jnox_native_startup_slots')))
    argv_all=[]
    for pid,(entry,sp,n,argc) in enumerate(startup):
        h=m.user(pid,sp,n)
        req(n%16==0 and sp%16==0 and struct.unpack_from('<Q',h)[0]==argc,'startup tail')
        argv=[]
        for i in range(argc):
            s=struct.unpack_from('<Q',h,8+i*8)[0]-sp
            req(0<=s<n,'argv tail pointer')
            argv.append(h[s:h.index(0,s)].decode())
        req(struct.unpack_from('<QQ',h,8*(argc+1))==(0,0),'argv and environment terminators')
        argv_all.append(argv)
    req(argv_all[0]==['/bin/app',COMMANDS[case]],'shell command')
    def var(pid,name):
        return m.user(pid,*elf_symbols(R/(apps[pid]+'.elf'))[name])
    sh=list(struct.unpack('<8i',var(0,'shell_result')))
    cat=list(struct.unpack('<3Q',var(1,'cat_result')))
    wc=list(struct.unpack('<4Q',var(2,'wc_result')))
    open_fds=[]
    for pid in range(3):
        desc=list(struct.iter_unpack('<4I',var(pid,'boot_files')))
        req(all(d[3]==0 for d in desc),'all application ROM FDs closed')
        open_fds.append(desc)
    nu=len(content); nl=content.count(b'\n')
    expected_out=host if case in ('a','b') else b'0\n' if case=='missing' else b''
    ex=dict(rows(u,'NATIVE EL0 EXIT PID '))
    if case in ('a','b','missing'):
        left=1 if case=='missing' else 0
        req(sh==[1,1,1,2,1,2,left,0] and ex=={0:0,1:left,2:0},'real children reaped')
        req(cat==([0,0,0] if left else [nu,nu,1]) and wc==([0,0,1,2] if left else [nu,nl,1,len(host)]),'cat and wc read/write/EOF')
        req(argv_all[1:]==[['cat','missing.txt' if left else 'sample.txt'],['wc','-l']],'parsed argv')
    elif case=='unknown':
        req(sh==[1,1,1,-1,1,0,1,-1] and ex=={0:127,1:1} and cat==[nu,0,0] and wc==[0]*4 and argv_all[1]==['cat','sample.txt'],'missing program and closed reader')
    else:
        req(sh==[0]*8 and ex=={0:2} and cat==[0]*3 and wc==[0]*4 and not any(e[1] in (41,50) for e in events),'malformed input')
    req(len(children)==2,'two register slots')
    for ch in children:
        pid,phase,spawn,exit,wait,status,argc,fdin,fdout,entry,sp,orphan=ch
        selected=[e for e in events if e[4]==pid]
        if pid in ex:
            req(phase==3 and 0<spawn<=exit<=wait and status==ex[pid] and argc==2 and (entry,sp)==startup[pid][:2] and not orphan,'reaped child')
            req((fdin,fdout)==((NO,4) if pid==1 else (3,NO)), 'directional descriptor redirection')
            req(selected and selected[0][0]>=spawn and selected[0][7:9]==[entry,sp] and all(e[15+pid]==0 for e in events if e[0]<spawn),'no child service before launch')
        else:
            req(ch==[pid,4,0,0,0,0,0,NO,NO,0,0,0] and not selected and all(e[15+pid]==0 for e in events) and argv_all[pid]==['/bin/app'],'dormant child')
    descs=rows(u,'NATIVE PIPE STATE 1 ')
    req(len(descs)==4 and all(d[2:8]==[0]*6 for d in descs),'no remaining pipe objects, names, owners, FDs or bytes')
    tasks=rows(u,'NATIVE PIPE TASK 1 ')
    transported=nu if case in ('a','b') else 0
    req([row[3:5] for row in tasks]==[[0,0],[0,transported],[transported,0]],'child stream totals')
    log=m.kernel('5spawn3LOG'); used=struct.unpack('<Q',m.kernel('5spawn4USED'))[0]
    req(struct.unpack('<Q',m.kernel('5spawn7DROPPED'))==(0,) and rows(u,'NATIVE SHELL CONSOLE DROPPED ')==[[0]],'no console records lost')
    out=bytearray()
    for i in range(used):
        row=log[i*280:(i+1)*280]
        pid,fd,nbytes=struct.unpack_from('<QQQ',row,256)
        req(pid==2 and fd==1 and nbytes<=256,'stdout attribution')
        payload=row[:nbytes]
        req(rows(u,f'NATIVE SHELL CONSOLE {i} ')==[[pid,fd,nbytes,*payload]],'UART/RAM journal equality')
        out.extend(payload)
    req(bytes(out)==expected_out and used==bool(out),'stdout bytes equal host/controls')
    if expected_out:
        req(expected_out in uart.split(b'NATIVE PIPE TASK 0 2 0 0 0 0\n')[1].split(b'NATIVE PIPE STATE 1')[0],'live, unformatted stdout')
    return dict(roots=m.roots,private_pages=pages,exec_argv=argv_all,input_sha256=digest(content),input_bytes=nu,input_newlines=nl,
                known_shell_result=sh,cat=cat,wc=wc,kernel_pipe_task_counters=tasks,pipe_final=descs,
                child_rows=children,exits=ex,raw_pid2_fd1_stdout_hex=out.hex(),host_wc_hex=host.hex(),scheduler_events=len(events),
                kernel_sha256=man['kernel_elf_sha256'])

def contention(policy):
    name='compete-'+policy
    res=check('named',policy,name); p=R/('package-'+name); c=R/('boot-'+name);qmp(c)
    req([x['priority'] for x in json.loads((p/'manifest.json').read_text())['slots']]==[7,6,3],'both writers outrank reader')
    uart=(c/'uart.bin').read_text()
    ev=rows(uart,'NATIVE FIXED EVENT ')
    def on_svc(row,pid):
        if row[1]!=47 or row[3]!=pid or row[4]==pid:
            return False
        path=R/('writer.elf' if pid==0 else 'writer-rust.elf')
        return elf_phdr_data(path,row[5]-4,8)==bytes.fromhex('e8058052214009d4')
    proof=[]
    for i,r in enumerate(ev):
        if not (on_svc(r,0) and r[4]==1 and 0 not in r[12:15]):continue
        for j in range(i+1,len(ev)):
            t=ev[j]
            if t[3]!=1:break
            if on_svc(t,1) and t[4]==2 and all(x==NO for x in t[12:15]):
                for k in range(j+1,len(ev)):
                    u=ev[k]
                    if u[3]!=2:break
                    if u[1]==46 and u[4]==0 and 1 in u[12:15] and u[7]==r[5]:
                        proof.append(dict(c_block_event=i,rust_block_event=j,reader_wakes_both_event=k,
                               c_retry_svc_pc=r[5],rust_retry_svc_pc=t[5],counter_ticks=[r[0],t[0],u[0]]))
                        break
                break
    req(proof,'two non-runnable writers, verified SVC opcodes, common reader wake')
    res['simultaneous_block_windows']=proof
    res['pipe_tasks']=rows(uart,'NATIVE PIPE TASK 1 ')
    return res

