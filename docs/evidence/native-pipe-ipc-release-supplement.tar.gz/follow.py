from pathlib import Path
d=Path.home()/'rel380-1c74146'
x=(d/'raw'/'extra.py').read_text()
exec(x[:x.index("for name in ('authority-owner'")])
a=(R/'authority-owner.c').read_text().replace('payload[2200]', 'payload[2600]').replace("mark != 'Y')","mark != 'Y' || read(4, &mark, 1) != 0)")
(R/'owner-fixed.c').write_text(a)
sdk('owner-fixed',R/'owner-fixed.c',['--pipes'])
package('authority-fixed-fifo','fifo',['owner-fixed','authority-peer'],['--fifo-grant','0:1:1','--pipe-link','0:3:1:3','--pipe-link','1:4:0:4'],2,[7,4])
for name,fd,op in [('cat',1,'read(1,&byte,1)'),('wc',0,'write(0,&byte,1)')]:
    src=(S/'examples/native-shell-pipeline'/(name+'.c')).read_text()
    probe='#include <errno.h>\n#include <fcntl.h>\nvolatile int child_fds[8];\n'
    probe+='int main(int argc, char **argv)\n{\n'
    probe+=f'    char byte = 0;\n    child_fds[0]=fcntl({fd},F_GETFL);\n    child_fds[1]=fcntl({fd},F_GETFD);\n'
    probe+=f'    child_fds[2]={op};\n    child_fds[3]=errno;\n'
    probe+='    child_fds[4]=fcntl(3,F_GETFD);\n    child_fds[5]=errno;\n    child_fds[6]=fcntl(4,F_GETFD);\n    child_fds[7]=errno;\n'
    src=src.replace('int main(int argc, char **argv)\n{',probe)
    (R/('probe-'+name+'.c')).write_text(src)
    sdk('probe-'+name,R/('probe-'+name+'.c'),['--local-socket','--pipes','--native-shell'])
    run('readelf-probe-'+name,['readelf','-lW',R/('probe-'+name+'.elf')])
package('shell-probe-fifo','fifo',['shell','probe-cat','probe-wc'],['--exec-child','1:cat','--exec-child','2:wc','--rom-file','sample.txt='+str(R/'input-a.txt'),'--arg','cat sample.txt | wc -l'],3,[7,4,4])
print('END-FOLLOWUP', flush=True)
