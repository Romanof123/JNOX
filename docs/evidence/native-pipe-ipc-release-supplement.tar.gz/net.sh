#!/bin/sh
set -eu
ip link set lo up
ip tuntap add dev jnx0 mode tap
ip addr add 10.0.2.2/24 dev jnx0
ip link set jnx0 up
ip -br addr
ip route
exec python3 examples/native-inet-sockets/peer.py "$1" "$2" --isolated-tap jnx0 --timeout 15