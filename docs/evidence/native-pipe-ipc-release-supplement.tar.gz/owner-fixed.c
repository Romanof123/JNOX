#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

volatile int release_owner[24];
static char payload[2600];

int main(void)
{
    char mark;
    int pair[2];
    if (mkfifo("/private", 0600) || write(3, "g", 1) != 1 ||
        read(4, &mark, 1) != 1 || mark != 'Y' || read(4, &mark, 1) != 0) return 91;
    release_owner[0] = open("/private", O_WRONLY | O_NONBLOCK);
    release_owner[1] = errno;
    int reader = open("/private", O_RDONLY | O_NONBLOCK);
    int writer = open("/private", O_WRONLY | O_NONBLOCK);
    if (reader < 0 || writer < 0 || close(3) || close(4)) return 92;
    for (unsigned i = 0; i < sizeof(payload); ++i) payload[i] = (char)(i * 17u + 3u);
    release_owner[2] = write(writer, payload, 1900);
    release_owner[3] = write(writer, payload + 1900, 600);
    release_owner[4] = write(writer, payload, 500);
    release_owner[5] = errno;
    if (unlink("/private") || mkfifo("/private", 0600)) return 93;
    int fresh = open("/private", O_RDONLY | O_NONBLOCK);
    if (fresh < 0) return 94;
    release_owner[6] = read(fresh, &mark, 1);
    release_owner[7] = close(writer);
    char actual[127];
    int total = 0;
    for (;;) {
        int n = read(reader, actual, sizeof(actual));
        if (n < 0) return 95;
        if (!n) break;
        for (int j = 0; j < n; ++j)
            if (actual[j] != (char)((total+j)*17u+3u)) return 96;
        total += n;
    }
    release_owner[8] = total;
    if (close(reader) || close(fresh) || unlink("/private")) return 97;
    if (pipe(pair) || dup2(pair[0],0)<0 || dup2(pair[0],1)<0 ||
        dup2(pair[0],2)<0 || dup2(pair[0],5)<0 || dup2(pair[0],6)<0) return 98;
    release_owner[9] = pipe((int[2]){0,0});
    release_owner[10] = errno;
    if (close(0) || close(1) || close(2) || close(5) || close(6)) return 99;
    if (mkfifo("/one",0600) || mkfifo("/two",0600) || mkfifo("/three",0600)) return 100;
    release_owner[11] = pipe((int[2]){0,0});
    release_owner[12] = errno;
    if (unlink("/one") || unlink("/two") || unlink("/three")) return 101;
    release_owner[13]=fcntl(pair[0],F_GETFL);
    release_owner[14]=fcntl(pair[1],F_GETFL);
    /* Both remaining anonymous ends are deliberately held at process exit. */
    return 68;
}