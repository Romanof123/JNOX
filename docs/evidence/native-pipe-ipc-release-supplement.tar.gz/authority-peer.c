#include <errno.h>
#include <fcntl.h>
#include <unistd.h>

volatile int release_peer[6];
int main(void)
{
    char signal;
    if (read(3, &signal, 1) != 1 || signal != 'g') return 90;
    release_peer[0] = open("/private", O_RDONLY | O_NONBLOCK);
    release_peer[1] = errno;
    release_peer[2] = open("/private", O_WRONLY | O_NONBLOCK);
    release_peer[3] = errno;
    release_peer[4] = unlink("/private");
    release_peer[5] = errno;
    if (write(4, "Y", 1) != 1) return 91;
    return 69;
}