#include <fcntl.h>
#include <stdint.h>
#include <unistd.h>

/* File bytes read, bytes written to stdout, reads returning EOF. */
volatile uint64_t cat_result[3];

#include <errno.h>
#include <fcntl.h>
volatile int child_fds[8];
int main(int argc, char **argv)
{
    char byte = 0;
    child_fds[0]=fcntl(1,F_GETFL);
    child_fds[1]=fcntl(1,F_GETFD);
    child_fds[2]=read(1,&byte,1);
    child_fds[3]=errno;
    child_fds[4]=fcntl(3,F_GETFD);
    child_fds[5]=errno;
    child_fds[6]=fcntl(4,F_GETFD);
    child_fds[7]=errno;

    if (argc != 2)
        return 2;
    int fd = open(argv[1], O_RDONLY);
    if (fd < 0)
        return 1;
    char data[53];
    for (;;) {
        ssize_t n = read(fd, data, sizeof(data));
        if (n < 0) {
            close(fd);
            return 1;
        }
        if (!n) {
            ++cat_result[2];
            break;
        }
        cat_result[0] += (unsigned)n;
        for (ssize_t sent = 0; sent < n;) {
            ssize_t k = write(STDOUT_FILENO, data + sent, (size_t)(n - sent));
            if (k <= 0) {
                close(fd);
                return 1;
            }
            sent += k;
            cat_result[1] += (unsigned)k;
        }
    }
    return close(fd) == 0 ? 0 : 1;
}
