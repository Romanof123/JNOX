set -eu
r=$PWD
d="$HOME/jnox-089-independent"
mkdir "$d"; mkdir "$d/src"; tar -xf "$r/freeze.tar" -C "$d/src"
export CARGO_HOME="$HOME/jnox-169-first-e203caa/cargo" RUSTUP_HOME="$HOME/jnox-169-first-e203caa/rustup" PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" PYTHONDONTWRITEBYTECODE=1
cd "$d/src/kernel"; export JNOX_BOARD=virt JNOX_PROFILE=reservation JNOX_APP=aligned-saturated
mkdir "$r/preflight"
rustc +1.95.0 -vV > "$r/preflight/compiler.txt"
rustc +1.95.0 --print sysroot | xargs -I@ sh -c 'sha256sum @/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld; @/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld -flavor gnu --version' > "$r/preflight/linker.txt"
for arm in B P; do
 mkdir "$r/preflight/$arm"
 export CARGO_TARGET_DIR="$d/target-$arm"
 if [ "$arm" = P ]; then export JNOX_RESERVATION_STAGE=frame-window; fi
 cargo +1.95.0 build --release --locked -j1 >"$r/preflight/$arm/build.log" 2>&1
 f="$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel"; cp "$f" "$r/preflight/$arm/kernel.elf"
 aarch64-linux-gnu-objdump -dC "$f" > "$r/preflight/$arm/disassembly"
 aarch64-linux-gnu-readelf -lSW "$f" > "$r/preflight/$arm/map"
done
cd "$d/src/tools"; python3 -m unittest -v test_reservation_frame_window > "$r/preflight/controls.log" 2>&1