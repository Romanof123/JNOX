from pathlib import Path
import json,hashlib,struct,subprocess,sys,time,shutil
r=Path(__file__).resolve().parent;h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def image(p):
 b=p.read_bytes(); ph=struct.unpack_from('<Q',b,32)[0];size,n=struct.unpack_from('<HH',b,54)
 return [struct.unpack_from('<Q',b,24)[0],[(s,hv) for i in range(n) for s in [struct.unpack_from('<II6Q',b,ph+i*size)] if s[0]==1 for hv in [hashlib.sha256(b[s[2]:s[2]+s[5]]).hexdigest()]]]
p=r/'preflight';d=Path.home()/'jnox-089-independent';q=Path('/usr/bin/qemu-system-aarch64')
old=r.parent/'reservation-172-independent/images/aligned-saturated/kernel.elf'
assert image(old)==image(p/'B/kernel.elf'),(image(old),image(p/'B/kernel.elf'))
order=[]
for i,(arm,trace) in enumerate([('B',True),('P',True),('P',False),('B',False)],1):
 o=d/f'first-{i}';o.mkdir();e=o/'kernel.elf';shutil.copyfile(p/arm/'kernel.elf',e)
 cmd=['timeout','15s',str(q),'-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','stdio','-kernel',str(e)]
 if trace:cmd+=['-d','int','-D',str(o/'exceptions.log')]
 order.append(dict(ordinal=i,arm=arm,trace=trace,argv=cmd,elf_sha256=h(e),selector='aligned-saturated',before_pc=0x4020182c if arm=='P' else None,after_pc=0x4020194c if arm=='P' else None))
freeze=dict(tree='ddf078851dbf37517934b5255a64c89a28afad94',old_elf=h(old),baseline_load=image(old),qemu=h(q),version=subprocess.check_output([q,'--version'],text=True),arms=order,files={str(f.relative_to(r)):h(f) for f in p.rglob('*') if f.is_file()},build='JNOX_BOARD=virt JNOX_PROFILE=reservation JNOX_APP=aligned-saturated cargo +1.95.0 build --release --locked -j1; P only: JNOX_RESERVATION_STAGE=frame-window')
(r/'freeze.json').write_text(json.dumps(freeze,indent=2));print(h(r/'freeze.json'),flush=True)
