from pathlib import Path
import json,hashlib,subprocess,re,traceback
from collections import defaultdict,Counter
from ledger import analyze,oracle
from replay import decode,rows,NA
root=Path(__file__).resolve().parent
def compact(path,app,rr):
 b=defaultdict(list)
 for r in rr:b[r[0]].append(r)
 def one(t):assert len(b[t])==1,(t,b[t]);return b[t][0]
 boot,receipt=b[24]; assert boot[2]==NA and receipt[2]==0
 cfg=one(1); E=one(2)[4]; S=3125000;ms=62500
 assert cfg[4:]==[62500000,S,int(app.startswith('cbs')),int('saturated' in app)]
 desc,flags,authority,owner=receipt[4:]
 assert flags in (0,1,3,7,15,31) and desc==1+2*cfg[6]+cfg[7]
 assert [authority,owner]==([3,0] if flags&4 else [0,NA])
 for bit,t in [(1,25),(1,37),(2,26),(4,27),(8,28),(16,29),(16,30)]:assert len(b[t])==int(bool(flags&bit))
 model=oracle(app)
 for t,key in ((31,'alloc'),(32,'jobs')):
  assert [r[3] for r in b[t]]==[0,1] and all(r[4:]==model[0][key][r[3]] and r[1]==receipt[1] for r in b[t])
 nm=subprocess.check_output(['aarch64-linux-gnu-nm','-n',str(path/'kernel.elf')],text=True)
 for i,(f,g) in enumerate(zip(b[34],b[35],strict=True)):
  pc=int(re.search(r'^([0-9a-f]+) T reservation_worker_'+('ab'[i])+r'$',nm,re.M)[1],16)
  seed=[0xa19,0xb19][i]; stack=b[17][i];assert f[4]==stack[5]-832 and stack[5]-stack[4]==16384 and f[5:]==[pc,837,seed] and g[4:]==[0,0,seed,256 if "wake" in app else NA] and f[1]==g[1]==receipt[1]
 assert len(b[34])==2
 assert not any(r[2]==0 for t in (4,5,6,7,18) for r in b[t] if t not in (4,18) or (t==4 and r[5]==0) or (t==18 and r[3]==0))
 prep=one(22); mask=one(36); arm0=b[3][0]; ret0=b[12][0];assert arm0[4:]==[E,1,E,0] and boot[5]==E and mask[4]<=prep[4]<=prep[1]<=mask[1]<E
 result=dict(epoch=E,descriptor=desc,flags=flags,authority=authority,storage=one(33)[4:],bank_owner=owner,decoded_allocations=[r[4:] for r in b[31]],decoded_jobs=[r[4:] for r in b[32]],terminal_decode=receipt[1],boot_to_E=E-boot[4],boot_to_config=cfg[1]-boot[4],config_to_arm=arm0[1]-cfg[1],arm_to_idle_return=ret0[1]-arm0[1],idle_return_to_mask=mask[4]-ret0[1],prep_duration=prep[1]-prep[4],masked_through_ready=mask[1]-mask[4],prep_slack=E-mask[1])
 # Adapter joins measured first-slot data to common grant fields for the original oracle.
 # No synthetic ledger rows enter the portable raw or receive live timestamps.
 joins=[]
 if flags&1:
  irq=one(25);rd=one(37);assert irq[4:]==[30,5,E,E] and rd[4:]==[irq[1],rd[1],E,30] and E<=irq[1]<=rd[1]
  joins.append([4,irq[1],0,2,E,0,30,5]);result.update(irq_offset=irq[1]-E,source_reads=rd[1]-irq[1])
 if flags&2:
  pre=one(26);assert pre[4:]==[desc,0,E,0] and rd[1]<=pre[1]
  result.update(irq_to_precommit=pre[1]-irq[1],source_end_to_pre=pre[1]-rd[1])
 if flags&4:
  post=one(27);assert post[4:]==[3,1,1,0] and pre[1]<=E+ms and pre[1]<=post[1]
  result.update(commit_duration=post[1]-pre[1],commit_offset=post[1]-E)
 if flags&8:
  cut=one(28);assert cut[4:]==[E+S-ms,1,E+S-ms,1] and post[1]<=E+ms and post[1]<=cut[1]
  joins.append([3,cut[1],0,0,*cut[4:]]);result['commit_to_arm']=cut[1]-post[1]
 if flags&16:
  sel=one(29);order=one(30);assert sel[4:]==[b[34][0][4],b[34][0][5],0,0xa19] and order[4:]==[1,E,E+S,desc] and cut[1]<=sel[1]==order[1]
  joins.extend([[7,sel[1],0,0,E,E+S,*sel[4:6]],[18,sel[1],0,0,*sel[4:]]])
  result['arm_to_selection']=sel[1]-cut[1]
  returns=[r for r in b[12] if r[2:4]==[0,0]]
  if returns:
   r,=returns;assert r[6]==1 and r[4:6]==sel[4:6] and r[1]>=sel[1];result.update(commit_to_preeret=r[1]-post[1],selection_to_preeret=r[1]-sel[1])
 if b[10]:
  g=b[10][0];assert g[4]==returns[0][1];result.update(first_offset=g[5]-E,boot_to_first=g[5]-boot[4],return_to_marker=g[5]-g[4])
 ordered=sorted([r for r in rr[:-1] if r[0] in (1,2,3,4,5,6,7,8,9,10,11,12,17,18,19,21)]+joins,key=lambda r:r[1])+[rr[-1]]
 audit=analyze(path,app,ordered)
 for r in b[7]:
  s=r[2];assert r[4:6]==[E+s*S,E+(s+1)*S]
  for t in (5,6):assert [x[3] for x in b[t] if x[2]==s]==[0,1]
 violations=[]
 for g in audit['grants']:
  for field,ok in [('opening',0<=g['worker_offset']<=ms),('end',g['after_end']<=0),('upper',g['upper']<=S),('allocation',g['allocation_upper']<=g['allocation_limit']),('cutoff',0<=g['after_cutoff']<=ms if g['action']==1 else g['after_cutoff']<0)]:
   if not ok:violations.append([g['slot'],g['owner'],field])
 z=rr[-1]; result['measured_guard_operand']=z[6:8]
 result['terminal_format_to_result']=z[1]-receipt[1]
 result['storage_bytes_total']=sum(result['storage'])
 result['bank_bytes']=sum(result['storage'][:2])
 assert result['storage']==[128,128,264,184] and len(rr)<=1024
 result['live_journal_row_count']=sum(r[0] not in (12,24,25,26,27,28,29,30,31,32,33,34,35,36,37) for r in rr)
 if z[4:6]==[2,5]:
  assert z[2:4]==[0,2] and z[7]==E and z[6]>E+ms and not b[10] and not b[7] and not flags&16
  assert not any(r[3]<2 for r in b[12])
  if flags==15: assert z[6]>=cut[1]
  if flags==7: assert z[6]==post[1]
  if flags==3: assert z[6]==pre[1]
  result['stop_before_selection']=True
 if z[4:6]==[2,2]:
  last=b[10][-1];assert z[6:]==[last[5],E+last[2]*S] and z[6]-z[7]>ms
 for r in b[4]:
  s=r[2];kind=r[5];target=E+(s+kind)*S-(ms if kind else 0)
  assert kind in (0,1) and r[4]==target and r[1]>=target and r[6:]==[30,5]
 for r in b[11]:
  if r[4]==3: assert not any(k[2]>r[2] and k[3]==r[3] for k in b[7])
 if rr[-1][4]==0:
  assert [r[2] for r in ordered if r[0]==4 and r[5]==0]==list(range(len(model)+1))
  assert flags==31 and not violations and rr[-1][2]==len(model) and len(b[21])==2
  assert [(r[2],r[3]) for r in ordered if r[0]==7]==[(s,x['owner']) for s,x in enumerate(model)]
  assert [(g['slot'],g['owner']) for g in audit['grants']]==[(s,x['owner']) for s,x in enumerate(model) if x['owner']<2]
  for r in b[21]:
   i=r[3];last=next(x for x in reversed(b[8]) if x[3]==i);trap=next(x for x in b[11] if x[2:4]==last[2:4]);assert r[4:]==[last[5],last[7],trap[6],0]
 result.update(audit,violations=violations);return result
def main():
 results={};freeze=json.loads((root/'freeze.json').read_text())
 for p in freeze['plans']:
  v,label=p['version'],p['label'];path=root/'raw'/v/label;app=label.split('/')[0]
  if not path.exists():continue
  try:
   assert hashlib.sha256((path/'kernel.elf').read_bytes()).hexdigest()==p['sha256'] and json.loads((path/'meta.json').read_text())['status']==124 and (path/'exceptions.log').exists()==label.endswith('trace')
   rr=rows(path)
   if v=='new' and 'refused' not in app:r=compact(path,app,rr)
   else:r=analyze(path,app);r.update(decode(rr,'v2',app))
   if 'refused' not in app:
    b=defaultdict(list)
    for row in rr:b[row[0]].append(row)
    r['total_raw_rows']=len(rr)
    r['first_schedule_config_to_marker']=b[10][0][5]-b[1][0][1] if b[10] else None
    r['terminal_dump_rows']=sum(x[0]>=24 and x[1]==r.get('terminal_decode') for x in rr)
    r['residency_observations']=[dict(slot=q[2],owner=q[3],marker_to_vector=q[6]-q[5],pre_eret_to_marker=q[5]-q[4],upper=q[7]) for q in b[10]]
   r['period_service']={}
   for g in r['grants']:
    key=f"{'AB'[g['owner']]}-deadline-{oracle(app)[g['slot']]['alloc'][g['owner']][3]}"
    r['period_service'].setdefault(key,[]).append([g['slot'],g['upper'],g['allocation_upper']])
   results[v+'/'+label]=r
  except Exception:results[v+'/'+label]=dict(error=traceback.format_exc())
 (root/'observations.json').write_text(json.dumps(results,indent=2))
 print([(k,v.get('error',v.get('status'))) for k,v in results.items()])
if __name__=='__main__':main()



