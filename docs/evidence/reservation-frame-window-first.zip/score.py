from pathlib import Path
import sys,shutil,json,tempfile,hashlib
r=Path(__file__).resolve().parent
sys.path[:0]=[str(r/'src/tools'),str(r/'audit-tools')]
from reservation_frame_window import Launch,replay
from audit import compact
out={}
for p in sorted((r/'raw').glob('first-*')):
 l=Launch(**json.loads((p/'launch.json').read_bytes()))
 result,raw=replay((p/'uart').read_bytes(),(p/'kernel.elf').read_bytes(),l)
 with tempfile.TemporaryDirectory() as td:
  q=Path(td);(q/'uart').write_bytes(raw)
  for n in ('exceptions.log','kernel.elf'):
   if (p/n).exists():shutil.copyfile(p/n,q/n)
  rr=[list(map(int,line.split())) for line in raw.splitlines()[3:-1]]
  ledger=compact(q,'aligned-saturated',rr)
 out[p.name]={'reader':result,'ledger':ledger}
 print(p.name,result['terminal'],result['whole_ticks'],result['pieces_ticks'],result['headroom_ticks'],result['return_to_first_ticks'],len(ledger['grants']),flush=True)
(r/'results.json').write_text(json.dumps(out,indent=2))
