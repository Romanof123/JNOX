from pathlib import Path
import hashlib,json,shutil,sys,subprocess as s,time
r=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(r/'freeze.json')=='4266753ef7131bd7a65e0c01fe0d205b3bc723f3147b7548571d32efa2eeb3f4'
cfg=json.loads((r/'freeze.json').read_bytes())
assert h(Path('/usr/bin/qemu-system-aarch64'))==cfg['qemu']
(r/'raw').mkdir()
for item in cfg['arms']:
 cmd=item['argv'];e=Path(cmd[cmd.index('-kernel')+1]);p=e.parent
 assert h(e)==item['elf_sha256']
 start=time.time_ns()
 with (p/'uart').open('xb') as out,(p/'stderr').open('xb') as err:
  res=s.run(cmd,cwd=p,stdin=s.DEVNULL,stdout=out,stderr=err)
 (p/'attempt.json').write_text(json.dumps({'ordinal':item['ordinal'],'argv':cmd,'start_ns':start,'end_ns':time.time_ns(),'returncode':res.returncode,'freeze_sha256':h(r/'freeze.json')},indent=2))
 launch={k:v for k,v in item.items() if k!='argv'};launch['uart_sha256']=h(p/'uart')
 (p/'launch.json').write_text(json.dumps(launch,indent=2))
 shutil.copytree(p,r/'raw'/p.name)
 print(item['ordinal'],(p/'uart').read_text().splitlines()[-2:],flush=True)
