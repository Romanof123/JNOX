"""CHG-055 raw-record observer, independent of candidate tooling. Python 3.9+."""
import argparse
import hashlib
import json
import re
from pathlib import Path

VERSION = "jnox.independent.phase/1"
COSTS = "frequency evidence release_to_ready wake final_poll commit restore mask receiver control supervisor irq".split()
NEGATIVES = ("missing-second early-command expiry-arrival-tie command-plus20ms issue-minus1 "
             "issue-plus1 command-minus1 command-plus1 wide-publication wide-command "
             "missed-wake sender-overrun control-overrun duplicate-write invalid-input "
             "old-generation future-generation stale-permit gate-invalidation skipped-phase").split()


def matrix():
    records = []
    for mode in ("operational", "characterization"):
        for clock in ("default", "icount"):
            pairs = ["12"]
            if clock == "default":
                pairs = ["01", "10", "12", "21"] if mode == "operational" else ["12", "21"]
            for policy in ("rm", "dm"):
                for pair in pairs:
                    for ordinal, arm in enumerate(pair, 1):
                        key = f"{mode}-{policy}-{clock}-{pair}-{ordinal}"
                        records.append(dict(id=key, mode=mode, clock=clock, policy=policy,
                                            arm=int(arm), refusal_position=key.replace(mode, "operational")
                                            if mode == "characterization" else None))
    return records


def identity(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def parse_uart(raw):
    starts = list(re.finditer(r"^CONTROL RAW v1\s*$", raw, re.M))
    ends = list(re.finditer(r"^CONTROL END\s*$", raw, re.M))
    if len(starts) != 1:
        return [], False
    start = starts[0].end()
    closed = len(ends) == 1 and ends[0].start() >= start
    body = raw[start:ends[0].start() if closed else len(raw)]
    rows = []
    for line in body.splitlines():
        if line.strip():
            if not re.fullmatch(r"\s*\d+(?:\s+\d+){3}\s*", line):
                closed = False
                continue
            rows.append(tuple(map(int, line.split())))
    return rows, closed and bool(rows) and not any(x >= 2**64 for row in rows for x in row)


def relation(lo, hi, target):
    if lo > hi or target is None:
        return "unavailable"
    if lo == hi == target:
        return "exact"
    if hi < target:
        return "early"
    if lo > target:
        return "late"
    return "uncertain"


def gap(first, second, period):
    lo, hi = second[0] - first[1], second[1] - first[0]
    valid = all(i <= u for i, u in (first, second))
    return dict(bounds=[lo, hi], verdict=relation(lo, hi, period) if valid else "unavailable")


def mechanism(path):
    if path is None:
        return {"status": "unavailable"}
    raw = path.read_text(errors="replace")
    return dict(source=identity(path), elrs=re.findall(r"with ELR (0x[0-9a-fA-F]+)", raw),
                erets=re.findall(r"Exception return .*? PC (0x[0-9a-fA-F]+)", raw),
                irq_count=raw.count("[IRQ]"), svc_count=raw.count("[SVC]"),
                symbol_and_event_attribution="requires linked ELF and ordered correlation")


def actuator(events, writes):
    # Independent instrument export: [event, counter_tick, ordinal, bit].
    if any(not isinstance(e, list) or len(e) != 4 or e[0] not in
           ("initial", "write", "transition", "terminal", "loss") or
           any(type(n) is not int or n < 0 for n in e[1:]) or e[3] not in (0, 1)
           for e in events):
        return "malformed"
    if any(e[3] for e in events if e[0] != "loss"):
        return "observed-on"
    if not writes or len(events) != writes + 2 or any(e[0] == "loss" for e in events):
        return "insufficient-coverage"
    expected = ["initial"] + ["write"] * writes + ["terminal"]
    return "off-through-observed-writes" if (
        [e[0] for e in events] == expected and
        [e[2] for e in events] == [0] + list(range(1, writes+1)) + [writes] and
        all(a[1] <= b[1] for a, b in zip(events, events[1:]))
    ) else "insufficient-coverage"


def scheduler(rows, hz):
    buckets = {0: 0, 1: 0}
    service, elapsed, phase, irq, spacing, sleeps = [], [], [], [], [], []
    previous = sleeping = None
    def check(value, us):
        if not hz:
            return "unavailable"
        return "within" if 0 <= value * 1_000_000 <= hz * us else "outside"
    for tag, t, a, b in rows:
        if tag == 6 and a in buckets:
            buckets[a] += b
        elif tag in (8, 95) and a in buckets:
            total = buckets[a]
            service.append(dict(worker=a,tick=t,partial=tag == 95,charged=total,
                                recorded=b,reconciled=(total == b),
                                measured=check(total, 750 if a else 250)))
            buckets[a] = 0
        elif tag == 9 and a in buckets:
            elapsed.append(dict(worker=a,release=b,response=t-b,
                                measured=check(t-b,10000 if a else 5000)))
        elif tag == 10:
            phase.append(dict(index=a,late=t-b,measured=check(t-b,1000)))
        elif tag == 3:
            irq.append(dict(index=b,late=t-a,measured=check(t-a,500)))
        elif tag == 21:
            if previous is not None:
                spacing.append(dict(index=a,delta=t-previous,measured=check(t-previous,5000)))
            previous=t
        elif tag == 69:
            sleeping=t
        elif tag == 68:
            sleeps.append({"entry":sleeping,"wake":t,"requested":a,"frame":b})
            sleeping=None
    return dict(service=service,response=elapsed,phase=phase,irq=irq,spacing=spacing,
                sleeps=sleeps,unfinished_sleep= sleeping, unclosed_slice_totals=buckets,
                scope="reported intervals; omitted mask tails, final return and system interference need attribution")

def score(pos, uart, device_path, mechanism_path):
    raw = uart.read_text(errors="replace")
    rows, closed = parse_uart(raw)
    def r(tag):
        return [x[1:] for x in rows if x[0] == tag]
    def only(tag):
        values = r(tag)
        return values[0] if len(values) == 1 else None
    def selected(tag, index, val):
        return [x for x in r(tag) if x[index] == val]

    header, arm, admission, mode = (only(i) for i in (32, 64, 65, 83))
    case_hash = 0
    for c in b"healthy":
        case_hash = (31 * case_hash + c) % 2**64
    expected = bool(header and header[1:] == (int(pos["policy"] == "dm"), case_hash))
    char = pos["mode"] == "characterization"
    if pos["arm"]:
        expected = bool(expected and arm and arm[1] == pos["arm"] and mode and mode[1] == int(char))
    else:
        expected = expected and not any(r(i) for i in (64, 65, 83))
    freq = arm[2] if arm else (only(1) or [0, 0])[1]
    period = freq // 100 if freq > 0 and freq % 100 == 0 else None
    offset = freq * 15 // 1000 if freq > 0 and freq * 15 % 1000 == 0 else None
    first, second = selected(74, 2, 1), selected(74, 2, 2)
    pubs = []
    for i, u, seq in r(74):
        issues = selected(11, 1, seq)
        reads = selected(78, 2, seq)
        accepts = selected(12, 1, seq)
        pubs.append(dict(sequence=seq, bracket=[i, u], issues=issues, acquires=reads,
                         accepts=accepts, matching_visible_record=bool(
                             i <= u and len(selected(74, 2, seq)) == 1 and
                             issues == [(i, seq, 1)] and len(accepts) == 1 and
                             accepts[0][2] == i and any(u <= lo <= hi <= accepts[0][0]
                                                        for lo, hi, _ in reads))))
    anchored = bool(len(first) == 1 and first[0][0] == first[0][1] and
                    any(p["sequence"] == 1 and p["matching_visible_record"] for p in pubs))
    base = first[0][0] if anchored else None
    issue1, issue2 = selected(11, 1, 1), selected(11, 1, 2)
    issue_delta = (issue2[0][0] - issue1[0][0] if len(issue1) == len(issue2) == 1
                   and issue1[0][2] == issue2[0][2] == 1 else None)
    cmd = only(76)
    target = base + offset if base is not None and offset is not None else None
    launch = any(r(i) for i in (1, 2, 3, 4, 5, 6, 8, 10, 11, 21, 74, 93))
    terminal = only(18)
    boot = only(19)
    refused = bool(pos["arm"] and not char and expected and closed and not launch and
                   admission and admission[1] == 0 and 0 < admission[2] < 4096 and
                   boot and boot[1] == 0 and terminal and terminal[1:] == (0, 0))
    first_latch = next((row for row in rows if row[0] == 13), None)
    phases = [x[1] for x in r(10)]
    horizon = phases == list(range(26)) and [x[1] for x in r(21)] == phases
    stop = only(90)
    reject = next(iter(r(66)), None)
    counts_ok = bool(stop and stop[1] <= 7 and sum(stop[1:]) == 7 and all(p["sequence"] <= stop[1] for p in pubs))
    fin = "incomplete"
    if closed and expected and terminal:
        if refused:
            fin = "refused-before-workers"
        elif horizon and not reject and (not pos["arm"] or counts_ok and stop[1] == 7):
            fin = "observed-full-phase-horizon"
        elif (reject and counts_ok and only(85) and only(86) and (1 <= reject[1] <= 16 or 100 <= reject[1] <= 110) and not any(x[0] in (71,74,76,84) for x in rows[next(i for i,x in enumerate(rows) if x[0]==66)+1:])):
            fin = "observed-early-stop"
    enddev = only(89)
    writes = enddev[1] if enddev else None
    triplets = [row for row in rows if row[0] in (80, 81, 82)]
    good = bool(writes and len(triplets) == writes * 3 and
                all(row[0] == (80, 81, 82)[n % 3] and row[2] == 1+n//3
                    and row[3] in (0, 1) and (n % 3 == 0 or row[3] == 0)
                    for n, row in enumerate(triplets)) and
                all(a[1] <= b[1] for a, b in zip(triplets, triplets[1:])))
    external = {"status": "unavailable"}
    if device_path:
        data = json.loads(device_path.read_text())
        bound = (data.get("schema") == "jnox.device-events/1" and data.get("position") == pos["id"]
                 and data.get("uart_sha256") == identity(uart)["sha256"] and data.get("events") is not None)
        external = dict(source=identity(device_path), status=actuator(data["events"], writes)
                        if bound else "unbound")
    containment = re.findall(r"^CONTROL CONTAINMENT FAIL[^\n]*", raw, re.M)
    on = any(x[2] for x in r(81)+r(82)+r(89)) or any(x[1] for x in r(18)+r(19))
    scope = "unavailable"
    if char:
        scope = "insufficient-coverage"
        if containment or on or external["status"] == "observed-on":
            scope = "containment-failure"
        elif closed and expected and good and boot and not boot[1] and terminal and not terminal[1] and external["status"] == "off-through-observed-writes":
            scope = "observed-off-within-instrumented-path"
    command_facts = {}
    if cmd:
        lower, upper, declared = cmd
        command_facts["declared_target_matches"] = target is not None and declared == target
        command_facts["generation_one_poll"] = len(r(77)) == 1 and r(77)[0][1] == 1 and r(77)[0][0] <= lower
        command_facts["independent_acquire_after_commit"] = len(r(79)) == 1 and upper <= r(79)[0][0] <= r(79)[0][1] and r(79)[0][2] == 1
        command_facts["two_distinct_accepted_before_commit"] = all(
            len(matches) == 1 and matches[0]["matching_visible_record"] and
            matches[0]["accepts"][0][0] <= lower for matches in
            ([p for p in pubs if p["sequence"] == seq] for seq in (1,2)))
        command_facts["fresh_through_controller_read"] = bool(
            period and base is not None and len(r(79)) == 1 and upper <= r(79)[0][0]
            and r(79)[0][1] < base + 2*period)
    latch_consistent = bool(first_latch and len(r(13)) == len(r(28)) == 1 and
                            r(28)[0][0] <= r(28)[0][1] == first_latch[1]
                            and r(28)[0][2] == first_latch[2])
    application_case = dict(name="healthy",identity_matches=expected,
        completion=fin,latch=first_latch,latch_bracket_consistent=latch_consistent,
        first_latch_absence_through_horizon=bool(fin=="observed-full-phase-horizon"
        and not r(13) and not r(28) and terminal[2]==0),
        truncated_latch_absence_inconclusive=not first_latch and not horizon,
        unattempted_sequences=list(range(stop[1]+1,8)) if counts_ok else None,
        issued_indices=[x[1] for x in r(11)],accepted_indices=[x[1] for x in r(12)])
    return dict(schema=VERSION, position=pos, source=identity(uart), complete_dump=closed, application_case=application_case,
                expected_healthy_policy_arm_mode=expected, disposition=fin, frequency=freq,
                period_ticks=period, admission_record=admission, missing_costs=[
                    name for k, name in enumerate(COSTS) if admission and admission[2] & (1<<k)],
                positive_phase_refusal_required=bool(pos["arm"] and not char),
                observed_refusal=refused, first_latch=first_latch, latch_brackets=r(28),
                first_rejection=reject, terminal=terminal, horizon=stop, phase_indices=phases,
                first_issue_gap=issue_delta, issue_verdict=relation(issue_delta,issue_delta,period)
                if issue_delta is not None else "unavailable", publications=pubs, first_anchor=base,
                first_publication_gap=gap(first[0][:2],second[0][:2],period)
                if len(first)==len(second)==1 else None, command=dict(facts=command_facts,commit=r(76),poll=r(77),
                    controller_read=r(79), expected_target=target, ingress_timing=relation(cmd[0],cmd[1],target)
                    if cmd else "unavailable"), write_path_triplets_complete=good,
                device=external, containment=scope, containment_details=containment,
                mechanism=mechanism(mechanism_path), scheduler=scheduler(rows,freq), raw_rows=rows, operational_positive=False,
                release_authorization="unavailable", negative_cases={key:"unavailable" for key in NEGATIVES})


def checks():
    assert gap((20,21),(30,31),10)["verdict"] == "uncertain"
    assert gap((20,20),(30,30),None)["verdict"] == "unavailable"
    assert relation(14,15,15) == "uncertain"
    assert actuator([["initial",0,0,0],["terminal",2,1,0]],1) == "insufficient-coverage"
    assert actuator([["initial",0,0,0],["transition",1,0,1],["terminal",2,0,0]],0) == "observed-on"
    assert not parse_uart("CONTROL RAW v1\n18 10 0 0\n")[1]
    return {"scope":"synthetic observer checks only", "assertions":6}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="action", required=True)
    sub.add_parser("matrix")
    sub.add_parser("self-check")
    p = sub.add_parser("observe")
    p.add_argument("position", choices=[p["id"] for p in matrix()])
    p.add_argument("uart",type=Path)
    p.add_argument("--mechanism",type=Path)
    p.add_argument("--device",type=Path)
    opt = parser.parse_args()
    if opt.action == "matrix":
        result = {"schema":VERSION, "positions":matrix()}
    elif opt.action == "self-check":
        result = checks()
    else:
        pos = next(p for p in matrix() if p["id"] == opt.position)
        result = score(pos,opt.uart,opt.device,opt.mechanism)
    print(json.dumps(result,indent=2))



