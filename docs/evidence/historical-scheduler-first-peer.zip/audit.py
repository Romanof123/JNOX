from pathlib import Path
import base64,hashlib,json,subprocess as sp,zipfile,sys,re
d=Path(__file__).resolve().parent;s=d.parent/'j235src'; e=d/'extract'
def git(*args):return sp.check_output(['git','-C',str(s),*args])
def sha(x):return hashlib.sha256(x).hexdigest()
def run(name,args,cwd):
 p=sp.run(args,cwd=cwd,stdout=sp.PIPE,stderr=sp.STDOUT)
 (d/name).write_bytes(p.stdout)
 print(name,p.returncode);assert p.returncode==0
a=git('show','9b7653dd8d4c6a064ef4d52c1ae67b1e98850ae8:docs/evidence/evd-032-regressions.json')
b=git('show','f0c47f1d76da6040aec6cd711eaa09ea64e04525:docs/evidence/evd-047-raw.zip')
import io
z=zipfile.ZipFile(io.BytesIO(b));p=json.loads(a)
print('Archived records',sha(a),sha(b));print('79 image comparison',p['proportional_control'])
for n in ('uart','exceptions.log'):
 row=p['first_boot_files']['virt-proportional/capture/run-1/'+n];x=base64.b64decode(row['base64']);assert x==(e/('79-'+n)).read_bytes() and sha(x)==row['sha256']
for src,dst in [('uart','uart'),('exceptions.log','exceptions.log'),('execution.json','execution.json'),('disassembly','disassembly.txt')]:
 assert z.read('prior-failure/'+src)==(e/('110-'+dst)).read_bytes()
for num,path in [('79','combined-gates/virt-proportional'),('110','partition-builds/partition-bench'),('110','partition-parent-builds/partition-bench')]:
 x=(e/(num+'.elf')).read_bytes();assert x==(d.parent/'.jnox-work/next-fixed'/path/'kernel.elf').read_bytes();print(path,sha(x))
print(git('cat-file','-t',p['tree']),git('rev-parse','a57a0cb^','6fccd8a^{tree}'))
for f in ['docs/scheduling-release-cases.md','docs/scheduling-release-cases.en.md']:
 print(f,[l[:12] for l in git('diff','HEAD^','HEAD','--',f).decode().splitlines() if l.startswith('+|')])
for n in ('79','110'):
 x=(e/(n+'-disassembly.txt')).read_text();print('\n'.join(l for l in x.splitlines() if re.search(r'^\s*(4020237c|40201930|40201944|40201790|40201850|40201858|40201964):',l)))
run('verify.txt',[sys.executable,'verify.py'],e)
run('graph.txt',[sys.executable,'tools/requirement_graph.py'],s)
run('matrix.json',[sys.executable,'tools/scheduling_evidence.py'],s)
run('tests.txt',[sys.executable,'-B','-m','unittest','test_requirement_graph','test_scheduling_evidence'],s/'tools')


