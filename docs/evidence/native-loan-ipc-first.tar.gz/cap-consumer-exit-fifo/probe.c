#include <jnox/loan.h>
#include <time.h>

volatile long private_results[64];
volatile unsigned long recorded;
volatile unsigned long grant_handles[4], grant_vas[4];

static int check(long actual, long expected) {
    if (recorded >= 64) return 0;
    private_results[recorded++] = actual;
    return actual == expected;
}
static int delay(long ms) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) return 0;
    t.tv_nsec += ms * 1000000;
    if (t.tv_nsec >= 1000000000) { t.tv_sec++; t.tv_nsec -= 1000000000; }
    return clock_nanosleep(CLOCK_MONOTONIC,TIMER_ABSTIME,&t,0)==0;
}
static unsigned char pattern(unsigned i) { return (unsigned char)(i*7+13); }
static int writer(int scenario) {
    jnox_writer_loan w=jnox_loan_acquire();
    if(!check(w.status,0)) return 100;
    grant_handles[0]=w.handle; grant_vas[0]=(unsigned long)w.page;
    for (unsigned i=0;i<4096;i++) w.page[i]=0xad;
    if(!check(jnox_loan_release(w.handle),0)) return 101;
    jnox_writer_loan a=jnox_loan_acquire(), b=jnox_loan_acquire(), c=jnox_loan_acquire();
    if(!check(a.status,0)||!check(b.status,0)||!check(c.status,0)) return 102;
    grant_handles[1]=a.handle; grant_handles[2]=b.handle; grant_handles[3]=c.handle;
    grant_vas[1]=(unsigned long)a.page; grant_vas[2]=(unsigned long)b.page; grant_vas[3]=(unsigned long)c.page;
    if(!check(jnox_loan_acquire().status,-11)||!check(jnox_loan_receive().status,-13)) return 103;
    if(!check(jnox_loan_release(w.handle),-116)||!check(jnox_loan_publish(w.handle,1),-116)) return 104;
    for(unsigned i=0;i<4096;i++) {
        if(a.page[i]||b.page[i]||c.page[i]) return 105;
        a.page[i]=pattern(i); b.page[i]=0x91; c.page[i]=0xc7;
    }
    if(!check(jnox_loan_publish(a.handle,4097),-90)) return 106;
    for(unsigned i=0;i<4096;i++) if(a.page[i]!=pattern(i)) return 107;
    if(!check(jnox_loan_publish(a.handle,4096),0)||!check(jnox_loan_publish(b.handle,0),0)||
       !check(jnox_loan_publish(c.handle,5),-11)) return 108;
    for(unsigned i=0;i<4096;i++) if(c.page[i]!=0xc7) return 109;
    if(scenario==2) return 81;
    if(!delay(150)) return 110;
    if(scenario==0) {
        if(!check(jnox_loan_acquire().status,-32)||!check(jnox_loan_publish(c.handle,1),-32)||
           !check(jnox_loan_release(c.handle),-32)) return 111;
    } else {
        if(!check(jnox_loan_release(a.handle),-13)) return 112;
    }
    return 81;
}
static int reader(int scenario) {
    if(scenario==2) {
        if(!check(jnox_loan_receive().status,-11)||!delay(200)) return 114;
    }
    if(!check(jnox_loan_acquire().status,-13)) return 115;
    jnox_reader_loan a=jnox_loan_receive();
    if(!check(a.status,0)||!check(a.length,4096)) return 116;
    grant_handles[0]=a.handle; grant_vas[0]=(unsigned long)a.page;
    unsigned long sum=0;
    for(unsigned i=0;i<4096;i++) { if(a.page[i]!=pattern(i)) return 117; sum+=a.page[i]; }
    if(!check(sum,522240)) return 118;
    if(scenario==0) return 82;
    if(scenario==1 && !delay(350)) return 119;
    for(unsigned i=0;i<4096;i++) if(a.page[i]!=pattern(i)) return 120;
    jnox_reader_loan b=jnox_loan_receive();
    if(!check(b.status,0)||!check(b.length,0)) return 121;
    grant_handles[1]=b.handle; grant_vas[1]=(unsigned long)b.page;
    for(unsigned i=0;i<4096;i++) if(b.page[i]) return 122;
    if(!check(jnox_loan_receive().status,-32)||!check(jnox_loan_release(a.handle),0)||
       !check(jnox_loan_release(a.handle),-116)||!check(jnox_loan_release(b.handle),0)) return 123;
    return 82;
}
int main(int argc,char **argv) {
    if(argc!=2) return 124;
    switch(argv[1][0]) {
    case 'W': return writer(argv[1][1]-'0');
    case 'R': return reader(argv[1][1]-'0');
    case 'T':
        if(!check(jnox_loan_acquire().status,-13)||!check(jnox_loan_publish(8,1),-13)||
           !check(jnox_loan_receive().status,-13)||!check(jnox_loan_release(8),-13)) return 125;
        return 83;
    case 'D':
        if(!check(jnox_loan_acquire().status,-38)||!check(jnox_loan_publish(0,0),-38)||
           !check(jnox_loan_receive().status,-38)||!check(jnox_loan_release(0),-38)) return 126;
        return 84;
    default: return 127;
    }
}
