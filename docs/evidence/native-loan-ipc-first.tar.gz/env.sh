source "$HOME/.cargo/env"
export PYTHONPATH="${PYTHONPATH:-}:$HOME/jnox-169-first-e203caa/deps" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true
d=${RAW:-$HOME/iv374-first-66d988a-raw}
src=${SRC:-$HOME/iv374-first-66d988a-src}
export CARGO_TARGET_DIR="$d/app-target"
rev=66d988a0772fac3fd305b83bb123c5d966ea5f23
cd "$src"
run() {
 local tag=$1 rc=0
 shift
 printf '%q ' "$@" >> "$d/commands.sh"
 echo >> "$d/commands.sh"
 "$@" > "$d/$tag.log" 2>&1 || rc=$?
 echo "$tag $rc" | tee -a "$d/status"
 if [ "$rc" -ne 0 ]; then tail -15 "$d/$tag.log"; fi
 return "$rc"
}
guest() {
 local tag=$1 pol=$2 expect=$3 first=$4 firstsrc=$5 second=$6
 shift 6
 local args=()
 if [ "$pol" = rr ]; then args+=(--quantum-ticks 625000); fi
 run "pkg-$tag" python3 tools/build_native_el0.py --out "$d/pkg-$tag" --elf "$first" --peer-elf "$second" --priority 7 --peer-priority 1 --policy "$pol" "${args[@]}" "$@" || return 0
 run "cap-$tag" python3 tools/native_el0_capture.py "$d/cap-$tag" "$d/pkg-$tag/kernel.elf" "$first" "$firstsrc" "$rev" --plain --manifest "$d/pkg-$tag/manifest.json" --expect-exit "$expect" --timeout 16 || :
 if [ -f "$d/cap-$tag/uart.bin" ]; then awk '/EXIT PID|DROPPED|FAULT|NATIVE LOAN STATE/{print}' "$d/cap-$tag/uart.bin"; fi
}
