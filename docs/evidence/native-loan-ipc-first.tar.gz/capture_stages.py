"""Read-only physical snapshots of public loan ownership transitions in an ordinary controlled fixture."""
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
from ordinary_amc_capture import FLAGS,save,sha
from qemu_capture import request

pkg, out, app = map(Path, sys.argv[1:])
out.mkdir()
def nm(path):
    rows = subprocess.check_output(["aarch64-linux-gnu-nm","-nS",path],text=True).splitlines()
    return {fields[-1]: (int(fields[0],16), int(fields[1],16) if len(fields)==4 else 0)
            for row in rows if len(fields:=row.split()) in (3,4)}
ks, us = nm(pkg/"kernel.elf"), nm(app)
base,limit=ks["_start"][0],ks["__stack_top"][0]
spaces,size=next(v for k,v in ks.items() if "6SPACES" in k)
va=us["checkpoint"][0]
m=json.loads((pkg/"manifest.json").read_text())
assert len(m["slots"])==2 and sha(pkg/"kernel.elf")==m["kernel_elf_sha256"] and sha(app)==m["slots"][0]["elf_sha256"]
qemu=shutil.which("qemu-system-aarch64")
command=[qemu,*FLAGS,"-qmp","stdio","-serial","file:"+str(out/"uart.bin"),"-kernel",str(pkg/"kernel.elf")]
save(out/"launch.json",dict(argv=command,revision=m["commit"],argument_package=m,ram_base=base,ram_bytes=limit-base,qemu_sha256=sha(Path(qemu))))
with (out/"stderr").open("xb") as err:
    proc=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,bufsize=0)
    class Pipe:
        write=proc.stdin.write
        readline=proc.stdout.readline
    pipe=Pipe()
    def word(pa):
        reply=request(pipe,"human-monitor-command",**{"command-line":f"xp /1gx 0x{pa:x}"})
        return int(re.search(r":\s+0x([a-fA-F0-9]+)",reply)[1],16)
    def checkpoint(pid):
        pa=spaces+pid*size//2
        for shift in [30,21,12]:
            pte=word(pa+((va>>shift)&511)*8)
            if pte & 3 != 3: return None
            pa=pte & 0xfffffffff000
        return word(pa+(va&4095))
    progress=[]
    try:
        assert "QMP" in json.loads(proc.stdout.readline())
        request(pipe,"qmp_capabilities")
        for pid,stage in [(0,1),(0,2),(1,3),(1,4),(0,5)]:
            until=time.monotonic()+8
            while time.monotonic()<until and checkpoint(pid)!=stage: time.sleep(.01)
            request(pipe,"stop")
            state=request(pipe,"query-status")
            seen=checkpoint(pid)
            assert state["running"] is False and seen==stage,(stage,seen,state)
            request(pipe,"pmemsave",val=base,size=limit-base,filename=str(out/f"ram-{stage}.bin"))
            progress.append([pid,stage,state])
            request(pipe,"cont")
        until=time.monotonic()+8
        while time.monotonic()<until:
            uart=(out/"uart.bin").read_text()
            if "NATIVE EL0 EXIT PID 1 86\n" in uart and "NATIVE EL0 EXIT PID 0 85\n" in uart: break
            time.sleep(.01)
        else: raise RuntimeError("missing terminal exits")
        request(pipe,"stop")
        request(pipe,"pmemsave",val=base,size=limit-base,filename=str(out/"ram.bin"))
        save(out/"progress.json",progress)
    finally:
        proc.terminate()
        proc.wait(timeout=3)
save(out/"session.json",dict(marker="EXIT 85",hashes={f.name:sha(f) for f in out.iterdir() if f.is_file()}))
