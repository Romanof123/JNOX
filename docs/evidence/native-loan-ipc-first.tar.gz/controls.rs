#[cfg(test)]
mod independent_verifier {
    use super::*;
    fn ok(_: MapOp) -> Result<(), i32> { Ok(()) }
    fn no(_: MapOp) -> Result<(), i32> { panic!("refusal performed mapping work") }
    #[test]
    fn several_counter_origins_through_boundaries() {
        for origin in [0,1,u64::MAX-2,u64::MAX-1,u64::MAX] {
            let mut c=LoanIpc::new(2,0);
            c.ring.head.store(origin, Ordering::Relaxed);
            c.ring.tail.store(origin, Ordering::Relaxed);
            for round in 0..4 {
                let a=c.acquire(2,ok).unwrap();
                let b=c.acquire(2,ok).unwrap();
                let d=c.acquire(2,ok).unwrap();
                assert_eq!(c.acquire(2,no),Err(-11));
                c.publish(2,a.handle,0,ok).unwrap();
                c.publish(2,b.handle,4096,ok).unwrap();
                assert_eq!(c.occupancy(),2);
                let full=(c.head(),c.tail(),c.page(d.slot));
                for (len,code) in [(u64::MAX,-90),(4097,-90),(17,-11)] {
                    assert_eq!(c.publish(2,d.handle,len,no),Err(code));
                    assert_eq!(full,(c.head(),c.tail(),c.page(d.slot)));
                }
                assert_eq!(c.receive(0,ok).unwrap().handle,a.handle);
                c.publish(2,d.handle,17,ok).unwrap();
                for (g,len) in [(b,4096),(d,17)] {
                    let r=c.receive(0,ok).unwrap();
                    assert_eq!((r.handle,r.len),(g.handle,len));
                }
                for g in [a,b,d] { c.release(0,g.handle,ok).unwrap(); }
                let wanted=origin.wrapping_add(3*(round+1));
                assert_eq!((c.head(),c.tail(),c.occupancy(),c.high_water()),(wanted,wanted,0,2));
            }
            println!("start={origin} final_head={} final_tail={} max={}",c.head(),c.tail(),c.high_water());
        }
    }
    #[test]
    fn last_generation_latches_exhaustion_with_previous_handles_dead() {
        let mut c=LoanIpc::new(1,2);
        let old=c.acquire(1,ok).unwrap();
        c.release(1,old.handle,ok).unwrap();
        c.generation=MAX_GENERATION-1;
        let last=c.acquire(1,ok).unwrap();
        assert_eq!(last.handle,(MAX_GENERATION<<2)|last.slot as u64);
        assert_eq!(c.release(1,old.handle,no),Err(-116));
        assert_eq!(c.publish(1,old.handle,1,no),Err(-116));
        c.publish(1,last.handle,1,ok).unwrap();
        assert_eq!(c.receive(2,ok).unwrap().handle,last.handle);
        c.release(2,last.handle,ok).unwrap();
        for _ in 0..3 {assert_eq!(c.acquire(1,no),Err(-75));}
        assert_eq!(c.release(2,last.handle,no),Err(-116));
        println!("last={} generation={} retries=3 status=-75",last.handle,c.generation);
    }
}
