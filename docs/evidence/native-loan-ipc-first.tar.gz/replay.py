"""Replay eleven frozen guest images into a new directory under Linux."""
import argparse, json, os, subprocess, sys
from pathlib import Path
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument("packet",type=Path)
ap.add_argument("new_output",type=Path)
args=ap.parse_args()
root=args.packet.resolve()
out=args.new_output.resolve()
out.mkdir()
env=dict(os.environ,PYTHONPATH=str(root/"replay-tools")+os.pathsep+os.environ.get("PYTHONPATH",""))
for orig in sorted(root.glob("pkg-*")):
    if not orig.is_dir(): continue
    case=orig.name[4:]
    pkg=out/orig.name
    pkg.symlink_to(orig,target_is_directory=True)
    manifest=json.loads((pkg/"manifest.json").read_text())
    app=pkg/manifest["slots"][0]["elf"]
    cap=out/("cap-"+case)
    if case.startswith("stages-"):
        command=[sys.executable,root/"capture_stages.py",pkg,cap,app]
    else:
        expect=73 if case.startswith("official-") else 82 if case.startswith("empty-") else 84 if case=="disabled" else 81
        command=[sys.executable,root/"replay-tools/native_el0_capture.py",cap,pkg/"kernel.elf",app,
                 root/("cap-"+case)/"probe.c",manifest["commit"],"--plain","--manifest",pkg/"manifest.json","--expect-exit",str(expect),"--timeout","16"]
    subprocess.run(command,env=env,check=True)
with (out/"results.json").open("x") as f:
    subprocess.run([sys.executable,root/"verify.py",out],check=True,stdout=f)
