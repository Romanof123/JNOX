#!/usr/bin/env bash
set -eu -o pipefail
prep=$(cd "$(dirname "$0")" && pwd)
d=${RAW:-$HOME/iv374-first-66d988a-raw}
src=${SRC:-$HOME/iv374-first-66d988a-src}
rev=66d988a0772fac3fd305b83bb123c5d966ea5f23
obj=${OBJECTS:-/mnt/d/codex/j-nox/.git/objects}
mkdir "$d" "$src"
git -C "$src" init -q
echo "$obj" > "$src/.git/objects/info/alternates"
cd "$src"
git sparse-checkout init --cone
git sparse-checkout set arch boards examples kernel sdk tools trace verification
git -c advice.detachedHead=false checkout -q --detach "$rev"
git rev-parse HEAD 'HEAD^{tree}' > "$d/revision.txt"
test "$(git rev-parse 'HEAD^{tree}')" = e921bdda13ce358b7adb6386f4a1e0fff4b56e72
test -z "$(git status --porcelain --untracked-files=no)"
cp "$prep"/{run.sh,env.sh,freeze.txt,issue-24.json,issue-374.json,original-ipc-005.txt} "$d/"
git show df5260d7048f04dd38ae9499b07b10578826d05b:docs/native-loan-ipc.en-ko.md > "$d/contract.md"
(cd "$d" && sha256sum freeze.txt issue-*.json original-ipc-005.txt contract.md env.sh run.sh) > "$d/freeze.sha256"
source "$d/env.sh"
run cc-writer sh sdk/native-aarch64/build.sh examples/native-loan/producer.c "$d/writer.elf"
run rs-reader sh sdk/native-aarch64/build-rust.sh examples/native-loan/reader/Cargo.toml "$d/reader.elf"
for pol in fifo rr; do
 guest "official-$pol" "$pol" 73 "$d/writer.elf" examples/native-loan/producer.c "$d/reader.elf" --loan-route 0:1
done
run host-build rustc --edition 2021 --test kernel/src/loan_ipc.rs -o "$d/host"
run host "$d/host" --nocapture
