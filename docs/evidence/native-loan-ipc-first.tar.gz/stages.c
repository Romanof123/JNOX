#include <jnox/loan.h>
#include <time.h>
volatile unsigned long checkpoint, handles[2], vas[2];
static int wait_ms(long ms) {
    struct timespec t;
    if(clock_gettime(CLOCK_MONOTONIC,&t)) return 0;
    t.tv_nsec += ms*1000000;
    t.tv_sec += t.tv_nsec/1000000000;
    t.tv_nsec %= 1000000000;
    return clock_nanosleep(CLOCK_MONOTONIC,TIMER_ABSTIME,&t,0)==0;
}
static unsigned char first(unsigned i) { return (unsigned char)(13+7*i); }
int main(int argc, char **argv) {
    if(argc!=2) return 101;
    if(argv[1][0]=='w') {
        jnox_writer_loan a=jnox_loan_acquire();
        if(a.status) return 102;
        handles[0]=a.handle; vas[0]=(unsigned long)a.page;
        for(unsigned i=0;i<4096;i++) {
            if(a.page[i]) return 103;
            a.page[i]=first(i);
        }
        checkpoint=1;
        if(!wait_ms(450) || jnox_loan_publish(a.handle,113)) return 104;
        checkpoint=2;
        if(!wait_ms(1050)) return 105;
        jnox_writer_loan b=jnox_loan_acquire();
        if(b.status || b.handle==a.handle || b.page!=a.page) return 106;
        handles[1]=b.handle; vas[1]=(unsigned long)b.page;
        for(unsigned i=0;i<4096;i++) if(b.page[i]) return 107;
        checkpoint=5;
        if(!wait_ms(200) || jnox_loan_release(b.handle)) return 108;
        return 85;
    }
    if(!wait_ms(800)) return 109;
    jnox_reader_loan r=jnox_loan_receive();
    if(r.status||r.length!=113) return 110;
    handles[0]=r.handle; vas[0]=(unsigned long)r.page;
    for(unsigned i=0;i<4096;i++) if(r.page[i]!=(i<113?first(i):0)) return 111;
    checkpoint=3;
    if(!wait_ms(350) || jnox_loan_release(r.handle)) return 112;
    checkpoint=4;
    if(!wait_ms(1050) || jnox_loan_receive().status!=-32) return 113;
    return 86;
}
