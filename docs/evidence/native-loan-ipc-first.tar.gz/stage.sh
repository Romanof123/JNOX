#!/usr/bin/env bash
set -eu -o pipefail
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
cp "$prep"/{stages.c,stage.sh,capture_stages.py} "$d/"
run cc-stage sh sdk/native-aarch64/build.sh "$d/stages.c" "$d/stages.elf"
for pol in fifo rr; do
  args=()
  if [ "$pol" = rr ]; then args+=(--quantum-ticks 625000); fi
  run "pkg-stages-$pol" python3 tools/build_native_el0.py --out "$d/pkg-stages-$pol" --elf "$d/stages.elf" --peer-elf "$d/stages.elf" --priority 7 --peer-priority 1 --policy "$pol" "${args[@]}" --loan-route 0:1 --arg w --peer-arg r
  PYTHONPATH="$src/tools:$PYTHONPATH" run "cap-stages-$pol" python3 "$d/capture_stages.py" "$d/pkg-stages-$pol" "$d/cap-stages-$pol" "$d/stages.elf"
done
