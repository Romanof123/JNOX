#!/usr/bin/env bash
set -eu -o pipefail
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
cp "$prep"/{controls.rs,controls.sh} "$d/"
cp kernel/src/loan_ipc.rs "$d/"
cat kernel/src/loan_ipc.rs "$d/controls.rs" > "$d/host-combined.rs"
run controls-build rustc --edition 2021 --test "$d/host-combined.rs" -o "$d/controls"
run controls "$d/controls" independent_verifier --nocapture
aarch64-linux-gnu-objdump -dC "$d/pkg-official-fifo/kernel.elf" > "$d/kernel.fifo.dis"
aarch64-linux-gnu-objdump -dC "$d/pkg-official-rr/kernel.elf" > "$d/kernel.rr.dis"
git diff --check > "$d/source-diff-check.log"
git status --short --untracked-files=no > "$d/tracked-status"
git ls-tree -r "$rev" -- arch boards kernel sdk tools examples/native-loan > "$d/input-tree.txt"
git bundle create "$d/candidate.bundle" HEAD '^04d699c8a445fc837a423c96ba35825810550c4b'
git bundle verify "$d/candidate.bundle" > "$d/bundle-verify.txt" 2>&1
{ rustc --version -v; clang --version; qemu-system-aarch64 --version; aarch64-linux-gnu-objdump --version | head -1; python3 --version; } > "$d/tools.txt"
