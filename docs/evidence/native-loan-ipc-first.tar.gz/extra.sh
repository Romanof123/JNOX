#!/usr/bin/env bash
set -eu -o pipefail
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
cp "$prep"/{extra.sh,probe.c} "$d/"
run cc-probe sh sdk/native-aarch64/build.sh "$d/probe.c" "$d/probe.elf"
for pol in fifo rr; do
 for pair in consumer-exit:0 producer-exit:1; do
  guest "${pair%:*}-$pol" "$pol" 81 "$d/probe.elf" "$d/probe.c" "$d/probe.elf" --peer-elf "$d/probe.elf" --peer-priority 4 --arg "W${pair#*:}" --peer-arg "R${pair#*:}" --peer2-arg T --loan-route 0:1
 done
 guest "empty-reverse-$pol" "$pol" 82 "$d/probe.elf" "$d/probe.c" "$d/probe.elf" --arg R2 --peer-arg W2 --loan-route 1:0
done
guest disabled fifo 84 "$d/probe.elf" "$d/probe.c" "$d/probe.elf" --arg D --peer-arg D
for case in self nonexistent duplicate; do
 case "$case" in
 self) opts=(--loan-route 0:0);; nonexistent) opts=(--loan-route 2:1);; duplicate) opts=(--loan-route 0:1 --loan-route 1:0);;
 esac
 rc=0
 run "reject-$case" python3 tools/build_native_el0.py --out "$d/rejected-$case" --elf "$d/probe.elf" --peer-elf "$d/probe.elf" --policy fifo --priority 7 --peer-priority 1 "${opts[@]}" || rc=$?
 test "$rc" = 2
 test ! -e "$d/rejected-$case"
done
