"""Offline first-verifier decoder. python3 verify.py EXTRACTED_RAW (GNU AArch64 nm and objdump)."""
import hashlib, json, re, struct, subprocess, sys
from pathlib import Path
D = Path(sys.argv[1])
REV = "66d988a0772fac3fd305b83bb123c5d966ea5f23"
VA = 0x1600000
PA = 0x0000fffffffff000
FLAGS = 3 | (3<<8) | (1<<6) | (1<<10) | (1<<11) | (1<<53) | (1<<54)
P = 4096
PATTERN = bytes((13+7*i)&255 for i in range(P))
def digest(x): return hashlib.sha256(x).hexdigest()
def shafile(p): return digest(p.read_bytes())
def nm(p):
    text = subprocess.check_output(["aarch64-linux-gnu-nm","-nS",p],text=True)
    return {f[3]:(int(f[0],16),int(f[1],16)) for line in text.splitlines() if len(f:=line.split())==4}
def word(ram,base,addr):
    assert base<=addr<=base+len(ram)-8
    return struct.unpack_from("<Q",ram,addr-base)[0]
def walk(ram,base,root,va):
    path=[root]
    for depth,shift in enumerate([30,21,12]):
        entry=word(ram,base,path[-1]+8*((va>>shift)&511))
        if depth==2: return path,entry
        assert entry&3==3,(depth,hex(va),entry)
        path.append(entry&PA)
def private(ram,base,root,sy,name,fmt):
    va,size=sy[name]
    assert struct.calcsize("<"+fmt)==size
    buf=bytearray()
    while len(buf)<size:
        _,pte=walk(ram,base,root,va)
        assert pte&3==3 and pte&64
        off=(pte&PA)+(va&4095)-base
        count=min(P-(va&4095),size-len(buf))
        buf+=ram[off:off+count]
        va+=count
    return list(struct.unpack("<"+fmt,buf))
def table_audit(ram,base,roots,l3,pages,expected):
    # Enumerate each process's actual three-level table tree. Require no EL0 alias
    # of its *or any other process's* translation tables and exactly the stated pool aliases.
    all_tables=set()
    walks=[]
    for pid,root in enumerate(roots):
        aliases={}
        user_pa=set()
        def descend(table,depth,prefix):
            all_tables.add(table)
            entries=struct.unpack_from("<512Q",ram,table-base)
            for idx,pte in enumerate(entries):
                if not pte&1: continue
                va=prefix+(idx<<[30,21,12][depth])
                assert pte&3==3,(pid,hex(va),hex(pte))
                if depth!=2:
                    descend(pte&PA,depth+1,va)
                elif pte&64:
                    user_pa.add(pte&PA)
                    if pages<=pte&PA<pages+3*P: aliases[va]=pte
        descend(root,0,0)
        want={VA+i*P:p for i,p in enumerate(expected[pid]) if p}
        assert aliases==want,(pid,aliases,want)
        for slot in range(3):
            path,pte=walk(ram,base,root,VA+slot*P)
            assert path[2]==l3+pid*P and pte==expected[pid][slot]
        for addr in [l3+pid*P,pages,pages+P,pages+2*P]:
            _,pte=walk(ram,base,root,addr)
            assert (pte&PA)==addr and not pte&64 and pte&3==3
            assert pte&(1<<54) and pte&(1<<53) and pte&0xffc==0x700
        walks.append(user_pa)
    assert all(not users&all_tables for users in walks)
    return len(all_tables)
def numbers(uart,tag):
    return [list(map(int,s[len(tag):].split())) for s in uart.splitlines() if s.startswith(tag+" ")]
def calculate(case):
    cap,pkg=D/("cap-"+case),D/("pkg-"+case)
    launch=json.loads((cap/"launch.json").read_text())
    m=json.loads((pkg/"manifest.json").read_text())
    sess=json.loads((cap/"session.json").read_text())
    u=(cap/"uart.bin").read_text()
    count=len(m["slots"])
    assert launch["argument_package"]==m and m["commit"]==REV and not m["tracked_changes"]
    assert launch["revision"]==REV and "tcg" in launch["argv"] and launch["argv"][launch["argv"].index("-smp")+1]=="1"
    assert m["kernel_elf_sha256"]==shafile(pkg/"kernel.elf")
    for f,h in sess["hashes"].items(): assert shafile(cap/f)==h,(case,f)
    assert "FAULT" not in u
    exits=numbers(u,"NATIVE EL0 EXIT PID")
    official=case.startswith("official")
    stages=case.startswith("stages")
    reverse=case.startswith("empty")
    consumer_loss=case.startswith("consumer")
    disabled=case=="disabled"
    expected=[73,74] if official else [85,86] if stages else [84,84] if disabled else [82,81] if reverse else [81,82,83]
    assert exits==list(map(list,enumerate(expected))) and sess["marker"]==f"EXIT {expected[0]}"
    sy=[nm(pkg/s["elf"]) for s in m["slots"]]
    for s in m["slots"]:
        assert s["elf_sha256"]==shafile(pkg/s["elf"]) and s["elf_sha256"] in u
    k=nm(pkg/"kernel.elf")
    root,sz=next(x for n,x in k.items() if "6SPACES" in n)
    assert sz%count==0
    roots=[root+i*sz//count for i in range(count)]
    ram=(cap/"ram.bin").read_bytes()
    base=launch["ram_base"]
    assert len(ram)==launch["ram_bytes"]
    dropped=numbers(u,"NATIVE FIXED DROPPED")[0][0]
    events=numbers(u,"NATIVE FIXED EVENT")
    assert events and all(a[0]<=b[0] for a,b in zip(events,events[1:]))
    if not official: assert dropped==0
    def vals(pid,sym,fmt): return private(ram,base,roots[pid],sy[pid],sym,fmt)
    result=dict(kernel=m["kernel_elf_sha256"],app_sha256=[s["elf_sha256"] for s in m["slots"]],exits=expected,policy=m["policy"],scheduler_dropped=dropped,
                fixed_first_last_ticks=[events[0][0],events[-1][0]],fixed_events=len(events))
    if disabled:
        assert "loan_route" not in m and not numbers(u,"NATIVE LOAN MAP")
        for i in [0,1]: assert vals(i,"recorded","Q")==[4] and vals(i,"private_results","64q")[:4]==[-38]*4
        return result
    producer,reader=(1,0) if reverse else (0,1)
    assert m["loan_route"]==dict(producer=producer,consumer=reader) and m["loan_pool"]==dict(pages=3,page_bytes=4096,ring_entries=2,max_length_bytes=4096)
    leaves,l3sz=k["jnox_native_loan_l3_tables"]; pages,psz=k["jnox_native_loan_pages"]
    assert l3sz==count*P and psz==3*P
    blank=[[0]*3 for _ in roots]
    result["private_tables_examined"]=table_audit(ram,base,roots,leaves,pages,blank)
    maps=numbers(u,"NATIVE LOAN MAP")
    n=8 if official else 1 if stages else 2
    state=numbers(u,"NATIVE LOAN STATE")
    assert state==[[n,n,0,min(n,2),0,0,len(maps),0]]
    assert numbers(u,"NATIVE LOAN PAGE")==[[i,0,0,0] for i in range(3)]
    prev=[[0]*count for _ in range(3)]
    queue=[]
    seen_publishes=[]
    seen_receives=[]
    for op,pid,slot,length,*entries in maps:
        assert len(entries)==count*2 and entries[:count]==prev[slot]
        before,after=entries[:count],entries[count:]
        d=pages+P*slot|FLAGS
        target=[0]*count
        if op in [1,3]:
            assert not any(before) and pid==([producer,reader][op==3])
            target[pid]=d|(128 if op==3 else 0)
            if op==3:
                assert queue and queue.pop(0)==slot
                seen_receives.append(slot)
        elif op in [2,4]:
            assert before[pid]==d|(128 if pid==reader else 0) and sum(bool(i) for i in before)==1
            if op==2:
                assert pid==producer and len(queue)<2
                queue.append(slot); seen_publishes.append((slot,length))
        else: raise ValueError(op)
        assert after==target
        prev[slot]=after
    assert not any(any(i) for i in prev)
    assert len(queue)==int(consumer_loss)
    result.update(state=state[0],live_trace_transitions=len(maps),physical_frames=[hex(pages+i*P) for i in range(3)],
                  terminal_frame_sha256=[digest(ram[pages-base+i*P:pages-base+(i+1)*P]) for i in range(3)])
    frames=[ram[pages-base+i*P:pages-base+(i+1)*P] for i in range(3)]
    if official:
        h=vals(0,"loan_write_handles","8Q"); v=vals(0,"loan_write_vas","8Q"); output=vals(1,"loan_reads","32Q")
        assert len(set(h))==8
        remaining=[bytes(P)]*3
        rows=[]
        for i,(handle,va) in enumerate(zip(h,v),1):
            slot=handle&3; length=5+3*i
            assert va==VA+P*slot and seen_publishes[i-1]==(slot,length) and seen_receives[i-1]==slot
            msg=bytes((17*i+3*j)&255 for j in range(length))
            row=[handle,va,length,sum(msg)]
            assert output[(i-1)*4:i*4]==row
            remaining[slot]=msg.ljust(P,b"\0")
            rows.append(row)
        abandoned=vals(0,"loan_abandoned_handle","Q")[0]
        assert abandoned not in h
        remaining[abandoned&3]=bytes(P)
        assert frames==remaining
        assert vals(0,"loan_full_status","q")==[-11] and vals(0,"loan_full_attempts","I")[0]>=1
        assert vals(1,"loan_stale_status","q")==[-116] and vals(1,"loan_final_status","q")==[-32]
        result.update(private_transfers=rows,abandoned_handle=abandoned,full_retries=vals(0,"loan_full_attempts","I")[0])
    elif stages:
        assert vals(0,"handles","2Q")==[4,8] and vals(1,"handles","2Q")==[4,0]
        assert vals(0,"vas","2Q")==[VA,VA] and vals(1,"vas","2Q")==[VA,0]
        assert frames==[bytes(P)]*3
        records=[]
        for stage,owner,ro,bits in [(1,0,False,PATTERN),(2,None,False,PATTERN[:113].ljust(P,b"\0")),
                (3,1,True,PATTERN[:113].ljust(P,b"\0")),(4,None,False,PATTERN[:113].ljust(P,b"\0")),(5,0,False,bytes(P))]:
            sr=(cap/f"ram-{stage}.bin").read_bytes()
            assert len(sr)==len(ram)
            sr_expected=[[0]*3 for _ in roots]
            if owner is not None: sr_expected[owner][0]=pages|FLAGS|(128 if ro else 0)
            tables=table_audit(sr,base,roots,leaves,pages,sr_expected)
            assert sr[pages-base:pages-base+P]==bits
            pid=1 if stage in [3,4] else 0
            assert private(sr,base,roots[pid],sy[pid],"checkpoint","Q")==[stage]
            records.append(dict(checkpoint=stage,descriptor=[hex(a[0]) for a in sr_expected],byte_sha256=digest(bits),page_tables=tables))
        result["physical_snapshots"]=records
    else:
        wr=[0,0,0,0,0,-11,-13,-116,-116,-90,0,0,-11]+([-32]*3 if consumer_loss else [] if reverse else [-13])
        rd=([-11] if reverse else [])+[-13,0,4096,522240]+([] if consumer_loss else [0,0,-32,0,-116,0])
        wants=[rd,wr] if reverse else [wr,rd,[-13]*4]
        for i,w in enumerate(wants):
            assert vals(i,"recorded","Q")==[len(w)] and vals(i,"private_results","64q")[:len(w)]==w,(case,i,w)
        assert vals(producer,"grant_handles","4Q")==[4,8,13,18]
        assert vals(producer,"grant_vas","4Q")==[VA,VA,VA+P,VA+2*P]
        assert vals(reader,"grant_handles","4Q")==([8,0,0,0] if consumer_loss else [8,13,0,0])
        assert frames==[PATTERN,bytes(P),bytes([0xc7])*P]
        reason=[r[3] for r in events if r[1]==3]
        assert reason==([1,0] if reverse else [2,1,0] if consumer_loss else [2,0,1])
        result.update(private_statuses=wants,exiting_slots_in_time_order=reason)
    return result

if __name__=="__main__":
    data={}
    for name in [x.name[4:] for x in sorted(D.glob("cap-*")) if x.is_dir()]:
        try: data[name]=calculate(name)
        except Exception:
            print("FAILED",name,file=sys.stderr)
            raise
    assert len(data)==11
    print(json.dumps(data,indent=2))
