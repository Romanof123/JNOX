#!/usr/bin/env bash
set -eu -o pipefail
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
cp "$prep"/{verify.py,replay.py,REPORT.en-ko.md,pack.sh} "$d/"
mkdir -p "$d/replay-tools"
cp tools/{native_el0_capture.py,ordinary_amc_capture.py,qemu_capture.py} "$d/replay-tools/"
aarch64-linux-gnu-size "$d"/pkg-{disabled,empty-reverse-fifo}/kernel.elf > "$d/footprint.txt"
stat --printf='%n %s\n' "$d"/pkg-{disabled,empty-reverse-fifo}/kernel.elf >> "$d/footprint.txt"
python3 "$d/verify.py" "$d" > "$d/results.json"
python3 -m py_compile "$d/verify.py" "$d/replay.py" "$d/capture_stages.py"
cd "$d"
files=$(mktemp)
find . \( -type d \( -name app-target -o -name target -o -name __pycache__ \) -prune \) -o \( -type f ! -name host ! -name controls ! -name host-combined.rs ! -name SHA256SUMS -print \) | LC_ALL=C sort > "$files"
while IFS= read -r name; do sha256sum "$name"; done < "$files" > SHA256SUMS
echo ./SHA256SUMS >> "$files"
out="$prep/374-first-66d988a.tar.gz"
tar --sort=name --owner=0 --group=0 --numeric-owner -czf "$out" -T "$files"
rm "$files"
(cd "$prep" && sha256sum 374-first-66d988a.tar.gz > 374-first-66d988a.tar.gz.sha256)
audit=$(mktemp -d)
tar -xzf "$out" -C "$audit"
(cd "$audit" && sha256sum -c SHA256SUMS > /dev/null && python3 verify.py . > "$audit/checked.json" && cmp results.json "$audit/checked.json")
cat "$prep/374-first-66d988a.tar.gz.sha256"
ls -lh "$out"
