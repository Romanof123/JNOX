set -eu
out=/mnt/d/codex/jnox237-evidence
cd ~/amc237/src
export PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR=$HOME/amc237/target PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$HOME/jnox-169-first-e203caa/deps
rev=$(git rev-parse HEAD)
(git log -2 --oneline; rustc -vV; cargo -V; qemu-system-aarch64 --version) > "$out/versions"
cp tools/ordinary_amc_{capture,replay}.py "$out/"
mkdir "$out/original"
for f in ordinary_amc_capture ordinary_amc_replay; do git show 70a0aee:tools/$f.py > "$out/original/$f.py"; done
cp docs/amc-stagger-plan.en-ko.md "$out/"
for app in exact-lo exact-hi over-hi stagger-idle; do
 (cd kernel && JNOX_BOARD=virt JNOX_PROFILE=amc JNOX_APP=$app cargo rustc --locked --release -j1 -- -C link-arg=-Map=$out/$app.map) > "$out/$app.build.log" 2>&1
 d=$out/$app
 python3 tools/ordinary_amc_capture.py freeze "$app" "$d" "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" /usr/bin/qemu-system-aarch64 "$rev" > "$out/$app.freeze"
 python3 tools/ordinary_amc_capture.py run "$d" "$(cat "$out/$app.freeze")" > "$out/$app.session" || true
 python3 tools/ordinary_amc_replay.py "$d" "$(cat "$out/$app.session")" > "$out/$app.replay" || true
 if [ "$app" != stagger-idle ]; then python3 "$out/original/ordinary_amc_replay.py" "$d" "$(cat "$out/$app.session")" > "$out/$app.original" || true; fi
done
rustc --edition=2021 --test tools/scheduling_tests.rs -o "$HOME/amc237/host" > "$out/host-build.log" 2>&1
"$HOME/amc237/host" --test-threads=1 > "$out/host.log"