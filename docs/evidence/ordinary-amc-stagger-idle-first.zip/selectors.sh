set -eu
cd ~/amc237/src/kernel
out=/mnt/d/codex/jnox237-evidence
export PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH CARGO_TARGET_DIR=$HOME/amc237/target CARGO_BUILD_JOBS=1 JNOX_PROFILE=amc
for variant in documented unknown wrong-board; do
 case $variant in documented) opts=(JNOX_BOARD=virt JNOX_AMC_APP=stagger-idle);; unknown) opts=(JNOX_BOARD=virt JNOX_APP=ordinary);; wrong-board) opts=(JNOX_BOARD=pi4 JNOX_APP=stagger-idle);; esac
 rc=0; env -u JNOX_APP "${opts[@]}" cargo build --locked --release -j1 > "$out/$variant.log" 2>&1 || rc=$?
 echo "$rc" > "$out/$variant.rc"
done