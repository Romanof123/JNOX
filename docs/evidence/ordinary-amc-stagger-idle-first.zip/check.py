from pathlib import Path
import json, subprocess, sys
base = Path(__file__).resolve().parent
for name in ('exact-lo','exact-hi','over-hi','stagger-idle'):
    for decoder in ([base] if name=='stagger-idle' else [base, base/'original']):
        subprocess.run([sys.executable,str(decoder/'ordinary_amc_replay.py'),str(base/name),(base/(name+'.session')).read_text().strip()],check=True,stdout=subprocess.DEVNULL)
rows = [line.split() for line in (base/'stagger-idle/first/uart.bin').read_text().splitlines() if line.startswith('AMR ')]
def get(tag):
    return [list(map(int,r[2:])) for r in rows if r[1]==tag]
releases = [(0,0,0,1,4),(2,0,1,2,6),(3,3,0,2,8),(4,1,0,2,8)]
assert [tuple(r[:5]) for r in get('RELEASE')]==releases
owners=[(0,0,0),(2,0,1),(3,3,0),(4,1,0),(5,1,0),(6,3,0)]
assert [tuple(r[:3]) for r in get('GRANT')]==owners
epoch=get('GRANT')[0][9]-3125000
grid=lambda k:epoch+k*3125000
for grant, work in zip(get('GRANT'),get('WORK')):
    k,t,g=grant[:3]
    assert grant[9]==grant[10]==grid(k+1)
    for n,s in [(work[4],work[5]),(work[7],work[8])]:
        ring=[2,5,1,6,3,7,4,8]
        assert s==36*(n//8)+sum(ring[(t+g+i)%8] for i in range(n%8))
assert get('CARRY')==[[5,1,1,0,1]]
idle,=get('IDLE'); wake,=get('WAKE'); complete,=get('COMPLETE')
assert idle[2]==idle[3]==wake[3]==grid(2) and wake[1:3]==[30,5] and wake[6]==idle[5]+4
assert complete[3:5]==[16,72] and complete[6]<grid(8)
print('idle arm-to-IRQ, compare-to-IRQ, b5-to-HI-work, b3-to-SVC, SVC margin ticks',wake[4]-idle[1],wake[4]-grid(2),get('WORK')[4][3]-grid(5),complete[6]-grid(3),grid(8)-complete[6])
