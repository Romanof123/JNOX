set -u
cd ~/jnox236-fifo-current
o=$PWD/out; r=$PWD/src
export PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH CARGO_TARGET_DIR=$PWD/target CARGO_BUILD_JOBS=1 PYTHONDONTWRITEBYTECODE=1
cd "$o"
cp "$0" post.sh
python3 check.py > chain-controls.log 2>&1; echo $? > chain-controls.rc
python3 replay.py > fifo-replay.log 2>&1; echo $? > fifo-replay.rc
sha256sum ordinary-{pi,ceiling}/{plain.uart,trace.uart,exceptions.log} > SHA256SUMS
python3 -m zipfile -c ../controls.zip SHA256SUMS ordinary-pi ordinary-ceiling
python3 "$r/tools/qualify_ordinary_mutex.py" ../controls.zip > legacy-grades.log 2>&1; echo $? > legacy-grades.rc
cd "$r/kernel"
for spec in virt:fixed:ordinary-chain virt:mutex:fixed-fifo virt:mutex:ordinary-chain:rust-prepared virt:none:ordinary-chain pi4:mutex:ordinary-fifo virt:mutex:unknown pi4:mutex:ordinary-chain virt:mutex:ordinary-fifo:rust-prepared; do
 IFS=: read -r board profile app anchor <<<"$spec"
 args=(JNOX_BOARD="$board" JNOX_APP="$app")
 [[ $profile == none ]] || args+=(JNOX_PROFILE="$profile")
 [[ -z $anchor ]] || args+=(JNOX_MUTEX_ANCHOR="$anchor")
 rc=0; env "${args[@]}" cargo build --locked --release -j1 >"$o/invalid-${spec//:/-}.log" 2>&1 || rc=$?
 echo "$spec $rc" >> "$o/negative-status"
done
cd "$r"
python3 "$o/rows.py" "$r" >"$o/rows.log" 2>&1; echo $? > "$o/rows.rc"
python3 tools/requirement_graph.py >"$o/graph.log" 2>&1; echo $? > "$o/graph.rc"
python3 tools/scheduling_evidence.py >"$o/matrix.json" 2>&1; echo $? > "$o/matrix.rc"
cd tools
python3 -m unittest -v test_mutex_anchor_replay test_scheduling_evidence test_requirement_graph test_build_kernel >"$o/scoped.log" 2>&1; echo $? > "$o/scoped.rc"

