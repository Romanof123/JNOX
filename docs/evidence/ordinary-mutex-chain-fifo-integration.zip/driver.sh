set -eu
cd ~/jnox236-fifo-current
export PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH CARGO_TARGET_DIR=$PWD/target CARGO_BUILD_JOBS=1 PYTHONDONTWRITEBYTECODE=1
o=$PWD/out
r=$PWD/src
rev=1bc463d88e5b69763e1268349a57e10685076020
cp chain/{check.py,control_replay.py,mutex_chain_replay.py,rows.py} fifo/replay.py "$o/"
cp "$0" "$o/driver.sh"
(rustc -vV; cargo -V; qemu-system-aarch64 --version; uname -a) > "$o/versions"
cd "$r/kernel"
for app in ordinary-chain ordinary-fifo ordinary-pi ordinary-ceiling; do
 d=$o/$app; mkdir "$d"
 JNOX_BOARD=virt JNOX_PROFILE=mutex JNOX_APP=$app cargo build --locked --release -j1 >"$d/build.log" 2>&1
 k=$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel
 if [[ $app == ordinary-fifo ]]; then python3 "$r/tools/ordinary_mutex_fifo_capture.py" freeze "$o/fifo" "$k" "$rev" > "$o/freeze.out"; else cp "$k" "$d/kernel.elf"; aarch64-linux-gnu-objdump -d "$k" >"$d/linked.asm"; fi
done
cd "$o"
sha256sum */kernel.elf driver.sh *.py "$r"/docs/{ordinary-mutex-chain.md,evidence/ordinary-mutex-fifo-first.zip,evidence/ordinary-timed-chain-integration.zip} > prelaunch.sha256
for app in ordinary-chain ordinary-fifo ordinary-pi ordinary-ceiling; do
 for mode in plain trace; do
 d=$o/$app; rc=0
 if [[ $app == ordinary-fifo ]]; then m=$mode; [[ $m != trace ]] || m=traced; python3 "$r/tools/ordinary_mutex_fifo_capture.py" run "$o/fifo" "$(cat freeze.out)" "$m" || rc=$?
 else opts=(); [[ $mode != trace ]] || opts=(-d int -D "$d/exceptions.log"); timeout -k 2s 15s qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -accel tcg -m 128M -nodefaults -display none -monitor none -serial stdio "${opts[@]}" -kernel "$d/kernel.elf" </dev/null >"$d/$mode.uart" 2>"$d/$mode.stderr" || rc=$?; fi
 echo "$rc" > "$d/$mode.rc"
 done
done
cd "$r"
rustc --edition=2021 --test tools/scheduling_tests.rs -o ../host >"$o/host-build" 2>&1
../host --test-threads=1 >"$o/host"

