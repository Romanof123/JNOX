set -u
base=$HOME/jnox225-independent
cd "$base/src/kernel"
export PATH="$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH" CARGO_BUILD_JOBS=1 JNOX_BOARD=pi4 JNOX_PROFILE=smp PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_TARGET_DIR="$base/build"
mkdir -p "$base/evidence"
cd "$base/src"
git rev-parse HEAD > "$base/evidence/source.txt"
git diff 708e327 HEAD -- docs/boards/pi4-stream-v1.en-ko.md > "$base/evidence/spec.diff"
git archive --format=tar HEAD | gzip > "$base/evidence/source.tar.gz"
python3 -m unittest discover -s tools -p test_pi4_stream_v1.py > "$base/evidence/unit.log" 2>&1
cd kernel
q=/mnt/d/codex/arm-speed-lab/build/system/qemu-system-aarch64
for w in stream original; do
for c in global partitioned clustered; do
d="$base/evidence/$w-$c"
mkdir -p "$d"
export JNOX_APP=migration-$c
f=()
work=sum-65536
if [ "$w" = stream ]; then f=(--features pi4-stream-v1); work=sample-crc32-v1; fi
cargo rustc --locked --release -j1 "${f[@]}" > "$d/build.log" 2>&1
rc=$?; echo "$rc" > "$d/build.rc"; [ "$rc" = 0 ] || continue
elf="$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel"
aarch64-linux-gnu-objcopy -O binary "$elf" "$d/img"
aarch64-linux-gnu-objdump -dC "$elf" > "$d/dis"
python3 ../tools/pi4_migration_capture.py freeze "$JNOX_APP" "$d/frozen" "$elf" "$d/img" "$d/dis" "$q" --source "$(git rev-parse HEAD)" --workload "$work" > "$d/freeze.sha" 2> "$d/freeze.err"
echo "$?" > "$d/freeze.rc"
done
done

