from pathlib import Path
import hashlib, subprocess, sys, zlib
if len(sys.argv)!=3:
    raise SystemExit('usage: python restore.py PATH_TO_JNOX NEW_ORIGINAL_ZIP')
p=Path(__file__).resolve().parent
source=subprocess.check_output(['git','-C',sys.argv[1],'archive','--format=tar.gz','c2ef99630950ecc598d157360e666bd96342772d'])
if hashlib.sha256(source).hexdigest()!='3d4edea171f87cbe0046607902b64843773f4b32c0c7b94243b9384348582d75':
    raise SystemExit('source archive bytes differ; use Ubuntu WSL git archive')
codec=zlib.compressobj(6,zlib.DEFLATED,-15)
raw=(p/'prefix.bin').read_bytes()+codec.compress(source)+codec.flush()+(p/'suffix.bin').read_bytes()
if hashlib.sha256(raw).hexdigest()!='9ca703496602615c982aeef8932f73c50e31f23d0052bfc2eb30ae68cb9d0886':
    raise SystemExit('ZIP reconstruction mismatch')
with Path(sys.argv[2]).open('xb') as f:
    f.write(raw)
