"""Independent offline reader for the two native RX poll captures. Python 3 stdlib."""
import hashlib
import json
import re
import struct
import sys
from collections import Counter
from pathlib import Path


def check(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def cstring(data, offset):
    return data[offset:data.index(0, offset)].decode()


class ELF:
    def __init__(self, path):
        self.data = path.read_bytes()
        d = self.data
        check(d[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<H', d, 18)[0] == 183, str(path))
        off = struct.unpack_from('<Q', d, 40)[0]
        size, count, names = struct.unpack_from('<HHH', d, 58)
        self.headers = [struct.unpack_from('<IIQQQQIIQQ', d, off + i * size) for i in range(count)]
        strings = self.section(names)
        self.names = [cstring(strings, h[0]) for h in self.headers]
        self.symbols = {}
        for i, h in enumerate(self.headers):
            if h[1] == 2:
                strings = self.section(h[6])
                for name, _, _, idx, value, length in struct.iter_unpack('<IBBHQQ', self.section(i)):
                    if idx and idx < count and name:
                        self.symbols[cstring(strings, name)] = (idx, value, length)

    def section(self, idx):
        h = self.headers[idx]
        return self.data[h[4]:h[4]+h[5]]

    def code(self, name):
        idx, addr, size = self.symbols[name]
        start = addr - self.headers[idx][3]
        return self.section(idx)[start:start+size]

    def relocations(self, name):
        idx = self.symbols[name][0]
        return {off for i,h in enumerate(self.headers) if h[1] == 4 and h[7] == idx
                for off, _, _ in struct.iter_unpack('<QQq', self.section(i))}


def unpack_stream(data, wire):
    pos = 24 if wire else 0
    if wire:
        check(data[:4] == bytes.fromhex('d4c3b2a1') and struct.unpack_from('<I',data,20)[0] == 1,'pcap Ethernet')
    records = []
    while pos < len(data):
        if wire:
            _, _, n, original = struct.unpack_from('<4I', data, pos)
            check(n == original, 'truncated pcap frame')
            pos += 16
        else:
            n = struct.unpack_from('>I', data, pos)[0]
            pos += 4
        check(0 < n <= len(data)-pos, 'incomplete frame')
        records.append(data[pos:pos+n])
        pos += n
    return records


class Ram:
    def __init__(self, path):
        self.blocks = {}
        for key, value in json.loads(path.read_text()).items():
            address, size = key.split('/')
            block = bytes.fromhex(value)
            check(len(block) == int(size), key)
            self.blocks[int(address,16),len(block)] = block

    def read(self, address, size):
        for (base,n), block in self.blocks.items():
            if base <= address and address + size <= base + n:
                return block[address-base:address-base+size]
        raise KeyError((hex(address),size))

    def phys(self, root, va):
        table = root
        for shift in (30,21,12):
            entry = struct.unpack('<Q',self.read(table+8*((va>>shift)&511),8))[0]
            check(entry & 3 == 3, 'missing page descriptor')
            table = entry & 0xfffffffff000
        return table + (va & 4095)

    def virt(self, root, va, n):
        chunks = []
        while n:
            step = min(n,4096-(va & 4095))
            chunks.append(self.read(self.phys(root,va),step))
            va += step
            n -= step
        return b''.join(chunks)

    def address_space(self, va, signature):
        matches = []
        for base,n in self.blocks:
            if n == 4096:
                try:
                    if self.virt(base,va,len(signature)) == signature:
                        matches.append(base)
                except (ValueError, KeyError):
                    pass
        check(len(matches)==1, 'unique task root')
        return matches[0]


def analyze(root):
    imported = root/'imported'
    imp = json.loads((imported/'import.json').read_text())
    src = root / 'source' / 'drivers' / 'net' / 'virtio_net.c'
    if not src.exists():
        src = Path(imp['source']['path'])
    if not src.exists() and str(imp['source']['path']).startswith('/mnt/d/'):
        src = Path('D:/'+imp['source']['path'][7:])
    source = src.read_bytes()
    check(sha(source)==imp['source']['sha256'], 'recorded compile source identity')
    driver = ELF(root/'native/user.elf')
    peer = ELF(root/'native/native_peer.elf')
    check(driver.data==(imported/'service.elf').read_bytes() and peer.data==(root/'peer.elf').read_bytes(),'ELF copy')
    baseline = ELF(imported/'virtio_net.original.o')
    original = ELF(imported/'virtio_net.packet.o')
    callback = ELF(imported/'virtio_net.callback.o')
    result = {'source_sha256':sha(source),'service_sha256':sha(driver.data),'peer_sha256':sha(peer.data),'baseline_object_sha256':sha(baseline.data),'packet_object_sha256':sha(original.data),'linked_callback_object_sha256':sha(callback.data),'symbols':{},'captures':{}}
    names = ['virtnet_alloc_queues','virtnet_poll','gro_receive_skb','jnox_rx_disable_cb_v1','virtqueue_enable_cb_prepare']
    for name in names:
        raw = driver.code(name)
        addr = driver.symbols[name][1]
        result['symbols'][name] = {'entry':hex(addr),'size':len(raw),'linked_sha256':sha(raw)}
        if name in names[:2]:
            check(name.encode() in source and original.code(name)==callback.code(name),name+' upstream/callback object')
            before = callback.code(name)
            rel = callback.relocations(name)
            check(len(before)==len(raw) and all(before[i:i+4]==raw[i:i+4] for i in range(0,len(raw),4) if i not in rel),name+' linked non-relocation instructions')
            check('virtio_net.callback.o:(.text.'+name+')' in (imported/'service.map').read_text(),name+' map')
            result['symbols'][name].update(object_sha256=sha(before),relocation_sites=len(rel))
    for directory in sorted(root.glob('capture-[ab]')):
        machine = (directory/'machine.log').read_text()
        uart = (directory/'uart.log').read_text()
        for line in ['NATIVE EL0 ELF '+sha(driver.data),'NATIVE EL0 PEER ELF '+sha(peer.data),'NATIVE EL0 EXIT PID 0 0','NATIVE EL0 EXIT PID 1 0']:
            check(line in uart,line)
        pcs = Counter(int(v,16) for v in re.findall(r'^Trace \d+: .*?\[[^/]+/([0-9a-f]+)/',machine,re.M))
        hits = {}
        for name in names:
            addr = driver.symbols[name][1]
            check(re.search(fr'^0x0*{addr:x}:\s+{int.from_bytes(driver.code(name)[:4],"little"):08x}\b',machine,re.M), name+' guest opcode')
            hits[name] = pcs[addr]
            check(hits[name] and not (name in peer.symbols or any(v<=addr<v+n for idx,v,n in peer.symbols.values() if n and peer.headers[idx][2] & 4)),name+' attribution')
        frames = unpack_stream((directory/'wire.pcap').read_bytes(), True)
        check(frames == unpack_stream((directory/'host-to-guest.bin').read_bytes(),False) and len(frames)==81 and not (directory/'guest-to-host.bin').read_bytes(),'socket/pcap')
        nonce = (directory/'nonce.bin').read_bytes()
        for i, f in enumerate(frames):
            check(f[:14]==bytes.fromhex(json.loads((directory/'launch.json').read_text())['mac'].replace(':','')+'024a4e4f580188b5') and f[22:30]==nonce,'frame header')
            if i<80:
                check(len(f)==60+i%32 and f[14:22]==b'JNOXRECV' and int.from_bytes(f[30:34],'big')==i and f[34:]==bytes(i+j for j in range(34,len(f))), 'sequence/payload')
            else:
                check(len(f)==60 and f[14:22]==b'JNOXACK!', 'ack')
        ram = Ram(directory/'final/ram.json')
        peer_va = peer.symbols['jnox_rx_peer_result'][1]
        pr = ram.address_space(peer_va,struct.pack('<Q',0x4a4e525850454531))
        poll_va = driver.symbols['jnox_rx_poll_receipt'][1]
        dr = ram.address_space(poll_va,struct.pack('<Q',driver.symbols['virtnet_poll'][1]))
        check(pr!=dr,'distinct page tables')
        for i,f in enumerate(frames):
            va = peer.symbols['jnox_rx_peer_frames'][1]+91*i if i<80 else peer.symbols['jnox_rx_peer_ack'][1]
            check(ram.virt(pr,va,len(f))==f,'peer frame '+str(i))
        def receipt(name):
            return struct.unpack('<8Q',ram.virt(dr,driver.symbols['jnox_rx_'+name+'_receipt'][1],64))
        poll, napi, skb = map(receipt,['poll','napi','skb'])
        check(poll[1]==8 and poll[2]==hits['virtnet_poll'] and poll[3]==poll[5]==81 and poll[4]==10 and poll[6:]==(1,11),'poll exhaustion')
        check(napi[:4]==(1,1,poll[2],10) and napi[6]==0,'registration and race')
        check(skb==(81,81,81,81,81,81,0,0) and hits['gro_receive_skb']==81,'typed handoffs')
        q = {}
        selected = 0
        for a,v in re.findall(r"memory_region_ops_write .*?addr (0x\w+) value (0x\w+) size 4 name 'virtio-mmio'",machine):
            reg, val = int(a,16)&511,int(v,16)
            if reg==0x30:
                selected=val
            elif reg in (0x38,0x80,0x84,0x90,0x94,0xa0,0xa4):
                q.setdefault(selected,{})[reg]=val
        rings = {}
        for phase in ('ready','active','final'):
            snap = Ram(directory/phase/'ram.json')
            check(json.loads((directory/phase/'halted.json').read_text())['running'] is False,'snapshot stopped')
            rings[phase]={}
            for index, regs in q.items():
                def reg64(lo):
                    return regs[lo] + (regs[lo+4]<<32)
                rings[phase][index]=[struct.unpack('<H',snap.read(reg64(lo)+2,2))[0] for lo in (0x90,0xa0)]
        check(set(q)=={0,1} and rings['ready'][0]==[32,0] and rings['active'][0][1]>=80 and all(r[1]==[0,0] for r in rings.values()),'rings')
        result['captures'][directory.name]=dict(nonce=nonce.hex(),entries=hits,poll=poll,napi=napi,skb=skb,peer_root=hex(pr),driver_root=hex(dr),matched_frames=81,wire_payload_bytes=sum(map(len,frames)),ring_avail_used=rings)
    check(len(result['captures'])==2,'two captures')
    return result


if __name__=='__main__':
    evidence = analyze(Path(sys.argv[1]))
    Path(sys.argv[2]).write_text(json.dumps(evidence,indent=2)+'\n')
