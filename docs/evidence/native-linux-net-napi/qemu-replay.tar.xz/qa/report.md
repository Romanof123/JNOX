# Independent offline reading of JNOX #432

Both AArch64 QEMU captures show one execution of the linked virtnet_alloc_queues entry, registration of the RX callback at the linked virtnet_poll address 0x40ac80, and 26 entries into that poll routine. The driver receipt gives a budget of eight, ten full-budget returns, 81 units of work, eleven nonempty returns and one unit on the final return. The separate NAPI registration counters recorded one RX and one TX registration.

The original C file hashes to 05e676f7fc4f91783c961c860b930fae33462348064887eea95be3a440282a29. The compiled packet-profile object's two routine sections match the callback object's sections byte for byte. The link map identifies that callback object as their provider. All instructions outside relocation sites match the loaded service ELF. The baseline object uses a different compilation profile and has different routine sizes. Source attribution relies on the preserved compiler invocation and local source digest. This was an offline inspection with no independent compilation. QEMU instruction words at the five monitored entries match the service, and the ELF hashes printed at boot match the supplied service and peer.

Each capture contains 81 QEMU execution entries at gro_receive_skb. The compatibility source uses typed struct gro_node and struct sk_buff arguments, verifies a linear packet and device, enqueues the packet, and returns GRO_NORMAL. The final service counters record 81 built, appended, classified, queued, read and released with zero pending and zero dropped. Return-value attribution uses the routine's source and successful downstream consumption. The trace does not sample the C return register. This exercises the GRO-disabled ordinary delivery path.

In both runs the external socket input, Ethernet PCAP and peer's independently translated private RAM agree byte for byte on 80 ordered data frames and one host-injected 60-byte ACK, 5,972 Ethernet bytes total. The socket output was empty. The ACK was delivered by IPC to the peer. Both PIDs exited zero. Distinct nonces and MACs distinguish the runs.

| Paused snapshot | RX avail / used | TX avail / used |
|---|---:|---:|
| Ready | 32 / 0 | 0 / 0 |
| Active | 112 / 80 | 0 / 0 |
| Final | 112 / 81 | 0 / 0 |

Virtio MMIO queue selections and ring addresses locate both queues in physical RAM. Both runs show 26 callback-disable entries and 16 callback-enable preparations. The rearm-race counter was zero. These captures do not demonstrate an arrival racing rearm or a virtio CPU IRQ/ISR dispatch. Polling, device status and ring activity are consistent with the observed deliveries.

Reproduce with Python 3 using read_poll.py CAPTURE_PARENT OUTPUT_JSON. The reader uses the bundled source/drivers/net/virtio_net.c when present and the recorded local source path for the original lab capture. Both paths require the same SHA-256 digest. It uses neither the capture result files nor an integration checker.
