#!/bin/sh
set -eu
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$PWD/vendor:$PWD/tools"
unset PYTHONOPTIMIZE
sha256sum --quiet -c SHA256SUMS
python3 -B - <<'PY'
import json, subprocess, sys, tempfile
from pathlib import Path
baseline = {"running CPU at burst", "host-to-guest.bin", "wire.pcap", "registered NAPI pointer",
            "no budget exhaustion", "skb build", "removed executed virtnet_poll", "removed executed gro_receive_skb"}
summary = json.loads(Path("result.json").read_bytes())
for case in ("capture-a", "capture-b"):
    cmd = [sys.executable, "-B", "tools/verify_linux_source_net_rx_poll.py", "--replay", "--mutation-tests",
           "--package", "native", "--driver-manifest", "imported/import.json", "--out", case]
    computed = json.loads(subprocess.check_output(cmd))
    rejected = computed.pop("rejected_mutations")
    if not baseline.issubset(rejected) or len(rejected) != len(set(rejected)):
        sys.exit(f"{case}: mutation coverage differs from the required controls")
    original = json.loads((Path(case) / "result.json").read_bytes())
    if computed != original or computed != summary["cases"][case]["observed"]:
        sys.exit(f"{case}: original result cannot be reproduced")
    print(case, json.dumps(computed, sort_keys=True), f"{len(rejected)} rejected mutations", flush=True)
recorded = json.loads(Path("qa/result.json").read_bytes())
reader = Path("qa") / summary["independent_reader"]
with tempfile.TemporaryDirectory() as work:
    result_path = Path(work) / "independent.json"
    subprocess.run([sys.executable, "-B", str(reader), ".", str(result_path)], check=True)
    actual = json.loads(result_path.read_bytes())
if actual != recorded:
    sys.exit("independent replay differs from the retained report")
print("PASS independent upstream poll replay of both captures matched the original report")
PY
