import csv, hashlib, json, re, struct, zipfile
from pathlib import Path
p=Path(__file__).parent
raw=p/'raw/plain'
sha=lambda b: hashlib.sha256(b).hexdigest()
manifest=json.loads((raw/'manifest.json').read_bytes())
archive=raw/'position.zip'
assert sha(archive.read_bytes())==manifest['archive_sha256']
with zipfile.ZipFile(archive) as z:
    assert len(z.infolist())==len(manifest['members'])==19
    for m in manifest['members']:
        b=z.read(m['name'])
        assert len(b)==m['size'] and sha(b)==m['sha256']
    assert sha(z.read('session/session.json'))==manifest['session_sha256']
    ram=z.read('session/ram.bin')
    log=z.read('session/exceptions.log').decode()
rows=list(struct.iter_unpack('<16Q',ram[0xf008:0xf008+513*128]))
head=rows[0]
assert head[0:5]==(1,3,1,62500000,625000) and head[7:9]==(0,0)
last=None
service=[0,0]
out=[]
irq_pcs=re.findall(r'Taking exception 5 \[IRQ\]\s+\.\.\.from EL0 to EL1.*?with ELR (0x[0-9a-f]+)',log,re.S)
for row in rows[1:1+head[6]]:
    if row[0]!=3: continue
    _,i,pid,lease,vector,r,c,ctl,iar,pc,sp,ps,x8,dt,a,b=row
    gap=r-last if last is not None else 0
    last=i
    service[pid]+=i-r
    assert service==[a,b] and dt==i-r
    irq=vector==0x480
    if irq: assert int(irq_pcs[lease-1],16)==pc
    out.append(dict(lease=lease,pid=pid,vector=hex(vector),R=r,C=c,I=i,ctl=ctl,iar=iar,pc=hex(pc),elapsed=i-r,lateness=i-c,gap=gap,A=a,B=b,diff=2*a-b,H_ok=625000<=i-r<=781250 if irq else None,G_ok=gap<=156250,prefix_ok=-781250<=2*a-b<=1562500 if lease<=36 else None,external_GIC_PPI_line_IAR='unobserved (plain)',guest_GT_ok=c==r+625000 and (not irq or (ctl&7==5 and iar==30 and i>=c))))
with (p/'leases.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,out[0]); w.writeheader(); w.writerows(out)
print('HEAD',head,'IRQs',len(irq_pcs),'leases',len(out))
for k in ['H_ok','G_ok','prefix_ok','guest_GT_ok']:print(k,[x['lease'] for x in out if x[k] is False])
print('max gap',max(x['gap'] for x in out),'max closure',max(x['elapsed'] for x in out[:36]),'end',out[35], 'tail',out[36:])
