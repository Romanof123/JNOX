import io, tarfile,os,itertools
from pathlib import Path
from native_extension_equivalence import Image,sha
from native_extension_source_equivalence import layout
base=Path(__file__).parent
archive=Path.cwd()/'docs/evidence/native-extension-stopped-progress-first-raw.tar.gz'
with tarfile.open(archive) as hist:
 for pos,label in itertools.product('ab',['ordinary','dormant','active']):
  prior='accepted' if (pos,label)==('a','ordinary') else pos+'-'+label
  a=Image(hist.extractfile(f'./{prior}-plain/kernel.elf').read())
  b=Image((base/f'{pos}-disabled'/label/'kernel.elf').read_bytes())
  x=layout(a,label!='ordinary',False);y=layout(b,label!='ordinary',False)
  print(pos,label, [i==j for i,j in zip(x,y)],'loads',a.loads==b.loads)
  print('loaded',[(hex(i[1]),len(i[-1]),len(j[-1]),sum(k!=l for k,l in zip(i[-1],j[-1]))) for i,j in zip(a.loads,b.loads)])
  if pos=='a' and label=='ordinary':
   print('sections',[(n,hex(a.sections[n]['sh_addr']),len(a.sections[n].data()),sum(u!=v for u,v in zip(a.sections[n].data(),b.sections[n].data()))) for n in a.sections])
   print('syms missing and extra',list(x[-1]-y[-1])[:16],list(y[-1]-x[-1])[:16])
   for i,j in zip(a.loads,b.loads):
    changed=[k for k,(u,v) in enumerate(zip(i[-1],j[-1])) if u!=v]
    print('mismatch',[(hex(i[1]+k),i[-1][k],j[-1][k]) for k in changed[:64]])
