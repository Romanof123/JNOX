"""Offline characterization of the retained first build products. Does not launch or score a guest."""
import hashlib
import io
import itertools
import json
import re
import struct
import subprocess
import tarfile
from collections import Counter
from pathlib import Path
from elftools.elf.elffile import ELFFile

OUT = Path(__file__).resolve().parent
SRC = OUT.parent / "src"
PAST = SRC / "docs/evidence/native-extension-stopped-progress-first-raw.tar.gz"
LABELS = ("ordinary", "dormant", "active")
DIGEST = lambda v: hashlib.sha256(v).hexdigest()

def loads(elf):
    return [(s["p_vaddr"],s["p_paddr"],s["p_flags"],s["p_memsz"],s["p_filesz"],s["p_align"],s.data()) for s in elf.iter_segments() if s["p_type"]=="PT_LOAD"]

def get(segments, addr, count):
    seg, = [s for s in segments if s[0] <= addr and addr+count<=s[0]+len(s[-1])]
    return seg[-1][addr-seg[0]:addr-seg[0]+count]

def sections(elf):
    return {s.name:(s["sh_addr"],s["sh_size"],s["sh_flags"],s["sh_type"],s["sh_addralign"]) for s in elf.iter_sections() if s["sh_flags"]&2}

def symbols(elf):
    return Counter((s.name,s["st_value"],s["st_size"]) for s in elf.get_section_by_name(".symtab").iter_symbols() if isinstance(s["st_shndx"],int) and s.name and not s.name.startswith("$"))

def sym(elf,name):
    s,=elf.get_section_by_name(".symtab").get_symbol_by_name(name)
    return s["st_value"],s["st_size"]

def seal_file(name,data):
    (OUT/name).write_bytes(data)

def classify(before, after):
    orig,curr=[ELFFile(io.BytesIO(data)) for data in (before,after)]
    old,new=loads(orig),loads(curr)
    assert [s[:-1] for s in old]==[s[:-1] for s in new] and sections(orig)==sections(curr)
    diffs={s[0]+i:(a,b) for s,t in zip(old,new) for i,(a,b) in enumerate(zip(s[-1],t[-1])) if a!=b}
    records=[]
    for k in sorted(set(x&~3 for x in diffs)):
        field=k-16
        def location(segs):
            p,n,l,c=struct.unpack("<QQII",get(segs,field,24))
            return get(segs,p,n).decode(),p,n,l,c
        a,b=location(old),location(new)
        assert a[:3]==b[:3] and a[-1]==b[-1] and a[0] in ("src/native_el0.rs","src/native_el0_mmu.rs") and b[3]-a[3]==(28 if "mmu" in a[0] else 2)
        assert all(k <= x < k+4 for x in diffs if field<=x<field+24)
        ro=sections(orig)[".rodata"]
        assert ro[0]<=field and field+24<=ro[0]+ro[1]
        records.append(dict(field=hex(field),line_field=hex(k),file=a[0],column=a[4],old_line=a[3],new_line=b[3],file_addr=hex(a[1])))
    x,y=symbols(orig),symbols(curr)
    def no_lto_id(counter):
        return Counter((re.sub(r"\.llvm\.\d+$","",name),va,size) for name,va,size in counter.elements())
    assert no_lto_id(x)==no_lto_id(y)
    return dict(original_elf=DIGEST(before),current_elf=DIGEST(after),load_geometry_match=True,allocated_section_geometry_match=True,
      changed_bytes={hex(k):v for k,v in diffs.items()},locations=records,changed_symbol_counts=[sum((x-y).values()),sum((y-x).values())],
      normalized_names_sizes_addresses_match=True,symbol_pairs=dict(original=list((x-y).elements()),current=list((y-x).elements())),
      sections={n:dict(address=hex(s[0]),size=s[1],flags=s[2],type=s[3],align=s[4],
        backed_changed=sum(s[0]<=k<s[0]+s[1] for k in diffs)) for n,s in sections(orig).items()})

def instructions(elf_path,listing_name):
    raw=elf_path.read_bytes()
    elf=ELFFile(io.BytesIO(raw))
    segs=loads(elf)
    vectors,_=sym(elf,"native_el0_vectors")
    sampler,extent=sym(elf,"jnox_extension_register_arm")
    # Full GNU disassembly and actual loader words are recorded independently.
    dis=subprocess.check_output(["aarch64-linux-gnu-objdump","-d",str(elf_path)])
    seal_file(listing_name,dis)
    timer_expected=[0xd5033fdf,0xd53be02c,0xd51be241,0xd51be22d,0xd5033fdf,0xd53be24b,0xd53be22a,0xd5033fdf,0xd53be029]
    disable_expected=[0xd5033fdf,0xd53be02c,0xd51be23f,0xd5033fdf,0xd53be24b,0xd53be22a,0xd5033fdf,0xd53be029]
    words=struct.unpack("<"+"I"*(extent//4),get(segs,sampler,extent))
    def match(seq):
        i,=[i for i in range(len(words)) if list(words[i:i+len(seq)])==seq]
        return sampler+4*i
    enable=match(timer_expected); disable=match(disable_expected)
    assert get(segs,enable-4,4)==struct.pack("<I",0x5280002d)
    prefixes=[]
    for offs in [5,9]:
        pc=vectors+offs*128
        insn,=struct.unpack("<I",get(segs,pc,4))
        assert insn>>26 == 0b000101
        imm=insn&0x3ffffff
        start=pc+((imm^(1<<25))-(1<<25))*4
        words_at_prefix=struct.unpack("<16I",get(segs,start,64))
        assert words_at_prefix[:3]==(0xa9bf2be9,0xd5033fdf,0xd53be02a)
        assert words_at_prefix[5:12]==(0xf900012a,0xd538400a,0xf900052a,0xd538402a,0xf900092a,0x910043ea,0xf9000d2a)
        assert words_at_prefix[14:]==(0xf900112a,0xa8c12be9)
        # Resolve ADRP and each byte-scaled offset against the linked scratch and generation.
        def page(word,at,reg):
            assert word&0x9f00001f==0x90000000|reg
            delta=(((word>>5)&0x7ffff)<<2)|((word>>29)&3)
            return (at&~4095)+(((delta^(1<<20))-(1<<20))<<12)
        p=page(words_at_prefix[3],start+12,9); w=words_at_prefix[4]
        assert w&0xffc003ff==0x91000129 and p+((w>>10)&4095)==sym(elf,"jnox_extension_reg_scratch")[0]
        p=page(words_at_prefix[12],start+48,10); w=words_at_prefix[13]
        assert w&0xffc003ff==0xf940014a and p+8*((w>>10)&4095)==sym(elf,"jnox_extension_reg_generation")[0]
        prefixes.append(dict(vector=hex(pc),vector_word=hex(insn),start=hex(start),counter=hex(start+8),spsr=hex(start+24),elr=hex(start+32),
                             recovery=hex(start+64),words=[hex(w) for w in words_at_prefix]))
    return dict(elf=DIGEST(raw),disassembly=DIGEST(dis),sampler=hex(sampler),size=extent,enable=hex(enable),disable=hex(disable),
        enable_readbacks=[hex(enable+i) for i in (20,24)],disable_readbacks=[hex(disable+i) for i in (16,20)],prefixes=prefixes)

with tarfile.open(PAST) as history:
    result={}
    for p,v in itertools.product("ab",LABELS):
        historic="accepted" if (p,v)==("a","ordinary") else p+"-"+v
        disabled=(OUT/(p+"-disabled")/v/"kernel.elf").read_bytes()
        enabled=OUT/p/v/"kernel.elf"
        comp=classify(history.extractfile("./"+historic+"-plain/kernel.elf").read(),disabled)
        assert len(comp["changed_bytes"])==12 and len(comp["locations"])==11
        ins=instructions(enabled,f"{p}-{v}.dis")
        result[p+"-"+v]=dict(disabled=comp,enabled=ins,standalone_matches_enabled=(OUT/(p+"-standalone")/"kernel.elf").read_bytes()==(OUT/p/"ordinary/kernel.elf").read_bytes())
        print(p,v,"disabled",len(comp["changed_bytes"]),"bytes in",len(comp["locations"]),"locations, symbols",comp["changed_symbol_counts"],
              "enabled static timer reads",ins["enable_readbacks"],"vectors",[(i["vector"],i["start"]) for i in ins["prefixes"]])
    seal_file("characterization.json",json.dumps(result,indent=2).encode()+b"\n")
