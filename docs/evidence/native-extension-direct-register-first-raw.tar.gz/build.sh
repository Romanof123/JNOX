set -euo pipefail
here=$(dirname "$(realpath "$0")"); . "$here/env.sh"
exec 9>"$out/command.log"; BASH_XTRACEFD=9; set -x
git status --porcelain > "$out/git-status-before"
git rev-parse HEAD upstream-main > "$out/refs"
git ls-files --eol kernel/src/native_extension_entry.S > "$out/source-eol"
git archive HEAD | gzip -n > "$out/source.tar.gz"
cp "$HOME/jnox352-first/pins.json" "$out/pins.json"
cat > "$out/refs.sha256" <<'HASH'
29c60cf742e78c1fd3a38d1aa9332e5fadd07f39614c7d4434b3a2225f655cc8  docs/evidence/native-extension-transaction-first.tar.gz
797d1e8594eb7ea645895e075e4bc99f925ed3061415c131107aab02706a99ca  docs/evidence/native-extension-source-built-first-raw.tar.gz
e49c2bbe1f1cb954f2d58db24fb1e2f0b575478aaa2c9c2abe13cfa8b36898ac  docs/evidence/native-extension-stopped-progress-first-raw.tar.gz
c54d67808ecbfa5d36d4e5cf6e3bc8d04990eea05a9f4c1fe93cdf5dfea00194  docs/evidence/native-extension-stopped-progress-first.en-ko.md
359d4cc8667ffaf66f13ddcc1c24376bb32718ea4f9335391e4ace8eec0e837f  docs/evidence/native-extension-stop-first-preflight.tar.gz
HASH
sha256sum -c "$out/refs.sha256" > "$out/refs.check"
mkdir "$out/ref"
tar xzf docs/evidence/native-extension-transaction-first.tar.gz -C "$out/ref" ./accepted ./accepted-trace/launch.json ./accepted-trace/probe.c
sha256sum "$ref"/{user,native_peer,native_peer2}.elf "$ref/extension_program.txt" "$out/ref/accepted-trace/"* > "$out/input-hashes"
{ rustc -vV; cargo -V; clang --version; qemu-system-aarch64 --version; aarch64-linux-gnu-objdump --version; python3 -c 'import elftools;print(elftools.__version__)'; } > "$out/tool-versions"
for p in a b; do
  python3 tools/native_extension_cohort.py "$p" "$ref" "$out/$p-disabled" --pins "$out/pins.json" > "$out/$p-disabled.first" 2>&1
  python3 tools/native_extension_cohort.py "$p" "$ref" "$out/$p" --pins "$out/pins.json" --extension-register-observations > "$out/$p-enabled.first" 2>&1
  apps=(--elf "$ref/user.elf" --peer-elf "$ref/native_peer.elf" --peer-elf "$ref/native_peer2.elf")
  if [[ $p == b ]]; then apps=(--elf "$ref/native_peer2.elf" --peer-elf "$ref/native_peer.elf" --peer-elf "$ref/user.elf" --arg four-batches); fi
  python3 tools/build_native_el0.py --board virt --policy extension --out "$out/$p-standalone" "${apps[@]}" --extension-program "$ref/extension_program.txt" --extension-register-observations > "$out/$p-standalone.first" 2>&1
done
for p in a b; do
  result=0
  python3 tools/native_extension_equivalence.py source-built "$p" "$out/$p" "$out/$p-standalone" "$out/$p-gate" --extension-register-observations --disabled-cohort "$out/$p-disabled" > "$out/$p.gate-first" 2>&1 || result=$?
  echo "$p $result" | tee -a "$out/preflight-status"
  cat "$out/$p.gate-first"
done
