base="$HOME/iv352-reg-9a63cfd"; out="$base/raw"; src="$base/src"; ref="$out/ref/accepted"
export PATH="$HOME/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$HOME/.cargo/bin:/usr/lib/llvm-14/bin:$PATH"
export PYTHONPATH="$HOME/jnox-328-supplement/deps"
export LC_ALL=C
cd "$src"
