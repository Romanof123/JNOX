import sys,io,tempfile,json,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path(r'D:/codex/pi391-corrected-check')
sys.path.insert(0,str(root/'tools'))
import test_pi4_native_serial_replay as t
import pi4_serial_capture as c
out=Path(__file__).parent
T=t.NativeReplayTests; T.setUpClass()
class Port(io.BytesIO):
 def reset_input_buffer(self): pass
 def read(self,n):
  if self.tell()>=62 and broken: raise broken('simulated failure')
  return super().read(min(n,31))
with tempfile.TemporaryDirectory() as tmp:
 obj=T(); obj.folder=Path(tmp); obj.runs=0
 for policy in ('rr','fifo'):
  pkg=obj.stage(policy); inputs=[obj.uart[policy+'-'+k] for k in ('plain','traced')]
  import shutil
  path=obj.replay(pkg,'pi4-native-'+policy,inputs,0)
  shutil.copytree(path,out/('file-'+policy))
  for broken in ((OSError,KeyboardInterrupt,False) if policy=='rr' else (False,)):
   folder=out/('SIMULATED-port-'+policy+('-'+broken.__name__ if broken else ''))
   args=['collector','--port','SIMULATED','--profile','pi4-native-'+policy,'--board-revision','SIMULATED','--eeprom','SIMULATED','--elf',str(pkg/'kernel.elf'),'--boot-dir',str(pkg.parent/('boot-'+policy)),'--native-manifest',str(pkg/'manifest.json'),'--output',str(folder)]
   with patch.object(sys,'argv',args),patch('builtins.input',return_value=''),patch.object(c,'serial_port',side_effect=[Port(x) for x in inputs]) as open_adapter:
    rc=c.main()
   print(folder.name,rc,(folder/'run-1/uart.bin').stat().st_size,'result?',(folder/'run-1/result.json').exists(),flush=True)
   if not broken:
    assert rc==0 and all((folder/f'run-{i}/uart.bin').read_bytes()==v for i,v in enumerate(inputs,1))
   else:
    r=json.loads((folder/'run-1/result.json').read_bytes()); identity=json.loads((folder/'run-1/identity.json').read_bytes()); sess=json.loads((folder/'session.json').read_bytes())
    assert rc==(130 if broken is KeyboardInterrupt else 2)
    assert r['uart_verdict']==('interrupted' if broken is KeyboardInterrupt else 'read_error')
    assert r['terminal_cause']==dict(operation='read',type=broken.__name__,message='simulated failure')
    assert (folder/'run-1/uart.bin').read_bytes()==inputs[0][:62] and r['bytes']==62 and r['uart_sha256']==t.sha(inputs[0][:62])
    assert r['read_records']==2 and r['run_id']==identity['run_id'] and r['session_id']==identity['session_id']==sess['session_id']
    assert open_adapter.call_count==1 and not (folder/'run-2').exists()
    print('verified terminal identity and partial hash, run 2 unstarted',flush=True)

