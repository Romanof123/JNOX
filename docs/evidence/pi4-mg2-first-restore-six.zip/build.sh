set -eu
cd ~/smp204-cc864a3-iv
export PATH="$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH" PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_BUILD_JOBS=1 JNOX_BOARD=pi4 JNOX_PROFILE=smp
sha=cc864a392828d37cf2fb933566e93e20bfeaa455
d=/mnt/d/codex/smp204-cc864a3-iv
model=/mnt/d/codex/arm-speed-lab/build/system/qemu-system-aarch64
mkdir -p results
sha256sum "$model" "$d/build.sh" > "$d/start.sha256"
for c in global partitioned clustered; do
 mkdir results/$c-build
 b="$PWD/results/$c-build"
 (cd kernel && JNOX_APP=migration-$c cargo rustc --locked --release -j1 -- -C link-arg=-Map="$b/linker.map") > "$b/build.log" 2>&1
 cp kernel/target/aarch64-unknown-none/release/jnox-kernel "$b/kernel.elf"
 aarch64-linux-gnu-objcopy -O binary "$b/kernel.elf" "$b/kernel8.img"
 aarch64-linux-gnu-objdump -dC "$b/kernel.elf" > "$b/disassembly.txt"
 python3 tools/pi4_migration_capture.py freeze migration-$c results/$c "$b/kernel.elf" "$b/kernel8.img" "$b/disassembly.txt" "$model" --source "$sha" > "$b/freeze.digest"
 PYTHONPATH="tools:$PYTHONPATH" python3 -c 'import sys;from pathlib import Path;from pi4_migration_replay import layout;p=Path(sys.argv[1]); print(layout(*[(p/n).read_bytes() for n in ("kernel.elf","kernel8.img","disassembly.txt")]))' "$b" > "$b/sites.txt"
 cp -r "$b" "$d/"
done
