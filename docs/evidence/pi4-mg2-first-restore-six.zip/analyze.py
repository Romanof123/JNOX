import json,sys
from pathlib import Path
import pi4_mg2_terminal as m
from pi4_migration_capture import sha, FLAGS
d=Path('/mnt/d/codex/smp204-cc864a3-iv')
for c in ('global','partitioned','clustered'):
 b=d/c; f=m.read_json(b/'freeze.json'); assert sha(b/'freeze.json')==(d/(c+'-build')/'freeze.digest').read_text().strip()
 for n in (1,2):
  p=b/f'first-{n}';s=m.read_json(p/'session.json');assert sha(p/'session.json')==(d/f'{c}-{n}.digest').read_text().strip()
  assert all(sha(p/k)==v for k,v in s['hashes'].items()) and all(sha(b/k)==v for k,v in f['hashes'].items())
  a=s['argv']; pre=[f['qemu'],*FLAGS];assert a[:len(pre)]==pre and a[len(pre)]=='-qmp' and a[len(pre)+1].endswith('/q.sock,server=on,wait=off') and a[len(pre)+2]=='-kernel' and a[-4:-1]==['-d','int,tid','-D']
  assert s['reason']=='terminal_quiet' and 10**9<=s['quiet_ns']<=s['elapsed_ns']<=30*10**9
  q=m.read_json(p/'qmp.json'); assert q['after']['status']=='paused' and q['before']['running'] and q['stop_before_ns']>=s['observation_monotonic_ns']['end']
  tids=m.read_json(p/'threads.json');assert all(tids[str(i['thread-id'])]==f"CPU {i['cpu-index']}/TCG" for i in q['cpus'])
  ram=m.rows_and_frames((p/'terminal-ram.bin').read_bytes(),f['ram'])
  obs=m.observations(p,s,f,ram); (d/f'{c}-{n}.analysis.json').write_text(json.dumps(dict(ram=ram,obs=obs),indent=2))
  print(c,n,obs['guest_result'],ram['last_pre_eret_per_cpu'],obs['external'],obs['M_local_pre_eret_to_terminal_svc'])
