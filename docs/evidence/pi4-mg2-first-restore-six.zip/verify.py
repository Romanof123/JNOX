import argparse, hashlib, importlib.util, io, json, os, re, sys, tempfile
from pathlib import Path
from zipfile import ZipFile
from elftools.elf.elffile import ELFFile
import pi4_mg2_terminal as m
from pi4_migration_capture import acquire,sha
from pi4_migration_replay import layout
d=Path('/mnt/d/codex/smp204-cc864a3-iv')
root=Path('results').resolve()
cases=['global','partitioned','clustered']
def write(path,data): path.write_text(json.dumps(data,indent=2))
if sys.argv[1]=='freeze':
 s=importlib.util.spec_from_file_location('old',d/'old.py'); old=importlib.util.module_from_spec(s);s.loader.exec_module(old)
 checks={}
 with ZipFile('docs/evidence/pi4-mg2-terminal-first.zip') as z:
  for c in cases:
   prefix='./cohort/migration-'+c+'/'
   elf=z.read(prefix+'kernel.elf'); scope=m.symbols_and_window(elf); assert scope==old.symbols_and_window(elf)
   for n in (1,2):
    raw=z.read(prefix+f'first-{n}/terminal-ram.bin')
    a=m.rows_and_frames(raw,scope); assert a==old.rows_and_frames(raw,scope)
    checks[f'archive-{c}-{n}']=[a['flags']['PEER_READY'],a['last_pre_eret_per_cpu'],hashlib.sha256(raw).hexdigest()]
 for c in cases:
  b=root/c; elf=(b/'kernel.elf').read_bytes(); scope=m.symbols_and_window(elf)
  addr,size=scope['symbols'][m.PUBLISHED_TICKS]; e=ELFFile(io.BytesIO(elf)); seg=next(s for s in e.iter_segments() if s['p_type']=='PT_LOAD' and s['p_vaddr']<=addr<s['p_vaddr']+s['p_memsz']); assert size==16 and addr%8==0 and addr>=seg['p_vaddr']+seg['p_filesz']
  dis=(b/'disassembly.txt').read_text()
  ret=dis.split('<sched_start_frame>:')[1].split('\n\n')[0]
  seq=['mov\tsp','elr_el1','spsr_el1','q30, q31','mpidr_el1','lsl #3','cntpct_el0','stlr\tx11, [x10]','ldp\tx0, x1','ldr\tx30','eret']
  idx=[ret.lower().index(i) for i in seq]; assert idx==sorted(idx) and ret.count('stlr')==1
  wait=dis.split('<jnox_kernel::pi4_migration::start>:')[1].split('\n\n')[0]
  block=re.search(r'([^\n]+adrp\tx8,[^\n]+\n[^\n]+add\tx8, x8, #0x[0-9a-f]+\n[^\n]+isb\n[^\n]+cntpct_el0.*?mov\tw0, #0x1c[^\n]*\n[^\n]+abort>)',wait,re.S)[1]
  pair=re.findall(r'adrp\tx8, ([0-9a-f]+)[^\n]*\n[^\n]+add\tx8, x8, #0x([0-9a-f]+)',block)[-1]; assert sum(int(x,16) for x in pair)==addr+8
  assert all(x in block for x in ('ldar\tx11','cbnz\tx11','ldarb','cntfrq_el0','lsl\tx12, x12, #2','b.cs'))
  sig=dis.split('<jnox_kernel::pi4_smp_bsp::signal>:')[1].split('\n\n')[0]; sgir=re.search(r'([0-9a-f]+):[^\n]+str\tw0, \[x8\]',sig)[1]
  checks[c]=dict(address=hex(addr),cpu1=hex(addr+8),sgir=sgir,strict=(root/(c+'-build')/'sites.txt').read_text(),restore=ret,wait=block)
  f=b/'freeze.json'; record=json.loads(f.read_text());record['ram']=scope;write(f,record);(root/(c+'-build')/'freeze.digest').write_text(sha(f)+'\n')
 write(d/'preflight.json',checks)
else:
 c=sys.argv[2]; n=int(sys.argv[3]);b=root/c; f=b/'freeze.json'; args=argparse.Namespace(directory=b,digest=(root/(c+'-build')/'freeze.digest').read_text().strip(),ordinal=n)
 with tempfile.TemporaryDirectory() as t: rc=acquire(args,m.TerminalRAM(Path(t)/'q.sock'))
 sys.exit(rc)
