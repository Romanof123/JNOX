set -eu
base=$HOME/jnox261-independent
dest=/mnt/d/codex/jnox261-independent
export PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH
export JNOX_EVIDENCE_DIR=$base/evidence
cd "$base/source"
sed -n '/^```sh$/,/^```$/{/^```/d;p;}' docs/deadline-owner-cap-plan.en-ko.md > "$base/recipe.sh"
cp "$base/recipe.sh" "$dest"
rustc -Vv > "$dest/toolchain"; which cargo >> "$dest/toolchain"
sh "$base/recipe.sh" > "$dest/recipe.stdout" 2>&1 &
pid=$!
while kill -0 "$pid" 2>/dev/null; do
 for dir in "$base"/evidence/owner*/ordinary*; do
  [ -d "$dir" ] || continue
  [ -f "$dir/terminal.rc" ] || continue
  case "$dir" in *-4-*) [ -f "$dir/supply-replay.rc" ] || continue;; esac
  dst=$dest/$(basename "$dir")
  [ -f "$dst/acquired.sha256" ] && continue
  mkdir -p "$dst"; cp "$dir"/* "$dst"; (cd "$dir"; sha256sum *) > "$dst/acquired.sha256"
 done
 sleep 1
done
rc=0;wait "$pid" || rc=$?; echo "$rc" > "$dest/recipe.rc"
for run in "$base"/evidence/owner*; do cp "$run/source-commit" "$dest"; for dir in "$run"/ordinary*; do dst=$dest/$(basename "$dir"); mkdir -p "$dst"; cp "$dir"/* "$dst"; (cd "$dir"; sha256sum *) > "$dst/acquired.sha256"; done; done
