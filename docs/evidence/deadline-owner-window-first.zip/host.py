from pathlib import Path
import subprocess as sp,itertools as it,json,os
base=Path(__file__).parent
src=Path.home()/'jnox261-independent/source'
tool=Path.home()/'jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc'
prog='#![allow(dead_code)]\n'+''.join(f'#[path="{src}/kernel/src/{n}.rs"] mod {n};\n' for n in ['ready_queue','deadline_policy','deadline_jobs'])+'''mod ordinary_deadline {pub fn counter()->u64{unreachable!()}}
use std::io::{self,BufRead};
fn main(){for line in io::stdin().lock().lines(){let l=line.unwrap();let v:Vec<u64>=l.split_whitespace().map(|s|s.parse().unwrap()).collect();println!("{:?}",deadline_jobs::owner_window_bound(v[0],v[1],v[2],v[3]));}}
'''
host=src.parent/'host';host.mkdir(exist_ok=True);(base/'bound_cli.rs').write_text(prog)
cmd=[str(tool),'--edition=2024','--cfg','jnox_ordinary_deadline']
for name,extra in [('author',['--test',str(src/'tools/deadline_supply_tests.rs')]),('oracle',[str(base/'bound_cli.rs')])]:
    sp.run(cmd+extra+['-o',str(host/name)],check=True)
with (base/'author-tests.log').open('w') as f:sp.run([str(host/'author')],stdout=f,check=True)
expect={}; windows=0;patterns=0
for q in range(1,5):
 for cells in range(1,4):
  D=q*cells
  for jobs in range(3):
   peak=[0]*(D+1)
   for times in it.product(*(range(k*q,(k+1)*q) for k in range(cells)),*([range(D)]*jobs)):
    patterns+=1
    for a in range(D):
     for b in range(a+1,D+1):
      windows+=1;peak[b-a]=max(peak[b-a],sum(a<=t<b for t in times))
   expect.update({(q,cells,w,jobs):f'Ok({peak[w]})' for w in range(1,D+1)})
m=2**64-1
expect.update({(0,1,1,0):'Err(Grid)',(1,0,1,0):'Err(Grid)',(2,1,0,0):'Err(Grid)',(2,1,3,0):'Err(Grid)',(m,2,1,0):'Err(Overflow)',(1,1,1,m):'Err(Overflow)',(1,m,m,0):f'Ok({m})',(m,1,m,1):'Ok(2)'})
r=sp.run([str(host/'oracle')],input=''.join(' '.join(map(str,k))+'\n' for k in expect),capture_output=True,text=True,check=True)
assert list(expect.values())==r.stdout.splitlines()
(base/'host-results.json').write_text(json.dumps(dict(patterns=patterns,windows=windows,cases=[dict(args=k,result=v) for k,v in expect.items()]),indent=2))
