from additional import base,arc,ls,sec,struct,json
audit={}
for r in ls:
    label=r['label']; n=next(n for n in arc.namelist() if n.endswith(label+'/kernel.elf'))
    old=arc.read(n);new=(base/'legacy'/label/'kernel.elf').read_bytes()
    o=sec(old)['.rodata'];c=sec(new)['.rodata'];assert o[:2]==c[:2];O=o[2];C=c[2];addr=o[0]
    dif={i for i,(x,y) in enumerate(zip(O,C)) if x!=y};remain=set(dif);matches=[]
    for a in range(0,len(O)-23,8):
        p,l,ol,col=struct.unpack_from('<QQII',O,a);np,nl,ne,nc=struct.unpack_from('<QQII',C,a)
        if p!=np or l!=nl or p<addr or p+l>addr+len(O) or l<1 or l>256:continue
        name=O[p-addr:p-addr+l]
        if not name.endswith(b'.rs') or col!=nc or ol==ne:continue
        matches.append([hex(addr+a),name.decode(),ol,ne,col]);remain.difference_update(range(a+16,a+20))
    audit[label]={'location_changes':matches,'unexplained_rodata_bytes':sorted(remain)}
(base/'legacy/locations.json').write_text(json.dumps(audit,indent=2))
print({k:len(v['unexplained_rodata_bytes']) for k,v in audit.items()})
