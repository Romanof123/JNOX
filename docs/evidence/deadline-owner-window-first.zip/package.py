from pathlib import Path
import hashlib,zipfile
base=Path(__file__).parent
files=sorted(p for p in base.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='SHA256-ALL')
sha=lambda b:hashlib.sha256(b).hexdigest()
(base/'SHA256-ALL').write_text(''.join(f'{sha(p.read_bytes())}  {p.relative_to(base).as_posix()}\n' for p in files))
out=base.with_suffix('.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for p in [*files,base/'SHA256-ALL']:z.write(p,p.relative_to(base))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for line in z.read('SHA256-ALL').decode().splitlines():
        h,n=line.split('  ',1);assert sha(z.read(n))==h
h=sha(out.read_bytes());print(h,out.stat().st_size);out.with_suffix('.zip.sha256').write_text(f'{h}  {out.name}\n')
