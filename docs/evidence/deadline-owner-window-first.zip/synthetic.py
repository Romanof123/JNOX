from itertools import product
from pathlib import Path
import json
count=0
for ticks in product(range(5), repeat=3):
    if list(ticks)!=sorted(ticks):continue
    for initial in [3]:
        for dest in product((0,1,3,4),repeat=3):
            owner=initial; changes=[]
            for index,(t,nxt) in enumerate(zip(ticks,dest)):
                if index+1<len(ticks):
                    if nxt!=owner:changes.append(t)
                    owner=nxt
            for w in range(1,6):
                all_windows=[sum(a<=t<a+w for t in changes) for a in range(6-w)]
                candidates={0,5-w}
                for t in changes:candidates.update(max(0,min(5-w,a)) for a in (t-w+1,t+1))
                assert max(all_windows)==max(sum(a<=t<a+w for t in changes) for a in candidates)
                count+=1
print(count,'synthetic peak comparisons passed, including repeated owners and terminal park')
