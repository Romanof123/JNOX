import re, json, sys
from pathlib import Path
base=Path(__file__).parent
def score(p):
    tags={}
    for line in (p/'uart.raw').read_text().splitlines():
        k,*v=line.split()
        if k in 'D J JOB CONFIG A_STOP A_PROGRESS RESULT OWNER_CAP OWNER_EVENT OWNER_PEAK SUPPLY OWNER_PRELAUNCH'.split():
            tags.setdefault(k,[]).append(list(map(int,v)))
    S,E,Q,jobs,bound,cap,accepted=tags['OWNER_CAP'][0]
    assert E==S+17*Q and bound==4 and jobs==2 and accepted==(cap==4)
    assert tags['OWNER_PRELAUNCH']==[[0]*4]
    ex=(p/'exceptions.log').read_text()
    if not accepted:
        assert not ex.strip() and not any(k in tags for k in ('D','J','OWNER_EVENT','RESULT','JOB'))
        return {'cap':cap,'exceptions':0}
    blocks=re.split(r'Taking exception \d+ \[(IRQ|SVC)\]',ex)
    pc=lambda x:int(x,16)
    eret=lambda s:[pc(x) for x in re.findall(r'Exception return .*? PC (0x[\da-f]+)',s)]
    assert len(eret(blocks[0]))==1
    ds=tags['D'];assert len(blocks)==1+2*len(ds)
    owners=[3]; emitted=[]; irqs=[]; svcs=[]; history={}; seen=set()
    for i,d in enumerate(ds):
        kind,slot,logical,grid,cmp,irq,restore,entry,counter,old,new,save,savepc,frame,framepc,*rest=d
        assert restore<entry<=counter and (not i or ds[i-1][8]<=restore)
        assert S<=entry<E and old==owners[-1] and save%16==frame%16==0
        k,log=blocks[1+2*i:3+2*i]
        assert k=={1:'IRQ',2:'SVC'}[kind] and pc(re.search(r'with ELR (0x[\da-f]+)',log)[1])==savepc
        history[old]=(save,savepc)
        if new in history: assert history[new]==(frame,framepc)
        if kind==1:
            assert irq==30 and grid==cmp==S+slot*Q and grid<=entry<grid+Q and slot not in seen
            seen.add(slot);irqs.append(entry)
        else:
            assert old in (0,1) and old not in [x[0] for x in svcs] and entry<grid
            assert entry < S+tags['JOB'][old][2]*Q
            svcs.append((old,entry))
        ret=eret(log);assert ret==([framepc] if i<len(ds)-1 else [])
        if ret:
            owners.append(new)
            if new!=old: emitted.append(entry)
        ev=tags['OWNER_EVENT'][i]
        assert ev[:7]==[i,kind,entry,old,new,int(bool(ret)),int(bool(ret) and old!=new)]
    def peak(times):
        starts={S,E-Q}
        for t in times:
            starts.update(max(S,min(E-Q,a)) for a in (t-Q+1,t+1))
        return max(sum(a<=t<a+Q for t in times) for a in starts)
    alltimes=sorted(irqs+[t for _,t in svcs]); result=[len(ds),len(emitted),peak(alltimes),peak(emitted),cap]
    assert tags['OWNER_PEAK']==[result] and peak(emitted)<=cap and len(svcs)==2
    rep=json.loads((p/'supply-replay.json').read_text()); assert rep['service_sum']==89440 and rep['worker_products']==tags['RESULT'][0][-2:]
    return dict(cap=cap,owners=owners,initial_pc=eret(blocks[0])[0],irq_entries=irqs,svc_entries=svcs,transfers=emitted,score=result,deadlines=[S+j[2]*Q for j in tags['JOB']],products=rep['worker_products'])
if __name__=='__main__':
    for d in sorted(base.glob('ordinary*')):
        print(json.dumps(dict(guest=d.name, **score(d))))

