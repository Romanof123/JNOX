from pathlib import Path
import json,zipfile,struct
base=Path(__file__).parent
archive=zipfile.ZipFile('/mnt/d/codex/jnox259260-baseline.zip')
for row in json.loads((base/'legacy/sections.json').read_text()):
    label=row['label'];name=next(n for n in archive.namelist() if n.endswith(label+'/kernel.elf'))
    old=archive.read(name);new=(base/'legacy'/label/'kernel.elf').read_bytes()
    ro=row['sections']['.rodata']; lower=ro['old_addr'];upper=lower+ro['old_size']; nd=0
    for i in range(int.from_bytes(old[56:58],'little')):
        h=old[64+56*i:120+56*i]
        if h[:4]!=b'\1\0\0\0':continue
        assert h==new[64+56*i:120+56*i]
        _,_,off,va,_,size,*_=struct.unpack('<II6Q',h)
        for ix,(x,y) in enumerate(zip(old[off:off+size],new[off:off+size])):
            if x!=y:assert lower<=ix+va<upper;nd+=1
    assert nd==ro['different_bytes']
print('All PT_LOAD headers equal. All changed PT_LOAD bytes lie in .rodata and the decoded locations account for all of them.')
