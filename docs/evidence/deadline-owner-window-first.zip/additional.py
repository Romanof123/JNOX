from pathlib import Path
import sys,struct,json,zipfile,hashlib,subprocess as sp
from score import score
base=Path(__file__).parent
def content(d):
    tags={}
    for l in (d/'uart.raw').read_text().splitlines():
        k,*v=l.split()
        if k!='ORDINARY' and k!='JNOX': tags.setdefault(k,[]).append(list(map(int,v)))
    return tags
def inspect(d):
    t=content(d); S,E,Q,*_=t['OWNER_CAP'][0]; HZ,origin,q,mode,over,ref,h,fsize=t['CONFIG'][0]
    assert (S,Q,h,fsize)==(origin,q,16,832)
    mask,full,tight,top,stack,servicepc=t['SUPPLY'][0];assert (mask,full,tight,ref)==(2,1,0,0)
    nm={}; sym=sp.check_output(['nm','-nS',str((base/d.name)/'kernel.elf')],text=True)
    for line in sym.splitlines():
        cols=line.split()
        if len(cols)>=3:nm[cols[-1]]=int(cols[0],16)
    idle=next(v for k,v in nm.items() if 'ordinary_deadline4idle' in k)
    stacks=next(v for k,v in nm.items() if 'ordinary_deadline6STACKS' in k)
    if 'D' not in t:return
    ds=t['D']; assert [j[:5] for j in t['JOB']]==[[0,0,5,2,250],[1,1,7,2,30]]
    if d.parent.name=='ram':
        app=d.name.split('-4-')[0]
        out=sp.check_output(['python3',str(Path.home()/'jnox261-independent/source/tools/deadline_supply_replay.py'),app,str(d/'uart.raw')]);(d/'supply-replay.json').write_bytes(out)
    assert score(d)['initial_pc']==idle
    assert t['A_STOP']==[[S+HZ//4]]
    assert all(j[6]==stacks+(j[0]+1)*stack for j in t['JOB'])
    entries=[]; changes=[];cost=[0]*3
    for i,row in enumerate(ds):
        kind,k,g,target,pg,irq,r,e,handler,old,new,fp,pc,dst,de,*_=row
        assert stacks+old*stack<=fp<=stacks+(old+1)*stack-fsize
        assert stacks+new*stack<=dst<=stacks+(new+1)*stack-fsize
        if i==0 or new not in [v[9] for v in ds[:i+1]]:
            if new<2: assert (dst,de)==(t['JOB'][new][6]-fsize,t['JOB'][new][5])
            if new==4: assert (dst,de)==(top-fsize,servicepc)
        if old<2:cost[old]+=e-r
        if kind==2:assert pc==nm['ordinary_deadline_after_svc']
        js=t['J'][3*i:3*i+3];assert [j[4] for j in js]==cost
        entries.append(e)
        if i<len(ds)-1 and old!=new:changes.append(e)
        assert t['OWNER_EVENT'][i][-2:]==[sum(e-Q<x<=e for x in xs) for xs in [entries,changes]]
    progress=[j[-1] for j in t['J'][-3:]]
    products=[]
    for seed,blocks in enumerate(progress[:2],1):
        a=pow(33,64*blocks,1<<69)
        products.append((seed*a+(a-1)//32)%2**64)
    assert t['RESULT'][0][2:]==products and t['RESULT'][0][0]==sum(i*i for i in range(1,65))
    assert t['A_PROGRESS'][0]==[t['J'][3][-1],t['J'][6][-1],progress[0]] and 0<t['J'][3][-1]<progress[0] and progress[1]>0
for p in [*base.glob('ordinary*'),*(base/'ram').glob('ordinary*')]:inspect(p)
def sec(b):
    off=struct.unpack_from('<Q',b,40)[0];n,st=struct.unpack_from('<HH',b,60)
    hdr=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*64) for i in range(n)]
    s=hdr[st];ns=b[s[4]:s[4]+s[5]]
    return {ns[h[0]:].split(b'\0',1)[0].decode():(h[3],h[5],b[h[4]:h[4]+h[5]] if h[1]!=8 else b'') for h in hdr}
arc=zipfile.ZipFile('/mnt/d/codex/jnox259260-baseline.zip');ls=json.loads((base/'legacy/results.json').read_text())
for r in ls:
    d=base/'legacy'/r['label']
    n=next(n for n in arc.namelist() if n.endswith(r['label']+'/kernel.elf'))
    a,b=sec(arc.read(n)),sec((d/'kernel.elf').read_bytes())
    r['sections']={k:dict(old_addr=a[k][0],new_addr=b[k][0],old_size=a[k][1],new_size=b[k][1],same_bytes=a[k][2]==b[k][2],different_bytes=sum(x!=y for x,y in zip(a[k][2],b[k][2]))+abs(len(a[k][2])-len(b[k][2]))) for k in a.keys()&b.keys() if k in ('.text','.rodata','.bss','.stack','.data')}
    assert r['rc']==124 and 'OWNER_' not in (d/'uart.raw').read_text() and r['last']==('ORDINARY DEADLINE REFUSED BEFORE LAUNCH' if '-refuse-' in r['label'] else 'ORDINARY DEADLINE FINISHED')
    if '-supply-' in r['label']:
        app,mode=r['label'].rsplit('-',1)
        cmd=['python3',str(Path.home()/'jnox261-independent/source/tools/deadline_supply_replay.py'),app,str(d/'uart.raw')]+(['--plain'] if mode=='plain' else [])
        rr=sp.run(cmd,capture_output=True);(d/'supply-replay.json').write_bytes(rr.stdout);assert rr.returncode==0,rr.stderr
(base/'legacy/sections.json').write_text(json.dumps(ls,indent=2))

