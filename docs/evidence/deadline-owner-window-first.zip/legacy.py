from pathlib import Path
import subprocess as s, os, hashlib, json, zipfile, shutil
base=Path('/mnt/d/codex/jnox261-independent')
src=Path.home()/'jnox261-independent/source'; target=src.parent/'legacy-target'
out=base/'legacy';out.mkdir(exist_ok=True)
archive=Path('/mnt/d/codex/jnox259260-baseline.zip')
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='e6b226c7e8f8d430bbe0167b437acbb7626d771eb090f28e2f7f71971861f20e'
arc=zipfile.ZipFile(archive)
sha=lambda b:hashlib.sha256(b).hexdigest()
prods=[]
for n in sorted(arc.namelist()):
    if not n.endswith('/kernel.elf') or 'ordinary-' not in n:continue
    label=Path(n).parent.name
    app,mode=label.rsplit('-',1);d=out/label;d.mkdir(exist_ok=True)
    e=dict(os.environ,PATH=str(Path.home()/'jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')+':/usr/bin:/bin',CARGO_TARGET_DIR=str(target),JNOX_PROFILE='deadline',JNOX_APP=app)
    if mode=='trace':e['JNOX_DEADLINE_TRACE']='1'
    cmd=['cargo','build','--release','--locked','--target','aarch64-unknown-none','-j','1'];r=s.run(cmd,cwd=src/'kernel',env=e,capture_output=True);(d/'build.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
    f=d/'kernel.elf';shutil.copyfile(target/'aarch64-unknown-none/release/jnox-kernel',f);old=arc.read(n)
    ph=lambda b:[b[int.from_bytes(h[8:16],'little'):int.from_bytes(h[8:16],'little')+int.from_bytes(h[32:40],'little')] for i in range(int.from_bytes(b[56:58],'little')) if (h:=b[64+56*i:120+56*i])[:4]==b'\1\0\0\0']
    new=f.read_bytes();row=dict(label=label,old=sha(old),new=sha(new),exact=old==new,loads=ph(old)==ph(new))
    cmd=['timeout','5s','qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-accel','tcg','-smp','1','-m','128M','-nographic','-nic','none','-monitor','none','-serial','stdio','-d','int','-D',str(d/'exceptions.log'),'-kernel',str(f)]
    r=s.run(cmd,stdin=s.DEVNULL,capture_output=True);(d/'uart.raw').write_bytes(r.stdout);(d/'qemu.stderr').write_bytes(r.stderr);row.update(rc=r.returncode,last=r.stdout.splitlines()[-1].decode() if r.stdout else '',qemu=cmd)
    prods.append(row);(out/'results.json').write_text(json.dumps(prods,indent=2));print(label,row['exact'],row['loads'],row['last'],flush=True)
assert len(prods)==16
