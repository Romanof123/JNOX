from pathlib import Path
import hashlib,json,zipfile
d=Path(__file__).parent
entries={}
for p in sorted(d.glob("ordinary*")):
    for l in (p/"acquired.sha256").read_text().splitlines():
        h,n=l.split("  ",1); f=p/n
        assert hashlib.sha256(f.read_bytes()).hexdigest()==h
        entries[f.relative_to(d).as_posix()]=h
assert len(list(d.glob("ordinary*")))==8
for n in ("recipe.sh","recipe.stdout","recipe.rc","source-commit","toolchain"):
    entries[n]=hashlib.sha256((d/n).read_bytes()).hexdigest()
(d/"first-matrix.json").write_text(json.dumps(entries,indent=2))
with zipfile.ZipFile(d/"first-matrix.zip","w",zipfile.ZIP_DEFLATED) as z:
    for n in [*entries,"first-matrix.json",*(p.relative_to(d).as_posix() for p in d.glob("ordinary*/acquired.sha256"))]: z.write(d/n,n)
