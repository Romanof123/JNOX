from pathlib import Path
import subprocess as s, os, time, socket, json, struct, re, sys
base=Path(__file__).parent
def probe(p):
    d=base/'ram'/p.name;d.mkdir(parents=True,exist_ok=True)
    txt=s.check_output(['nm','-nS',str(p/'kernel.elf')],text=True);(d/'nm.txt').write_text(txt)
    syms={}
    for line in txt.splitlines():
        part=line.split()
        if len(part)!=4:continue
        a,n,_,name=part
        for key in ('STACKS','deadline_restore_count','ordinary_deadline_rows','ordinary_deadline_row_count','PROGRESS','SERVICE_SUM','SERVICE_SP'):
            if key in name:syms[key]=(int(a,16),int(n,16))
    sock='/tmp/jnox261-ram.sock'
    if os.path.exists(sock): os.unlink(sock)
    cmd=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-accel','tcg','-smp','1','-m','128M','-nographic','-nic','none','-monitor','none','-serial','file:'+str(d/'uart.raw'),'-qmp','unix:'+sock+',server=on,wait=off','-d','int','-D',str(d/'exceptions.log'),'-kernel',str(p/'kernel.elf')]
    proc=s.Popen(cmd,stdin=s.DEVNULL,stdout=s.DEVNULL,stderr=(d/'qemu.stderr').open('wb'))
    try:
        deadline=time.monotonic()+10
        while time.monotonic()<deadline:
            if (d/'uart.raw').exists() and any((d/'uart.raw').read_bytes().rstrip().endswith(x) for x in [b'ORDINARY DEADLINE FINISHED',b'ORDINARY OWNER CAP REFUSED BEFORE LAUNCH']):break
            time.sleep(.05)
        else:raise RuntimeError('no terminal')
        time.sleep(.15)
        conn=socket.socket(socket.AF_UNIX);conn.connect(sock);f=conn.makefile('rwb',buffering=0);f.readline()
        def send(k,args=None):
            f.write((json.dumps(dict(execute=k,arguments=args or {}))+'\n').encode())
            while True:
                r=json.loads(f.readline())
                if 'return' in r:return r['return']
                if 'error' in r:raise Exception(r)
        send('qmp_capabilities');send('stop')
        for key,(a,n) in syms.items():
            send('pmemsave',dict(val=a,size=n,filename=str(d/(key+'.bin'))))
        send('quit');proc.wait(timeout=4)
        (d/'capture.json').write_text(json.dumps(dict(command=cmd,rc=proc.returncode,symbols=syms),indent=2))
    finally:
        if proc.poll() is None:proc.kill();proc.wait()
    get=lambda k:(d/(k+'.bin')).read_bytes()
    assert len(syms)==7
    if '-3-' in p.name:
        assert all(not any(get(k)) for k in syms);return
    fields=[l.split() for l in (d/'uart.raw').read_text().splitlines()]
    rows=[list(map(int,l[1:])) for l in fields if l[0]=='D']
    assert int.from_bytes(get('ordinary_deadline_row_count'),'little')==len(rows)
    blob=get('ordinary_deadline_rows')
    for i,row in enumerate(rows):
        assert list(struct.unpack_from('<19Q',blob,i*448))==row
    assert int.from_bytes(get('deadline_restore_count'),'little')==rows[-1][6]
    assert int.from_bytes(get('SERVICE_SUM'),'little')==sum(i*i for i in range(1,65))
    j=[list(map(int,l[1:])) for l in fields if l[0]=='J']
    for i in range(len(rows)):
        for k,x in enumerate(j[3*i:3*i+3]):
            at=i*448+160+96*k
            assert [int.from_bytes(blob[at+16*m:at+16*m+16],'little',signed=True) for m in range(6)]==x
    assert list(struct.unpack('<3Q',get('PROGRESS')))==[x[-1] for x in j[-3:]]
for p in sorted(base.glob('ordinary*')):
    probe(p); print(p.name,'RAM passed',flush=True)
