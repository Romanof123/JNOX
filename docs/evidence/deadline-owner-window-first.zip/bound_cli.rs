#![allow(dead_code)]
#[path="/home/ywcho/jnox261-independent/source/kernel/src/ready_queue.rs"] mod ready_queue;
#[path="/home/ywcho/jnox261-independent/source/kernel/src/deadline_policy.rs"] mod deadline_policy;
#[path="/home/ywcho/jnox261-independent/source/kernel/src/deadline_jobs.rs"] mod deadline_jobs;
mod ordinary_deadline {pub fn counter()->u64{unreachable!()}}
use std::io::{self,BufRead};
fn main(){for line in io::stdin().lock().lines(){let l=line.unwrap();let v:Vec<u64>=l.split_whitespace().map(|s|s.parse().unwrap()).collect();println!("{:?}",deadline_jobs::owner_window_bound(v[0],v[1],v[2],v[3]));}}
