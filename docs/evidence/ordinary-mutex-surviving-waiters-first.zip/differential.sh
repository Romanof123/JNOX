set -eu
w=$HOME/jnox295-independent-first
base=/mnt/d/codex/jnox295-independent-evidence
cd "$w"
mv src scored-src
mv target scored-target
mkdir src
tar -xf "$base/parent.tar" -C src
export PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH CARGO_TARGET_DIR=$w/target CARGO_BUILD_JOBS=1 PYTHONDONTWRITEBYTECODE=1
cd src/kernel
for p in pi ceiling; do
 d=$base/parent-diff/$p; mkdir -p "$d"
 JNOX_BOARD=virt JNOX_PROFILE=mutex JNOX_APP=ordinary-$p cargo build --locked --release -j1 > "$d/build.log" 2>&1
 cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" "$d/kernel.elf"
 for rev in parent scored; do
 k=$d/kernel.elf; [[ $rev != scored ]] || k=$base/elf/$p/kernel.elf
 aarch64-linux-gnu-readelf -W -ahlS "$k" > "$d/$rev-elf.txt"
 aarch64-linux-gnu-nm -nCS "$k" > "$d/$rev-symbols.txt"
 aarch64-linux-gnu-objdump -dC "$k" > "$d/$rev-linked.asm"
 done
done