from pathlib import Path
import re
from collections import defaultdict
root=Path(__file__).resolve().parent
na=2**64-1
asm=(root/'elf/survivors/linked.asm').read_text()
ins={int(a,16):b for a,b in re.findall(r'^\s*([0-9a-f]+):\s+[0-9a-f]{8}\s+([^\n]+)',asm,re.M)}
for mode in ['01-new-plain','02-new-traced']:
    d=root/mode
    raw=(d/'uart').read_text()
    assert raw.startswith('JNOX M1 BOOT\nJNOX M1 READY\n') and raw.endswith('SURVIVORS COMPLETE\n')
    sections=raw.split('SURVIVORS RAW 1\n')[1:]
    assert len(sections)==2
    external_pcs=[]; external_returns=[]; external_ops=[]; bounds=[]
    for n,part in enumerate(sections,1):
        fields=defaultdict(list)
        for line in part.split('SURVIVORS END')[0].splitlines():
            tag,*cols=line.split()
            fields[tag].append([int(c,16) for c in cols])
        a,b=(4,5) if n==1 else (5,4)
        e,r,s,t=fields['E'],fields['R'],fields['S'],fields['T'][0]
        assert fields['H']==[[n,0,20,20]] and len(e)==len(r)==20
        assert [v[0] for v in s]==list(range(6))
        for idx,lo,hi,size,entry in s:
            assert size==832 and entry in ins
            bounds.append((lo,hi))
        actor=[0,1,1,a,1,b,1,3,0,3,2,0,1,1,1,a,a,b,b,0]
        op=[1,1,6,1,6,1,1,3,5,4,4,2,2,2,4,2,4,2,4,4]
        sel=actor[1:]+[na]
        frame={v[0]:(v[2]-v[3],v[4],0x6700+v[0]) for v in s}
        assert r[0][:2]==list(frame[0][:2])
        aq=(a+1)*16+b+1
        wait=[0,0,0,a+1,a+1,aq,aq*16+2,(aq*16+2)*16+4,aq*16+2,aq*16+2,aq*16+2,aq,aq,b+1,b+1,0,0,0,0,0]
        ready=[1,1,0x12,1,0x12,1,0x13,3,0x13,1,0,1,1,16+a+1,1,16+b+1,1,1,0,0]
        for i,x in enumerate(e):
            assert (x[2],x[4],x[5],x[27],x[28])==(op[i],actor[i],sel[i],ready[i],wait[i])
            who=x[4]; lo,hi,size=s[who][1:4]
            assert x[6]%16==0 and lo<=x[6]<=hi-size and x[24]==who+1
            assert x[2]==5 or ins[x[7]-4].startswith('svc')
            assert r[i][2]<=x[0]<=x[1]
            frame[who]=tuple(x[j] for j in [6,7,9])
            if i<19:
                nxt=x[5]
                assert frame[nxt]==tuple(x[10:13]) and x[25]==nxt+1
                assert r[i+1][:2]==x[10:12] and r[i+1][2]>=x[1]
            if i in [11,13,15]:
                gr={11:1,13:a,15:b}[i]
                assert x[20]==gr and x[21:23]==list(frame[gr][:2]) and x[23]==0
                assert x[14+(i==11)]==gr
            external_pcs.append(x[7]); external_ops.append('IRQ' if x[2]==5 else 'SVC')
        external_returns += [v[1] for v in r]
        irq=e[8]
        assert e[7][14:19]==[1,0,56,2,0x20204030404] and irq[14:19]==[1,0,48,2,0x20204030202]
        assert t[0]==62500000 and t[2]-t[1]==62500 and t[3:6]==[30,5,t[2]] and t[6]>=t[2]
        assert t[6:9]==[irq[0],irq[6],irq[7]] and t[9:]==[0,irq[31],1] and 0<irq[31]<16384
        assert 0x40202f1c<=irq[7]<=0x40202f40
        assert e[10][10:12]==irq[6:8]
        for blocked,selected,result in [(7,8,1),(6,11,0),(3,14,0),(5,16,0)]:
            assert e[blocked][6:8]==e[selected][10:12] and e[selected][26]==result
        batch=[4194304,35651584]
        assert e[9][32:38]==irq[32:38] and e[9][38]==1 and e[10][39]==2176
        assert e[11][32:36]==batch+[0,0] and e[12][32:36]==batch*2
        val=4
        for i,(tag,row) in enumerate(zip((a,b),fields['WA'],strict=True)):
            lo,hi=s[tag][1:3]
            nxt=val*10+tag-3
            assert row[:4]==[n,i,tag,0] and lo<=row[4]<=hi
            assert row[5:]==batch+[i,val,i+1,nxt] and e[15+2*i][36:38]==[i+1,nxt]
            val=nxt
        assert fields['WP']==[[n,0,16384,*batch,*batch,2,val,1,2176]]
        for row,tag,result in zip(fields['WR'],[1,3],[0,1],strict=True):
            assert row[:3]==[n,tag,result] and s[tag][1]<=row[3]<=s[tag][2]
        print(mode,n,'IRQ chunks',t[10],'IRQ PC',hex(t[8]),'counter-target',t[6]-t[2],'writers',a,b,'report',val)
    assert all(x[1]<=y[0] for x,y in zip(sorted(bounds),sorted(bounds)[1:]))
    if 'traced' in mode:
        log=(d/'exceptions.log').read_text()
        assert external_pcs==[int(x,16) for x in re.findall(r'with ELR 0x(\w+)',log)]
        assert external_returns==[int(x,16) for x in re.findall(r'Exception return .*?PC 0x(\w+)',log)]
        assert external_ops==re.findall(r'Taking exception \d+ \[(.*?)\]',log)
