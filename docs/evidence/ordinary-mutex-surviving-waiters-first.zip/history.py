from pathlib import Path
import zipfile,hashlib
root=Path(__file__).resolve().parent
for cohort in ['ordinary-timed-chain-integration','ordinary-mutex-chain-fifo-integration','current']:
 z=None if cohort=='current' else zipfile.ZipFile(root/'source/docs/evidence'/f'{cohort}.zip')
 for i,p in enumerate(['pi','ceiling']):
  for j,m in enumerate(['plain','trace']):
   if z:
    raw=z.read(f'ordinary-{p}/{m}.uart')
   else:
    raw=(next(root.glob(f'{7+i*2+j:02d}-*'))/'uart').read_bytes()
   rows=[[int(v,16) for v in l.split()[1:]] for l in raw.splitlines() if l.startswith(b'E ')]
   h=next(l for l in raw.splitlines() if l.startswith(b'H ')).split()
   irq=next(r for r in rows if r[2]==5)
   print(cohort,p,m,'reason',int(h[2],16),'IRQ PC',hex(irq[7]),'chunks',irq[20],'in_work',irq[21],'uart sha256',hashlib.sha256(raw).hexdigest())
