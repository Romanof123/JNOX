from pathlib import Path
import re, copy
from collections import defaultdict
root=Path(__file__).resolve().parent/'fifo'
nil=2**64-1
asm=(root/'disassembly').read_text()
ins={int(a,16):op for a,op in re.findall(r'^\s*([0-9a-f]+):\s+[0-9a-f]{8}\s+([^\n]+)',asm,re.M)}
def read(mode):
    lines=(root/mode/'uart').read_text().splitlines()
    assert lines[:3]==['JNOX M1 BOOT','JNOX M1 READY','FIFO RAW 1'] and lines[-1]=='FIFO END'
    tags=defaultdict(list)
    for row in lines[3:-1]:
        t,*v=row.split()
        assert len(v)=={'H':3,'S':5,'J':23,'R':4}[t] and all(re.fullmatch('[0-9a-f]{16}',s) for s in v)
        tags[t].append([int(s,16) for s in v])
    return tags
def replay(raw,mode):
    J,R=raw['J'],raw['R']
    assert raw['H']==[[0,30,30]] and len(J)==len(R)==30
    stacks={(e,t):(lo,hi,pc) for e,t,lo,hi,pc in raw['S']}
    assert len(stacks)==len(raw['S'])==8
    bounds=sorted((lo,hi) for lo,hi,_ in stacks.values())
    assert all(a[1]<=b[0] for a,b in zip(bounds,bounds[1:]))
    for e,(a,b) in enumerate([(1,2),(2,1)],1):
        w,z=1<<a,1<<b
        ops=[7,1,5,3,1,3,1,2,6,2,4,6,2,4,4]
        actors=[nil,0,0,0,a,0,b,0,a,a,a,b,b,b,0]
        sel=[0,0,0,a,0,b,0,a,a,a,b,b,b,0,3]
        waits=[0,0,0,0,w,w,6,z,z,0,0,0,0,0,0]
        ready=[9,9,9,9|w,9,9|z,9,9|w,9|w,15,9|z,9|z,9|z,9,8]
        owner=[nil,0,0,0,0,0,0,a,a,b,b,b,nil,nil,nil]
        saved={}; count=value=0
        for i,j in enumerate(J[(e-1)*15:e*15]):
            epoch,n,op,arg,t,s,fr,pc,out,ret,x0,rm,wm,prio,own,done,grant,c,v,initial,result,prev_c,prev_v=j
            assert [epoch,n,op,t,s]==[e,(e-1)*15+i+1,ops[i],actors[i],sel[i]], 'dispatch or early return'
            assert arg==({3:a,5:b}.get(i,0))
            assert [wm,rm,own]==[waits[i],ready[i],owner[i]] and wm&rm==0
            assert prio==(0x70707 if 4<=i<=6 else 0x70702)
            assert grant=={7:a,9:b}.get(i,nil),'arrival-based handoff'
            assert done==(7 if i==14 else 6 if i==13 else w if i>=10 else 0)
            if t!=nil:
                lo,hi,_=stacks[e,t]
                assert fr%16==0 and lo<=fr<=hi-832 and ins[pc-4].startswith('svc')
                saved[t]=(fr,pc)
            else: assert fr==pc==nil
            lo,hi,entry=stacks[e,s]
            assert out%16==0 and lo<=out<=hi-832 and ret in ins
            assert (out,ret)==saved.get(s,(hi-832,entry)) and x0==0
            assert R[(e-1)*15+i][:3]==[(e-1)*15+i+1,out,ret]
            if op==5: value=4
            if op==6:
                assert own==t and [result,prev_c,prev_v]==[0,count,value]
                count+=1; value=10*value+t
            else: assert result==prev_c==prev_v==nil
            assert [c,v]==[count,value],'protected intermediate state'
            if op==1 and t in (1,2): assert pc==0x40202478 and initial==0
        assert count==2 and value==400+10*a+b
    assert all(x[3]<=y[3] for x,y in zip(R,R[1:]))
    if mode=='traced':
        log=(root/mode/'exceptions.log').read_text()
        returns=[int(x,16) for x in re.findall(r'^Exception return .* PC 0x([0-9a-f]+)$',log,re.M)]
        elrs=[int(x,16) for x in re.findall(r'^\.\.\.with ELR 0x([0-9a-f]+)$',log,re.M)]
        assert returns==[r[2] for r in R] and elrs==[j[7] for j in J if j[4]!=nil]
for mode in ['plain','traced']:
    rows=read(mode); replay(rows,mode)
    print(mode,'both epochs PASS: 4,41,412 and 4,42,421')
    for label,index,field,new in [('fixed-ID',22,16,1),('early return',21,5,1),('intermediate value',23,18,41)]:
        altered=copy.deepcopy(rows); altered['J'][index][field]=new
        try: replay(altered,mode)
        except AssertionError as why: print(mode,label,'REJECT',why)
        else: raise ValueError(label)
