import hashlib, sys, re, subprocess, tempfile
from pathlib import Path
from collections import defaultdict
root=Path(__file__).resolve().parent
def fields(p):
    rows=defaultdict(list)
    for line in p.read_text().splitlines()[3:-1]:
        tag,*values=line.split()
        rows[tag].append([int(v,16) for v in values])
    return rows
for mode in ('plain','trace'):
    d=root/'ordinary-chain'
    subprocess.run([sys.executable,str(root/'mutex_chain_replay.py'),str(d/(mode+'.uart'))],check=True)
    t=fields(d/(mode+'.uart')); events=t['E']; restores=t['R']
    assert [x[13] for x in events]==[3,3,13,5,13,5,1,3,3,3,1]
    assert [x[16:18] for x in events]==[[0,0],[0,0],[0,2],[8,2],[0,2],[0,2],[0,2],[0,0],[0,0],[0,0],[0,0]]
    frame={}
    for e in events:
        frame[e[4]]=(e[6],e[7],e[9])
        if e[5] in frame: assert frame[e[5]]==(e[10],e[11],e[12])
    if mode=='trace':
        log=(d/'exceptions.log').read_text()
        assert re.findall(r'Taking exception \d+ \[(.*?)\]',log)==['IRQ' if e[2]==5 else 'SVC' for e in events]+['SVC']
        assert [int(x,16) for x in re.findall(r'with ELR 0x(\w+)',log)]==[x[7] for x in events]+[0x40201ce0]
        assert [int(x,16) for x in re.findall(r'Exception return .*?PC 0x(\w+)',log)]==[x[1] for x in restores]
    irq=events[4]; timer=t['T'][0]
    print(mode,'progress',irq[20],'pc',hex(irq[7]),'target_to_irq_ticks',irq[0]-timer[2],flush=True)
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp); manifest=[]
    for i,(app,mode) in enumerate((app,mode) for app in ('ordinary-pi','ordinary-ceiling') for mode in ('plain','trace')):
        d=tmp/f'0{i}-{app}-{mode}'; d.mkdir()
        files={'uart':mode+'.uart'}
        if mode=='trace':files['external.log']='exceptions.log'
        for name,src in files.items():
            raw=(root/app/src).read_bytes(); (d/name).write_bytes(raw)
            manifest.append(f'{hashlib.sha256(raw).hexdigest()}  {d.name}/{name}')
        irq=next(e for e in fields(d/'uart')['E'] if e[2]==5)
        print(d.name,'IRQ PC',hex(irq[7]),flush=True)
    (tmp/'SHA256SUMS').write_text('\n'.join(manifest))
    subprocess.run([sys.executable,str(root/'control_replay.py'),str(tmp)],check=True)
