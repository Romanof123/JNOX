from pathlib import Path
import re,hashlib,zipfile,sys
root=Path(sys.argv[1])
for name in ("scheduling-release-cases.md","scheduling-release-cases.en.md"):
    p=root/"docs"/name
    row,=[line for line in p.read_text(encoding="utf-8").splitlines() if line.startswith("| POL-014 |")]
    target,=re.findall(r"\]\((evidence/ordinary-timed-chain-first[^)]*)\)",row)
    report=p.parent/target
    link,=re.findall(r"\]\((ordinary-timed-chain-first.zip)\)",report.read_text(encoding="utf-8"))
    z=report.parent/link
    digest=hashlib.sha256(z.read_bytes()).hexdigest()
    assert digest=="001d81b80f4e5635676bd6c2f13b31f03d4077e9ff132f226deec726f79353e7"
    assert digest in report.read_text(encoding="utf-8")
    with zipfile.ZipFile(z) as archive:
        assert sum(path.endswith(("/plain.uart","/trace.uart")) for path in archive.namelist())==6
        assert archive.testzip() is None
    print(name,target,link,digest)
