from pathlib import Path
import zipfile, hashlib
root=Path(__file__).resolve().parent
dest=root.with_suffix('.zip')
files=[]
for f in sorted(root.rglob('*')):
 if not f.is_file(): continue
 rel=f.relative_to(root); name=rel.as_posix()
 if name in ('source.tar','parent.tar','MANIFEST.sha256'):continue
 if rel.parts[0]=='source' and name not in {'source/kernel/src/'+s for s in ['ordinary_mutex_survivors.rs','ordinary_mutex_survivors_workers.rs','context.S','mutex_policy.rs','ready_queue.rs']}|{'source/docs/ordinary-mutex-surviving-waiters.en-ko.md','source/kernel/build.rs','source/kernel/src/main.rs'}:continue
 files.append((f,name))
manifest=''.join(f'{hashlib.sha256(f.read_bytes()).hexdigest()}  {n}\n' for f,n in files)
(root/'MANIFEST.sha256').write_bytes(manifest.encode())
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
 for f,name in files:z.write(f,name)
 z.write(root/'MANIFEST.sha256','MANIFEST.sha256')
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for line in z.read('MANIFEST.sha256').decode().splitlines():
  digest,n=line.split('  ',1)
  assert hashlib.sha256(z.read(n)).hexdigest()==digest
digest=hashlib.sha256(dest.read_bytes()).hexdigest()
dest.with_suffix('.zip.sha256').write_text(f'{digest}  {dest.name}\n')
print(dest, dest.stat().st_size, digest, 'files',len(files)+1)
