set -eu
base=/mnt/d/codex/jnox295-independent-evidence
w=$HOME/jnox295-independent-first
mkdir "$w"
cd "$w"
mkdir src
tar -xf "$base/source.tar" -C src
export PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH CARGO_TARGET_DIR=$w/target CARGO_BUILD_JOBS=1 PYTHONDONTWRITEBYTECODE=1
cd src/kernel
(rustc -vV; cargo -V; qemu-system-aarch64 --version; uname -a) > "$base/versions.txt"
for p in survivors chain fifo pi ceiling; do
 d=$base/elf/$p; mkdir -p "$d"
 JNOX_BOARD=virt JNOX_PROFILE=mutex JNOX_APP=ordinary-$p cargo build --locked --release -j1 > "$d/build.log" 2>&1
 cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" "$d/kernel.elf"
 aarch64-linux-gnu-objdump -dC "$d/kernel.elf" > "$d/linked.asm"
 aarch64-linux-gnu-nm -nC "$d/kernel.elf" > "$d/symbols.txt"
done
cd "$base"
sha256sum source.tar driver.sh elf/*/kernel.elf > prelaunch.sha256
i=0
for p in survivors chain fifo pi ceiling; do
 for m in plain traced; do
 i=$((i+1)); d=$(printf '%02d' "$i"); d=$(echo "$base/$d"-*)
 opts=(); [[ $m != traced ]] || opts=(-d int -D "$d/exceptions.log")
 cmd=(timeout -k 2s 15s qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -accel tcg -m 128M -nodefaults -display none -monitor none -serial stdio "${opts[@]}" -kernel "$base/elf/$p/kernel.elf")
 printf '%q ' "${cmd[@]}" > "$d/argv"
 date -u --iso-8601=ns > "$d/start"
 rc=0; "${cmd[@]}" </dev/null > "$d/uart" 2> "$d/stderr" || rc=$?
 echo "$rc" > "$d/status"; date -u --iso-8601=ns > "$d/end"
 done
done