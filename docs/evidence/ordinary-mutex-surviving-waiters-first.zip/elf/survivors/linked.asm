
/mnt/d/codex/jnox295-independent-evidence/elf/survivors/kernel.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000040200000 <_start>:
    40200000:	d5034fdf 	msr	daifset, #0xf
    40200004:	d5384240 	mrs	x0, currentel
    40200008:	f100101f 	cmp	x0, #0x4
    4020000c:	54000241 	b.ne	40200054 <_start+0x54>  // b.any
    40200010:	d50041bf 	msr	spsel, #0x1
    40200014:	58000260 	ldr	x0, 40200060 <_start+0x60>
    40200018:	9100001f 	mov	sp, x0
    4020001c:	d5381040 	mrs	x0, cpacr_el1
    40200020:	b26c0400 	orr	x0, x0, #0x300000
    40200024:	d5181040 	msr	cpacr_el1, x0
    40200028:	d5033fdf 	isb
    4020002c:	580001e0 	ldr	x0, 40200068 <_start+0x68>
    40200030:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    40200034:	f9000001 	str	x1, [x0]
    40200038:	580001c0 	ldr	x0, 40200070 <_start+0x70>
    4020003c:	580001e1 	ldr	x1, 40200078 <_start+0x78>
    40200040:	eb01001f 	cmp	x0, x1
    40200044:	54000062 	b.cs	40200050 <_start+0x50>  // b.hs, b.nlast
    40200048:	f800841f 	str	xzr, [x0], #8
    4020004c:	17fffffd 	b	40200040 <_start+0x40>
    40200050:	1400002e 	b	40200108 <jnox_kernel::kernel_main>
    40200054:	d503205f 	wfe
    40200058:	17ffffff 	b	40200054 <_start+0x54>
    4020005c:	00000000 	udf	#0
    40200060:	4023d580 	.word	0x4023d580
    40200064:	00000000 	.word	0x00000000
    40200068:	402052c0 	.word	0x402052c0
    4020006c:	00000000 	.word	0x00000000
    40200070:	402052c0 	.word	0x402052c0
    40200074:	00000000 	.word	0x00000000
    40200078:	40239580 	.word	0x40239580
    4020007c:	00000000 	.word	0x00000000

0000000040200080 <__rustc::rust_begin_unwind>:
    40200080:	d503205f 	wfe
    40200084:	17ffffff 	b	40200080 <__rustc::rust_begin_unwind>

0000000040200088 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>:
    40200088:	d10083ff 	sub	sp, sp, #0x20
    4020008c:	a9014ffe 	stp	x30, x19, [sp, #16]
    40200090:	f100143f 	cmp	x1, #0x5
    40200094:	540001c8 	b.hi	402000cc <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x44>  // b.pmore
    40200098:	aa0103f3 	mov	x19, x1
    4020009c:	f9400000 	ldr	x0, [x0]
    402000a0:	94000030 	bl	40200160 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907>
    402000a4:	36000140 	tbz	w0, #0, 402000cc <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x44>
    402000a8:	d348fc08 	lsr	x8, x0, #8
    402000ac:	d368fc09 	lsr	x9, x0, #40
    402000b0:	79001be9 	strh	w9, [sp, #12]
    402000b4:	b9000be8 	str	w8, [sp, #8]
    402000b8:	910023e8 	add	x8, sp, #0x8
    402000bc:	38736900 	ldrb	w0, [x8, x19]
    402000c0:	a9414ffe 	ldp	x30, x19, [sp, #16]
    402000c4:	910083ff 	add	sp, sp, #0x20
    402000c8:	d65f03c0 	ret
    402000cc:	9400026d 	bl	40200a80 <_ZN11jnox_kernel24ordinary_mutex_survivors7Runtime6choose28_$u7b$$u7b$closure$u7d$$u7d$28_$u7b$$u7b$closure$u7d$$u7d$17hbd19f1c9c23d3740E.llvm.13497221849890916907>

00000000402000d0 <jnox_kernel::uart_write>:
    402000d0:	b40001a1 	cbz	x1, 40200104 <jnox_kernel::uart_write+0x34>
    402000d4:	8b010008 	add	x8, x0, x1
    402000d8:	52800309 	mov	w9, #0x18                  	// #24
    402000dc:	72a12009 	movk	w9, #0x900, lsl #16
    402000e0:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    402000e4:	3840140b 	ldrb	w11, [x0], #1
    402000e8:	b940012c 	ldr	w12, [x9]
    402000ec:	3628006c 	tbz	w12, #5, 402000f8 <jnox_kernel::uart_write+0x28>
    402000f0:	d5033fdf 	isb
    402000f4:	17fffffd 	b	402000e8 <jnox_kernel::uart_write+0x18>
    402000f8:	b900014b 	str	w11, [x10]
    402000fc:	eb08001f 	cmp	x0, x8
    40200100:	54ffff21 	b.ne	402000e4 <jnox_kernel::uart_write+0x14>  // b.any
    40200104:	d65f03c0 	ret

0000000040200108 <jnox_kernel::kernel_main>:
    40200108:	b0000028 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    4020010c:	f9416108 	ldr	x8, [x8, #704]
    40200110:	b4000068 	cbz	x8, 4020011c <jnox_kernel::kernel_main+0x14>
    40200114:	d503205f 	wfe
    40200118:	17ffffff 	b	40200114 <jnox_kernel::kernel_main+0xc>
    4020011c:	f81f0ffe 	str	x30, [sp, #-16]!
    40200120:	52800608 	mov	w8, #0x30                  	// #48
    40200124:	72a12008 	movk	w8, #0x900, lsl #16
    40200128:	b900011f 	str	wzr, [x8]
    4020012c:	528001a9 	mov	w9, #0xd                   	// #13
    40200130:	5280002a 	mov	w10, #0x1                   	// #1
    40200134:	b81f4109 	stur	w9, [x8, #-12]
    40200138:	b81f810a 	stur	w10, [x8, #-8]
    4020013c:	52800c09 	mov	w9, #0x60                  	// #96
    40200140:	b81fc109 	stur	w9, [x8, #-4]
    40200144:	52802029 	mov	w9, #0x101                 	// #257
    40200148:	b9000109 	str	w9, [x8]
    4020014c:	d503201f 	nop
    40200150:	10024440 	adr	x0, 402049d8 <memset+0x154>
    40200154:	52800361 	mov	w1, #0x1b                  	// #27
    40200158:	97ffffde 	bl	402000d0 <jnox_kernel::uart_write>
    4020015c:	94000656 	bl	40201ab4 <jnox_kernel::ordinary_mutex_survivors::run>

0000000040200160 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907>:
    40200160:	d101c3ff 	sub	sp, sp, #0x70
    40200164:	f9002bfe 	str	x30, [sp, #80]
    40200168:	a9064ff4 	stp	x20, x19, [sp, #96]
    4020016c:	aa1f03e9 	mov	x9, xzr
    40200170:	9100800a 	add	x10, x0, #0x20
    40200174:	9103800b 	add	x11, x0, #0xe0
    40200178:	9105600c 	add	x12, x0, #0x158
    4020017c:	9100e00d 	add	x13, x0, #0x38
    40200180:	52a0002e 	mov	w14, #0x10000               	// #65536
    40200184:	9100a3ef 	add	x15, sp, #0x28
    40200188:	aa1f03f2 	mov	x18, xzr
    4020018c:	8b091550 	add	x16, x10, x9, lsl #5
    40200190:	aa0d03f1 	mov	x17, x13
    40200194:	52800201 	mov	w1, #0x10                  	// #16
    40200198:	8b120208 	add	x8, x16, x18
    4020019c:	91004252 	add	x18, x18, #0x10
    402001a0:	f9400102 	ldr	x2, [x8]
    402001a4:	f100045f 	cmp	x2, #0x1
    402001a8:	540000e1 	b.ne	402001c4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x64>  // b.any
    402001ac:	f9400508 	ldr	x8, [x8, #8]
    402001b0:	f100051f 	cmp	x8, #0x1
    402001b4:	540015e8 	b.hi	40200470 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x310>  // b.pmore
    402001b8:	8b080c08 	add	x8, x0, x8, lsl #3
    402001bc:	39451102 	ldrb	w2, [x8, #324]
    402001c0:	370000e2 	tbnz	w2, #0, 402001dc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x7c>
    402001c4:	d1004021 	sub	x1, x1, #0x10
    402001c8:	91004231 	add	x17, x17, #0x10
    402001cc:	f100825f 	cmp	x18, #0x20
    402001d0:	54fffe41 	b.ne	40200198 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x38>  // b.any
    402001d4:	2a1f03f1 	mov	w17, wzr
    402001d8:	14000016 	b	40200230 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0xd0>
    402001dc:	39451510 	ldrb	w16, [x8, #325]
    402001e0:	f100825f 	cmp	x18, #0x20
    402001e4:	54000240 	b.eq	4020022c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0xcc>  // b.none
    402001e8:	d344fc32 	lsr	x18, x1, #4
    402001ec:	f85f8228 	ldur	x8, [x17, #-8]
    402001f0:	f100051f 	cmp	x8, #0x1
    402001f4:	54000161 	b.ne	40200220 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0xc0>  // b.any
    402001f8:	f9400228 	ldr	x8, [x17]
    402001fc:	f100051f 	cmp	x8, #0x1
    40200200:	54001388 	b.hi	40200470 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x310>  // b.pmore
    40200204:	8b080c08 	add	x8, x0, x8, lsl #3
    40200208:	39451101 	ldrb	w1, [x8, #324]
    4020020c:	360000a1 	tbz	w1, #0, 40200220 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0xc0>
    40200210:	39451508 	ldrb	w8, [x8, #325]
    40200214:	12001e10 	and	w16, w16, #0xff
    40200218:	6b08021f 	cmp	w16, w8
    4020021c:	1a888210 	csel	w16, w16, w8, hi  // hi = pmore
    40200220:	f1000652 	subs	x18, x18, #0x1
    40200224:	91004231 	add	x17, x17, #0x10
    40200228:	54fffe21 	b.ne	402001ec <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x8c>  // b.any
    4020022c:	52800031 	mov	w17, #0x1                   	// #1
    40200230:	8b091168 	add	x8, x11, x9, lsl #4
    40200234:	f9400112 	ldr	x18, [x8]
    40200238:	f100065f 	cmp	x18, #0x1
    4020023c:	540000e1 	b.ne	40200258 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0xf8>  // b.any
    40200240:	f9400508 	ldr	x8, [x8, #8]
    40200244:	f100051f 	cmp	x8, #0x1
    40200248:	540011e8 	b.hi	40200484 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x324>  // b.pmore
    4020024c:	8b080c12 	add	x18, x0, x8, lsl #3
    40200250:	39451252 	ldrb	w18, [x18, #324]
    40200254:	36000092 	tbz	w18, #0, 40200264 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x104>
    40200258:	38696988 	ldrb	w8, [x12, x9]
    4020025c:	d3607d08 	lsl	x8, x8, #32
    40200260:	1400000b 	b	4020028c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x12c>
    40200264:	8b081008 	add	x8, x0, x8, lsl #4
    40200268:	b9400112 	ldr	w18, [x8]
    4020026c:	f9400508 	ldr	x8, [x8, #8]
    40200270:	38696981 	ldrb	w1, [x12, x9]
    40200274:	53081d08 	lsl	w8, w8, #24
    40200278:	7100025f 	cmp	w18, #0x0
    4020027c:	9a9f1108 	csel	x8, x8, xzr, ne  // ne = any
    40200280:	aa018108 	orr	x8, x8, x1, lsl #32
    40200284:	9a9f11d2 	csel	x18, x14, xzr, ne  // ne = any
    40200288:	aa120108 	orr	x8, x8, x18
    4020028c:	12001e10 	and	w16, w16, #0xff
    40200290:	2a1103f1 	mov	w17, w17
    40200294:	aa102230 	orr	x16, x17, x16, lsl #8
    40200298:	8b090931 	add	x17, x9, x9, lsl #2
    4020029c:	8b1101f1 	add	x17, x15, x17
    402002a0:	8b080208 	add	x8, x16, x8
    402002a4:	39000228 	strb	w8, [x17]
    402002a8:	d358fd10 	lsr	x16, x8, #24
    402002ac:	39000e30 	strb	w16, [x17, #3]
    402002b0:	d350fd10 	lsr	x16, x8, #16
    402002b4:	39000a30 	strb	w16, [x17, #2]
    402002b8:	d348fd10 	lsr	x16, x8, #8
    402002bc:	d360fd08 	lsr	x8, x8, #32
    402002c0:	39000630 	strb	w16, [x17, #1]
    402002c4:	39001228 	strb	w8, [x17, #4]
    402002c8:	91000529 	add	x9, x9, #0x1
    402002cc:	910081ad 	add	x13, x13, #0x20
    402002d0:	f100193f 	cmp	x9, #0x6
    402002d4:	54fff5a1 	b.ne	40200188 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x28>  // b.any
    402002d8:	528003d3 	mov	w19, #0x1e                  	// #30
    402002dc:	91002bf4 	add	x20, sp, #0xa
    402002e0:	91002be0 	add	x0, sp, #0xa
    402002e4:	9100a3e1 	add	x1, sp, #0x28
    402002e8:	528003c2 	mov	w2, #0x1e                  	// #30
    402002ec:	940010e3 	bl	40204678 <memcpy>
    402002f0:	79009bff 	strh	wzr, [sp, #76]
    402002f4:	b9004bff 	str	wzr, [sp, #72]
    402002f8:	7900bbff 	strh	wzr, [sp, #92]
    402002fc:	b9005bff 	str	wzr, [sp, #88]
    40200300:	79005bff 	strh	wzr, [sp, #44]
    40200304:	91000a88 	add	x8, x20, #0x2
    40200308:	910123e9 	add	x9, sp, #0x48
    4020030c:	910163ea 	add	x10, sp, #0x58
    40200310:	b9002bff 	str	wzr, [sp, #40]
    40200314:	3940090b 	ldrb	w11, [x8, #2]
    40200318:	385ff10c 	ldurb	w12, [x8, #-1]
    4020031c:	385fe10d 	ldurb	w13, [x8, #-2]
    40200320:	6b0b019f 	cmp	w12, w11
    40200324:	1a8b818c 	csel	w12, w12, w11, hi  // hi = pmore
    40200328:	710001bf 	cmp	w13, #0x0
    4020032c:	1a8b118b 	csel	w11, w12, w11, ne  // ne = any
    40200330:	3900012b 	strb	w11, [x9]
    40200334:	3940010b 	ldrb	w11, [x8]
    40200338:	7100057f 	cmp	w11, #0x1
    4020033c:	540000e1 	b.ne	40200358 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x1f8>  // b.any
    40200340:	3940050b 	ldrb	w11, [x8, #1]
    40200344:	f100157f 	cmp	x11, #0x5
    40200348:	54000808 	b.hi	40200448 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x2e8>  // b.pmore
    4020034c:	386b694c 	ldrb	w12, [x10, x11]
    40200350:	1100058c 	add	w12, w12, #0x1
    40200354:	382b694c 	strb	w12, [x10, x11]
    40200358:	91001508 	add	x8, x8, #0x5
    4020035c:	91000529 	add	x9, x9, #0x1
    40200360:	f1001673 	subs	x19, x19, #0x5
    40200364:	54fffd81 	b.ne	40200314 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x1b4>  // b.any
    40200368:	aa1f03e0 	mov	x0, xzr
    4020036c:	aa1f03e8 	mov	x8, xzr
    40200370:	910163e9 	add	x9, sp, #0x58
    40200374:	9100a3ea 	add	x10, sp, #0x28
    40200378:	3868692b 	ldrb	w11, [x9, x8]
    4020037c:	350000ab 	cbnz	w11, 40200390 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x230>
    40200380:	f100181f 	cmp	x0, #0x6
    40200384:	54000962 	b.cs	402004b0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x350>  // b.hs, b.nlast
    40200388:	38206948 	strb	w8, [x10, x0]
    4020038c:	91000400 	add	x0, x0, #0x1
    40200390:	91000508 	add	x8, x8, #0x1
    40200394:	f100191f 	cmp	x8, #0x6
    40200398:	54ffff01 	b.ne	40200378 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x218>  // b.any
    4020039c:	b40005a0 	cbz	x0, 40200450 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x2f0>
    402003a0:	aa1f03ea 	mov	x10, xzr
    402003a4:	9100a3eb 	add	x11, sp, #0x28
    402003a8:	91002bec 	add	x12, sp, #0xa
    402003ac:	910123ed 	add	x13, sp, #0x48
    402003b0:	910163ee 	add	x14, sp, #0x58
    402003b4:	f100195f 	cmp	x10, #0x6
    402003b8:	54000740 	b.eq	402004a0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x340>  // b.none
    402003bc:	386a6969 	ldrb	w9, [x11, x10]
    402003c0:	f100193f 	cmp	x9, #0x6
    402003c4:	54000662 	b.cs	40200490 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x330>  // b.hs, b.nlast
    402003c8:	8b090928 	add	x8, x9, x9, lsl #2
    402003cc:	8b080188 	add	x8, x12, x8
    402003d0:	3940090f 	ldrb	w15, [x8, #2]
    402003d4:	3600024f 	tbz	w15, #0, 4020041c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x2bc>
    402003d8:	39400d08 	ldrb	w8, [x8, #3]
    402003dc:	f100191f 	cmp	x8, #0x6
    402003e0:	540006e2 	b.cs	402004bc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x35c>  // b.hs, b.nlast
    402003e4:	386869af 	ldrb	w15, [x13, x8]
    402003e8:	386969a9 	ldrb	w9, [x13, x9]
    402003ec:	386869d0 	ldrb	w16, [x14, x8]
    402003f0:	6b0f013f 	cmp	w9, w15
    402003f4:	51000610 	sub	w16, w16, #0x1
    402003f8:	1a8f8129 	csel	w9, w9, w15, hi  // hi = pmore
    402003fc:	382869a9 	strb	w9, [x13, x8]
    40200400:	72001e1f 	tst	w16, #0xff
    40200404:	382869d0 	strb	w16, [x14, x8]
    40200408:	540000a1 	b.ne	4020041c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x2bc>  // b.any
    4020040c:	f100141f 	cmp	x0, #0x5
    40200410:	540005e8 	b.hi	402004cc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x36c>  // b.pmore
    40200414:	38206968 	strb	w8, [x11, x0]
    40200418:	91000400 	add	x0, x0, #0x1
    4020041c:	9100054a 	add	x10, x10, #0x1
    40200420:	eb00015f 	cmp	x10, x0
    40200424:	54fffc83 	b.cc	402003b4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x254>  // b.lo, b.ul, b.last
    40200428:	f100195f 	cmp	x10, #0x6
    4020042c:	1a9f17e8 	cset	w8, eq  // eq = none
    40200430:	79409be9 	ldrh	w9, [sp, #76]
    40200434:	b9404bea 	ldr	w10, [sp, #72]
    40200438:	d378dd4a 	lsl	x10, x10, #8
    4020043c:	aa09a149 	orr	x9, x10, x9, lsl #40
    40200440:	9a9f0129 	csel	x9, x9, xzr, eq  // eq = none
    40200444:	14000005 	b	40200458 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x2f8>
    40200448:	aa1f03e0 	mov	x0, xzr
    4020044c:	14000005 	b	40200460 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x300>
    40200450:	2a1f03e8 	mov	w8, wzr
    40200454:	aa1f03e9 	mov	x9, xzr
    40200458:	2a0803e8 	mov	w8, w8
    4020045c:	aa080120 	orr	x0, x9, x8
    40200460:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40200464:	f9402bfe 	ldr	x30, [sp, #80]
    40200468:	9101c3ff 	add	sp, sp, #0x70
    4020046c:	d65f03c0 	ret
    40200470:	d503201f 	nop
    40200474:	10023622 	adr	x2, 40204b38 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.1.llvm.13497221849890916907+0x2e>
    40200478:	aa0803e0 	mov	x0, x8
    4020047c:	52800041 	mov	w1, #0x2                   	// #2
    40200480:	94000cd1 	bl	402037c4 <core::panicking::panic_bounds_check>
    40200484:	d503201f 	nop
    40200488:	100234c2 	adr	x2, 40204b20 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.1.llvm.13497221849890916907+0x16>
    4020048c:	17fffffb 	b	40200478 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x318>
    40200490:	d503201f 	nop
    40200494:	10023ee2 	adr	x2, 40204c70 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.14.llvm.13497221849890916907+0x30>
    40200498:	aa0903e0 	mov	x0, x9
    4020049c:	1400000e 	b	402004d4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x374>
    402004a0:	d503201f 	nop
    402004a4:	10023da2 	adr	x2, 40204c58 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.14.llvm.13497221849890916907+0x18>
    402004a8:	528000c0 	mov	w0, #0x6                   	// #6
    402004ac:	1400000a 	b	402004d4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x374>
    402004b0:	d503201f 	nop
    402004b4:	10024022 	adr	x2, 40204cb8 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.14.llvm.13497221849890916907+0x78>
    402004b8:	14000007 	b	402004d4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x374>
    402004bc:	d503201f 	nop
    402004c0:	10023e42 	adr	x2, 40204c88 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.14.llvm.13497221849890916907+0x48>
    402004c4:	aa0803e0 	mov	x0, x8
    402004c8:	14000003 	b	402004d4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907+0x374>
    402004cc:	d503201f 	nop
    402004d0:	10023e82 	adr	x2, 40204ca0 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.14.llvm.13497221849890916907+0x60>
    402004d4:	528000c1 	mov	w1, #0x6                   	// #6
    402004d8:	94000cbb 	bl	402037c4 <core::panicking::panic_bounds_check>

00000000402004dc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17hee72c2801fa4e836E.llvm.13497221849890916907>:
    402004dc:	f81f0ffe 	str	x30, [sp, #-16]!
    402004e0:	f100143f 	cmp	x1, #0x5
    402004e4:	540003e8 	b.hi	40200560 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17hee72c2801fa4e836E.llvm.13497221849890916907+0x84>  // b.pmore
    402004e8:	8b010008 	add	x8, x0, x1
    402004ec:	39457908 	ldrb	w8, [x8, #350]
    402004f0:	f100191f 	cmp	x8, #0x6
    402004f4:	540003e2 	b.cs	40200570 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17hee72c2801fa4e836E.llvm.13497221849890916907+0x94>  // b.hs, b.nlast
    402004f8:	8b081008 	add	x8, x0, x8, lsl #4
    402004fc:	f900711f 	str	xzr, [x8, #224]
    40200500:	f940a80a 	ldr	x10, [x0, #336]
    40200504:	d1000548 	sub	x8, x10, #0x1
    40200508:	f900a808 	str	x8, [x0, #336]
    4020050c:	eb08003f 	cmp	x1, x8
    40200510:	540001a2 	b.cs	40200544 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17hee72c2801fa4e836E.llvm.13497221849890916907+0x68>  // b.hs, b.nlast
    40200514:	8b000028 	add	x8, x1, x0
    40200518:	91057d09 	add	x9, x8, #0x15f
    4020051c:	aa2103e8 	mvn	x8, x1
    40200520:	cb0a03ea 	neg	x10, x10
    40200524:	b100191f 	cmn	x8, #0x6
    40200528:	54000120 	b.eq	4020054c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17hee72c2801fa4e836E.llvm.13497221849890916907+0x70>  // b.none
    4020052c:	3940012b 	ldrb	w11, [x9]
    40200530:	381ff12b 	sturb	w11, [x9, #-1]
    40200534:	91000529 	add	x9, x9, #0x1
    40200538:	d1000508 	sub	x8, x8, #0x1
    4020053c:	eb08015f 	cmp	x10, x8
    40200540:	54ffff21 	b.ne	40200524 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17hee72c2801fa4e836E.llvm.13497221849890916907+0x48>  // b.any
    40200544:	f84107fe 	ldr	x30, [sp], #16
    40200548:	d65f03c0 	ret
    4020054c:	cb0803e0 	neg	x0, x8
    40200550:	d503201f 	nop
    40200554:	10023222 	adr	x2, 40204b98 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.7.llvm.13497221849890916907>
    40200558:	528000c1 	mov	w1, #0x6                   	// #6
    4020055c:	94000c9a 	bl	402037c4 <core::panicking::panic_bounds_check>
    40200560:	d503201f 	nop
    40200564:	10023022 	adr	x2, 40204b68 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.5.llvm.13497221849890916907>
    40200568:	aa0103e0 	mov	x0, x1
    4020056c:	17fffffb 	b	40200558 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17hee72c2801fa4e836E.llvm.13497221849890916907+0x7c>
    40200570:	d503201f 	nop
    40200574:	10023062 	adr	x2, 40204b80 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.6.llvm.13497221849890916907>
    40200578:	aa0803e0 	mov	x0, x8
    4020057c:	17fffff7 	b	40200558 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17hee72c2801fa4e836E.llvm.13497221849890916907+0x7c>

0000000040200580 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17hcc00d34e95a61f80E.llvm.13497221849890916907>:
    40200580:	f81f0ffe 	str	x30, [sp, #-16]!
    40200584:	91038009 	add	x9, x0, #0xe0
    40200588:	528000ea 	mov	w10, #0x7                   	// #7
    4020058c:	f100054a 	subs	x10, x10, #0x1
    40200590:	54000240 	b.eq	402005d8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17hcc00d34e95a61f80E.llvm.13497221849890916907+0x58>  // b.none
    40200594:	eb01005f 	cmp	x2, x1
    40200598:	54000200 	b.eq	402005d8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17hcc00d34e95a61f80E.llvm.13497221849890916907+0x58>  // b.none
    4020059c:	f100145f 	cmp	x2, #0x5
    402005a0:	54000228 	b.hi	402005e4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17hcc00d34e95a61f80E.llvm.13497221849890916907+0x64>  // b.pmore
    402005a4:	8b021128 	add	x8, x9, x2, lsl #4
    402005a8:	f940010b 	ldr	x11, [x8]
    402005ac:	f100057f 	cmp	x11, #0x1
    402005b0:	54000101 	b.ne	402005d0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17hcc00d34e95a61f80E.llvm.13497221849890916907+0x50>  // b.any
    402005b4:	f9400508 	ldr	x8, [x8, #8]
    402005b8:	f100091f 	cmp	x8, #0x2
    402005bc:	54000202 	b.cs	402005fc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17hcc00d34e95a61f80E.llvm.13497221849890916907+0x7c>  // b.hs, b.nlast
    402005c0:	8b081008 	add	x8, x0, x8, lsl #4
    402005c4:	b940010b 	ldr	w11, [x8]
    402005c8:	f9400502 	ldr	x2, [x8, #8]
    402005cc:	3707fe0b 	tbnz	w11, #0, 4020058c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17hcc00d34e95a61f80E.llvm.13497221849890916907+0xc>
    402005d0:	2a1f03e0 	mov	w0, wzr
    402005d4:	14000002 	b	402005dc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17hcc00d34e95a61f80E.llvm.13497221849890916907+0x5c>
    402005d8:	52800020 	mov	w0, #0x1                   	// #1
    402005dc:	f84107fe 	ldr	x30, [sp], #16
    402005e0:	d65f03c0 	ret
    402005e4:	d503201f 	nop
    402005e8:	10022e48 	adr	x8, 40204bb0 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.8.llvm.13497221849890916907>
    402005ec:	aa0203e0 	mov	x0, x2
    402005f0:	528000c1 	mov	w1, #0x6                   	// #6
    402005f4:	aa0803e2 	mov	x2, x8
    402005f8:	94000c73 	bl	402037c4 <core::panicking::panic_bounds_check>
    402005fc:	d503201f 	nop
    40200600:	10022e42 	adr	x2, 40204bc8 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.9.llvm.13497221849890916907>
    40200604:	aa0803e0 	mov	x0, x8
    40200608:	52800041 	mov	w1, #0x2                   	// #2
    4020060c:	94000c6e 	bl	402037c4 <core::panicking::panic_bounds_check>

0000000040200610 <jnox_kernel::mutex_policy::LockSet<_,_>::new>:
    40200610:	d10503ff 	sub	sp, sp, #0x140
    40200614:	f90093fd 	str	x29, [sp, #288]
    40200618:	a9134ffe 	stp	x30, x19, [sp, #304]
    4020061c:	aa0803f3 	mov	x19, x8
    40200620:	aa1f03e8 	mov	x8, xzr
    40200624:	b9012be0 	str	w0, [sp, #296]
    40200628:	d360fc09 	lsr	x9, x0, #32
    4020062c:	79025be9 	strh	w9, [sp, #300]
    40200630:	9104a3e9 	add	x9, sp, #0x128
    40200634:	8b08002b 	add	x11, x1, x8
    40200638:	b940016a 	ldr	w10, [x11]
    4020063c:	5100054c 	sub	w12, w10, #0x1
    40200640:	7100fd9f 	cmp	w12, #0x3f
    40200644:	54000742 	b.cs	4020072c <jnox_kernel::mutex_policy::LockSet<_,_>::new+0x11c>  // b.hs, b.nlast
    40200648:	3940116c 	ldrb	w12, [x11, #4]
    4020064c:	7100059f 	cmp	w12, #0x1
    40200650:	540001a1 	b.ne	40200684 <jnox_kernel::mutex_policy::LockSet<_,_>::new+0x74>  // b.any
    40200654:	aa1f03ec 	mov	x12, xzr
    40200658:	3940156b 	ldrb	w11, [x11, #5]
    4020065c:	f100199f 	cmp	x12, #0x6
    40200660:	54000120 	b.eq	40200684 <jnox_kernel::mutex_policy::LockSet<_,_>::new+0x74>  // b.none
    40200664:	aa0c03ed 	mov	x13, x12
    40200668:	9100058c 	add	x12, x12, #0x1
    4020066c:	1acd254e 	lsr	w14, w10, w13
    40200670:	3607ff6e 	tbz	w14, #0, 4020065c <jnox_kernel::mutex_policy::LockSet<_,_>::new+0x4c>
    40200674:	386d692d 	ldrb	w13, [x9, x13]
    40200678:	6b0b01bf 	cmp	w13, w11
    4020067c:	54000588 	b.hi	4020072c <jnox_kernel::mutex_policy::LockSet<_,_>::new+0x11c>  // b.pmore
    40200680:	17fffff7 	b	4020065c <jnox_kernel::mutex_policy::LockSet<_,_>::new+0x4c>
    40200684:	91002108 	add	x8, x8, #0x8
    40200688:	f100411f 	cmp	x8, #0x10
    4020068c:	54fffd41 	b.ne	40200634 <jnox_kernel::mutex_policy::LockSet<_,_>::new+0x24>  // b.any
    40200690:	aa1f03e8 	mov	x8, xzr
    40200694:	910003e9 	mov	x9, sp
    40200698:	8b08012a 	add	x10, x9, x8
    4020069c:	f900015f 	str	xzr, [x10]
    402006a0:	f900095f 	str	xzr, [x10, #16]
    402006a4:	91008108 	add	x8, x8, #0x20
    402006a8:	f103011f 	cmp	x8, #0xc0
    402006ac:	54ffff61 	b.ne	40200698 <jnox_kernel::mutex_policy::LockSet<_,_>::new+0x88>  // b.any
    402006b0:	aa1f03e8 	mov	x8, xzr
    402006b4:	910303e9 	add	x9, sp, #0xc0
    402006b8:	f828693f 	str	xzr, [x9, x8]
    402006bc:	91004108 	add	x8, x8, #0x10
    402006c0:	f101811f 	cmp	x8, #0x60
    402006c4:	54ffffa1 	b.ne	402006b8 <jnox_kernel::mutex_policy::LockSet<_,_>::new+0xa8>  // b.any
    402006c8:	b9412be8 	ldr	w8, [sp, #296]
    402006cc:	b9015a68 	str	w8, [x19, #344]
    402006d0:	79425be8 	ldrh	w8, [sp, #300]
    402006d4:	7902ba68 	strh	w8, [x19, #348]
    402006d8:	29402428 	ldp	w8, w9, [x1]
    402006dc:	b9014268 	str	w8, [x19, #320]
    402006e0:	7902c67f 	strh	wzr, [x19, #354]
    402006e4:	7902c27f 	strh	wzr, [x19, #352]
    402006e8:	7902be7f 	strh	wzr, [x19, #350]
    402006ec:	b9014669 	str	w9, [x19, #324]
    402006f0:	29412428 	ldp	w8, w9, [x1, #8]
    402006f4:	b9014a68 	str	w8, [x19, #328]
    402006f8:	b9014e69 	str	w9, [x19, #332]
    402006fc:	f900027f 	str	xzr, [x19]
    40200700:	f9000a7f 	str	xzr, [x19, #16]
    40200704:	91008260 	add	x0, x19, #0x20
    40200708:	910003e1 	mov	x1, sp
    4020070c:	52801802 	mov	w2, #0xc0                  	// #192
    40200710:	94000fda 	bl	40204678 <memcpy>
    40200714:	91038260 	add	x0, x19, #0xe0
    40200718:	910303e1 	add	x1, sp, #0xc0
    4020071c:	52800c02 	mov	w2, #0x60                  	// #96
    40200720:	94000fd6 	bl	40204678 <memcpy>
    40200724:	f900aa7f 	str	xzr, [x19, #336]
    40200728:	14000003 	b	40200734 <jnox_kernel::mutex_policy::LockSet<_,_>::new+0x124>
    4020072c:	52800048 	mov	w8, #0x2                   	// #2
    40200730:	f9000268 	str	x8, [x19]
    40200734:	a9534ffe 	ldp	x30, x19, [sp, #304]
    40200738:	f94093fd 	ldr	x29, [sp, #288]
    4020073c:	910503ff 	add	sp, sp, #0x140
    40200740:	d65f03c0 	ret

0000000040200744 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire>:
    40200744:	f100143f 	cmp	x1, #0x5
    40200748:	54000069 	b.ls	40200754 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire+0x10>  // b.plast
    4020074c:	52800040 	mov	w0, #0x2                   	// #2
    40200750:	d65f03c0 	ret
    40200754:	a9bd5ffe 	stp	x30, x23, [sp, #-48]!
    40200758:	a90157f6 	stp	x22, x21, [sp, #16]
    4020075c:	a9024ff4 	stp	x20, x19, [sp, #32]
    40200760:	aa0203f3 	mov	x19, x2
    40200764:	aa0103f4 	mov	x20, x1
    40200768:	aa0003f5 	mov	x21, x0
    4020076c:	8b011408 	add	x8, x0, x1, lsl #5
    40200770:	91008108 	add	x8, x8, #0x20
    40200774:	52800409 	mov	w9, #0x20                  	// #32
    40200778:	f940010a 	ldr	x10, [x8]
    4020077c:	b40000aa 	cbz	x10, 40200790 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire+0x4c>
    40200780:	91004108 	add	x8, x8, #0x10
    40200784:	f1004129 	subs	x9, x9, #0x10
    40200788:	54ffff81 	b.ne	40200778 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire+0x34>  // b.any
    4020078c:	1400000a 	b	402007b4 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire+0x70>
    40200790:	f100067f 	cmp	x19, #0x1
    40200794:	54000108 	b.hi	402007b4 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire+0x70>  // b.pmore
    40200798:	8b130ea9 	add	x9, x21, x19, lsl #3
    4020079c:	b9414129 	ldr	w9, [x9, #320]
    402007a0:	1ad42529 	lsr	w9, w9, w20
    402007a4:	36000089 	tbz	w9, #0, 402007b4 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire+0x70>
    402007a8:	8b1412b6 	add	x22, x21, x20, lsl #4
    402007ac:	f84e0ec9 	ldr	x9, [x22, #224]!
    402007b0:	b40000c9 	cbz	x9, 402007c8 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire+0x84>
    402007b4:	52800040 	mov	w0, #0x2                   	// #2
    402007b8:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402007bc:	a94157f6 	ldp	x22, x21, [sp, #16]
    402007c0:	a8c35ffe 	ldp	x30, x23, [sp], #48
    402007c4:	d65f03c0 	ret
    402007c8:	8b1312a9 	add	x9, x21, x19, lsl #4
    402007cc:	f940012a 	ldr	x10, [x9]
    402007d0:	f100055f 	cmp	x10, #0x1
    402007d4:	54000201 	b.ne	40200814 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire+0xd0>  // b.any
    402007d8:	f940aab7 	ldr	x23, [x21, #336]
    402007dc:	f10016ff 	cmp	x23, #0x5
    402007e0:	54fffea8 	b.hi	402007b4 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire+0x70>  // b.pmore
    402007e4:	f9400522 	ldr	x2, [x9, #8]
    402007e8:	aa1503e0 	mov	x0, x21
    402007ec:	aa1403e1 	mov	x1, x20
    402007f0:	97ffff64 	bl	40200580 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17hcc00d34e95a61f80E.llvm.13497221849890916907>
    402007f4:	3707fe00 	tbnz	w0, #0, 402007b4 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire+0x70>
    402007f8:	8b1702a8 	add	x8, x21, x23
    402007fc:	39057914 	strb	w20, [x8, #350]
    40200800:	910006e8 	add	x8, x23, #0x1
    40200804:	f900aaa8 	str	x8, [x21, #336]
    40200808:	52800020 	mov	w0, #0x1                   	// #1
    4020080c:	a9004ec0 	stp	x0, x19, [x22]
    40200810:	17ffffea 	b	402007b8 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire+0x74>
    40200814:	2a1f03e0 	mov	w0, wzr
    40200818:	5280002a 	mov	w10, #0x1                   	// #1
    4020081c:	a9004d0a 	stp	x10, x19, [x8]
    40200820:	a900512a 	stp	x10, x20, [x9]
    40200824:	17ffffe5 	b	402007b8 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire+0x74>

0000000040200828 <jnox_kernel::mutex_policy::LockSet<_,_>::release>:
    40200828:	f81b0ffe 	str	x30, [sp, #-80]!
    4020082c:	a90167fa 	stp	x26, x25, [sp, #16]
    40200830:	a9025ff8 	stp	x24, x23, [sp, #32]
    40200834:	a90357f6 	stp	x22, x21, [sp, #48]
    40200838:	a9044ff4 	stp	x20, x19, [sp, #64]
    4020083c:	f100045f 	cmp	x2, #0x1
    40200840:	540001c8 	b.hi	40200878 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x50>  // b.pmore
    40200844:	aa0203f4 	mov	x20, x2
    40200848:	aa0003f3 	mov	x19, x0
    4020084c:	8b021017 	add	x23, x0, x2, lsl #4
    40200850:	a94026e8 	ldp	x8, x9, [x23]
    40200854:	f100011f 	cmp	x8, #0x0
    40200858:	fa411120 	ccmp	x9, x1, #0x0, ne  // ne = any
    4020085c:	540000e1 	b.ne	40200878 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x50>  // b.any
    40200860:	f100143f 	cmp	x1, #0x5
    40200864:	54000c28 	b.hi	402009e8 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x1c0>  // b.pmore
    40200868:	91038279 	add	x25, x19, #0xe0
    4020086c:	d37cec28 	lsl	x8, x1, #4
    40200870:	f8686b28 	ldr	x8, [x25, x8]
    40200874:	b4000148 	cbz	x8, 4020089c <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x74>
    40200878:	52800056 	mov	w22, #0x2                   	// #2
    4020087c:	aa1603e0 	mov	x0, x22
    40200880:	aa1503e1 	mov	x1, x21
    40200884:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40200888:	a94357f6 	ldp	x22, x21, [sp, #48]
    4020088c:	a9425ff8 	ldp	x24, x23, [sp, #32]
    40200890:	a94167fa 	ldp	x26, x25, [sp, #16]
    40200894:	f84507fe 	ldr	x30, [sp], #80
    40200898:	d65f03c0 	ret
    4020089c:	9100827a 	add	x26, x19, #0x20
    402008a0:	8b011668 	add	x8, x19, x1, lsl #5
    402008a4:	91012118 	add	x24, x8, #0x48
    402008a8:	928003e8 	mov	x8, #0xffffffffffffffe0    	// #-32
    402008ac:	52800056 	mov	w22, #0x2                   	// #2
    402008b0:	b4fffe68 	cbz	x8, 4020087c <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x54>
    402008b4:	f85e8309 	ldur	x9, [x24, #-24]
    402008b8:	d1004318 	sub	x24, x24, #0x10
    402008bc:	91004108 	add	x8, x8, #0x10
    402008c0:	b4ffff89 	cbz	x9, 402008b0 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x88>
    402008c4:	f85f8308 	ldur	x8, [x24, #-8]
    402008c8:	b4fffd88 	cbz	x8, 40200878 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x50>
    402008cc:	f9400308 	ldr	x8, [x24]
    402008d0:	eb14011f 	cmp	x8, x20
    402008d4:	54fffd21 	b.ne	40200878 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x50>  // b.any
    402008d8:	aa1303e0 	mov	x0, x19
    402008dc:	97fffe21 	bl	40200160 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h755569b820a7af71E.llvm.13497221849890916907>
    402008e0:	3607fcc0 	tbz	w0, #0, 40200878 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x50>
    402008e4:	d348fc08 	lsr	x8, x0, #8
    402008e8:	d368fc09 	lsr	x9, x0, #40
    402008ec:	79001be9 	strh	w9, [sp, #12]
    402008f0:	b9000be8 	str	w8, [sp, #8]
    402008f4:	f940aa68 	ldr	x8, [x19, #336]
    402008f8:	f1001d1f 	cmp	x8, #0x7
    402008fc:	540006a2 	b.cs	402009d0 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x1a8>  // b.hs, b.nlast
    40200900:	b4000568 	cbz	x8, 402009ac <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x184>
    40200904:	aa1f03eb 	mov	x11, xzr
    40200908:	aa1f03e9 	mov	x9, xzr
    4020090c:	910023ea 	add	x10, sp, #0x8
    40200910:	8b09026c 	add	x12, x19, x9
    40200914:	39457980 	ldrb	w0, [x12, #350]
    40200918:	f100181f 	cmp	x0, #0x6
    4020091c:	540006e2 	b.cs	402009f8 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x1d0>  // b.hs, b.nlast
    40200920:	8b00132c 	add	x12, x25, x0, lsl #4
    40200924:	f940018d 	ldr	x13, [x12]
    40200928:	f10005bf 	cmp	x13, #0x1
    4020092c:	54000241 	b.ne	40200974 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x14c>  // b.any
    40200930:	f940058c 	ldr	x12, [x12, #8]
    40200934:	eb14019f 	cmp	x12, x20
    40200938:	540001e1 	b.ne	40200974 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x14c>  // b.any
    4020093c:	f100057f 	cmp	x11, #0x1
    40200940:	54000141 	b.ne	40200968 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x140>  // b.any
    40200944:	f1001abf 	cmp	x21, #0x6
    40200948:	54000602 	b.cs	40200a08 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x1e0>  // b.hs, b.nlast
    4020094c:	3860694b 	ldrb	w11, [x10, x0]
    40200950:	3875694c 	ldrb	w12, [x10, x21]
    40200954:	6b0c017f 	cmp	w11, w12
    40200958:	9a818121 	csel	x1, x9, x1, hi  // hi = pmore
    4020095c:	9a958015 	csel	x21, x0, x21, hi  // hi = pmore
    40200960:	5280002b 	mov	w11, #0x1                   	// #1
    40200964:	14000004 	b	40200974 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x14c>
    40200968:	5280002b 	mov	w11, #0x1                   	// #1
    4020096c:	aa0903e1 	mov	x1, x9
    40200970:	aa0003f5 	mov	x21, x0
    40200974:	91000529 	add	x9, x9, #0x1
    40200978:	eb09011f 	cmp	x8, x9
    4020097c:	54fffca1 	b.ne	40200910 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0xe8>  // b.any
    40200980:	f100057f 	cmp	x11, #0x1
    40200984:	54000141 	b.ne	402009ac <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x184>  // b.any
    40200988:	8b151748 	add	x8, x26, x21, lsl #5
    4020098c:	52800409 	mov	w9, #0x20                  	// #32
    40200990:	52800056 	mov	w22, #0x2                   	// #2
    40200994:	f940010a 	ldr	x10, [x8]
    40200998:	b400012a 	cbz	x10, 402009bc <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x194>
    4020099c:	91004108 	add	x8, x8, #0x10
    402009a0:	f1004129 	subs	x9, x9, #0x10
    402009a4:	54ffff81 	b.ne	40200994 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x16c>  // b.any
    402009a8:	17ffffb5 	b	4020087c <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x54>
    402009ac:	aa1f03f6 	mov	x22, xzr
    402009b0:	f81f831f 	stur	xzr, [x24, #-8]
    402009b4:	a90056f6 	stp	x22, x21, [x23]
    402009b8:	17ffffb1 	b	4020087c <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x54>
    402009bc:	52800036 	mov	w22, #0x1                   	// #1
    402009c0:	a9005116 	stp	x22, x20, [x8]
    402009c4:	aa1303e0 	mov	x0, x19
    402009c8:	97fffec5 	bl	402004dc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17hee72c2801fa4e836E.llvm.13497221849890916907>
    402009cc:	17fffff9 	b	402009b0 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x188>
    402009d0:	d503201f 	nop
    402009d4:	10021123 	adr	x3, 40204bf8 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.9.llvm.13497221849890916907+0x30>
    402009d8:	aa1f03e0 	mov	x0, xzr
    402009dc:	aa0803e1 	mov	x1, x8
    402009e0:	528000c2 	mov	w2, #0x6                   	// #6
    402009e4:	94000d77 	bl	40203fc0 <core::slice::index::slice_index_fail>
    402009e8:	d503201f 	nop
    402009ec:	10020fa2 	adr	x2, 40204be0 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.9.llvm.13497221849890916907+0x18>
    402009f0:	aa0103e0 	mov	x0, x1
    402009f4:	14000003 	b	40200a00 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x1d8>
    402009f8:	d503201f 	nop
    402009fc:	100210a2 	adr	x2, 40204c10 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.9.llvm.13497221849890916907+0x48>
    40200a00:	528000c1 	mov	w1, #0x6                   	// #6
    40200a04:	94000b70 	bl	402037c4 <core::panicking::panic_bounds_check>
    40200a08:	d503201f 	nop
    40200a0c:	100210e2 	adr	x2, 40204c28 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.9.llvm.13497221849890916907+0x60>
    40200a10:	aa1503e0 	mov	x0, x21
    40200a14:	17fffffb 	b	40200a00 <jnox_kernel::mutex_policy::LockSet<_,_>::release+0x1d8>

0000000040200a18 <jnox_kernel::mutex_policy::LockSet<_,_>::timeout>:
    40200a18:	f81f0ffe 	str	x30, [sp, #-16]!
    40200a1c:	aa0103e8 	mov	x8, x1
    40200a20:	f940a801 	ldr	x1, [x0, #336]
    40200a24:	f1001c3f 	cmp	x1, #0x7
    40200a28:	54000222 	b.cs	40200a6c <jnox_kernel::mutex_policy::LockSet<_,_>::timeout+0x54>  // b.hs, b.nlast
    40200a2c:	b4000121 	cbz	x1, 40200a50 <jnox_kernel::mutex_policy::LockSet<_,_>::timeout+0x38>
    40200a30:	aa1f03e9 	mov	x9, xzr
    40200a34:	8b09000a 	add	x10, x0, x9
    40200a38:	3945794a 	ldrb	w10, [x10, #350]
    40200a3c:	eb0a011f 	cmp	x8, x10
    40200a40:	540000c0 	b.eq	40200a58 <jnox_kernel::mutex_policy::LockSet<_,_>::timeout+0x40>  // b.none
    40200a44:	91000529 	add	x9, x9, #0x1
    40200a48:	eb09003f 	cmp	x1, x9
    40200a4c:	54ffff41 	b.ne	40200a34 <jnox_kernel::mutex_policy::LockSet<_,_>::timeout+0x1c>  // b.any
    40200a50:	2a1f03e0 	mov	w0, wzr
    40200a54:	14000004 	b	40200a64 <jnox_kernel::mutex_policy::LockSet<_,_>::timeout+0x4c>
    40200a58:	aa0903e1 	mov	x1, x9
    40200a5c:	97fffea0 	bl	402004dc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17hee72c2801fa4e836E.llvm.13497221849890916907>
    40200a60:	52800020 	mov	w0, #0x1                   	// #1
    40200a64:	f84107fe 	ldr	x30, [sp], #16
    40200a68:	d65f03c0 	ret
    40200a6c:	d503201f 	nop
    40200a70:	10020e83 	adr	x3, 40204c40 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.14.llvm.13497221849890916907>
    40200a74:	aa1f03e0 	mov	x0, xzr
    40200a78:	528000c2 	mov	w2, #0x6                   	// #6
    40200a7c:	94000d51 	bl	40203fc0 <core::slice::index::slice_index_fail>

0000000040200a80 <_ZN11jnox_kernel24ordinary_mutex_survivors7Runtime6choose28_$u7b$$u7b$closure$u7d$$u7d$28_$u7b$$u7b$closure$u7d$$u7d$17hbd19f1c9c23d3740E.llvm.13497221849890916907>:
    40200a80:	f81f0ffe 	str	x30, [sp, #-16]!
    40200a84:	52800060 	mov	w0, #0x3                   	// #3
    40200a88:	940004ea 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

0000000040200a8c <jnox_kernel::context::init_timer_irq>:
    40200a8c:	d503201f 	nop
    40200a90:	10002b88 	adr	x8, 40201000 <sched_vectors>
    40200a94:	d518c008 	msr	vbar_el1, x8
    40200a98:	d51be23f 	msr	cntp_ctl_el0, xzr
    40200a9c:	d5033fdf 	isb
    40200aa0:	52a10008 	mov	w8, #0x8000000             	// #134217728
    40200aa4:	b900011f 	str	wzr, [x8]
    40200aa8:	52a10029 	mov	w9, #0x8010000             	// #134283264
    40200aac:	b900013f 	str	wzr, [x9]
    40200ab0:	5280100a 	mov	w10, #0x80                  	// #128
    40200ab4:	72a1000a 	movk	w10, #0x800, lsl #16
    40200ab8:	b940014b 	ldr	w11, [x10]
    40200abc:	1201796b 	and	w11, w11, #0xbfffffff
    40200ac0:	b900014b 	str	w11, [x10]
    40200ac4:	5280100b 	mov	w11, #0x80                  	// #128
    40200ac8:	390e794b 	strb	w11, [x10, #926]
    40200acc:	52a8000b 	mov	w11, #0x40000000            	// #1073741824
    40200ad0:	b902014b 	str	w11, [x10, #512]
    40200ad4:	b900814b 	str	w11, [x10, #128]
    40200ad8:	5280008a 	mov	w10, #0x4                   	// #4
    40200adc:	72a1002a 	movk	w10, #0x801, lsl #16
    40200ae0:	52801feb 	mov	w11, #0xff                  	// #255
    40200ae4:	b900014b 	str	w11, [x10]
    40200ae8:	5280002a 	mov	w10, #0x1                   	// #1
    40200aec:	b900010a 	str	w10, [x8]
    40200af0:	b900012a 	str	w10, [x9]
    40200af4:	d5033f9f 	dsb	sy
    40200af8:	d5033fdf 	isb
    40200afc:	d65f03c0 	ret
	...

0000000040201000 <sched_vectors>:
    40201000:	14000200 00000000 00000000 00000000     ................
	...
    40201080:	140001e0 00000000 00000000 00000000     ................
	...
    40201100:	140001c0 00000000 00000000 00000000     ................
	...
    40201180:	140001a0 00000000 00000000 00000000     ................
	...
    40201200:	140001b6 00000000 00000000 00000000     ................
	...
    40201280:	14000161 00000000 00000000 00000000     a...............
	...
    40201300:	14000140 00000000 00000000 00000000     @...............
	...
    40201380:	14000120 00000000 00000000 00000000      ...............
	...
    40201400:	14000100 00000000 00000000 00000000     ................
	...
    40201480:	140000e0 00000000 00000000 00000000     ................
	...
    40201500:	140000c0 00000000 00000000 00000000     ................
	...
    40201580:	140000a0 00000000 00000000 00000000     ................
	...
    40201600:	14000080 00000000 00000000 00000000     ................
	...
    40201680:	14000060 00000000 00000000 00000000     `...............
	...
    40201700:	14000040 00000000 00000000 00000000     @...............
	...
    40201780:	14000020 00000000 00000000 00000000      ...............
	...
    40201800:	140000aa d10d03ff f90027e9 d5033fdf     .........'...?..
    40201810:	d53be029 f9009fe9 f94027e9 a90007e0     ).;......'@.....
    40201820:	a9010fe2 a90217e4 a9031fe6 a90427e8     .............'..
    40201830:	a9052fea a90637ec a9073fee a90847f0     ./...7...?...G..
    40201840:	a9094ff2 a90a57f4 a90b5ff6 a90c67f8     .O...W..._...g..
    40201850:	a90d6ffa a90e77fc f9007bfe ad0a07e0     .o...w...{......
    40201860:	ad0b0fe2 ad0c17e4 ad0d1fe6 ad0e27e8     .............'..
    40201870:	ad0f2fea ad1037ec ad113fee ad1247f0     ./...7...?...G..
    40201880:	ad134ff2 ad1457f4 ad155ff6 ad1667f8     .O...W..._...g..
    40201890:	ad176ffa ad1877fc ad197ffe d5384029     .o...w......)@8.
    402018a0:	d538400a a90fabe9 d53b4409 d53b442a     .@8......D;.*D;.
    402018b0:	a910abe9 d538d089 d538410a a911abe9     ......8..A8.....
    402018c0:	d53bd049 d53bd06a a912abe9 910003e0     I.;.j.;.........
    402018d0:	9400046e 14000036 d10d03ff f90027e9     n...6........'..
    402018e0:	d5033fdf d53be029 f9009fe9 f94027e9     .?..).;......'@.
    402018f0:	a90007e0 a9010fe2 a90217e4 a9031fe6     ................
    40201900:	a90427e8 a9052fea a90637ec a9073fee     .'.../...7...?..
    40201910:	a90847f0 a9094ff2 a90a57f4 a90b5ff6     .G...O...W..._..
    40201920:	a90c67f8 a90d6ffa a90e77fc f9007bfe     .g...o...w...{..
    40201930:	ad0a07e0 ad0b0fe2 ad0c17e4 ad0d1fe6     ................
    40201940:	ad0e27e8 ad0f2fea ad1037ec ad113fee     .'.../...7...?..
    40201950:	ad1247f0 ad134ff2 ad1457f4 ad155ff6     .G...O...W..._..
    40201960:	ad1667f8 ad176ffa ad1877fc ad197ffe     .g...o...w......
    40201970:	d5384029 d538400a a90fabe9 d53b4409     )@8..@8......D;.
    40201980:	d53b442a a910abe9 d538d089 d538410a     *D;.......8..A8.
    40201990:	a911abe9 d53bd049 d53bd06a a912abe9     ....I.;.j.;.....
    402019a0:	910003e0 9400031d 14000001              ............

00000000402019ac <sched_start_frame>:
    402019ac:	9100001f 	mov	sp, x0
    402019b0:	a94fabe9 	ldp	x9, x10, [sp, #248]
    402019b4:	d5184029 	msr	elr_el1, x9
    402019b8:	d518400a 	msr	spsr_el1, x10
    402019bc:	a950abe9 	ldp	x9, x10, [sp, #264]
    402019c0:	d51b4409 	msr	fpcr, x9
    402019c4:	d51b442a 	msr	fpsr, x10
    402019c8:	a951abe9 	ldp	x9, x10, [sp, #280]
    402019cc:	d518d089 	msr	tpidr_el1, x9
    402019d0:	d518410a 	msr	sp_el0, x10
    402019d4:	a952abe9 	ldp	x9, x10, [sp, #296]
    402019d8:	d51bd049 	msr	tpidr_el0, x9
    402019dc:	d51bd06a 	msr	tpidrro_el0, x10
    402019e0:	ad4a07e0 	ldp	q0, q1, [sp, #320]
    402019e4:	ad4b0fe2 	ldp	q2, q3, [sp, #352]
    402019e8:	ad4c17e4 	ldp	q4, q5, [sp, #384]
    402019ec:	ad4d1fe6 	ldp	q6, q7, [sp, #416]
    402019f0:	ad4e27e8 	ldp	q8, q9, [sp, #448]
    402019f4:	ad4f2fea 	ldp	q10, q11, [sp, #480]
    402019f8:	ad5037ec 	ldp	q12, q13, [sp, #512]
    402019fc:	ad513fee 	ldp	q14, q15, [sp, #544]
    40201a00:	ad5247f0 	ldp	q16, q17, [sp, #576]
    40201a04:	ad534ff2 	ldp	q18, q19, [sp, #608]
    40201a08:	ad5457f4 	ldp	q20, q21, [sp, #640]
    40201a0c:	ad555ff6 	ldp	q22, q23, [sp, #672]
    40201a10:	ad5667f8 	ldp	q24, q25, [sp, #704]
    40201a14:	ad576ffa 	ldp	q26, q27, [sp, #736]
    40201a18:	ad5877fc 	ldp	q28, q29, [sp, #768]
    40201a1c:	ad597ffe 	ldp	q30, q31, [sp, #800]
    40201a20:	d503201f 	nop
    40201a24:	101ba869 	adr	x9, 40238f30 <jnox_ap_returns>
    40201a28:	f940012a 	ldr	x10, [x9]
    40201a2c:	f101015f 	cmp	x10, #0x40
    40201a30:	54ffee82 	b.cs	40201800 <sched_vectors+0x800>  // b.hs, b.nlast
    40201a34:	9100054b 	add	x11, x10, #0x1
    40201a38:	f800852b 	str	x11, [x9], #8
    40201a3c:	d280030b 	mov	x11, #0x18                  	// #24
    40201a40:	9b0b2549 	madd	x9, x10, x11, x9
    40201a44:	910003ea 	mov	x10, sp
    40201a48:	d538402b 	mrs	x11, elr_el1
    40201a4c:	a9002d2a 	stp	x10, x11, [x9]
    40201a50:	d5033fdf 	isb
    40201a54:	d53be02a 	mrs	x10, cntpct_el0
    40201a58:	f900092a 	str	x10, [x9, #16]
    40201a5c:	a94007e0 	ldp	x0, x1, [sp]
    40201a60:	a9410fe2 	ldp	x2, x3, [sp, #16]
    40201a64:	a94217e4 	ldp	x4, x5, [sp, #32]
    40201a68:	a9431fe6 	ldp	x6, x7, [sp, #48]
    40201a6c:	a94427e8 	ldp	x8, x9, [sp, #64]
    40201a70:	a9452fea 	ldp	x10, x11, [sp, #80]
    40201a74:	a94637ec 	ldp	x12, x13, [sp, #96]
    40201a78:	a9473fee 	ldp	x14, x15, [sp, #112]
    40201a7c:	a94847f0 	ldp	x16, x17, [sp, #128]
    40201a80:	a9494ff2 	ldp	x18, x19, [sp, #144]
    40201a84:	a94a57f4 	ldp	x20, x21, [sp, #160]
    40201a88:	a94b5ff6 	ldp	x22, x23, [sp, #176]
    40201a8c:	a94c67f8 	ldp	x24, x25, [sp, #192]
    40201a90:	a94d6ffa 	ldp	x26, x27, [sp, #208]
    40201a94:	a94e77fc 	ldp	x28, x29, [sp, #224]
    40201a98:	f9407bfe 	ldr	x30, [sp, #240]
    40201a9c:	910d03ff 	add	sp, sp, #0x340
    40201aa0:	d5033f5f 	clrex
    40201aa4:	d69f03e0 	eret

0000000040201aa8 <jnox_kernel::ordinary_mutex_survivors::unexpected>:
    40201aa8:	f81f0ffe 	str	x30, [sp, #-16]!
    40201aac:	52800220 	mov	w0, #0x11                  	// #17
    40201ab0:	940000e0 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

0000000040201ab4 <jnox_kernel::ordinary_mutex_survivors::run>:
    40201ab4:	f81f0ffe 	str	x30, [sp, #-16]!
    40201ab8:	97fffbf5 	bl	40200a8c <jnox_kernel::context::init_timer_irq>
    40201abc:	d53be001 	mrs	x1, cntfrq_el0
    40201ac0:	f10fa03f 	cmp	x1, #0x3e8
    40201ac4:	540001a3 	b.cc	40201af8 <jnox_kernel::ordinary_mutex_survivors::run+0x44>  // b.lo, b.ul, b.last
    40201ac8:	d343fc28 	lsr	x8, x1, #3
    40201acc:	d29ef9e9 	mov	x9, #0xf7cf                	// #63439
    40201ad0:	f2bc6a69 	movk	x9, #0xe353, lsl #16
    40201ad4:	f2d374a9 	movk	x9, #0x9ba5, lsl #32
    40201ad8:	f2e41889 	movk	x9, #0x20c4, lsl #48
    40201adc:	9bc97d08 	umulh	x8, x8, x9
    40201ae0:	d344fd08 	lsr	x8, x8, #4
    40201ae4:	52807d09 	mov	w9, #0x3e8                 	// #1000
    40201ae8:	9b098508 	msub	x8, x8, x9, x1
    40201aec:	b5000068 	cbnz	x8, 40201af8 <jnox_kernel::ordinary_mutex_survivors::run+0x44>
    40201af0:	52800020 	mov	w0, #0x1                   	// #1
    40201af4:	940000d3 	bl	40201e40 <jnox_kernel::ordinary_mutex_survivors::start>
    40201af8:	528001a0 	mov	w0, #0xd                   	// #13
    40201afc:	940000cd 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

0000000040201b00 <jnox_kernel::ordinary_mutex_survivors::dump>:
    40201b00:	d10343ff 	sub	sp, sp, #0xd0
    40201b04:	f9003bfe 	str	x30, [sp, #112]
    40201b08:	a9086ffc 	stp	x28, x27, [sp, #128]
    40201b0c:	a90967fa 	stp	x26, x25, [sp, #144]
    40201b10:	a90a5ff8 	stp	x24, x23, [sp, #160]
    40201b14:	a90b57f6 	stp	x22, x21, [sp, #176]
    40201b18:	a90c4ff4 	stp	x20, x19, [sp, #192]
    40201b1c:	aa1f03e8 	mov	x8, xzr
    40201b20:	52800315 	mov	w21, #0x18                  	// #24
    40201b24:	72a12015 	movk	w21, #0x900, lsl #16
    40201b28:	d5034fdf 	msr	daifset, #0xf
    40201b2c:	d51be23f 	msr	cntp_ctl_el0, xzr
    40201b30:	d5033fdf 	isb
    40201b34:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40201b38:	d503201f 	nop
    40201b3c:	10018caa 	adr	x10, 40204cd0 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.14.llvm.13497221849890916907+0x90>
    40201b40:	3868694b 	ldrb	w11, [x10, x8]
    40201b44:	b94002ac 	ldr	w12, [x21]
    40201b48:	3628006c 	tbz	w12, #5, 40201b54 <jnox_kernel::ordinary_mutex_survivors::dump+0x54>
    40201b4c:	d5033fdf 	isb
    40201b50:	17fffffd 	b	40201b44 <jnox_kernel::ordinary_mutex_survivors::dump+0x44>
    40201b54:	91000508 	add	x8, x8, #0x1
    40201b58:	b900012b 	str	w11, [x9]
    40201b5c:	f100411f 	cmp	x8, #0x10
    40201b60:	54ffff01 	b.ne	40201b40 <jnox_kernel::ordinary_mutex_survivors::dump+0x40>  // b.any
    40201b64:	90000037 	adrp	x23, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40201b68:	90000038 	adrp	x24, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40201b6c:	f00001b6 	adrp	x22, 40238000 <jnox_kernel::ordinary_mutex_survivors::JOURNAL+0x2cd0>
    40201b70:	f94002e8 	ldr	x8, [x23]
    40201b74:	f9416709 	ldr	x9, [x24, #712]
    40201b78:	a90003e8 	stp	x8, x0, [sp]
    40201b7c:	f9479ac8 	ldr	x8, [x22, #3888]
    40201b80:	a90123e9 	stp	x9, x8, [sp, #16]
    40201b84:	d503201f 	nop
    40201b88:	10018b40 	adr	x0, 40204cf0 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0x10>
    40201b8c:	910003f3 	mov	x19, sp
    40201b90:	910003e2 	mov	x2, sp
    40201b94:	52800021 	mov	w1, #0x1                   	// #1
    40201b98:	52800083 	mov	w3, #0x4                   	// #4
    40201b9c:	9400006a 	bl	40201d44 <jnox_kernel::ordinary_mutex_survivors::line>
    40201ba0:	d503201f 	nop
    40201ba4:	30018a60 	adr	x0, 40204cf1 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0x11>
    40201ba8:	d503201f 	nop
    40201bac:	1001b922 	adr	x2, 402052d0 <jnox_kernel::ordinary_mutex_survivors::TIMER>
    40201bb0:	52800021 	mov	w1, #0x1                   	// #1
    40201bb4:	52800183 	mov	w3, #0xc                   	// #12
    40201bb8:	94000063 	bl	40201d44 <jnox_kernel::ordinary_mutex_survivors::line>
    40201bbc:	91004273 	add	x19, x19, #0x10
    40201bc0:	d503201f 	nop
    40201bc4:	100189a1 	adr	x1, 40204cf8 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0x18>
    40201bc8:	aa1303e0 	mov	x0, x19
    40201bcc:	52800602 	mov	w2, #0x30                  	// #48
    40201bd0:	94000aaa 	bl	40204678 <memcpy>
    40201bd4:	aa1f03fb 	mov	x27, xzr
    40201bd8:	d503201f 	nop
    40201bdc:	1001baa8 	adr	x8, 40205330 <jnox_kernel::ordinary_mutex_survivors::STACKS>
    40201be0:	f90023ff 	str	xzr, [sp, #64]
    40201be4:	321107f9 	mov	w25, #0x18000               	// #98304
    40201be8:	d140611a 	sub	x26, x8, #0x18, lsl #12
    40201bec:	5280681c 	mov	w28, #0x340                 	// #832
    40201bf0:	d503201f 	nop
    40201bf4:	10018af4 	adr	x20, 40204d50 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0x70>
    40201bf8:	f87b7a68 	ldr	x8, [x19, x27, lsl #3]
    40201bfc:	f94002e9 	ldr	x9, [x23]
    40201c00:	9b196929 	madd	x9, x9, x25, x26
    40201c04:	a904a7fb 	stp	x27, x9, [sp, #72]
    40201c08:	9100077b 	add	x27, x27, #0x1
    40201c0c:	91401129 	add	x9, x9, #0x4, lsl #12
    40201c10:	a905f3e9 	stp	x9, x28, [sp, #88]
    40201c14:	f90037e8 	str	x8, [sp, #104]
    40201c18:	910123e2 	add	x2, sp, #0x48
    40201c1c:	aa1403e0 	mov	x0, x20
    40201c20:	52800021 	mov	w1, #0x1                   	// #1
    40201c24:	528000a3 	mov	w3, #0x5                   	// #5
    40201c28:	94000047 	bl	40201d44 <jnox_kernel::ordinary_mutex_survivors::line>
    40201c2c:	9140135a 	add	x26, x26, #0x4, lsl #12
    40201c30:	f1001b7f 	cmp	x27, #0x6
    40201c34:	54fffe21 	b.ne	40201bf8 <jnox_kernel::ordinary_mutex_survivors::dump+0xf8>  // b.any
    40201c38:	f9416717 	ldr	x23, [x24, #712]
    40201c3c:	b4000217 	cbz	x23, 40201c7c <jnox_kernel::ordinary_mutex_survivors::dump+0x17c>
    40201c40:	d503201f 	nop
    40201c44:	1019b773 	adr	x19, 40235330 <jnox_kernel::ordinary_mutex_survivors::JOURNAL>
    40201c48:	52800618 	mov	w24, #0x30                  	// #48
    40201c4c:	d503201f 	nop
    40201c50:	70018734 	adr	x20, 40204d37 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0x57>
    40201c54:	b4000638 	cbz	x24, 40201d18 <jnox_kernel::ordinary_mutex_survivors::dump+0x218>
    40201c58:	aa1403e0 	mov	x0, x20
    40201c5c:	52800021 	mov	w1, #0x1                   	// #1
    40201c60:	aa1303e2 	mov	x2, x19
    40201c64:	52800503 	mov	w3, #0x28                  	// #40
    40201c68:	94000037 	bl	40201d44 <jnox_kernel::ordinary_mutex_survivors::line>
    40201c6c:	d10006f7 	sub	x23, x23, #0x1
    40201c70:	91050273 	add	x19, x19, #0x140
    40201c74:	d1000718 	sub	x24, x24, #0x1
    40201c78:	b5fffef7 	cbnz	x23, 40201c54 <jnox_kernel::ordinary_mutex_survivors::dump+0x154>
    40201c7c:	f9479ac8 	ldr	x8, [x22, #3888]
    40201c80:	f101011f 	cmp	x8, #0x40
    40201c84:	52800809 	mov	w9, #0x40                  	// #64
    40201c88:	9a893116 	csel	x22, x8, x9, cc  // cc = lo, ul, last
    40201c8c:	b40001a8 	cbz	x8, 40201cc0 <jnox_kernel::ordinary_mutex_survivors::dump+0x1c0>
    40201c90:	f00001b3 	adrp	x19, 40238000 <jnox_kernel::ordinary_mutex_survivors::JOURNAL+0x2cd0>
    40201c94:	913ce273 	add	x19, x19, #0xf38
    40201c98:	d503201f 	nop
    40201c9c:	500184d4 	adr	x20, 40204d36 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0x56>
    40201ca0:	aa1403e0 	mov	x0, x20
    40201ca4:	52800021 	mov	w1, #0x1                   	// #1
    40201ca8:	aa1303e2 	mov	x2, x19
    40201cac:	52800063 	mov	w3, #0x3                   	// #3
    40201cb0:	94000025 	bl	40201d44 <jnox_kernel::ordinary_mutex_survivors::line>
    40201cb4:	91006273 	add	x19, x19, #0x18
    40201cb8:	f10006d6 	subs	x22, x22, #0x1
    40201cbc:	54ffff21 	b.ne	40201ca0 <jnox_kernel::ordinary_mutex_survivors::dump+0x1a0>  // b.any
    40201cc0:	940004b9 	bl	40202fa4 <jnox_kernel::ordinary_mutex_survivors::workers::dump>
    40201cc4:	aa1f03e8 	mov	x8, xzr
    40201cc8:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40201ccc:	d503201f 	nop
    40201cd0:	100182ca 	adr	x10, 40204d28 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0x48>
    40201cd4:	3868694b 	ldrb	w11, [x10, x8]
    40201cd8:	b94002ac 	ldr	w12, [x21]
    40201cdc:	3628006c 	tbz	w12, #5, 40201ce8 <jnox_kernel::ordinary_mutex_survivors::dump+0x1e8>
    40201ce0:	d5033fdf 	isb
    40201ce4:	17fffffd 	b	40201cd8 <jnox_kernel::ordinary_mutex_survivors::dump+0x1d8>
    40201ce8:	91000508 	add	x8, x8, #0x1
    40201cec:	b900012b 	str	w11, [x9]
    40201cf0:	f100391f 	cmp	x8, #0xe
    40201cf4:	54ffff01 	b.ne	40201cd4 <jnox_kernel::ordinary_mutex_survivors::dump+0x1d4>  // b.any
    40201cf8:	a94c4ff4 	ldp	x20, x19, [sp, #192]
    40201cfc:	a94b57f6 	ldp	x22, x21, [sp, #176]
    40201d00:	a94a5ff8 	ldp	x24, x23, [sp, #160]
    40201d04:	a94967fa 	ldp	x26, x25, [sp, #144]
    40201d08:	a9486ffc 	ldp	x28, x27, [sp, #128]
    40201d0c:	f9403bfe 	ldr	x30, [sp, #112]
    40201d10:	910343ff 	add	sp, sp, #0xd0
    40201d14:	d65f03c0 	ret
    40201d18:	d503201f 	nop
    40201d1c:	100180e2 	adr	x2, 40204d38 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0x58>
    40201d20:	52800600 	mov	w0, #0x30                  	// #48
    40201d24:	52800601 	mov	w1, #0x30                  	// #48
    40201d28:	940006a7 	bl	402037c4 <core::panicking::panic_bounds_check>

0000000040201d2c <jnox_kernel::ordinary_mutex_survivors::exit>:
    40201d2c:	f81f0ffe 	str	x30, [sp, #-16]!
    40201d30:	52800080 	mov	w0, #0x4                   	// #4
    40201d34:	aa1f03e1 	mov	x1, xzr
    40201d38:	94000230 	bl	402025f8 <jnox_kernel::ordinary_mutex_survivors::checked>
    40201d3c:	52800180 	mov	w0, #0xc                   	// #12
    40201d40:	9400003c 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

0000000040201d44 <jnox_kernel::ordinary_mutex_survivors::line>:
    40201d44:	d10043ff 	sub	sp, sp, #0x10
    40201d48:	52800308 	mov	w8, #0x18                  	// #24
    40201d4c:	72a12008 	movk	w8, #0x900, lsl #16
    40201d50:	b4000161 	cbz	x1, 40201d7c <jnox_kernel::ordinary_mutex_survivors::line+0x38>
    40201d54:	8b010009 	add	x9, x0, x1
    40201d58:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    40201d5c:	3840140b 	ldrb	w11, [x0], #1
    40201d60:	b940010c 	ldr	w12, [x8]
    40201d64:	3628006c 	tbz	w12, #5, 40201d70 <jnox_kernel::ordinary_mutex_survivors::line+0x2c>
    40201d68:	d5033fdf 	isb
    40201d6c:	17fffffd 	b	40201d60 <jnox_kernel::ordinary_mutex_survivors::line+0x1c>
    40201d70:	b900014b 	str	w11, [x10]
    40201d74:	eb09001f 	cmp	x0, x9
    40201d78:	54ffff21 	b.ne	40201d5c <jnox_kernel::ordinary_mutex_survivors::line+0x18>  // b.any
    40201d7c:	b40004c3 	cbz	x3, 40201e14 <jnox_kernel::ordinary_mutex_survivors::line+0xd0>
    40201d80:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40201d84:	8b030c4a 	add	x10, x2, x3, lsl #3
    40201d88:	5280040b 	mov	w11, #0x20                  	// #32
    40201d8c:	910003ec 	mov	x12, sp
    40201d90:	d503201f 	nop
    40201d94:	10017a6d 	adr	x13, 40204ce0 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173>
    40201d98:	f940004e 	ldr	x14, [x2]
    40201d9c:	910003ef 	mov	x15, sp
    40201da0:	52800790 	mov	w16, #0x3c                  	// #60
    40201da4:	a9007fff 	stp	xzr, xzr, [sp]
    40201da8:	9ad025d1 	lsr	x17, x14, x16
    40201dac:	92400e31 	and	x17, x17, #0xf
    40201db0:	387169b1 	ldrb	w17, [x13, x17]
    40201db4:	380015f1 	strb	w17, [x15], #1
    40201db8:	d1001210 	sub	x16, x16, #0x4
    40201dbc:	b100121f 	cmn	x16, #0x4
    40201dc0:	54ffff41 	b.ne	40201da8 <jnox_kernel::ordinary_mutex_survivors::line+0x64>  // b.any
    40201dc4:	14000002 	b	40201dcc <jnox_kernel::ordinary_mutex_survivors::line+0x88>
    40201dc8:	d5033fdf 	isb
    40201dcc:	b940010e 	ldr	w14, [x8]
    40201dd0:	372fffce 	tbnz	w14, #5, 40201dc8 <jnox_kernel::ordinary_mutex_survivors::line+0x84>
    40201dd4:	aa1f03ee 	mov	x14, xzr
    40201dd8:	b900012b 	str	w11, [x9]
    40201ddc:	386e698f 	ldrb	w15, [x12, x14]
    40201de0:	b9400110 	ldr	w16, [x8]
    40201de4:	36280070 	tbz	w16, #5, 40201df0 <jnox_kernel::ordinary_mutex_survivors::line+0xac>
    40201de8:	d5033fdf 	isb
    40201dec:	17fffffd 	b	40201de0 <jnox_kernel::ordinary_mutex_survivors::line+0x9c>
    40201df0:	910005ce 	add	x14, x14, #0x1
    40201df4:	b900012f 	str	w15, [x9]
    40201df8:	f10041df 	cmp	x14, #0x10
    40201dfc:	54ffff01 	b.ne	40201ddc <jnox_kernel::ordinary_mutex_survivors::line+0x98>  // b.any
    40201e00:	91002042 	add	x2, x2, #0x8
    40201e04:	eb0a005f 	cmp	x2, x10
    40201e08:	54fffc81 	b.ne	40201d98 <jnox_kernel::ordinary_mutex_survivors::line+0x54>  // b.any
    40201e0c:	14000002 	b	40201e14 <jnox_kernel::ordinary_mutex_survivors::line+0xd0>
    40201e10:	d5033fdf 	isb
    40201e14:	b9400109 	ldr	w9, [x8]
    40201e18:	372fffc9 	tbnz	w9, #5, 40201e10 <jnox_kernel::ordinary_mutex_survivors::line+0xcc>
    40201e1c:	52a12008 	mov	w8, #0x9000000             	// #150994944
    40201e20:	52800149 	mov	w9, #0xa                   	// #10
    40201e24:	b9000109 	str	w9, [x8]
    40201e28:	910043ff 	add	sp, sp, #0x10
    40201e2c:	d65f03c0 	ret

0000000040201e30 <jnox_kernel::ordinary_mutex_survivors::stop>:
    40201e30:	f81f0ffe 	str	x30, [sp, #-16]!
    40201e34:	97ffff33 	bl	40201b00 <jnox_kernel::ordinary_mutex_survivors::dump>
    40201e38:	d503205f 	wfe
    40201e3c:	17ffffff 	b	40201e38 <jnox_kernel::ordinary_mutex_survivors::stop+0x8>

0000000040201e40 <jnox_kernel::ordinary_mutex_survivors::start>:
    40201e40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40201e44:	a90157f6 	stp	x22, x21, [sp, #16]
    40201e48:	a9024ff4 	stp	x20, x19, [sp, #32]
    40201e4c:	d10d83ff 	sub	sp, sp, #0x360
    40201e50:	aa0103f4 	mov	x20, x1
    40201e54:	aa0003f3 	mov	x19, x0
    40201e58:	90000028 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40201e5c:	f9000100 	str	x0, [x8]
    40201e60:	90000028 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40201e64:	f901651f 	str	xzr, [x8, #712]
    40201e68:	f00001a8 	adrp	x8, 40238000 <jnox_kernel::ordinary_mutex_survivors::JOURNAL+0x2cd0>
    40201e6c:	f907991f 	str	xzr, [x8, #3888]
    40201e70:	d503201f 	nop
    40201e74:	1001a2e0 	adr	x0, 402052d0 <jnox_kernel::ordinary_mutex_survivors::TIMER>
    40201e78:	2a1f03e1 	mov	w1, wzr
    40201e7c:	52800c02 	mov	w2, #0x60                  	// #96
    40201e80:	94000a81 	bl	40204884 <memset>
    40201e84:	d503201f 	nop
    40201e88:	101bb648 	adr	x8, 40239550 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers6CHUNKS17h78003a5906450e90E.0.llvm.1785347619192815592>
    40201e8c:	c89ffd1f 	stlr	xzr, [x8]
    40201e90:	d503201f 	nop
    40201e94:	101bb728 	adr	x8, 40239578 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers7IN_WORK17h5c2f8327ddf6c11fE.0.llvm.1785347619192815592>
    40201e98:	c89ffd1f 	stlr	xzr, [x8]
    40201e9c:	900001c8 	adrp	x8, 40239000 <jnox_ap_returns+0xd0>
    40201ea0:	f902a513 	str	x19, [x8, #1352]
    40201ea4:	d503201f 	nop
    40201ea8:	101bb488 	adr	x8, 40239538 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers5BATCH17h34c6dfe899ffbb21E.llvm.1785347619192815592>
    40201eac:	a9007d1f 	stp	xzr, xzr, [x8]
    40201eb0:	d503201f 	nop
    40201eb4:	101bb528 	adr	x8, 40239558 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers6REPORT17h79dabd79cd10ba08E.llvm.1785347619192815592>
    40201eb8:	a9007d1f 	stp	xzr, xzr, [x8]
    40201ebc:	a9017d1f 	stp	xzr, xzr, [x8, #16]
    40201ec0:	90000028 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40201ec4:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    40201ec8:	f9014916 	str	x22, [x8, #656]
    40201ecc:	90000028 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40201ed0:	f9015d16 	str	x22, [x8, #696]
    40201ed4:	d503201f 	nop
    40201ed8:	10019955 	adr	x21, 40205200 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers11APPEND_ROWS17hadbbd6f2c286f13aE.llvm.1785347619192815592>
    40201edc:	aa1503e0 	mov	x0, x21
    40201ee0:	52801fe1 	mov	w1, #0xff                  	// #255
    40201ee4:	52800902 	mov	w2, #0x48                  	// #72
    40201ee8:	94000a67 	bl	40204884 <memset>
    40201eec:	910122a0 	add	x0, x21, #0x48
    40201ef0:	52801fe1 	mov	w1, #0xff                  	// #255
    40201ef4:	52800902 	mov	w2, #0x48                  	// #72
    40201ef8:	94000a63 	bl	40204884 <memset>
    40201efc:	d503201f 	nop
    40201f00:	10019cc8 	adr	x8, 40205298 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers11RETURN_ROWS17hc1064bb16cbd219dE.llvm.1785347619192815592>
    40201f04:	a9005916 	stp	x22, x22, [x8]
    40201f08:	a9015916 	stp	x22, x22, [x8, #16]
    40201f0c:	52800748 	mov	w8, #0x3a                  	// #58
    40201f10:	b90003e8 	str	w8, [sp]
    40201f14:	390013ff 	strb	wzr, [sp, #4]
    40201f18:	52800068 	mov	w8, #0x3                   	// #3
    40201f1c:	b9000be8 	str	w8, [sp, #8]
    40201f20:	390033ff 	strb	wzr, [sp, #12]
    40201f24:	d2804020 	mov	x0, #0x201                 	// #513
    40201f28:	f2a08060 	movk	x0, #0x403, lsl #16
    40201f2c:	f2c04040 	movk	x0, #0x202, lsl #32
    40201f30:	910003f6 	mov	x22, sp
    40201f34:	9107e3e8 	add	x8, sp, #0x1f8
    40201f38:	910003e1 	mov	x1, sp
    40201f3c:	97fff9b5 	bl	40200610 <jnox_kernel::mutex_policy::LockSet<_,_>::new>
    40201f40:	f940ffe8 	ldr	x8, [sp, #504]
    40201f44:	f100091f 	cmp	x8, #0x2
    40201f48:	54000061 	b.ne	40201f54 <jnox_kernel::ordinary_mutex_survivors::start+0x114>  // b.any
    40201f4c:	52800020 	mov	w0, #0x1                   	// #1
    40201f50:	97ffffb8 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>
    40201f54:	9107e3f5 	add	x21, sp, #0x1f8
    40201f58:	910003e0 	mov	x0, sp
    40201f5c:	9107e3e1 	add	x1, sp, #0x1f8
    40201f60:	52802d02 	mov	w2, #0x168                 	// #360
    40201f64:	940009c5 	bl	40204678 <memcpy>
    40201f68:	7903efff 	strh	wzr, [sp, #502]
    40201f6c:	9105a2c0 	add	x0, x22, #0x168
    40201f70:	2a1f03e1 	mov	w1, wzr
    40201f74:	52800f02 	mov	w2, #0x78                  	// #120
    40201f78:	94000a43 	bl	40204884 <memset>
    40201f7c:	d503201f 	nop
    40201f80:	30016e81 	adr	x1, 40204d51 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0x71>
    40201f84:	9107c2c0 	add	x0, x22, #0x1f0
    40201f88:	528000c2 	mov	w2, #0x6                   	// #6
    40201f8c:	940009bb 	bl	40204678 <memcpy>
    40201f90:	910042b5 	add	x21, x21, #0x10
    40201f94:	a91e7ff4 	stp	x20, xzr, [sp, #480]
    40201f98:	d503201f 	nop
    40201f9c:	10016ae1 	adr	x1, 40204cf8 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0x18>
    40201fa0:	aa1503e0 	mov	x0, x21
    40201fa4:	52800602 	mov	w2, #0x30                  	// #48
    40201fa8:	940009b4 	bl	40204678 <memcpy>
    40201fac:	aa1f03ea 	mov	x10, xzr
    40201fb0:	f9011fff 	str	xzr, [sp, #568]
    40201fb4:	d503201f 	nop
    40201fb8:	10019bc8 	adr	x8, 40205330 <jnox_kernel::ordinary_mutex_survivors::STACKS>
    40201fbc:	321107e9 	mov	w9, #0x18000               	// #98304
    40201fc0:	9b092268 	madd	x8, x19, x9, x8
    40201fc4:	d1405108 	sub	x8, x8, #0x14, lsl #12
    40201fc8:	d10d0108 	sub	x8, x8, #0x340
    40201fcc:	528068a9 	mov	w9, #0x345                 	// #837
    40201fd0:	528ce00b 	mov	w11, #0x6700                	// #26368
    40201fd4:	f86a7aac 	ldr	x12, [x21, x10, lsl #3]
    40201fd8:	8b0b014d 	add	x13, x10, x11
    40201fdc:	8b0a0ece 	add	x14, x22, x10, lsl #3
    40201fe0:	9100054a 	add	x10, x10, #0x1
    40201fe4:	f9008d0a 	str	x10, [x8, #280]
    40201fe8:	f9004d0d 	str	x13, [x8, #152]
    40201fec:	a90fa50c 	stp	x12, x9, [x8, #248]
    40201ff0:	f900d1c8 	str	x8, [x14, #416]
    40201ff4:	91401108 	add	x8, x8, #0x4, lsl #12
    40201ff8:	f100195f 	cmp	x10, #0x6
    40201ffc:	54fffec1 	b.ne	40201fd4 <jnox_kernel::ordinary_mutex_survivors::start+0x194>  // b.any
    40202000:	910003e0 	mov	x0, sp
    40202004:	aa1f03e1 	mov	x1, xzr
    40202008:	2a1f03e2 	mov	w2, wzr
    4020200c:	94000151 	bl	40202550 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue>
    40202010:	910003e0 	mov	x0, sp
    40202014:	94000030 	bl	402020d4 <jnox_kernel::ordinary_mutex_survivors::Runtime::choose>
    40202018:	aa0003f3 	mov	x19, x0
    4020201c:	d503201f 	nop
    40202020:	10017f40 	adr	x0, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    40202024:	910003e1 	mov	x1, sp
    40202028:	52803f02 	mov	w2, #0x1f8                 	// #504
    4020202c:	94000993 	bl	40204678 <memcpy>
    40202030:	aa1303e0 	mov	x0, x19
    40202034:	97fffe5e 	bl	402019ac <sched_start_frame>

0000000040202038 <jnox_kernel::ordinary_mutex_survivors::Runtime::save>:
    40202038:	f81f0ffe 	str	x30, [sp, #-16]!
    4020203c:	aa0003e8 	mov	x8, x0
    40202040:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202044:	f940ed20 	ldr	x0, [x9, #472]
    40202048:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    4020204c:	f9400129 	ldr	x9, [x9]
    40202050:	528000ca 	mov	w10, #0x6                   	// #6
    40202054:	d503201f 	nop
    40202058:	100196cb 	adr	x11, 40205330 <jnox_kernel::ordinary_mutex_survivors::STACKS>
    4020205c:	9b0a0129 	madd	x9, x9, x10, x0
    40202060:	8b093969 	add	x9, x11, x9, lsl #14
    40202064:	d140612a 	sub	x10, x9, #0x18, lsl #12
    40202068:	92400d0b 	and	x11, x8, #0xf
    4020206c:	d1405129 	sub	x9, x9, #0x14, lsl #12
    40202070:	d10d0129 	sub	x9, x9, #0x340
    40202074:	eb08013f 	cmp	x9, x8
    40202078:	fa402960 	ccmp	x11, #0x0, #0x0, cs  // cs = hs, nlast
    4020207c:	fa480142 	ccmp	x10, x8, #0x2, eq  // eq = none
    40202080:	540001e8 	b.hi	402020bc <jnox_kernel::ordinary_mutex_survivors::Runtime::save+0x84>  // b.pmore
    40202084:	f100141f 	cmp	x0, #0x5
    40202088:	540001e8 	b.hi	402020c4 <jnox_kernel::ordinary_mutex_survivors::Runtime::save+0x8c>  // b.pmore
    4020208c:	d503201f 	nop
    40202090:	10017bc9 	adr	x9, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    40202094:	8b000d29 	add	x9, x9, x0, lsl #3
    40202098:	f940d12a 	ldr	x10, [x9, #416]
    4020209c:	b500010a 	cbnz	x10, 402020bc <jnox_kernel::ordinary_mutex_survivors::Runtime::save+0x84>
    402020a0:	f9408d0a 	ldr	x10, [x8, #280]
    402020a4:	9100040b 	add	x11, x0, #0x1
    402020a8:	eb0b015f 	cmp	x10, x11
    402020ac:	54000081 	b.ne	402020bc <jnox_kernel::ordinary_mutex_survivors::Runtime::save+0x84>  // b.any
    402020b0:	f900d128 	str	x8, [x9, #416]
    402020b4:	f84107fe 	ldr	x30, [sp], #16
    402020b8:	d65f03c0 	ret
    402020bc:	52800080 	mov	w0, #0x4                   	// #4
    402020c0:	97ffff5c 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>
    402020c4:	d503201f 	nop
    402020c8:	10016482 	adr	x2, 40204d58 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0x78>
    402020cc:	528000c1 	mov	w1, #0x6                   	// #6
    402020d0:	940005bd 	bl	402037c4 <core::panicking::panic_bounds_check>

00000000402020d4 <jnox_kernel::ordinary_mutex_survivors::Runtime::choose>:
    402020d4:	d100c3ff 	sub	sp, sp, #0x30
    402020d8:	a90157fe 	stp	x30, x21, [sp, #16]
    402020dc:	a9024ff4 	stp	x20, x19, [sp, #32]
    402020e0:	aa0003f3 	mov	x19, x0
    402020e4:	aa1f03f4 	mov	x20, xzr
    402020e8:	f90007e0 	str	x0, [sp, #8]
    402020ec:	910003f5 	mov	x21, sp
    402020f0:	910023e0 	add	x0, sp, #0x8
    402020f4:	aa1403e1 	mov	x1, x20
    402020f8:	97fff7e4 	bl	40200088 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    402020fc:	38346aa0 	strb	w0, [x21, x20]
    40202100:	91000694 	add	x20, x20, #0x1
    40202104:	f1001a9f 	cmp	x20, #0x6
    40202108:	54ffff41 	b.ne	402020f0 <jnox_kernel::ordinary_mutex_survivors::Runtime::choose+0x1c>  // b.any
    4020210c:	79400be8 	ldrh	w8, [sp, #4]
    40202110:	7903ea68 	strh	w8, [x19, #500]
    40202114:	b94003e8 	ldr	w8, [sp]
    40202118:	b901f268 	str	w8, [x19, #496]
    4020211c:	9105a260 	add	x0, x19, #0x168
    40202120:	9107c261 	add	x1, x19, #0x1f0
    40202124:	940002ee 	bl	40202cdc <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest>
    40202128:	36000360 	tbz	w0, #0, 40202194 <jnox_kernel::ordinary_mutex_survivors::Runtime::choose+0xc0>
    4020212c:	f900ea61 	str	x1, [x19, #464]
    40202130:	f100143f 	cmp	x1, #0x5
    40202134:	54000328 	b.hi	40202198 <jnox_kernel::ordinary_mutex_survivors::Runtime::choose+0xc4>  // b.pmore
    40202138:	8b010e68 	add	x8, x19, x1, lsl #3
    4020213c:	f940d100 	ldr	x0, [x8, #416]
    40202140:	f900d11f 	str	xzr, [x8, #416]
    40202144:	f940ea68 	ldr	x8, [x19, #464]
    40202148:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    4020214c:	f9400129 	ldr	x9, [x9]
    40202150:	528000ca 	mov	w10, #0x6                   	// #6
    40202154:	d503201f 	nop
    40202158:	10018ecb 	adr	x11, 40205330 <jnox_kernel::ordinary_mutex_survivors::STACKS>
    4020215c:	9b0a2128 	madd	x8, x9, x10, x8
    40202160:	8b083968 	add	x8, x11, x8, lsl #14
    40202164:	d1406109 	sub	x9, x8, #0x18, lsl #12
    40202168:	92400c0a 	and	x10, x0, #0xf
    4020216c:	d1405108 	sub	x8, x8, #0x14, lsl #12
    40202170:	d10d0108 	sub	x8, x8, #0x340
    40202174:	eb00011f 	cmp	x8, x0
    40202178:	fa402940 	ccmp	x10, #0x0, #0x0, cs  // cs = hs, nlast
    4020217c:	fa400122 	ccmp	x9, x0, #0x2, eq  // eq = none
    40202180:	54000168 	b.hi	402021ac <jnox_kernel::ordinary_mutex_survivors::Runtime::choose+0xd8>  // b.pmore
    40202184:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40202188:	a94157fe 	ldp	x30, x21, [sp, #16]
    4020218c:	9100c3ff 	add	sp, sp, #0x30
    40202190:	d65f03c0 	ret
    40202194:	94000008 	bl	402021b4 <jnox_kernel::ordinary_mutex_survivors::Runtime::choose::{{closure}}>
    40202198:	d503201f 	nop
    4020219c:	10015ea2 	adr	x2, 40204d70 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0x90>
    402021a0:	aa0103e0 	mov	x0, x1
    402021a4:	528000c1 	mov	w1, #0x6                   	// #6
    402021a8:	94000587 	bl	402037c4 <core::panicking::panic_bounds_check>
    402021ac:	52800080 	mov	w0, #0x4                   	// #4
    402021b0:	97ffff20 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

00000000402021b4 <jnox_kernel::ordinary_mutex_survivors::Runtime::choose::{{closure}}>:
    402021b4:	f81f0ffe 	str	x30, [sp, #-16]!
    402021b8:	52800060 	mov	w0, #0x3                   	// #3
    402021bc:	97ffff1d 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

00000000402021c0 <jnox_kernel::ordinary_mutex_survivors::Runtime::record>:
    402021c0:	d10383ff 	sub	sp, sp, #0xe0
    402021c4:	a9087bfd 	stp	x29, x30, [sp, #128]
    402021c8:	a9096ffc 	stp	x28, x27, [sp, #144]
    402021cc:	a90a67fa 	stp	x26, x25, [sp, #160]
    402021d0:	a90b5ff8 	stp	x24, x23, [sp, #176]
    402021d4:	a90c57f6 	stp	x22, x21, [sp, #192]
    402021d8:	a90d4ff4 	stp	x20, x19, [sp, #208]
    402021dc:	aa1f03ea 	mov	x10, xzr
    402021e0:	aa1f03e9 	mov	x9, xzr
    402021e4:	aa1f03ef 	mov	x15, xzr
    402021e8:	f94073f7 	ldr	x23, [sp, #224]
    402021ec:	a9077fff 	stp	xzr, xzr, [sp, #112]
    402021f0:	f000000b 	adrp	x11, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    402021f4:	9103c16b 	add	x11, x11, #0xf0
    402021f8:	5280002d 	mov	w13, #0x1                   	// #1
    402021fc:	9101c3ee 	add	x14, sp, #0x70
    40202200:	d503201f 	nop
    40202204:	1001702c 	adr	x12, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    40202208:	b85f8168 	ldur	w8, [x11, #-8]
    4020220c:	36000108 	tbz	w8, #0, 4020222c <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x6c>
    40202210:	f9400168 	ldr	x8, [x11]
    40202214:	f100051f 	cmp	x8, #0x1
    40202218:	540017e8 	b.hi	40202514 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x354>  // b.pmore
    4020221c:	9acf21b0 	lsl	x16, x13, x15
    40202220:	f86879d1 	ldr	x17, [x14, x8, lsl #3]
    40202224:	aa100230 	orr	x16, x17, x16
    40202228:	f82879d0 	str	x16, [x14, x8, lsl #3]
    4020222c:	8b0f0188 	add	x8, x12, x15
    40202230:	910005ef 	add	x15, x15, #0x1
    40202234:	3947c108 	ldrb	w8, [x8, #496]
    40202238:	9100416b 	add	x11, x11, #0x10
    4020223c:	9aca2108 	lsl	x8, x8, x10
    40202240:	aa090109 	orr	x9, x8, x9
    40202244:	9100214a 	add	x10, x10, #0x8
    40202248:	f10019ff 	cmp	x15, #0x6
    4020224c:	54fffde1 	b.ne	40202208 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x48>  // b.any
    40202250:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202254:	f940d108 	ldr	x8, [x8, #416]
    40202258:	f1001d1f 	cmp	x8, #0x7
    4020225c:	540014a2 	b.cs	402024f0 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x330>  // b.hs, b.nlast
    40202260:	aa1f03eb 	mov	x11, xzr
    40202264:	b4000108 	cbz	x8, 40202284 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0xc4>
    40202268:	f000000a 	adrp	x10, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    4020226c:	9105c14a 	add	x10, x10, #0x170
    40202270:	f840854d 	ldr	x13, [x10], #8
    40202274:	8b0b11ab 	add	x11, x13, x11, lsl #4
    40202278:	9100056b 	add	x11, x11, #0x1
    4020227c:	f1000508 	subs	x8, x8, #0x1
    40202280:	54ffff81 	b.ne	40202270 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0xb0>  // b.any
    40202284:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202288:	f940ad08 	ldr	x8, [x8, #344]
    4020228c:	f1001d1f 	cmp	x8, #0x7
    40202290:	54001362 	b.cs	402024fc <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x33c>  // b.hs, b.nlast
    40202294:	aa1f03ed 	mov	x13, xzr
    40202298:	b4000108 	cbz	x8, 402022b8 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0xf8>
    4020229c:	f000000a 	adrp	x10, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    402022a0:	9105994a 	add	x10, x10, #0x166
    402022a4:	3840154e 	ldrb	w14, [x10], #1
    402022a8:	8b0d11cd 	add	x13, x14, x13, lsl #4
    402022ac:	910005ad 	add	x13, x13, #0x1
    402022b0:	f1000508 	subs	x8, x8, #0x1
    402022b4:	54ffff81 	b.ne	402022a4 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0xe4>  // b.any
    402022b8:	f10004ff 	cmp	x7, #0x1
    402022bc:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    402022c0:	54000121 	b.ne	402022e4 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x124>  // b.any
    402022c4:	f940ed0a 	ldr	x10, [x8, #472]
    402022c8:	eb17015f 	cmp	x10, x23
    402022cc:	54000081 	b.ne	402022dc <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x11c>  // b.any
    402022d0:	aa0503f8 	mov	x24, x5
    402022d4:	37000084 	tbnz	w4, #0, 402022e4 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x124>
    402022d8:	9400009b 	bl	40202544 <jnox_kernel::ordinary_mutex_survivors::Runtime::record::{{closure}}::{{closure}}>
    402022dc:	8b170d8a 	add	x10, x12, x23, lsl #3
    402022e0:	f940d158 	ldr	x24, [x10, #416]
    402022e4:	f0000015 	adrp	x21, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    402022e8:	f94166aa 	ldr	x10, [x21, #712]
    402022ec:	f100bd5f 	cmp	x10, #0x2f
    402022f0:	540011c8 	b.hi	40202528 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x368>  // b.pmore
    402022f4:	f9409c6a 	ldr	x10, [x3, #312]
    402022f8:	f90013ea 	str	x10, [sp, #32]
    402022fc:	d5033fdf 	isb
    40202300:	d53be02a 	mrs	x10, cntpct_el0
    40202304:	f90017ea 	str	x10, [sp, #40]
    40202308:	f100049f 	cmp	x4, #0x1
    4020230c:	54000121 	b.ne	40202330 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x170>  // b.any
    40202310:	f9407caa 	ldr	x10, [x5, #248]
    40202314:	f90027ea 	str	x10, [sp, #72]
    40202318:	f9404caa 	ldr	x10, [x5, #152]
    4020231c:	f90023ea 	str	x10, [sp, #64]
    40202320:	370000c7 	tbnz	w7, #0, 40202338 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x178>
    40202324:	f9001fff 	str	xzr, [sp, #56]
    40202328:	9280000a 	mov	x10, #0xffffffffffffffff    	// #-1
    4020232c:	14000006 	b	40202344 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x184>
    40202330:	a9047fff 	stp	xzr, xzr, [sp, #64]
    40202334:	3607ff87 	tbz	w7, #0, 40202324 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x164>
    40202338:	f9407f0a 	ldr	x10, [x24, #248]
    4020233c:	f9001fea 	str	x10, [sp, #56]
    40202340:	f940030a 	ldr	x10, [x24]
    40202344:	f9001bea 	str	x10, [sp, #48]
    40202348:	a9061be5 	stp	x5, x6, [sp, #96]
    4020234c:	a9050be4 	stp	x4, x2, [sp, #80]
    40202350:	aa0003f6 	mov	x22, x0
    40202354:	aa0103ef 	mov	x15, x1
    40202358:	360000a4 	tbz	w4, #0, 4020236c <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x1ac>
    4020235c:	f9408caa 	ldr	x10, [x5, #280]
    40202360:	f9000fea 	str	x10, [sp, #24]
    40202364:	f94000aa 	ldr	x10, [x5]
    40202368:	14000003 	b	40202374 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x1b4>
    4020236c:	f9000fff 	str	xzr, [sp, #24]
    40202370:	9280000a 	mov	x10, #0xffffffffffffffff    	// #-1
    40202374:	3947dd99 	ldrb	w25, [x12, #503]
    40202378:	f940ed11 	ldr	x17, [x8, #472]
    4020237c:	a94f9470 	ldp	x16, x5, [x3, #248]
    40202380:	f9404c6e 	ldr	x14, [x3, #152]
    40202384:	a9401192 	ldp	x18, x4, [x12]
    40202388:	a9415193 	ldp	x19, x20, [x12, #16]
    4020238c:	a94703e1 	ldp	x1, x0, [sp, #112]
    40202390:	f9408c7c 	ldr	x28, [x3, #280]
    40202394:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202398:	f940f90c 	ldr	x12, [x8, #496]
    4020239c:	d503201f 	nop
    402023a0:	101b8d88 	adr	x8, 40239550 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers6CHUNKS17h78003a5906450e90E.0.llvm.1785347619192815592>
    402023a4:	c8dffd08 	ldar	x8, [x8]
    402023a8:	a900abe8 	stp	x8, x10, [sp, #8]
    402023ac:	d503201f 	nop
    402023b0:	101b8e48 	adr	x8, 40239578 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers7IN_WORK17h5c2f8327ddf6c11fE.0.llvm.1785347619192815592>
    402023b4:	c8dffd1d 	ldar	x29, [x8]
    402023b8:	d503201f 	nop
    402023bc:	101b8be8 	adr	x8, 40239538 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers5BATCH17h34c6dfe899ffbb21E.llvm.1785347619192815592>
    402023c0:	f940051b 	ldr	x27, [x8, #8]
    402023c4:	f940010a 	ldr	x10, [x8]
    402023c8:	d503201f 	nop
    402023cc:	101b8c68 	adr	x8, 40239558 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers6REPORT17h79dabd79cd10ba08E.llvm.1785347619192815592>
    402023d0:	f9400d1a 	ldr	x26, [x8, #24]
    402023d4:	f940091e 	ldr	x30, [x8, #16]
    402023d8:	f9400506 	ldr	x6, [x8, #8]
    402023dc:	f9400102 	ldr	x2, [x8]
    402023e0:	f94166a8 	ldr	x8, [x21, #712]
    402023e4:	f100c11f 	cmp	x8, #0x30
    402023e8:	54000a42 	b.cs	40202530 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x370>  // b.hs, b.nlast
    402023ec:	720000ff 	tst	w7, #0x1
    402023f0:	d503201f 	nop
    402023f4:	101979e7 	adr	x7, 40235330 <jnox_kernel::ordinary_mutex_survivors::JOURNAL>
    402023f8:	52802815 	mov	w21, #0x140                 	// #320
    402023fc:	9b151d07 	madd	x7, x8, x21, x7
    40202400:	f94013f5 	ldr	x21, [sp, #32]
    40202404:	f90000f5 	str	x21, [x7]
    40202408:	f94017f5 	ldr	x21, [sp, #40]
    4020240c:	a900d8f5 	stp	x21, x22, [x7, #8]
    40202410:	f9000cef 	str	x15, [x7, #24]
    40202414:	9a9f130f 	csel	x15, x24, xzr, ne  // ne = any
    40202418:	da9f12f5 	csinv	x21, x23, xzr, ne  // ne = any
    4020241c:	7100027f 	cmp	w19, #0x0
    40202420:	da9f1293 	csinv	x19, x20, xzr, ne  // ne = any
    40202424:	7100025f 	cmp	w18, #0x0
    40202428:	da9f1092 	csinv	x18, x4, xzr, ne  // ne = any
    4020242c:	f9402be4 	ldr	x4, [sp, #80]
    40202430:	7200009f 	tst	w4, #0x1
    40202434:	da9f1231 	csinv	x17, x17, xzr, ne  // ne = any
    40202438:	f9402fe4 	ldr	x4, [sp, #88]
    4020243c:	a90244e4 	stp	x4, x17, [x7, #32]
    40202440:	a90340e3 	stp	x3, x16, [x7, #48]
    40202444:	a90438e5 	stp	x5, x14, [x7, #64]
    40202448:	f0000010 	adrp	x16, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    4020244c:	f9415e10 	ldr	x16, [x16, #696]
    40202450:	f000000e 	adrp	x14, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202454:	f94149ce 	ldr	x14, [x14, #656]
    40202458:	f94033f1 	ldr	x17, [sp, #96]
    4020245c:	9a9f1231 	csel	x17, x17, xzr, ne  // ne = any
    40202460:	f90028f1 	str	x17, [x7, #80]
    40202464:	f94027f1 	ldr	x17, [sp, #72]
    40202468:	f9002cf1 	str	x17, [x7, #88]
    4020246c:	f94023f1 	ldr	x17, [sp, #64]
    40202470:	a90664f1 	stp	x17, x25, [x7, #96]
    40202474:	a9074cf2 	stp	x18, x19, [x7, #112]
    40202478:	a90800e1 	stp	x1, x0, [x7, #128]
    4020247c:	f90048e9 	str	x9, [x7, #144]
    40202480:	f94037e9 	ldr	x9, [sp, #104]
    40202484:	a909d4e9 	stp	x9, x21, [x7, #152]
    40202488:	f9401fe9 	ldr	x9, [sp, #56]
    4020248c:	a90aa4ef 	stp	x15, x9, [x7, #168]
    40202490:	f9401be9 	ldr	x9, [sp, #48]
    40202494:	a90bf0e9 	stp	x9, x28, [x7, #184]
    40202498:	f9400fe9 	ldr	x9, [sp, #24]
    4020249c:	f90064e9 	str	x9, [x7, #200]
    402024a0:	f9400be9 	ldr	x9, [sp, #16]
    402024a4:	a90d2ce9 	stp	x9, x11, [x7, #208]
    402024a8:	a90e30ed 	stp	x13, x12, [x7, #224]
    402024ac:	f94007e9 	ldr	x9, [sp, #8]
    402024b0:	a90f24fd 	stp	x29, x9, [x7, #240]
    402024b4:	a9106cea 	stp	x10, x27, [x7, #256]
    402024b8:	a91118e2 	stp	x2, x6, [x7, #272]
    402024bc:	a91268fe 	stp	x30, x26, [x7, #288]
    402024c0:	a91340ee 	stp	x14, x16, [x7, #304]
    402024c4:	91000508 	add	x8, x8, #0x1
    402024c8:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    402024cc:	f9016528 	str	x8, [x9, #712]
    402024d0:	a94d4ff4 	ldp	x20, x19, [sp, #208]
    402024d4:	a94c57f6 	ldp	x22, x21, [sp, #192]
    402024d8:	a94b5ff8 	ldp	x24, x23, [sp, #176]
    402024dc:	a94a67fa 	ldp	x26, x25, [sp, #160]
    402024e0:	a9496ffc 	ldp	x28, x27, [sp, #144]
    402024e4:	a9487bfd 	ldp	x29, x30, [sp, #128]
    402024e8:	910383ff 	add	sp, sp, #0xe0
    402024ec:	d65f03c0 	ret
    402024f0:	d503201f 	nop
    402024f4:	10014aa3 	adr	x3, 40204e48 <anon.a96ef1ad02bf9434d4f9fb3a54991149.4.llvm.1785347619192815592>
    402024f8:	14000003 	b	40202504 <jnox_kernel::ordinary_mutex_survivors::Runtime::record+0x344>
    402024fc:	d503201f 	nop
    40202500:	10013283 	adr	x3, 40204b50 <anon.6ed93a0cdbab6e50679980c3de7a7cf9.4.llvm.13497221849890916907>
    40202504:	aa1f03e0 	mov	x0, xzr
    40202508:	aa0803e1 	mov	x1, x8
    4020250c:	528000c2 	mov	w2, #0x6                   	// #6
    40202510:	940006ac 	bl	40203fc0 <core::slice::index::slice_index_fail>
    40202514:	d503201f 	nop
    40202518:	10014442 	adr	x2, 40204da0 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0xc0>
    4020251c:	aa0803e0 	mov	x0, x8
    40202520:	52800041 	mov	w1, #0x2                   	// #2
    40202524:	940004a8 	bl	402037c4 <core::panicking::panic_bounds_check>
    40202528:	528000a0 	mov	w0, #0x5                   	// #5
    4020252c:	97fffe41 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>
    40202530:	d503201f 	nop
    40202534:	100142a2 	adr	x2, 40204d88 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0xa8>
    40202538:	aa0803e0 	mov	x0, x8
    4020253c:	52800601 	mov	w1, #0x30                  	// #48
    40202540:	940004a1 	bl	402037c4 <core::panicking::panic_bounds_check>

0000000040202544 <jnox_kernel::ordinary_mutex_survivors::Runtime::record::{{closure}}::{{closure}}>:
    40202544:	f81f0ffe 	str	x30, [sp, #-16]!
    40202548:	52800080 	mov	w0, #0x4                   	// #4
    4020254c:	97fffe39 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

0000000040202550 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue>:
    40202550:	f81f0ffe 	str	x30, [sp, #-16]!
    40202554:	3947dc08 	ldrb	w8, [x0, #503]
    40202558:	12000829 	and	w9, w1, #0x7
    4020255c:	1ac92508 	lsr	w8, w8, w9
    40202560:	37000328 	tbnz	w8, #0, 402025c4 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue+0x74>
    40202564:	f100143f 	cmp	x1, #0x5
    40202568:	540003e8 	b.hi	402025e4 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue+0x94>  // b.pmore
    4020256c:	8b011008 	add	x8, x0, x1, lsl #4
    40202570:	f9407108 	ldr	x8, [x8, #224]
    40202574:	b5000288 	cbnz	x8, 402025c4 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue+0x74>
    40202578:	8b010c08 	add	x8, x0, x1, lsl #3
    4020257c:	f940d108 	ldr	x8, [x8, #416]
    40202580:	b4000228 	cbz	x8, 402025c4 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue+0x74>
    40202584:	9105a008 	add	x8, x0, #0x168
    40202588:	340000a2 	cbz	w2, 4020259c <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue+0x4c>
    4020258c:	aa0803e0 	mov	x0, x8
    40202590:	940001b1 	bl	40202c54 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front>
    40202594:	36000180 	tbz	w0, #0, 402025c4 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue+0x74>
    40202598:	14000011 	b	402025dc <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue+0x8c>
    4020259c:	f940cc09 	ldr	x9, [x0, #408]
    402025a0:	f100153f 	cmp	x9, #0x5
    402025a4:	54000108 	b.hi	402025c4 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue+0x74>  // b.pmore
    402025a8:	d37df12a 	lsl	x10, x9, #3
    402025ac:	9105a00b 	add	x11, x0, #0x168
    402025b0:	b40000ea 	cbz	x10, 402025cc <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue+0x7c>
    402025b4:	f840856c 	ldr	x12, [x11], #8
    402025b8:	d100214a 	sub	x10, x10, #0x8
    402025bc:	eb01019f 	cmp	x12, x1
    402025c0:	54ffff81 	b.ne	402025b0 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue+0x60>  // b.any
    402025c4:	52800040 	mov	w0, #0x2                   	// #2
    402025c8:	97fffe1a 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>
    402025cc:	f8297901 	str	x1, [x8, x9, lsl #3]
    402025d0:	f940cc08 	ldr	x8, [x0, #408]
    402025d4:	91000508 	add	x8, x8, #0x1
    402025d8:	f900cc08 	str	x8, [x0, #408]
    402025dc:	f84107fe 	ldr	x30, [sp], #16
    402025e0:	d65f03c0 	ret
    402025e4:	d503201f 	nop
    402025e8:	10013e82 	adr	x2, 40204db8 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0xd8>
    402025ec:	aa0103e0 	mov	x0, x1
    402025f0:	528000c1 	mov	w1, #0x6                   	// #6
    402025f4:	94000474 	bl	402037c4 <core::panicking::panic_bounds_check>

00000000402025f8 <jnox_kernel::ordinary_mutex_survivors::checked>:
    402025f8:	aa0003e8 	mov	x8, x0
    402025fc:	aa0103e0 	mov	x0, x1
    40202600:	d4000001 	svc	#0x0
    40202604:	b5000040 	cbnz	x0, 4020260c <jnox_kernel::ordinary_mutex_survivors::checked+0x14>
    40202608:	d65f03c0 	ret
    4020260c:	f81f0ffe 	str	x30, [sp, #-16]!
    40202610:	52800160 	mov	w0, #0xb                   	// #11
    40202614:	97fffe07 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

0000000040202618 <jnox_kernel::ordinary_mutex_survivors::request>:
    40202618:	d101c3ff 	sub	sp, sp, #0x70
    4020261c:	f90013fe 	str	x30, [sp, #32]
    40202620:	a90367fa 	stp	x26, x25, [sp, #48]
    40202624:	a9045ff8 	stp	x24, x23, [sp, #64]
    40202628:	a90557f6 	stp	x22, x21, [sp, #80]
    4020262c:	a9064ff4 	stp	x20, x19, [sp, #96]
    40202630:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202634:	f9400508 	ldr	x8, [x8, #8]
    40202638:	f100091f 	cmp	x8, #0x2
    4020263c:	54001fa0 	b.eq	40202a30 <jnox_kernel::ordinary_mutex_survivors::request+0x418>  // b.none
    40202640:	aa0003f3 	mov	x19, x0
    40202644:	97fffe7d 	bl	40202038 <jnox_kernel::ordinary_mutex_survivors::Runtime::save>
    40202648:	aa0003f4 	mov	x20, x0
    4020264c:	f9402276 	ldr	x22, [x19, #64]
    40202650:	f9400275 	ldr	x21, [x19]
    40202654:	f1000adf 	cmp	x22, #0x2
    40202658:	540005ed 	b.le	40202714 <jnox_kernel::ordinary_mutex_survivors::request+0xfc>
    4020265c:	f1000edf 	cmp	x22, #0x3
    40202660:	54000ae0 	b.eq	402027bc <jnox_kernel::ordinary_mutex_survivors::request+0x1a4>  // b.none
    40202664:	f10012df 	cmp	x22, #0x4
    40202668:	54000da0 	b.eq	4020281c <jnox_kernel::ordinary_mutex_survivors::request+0x204>  // b.none
    4020266c:	f1001adf 	cmp	x22, #0x6
    40202670:	54001e41 	b.ne	40202a38 <jnox_kernel::ordinary_mutex_survivors::request+0x420>  // b.any
    40202674:	f100069f 	cmp	x20, #0x1
    40202678:	54001e01 	b.ne	40202a38 <jnox_kernel::ordinary_mutex_survivors::request+0x420>  // b.any
    4020267c:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202680:	f940f908 	ldr	x8, [x8, #496]
    40202684:	f100091f 	cmp	x8, #0x2
    40202688:	54001d82 	b.cs	40202a38 <jnox_kernel::ordinary_mutex_survivors::request+0x420>  // b.hs, b.nlast
    4020268c:	d503201f 	nop
    40202690:	10014bd7 	adr	x23, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    40202694:	f94002e9 	ldr	x9, [x23]
    40202698:	f100053f 	cmp	x9, #0x1
    4020269c:	54001ce1 	b.ne	40202a38 <jnox_kernel::ordinary_mutex_survivors::request+0x420>  // b.any
    402026a0:	f94006e9 	ldr	x9, [x23, #8]
    402026a4:	f100053f 	cmp	x9, #0x1
    402026a8:	54001c81 	b.ne	40202a38 <jnox_kernel::ordinary_mutex_survivors::request+0x420>  // b.any
    402026ac:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    402026b0:	f9400129 	ldr	x9, [x9]
    402026b4:	f100053f 	cmp	x9, #0x1
    402026b8:	5280008a 	mov	w10, #0x4                   	// #4
    402026bc:	9a8a0549 	cinc	x9, x10, ne  // ne = any
    402026c0:	9a8a154a 	cinc	x10, x10, eq  // eq = none
    402026c4:	a9012be9 	stp	x9, x10, [sp, #16]
    402026c8:	f100051f 	cmp	x8, #0x1
    402026cc:	540000e1 	b.ne	402026e8 <jnox_kernel::ordinary_mutex_survivors::request+0xd0>  // b.any
    402026d0:	8b0912e9 	add	x9, x23, x9, lsl #4
    402026d4:	f940712a 	ldr	x10, [x9, #224]
    402026d8:	f100055f 	cmp	x10, #0x1
    402026dc:	54001b21 	b.ne	40202a40 <jnox_kernel::ordinary_mutex_survivors::request+0x428>  // b.any
    402026e0:	f9407529 	ldr	x9, [x9, #232]
    402026e4:	b5001ae9 	cbnz	x9, 40202a40 <jnox_kernel::ordinary_mutex_survivors::request+0x428>
    402026e8:	910043e9 	add	x9, sp, #0x10
    402026ec:	f8687921 	ldr	x1, [x9, x8, lsl #3]
    402026f0:	aa1703e0 	mov	x0, x23
    402026f4:	2a1f03e2 	mov	w2, wzr
    402026f8:	97ffff96 	bl	40202550 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue>
    402026fc:	f940f6e8 	ldr	x8, [x23, #488]
    40202700:	91000508 	add	x8, x8, #0x1
    40202704:	f900f6e8 	str	x8, [x23, #488]
    40202708:	f900027f 	str	xzr, [x19]
    4020270c:	aa1703e0 	mov	x0, x23
    40202710:	14000077 	b	402028ec <jnox_kernel::ordinary_mutex_survivors::request+0x2d4>
    40202714:	f10006df 	cmp	x22, #0x1
    40202718:	54000520 	b.eq	402027bc <jnox_kernel::ordinary_mutex_survivors::request+0x1a4>  // b.none
    4020271c:	f1000adf 	cmp	x22, #0x2
    40202720:	540018c1 	b.ne	40202a38 <jnox_kernel::ordinary_mutex_survivors::request+0x420>  // b.any
    40202724:	d503201f 	nop
    40202728:	10014717 	adr	x23, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    4020272c:	aa1703e0 	mov	x0, x23
    40202730:	aa1403e1 	mov	x1, x20
    40202734:	aa1503e2 	mov	x2, x21
    40202738:	97fff83c 	bl	40200828 <jnox_kernel::mutex_policy::LockSet<_,_>::release>
    4020273c:	f100081f 	cmp	x0, #0x2
    40202740:	54001840 	b.eq	40202a48 <jnox_kernel::ordinary_mutex_survivors::request+0x430>  // b.none
    40202744:	36000ec0 	tbz	w0, #0, 4020291c <jnox_kernel::ordinary_mutex_survivors::request+0x304>
    40202748:	aa0103f8 	mov	x24, x1
    4020274c:	f100183f 	cmp	x1, #0x6
    40202750:	54001862 	b.cs	40202a5c <jnox_kernel::ordinary_mutex_survivors::request+0x444>  // b.hs, b.nlast
    40202754:	8b180ee8 	add	x8, x23, x24, lsl #3
    40202758:	f940d108 	ldr	x8, [x8, #416]
    4020275c:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202760:	f9400129 	ldr	x9, [x9]
    40202764:	528000ca 	mov	w10, #0x6                   	// #6
    40202768:	9b0a6129 	madd	x9, x9, x10, x24
    4020276c:	d503201f 	nop
    40202770:	10015e0a 	adr	x10, 40205330 <jnox_kernel::ordinary_mutex_survivors::STACKS>
    40202774:	8b093949 	add	x9, x10, x9, lsl #14
    40202778:	d140512a 	sub	x10, x9, #0x14, lsl #12
    4020277c:	d10d014a 	sub	x10, x10, #0x340
    40202780:	eb08015f 	cmp	x10, x8
    40202784:	54001763 	b.cc	40202a70 <jnox_kernel::ordinary_mutex_survivors::request+0x458>  // b.lo, b.ul, b.last
    40202788:	92400d0a 	and	x10, x8, #0xf
    4020278c:	b500172a 	cbnz	x10, 40202a70 <jnox_kernel::ordinary_mutex_survivors::request+0x458>
    40202790:	d1406129 	sub	x9, x9, #0x18, lsl #12
    40202794:	eb08013f 	cmp	x9, x8
    40202798:	540016c8 	b.hi	40202a70 <jnox_kernel::ordinary_mutex_survivors::request+0x458>  // b.pmore
    4020279c:	f900011f 	str	xzr, [x8]
    402027a0:	d503201f 	nop
    402027a4:	10014320 	adr	x0, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    402027a8:	aa1803e1 	mov	x1, x24
    402027ac:	2a1f03e2 	mov	w2, wzr
    402027b0:	97ffff68 	bl	40202550 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue>
    402027b4:	52800037 	mov	w23, #0x1                   	// #1
    402027b8:	1400005a 	b	40202920 <jnox_kernel::ordinary_mutex_survivors::request+0x308>
    402027bc:	d503201f 	nop
    402027c0:	10014240 	adr	x0, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    402027c4:	aa1403e1 	mov	x1, x20
    402027c8:	aa1503e2 	mov	x2, x21
    402027cc:	97fff7de 	bl	40200744 <jnox_kernel::mutex_policy::LockSet<_,_>::acquire>
    402027d0:	72001c08 	ands	w8, w0, #0xff
    402027d4:	54000760 	b.eq	402028c0 <jnox_kernel::ordinary_mutex_survivors::request+0x2a8>  // b.none
    402027d8:	7100091f 	cmp	w8, #0x2
    402027dc:	54001320 	b.eq	40202a40 <jnox_kernel::ordinary_mutex_survivors::request+0x428>  // b.none
    402027e0:	f100069f 	cmp	x20, #0x1
    402027e4:	54000901 	b.ne	40202904 <jnox_kernel::ordinary_mutex_survivors::request+0x2ec>  // b.any
    402027e8:	f10006bf 	cmp	x21, #0x1
    402027ec:	540008c1 	b.ne	40202904 <jnox_kernel::ordinary_mutex_survivors::request+0x2ec>  // b.any
    402027f0:	d503201f 	nop
    402027f4:	100140b7 	adr	x23, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    402027f8:	aa1703e0 	mov	x0, x23
    402027fc:	52800061 	mov	w1, #0x3                   	// #3
    40202800:	2a1f03e2 	mov	w2, wzr
    40202804:	97ffff53 	bl	40202550 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue>
    40202808:	aa1703e0 	mov	x0, x23
    4020280c:	52800041 	mov	w1, #0x2                   	// #2
    40202810:	2a1f03e2 	mov	w2, wzr
    40202814:	97ffff4f 	bl	40202550 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue>
    40202818:	1400004f 	b	40202954 <jnox_kernel::ordinary_mutex_survivors::request+0x33c>
    4020281c:	52800028 	mov	w8, #0x1                   	// #1
    40202820:	1ad42108 	lsl	w8, w8, w20
    40202824:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202828:	3947fd2a 	ldrb	w10, [x9, #511]
    4020282c:	2a080148 	orr	w8, w10, w8
    40202830:	3907fd28 	strb	w8, [x9, #511]
    40202834:	7100fd1f 	cmp	w8, #0x3f
    40202838:	54000601 	b.ne	402028f8 <jnox_kernel::ordinary_mutex_survivors::request+0x2e0>  // b.any
    4020283c:	52800080 	mov	w0, #0x4                   	// #4
    40202840:	aa1503e1 	mov	x1, x21
    40202844:	aa1403e2 	mov	x2, x20
    40202848:	aa1303e3 	mov	x3, x19
    4020284c:	aa1f03e4 	mov	x4, xzr
    40202850:	aa1f03e6 	mov	x6, xzr
    40202854:	aa1f03e7 	mov	x7, xzr
    40202858:	97fffe5a 	bl	402021c0 <jnox_kernel::ordinary_mutex_survivors::Runtime::record>
    4020285c:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202860:	f940f513 	ldr	x19, [x8, #488]
    40202864:	aa1f03e0 	mov	x0, xzr
    40202868:	97fffca6 	bl	40201b00 <jnox_kernel::ordinary_mutex_survivors::dump>
    4020286c:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202870:	f9400108 	ldr	x8, [x8]
    40202874:	f100051f 	cmp	x8, #0x1
    40202878:	54000ec0 	b.eq	40202a50 <jnox_kernel::ordinary_mutex_survivors::request+0x438>  // b.none
    4020287c:	aa1f03e8 	mov	x8, xzr
    40202880:	52800309 	mov	w9, #0x18                  	// #24
    40202884:	72a12009 	movk	w9, #0x900, lsl #16
    40202888:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    4020288c:	d503201f 	nop
    40202890:	10012acb 	adr	x11, 40204de8 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0x108>
    40202894:	3868696c 	ldrb	w12, [x11, x8]
    40202898:	b940012d 	ldr	w13, [x9]
    4020289c:	3628006d 	tbz	w13, #5, 402028a8 <jnox_kernel::ordinary_mutex_survivors::request+0x290>
    402028a0:	d5033fdf 	isb
    402028a4:	17fffffd 	b	40202898 <jnox_kernel::ordinary_mutex_survivors::request+0x280>
    402028a8:	91000508 	add	x8, x8, #0x1
    402028ac:	b900014c 	str	w12, [x10]
    402028b0:	f1004d1f 	cmp	x8, #0x13
    402028b4:	54ffff01 	b.ne	40202894 <jnox_kernel::ordinary_mutex_survivors::request+0x27c>  // b.any
    402028b8:	d503205f 	wfe
    402028bc:	17ffffff 	b	402028b8 <jnox_kernel::ordinary_mutex_survivors::request+0x2a0>
    402028c0:	f1000edf 	cmp	x22, #0x3
    402028c4:	54000be0 	b.eq	40202a40 <jnox_kernel::ordinary_mutex_survivors::request+0x428>  // b.none
    402028c8:	f900027f 	str	xzr, [x19]
    402028cc:	d503201f 	nop
    402028d0:	100139c0 	adr	x0, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    402028d4:	aa1403e1 	mov	x1, x20
    402028d8:	52800022 	mov	w2, #0x1                   	// #1
    402028dc:	97ffff1d 	bl	40202550 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue>
    402028e0:	b50000d4 	cbnz	x20, 402028f8 <jnox_kernel::ordinary_mutex_survivors::request+0x2e0>
    402028e4:	d503201f 	nop
    402028e8:	10013900 	adr	x0, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    402028ec:	52800021 	mov	w1, #0x1                   	// #1
    402028f0:	2a1f03e2 	mov	w2, wzr
    402028f4:	97ffff17 	bl	40202550 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue>
    402028f8:	aa1f03f7 	mov	x23, xzr
    402028fc:	aa1f03f9 	mov	x25, xzr
    40202900:	14000017 	b	4020295c <jnox_kernel::ordinary_mutex_survivors::request+0x344>
    40202904:	f100129f 	cmp	x20, #0x4
    40202908:	540001c1 	b.ne	40202940 <jnox_kernel::ordinary_mutex_survivors::request+0x328>  // b.any
    4020290c:	f10006df 	cmp	x22, #0x1
    40202910:	54000981 	b.ne	40202a40 <jnox_kernel::ordinary_mutex_survivors::request+0x428>  // b.any
    40202914:	b4000215 	cbz	x21, 40202954 <jnox_kernel::ordinary_mutex_survivors::request+0x33c>
    40202918:	1400004a 	b	40202a40 <jnox_kernel::ordinary_mutex_survivors::request+0x428>
    4020291c:	aa1f03f7 	mov	x23, xzr
    40202920:	f900027f 	str	xzr, [x19]
    40202924:	d503201f 	nop
    40202928:	10013700 	adr	x0, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    4020292c:	aa1403e1 	mov	x1, x20
    40202930:	52800022 	mov	w2, #0x1                   	// #1
    40202934:	97ffff07 	bl	40202550 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue>
    40202938:	aa1f03f9 	mov	x25, xzr
    4020293c:	14000008 	b	4020295c <jnox_kernel::ordinary_mutex_survivors::request+0x344>
    40202940:	f100169f 	cmp	x20, #0x5
    40202944:	54000381 	b.ne	402029b4 <jnox_kernel::ordinary_mutex_survivors::request+0x39c>  // b.any
    40202948:	f10006df 	cmp	x22, #0x1
    4020294c:	54000341 	b.ne	402029b4 <jnox_kernel::ordinary_mutex_survivors::request+0x39c>  // b.any
    40202950:	b5000335 	cbnz	x21, 402029b4 <jnox_kernel::ordinary_mutex_survivors::request+0x39c>
    40202954:	aa1f03f7 	mov	x23, xzr
    40202958:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    4020295c:	d503201f 	nop
    40202960:	10013540 	adr	x0, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    40202964:	97fffddc 	bl	402020d4 <jnox_kernel::ordinary_mutex_survivors::Runtime::choose>
    40202968:	aa0003fa 	mov	x26, x0
    4020296c:	f90003f8 	str	x24, [sp]
    40202970:	aa1603e0 	mov	x0, x22
    40202974:	aa1503e1 	mov	x1, x21
    40202978:	aa1403e2 	mov	x2, x20
    4020297c:	aa1303e3 	mov	x3, x19
    40202980:	52800024 	mov	w4, #0x1                   	// #1
    40202984:	aa1a03e5 	mov	x5, x26
    40202988:	aa1903e6 	mov	x6, x25
    4020298c:	aa1703e7 	mov	x7, x23
    40202990:	97fffe0c 	bl	402021c0 <jnox_kernel::ordinary_mutex_survivors::Runtime::record>
    40202994:	aa1a03e0 	mov	x0, x26
    40202998:	a9464ff4 	ldp	x20, x19, [sp, #96]
    4020299c:	a94557f6 	ldp	x22, x21, [sp, #80]
    402029a0:	a9445ff8 	ldp	x24, x23, [sp, #64]
    402029a4:	a94367fa 	ldp	x26, x25, [sp, #48]
    402029a8:	f94013fe 	ldr	x30, [sp, #32]
    402029ac:	9101c3ff 	add	sp, sp, #0x70
    402029b0:	d65f03c0 	ret
    402029b4:	f1000e9f 	cmp	x20, #0x3
    402029b8:	54000441 	b.ne	40202a40 <jnox_kernel::ordinary_mutex_survivors::request+0x428>  // b.any
    402029bc:	f1000edf 	cmp	x22, #0x3
    402029c0:	54000401 	b.ne	40202a40 <jnox_kernel::ordinary_mutex_survivors::request+0x428>  // b.any
    402029c4:	b50003f5 	cbnz	x21, 40202a40 <jnox_kernel::ordinary_mutex_survivors::request+0x428>
    402029c8:	d5033fdf 	isb
    402029cc:	d53be028 	mrs	x8, cntpct_el0
    402029d0:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    402029d4:	f940f52a 	ldr	x10, [x9, #488]
    402029d8:	d343fd49 	lsr	x9, x10, #3
    402029dc:	d29ef9eb 	mov	x11, #0xf7cf                	// #63439
    402029e0:	f2bc6a6b 	movk	x11, #0xe353, lsl #16
    402029e4:	f2d374ab 	movk	x11, #0x9ba5, lsl #32
    402029e8:	f2e4188b 	movk	x11, #0x20c4, lsl #48
    402029ec:	9bcb7d29 	umulh	x9, x9, x11
    402029f0:	ab491109 	adds	x9, x8, x9, lsr #4
    402029f4:	54000422 	b.cs	40202a78 <jnox_kernel::ordinary_mutex_survivors::request+0x460>  // b.hs, b.nlast
    402029f8:	aa1f03f7 	mov	x23, xzr
    402029fc:	f000000b 	adrp	x11, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202a00:	9107816b 	add	x11, x11, #0x1e0
    40202a04:	f9000169 	str	x9, [x11]
    40202a08:	5280002c 	mov	w12, #0x1                   	// #1
    40202a0c:	d503201f 	nop
    40202a10:	1001460d 	adr	x13, 402052d0 <jnox_kernel::ordinary_mutex_survivors::TIMER>
    40202a14:	3900796c 	strb	w12, [x11, #30]
    40202a18:	a90021aa 	stp	x10, x8, [x13]
    40202a1c:	f90009a9 	str	x9, [x13, #16]
    40202a20:	d51be249 	msr	cntp_cval_el0, x9
    40202a24:	d51be22c 	msr	cntp_ctl_el0, x12
    40202a28:	d5033fdf 	isb
    40202a2c:	17ffffcb 	b	40202958 <jnox_kernel::ordinary_mutex_survivors::request+0x340>
    40202a30:	52800020 	mov	w0, #0x1                   	// #1
    40202a34:	97fffcff 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>
    40202a38:	52800100 	mov	w0, #0x8                   	// #8
    40202a3c:	97fffcfd 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>
    40202a40:	528000c0 	mov	w0, #0x6                   	// #6
    40202a44:	97fffcfb 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>
    40202a48:	528000e0 	mov	w0, #0x7                   	// #7
    40202a4c:	97fffcf9 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>
    40202a50:	52800040 	mov	w0, #0x2                   	// #2
    40202a54:	aa1303e1 	mov	x1, x19
    40202a58:	97fffcfa 	bl	40201e40 <jnox_kernel::ordinary_mutex_survivors::start>
    40202a5c:	d503201f 	nop
    40202a60:	10011b82 	adr	x2, 40204dd0 <anon.4647c77b832f619570b67d6a55a6fef3.12.llvm.13055757901172775173+0xf0>
    40202a64:	aa1803e0 	mov	x0, x24
    40202a68:	528000c1 	mov	w1, #0x6                   	// #6
    40202a6c:	94000356 	bl	402037c4 <core::panicking::panic_bounds_check>
    40202a70:	52800080 	mov	w0, #0x4                   	// #4
    40202a74:	97fffcef 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>
    40202a78:	94000001 	bl	40202a7c <jnox_kernel::ordinary_mutex_survivors::request::{{closure}}>

0000000040202a7c <jnox_kernel::ordinary_mutex_survivors::request::{{closure}}>:
    40202a7c:	f81f0ffe 	str	x30, [sp, #-16]!
    40202a80:	528000c0 	mov	w0, #0x6                   	// #6
    40202a84:	97fffceb 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

0000000040202a88 <jnox_kernel::ordinary_mutex_survivors::interrupt>:
    40202a88:	d100c3ff 	sub	sp, sp, #0x30
    40202a8c:	f9000bfe 	str	x30, [sp, #16]
    40202a90:	a9024ff4 	stp	x20, x19, [sp, #32]
    40202a94:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202a98:	f9400508 	ldr	x8, [x8, #8]
    40202a9c:	f100091f 	cmp	x8, #0x2
    40202aa0:	54000d20 	b.eq	40202c44 <jnox_kernel::ordinary_mutex_survivors::interrupt+0x1bc>  // b.none
    40202aa4:	aa0003f3 	mov	x19, x0
    40202aa8:	97fffd64 	bl	40202038 <jnox_kernel::ordinary_mutex_survivors::Runtime::save>
    40202aac:	52800189 	mov	w9, #0xc                   	// #12
    40202ab0:	72a10029 	movk	w9, #0x801, lsl #16
    40202ab4:	b940012d 	ldr	w13, [x9]
    40202ab8:	d53be22b 	mrs	x11, cntp_ctl_el0
    40202abc:	d53be248 	mrs	x8, cntp_cval_el0
    40202ac0:	d51be23f 	msr	cntp_ctl_el0, xzr
    40202ac4:	d5033fdf 	isb
    40202ac8:	f000000e 	adrp	x14, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202acc:	910ba1ce 	add	x14, x14, #0x2e8
    40202ad0:	a9002dcd 	stp	x13, x11, [x14]
    40202ad4:	f90009c8 	str	x8, [x14, #16]
    40202ad8:	d503201f 	nop
    40202adc:	101b53aa 	adr	x10, 40239550 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers6CHUNKS17h78003a5906450e90E.0.llvm.1785347619192815592>
    40202ae0:	b900052d 	str	w13, [x9, #4]
    40202ae4:	d503201f 	nop
    40202ae8:	101b5489 	adr	x9, 40239578 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers7IN_WORK17h5c2f8327ddf6c11fE.0.llvm.1785347619192815592>
    40202aec:	d5033f9f 	dsb	sy
    40202af0:	d5033fdf 	isb
    40202af4:	c8dffd4a 	ldar	x10, [x10]
    40202af8:	c8dffd29 	ldar	x9, [x9]
    40202afc:	f9409e6c 	ldr	x12, [x19, #312]
    40202b00:	a901cdcc 	stp	x12, x19, [x14, #24]
    40202b04:	f9407e6f 	ldr	x15, [x19, #248]
    40202b08:	a90281cf 	stp	x15, x0, [x14, #40]
    40202b0c:	a903a5ca 	stp	x10, x9, [x14, #56]
    40202b10:	120025ad 	and	w13, w13, #0x3ff
    40202b14:	710079bf 	cmp	w13, #0x1e
    40202b18:	54000921 	b.ne	40202c3c <jnox_kernel::ordinary_mutex_survivors::interrupt+0x1b4>  // b.any
    40202b1c:	b5000900 	cbnz	x0, 40202c3c <jnox_kernel::ordinary_mutex_survivors::interrupt+0x1b4>
    40202b20:	f000000d 	adrp	x13, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202b24:	910781ad 	add	x13, x13, #0x1e0
    40202b28:	394079ae 	ldrb	w14, [x13, #30]
    40202b2c:	3600088e 	tbz	w14, #0, 40202c3c <jnox_kernel::ordinary_mutex_survivors::interrupt+0x1b4>
    40202b30:	9240096b 	and	x11, x11, #0x7
    40202b34:	f100157f 	cmp	x11, #0x5
    40202b38:	54000821 	b.ne	40202c3c <jnox_kernel::ordinary_mutex_survivors::interrupt+0x1b4>  // b.any
    40202b3c:	eb08019f 	cmp	x12, x8
    40202b40:	540007e3 	b.cc	40202c3c <jnox_kernel::ordinary_mutex_survivors::interrupt+0x1b4>  // b.lo, b.ul, b.last
    40202b44:	f94001ab 	ldr	x11, [x13]
    40202b48:	eb0b011f 	cmp	x8, x11
    40202b4c:	54000781 	b.ne	40202c3c <jnox_kernel::ordinary_mutex_survivors::interrupt+0x1b4>  // b.any
    40202b50:	d1000548 	sub	x8, x10, #0x1
    40202b54:	5287ffca 	mov	w10, #0x3ffe                	// #16382
    40202b58:	eb0a011f 	cmp	x8, x10
    40202b5c:	54000708 	b.hi	40202c3c <jnox_kernel::ordinary_mutex_survivors::interrupt+0x1b4>  // b.pmore
    40202b60:	f100053f 	cmp	x9, #0x1
    40202b64:	540006c1 	b.ne	40202c3c <jnox_kernel::ordinary_mutex_survivors::interrupt+0x1b4>  // b.any
    40202b68:	d503201f 	nop
    40202b6c:	100124e0 	adr	x0, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    40202b70:	52800061 	mov	w1, #0x3                   	// #3
    40202b74:	97fff7a9 	bl	40200a18 <jnox_kernel::mutex_policy::LockSet<_,_>::timeout>
    40202b78:	34000620 	cbz	w0, 40202c3c <jnox_kernel::ordinary_mutex_survivors::interrupt+0x1b4>
    40202b7c:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202b80:	91070108 	add	x8, x8, #0x1c0
    40202b84:	3900f91f 	strb	wzr, [x8, #62]
    40202b88:	f9400108 	ldr	x8, [x8]
    40202b8c:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40202b90:	f9400129 	ldr	x9, [x9]
    40202b94:	321107ea 	mov	w10, #0x18000               	// #98304
    40202b98:	d503201f 	nop
    40202b9c:	10013cab 	adr	x11, 40205330 <jnox_kernel::ordinary_mutex_survivors::STACKS>
    40202ba0:	9b0a2d29 	madd	x9, x9, x10, x11
    40202ba4:	929067ea 	mov	x10, #0xffffffffffff7cc0    	// #-33600
    40202ba8:	8b0a012a 	add	x10, x9, x10
    40202bac:	eb08015f 	cmp	x10, x8
    40202bb0:	540004e3 	b.cc	40202c4c <jnox_kernel::ordinary_mutex_survivors::interrupt+0x1c4>  // b.lo, b.ul, b.last
    40202bb4:	92400d0a 	and	x10, x8, #0xf
    40202bb8:	b50004aa 	cbnz	x10, 40202c4c <jnox_kernel::ordinary_mutex_survivors::interrupt+0x1c4>
    40202bbc:	d1403129 	sub	x9, x9, #0xc, lsl #12
    40202bc0:	eb08013f 	cmp	x9, x8
    40202bc4:	54000448 	b.hi	40202c4c <jnox_kernel::ordinary_mutex_survivors::interrupt+0x1c4>  // b.pmore
    40202bc8:	52800029 	mov	w9, #0x1                   	// #1
    40202bcc:	f9000109 	str	x9, [x8]
    40202bd0:	d503201f 	nop
    40202bd4:	100121b4 	adr	x20, 40205008 <jnox_kernel::ordinary_mutex_survivors::ACTIVE>
    40202bd8:	aa1403e0 	mov	x0, x20
    40202bdc:	aa1f03e1 	mov	x1, xzr
    40202be0:	52800022 	mov	w2, #0x1                   	// #1
    40202be4:	97fffe5b 	bl	40202550 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue>
    40202be8:	aa1403e0 	mov	x0, x20
    40202bec:	52800061 	mov	w1, #0x3                   	// #3
    40202bf0:	2a1f03e2 	mov	w2, wzr
    40202bf4:	97fffe57 	bl	40202550 <jnox_kernel::ordinary_mutex_survivors::Runtime::enqueue>
    40202bf8:	aa1403e0 	mov	x0, x20
    40202bfc:	97fffd36 	bl	402020d4 <jnox_kernel::ordinary_mutex_survivors::Runtime::choose>
    40202c00:	aa0003f4 	mov	x20, x0
    40202c04:	528000a0 	mov	w0, #0x5                   	// #5
    40202c08:	aa1f03e1 	mov	x1, xzr
    40202c0c:	aa1f03e2 	mov	x2, xzr
    40202c10:	aa1303e3 	mov	x3, x19
    40202c14:	52800024 	mov	w4, #0x1                   	// #1
    40202c18:	aa1403e5 	mov	x5, x20
    40202c1c:	52800026 	mov	w6, #0x1                   	// #1
    40202c20:	aa1f03e7 	mov	x7, xzr
    40202c24:	97fffd67 	bl	402021c0 <jnox_kernel::ordinary_mutex_survivors::Runtime::record>
    40202c28:	aa1403e0 	mov	x0, x20
    40202c2c:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40202c30:	f9400bfe 	ldr	x30, [sp, #16]
    40202c34:	9100c3ff 	add	sp, sp, #0x30
    40202c38:	d65f03c0 	ret
    40202c3c:	52800120 	mov	w0, #0x9                   	// #9
    40202c40:	97fffc7c 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>
    40202c44:	52800020 	mov	w0, #0x1                   	// #1
    40202c48:	97fffc7a 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>
    40202c4c:	52800080 	mov	w0, #0x4                   	// #4
    40202c50:	97fffc78 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

0000000040202c54 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front>:
    40202c54:	f81e0ffe 	str	x30, [sp, #-32]!
    40202c58:	a9014ff4 	stp	x20, x19, [sp, #16]
    40202c5c:	aa0003f3 	mov	x19, x0
    40202c60:	2a1f03e0 	mov	w0, wzr
    40202c64:	f100143f 	cmp	x1, #0x5
    40202c68:	54000348 	b.hi	40202cd0 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x7c>  // b.pmore
    40202c6c:	f9401a68 	ldr	x8, [x19, #48]
    40202c70:	f100151f 	cmp	x8, #0x5
    40202c74:	540002e8 	b.hi	40202cd0 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x7c>  // b.pmore
    40202c78:	aa0103f4 	mov	x20, x1
    40202c7c:	aa1f03e9 	mov	x9, xzr
    40202c80:	d37df102 	lsl	x2, x8, #3
    40202c84:	eb09005f 	cmp	x2, x9
    40202c88:	540000e0 	b.eq	40202ca4 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x50>  // b.none
    40202c8c:	f8696a6a 	ldr	x10, [x19, x9]
    40202c90:	91002129 	add	x9, x9, #0x8
    40202c94:	eb14015f 	cmp	x10, x20
    40202c98:	54ffff61 	b.ne	40202c84 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x30>  // b.any
    40202c9c:	2a1f03e0 	mov	w0, wzr
    40202ca0:	1400000c 	b	40202cd0 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x7c>
    40202ca4:	b40000e8 	cbz	x8, 40202cc0 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x6c>
    40202ca8:	91002260 	add	x0, x19, #0x8
    40202cac:	aa1303e1 	mov	x1, x19
    40202cb0:	94000568 	bl	40204250 <memmove>
    40202cb4:	f9401a68 	ldr	x8, [x19, #48]
    40202cb8:	91000508 	add	x8, x8, #0x1
    40202cbc:	14000002 	b	40202cc4 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x70>
    40202cc0:	52800028 	mov	w8, #0x1                   	// #1
    40202cc4:	f9000274 	str	x20, [x19]
    40202cc8:	52800020 	mov	w0, #0x1                   	// #1
    40202ccc:	f9001a68 	str	x8, [x19, #48]
    40202cd0:	a9414ff4 	ldp	x20, x19, [sp, #16]
    40202cd4:	f84207fe 	ldr	x30, [sp], #32
    40202cd8:	d65f03c0 	ret

0000000040202cdc <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest>:
    40202cdc:	f81f0ffe 	str	x30, [sp, #-16]!
    40202ce0:	aa0103e9 	mov	x9, x1
    40202ce4:	f9401801 	ldr	x1, [x0, #48]
    40202ce8:	f1001c3f 	cmp	x1, #0x7
    40202cec:	540005a2 	b.cs	40202da0 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xc4>  // b.hs, b.nlast
    40202cf0:	b40004c1 	cbz	x1, 40202d88 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xac>
    40202cf4:	2a1f03eb 	mov	w11, wzr
    40202cf8:	aa1f03ee 	mov	x14, xzr
    40202cfc:	d37df02d 	lsl	x13, x1, #3
    40202d00:	f86e780a 	ldr	x10, [x0, x14, lsl #3]
    40202d04:	f100195f 	cmp	x10, #0x6
    40202d08:	54000562 	b.cs	40202db4 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xd8>  // b.hs, b.nlast
    40202d0c:	386a692a 	ldrb	w10, [x9, x10]
    40202d10:	12001d4f 	and	w15, w10, #0xff
    40202d14:	6b2c01ff 	cmp	w15, w12, uxtb
    40202d18:	1a9f87ef 	cset	w15, ls  // ls = plast
    40202d1c:	6a0f017f 	tst	w11, w15
    40202d20:	9a8e1108 	csel	x8, x8, x14, ne  // ne = any
    40202d24:	910005ce 	add	x14, x14, #0x1
    40202d28:	1a8a118c 	csel	w12, w12, w10, ne  // ne = any
    40202d2c:	f10021ad 	subs	x13, x13, #0x8
    40202d30:	5280002b 	mov	w11, #0x1                   	// #1
    40202d34:	54fffe61 	b.ne	40202d00 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0x24>  // b.any
    40202d38:	f100151f 	cmp	x8, #0x5
    40202d3c:	540004e8 	b.hi	40202dd8 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xfc>  // b.pmore
    40202d40:	f8687809 	ldr	x9, [x0, x8, lsl #3]
    40202d44:	d100042a 	sub	x10, x1, #0x1
    40202d48:	f900180a 	str	x10, [x0, #48]
    40202d4c:	eb0a011f 	cmp	x8, x10
    40202d50:	54000202 	b.cs	40202d90 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xb4>  // b.hs, b.nlast
    40202d54:	8b080c0a 	add	x10, x0, x8, lsl #3
    40202d58:	9100214a 	add	x10, x10, #0x8
    40202d5c:	91000508 	add	x8, x8, #0x1
    40202d60:	52800020 	mov	w0, #0x1                   	// #1
    40202d64:	f100191f 	cmp	x8, #0x6
    40202d68:	540002e0 	b.eq	40202dc4 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xe8>  // b.none
    40202d6c:	f940014b 	ldr	x11, [x10]
    40202d70:	f81f814b 	stur	x11, [x10, #-8]
    40202d74:	9100214a 	add	x10, x10, #0x8
    40202d78:	91000508 	add	x8, x8, #0x1
    40202d7c:	eb08003f 	cmp	x1, x8
    40202d80:	54ffff21 	b.ne	40202d64 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0x88>  // b.any
    40202d84:	14000004 	b	40202d94 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xb8>
    40202d88:	aa1f03e0 	mov	x0, xzr
    40202d8c:	14000002 	b	40202d94 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xb8>
    40202d90:	52800020 	mov	w0, #0x1                   	// #1
    40202d94:	aa0903e1 	mov	x1, x9
    40202d98:	f84107fe 	ldr	x30, [sp], #16
    40202d9c:	d65f03c0 	ret
    40202da0:	d503201f 	nop
    40202da4:	100102e3 	adr	x3, 40204e00 <anon.a96ef1ad02bf9434d4f9fb3a54991149.1.llvm.1785347619192815592>
    40202da8:	aa1f03e0 	mov	x0, xzr
    40202dac:	528000c2 	mov	w2, #0x6                   	// #6
    40202db0:	94000484 	bl	40203fc0 <core::slice::index::slice_index_fail>
    40202db4:	d503201f 	nop
    40202db8:	10010542 	adr	x2, 40204e60 <anon.a96ef1ad02bf9434d4f9fb3a54991149.6.llvm.1785347619192815592>
    40202dbc:	aa0a03e0 	mov	x0, x10
    40202dc0:	14000004 	b	40202dd0 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xf4>
    40202dc4:	d503201f 	nop
    40202dc8:	10010342 	adr	x2, 40204e30 <anon.a96ef1ad02bf9434d4f9fb3a54991149.3.llvm.1785347619192815592>
    40202dcc:	aa0803e0 	mov	x0, x8
    40202dd0:	528000c1 	mov	w1, #0x6                   	// #6
    40202dd4:	9400027c 	bl	402037c4 <core::panicking::panic_bounds_check>
    40202dd8:	d503201f 	nop
    40202ddc:	100101e2 	adr	x2, 40204e18 <anon.a96ef1ad02bf9434d4f9fb3a54991149.2.llvm.1785347619192815592>
    40202de0:	17fffffb 	b	40202dcc <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xf0>

0000000040202de4 <jnox_kernel::ordinary_mutex_survivors::workers::reporter_a>:
    40202de4:	f81f0ffe 	str	x30, [sp, #-16]!
    40202de8:	52800080 	mov	w0, #0x4                   	// #4
    40202dec:	52800021 	mov	w1, #0x1                   	// #1
    40202df0:	940000f4 	bl	402031c0 <jnox_kernel::ordinary_mutex_survivors::workers::append>

0000000040202df4 <jnox_kernel::ordinary_mutex_survivors::workers::reporter_b>:
    40202df4:	f81f0ffe 	str	x30, [sp, #-16]!
    40202df8:	528000a0 	mov	w0, #0x5                   	// #5
    40202dfc:	52800041 	mov	w1, #0x2                   	// #2
    40202e00:	940000f0 	bl	402031c0 <jnox_kernel::ordinary_mutex_survivors::workers::append>

0000000040202e04 <jnox_kernel::ordinary_mutex_survivors::workers::low>:
    40202e04:	d10083ff 	sub	sp, sp, #0x20
    40202e08:	f9000bfe 	str	x30, [sp, #16]
    40202e0c:	52800020 	mov	w0, #0x1                   	// #1
    40202e10:	aa1f03e1 	mov	x1, xzr
    40202e14:	97fffdf9 	bl	402025f8 <jnox_kernel::ordinary_mutex_survivors::checked>
    40202e18:	f00001a8 	adrp	x8, 40239000 <jnox_ap_returns+0xd0>
    40202e1c:	52800089 	mov	w9, #0x4                   	// #4
    40202e20:	f902b909 	str	x9, [x8, #1392]
    40202e24:	528000c0 	mov	w0, #0x6                   	// #6
    40202e28:	aa1f03e1 	mov	x1, xzr
    40202e2c:	97fffdf3 	bl	402025f8 <jnox_kernel::ordinary_mutex_survivors::checked>
    40202e30:	528000c0 	mov	w0, #0x6                   	// #6
    40202e34:	aa1f03e1 	mov	x1, xzr
    40202e38:	97fffdf0 	bl	402025f8 <jnox_kernel::ordinary_mutex_survivors::checked>
    40202e3c:	52800028 	mov	w8, #0x1                   	// #1
    40202e40:	52800020 	mov	w0, #0x1                   	// #1
    40202e44:	d4000001 	svc	#0x0
    40202e48:	910003e8 	mov	x8, sp
    40202e4c:	f9000fe0 	str	x0, [sp, #24]
    40202e50:	f90007e8 	str	x8, [sp, #8]
    40202e54:	f9400fe8 	ldr	x8, [sp, #24]
    40202e58:	d503201f 	nop
    40202e5c:	100121e9 	adr	x9, 40205298 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers11RETURN_ROWS17hc1064bb16cbd219dE.llvm.1785347619192815592>
    40202e60:	f9000128 	str	x8, [x9]
    40202e64:	f94007e8 	ldr	x8, [sp, #8]
    40202e68:	f9000528 	str	x8, [x9, #8]
    40202e6c:	b5000320 	cbnz	x0, 40202ed0 <jnox_kernel::ordinary_mutex_survivors::workers::low+0xcc>
    40202e70:	d503201f 	nop
    40202e74:	101b3629 	adr	x9, 40239538 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers5BATCH17h34c6dfe899ffbb21E.llvm.1785347619192815592>
    40202e78:	f9400128 	ldr	x8, [x9]
    40202e7c:	f9400529 	ldr	x9, [x9, #8]
    40202e80:	52a0440a 	mov	w10, #0x2200000             	// #35651584
    40202e84:	eb0a013f 	cmp	x9, x10
    40202e88:	52a0080a 	mov	w10, #0x400000              	// #4194304
    40202e8c:	fa4a0100 	ccmp	x8, x10, #0x0, eq  // eq = none
    40202e90:	54000241 	b.ne	40202ed8 <jnox_kernel::ordinary_mutex_survivors::workers::low+0xd4>  // b.any
    40202e94:	f9000fe8 	str	x8, [sp, #24]
    40202e98:	f90007e9 	str	x9, [sp, #8]
    40202e9c:	f9400fe8 	ldr	x8, [sp, #24]
    40202ea0:	d503201f 	nop
    40202ea4:	101b35a9 	adr	x9, 40239558 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers6REPORT17h79dabd79cd10ba08E.llvm.1785347619192815592>
    40202ea8:	f9000128 	str	x8, [x9]
    40202eac:	f94007e8 	ldr	x8, [sp, #8]
    40202eb0:	f9000528 	str	x8, [x9, #8]
    40202eb4:	52800040 	mov	w0, #0x2                   	// #2
    40202eb8:	52800021 	mov	w1, #0x1                   	// #1
    40202ebc:	97fffdcf 	bl	402025f8 <jnox_kernel::ordinary_mutex_survivors::checked>
    40202ec0:	52800040 	mov	w0, #0x2                   	// #2
    40202ec4:	aa1f03e1 	mov	x1, xzr
    40202ec8:	97fffdcc 	bl	402025f8 <jnox_kernel::ordinary_mutex_survivors::checked>
    40202ecc:	97fffb98 	bl	40201d2c <jnox_kernel::ordinary_mutex_survivors::exit>
    40202ed0:	52800400 	mov	w0, #0x20                  	// #32
    40202ed4:	97fffbd7 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>
    40202ed8:	52800420 	mov	w0, #0x21                  	// #33
    40202edc:	97fffbd5 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

0000000040202ee0 <jnox_kernel::ordinary_mutex_survivors::workers::base>:
    40202ee0:	d10083ff 	sub	sp, sp, #0x20
    40202ee4:	a9014ffe 	stp	x30, x19, [sp, #16]
    40202ee8:	52800033 	mov	w19, #0x1                   	// #1
    40202eec:	52800020 	mov	w0, #0x1                   	// #1
    40202ef0:	52800021 	mov	w1, #0x1                   	// #1
    40202ef4:	97fffdc1 	bl	402025f8 <jnox_kernel::ordinary_mutex_survivors::checked>
    40202ef8:	aa1f03e9 	mov	x9, xzr
    40202efc:	aa1f03e8 	mov	x8, xzr
    40202f00:	d503201f 	nop
    40202f04:	101b33aa 	adr	x10, 40239578 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers7IN_WORK17h5c2f8327ddf6c11fE.0.llvm.1785347619192815592>
    40202f08:	d503201f 	nop
    40202f0c:	5000fb8b 	adr	x11, 40204e7e <jnox_kernel::ordinary_mutex_survivors::workers::INPUT>
    40202f10:	c89ffd53 	stlr	x19, [x10]
    40202f14:	d503201f 	nop
    40202f18:	101b31cc 	adr	x12, 40239550 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers6CHUNKS17h78003a5906450e90E.0.llvm.1785347619192815592>
    40202f1c:	aa1f03ed 	mov	x13, xzr
    40202f20:	92400dae 	and	x14, x13, #0xf
    40202f24:	386e696e 	ldrb	w14, [x11, x14]
    40202f28:	910005ad 	add	x13, x13, #0x1
    40202f2c:	8b0e0129 	add	x9, x9, x14
    40202f30:	f10401bf 	cmp	x13, #0x100
    40202f34:	54ffff61 	b.ne	40202f20 <jnox_kernel::ordinary_mutex_survivors::workers::base+0x40>  // b.any
    40202f38:	f140127f 	cmp	x19, #0x4, lsl #12
    40202f3c:	9a93066d 	cinc	x13, x19, ne  // ne = any
    40202f40:	91040108 	add	x8, x8, #0x100
    40202f44:	c89ffd93 	stlr	x19, [x12]
    40202f48:	54000080 	b.eq	40202f58 <jnox_kernel::ordinary_mutex_survivors::workers::base+0x78>  // b.none
    40202f4c:	f14011bf 	cmp	x13, #0x4, lsl #12
    40202f50:	aa0d03f3 	mov	x19, x13
    40202f54:	54fffe49 	b.ls	40202f1c <jnox_kernel::ordinary_mutex_survivors::workers::base+0x3c>  // b.plast
    40202f58:	a90023e9 	stp	x9, x8, [sp]
    40202f5c:	d503201f 	nop
    40202f60:	101b2ecb 	adr	x11, 40239538 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers5BATCH17h34c6dfe899ffbb21E.llvm.1785347619192815592>
    40202f64:	f94007ec 	ldr	x12, [sp, #8]
    40202f68:	f900016c 	str	x12, [x11]
    40202f6c:	f94003ec 	ldr	x12, [sp]
    40202f70:	52a0440d 	mov	w13, #0x2200000             	// #35651584
    40202f74:	f900056c 	str	x12, [x11, #8]
    40202f78:	c89ffd5f 	stlr	xzr, [x10]
    40202f7c:	eb0d013f 	cmp	x9, x13
    40202f80:	52a00809 	mov	w9, #0x400000              	// #4194304
    40202f84:	fa490100 	ccmp	x8, x9, #0x0, eq  // eq = none
    40202f88:	540000a1 	b.ne	40202f9c <jnox_kernel::ordinary_mutex_survivors::workers::base+0xbc>  // b.any
    40202f8c:	52800040 	mov	w0, #0x2                   	// #2
    40202f90:	52800021 	mov	w1, #0x1                   	// #1
    40202f94:	97fffd99 	bl	402025f8 <jnox_kernel::ordinary_mutex_survivors::checked>
    40202f98:	97fffb65 	bl	40201d2c <jnox_kernel::ordinary_mutex_survivors::exit>
    40202f9c:	528003e0 	mov	w0, #0x1f                  	// #31
    40202fa0:	97fffba4 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

0000000040202fa4 <jnox_kernel::ordinary_mutex_survivors::workers::dump>:
    40202fa4:	d10443ff 	sub	sp, sp, #0x110
    40202fa8:	a90d7bfd 	stp	x29, x30, [sp, #208]
    40202fac:	a90e5ff8 	stp	x24, x23, [sp, #224]
    40202fb0:	a90f57f6 	stp	x22, x21, [sp, #240]
    40202fb4:	a9104ff4 	stp	x20, x19, [sp, #256]
    40202fb8:	aa1f03e8 	mov	x8, xzr
    40202fbc:	f00001a9 	adrp	x9, 40239000 <jnox_ap_returns+0xd0>
    40202fc0:	f942a534 	ldr	x20, [x9, #1352]
    40202fc4:	910003e9 	mov	x9, sp
    40202fc8:	f8286934 	str	x20, [x9, x8]
    40202fcc:	91002108 	add	x8, x8, #0x8
    40202fd0:	f101611f 	cmp	x8, #0x58
    40202fd4:	54ffffa1 	b.ne	40202fc8 <jnox_kernel::ordinary_mutex_survivors::workers::dump+0x24>  // b.any
    40202fd8:	d503201f 	nop
    40202fdc:	101b2ba8 	adr	x8, 40239550 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers6CHUNKS17h78003a5906450e90E.0.llvm.1785347619192815592>
    40202fe0:	d503201f 	nop
    40202fe4:	101b2ca9 	adr	x9, 40239578 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers7IN_WORK17h5c2f8327ddf6c11fE.0.llvm.1785347619192815592>
    40202fe8:	d503201f 	nop
    40202fec:	101b2a6a 	adr	x10, 40239538 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers5BATCH17h34c6dfe899ffbb21E.llvm.1785347619192815592>
    40202ff0:	d503201f 	nop
    40202ff4:	101b2b2b 	adr	x11, 40239558 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers6REPORT17h79dabd79cd10ba08E.llvm.1785347619192815592>
    40202ff8:	c8dffd08 	ldar	x8, [x8]
    40202ffc:	c8dffd29 	ldar	x9, [x9]
    40203000:	f940054c 	ldr	x12, [x10, #8]
    40203004:	f940014a 	ldr	x10, [x10]
    40203008:	f9400d6d 	ldr	x13, [x11, #24]
    4020300c:	f940096e 	ldr	x14, [x11, #16]
    40203010:	f940056f 	ldr	x15, [x11, #8]
    40203014:	f940016b 	ldr	x11, [x11]
    40203018:	a900a3e9 	stp	x9, x8, [sp, #8]
    4020301c:	a901b3ea 	stp	x10, x12, [sp, #24]
    40203020:	d0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40203024:	d0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40203028:	a902bfeb 	stp	x11, x15, [sp, #40]
    4020302c:	f9414908 	ldr	x8, [x8, #656]
    40203030:	a903b7ee 	stp	x14, x13, [sp, #56]
    40203034:	f9415d29 	ldr	x9, [x9, #696]
    40203038:	a904a7e8 	stp	x8, x9, [sp, #72]
    4020303c:	d503201f 	nop
    40203040:	1000f1c0 	adr	x0, 40204e78 <anon.a96ef1ad02bf9434d4f9fb3a54991149.6.llvm.1785347619192815592+0x18>
    40203044:	910003e2 	mov	x2, sp
    40203048:	52800041 	mov	w1, #0x2                   	// #2
    4020304c:	52800163 	mov	w3, #0xb                   	// #11
    40203050:	97fffb3d 	bl	40201d44 <jnox_kernel::ordinary_mutex_survivors::line>
    40203054:	aa1f03e8 	mov	x8, xzr
    40203058:	52800029 	mov	w9, #0x1                   	// #1
    4020305c:	910163f5 	add	x21, sp, #0x58
    40203060:	d503201f 	nop
    40203064:	10010cf6 	adr	x22, 40205200 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers11APPEND_ROWS17hadbbd6f2c286f13aE.llvm.1785347619192815592>
    40203068:	52800917 	mov	w23, #0x48                  	// #72
    4020306c:	d503201f 	nop
    40203070:	1000f073 	adr	x19, 40204e7c <anon.a96ef1ad02bf9434d4f9fb3a54991149.6.llvm.1785347619192815592+0x1c>
    40203074:	aa1f03ea 	mov	x10, xzr
    40203078:	2a0903f8 	mov	w24, w9
    4020307c:	f82a6ab4 	str	x20, [x21, x10]
    40203080:	9100214a 	add	x10, x10, #0x8
    40203084:	f101615f 	cmp	x10, #0x58
    40203088:	54ffffa1 	b.ne	4020307c <jnox_kernel::ordinary_mutex_survivors::workers::dump+0xd8>  // b.any
    4020308c:	f90033e8 	str	x8, [sp, #96]
    40203090:	9b175908 	madd	x8, x8, x23, x22
    40203094:	f9402109 	ldr	x9, [x8, #64]
    40203098:	f9401d0a 	ldr	x10, [x8, #56]
    4020309c:	f940190b 	ldr	x11, [x8, #48]
    402030a0:	f940150c 	ldr	x12, [x8, #40]
    402030a4:	f940110d 	ldr	x13, [x8, #32]
    402030a8:	f9400d0e 	ldr	x14, [x8, #24]
    402030ac:	f940090f 	ldr	x15, [x8, #16]
    402030b0:	f9400510 	ldr	x16, [x8, #8]
    402030b4:	f9400108 	ldr	x8, [x8]
    402030b8:	a906c3e8 	stp	x8, x16, [sp, #104]
    402030bc:	a907bbef 	stp	x15, x14, [sp, #120]
    402030c0:	a908b3ed 	stp	x13, x12, [sp, #136]
    402030c4:	a909abeb 	stp	x11, x10, [sp, #152]
    402030c8:	f90057e9 	str	x9, [sp, #168]
    402030cc:	910163e2 	add	x2, sp, #0x58
    402030d0:	aa1303e0 	mov	x0, x19
    402030d4:	52800041 	mov	w1, #0x2                   	// #2
    402030d8:	52800163 	mov	w3, #0xb                   	// #11
    402030dc:	97fffb1a 	bl	40201d44 <jnox_kernel::ordinary_mutex_survivors::line>
    402030e0:	2a1f03e9 	mov	w9, wzr
    402030e4:	52800028 	mov	w8, #0x1                   	// #1
    402030e8:	3707fc78 	tbnz	w24, #0, 40203074 <jnox_kernel::ordinary_mutex_survivors::workers::dump+0xd0>
    402030ec:	2a1f03e8 	mov	w8, wzr
    402030f0:	aa1f03e9 	mov	x9, xzr
    402030f4:	910163ea 	add	x10, sp, #0x58
    402030f8:	91004155 	add	x21, x10, #0x10
    402030fc:	5280002a 	mov	w10, #0x1                   	// #1
    40203100:	5280006b 	mov	w11, #0x3                   	// #3
    40203104:	d503201f 	nop
    40203108:	10010c96 	adr	x22, 40205298 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers11RETURN_ROWS17hc1064bb16cbd219dE.llvm.1785347619192815592>
    4020310c:	a906afea 	stp	x10, x11, [sp, #104]
    40203110:	d503201f 	nop
    40203114:	5000eb33 	adr	x19, 40204e7a <anon.a96ef1ad02bf9434d4f9fb3a54991149.6.llvm.1785347619192815592+0x1a>
    40203118:	f8697aaa 	ldr	x10, [x21, x9, lsl #3]
    4020311c:	8b0912c9 	add	x9, x22, x9, lsl #4
    40203120:	f940052b 	ldr	x11, [x9, #8]
    40203124:	f9400129 	ldr	x9, [x9]
    40203128:	a90b2bf4 	stp	x20, x10, [sp, #176]
    4020312c:	2a0803f7 	mov	w23, w8
    40203130:	a90c2fe9 	stp	x9, x11, [sp, #192]
    40203134:	9102c3e2 	add	x2, sp, #0xb0
    40203138:	aa1303e0 	mov	x0, x19
    4020313c:	52800041 	mov	w1, #0x2                   	// #2
    40203140:	52800083 	mov	w3, #0x4                   	// #4
    40203144:	97fffb00 	bl	40201d44 <jnox_kernel::ordinary_mutex_survivors::line>
    40203148:	52800028 	mov	w8, #0x1                   	// #1
    4020314c:	52800029 	mov	w9, #0x1                   	// #1
    40203150:	3607fe57 	tbz	w23, #0, 40203118 <jnox_kernel::ordinary_mutex_survivors::workers::dump+0x174>
    40203154:	a9504ff4 	ldp	x20, x19, [sp, #256]
    40203158:	a94f57f6 	ldp	x22, x21, [sp, #240]
    4020315c:	a94e5ff8 	ldp	x24, x23, [sp, #224]
    40203160:	a94d7bfd 	ldp	x29, x30, [sp, #208]
    40203164:	910443ff 	add	sp, sp, #0x110
    40203168:	d65f03c0 	ret

000000004020316c <jnox_kernel::ordinary_mutex_survivors::workers::high>:
    4020316c:	d10083ff 	sub	sp, sp, #0x20
    40203170:	f9000bfe 	str	x30, [sp, #16]
    40203174:	aa1f03e0 	mov	x0, xzr
    40203178:	52800068 	mov	w8, #0x3                   	// #3
    4020317c:	d4000001 	svc	#0x0
    40203180:	d0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40203184:	f9014900 	str	x0, [x8, #656]
    40203188:	910003e8 	mov	x8, sp
    4020318c:	f9000fe0 	str	x0, [sp, #24]
    40203190:	f90007e8 	str	x8, [sp, #8]
    40203194:	f9400fe8 	ldr	x8, [sp, #24]
    40203198:	d0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    4020319c:	910aa129 	add	x9, x9, #0x2a8
    402031a0:	f9000128 	str	x8, [x9]
    402031a4:	f94007e8 	ldr	x8, [sp, #8]
    402031a8:	f9000528 	str	x8, [x9, #8]
    402031ac:	f100041f 	cmp	x0, #0x1
    402031b0:	54000041 	b.ne	402031b8 <jnox_kernel::ordinary_mutex_survivors::workers::high+0x4c>  // b.any
    402031b4:	97fffade 	bl	40201d2c <jnox_kernel::ordinary_mutex_survivors::exit>
    402031b8:	52800460 	mov	w0, #0x23                  	// #35
    402031bc:	97fffb1d 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

00000000402031c0 <jnox_kernel::ordinary_mutex_survivors::workers::append>:
    402031c0:	d10143ff 	sub	sp, sp, #0x50
    402031c4:	f90023fe 	str	x30, [sp, #64]
    402031c8:	aa0003e9 	mov	x9, x0
    402031cc:	52800028 	mov	w8, #0x1                   	// #1
    402031d0:	aa1f03e0 	mov	x0, xzr
    402031d4:	d4000001 	svc	#0x0
    402031d8:	910003e8 	mov	x8, sp
    402031dc:	b5000740 	cbnz	x0, 402032c4 <jnox_kernel::ordinary_mutex_survivors::workers::append+0x104>
    402031e0:	d503201f 	nop
    402031e4:	101b1bad 	adr	x13, 40239558 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers6REPORT17h79dabd79cd10ba08E.llvm.1785347619192815592>
    402031e8:	f94009aa 	ldr	x10, [x13, #16]
    402031ec:	f9400dab 	ldr	x11, [x13, #24]
    402031f0:	f94001ae 	ldr	x14, [x13]
    402031f4:	f94005ac 	ldr	x12, [x13, #8]
    402031f8:	52a0440f 	mov	w15, #0x2200000             	// #35651584
    402031fc:	eb0f019f 	cmp	x12, x15
    40203200:	52a0080f 	mov	w15, #0x400000              	// #4194304
    40203204:	fa4f01c0 	ccmp	x14, x15, #0x0, eq  // eq = none
    40203208:	540006a1 	b.ne	402032dc <jnox_kernel::ordinary_mutex_survivors::workers::append+0x11c>  // b.any
    4020320c:	f100055f 	cmp	x10, #0x1
    40203210:	540005e0 	b.eq	402032cc <jnox_kernel::ordinary_mutex_survivors::workers::append+0x10c>  // b.none
    40203214:	b500064a 	cbnz	x10, 402032dc <jnox_kernel::ordinary_mutex_survivors::workers::append+0x11c>
    40203218:	f100117f 	cmp	x11, #0x4
    4020321c:	54000601 	b.ne	402032dc <jnox_kernel::ordinary_mutex_survivors::workers::append+0x11c>  // b.any
    40203220:	9100054e 	add	x14, x10, #0x1
    40203224:	f90009ae 	str	x14, [x13, #16]
    40203228:	5280014e 	mov	w14, #0xa                   	// #10
    4020322c:	9b0e056e 	madd	x14, x11, x14, x1
    40203230:	f9000dae 	str	x14, [x13, #24]
    40203234:	f94005bf 	ldr	xzr, [x13, #8]
    40203238:	f94001bf 	ldr	xzr, [x13]
    4020323c:	f9400dae 	ldr	x14, [x13, #24]
    40203240:	f94009ad 	ldr	x13, [x13, #16]
    40203244:	d503201f 	nop
    40203248:	1000fdcf 	adr	x15, 40205200 <_ZN11jnox_kernel24ordinary_mutex_survivors7workers11APPEND_ROWS17hadbbd6f2c286f13aE.llvm.1785347619192815592>
    4020324c:	52800910 	mov	w16, #0x48                  	// #72
    40203250:	9b103d4f 	madd	x15, x10, x16, x15
    40203254:	f90027e9 	str	x9, [sp, #72]
    40203258:	a9037fe8 	stp	x8, xzr, [sp, #48]
    4020325c:	52a00808 	mov	w8, #0x400000              	// #4194304
    40203260:	a90223ec 	stp	x12, x8, [sp, #32]
    40203264:	a9012beb 	stp	x11, x10, [sp, #16]
    40203268:	a90037ee 	stp	x14, x13, [sp]
    4020326c:	f94027e8 	ldr	x8, [sp, #72]
    40203270:	f90001e8 	str	x8, [x15]
    40203274:	f9401fe8 	ldr	x8, [sp, #56]
    40203278:	f90005e8 	str	x8, [x15, #8]
    4020327c:	f9401be8 	ldr	x8, [sp, #48]
    40203280:	f90009e8 	str	x8, [x15, #16]
    40203284:	f94017e8 	ldr	x8, [sp, #40]
    40203288:	f9000de8 	str	x8, [x15, #24]
    4020328c:	f94013e8 	ldr	x8, [sp, #32]
    40203290:	f90011e8 	str	x8, [x15, #32]
    40203294:	f9400fe8 	ldr	x8, [sp, #24]
    40203298:	f90015e8 	str	x8, [x15, #40]
    4020329c:	f9400be8 	ldr	x8, [sp, #16]
    402032a0:	f90019e8 	str	x8, [x15, #48]
    402032a4:	f94007e8 	ldr	x8, [sp, #8]
    402032a8:	f9001de8 	str	x8, [x15, #56]
    402032ac:	f94003e8 	ldr	x8, [sp]
    402032b0:	f90021e8 	str	x8, [x15, #64]
    402032b4:	52800040 	mov	w0, #0x2                   	// #2
    402032b8:	aa1f03e1 	mov	x1, xzr
    402032bc:	97fffccf 	bl	402025f8 <jnox_kernel::ordinary_mutex_survivors::checked>
    402032c0:	97fffa9b 	bl	40201d2c <jnox_kernel::ordinary_mutex_survivors::exit>
    402032c4:	52800480 	mov	w0, #0x24                  	// #36
    402032c8:	97fffada 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>
    402032cc:	5280056e 	mov	w14, #0x2b                  	// #43
    402032d0:	cb0101ce 	sub	x14, x14, x1
    402032d4:	eb0e017f 	cmp	x11, x14
    402032d8:	54fffa40 	b.eq	40203220 <jnox_kernel::ordinary_mutex_survivors::workers::append+0x60>  // b.none
    402032dc:	528004a0 	mov	w0, #0x25                  	// #37
    402032e0:	97fffad4 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

00000000402032e4 <jnox_kernel::ordinary_mutex_survivors::workers::medium>:
    402032e4:	f81f0ffe 	str	x30, [sp, #-16]!
    402032e8:	aa1f03e8 	mov	x8, xzr
    402032ec:	aa1f03ea 	mov	x10, xzr
    402032f0:	d503201f 	nop
    402032f4:	5000dc49 	adr	x9, 40204e7e <jnox_kernel::ordinary_mutex_survivors::workers::INPUT>
    402032f8:	92400d4b 	and	x11, x10, #0xf
    402032fc:	386b692b 	ldrb	w11, [x9, x11]
    40203300:	9100054a 	add	x10, x10, #0x1
    40203304:	8b0b0108 	add	x8, x8, x11
    40203308:	f104015f 	cmp	x10, #0x100
    4020330c:	54ffff61 	b.ne	402032f8 <jnox_kernel::ordinary_mutex_survivors::workers::medium+0x14>  // b.any
    40203310:	d0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel24ordinary_mutex_survivors5EPOCH17hc0b231613966fb43E.0>
    40203314:	f9015d28 	str	x8, [x9, #696]
    40203318:	f122011f 	cmp	x8, #0x880
    4020331c:	54000041 	b.ne	40203324 <jnox_kernel::ordinary_mutex_survivors::workers::medium+0x40>  // b.any
    40203320:	97fffa83 	bl	40201d2c <jnox_kernel::ordinary_mutex_survivors::exit>
    40203324:	52800440 	mov	w0, #0x22                  	// #34
    40203328:	97fffac2 	bl	40201e30 <jnox_kernel::ordinary_mutex_survivors::stop>

000000004020332c <<core::fmt::Formatter>::pad_integral>:
    4020332c:	d101c3ff 	sub	sp, sp, #0x70
    40203330:	a9017bfd 	stp	x29, x30, [sp, #16]
    40203334:	a9026ffc 	stp	x28, x27, [sp, #32]
    40203338:	a90367fa 	stp	x26, x25, [sp, #48]
    4020333c:	a9045ff8 	stp	x24, x23, [sp, #64]
    40203340:	a90557f6 	stp	x22, x21, [sp, #80]
    40203344:	a9064ff4 	stp	x20, x19, [sp, #96]
    40203348:	910043fd 	add	x29, sp, #0x10
    4020334c:	b940101a 	ldr	w26, [x0, #16]
    40203350:	52a00229 	mov	w9, #0x110000              	// #1114112
    40203354:	aa0503f3 	mov	x19, x5
    40203358:	aa0403fc 	mov	x28, x4
    4020335c:	aa0303f6 	mov	x22, x3
    40203360:	aa0003f5 	mov	x21, x0
    40203364:	926b0348 	and	x8, x26, #0x200000
    40203368:	d355574a 	ubfx	x10, x26, #21, #1
    4020336c:	7100011f 	cmp	w8, #0x0
    40203370:	52800568 	mov	w8, #0x2b                  	// #43
    40203374:	1a880128 	csel	w8, w9, w8, eq  // eq = none
    40203378:	7100003f 	cmp	w1, #0x0
    4020337c:	528005a9 	mov	w9, #0x2d                  	// #45
    40203380:	9a9f154a 	csinc	x10, x10, xzr, ne  // ne = any
    40203384:	1a891118 	csel	w24, w8, w9, ne  // ne = any
    40203388:	8b05015b 	add	x27, x10, x5
    4020338c:	37b8033a 	tbnz	w26, #23, 402033f0 <<core::fmt::Formatter>::pad_integral+0xc4>
    40203390:	aa1f03f7 	mov	x23, xzr
    40203394:	79402ab4 	ldrh	w20, [x21, #20]
    40203398:	eb14037f 	cmp	x27, x20
    4020339c:	54001503 	b.cc	4020363c <<core::fmt::Formatter>::pad_integral+0x310>  // b.lo, b.ul, b.last
    402033a0:	a94056b9 	ldp	x25, x21, [x21]
    402033a4:	2a1803e2 	mov	w2, w24
    402033a8:	aa1703e3 	mov	x3, x23
    402033ac:	aa1603e4 	mov	x4, x22
    402033b0:	aa1903e0 	mov	x0, x25
    402033b4:	aa1503e1 	mov	x1, x21
    402033b8:	9400032f 	bl	40204074 <<core::fmt::Formatter>::pad_integral::write_prefix>
    402033bc:	37001d60 	tbnz	w0, #0, 40203768 <<core::fmt::Formatter>::pad_integral+0x43c>
    402033c0:	f9400ea3 	ldr	x3, [x21, #24]
    402033c4:	aa1903e0 	mov	x0, x25
    402033c8:	aa1c03e1 	mov	x1, x28
    402033cc:	aa1303e2 	mov	x2, x19
    402033d0:	a9464ff4 	ldp	x20, x19, [sp, #96]
    402033d4:	a94557f6 	ldp	x22, x21, [sp, #80]
    402033d8:	a9445ff8 	ldp	x24, x23, [sp, #64]
    402033dc:	a94367fa 	ldp	x26, x25, [sp, #48]
    402033e0:	a9426ffc 	ldp	x28, x27, [sp, #32]
    402033e4:	a9417bfd 	ldp	x29, x30, [sp, #16]
    402033e8:	9101c3ff 	add	sp, sp, #0x70
    402033ec:	d61f0060 	br	x3
    402033f0:	aa0203f7 	mov	x23, x2
    402033f4:	f10082df 	cmp	x22, #0x20
    402033f8:	540000e2 	b.cs	40203414 <<core::fmt::Formatter>::pad_integral+0xe8>  // b.hs, b.nlast
    402033fc:	b4000156 	cbz	x22, 40203424 <<core::fmt::Formatter>::pad_integral+0xf8>
    40203400:	f10022df 	cmp	x22, #0x8
    40203404:	54000142 	b.cs	4020342c <<core::fmt::Formatter>::pad_integral+0x100>  // b.hs, b.nlast
    40203408:	aa1f03e8 	mov	x8, xzr
    4020340c:	aa1f03e0 	mov	x0, xzr
    40203410:	14000080 	b	40203610 <<core::fmt::Formatter>::pad_integral+0x2e4>
    40203414:	aa1703e0 	mov	x0, x23
    40203418:	aa1603e1 	mov	x1, x22
    4020341c:	94000102 	bl	40203824 <core::str::count::do_count_chars>
    40203420:	14000083 	b	4020362c <<core::fmt::Formatter>::pad_integral+0x300>
    40203424:	aa1f03e0 	mov	x0, xzr
    40203428:	14000081 	b	4020362c <<core::fmt::Formatter>::pad_integral+0x300>
    4020342c:	aa1703ea 	mov	x10, x23
    40203430:	39400ae9 	ldrb	w9, [x23, #2]
    40203434:	394006e8 	ldrb	w8, [x23, #1]
    40203438:	38404d4b 	ldrb	w11, [x10, #4]!
    4020343c:	3940094c 	ldrb	w12, [x10, #2]
    40203440:	394002ed 	ldrb	w13, [x23]
    40203444:	39400eee 	ldrb	w14, [x23, #3]
    40203448:	d370bd29 	lsl	x9, x9, #16
    4020344c:	394016ef 	ldrb	w15, [x23, #5]
    40203450:	39400d4a 	ldrb	w10, [x10, #3]
    40203454:	53103d8c 	lsl	w12, w12, #16
    40203458:	aa0821a8 	orr	x8, x13, x8, lsl #8
    4020345c:	aa0e6129 	orr	x9, x9, x14, lsl #24
    40203460:	0f05e7e4 	movi	v4.8b, #0xbf
    40203464:	2a0f216b 	orr	w11, w11, w15, lsl #8
    40203468:	2a0a618a 	orr	w10, w12, w10, lsl #24
    4020346c:	aa080128 	orr	x8, x9, x8
    40203470:	2a0b0149 	orr	w9, w10, w11
    40203474:	aa098108 	orr	x8, x8, x9, lsl #32
    40203478:	9e670100 	fmov	d0, x8
    4020347c:	52800028 	mov	w8, #0x1                   	// #1
    40203480:	4e080d03 	dup	v3.2d, x8
    40203484:	927d06c8 	and	x8, x22, #0x18
    40203488:	f100211f 	cmp	x8, #0x8
    4020348c:	0e243400 	cmgt	v0.8b, v0.8b, v4.8b
    40203490:	2f08a400 	uxtl	v0.8h, v0.8b
    40203494:	6f10a401 	uxtl2	v1.4s, v0.8h
    40203498:	2f10a400 	uxtl	v0.4s, v0.4h
    4020349c:	6f20a422 	uxtl2	v2.2d, v1.4s
    402034a0:	2f20a421 	uxtl	v1.2d, v1.2s
    402034a4:	6f20a405 	uxtl2	v5.2d, v0.4s
    402034a8:	2f20a406 	uxtl	v6.2d, v0.2s
    402034ac:	4e231c40 	and	v0.16b, v2.16b, v3.16b
    402034b0:	4e231c22 	and	v2.16b, v1.16b, v3.16b
    402034b4:	4e231ca1 	and	v1.16b, v5.16b, v3.16b
    402034b8:	4e231cc3 	and	v3.16b, v6.16b, v3.16b
    402034bc:	540009c0 	b.eq	402035f4 <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    402034c0:	aa1703e9 	mov	x9, x23
    402034c4:	f100411f 	cmp	x8, #0x10
    402034c8:	38408d2a 	ldrb	w10, [x9, #8]!
    402034cc:	3940052b 	ldrb	w11, [x9, #1]
    402034d0:	39400d2c 	ldrb	w12, [x9, #3]
    402034d4:	3940092d 	ldrb	w13, [x9, #2]
    402034d8:	3940152e 	ldrb	w14, [x9, #5]
    402034dc:	38404d2f 	ldrb	w15, [x9, #4]!
    402034e0:	39400930 	ldrb	w16, [x9, #2]
    402034e4:	39400d29 	ldrb	w9, [x9, #3]
    402034e8:	d370bdad 	lsl	x13, x13, #16
    402034ec:	aa0b214a 	orr	x10, x10, x11, lsl #8
    402034f0:	53103e10 	lsl	w16, w16, #16
    402034f4:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    402034f8:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    402034fc:	2a096209 	orr	w9, w16, w9, lsl #24
    40203500:	aa0a018a 	orr	x10, x12, x10
    40203504:	2a0b0129 	orr	w9, w9, w11
    40203508:	aa098149 	orr	x9, x10, x9, lsl #32
    4020350c:	9e670125 	fmov	d5, x9
    40203510:	52800029 	mov	w9, #0x1                   	// #1
    40203514:	4e080d26 	dup	v6.2d, x9
    40203518:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    4020351c:	2f08a484 	uxtl	v4.8h, v4.8b
    40203520:	6f10a485 	uxtl2	v5.4s, v4.8h
    40203524:	2f10a484 	uxtl	v4.4s, v4.4h
    40203528:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    4020352c:	2f20a490 	uxtl	v16.2d, v4.2s
    40203530:	6f20a484 	uxtl2	v4.2d, v4.4s
    40203534:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40203538:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    4020353c:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40203540:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40203544:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40203548:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    4020354c:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40203550:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40203554:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40203558:	540004e0 	b.eq	402035f4 <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    4020355c:	aa1703e9 	mov	x9, x23
    40203560:	0f05e7e4 	movi	v4.8b, #0xbf
    40203564:	38410d2a 	ldrb	w10, [x9, #16]!
    40203568:	3940052b 	ldrb	w11, [x9, #1]
    4020356c:	39400d2c 	ldrb	w12, [x9, #3]
    40203570:	3940092d 	ldrb	w13, [x9, #2]
    40203574:	3940152e 	ldrb	w14, [x9, #5]
    40203578:	38404d2f 	ldrb	w15, [x9, #4]!
    4020357c:	39400930 	ldrb	w16, [x9, #2]
    40203580:	39400d29 	ldrb	w9, [x9, #3]
    40203584:	d370bdad 	lsl	x13, x13, #16
    40203588:	aa0b214a 	orr	x10, x10, x11, lsl #8
    4020358c:	53103e10 	lsl	w16, w16, #16
    40203590:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40203594:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40203598:	2a096209 	orr	w9, w16, w9, lsl #24
    4020359c:	aa0a018a 	orr	x10, x12, x10
    402035a0:	2a0b0129 	orr	w9, w9, w11
    402035a4:	aa098149 	orr	x9, x10, x9, lsl #32
    402035a8:	9e670125 	fmov	d5, x9
    402035ac:	52800029 	mov	w9, #0x1                   	// #1
    402035b0:	4e080d26 	dup	v6.2d, x9
    402035b4:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    402035b8:	2f08a484 	uxtl	v4.8h, v4.8b
    402035bc:	6f10a485 	uxtl2	v5.4s, v4.8h
    402035c0:	2f10a484 	uxtl	v4.4s, v4.4h
    402035c4:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    402035c8:	2f20a490 	uxtl	v16.2d, v4.2s
    402035cc:	6f20a484 	uxtl2	v4.2d, v4.4s
    402035d0:	2f20a4a5 	uxtl	v5.2d, v5.2s
    402035d4:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    402035d8:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    402035dc:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    402035e0:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    402035e4:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    402035e8:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    402035ec:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    402035f0:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    402035f4:	4ee28462 	add	v2.2d, v3.2d, v2.2d
    402035f8:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    402035fc:	eb0802df 	cmp	x22, x8
    40203600:	4ee08440 	add	v0.2d, v2.2d, v0.2d
    40203604:	5ef1b800 	addp	d0, v0.2d
    40203608:	9e660000 	fmov	x0, d0
    4020360c:	54000100 	b.eq	4020362c <<core::fmt::Formatter>::pad_integral+0x300>  // b.none
    40203610:	cb0802c9 	sub	x9, x22, x8
    40203614:	8b0802e8 	add	x8, x23, x8
    40203618:	38c0150a 	ldrsb	w10, [x8], #1
    4020361c:	3101055f 	cmn	w10, #0x41
    40203620:	9a80d400 	cinc	x0, x0, gt
    40203624:	f1000529 	subs	x9, x9, #0x1
    40203628:	54ffff81 	b.ne	40203618 <<core::fmt::Formatter>::pad_integral+0x2ec>  // b.any
    4020362c:	8b1b001b 	add	x27, x0, x27
    40203630:	79402ab4 	ldrh	w20, [x21, #20]
    40203634:	eb14037f 	cmp	x27, x20
    40203638:	54ffeb42 	b.cs	402033a0 <<core::fmt::Formatter>::pad_integral+0x74>  // b.hs, b.nlast
    4020363c:	f90007fc 	str	x28, [sp, #8]
    40203640:	37c0011a 	tbnz	w26, #24, 40203660 <<core::fmt::Formatter>::pad_integral+0x334>
    40203644:	531d7b48 	ubfx	w8, w26, #29, #2
    40203648:	4b1b029b 	sub	w27, w20, w27
    4020364c:	7100051f 	cmp	w8, #0x1
    40203650:	540003cc 	b.gt	402036c8 <<core::fmt::Formatter>::pad_integral+0x39c>
    40203654:	35000568 	cbnz	w8, 40203700 <<core::fmt::Formatter>::pad_integral+0x3d4>
    40203658:	2a1f03fc 	mov	w28, wzr
    4020365c:	1400002a 	b	40203704 <<core::fmt::Formatter>::pad_integral+0x3d8>
    40203660:	a940f2ba 	ldp	x26, x28, [x21, #8]
    40203664:	52b3fc08 	mov	w8, #0x9fe00000            	// #-1612709888
    40203668:	f94002b9 	ldr	x25, [x21]
    4020366c:	2a1803e2 	mov	w2, w24
    40203670:	aa1703e3 	mov	x3, x23
    40203674:	aa1603e4 	mov	x4, x22
    40203678:	0a080388 	and	w8, w28, w8
    4020367c:	aa1903e0 	mov	x0, x25
    40203680:	aa1a03e1 	mov	x1, x26
    40203684:	321c0508 	orr	w8, w8, #0x30
    40203688:	32030108 	orr	w8, w8, #0x20000000
    4020368c:	b90012a8 	str	w8, [x21, #16]
    40203690:	94000279 	bl	40204074 <<core::fmt::Formatter>::pad_integral::write_prefix>
    40203694:	370006a0 	tbnz	w0, #0, 40203768 <<core::fmt::Formatter>::pad_integral+0x43c>
    40203698:	2a1f03f6 	mov	w22, wzr
    4020369c:	4b1b0294 	sub	w20, w20, w27
    402036a0:	12003ec8 	and	w8, w22, #0xffff
    402036a4:	6b34211f 	cmp	w8, w20, uxth
    402036a8:	540001a2 	b.cs	402036dc <<core::fmt::Formatter>::pad_integral+0x3b0>  // b.hs, b.nlast
    402036ac:	f9401348 	ldr	x8, [x26, #32]
    402036b0:	aa1903e0 	mov	x0, x25
    402036b4:	52800601 	mov	w1, #0x30                  	// #48
    402036b8:	110006d6 	add	w22, w22, #0x1
    402036bc:	d63f0100 	blr	x8
    402036c0:	3607ff00 	tbz	w0, #0, 402036a0 <<core::fmt::Formatter>::pad_integral+0x374>
    402036c4:	14000029 	b	40203768 <<core::fmt::Formatter>::pad_integral+0x43c>
    402036c8:	7100091f 	cmp	w8, #0x2
    402036cc:	2a1b03fc 	mov	w28, w27
    402036d0:	540001a1 	b.ne	40203704 <<core::fmt::Formatter>::pad_integral+0x3d8>  // b.any
    402036d4:	53013f7c 	ubfx	w28, w27, #1, #15
    402036d8:	1400000b 	b	40203704 <<core::fmt::Formatter>::pad_integral+0x3d8>
    402036dc:	f9400f48 	ldr	x8, [x26, #24]
    402036e0:	f94007e1 	ldr	x1, [sp, #8]
    402036e4:	aa1903e0 	mov	x0, x25
    402036e8:	aa1303e2 	mov	x2, x19
    402036ec:	d63f0100 	blr	x8
    402036f0:	370003c0 	tbnz	w0, #0, 40203768 <<core::fmt::Formatter>::pad_integral+0x43c>
    402036f4:	2a1f03f3 	mov	w19, wzr
    402036f8:	f9000abc 	str	x28, [x21, #16]
    402036fc:	1400001c 	b	4020376c <<core::fmt::Formatter>::pad_integral+0x440>
    40203700:	2a1b03fc 	mov	w28, w27
    40203704:	a94056b9 	ldp	x25, x21, [x21]
    40203708:	2a1f03f4 	mov	w20, wzr
    4020370c:	12003e88 	and	w8, w20, #0xffff
    40203710:	6b3c211f 	cmp	w8, w28, uxth
    40203714:	54000102 	b.cs	40203734 <<core::fmt::Formatter>::pad_integral+0x408>  // b.hs, b.nlast
    40203718:	f94012a8 	ldr	x8, [x21, #32]
    4020371c:	12005341 	and	w1, w26, #0x1fffff
    40203720:	aa1903e0 	mov	x0, x25
    40203724:	11000694 	add	w20, w20, #0x1
    40203728:	d63f0100 	blr	x8
    4020372c:	3607ff00 	tbz	w0, #0, 4020370c <<core::fmt::Formatter>::pad_integral+0x3e0>
    40203730:	1400000e 	b	40203768 <<core::fmt::Formatter>::pad_integral+0x43c>
    40203734:	aa1903e0 	mov	x0, x25
    40203738:	aa1503e1 	mov	x1, x21
    4020373c:	2a1803e2 	mov	w2, w24
    40203740:	aa1703e3 	mov	x3, x23
    40203744:	aa1603e4 	mov	x4, x22
    40203748:	9400024b 	bl	40204074 <<core::fmt::Formatter>::pad_integral::write_prefix>
    4020374c:	370000e0 	tbnz	w0, #0, 40203768 <<core::fmt::Formatter>::pad_integral+0x43c>
    40203750:	f9400ea8 	ldr	x8, [x21, #24]
    40203754:	f94007e1 	ldr	x1, [sp, #8]
    40203758:	aa1903e0 	mov	x0, x25
    4020375c:	aa1303e2 	mov	x2, x19
    40203760:	d63f0100 	blr	x8
    40203764:	36000160 	tbz	w0, #0, 40203790 <<core::fmt::Formatter>::pad_integral+0x464>
    40203768:	52800033 	mov	w19, #0x1                   	// #1
    4020376c:	2a1303e0 	mov	w0, w19
    40203770:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40203774:	a94557f6 	ldp	x22, x21, [sp, #80]
    40203778:	a9445ff8 	ldp	x24, x23, [sp, #64]
    4020377c:	a94367fa 	ldp	x26, x25, [sp, #48]
    40203780:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40203784:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40203788:	9101c3ff 	add	sp, sp, #0x70
    4020378c:	d65f03c0 	ret
    40203790:	2a1f03f4 	mov	w20, wzr
    40203794:	4b1c0376 	sub	w22, w27, w28
    40203798:	12003e88 	and	w8, w20, #0xffff
    4020379c:	6b36211f 	cmp	w8, w22, uxth
    402037a0:	1a9f27f3 	cset	w19, cc  // cc = lo, ul, last
    402037a4:	54fffe42 	b.cs	4020376c <<core::fmt::Formatter>::pad_integral+0x440>  // b.hs, b.nlast
    402037a8:	f94012a8 	ldr	x8, [x21, #32]
    402037ac:	12005341 	and	w1, w26, #0x1fffff
    402037b0:	aa1903e0 	mov	x0, x25
    402037b4:	11000694 	add	w20, w20, #0x1
    402037b8:	d63f0100 	blr	x8
    402037bc:	3607fee0 	tbz	w0, #0, 40203798 <<core::fmt::Formatter>::pad_integral+0x46c>
    402037c0:	17ffffeb 	b	4020376c <<core::fmt::Formatter>::pad_integral+0x440>

00000000402037c4 <core::panicking::panic_bounds_check>:
    402037c4:	d10103ff 	sub	sp, sp, #0x40
    402037c8:	a9037bfd 	stp	x29, x30, [sp, #48]
    402037cc:	9100c3fd 	add	x29, sp, #0x30
    402037d0:	910023e8 	add	x8, sp, #0x8
    402037d4:	d503201f 	nop
    402037d8:	10004929 	adr	x9, 402040fc <<u64 as core::fmt::Display>::fmt>
    402037dc:	a90007e0 	stp	x0, x1, [sp]
    402037e0:	b0000000 	adrp	x0, 40204000 <core::slice::index::slice_index_fail+0x40>
    402037e4:	91293800 	add	x0, x0, #0xa4e
    402037e8:	a90127e8 	stp	x8, x9, [sp, #16]
    402037ec:	910003e8 	mov	x8, sp
    402037f0:	910043e1 	add	x1, sp, #0x10
    402037f4:	a90227e8 	stp	x8, x9, [sp, #32]
    402037f8:	94000001 	bl	402037fc <core::panicking::panic_fmt>

00000000402037fc <core::panicking::panic_fmt>:
    402037fc:	d10103ff 	sub	sp, sp, #0x40
    40203800:	a9037bfd 	stp	x29, x30, [sp, #48]
    40203804:	9100c3fd 	add	x29, sp, #0x30
    40203808:	910023e8 	add	x8, sp, #0x8
    4020380c:	a90087e0 	stp	x0, x1, [sp, #8]
    40203810:	910063e0 	add	x0, sp, #0x18
    40203814:	a9018be8 	stp	x8, x2, [sp, #24]
    40203818:	52800028 	mov	w8, #0x1                   	// #1
    4020381c:	790053e8 	strh	w8, [sp, #40]
    40203820:	97fff218 	bl	40200080 <__rustc::rust_begin_unwind>

0000000040203824 <core::str::count::do_count_chars>:
    40203824:	d10183ff 	sub	sp, sp, #0x60
    40203828:	fd0023ea 	str	d10, [sp, #64]
    4020382c:	6d0523e9 	stp	d9, d8, [sp, #80]
    40203830:	91001c08 	add	x8, x0, #0x7
    40203834:	927df10d 	and	x13, x8, #0xfffffffffffffff8
    40203838:	cb0001ac 	sub	x12, x13, x0
    4020383c:	eb0c002b 	subs	x11, x1, x12
    40203840:	540000e2 	b.cs	4020385c <core::str::count::do_count_chars+0x38>  // b.hs, b.nlast
    40203844:	b4000721 	cbz	x1, 40203928 <core::str::count::do_count_chars+0x104>
    40203848:	f100203f 	cmp	x1, #0x8
    4020384c:	54001b82 	b.cs	40203bbc <core::str::count::do_count_chars+0x398>  // b.hs, b.nlast
    40203850:	aa1f03e9 	mov	x9, xzr
    40203854:	aa1f03e8 	mov	x8, xzr
    40203858:	140001d2 	b	40203fa0 <core::str::count::do_count_chars+0x77c>
    4020385c:	d343fd69 	lsr	x9, x11, #3
    40203860:	b4ffff29 	cbz	x9, 40203844 <core::str::count::do_count_chars+0x20>
    40203864:	eb0001bf 	cmp	x13, x0
    40203868:	9240096a 	and	x10, x11, #0x7
    4020386c:	aa1f03e8 	mov	x8, xzr
    40203870:	54000100 	b.eq	40203890 <core::str::count::do_count_chars+0x6c>  // b.none
    40203874:	cb0d000d 	sub	x13, x0, x13
    40203878:	aa0003ee 	mov	x14, x0
    4020387c:	38c015cf 	ldrsb	w15, [x14], #1
    40203880:	310105ff 	cmn	w15, #0x41
    40203884:	9a88d508 	cinc	x8, x8, gt
    40203888:	b10005ad 	adds	x13, x13, #0x1
    4020388c:	54ffff83 	b.cc	4020387c <core::str::count::do_count_chars+0x58>  // b.lo, b.ul, b.last
    40203890:	8b0c000e 	add	x14, x0, x12
    40203894:	b400056a 	cbz	x10, 40203940 <core::str::count::do_count_chars+0x11c>
    40203898:	927ded6b 	and	x11, x11, #0x7ffffffffffffff8
    4020389c:	8b0b01cc 	add	x12, x14, x11
    402038a0:	39c0018b 	ldrsb	w11, [x12]
    402038a4:	3101057f 	cmn	w11, #0x41
    402038a8:	1a9fd7eb 	cset	w11, gt
    402038ac:	f100055f 	cmp	x10, #0x1
    402038b0:	540004a0 	b.eq	40203944 <core::str::count::do_count_chars+0x120>  // b.none
    402038b4:	39c0058d 	ldrsb	w13, [x12, #1]
    402038b8:	310105bf 	cmn	w13, #0x41
    402038bc:	9a8bd56b 	cinc	x11, x11, gt
    402038c0:	f100095f 	cmp	x10, #0x2
    402038c4:	54000400 	b.eq	40203944 <core::str::count::do_count_chars+0x120>  // b.none
    402038c8:	39c0098d 	ldrsb	w13, [x12, #2]
    402038cc:	310105bf 	cmn	w13, #0x41
    402038d0:	9a8bd56b 	cinc	x11, x11, gt
    402038d4:	f1000d5f 	cmp	x10, #0x3
    402038d8:	54000360 	b.eq	40203944 <core::str::count::do_count_chars+0x120>  // b.none
    402038dc:	39c00d8d 	ldrsb	w13, [x12, #3]
    402038e0:	310105bf 	cmn	w13, #0x41
    402038e4:	9a8bd56b 	cinc	x11, x11, gt
    402038e8:	f100115f 	cmp	x10, #0x4
    402038ec:	540002c0 	b.eq	40203944 <core::str::count::do_count_chars+0x120>  // b.none
    402038f0:	39c0118d 	ldrsb	w13, [x12, #4]
    402038f4:	310105bf 	cmn	w13, #0x41
    402038f8:	9a8bd56b 	cinc	x11, x11, gt
    402038fc:	f100155f 	cmp	x10, #0x5
    40203900:	54000220 	b.eq	40203944 <core::str::count::do_count_chars+0x120>  // b.none
    40203904:	39c0158d 	ldrsb	w13, [x12, #5]
    40203908:	310105bf 	cmn	w13, #0x41
    4020390c:	9a8bd56b 	cinc	x11, x11, gt
    40203910:	f100195f 	cmp	x10, #0x6
    40203914:	54000180 	b.eq	40203944 <core::str::count::do_count_chars+0x120>  // b.none
    40203918:	39c0198a 	ldrsb	w10, [x12, #6]
    4020391c:	3101055f 	cmn	w10, #0x41
    40203920:	9a8bd56b 	cinc	x11, x11, gt
    40203924:	14000008 	b	40203944 <core::str::count::do_count_chars+0x120>
    40203928:	aa1f03e8 	mov	x8, xzr
    4020392c:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40203930:	aa0803e0 	mov	x0, x8
    40203934:	fd4023ea 	ldr	d10, [sp, #64]
    40203938:	910183ff 	add	sp, sp, #0x60
    4020393c:	d65f03c0 	ret
    40203940:	aa1f03eb 	mov	x11, xzr
    40203944:	4f00e420 	movi	v0.16b, #0x1
    40203948:	8b080168 	add	x8, x11, x8
    4020394c:	5280180a 	mov	w10, #0xc0                  	// #192
    40203950:	b20083eb 	mov	x11, #0x1000100010001       	// #281479271743489
    40203954:	1400000c 	b	40203984 <core::str::count::do_count_chars+0x160>
    40203958:	aa1f03f1 	mov	x17, xzr
    4020395c:	d348fe2f 	lsr	x15, x17, #8
    40203960:	92009e30 	and	x16, x17, #0xff00ff00ff00ff
    40203964:	8b0e018e 	add	x14, x12, x14
    40203968:	cb0d0129 	sub	x9, x9, x13
    4020396c:	92009def 	and	x15, x15, #0xff00ff00ff00ff
    40203970:	8b1001ef 	add	x15, x15, x16
    40203974:	9b0b7df0 	mul	x16, x15, x11
    40203978:	924005af 	and	x15, x13, #0x3
    4020397c:	8b50c108 	add	x8, x8, x16, lsr #48
    40203980:	b5000d8f 	cbnz	x15, 40203b30 <core::str::count::do_count_chars+0x30c>
    40203984:	b4fffd49 	cbz	x9, 4020392c <core::str::count::do_count_chars+0x108>
    40203988:	f103013f 	cmp	x9, #0xc0
    4020398c:	aa0e03ec 	mov	x12, x14
    40203990:	9a8a312d 	csel	x13, x9, x10, cc  // cc = lo, ul, last
    40203994:	d37df1ae 	lsl	x14, x13, #3
    40203998:	f27b15d0 	ands	x16, x14, #0x7e0
    4020399c:	54fffde0 	b.eq	40203958 <core::str::count::do_count_chars+0x134>  // b.none
    402039a0:	d10081cf 	sub	x15, x14, #0x20
    402039a4:	f10181ff 	cmp	x15, #0x60
    402039a8:	54000082 	b.cs	402039b8 <core::str::count::do_count_chars+0x194>  // b.hs, b.nlast
    402039ac:	aa1f03f1 	mov	x17, xzr
    402039b0:	aa0c03ef 	mov	x15, x12
    402039b4:	14000044 	b	40203ac4 <core::str::count::do_count_chars+0x2a0>
    402039b8:	d345fdef 	lsr	x15, x15, #5
    402039bc:	6f00e401 	movi	v1.2d, #0x0
    402039c0:	6f00e402 	movi	v2.2d, #0x0
    402039c4:	91010180 	add	x0, x12, #0x40
    402039c8:	910005f1 	add	x17, x15, #0x1
    402039cc:	927ee632 	and	x18, x17, #0xffffffffffffffc
    402039d0:	927ee621 	and	x1, x17, #0xffffffffffffffc
    402039d4:	8b12158f 	add	x15, x12, x18, lsl #5
    402039d8:	d1010002 	sub	x2, x0, #0x40
    402039dc:	4c400c10 	ld4	{v16.2d-v19.2d}, [x0]
    402039e0:	f1001021 	subs	x1, x1, #0x4
    402039e4:	91020000 	add	x0, x0, #0x80
    402039e8:	4c400c43 	ld4	{v3.2d-v6.2d}, [x2]
    402039ec:	6e205a07 	mvn	v7.16b, v16.16b
    402039f0:	6e205a35 	mvn	v21.16b, v17.16b
    402039f4:	6e205a5a 	mvn	v26.16b, v18.16b
    402039f8:	6e205876 	mvn	v22.16b, v3.16b
    402039fc:	6e205897 	mvn	v23.16b, v4.16b
    40203a00:	6e2058b8 	mvn	v24.16b, v5.16b
    40203a04:	6f7a0614 	ushr	v20.2d, v16.2d, #6
    40203a08:	6f7a0639 	ushr	v25.2d, v17.2d, #6
    40203a0c:	6f7a065b 	ushr	v27.2d, v18.2d, #6
    40203a10:	6f7a047c 	ushr	v28.2d, v3.2d, #6
    40203a14:	6f7a049d 	ushr	v29.2d, v4.2d, #6
    40203a18:	6f7a04be 	ushr	v30.2d, v5.2d, #6
    40203a1c:	6f7906d6 	ushr	v22.2d, v22.2d, #7
    40203a20:	6f7906f7 	ushr	v23.2d, v23.2d, #7
    40203a24:	6f790718 	ushr	v24.2d, v24.2d, #7
    40203a28:	6f7904e7 	ushr	v7.2d, v7.2d, #7
    40203a2c:	6f7906b5 	ushr	v21.2d, v21.2d, #7
    40203a30:	6f79075a 	ushr	v26.2d, v26.2d, #7
    40203a34:	6e205a7f 	mvn	v31.16b, v19.16b
    40203a38:	6f7a0670 	ushr	v16.2d, v19.2d, #6
    40203a3c:	6e2058d1 	mvn	v17.16b, v6.16b
    40203a40:	4ebc1ed2 	orr	v18.16b, v22.16b, v28.16b
    40203a44:	4ebd1ef3 	orr	v19.16b, v23.16b, v29.16b
    40203a48:	4ebe1f16 	orr	v22.16b, v24.16b, v30.16b
    40203a4c:	4eb41ce7 	orr	v7.16b, v7.16b, v20.16b
    40203a50:	4eb91eb4 	orr	v20.16b, v21.16b, v25.16b
    40203a54:	4ebb1f55 	orr	v21.16b, v26.16b, v27.16b
    40203a58:	6f7a04c3 	ushr	v3.2d, v6.2d, #6
    40203a5c:	6f7907e4 	ushr	v4.2d, v31.2d, #7
    40203a60:	6f790625 	ushr	v5.2d, v17.2d, #7
    40203a64:	4e201e46 	and	v6.16b, v18.16b, v0.16b
    40203a68:	4e201e71 	and	v17.16b, v19.16b, v0.16b
    40203a6c:	4e201ed2 	and	v18.16b, v22.16b, v0.16b
    40203a70:	4e201ce7 	and	v7.16b, v7.16b, v0.16b
    40203a74:	4e201e93 	and	v19.16b, v20.16b, v0.16b
    40203a78:	4e201eb4 	and	v20.16b, v21.16b, v0.16b
    40203a7c:	4eb01c84 	orr	v4.16b, v4.16b, v16.16b
    40203a80:	4ea31ca3 	orr	v3.16b, v5.16b, v3.16b
    40203a84:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40203a88:	4ef18646 	add	v6.2d, v18.2d, v17.2d
    40203a8c:	4ee284e2 	add	v2.2d, v7.2d, v2.2d
    40203a90:	4ef38685 	add	v5.2d, v20.2d, v19.2d
    40203a94:	4e201c63 	and	v3.16b, v3.16b, v0.16b
    40203a98:	4e201c84 	and	v4.16b, v4.16b, v0.16b
    40203a9c:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40203aa0:	4ee284a2 	add	v2.2d, v5.2d, v2.2d
    40203aa4:	4ee18461 	add	v1.2d, v3.2d, v1.2d
    40203aa8:	4ee28482 	add	v2.2d, v4.2d, v2.2d
    40203aac:	54fff961 	b.ne	402039d8 <core::str::count::do_count_chars+0x1b4>  // b.any
    40203ab0:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40203ab4:	eb12023f 	cmp	x17, x18
    40203ab8:	5ef1b821 	addp	d1, v1.2d
    40203abc:	9e660031 	fmov	x17, d1
    40203ac0:	54fff4e0 	b.eq	4020395c <core::str::count::do_count_chars+0x138>  // b.none
    40203ac4:	8b100190 	add	x16, x12, x16
    40203ac8:	f9400df2 	ldr	x18, [x15, #24]
    40203acc:	f9001ff2 	str	x18, [sp, #56]
    40203ad0:	f94009f2 	ldr	x18, [x15, #16]
    40203ad4:	f9001bf2 	str	x18, [sp, #48]
    40203ad8:	f94005f2 	ldr	x18, [x15, #8]
    40203adc:	f90017f2 	str	x18, [sp, #40]
    40203ae0:	f84205f2 	ldr	x18, [x15], #32
    40203ae4:	eb1001ff 	cmp	x15, x16
    40203ae8:	f90013f2 	str	x18, [sp, #32]
    40203aec:	ad4107e2 	ldp	q2, q1, [sp, #32]
    40203af0:	6e205823 	mvn	v3.16b, v1.16b
    40203af4:	6e205844 	mvn	v4.16b, v2.16b
    40203af8:	6f7a0421 	ushr	v1.2d, v1.2d, #6
    40203afc:	6f7a0442 	ushr	v2.2d, v2.2d, #6
    40203b00:	6f790463 	ushr	v3.2d, v3.2d, #7
    40203b04:	6f790484 	ushr	v4.2d, v4.2d, #7
    40203b08:	4ea21c82 	orr	v2.16b, v4.16b, v2.16b
    40203b0c:	4ea11c61 	orr	v1.16b, v3.16b, v1.16b
    40203b10:	4e201c21 	and	v1.16b, v1.16b, v0.16b
    40203b14:	4e201c42 	and	v2.16b, v2.16b, v0.16b
    40203b18:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40203b1c:	5ef1b821 	addp	d1, v1.2d
    40203b20:	9e660032 	fmov	x18, d1
    40203b24:	8b110251 	add	x17, x18, x17
    40203b28:	54fffd01 	b.ne	40203ac8 <core::str::count::do_count_chars+0x2a4>  // b.any
    40203b2c:	17ffff8c 	b	4020395c <core::str::count::do_count_chars+0x138>
    40203b30:	927e15a9 	and	x9, x13, #0xfc
    40203b34:	f10005ff 	cmp	x15, #0x1
    40203b38:	8b090d8a 	add	x10, x12, x9, lsl #3
    40203b3c:	f9400149 	ldr	x9, [x10]
    40203b40:	aa2903eb 	mvn	x11, x9
    40203b44:	d347fd6b 	lsr	x11, x11, #7
    40203b48:	aa491969 	orr	x9, x11, x9, lsr #6
    40203b4c:	9200c129 	and	x9, x9, #0x101010101010101
    40203b50:	540001e0 	b.eq	40203b8c <core::str::count::do_count_chars+0x368>  // b.none
    40203b54:	f940054b 	ldr	x11, [x10, #8]
    40203b58:	f10009ff 	cmp	x15, #0x2
    40203b5c:	aa2b03ec 	mvn	x12, x11
    40203b60:	d347fd8c 	lsr	x12, x12, #7
    40203b64:	aa4b198b 	orr	x11, x12, x11, lsr #6
    40203b68:	9200c16b 	and	x11, x11, #0x101010101010101
    40203b6c:	8b090169 	add	x9, x11, x9
    40203b70:	540000e0 	b.eq	40203b8c <core::str::count::do_count_chars+0x368>  // b.none
    40203b74:	f940094a 	ldr	x10, [x10, #16]
    40203b78:	aa2a03eb 	mvn	x11, x10
    40203b7c:	d347fd6b 	lsr	x11, x11, #7
    40203b80:	aa4a196a 	orr	x10, x11, x10, lsr #6
    40203b84:	9200c14a 	and	x10, x10, #0x101010101010101
    40203b88:	8b090149 	add	x9, x10, x9
    40203b8c:	d348fd2a 	lsr	x10, x9, #8
    40203b90:	92009d29 	and	x9, x9, #0xff00ff00ff00ff
    40203b94:	92009d4a 	and	x10, x10, #0xff00ff00ff00ff
    40203b98:	8b090149 	add	x9, x10, x9
    40203b9c:	b20083ea 	mov	x10, #0x1000100010001       	// #281479271743489
    40203ba0:	9b0a7d29 	mul	x9, x9, x10
    40203ba4:	8b49c108 	add	x8, x8, x9, lsr #48
    40203ba8:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40203bac:	aa0803e0 	mov	x0, x8
    40203bb0:	fd4023ea 	ldr	d10, [sp, #64]
    40203bb4:	910183ff 	add	sp, sp, #0x60
    40203bb8:	d65f03c0 	ret
    40203bbc:	f100803f 	cmp	x1, #0x20
    40203bc0:	54000082 	b.cs	40203bd0 <core::str::count::do_count_chars+0x3ac>  // b.hs, b.nlast
    40203bc4:	aa1f03e9 	mov	x9, xzr
    40203bc8:	aa1f03e8 	mov	x8, xzr
    40203bcc:	140000bc 	b	40203ebc <core::str::count::do_count_chars+0x698>
    40203bd0:	6f00e400 	movi	v0.2d, #0x0
    40203bd4:	4f05e7e3 	movi	v3.16b, #0xbf
    40203bd8:	52800028 	mov	w8, #0x1                   	// #1
    40203bdc:	6f00e402 	movi	v2.2d, #0x0
    40203be0:	6f00e407 	movi	v7.2d, #0x0
    40203be4:	927d042a 	and	x10, x1, #0x18
    40203be8:	6f00e401 	movi	v1.2d, #0x0
    40203bec:	6f00e412 	movi	v18.2d, #0x0
    40203bf0:	927be829 	and	x9, x1, #0xffffffffffffffe0
    40203bf4:	6f00e405 	movi	v5.2d, #0x0
    40203bf8:	6f00e406 	movi	v6.2d, #0x0
    40203bfc:	927be82b 	and	x11, x1, #0xffffffffffffffe0
    40203c00:	6f00e404 	movi	v4.2d, #0x0
    40203c04:	6f00e416 	movi	v22.2d, #0x0
    40203c08:	6f00e411 	movi	v17.2d, #0x0
    40203c0c:	6f00e410 	movi	v16.2d, #0x0
    40203c10:	6f00e417 	movi	v23.2d, #0x0
    40203c14:	6f00e414 	movi	v20.2d, #0x0
    40203c18:	6f00e415 	movi	v21.2d, #0x0
    40203c1c:	6f00e413 	movi	v19.2d, #0x0
    40203c20:	6f00e418 	movi	v24.2d, #0x0
    40203c24:	4e080d19 	dup	v25.2d, x8
    40203c28:	91004008 	add	x8, x0, #0x10
    40203c2c:	aa0803ec 	mov	x12, x8
    40203c30:	385f1112 	ldurb	w18, [x8, #-15]
    40203c34:	385f5102 	ldurb	w2, [x8, #-11]
    40203c38:	385f0d8d 	ldrb	w13, [x12, #-16]!
    40203c3c:	aa0c03ef 	mov	x15, x12
    40203c40:	3940098e 	ldrb	w14, [x12, #2]
    40203c44:	38404df0 	ldrb	w16, [x15, #4]!
    40203c48:	394009f1 	ldrb	w17, [x15, #2]
    40203c4c:	39400d83 	ldrb	w3, [x12, #3]
    40203c50:	39400def 	ldrb	w15, [x15, #3]
    40203c54:	d370bdce 	lsl	x14, x14, #16
    40203c58:	aa1221ad 	orr	x13, x13, x18, lsl #8
    40203c5c:	2a022210 	orr	w16, w16, w2, lsl #8
    40203c60:	53103e31 	lsl	w17, w17, #16
    40203c64:	f100816b 	subs	x11, x11, #0x20
    40203c68:	aa0361ce 	orr	x14, x14, x3, lsl #24
    40203c6c:	2a0f622f 	orr	w15, w17, w15, lsl #24
    40203c70:	aa0d01cd 	orr	x13, x14, x13
    40203c74:	2a1001ee 	orr	w14, w15, w16
    40203c78:	aa0e81ad 	orr	x13, x13, x14, lsl #32
    40203c7c:	f9000bed 	str	x13, [sp, #16]
    40203c80:	aa0c03ed 	mov	x13, x12
    40203c84:	38408dae 	ldrb	w14, [x13, #8]!
    40203c88:	39400daf 	ldrb	w15, [x13, #3]
    40203c8c:	394009b0 	ldrb	w16, [x13, #2]
    40203c90:	38404db1 	ldrb	w17, [x13, #4]!
    40203c94:	394009b2 	ldrb	w18, [x13, #2]
    40203c98:	39402582 	ldrb	w2, [x12, #9]
    40203c9c:	3940358c 	ldrb	w12, [x12, #13]
    40203ca0:	39400dad 	ldrb	w13, [x13, #3]
    40203ca4:	d370be10 	lsl	x16, x16, #16
    40203ca8:	53103e52 	lsl	w18, w18, #16
    40203cac:	aa0221ce 	orr	x14, x14, x2, lsl #8
    40203cb0:	2a0c222c 	orr	w12, w17, w12, lsl #8
    40203cb4:	aa0f620f 	orr	x15, x16, x15, lsl #24
    40203cb8:	2a0d624d 	orr	w13, w18, w13, lsl #24
    40203cbc:	aa0e01ee 	orr	x14, x15, x14
    40203cc0:	2a0c01ac 	orr	w12, w13, w12
    40203cc4:	aa0c81cc 	orr	x12, x14, x12, lsl #32
    40203cc8:	f9000fec 	str	x12, [sp, #24]
    40203ccc:	aa0803ec 	mov	x12, x8
    40203cd0:	3940090e 	ldrb	w14, [x8, #2]
    40203cd4:	38404d8f 	ldrb	w15, [x12, #4]!
    40203cd8:	39400990 	ldrb	w16, [x12, #2]
    40203cdc:	3940050d 	ldrb	w13, [x8, #1]
    40203ce0:	39400111 	ldrb	w17, [x8]
    40203ce4:	39400d12 	ldrb	w18, [x8, #3]
    40203ce8:	39401502 	ldrb	w2, [x8, #5]
    40203cec:	39400d8c 	ldrb	w12, [x12, #3]
    40203cf0:	d370bdce 	lsl	x14, x14, #16
    40203cf4:	53103e10 	lsl	w16, w16, #16
    40203cf8:	aa0d222d 	orr	x13, x17, x13, lsl #8
    40203cfc:	2a0221ef 	orr	w15, w15, w2, lsl #8
    40203d00:	3dc007fa 	ldr	q26, [sp, #16]
    40203d04:	aa1261ce 	orr	x14, x14, x18, lsl #24
    40203d08:	2a0c620c 	orr	w12, w16, w12, lsl #24
    40203d0c:	4e23375a 	cmgt	v26.16b, v26.16b, v3.16b
    40203d10:	aa0d01cd 	orr	x13, x14, x13
    40203d14:	2a0f018c 	orr	w12, w12, w15
    40203d18:	aa0c81ac 	orr	x12, x13, x12, lsl #32
    40203d1c:	aa0803ed 	mov	x13, x8
    40203d20:	6f08a75b 	uxtl2	v27.8h, v26.16b
    40203d24:	2f08a75a 	uxtl	v26.8h, v26.8b
    40203d28:	f90003ec 	str	x12, [sp]
    40203d2c:	38408dac 	ldrb	w12, [x13, #8]!
    40203d30:	39400dae 	ldrb	w14, [x13, #3]
    40203d34:	394009af 	ldrb	w15, [x13, #2]
    40203d38:	38404db0 	ldrb	w16, [x13, #4]!
    40203d3c:	394009b1 	ldrb	w17, [x13, #2]
    40203d40:	39402512 	ldrb	w18, [x8, #9]
    40203d44:	39403502 	ldrb	w2, [x8, #13]
    40203d48:	39400dad 	ldrb	w13, [x13, #3]
    40203d4c:	d370bdef 	lsl	x15, x15, #16
    40203d50:	6f10a77c 	uxtl2	v28.4s, v27.8h
    40203d54:	53103e31 	lsl	w17, w17, #16
    40203d58:	aa12218c 	orr	x12, x12, x18, lsl #8
    40203d5c:	2a022210 	orr	w16, w16, w2, lsl #8
    40203d60:	aa0e61ee 	orr	x14, x15, x14, lsl #24
    40203d64:	2f10a77b 	uxtl	v27.4s, v27.4h
    40203d68:	2f10a75e 	uxtl	v30.4s, v26.4h
    40203d6c:	2a0d622d 	orr	w13, w17, w13, lsl #24
    40203d70:	6f20a79d 	uxtl2	v29.2d, v28.4s
    40203d74:	6f10a75a 	uxtl2	v26.4s, v26.8h
    40203d78:	aa0c01cc 	orr	x12, x14, x12
    40203d7c:	2f20a79c 	uxtl	v28.2d, v28.2s
    40203d80:	91008108 	add	x8, x8, #0x20
    40203d84:	2a1001ad 	orr	w13, w13, w16
    40203d88:	6f20a768 	uxtl2	v8.2d, v27.4s
    40203d8c:	6f20a7c9 	uxtl2	v9.2d, v30.4s
    40203d90:	aa0d818c 	orr	x12, x12, x13, lsl #32
    40203d94:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    40203d98:	6f20a74a 	uxtl2	v10.2d, v26.4s
    40203d9c:	2f20a75a 	uxtl	v26.2d, v26.2s
    40203da0:	2f20a77b 	uxtl	v27.2d, v27.2s
    40203da4:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    40203da8:	f90007ec 	str	x12, [sp, #8]
    40203dac:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    40203db0:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    40203db4:	3dc003ff 	ldr	q31, [sp]
    40203db8:	4efd86d6 	add	v22.2d, v22.2d, v29.2d
    40203dbc:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40203dc0:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    40203dc4:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    40203dc8:	4efc8484 	add	v4.2d, v4.2d, v28.2d
    40203dcc:	4e2337ff 	cmgt	v31.16b, v31.16b, v3.16b
    40203dd0:	4ee884c6 	add	v6.2d, v6.2d, v8.2d
    40203dd4:	2f20a7de 	uxtl	v30.2d, v30.2s
    40203dd8:	4eea8652 	add	v18.2d, v18.2d, v10.2d
    40203ddc:	4ee984e7 	add	v7.2d, v7.2d, v9.2d
    40203de0:	4efa8421 	add	v1.2d, v1.2d, v26.2d
    40203de4:	4efb84a5 	add	v5.2d, v5.2d, v27.2d
    40203de8:	6f08a7fd 	uxtl2	v29.8h, v31.16b
    40203dec:	2f08a7ff 	uxtl	v31.8h, v31.8b
    40203df0:	4e391fde 	and	v30.16b, v30.16b, v25.16b
    40203df4:	6f10a7bc 	uxtl2	v28.4s, v29.8h
    40203df8:	6f10a7e8 	uxtl2	v8.4s, v31.8h
    40203dfc:	2f10a7bd 	uxtl	v29.4s, v29.4h
    40203e00:	2f10a7fa 	uxtl	v26.4s, v31.4h
    40203e04:	4efe8442 	add	v2.2d, v2.2d, v30.2d
    40203e08:	2f20a79b 	uxtl	v27.2d, v28.2s
    40203e0c:	6f20a79c 	uxtl2	v28.2d, v28.4s
    40203e10:	2f20a7bf 	uxtl	v31.2d, v29.2s
    40203e14:	6f20a509 	uxtl2	v9.2d, v8.4s
    40203e18:	6f20a7bd 	uxtl2	v29.2d, v29.4s
    40203e1c:	2f20a74a 	uxtl	v10.2d, v26.2s
    40203e20:	6f20a75a 	uxtl2	v26.2d, v26.4s
    40203e24:	2f20a508 	uxtl	v8.2d, v8.2s
    40203e28:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    40203e2c:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    40203e30:	4e391fff 	and	v31.16b, v31.16b, v25.16b
    40203e34:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    40203e38:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    40203e3c:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40203e40:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    40203e44:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    40203e48:	4efc8718 	add	v24.2d, v24.2d, v28.2d
    40203e4c:	4efb8673 	add	v19.2d, v19.2d, v27.2d
    40203e50:	4eff8694 	add	v20.2d, v20.2d, v31.2d
    40203e54:	4efd86b5 	add	v21.2d, v21.2d, v29.2d
    40203e58:	4ee986f7 	add	v23.2d, v23.2d, v9.2d
    40203e5c:	4eea8631 	add	v17.2d, v17.2d, v10.2d
    40203e60:	4ee88610 	add	v16.2d, v16.2d, v8.2d
    40203e64:	4efa8400 	add	v0.2d, v0.2d, v26.2d
    40203e68:	54ffee21 	b.ne	40203c2c <core::str::count::do_count_chars+0x408>  // b.any
    40203e6c:	4ef286e3 	add	v3.2d, v23.2d, v18.2d
    40203e70:	4ef68712 	add	v18.2d, v24.2d, v22.2d
    40203e74:	eb09003f 	cmp	x1, x9
    40203e78:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40203e7c:	4ee28622 	add	v2.2d, v17.2d, v2.2d
    40203e80:	4ee58685 	add	v5.2d, v20.2d, v5.2d
    40203e84:	4ee686a6 	add	v6.2d, v21.2d, v6.2d
    40203e88:	4ee18601 	add	v1.2d, v16.2d, v1.2d
    40203e8c:	4ee48664 	add	v4.2d, v19.2d, v4.2d
    40203e90:	4ef28463 	add	v3.2d, v3.2d, v18.2d
    40203e94:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40203e98:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40203e9c:	4ee68400 	add	v0.2d, v0.2d, v6.2d
    40203ea0:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40203ea4:	4ee38400 	add	v0.2d, v0.2d, v3.2d
    40203ea8:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    40203eac:	5ef1b800 	addp	d0, v0.2d
    40203eb0:	9e660008 	fmov	x8, d0
    40203eb4:	54ffd3c0 	b.eq	4020392c <core::str::count::do_count_chars+0x108>  // b.none
    40203eb8:	b400074a 	cbz	x10, 40203fa0 <core::str::count::do_count_chars+0x77c>
    40203ebc:	6f00e400 	movi	v0.2d, #0x0
    40203ec0:	6f00e401 	movi	v1.2d, #0x0
    40203ec4:	aa0903ea 	mov	x10, x9
    40203ec8:	0f05e7e2 	movi	v2.8b, #0xbf
    40203ecc:	6f00e403 	movi	v3.2d, #0x0
    40203ed0:	927df029 	and	x9, x1, #0xfffffffffffffff8
    40203ed4:	6f00e404 	movi	v4.2d, #0x0
    40203ed8:	4e081d00 	mov	v0.d[0], x8
    40203edc:	52800028 	mov	w8, #0x1                   	// #1
    40203ee0:	4e080d05 	dup	v5.2d, x8
    40203ee4:	cb090148 	sub	x8, x10, x9
    40203ee8:	8b0a000a 	add	x10, x0, x10
    40203eec:	aa0a03ed 	mov	x13, x10
    40203ef0:	3940094c 	ldrb	w12, [x10, #2]
    40203ef4:	3940054b 	ldrb	w11, [x10, #1]
    40203ef8:	38404dae 	ldrb	w14, [x13, #4]!
    40203efc:	394009af 	ldrb	w15, [x13, #2]
    40203f00:	39400150 	ldrb	w16, [x10]
    40203f04:	39400d51 	ldrb	w17, [x10, #3]
    40203f08:	d370bd8c 	lsl	x12, x12, #16
    40203f0c:	39401552 	ldrb	w18, [x10, #5]
    40203f10:	39400dad 	ldrb	w13, [x13, #3]
    40203f14:	53103def 	lsl	w15, w15, #16
    40203f18:	aa0b220b 	orr	x11, x16, x11, lsl #8
    40203f1c:	aa11618c 	orr	x12, x12, x17, lsl #24
    40203f20:	b1002108 	adds	x8, x8, #0x8
    40203f24:	2a1221ce 	orr	w14, w14, w18, lsl #8
    40203f28:	2a0d61ed 	orr	w13, w15, w13, lsl #24
    40203f2c:	9100214a 	add	x10, x10, #0x8
    40203f30:	aa0b018b 	orr	x11, x12, x11
    40203f34:	2a0e01ac 	orr	w12, w13, w14
    40203f38:	aa0c816b 	orr	x11, x11, x12, lsl #32
    40203f3c:	9e670166 	fmov	d6, x11
    40203f40:	0e2234c6 	cmgt	v6.8b, v6.8b, v2.8b
    40203f44:	2f08a4c6 	uxtl	v6.8h, v6.8b
    40203f48:	6f10a4c7 	uxtl2	v7.4s, v6.8h
    40203f4c:	2f10a4c6 	uxtl	v6.4s, v6.4h
    40203f50:	6f20a4f0 	uxtl2	v16.2d, v7.4s
    40203f54:	2f20a4d1 	uxtl	v17.2d, v6.2s
    40203f58:	6f20a4c6 	uxtl2	v6.2d, v6.4s
    40203f5c:	2f20a4e7 	uxtl	v7.2d, v7.2s
    40203f60:	4e251e10 	and	v16.16b, v16.16b, v5.16b
    40203f64:	4e251e31 	and	v17.16b, v17.16b, v5.16b
    40203f68:	4e251cc6 	and	v6.16b, v6.16b, v5.16b
    40203f6c:	4e251ce7 	and	v7.16b, v7.16b, v5.16b
    40203f70:	4ef08484 	add	v4.2d, v4.2d, v16.2d
    40203f74:	4ee68463 	add	v3.2d, v3.2d, v6.2d
    40203f78:	4ef18400 	add	v0.2d, v0.2d, v17.2d
    40203f7c:	4ee78421 	add	v1.2d, v1.2d, v7.2d
    40203f80:	54fffb61 	b.ne	40203eec <core::str::count::do_count_chars+0x6c8>  // b.any
    40203f84:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    40203f88:	4ee48461 	add	v1.2d, v3.2d, v4.2d
    40203f8c:	eb09003f 	cmp	x1, x9
    40203f90:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    40203f94:	5ef1b800 	addp	d0, v0.2d
    40203f98:	9e660008 	fmov	x8, d0
    40203f9c:	54ffcc80 	b.eq	4020392c <core::str::count::do_count_chars+0x108>  // b.none
    40203fa0:	cb09002a 	sub	x10, x1, x9
    40203fa4:	8b090009 	add	x9, x0, x9
    40203fa8:	38c0152b 	ldrsb	w11, [x9], #1
    40203fac:	3101057f 	cmn	w11, #0x41
    40203fb0:	9a88d508 	cinc	x8, x8, gt
    40203fb4:	f100054a 	subs	x10, x10, #0x1
    40203fb8:	54ffff81 	b.ne	40203fa8 <core::str::count::do_count_chars+0x784>  // b.any
    40203fbc:	17fffe5c 	b	4020392c <core::str::count::do_count_chars+0x108>

0000000040203fc0 <core::slice::index::slice_index_fail>:
    40203fc0:	d10103ff 	sub	sp, sp, #0x40
    40203fc4:	a9037bfd 	stp	x29, x30, [sp, #48]
    40203fc8:	9100c3fd 	add	x29, sp, #0x30
    40203fcc:	eb02001f 	cmp	x0, x2
    40203fd0:	540001a9 	b.ls	40204004 <core::slice::index::slice_index_fail+0x44>  // b.plast
    40203fd4:	910003e8 	mov	x8, sp
    40203fd8:	d503201f 	nop
    40203fdc:	10000909 	adr	x9, 402040fc <<u64 as core::fmt::Display>::fmt>
    40203fe0:	a9000be0 	stp	x0, x2, [sp]
    40203fe4:	b0000000 	adrp	x0, 40204000 <core::slice::index::slice_index_fail+0x40>
    40203fe8:	912b4400 	add	x0, x0, #0xad1
    40203fec:	a90127e8 	stp	x8, x9, [sp, #16]
    40203ff0:	910023e8 	add	x8, sp, #0x8
    40203ff4:	a90227e8 	stp	x8, x9, [sp, #32]
    40203ff8:	910043e1 	add	x1, sp, #0x10
    40203ffc:	aa0303e2 	mov	x2, x3
    40204000:	97fffdff 	bl	402037fc <core::panicking::panic_fmt>
    40204004:	eb02003f 	cmp	x1, x2
    40204008:	540001e8 	b.hi	40204044 <core::slice::index::slice_index_fail+0x84>  // b.pmore
    4020400c:	eb01001f 	cmp	x0, x1
    40204010:	540001a9 	b.ls	40204044 <core::slice::index::slice_index_fail+0x84>  // b.plast
    40204014:	910003e8 	mov	x8, sp
    40204018:	d503201f 	nop
    4020401c:	10000709 	adr	x9, 402040fc <<u64 as core::fmt::Display>::fmt>
    40204020:	a90127e8 	stp	x8, x9, [sp, #16]
    40204024:	910023e8 	add	x8, sp, #0x8
    40204028:	a90007e0 	stp	x0, x1, [sp]
    4020402c:	90000000 	adrp	x0, 40204000 <core::slice::index::slice_index_fail+0x40>
    40204030:	91281800 	add	x0, x0, #0xa06
    40204034:	a90227e8 	stp	x8, x9, [sp, #32]
    40204038:	910043e1 	add	x1, sp, #0x10
    4020403c:	aa0303e2 	mov	x2, x3
    40204040:	97fffdef 	bl	402037fc <core::panicking::panic_fmt>
    40204044:	910003e8 	mov	x8, sp
    40204048:	d503201f 	nop
    4020404c:	10000589 	adr	x9, 402040fc <<u64 as core::fmt::Display>::fmt>
    40204050:	a90127e8 	stp	x8, x9, [sp, #16]
    40204054:	910023e8 	add	x8, sp, #0x8
    40204058:	90000000 	adrp	x0, 40204000 <core::slice::index::slice_index_fail+0x40>
    4020405c:	912a1400 	add	x0, x0, #0xa85
    40204060:	a9000be1 	stp	x1, x2, [sp]
    40204064:	a90227e8 	stp	x8, x9, [sp, #32]
    40204068:	910043e1 	add	x1, sp, #0x10
    4020406c:	aa0303e2 	mov	x2, x3
    40204070:	97fffde3 	bl	402037fc <core::panicking::panic_fmt>

0000000040204074 <<core::fmt::Formatter>::pad_integral::write_prefix>:
    40204074:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40204078:	a90157f6 	stp	x22, x21, [sp, #16]
    4020407c:	a9024ff4 	stp	x20, x19, [sp, #32]
    40204080:	910003fd 	mov	x29, sp
    40204084:	aa0403f3 	mov	x19, x4
    40204088:	aa0303f4 	mov	x20, x3
    4020408c:	aa0103f5 	mov	x21, x1
    40204090:	7144405f 	cmp	w2, #0x110, lsl #12
    40204094:	540001a0 	b.eq	402040c8 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>  // b.none
    40204098:	f94012a8 	ldr	x8, [x21, #32]
    4020409c:	2a0203e1 	mov	w1, w2
    402040a0:	aa0003f6 	mov	x22, x0
    402040a4:	d63f0100 	blr	x8
    402040a8:	2a0003e8 	mov	w8, w0
    402040ac:	aa1603e0 	mov	x0, x22
    402040b0:	360000c8 	tbz	w8, #0, 402040c8 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>
    402040b4:	52800020 	mov	w0, #0x1                   	// #1
    402040b8:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402040bc:	a94157f6 	ldp	x22, x21, [sp, #16]
    402040c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402040c4:	d65f03c0 	ret
    402040c8:	b4000114 	cbz	x20, 402040e8 <<core::fmt::Formatter>::pad_integral::write_prefix+0x74>
    402040cc:	f9400ea3 	ldr	x3, [x21, #24]
    402040d0:	aa1403e1 	mov	x1, x20
    402040d4:	aa1303e2 	mov	x2, x19
    402040d8:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402040dc:	a94157f6 	ldp	x22, x21, [sp, #16]
    402040e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402040e4:	d61f0060 	br	x3
    402040e8:	2a1f03e0 	mov	w0, wzr
    402040ec:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402040f0:	a94157f6 	ldp	x22, x21, [sp, #16]
    402040f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402040f8:	d65f03c0 	ret

00000000402040fc <<u64 as core::fmt::Display>::fmt>:
    402040fc:	d100c3ff 	sub	sp, sp, #0x30
    40204100:	a9027bfd 	stp	x29, x30, [sp, #32]
    40204104:	910083fd 	add	x29, sp, #0x20
    40204108:	f9400009 	ldr	x9, [x0]
    4020410c:	d503201f 	nop
    40204110:	50006be8 	adr	x8, 40204e8e <jnox_kernel::ordinary_mutex_survivors::workers::INPUT+0x10>
    40204114:	f10fa13f 	cmp	x9, #0x3e8
    40204118:	540004e3 	b.cc	402041b4 <<u64 as core::fmt::Display>::fmt+0xb8>  // b.lo, b.ul, b.last
    4020411c:	d28b296c 	mov	x12, #0x594b                	// #22859
    40204120:	910033ea 	add	x10, sp, #0xc
    40204124:	5292cff1 	mov	w17, #0x967f                	// #38527
    40204128:	f2a710cc 	movk	x12, #0x3886, lsl #16
    4020412c:	9280026b 	mov	x11, #0xffffffffffffffec    	// #-20
    40204130:	5284e20d 	mov	w13, #0x2710                	// #10000
    40204134:	f2d8bacc 	movk	x12, #0xc5d6, lsl #32
    40204138:	52828f6e 	mov	w14, #0x147b                	// #5243
    4020413c:	91004d4f 	add	x15, x10, #0x13
    40204140:	f2e68dac 	movk	x12, #0x346d, lsl #48
    40204144:	52800c90 	mov	w16, #0x64                  	// #100
    40204148:	72a01311 	movk	w17, #0x98, lsl #16
    4020414c:	aa0903ea 	mov	x10, x9
    40204150:	aa0a03f2 	mov	x18, x10
    40204154:	9bcc7d4a 	umulh	x10, x10, x12
    40204158:	9100116b 	add	x11, x11, #0x4
    4020415c:	eb11025f 	cmp	x18, x17
    40204160:	d34bfd4a 	lsr	x10, x10, #11
    40204164:	1b0dc940 	msub	w0, w10, w13, w18
    40204168:	53023c02 	ubfx	w2, w0, #2, #14
    4020416c:	1b0e7c42 	mul	w2, w2, w14
    40204170:	53117c42 	lsr	w2, w2, #17
    40204174:	1b108040 	msub	w0, w2, w16, w0
    40204178:	8b224502 	add	x2, x8, w2, uxtw #1
    4020417c:	39400043 	ldrb	w3, [x2]
    40204180:	39400442 	ldrb	w2, [x2, #1]
    40204184:	8b202500 	add	x0, x8, w0, uxth #1
    40204188:	381fd1e3 	sturb	w3, [x15, #-3]
    4020418c:	39400003 	ldrb	w3, [x0]
    40204190:	39400400 	ldrb	w0, [x0, #1]
    40204194:	381fe1e2 	sturb	w2, [x15, #-2]
    40204198:	381ff1e3 	sturb	w3, [x15, #-1]
    4020419c:	381fc5e0 	strb	w0, [x15], #-4
    402041a0:	54fffd88 	b.hi	40204150 <<u64 as core::fmt::Display>::fmt+0x54>  // b.pmore
    402041a4:	cb0b03eb 	neg	x11, x11
    402041a8:	f100255f 	cmp	x10, #0x9
    402041ac:	540000c8 	b.hi	402041c4 <<u64 as core::fmt::Display>::fmt+0xc8>  // b.pmore
    402041b0:	14000015 	b	40204204 <<u64 as core::fmt::Display>::fmt+0x108>
    402041b4:	5280028b 	mov	w11, #0x14                  	// #20
    402041b8:	aa0903ea 	mov	x10, x9
    402041bc:	f100253f 	cmp	x9, #0x9
    402041c0:	54000229 	b.ls	40204204 <<u64 as core::fmt::Display>::fmt+0x108>  // b.plast
    402041c4:	53023d4c 	ubfx	w12, w10, #2, #14
    402041c8:	52828f6d 	mov	w13, #0x147b                	// #5243
    402041cc:	910033ef 	add	x15, sp, #0xc
    402041d0:	1b0d7d8c 	mul	w12, w12, w13
    402041d4:	52800c8d 	mov	w13, #0x64                  	// #100
    402041d8:	53117d8c 	lsr	w12, w12, #17
    402041dc:	1b0da98a 	msub	w10, w12, w13, w10
    402041e0:	d100096d 	sub	x13, x11, #0x2
    402041e4:	8b0b01eb 	add	x11, x15, x11
    402041e8:	8b2a250a 	add	x10, x8, w10, uxth #1
    402041ec:	3940014e 	ldrb	w14, [x10]
    402041f0:	3940054a 	ldrb	w10, [x10, #1]
    402041f4:	382d69ee 	strb	w14, [x15, x13]
    402041f8:	381ff16a 	sturb	w10, [x11, #-1]
    402041fc:	aa0c03ea 	mov	x10, x12
    40204200:	aa0d03eb 	mov	x11, x13
    40204204:	b4000049 	cbz	x9, 4020420c <<u64 as core::fmt::Display>::fmt+0x110>
    40204208:	b40000ca 	cbz	x10, 40204220 <<u64 as core::fmt::Display>::fmt+0x124>
    4020420c:	8b0a0508 	add	x8, x8, x10, lsl #1
    40204210:	d100056b 	sub	x11, x11, #0x1
    40204214:	910033e9 	add	x9, sp, #0xc
    40204218:	39400508 	ldrb	w8, [x8, #1]
    4020421c:	382b6928 	strb	w8, [x9, x11]
    40204220:	52800288 	mov	w8, #0x14                  	// #20
    40204224:	aa0103e0 	mov	x0, x1
    40204228:	52800021 	mov	w1, #0x1                   	// #1
    4020422c:	cb0b0105 	sub	x5, x8, x11
    40204230:	910033e8 	add	x8, sp, #0xc
    40204234:	52800022 	mov	w2, #0x1                   	// #1
    40204238:	8b0b0104 	add	x4, x8, x11
    4020423c:	aa1f03e3 	mov	x3, xzr
    40204240:	97fffc3b 	bl	4020332c <<core::fmt::Formatter>::pad_integral>
    40204244:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40204248:	9100c3ff 	add	sp, sp, #0x30
    4020424c:	d65f03c0 	ret

0000000040204250 <memmove>:
    40204250:	14000001 	b	40204254 <compiler_builtins::mem::memmove>

0000000040204254 <compiler_builtins::mem::memmove>:
    40204254:	cb01000c 	sub	x12, x0, x1
    40204258:	eb02019f 	cmp	x12, x2
    4020425c:	540004a2 	b.cs	402042f0 <compiler_builtins::mem::memmove+0x9c>  // b.hs, b.nlast
    40204260:	f100405f 	cmp	x2, #0x10
    40204264:	8b020008 	add	x8, x0, x2
    40204268:	8b020029 	add	x9, x1, x2
    4020426c:	54001403 	b.cc	402044ec <compiler_builtins::mem::memmove+0x298>  // b.lo, b.ul, b.last
    40204270:	927df10a 	and	x10, x8, #0xfffffffffffffff8
    40204274:	9240090b 	and	x11, x8, #0x7
    40204278:	eb08015f 	cmp	x10, x8
    4020427c:	cb0b03ec 	neg	x12, x11
    40204280:	54001142 	b.cs	402044a8 <compiler_builtins::mem::memmove+0x254>  // b.hs, b.nlast
    40204284:	f100117f 	cmp	x11, #0x4
    40204288:	54001043 	b.cc	40204490 <compiler_builtins::mem::memmove+0x23c>  // b.lo, b.ul, b.last
    4020428c:	cb00002d 	sub	x13, x1, x0
    40204290:	f10081bf 	cmp	x13, #0x20
    40204294:	8b02002d 	add	x13, x1, x2
    40204298:	54000fe3 	b.cc	40204494 <compiler_builtins::mem::memmove+0x240>  // b.lo, b.ul, b.last
    4020429c:	927e010e 	and	x14, x8, #0x4
    402042a0:	d1001050 	sub	x16, x2, #0x4
    402042a4:	927df908 	and	x8, x8, #0xfffffffffffffffb
    402042a8:	cb0e012d 	sub	x13, x9, x14
    402042ac:	8b10002f 	add	x15, x1, x16
    402042b0:	8b100010 	add	x16, x0, x16
    402042b4:	aa0e03f1 	mov	x17, x14
    402042b8:	39400df2 	ldrb	w18, [x15, #3]
    402042bc:	394009e3 	ldrb	w3, [x15, #2]
    402042c0:	d1001231 	sub	x17, x17, #0x4
    402042c4:	394001e4 	ldrb	w4, [x15]
    402042c8:	394005e5 	ldrb	w5, [x15, #1]
    402042cc:	d10011ef 	sub	x15, x15, #0x4
    402042d0:	39000e12 	strb	w18, [x16, #3]
    402042d4:	39000a03 	strb	w3, [x16, #2]
    402042d8:	39000605 	strb	w5, [x16, #1]
    402042dc:	381fc604 	strb	w4, [x16], #-4
    402042e0:	b5fffed1 	cbnz	x17, 402042b8 <compiler_builtins::mem::memmove+0x64>
    402042e4:	eb0e017f 	cmp	x11, x14
    402042e8:	54000d61 	b.ne	40204494 <compiler_builtins::mem::memmove+0x240>  // b.any
    402042ec:	1400006f 	b	402044a8 <compiler_builtins::mem::memmove+0x254>
    402042f0:	f100405f 	cmp	x2, #0x10
    402042f4:	54000703 	b.cc	402043d4 <compiler_builtins::mem::memmove+0x180>  // b.lo, b.ul, b.last
    402042f8:	cb0003ed 	neg	x13, x0
    402042fc:	924009a8 	and	x8, x13, #0x7
    40204300:	8b080009 	add	x9, x0, x8
    40204304:	eb09001f 	cmp	x0, x9
    40204308:	54000402 	b.cs	40204388 <compiler_builtins::mem::memmove+0x134>  // b.hs, b.nlast
    4020430c:	f100111f 	cmp	x8, #0x4
    40204310:	aa0003ea 	mov	x10, x0
    40204314:	aa0103eb 	mov	x11, x1
    40204318:	54000303 	b.cc	40204378 <compiler_builtins::mem::memmove+0x124>  // b.lo, b.ul, b.last
    4020431c:	f100819f 	cmp	x12, #0x20
    40204320:	aa0003ea 	mov	x10, x0
    40204324:	aa0103eb 	mov	x11, x1
    40204328:	54000283 	b.cc	40204378 <compiler_builtins::mem::memmove+0x124>  // b.lo, b.ul, b.last
    4020432c:	927e01ac 	and	x12, x13, #0x4
    40204330:	aa0003ed 	mov	x13, x0
    40204334:	aa0103ee 	mov	x14, x1
    40204338:	8b0c000a 	add	x10, x0, x12
    4020433c:	8b0c002b 	add	x11, x1, x12
    40204340:	aa0c03ef 	mov	x15, x12
    40204344:	39400dd0 	ldrb	w16, [x14, #3]
    40204348:	394009d1 	ldrb	w17, [x14, #2]
    4020434c:	f10011ef 	subs	x15, x15, #0x4
    40204350:	394001d2 	ldrb	w18, [x14]
    40204354:	394005c3 	ldrb	w3, [x14, #1]
    40204358:	910011ce 	add	x14, x14, #0x4
    4020435c:	39000db0 	strb	w16, [x13, #3]
    40204360:	390009b1 	strb	w17, [x13, #2]
    40204364:	390005a3 	strb	w3, [x13, #1]
    40204368:	380045b2 	strb	w18, [x13], #4
    4020436c:	54fffec1 	b.ne	40204344 <compiler_builtins::mem::memmove+0xf0>  // b.any
    40204370:	eb0c011f 	cmp	x8, x12
    40204374:	540000a0 	b.eq	40204388 <compiler_builtins::mem::memmove+0x134>  // b.none
    40204378:	3840156c 	ldrb	w12, [x11], #1
    4020437c:	3800154c 	strb	w12, [x10], #1
    40204380:	eb09015f 	cmp	x10, x9
    40204384:	54ffffa1 	b.ne	40204378 <compiler_builtins::mem::memmove+0x124>  // b.any
    40204388:	cb08004b 	sub	x11, x2, x8
    4020438c:	8b08002a 	add	x10, x1, x8
    40204390:	927df16c 	and	x12, x11, #0xfffffffffffffff8
    40204394:	f240095f 	tst	x10, #0x7
    40204398:	8b0c0128 	add	x8, x9, x12
    4020439c:	54001061 	b.ne	402045a8 <compiler_builtins::mem::memmove+0x354>  // b.any
    402043a0:	eb08013f 	cmp	x9, x8
    402043a4:	540000c2 	b.cs	402043bc <compiler_builtins::mem::memmove+0x168>  // b.hs, b.nlast
    402043a8:	aa0a03ed 	mov	x13, x10
    402043ac:	f84085ae 	ldr	x14, [x13], #8
    402043b0:	f800852e 	str	x14, [x9], #8
    402043b4:	eb08013f 	cmp	x9, x8
    402043b8:	54ffffa3 	b.cc	402043ac <compiler_builtins::mem::memmove+0x158>  // b.lo, b.ul, b.last
    402043bc:	8b0c0141 	add	x1, x10, x12
    402043c0:	92400962 	and	x2, x11, #0x7
    402043c4:	8b020109 	add	x9, x8, x2
    402043c8:	eb09011f 	cmp	x8, x9
    402043cc:	540000c3 	b.cc	402043e4 <compiler_builtins::mem::memmove+0x190>  // b.lo, b.ul, b.last
    402043d0:	14000075 	b	402045a4 <compiler_builtins::mem::memmove+0x350>
    402043d4:	aa0003e8 	mov	x8, x0
    402043d8:	8b020009 	add	x9, x0, x2
    402043dc:	eb09001f 	cmp	x0, x9
    402043e0:	54000e22 	b.cs	402045a4 <compiler_builtins::mem::memmove+0x350>  // b.hs, b.nlast
    402043e4:	f100105f 	cmp	x2, #0x4
    402043e8:	540004a3 	b.cc	4020447c <compiler_builtins::mem::memmove+0x228>  // b.lo, b.ul, b.last
    402043ec:	cb01010a 	sub	x10, x8, x1
    402043f0:	f100815f 	cmp	x10, #0x20
    402043f4:	54000443 	b.cc	4020447c <compiler_builtins::mem::memmove+0x228>  // b.lo, b.ul, b.last
    402043f8:	39400c2a 	ldrb	w10, [x1, #3]
    402043fc:	3940082b 	ldrb	w11, [x1, #2]
    40204400:	3940002c 	ldrb	w12, [x1]
    40204404:	3940042d 	ldrb	w13, [x1, #1]
    40204408:	39000d0a 	strb	w10, [x8, #3]
    4020440c:	927e044a 	and	x10, x2, #0xc
    40204410:	f100115f 	cmp	x10, #0x4
    40204414:	3900090b 	strb	w11, [x8, #2]
    40204418:	3900050d 	strb	w13, [x8, #1]
    4020441c:	3900010c 	strb	w12, [x8]
    40204420:	54000260 	b.eq	4020446c <compiler_builtins::mem::memmove+0x218>  // b.none
    40204424:	39401c2b 	ldrb	w11, [x1, #7]
    40204428:	3940182c 	ldrb	w12, [x1, #6]
    4020442c:	f100215f 	cmp	x10, #0x8
    40204430:	3940102d 	ldrb	w13, [x1, #4]
    40204434:	3940142e 	ldrb	w14, [x1, #5]
    40204438:	39001d0b 	strb	w11, [x8, #7]
    4020443c:	3900190c 	strb	w12, [x8, #6]
    40204440:	3900150e 	strb	w14, [x8, #5]
    40204444:	3900110d 	strb	w13, [x8, #4]
    40204448:	54000120 	b.eq	4020446c <compiler_builtins::mem::memmove+0x218>  // b.none
    4020444c:	39402c2b 	ldrb	w11, [x1, #11]
    40204450:	3940282c 	ldrb	w12, [x1, #10]
    40204454:	3940202d 	ldrb	w13, [x1, #8]
    40204458:	3940242e 	ldrb	w14, [x1, #9]
    4020445c:	39002d0b 	strb	w11, [x8, #11]
    40204460:	3900290c 	strb	w12, [x8, #10]
    40204464:	3900250e 	strb	w14, [x8, #9]
    40204468:	3900210d 	strb	w13, [x8, #8]
    4020446c:	eb0a005f 	cmp	x2, x10
    40204470:	540009a0 	b.eq	402045a4 <compiler_builtins::mem::memmove+0x350>  // b.none
    40204474:	8b0a0108 	add	x8, x8, x10
    40204478:	8b0a0021 	add	x1, x1, x10
    4020447c:	3840142a 	ldrb	w10, [x1], #1
    40204480:	3800150a 	strb	w10, [x8], #1
    40204484:	eb09011f 	cmp	x8, x9
    40204488:	54ffffa1 	b.ne	4020447c <compiler_builtins::mem::memmove+0x228>  // b.any
    4020448c:	14000046 	b	402045a4 <compiler_builtins::mem::memmove+0x350>
    40204490:	8b02002d 	add	x13, x1, x2
    40204494:	d10005ad 	sub	x13, x13, #0x1
    40204498:	385ff5ae 	ldrb	w14, [x13], #-1
    4020449c:	381ffd0e 	strb	w14, [x8, #-1]!
    402044a0:	eb08015f 	cmp	x10, x8
    402044a4:	54ffffa3 	b.cc	40204498 <compiler_builtins::mem::memmove+0x244>  // b.lo, b.ul, b.last
    402044a8:	cb0b004b 	sub	x11, x2, x11
    402044ac:	8b0c0129 	add	x9, x9, x12
    402044b0:	927df168 	and	x8, x11, #0xfffffffffffffff8
    402044b4:	9240092d 	and	x13, x9, #0x7
    402044b8:	cb0803ec 	neg	x12, x8
    402044bc:	cb080148 	sub	x8, x10, x8
    402044c0:	eb0a011f 	cmp	x8, x10
    402044c4:	b5000a6d 	cbnz	x13, 40204610 <compiler_builtins::mem::memmove+0x3bc>
    402044c8:	540000e2 	b.cs	402044e4 <compiler_builtins::mem::memmove+0x290>  // b.hs, b.nlast
    402044cc:	8b01016d 	add	x13, x11, x1
    402044d0:	d10021ad 	sub	x13, x13, #0x8
    402044d4:	f85f85ae 	ldr	x14, [x13], #-8
    402044d8:	f81f8d4e 	str	x14, [x10, #-8]!
    402044dc:	eb0a011f 	cmp	x8, x10
    402044e0:	54ffffa3 	b.cc	402044d4 <compiler_builtins::mem::memmove+0x280>  // b.lo, b.ul, b.last
    402044e4:	8b0c0129 	add	x9, x9, x12
    402044e8:	92400962 	and	x2, x11, #0x7
    402044ec:	cb02010a 	sub	x10, x8, x2
    402044f0:	eb08015f 	cmp	x10, x8
    402044f4:	54000582 	b.cs	402045a4 <compiler_builtins::mem::memmove+0x350>  // b.hs, b.nlast
    402044f8:	f100105f 	cmp	x2, #0x4
    402044fc:	540004a3 	b.cc	40204590 <compiler_builtins::mem::memmove+0x33c>  // b.lo, b.ul, b.last
    40204500:	cb08012b 	sub	x11, x9, x8
    40204504:	f100817f 	cmp	x11, #0x20
    40204508:	54000443 	b.cc	40204590 <compiler_builtins::mem::memmove+0x33c>  // b.lo, b.ul, b.last
    4020450c:	385ff12b 	ldurb	w11, [x9, #-1]
    40204510:	385fe12c 	ldurb	w12, [x9, #-2]
    40204514:	385fc12d 	ldurb	w13, [x9, #-4]
    40204518:	385fd12e 	ldurb	w14, [x9, #-3]
    4020451c:	381ff10b 	sturb	w11, [x8, #-1]
    40204520:	927e044b 	and	x11, x2, #0xc
    40204524:	f100117f 	cmp	x11, #0x4
    40204528:	381fe10c 	sturb	w12, [x8, #-2]
    4020452c:	381fd10e 	sturb	w14, [x8, #-3]
    40204530:	381fc10d 	sturb	w13, [x8, #-4]
    40204534:	54000260 	b.eq	40204580 <compiler_builtins::mem::memmove+0x32c>  // b.none
    40204538:	385fb12c 	ldurb	w12, [x9, #-5]
    4020453c:	385fa12d 	ldurb	w13, [x9, #-6]
    40204540:	f100217f 	cmp	x11, #0x8
    40204544:	385f812e 	ldurb	w14, [x9, #-8]
    40204548:	385f912f 	ldurb	w15, [x9, #-7]
    4020454c:	381fb10c 	sturb	w12, [x8, #-5]
    40204550:	381fa10d 	sturb	w13, [x8, #-6]
    40204554:	381f910f 	sturb	w15, [x8, #-7]
    40204558:	381f810e 	sturb	w14, [x8, #-8]
    4020455c:	54000120 	b.eq	40204580 <compiler_builtins::mem::memmove+0x32c>  // b.none
    40204560:	385f712c 	ldurb	w12, [x9, #-9]
    40204564:	385f612d 	ldurb	w13, [x9, #-10]
    40204568:	385f412e 	ldurb	w14, [x9, #-12]
    4020456c:	385f512f 	ldurb	w15, [x9, #-11]
    40204570:	381f710c 	sturb	w12, [x8, #-9]
    40204574:	381f610d 	sturb	w13, [x8, #-10]
    40204578:	381f510f 	sturb	w15, [x8, #-11]
    4020457c:	381f410e 	sturb	w14, [x8, #-12]
    40204580:	eb0b005f 	cmp	x2, x11
    40204584:	54000100 	b.eq	402045a4 <compiler_builtins::mem::memmove+0x350>  // b.none
    40204588:	cb0b0129 	sub	x9, x9, x11
    4020458c:	cb0b0108 	sub	x8, x8, x11
    40204590:	d1000529 	sub	x9, x9, #0x1
    40204594:	385ff52b 	ldrb	w11, [x9], #-1
    40204598:	381ffd0b 	strb	w11, [x8, #-1]!
    4020459c:	eb08015f 	cmp	x10, x8
    402045a0:	54ffffa3 	b.cc	40204594 <compiler_builtins::mem::memmove+0x340>  // b.lo, b.ul, b.last
    402045a4:	d65f03c0 	ret
    402045a8:	eb08013f 	cmp	x9, x8
    402045ac:	54fff082 	b.cs	402043bc <compiler_builtins::mem::memmove+0x168>  // b.hs, b.nlast
    402045b0:	aa0a03ed 	mov	x13, x10
    402045b4:	aa0d03f0 	mov	x16, x13
    402045b8:	394009af 	ldrb	w15, [x13, #2]
    402045bc:	394005ae 	ldrb	w14, [x13, #1]
    402045c0:	38404e11 	ldrb	w17, [x16, #4]!
    402045c4:	39400a12 	ldrb	w18, [x16, #2]
    402045c8:	394001a1 	ldrb	w1, [x13]
    402045cc:	39400da2 	ldrb	w2, [x13, #3]
    402045d0:	d370bdef 	lsl	x15, x15, #16
    402045d4:	394015a3 	ldrb	w3, [x13, #5]
    402045d8:	39400e10 	ldrb	w16, [x16, #3]
    402045dc:	53103e52 	lsl	w18, w18, #16
    402045e0:	aa0e202e 	orr	x14, x1, x14, lsl #8
    402045e4:	aa0261ef 	orr	x15, x15, x2, lsl #24
    402045e8:	910021ad 	add	x13, x13, #0x8
    402045ec:	2a032231 	orr	w17, w17, w3, lsl #8
    402045f0:	2a106250 	orr	w16, w18, w16, lsl #24
    402045f4:	aa0e01ee 	orr	x14, x15, x14
    402045f8:	2a11020f 	orr	w15, w16, w17
    402045fc:	aa0f81ce 	orr	x14, x14, x15, lsl #32
    40204600:	f800852e 	str	x14, [x9], #8
    40204604:	eb08013f 	cmp	x9, x8
    40204608:	54fffd63 	b.cc	402045b4 <compiler_builtins::mem::memmove+0x360>  // b.lo, b.ul, b.last
    4020460c:	17ffff6c 	b	402043bc <compiler_builtins::mem::memmove+0x168>
    40204610:	54fff6a2 	b.cs	402044e4 <compiler_builtins::mem::memmove+0x290>  // b.hs, b.nlast
    40204614:	8b01016d 	add	x13, x11, x1
    40204618:	d10021ad 	sub	x13, x13, #0x8
    4020461c:	aa0d03f0 	mov	x16, x13
    40204620:	394009af 	ldrb	w15, [x13, #2]
    40204624:	394005ae 	ldrb	w14, [x13, #1]
    40204628:	38404e11 	ldrb	w17, [x16, #4]!
    4020462c:	39400a12 	ldrb	w18, [x16, #2]
    40204630:	394001a1 	ldrb	w1, [x13]
    40204634:	39400da2 	ldrb	w2, [x13, #3]
    40204638:	d370bdef 	lsl	x15, x15, #16
    4020463c:	394015a3 	ldrb	w3, [x13, #5]
    40204640:	39400e10 	ldrb	w16, [x16, #3]
    40204644:	53103e52 	lsl	w18, w18, #16
    40204648:	aa0e202e 	orr	x14, x1, x14, lsl #8
    4020464c:	aa0261ef 	orr	x15, x15, x2, lsl #24
    40204650:	d10021ad 	sub	x13, x13, #0x8
    40204654:	2a032231 	orr	w17, w17, w3, lsl #8
    40204658:	2a106250 	orr	w16, w18, w16, lsl #24
    4020465c:	aa0e01ee 	orr	x14, x15, x14
    40204660:	2a11020f 	orr	w15, w16, w17
    40204664:	aa0f81ce 	orr	x14, x14, x15, lsl #32
    40204668:	f81f8d4e 	str	x14, [x10, #-8]!
    4020466c:	eb0a011f 	cmp	x8, x10
    40204670:	54fffd63 	b.cc	4020461c <compiler_builtins::mem::memmove+0x3c8>  // b.lo, b.ul, b.last
    40204674:	17ffff9c 	b	402044e4 <compiler_builtins::mem::memmove+0x290>

0000000040204678 <memcpy>:
    40204678:	f100405f 	cmp	x2, #0x10
    4020467c:	54000723 	b.cc	40204760 <memcpy+0xe8>  // b.lo, b.ul, b.last
    40204680:	cb0003ec 	neg	x12, x0
    40204684:	92400988 	and	x8, x12, #0x7
    40204688:	8b080009 	add	x9, x0, x8
    4020468c:	eb09001f 	cmp	x0, x9
    40204690:	54000422 	b.cs	40204714 <memcpy+0x9c>  // b.hs, b.nlast
    40204694:	f100111f 	cmp	x8, #0x4
    40204698:	aa0003ea 	mov	x10, x0
    4020469c:	aa0103eb 	mov	x11, x1
    402046a0:	54000323 	b.cc	40204704 <memcpy+0x8c>  // b.lo, b.ul, b.last
    402046a4:	cb01000a 	sub	x10, x0, x1
    402046a8:	aa0103eb 	mov	x11, x1
    402046ac:	f100815f 	cmp	x10, #0x20
    402046b0:	aa0003ea 	mov	x10, x0
    402046b4:	54000283 	b.cc	40204704 <memcpy+0x8c>  // b.lo, b.ul, b.last
    402046b8:	927e018c 	and	x12, x12, #0x4
    402046bc:	aa0003ed 	mov	x13, x0
    402046c0:	aa0103ee 	mov	x14, x1
    402046c4:	8b0c000a 	add	x10, x0, x12
    402046c8:	8b0c002b 	add	x11, x1, x12
    402046cc:	aa0c03ef 	mov	x15, x12
    402046d0:	39400dd0 	ldrb	w16, [x14, #3]
    402046d4:	394009d1 	ldrb	w17, [x14, #2]
    402046d8:	f10011ef 	subs	x15, x15, #0x4
    402046dc:	394001d2 	ldrb	w18, [x14]
    402046e0:	394005c3 	ldrb	w3, [x14, #1]
    402046e4:	910011ce 	add	x14, x14, #0x4
    402046e8:	39000db0 	strb	w16, [x13, #3]
    402046ec:	390009b1 	strb	w17, [x13, #2]
    402046f0:	390005a3 	strb	w3, [x13, #1]
    402046f4:	380045b2 	strb	w18, [x13], #4
    402046f8:	54fffec1 	b.ne	402046d0 <memcpy+0x58>  // b.any
    402046fc:	eb0c011f 	cmp	x8, x12
    40204700:	540000a0 	b.eq	40204714 <memcpy+0x9c>  // b.none
    40204704:	3840156c 	ldrb	w12, [x11], #1
    40204708:	3800154c 	strb	w12, [x10], #1
    4020470c:	eb09015f 	cmp	x10, x9
    40204710:	54ffffa1 	b.ne	40204704 <memcpy+0x8c>  // b.any
    40204714:	cb08004b 	sub	x11, x2, x8
    40204718:	8b08002a 	add	x10, x1, x8
    4020471c:	927df16c 	and	x12, x11, #0xfffffffffffffff8
    40204720:	f240095f 	tst	x10, #0x7
    40204724:	8b0c0128 	add	x8, x9, x12
    40204728:	540007a1 	b.ne	4020481c <memcpy+0x1a4>  // b.any
    4020472c:	eb08013f 	cmp	x9, x8
    40204730:	540000c2 	b.cs	40204748 <memcpy+0xd0>  // b.hs, b.nlast
    40204734:	aa0a03ed 	mov	x13, x10
    40204738:	f84085ae 	ldr	x14, [x13], #8
    4020473c:	f800852e 	str	x14, [x9], #8
    40204740:	eb08013f 	cmp	x9, x8
    40204744:	54ffffa3 	b.cc	40204738 <memcpy+0xc0>  // b.lo, b.ul, b.last
    40204748:	8b0c0141 	add	x1, x10, x12
    4020474c:	92400962 	and	x2, x11, #0x7
    40204750:	8b020109 	add	x9, x8, x2
    40204754:	eb09011f 	cmp	x8, x9
    40204758:	540000c3 	b.cc	40204770 <memcpy+0xf8>  // b.lo, b.ul, b.last
    4020475c:	1400002f 	b	40204818 <memcpy+0x1a0>
    40204760:	aa0003e8 	mov	x8, x0
    40204764:	8b020009 	add	x9, x0, x2
    40204768:	eb09001f 	cmp	x0, x9
    4020476c:	54000562 	b.cs	40204818 <memcpy+0x1a0>  // b.hs, b.nlast
    40204770:	f100105f 	cmp	x2, #0x4
    40204774:	540004a3 	b.cc	40204808 <memcpy+0x190>  // b.lo, b.ul, b.last
    40204778:	cb01010a 	sub	x10, x8, x1
    4020477c:	f100815f 	cmp	x10, #0x20
    40204780:	54000443 	b.cc	40204808 <memcpy+0x190>  // b.lo, b.ul, b.last
    40204784:	39400c2a 	ldrb	w10, [x1, #3]
    40204788:	3940082b 	ldrb	w11, [x1, #2]
    4020478c:	3940002c 	ldrb	w12, [x1]
    40204790:	3940042d 	ldrb	w13, [x1, #1]
    40204794:	39000d0a 	strb	w10, [x8, #3]
    40204798:	927e044a 	and	x10, x2, #0xc
    4020479c:	f100115f 	cmp	x10, #0x4
    402047a0:	3900090b 	strb	w11, [x8, #2]
    402047a4:	3900050d 	strb	w13, [x8, #1]
    402047a8:	3900010c 	strb	w12, [x8]
    402047ac:	54000260 	b.eq	402047f8 <memcpy+0x180>  // b.none
    402047b0:	39401c2b 	ldrb	w11, [x1, #7]
    402047b4:	3940182c 	ldrb	w12, [x1, #6]
    402047b8:	f100215f 	cmp	x10, #0x8
    402047bc:	3940102d 	ldrb	w13, [x1, #4]
    402047c0:	3940142e 	ldrb	w14, [x1, #5]
    402047c4:	39001d0b 	strb	w11, [x8, #7]
    402047c8:	3900190c 	strb	w12, [x8, #6]
    402047cc:	3900150e 	strb	w14, [x8, #5]
    402047d0:	3900110d 	strb	w13, [x8, #4]
    402047d4:	54000120 	b.eq	402047f8 <memcpy+0x180>  // b.none
    402047d8:	39402c2b 	ldrb	w11, [x1, #11]
    402047dc:	3940282c 	ldrb	w12, [x1, #10]
    402047e0:	3940202d 	ldrb	w13, [x1, #8]
    402047e4:	3940242e 	ldrb	w14, [x1, #9]
    402047e8:	39002d0b 	strb	w11, [x8, #11]
    402047ec:	3900290c 	strb	w12, [x8, #10]
    402047f0:	3900250e 	strb	w14, [x8, #9]
    402047f4:	3900210d 	strb	w13, [x8, #8]
    402047f8:	eb0a005f 	cmp	x2, x10
    402047fc:	540000e0 	b.eq	40204818 <memcpy+0x1a0>  // b.none
    40204800:	8b0a0108 	add	x8, x8, x10
    40204804:	8b0a0021 	add	x1, x1, x10
    40204808:	3840142a 	ldrb	w10, [x1], #1
    4020480c:	3800150a 	strb	w10, [x8], #1
    40204810:	eb09011f 	cmp	x8, x9
    40204814:	54ffffa1 	b.ne	40204808 <memcpy+0x190>  // b.any
    40204818:	d65f03c0 	ret
    4020481c:	eb08013f 	cmp	x9, x8
    40204820:	54fff942 	b.cs	40204748 <memcpy+0xd0>  // b.hs, b.nlast
    40204824:	aa0a03ed 	mov	x13, x10
    40204828:	aa0d03f0 	mov	x16, x13
    4020482c:	394009af 	ldrb	w15, [x13, #2]
    40204830:	394005ae 	ldrb	w14, [x13, #1]
    40204834:	38404e11 	ldrb	w17, [x16, #4]!
    40204838:	39400a12 	ldrb	w18, [x16, #2]
    4020483c:	394001a1 	ldrb	w1, [x13]
    40204840:	39400da2 	ldrb	w2, [x13, #3]
    40204844:	d370bdef 	lsl	x15, x15, #16
    40204848:	394015a3 	ldrb	w3, [x13, #5]
    4020484c:	39400e10 	ldrb	w16, [x16, #3]
    40204850:	53103e52 	lsl	w18, w18, #16
    40204854:	aa0e202e 	orr	x14, x1, x14, lsl #8
    40204858:	aa0261ef 	orr	x15, x15, x2, lsl #24
    4020485c:	910021ad 	add	x13, x13, #0x8
    40204860:	2a032231 	orr	w17, w17, w3, lsl #8
    40204864:	2a106250 	orr	w16, w18, w16, lsl #24
    40204868:	aa0e01ee 	orr	x14, x15, x14
    4020486c:	2a11020f 	orr	w15, w16, w17
    40204870:	aa0f81ce 	orr	x14, x14, x15, lsl #32
    40204874:	f800852e 	str	x14, [x9], #8
    40204878:	eb08013f 	cmp	x9, x8
    4020487c:	54fffd63 	b.cc	40204828 <memcpy+0x1b0>  // b.lo, b.ul, b.last
    40204880:	17ffffb2 	b	40204748 <memcpy+0xd0>

0000000040204884 <memset>:
    40204884:	f100405f 	cmp	x2, #0x10
    40204888:	540009e3 	b.cc	402049c4 <memset+0x140>  // b.lo, b.ul, b.last
    4020488c:	cb0003eb 	neg	x11, x0
    40204890:	92400968 	and	x8, x11, #0x7
    40204894:	8b080009 	add	x9, x0, x8
    40204898:	eb09001f 	cmp	x0, x9
    4020489c:	54000302 	b.cs	402048fc <memset+0x78>  // b.hs, b.nlast
    402048a0:	f100111f 	cmp	x8, #0x4
    402048a4:	aa0003ea 	mov	x10, x0
    402048a8:	54000243 	b.cc	402048f0 <memset+0x6c>  // b.lo, b.ul, b.last
    402048ac:	0e020c20 	dup	v0.4h, w1
    402048b0:	927e016b 	and	x11, x11, #0x4
    402048b4:	aa0003ec 	mov	x12, x0
    402048b8:	8b0b000a 	add	x10, x0, x11
    402048bc:	aa0b03ed 	mov	x13, x11
    402048c0:	5e0e0401 	mov	h1, v0.h[3]
    402048c4:	5e0a0402 	mov	h2, v0.h[2]
    402048c8:	5e060403 	mov	h3, v0.h[1]
    402048cc:	3d000180 	str	b0, [x12]
    402048d0:	f10011ad 	subs	x13, x13, #0x4
    402048d4:	3c003181 	stur	b1, [x12, #3]
    402048d8:	3c002182 	stur	b2, [x12, #2]
    402048dc:	3c001183 	stur	b3, [x12, #1]
    402048e0:	9100118c 	add	x12, x12, #0x4
    402048e4:	54ffff41 	b.ne	402048cc <memset+0x48>  // b.any
    402048e8:	eb0b011f 	cmp	x8, x11
    402048ec:	54000080 	b.eq	402048fc <memset+0x78>  // b.none
    402048f0:	38001541 	strb	w1, [x10], #1
    402048f4:	eb09015f 	cmp	x10, x9
    402048f8:	54ffffc1 	b.ne	402048f0 <memset+0x6c>  // b.any
    402048fc:	cb08004a 	sub	x10, x2, x8
    40204900:	927df148 	and	x8, x10, #0xfffffffffffffff8
    40204904:	8b080128 	add	x8, x9, x8
    40204908:	eb08013f 	cmp	x9, x8
    4020490c:	54000102 	b.cs	4020492c <memset+0xa8>  // b.hs, b.nlast
    40204910:	12001c2b 	and	w11, w1, #0xff
    40204914:	3200c3ec 	mov	w12, #0x1010101             	// #16843009
    40204918:	1b0c7d6b 	mul	w11, w11, w12
    4020491c:	aa0b816b 	orr	x11, x11, x11, lsl #32
    40204920:	f800852b 	str	x11, [x9], #8
    40204924:	eb08013f 	cmp	x9, x8
    40204928:	54ffffc3 	b.cc	40204920 <memset+0x9c>  // b.lo, b.ul, b.last
    4020492c:	92400942 	and	x2, x10, #0x7
    40204930:	8b020109 	add	x9, x8, x2
    40204934:	eb09011f 	cmp	x8, x9
    40204938:	54000442 	b.cs	402049c0 <memset+0x13c>  // b.hs, b.nlast
    4020493c:	f100105f 	cmp	x2, #0x4
    40204940:	540003a3 	b.cc	402049b4 <memset+0x130>  // b.lo, b.ul, b.last
    40204944:	927e044a 	and	x10, x2, #0xc
    40204948:	39000d01 	strb	w1, [x8, #3]
    4020494c:	f100115f 	cmp	x10, #0x4
    40204950:	8b0a010b 	add	x11, x8, x10
    40204954:	39000901 	strb	w1, [x8, #2]
    40204958:	39000501 	strb	w1, [x8, #1]
    4020495c:	39000101 	strb	w1, [x8]
    40204960:	54000240 	b.eq	402049a8 <memset+0x124>  // b.none
    40204964:	0e020c20 	dup	v0.4h, w1
    40204968:	f100215f 	cmp	x10, #0x8
    4020496c:	5e0e0401 	mov	h1, v0.h[3]
    40204970:	5e0a0402 	mov	h2, v0.h[2]
    40204974:	5e060403 	mov	h3, v0.h[1]
    40204978:	3c004100 	stur	b0, [x8, #4]
    4020497c:	3c007101 	stur	b1, [x8, #7]
    40204980:	3c006102 	stur	b2, [x8, #6]
    40204984:	3c005103 	stur	b3, [x8, #5]
    40204988:	54000100 	b.eq	402049a8 <memset+0x124>  // b.none
    4020498c:	5e0e0401 	mov	h1, v0.h[3]
    40204990:	5e0a0402 	mov	h2, v0.h[2]
    40204994:	3c008100 	stur	b0, [x8, #8]
    40204998:	5e060403 	mov	h3, v0.h[1]
    4020499c:	3c00b101 	stur	b1, [x8, #11]
    402049a0:	3c00a102 	stur	b2, [x8, #10]
    402049a4:	3c009103 	stur	b3, [x8, #9]
    402049a8:	eb0a005f 	cmp	x2, x10
    402049ac:	aa0b03e8 	mov	x8, x11
    402049b0:	54000080 	b.eq	402049c0 <memset+0x13c>  // b.none
    402049b4:	38001501 	strb	w1, [x8], #1
    402049b8:	eb09011f 	cmp	x8, x9
    402049bc:	54ffffc1 	b.ne	402049b4 <memset+0x130>  // b.any
    402049c0:	d65f03c0 	ret
    402049c4:	aa0003e8 	mov	x8, x0
    402049c8:	8b020009 	add	x9, x0, x2
    402049cc:	eb09001f 	cmp	x0, x9
    402049d0:	54fffb63 	b.cc	4020493c <memset+0xb8>  // b.lo, b.ul, b.last
    402049d4:	17fffffb 	b	402049c0 <memset+0x13c>
