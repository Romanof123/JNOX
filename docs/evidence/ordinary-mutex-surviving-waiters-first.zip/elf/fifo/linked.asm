
/mnt/d/codex/jnox295-independent-evidence/elf/fifo/kernel.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000040200000 <_start>:
    40200000:	d5034fdf 	msr	daifset, #0xf
    40200004:	d5384240 	mrs	x0, currentel
    40200008:	f100101f 	cmp	x0, #0x4
    4020000c:	54000241 	b.ne	40200054 <_start+0x54>  // b.any
    40200010:	d50041bf 	msr	spsel, #0x1
    40200014:	58000260 	ldr	x0, 40200060 <_start+0x60>
    40200018:	9100001f 	mov	sp, x0
    4020001c:	d5381040 	mrs	x0, cpacr_el1
    40200020:	b26c0400 	orr	x0, x0, #0x300000
    40200024:	d5181040 	msr	cpacr_el1, x0
    40200028:	d5033fdf 	isb
    4020002c:	580001e0 	ldr	x0, 40200068 <_start+0x68>
    40200030:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    40200034:	f9000001 	str	x1, [x0]
    40200038:	580001c0 	ldr	x0, 40200070 <_start+0x70>
    4020003c:	580001e1 	ldr	x1, 40200078 <_start+0x78>
    40200040:	eb01001f 	cmp	x0, x1
    40200044:	54000062 	b.cs	40200050 <_start+0x50>  // b.hs, b.nlast
    40200048:	f800841f 	str	xzr, [x0], #8
    4020004c:	17fffffd 	b	40200040 <_start+0x40>
    40200050:	14000988 	b	40202670 <jnox_kernel::kernel_main>
    40200054:	d503205f 	wfe
    40200058:	17ffffff 	b	40200054 <_start+0x54>
    4020005c:	00000000 	udf	#0
    40200060:	4022b440 	.word	0x4022b440
    40200064:	00000000 	.word	0x00000000
    40200068:	40227438 	.word	0x40227438
    4020006c:	00000000 	.word	0x00000000
    40200070:	40205150 	.word	0x40205150
    40200074:	00000000 	.word	0x00000000
    40200078:	40227440 	.word	0x40227440
	...

0000000040200800 <sched_vectors>:
    40200800:	14000200 00000000 00000000 00000000     ................
	...
    40200880:	140001e0 00000000 00000000 00000000     ................
	...
    40200900:	140001c0 00000000 00000000 00000000     ................
	...
    40200980:	140001a0 00000000 00000000 00000000     ................
	...
    40200a00:	140001b6 00000000 00000000 00000000     ................
	...
    40200a80:	14000161 00000000 00000000 00000000     a...............
	...
    40200b00:	14000140 00000000 00000000 00000000     @...............
	...
    40200b80:	14000120 00000000 00000000 00000000      ...............
	...
    40200c00:	14000100 00000000 00000000 00000000     ................
	...
    40200c80:	140000e0 00000000 00000000 00000000     ................
	...
    40200d00:	140000c0 00000000 00000000 00000000     ................
	...
    40200d80:	140000a0 00000000 00000000 00000000     ................
	...
    40200e00:	14000080 00000000 00000000 00000000     ................
	...
    40200e80:	14000060 00000000 00000000 00000000     `...............
	...
    40200f00:	14000040 00000000 00000000 00000000     @...............
	...
    40200f80:	14000020 00000000 00000000 00000000      ...............
	...
    40201000:	140000f4 d10d03ff f90027e9 d5033fdf     .........'...?..
    40201010:	d53be029 f9009fe9 f94027e9 a90007e0     ).;......'@.....
    40201020:	a9010fe2 a90217e4 a9031fe6 a90427e8     .............'..
    40201030:	a9052fea a90637ec a9073fee a90847f0     ./...7...?...G..
    40201040:	a9094ff2 a90a57f4 a90b5ff6 a90c67f8     .O...W..._...g..
    40201050:	a90d6ffa a90e77fc f9007bfe ad0a07e0     .o...w...{......
    40201060:	ad0b0fe2 ad0c17e4 ad0d1fe6 ad0e27e8     .............'..
    40201070:	ad0f2fea ad1037ec ad113fee ad1247f0     ./...7...?...G..
    40201080:	ad134ff2 ad1457f4 ad155ff6 ad1667f8     .O...W..._...g..
    40201090:	ad176ffa ad1877fc ad197ffe d5384029     .o...w......)@8.
    402010a0:	d538400a a90fabe9 d53b4409 d53b442a     .@8......D;.*D;.
    402010b0:	a910abe9 d538d089 d538410a a911abe9     ......8..A8.....
    402010c0:	d53bd049 d53bd06a a912abe9 910003e0     I.;.j.;.........
    402010d0:	940000c0 14000036 d10d03ff f90027e9     ....6........'..
    402010e0:	d5033fdf d53be029 f9009fe9 f94027e9     .?..).;......'@.
    402010f0:	a90007e0 a9010fe2 a90217e4 a9031fe6     ................
    40201100:	a90427e8 a9052fea a90637ec a9073fee     .'.../...7...?..
    40201110:	a90847f0 a9094ff2 a90a57f4 a90b5ff6     .G...O...W..._..
    40201120:	a90c67f8 a90d6ffa a90e77fc f9007bfe     .g...o...w...{..
    40201130:	ad0a07e0 ad0b0fe2 ad0c17e4 ad0d1fe6     ................
    40201140:	ad0e27e8 ad0f2fea ad1037ec ad113fee     .'.../...7...?..
    40201150:	ad1247f0 ad134ff2 ad1457f4 ad155ff6     .G...O...W..._..
    40201160:	ad1667f8 ad176ffa ad1877fc ad197ffe     .g...o...w......
    40201170:	d5384029 d538400a a90fabe9 d53b4409     )@8..@8......D;.
    40201180:	d53b442a a910abe9 d538d089 d538410a     *D;.......8..A8.
    40201190:	a911abe9 d53bd049 d53bd06a a912abe9     ....I.;.j.;.....
    402011a0:	910003e0 94000314 14000001              ............

00000000402011ac <sched_start_frame>:
    402011ac:	9100001f 	mov	sp, x0
    402011b0:	a94fabe9 	ldp	x9, x10, [sp, #248]
    402011b4:	d5184029 	msr	elr_el1, x9
    402011b8:	d518400a 	msr	spsr_el1, x10
    402011bc:	a950abe9 	ldp	x9, x10, [sp, #264]
    402011c0:	d51b4409 	msr	fpcr, x9
    402011c4:	d51b442a 	msr	fpsr, x10
    402011c8:	a951abe9 	ldp	x9, x10, [sp, #280]
    402011cc:	d518d089 	msr	tpidr_el1, x9
    402011d0:	d518410a 	msr	sp_el0, x10
    402011d4:	a952abe9 	ldp	x9, x10, [sp, #296]
    402011d8:	d51bd049 	msr	tpidr_el0, x9
    402011dc:	d51bd06a 	msr	tpidrro_el0, x10
    402011e0:	ad4a07e0 	ldp	q0, q1, [sp, #320]
    402011e4:	ad4b0fe2 	ldp	q2, q3, [sp, #352]
    402011e8:	ad4c17e4 	ldp	q4, q5, [sp, #384]
    402011ec:	ad4d1fe6 	ldp	q6, q7, [sp, #416]
    402011f0:	ad4e27e8 	ldp	q8, q9, [sp, #448]
    402011f4:	ad4f2fea 	ldp	q10, q11, [sp, #480]
    402011f8:	ad5037ec 	ldp	q12, q13, [sp, #512]
    402011fc:	ad513fee 	ldp	q14, q15, [sp, #544]
    40201200:	ad5247f0 	ldp	q16, q17, [sp, #576]
    40201204:	ad534ff2 	ldp	q18, q19, [sp, #608]
    40201208:	ad5457f4 	ldp	q20, q21, [sp, #640]
    4020120c:	ad555ff6 	ldp	q22, q23, [sp, #672]
    40201210:	ad5667f8 	ldp	q24, q25, [sp, #704]
    40201214:	ad576ffa 	ldp	q26, q27, [sp, #736]
    40201218:	ad5877fc 	ldp	q28, q29, [sp, #768]
    4020121c:	ad597ffe 	ldp	q30, q31, [sp, #800]
    40201220:	d503201f 	nop
    40201224:	1012e069 	adr	x9, 40226e30 <jnox_ap_returns>
    40201228:	f940012a 	ldr	x10, [x9]
    4020122c:	f101015f 	cmp	x10, #0x40
    40201230:	54ffee82 	b.cs	40201000 <sched_vectors+0x800>  // b.hs, b.nlast
    40201234:	9100054b 	add	x11, x10, #0x1
    40201238:	f800852b 	str	x11, [x9], #8
    4020123c:	d280030b 	mov	x11, #0x18                  	// #24
    40201240:	9b0b2549 	madd	x9, x10, x11, x9
    40201244:	910003ea 	mov	x10, sp
    40201248:	d538402b 	mrs	x11, elr_el1
    4020124c:	a9002d2a 	stp	x10, x11, [x9]
    40201250:	d5033fdf 	isb
    40201254:	d53be02a 	mrs	x10, cntpct_el0
    40201258:	f900092a 	str	x10, [x9, #16]
    4020125c:	a94007e0 	ldp	x0, x1, [sp]
    40201260:	a9410fe2 	ldp	x2, x3, [sp, #16]
    40201264:	a94217e4 	ldp	x4, x5, [sp, #32]
    40201268:	a9431fe6 	ldp	x6, x7, [sp, #48]
    4020126c:	a94427e8 	ldp	x8, x9, [sp, #64]
    40201270:	a9452fea 	ldp	x10, x11, [sp, #80]
    40201274:	a94637ec 	ldp	x12, x13, [sp, #96]
    40201278:	a9473fee 	ldp	x14, x15, [sp, #112]
    4020127c:	a94847f0 	ldp	x16, x17, [sp, #128]
    40201280:	a9494ff2 	ldp	x18, x19, [sp, #144]
    40201284:	a94a57f4 	ldp	x20, x21, [sp, #160]
    40201288:	a94b5ff6 	ldp	x22, x23, [sp, #176]
    4020128c:	a94c67f8 	ldp	x24, x25, [sp, #192]
    40201290:	a94d6ffa 	ldp	x26, x27, [sp, #208]
    40201294:	a94e77fc 	ldp	x28, x29, [sp, #224]
    40201298:	f9407bfe 	ldr	x30, [sp, #240]
    4020129c:	910d03ff 	add	sp, sp, #0x340
    402012a0:	d5033f5f 	clrex
    402012a4:	d69f03e0 	eret

00000000402012a8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17ha1954380307d5c31E.llvm.4966675838875970461>:
    402012a8:	d10143ff 	sub	sp, sp, #0x50
    402012ac:	f9001bfe 	str	x30, [sp, #48]
    402012b0:	a9044ff4 	stp	x20, x19, [sp, #64]
    402012b4:	aa1f03f3 	mov	x19, xzr
    402012b8:	f90007e0 	str	x0, [sp, #8]
    402012bc:	910073f4 	add	x20, sp, #0x1c
    402012c0:	910023e0 	add	x0, sp, #0x8
    402012c4:	aa1303e1 	mov	x1, x19
    402012c8:	9400046f 	bl	40202484 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    402012cc:	39000280 	strb	w0, [x20]
    402012d0:	91000673 	add	x19, x19, #0x1
    402012d4:	d358fc08 	lsr	x8, x0, #24
    402012d8:	39000e88 	strb	w8, [x20, #3]
    402012dc:	d350fc08 	lsr	x8, x0, #16
    402012e0:	d348fc09 	lsr	x9, x0, #8
    402012e4:	39000a88 	strb	w8, [x20, #2]
    402012e8:	d360fc08 	lsr	x8, x0, #32
    402012ec:	39000689 	strb	w9, [x20, #1]
    402012f0:	39001288 	strb	w8, [x20, #4]
    402012f4:	91001694 	add	x20, x20, #0x5
    402012f8:	f100127f 	cmp	x19, #0x4
    402012fc:	54fffe21 	b.ne	402012c0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17ha1954380307d5c31E.llvm.4966675838875970461+0x18>  // b.any
    40201300:	3940b7e8 	ldrb	w8, [sp, #45]
    40201304:	3940b3e9 	ldrb	w9, [sp, #44]
    40201308:	3940bbea 	ldrb	w10, [sp, #46]
    4020130c:	3940bfeb 	ldrb	w11, [sp, #47]
    40201310:	394087ec 	ldrb	w12, [sp, #33]
    40201314:	2a082128 	orr	w8, w9, w8, lsl #8
    40201318:	394083e9 	ldrb	w9, [sp, #32]
    4020131c:	2a0c2129 	orr	w9, w9, w12, lsl #8
    40201320:	39408bec 	ldrb	w12, [sp, #34]
    40201324:	53103d4a 	lsl	w10, w10, #16
    40201328:	2a0b614a 	orr	w10, w10, w11, lsl #24
    4020132c:	39408feb 	ldrb	w11, [sp, #35]
    40201330:	53103d8c 	lsl	w12, w12, #16
    40201334:	2a0b618b 	orr	w11, w12, w11, lsl #24
    40201338:	394077ec 	ldrb	w12, [sp, #29]
    4020133c:	2a080148 	orr	w8, w10, w8
    40201340:	2a090169 	orr	w9, w11, w9
    40201344:	b9001be8 	str	w8, [sp, #24]
    40201348:	394073e8 	ldrb	w8, [sp, #28]
    4020134c:	aa0c2108 	orr	x8, x8, x12, lsl #8
    40201350:	39407fea 	ldrb	w10, [sp, #31]
    40201354:	39407beb 	ldrb	w11, [sp, #30]
    40201358:	d370bd6b 	lsl	x11, x11, #16
    4020135c:	aa0a616a 	orr	x10, x11, x10, lsl #24
    40201360:	aa080148 	orr	x8, x10, x8
    40201364:	aa098108 	orr	x8, x8, x9, lsl #32
    40201368:	394097e9 	ldrb	w9, [sp, #37]
    4020136c:	394093ea 	ldrb	w10, [sp, #36]
    40201370:	aa092149 	orr	x9, x10, x9, lsl #8
    40201374:	39409bea 	ldrb	w10, [sp, #38]
    40201378:	d370bd4a 	lsl	x10, x10, #16
    4020137c:	39409feb 	ldrb	w11, [sp, #39]
    40201380:	aa0b614a 	orr	x10, x10, x11, lsl #24
    40201384:	aa090149 	orr	x9, x10, x9
    40201388:	910073ea 	add	x10, sp, #0x1c
    4020138c:	9100214a 	add	x10, x10, #0x8
    40201390:	38404d4b 	ldrb	w11, [x10, #4]!
    40201394:	3940a7ec 	ldrb	w12, [sp, #41]
    40201398:	2a0c216b 	orr	w11, w11, w12, lsl #8
    4020139c:	3940094c 	ldrb	w12, [x10, #2]
    402013a0:	53103d8c 	lsl	w12, w12, #16
    402013a4:	39400d4a 	ldrb	w10, [x10, #3]
    402013a8:	2a0a618a 	orr	w10, w12, w10, lsl #24
    402013ac:	2a0b014a 	orr	w10, w10, w11
    402013b0:	aa0a8129 	orr	x9, x9, x10, lsl #32
    402013b4:	a900a7e8 	stp	x8, x9, [sp, #8]
    402013b8:	910023e0 	add	x0, sp, #0x8
    402013bc:	94000561 	bl	40202940 <jnox_kernel::domain_policy::effective_priorities>
    402013c0:	a9444ff4 	ldp	x20, x19, [sp, #64]
    402013c4:	f9401bfe 	ldr	x30, [sp, #48]
    402013c8:	910143ff 	add	sp, sp, #0x50
    402013cc:	d65f03c0 	ret

00000000402013d0 <jnox_kernel::ordinary_mutex_fifo::unexpected>:
    402013d0:	f81f0ffe 	str	x30, [sp, #-16]!
    402013d4:	52800120 	mov	w0, #0x9                   	// #9
    402013d8:	94000074 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>

00000000402013dc <jnox_kernel::ordinary_mutex_fifo::run>:
    402013dc:	f81f0ffe 	str	x30, [sp, #-16]!
    402013e0:	940005c6 	bl	40202af8 <jnox_kernel::context::init_timer_irq>
    402013e4:	52800020 	mov	w0, #0x1                   	// #1
    402013e8:	94000119 	bl	4020184c <_ZN11jnox_kernel19ordinary_mutex_fifo5start17hc37bd2ad57dcb1c6E.llvm.4966675838875970461>

00000000402013ec <jnox_kernel::ordinary_mutex_fifo::exit>:
    402013ec:	f81f0ffe 	str	x30, [sp, #-16]!
    402013f0:	52800080 	mov	w0, #0x4                   	// #4
    402013f4:	aa1f03e1 	mov	x1, xzr
    402013f8:	94000273 	bl	40201dc4 <jnox_kernel::ordinary_mutex_fifo::checked>
    402013fc:	52800020 	mov	w0, #0x1                   	// #1
    40201400:	9400006a 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>

0000000040201404 <jnox_kernel::ordinary_mutex_fifo::idle>:
    40201404:	d10103ff 	sub	sp, sp, #0x40
    40201408:	a9015ffe 	stp	x30, x23, [sp, #16]
    4020140c:	a90257f6 	stp	x22, x21, [sp, #32]
    40201410:	a9034ff4 	stp	x20, x19, [sp, #48]
    40201414:	90000028 	adrp	x8, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201418:	f9400108 	ldr	x8, [x8]
    4020141c:	f100091f 	cmp	x8, #0x2
    40201420:	54000540 	b.eq	402014c8 <jnox_kernel::ordinary_mutex_fifo::idle+0xc4>  // b.none
    40201424:	b50003e8 	cbnz	x8, 402014a0 <jnox_kernel::ordinary_mutex_fifo::idle+0x9c>
    40201428:	90000028 	adrp	x8, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    4020142c:	9104e108 	add	x8, x8, #0x138
    40201430:	39402509 	ldrb	w9, [x8, #9]
    40201434:	71001d3f 	cmp	w9, #0x7
    40201438:	54000341 	b.ne	402014a0 <jnox_kernel::ordinary_mutex_fifo::idle+0x9c>  // b.any
    4020143c:	f9400108 	ldr	x8, [x8]
    40201440:	f1000d1f 	cmp	x8, #0x3
    40201444:	540002e1 	b.ne	402014a0 <jnox_kernel::ordinary_mutex_fifo::idle+0x9c>  // b.any
    40201448:	aa1f03f4 	mov	x20, xzr
    4020144c:	90000035 	adrp	x21, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201450:	910242b5 	add	x21, x21, #0x90
    40201454:	d503201f 	nop
    40201458:	1001dd53 	adr	x19, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    4020145c:	910033f6 	add	x22, sp, #0xc
    40201460:	d0000017 	adrp	x23, 40203000 <<core::fmt::Formatter>::pad_integral+0x494>
    40201464:	913be6f7 	add	x23, x23, #0xef9
    40201468:	f100129f 	cmp	x20, #0x4
    4020146c:	540001e0 	b.eq	402014a8 <jnox_kernel::ordinary_mutex_fifo::idle+0xa4>  // b.none
    40201470:	f84106a8 	ldr	x8, [x21], #16
    40201474:	b5000168 	cbnz	x8, 402014a0 <jnox_kernel::ordinary_mutex_fifo::idle+0x9c>
    40201478:	aa1303e0 	mov	x0, x19
    4020147c:	97ffff8b 	bl	402012a8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17ha1954380307d5c31E.llvm.4966675838875970461>
    40201480:	36000100 	tbz	w0, #0, 402014a0 <jnox_kernel::ordinary_mutex_fifo::idle+0x9c>
    40201484:	d348fc08 	lsr	x8, x0, #8
    40201488:	b9000fe8 	str	w8, [sp, #12]
    4020148c:	38746ac8 	ldrb	w8, [x22, x20]
    40201490:	38746ae9 	ldrb	w9, [x23, x20]
    40201494:	91000694 	add	x20, x20, #0x1
    40201498:	6b09011f 	cmp	w8, w9
    4020149c:	54fffe60 	b.eq	40201468 <jnox_kernel::ordinary_mutex_fifo::idle+0x64>  // b.none
    402014a0:	52800060 	mov	w0, #0x3                   	// #3
    402014a4:	94000041 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>
    402014a8:	90000028 	adrp	x8, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    402014ac:	f9407508 	ldr	x8, [x8, #232]
    402014b0:	f100051f 	cmp	x8, #0x1
    402014b4:	54000061 	b.ne	402014c0 <jnox_kernel::ordinary_mutex_fifo::idle+0xbc>  // b.any
    402014b8:	52800040 	mov	w0, #0x2                   	// #2
    402014bc:	940000e4 	bl	4020184c <_ZN11jnox_kernel19ordinary_mutex_fifo5start17hc37bd2ad57dcb1c6E.llvm.4966675838875970461>
    402014c0:	aa1f03e0 	mov	x0, xzr
    402014c4:	94000039 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>
    402014c8:	d503201f 	nop
    402014cc:	10015ae0 	adr	x0, 40204028 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0xd8>
    402014d0:	940006cd 	bl	40203004 <core::option::unwrap_failed>

00000000402014d4 <jnox_kernel::ordinary_mutex_fifo::line>:
    402014d4:	d10043ff 	sub	sp, sp, #0x10
    402014d8:	52800308 	mov	w8, #0x18                  	// #24
    402014dc:	72a12008 	movk	w8, #0x900, lsl #16
    402014e0:	3940000c 	ldrb	w12, [x0]
    402014e4:	b9400109 	ldr	w9, [x8]
    402014e8:	36280069 	tbz	w9, #5, 402014f4 <jnox_kernel::ordinary_mutex_fifo::line+0x20>
    402014ec:	d5033fdf 	isb
    402014f0:	17fffffd 	b	402014e4 <jnox_kernel::ordinary_mutex_fifo::line+0x10>
    402014f4:	52a12009 	mov	w9, #0x9000000             	// #150994944
    402014f8:	8b020c2a 	add	x10, x1, x2, lsl #3
    402014fc:	5280040b 	mov	w11, #0x20                  	// #32
    40201500:	b900012c 	str	w12, [x9]
    40201504:	910003ec 	mov	x12, sp
    40201508:	d503201f 	nop
    4020150c:	100159ad 	adr	x13, 40204040 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0xf0>
    40201510:	f940002e 	ldr	x14, [x1]
    40201514:	910003ef 	mov	x15, sp
    40201518:	52800790 	mov	w16, #0x3c                  	// #60
    4020151c:	a9007fff 	stp	xzr, xzr, [sp]
    40201520:	9ad025d1 	lsr	x17, x14, x16
    40201524:	92400e31 	and	x17, x17, #0xf
    40201528:	387169b1 	ldrb	w17, [x13, x17]
    4020152c:	380015f1 	strb	w17, [x15], #1
    40201530:	d1001210 	sub	x16, x16, #0x4
    40201534:	b100121f 	cmn	x16, #0x4
    40201538:	54ffff41 	b.ne	40201520 <jnox_kernel::ordinary_mutex_fifo::line+0x4c>  // b.any
    4020153c:	14000002 	b	40201544 <jnox_kernel::ordinary_mutex_fifo::line+0x70>
    40201540:	d5033fdf 	isb
    40201544:	b940010e 	ldr	w14, [x8]
    40201548:	372fffce 	tbnz	w14, #5, 40201540 <jnox_kernel::ordinary_mutex_fifo::line+0x6c>
    4020154c:	aa1f03ee 	mov	x14, xzr
    40201550:	b900012b 	str	w11, [x9]
    40201554:	386e698f 	ldrb	w15, [x12, x14]
    40201558:	b9400110 	ldr	w16, [x8]
    4020155c:	36280070 	tbz	w16, #5, 40201568 <jnox_kernel::ordinary_mutex_fifo::line+0x94>
    40201560:	d5033fdf 	isb
    40201564:	17fffffd 	b	40201558 <jnox_kernel::ordinary_mutex_fifo::line+0x84>
    40201568:	910005ce 	add	x14, x14, #0x1
    4020156c:	b900012f 	str	w15, [x9]
    40201570:	f10041df 	cmp	x14, #0x10
    40201574:	54ffff01 	b.ne	40201554 <jnox_kernel::ordinary_mutex_fifo::line+0x80>  // b.any
    40201578:	91002021 	add	x1, x1, #0x8
    4020157c:	eb0a003f 	cmp	x1, x10
    40201580:	54fffc81 	b.ne	40201510 <jnox_kernel::ordinary_mutex_fifo::line+0x3c>  // b.any
    40201584:	14000002 	b	4020158c <jnox_kernel::ordinary_mutex_fifo::line+0xb8>
    40201588:	d5033fdf 	isb
    4020158c:	b9400109 	ldr	w9, [x8]
    40201590:	372fffc9 	tbnz	w9, #5, 40201588 <jnox_kernel::ordinary_mutex_fifo::line+0xb4>
    40201594:	52a12008 	mov	w8, #0x9000000             	// #150994944
    40201598:	52800149 	mov	w9, #0xa                   	// #10
    4020159c:	b9000109 	str	w9, [x8]
    402015a0:	910043ff 	add	sp, sp, #0x10
    402015a4:	d65f03c0 	ret

00000000402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>:
    402015a8:	d10383ff 	sub	sp, sp, #0xe0
    402015ac:	a9087bfd 	stp	x29, x30, [sp, #128]
    402015b0:	a9096ffc 	stp	x28, x27, [sp, #144]
    402015b4:	a90a67fa 	stp	x26, x25, [sp, #160]
    402015b8:	a90b5ff8 	stp	x24, x23, [sp, #176]
    402015bc:	a90c57f6 	stp	x22, x21, [sp, #192]
    402015c0:	a90d4ff4 	stp	x20, x19, [sp, #208]
    402015c4:	aa1f03e8 	mov	x8, xzr
    402015c8:	52800315 	mov	w21, #0x18                  	// #24
    402015cc:	72a12015 	movk	w21, #0x900, lsl #16
    402015d0:	d5034fdf 	msr	daifset, #0xf
    402015d4:	52a12009 	mov	w9, #0x9000000             	// #150994944
    402015d8:	d503201f 	nop
    402015dc:	100153aa 	adr	x10, 40204050 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x100>
    402015e0:	3868694b 	ldrb	w11, [x10, x8]
    402015e4:	b94002ac 	ldr	w12, [x21]
    402015e8:	3628006c 	tbz	w12, #5, 402015f4 <jnox_kernel::ordinary_mutex_fifo::stop+0x4c>
    402015ec:	d5033fdf 	isb
    402015f0:	17fffffd 	b	402015e4 <jnox_kernel::ordinary_mutex_fifo::stop+0x3c>
    402015f4:	91000508 	add	x8, x8, #0x1
    402015f8:	b900012b 	str	w11, [x9]
    402015fc:	f1002d1f 	cmp	x8, #0xb
    40201600:	54ffff01 	b.ne	402015e0 <jnox_kernel::ordinary_mutex_fifo::stop+0x38>  // b.any
    40201604:	90000028 	adrp	x8, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201608:	f940a909 	ldr	x9, [x8, #336]
    4020160c:	f100a13f 	cmp	x9, #0x28
    40201610:	52800508 	mov	w8, #0x28                  	// #40
    40201614:	f90003e9 	str	x9, [sp]
    40201618:	9a883137 	csel	x23, x9, x8, cc  // cc = lo, ul, last
    4020161c:	b0000128 	adrp	x8, 40226000 <jnox_kernel::ordinary_mutex_fifo::JOURNAL+0xea0>
    40201620:	f9471909 	ldr	x9, [x8, #3632]
    40201624:	f101013f 	cmp	x9, #0x40
    40201628:	52800808 	mov	w8, #0x40                  	// #64
    4020162c:	a9025fe0 	stp	x0, x23, [sp, #32]
    40201630:	f90007e9 	str	x9, [sp, #8]
    40201634:	9a883136 	csel	x22, x9, x8, cc  // cc = lo, ul, last
    40201638:	f9001bf6 	str	x22, [sp, #48]
    4020163c:	d503201f 	nop
    40201640:	700150c0 	adr	x0, 4020405b <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x10b>
    40201644:	910083f3 	add	x19, sp, #0x20
    40201648:	910083e1 	add	x1, sp, #0x20
    4020164c:	52800062 	mov	w2, #0x3                   	// #3
    40201650:	97ffffa1 	bl	402014d4 <jnox_kernel::ordinary_mutex_fifo::line>
    40201654:	2a1f03e8 	mov	w8, wzr
    40201658:	91004279 	add	x25, x19, #0x10
    4020165c:	d503201f 	nop
    40201660:	10015049 	adr	x9, 40204068 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x118>
    40201664:	5280003d 	mov	w29, #0x1                   	// #1
    40201668:	a940292b 	ldp	x11, x10, [x9]
    4020166c:	a9012fea 	stp	x10, x11, [sp, #16]
    40201670:	a9415138 	ldp	x24, x20, [x9, #16]
    40201674:	d503201f 	nop
    40201678:	10015093 	adr	x19, 40204088 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x138>
    4020167c:	aa1f03fa 	mov	x26, xzr
    40201680:	2a0803fc 	mov	w28, w8
    40201684:	a94127e8 	ldp	x8, x9, [sp, #16]
    40201688:	a9002329 	stp	x9, x8, [x25]
    4020168c:	a9015338 	stp	x24, x20, [x25, #16]
    40201690:	d503201f 	nop
    40201694:	1001d668 	adr	x8, 40205160 <jnox_kernel::ordinary_mutex_fifo::STACKS>
    40201698:	8b1d4108 	add	x8, x8, x29, lsl #16
    4020169c:	d1404108 	sub	x8, x8, #0x10, lsl #12
    402016a0:	f9002bff 	str	xzr, [sp, #80]
    402016a4:	f87a7b29 	ldr	x9, [x25, x26, lsl #3]
    402016a8:	a905ebfd 	stp	x29, x26, [sp, #88]
    402016ac:	9100075a 	add	x26, x26, #0x1
    402016b0:	9140111b 	add	x27, x8, #0x4, lsl #12
    402016b4:	a906efe8 	stp	x8, x27, [sp, #104]
    402016b8:	f9003fe9 	str	x9, [sp, #120]
    402016bc:	910163e1 	add	x1, sp, #0x58
    402016c0:	aa1303e0 	mov	x0, x19
    402016c4:	528000a2 	mov	w2, #0x5                   	// #5
    402016c8:	97ffff83 	bl	402014d4 <jnox_kernel::ordinary_mutex_fifo::line>
    402016cc:	f100135f 	cmp	x26, #0x4
    402016d0:	aa1b03e8 	mov	x8, x27
    402016d4:	54fffe81 	b.ne	402016a4 <jnox_kernel::ordinary_mutex_fifo::stop+0xfc>  // b.any
    402016d8:	52800028 	mov	w8, #0x1                   	// #1
    402016dc:	5280005d 	mov	w29, #0x2                   	// #2
    402016e0:	3607fcfc 	tbz	w28, #0, 4020167c <jnox_kernel::ordinary_mutex_fifo::stop+0xd4>
    402016e4:	f94003e8 	ldr	x8, [sp]
    402016e8:	b4000188 	cbz	x8, 40201718 <jnox_kernel::ordinary_mutex_fifo::stop+0x170>
    402016ec:	d503201f 	nop
    402016f0:	1011d393 	adr	x19, 40225160 <jnox_kernel::ordinary_mutex_fifo::JOURNAL>
    402016f4:	d503201f 	nop
    402016f8:	50014b74 	adr	x20, 40204066 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x116>
    402016fc:	aa1403e0 	mov	x0, x20
    40201700:	aa1303e1 	mov	x1, x19
    40201704:	528002e2 	mov	w2, #0x17                  	// #23
    40201708:	97ffff73 	bl	402014d4 <jnox_kernel::ordinary_mutex_fifo::line>
    4020170c:	9102e273 	add	x19, x19, #0xb8
    40201710:	f10006f7 	subs	x23, x23, #0x1
    40201714:	54ffff41 	b.ne	402016fc <jnox_kernel::ordinary_mutex_fifo::stop+0x154>  // b.any
    40201718:	f94007e8 	ldr	x8, [sp, #8]
    4020171c:	b4000228 	cbz	x8, 40201760 <jnox_kernel::ordinary_mutex_fifo::stop+0x1b8>
    40201720:	b0000134 	adrp	x20, 40226000 <jnox_kernel::ordinary_mutex_fifo::JOURNAL+0xea0>
    40201724:	91392294 	add	x20, x20, #0xe48
    40201728:	52800037 	mov	w23, #0x1                   	// #1
    4020172c:	d503201f 	nop
    40201730:	300149b3 	adr	x19, 40204065 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x115>
    40201734:	a97f2688 	ldp	x8, x9, [x20, #-16]
    40201738:	a90223f7 	stp	x23, x8, [sp, #32]
    4020173c:	f8418688 	ldr	x8, [x20], #24
    40201740:	a90323e9 	stp	x9, x8, [sp, #48]
    40201744:	910083e1 	add	x1, sp, #0x20
    40201748:	aa1303e0 	mov	x0, x19
    4020174c:	52800082 	mov	w2, #0x4                   	// #4
    40201750:	97ffff61 	bl	402014d4 <jnox_kernel::ordinary_mutex_fifo::line>
    40201754:	f10006d6 	subs	x22, x22, #0x1
    40201758:	910006f7 	add	x23, x23, #0x1
    4020175c:	54fffec1 	b.ne	40201734 <jnox_kernel::ordinary_mutex_fifo::stop+0x18c>  // b.any
    40201760:	aa1f03e8 	mov	x8, xzr
    40201764:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40201768:	d503201f 	nop
    4020176c:	1001478a 	adr	x10, 4020405c <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x10c>
    40201770:	3868694b 	ldrb	w11, [x10, x8]
    40201774:	b94002ac 	ldr	w12, [x21]
    40201778:	3628006c 	tbz	w12, #5, 40201784 <jnox_kernel::ordinary_mutex_fifo::stop+0x1dc>
    4020177c:	d5033fdf 	isb
    40201780:	17fffffd 	b	40201774 <jnox_kernel::ordinary_mutex_fifo::stop+0x1cc>
    40201784:	91000508 	add	x8, x8, #0x1
    40201788:	b900012b 	str	w11, [x9]
    4020178c:	f100251f 	cmp	x8, #0x9
    40201790:	54ffff01 	b.ne	40201770 <jnox_kernel::ordinary_mutex_fifo::stop+0x1c8>  // b.any
    40201794:	d503205f 	wfe
    40201798:	17ffffff 	b	40201794 <jnox_kernel::ordinary_mutex_fifo::stop+0x1ec>

000000004020179c <jnox_kernel::ordinary_mutex_fifo::owner>:
    4020179c:	d100c3ff 	sub	sp, sp, #0x30
    402017a0:	f9000bfe 	str	x30, [sp, #16]
    402017a4:	a9024ff4 	stp	x20, x19, [sp, #32]
    402017a8:	52800028 	mov	w8, #0x1                   	// #1
    402017ac:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    402017b0:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    402017b4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    402017b8:	aa1f03e0 	mov	x0, xzr
    402017bc:	d4000001 	svc	#0x0
    402017c0:	b50003c0 	cbnz	x0, 40201838 <jnox_kernel::ordinary_mutex_fifo::owner+0x9c>
    402017c4:	f9000fff 	str	xzr, [sp, #24]
    402017c8:	52800088 	mov	w8, #0x4                   	// #4
    402017cc:	f90007e8 	str	x8, [sp, #8]
    402017d0:	f9400fe8 	ldr	x8, [sp, #24]
    402017d4:	d503201f 	nop
    402017d8:	1012b249 	adr	x9, 40226e20 <jnox_kernel::ordinary_mutex_fifo::PROTECTED>
    402017dc:	f9000128 	str	x8, [x9]
    402017e0:	f94007e8 	ldr	x8, [sp, #8]
    402017e4:	f9000528 	str	x8, [x9, #8]
    402017e8:	528000a8 	mov	w8, #0x5                   	// #5
    402017ec:	d4000001 	svc	#0x0
    402017f0:	b5000240 	cbnz	x0, 40201838 <jnox_kernel::ordinary_mutex_fifo::owner+0x9c>
    402017f4:	90000028 	adrp	x8, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    402017f8:	f9400108 	ldr	x8, [x8]
    402017fc:	f100091f 	cmp	x8, #0x2
    40201800:	54000200 	b.eq	40201840 <jnox_kernel::ordinary_mutex_fifo::owner+0xa4>  // b.none
    40201804:	90000028 	adrp	x8, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201808:	f9407513 	ldr	x19, [x8, #232]
    4020180c:	52800074 	mov	w20, #0x3                   	// #3
    40201810:	52800060 	mov	w0, #0x3                   	// #3
    40201814:	aa1303e1 	mov	x1, x19
    40201818:	9400016b 	bl	40201dc4 <jnox_kernel::ordinary_mutex_fifo::checked>
    4020181c:	cb130281 	sub	x1, x20, x19
    40201820:	52800060 	mov	w0, #0x3                   	// #3
    40201824:	94000168 	bl	40201dc4 <jnox_kernel::ordinary_mutex_fifo::checked>
    40201828:	52800040 	mov	w0, #0x2                   	// #2
    4020182c:	aa1f03e1 	mov	x1, xzr
    40201830:	94000165 	bl	40201dc4 <jnox_kernel::ordinary_mutex_fifo::checked>
    40201834:	97fffeee 	bl	402013ec <jnox_kernel::ordinary_mutex_fifo::exit>
    40201838:	52800020 	mov	w0, #0x1                   	// #1
    4020183c:	97ffff5b 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>
    40201840:	d503201f 	nop
    40201844:	10014260 	adr	x0, 40204090 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x140>
    40201848:	940005ef 	bl	40203004 <core::option::unwrap_failed>

000000004020184c <_ZN11jnox_kernel19ordinary_mutex_fifo5start17hc37bd2ad57dcb1c6E.llvm.4966675838875970461>:
    4020184c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    40201850:	a9014ff4 	stp	x20, x19, [sp, #16]
    40201854:	d10983ff 	sub	sp, sp, #0x260
    40201858:	aa0003f3 	mov	x19, x0
    4020185c:	aa1f03e8 	mov	x8, xzr
    40201860:	d5034fdf 	msr	daifset, #0xf
    40201864:	910063e9 	add	x9, sp, #0x18
    40201868:	8b08012a 	add	x10, x9, x8
    4020186c:	f900015f 	str	xzr, [x10]
    40201870:	f900095f 	str	xzr, [x10, #16]
    40201874:	91008108 	add	x8, x8, #0x20
    40201878:	f102011f 	cmp	x8, #0x80
    4020187c:	54ffff61 	b.ne	40201868 <_ZN11jnox_kernel19ordinary_mutex_fifo5start17hc37bd2ad57dcb1c6E.llvm.4966675838875970461+0x1c>  // b.any
    40201880:	aa1f03e8 	mov	x8, xzr
    40201884:	910883e9 	add	x9, sp, #0x220
    40201888:	f828693f 	str	xzr, [x9, x8]
    4020188c:	91004108 	add	x8, x8, #0x10
    40201890:	f101011f 	cmp	x8, #0x40
    40201894:	54ffffa1 	b.ne	40201888 <_ZN11jnox_kernel19ordinary_mutex_fifo5start17hc37bd2ad57dcb1c6E.llvm.4966675838875970461+0x3c>  // b.any
    40201898:	910583e8 	add	x8, sp, #0x160
    4020189c:	910063f4 	add	x20, sp, #0x18
    402018a0:	91002100 	add	x0, x8, #0x8
    402018a4:	910063e1 	add	x1, sp, #0x18
    402018a8:	52801002 	mov	w2, #0x80                  	// #128
    402018ac:	94000885 	bl	40203ac0 <memcpy>
    402018b0:	9103c280 	add	x0, x20, #0xf0
    402018b4:	2a1f03e1 	mov	w1, wzr
    402018b8:	52800902 	mov	w2, #0x48                  	// #72
    402018bc:	94000904 	bl	40203ccc <memset>
    402018c0:	f90083f3 	str	x19, [sp, #256]
    402018c4:	f9000fff 	str	xzr, [sp, #24]
    402018c8:	91002280 	add	x0, x20, #0x8
    402018cc:	910583e1 	add	x1, sp, #0x160
    402018d0:	52801102 	mov	w2, #0x88                  	// #136
    402018d4:	9400087b 	bl	40203ac0 <memcpy>
    402018d8:	91024280 	add	x0, x20, #0x90
    402018dc:	910883e1 	add	x1, sp, #0x220
    402018e0:	52800802 	mov	w2, #0x40                  	// #64
    402018e4:	94000877 	bl	40203ac0 <memcpy>
    402018e8:	528000e8 	mov	w8, #0x7                   	// #7
    402018ec:	7902b3ff 	strh	wzr, [sp, #344]
    402018f0:	5280e049 	mov	w9, #0x702                 	// #1794
    402018f4:	72a000e9 	movk	w9, #0x7, lsl #16
    402018f8:	5280006a 	mov	w10, #0x3                   	// #3
    402018fc:	d503201f 	nop
    40201900:	10013b4b 	adr	x11, 40204068 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x118>
    40201904:	a90f27ff 	stp	xzr, x9, [sp, #240]
    40201908:	f900abea 	str	x10, [sp, #336]
    4020190c:	d503201f 	nop
    40201910:	1001c289 	adr	x9, 40205160 <jnox_kernel::ordinary_mutex_fifo::STACKS>
    40201914:	a940316a 	ldp	x10, x12, [x11]
    40201918:	a91fb3ea 	stp	x10, x12, [sp, #504]
    4020191c:	a9412d6a 	ldp	x10, x11, [x11, #16]
    40201920:	9107a3ec 	add	x12, sp, #0x1e8
    40201924:	f90077e8 	str	x8, [sp, #232]
    40201928:	91004188 	add	x8, x12, #0x10
    4020192c:	8b134129 	add	x9, x9, x19, lsl #16
    40201930:	929867ec 	mov	x12, #0xffffffffffff3cc0    	// #-49984
    40201934:	f90107ea 	str	x10, [sp, #520]
    40201938:	f9010beb 	str	x11, [sp, #528]
    4020193c:	8b0c0129 	add	x9, x9, x12
    40201940:	5280046a 	mov	w10, #0x23                  	// #35
    40201944:	528068ab 	mov	w11, #0x345                 	// #837
    40201948:	f9010fff 	str	xzr, [sp, #536]
    4020194c:	f840850c 	ldr	x12, [x8], #8
    40201950:	d100894d 	sub	x13, x10, #0x22
    40201954:	a90fad2c 	stp	x12, x11, [x9, #248]
    40201958:	f9008d2d 	str	x13, [x9, #280]
    4020195c:	f82a7a89 	str	x9, [x20, x10, lsl #3]
    40201960:	9100054a 	add	x10, x10, #0x1
    40201964:	91401129 	add	x9, x9, #0x4, lsl #12
    40201968:	f1009d5f 	cmp	x10, #0x27
    4020196c:	54ffff01 	b.ne	4020194c <_ZN11jnox_kernel19ordinary_mutex_fifo5start17hc37bd2ad57dcb1c6E.llvm.4966675838875970461+0x100>  // b.any
    40201970:	a91effff 	stp	xzr, xzr, [sp, #488]
    40201974:	f940f7e8 	ldr	x8, [sp, #488]
    40201978:	d503201f 	nop
    4020197c:	1012a529 	adr	x9, 40226e20 <jnox_kernel::ordinary_mutex_fifo::PROTECTED>
    40201980:	f940fbea 	ldr	x10, [sp, #496]
    40201984:	f900052a 	str	x10, [x9, #8]
    40201988:	f9000128 	str	x8, [x9]
    4020198c:	910063e0 	add	x0, sp, #0x18
    40201990:	52800061 	mov	w1, #0x3                   	// #3
    40201994:	2a1f03e2 	mov	w2, wzr
    40201998:	940000e2 	bl	40201d20 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue>
    4020199c:	910063e0 	add	x0, sp, #0x18
    402019a0:	aa1f03e1 	mov	x1, xzr
    402019a4:	2a1f03e2 	mov	w2, wzr
    402019a8:	940000de 	bl	40201d20 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue>
    402019ac:	910063e0 	add	x0, sp, #0x18
    402019b0:	94000034 	bl	40201a80 <jnox_kernel::ordinary_mutex_fifo::Runtime::choose>
    402019b4:	aa0003f3 	mov	x19, x0
    402019b8:	92800008 	mov	x8, #0xffffffffffffffff    	// #-1
    402019bc:	a91f23e8 	stp	x8, x8, [sp, #496]
    402019c0:	f900f7e8 	str	x8, [sp, #488]
    402019c4:	9107a3e8 	add	x8, sp, #0x1e8
    402019c8:	910063e0 	add	x0, sp, #0x18
    402019cc:	f90007e8 	str	x8, [sp, #8]
    402019d0:	528000e1 	mov	w1, #0x7                   	// #7
    402019d4:	aa1f03e2 	mov	x2, xzr
    402019d8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    402019dc:	aa1f03e4 	mov	x4, xzr
    402019e0:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    402019e4:	aa1303e6 	mov	x6, x19
    402019e8:	aa1f03e7 	mov	x7, xzr
    402019ec:	9400004d 	bl	40201b20 <jnox_kernel::ordinary_mutex_fifo::Runtime::record>
    402019f0:	d503201f 	nop
    402019f4:	1001b060 	adr	x0, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    402019f8:	910063e1 	add	x1, sp, #0x18
    402019fc:	52802902 	mov	w2, #0x148                 	// #328
    40201a00:	94000830 	bl	40203ac0 <memcpy>
    40201a04:	aa1303e0 	mov	x0, x19
    40201a08:	97fffde9 	bl	402011ac <sched_start_frame>

0000000040201a0c <jnox_kernel::ordinary_mutex_fifo::worker>:
    40201a0c:	d10083ff 	sub	sp, sp, #0x20
    40201a10:	a9014ffe 	stp	x30, x19, [sp, #16]
    40201a14:	aa0003f3 	mov	x19, x0
    40201a18:	94000292 	bl	40202460 <fifo_worker_acquire>
    40201a1c:	b50002a0 	cbnz	x0, 40201a70 <jnox_kernel::ordinary_mutex_fifo::worker+0x64>
    40201a20:	d503201f 	nop
    40201a24:	10129fe8 	adr	x8, 40226e20 <jnox_kernel::ordinary_mutex_fifo::PROTECTED>
    40201a28:	f9400503 	ldr	x3, [x8, #8]
    40201a2c:	f9400102 	ldr	x2, [x8]
    40201a30:	91000449 	add	x9, x2, #0x1
    40201a34:	5280014a 	mov	w10, #0xa                   	// #10
    40201a38:	9b0a4c6a 	madd	x10, x3, x10, x19
    40201a3c:	a90027ea 	stp	x10, x9, [sp]
    40201a40:	f94007e9 	ldr	x9, [sp, #8]
    40201a44:	f9000109 	str	x9, [x8]
    40201a48:	f94003e9 	ldr	x9, [sp]
    40201a4c:	f9000509 	str	x9, [x8, #8]
    40201a50:	528000c8 	mov	w8, #0x6                   	// #6
    40201a54:	aa1f03e1 	mov	x1, xzr
    40201a58:	d4000001 	svc	#0x0
    40201a5c:	b50000e0 	cbnz	x0, 40201a78 <jnox_kernel::ordinary_mutex_fifo::worker+0x6c>
    40201a60:	52800040 	mov	w0, #0x2                   	// #2
    40201a64:	aa1f03e1 	mov	x1, xzr
    40201a68:	940000d7 	bl	40201dc4 <jnox_kernel::ordinary_mutex_fifo::checked>
    40201a6c:	97fffe60 	bl	402013ec <jnox_kernel::ordinary_mutex_fifo::exit>
    40201a70:	52800040 	mov	w0, #0x2                   	// #2
    40201a74:	97fffecd 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>
    40201a78:	52800020 	mov	w0, #0x1                   	// #1
    40201a7c:	97fffecb 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>

0000000040201a80 <jnox_kernel::ordinary_mutex_fifo::Runtime::choose>:
    40201a80:	a9bf4ffe 	stp	x30, x19, [sp, #-16]!
    40201a84:	aa0003f3 	mov	x19, x0
    40201a88:	9103c000 	add	x0, x0, #0xf0
    40201a8c:	aa1303e1 	mov	x1, x19
    40201a90:	9400033e 	bl	40202788 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest>
    40201a94:	36000340 	tbz	w0, #0, 40201afc <jnox_kernel::ordinary_mutex_fifo::Runtime::choose+0x7c>
    40201a98:	f9009e61 	str	x1, [x19, #312]
    40201a9c:	f1000c3f 	cmp	x1, #0x3
    40201aa0:	54000308 	b.hi	40201b00 <jnox_kernel::ordinary_mutex_fifo::Runtime::choose+0x80>  // b.pmore
    40201aa4:	8b010e68 	add	x8, x19, x1, lsl #3
    40201aa8:	f9408d00 	ldr	x0, [x8, #280]
    40201aac:	f9008d1f 	str	xzr, [x8, #280]
    40201ab0:	f2400c1f 	tst	x0, #0xf
    40201ab4:	54000201 	b.ne	40201af4 <jnox_kernel::ordinary_mutex_fifo::Runtime::choose+0x74>  // b.any
    40201ab8:	f9409e68 	ldr	x8, [x19, #312]
    40201abc:	f9407669 	ldr	x9, [x19, #232]
    40201ac0:	d503201f 	nop
    40201ac4:	1001b4ea 	adr	x10, 40205160 <jnox_kernel::ordinary_mutex_fifo::STACKS>
    40201ac8:	8b094149 	add	x9, x10, x9, lsl #16
    40201acc:	8b083928 	add	x8, x9, x8, lsl #14
    40201ad0:	d1404109 	sub	x9, x8, #0x10, lsl #12
    40201ad4:	eb00013f 	cmp	x9, x0
    40201ad8:	540000e8 	b.hi	40201af4 <jnox_kernel::ordinary_mutex_fifo::Runtime::choose+0x74>  // b.pmore
    40201adc:	929867e9 	mov	x9, #0xffffffffffff3cc0    	// #-49984
    40201ae0:	8b090108 	add	x8, x8, x9
    40201ae4:	eb00011f 	cmp	x8, x0
    40201ae8:	54000063 	b.cc	40201af4 <jnox_kernel::ordinary_mutex_fifo::Runtime::choose+0x74>  // b.lo, b.ul, b.last
    40201aec:	a8c14ffe 	ldp	x30, x19, [sp], #16
    40201af0:	d65f03c0 	ret
    40201af4:	52800080 	mov	w0, #0x4                   	// #4
    40201af8:	97fffeac 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>
    40201afc:	94000006 	bl	40201b14 <jnox_kernel::ordinary_mutex_fifo::Runtime::choose::{{closure}}>
    40201b00:	d503201f 	nop
    40201b04:	10012d22 	adr	x2, 402040a8 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x158>
    40201b08:	aa0103e0 	mov	x0, x1
    40201b0c:	52800081 	mov	w1, #0x4                   	// #4
    40201b10:	94000544 	bl	40203020 <core::panicking::panic_bounds_check>

0000000040201b14 <jnox_kernel::ordinary_mutex_fifo::Runtime::choose::{{closure}}>:
    40201b14:	f81f0ffe 	str	x30, [sp, #-16]!
    40201b18:	52800080 	mov	w0, #0x4                   	// #4
    40201b1c:	97fffea3 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>

0000000040201b20 <jnox_kernel::ordinary_mutex_fifo::Runtime::record>:
    40201b20:	d102c3ff 	sub	sp, sp, #0xb0
    40201b24:	a9057bfd 	stp	x29, x30, [sp, #80]
    40201b28:	a9066ffc 	stp	x28, x27, [sp, #96]
    40201b2c:	a90767fa 	stp	x26, x25, [sp, #112]
    40201b30:	a9085ff8 	stp	x24, x23, [sp, #128]
    40201b34:	a90957f6 	stp	x22, x21, [sp, #144]
    40201b38:	a90a4ff4 	stp	x20, x19, [sp, #160]
    40201b3c:	aa0103e8 	mov	x8, x1
    40201b40:	f9408801 	ldr	x1, [x0, #272]
    40201b44:	f100143f 	cmp	x1, #0x5
    40201b48:	54000de2 	b.cs	40201d04 <jnox_kernel::ordinary_mutex_fifo::Runtime::record+0x1e4>  // b.hs, b.nlast
    40201b4c:	aa0003f6 	mov	x22, x0
    40201b50:	aa0403f7 	mov	x23, x4
    40201b54:	a9018be8 	stp	x8, x2, [sp, #24]
    40201b58:	a9029fe3 	stp	x3, x7, [sp, #40]
    40201b5c:	a90397e6 	stp	x6, x5, [sp, #56]
    40201b60:	f9405ffb 	ldr	x27, [sp, #184]
    40201b64:	f9409c09 	ldr	x9, [x0, #312]
    40201b68:	52800028 	mov	w8, #0x1                   	// #1
    40201b6c:	f9000be9 	str	x9, [sp, #16]
    40201b70:	9ac9211c 	lsl	x28, x8, x9
    40201b74:	b4000121 	cbz	x1, 40201b98 <jnox_kernel::ordinary_mutex_fifo::Runtime::record+0x78>
    40201b78:	9103c2c8 	add	x8, x22, #0xf0
    40201b7c:	d37df029 	lsl	x9, x1, #3
    40201b80:	5280002a 	mov	w10, #0x1                   	// #1
    40201b84:	f840850b 	ldr	x11, [x8], #8
    40201b88:	9acb214b 	lsl	x11, x10, x11
    40201b8c:	aa1c017c 	orr	x28, x11, x28
    40201b90:	f1002129 	subs	x9, x9, #0x8
    40201b94:	54ffff81 	b.ne	40201b84 <jnox_kernel::ordinary_mutex_fifo::Runtime::record+0x64>  // b.any
    40201b98:	aa1f03f9 	mov	x25, xzr
    40201b9c:	aa1f03f5 	mov	x21, xzr
    40201ba0:	aa1f03f3 	mov	x19, xzr
    40201ba4:	aa1f03f4 	mov	x20, xzr
    40201ba8:	f9405be8 	ldr	x8, [sp, #176]
    40201bac:	f90007e8 	str	x8, [sp, #8]
    40201bb0:	910262da 	add	x26, x22, #0x98
    40201bb4:	52800038 	mov	w24, #0x1                   	// #1
    40201bb8:	910133fd 	add	x29, sp, #0x4c
    40201bbc:	f85f8348 	ldur	x8, [x26, #-8]
    40201bc0:	f100051f 	cmp	x8, #0x1
    40201bc4:	540000c1 	b.ne	40201bdc <jnox_kernel::ordinary_mutex_fifo::Runtime::record+0xbc>  // b.any
    40201bc8:	f9400348 	ldr	x8, [x26]
    40201bcc:	9ad42309 	lsl	x9, x24, x20
    40201bd0:	aa150129 	orr	x9, x9, x21
    40201bd4:	f100011f 	cmp	x8, #0x0
    40201bd8:	9a950135 	csel	x21, x9, x21, eq  // eq = none
    40201bdc:	aa1603e0 	mov	x0, x22
    40201be0:	97fffdb2 	bl	402012a8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17ha1954380307d5c31E.llvm.4966675838875970461>
    40201be4:	360008a0 	tbz	w0, #0, 40201cf8 <jnox_kernel::ordinary_mutex_fifo::Runtime::record+0x1d8>
    40201be8:	d348fc08 	lsr	x8, x0, #8
    40201bec:	b9004fe8 	str	w8, [sp, #76]
    40201bf0:	38746ba8 	ldrb	w8, [x29, x20]
    40201bf4:	91000694 	add	x20, x20, #0x1
    40201bf8:	9ad92108 	lsl	x8, x8, x25
    40201bfc:	91002339 	add	x25, x25, #0x8
    40201c00:	aa130113 	orr	x19, x8, x19
    40201c04:	9100435a 	add	x26, x26, #0x10
    40201c08:	f100129f 	cmp	x20, #0x4
    40201c0c:	54fffd81 	b.ne	40201bbc <jnox_kernel::ordinary_mutex_fifo::Runtime::record+0x9c>  // b.any
    40201c10:	90000028 	adrp	x8, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201c14:	f940a909 	ldr	x9, [x8, #336]
    40201c18:	f1009d3f 	cmp	x9, #0x27
    40201c1c:	540007e8 	b.hi	40201d18 <jnox_kernel::ordinary_mutex_fifo::Runtime::record+0x1f8>  // b.pmore
    40201c20:	b4000077 	cbz	x23, 40201c2c <jnox_kernel::ordinary_mutex_fifo::Runtime::record+0x10c>
    40201c24:	f9407eea 	ldr	x10, [x23, #248]
    40201c28:	14000003 	b	40201c34 <jnox_kernel::ordinary_mutex_fifo::Runtime::record+0x114>
    40201c2c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    40201c30:	9280000a 	mov	x10, #0xffffffffffffffff    	// #-1
    40201c34:	d503201f 	nop
    40201c38:	10128f4b 	adr	x11, 40226e20 <jnox_kernel::ordinary_mutex_fifo::PROTECTED>
    40201c3c:	9100052c 	add	x12, x9, #0x1
    40201c40:	5280170d 	mov	w13, #0xb8                  	// #184
    40201c44:	d503201f 	nop
    40201c48:	1011a8ce 	adr	x14, 40225160 <jnox_kernel::ordinary_mutex_fifo::JOURNAL>
    40201c4c:	f940056f 	ldr	x15, [x11, #8]
    40201c50:	f940016b 	ldr	x11, [x11]
    40201c54:	f94076d0 	ldr	x16, [x22, #232]
    40201c58:	f9401fe0 	ldr	x0, [sp, #56]
    40201c5c:	f9407c11 	ldr	x17, [x0, #248]
    40201c60:	f9400012 	ldr	x18, [x0]
    40201c64:	9b0d3929 	madd	x9, x9, x13, x14
    40201c68:	a9003130 	stp	x16, x12, [x9]
    40201c6c:	a941b7ee 	ldp	x14, x13, [sp, #24]
    40201c70:	a901352e 	stp	x14, x13, [x9, #16]
    40201c74:	f94017ee 	ldr	x14, [sp, #40]
    40201c78:	f9400bed 	ldr	x13, [sp, #16]
    40201c7c:	a902352e 	stp	x14, x13, [x9, #32]
    40201c80:	b94002cd 	ldr	w13, [x22]
    40201c84:	f94006ce 	ldr	x14, [x22, #8]
    40201c88:	710001bf 	cmp	w13, #0x0
    40201c8c:	a9032937 	stp	x23, x10, [x9, #48]
    40201c90:	da9f11ca 	csinv	x10, x14, xzr, ne  // ne = any
    40201c94:	394506cd 	ldrb	w13, [x22, #321]
    40201c98:	f9401bee 	ldr	x14, [sp, #48]
    40201c9c:	720001df 	tst	w14, #0x1
    40201ca0:	f94007ee 	ldr	x14, [sp, #8]
    40201ca4:	da9f11ce 	csinv	x14, x14, xzr, ne  // ne = any
    40201ca8:	a9044520 	stp	x0, x17, [x9, #64]
    40201cac:	a940c371 	ldp	x17, x16, [x27, #8]
    40201cb0:	f9400360 	ldr	x0, [x27]
    40201cb4:	a9057132 	stp	x18, x28, [x9, #80]
    40201cb8:	a9064d35 	stp	x21, x19, [x9, #96]
    40201cbc:	a907352a 	stp	x10, x13, [x9, #112]
    40201cc0:	a9082d2e 	stp	x14, x11, [x9, #128]
    40201cc4:	f94023ea 	ldr	x10, [sp, #64]
    40201cc8:	a909292f 	stp	x15, x10, [x9, #144]
    40201ccc:	a90a4520 	stp	x0, x17, [x9, #160]
    40201cd0:	f9005930 	str	x16, [x9, #176]
    40201cd4:	f900a90c 	str	x12, [x8, #336]
    40201cd8:	a94a4ff4 	ldp	x20, x19, [sp, #160]
    40201cdc:	a94957f6 	ldp	x22, x21, [sp, #144]
    40201ce0:	a9485ff8 	ldp	x24, x23, [sp, #128]
    40201ce4:	a94767fa 	ldp	x26, x25, [sp, #112]
    40201ce8:	a9466ffc 	ldp	x28, x27, [sp, #96]
    40201cec:	a9457bfd 	ldp	x29, x30, [sp, #80]
    40201cf0:	9102c3ff 	add	sp, sp, #0xb0
    40201cf4:	d65f03c0 	ret
    40201cf8:	d503201f 	nop
    40201cfc:	10011e20 	adr	x0, 402040c0 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x170>
    40201d00:	940004c1 	bl	40203004 <core::option::unwrap_failed>
    40201d04:	d503201f 	nop
    40201d08:	10012643 	adr	x3, 402041d0 <anon.6df75e256c2768ac659efecb48cbbb77.7.llvm.9204665349642594691>
    40201d0c:	aa1f03e0 	mov	x0, xzr
    40201d10:	52800082 	mov	w2, #0x4                   	// #4
    40201d14:	940006c7 	bl	40203830 <core::slice::index::slice_index_fail>
    40201d18:	528000a0 	mov	w0, #0x5                   	// #5
    40201d1c:	97fffe23 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>

0000000040201d20 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue>:
    40201d20:	f81f0ffe 	str	x30, [sp, #-16]!
    40201d24:	39450408 	ldrb	w8, [x0, #321]
    40201d28:	12000829 	and	w9, w1, #0x7
    40201d2c:	1ac92508 	lsr	w8, w8, w9
    40201d30:	37000348 	tbnz	w8, #0, 40201d98 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue+0x78>
    40201d34:	f1000c3f 	cmp	x1, #0x3
    40201d38:	540003c8 	b.hi	40201db0 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue+0x90>  // b.pmore
    40201d3c:	8b011008 	add	x8, x0, x1, lsl #4
    40201d40:	f9404908 	ldr	x8, [x8, #144]
    40201d44:	b50002a8 	cbnz	x8, 40201d98 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue+0x78>
    40201d48:	8b010c08 	add	x8, x0, x1, lsl #3
    40201d4c:	f9408d08 	ldr	x8, [x8, #280]
    40201d50:	f2400d1f 	tst	x8, #0xf
    40201d54:	54000221 	b.ne	40201d98 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue+0x78>  // b.any
    40201d58:	f9407409 	ldr	x9, [x0, #232]
    40201d5c:	d503201f 	nop
    40201d60:	1001a00a 	adr	x10, 40205160 <jnox_kernel::ordinary_mutex_fifo::STACKS>
    40201d64:	8b094149 	add	x9, x10, x9, lsl #16
    40201d68:	8b013929 	add	x9, x9, x1, lsl #14
    40201d6c:	d140412a 	sub	x10, x9, #0x10, lsl #12
    40201d70:	eb08015f 	cmp	x10, x8
    40201d74:	54000128 	b.hi	40201d98 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue+0x78>  // b.pmore
    40201d78:	929867ea 	mov	x10, #0xffffffffffff3cc0    	// #-49984
    40201d7c:	8b0a0129 	add	x9, x9, x10
    40201d80:	eb08013f 	cmp	x9, x8
    40201d84:	540000a3 	b.cc	40201d98 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue+0x78>  // b.lo, b.ul, b.last
    40201d88:	9103c000 	add	x0, x0, #0xf0
    40201d8c:	360000a2 	tbz	w2, #0, 40201da0 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue+0x80>
    40201d90:	9400024e 	bl	402026c8 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front>
    40201d94:	370000a0 	tbnz	w0, #0, 40201da8 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue+0x88>
    40201d98:	52800080 	mov	w0, #0x4                   	// #4
    40201d9c:	97fffe03 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>
    40201da0:	940002cc 	bl	402028d0 <jnox_kernel::ready_queue::ReadyQueue<_>::push_back>
    40201da4:	34ffffa0 	cbz	w0, 40201d98 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue+0x78>
    40201da8:	f84107fe 	ldr	x30, [sp], #16
    40201dac:	d65f03c0 	ret
    40201db0:	d503201f 	nop
    40201db4:	10011922 	adr	x2, 402040d8 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x188>
    40201db8:	aa0103e0 	mov	x0, x1
    40201dbc:	52800081 	mov	w1, #0x4                   	// #4
    40201dc0:	94000498 	bl	40203020 <core::panicking::panic_bounds_check>

0000000040201dc4 <jnox_kernel::ordinary_mutex_fifo::checked>:
    40201dc4:	aa0103e9 	mov	x9, x1
    40201dc8:	aa0003e8 	mov	x8, x0
    40201dcc:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    40201dd0:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201dd4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    40201dd8:	aa0903e0 	mov	x0, x9
    40201ddc:	d4000001 	svc	#0x0
    40201de0:	b5000040 	cbnz	x0, 40201de8 <jnox_kernel::ordinary_mutex_fifo::checked+0x24>
    40201de4:	d65f03c0 	ret
    40201de8:	f81f0ffe 	str	x30, [sp, #-16]!
    40201dec:	52800020 	mov	w0, #0x1                   	// #1
    40201df0:	97fffdee 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>

0000000040201df4 <jnox_kernel::ordinary_mutex_fifo::request>:
    40201df4:	d10243ff 	sub	sp, sp, #0x90
    40201df8:	f9001bfe 	str	x30, [sp, #48]
    40201dfc:	a9046ffc 	stp	x28, x27, [sp, #64]
    40201e00:	a90567fa 	stp	x26, x25, [sp, #80]
    40201e04:	a9065ff8 	stp	x24, x23, [sp, #96]
    40201e08:	a90757f6 	stp	x22, x21, [sp, #112]
    40201e0c:	a9084ff4 	stp	x20, x19, [sp, #128]
    40201e10:	d5385208 	mrs	x8, esr_el1
    40201e14:	9266d508 	and	x8, x8, #0xfffffffffc00ffff
    40201e18:	52aa8009 	mov	w9, #0x54000000            	// #1409286144
    40201e1c:	eb09011f 	cmp	x8, x9
    40201e20:	54002c81 	b.ne	402023b0 <jnox_kernel::ordinary_mutex_fifo::request+0x5bc>  // b.any
    40201e24:	9000003b 	adrp	x27, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201e28:	f9400368 	ldr	x8, [x27]
    40201e2c:	f100091f 	cmp	x8, #0x2
    40201e30:	540029a0 	b.eq	40202364 <jnox_kernel::ordinary_mutex_fifo::request+0x570>  // b.none
    40201e34:	aa0003f3 	mov	x19, x0
    40201e38:	f2400c1f 	tst	x0, #0xf
    40201e3c:	54002a41 	b.ne	40202384 <jnox_kernel::ordinary_mutex_fifo::request+0x590>  // b.any
    40201e40:	90000029 	adrp	x9, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201e44:	f9409d34 	ldr	x20, [x9, #312]
    40201e48:	90000039 	adrp	x25, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201e4c:	f9407729 	ldr	x9, [x25, #232]
    40201e50:	d503201f 	nop
    40201e54:	1001987a 	adr	x26, 40205160 <jnox_kernel::ordinary_mutex_fifo::STACKS>
    40201e58:	8b094349 	add	x9, x26, x9, lsl #16
    40201e5c:	8b143929 	add	x9, x9, x20, lsl #14
    40201e60:	d140412a 	sub	x10, x9, #0x10, lsl #12
    40201e64:	929867eb 	mov	x11, #0xffffffffffff3cc0    	// #-49984
    40201e68:	8b0b0129 	add	x9, x9, x11
    40201e6c:	eb13015f 	cmp	x10, x19
    40201e70:	fa539120 	ccmp	x9, x19, #0x0, ls  // ls = plast
    40201e74:	54002883 	b.cc	40202384 <jnox_kernel::ordinary_mutex_fifo::request+0x590>  // b.lo, b.ul, b.last
    40201e78:	f100129f 	cmp	x20, #0x4
    40201e7c:	540029e2 	b.cs	402023b8 <jnox_kernel::ordinary_mutex_fifo::request+0x5c4>  // b.hs, b.nlast
    40201e80:	d503201f 	nop
    40201e84:	10018bf7 	adr	x23, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201e88:	8b140ee9 	add	x9, x23, x20, lsl #3
    40201e8c:	f9408d2a 	ldr	x10, [x9, #280]
    40201e90:	b50027aa 	cbnz	x10, 40202384 <jnox_kernel::ordinary_mutex_fifo::request+0x590>
    40201e94:	f9408e6a 	ldr	x10, [x19, #280]
    40201e98:	9100068b 	add	x11, x20, #0x1
    40201e9c:	eb0b015f 	cmp	x10, x11
    40201ea0:	54002721 	b.ne	40202384 <jnox_kernel::ordinary_mutex_fifo::request+0x590>  // b.any
    40201ea4:	f9008d33 	str	x19, [x9, #280]
    40201ea8:	f9402276 	ldr	x22, [x19, #64]
    40201eac:	f9400275 	ldr	x21, [x19]
    40201eb0:	92800009 	mov	x9, #0xffffffffffffffff    	// #-1
    40201eb4:	a901a7e9 	stp	x9, x9, [sp, #24]
    40201eb8:	f90017e9 	str	x9, [sp, #40]
    40201ebc:	f1000edf 	cmp	x22, #0x3
    40201ec0:	5400040c 	b.gt	40201f40 <jnox_kernel::ordinary_mutex_fifo::request+0x14c>
    40201ec4:	f10006df 	cmp	x22, #0x1
    40201ec8:	540010e0 	b.eq	402020e4 <jnox_kernel::ordinary_mutex_fifo::request+0x2f0>  // b.none
    40201ecc:	f1000adf 	cmp	x22, #0x2
    40201ed0:	540005a0 	b.eq	40201f84 <jnox_kernel::ordinary_mutex_fifo::request+0x190>  // b.none
    40201ed4:	f1000edf 	cmp	x22, #0x3
    40201ed8:	54002681 	b.ne	402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>  // b.any
    40201edc:	b5002674 	cbnz	x20, 402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>
    40201ee0:	d10006a9 	sub	x9, x21, #0x1
    40201ee4:	f100093f 	cmp	x9, #0x2
    40201ee8:	54002602 	b.cs	402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>  // b.hs, b.nlast
    40201eec:	b40025e8 	cbz	x8, 402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>
    40201ef0:	90000029 	adrp	x9, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201ef4:	91002129 	add	x9, x9, #0x8
    40201ef8:	3944e128 	ldrb	w8, [x9, #312]
    40201efc:	5280002a 	mov	w10, #0x1                   	// #1
    40201f00:	1ad5214a 	lsl	w10, w10, w21
    40201f04:	0a0a010b 	and	w11, w8, w10
    40201f08:	3500250b 	cbnz	w11, 402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>
    40201f0c:	f9400129 	ldr	x9, [x9]
    40201f10:	b50024c9 	cbnz	x9, 402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>
    40201f14:	2a0a0108 	orr	w8, w8, w10
    40201f18:	390502e8 	strb	w8, [x23, #320]
    40201f1c:	aa1703e0 	mov	x0, x23
    40201f20:	aa1503e1 	mov	x1, x21
    40201f24:	2a1f03e2 	mov	w2, wzr
    40201f28:	97ffff7e 	bl	40201d20 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue>
    40201f2c:	f900027f 	str	xzr, [x19]
    40201f30:	aa1703e0 	mov	x0, x23
    40201f34:	aa1f03e1 	mov	x1, xzr
    40201f38:	2a1f03e2 	mov	w2, wzr
    40201f3c:	14000067 	b	402020d8 <jnox_kernel::ordinary_mutex_fifo::request+0x2e4>
    40201f40:	f10012df 	cmp	x22, #0x4
    40201f44:	54000e60 	b.eq	40202110 <jnox_kernel::ordinary_mutex_fifo::request+0x31c>  // b.none
    40201f48:	f10016df 	cmp	x22, #0x5
    40201f4c:	54000b00 	b.eq	402020ac <jnox_kernel::ordinary_mutex_fifo::request+0x2b8>  // b.none
    40201f50:	f1001adf 	cmp	x22, #0x6
    40201f54:	540022a1 	b.ne	402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>  // b.any
    40201f58:	f100051f 	cmp	x8, #0x1
    40201f5c:	54002261 	b.ne	402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>  // b.any
    40201f60:	90000028 	adrp	x8, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201f64:	f9400508 	ldr	x8, [x8, #8]
    40201f68:	eb14011f 	cmp	x8, x20
    40201f6c:	540021e1 	b.ne	402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>  // b.any
    40201f70:	a940a668 	ldp	x8, x9, [x19, #8]
    40201f74:	a901a7e8 	stp	x8, x9, [sp, #24]
    40201f78:	f9400e68 	ldr	x8, [x19, #24]
    40201f7c:	f90017e8 	str	x8, [sp, #40]
    40201f80:	14000051 	b	402020c4 <jnox_kernel::ordinary_mutex_fifo::request+0x2d0>
    40201f84:	b5002135 	cbnz	x21, 402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>
    40201f88:	b4000c08 	cbz	x8, 40202108 <jnox_kernel::ordinary_mutex_fifo::request+0x314>
    40201f8c:	90000028 	adrp	x8, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201f90:	f9400508 	ldr	x8, [x8, #8]
    40201f94:	eb14011f 	cmp	x8, x20
    40201f98:	54000b81 	b.ne	40202108 <jnox_kernel::ordinary_mutex_fifo::request+0x314>  // b.any
    40201f9c:	8b1412e8 	add	x8, x23, x20, lsl #4
    40201fa0:	f9404908 	ldr	x8, [x8, #144]
    40201fa4:	b5000b28 	cbnz	x8, 40202108 <jnox_kernel::ordinary_mutex_fifo::request+0x314>
    40201fa8:	8b1416e8 	add	x8, x23, x20, lsl #5
    40201fac:	9100e11c 	add	x28, x8, #0x38
    40201fb0:	928003e8 	mov	x8, #0xffffffffffffffe0    	// #-32
    40201fb4:	b4000aa8 	cbz	x8, 40202108 <jnox_kernel::ordinary_mutex_fifo::request+0x314>
    40201fb8:	f85e8389 	ldur	x9, [x28, #-24]
    40201fbc:	d100439c 	sub	x28, x28, #0x10
    40201fc0:	91004108 	add	x8, x8, #0x10
    40201fc4:	b4ffff89 	cbz	x9, 40201fb4 <jnox_kernel::ordinary_mutex_fifo::request+0x1c0>
    40201fc8:	f85f8388 	ldur	x8, [x28, #-8]
    40201fcc:	b40009e8 	cbz	x8, 40202108 <jnox_kernel::ordinary_mutex_fifo::request+0x314>
    40201fd0:	f9400388 	ldr	x8, [x28]
    40201fd4:	b50009a8 	cbnz	x8, 40202108 <jnox_kernel::ordinary_mutex_fifo::request+0x314>
    40201fd8:	d503201f 	nop
    40201fdc:	10018138 	adr	x24, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201fe0:	aa1803e0 	mov	x0, x24
    40201fe4:	97fffcb1 	bl	402012a8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17ha1954380307d5c31E.llvm.4966675838875970461>
    40201fe8:	36000900 	tbz	w0, #0, 40202108 <jnox_kernel::ordinary_mutex_fifo::request+0x314>
    40201fec:	d348fc08 	lsr	x8, x0, #8
    40201ff0:	b9003fe8 	str	w8, [sp, #60]
    40201ff4:	90000028 	adrp	x8, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40201ff8:	f9406d01 	ldr	x1, [x8, #216]
    40201ffc:	f100143f 	cmp	x1, #0x5
    40202000:	54001b82 	b.cs	40202370 <jnox_kernel::ordinary_mutex_fifo::request+0x57c>  // b.hs, b.nlast
    40202004:	b4001141 	cbz	x1, 4020222c <jnox_kernel::ordinary_mutex_fifo::request+0x438>
    40202008:	aa1f03eb 	mov	x11, xzr
    4020200c:	aa1f03e9 	mov	x9, xzr
    40202010:	9100f3ea 	add	x10, sp, #0x3c
    40202014:	8b090308 	add	x8, x24, x9
    40202018:	39439108 	ldrb	w8, [x8, #228]
    4020201c:	f100111f 	cmp	x8, #0x4
    40202020:	54001b62 	b.cs	4020238c <jnox_kernel::ordinary_mutex_fifo::request+0x598>  // b.hs, b.nlast
    40202024:	8b08130c 	add	x12, x24, x8, lsl #4
    40202028:	f8490d8d 	ldr	x13, [x12, #144]!
    4020202c:	f10005bf 	cmp	x13, #0x1
    40202030:	54000221 	b.ne	40202074 <jnox_kernel::ordinary_mutex_fifo::request+0x280>  // b.any
    40202034:	f940058c 	ldr	x12, [x12, #8]
    40202038:	b50001ec 	cbnz	x12, 40202074 <jnox_kernel::ordinary_mutex_fifo::request+0x280>
    4020203c:	f100057f 	cmp	x11, #0x1
    40202040:	54000141 	b.ne	40202068 <jnox_kernel::ordinary_mutex_fifo::request+0x274>  // b.any
    40202044:	f10012ff 	cmp	x23, #0x4
    40202048:	54001c82 	b.cs	402023d8 <jnox_kernel::ordinary_mutex_fifo::request+0x5e4>  // b.hs, b.nlast
    4020204c:	3868694b 	ldrb	w11, [x10, x8]
    40202050:	3877694c 	ldrb	w12, [x10, x23]
    40202054:	6b0c017f 	cmp	w11, w12
    40202058:	9a808120 	csel	x0, x9, x0, hi  // hi = pmore
    4020205c:	9a978117 	csel	x23, x8, x23, hi  // hi = pmore
    40202060:	5280002b 	mov	w11, #0x1                   	// #1
    40202064:	14000004 	b	40202074 <jnox_kernel::ordinary_mutex_fifo::request+0x280>
    40202068:	5280002b 	mov	w11, #0x1                   	// #1
    4020206c:	aa0903e0 	mov	x0, x9
    40202070:	aa0803f7 	mov	x23, x8
    40202074:	91000529 	add	x9, x9, #0x1
    40202078:	eb09003f 	cmp	x1, x9
    4020207c:	54fffcc1 	b.ne	40202014 <jnox_kernel::ordinary_mutex_fifo::request+0x220>  // b.any
    40202080:	f100057f 	cmp	x11, #0x1
    40202084:	54000d41 	b.ne	4020222c <jnox_kernel::ordinary_mutex_fifo::request+0x438>  // b.any
    40202088:	8b171708 	add	x8, x24, x23, lsl #5
    4020208c:	91004108 	add	x8, x8, #0x10
    40202090:	52800409 	mov	w9, #0x20                  	// #32
    40202094:	f940010a 	ldr	x10, [x8]
    40202098:	b4000eea 	cbz	x10, 40202274 <jnox_kernel::ordinary_mutex_fifo::request+0x480>
    4020209c:	91004108 	add	x8, x8, #0x10
    402020a0:	f1004129 	subs	x9, x9, #0x10
    402020a4:	54000320 	b.eq	40202108 <jnox_kernel::ordinary_mutex_fifo::request+0x314>  // b.none
    402020a8:	17fffffb 	b	40202094 <jnox_kernel::ordinary_mutex_fifo::request+0x2a0>
    402020ac:	f100051f 	cmp	x8, #0x1
    402020b0:	540017c1 	b.ne	402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>  // b.any
    402020b4:	f0000008 	adrp	x8, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    402020b8:	f9400508 	ldr	x8, [x8, #8]
    402020bc:	eb14011f 	cmp	x8, x20
    402020c0:	54001741 	b.ne	402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>  // b.any
    402020c4:	f900027f 	str	xzr, [x19]
    402020c8:	d503201f 	nop
    402020cc:	100179a0 	adr	x0, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    402020d0:	aa1403e1 	mov	x1, x20
    402020d4:	52800022 	mov	w2, #0x1                   	// #1
    402020d8:	97ffff12 	bl	40201d20 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue>
    402020dc:	aa1f03f8 	mov	x24, xzr
    402020e0:	1400001a 	b	40202148 <jnox_kernel::ordinary_mutex_fifo::request+0x354>
    402020e4:	b5001635 	cbnz	x21, 402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>
    402020e8:	8b1416e9 	add	x9, x23, x20, lsl #5
    402020ec:	9100412a 	add	x10, x9, #0x10
    402020f0:	52800409 	mov	w9, #0x20                  	// #32
    402020f4:	f940014b 	ldr	x11, [x10]
    402020f8:	b40005ab 	cbz	x11, 402021ac <jnox_kernel::ordinary_mutex_fifo::request+0x3b8>
    402020fc:	9100414a 	add	x10, x10, #0x10
    40202100:	f1004129 	subs	x9, x9, #0x10
    40202104:	54ffff81 	b.ne	402020f4 <jnox_kernel::ordinary_mutex_fifo::request+0x300>  // b.any
    40202108:	528000e0 	mov	w0, #0x7                   	// #7
    4020210c:	97fffd27 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>
    40202110:	f1000e9f 	cmp	x20, #0x3
    40202114:	540014a0 	b.eq	402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>  // b.none
    40202118:	b40000a8 	cbz	x8, 4020212c <jnox_kernel::ordinary_mutex_fifo::request+0x338>
    4020211c:	f0000008 	adrp	x8, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40202120:	f9400508 	ldr	x8, [x8, #8]
    40202124:	eb14011f 	cmp	x8, x20
    40202128:	54001400 	b.eq	402023a8 <jnox_kernel::ordinary_mutex_fifo::request+0x5b4>  // b.none
    4020212c:	aa1f03f8 	mov	x24, xzr
    40202130:	52800028 	mov	w8, #0x1                   	// #1
    40202134:	1ad42108 	lsl	w8, w8, w20
    40202138:	f0000009 	adrp	x9, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    4020213c:	3945052a 	ldrb	w10, [x9, #321]
    40202140:	2a080148 	orr	w8, w10, w8
    40202144:	39050528 	strb	w8, [x9, #321]
    40202148:	d503201f 	nop
    4020214c:	100175b9 	adr	x25, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40202150:	aa1903e0 	mov	x0, x25
    40202154:	97fffe4b 	bl	40201a80 <jnox_kernel::ordinary_mutex_fifo::Runtime::choose>
    40202158:	aa0003fa 	mov	x26, x0
    4020215c:	910063e8 	add	x8, sp, #0x18
    40202160:	a90023f7 	stp	x23, x8, [sp]
    40202164:	aa1903e0 	mov	x0, x25
    40202168:	aa1603e1 	mov	x1, x22
    4020216c:	aa1503e2 	mov	x2, x21
    40202170:	aa1403e3 	mov	x3, x20
    40202174:	aa1303e4 	mov	x4, x19
    40202178:	aa1503e5 	mov	x5, x21
    4020217c:	aa1a03e6 	mov	x6, x26
    40202180:	aa1803e7 	mov	x7, x24
    40202184:	97fffe67 	bl	40201b20 <jnox_kernel::ordinary_mutex_fifo::Runtime::record>
    40202188:	aa1a03e0 	mov	x0, x26
    4020218c:	a9484ff4 	ldp	x20, x19, [sp, #128]
    40202190:	a94757f6 	ldp	x22, x21, [sp, #112]
    40202194:	a9465ff8 	ldp	x24, x23, [sp, #96]
    40202198:	a94567fa 	ldp	x26, x25, [sp, #80]
    4020219c:	a9446ffc 	ldp	x28, x27, [sp, #64]
    402021a0:	f9401bfe 	ldr	x30, [sp, #48]
    402021a4:	910243ff 	add	sp, sp, #0x90
    402021a8:	d65f03c0 	ret
    402021ac:	f0000009 	adrp	x9, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    402021b0:	b940d129 	ldr	w9, [x9, #208]
    402021b4:	1ad42529 	lsr	w9, w9, w20
    402021b8:	3607fa89 	tbz	w9, #0, 40202108 <jnox_kernel::ordinary_mutex_fifo::request+0x314>
    402021bc:	8b1412e9 	add	x9, x23, x20, lsl #4
    402021c0:	f8490d2b 	ldr	x11, [x9, #144]!
    402021c4:	b5fffa2b 	cbnz	x11, 40202108 <jnox_kernel::ordinary_mutex_fifo::request+0x314>
    402021c8:	f100051f 	cmp	x8, #0x1
    402021cc:	54000381 	b.ne	4020223c <jnox_kernel::ordinary_mutex_fifo::request+0x448>  // b.any
    402021d0:	f0000008 	adrp	x8, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    402021d4:	f9406d0a 	ldr	x10, [x8, #216]
    402021d8:	f1000d5f 	cmp	x10, #0x3
    402021dc:	54fff968 	b.hi	40202108 <jnox_kernel::ordinary_mutex_fifo::request+0x314>  // b.pmore
    402021e0:	f94006e0 	ldr	x0, [x23, #8]
    402021e4:	8b0012eb 	add	x11, x23, x0, lsl #4
    402021e8:	528000ac 	mov	w12, #0x5                   	// #5
    402021ec:	f100058c 	subs	x12, x12, #0x1
    402021f0:	54fff8c0 	b.eq	40202108 <jnox_kernel::ordinary_mutex_fifo::request+0x314>  // b.none
    402021f4:	eb14001f 	cmp	x0, x20
    402021f8:	54fff880 	b.eq	40202108 <jnox_kernel::ordinary_mutex_fifo::request+0x314>  // b.none
    402021fc:	f1000c1f 	cmp	x0, #0x3
    40202200:	54000ce8 	b.hi	4020239c <jnox_kernel::ordinary_mutex_fifo::request+0x5a8>  // b.pmore
    40202204:	f8490168 	ldur	x8, [x11, #144]
    40202208:	f100051f 	cmp	x8, #0x1
    4020220c:	54000241 	b.ne	40202254 <jnox_kernel::ordinary_mutex_fifo::request+0x460>  // b.any
    40202210:	f8498168 	ldur	x8, [x11, #152]
    40202214:	b4fffec8 	cbz	x8, 402021ec <jnox_kernel::ordinary_mutex_fifo::request+0x3f8>
    40202218:	d503201f 	nop
    4020221c:	1000ed62 	adr	x2, 40203fc8 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x78>
    40202220:	aa0803e0 	mov	x0, x8
    40202224:	52800021 	mov	w1, #0x1                   	// #1
    40202228:	9400037e 	bl	40203020 <core::panicking::panic_bounds_check>
    4020222c:	aa1f03f8 	mov	x24, xzr
    40202230:	f81f839f 	stur	xzr, [x28, #-8]
    40202234:	f900037f 	str	xzr, [x27]
    40202238:	14000044 	b	40202348 <jnox_kernel::ordinary_mutex_fifo::request+0x554>
    4020223c:	52800028 	mov	w8, #0x1                   	// #1
    40202240:	a9007d48 	stp	x8, xzr, [x10]
    40202244:	a90052e8 	stp	x8, x20, [x23]
    40202248:	f900027f 	str	xzr, [x19]
    4020224c:	aa1703e0 	mov	x0, x23
    40202250:	17ffffa0 	b	402020d0 <jnox_kernel::ordinary_mutex_fifo::request+0x2dc>
    40202254:	aa1f03f8 	mov	x24, xzr
    40202258:	8b0a02e8 	add	x8, x23, x10
    4020225c:	39039114 	strb	w20, [x8, #228]
    40202260:	91000548 	add	x8, x10, #0x1
    40202264:	f9006ee8 	str	x8, [x23, #216]
    40202268:	52800028 	mov	w8, #0x1                   	// #1
    4020226c:	a9007d28 	stp	x8, xzr, [x9]
    40202270:	17ffffb6 	b	40202148 <jnox_kernel::ordinary_mutex_fifo::request+0x354>
    40202274:	52800029 	mov	w9, #0x1                   	// #1
    40202278:	a9007d09 	stp	x9, xzr, [x8]
    4020227c:	f1000c1f 	cmp	x0, #0x3
    40202280:	54000b68 	b.hi	402023ec <jnox_kernel::ordinary_mutex_fifo::request+0x5f8>  // b.pmore
    40202284:	8b000308 	add	x8, x24, x0
    40202288:	39439108 	ldrb	w8, [x8, #228]
    4020228c:	f100111f 	cmp	x8, #0x4
    40202290:	54000b42 	b.cs	402023f8 <jnox_kernel::ordinary_mutex_fifo::request+0x604>  // b.hs, b.nlast
    40202294:	8b081308 	add	x8, x24, x8, lsl #4
    40202298:	f900491f 	str	xzr, [x8, #144]
    4020229c:	f9406f0a 	ldr	x10, [x24, #216]
    402022a0:	d1000548 	sub	x8, x10, #0x1
    402022a4:	f9006f08 	str	x8, [x24, #216]
    402022a8:	eb08001f 	cmp	x0, x8
    402022ac:	540001a2 	b.cs	402022e0 <jnox_kernel::ordinary_mutex_fifo::request+0x4ec>  // b.hs, b.nlast
    402022b0:	8b000308 	add	x8, x24, x0
    402022b4:	91039509 	add	x9, x8, #0xe5
    402022b8:	aa2003e8 	mvn	x8, x0
    402022bc:	cb0a03ea 	neg	x10, x10
    402022c0:	b100111f 	cmn	x8, #0x4
    402022c4:	54000820 	b.eq	402023c8 <jnox_kernel::ordinary_mutex_fifo::request+0x5d4>  // b.none
    402022c8:	3940012b 	ldrb	w11, [x9]
    402022cc:	381ff12b 	sturb	w11, [x9, #-1]
    402022d0:	91000529 	add	x9, x9, #0x1
    402022d4:	d1000508 	sub	x8, x8, #0x1
    402022d8:	eb08015f 	cmp	x10, x8
    402022dc:	54ffff21 	b.ne	402022c0 <jnox_kernel::ordinary_mutex_fifo::request+0x4cc>  // b.any
    402022e0:	f81f839f 	stur	xzr, [x28, #-8]
    402022e4:	52800028 	mov	w8, #0x1                   	// #1
    402022e8:	f10012ff 	cmp	x23, #0x4
    402022ec:	a9005f08 	stp	x8, x23, [x24]
    402022f0:	540008a2 	b.cs	40202404 <jnox_kernel::ordinary_mutex_fifo::request+0x610>  // b.hs, b.nlast
    402022f4:	8b170f08 	add	x8, x24, x23, lsl #3
    402022f8:	f9408d08 	ldr	x8, [x8, #280]
    402022fc:	f2400d1f 	tst	x8, #0xf
    40202300:	54000421 	b.ne	40202384 <jnox_kernel::ordinary_mutex_fifo::request+0x590>  // b.any
    40202304:	f9407729 	ldr	x9, [x25, #232]
    40202308:	8b094349 	add	x9, x26, x9, lsl #16
    4020230c:	8b173929 	add	x9, x9, x23, lsl #14
    40202310:	d140412a 	sub	x10, x9, #0x10, lsl #12
    40202314:	eb08015f 	cmp	x10, x8
    40202318:	54000368 	b.hi	40202384 <jnox_kernel::ordinary_mutex_fifo::request+0x590>  // b.pmore
    4020231c:	929867ea 	mov	x10, #0xffffffffffff3cc0    	// #-49984
    40202320:	8b0a0129 	add	x9, x9, x10
    40202324:	eb08013f 	cmp	x9, x8
    40202328:	540002e3 	b.cc	40202384 <jnox_kernel::ordinary_mutex_fifo::request+0x590>  // b.lo, b.ul, b.last
    4020232c:	f900011f 	str	xzr, [x8]
    40202330:	d503201f 	nop
    40202334:	10016660 	adr	x0, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40202338:	aa1703e1 	mov	x1, x23
    4020233c:	2a1f03e2 	mov	w2, wzr
    40202340:	97fffe78 	bl	40201d20 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue>
    40202344:	52800038 	mov	w24, #0x1                   	// #1
    40202348:	f900027f 	str	xzr, [x19]
    4020234c:	d503201f 	nop
    40202350:	10016580 	adr	x0, 40205000 <jnox_kernel::ordinary_mutex_fifo::ACTIVE>
    40202354:	aa1403e1 	mov	x1, x20
    40202358:	52800022 	mov	w2, #0x1                   	// #1
    4020235c:	97fffe71 	bl	40201d20 <jnox_kernel::ordinary_mutex_fifo::Runtime::enqueue>
    40202360:	17ffff7a 	b	40202148 <jnox_kernel::ordinary_mutex_fifo::request+0x354>
    40202364:	d503201f 	nop
    40202368:	1000ec40 	adr	x0, 402040f0 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x1a0>
    4020236c:	94000326 	bl	40203004 <core::option::unwrap_failed>
    40202370:	d503201f 	nop
    40202374:	1000e363 	adr	x3, 40203fe0 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x90>
    40202378:	aa1f03e0 	mov	x0, xzr
    4020237c:	52800082 	mov	w2, #0x4                   	// #4
    40202380:	9400052c 	bl	40203830 <core::slice::index::slice_index_fail>
    40202384:	52800080 	mov	w0, #0x4                   	// #4
    40202388:	97fffc88 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>
    4020238c:	d503201f 	nop
    40202390:	1000e342 	adr	x2, 40203ff8 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0xa8>
    40202394:	aa0803e0 	mov	x0, x8
    40202398:	14000013 	b	402023e4 <jnox_kernel::ordinary_mutex_fifo::request+0x5f0>
    4020239c:	d503201f 	nop
    402023a0:	1000e082 	adr	x2, 40203fb0 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x60>
    402023a4:	14000010 	b	402023e4 <jnox_kernel::ordinary_mutex_fifo::request+0x5f0>
    402023a8:	52800100 	mov	w0, #0x8                   	// #8
    402023ac:	97fffc7f 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>
    402023b0:	528000c0 	mov	w0, #0x6                   	// #6
    402023b4:	97fffc7d 	bl	402015a8 <jnox_kernel::ordinary_mutex_fifo::stop>
    402023b8:	d503201f 	nop
    402023bc:	1000ea62 	adr	x2, 40204108 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x1b8>
    402023c0:	aa1403e0 	mov	x0, x20
    402023c4:	14000008 	b	402023e4 <jnox_kernel::ordinary_mutex_fifo::request+0x5f0>
    402023c8:	cb0803e0 	neg	x0, x8
    402023cc:	d503201f 	nop
    402023d0:	1000de42 	adr	x2, 40203f98 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x48>
    402023d4:	14000004 	b	402023e4 <jnox_kernel::ordinary_mutex_fifo::request+0x5f0>
    402023d8:	d503201f 	nop
    402023dc:	1000e1a2 	adr	x2, 40204010 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0xc0>
    402023e0:	aa1703e0 	mov	x0, x23
    402023e4:	52800081 	mov	w1, #0x4                   	// #4
    402023e8:	9400030e 	bl	40203020 <core::panicking::panic_bounds_check>
    402023ec:	d503201f 	nop
    402023f0:	1000dbc2 	adr	x2, 40203f68 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x18>
    402023f4:	17fffffc 	b	402023e4 <jnox_kernel::ordinary_mutex_fifo::request+0x5f0>
    402023f8:	d503201f 	nop
    402023fc:	1000dc22 	adr	x2, 40203f80 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x30>
    40202400:	17ffffe5 	b	40202394 <jnox_kernel::ordinary_mutex_fifo::request+0x5a0>
    40202404:	d503201f 	nop
    40202408:	1000e8c2 	adr	x2, 40204120 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x1d0>
    4020240c:	17fffff5 	b	402023e0 <jnox_kernel::ordinary_mutex_fifo::request+0x5ec>

0000000040202410 <jnox_kernel::ordinary_mutex_fifo::worker_a>:
    40202410:	f81f0ffe 	str	x30, [sp, #-16]!
    40202414:	52800020 	mov	w0, #0x1                   	// #1
    40202418:	97fffd7d 	bl	40201a0c <jnox_kernel::ordinary_mutex_fifo::worker>

000000004020241c <jnox_kernel::ordinary_mutex_fifo::worker_b>:
    4020241c:	f81f0ffe 	str	x30, [sp, #-16]!
    40202420:	52800040 	mov	w0, #0x2                   	// #2
    40202424:	97fffd7a 	bl	40201a0c <jnox_kernel::ordinary_mutex_fifo::worker>

0000000040202428 <core::ops::function::impls::<impl core::ops::function::FnMut<A> for &mut F>::call_mut>:
    40202428:	aa0003e8 	mov	x8, x0
    4020242c:	f9400020 	ldr	x0, [x1]
    40202430:	b50000e0 	cbnz	x0, 4020244c <core::ops::function::impls::<impl core::ops::function::FnMut<A> for &mut F>::call_mut+0x24>
    40202434:	f9400108 	ldr	x8, [x8]
    40202438:	f9400108 	ldr	x8, [x8]
    4020243c:	39435100 	ldrb	w0, [x8, #212]
    40202440:	36000040 	tbz	w0, #0, 40202448 <core::ops::function::impls::<impl core::ops::function::FnMut<A> for &mut F>::call_mut+0x20>
    40202444:	39435501 	ldrb	w1, [x8, #213]
    40202448:	d65f03c0 	ret
    4020244c:	f81f0ffe 	str	x30, [sp, #-16]!
    40202450:	d503201f 	nop
    40202454:	1000d7e2 	adr	x2, 40203f50 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461>
    40202458:	52800021 	mov	w1, #0x1                   	// #1
    4020245c:	940002f1 	bl	40203020 <core::panicking::panic_bounds_check>

0000000040202460 <fifo_worker_acquire>:
    40202460:	52800028 	mov	w8, #0x1                   	// #1
    40202464:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    40202468:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4020246c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    40202470:	aa1f03e0 	mov	x0, xzr
    40202474:	d4000001 	svc	#0x0
    40202478:	d65f03c0 	ret

000000004020247c <__rustc::rust_begin_unwind>:
    4020247c:	d503205f 	wfe
    40202480:	17ffffff 	b	4020247c <__rustc::rust_begin_unwind>

0000000040202484 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>:
    40202484:	d10203ff 	sub	sp, sp, #0x80
    40202488:	f90023fe 	str	x30, [sp, #64]
    4020248c:	a9055ff8 	stp	x24, x23, [sp, #80]
    40202490:	a90657f6 	stp	x22, x21, [sp, #96]
    40202494:	a9074ff4 	stp	x20, x19, [sp, #112]
    40202498:	aa0103f3 	mov	x19, x1
    4020249c:	f1000c3f 	cmp	x1, #0x3
    402024a0:	54000bc8 	b.hi	40202618 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x194>  // b.pmore
    402024a4:	aa1f03f5 	mov	x21, xzr
    402024a8:	f9400014 	ldr	x20, [x0]
    402024ac:	8b131696 	add	x22, x20, x19, lsl #5
    402024b0:	910042c8 	add	x8, x22, #0x10
    402024b4:	9100c2c9 	add	x9, x22, #0x30
    402024b8:	a902a7e8 	stp	x8, x9, [sp, #40]
    402024bc:	d37bea78 	lsl	x24, x19, #5
    402024c0:	910023e8 	add	x8, sp, #0x8
    402024c4:	f90007ff 	str	xzr, [sp, #8]
    402024c8:	f9000fff 	str	xzr, [sp, #24]
    402024cc:	9100c108 	add	x8, x8, #0x30
    402024d0:	f9001ff4 	str	x20, [sp, #56]
    402024d4:	f90027e8 	str	x8, [sp, #72]
    402024d8:	928003e8 	mov	x8, #0xffffffffffffffe0    	// #-32
    402024dc:	cb160117 	sub	x23, x8, x22
    402024e0:	8b1502c8 	add	x8, x22, x21
    402024e4:	f9400909 	ldr	x9, [x8, #16]
    402024e8:	f100053f 	cmp	x9, #0x1
    402024ec:	540000a1 	b.ne	40202500 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x7c>  // b.any
    402024f0:	910123e0 	add	x0, sp, #0x48
    402024f4:	91006101 	add	x1, x8, #0x18
    402024f8:	97ffffcc 	bl	40202428 <core::ops::function::impls::<impl core::ops::function::FnMut<A> for &mut F>::call_mut>
    402024fc:	370000c0 	tbnz	w0, #0, 40202514 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x90>
    40202500:	910042b5 	add	x21, x21, #0x10
    40202504:	f10082bf 	cmp	x21, #0x20
    40202508:	54fffec1 	b.ne	402024e0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x5c>  // b.any
    4020250c:	2a1f03e8 	mov	w8, wzr
    40202510:	1400001d 	b	40202584 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x100>
    40202514:	8b180288 	add	x8, x20, x24
    40202518:	8b150108 	add	x8, x8, x21
    4020251c:	91008109 	add	x9, x8, #0x20
    40202520:	f90017e9 	str	x9, [sp, #40]
    40202524:	f9401beb 	ldr	x11, [sp, #48]
    40202528:	eb0b013f 	cmp	x9, x11
    4020252c:	540002a0 	b.eq	40202580 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0xfc>  // b.none
    40202530:	f9401fea 	ldr	x10, [sp, #56]
    40202534:	9100a108 	add	x8, x8, #0x28
    40202538:	39435149 	ldrb	w9, [x10, #212]
    4020253c:	3943554a 	ldrb	w10, [x10, #213]
    40202540:	8b17016b 	add	x11, x11, x23
    40202544:	cb15016b 	sub	x11, x11, x21
    40202548:	d344fd6b 	lsr	x11, x11, #4
    4020254c:	f85f810c 	ldur	x12, [x8, #-8]
    40202550:	f100059f 	cmp	x12, #0x1
    40202554:	54000101 	b.ne	40202574 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0xf0>  // b.any
    40202558:	f9400100 	ldr	x0, [x8]
    4020255c:	b5000560 	cbnz	x0, 40202608 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x184>
    40202560:	12001c2c 	and	w12, w1, #0xff
    40202564:	6b0a019f 	cmp	w12, w10
    40202568:	1a8a818c 	csel	w12, w12, w10, hi  // hi = pmore
    4020256c:	7100013f 	cmp	w9, #0x0
    40202570:	1a811181 	csel	w1, w12, w1, ne  // ne = any
    40202574:	f100056b 	subs	x11, x11, #0x1
    40202578:	91004108 	add	x8, x8, #0x10
    4020257c:	54fffe81 	b.ne	4020254c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0xc8>  // b.any
    40202580:	52800028 	mov	w8, #0x1                   	// #1
    40202584:	8b131289 	add	x9, x20, x19, lsl #4
    40202588:	b940912a 	ldr	w10, [x9, #144]
    4020258c:	3600026a 	tbz	w10, #0, 402025d8 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    40202590:	f9404d20 	ldr	x0, [x9, #152]
    40202594:	b50004c0 	cbnz	x0, 4020262c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x1a8>
    40202598:	39435289 	ldrb	w9, [x20, #212]
    4020259c:	a9402e8a 	ldp	x10, x11, [x20]
    402025a0:	5200012c 	eor	w12, w9, #0x1
    402025a4:	8b13028d 	add	x13, x20, x19
    402025a8:	394381ad 	ldrb	w13, [x13, #224]
    402025ac:	53081d6b 	lsl	w11, w11, #24
    402025b0:	7200014a 	ands	w10, w10, #0x1
    402025b4:	9a9f116b 	csel	x11, x11, xzr, ne  // ne = any
    402025b8:	7200013f 	tst	w9, #0x1
    402025bc:	9a8b13e9 	csel	x9, xzr, x11, ne  // ne = any
    402025c0:	aa0d8129 	orr	x9, x9, x13, lsl #32
    402025c4:	6a0c015f 	tst	w10, w12
    402025c8:	52a0002a 	mov	w10, #0x10000               	// #65536
    402025cc:	9a9f114a 	csel	x10, x10, xzr, ne  // ne = any
    402025d0:	aa0a0129 	orr	x9, x9, x10
    402025d4:	14000004 	b	402025e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x160>
    402025d8:	8b130289 	add	x9, x20, x19
    402025dc:	39438129 	ldrb	w9, [x9, #224]
    402025e0:	d3607d29 	lsl	x9, x9, #32
    402025e4:	2a0803e8 	mov	w8, w8
    402025e8:	b3781c28 	bfi	x8, x1, #8, #8
    402025ec:	8b090100 	add	x0, x8, x9
    402025f0:	a9474ff4 	ldp	x20, x19, [sp, #112]
    402025f4:	a94657f6 	ldp	x22, x21, [sp, #96]
    402025f8:	a9455ff8 	ldp	x24, x23, [sp, #80]
    402025fc:	f94023fe 	ldr	x30, [sp, #64]
    40202600:	910203ff 	add	sp, sp, #0x80
    40202604:	d65f03c0 	ret
    40202608:	d503201f 	nop
    4020260c:	1000e122 	adr	x2, 40204230 <anon.6df75e256c2768ac659efecb48cbbb77.8.llvm.9204665349642594691+0x48>
    40202610:	52800021 	mov	w1, #0x1                   	// #1
    40202614:	94000283 	bl	40203020 <core::panicking::panic_bounds_check>
    40202618:	d503201f 	nop
    4020261c:	1000df22 	adr	x2, 40204200 <anon.6df75e256c2768ac659efecb48cbbb77.8.llvm.9204665349642594691+0x18>
    40202620:	aa1303e0 	mov	x0, x19
    40202624:	52800081 	mov	w1, #0x4                   	// #4
    40202628:	9400027e 	bl	40203020 <core::panicking::panic_bounds_check>
    4020262c:	d503201f 	nop
    40202630:	1000df42 	adr	x2, 40204218 <anon.6df75e256c2768ac659efecb48cbbb77.8.llvm.9204665349642594691+0x30>
    40202634:	17fffff7 	b	40202610 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x18c>

0000000040202638 <jnox_kernel::uart_write>:
    40202638:	b40001a1 	cbz	x1, 4020266c <jnox_kernel::uart_write+0x34>
    4020263c:	8b010008 	add	x8, x0, x1
    40202640:	52800309 	mov	w9, #0x18                  	// #24
    40202644:	72a12009 	movk	w9, #0x900, lsl #16
    40202648:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    4020264c:	3840140b 	ldrb	w11, [x0], #1
    40202650:	b940012c 	ldr	w12, [x9]
    40202654:	3628006c 	tbz	w12, #5, 40202660 <jnox_kernel::uart_write+0x28>
    40202658:	d5033fdf 	isb
    4020265c:	17fffffd 	b	40202650 <jnox_kernel::uart_write+0x18>
    40202660:	b900014b 	str	w11, [x10]
    40202664:	eb08001f 	cmp	x0, x8
    40202668:	54ffff21 	b.ne	4020264c <jnox_kernel::uart_write+0x14>  // b.any
    4020266c:	d65f03c0 	ret

0000000040202670 <jnox_kernel::kernel_main>:
    40202670:	b0000128 	adrp	x8, 40227000 <jnox_ap_returns+0x1d0>
    40202674:	f9421d08 	ldr	x8, [x8, #1080]
    40202678:	b4000068 	cbz	x8, 40202684 <jnox_kernel::kernel_main+0x14>
    4020267c:	d503205f 	wfe
    40202680:	17ffffff 	b	4020267c <jnox_kernel::kernel_main+0xc>
    40202684:	f81f0ffe 	str	x30, [sp, #-16]!
    40202688:	52800608 	mov	w8, #0x30                  	// #48
    4020268c:	72a12008 	movk	w8, #0x900, lsl #16
    40202690:	b900011f 	str	wzr, [x8]
    40202694:	528001a9 	mov	w9, #0xd                   	// #13
    40202698:	5280002a 	mov	w10, #0x1                   	// #1
    4020269c:	b81f4109 	stur	w9, [x8, #-12]
    402026a0:	b81f810a 	stur	w10, [x8, #-8]
    402026a4:	52800c09 	mov	w9, #0x60                  	// #96
    402026a8:	b81fc109 	stur	w9, [x8, #-4]
    402026ac:	52802029 	mov	w9, #0x101                 	// #257
    402026b0:	b9000109 	str	w9, [x8]
    402026b4:	d503201f 	nop
    402026b8:	1000d400 	adr	x0, 40204138 <anon.2c1f39affa57d0156fe9a41c49a99695.1.llvm.4966675838875970461+0x1e8>
    402026bc:	52800361 	mov	w1, #0x1b                  	// #27
    402026c0:	97ffffde 	bl	40202638 <jnox_kernel::uart_write>
    402026c4:	97fffb46 	bl	402013dc <jnox_kernel::ordinary_mutex_fifo::run>

00000000402026c8 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front>:
    402026c8:	f81f0ffe 	str	x30, [sp, #-16]!
    402026cc:	f9401009 	ldr	x9, [x0, #32]
    402026d0:	aa010128 	orr	x8, x9, x1
    402026d4:	f1000d1f 	cmp	x8, #0x3
    402026d8:	54000148 	b.hi	40202700 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x38>  // b.pmore
    402026dc:	aa1f03e8 	mov	x8, xzr
    402026e0:	8b090c0a 	add	x10, x0, x9, lsl #3
    402026e4:	d37df12b 	lsl	x11, x9, #3
    402026e8:	eb08017f 	cmp	x11, x8
    402026ec:	540000e0 	b.eq	40202708 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x40>  // b.none
    402026f0:	f868680c 	ldr	x12, [x0, x8]
    402026f4:	91002108 	add	x8, x8, #0x8
    402026f8:	eb01019f 	cmp	x12, x1
    402026fc:	54ffff61 	b.ne	402026e8 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x20>  // b.any
    40202700:	2a1f03e8 	mov	w8, wzr
    40202704:	14000015 	b	40202758 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x90>
    40202708:	b4000209 	cbz	x9, 40202748 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x80>
    4020270c:	d1000528 	sub	x8, x9, #0x1
    40202710:	f100153f 	cmp	x9, #0x5
    40202714:	54000302 	b.cs	40202774 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0xac>  // b.hs, b.nlast
    40202718:	f1000d1f 	cmp	x8, #0x3
    4020271c:	54000240 	b.eq	40202764 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x9c>  // b.none
    40202720:	aa0a03eb 	mov	x11, x10
    40202724:	f85f8d6c 	ldr	x12, [x11, #-8]!
    40202728:	f900014c 	str	x12, [x10]
    4020272c:	d1000508 	sub	x8, x8, #0x1
    40202730:	b100051f 	cmn	x8, #0x1
    40202734:	aa0b03ea 	mov	x10, x11
    40202738:	54fffec1 	b.ne	40202710 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x48>  // b.any
    4020273c:	f9401008 	ldr	x8, [x0, #32]
    40202740:	91000509 	add	x9, x8, #0x1
    40202744:	14000002 	b	4020274c <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0x84>
    40202748:	52800029 	mov	w9, #0x1                   	// #1
    4020274c:	f9000001 	str	x1, [x0]
    40202750:	52800028 	mov	w8, #0x1                   	// #1
    40202754:	f9001009 	str	x9, [x0, #32]
    40202758:	2a0803e0 	mov	w0, w8
    4020275c:	f84107fe 	ldr	x30, [sp], #16
    40202760:	d65f03c0 	ret
    40202764:	d503201f 	nop
    40202768:	1000d282 	adr	x2, 402041b8 <anon.6df75e256c2768ac659efecb48cbbb77.6.llvm.9204665349642594691>
    4020276c:	52800080 	mov	w0, #0x4                   	// #4
    40202770:	14000004 	b	40202780 <jnox_kernel::ready_queue::ReadyQueue<_>::push_front+0xb8>
    40202774:	d503201f 	nop
    40202778:	1000d142 	adr	x2, 402041a0 <anon.6df75e256c2768ac659efecb48cbbb77.5.llvm.9204665349642594691>
    4020277c:	aa0803e0 	mov	x0, x8
    40202780:	52800081 	mov	w1, #0x4                   	// #4
    40202784:	94000227 	bl	40203020 <core::panicking::panic_bounds_check>

0000000040202788 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest>:
    40202788:	f81a0ffe 	str	x30, [sp, #-96]!
    4020278c:	a9016ffc 	stp	x28, x27, [sp, #16]
    40202790:	a90267fa 	stp	x26, x25, [sp, #32]
    40202794:	a9035ff8 	stp	x24, x23, [sp, #48]
    40202798:	a90457f6 	stp	x22, x21, [sp, #64]
    4020279c:	a9054ff4 	stp	x20, x19, [sp, #80]
    402027a0:	f9401013 	ldr	x19, [x0, #32]
    402027a4:	f100167f 	cmp	x19, #0x5
    402027a8:	54000762 	b.cs	40202894 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0x10c>  // b.hs, b.nlast
    402027ac:	b4000613 	cbz	x19, 4020286c <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xe4>
    402027b0:	aa0103f5 	mov	x21, x1
    402027b4:	aa0003f4 	mov	x20, x0
    402027b8:	2a1f03f9 	mov	w25, wzr
    402027bc:	aa1f03f7 	mov	x23, xzr
    402027c0:	d37df278 	lsl	x24, x19, #3
    402027c4:	910033fb 	add	x27, sp, #0xc
    402027c8:	f8777a9c 	ldr	x28, [x20, x23, lsl #3]
    402027cc:	f1000f9f 	cmp	x28, #0x3
    402027d0:	54000108 	b.hi	402027f0 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0x68>  // b.pmore
    402027d4:	aa1503e0 	mov	x0, x21
    402027d8:	97fffab4 	bl	402012a8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17ha1954380307d5c31E.llvm.4966675838875970461>
    402027dc:	360000a0 	tbz	w0, #0, 402027f0 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0x68>
    402027e0:	d348fc08 	lsr	x8, x0, #8
    402027e4:	b9000fe8 	str	w8, [sp, #12]
    402027e8:	387c6b68 	ldrb	w8, [x27, x28]
    402027ec:	14000002 	b	402027f4 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0x6c>
    402027f0:	2a1f03e8 	mov	w8, wzr
    402027f4:	12001d09 	and	w9, w8, #0xff
    402027f8:	6b3a013f 	cmp	w9, w26, uxtb
    402027fc:	1a9f87e9 	cset	w9, ls  // ls = plast
    40202800:	6a09033f 	tst	w25, w9
    40202804:	9a9712d6 	csel	x22, x22, x23, ne  // ne = any
    40202808:	1a88135a 	csel	w26, w26, w8, ne  // ne = any
    4020280c:	f1002318 	subs	x24, x24, #0x8
    40202810:	910006f7 	add	x23, x23, #0x1
    40202814:	52800039 	mov	w25, #0x1                   	// #1
    40202818:	54fffd81 	b.ne	402027c8 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0x40>  // b.any
    4020281c:	f1000edf 	cmp	x22, #0x3
    40202820:	54000508 	b.hi	402028c0 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0x138>  // b.pmore
    40202824:	f8767a81 	ldr	x1, [x20, x22, lsl #3]
    40202828:	d1000668 	sub	x8, x19, #0x1
    4020282c:	f9001288 	str	x8, [x20, #32]
    40202830:	eb0802df 	cmp	x22, x8
    40202834:	54000202 	b.cs	40202874 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xec>  // b.hs, b.nlast
    40202838:	8b160e88 	add	x8, x20, x22, lsl #3
    4020283c:	91002109 	add	x9, x8, #0x8
    40202840:	910006c8 	add	x8, x22, #0x1
    40202844:	52800020 	mov	w0, #0x1                   	// #1
    40202848:	f100111f 	cmp	x8, #0x4
    4020284c:	54000300 	b.eq	402028ac <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0x124>  // b.none
    40202850:	f940012a 	ldr	x10, [x9]
    40202854:	f81f812a 	stur	x10, [x9, #-8]
    40202858:	91002129 	add	x9, x9, #0x8
    4020285c:	91000508 	add	x8, x8, #0x1
    40202860:	eb08027f 	cmp	x19, x8
    40202864:	54ffff21 	b.ne	40202848 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xc0>  // b.any
    40202868:	14000004 	b	40202878 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xf0>
    4020286c:	aa1f03e0 	mov	x0, xzr
    40202870:	14000002 	b	40202878 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0xf0>
    40202874:	52800020 	mov	w0, #0x1                   	// #1
    40202878:	a9454ff4 	ldp	x20, x19, [sp, #80]
    4020287c:	a94457f6 	ldp	x22, x21, [sp, #64]
    40202880:	a9435ff8 	ldp	x24, x23, [sp, #48]
    40202884:	a94267fa 	ldp	x26, x25, [sp, #32]
    40202888:	a9416ffc 	ldp	x28, x27, [sp, #16]
    4020288c:	f84607fe 	ldr	x30, [sp], #96
    40202890:	d65f03c0 	ret
    40202894:	d503201f 	nop
    40202898:	1000c603 	adr	x3, 40204158 <anon.6df75e256c2768ac659efecb48cbbb77.2.llvm.9204665349642594691>
    4020289c:	aa1f03e0 	mov	x0, xzr
    402028a0:	aa1303e1 	mov	x1, x19
    402028a4:	52800082 	mov	w2, #0x4                   	// #4
    402028a8:	940003e2 	bl	40203830 <core::slice::index::slice_index_fail>
    402028ac:	d503201f 	nop
    402028b0:	1000c6c2 	adr	x2, 40204188 <anon.6df75e256c2768ac659efecb48cbbb77.4.llvm.9204665349642594691>
    402028b4:	aa0803e0 	mov	x0, x8
    402028b8:	52800081 	mov	w1, #0x4                   	// #4
    402028bc:	940001d9 	bl	40203020 <core::panicking::panic_bounds_check>
    402028c0:	d503201f 	nop
    402028c4:	1000c562 	adr	x2, 40204170 <anon.6df75e256c2768ac659efecb48cbbb77.3.llvm.9204665349642594691>
    402028c8:	aa1603e0 	mov	x0, x22
    402028cc:	17fffffb 	b	402028b8 <jnox_kernel::ready_queue::ReadyQueue<_>::pop_highest+0x130>

00000000402028d0 <jnox_kernel::ready_queue::ReadyQueue<_>::push_back>:
    402028d0:	f81f0ffe 	str	x30, [sp, #-16]!
    402028d4:	aa0003e8 	mov	x8, x0
    402028d8:	f9401000 	ldr	x0, [x0, #32]
    402028dc:	aa010009 	orr	x9, x0, x1
    402028e0:	f1000d3f 	cmp	x9, #0x3
    402028e4:	54000108 	b.hi	40202904 <jnox_kernel::ready_queue::ReadyQueue<_>::push_back+0x34>  // b.pmore
    402028e8:	d37df009 	lsl	x9, x0, #3
    402028ec:	aa0803ea 	mov	x10, x8
    402028f0:	b40000e9 	cbz	x9, 4020290c <jnox_kernel::ready_queue::ReadyQueue<_>::push_back+0x3c>
    402028f4:	f840854b 	ldr	x11, [x10], #8
    402028f8:	d1002129 	sub	x9, x9, #0x8
    402028fc:	eb01017f 	cmp	x11, x1
    40202900:	54ffff81 	b.ne	402028f0 <jnox_kernel::ready_queue::ReadyQueue<_>::push_back+0x20>  // b.any
    40202904:	2a1f03e0 	mov	w0, wzr
    40202908:	14000008 	b	40202928 <jnox_kernel::ready_queue::ReadyQueue<_>::push_back+0x58>
    4020290c:	f100101f 	cmp	x0, #0x4
    40202910:	54000102 	b.cs	40202930 <jnox_kernel::ready_queue::ReadyQueue<_>::push_back+0x60>  // b.hs, b.nlast
    40202914:	f8207901 	str	x1, [x8, x0, lsl #3]
    40202918:	f9401109 	ldr	x9, [x8, #32]
    4020291c:	91000529 	add	x9, x9, #0x1
    40202920:	f9001109 	str	x9, [x8, #32]
    40202924:	52800020 	mov	w0, #0x1                   	// #1
    40202928:	f84107fe 	ldr	x30, [sp], #16
    4020292c:	d65f03c0 	ret
    40202930:	d503201f 	nop
    40202934:	1000c5a2 	adr	x2, 402041e8 <anon.6df75e256c2768ac659efecb48cbbb77.8.llvm.9204665349642594691>
    40202938:	52800081 	mov	w1, #0x4                   	// #4
    4020293c:	940001b9 	bl	40203020 <core::panicking::panic_bounds_check>

0000000040202940 <jnox_kernel::domain_policy::effective_priorities>:
    40202940:	d10083ff 	sub	sp, sp, #0x20
    40202944:	f9000bfe 	str	x30, [sp, #16]
    40202948:	b9000fff 	str	wzr, [sp, #12]
    4020294c:	29037fff 	stp	wzr, wzr, [sp, #24]
    40202950:	910033e8 	add	x8, sp, #0xc
    40202954:	91000809 	add	x9, x0, #0x2
    40202958:	5280028a 	mov	w10, #0x14                  	// #20
    4020295c:	910063eb 	add	x11, sp, #0x18
    40202960:	3940092c 	ldrb	w12, [x9, #2]
    40202964:	385ff12d 	ldurb	w13, [x9, #-1]
    40202968:	385fe12e 	ldurb	w14, [x9, #-2]
    4020296c:	6b0c01bf 	cmp	w13, w12
    40202970:	1a8c81ad 	csel	w13, w13, w12, hi  // hi = pmore
    40202974:	710001df 	cmp	w14, #0x0
    40202978:	1a8c11ac 	csel	w12, w13, w12, ne  // ne = any
    4020297c:	3900010c 	strb	w12, [x8]
    40202980:	3940012c 	ldrb	w12, [x9]
    40202984:	7100059f 	cmp	w12, #0x1
    40202988:	540000e1 	b.ne	402029a4 <jnox_kernel::domain_policy::effective_priorities+0x64>  // b.any
    4020298c:	3940052c 	ldrb	w12, [x9, #1]
    40202990:	f1000d9f 	cmp	x12, #0x3
    40202994:	540007a8 	b.hi	40202a88 <jnox_kernel::domain_policy::effective_priorities+0x148>  // b.pmore
    40202998:	386c696d 	ldrb	w13, [x11, x12]
    4020299c:	110005ad 	add	w13, w13, #0x1
    402029a0:	382c696d 	strb	w13, [x11, x12]
    402029a4:	91001529 	add	x9, x9, #0x5
    402029a8:	91000508 	add	x8, x8, #0x1
    402029ac:	f100154a 	subs	x10, x10, #0x5
    402029b0:	54fffd81 	b.ne	40202960 <jnox_kernel::domain_policy::effective_priorities+0x20>  // b.any
    402029b4:	aa1f03e8 	mov	x8, xzr
    402029b8:	aa1f03e9 	mov	x9, xzr
    402029bc:	910063ea 	add	x10, sp, #0x18
    402029c0:	910073eb 	add	x11, sp, #0x1c
    402029c4:	3869694c 	ldrb	w12, [x10, x9]
    402029c8:	350000ac 	cbnz	w12, 402029dc <jnox_kernel::domain_policy::effective_priorities+0x9c>
    402029cc:	f100111f 	cmp	x8, #0x4
    402029d0:	540007c2 	b.cs	40202ac8 <jnox_kernel::domain_policy::effective_priorities+0x188>  // b.hs, b.nlast
    402029d4:	38286969 	strb	w9, [x11, x8]
    402029d8:	91000508 	add	x8, x8, #0x1
    402029dc:	91000529 	add	x9, x9, #0x1
    402029e0:	f100113f 	cmp	x9, #0x4
    402029e4:	54ffff01 	b.ne	402029c4 <jnox_kernel::domain_policy::effective_priorities+0x84>  // b.any
    402029e8:	b4000548 	cbz	x8, 40202a90 <jnox_kernel::domain_policy::effective_priorities+0x150>
    402029ec:	aa1f03eb 	mov	x11, xzr
    402029f0:	910073ec 	add	x12, sp, #0x1c
    402029f4:	910033ed 	add	x13, sp, #0xc
    402029f8:	910063ee 	add	x14, sp, #0x18
    402029fc:	f100117f 	cmp	x11, #0x4
    40202a00:	540005c0 	b.eq	40202ab8 <jnox_kernel::domain_policy::effective_priorities+0x178>  // b.none
    40202a04:	386b698a 	ldrb	w10, [x12, x11]
    40202a08:	f100115f 	cmp	x10, #0x4
    40202a0c:	540004e2 	b.cs	40202aa8 <jnox_kernel::domain_policy::effective_priorities+0x168>  // b.hs, b.nlast
    40202a10:	8b0a0949 	add	x9, x10, x10, lsl #2
    40202a14:	8b090009 	add	x9, x0, x9
    40202a18:	3940092f 	ldrb	w15, [x9, #2]
    40202a1c:	3600024f 	tbz	w15, #0, 40202a64 <jnox_kernel::domain_policy::effective_priorities+0x124>
    40202a20:	39400d29 	ldrb	w9, [x9, #3]
    40202a24:	f100113f 	cmp	x9, #0x4
    40202a28:	54000562 	b.cs	40202ad4 <jnox_kernel::domain_policy::effective_priorities+0x194>  // b.hs, b.nlast
    40202a2c:	386969af 	ldrb	w15, [x13, x9]
    40202a30:	386a69aa 	ldrb	w10, [x13, x10]
    40202a34:	386969d0 	ldrb	w16, [x14, x9]
    40202a38:	6b0f015f 	cmp	w10, w15
    40202a3c:	51000610 	sub	w16, w16, #0x1
    40202a40:	1a8f814a 	csel	w10, w10, w15, hi  // hi = pmore
    40202a44:	382969aa 	strb	w10, [x13, x9]
    40202a48:	72001e1f 	tst	w16, #0xff
    40202a4c:	382969d0 	strb	w16, [x14, x9]
    40202a50:	540000a1 	b.ne	40202a64 <jnox_kernel::domain_policy::effective_priorities+0x124>  // b.any
    40202a54:	f1000d1f 	cmp	x8, #0x3
    40202a58:	54000468 	b.hi	40202ae4 <jnox_kernel::domain_policy::effective_priorities+0x1a4>  // b.pmore
    40202a5c:	38286989 	strb	w9, [x12, x8]
    40202a60:	91000508 	add	x8, x8, #0x1
    40202a64:	9100056b 	add	x11, x11, #0x1
    40202a68:	eb08017f 	cmp	x11, x8
    40202a6c:	54fffc83 	b.cc	402029fc <jnox_kernel::domain_policy::effective_priorities+0xbc>  // b.lo, b.ul, b.last
    40202a70:	f100117f 	cmp	x11, #0x4
    40202a74:	1a9f17e8 	cset	w8, eq  // eq = none
    40202a78:	b9400fe9 	ldr	w9, [sp, #12]
    40202a7c:	d378dd29 	lsl	x9, x9, #8
    40202a80:	9a9f0129 	csel	x9, x9, xzr, eq  // eq = none
    40202a84:	14000004 	b	40202a94 <jnox_kernel::domain_policy::effective_priorities+0x154>
    40202a88:	aa1f03e0 	mov	x0, xzr
    40202a8c:	14000004 	b	40202a9c <jnox_kernel::domain_policy::effective_priorities+0x15c>
    40202a90:	aa1f03e9 	mov	x9, xzr
    40202a94:	2a0803e8 	mov	w8, w8
    40202a98:	aa080120 	orr	x0, x9, x8
    40202a9c:	f9400bfe 	ldr	x30, [sp, #16]
    40202aa0:	910083ff 	add	sp, sp, #0x20
    40202aa4:	d65f03c0 	ret
    40202aa8:	d503201f 	nop
    40202aac:	1000bda2 	adr	x2, 40204260 <anon.6df75e256c2768ac659efecb48cbbb77.8.llvm.9204665349642594691+0x78>
    40202ab0:	aa0a03e0 	mov	x0, x10
    40202ab4:	1400000f 	b	40202af0 <jnox_kernel::domain_policy::effective_priorities+0x1b0>
    40202ab8:	d503201f 	nop
    40202abc:	1000bc62 	adr	x2, 40204248 <anon.6df75e256c2768ac659efecb48cbbb77.8.llvm.9204665349642594691+0x60>
    40202ac0:	52800080 	mov	w0, #0x4                   	// #4
    40202ac4:	1400000b 	b	40202af0 <jnox_kernel::domain_policy::effective_priorities+0x1b0>
    40202ac8:	d503201f 	nop
    40202acc:	1000bee2 	adr	x2, 402042a8 <anon.6df75e256c2768ac659efecb48cbbb77.8.llvm.9204665349642594691+0xc0>
    40202ad0:	14000007 	b	40202aec <jnox_kernel::domain_policy::effective_priorities+0x1ac>
    40202ad4:	d503201f 	nop
    40202ad8:	1000bd02 	adr	x2, 40204278 <anon.6df75e256c2768ac659efecb48cbbb77.8.llvm.9204665349642594691+0x90>
    40202adc:	aa0903e0 	mov	x0, x9
    40202ae0:	14000004 	b	40202af0 <jnox_kernel::domain_policy::effective_priorities+0x1b0>
    40202ae4:	d503201f 	nop
    40202ae8:	1000bd42 	adr	x2, 40204290 <anon.6df75e256c2768ac659efecb48cbbb77.8.llvm.9204665349642594691+0xa8>
    40202aec:	aa0803e0 	mov	x0, x8
    40202af0:	52800081 	mov	w1, #0x4                   	// #4
    40202af4:	9400014b 	bl	40203020 <core::panicking::panic_bounds_check>

0000000040202af8 <jnox_kernel::context::init_timer_irq>:
    40202af8:	d503201f 	nop
    40202afc:	10fee828 	adr	x8, 40200800 <sched_vectors>
    40202b00:	d518c008 	msr	vbar_el1, x8
    40202b04:	d51be23f 	msr	cntp_ctl_el0, xzr
    40202b08:	d5033fdf 	isb
    40202b0c:	52a10008 	mov	w8, #0x8000000             	// #134217728
    40202b10:	b900011f 	str	wzr, [x8]
    40202b14:	52a10029 	mov	w9, #0x8010000             	// #134283264
    40202b18:	b900013f 	str	wzr, [x9]
    40202b1c:	5280100a 	mov	w10, #0x80                  	// #128
    40202b20:	72a1000a 	movk	w10, #0x800, lsl #16
    40202b24:	b940014b 	ldr	w11, [x10]
    40202b28:	1201796b 	and	w11, w11, #0xbfffffff
    40202b2c:	b900014b 	str	w11, [x10]
    40202b30:	5280100b 	mov	w11, #0x80                  	// #128
    40202b34:	390e794b 	strb	w11, [x10, #926]
    40202b38:	52a8000b 	mov	w11, #0x40000000            	// #1073741824
    40202b3c:	b902014b 	str	w11, [x10, #512]
    40202b40:	b900814b 	str	w11, [x10, #128]
    40202b44:	5280008a 	mov	w10, #0x4                   	// #4
    40202b48:	72a1002a 	movk	w10, #0x801, lsl #16
    40202b4c:	52801feb 	mov	w11, #0xff                  	// #255
    40202b50:	b900014b 	str	w11, [x10]
    40202b54:	5280002a 	mov	w10, #0x1                   	// #1
    40202b58:	b900010a 	str	w10, [x8]
    40202b5c:	b900012a 	str	w10, [x9]
    40202b60:	d5033f9f 	dsb	sy
    40202b64:	d5033fdf 	isb
    40202b68:	d65f03c0 	ret

0000000040202b6c <<core::fmt::Formatter>::pad_integral>:
    40202b6c:	d101c3ff 	sub	sp, sp, #0x70
    40202b70:	a9017bfd 	stp	x29, x30, [sp, #16]
    40202b74:	a9026ffc 	stp	x28, x27, [sp, #32]
    40202b78:	a90367fa 	stp	x26, x25, [sp, #48]
    40202b7c:	a9045ff8 	stp	x24, x23, [sp, #64]
    40202b80:	a90557f6 	stp	x22, x21, [sp, #80]
    40202b84:	a9064ff4 	stp	x20, x19, [sp, #96]
    40202b88:	910043fd 	add	x29, sp, #0x10
    40202b8c:	b940101a 	ldr	w26, [x0, #16]
    40202b90:	52a00229 	mov	w9, #0x110000              	// #1114112
    40202b94:	aa0503f3 	mov	x19, x5
    40202b98:	aa0403fc 	mov	x28, x4
    40202b9c:	aa0303f6 	mov	x22, x3
    40202ba0:	aa0003f5 	mov	x21, x0
    40202ba4:	926b0348 	and	x8, x26, #0x200000
    40202ba8:	d355574a 	ubfx	x10, x26, #21, #1
    40202bac:	7100011f 	cmp	w8, #0x0
    40202bb0:	52800568 	mov	w8, #0x2b                  	// #43
    40202bb4:	1a880128 	csel	w8, w9, w8, eq  // eq = none
    40202bb8:	7100003f 	cmp	w1, #0x0
    40202bbc:	528005a9 	mov	w9, #0x2d                  	// #45
    40202bc0:	9a9f154a 	csinc	x10, x10, xzr, ne  // ne = any
    40202bc4:	1a891118 	csel	w24, w8, w9, ne  // ne = any
    40202bc8:	8b05015b 	add	x27, x10, x5
    40202bcc:	37b8033a 	tbnz	w26, #23, 40202c30 <<core::fmt::Formatter>::pad_integral+0xc4>
    40202bd0:	aa1f03f7 	mov	x23, xzr
    40202bd4:	79402ab4 	ldrh	w20, [x21, #20]
    40202bd8:	eb14037f 	cmp	x27, x20
    40202bdc:	54001503 	b.cc	40202e7c <<core::fmt::Formatter>::pad_integral+0x310>  // b.lo, b.ul, b.last
    40202be0:	a94056b9 	ldp	x25, x21, [x21]
    40202be4:	2a1803e2 	mov	w2, w24
    40202be8:	aa1703e3 	mov	x3, x23
    40202bec:	aa1603e4 	mov	x4, x22
    40202bf0:	aa1903e0 	mov	x0, x25
    40202bf4:	aa1503e1 	mov	x1, x21
    40202bf8:	9400033b 	bl	402038e4 <<core::fmt::Formatter>::pad_integral::write_prefix>
    40202bfc:	37001d60 	tbnz	w0, #0, 40202fa8 <<core::fmt::Formatter>::pad_integral+0x43c>
    40202c00:	f9400ea3 	ldr	x3, [x21, #24]
    40202c04:	aa1903e0 	mov	x0, x25
    40202c08:	aa1c03e1 	mov	x1, x28
    40202c0c:	aa1303e2 	mov	x2, x19
    40202c10:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40202c14:	a94557f6 	ldp	x22, x21, [sp, #80]
    40202c18:	a9445ff8 	ldp	x24, x23, [sp, #64]
    40202c1c:	a94367fa 	ldp	x26, x25, [sp, #48]
    40202c20:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40202c24:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40202c28:	9101c3ff 	add	sp, sp, #0x70
    40202c2c:	d61f0060 	br	x3
    40202c30:	aa0203f7 	mov	x23, x2
    40202c34:	f10082df 	cmp	x22, #0x20
    40202c38:	540000e2 	b.cs	40202c54 <<core::fmt::Formatter>::pad_integral+0xe8>  // b.hs, b.nlast
    40202c3c:	b4000156 	cbz	x22, 40202c64 <<core::fmt::Formatter>::pad_integral+0xf8>
    40202c40:	f10022df 	cmp	x22, #0x8
    40202c44:	54000142 	b.cs	40202c6c <<core::fmt::Formatter>::pad_integral+0x100>  // b.hs, b.nlast
    40202c48:	aa1f03e8 	mov	x8, xzr
    40202c4c:	aa1f03e0 	mov	x0, xzr
    40202c50:	14000080 	b	40202e50 <<core::fmt::Formatter>::pad_integral+0x2e4>
    40202c54:	aa1703e0 	mov	x0, x23
    40202c58:	aa1603e1 	mov	x1, x22
    40202c5c:	9400010e 	bl	40203094 <core::str::count::do_count_chars>
    40202c60:	14000083 	b	40202e6c <<core::fmt::Formatter>::pad_integral+0x300>
    40202c64:	aa1f03e0 	mov	x0, xzr
    40202c68:	14000081 	b	40202e6c <<core::fmt::Formatter>::pad_integral+0x300>
    40202c6c:	aa1703ea 	mov	x10, x23
    40202c70:	39400ae9 	ldrb	w9, [x23, #2]
    40202c74:	394006e8 	ldrb	w8, [x23, #1]
    40202c78:	38404d4b 	ldrb	w11, [x10, #4]!
    40202c7c:	3940094c 	ldrb	w12, [x10, #2]
    40202c80:	394002ed 	ldrb	w13, [x23]
    40202c84:	39400eee 	ldrb	w14, [x23, #3]
    40202c88:	d370bd29 	lsl	x9, x9, #16
    40202c8c:	394016ef 	ldrb	w15, [x23, #5]
    40202c90:	39400d4a 	ldrb	w10, [x10, #3]
    40202c94:	53103d8c 	lsl	w12, w12, #16
    40202c98:	aa0821a8 	orr	x8, x13, x8, lsl #8
    40202c9c:	aa0e6129 	orr	x9, x9, x14, lsl #24
    40202ca0:	0f05e7e4 	movi	v4.8b, #0xbf
    40202ca4:	2a0f216b 	orr	w11, w11, w15, lsl #8
    40202ca8:	2a0a618a 	orr	w10, w12, w10, lsl #24
    40202cac:	aa080128 	orr	x8, x9, x8
    40202cb0:	2a0b0149 	orr	w9, w10, w11
    40202cb4:	aa098108 	orr	x8, x8, x9, lsl #32
    40202cb8:	9e670100 	fmov	d0, x8
    40202cbc:	52800028 	mov	w8, #0x1                   	// #1
    40202cc0:	4e080d03 	dup	v3.2d, x8
    40202cc4:	927d06c8 	and	x8, x22, #0x18
    40202cc8:	f100211f 	cmp	x8, #0x8
    40202ccc:	0e243400 	cmgt	v0.8b, v0.8b, v4.8b
    40202cd0:	2f08a400 	uxtl	v0.8h, v0.8b
    40202cd4:	6f10a401 	uxtl2	v1.4s, v0.8h
    40202cd8:	2f10a400 	uxtl	v0.4s, v0.4h
    40202cdc:	6f20a422 	uxtl2	v2.2d, v1.4s
    40202ce0:	2f20a421 	uxtl	v1.2d, v1.2s
    40202ce4:	6f20a405 	uxtl2	v5.2d, v0.4s
    40202ce8:	2f20a406 	uxtl	v6.2d, v0.2s
    40202cec:	4e231c40 	and	v0.16b, v2.16b, v3.16b
    40202cf0:	4e231c22 	and	v2.16b, v1.16b, v3.16b
    40202cf4:	4e231ca1 	and	v1.16b, v5.16b, v3.16b
    40202cf8:	4e231cc3 	and	v3.16b, v6.16b, v3.16b
    40202cfc:	540009c0 	b.eq	40202e34 <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    40202d00:	aa1703e9 	mov	x9, x23
    40202d04:	f100411f 	cmp	x8, #0x10
    40202d08:	38408d2a 	ldrb	w10, [x9, #8]!
    40202d0c:	3940052b 	ldrb	w11, [x9, #1]
    40202d10:	39400d2c 	ldrb	w12, [x9, #3]
    40202d14:	3940092d 	ldrb	w13, [x9, #2]
    40202d18:	3940152e 	ldrb	w14, [x9, #5]
    40202d1c:	38404d2f 	ldrb	w15, [x9, #4]!
    40202d20:	39400930 	ldrb	w16, [x9, #2]
    40202d24:	39400d29 	ldrb	w9, [x9, #3]
    40202d28:	d370bdad 	lsl	x13, x13, #16
    40202d2c:	aa0b214a 	orr	x10, x10, x11, lsl #8
    40202d30:	53103e10 	lsl	w16, w16, #16
    40202d34:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40202d38:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40202d3c:	2a096209 	orr	w9, w16, w9, lsl #24
    40202d40:	aa0a018a 	orr	x10, x12, x10
    40202d44:	2a0b0129 	orr	w9, w9, w11
    40202d48:	aa098149 	orr	x9, x10, x9, lsl #32
    40202d4c:	9e670125 	fmov	d5, x9
    40202d50:	52800029 	mov	w9, #0x1                   	// #1
    40202d54:	4e080d26 	dup	v6.2d, x9
    40202d58:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40202d5c:	2f08a484 	uxtl	v4.8h, v4.8b
    40202d60:	6f10a485 	uxtl2	v5.4s, v4.8h
    40202d64:	2f10a484 	uxtl	v4.4s, v4.4h
    40202d68:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40202d6c:	2f20a490 	uxtl	v16.2d, v4.2s
    40202d70:	6f20a484 	uxtl2	v4.2d, v4.4s
    40202d74:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40202d78:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40202d7c:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40202d80:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40202d84:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40202d88:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40202d8c:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40202d90:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40202d94:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40202d98:	540004e0 	b.eq	40202e34 <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    40202d9c:	aa1703e9 	mov	x9, x23
    40202da0:	0f05e7e4 	movi	v4.8b, #0xbf
    40202da4:	38410d2a 	ldrb	w10, [x9, #16]!
    40202da8:	3940052b 	ldrb	w11, [x9, #1]
    40202dac:	39400d2c 	ldrb	w12, [x9, #3]
    40202db0:	3940092d 	ldrb	w13, [x9, #2]
    40202db4:	3940152e 	ldrb	w14, [x9, #5]
    40202db8:	38404d2f 	ldrb	w15, [x9, #4]!
    40202dbc:	39400930 	ldrb	w16, [x9, #2]
    40202dc0:	39400d29 	ldrb	w9, [x9, #3]
    40202dc4:	d370bdad 	lsl	x13, x13, #16
    40202dc8:	aa0b214a 	orr	x10, x10, x11, lsl #8
    40202dcc:	53103e10 	lsl	w16, w16, #16
    40202dd0:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40202dd4:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40202dd8:	2a096209 	orr	w9, w16, w9, lsl #24
    40202ddc:	aa0a018a 	orr	x10, x12, x10
    40202de0:	2a0b0129 	orr	w9, w9, w11
    40202de4:	aa098149 	orr	x9, x10, x9, lsl #32
    40202de8:	9e670125 	fmov	d5, x9
    40202dec:	52800029 	mov	w9, #0x1                   	// #1
    40202df0:	4e080d26 	dup	v6.2d, x9
    40202df4:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40202df8:	2f08a484 	uxtl	v4.8h, v4.8b
    40202dfc:	6f10a485 	uxtl2	v5.4s, v4.8h
    40202e00:	2f10a484 	uxtl	v4.4s, v4.4h
    40202e04:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40202e08:	2f20a490 	uxtl	v16.2d, v4.2s
    40202e0c:	6f20a484 	uxtl2	v4.2d, v4.4s
    40202e10:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40202e14:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40202e18:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40202e1c:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40202e20:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40202e24:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40202e28:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40202e2c:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40202e30:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40202e34:	4ee28462 	add	v2.2d, v3.2d, v2.2d
    40202e38:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    40202e3c:	eb0802df 	cmp	x22, x8
    40202e40:	4ee08440 	add	v0.2d, v2.2d, v0.2d
    40202e44:	5ef1b800 	addp	d0, v0.2d
    40202e48:	9e660000 	fmov	x0, d0
    40202e4c:	54000100 	b.eq	40202e6c <<core::fmt::Formatter>::pad_integral+0x300>  // b.none
    40202e50:	cb0802c9 	sub	x9, x22, x8
    40202e54:	8b0802e8 	add	x8, x23, x8
    40202e58:	38c0150a 	ldrsb	w10, [x8], #1
    40202e5c:	3101055f 	cmn	w10, #0x41
    40202e60:	9a80d400 	cinc	x0, x0, gt
    40202e64:	f1000529 	subs	x9, x9, #0x1
    40202e68:	54ffff81 	b.ne	40202e58 <<core::fmt::Formatter>::pad_integral+0x2ec>  // b.any
    40202e6c:	8b1b001b 	add	x27, x0, x27
    40202e70:	79402ab4 	ldrh	w20, [x21, #20]
    40202e74:	eb14037f 	cmp	x27, x20
    40202e78:	54ffeb42 	b.cs	40202be0 <<core::fmt::Formatter>::pad_integral+0x74>  // b.hs, b.nlast
    40202e7c:	f90007fc 	str	x28, [sp, #8]
    40202e80:	37c0011a 	tbnz	w26, #24, 40202ea0 <<core::fmt::Formatter>::pad_integral+0x334>
    40202e84:	531d7b48 	ubfx	w8, w26, #29, #2
    40202e88:	4b1b029b 	sub	w27, w20, w27
    40202e8c:	7100051f 	cmp	w8, #0x1
    40202e90:	540003cc 	b.gt	40202f08 <<core::fmt::Formatter>::pad_integral+0x39c>
    40202e94:	35000568 	cbnz	w8, 40202f40 <<core::fmt::Formatter>::pad_integral+0x3d4>
    40202e98:	2a1f03fc 	mov	w28, wzr
    40202e9c:	1400002a 	b	40202f44 <<core::fmt::Formatter>::pad_integral+0x3d8>
    40202ea0:	a940f2ba 	ldp	x26, x28, [x21, #8]
    40202ea4:	52b3fc08 	mov	w8, #0x9fe00000            	// #-1612709888
    40202ea8:	f94002b9 	ldr	x25, [x21]
    40202eac:	2a1803e2 	mov	w2, w24
    40202eb0:	aa1703e3 	mov	x3, x23
    40202eb4:	aa1603e4 	mov	x4, x22
    40202eb8:	0a080388 	and	w8, w28, w8
    40202ebc:	aa1903e0 	mov	x0, x25
    40202ec0:	aa1a03e1 	mov	x1, x26
    40202ec4:	321c0508 	orr	w8, w8, #0x30
    40202ec8:	32030108 	orr	w8, w8, #0x20000000
    40202ecc:	b90012a8 	str	w8, [x21, #16]
    40202ed0:	94000285 	bl	402038e4 <<core::fmt::Formatter>::pad_integral::write_prefix>
    40202ed4:	370006a0 	tbnz	w0, #0, 40202fa8 <<core::fmt::Formatter>::pad_integral+0x43c>
    40202ed8:	2a1f03f6 	mov	w22, wzr
    40202edc:	4b1b0294 	sub	w20, w20, w27
    40202ee0:	12003ec8 	and	w8, w22, #0xffff
    40202ee4:	6b34211f 	cmp	w8, w20, uxth
    40202ee8:	540001a2 	b.cs	40202f1c <<core::fmt::Formatter>::pad_integral+0x3b0>  // b.hs, b.nlast
    40202eec:	f9401348 	ldr	x8, [x26, #32]
    40202ef0:	aa1903e0 	mov	x0, x25
    40202ef4:	52800601 	mov	w1, #0x30                  	// #48
    40202ef8:	110006d6 	add	w22, w22, #0x1
    40202efc:	d63f0100 	blr	x8
    40202f00:	3607ff00 	tbz	w0, #0, 40202ee0 <<core::fmt::Formatter>::pad_integral+0x374>
    40202f04:	14000029 	b	40202fa8 <<core::fmt::Formatter>::pad_integral+0x43c>
    40202f08:	7100091f 	cmp	w8, #0x2
    40202f0c:	2a1b03fc 	mov	w28, w27
    40202f10:	540001a1 	b.ne	40202f44 <<core::fmt::Formatter>::pad_integral+0x3d8>  // b.any
    40202f14:	53013f7c 	ubfx	w28, w27, #1, #15
    40202f18:	1400000b 	b	40202f44 <<core::fmt::Formatter>::pad_integral+0x3d8>
    40202f1c:	f9400f48 	ldr	x8, [x26, #24]
    40202f20:	f94007e1 	ldr	x1, [sp, #8]
    40202f24:	aa1903e0 	mov	x0, x25
    40202f28:	aa1303e2 	mov	x2, x19
    40202f2c:	d63f0100 	blr	x8
    40202f30:	370003c0 	tbnz	w0, #0, 40202fa8 <<core::fmt::Formatter>::pad_integral+0x43c>
    40202f34:	2a1f03f3 	mov	w19, wzr
    40202f38:	f9000abc 	str	x28, [x21, #16]
    40202f3c:	1400001c 	b	40202fac <<core::fmt::Formatter>::pad_integral+0x440>
    40202f40:	2a1b03fc 	mov	w28, w27
    40202f44:	a94056b9 	ldp	x25, x21, [x21]
    40202f48:	2a1f03f4 	mov	w20, wzr
    40202f4c:	12003e88 	and	w8, w20, #0xffff
    40202f50:	6b3c211f 	cmp	w8, w28, uxth
    40202f54:	54000102 	b.cs	40202f74 <<core::fmt::Formatter>::pad_integral+0x408>  // b.hs, b.nlast
    40202f58:	f94012a8 	ldr	x8, [x21, #32]
    40202f5c:	12005341 	and	w1, w26, #0x1fffff
    40202f60:	aa1903e0 	mov	x0, x25
    40202f64:	11000694 	add	w20, w20, #0x1
    40202f68:	d63f0100 	blr	x8
    40202f6c:	3607ff00 	tbz	w0, #0, 40202f4c <<core::fmt::Formatter>::pad_integral+0x3e0>
    40202f70:	1400000e 	b	40202fa8 <<core::fmt::Formatter>::pad_integral+0x43c>
    40202f74:	aa1903e0 	mov	x0, x25
    40202f78:	aa1503e1 	mov	x1, x21
    40202f7c:	2a1803e2 	mov	w2, w24
    40202f80:	aa1703e3 	mov	x3, x23
    40202f84:	aa1603e4 	mov	x4, x22
    40202f88:	94000257 	bl	402038e4 <<core::fmt::Formatter>::pad_integral::write_prefix>
    40202f8c:	370000e0 	tbnz	w0, #0, 40202fa8 <<core::fmt::Formatter>::pad_integral+0x43c>
    40202f90:	f9400ea8 	ldr	x8, [x21, #24]
    40202f94:	f94007e1 	ldr	x1, [sp, #8]
    40202f98:	aa1903e0 	mov	x0, x25
    40202f9c:	aa1303e2 	mov	x2, x19
    40202fa0:	d63f0100 	blr	x8
    40202fa4:	36000160 	tbz	w0, #0, 40202fd0 <<core::fmt::Formatter>::pad_integral+0x464>
    40202fa8:	52800033 	mov	w19, #0x1                   	// #1
    40202fac:	2a1303e0 	mov	w0, w19
    40202fb0:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40202fb4:	a94557f6 	ldp	x22, x21, [sp, #80]
    40202fb8:	a9445ff8 	ldp	x24, x23, [sp, #64]
    40202fbc:	a94367fa 	ldp	x26, x25, [sp, #48]
    40202fc0:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40202fc4:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40202fc8:	9101c3ff 	add	sp, sp, #0x70
    40202fcc:	d65f03c0 	ret
    40202fd0:	2a1f03f4 	mov	w20, wzr
    40202fd4:	4b1c0376 	sub	w22, w27, w28
    40202fd8:	12003e88 	and	w8, w20, #0xffff
    40202fdc:	6b36211f 	cmp	w8, w22, uxth
    40202fe0:	1a9f27f3 	cset	w19, cc  // cc = lo, ul, last
    40202fe4:	54fffe42 	b.cs	40202fac <<core::fmt::Formatter>::pad_integral+0x440>  // b.hs, b.nlast
    40202fe8:	f94012a8 	ldr	x8, [x21, #32]
    40202fec:	12005341 	and	w1, w26, #0x1fffff
    40202ff0:	aa1903e0 	mov	x0, x25
    40202ff4:	11000694 	add	w20, w20, #0x1
    40202ff8:	d63f0100 	blr	x8
    40202ffc:	3607fee0 	tbz	w0, #0, 40202fd8 <<core::fmt::Formatter>::pad_integral+0x46c>
    40203000:	17ffffeb 	b	40202fac <<core::fmt::Formatter>::pad_integral+0x440>

0000000040203004 <core::option::unwrap_failed>:
    40203004:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    40203008:	910003fd 	mov	x29, sp
    4020300c:	aa0003e2 	mov	x2, x0
    40203010:	d503201f 	nop
    40203014:	10009560 	adr	x0, 402042c0 <anon.6df75e256c2768ac659efecb48cbbb77.8.llvm.9204665349642594691+0xd8>
    40203018:	52800561 	mov	w1, #0x2b                  	// #43
    4020301c:	9400000f 	bl	40203058 <core::panicking::panic>

0000000040203020 <core::panicking::panic_bounds_check>:
    40203020:	d10103ff 	sub	sp, sp, #0x40
    40203024:	a9037bfd 	stp	x29, x30, [sp, #48]
    40203028:	9100c3fd 	add	x29, sp, #0x30
    4020302c:	910023e8 	add	x8, sp, #0x8
    40203030:	d503201f 	nop
    40203034:	100049c9 	adr	x9, 4020396c <<u64 as core::fmt::Display>::fmt>
    40203038:	a90007e0 	stp	x0, x1, [sp]
    4020303c:	90000000 	adrp	x0, 40203000 <<core::fmt::Formatter>::pad_integral+0x494>
    40203040:	9139d800 	add	x0, x0, #0xe76
    40203044:	a90127e8 	stp	x8, x9, [sp, #16]
    40203048:	910003e8 	mov	x8, sp
    4020304c:	910043e1 	add	x1, sp, #0x10
    40203050:	a90227e8 	stp	x8, x9, [sp, #32]
    40203054:	94000006 	bl	4020306c <core::panicking::panic_fmt>

0000000040203058 <core::panicking::panic>:
    40203058:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4020305c:	910003fd 	mov	x29, sp
    40203060:	52800028 	mov	w8, #0x1                   	// #1
    40203064:	aa010501 	orr	x1, x8, x1, lsl #1
    40203068:	94000001 	bl	4020306c <core::panicking::panic_fmt>

000000004020306c <core::panicking::panic_fmt>:
    4020306c:	d10103ff 	sub	sp, sp, #0x40
    40203070:	a9037bfd 	stp	x29, x30, [sp, #48]
    40203074:	9100c3fd 	add	x29, sp, #0x30
    40203078:	910023e8 	add	x8, sp, #0x8
    4020307c:	a90087e0 	stp	x0, x1, [sp, #8]
    40203080:	910063e0 	add	x0, sp, #0x18
    40203084:	a9018be8 	stp	x8, x2, [sp, #24]
    40203088:	52800028 	mov	w8, #0x1                   	// #1
    4020308c:	790053e8 	strh	w8, [sp, #40]
    40203090:	97fffcfb 	bl	4020247c <__rustc::rust_begin_unwind>

0000000040203094 <core::str::count::do_count_chars>:
    40203094:	d10183ff 	sub	sp, sp, #0x60
    40203098:	fd0023ea 	str	d10, [sp, #64]
    4020309c:	6d0523e9 	stp	d9, d8, [sp, #80]
    402030a0:	91001c08 	add	x8, x0, #0x7
    402030a4:	927df10d 	and	x13, x8, #0xfffffffffffffff8
    402030a8:	cb0001ac 	sub	x12, x13, x0
    402030ac:	eb0c002b 	subs	x11, x1, x12
    402030b0:	540000e2 	b.cs	402030cc <core::str::count::do_count_chars+0x38>  // b.hs, b.nlast
    402030b4:	b4000721 	cbz	x1, 40203198 <core::str::count::do_count_chars+0x104>
    402030b8:	f100203f 	cmp	x1, #0x8
    402030bc:	54001b82 	b.cs	4020342c <core::str::count::do_count_chars+0x398>  // b.hs, b.nlast
    402030c0:	aa1f03e9 	mov	x9, xzr
    402030c4:	aa1f03e8 	mov	x8, xzr
    402030c8:	140001d2 	b	40203810 <core::str::count::do_count_chars+0x77c>
    402030cc:	d343fd69 	lsr	x9, x11, #3
    402030d0:	b4ffff29 	cbz	x9, 402030b4 <core::str::count::do_count_chars+0x20>
    402030d4:	eb0001bf 	cmp	x13, x0
    402030d8:	9240096a 	and	x10, x11, #0x7
    402030dc:	aa1f03e8 	mov	x8, xzr
    402030e0:	54000100 	b.eq	40203100 <core::str::count::do_count_chars+0x6c>  // b.none
    402030e4:	cb0d000d 	sub	x13, x0, x13
    402030e8:	aa0003ee 	mov	x14, x0
    402030ec:	38c015cf 	ldrsb	w15, [x14], #1
    402030f0:	310105ff 	cmn	w15, #0x41
    402030f4:	9a88d508 	cinc	x8, x8, gt
    402030f8:	b10005ad 	adds	x13, x13, #0x1
    402030fc:	54ffff83 	b.cc	402030ec <core::str::count::do_count_chars+0x58>  // b.lo, b.ul, b.last
    40203100:	8b0c000e 	add	x14, x0, x12
    40203104:	b400056a 	cbz	x10, 402031b0 <core::str::count::do_count_chars+0x11c>
    40203108:	927ded6b 	and	x11, x11, #0x7ffffffffffffff8
    4020310c:	8b0b01cc 	add	x12, x14, x11
    40203110:	39c0018b 	ldrsb	w11, [x12]
    40203114:	3101057f 	cmn	w11, #0x41
    40203118:	1a9fd7eb 	cset	w11, gt
    4020311c:	f100055f 	cmp	x10, #0x1
    40203120:	540004a0 	b.eq	402031b4 <core::str::count::do_count_chars+0x120>  // b.none
    40203124:	39c0058d 	ldrsb	w13, [x12, #1]
    40203128:	310105bf 	cmn	w13, #0x41
    4020312c:	9a8bd56b 	cinc	x11, x11, gt
    40203130:	f100095f 	cmp	x10, #0x2
    40203134:	54000400 	b.eq	402031b4 <core::str::count::do_count_chars+0x120>  // b.none
    40203138:	39c0098d 	ldrsb	w13, [x12, #2]
    4020313c:	310105bf 	cmn	w13, #0x41
    40203140:	9a8bd56b 	cinc	x11, x11, gt
    40203144:	f1000d5f 	cmp	x10, #0x3
    40203148:	54000360 	b.eq	402031b4 <core::str::count::do_count_chars+0x120>  // b.none
    4020314c:	39c00d8d 	ldrsb	w13, [x12, #3]
    40203150:	310105bf 	cmn	w13, #0x41
    40203154:	9a8bd56b 	cinc	x11, x11, gt
    40203158:	f100115f 	cmp	x10, #0x4
    4020315c:	540002c0 	b.eq	402031b4 <core::str::count::do_count_chars+0x120>  // b.none
    40203160:	39c0118d 	ldrsb	w13, [x12, #4]
    40203164:	310105bf 	cmn	w13, #0x41
    40203168:	9a8bd56b 	cinc	x11, x11, gt
    4020316c:	f100155f 	cmp	x10, #0x5
    40203170:	54000220 	b.eq	402031b4 <core::str::count::do_count_chars+0x120>  // b.none
    40203174:	39c0158d 	ldrsb	w13, [x12, #5]
    40203178:	310105bf 	cmn	w13, #0x41
    4020317c:	9a8bd56b 	cinc	x11, x11, gt
    40203180:	f100195f 	cmp	x10, #0x6
    40203184:	54000180 	b.eq	402031b4 <core::str::count::do_count_chars+0x120>  // b.none
    40203188:	39c0198a 	ldrsb	w10, [x12, #6]
    4020318c:	3101055f 	cmn	w10, #0x41
    40203190:	9a8bd56b 	cinc	x11, x11, gt
    40203194:	14000008 	b	402031b4 <core::str::count::do_count_chars+0x120>
    40203198:	aa1f03e8 	mov	x8, xzr
    4020319c:	6d4523e9 	ldp	d9, d8, [sp, #80]
    402031a0:	aa0803e0 	mov	x0, x8
    402031a4:	fd4023ea 	ldr	d10, [sp, #64]
    402031a8:	910183ff 	add	sp, sp, #0x60
    402031ac:	d65f03c0 	ret
    402031b0:	aa1f03eb 	mov	x11, xzr
    402031b4:	4f00e420 	movi	v0.16b, #0x1
    402031b8:	8b080168 	add	x8, x11, x8
    402031bc:	5280180a 	mov	w10, #0xc0                  	// #192
    402031c0:	b20083eb 	mov	x11, #0x1000100010001       	// #281479271743489
    402031c4:	1400000c 	b	402031f4 <core::str::count::do_count_chars+0x160>
    402031c8:	aa1f03f1 	mov	x17, xzr
    402031cc:	d348fe2f 	lsr	x15, x17, #8
    402031d0:	92009e30 	and	x16, x17, #0xff00ff00ff00ff
    402031d4:	8b0e018e 	add	x14, x12, x14
    402031d8:	cb0d0129 	sub	x9, x9, x13
    402031dc:	92009def 	and	x15, x15, #0xff00ff00ff00ff
    402031e0:	8b1001ef 	add	x15, x15, x16
    402031e4:	9b0b7df0 	mul	x16, x15, x11
    402031e8:	924005af 	and	x15, x13, #0x3
    402031ec:	8b50c108 	add	x8, x8, x16, lsr #48
    402031f0:	b5000d8f 	cbnz	x15, 402033a0 <core::str::count::do_count_chars+0x30c>
    402031f4:	b4fffd49 	cbz	x9, 4020319c <core::str::count::do_count_chars+0x108>
    402031f8:	f103013f 	cmp	x9, #0xc0
    402031fc:	aa0e03ec 	mov	x12, x14
    40203200:	9a8a312d 	csel	x13, x9, x10, cc  // cc = lo, ul, last
    40203204:	d37df1ae 	lsl	x14, x13, #3
    40203208:	f27b15d0 	ands	x16, x14, #0x7e0
    4020320c:	54fffde0 	b.eq	402031c8 <core::str::count::do_count_chars+0x134>  // b.none
    40203210:	d10081cf 	sub	x15, x14, #0x20
    40203214:	f10181ff 	cmp	x15, #0x60
    40203218:	54000082 	b.cs	40203228 <core::str::count::do_count_chars+0x194>  // b.hs, b.nlast
    4020321c:	aa1f03f1 	mov	x17, xzr
    40203220:	aa0c03ef 	mov	x15, x12
    40203224:	14000044 	b	40203334 <core::str::count::do_count_chars+0x2a0>
    40203228:	d345fdef 	lsr	x15, x15, #5
    4020322c:	6f00e401 	movi	v1.2d, #0x0
    40203230:	6f00e402 	movi	v2.2d, #0x0
    40203234:	91010180 	add	x0, x12, #0x40
    40203238:	910005f1 	add	x17, x15, #0x1
    4020323c:	927ee632 	and	x18, x17, #0xffffffffffffffc
    40203240:	927ee621 	and	x1, x17, #0xffffffffffffffc
    40203244:	8b12158f 	add	x15, x12, x18, lsl #5
    40203248:	d1010002 	sub	x2, x0, #0x40
    4020324c:	4c400c10 	ld4	{v16.2d-v19.2d}, [x0]
    40203250:	f1001021 	subs	x1, x1, #0x4
    40203254:	91020000 	add	x0, x0, #0x80
    40203258:	4c400c43 	ld4	{v3.2d-v6.2d}, [x2]
    4020325c:	6e205a07 	mvn	v7.16b, v16.16b
    40203260:	6e205a35 	mvn	v21.16b, v17.16b
    40203264:	6e205a5a 	mvn	v26.16b, v18.16b
    40203268:	6e205876 	mvn	v22.16b, v3.16b
    4020326c:	6e205897 	mvn	v23.16b, v4.16b
    40203270:	6e2058b8 	mvn	v24.16b, v5.16b
    40203274:	6f7a0614 	ushr	v20.2d, v16.2d, #6
    40203278:	6f7a0639 	ushr	v25.2d, v17.2d, #6
    4020327c:	6f7a065b 	ushr	v27.2d, v18.2d, #6
    40203280:	6f7a047c 	ushr	v28.2d, v3.2d, #6
    40203284:	6f7a049d 	ushr	v29.2d, v4.2d, #6
    40203288:	6f7a04be 	ushr	v30.2d, v5.2d, #6
    4020328c:	6f7906d6 	ushr	v22.2d, v22.2d, #7
    40203290:	6f7906f7 	ushr	v23.2d, v23.2d, #7
    40203294:	6f790718 	ushr	v24.2d, v24.2d, #7
    40203298:	6f7904e7 	ushr	v7.2d, v7.2d, #7
    4020329c:	6f7906b5 	ushr	v21.2d, v21.2d, #7
    402032a0:	6f79075a 	ushr	v26.2d, v26.2d, #7
    402032a4:	6e205a7f 	mvn	v31.16b, v19.16b
    402032a8:	6f7a0670 	ushr	v16.2d, v19.2d, #6
    402032ac:	6e2058d1 	mvn	v17.16b, v6.16b
    402032b0:	4ebc1ed2 	orr	v18.16b, v22.16b, v28.16b
    402032b4:	4ebd1ef3 	orr	v19.16b, v23.16b, v29.16b
    402032b8:	4ebe1f16 	orr	v22.16b, v24.16b, v30.16b
    402032bc:	4eb41ce7 	orr	v7.16b, v7.16b, v20.16b
    402032c0:	4eb91eb4 	orr	v20.16b, v21.16b, v25.16b
    402032c4:	4ebb1f55 	orr	v21.16b, v26.16b, v27.16b
    402032c8:	6f7a04c3 	ushr	v3.2d, v6.2d, #6
    402032cc:	6f7907e4 	ushr	v4.2d, v31.2d, #7
    402032d0:	6f790625 	ushr	v5.2d, v17.2d, #7
    402032d4:	4e201e46 	and	v6.16b, v18.16b, v0.16b
    402032d8:	4e201e71 	and	v17.16b, v19.16b, v0.16b
    402032dc:	4e201ed2 	and	v18.16b, v22.16b, v0.16b
    402032e0:	4e201ce7 	and	v7.16b, v7.16b, v0.16b
    402032e4:	4e201e93 	and	v19.16b, v20.16b, v0.16b
    402032e8:	4e201eb4 	and	v20.16b, v21.16b, v0.16b
    402032ec:	4eb01c84 	orr	v4.16b, v4.16b, v16.16b
    402032f0:	4ea31ca3 	orr	v3.16b, v5.16b, v3.16b
    402032f4:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    402032f8:	4ef18646 	add	v6.2d, v18.2d, v17.2d
    402032fc:	4ee284e2 	add	v2.2d, v7.2d, v2.2d
    40203300:	4ef38685 	add	v5.2d, v20.2d, v19.2d
    40203304:	4e201c63 	and	v3.16b, v3.16b, v0.16b
    40203308:	4e201c84 	and	v4.16b, v4.16b, v0.16b
    4020330c:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40203310:	4ee284a2 	add	v2.2d, v5.2d, v2.2d
    40203314:	4ee18461 	add	v1.2d, v3.2d, v1.2d
    40203318:	4ee28482 	add	v2.2d, v4.2d, v2.2d
    4020331c:	54fff961 	b.ne	40203248 <core::str::count::do_count_chars+0x1b4>  // b.any
    40203320:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40203324:	eb12023f 	cmp	x17, x18
    40203328:	5ef1b821 	addp	d1, v1.2d
    4020332c:	9e660031 	fmov	x17, d1
    40203330:	54fff4e0 	b.eq	402031cc <core::str::count::do_count_chars+0x138>  // b.none
    40203334:	8b100190 	add	x16, x12, x16
    40203338:	f9400df2 	ldr	x18, [x15, #24]
    4020333c:	f9001ff2 	str	x18, [sp, #56]
    40203340:	f94009f2 	ldr	x18, [x15, #16]
    40203344:	f9001bf2 	str	x18, [sp, #48]
    40203348:	f94005f2 	ldr	x18, [x15, #8]
    4020334c:	f90017f2 	str	x18, [sp, #40]
    40203350:	f84205f2 	ldr	x18, [x15], #32
    40203354:	eb1001ff 	cmp	x15, x16
    40203358:	f90013f2 	str	x18, [sp, #32]
    4020335c:	ad4107e2 	ldp	q2, q1, [sp, #32]
    40203360:	6e205823 	mvn	v3.16b, v1.16b
    40203364:	6e205844 	mvn	v4.16b, v2.16b
    40203368:	6f7a0421 	ushr	v1.2d, v1.2d, #6
    4020336c:	6f7a0442 	ushr	v2.2d, v2.2d, #6
    40203370:	6f790463 	ushr	v3.2d, v3.2d, #7
    40203374:	6f790484 	ushr	v4.2d, v4.2d, #7
    40203378:	4ea21c82 	orr	v2.16b, v4.16b, v2.16b
    4020337c:	4ea11c61 	orr	v1.16b, v3.16b, v1.16b
    40203380:	4e201c21 	and	v1.16b, v1.16b, v0.16b
    40203384:	4e201c42 	and	v2.16b, v2.16b, v0.16b
    40203388:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    4020338c:	5ef1b821 	addp	d1, v1.2d
    40203390:	9e660032 	fmov	x18, d1
    40203394:	8b110251 	add	x17, x18, x17
    40203398:	54fffd01 	b.ne	40203338 <core::str::count::do_count_chars+0x2a4>  // b.any
    4020339c:	17ffff8c 	b	402031cc <core::str::count::do_count_chars+0x138>
    402033a0:	927e15a9 	and	x9, x13, #0xfc
    402033a4:	f10005ff 	cmp	x15, #0x1
    402033a8:	8b090d8a 	add	x10, x12, x9, lsl #3
    402033ac:	f9400149 	ldr	x9, [x10]
    402033b0:	aa2903eb 	mvn	x11, x9
    402033b4:	d347fd6b 	lsr	x11, x11, #7
    402033b8:	aa491969 	orr	x9, x11, x9, lsr #6
    402033bc:	9200c129 	and	x9, x9, #0x101010101010101
    402033c0:	540001e0 	b.eq	402033fc <core::str::count::do_count_chars+0x368>  // b.none
    402033c4:	f940054b 	ldr	x11, [x10, #8]
    402033c8:	f10009ff 	cmp	x15, #0x2
    402033cc:	aa2b03ec 	mvn	x12, x11
    402033d0:	d347fd8c 	lsr	x12, x12, #7
    402033d4:	aa4b198b 	orr	x11, x12, x11, lsr #6
    402033d8:	9200c16b 	and	x11, x11, #0x101010101010101
    402033dc:	8b090169 	add	x9, x11, x9
    402033e0:	540000e0 	b.eq	402033fc <core::str::count::do_count_chars+0x368>  // b.none
    402033e4:	f940094a 	ldr	x10, [x10, #16]
    402033e8:	aa2a03eb 	mvn	x11, x10
    402033ec:	d347fd6b 	lsr	x11, x11, #7
    402033f0:	aa4a196a 	orr	x10, x11, x10, lsr #6
    402033f4:	9200c14a 	and	x10, x10, #0x101010101010101
    402033f8:	8b090149 	add	x9, x10, x9
    402033fc:	d348fd2a 	lsr	x10, x9, #8
    40203400:	92009d29 	and	x9, x9, #0xff00ff00ff00ff
    40203404:	92009d4a 	and	x10, x10, #0xff00ff00ff00ff
    40203408:	8b090149 	add	x9, x10, x9
    4020340c:	b20083ea 	mov	x10, #0x1000100010001       	// #281479271743489
    40203410:	9b0a7d29 	mul	x9, x9, x10
    40203414:	8b49c108 	add	x8, x8, x9, lsr #48
    40203418:	6d4523e9 	ldp	d9, d8, [sp, #80]
    4020341c:	aa0803e0 	mov	x0, x8
    40203420:	fd4023ea 	ldr	d10, [sp, #64]
    40203424:	910183ff 	add	sp, sp, #0x60
    40203428:	d65f03c0 	ret
    4020342c:	f100803f 	cmp	x1, #0x20
    40203430:	54000082 	b.cs	40203440 <core::str::count::do_count_chars+0x3ac>  // b.hs, b.nlast
    40203434:	aa1f03e9 	mov	x9, xzr
    40203438:	aa1f03e8 	mov	x8, xzr
    4020343c:	140000bc 	b	4020372c <core::str::count::do_count_chars+0x698>
    40203440:	6f00e400 	movi	v0.2d, #0x0
    40203444:	4f05e7e3 	movi	v3.16b, #0xbf
    40203448:	52800028 	mov	w8, #0x1                   	// #1
    4020344c:	6f00e402 	movi	v2.2d, #0x0
    40203450:	6f00e407 	movi	v7.2d, #0x0
    40203454:	927d042a 	and	x10, x1, #0x18
    40203458:	6f00e401 	movi	v1.2d, #0x0
    4020345c:	6f00e412 	movi	v18.2d, #0x0
    40203460:	927be829 	and	x9, x1, #0xffffffffffffffe0
    40203464:	6f00e405 	movi	v5.2d, #0x0
    40203468:	6f00e406 	movi	v6.2d, #0x0
    4020346c:	927be82b 	and	x11, x1, #0xffffffffffffffe0
    40203470:	6f00e404 	movi	v4.2d, #0x0
    40203474:	6f00e416 	movi	v22.2d, #0x0
    40203478:	6f00e411 	movi	v17.2d, #0x0
    4020347c:	6f00e410 	movi	v16.2d, #0x0
    40203480:	6f00e417 	movi	v23.2d, #0x0
    40203484:	6f00e414 	movi	v20.2d, #0x0
    40203488:	6f00e415 	movi	v21.2d, #0x0
    4020348c:	6f00e413 	movi	v19.2d, #0x0
    40203490:	6f00e418 	movi	v24.2d, #0x0
    40203494:	4e080d19 	dup	v25.2d, x8
    40203498:	91004008 	add	x8, x0, #0x10
    4020349c:	aa0803ec 	mov	x12, x8
    402034a0:	385f1112 	ldurb	w18, [x8, #-15]
    402034a4:	385f5102 	ldurb	w2, [x8, #-11]
    402034a8:	385f0d8d 	ldrb	w13, [x12, #-16]!
    402034ac:	aa0c03ef 	mov	x15, x12
    402034b0:	3940098e 	ldrb	w14, [x12, #2]
    402034b4:	38404df0 	ldrb	w16, [x15, #4]!
    402034b8:	394009f1 	ldrb	w17, [x15, #2]
    402034bc:	39400d83 	ldrb	w3, [x12, #3]
    402034c0:	39400def 	ldrb	w15, [x15, #3]
    402034c4:	d370bdce 	lsl	x14, x14, #16
    402034c8:	aa1221ad 	orr	x13, x13, x18, lsl #8
    402034cc:	2a022210 	orr	w16, w16, w2, lsl #8
    402034d0:	53103e31 	lsl	w17, w17, #16
    402034d4:	f100816b 	subs	x11, x11, #0x20
    402034d8:	aa0361ce 	orr	x14, x14, x3, lsl #24
    402034dc:	2a0f622f 	orr	w15, w17, w15, lsl #24
    402034e0:	aa0d01cd 	orr	x13, x14, x13
    402034e4:	2a1001ee 	orr	w14, w15, w16
    402034e8:	aa0e81ad 	orr	x13, x13, x14, lsl #32
    402034ec:	f9000bed 	str	x13, [sp, #16]
    402034f0:	aa0c03ed 	mov	x13, x12
    402034f4:	38408dae 	ldrb	w14, [x13, #8]!
    402034f8:	39400daf 	ldrb	w15, [x13, #3]
    402034fc:	394009b0 	ldrb	w16, [x13, #2]
    40203500:	38404db1 	ldrb	w17, [x13, #4]!
    40203504:	394009b2 	ldrb	w18, [x13, #2]
    40203508:	39402582 	ldrb	w2, [x12, #9]
    4020350c:	3940358c 	ldrb	w12, [x12, #13]
    40203510:	39400dad 	ldrb	w13, [x13, #3]
    40203514:	d370be10 	lsl	x16, x16, #16
    40203518:	53103e52 	lsl	w18, w18, #16
    4020351c:	aa0221ce 	orr	x14, x14, x2, lsl #8
    40203520:	2a0c222c 	orr	w12, w17, w12, lsl #8
    40203524:	aa0f620f 	orr	x15, x16, x15, lsl #24
    40203528:	2a0d624d 	orr	w13, w18, w13, lsl #24
    4020352c:	aa0e01ee 	orr	x14, x15, x14
    40203530:	2a0c01ac 	orr	w12, w13, w12
    40203534:	aa0c81cc 	orr	x12, x14, x12, lsl #32
    40203538:	f9000fec 	str	x12, [sp, #24]
    4020353c:	aa0803ec 	mov	x12, x8
    40203540:	3940090e 	ldrb	w14, [x8, #2]
    40203544:	38404d8f 	ldrb	w15, [x12, #4]!
    40203548:	39400990 	ldrb	w16, [x12, #2]
    4020354c:	3940050d 	ldrb	w13, [x8, #1]
    40203550:	39400111 	ldrb	w17, [x8]
    40203554:	39400d12 	ldrb	w18, [x8, #3]
    40203558:	39401502 	ldrb	w2, [x8, #5]
    4020355c:	39400d8c 	ldrb	w12, [x12, #3]
    40203560:	d370bdce 	lsl	x14, x14, #16
    40203564:	53103e10 	lsl	w16, w16, #16
    40203568:	aa0d222d 	orr	x13, x17, x13, lsl #8
    4020356c:	2a0221ef 	orr	w15, w15, w2, lsl #8
    40203570:	3dc007fa 	ldr	q26, [sp, #16]
    40203574:	aa1261ce 	orr	x14, x14, x18, lsl #24
    40203578:	2a0c620c 	orr	w12, w16, w12, lsl #24
    4020357c:	4e23375a 	cmgt	v26.16b, v26.16b, v3.16b
    40203580:	aa0d01cd 	orr	x13, x14, x13
    40203584:	2a0f018c 	orr	w12, w12, w15
    40203588:	aa0c81ac 	orr	x12, x13, x12, lsl #32
    4020358c:	aa0803ed 	mov	x13, x8
    40203590:	6f08a75b 	uxtl2	v27.8h, v26.16b
    40203594:	2f08a75a 	uxtl	v26.8h, v26.8b
    40203598:	f90003ec 	str	x12, [sp]
    4020359c:	38408dac 	ldrb	w12, [x13, #8]!
    402035a0:	39400dae 	ldrb	w14, [x13, #3]
    402035a4:	394009af 	ldrb	w15, [x13, #2]
    402035a8:	38404db0 	ldrb	w16, [x13, #4]!
    402035ac:	394009b1 	ldrb	w17, [x13, #2]
    402035b0:	39402512 	ldrb	w18, [x8, #9]
    402035b4:	39403502 	ldrb	w2, [x8, #13]
    402035b8:	39400dad 	ldrb	w13, [x13, #3]
    402035bc:	d370bdef 	lsl	x15, x15, #16
    402035c0:	6f10a77c 	uxtl2	v28.4s, v27.8h
    402035c4:	53103e31 	lsl	w17, w17, #16
    402035c8:	aa12218c 	orr	x12, x12, x18, lsl #8
    402035cc:	2a022210 	orr	w16, w16, w2, lsl #8
    402035d0:	aa0e61ee 	orr	x14, x15, x14, lsl #24
    402035d4:	2f10a77b 	uxtl	v27.4s, v27.4h
    402035d8:	2f10a75e 	uxtl	v30.4s, v26.4h
    402035dc:	2a0d622d 	orr	w13, w17, w13, lsl #24
    402035e0:	6f20a79d 	uxtl2	v29.2d, v28.4s
    402035e4:	6f10a75a 	uxtl2	v26.4s, v26.8h
    402035e8:	aa0c01cc 	orr	x12, x14, x12
    402035ec:	2f20a79c 	uxtl	v28.2d, v28.2s
    402035f0:	91008108 	add	x8, x8, #0x20
    402035f4:	2a1001ad 	orr	w13, w13, w16
    402035f8:	6f20a768 	uxtl2	v8.2d, v27.4s
    402035fc:	6f20a7c9 	uxtl2	v9.2d, v30.4s
    40203600:	aa0d818c 	orr	x12, x12, x13, lsl #32
    40203604:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    40203608:	6f20a74a 	uxtl2	v10.2d, v26.4s
    4020360c:	2f20a75a 	uxtl	v26.2d, v26.2s
    40203610:	2f20a77b 	uxtl	v27.2d, v27.2s
    40203614:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    40203618:	f90007ec 	str	x12, [sp, #8]
    4020361c:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    40203620:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    40203624:	3dc003ff 	ldr	q31, [sp]
    40203628:	4efd86d6 	add	v22.2d, v22.2d, v29.2d
    4020362c:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40203630:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    40203634:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    40203638:	4efc8484 	add	v4.2d, v4.2d, v28.2d
    4020363c:	4e2337ff 	cmgt	v31.16b, v31.16b, v3.16b
    40203640:	4ee884c6 	add	v6.2d, v6.2d, v8.2d
    40203644:	2f20a7de 	uxtl	v30.2d, v30.2s
    40203648:	4eea8652 	add	v18.2d, v18.2d, v10.2d
    4020364c:	4ee984e7 	add	v7.2d, v7.2d, v9.2d
    40203650:	4efa8421 	add	v1.2d, v1.2d, v26.2d
    40203654:	4efb84a5 	add	v5.2d, v5.2d, v27.2d
    40203658:	6f08a7fd 	uxtl2	v29.8h, v31.16b
    4020365c:	2f08a7ff 	uxtl	v31.8h, v31.8b
    40203660:	4e391fde 	and	v30.16b, v30.16b, v25.16b
    40203664:	6f10a7bc 	uxtl2	v28.4s, v29.8h
    40203668:	6f10a7e8 	uxtl2	v8.4s, v31.8h
    4020366c:	2f10a7bd 	uxtl	v29.4s, v29.4h
    40203670:	2f10a7fa 	uxtl	v26.4s, v31.4h
    40203674:	4efe8442 	add	v2.2d, v2.2d, v30.2d
    40203678:	2f20a79b 	uxtl	v27.2d, v28.2s
    4020367c:	6f20a79c 	uxtl2	v28.2d, v28.4s
    40203680:	2f20a7bf 	uxtl	v31.2d, v29.2s
    40203684:	6f20a509 	uxtl2	v9.2d, v8.4s
    40203688:	6f20a7bd 	uxtl2	v29.2d, v29.4s
    4020368c:	2f20a74a 	uxtl	v10.2d, v26.2s
    40203690:	6f20a75a 	uxtl2	v26.2d, v26.4s
    40203694:	2f20a508 	uxtl	v8.2d, v8.2s
    40203698:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    4020369c:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    402036a0:	4e391fff 	and	v31.16b, v31.16b, v25.16b
    402036a4:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    402036a8:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    402036ac:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    402036b0:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    402036b4:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    402036b8:	4efc8718 	add	v24.2d, v24.2d, v28.2d
    402036bc:	4efb8673 	add	v19.2d, v19.2d, v27.2d
    402036c0:	4eff8694 	add	v20.2d, v20.2d, v31.2d
    402036c4:	4efd86b5 	add	v21.2d, v21.2d, v29.2d
    402036c8:	4ee986f7 	add	v23.2d, v23.2d, v9.2d
    402036cc:	4eea8631 	add	v17.2d, v17.2d, v10.2d
    402036d0:	4ee88610 	add	v16.2d, v16.2d, v8.2d
    402036d4:	4efa8400 	add	v0.2d, v0.2d, v26.2d
    402036d8:	54ffee21 	b.ne	4020349c <core::str::count::do_count_chars+0x408>  // b.any
    402036dc:	4ef286e3 	add	v3.2d, v23.2d, v18.2d
    402036e0:	4ef68712 	add	v18.2d, v24.2d, v22.2d
    402036e4:	eb09003f 	cmp	x1, x9
    402036e8:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    402036ec:	4ee28622 	add	v2.2d, v17.2d, v2.2d
    402036f0:	4ee58685 	add	v5.2d, v20.2d, v5.2d
    402036f4:	4ee686a6 	add	v6.2d, v21.2d, v6.2d
    402036f8:	4ee18601 	add	v1.2d, v16.2d, v1.2d
    402036fc:	4ee48664 	add	v4.2d, v19.2d, v4.2d
    40203700:	4ef28463 	add	v3.2d, v3.2d, v18.2d
    40203704:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40203708:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    4020370c:	4ee68400 	add	v0.2d, v0.2d, v6.2d
    40203710:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40203714:	4ee38400 	add	v0.2d, v0.2d, v3.2d
    40203718:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    4020371c:	5ef1b800 	addp	d0, v0.2d
    40203720:	9e660008 	fmov	x8, d0
    40203724:	54ffd3c0 	b.eq	4020319c <core::str::count::do_count_chars+0x108>  // b.none
    40203728:	b400074a 	cbz	x10, 40203810 <core::str::count::do_count_chars+0x77c>
    4020372c:	6f00e400 	movi	v0.2d, #0x0
    40203730:	6f00e401 	movi	v1.2d, #0x0
    40203734:	aa0903ea 	mov	x10, x9
    40203738:	0f05e7e2 	movi	v2.8b, #0xbf
    4020373c:	6f00e403 	movi	v3.2d, #0x0
    40203740:	927df029 	and	x9, x1, #0xfffffffffffffff8
    40203744:	6f00e404 	movi	v4.2d, #0x0
    40203748:	4e081d00 	mov	v0.d[0], x8
    4020374c:	52800028 	mov	w8, #0x1                   	// #1
    40203750:	4e080d05 	dup	v5.2d, x8
    40203754:	cb090148 	sub	x8, x10, x9
    40203758:	8b0a000a 	add	x10, x0, x10
    4020375c:	aa0a03ed 	mov	x13, x10
    40203760:	3940094c 	ldrb	w12, [x10, #2]
    40203764:	3940054b 	ldrb	w11, [x10, #1]
    40203768:	38404dae 	ldrb	w14, [x13, #4]!
    4020376c:	394009af 	ldrb	w15, [x13, #2]
    40203770:	39400150 	ldrb	w16, [x10]
    40203774:	39400d51 	ldrb	w17, [x10, #3]
    40203778:	d370bd8c 	lsl	x12, x12, #16
    4020377c:	39401552 	ldrb	w18, [x10, #5]
    40203780:	39400dad 	ldrb	w13, [x13, #3]
    40203784:	53103def 	lsl	w15, w15, #16
    40203788:	aa0b220b 	orr	x11, x16, x11, lsl #8
    4020378c:	aa11618c 	orr	x12, x12, x17, lsl #24
    40203790:	b1002108 	adds	x8, x8, #0x8
    40203794:	2a1221ce 	orr	w14, w14, w18, lsl #8
    40203798:	2a0d61ed 	orr	w13, w15, w13, lsl #24
    4020379c:	9100214a 	add	x10, x10, #0x8
    402037a0:	aa0b018b 	orr	x11, x12, x11
    402037a4:	2a0e01ac 	orr	w12, w13, w14
    402037a8:	aa0c816b 	orr	x11, x11, x12, lsl #32
    402037ac:	9e670166 	fmov	d6, x11
    402037b0:	0e2234c6 	cmgt	v6.8b, v6.8b, v2.8b
    402037b4:	2f08a4c6 	uxtl	v6.8h, v6.8b
    402037b8:	6f10a4c7 	uxtl2	v7.4s, v6.8h
    402037bc:	2f10a4c6 	uxtl	v6.4s, v6.4h
    402037c0:	6f20a4f0 	uxtl2	v16.2d, v7.4s
    402037c4:	2f20a4d1 	uxtl	v17.2d, v6.2s
    402037c8:	6f20a4c6 	uxtl2	v6.2d, v6.4s
    402037cc:	2f20a4e7 	uxtl	v7.2d, v7.2s
    402037d0:	4e251e10 	and	v16.16b, v16.16b, v5.16b
    402037d4:	4e251e31 	and	v17.16b, v17.16b, v5.16b
    402037d8:	4e251cc6 	and	v6.16b, v6.16b, v5.16b
    402037dc:	4e251ce7 	and	v7.16b, v7.16b, v5.16b
    402037e0:	4ef08484 	add	v4.2d, v4.2d, v16.2d
    402037e4:	4ee68463 	add	v3.2d, v3.2d, v6.2d
    402037e8:	4ef18400 	add	v0.2d, v0.2d, v17.2d
    402037ec:	4ee78421 	add	v1.2d, v1.2d, v7.2d
    402037f0:	54fffb61 	b.ne	4020375c <core::str::count::do_count_chars+0x6c8>  // b.any
    402037f4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    402037f8:	4ee48461 	add	v1.2d, v3.2d, v4.2d
    402037fc:	eb09003f 	cmp	x1, x9
    40203800:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    40203804:	5ef1b800 	addp	d0, v0.2d
    40203808:	9e660008 	fmov	x8, d0
    4020380c:	54ffcc80 	b.eq	4020319c <core::str::count::do_count_chars+0x108>  // b.none
    40203810:	cb09002a 	sub	x10, x1, x9
    40203814:	8b090009 	add	x9, x0, x9
    40203818:	38c0152b 	ldrsb	w11, [x9], #1
    4020381c:	3101057f 	cmn	w11, #0x41
    40203820:	9a88d508 	cinc	x8, x8, gt
    40203824:	f100054a 	subs	x10, x10, #0x1
    40203828:	54ffff81 	b.ne	40203818 <core::str::count::do_count_chars+0x784>  // b.any
    4020382c:	17fffe5c 	b	4020319c <core::str::count::do_count_chars+0x108>

0000000040203830 <core::slice::index::slice_index_fail>:
    40203830:	d10103ff 	sub	sp, sp, #0x40
    40203834:	a9037bfd 	stp	x29, x30, [sp, #48]
    40203838:	9100c3fd 	add	x29, sp, #0x30
    4020383c:	eb02001f 	cmp	x0, x2
    40203840:	540001a9 	b.ls	40203874 <core::slice::index::slice_index_fail+0x44>  // b.plast
    40203844:	910003e8 	mov	x8, sp
    40203848:	d503201f 	nop
    4020384c:	10000909 	adr	x9, 4020396c <<u64 as core::fmt::Display>::fmt>
    40203850:	a9000be0 	stp	x0, x2, [sp]
    40203854:	90000000 	adrp	x0, 40203000 <<core::fmt::Formatter>::pad_integral+0x494>
    40203858:	913bf400 	add	x0, x0, #0xefd
    4020385c:	a90127e8 	stp	x8, x9, [sp, #16]
    40203860:	910023e8 	add	x8, sp, #0x8
    40203864:	a90227e8 	stp	x8, x9, [sp, #32]
    40203868:	910043e1 	add	x1, sp, #0x10
    4020386c:	aa0303e2 	mov	x2, x3
    40203870:	97fffdff 	bl	4020306c <core::panicking::panic_fmt>
    40203874:	eb02003f 	cmp	x1, x2
    40203878:	540001e8 	b.hi	402038b4 <core::slice::index::slice_index_fail+0x84>  // b.pmore
    4020387c:	eb01001f 	cmp	x0, x1
    40203880:	540001a9 	b.ls	402038b4 <core::slice::index::slice_index_fail+0x84>  // b.plast
    40203884:	910003e8 	mov	x8, sp
    40203888:	d503201f 	nop
    4020388c:	10000709 	adr	x9, 4020396c <<u64 as core::fmt::Display>::fmt>
    40203890:	a90127e8 	stp	x8, x9, [sp, #16]
    40203894:	910023e8 	add	x8, sp, #0x8
    40203898:	a90007e0 	stp	x0, x1, [sp]
    4020389c:	90000000 	adrp	x0, 40203000 <<core::fmt::Formatter>::pad_integral+0x494>
    402038a0:	91393800 	add	x0, x0, #0xe4e
    402038a4:	a90227e8 	stp	x8, x9, [sp, #32]
    402038a8:	910043e1 	add	x1, sp, #0x10
    402038ac:	aa0303e2 	mov	x2, x3
    402038b0:	97fffdef 	bl	4020306c <core::panicking::panic_fmt>
    402038b4:	910003e8 	mov	x8, sp
    402038b8:	d503201f 	nop
    402038bc:	10000589 	adr	x9, 4020396c <<u64 as core::fmt::Display>::fmt>
    402038c0:	a90127e8 	stp	x8, x9, [sp, #16]
    402038c4:	910023e8 	add	x8, sp, #0x8
    402038c8:	90000000 	adrp	x0, 40203000 <<core::fmt::Formatter>::pad_integral+0x494>
    402038cc:	913ab400 	add	x0, x0, #0xead
    402038d0:	a9000be1 	stp	x1, x2, [sp]
    402038d4:	a90227e8 	stp	x8, x9, [sp, #32]
    402038d8:	910043e1 	add	x1, sp, #0x10
    402038dc:	aa0303e2 	mov	x2, x3
    402038e0:	97fffde3 	bl	4020306c <core::panicking::panic_fmt>

00000000402038e4 <<core::fmt::Formatter>::pad_integral::write_prefix>:
    402038e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    402038e8:	a90157f6 	stp	x22, x21, [sp, #16]
    402038ec:	a9024ff4 	stp	x20, x19, [sp, #32]
    402038f0:	910003fd 	mov	x29, sp
    402038f4:	aa0403f3 	mov	x19, x4
    402038f8:	aa0303f4 	mov	x20, x3
    402038fc:	aa0103f5 	mov	x21, x1
    40203900:	7144405f 	cmp	w2, #0x110, lsl #12
    40203904:	540001a0 	b.eq	40203938 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>  // b.none
    40203908:	f94012a8 	ldr	x8, [x21, #32]
    4020390c:	2a0203e1 	mov	w1, w2
    40203910:	aa0003f6 	mov	x22, x0
    40203914:	d63f0100 	blr	x8
    40203918:	2a0003e8 	mov	w8, w0
    4020391c:	aa1603e0 	mov	x0, x22
    40203920:	360000c8 	tbz	w8, #0, 40203938 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>
    40203924:	52800020 	mov	w0, #0x1                   	// #1
    40203928:	a9424ff4 	ldp	x20, x19, [sp, #32]
    4020392c:	a94157f6 	ldp	x22, x21, [sp, #16]
    40203930:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40203934:	d65f03c0 	ret
    40203938:	b4000114 	cbz	x20, 40203958 <<core::fmt::Formatter>::pad_integral::write_prefix+0x74>
    4020393c:	f9400ea3 	ldr	x3, [x21, #24]
    40203940:	aa1403e1 	mov	x1, x20
    40203944:	aa1303e2 	mov	x2, x19
    40203948:	a9424ff4 	ldp	x20, x19, [sp, #32]
    4020394c:	a94157f6 	ldp	x22, x21, [sp, #16]
    40203950:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40203954:	d61f0060 	br	x3
    40203958:	2a1f03e0 	mov	w0, wzr
    4020395c:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40203960:	a94157f6 	ldp	x22, x21, [sp, #16]
    40203964:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40203968:	d65f03c0 	ret

000000004020396c <<u64 as core::fmt::Display>::fmt>:
    4020396c:	d100c3ff 	sub	sp, sp, #0x30
    40203970:	a9027bfd 	stp	x29, x30, [sp, #32]
    40203974:	910083fd 	add	x29, sp, #0x20
    40203978:	f9400009 	ldr	x9, [x0]
    4020397c:	d503201f 	nop
    40203980:	70004b48 	adr	x8, 402042eb <anon.6df75e256c2768ac659efecb48cbbb77.8.llvm.9204665349642594691+0x103>
    40203984:	f10fa13f 	cmp	x9, #0x3e8
    40203988:	540004e3 	b.cc	40203a24 <<u64 as core::fmt::Display>::fmt+0xb8>  // b.lo, b.ul, b.last
    4020398c:	d28b296c 	mov	x12, #0x594b                	// #22859
    40203990:	910033ea 	add	x10, sp, #0xc
    40203994:	5292cff1 	mov	w17, #0x967f                	// #38527
    40203998:	f2a710cc 	movk	x12, #0x3886, lsl #16
    4020399c:	9280026b 	mov	x11, #0xffffffffffffffec    	// #-20
    402039a0:	5284e20d 	mov	w13, #0x2710                	// #10000
    402039a4:	f2d8bacc 	movk	x12, #0xc5d6, lsl #32
    402039a8:	52828f6e 	mov	w14, #0x147b                	// #5243
    402039ac:	91004d4f 	add	x15, x10, #0x13
    402039b0:	f2e68dac 	movk	x12, #0x346d, lsl #48
    402039b4:	52800c90 	mov	w16, #0x64                  	// #100
    402039b8:	72a01311 	movk	w17, #0x98, lsl #16
    402039bc:	aa0903ea 	mov	x10, x9
    402039c0:	aa0a03f2 	mov	x18, x10
    402039c4:	9bcc7d4a 	umulh	x10, x10, x12
    402039c8:	9100116b 	add	x11, x11, #0x4
    402039cc:	eb11025f 	cmp	x18, x17
    402039d0:	d34bfd4a 	lsr	x10, x10, #11
    402039d4:	1b0dc940 	msub	w0, w10, w13, w18
    402039d8:	53023c02 	ubfx	w2, w0, #2, #14
    402039dc:	1b0e7c42 	mul	w2, w2, w14
    402039e0:	53117c42 	lsr	w2, w2, #17
    402039e4:	1b108040 	msub	w0, w2, w16, w0
    402039e8:	8b224502 	add	x2, x8, w2, uxtw #1
    402039ec:	39400043 	ldrb	w3, [x2]
    402039f0:	39400442 	ldrb	w2, [x2, #1]
    402039f4:	8b202500 	add	x0, x8, w0, uxth #1
    402039f8:	381fd1e3 	sturb	w3, [x15, #-3]
    402039fc:	39400003 	ldrb	w3, [x0]
    40203a00:	39400400 	ldrb	w0, [x0, #1]
    40203a04:	381fe1e2 	sturb	w2, [x15, #-2]
    40203a08:	381ff1e3 	sturb	w3, [x15, #-1]
    40203a0c:	381fc5e0 	strb	w0, [x15], #-4
    40203a10:	54fffd88 	b.hi	402039c0 <<u64 as core::fmt::Display>::fmt+0x54>  // b.pmore
    40203a14:	cb0b03eb 	neg	x11, x11
    40203a18:	f100255f 	cmp	x10, #0x9
    40203a1c:	540000c8 	b.hi	40203a34 <<u64 as core::fmt::Display>::fmt+0xc8>  // b.pmore
    40203a20:	14000015 	b	40203a74 <<u64 as core::fmt::Display>::fmt+0x108>
    40203a24:	5280028b 	mov	w11, #0x14                  	// #20
    40203a28:	aa0903ea 	mov	x10, x9
    40203a2c:	f100253f 	cmp	x9, #0x9
    40203a30:	54000229 	b.ls	40203a74 <<u64 as core::fmt::Display>::fmt+0x108>  // b.plast
    40203a34:	53023d4c 	ubfx	w12, w10, #2, #14
    40203a38:	52828f6d 	mov	w13, #0x147b                	// #5243
    40203a3c:	910033ef 	add	x15, sp, #0xc
    40203a40:	1b0d7d8c 	mul	w12, w12, w13
    40203a44:	52800c8d 	mov	w13, #0x64                  	// #100
    40203a48:	53117d8c 	lsr	w12, w12, #17
    40203a4c:	1b0da98a 	msub	w10, w12, w13, w10
    40203a50:	d100096d 	sub	x13, x11, #0x2
    40203a54:	8b0b01eb 	add	x11, x15, x11
    40203a58:	8b2a250a 	add	x10, x8, w10, uxth #1
    40203a5c:	3940014e 	ldrb	w14, [x10]
    40203a60:	3940054a 	ldrb	w10, [x10, #1]
    40203a64:	382d69ee 	strb	w14, [x15, x13]
    40203a68:	381ff16a 	sturb	w10, [x11, #-1]
    40203a6c:	aa0c03ea 	mov	x10, x12
    40203a70:	aa0d03eb 	mov	x11, x13
    40203a74:	b4000049 	cbz	x9, 40203a7c <<u64 as core::fmt::Display>::fmt+0x110>
    40203a78:	b40000ca 	cbz	x10, 40203a90 <<u64 as core::fmt::Display>::fmt+0x124>
    40203a7c:	8b0a0508 	add	x8, x8, x10, lsl #1
    40203a80:	d100056b 	sub	x11, x11, #0x1
    40203a84:	910033e9 	add	x9, sp, #0xc
    40203a88:	39400508 	ldrb	w8, [x8, #1]
    40203a8c:	382b6928 	strb	w8, [x9, x11]
    40203a90:	52800288 	mov	w8, #0x14                  	// #20
    40203a94:	aa0103e0 	mov	x0, x1
    40203a98:	52800021 	mov	w1, #0x1                   	// #1
    40203a9c:	cb0b0105 	sub	x5, x8, x11
    40203aa0:	910033e8 	add	x8, sp, #0xc
    40203aa4:	52800022 	mov	w2, #0x1                   	// #1
    40203aa8:	8b0b0104 	add	x4, x8, x11
    40203aac:	aa1f03e3 	mov	x3, xzr
    40203ab0:	97fffc2f 	bl	40202b6c <<core::fmt::Formatter>::pad_integral>
    40203ab4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40203ab8:	9100c3ff 	add	sp, sp, #0x30
    40203abc:	d65f03c0 	ret

0000000040203ac0 <memcpy>:
    40203ac0:	f100405f 	cmp	x2, #0x10
    40203ac4:	54000723 	b.cc	40203ba8 <memcpy+0xe8>  // b.lo, b.ul, b.last
    40203ac8:	cb0003ec 	neg	x12, x0
    40203acc:	92400988 	and	x8, x12, #0x7
    40203ad0:	8b080009 	add	x9, x0, x8
    40203ad4:	eb09001f 	cmp	x0, x9
    40203ad8:	54000422 	b.cs	40203b5c <memcpy+0x9c>  // b.hs, b.nlast
    40203adc:	f100111f 	cmp	x8, #0x4
    40203ae0:	aa0003ea 	mov	x10, x0
    40203ae4:	aa0103eb 	mov	x11, x1
    40203ae8:	54000323 	b.cc	40203b4c <memcpy+0x8c>  // b.lo, b.ul, b.last
    40203aec:	cb01000a 	sub	x10, x0, x1
    40203af0:	aa0103eb 	mov	x11, x1
    40203af4:	f100815f 	cmp	x10, #0x20
    40203af8:	aa0003ea 	mov	x10, x0
    40203afc:	54000283 	b.cc	40203b4c <memcpy+0x8c>  // b.lo, b.ul, b.last
    40203b00:	927e018c 	and	x12, x12, #0x4
    40203b04:	aa0003ed 	mov	x13, x0
    40203b08:	aa0103ee 	mov	x14, x1
    40203b0c:	8b0c000a 	add	x10, x0, x12
    40203b10:	8b0c002b 	add	x11, x1, x12
    40203b14:	aa0c03ef 	mov	x15, x12
    40203b18:	39400dd0 	ldrb	w16, [x14, #3]
    40203b1c:	394009d1 	ldrb	w17, [x14, #2]
    40203b20:	f10011ef 	subs	x15, x15, #0x4
    40203b24:	394001d2 	ldrb	w18, [x14]
    40203b28:	394005c3 	ldrb	w3, [x14, #1]
    40203b2c:	910011ce 	add	x14, x14, #0x4
    40203b30:	39000db0 	strb	w16, [x13, #3]
    40203b34:	390009b1 	strb	w17, [x13, #2]
    40203b38:	390005a3 	strb	w3, [x13, #1]
    40203b3c:	380045b2 	strb	w18, [x13], #4
    40203b40:	54fffec1 	b.ne	40203b18 <memcpy+0x58>  // b.any
    40203b44:	eb0c011f 	cmp	x8, x12
    40203b48:	540000a0 	b.eq	40203b5c <memcpy+0x9c>  // b.none
    40203b4c:	3840156c 	ldrb	w12, [x11], #1
    40203b50:	3800154c 	strb	w12, [x10], #1
    40203b54:	eb09015f 	cmp	x10, x9
    40203b58:	54ffffa1 	b.ne	40203b4c <memcpy+0x8c>  // b.any
    40203b5c:	cb08004b 	sub	x11, x2, x8
    40203b60:	8b08002a 	add	x10, x1, x8
    40203b64:	927df16c 	and	x12, x11, #0xfffffffffffffff8
    40203b68:	f240095f 	tst	x10, #0x7
    40203b6c:	8b0c0128 	add	x8, x9, x12
    40203b70:	540007a1 	b.ne	40203c64 <memcpy+0x1a4>  // b.any
    40203b74:	eb08013f 	cmp	x9, x8
    40203b78:	540000c2 	b.cs	40203b90 <memcpy+0xd0>  // b.hs, b.nlast
    40203b7c:	aa0a03ed 	mov	x13, x10
    40203b80:	f84085ae 	ldr	x14, [x13], #8
    40203b84:	f800852e 	str	x14, [x9], #8
    40203b88:	eb08013f 	cmp	x9, x8
    40203b8c:	54ffffa3 	b.cc	40203b80 <memcpy+0xc0>  // b.lo, b.ul, b.last
    40203b90:	8b0c0141 	add	x1, x10, x12
    40203b94:	92400962 	and	x2, x11, #0x7
    40203b98:	8b020109 	add	x9, x8, x2
    40203b9c:	eb09011f 	cmp	x8, x9
    40203ba0:	540000c3 	b.cc	40203bb8 <memcpy+0xf8>  // b.lo, b.ul, b.last
    40203ba4:	1400002f 	b	40203c60 <memcpy+0x1a0>
    40203ba8:	aa0003e8 	mov	x8, x0
    40203bac:	8b020009 	add	x9, x0, x2
    40203bb0:	eb09001f 	cmp	x0, x9
    40203bb4:	54000562 	b.cs	40203c60 <memcpy+0x1a0>  // b.hs, b.nlast
    40203bb8:	f100105f 	cmp	x2, #0x4
    40203bbc:	540004a3 	b.cc	40203c50 <memcpy+0x190>  // b.lo, b.ul, b.last
    40203bc0:	cb01010a 	sub	x10, x8, x1
    40203bc4:	f100815f 	cmp	x10, #0x20
    40203bc8:	54000443 	b.cc	40203c50 <memcpy+0x190>  // b.lo, b.ul, b.last
    40203bcc:	39400c2a 	ldrb	w10, [x1, #3]
    40203bd0:	3940082b 	ldrb	w11, [x1, #2]
    40203bd4:	3940002c 	ldrb	w12, [x1]
    40203bd8:	3940042d 	ldrb	w13, [x1, #1]
    40203bdc:	39000d0a 	strb	w10, [x8, #3]
    40203be0:	927e044a 	and	x10, x2, #0xc
    40203be4:	f100115f 	cmp	x10, #0x4
    40203be8:	3900090b 	strb	w11, [x8, #2]
    40203bec:	3900050d 	strb	w13, [x8, #1]
    40203bf0:	3900010c 	strb	w12, [x8]
    40203bf4:	54000260 	b.eq	40203c40 <memcpy+0x180>  // b.none
    40203bf8:	39401c2b 	ldrb	w11, [x1, #7]
    40203bfc:	3940182c 	ldrb	w12, [x1, #6]
    40203c00:	f100215f 	cmp	x10, #0x8
    40203c04:	3940102d 	ldrb	w13, [x1, #4]
    40203c08:	3940142e 	ldrb	w14, [x1, #5]
    40203c0c:	39001d0b 	strb	w11, [x8, #7]
    40203c10:	3900190c 	strb	w12, [x8, #6]
    40203c14:	3900150e 	strb	w14, [x8, #5]
    40203c18:	3900110d 	strb	w13, [x8, #4]
    40203c1c:	54000120 	b.eq	40203c40 <memcpy+0x180>  // b.none
    40203c20:	39402c2b 	ldrb	w11, [x1, #11]
    40203c24:	3940282c 	ldrb	w12, [x1, #10]
    40203c28:	3940202d 	ldrb	w13, [x1, #8]
    40203c2c:	3940242e 	ldrb	w14, [x1, #9]
    40203c30:	39002d0b 	strb	w11, [x8, #11]
    40203c34:	3900290c 	strb	w12, [x8, #10]
    40203c38:	3900250e 	strb	w14, [x8, #9]
    40203c3c:	3900210d 	strb	w13, [x8, #8]
    40203c40:	eb0a005f 	cmp	x2, x10
    40203c44:	540000e0 	b.eq	40203c60 <memcpy+0x1a0>  // b.none
    40203c48:	8b0a0108 	add	x8, x8, x10
    40203c4c:	8b0a0021 	add	x1, x1, x10
    40203c50:	3840142a 	ldrb	w10, [x1], #1
    40203c54:	3800150a 	strb	w10, [x8], #1
    40203c58:	eb09011f 	cmp	x8, x9
    40203c5c:	54ffffa1 	b.ne	40203c50 <memcpy+0x190>  // b.any
    40203c60:	d65f03c0 	ret
    40203c64:	eb08013f 	cmp	x9, x8
    40203c68:	54fff942 	b.cs	40203b90 <memcpy+0xd0>  // b.hs, b.nlast
    40203c6c:	aa0a03ed 	mov	x13, x10
    40203c70:	aa0d03f0 	mov	x16, x13
    40203c74:	394009af 	ldrb	w15, [x13, #2]
    40203c78:	394005ae 	ldrb	w14, [x13, #1]
    40203c7c:	38404e11 	ldrb	w17, [x16, #4]!
    40203c80:	39400a12 	ldrb	w18, [x16, #2]
    40203c84:	394001a1 	ldrb	w1, [x13]
    40203c88:	39400da2 	ldrb	w2, [x13, #3]
    40203c8c:	d370bdef 	lsl	x15, x15, #16
    40203c90:	394015a3 	ldrb	w3, [x13, #5]
    40203c94:	39400e10 	ldrb	w16, [x16, #3]
    40203c98:	53103e52 	lsl	w18, w18, #16
    40203c9c:	aa0e202e 	orr	x14, x1, x14, lsl #8
    40203ca0:	aa0261ef 	orr	x15, x15, x2, lsl #24
    40203ca4:	910021ad 	add	x13, x13, #0x8
    40203ca8:	2a032231 	orr	w17, w17, w3, lsl #8
    40203cac:	2a106250 	orr	w16, w18, w16, lsl #24
    40203cb0:	aa0e01ee 	orr	x14, x15, x14
    40203cb4:	2a11020f 	orr	w15, w16, w17
    40203cb8:	aa0f81ce 	orr	x14, x14, x15, lsl #32
    40203cbc:	f800852e 	str	x14, [x9], #8
    40203cc0:	eb08013f 	cmp	x9, x8
    40203cc4:	54fffd63 	b.cc	40203c70 <memcpy+0x1b0>  // b.lo, b.ul, b.last
    40203cc8:	17ffffb2 	b	40203b90 <memcpy+0xd0>

0000000040203ccc <memset>:
    40203ccc:	f100405f 	cmp	x2, #0x10
    40203cd0:	540009e3 	b.cc	40203e0c <memset+0x140>  // b.lo, b.ul, b.last
    40203cd4:	cb0003eb 	neg	x11, x0
    40203cd8:	92400968 	and	x8, x11, #0x7
    40203cdc:	8b080009 	add	x9, x0, x8
    40203ce0:	eb09001f 	cmp	x0, x9
    40203ce4:	54000302 	b.cs	40203d44 <memset+0x78>  // b.hs, b.nlast
    40203ce8:	f100111f 	cmp	x8, #0x4
    40203cec:	aa0003ea 	mov	x10, x0
    40203cf0:	54000243 	b.cc	40203d38 <memset+0x6c>  // b.lo, b.ul, b.last
    40203cf4:	0e020c20 	dup	v0.4h, w1
    40203cf8:	927e016b 	and	x11, x11, #0x4
    40203cfc:	aa0003ec 	mov	x12, x0
    40203d00:	8b0b000a 	add	x10, x0, x11
    40203d04:	aa0b03ed 	mov	x13, x11
    40203d08:	5e0e0401 	mov	h1, v0.h[3]
    40203d0c:	5e0a0402 	mov	h2, v0.h[2]
    40203d10:	5e060403 	mov	h3, v0.h[1]
    40203d14:	3d000180 	str	b0, [x12]
    40203d18:	f10011ad 	subs	x13, x13, #0x4
    40203d1c:	3c003181 	stur	b1, [x12, #3]
    40203d20:	3c002182 	stur	b2, [x12, #2]
    40203d24:	3c001183 	stur	b3, [x12, #1]
    40203d28:	9100118c 	add	x12, x12, #0x4
    40203d2c:	54ffff41 	b.ne	40203d14 <memset+0x48>  // b.any
    40203d30:	eb0b011f 	cmp	x8, x11
    40203d34:	54000080 	b.eq	40203d44 <memset+0x78>  // b.none
    40203d38:	38001541 	strb	w1, [x10], #1
    40203d3c:	eb09015f 	cmp	x10, x9
    40203d40:	54ffffc1 	b.ne	40203d38 <memset+0x6c>  // b.any
    40203d44:	cb08004a 	sub	x10, x2, x8
    40203d48:	927df148 	and	x8, x10, #0xfffffffffffffff8
    40203d4c:	8b080128 	add	x8, x9, x8
    40203d50:	eb08013f 	cmp	x9, x8
    40203d54:	54000102 	b.cs	40203d74 <memset+0xa8>  // b.hs, b.nlast
    40203d58:	12001c2b 	and	w11, w1, #0xff
    40203d5c:	3200c3ec 	mov	w12, #0x1010101             	// #16843009
    40203d60:	1b0c7d6b 	mul	w11, w11, w12
    40203d64:	aa0b816b 	orr	x11, x11, x11, lsl #32
    40203d68:	f800852b 	str	x11, [x9], #8
    40203d6c:	eb08013f 	cmp	x9, x8
    40203d70:	54ffffc3 	b.cc	40203d68 <memset+0x9c>  // b.lo, b.ul, b.last
    40203d74:	92400942 	and	x2, x10, #0x7
    40203d78:	8b020109 	add	x9, x8, x2
    40203d7c:	eb09011f 	cmp	x8, x9
    40203d80:	54000442 	b.cs	40203e08 <memset+0x13c>  // b.hs, b.nlast
    40203d84:	f100105f 	cmp	x2, #0x4
    40203d88:	540003a3 	b.cc	40203dfc <memset+0x130>  // b.lo, b.ul, b.last
    40203d8c:	927e044a 	and	x10, x2, #0xc
    40203d90:	39000d01 	strb	w1, [x8, #3]
    40203d94:	f100115f 	cmp	x10, #0x4
    40203d98:	8b0a010b 	add	x11, x8, x10
    40203d9c:	39000901 	strb	w1, [x8, #2]
    40203da0:	39000501 	strb	w1, [x8, #1]
    40203da4:	39000101 	strb	w1, [x8]
    40203da8:	54000240 	b.eq	40203df0 <memset+0x124>  // b.none
    40203dac:	0e020c20 	dup	v0.4h, w1
    40203db0:	f100215f 	cmp	x10, #0x8
    40203db4:	5e0e0401 	mov	h1, v0.h[3]
    40203db8:	5e0a0402 	mov	h2, v0.h[2]
    40203dbc:	5e060403 	mov	h3, v0.h[1]
    40203dc0:	3c004100 	stur	b0, [x8, #4]
    40203dc4:	3c007101 	stur	b1, [x8, #7]
    40203dc8:	3c006102 	stur	b2, [x8, #6]
    40203dcc:	3c005103 	stur	b3, [x8, #5]
    40203dd0:	54000100 	b.eq	40203df0 <memset+0x124>  // b.none
    40203dd4:	5e0e0401 	mov	h1, v0.h[3]
    40203dd8:	5e0a0402 	mov	h2, v0.h[2]
    40203ddc:	3c008100 	stur	b0, [x8, #8]
    40203de0:	5e060403 	mov	h3, v0.h[1]
    40203de4:	3c00b101 	stur	b1, [x8, #11]
    40203de8:	3c00a102 	stur	b2, [x8, #10]
    40203dec:	3c009103 	stur	b3, [x8, #9]
    40203df0:	eb0a005f 	cmp	x2, x10
    40203df4:	aa0b03e8 	mov	x8, x11
    40203df8:	54000080 	b.eq	40203e08 <memset+0x13c>  // b.none
    40203dfc:	38001501 	strb	w1, [x8], #1
    40203e00:	eb09011f 	cmp	x8, x9
    40203e04:	54ffffc1 	b.ne	40203dfc <memset+0x130>  // b.any
    40203e08:	d65f03c0 	ret
    40203e0c:	aa0003e8 	mov	x8, x0
    40203e10:	8b020009 	add	x9, x0, x2
    40203e14:	eb09001f 	cmp	x0, x9
    40203e18:	54fffb63 	b.cc	40203d84 <memset+0xb8>  // b.lo, b.ul, b.last
    40203e1c:	17fffffb 	b	40203e08 <memset+0x13c>
