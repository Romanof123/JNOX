from pathlib import Path
import re,struct,hashlib
root=Path(__file__).resolve().parent
for p in ['pi','ceiling']:
    dr=root/'parent-diff'/p
    a=(dr/'kernel.elf').read_bytes(); b=(root/'elf'/p/'kernel.elf').read_bytes()
    sha=lambda x:hashlib.sha256(x).hexdigest()
    print(p,'parent',sha(a),'candidate',sha(b))
    assert a[:52]==b[:52] and struct.unpack_from('<Q',a,24)[0]==0x40200000
    for i in range(2):
        off=64+56*i
        ah=struct.unpack_from('<IIQQQQQQ',a,off)
        bh=struct.unpack_from('<IIQQQQQQ',b,off)
        assert ah==bh
        _,flags,offset,addr,_,size,memsz,_=ah
        left=a[offset:offset+size];right=b[offset:offset+size]
        print('LOAD',i,'address',hex(addr),'flags',flags,'filesz/memsz',size,memsz,'hashes',sha(left),sha(right))
        print('byte differences',[(hex(addr+j),l,r) for j,(l,r) in enumerate(zip(left,right)) if l!=r][:100])
    old=(dr/'parent-symbols.txt').read_text()
    new=(dr/'scored-symbols.txt').read_text()
    norm=lambda x: re.sub(r'\.llvm\.\d+','.llvm.N',x)
    print('nm normalized names/addresses/sizes equal',norm(old)==norm(new))
    old=(dr/'parent-linked.asm').read_text(); new=(dr/'scored-linked.asm').read_text()
    words=lambda x:re.findall(r'^\s*([a-f0-9]+):\s+([a-f0-9]{8})',x,re.M)
    assert words(old)==words(new)
    print('all linked instruction words and addresses equal',len(words(old)))
