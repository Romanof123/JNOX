set -eu
base=/mnt/d/codex/jnox295-independent-evidence
w=$HOME/jnox295-independent-first
o=$base/replay
mkdir "$o"
cd "$o"
python3 - "$w" <<'PY'
from pathlib import Path
import sys,zipfile
src=Path(sys.argv[1])/'src'
with zipfile.ZipFile(src/'docs/evidence/ordinary-mutex-chain-fifo-integration.zip') as z:
 for f in ['control_replay.py','mutex_chain_replay.py','check.py','replay.py','rows.py']:
  Path(f).write_bytes(z.read(f))
PY
for p in chain fifo pi ceiling; do
 mkdir "ordinary-$p"
 for mode in plain traced; do
  d=$(echo "$base"/*-"$p"-"$mode"); m=plain; [[ "$mode" != traced ]] || m=trace
  cp "$d/uart" "ordinary-$p/$m.uart"
  [[ "$mode" != traced ]] || cp "$d/exceptions.log" "ordinary-$p/exceptions.log"
 done
done
mkdir -p fifo/{plain,traced}
cp "$base/elf/fifo/linked.asm" fifo/disassembly
cp ordinary-fifo/plain.uart fifo/plain/uart
cp ordinary-fifo/trace.uart fifo/traced/uart
cp ordinary-fifo/exceptions.log fifo/traced/
python3 "$base/survivors_replay.py" > survivors.log
set +e
python3 check.py > chain-controls.log 2>&1; echo $? > chain-controls.rc
python3 replay.py > fifo.log 2>&1; echo $? > fifo.rc
sha256sum ordinary-{pi,ceiling}/{plain.uart,trace.uart,exceptions.log} > SHA256SUMS
python3 -m zipfile -c "$w/controls.zip" SHA256SUMS ordinary-pi ordinary-ceiling
r=$w/src
python3 "$r/tools/qualify_ordinary_mutex.py" "$w/controls.zip" > legacy.log 2>&1; echo $? > legacy.rc
export PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH CARGO_TARGET_DIR=$w/target CARGO_BUILD_JOBS=1 PYTHONDONTWRITEBYTECODE=1
cd "$r"
rustc --edition=2021 --test tools/scheduling_tests.rs -o "$w/host" > "$o/host-build.log" 2>&1 && "$w/host" --test-threads=1 > "$o/host.log" 2>&1; echo $? > "$o/host.rc"
python3 "$o/rows.py" "$r" > "$o/rows.log" 2>&1; echo $? > "$o/rows.rc"
python3 tools/requirement_graph.py > "$o/graph.log" 2>&1; echo $? > "$o/graph.rc"
python3 tools/scheduling_evidence.py > "$o/matrix.json" 2>&1; echo $? > "$o/matrix.rc"
cd tools
python3 -m unittest -v test_mutex_anchor_replay test_scheduling_evidence test_requirement_graph test_build_kernel > "$o/scoped.log" 2>&1; echo $? > "$o/scoped.rc"
cd "$r/kernel"
for spec in virt:fixed:ordinary-chain virt:mutex:fixed-fifo virt:mutex:ordinary-chain:rust-prepared virt:none:ordinary-chain pi4:mutex:ordinary-fifo virt:mutex:unknown pi4:mutex:ordinary-chain virt:mutex:ordinary-fifo:rust-prepared pi4:mutex:ordinary-survivors virt:mutex:ordinary-survivors:rust-prepared; do
 IFS=: read -r board profile app anchor <<<"$spec"
 args=(JNOX_BOARD="$board" JNOX_APP="$app")
 [[ $profile == none ]] || args+=(JNOX_PROFILE="$profile")
 [[ -z $anchor ]] || args+=(JNOX_MUTEX_ANCHOR="$anchor")
 rc=0; env "${args[@]}" cargo build --locked --release -j1 >"$o/invalid-${spec//:/-}.log" 2>&1 || rc=$?
 echo "$spec $rc" >> "$o/negative-status"
done