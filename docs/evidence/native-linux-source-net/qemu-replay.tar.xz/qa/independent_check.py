"""Inspect existing #426 capture files only. Run under WSL with the run root."""
import hashlib
import json
import re
import struct
import subprocess
import sys
from pathlib import Path


def check(condition, description):
    if not condition:
        raise ValueError(description)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def walk(ram, root_pa, va):
    table = root_pa
    for shift in (30,21,12):
        location = table + 8 * ((va >> shift) & 511)
        pte = int.from_bytes(bytes.fromhex(ram[f"{location:x}/8"]), "little")
        check(pte & 3 == 3, "invalid table or final PTE")
        table = pte & 0x0000fffffffff000
    return table | (va & 4095), pte


def cpu_observations(path):
    if not path.exists():
        return None
    asm = re.compile(r"^\s*0x([\da-f]+):\s+([\da-f]{8})\b")
    trace = re.compile(r"^Trace 0: (0x[\da-f]+) \[([\da-f]+)/([\da-f]+)/([\da-f]+)/([\da-f]+)\]")
    lines = path.read_text().splitlines()
    dispatches = [(i, m.groups()) for i,line in enumerate(lines)
               if (m:=trace.match(line)) and int(m[3],16) == 0x4009b0]
    entries = []
    stopped = []
    for i,fields in dispatches:
        abort = re.fullmatch(r"Stopped execution of TB chain before (0x[\da-f]+) \[([\da-f]+)\]\s*",
                             lines[i+1] if i+1<len(lines) else "")
        if abort and abort[1]==fields[0] and int(abort[2],16)==int(fields[2],16):
            stopped.append(i+1)
        else:
            entries.append((i,fields))
    translations = [i for i,line in enumerate(lines)
                    if (m:=asm.match(line)) and int(m[1],16)==0x4009b0]
    check(len(translations)==1 and len(entries)==3 and len(set(e for _,e in entries))==1,
          "callback TB translation and execution count")
    index = translations[0]
    words = []
    for line in lines[index:index+7]:
        m = asm.match(line)
        if not m:
            break
        words.append((int(m[1],16),m[2]))
    check(words and all(callback_words.get(addr)==word for addr,word in words), "linked TB bytes")
    check(any(peer_words.get(addr)!=word for addr,word in words), "ambiguous peer VA")
    next_trace = next(i for i in range(index+1,len(lines)) if trace.match(lines[i]))
    check(next_trace == dispatches[0][0] and dispatches[0][1]==entries[0][1]
          and not any(l.startswith("IN:") for l in lines[index+1:next_trace]),
          "translation-to-execution association")
    return dict(executions=len(entries), translation_line=index+1, aborted_dispatch_lines=stopped,
                exec_lines=[i+1 for i,_ in entries], entry_words=words, sha256=sha(path))


def ownership_epoch(path):
    records = []
    for i,line in enumerate((path/"uart.log").read_text().splitlines(),1):
        if line.startswith("NATIVE FIXED EVENT "):
            fields = list(map(int,line.split()[3:]))
            records.append((i,fields[0],fields[1],fields[3],fields[4],fields[5]))
    # PC after SVC, PID, syscall number, location of MOV W8,#number.
    calls = [(0x400110,0,156,0x400100),(0x400b7c,1,156,0x400b70),
             (0x400b90,1,157,0x400b88),(0x400ba4,1,158,0x400b9c),
             (0x400bb8,1,159,0x400bb0),(0x400bcc,1,160,0x400bc4),
             (0x400594,0,156,0x40058c)]
    evidence = []
    check(driver_words[0x4000f0]=="52800020" and driver_words[0x400580]=="aa1f03e0",
          "driver claim/release x0 argument")
    for pc,pid,number,mov in calls:
        words = peer_words if pid else driver_words
        check(words[pc-4]=="d4094021" and int(words[mov],16)==(0x52800008 | number<<5),
              "syscall instruction or number differs from ELF")
        matches = [r for r in records if r[2:]==(5,pid,pid,pc)]
        check(len(matches)==1, "expected single fixed syscall event per callsite")
        row = matches[0]
        evidence.append(dict(line=row[0],tick=row[1],pid=pid,number=number,return_pc=hex(pc)))
    for a,b in zip(evidence,evidence[1:]):
        check(a["tick"]<b["tick"] and a["line"]<b["line"], "owner epoch order")
    check(any(evidence[0]["line"]<i<evidence[1]["line"] and (kind,old,new)==(2,0,1)
              for i,_,kind,old,new,_ in records),"owner to peer switch")
    check(any(evidence[-2]["line"]<i<evidence[-1]["line"] and old!=0 and new==0
              for i,_,_,old,new,_ in records),"owner resumed")
    return evidence


def capture(path):
    launch = json.loads((path / "launch.json").read_text())
    ram = json.loads((path / "ram.json").read_text())
    receipts = []
    for root_pa,va,size in ((0x40230000,0x402008,256),(0x40645000,0x402010,128)):
        pa,pte = walk(ram,root_pa,va)
        check((pte>>6)&3 == 1, "EL0 RW receipt PTE")
        nic_pa,nic_pte = walk(ram,root_pa,0xa003e00)
        check(nic_pa==0xa003e00 and (nic_pte>>6)&3==0 and (nic_pte>>2)&7==1,
              "EL1-only device mapping")
        receipts.append(pa)
    check(receipts[0]>>12 != receipts[1]>>12, "receipt RAM pages alias")
    driver = struct.unpack("<32q", bytes.fromhex(ram[f"{receipts[0]:x}/256"]))
    peer = struct.unpack("<16q", bytes.fromhex(ram[f"{receipts[1]:x}/128"]))
    mac = bytes.fromhex(launch["mac"].replace(":", ""))
    mtu = launch["mtu"]
    check(driver[:5] == (0x564e455444303031, 100, 0, 0, 3), "driver stage")
    check(driver[7:15] == (int.from_bytes(mac, "little"), mtu, 0x100000028,
          0x100000028, 0, mtu, 1, 0), "RAM successful validation")
    check(driver[15:31] == (-22,0,1,-22,0,1,-22,3,0,11,0,-19,0,3,0,-19),
          "RAM negative controls and release")
    check(peer[:9] == (0x564e455450303031,100,0,-13,-13,-13,-13,-13,6),
          "peer syscall receipts")
    base = 0xa003e00
    events = []
    for mode, address, value, width in re.findall(
            r"memory_region_ops_(read|write).*?addr (0x\w+) value (0x\w+) size (\d+) name 'virtio-mmio'",
            (path / "mmio.trace").read_text()):
        offset = int(address,16) - base
        if 0 <= offset < 512:
            events.append((mode, offset, int(width), int(value,16)))
    config = [e for e in events if e[1] >= 256]
    expected = [("read",256+i,1,v) for i,v in enumerate(mac)] + [("read",266,2,mtu)]*2
    check(config == expected, "wrong config read width, value, offset or count")
    offers = [value for mode, off, width, value in events if (mode,off,width)==("read",16,4)]
    check(offers and offers[:2] == offers[-2:] and
          tuple(v & 0xffffffff for v in offers[:2]) == driver[5:7], "offer words")
    selected = [value for mode,off,width,value in events if (mode,off,width)==("write",32,4)]
    check(selected == [40,1], "selected feature words")
    statuses = [v for mode,off,width,v in events if (mode,off,width)==("write",112,4)]
    check(statuses == [0,1,3,11,0,0,1,3,0], "status transitions")
    return dict(capture=path.name, mac=mac.hex(":"), mtu=mtu, config_reads=config,
                raw_qemu_offer=offers, guest_offer=driver[5:7], selected=selected,
                cpu=cpu_observations(path/"callback.log"), receipt_pa=receipts,
                owner_epoch=ownership_epoch(path), uart_sha256=sha(path/"uart.log"),
                status_writes=statuses, peer_156_to_160=peer[3:8],
                driver_15_to_30=driver[15:31], raw_sha256={n:sha(path/n) for n in
                ("mmio.trace","ram.json","launch.json")})


root = Path(sys.argv[1])
service = root / "imported/service.elf"
def get_words(elf,symbol=None):
    args = ["aarch64-linux-gnu-objdump","-d"]
    if symbol:
        args.append("--disassemble="+symbol)
    output = subprocess.check_output([*args,elf],text=True)
    return {int(addr,16):word for addr,word in re.findall(r"^\s*([0-9a-f]+):\s+([0-9a-f]{8})\s",output,re.M)}


callback_words = get_words(service,"virtnet_validate")
peer_words = get_words(root/"native/native_peer.elf")
driver_words = get_words(service)
disasm = subprocess.check_output(["aarch64-linux-gnu-objdump","-d",
                                  "--disassemble=jnox_net_validate",service],text=True)
check(re.search(r"400928:\s+94000022\s+bl\s+4009b0 <virtnet_validate>",disasm),
      "linked branch to original callback")
check(sha(service)==sha(root/"native/user.elf"), "native service identity")
print(json.dumps(dict(service_sha256=sha(service), static_call="0x400928 -> 0x4009b0",
      captures=[capture(root/n) for n in sys.argv[2:]],
      scope="RAM receipts, page walks, MMIO and per-slot SVC return PCs. CPU callback evidence only where cpu is populated."),indent=2))
