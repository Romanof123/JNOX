from pathlib import Path
import hashlib,json,struct,sys,zipfile,subprocess as sp,re
p=Path(__file__).resolve().parent;b=p.parent
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def get(f):return json.loads(f.read_bytes())
def save(f,v):f.write_text(json.dumps(v,indent=2)+'\n')
def locations(elf,delta):
 data=elf.read_bytes();off=struct.unpack_from('<Q',data,32)[0];ss,n=struct.unpack_from('<HH',data,54)
 segments=[struct.unpack_from('<II6Q',data,off+i*ss) for i in range(n)];_,_,base,va,_,length,*_=next(x for x in segments if x[0]==1)
 loc=[]
 for i,*_ in delta:
  for step in range(4):
   o=i-step-16;ptr,lengthname,line,col=struct.unpack_from('<QQII',data,base+o)
   if va<=ptr<va+length and lengthname<512:
    s=data[base+ptr-va:base+ptr-va+lengthname].decode(errors='replace')
    if s.endswith('.rs'):loc.append(dict(offset=i,file=s,line=line,column=col));break
 return loc
C=get(p/'comparisons.json')
for tag,x in C.items():
 d=x['segment_byte_differences'][0]['differing_shared_offsets'];x['old_source_locations']=locations(b/x['reference'],d);x['new_source_locations']=locations(p/tag/'kernel.elf',d)
save(p/'comparisons.json',C)
with zipfile.ZipFile(b/'markers-integrated-pinned/docs/evidence/evd-051-study.zip') as z:
 for n in z.namelist():
  if '/ADDENDUM-decoder.' in n:(p/Path(n).name).write_bytes(z.read(n))
def audit(tag):
 f=p/(tag+'.audit.json');d=get(f);return dict(findings=d['findings'],exit=int(bool(d['findings'])),sha256=sha(f),head=sp.check_output(['git','-C',str(b/tag),'rev-parse','HEAD'],text=True).strip())
replays=get(p/'replays.json');reg=get(p/'regression-builds.json')
summary=dict(head_verdicts={'descriptor':'integration functional checks PASS; strict audit findings []; all healthy timing replays nonqualifying; control PT_LOAD differs from isolated references','markers':'HOLD: strict audit dangling implementation for POL-004: IMP-052. Integrated decoder and selector checks pass; all healthy timing replays nonqualifying; control PT_LOAD differs from isolated references'},audits={t:audit(t) for t in ('descriptor-integrated-pinned','markers-integrated-pinned','reservation-repair-plan-evidence')},reservation_EVD053='Explicit typed CSV edge POL-008,has-analysis-evidence,EVD-053. Strict audit includes in POL-008 analysis, with direct IMP-053 -> VER-002/005/023 paths. Docs-only audit.',build_exits={k:v['exit'] for k,v in get(p/'builds.json').items()},boots={k:dict(terminal=v['terminal'],healthy=get(p/k/'guest/score.stdout')['verdict'],failures=get(p/k/'guest/score.stdout')['failures'],cold_fixed_no_probe=v.get('cold_fixed_no_probe'),external_decoder=v.get('marker_exit')) for k,v in get(p/'boots.json').items()},elf_comparisons={k:dict(instruction_differences=len(v['instruction_differences']),load_byte_differences=sum(len(s['differing_shared_offsets']) for s in v['segment_byte_differences']),all_changed_bytes_in_source_line_metadata=len(v['new_source_locations'])==sum(len(s['differing_shared_offsets']) for s in v['segment_byte_differences']),same_layout=all(s['old_layout']==s['new_layout'] for s in v['segment_byte_differences'])) for k,v in C.items()},earlier_guests={k:dict(exit=v['guest_exit'],ap_end=v.get('ap_check',{}).get('end')) for k,v in reg.items()},decoder='All four genuine journals, UART and ordered external exceptions pass repaired decoder, regression and independent phase/interval join for all 104 marker phases. Original decoder has no external exception API: two-input results reproduced saved outputs, with identical disjoint totals for all slices. Independent boot 02 n=9 values below. Controls reject reversed interval, wrong phase, omitted and duplicated data, PC and terminal trace corruption.',boot02_first=replays[next(iter(replays))]['independent_phase_rows'][0],addendum_sha256=sha(p/'ADDENDUM-decoder.md'),limitations='Single default-clock boot per selected guest. Timing nonqualification stands. No semantic or hardware equivalence inferred from matching instructions. Descriptor head predates marker implementation; cold+marker exclusivity exercised on marker-integrated head.')
save(p/'report.json',summary)
files={str(f.relative_to(p)).replace(chr(92),'/'):sha(f) for f in p.rglob('*') if f.is_file() and not any(x.startswith('target-') for x in f.relative_to(p).parts) and f.name not in ('manifest.json','manifest.sha256')}
save(p/'manifest.json',files);(p/'manifest.sha256').write_text(sha(p/'manifest.json')+'  manifest.json\n');print('report',sha(p/'report.json'),'manifest',sha(p/'manifest.json'));print(summary['elf_comparisons'])
