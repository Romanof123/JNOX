from pathlib import Path
import hashlib,json,sys,tarfile,struct,subprocess as sp,tempfile,shutil,time,os,difflib,re
p=Path(__file__).resolve().parent;b=p.parent;ref=b/'service53-corrected-builds';cold=b/'cold-merged-gates'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def save(f,v):f.write_text(json.dumps(v,indent=2)+'\n')
def get(f):return json.loads(f.read_bytes())
cfg=get(ref/'protocol.json');idx=get(p/'builds.json');tmp=Path(tempfile.mkdtemp(dir='/tmp',prefix='jnox-i53-'))
os.environ.update(TMPDIR=str(tmp),PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0,str(ref));from capture import loads_image,snapshot
sys.path.insert(0,str(b/'markers-integrated-pinned/tools'));from qemu_capture import request
q=Path(cfg['qemu']);assert sha(q)==cfg['qemu_sha256'];save(p/'host.json',dict(tmp=str(tmp),qemu=sha(q),boot_id=Path('/proc/sys/kernel/random/boot_id').read_text(),fs=sp.check_output(['df','-T',tmp],text=True)))
def cmd(d,tag,argv):
 r=sp.run(list(map(str,argv)),capture_output=True);(d/(tag+'.stdout')).write_bytes(r.stdout);(d/(tag+'.stderr')).write_bytes(r.stderr);save(d/(tag+'.json'),dict(argv=list(map(str,argv)),exit=r.returncode));return r
comparisons={};boots={};sealed={}
for tag,v in idx.items():
 if v['exit']:continue
 head,pol,arm=tag.split('-');d=p/tag;elf=d/'kernel.elf'
 origin=(cold/(pol+'-healthy-diagnostic')/'kernel.elf') if arm=='cold' else ref/'images'/(pol+'-'+arm)/'kernel.elf'
 def dis(f):return sp.check_output(['aarch64-linux-gnu-objdump','-dC',f]).decode().splitlines()[2:]
 old,new=dis(origin),dis(elf);diff=list(difflib.unified_diff(old,new,fromfile='reference',tofile='integrated',lineterm=''));(d/'linked.diff').write_text('\n'.join(diff));(d/'disassembly.txt').write_text('\n'.join(new))
 z=comparisons[tag]=dict(reference=str(origin.relative_to(b)),source_sha=sha(origin),elf_sha=sha(elf),load_segments=loads_image(elf),reference_segments=loads_image(origin),same_load=loads_image(origin)==loads_image(elf),same_disassembly=not diff)
 if arm=='baseline':z['also_cold_merged_baseline_equal']=loads_image(cold/(pol+'-healthy')/'kernel.elf')==loads_image(elf)
save(p/'comparisons.json',comparisons)
for tag in ['descriptor-rm-descriptor','descriptor-dm-descriptor','markers-rm-marker','markers-dm-marker','markers-dm-cold','descriptor-rm-cold']:
 head,pol,arm=tag.split('-');d=tmp/tag;d.mkdir();elf=d/'kernel.elf';shutil.copy2(p/tag/'kernel.elf',elf)
 uart=d/'uart';ext=d/'exceptions';sock=d/'q';argv=[str(q),*cfg['qemu_options'],'-serial','file:'+str(uart)]
 marker=None
 if arm=='marker':
  sym=sp.check_output(['aarch64-linux-gnu-nm','-nS',elf],text=True);m=re.search(r'^([0-9a-f]+) ([0-9a-f]+) \w control_marker_journal$',sym,re.M);marker=tuple(int(x,16) for x in m.groups())
 if arm=='cold':
  inp=d/'cold-mode.bin';inp.write_bytes(b'2');argv+=['-fw_cfg','name=opt/jnox/cold-mode,file='+str(inp)]
 else:argv+=['-d','int','-D',str(ext)]
 argv+=['-qmp','unix:'+str(sock)+',server=on,wait=off','-kernel',str(elf)]
 with (d/'stderr').open('wb') as err,(d/'stdout').open('wb') as out:
  t=time.monotonic();proc=sp.Popen(argv,stderr=err,stdout=out)
  try:
   while time.monotonic()-t<10 and proc.poll()==None and not (uart.exists() and uart.read_bytes().endswith(b'CONTROL END\n')): time.sleep(.001)
   terminal=uart.exists() and uart.read_bytes().endswith(b'CONTROL END\n')
   if terminal:snapshot(sock,d,marker,request)
  finally:
   proc.terminate();proc.wait(5)
 if sock.exists():sock.unlink()
 z=boots[tag]=dict(argv=argv,elf=sha(elf),terminal=terminal,exit=proc.returncode)
 score=cmd(d,'score',[sys.executable,'-B',b/(head+'-integrated-pinned/tools/control_observations.py'),'healthy',uart]);z['score_exit']=score.returncode
 if arm=='marker':z['marker_exit']=cmd(d,'marker',[sys.executable,'-B',b/(head+'-integrated-pinned/tools/control_service_markers.py'),d/'markers.bin',uart,'--exceptions',ext]).returncode
 if arm=='cold':
  rows=[list(map(int,l.split())) for l in uart.read_text().splitlines() if l and l[0].isdigit()];x,= [r for r in rows if r[0]==48];epoch,=[r for r in rows if r[0]==1];z['cold_fixed_no_probe']=x[3]==2 and epoch[1]==x[1]+x[2]//4 and not any(r[0] in [57,60] for r in rows)
 shutil.copytree(d,p/tag/'guest');save(p/'boots.json',boots)
for item in get(ref/'captures/index.json'):
 if item['case']['arm']!='marker':continue
 archive=ref/'captures'/item['archive'];assert sha(archive)==item['archive_sha256'];tag=archive.name.split('.')[0];d=p/'replay'/tag;d.mkdir(parents=True)
 with tarfile.open(archive) as tar:
  for name in ('uart','markers.bin','exceptions','marker_decode.stdout'):
   (d/name).write_bytes(tar.extractfile(tag+'/'+name).read())
 old=ref/'sources/marker/tools/control_service_markers.py';tool=b/'markers-integrated-pinned/tools/control_service_markers.py';reg=tool.with_name('control_service_markers_regression.py')
 j,u,e=d/'markers.bin',d/'uart',d/'exceptions'
 original=cmd(d,'original',[sys.executable,'-B',old,j,u]);fixed=cmd(d,'fixed',[sys.executable,'-B',tool,j,u,'--exceptions',e]);neg=cmd(d,'controls',[sys.executable,'-B',reg,j,u,e])
 a=json.loads(original.stdout);f=json.loads(fixed.stdout);raw=j.read_bytes();n=struct.unpack_from('<Q',raw)[0];checks=[(i,t,end,phase,end-t) for i in range(n) for k,t,end,phase,*_ in [struct.unpack_from('<7Q',raw,24+56*i)] if k==8];rows=[list(map(int,l.split())) for l in u.read_text().splitlines() if l.startswith('21 ')];assert len(checks)==len(rows)==len(f['phases'])==26
 for (i,t,end,phase,dt),row,qrow in zip(checks,rows,f['phases']):
  assert row==[21,end,phase,t] and dt>=0 and (dt,phase)==(qrow['check_ticks'],qrow['phase'])
 du=d/'duplicate-uart';lines=u.read_text().splitlines();k=next(i for i,s in enumerate(lines) if s.startswith('8 '));lines.insert(k,lines[k]);du.write_text('\n'.join(lines)+'\n')
 dup=cmd(d,'duplicate-control',[sys.executable,'-B',tool,j,du,'--exceptions',e])
 sealed[tag]=dict(archive=sha(archive),inputs={x.name:sha(x) for x in (j,u,e)},original_exit=original.returncode,original_matches_archived=a==get(d/'marker_decode.stdout'),original_slices_match=[r['disjoint_ticks'] for r in a['slices']]==[r['disjoint_ticks'] for r in f['slices']],fixed_exit=fixed.returncode,controls_exit=neg.returncode,duplicated_debit_exit=dup.returncode,independent_phase_rows=checks)
 save(p/'replays.json',sealed)
