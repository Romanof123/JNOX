set -eu
find cases outputs -type f > members
ls *.py *.json *.md *.log seal.sh >> members
sort -u members -o members
xargs -d '\n' sha256sum < members > MEMBER-SHA256
tar -czf reader-e780-first.tar.gz -T members MEMBER-SHA256
mkdir recheck
tar xf reader-e780-first.tar.gz -C recheck
(cd recheck && sha256sum -c MEMBER-SHA256 > ../verification.log)
dest=/mnt/d/codex/.jnox-work/next-fixed/340-verification-e780
mkdir -p "$dest"
cp reader-e780-first.tar.gz reader-supplement.en-ko.md "$dest/"
sha256sum reader-e780-first.tar.gz reader-supplement.en-ko.md "$dest"/*
