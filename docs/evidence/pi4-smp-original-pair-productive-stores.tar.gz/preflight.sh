#!/bin/bash
set -eu
base=$(cd "$(dirname "$0")" && pwd)
q=/home/ywcho/arm-speed-lab-tools/qemu-11.1.3
run=/home/ywcho/iv356-d781978-store
mkdir -m 700 "$run"
cd "$run"
tar -xzf "$base/source/docs/evidence/pi4-native-smp-first-execution-raw.tar.gz" sealed/p2
mkdir -m 700 tools
cp "$base/source/tools/"*.py tools/
cp "$base/source/tools/pi4_native_smp_store_plugin.c" tools/
python3 -m zipfile -e "$base/vendor/pyelftools-0.32-py3-none-any.whl" vendor
export PYTHONPATH="$run/vendor:$run/tools" PYTHONDONTWRITEBYTECODE=1
python3 - <<'PY'
from pathlib import Path
from pi4_native_smp_store import original,mappings
p=Path("sealed/p2")
m,k=original(p)
print("archived P2 digest and all members verified:",m["commit"],mappings(p,m,k))
PY
python3 tools/pi4_native_smp_store.py --help
p=/home/ywcho/arm-speed-lab-tools/qemu-11.1.3/build/qemu-system-aarch64
readelf -nW "$p" | grep 'Build ID'
file "$base/build/observer.so" "$p"
nm -D --defined-only "$base/build/observer.so"
nm -D --defined-only "$p" | awk '$2=="T" && $3~/^qemu_plugin_/ {print $3}' | sort > "$base/exported.txt"
nm -D --undefined-only "$base/build/observer.so" | awk '$2~/^qemu_plugin_/ {print $2}' | sort > "$base/imported.txt"
comm -23 "$base/imported.txt" "$base/exported.txt" > "$base/unresolved.txt"
test ! -s "$base/unresolved.txt"
wc -l "$base/imported.txt" "$base/exported.txt"
grep -n -E 'CONFIG_PLUGIN |^plugins = ' "$q/build/config-host.h" "$q/build/meson-private/cmd_line.txt"
grep -nE '^#define QEMU_PLUGIN_VERSION' "$q/include/plugins/qemu-plugin.h"
for f in include/plugins/qemu-plugin.h plugins/system.c plugins/loader.c plugins/core.c plugins/api.c hw/arm/raspi.c hw/arm/raspi4b.c tcg/tcg-op-ldst.c accel/tcg/translator.c accel/tcg/plugin-gen.c target/arm/helper.c target/arm/tcg/helper-a64.c target/arm/tcg/translate-a64.c build/config-host.h build/meson-private/cmd_line.txt; do sha256sum "$q/$f"; done
sed -n '163,180p' "$q/accel/tcg/translator.c"
sed -n '315,326p' "$q/tcg/tcg-op-ldst.c"
sed -n '8919,8935p;9653,9685p' "$q/target/arm/helper.c"
sed -n '165,200p;747,767p' "$q/include/plugins/qemu-plugin.h"
sed -n '18,26p' "$q/plugins/system.c"
sed -n '293,309p' "$q/plugins/loader.c"
grep -nE 'raspi_machine_class_common_init|default_cpus' "$q/hw/arm/raspi.c" "$q/hw/arm/raspi4b.c"
grep -E 'NATIVE SMP (CONFIG|CAL|TASK|END)|EXIT PID' sealed/p2/uart.bin
grep -E ' [[:alpha:]] private_result$' sealed/p2/{user.elf,native_peer.elf}.nm
grep -E ' (2002144|2002148|2002154|2002170|2002174|2002190|40048c|400490|400084|400088):' sealed/p2/{kernel,user,native_peer}.elf.dis
sha256sum "$base/build/observer.so" "$base/vendor/"*.whl "$p"
python3 - <<'PY'
import os,time,struct,mmap,sys
from pathlib import Path
p=Path('output-capability-test')
fd=os.open(p,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
os.posix_fallocate(fd,0,262464)
mm=mmap.mmap(fd,262464,flags=mmap.MAP_SHARED,prot=mmap.PROT_READ|mmap.PROT_WRITE)
os.close(fd)
mm[0:8]=b'share-ok'
print('filesystem shared visibility during mapping:',p.open('rb').read(8),'clock_resolution_seconds=',time.clock_getres(time.CLOCK_MONOTONIC), 'affinity=',os.sched_getaffinity(0),'policy=',os.sched_getscheduler(0),'nice=',os.getpriority(os.PRIO_PROCESS,0))
assert p.open('rb').read(8)==b'share-ok'
mm.close()
PY