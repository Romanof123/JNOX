import sys,json
from pathlib import Path
from elftools.elf.elffile import ELFFile
d=Path(sys.argv[1]);model=Path('/home/ywcho/arm-speed-lab-tools/qemu-11.1.3/build/qemu-system-aarch64')
with (d/'build/observer.so').open('rb') as f,model.open('rb') as q:
 p=ELFFile(f);e=ELFFile(q);pt=p.get_section_by_name('.dynsym');qt=e.get_section_by_name('.dynsym')
 exports={s.name:s for s in qt.iter_symbols() if s['st_shndx']!='SHN_UNDEF'}
 imports=sorted(s.name for s in pt.iter_symbols() if s['st_shndx']=='SHN_UNDEF' and s.name.startswith('qemu_plugin_'))
 assert all(exports[n]['st_info']['type']=='STT_FUNC' for n in imports)
 version,=pt.get_symbol_by_name('qemu_plugin_version');install,=pt.get_symbol_by_name('qemu_plugin_install')
 assert (version['st_info']['type'],version['st_size'])==('STT_OBJECT',4) and install['st_info']['type']=='STT_FUNC'
 sec=p.get_section(version['st_shndx']);off=version['st_value']-sec['sh_addr'];v=int.from_bytes(sec.data()[off:off+4],'little');assert v==7
 print(json.dumps(dict(emulator_machine=e['e_machine'],module_machine=p['e_machine'],module_type=p['e_type'],api_symbol_type=version['st_info']['type'],api_symbol_value=v,install_type=install['st_info']['type'],all_qemu_imported_names_are_exported_functions=imports),indent=2))