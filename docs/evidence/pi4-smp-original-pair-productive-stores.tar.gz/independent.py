"""Independent offline reader. Run with CAPTURE_DIR and prospective.json as arguments."""
import hashlib, json, math, re, struct, sys
from itertools import groupby
from pathlib import Path
from elftools.elf.elffile import ELFFile

root, prospect = map(Path, sys.argv[1:])
read = lambda p: json.loads(p.read_bytes())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
session = read(root/'session.json')
assert session['reason']=='terminal' and digest(root/'session.json')=='5c10f6cae71d4a4e22b4ac346c1a61761542e82f3069d694f63236d6f64ba70a'
assert set(session['files'])=={p.name for p in root.iterdir() if p.name!='session.json'}
assert all(digest(root/name)==h for name,h in session['files'].items())
prospective=read(prospect)
assert read(root/'launch.json')['argv']==prospective['argv']
assert digest(root/'manifest.json')==prospective['manifest']
manifest=read(root/'manifest.json')
assert manifest['slots']==prospective['slots']
assert all(digest(root/s['elf'])==s['elf_sha256'] for s in manifest['slots'])
assert digest(root/'kernel8.img')==manifest['kernel8_img_sha256']
assert digest(root/'kernel.elf')==manifest['kernel_elf_sha256']
ram=(root/'ram.bin').read_bytes()
base=0x2000000
def unpack(addr,n): return struct.unpack_from('<'+'Q'*n,ram,addr-base)
def walk(ttbr,va):
    a=ttbr&0x0000fffffffff000
    for s in [30,21,12]:
        ent,=unpack(a+8*((va>>s)&511),1)
        assert ent&3==3
        a=ent&0x0000fffffffff000
    return a+(va&4095),ent
def records(tag):
    return [tuple(map(int,m.group(1).split())) for m in re.finditer(r'^NATIVE SMP '+tag+r' ([0-9 ]+)$',uart,re.M)]
def file_bytes(elf,va,sz):
    s,=[s for s in elf.iter_segments() if s['p_type']=='PT_LOAD' and s['p_vaddr']<=va and va+sz<=s['p_vaddr']+s['p_filesz']]
    rel=va-s['p_vaddr'];return s.data()[rel:rel+sz]
uart=(root/'uart.bin').read_text()
assert records('END')==[(1,3,1,1)]
assert records('CONFIG')[0][0:3]==(1,62500000,1250000)
assert records('CONFIG')[0][4:]==(2,2)
exits=[tuple(map(int,x)) for x in re.findall(r'EXIT PID (\d+) (\d+)',uart)]
sieve=bytearray([1])*2000001
sieve[:2]=bytes(2)
for i in range(2,math.isqrt(len(sieve))+1):
    if sieve[i]:sieve[i*i::i]=bytes(len(sieve[i*i::i]))
truth=[sum(sieve[:1000001]),sum(sieve[1000001:])]
assert truth==[78498,70435] and exits==[(0,12),(1,77)]
before,sample,after=records('CAL')[0]
off=[before-sample,after-sample]
raw=(root/'observer.bin').read_bytes()
assert raw==(root/'observer.shared').read_bytes() and len(raw)==262464
hdr=struct.unpack_from('<8Q',raw)
assert hdr==(0x3535334f425331,1,2,1024,16,1,7,1)
res=hdr[5]
fields='seq kind cpu gen pc aux va pa val idx a b c d R extra'.split()
trace=(root/'exceptions.log').read_text()
pattern=r'^Taking exception (\d+) \[(IRQ|SVC)\] on CPU (\d+)\n\.\.\.from EL(\d) to EL1\n\.\.\.with ESR [^\n]+\n\.\.\.with SPSR (0x[0-9a-f]+)\n\.\.\.with ELR (0x[0-9a-f]+)\n\.\.\.to EL1 PC (0x[0-9a-f]+) PSTATE (0x[0-9a-f]+)$'
trace_entries=[m.groups() for m in re.finditer(pattern,trace,re.M)]
assert len(trace_entries)==trace.count('Taking exception')
return_lines=re.findall(r'^Exception return from AArch64 EL1 to AArch64 EL0 PC (0x[0-9a-f]+)$',trace,re.M)
all_runs=[[],[]]; counters=[]; packet_rows=[]; products=[]; journal_output=[]
for cpu,j in enumerate(records('JOURNAL')):
    cp,jaddr,n,width,loss,frames,fsize=j
    assert cp==cpu and 0<n<=256 and (width,loss,fsize)==(37,0,816)
    slot,aff,pri,rel,elapsed,ttbr=records('TASK')[cpu]
    assert (slot,aff,pri,rel)==(cpu,cpu,2,0) and ttbr>>48==cpu+1
    pcs=[0x40048c,0x400084]; pc=pcs[cpu]
    opcodes=[(0xb900012b,0x1100090b),(0xb900014b,0x17fffff0)]
    sp=manifest['slots'][cpu]
    assert (sp['cpu_mask'],sp['priority'],sp['release_cell'],sp['argv'])==(1<<cpu,2,0,['/bin/app'])
    with (root/sp['elf']).open('rb') as f:
        elf=ELFFile(f);sym,=elf.get_section_by_name('.symtab').get_symbol_by_name('private_result')
        assert (sym['st_value'],sym['st_size'])==(0x402000,4)
        initial,=struct.unpack('<I',file_bytes(elf,0x402000,4))
        assert initial==1-cpu
        assert struct.unpack('<II',file_bytes(elf,pc,8))==opcodes[cpu]
    pcpa,code=walk(ttbr,pc)
    assert struct.unpack_from('<II',ram,pcpa-base)==opcodes[cpu]
    pa,desc=walk(ttbr,0x402000)
    value,=struct.unpack_from('<I',ram,pa-base)
    assert value==truth[cpu] and pa==(0x2136000,0x254b000)[cpu]
    assert (desc>>6)&3==1 and (desc>>53)&3==3 and (code>>6)&3==3 and (code>>53)&3==1
    products.append(dict(cpu=cpu,slot=slot,root=hex(ttbr),pc=hex(pc),code_pa=hex(pcpa),count_pa=hex(pa),initial=initial,terminal=value,exit=exits[cpu][1]))
    rows=[unpack(jaddr+i*width*8,width) for i in range(n)]
    framesets=[(unpack(frames+2*i*fsize,102),unpack(frames+(2*i+1)*fsize,102)) for i in range(n)]
    es=[e for e in trace_entries if int(e[2])==cpu]
    assert len(es)==n
    buf=64+cpu*(128+1024*128)
    h=struct.unpack_from('<16Q',raw,buf)
    count,used,dropped,executed,mem,done,aborted,invalid,generations,pending,waiting,discons,returns,firsts,first_loss,pending_mem=h
    assert count==used<=1024 and dropped==first_loss==aborted==pending==waiting==invalid==pending_mem==0
    assert done==executed==mem==truth[cpu]-initial
    pkt=[dict(zip(fields,struct.unpack_from('<16Q',raw,buf+128+128*i))) for i in range(used)]
    assert not any(raw[buf+128+128*used:buf+128+128*1024])
    assert all(p['seq']==1+i and p['cpu']==cpu for i,p in enumerate(pkt))
    packet_rows.append(pkt)
    journal_output.append([])
    ni=0; user=None; gen=0; active=2; last_R=0; last_t=0; resumed=0; samples=0
    for i,p in enumerate(pkt):
        k=p['kind']
        assert last_t<=p['a']<=p['b']
        last_t=p['b']
        if k==1:
            assert user is None and ni and ni<len(rows) and (i==0 or pkt[i-1]['kind']==4) and pkt[i+1]['kind']==2
            prep,closing=rows[ni-1:ni+1]; saved,sel=framesets[ni-1]
            gen+=1;last_R=p['R']
            assert p['pc']==0x2002154 and prep[7]==closing[6]==cpu and prep[22]==closing[21]==ttbr
            assert p['R']==closing[8] and prep[5]<=p['R']<closing[4] and sel[33]&31==0
            user=dict(cpu=cpu,generation=gen,prepare=ni-1,closing=ni,root=hex(ttbr),pop_pc=sel[32],R=p['R'],E=closing[4],return_seq=p['seq'],resume_ppi=(prep[6]==cpu and prep[2]==1 and prep[3]&1023==30 and saved==sel),stores=[])
            all_runs[cpu].append(user)
        elif k==2:
            assert user and pkt[i-1]['kind']==1 and p['pc']==user['pop_pc']
            user.update(first_seq=p['seq'],first_hi=p['b'])
        elif k==3:
            row=rows[ni]; f,g=framesets[ni]; ex=es[ni]
            num,kind,ecpu,origin,spsr,elr,vec,state=ex
            assert row[:2]==(cpu,ni) and row[6]==active and (row[6]==cpu)==(user is not None)
            active=row[7]
            is_irq=row[2]==1
            assert int(num)==(5 if is_irq else 2) and kind==('IRQ' if is_irq else 'SVC') and int(origin)==(0 if user else 1)
            assert row[30:32]==(int(elr,16),int(spsr,16)) and int(state,16)&0x8f==0x85
            assert p['extra']==row[2] and p['aux']==int(vec,16)==0x2001800+128*(9 if (is_irq and user) else 5 if is_irq else 8)
            # Matched QEMU records the SVC PC after its advance; inspect actual delta.
            from_delta=row[30]-p['pc']
            if is_irq:assert from_delta==0
            else:assert from_delta in (0,4) and user and row[3]==1 and row[30]==0x400020
            assert pkt[i+1]['kind']==4 and pkt[i+1]['pc']==p['aux']
            if user:
                assert f[32:34]==row[30:32] and f[33]&31==0 and 0x01001000<=f[31]<=0x01011000 and f[31]%16==0
                assert rows[user['closing']]==row and row[21]==ttbr
                user.update(exception_seq=p['seq'],exception_lo=p['a'],exception_pc=p['pc'],vector=p['aux'])
                if is_irq and row[3]&1023==30:
                    assert row[32]==row[10]<=row[4] and row[33]&7==5
                user=None
            journal_output[cpu].append(dict(i=ni,kind=kind,from_el=int(origin),from_delta=from_delta,pc=hex(p['pc']),ELR=elr,SPSR=spsr,vector=vec,source_slot=row[6],next_slot=row[7],root=hex(row[21]),entry=row[4],resume=row[8],ppi=row[3] if is_irq else None))
            ni+=1
        elif k==4:assert pkt[i-1]['kind']==3 and user is None
        elif k==5:
            assert user and p['gen']==user['generation'] and user['first_hi']<=p['a']<=p['b']<=p['c']<=p['d']
            assert (p['pc'],p['aux'],p['va'],p['pa'])==(pc,pc+4,0x402000,pa)
            samples+=1
            assert p['idx']==samples*256 and p['val']==initial+p['idx']
            last_t=p['d'];user['stores'].append(p)
        elif k in (6,7):
            assert user is None and p['pc']==(0x2002170 if k==6 else 0x2002174)
            assert (pkt[i+1] if k==6 else pkt[i-1])['kind']==(7 if k==6 else 6)
        else:raise AssertionError(k)
        assert p['gen']==gen and p['R']==last_R
    assert ni==n==discons and user is None and generations==gen==firsts==returns and samples==done//256
    ppi=[r for r in all_runs[cpu] if r['resume_ppi'] and r['stores']]
    assert ppi and samples<=(307,276)[cpu]
    counters.append(dict(rows=used,verified_stores=done,samples=samples,discontinuities=ni,returns=gen,ppi_returns_with_stores=len(ppi),events_by_type={str(k):len(list(g)) for k,g in groupby(sorted(p['kind'] for p in pkt))},aborted=aborted,dropped=dropped,invalid=invalid,pending=pending,first_loss=first_loss))
assert len(return_lines)==sum(c['returns'] for c in counters)
assert sorted(int(x,16) for x in return_lines)==sorted(r['pop_pc'] for group in all_runs for r in group)
def view(p):return {k:p[k] for k in ('cpu','seq','gen','val','idx','a','b','c','d')}
def witness(a,b,ps):
    rr=[a,b];r=(res if res>0 else 1);guards=[[x['stores'][0]['d']+r,x['stores'][-1]['a']-r] for x in rr]
    low=max(g[0] for g in guards);high=min(g[1] for g in guards)
    margins=[ps[0]['a']-r-low]+[q['a']-r-(p['d']+r) for p,q in zip(ps,ps[1:])]+[high-(ps[-1]['d']+r)]
    assert all(m>0 for m in margins) and [p['cpu'] for p in ps] in ([0,1,0,1],[1,0,1,0])
    for x in rr:
        assert x['first_hi']<x['stores'][0]['a'] and x['stores'][-1]['d']<x['exception_lo']
        assert [p['val'] for p in ps if p['cpu']==x['cpu']]==sorted({p['val'] for p in ps if p['cpu']==x['cpu']})
    intervals=[[max(a['R'],b['R']+d),min(a['E'],b['E']+d)] for d in off]
    assert all(i<j for i,j in intervals)
    return dict(stores=[view(p) for p in ps],runs=[{k:v for k,v in x.items() if k!='stores'} for x in rr],guard_stores=[[view(x['stores'][0]),view(x['stores'][-1])] for x in rr],margin_ns=margins,guest_at_offset_endpoints=intervals,guest_uniform_outer=[intervals[0][0],intervals[-1][1]],guest_all_offset_intersection=[intervals[-1][0],intervals[0][1]])
a,b=all_runs[0][0],all_runs[1][0]
first_chain=witness(a,b,[packet_rows[c][seq-1] for c,seq in [(0,17),(1,12),(0,23),(1,13)]])
# A second witness, after same-frame PPI30 resumption on both CPUs. Maximize
# the smallest host separation using the observed data, including the guards.
best=None
for a in all_runs[0]:
    for b in all_runs[1]:
        if not (a['resume_ppi'] and b['resume_ppi'] and min(len(a['stores']),len(b['stores']))>=4):continue
        groups=[a['stores'],b['stores']]
        low=max(g[0]['d']+res for g in groups);high=min(g[-1]['a']-res for g in groups)
        for start in (0,1):
            def selected(gap):
                out=[];prev=low
                for cpu in (start,start^1,start,start^1):
                    p=next((p for p in groups[cpu] if p['a']-res-prev>=gap and high-p['d']-res>=gap),None)
                    if not p:return None
                    out.append(p);prev=p['d']+res
                return out
            lo,hi=0,max(0,high-low)
            while lo<hi:
                m=(lo+hi+1)//2
                if selected(m):lo=m
                else:hi=m-1
            if lo>0 and (best is None or lo>best[0]):
                best=(lo,witness(a,b,selected(lo)))
assert best
print(json.dumps(dict(session=digest(root/'session.json'),capture_files=len(session['files']),first_argv_matches=True,reference=prospective['session'],clock_offset=off,clock_resolution_ns=res,calibration=[before,sample,after],products=products,counters=counters,production_chain_independent=first_chain,ppi_resumed_chain=best[1],journal=journal_output),indent=2))