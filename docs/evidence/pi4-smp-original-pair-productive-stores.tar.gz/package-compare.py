from pathlib import Path
import sys, hashlib, json, re
r=Path(sys.argv[1]);a=r/'sealed/p2';b=r/'first/first-store-traced'
for f in sorted(a.glob('*.dis')):
 orig=f.read_bytes();new=(b/f.name).read_bytes()
 norm=lambda t:re.sub(rb'^/[^\n]+:\s+file format',b'OBJECT: file format',t,flags=re.M)
 print(f.name,hashlib.sha256(orig).hexdigest(),hashlib.sha256(new).hexdigest(), 'body_equal',norm(orig)==norm(new))
 assert norm(orig)==norm(new)
print('other package files', [x.name for x in sorted(a.iterdir()) if x.name in ['kernel.elf','kernel8.img','manifest.json','native_peer.elf','user.elf'] or x.name.endswith('.nm')])
assert all((b/n).read_bytes()==(a/n).read_bytes() for n in ['kernel.elf','kernel8.img','manifest.json','native_peer.elf','user.elf','kernel.elf.nm','user.elf.nm','native_peer.elf.nm'])
print('output copy sha256',hashlib.sha256((b/'observer.bin').read_bytes()).hexdigest(),hashlib.sha256((b/'observer.shared').read_bytes()).hexdigest())
print('first only', [p.name for p in (r/'first').iterdir() if p.is_dir()])