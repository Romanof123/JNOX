#!/bin/bash
set -eu
run=/home/ywcho/iv356-d781978-store
cd "$run"
export PYTHONPATH="$run/vendor:$run/tools" PYTHONDONTWRITEBYTECODE=1
python3 - <<'PY'
from pathlib import Path
import json,datetime,hashlib,subprocess,sys
args=json.loads(Path('capture-command.json').read_bytes())
assert hashlib.sha256(Path('prospective.json').read_bytes()).hexdigest()=='673e6a7d2c5e214171177e8fd89ef18b77bed056eabbce338fcae6624763b7b7'
assert hashlib.sha256(Path('first/seal.json').read_bytes()).hexdigest()==args[-1]=='61cabffaf0aaf36e2ab601fe802a244b454847a6c16ce29e6045423626d29a53'
t=datetime.datetime.now(datetime.timezone.utc)
with Path('capture.once').open('x') as f:f.write(t.isoformat()+'\n')
with Path('capture.stdout').open('xb') as out, Path('capture.stderr').open('xb') as err:
 r=subprocess.run(args, stdout=out,stderr=err)
sf=Path('first/first-store-traced/session.json')
print('capture_rc',r.returncode,'elapsed_s',(datetime.datetime.now(datetime.timezone.utc)-t).total_seconds())
print(Path('capture.stdout').read_text(),Path('capture.stderr').read_text())
if sf.exists():print(sf.read_text())
sys.exit(r.returncode)
PY