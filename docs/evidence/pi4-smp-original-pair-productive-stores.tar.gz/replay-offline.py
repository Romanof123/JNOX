"""Run both offline decoders from an extracted evidence archive, with Python 3."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
from types import SimpleNamespace
import zipfile

base=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for line in (base/"SHA256SUMS").read_text().splitlines():
    h,name=line.split("  ",1)
    assert sha(base/name)==h,name
with tempfile.TemporaryDirectory() as temp:
    work=Path(temp)
    with zipfile.ZipFile(next((base/"vendor").glob("*.whl"))) as z:z.extractall(work/"lib")
    env=dict(os.environ,PYTHONPATH=str(work/"lib"),PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1")
    sys.dont_write_bytecode=True
    sys.path[:0]=[str(work/"lib"),str(base/"source/tools")]
    from pi4_native_smp_store import report
    sealdir=base/"first"
    capture=sealdir/"first-store-traced"
    assert sha(sealdir/"seal.json")=="61cabffaf0aaf36e2ab601fe802a244b454847a6c16ce29e6045423626d29a53"
    seal=json.loads((sealdir/"seal.json").read_bytes())
    assert all(sha(sealdir/f)==h for f,h in seal["files"].items())
    with tarfile.open(base/"source/docs/evidence/pi4-native-smp-first-execution-raw.tar.gz") as t:
        for m in t:
            if m.isfile() and m.name.startswith("sealed/p2/"):
                p=Path(m.name)
                assert len(p.parts)==3 and p.parts[:2]==("sealed","p2") and p.name not in ("..",".")
                dest=work/p;dest.parent.mkdir(exist_ok=True,parents=True);dest.write_bytes(t.extractfile(m).read())
    # Replace only the host location of the original archive after authenticating the sealed bytes.
    seal=dict(seal,p2=str(work/"sealed/p2"))
    assert sha(work/"sealed/p2/session.json")==seal["reference"]
    stock=report(SimpleNamespace(out=sealdir,session_sha=sha(capture/"session.json")),seal)
    assert json.loads(json.dumps(stock))==json.loads((base/"production-report.json").read_bytes())
    independent=subprocess.check_output([sys.executable,str(base/"independent.py"),str(capture),str(base/"prospective.json")],env=env)
    j=json.loads(independent)
    assert j==json.loads((base/"independent.json").read_bytes())
    print("Archive checksums, original reference, production result and independent reconstruction verified.")
    print("New session",j["session"],"stock result",stock["strict_overlap"])
    print("PPI-resumed witness",[(r["cpu"],r["seq"],r["val"]) for r in j["ppi_resumed_chain"]["stores"]])
    print("Widened margins (ns)",j["ppi_resumed_chain"]["margin_ns"])