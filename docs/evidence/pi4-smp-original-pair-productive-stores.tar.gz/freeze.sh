#!/bin/bash
set -eu
base=$(cd "$(dirname "$0")" && pwd)
run=/home/ywcho/iv356-d781978-store
cd "$run"
export PYTHONPATH="$run/vendor:$run/tools" PYTHONDONTWRITEBYTECODE=1
python3 - "$base" <<'PY'
from pathlib import Path
import json,sys,hashlib,datetime,os
base=Path(sys.argv[1]); r=Path.cwd(); q=Path('/home/ywcho/arm-speed-lab-tools/qemu-11.1.3'); b=json.loads((base/'build/build.json').read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,obj):
 with p.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
x=dict(api=7,qemu_sha256=b['qemu_sha256'],build_id=b['qemu_build_id'],header_sha256=b['header_sha256'],plugin_sha256=b['plugin_sha256'],plugin_build_sha256=sha(base/'build/build.json'),plugin_source_sha256=b['source_sha256'],build_configuration={'config-host.h':sha(q/'build/config-host.h'),'meson-cmd_line.txt':sha(q/'build/meson-private/cmd_line.txt'),'CONFIG_PLUGIN':1,'plugins':True},capabilities=dict.fromkeys(['vcpu_exec','vcpu_memory','physical_address','store_u32_le','discontinuity','eret_first_user','stopped_shared_output','cpu_indexed_exceptions'],True),evidence={'qualification_log_sha256':sha(base/'preflight.log'),'matching_imports':(base/'imported.txt').read_text().splitlines(),'unresolved':(base/'unresolved.txt').read_text().splitlines(),'mode':'Availability from exact SDK code, exported symbols, archived PC/opcodes/TTBR walk and stopped-output code. The local shared file probe is independent of guest operation. Execution, event completeness, stores, host ordering and guest counter bounds must be assessed after this first.'})
write(r/'availability.json',x)
p2=r/'sealed/p2'; cmd=json.loads((p2/'launch.json').read_bytes())['argv']; dst=r/'first/first-store-traced'; src=Path(cmd[cmd.index('-kernel')+1]).parent
argv=[a.replace(str(src)+'/',str(dst)+'/') for a in cmd]+['-plugin',str(dst.parent/'observer.so')+',out='+str(dst/'observer.shared')]
py=r/'tools/pi4_native_smp_store.py'
write(r/'prospective.json',dict(id='356-d781978-independent-p2-stage2-first',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head='d7819781ce1995399a67340fa775bfc544c1c9cc',argv=argv,session=sha(p2/'session.json'),manifest=sha(p2/'manifest.json'),slots=json.loads((p2/'manifest.json').read_bytes())['slots'],clock='original 62.5MHz; 1,250,000 ticks; no clock, pinning or scheduling flags',cadence_ms=25,watchdog_s=120,host_clock='Linux CLOCK_MONOTONIC; widen each reported endpoint by clock_getres; signed comparisons; no interpolation to guest ticks',bounds={'per_cpu_shared_rows':1024,'row_words':16,'completed_stride':256,'C_max':307,'Rust_max':276,'journal_rows_per_cpu':256,'stopped_map_size':262464},limitations='All streams share a fixed 1024-row ringless buffer per CPU, with first-drop reporting. The consumer enforces journal and sparse limits. A drop or unmatched idle/return/exception blocks promotion.',variant='original p2, one acquisition, no retries',tools={p.name:sha(p) for p in (r/'tools').iterdir() if p.is_file()},pyelftools_wheel=sha(next((base/'vendor').glob('*.whl'))),seal_argv=['python3',str(py),'seal',str(p2),str(r/'first'),argv[0],str(base/'build/observer.so'),str(q/'include/plugins/qemu-plugin.h'),str(base/'build/build.json'),str(r/'availability.json'),sha(r/'availability.json')],qemu_requested=argv[0],qemu_realpath=str(Path(argv[0]).resolve()),host_affinity=sorted(os.sched_getaffinity(0)),scheduler=os.sched_getscheduler(0),nice=os.getpriority(os.PRIO_PROCESS,0)))
PY
python3 - <<'PY'
import json,subprocess,sys,hashlib
from pathlib import Path
p=json.loads(Path('prospective.json').read_bytes())
assert p['argv'][0]==p['qemu_realpath'] and not Path('first').exists()
with Path('seal.stdout').open('xb') as out,Path('seal.stderr').open('xb') as err:rc=subprocess.run(p['seal_argv'],stdout=out,stderr=err).returncode
print('seal',rc,Path('seal.stdout').read_text(),Path('seal.stderr').read_text())
if rc:sys.exit(rc)
digest=hashlib.sha256(Path('first/seal.json').read_bytes()).hexdigest()
assert digest==Path('seal.stdout').read_text().strip()
print('prospective',hashlib.sha256(Path('prospective.json').read_bytes()).hexdigest(),flush=True)
with Path('capture-command.json').open('x') as f:json.dump(['python3',str(Path('tools/pi4_native_smp_store.py').resolve()),'capture',str(Path('first').resolve()),digest],f)
PY