#!/usr/bin/env python3
"""Build a portable package from already-completed native lifecycle cold boots."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import stat
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
from evidence_io import archive, copy, export, extract, git, read, regular, require, sha, write
from replay import BOARD, FAILURE_STAGES, FAILURE_VERIFIER, HEADERS_HASH, LINUX, PROFILE, RAW, STAGES, VERIFIER, observer_args

PM = Path(__file__).resolve().parent
LAB = Path.home() / "jnox406-lab"
KNOWN_SOURCE = {"arch/aarch64", "kernel", "boards", "examples/linux-source-net-lifecycle", PROFILE}
BUILD_TOOLS = ["tools/build_linux_source_virtio_net.py", "tools/build_native_el0.py", "tools/build_kernel.py"]


def tool_closure(repo, rev, entrypoints):
    """Follow imports only among Python modules tracked under tools/ at this revision."""
    paths = {p for p in git(repo, "ls-tree", "-r", "--name-only", rev, "--", "tools").decode().splitlines()
             if re.fullmatch(r"tools/[A-Za-z_][A-Za-z_0-9]*\.py", p)}
    selected, pending = set(), list(entrypoints)
    while pending:
        path = pending.pop()
        if path in selected:
            continue
        require(path in paths, f"missing tracked Python tool {rev}:{path}")
        selected.add(path)
        code = git(repo, "show", f"{rev}:{path}")
        for node in ast.walk(ast.parse(code)):
            if isinstance(node, ast.Import):
                names = [n.name for n in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                names = [node.module]
            else:
                continue
            for name in names:
                dependency = "tools/" + name.split(".")[0] + ".py"
                if dependency in paths and dependency not in selected:
                    pending.append(dependency)
    return selected


def header_ledger(headers, dest):
    dest.mkdir(parents=True, exist_ok=True)
    if (dest / "tree.json").exists():
        return
    records = {}
    for root, dirs, files in os.walk(headers, followlinks=False):
        directory = Path(root)
        for name in dirs:
            require(stat.S_ISDIR((directory / name).lstat().st_mode), f"linked header directory {directory / name}")
        for name in files:
            file = directory / name
            require(stat.S_ISREG(file.lstat().st_mode), f"linked or irregular header {file}")
            records[file.relative_to(headers).as_posix()] = sha(file)
    whole = hashlib.sha256()
    for name, digest in sorted(records.items()):
        whole.update(name.encode() + b"\0" + bytes.fromhex(digest))
    require(len(records) == 9403 and whole.hexdigest() == HEADERS_HASH, "pinned compiler header tree differs")
    write(dest / "tree.json", records)


def add_build(stage, args, build, bid):
    dest = stage / "builds" / bid
    m, imp = read(regular(build, "native/manifest.json")), read(regular(build, "imported/import.json"))
    expected = "lifecycle-failure-service" if args.failures else "lifecycle-service"
    require(m["tracked_changes"] == "" and imp["mode"] == expected, "expected clean lifecycle build")
    native = ["manifest.json", "kernel.elf", "user.elf", "native_peer.elf", "build.log"]
    for name in native:
        copy(regular(build, Path("native") / name), dest / "native" / name)
    copy(regular(build, "build.log"), dest / "build.log")
    objects = set(imp["input_sha256_by_object"]) | set(imp["objects"]) | {imp[k]["filename"] for k in ("callback_object","driver_object")}
    for name in objects | {"service.elf","peer.elf","service.map","peer.map","import.json"}:
        require(Path(name).name == name, f"unexpected intake filename {name}")
        copy(regular(build, Path("imported") / name), dest / "imported" / name)
    rev = m["commit"]
    require(re.fullmatch("[0-9a-f]{40}", rev) and imp["header_tree_sha256"] == HEADERS_HASH, "commit or header profile")
    headers = args.headers or Path(imp["header_root"])
    source = args.linux_source or Path(imp["source"]["path"])
    hdir = stage / "source/linux-headers" / HEADERS_HASH
    header_ledger(headers, hdir)
    for path, digest in imp["header_profile"]["generated_sha256"].items():
        copy(regular(headers, path), hdir / "files" / path, digest)
    tracked = KNOWN_SOURCE | tool_closure(args.repo, rev, BUILD_TOOLS)
    inputs = {}
    for name, digest in imp["input_sha256"].items():
        path = Path(name)
        require(".." not in path.parts, f"invalid compiler path {name}")
        if name.startswith("headers/"):
            rel = path.relative_to("headers")
            target = hdir / "files" / rel
            copy(regular(headers, rel), target, digest)
        elif name == imp["upstream"]["path"]:
            require(imp["upstream"]["commit"] == LINUX and name == "drivers/net/virtio_net.c", "upstream input")
            target = stage / "source/linux" / LINUX / name
            copy(source, target, digest)
        elif path.is_absolute():
            require(path.parent.name == "build" and path.suffix in (".h",".inc"), f"unrecognized generated input {name}")
            target = dest / "imported" / path.name
            copy(regular(build, Path("imported") / path.name), target, digest)
        else:
            tracked.add(name)
            target = stage / "source/jnox" / rev / path
        inputs[name] = target.relative_to(stage).as_posix()
    export(args.repo, rev, tracked, stage / "source/jnox" / rev)
    write(dest / "source-index.json", {"commit": rev, "compiler_inputs": inputs})
    return m


def add_capture(stage, args, label, build, rev, bid, through_open, correction=None):
    origin = build / label
    require(origin.is_dir() and not origin.is_symlink() and not (origin / "failure.json").exists(),
            f"expected completed capture {origin}")
    require((regular(origin, "observer-commit.txt")).read_text().strip() == rev, f"{label} capture-time observer differs")
    dest = stage / "captures" / label
    expected = FAILURE_STAGES if args.failures else STAGES[:2] if through_open else STAGES
    require({p.name for p in origin.iterdir() if p.is_dir()} == set(expected), f"{label} checkpoint scope")
    raw = list(RAW)
    missing_result = False
    if args.failures:
        raw[raw.index("nonces.bin")] = "nonce.bin"
        missing_result = not (origin / "result.json").exists()
        if missing_result:
            require(correction is not None, "incomplete failure capture without corrected offline result")
            raw.remove("result.json")
    for name in raw:
        copy(regular(origin, name), dest / name)
    for name in expected:
        for file in ("qmp.json", "halted.json", "ram.json"):
            copy(regular(origin, Path(name) / file), dest / name / file)
    verifier = FAILURE_VERIFIER if args.failures else VERIFIER
    result = {"label": label, "build": bid, "build_commit": read(stage / "builds" / bid / "native/manifest.json")["commit"],
              "observer_commit": rev, "through_open": through_open, "failures": args.failures}
    corrected = correction[0] if correction else rev
    for revision in {rev,corrected}:
        require(re.fullmatch("[0-9a-f]{40}",revision), "observer revision")
        observer = stage / "observers" / revision
        if not observer.exists():
            tracked = tool_closure(args.repo, revision, [verifier]) | {BOARD + "/board.json", BOARD + "/virt-net.dtb.gz"}
            export(args.repo, revision, tracked, observer)
    if correction:
        require(args.failures and rev != corrected, "correction must identify a separate failure-profile revision")
        directory = stage / "corrections" / label
        copy(Path(correction[1]), directory / "corrected-result.json")
        copy(Path(correction[2]), directory / "capture-observer.log")
        logged = (directory / "capture-observer.log").read_text().splitlines()
        require(logged and logged[-1].startswith("ValueError: "), "original observer terminal error")
        original = stage / "observers" / rev
        updates = stage / "observers" / corrected
        helpers = sorted(p.relative_to(original).as_posix() for p in original.rglob("*") if p.is_file() and
                         p.relative_to(original).as_posix() not in ("commit.raw",verifier))
        require(all(sha(original / p) == sha(updates / p) for p in helpers), "capture helper changed across offline correction")
        def capture_functions(observer):
            code = ast.parse((observer / verifier).read_bytes())
            return {node.name:ast.dump(node) for node in code.body if isinstance(node,ast.FunctionDef) and
                    node.name in ("layout","state","capture")}
        before = capture_functions(original)
        require(set(before) == {"layout","state","capture"} and before == capture_functions(updates),
                "changed acquisition code in replacement observer")
        (directory / "observer.patch").write_bytes(git(args.repo,"diff",rev,corrected,"--",verifier))
        write(directory / "change.json", {"capture":rev, "replay":corrected, "capture_helpers":helpers,
              "unchanged_acquisition_functions":sorted(before), "original_error":logged[-1]})
        result.update(replay_commit=corrected, baseline=f"corrections/{label}/corrected-result.json",
                      capture_without_result=missing_result)
    return result


def add_independent(stage, args, case, reports):
    label = case["label"]
    report = reports.get(label)
    if report is None and args.independent_dir is not None:
        candidate = args.independent_dir / (label + ".json")
        if candidate.is_file():
            report = candidate
    if report is None:
        require(not args.failures, f"failure case {label} requires an independent reader result")
        return
    reader = args.independent_reader or args.independent_dir / "replay.py"
    copy(reader, stage / "qa/replay.py")
    prior = read(report)
    if args.failures:
        require([c["case"] for c in prior["cases"]] == [1,2,3,4] and len(prior["frame_sha256"]) == 2 and
                "error" not in prior, f"independent failure report {label}")
    else:
        require(prior.get("errors") == [] and prior.get("scope") == ("through-open" if case["through_open"] else "full"),
                f"independent report scope or errors {label}")
    report_target = f"qa/reports/{label}.json"
    copy(report, stage / report_target)
    capture_rel = "../../captures/" + label if args.failures else "captures/" + label
    argv = ["qa/replay.py", "builds/" + case["build"], capture_rel, "source/linux/" + LINUX + "/drivers/net/virtio_net.c"]
    if not case["through_open"]:
        argv.append("--full")
    case["independent"] = {"report": report_target, "argv": argv, "scope": "four failures and recovery" if args.failures else prior["scope"]}


def mapping(pairs, labels, description):
    result = dict(pairs)
    require(len(result) == len(pairs) and set(result) <= labels, f"duplicate or unknown label in {description}")
    return result


def package(stage, args):
    cases = []
    labels = {c[0] for c in args.case}
    require(len(labels) == len(args.case) and all(re.fullmatch(r"[A-Za-z0-9][\w.-]*", label) for label in labels),
            "case labels must be unique directory names")
    opens = set(args.through_open)
    require(opens <= labels | {"*"}, "unknown --through-open label")
    reports = {label:Path(path) for label,path in mapping(args.independent_report, labels, "--independent-report").items()}
    commits = mapping(args.expect_build, labels, "--expect-build")
    corrections = mapping([(c[0],c[1:]) for c in args.replay_with], labels, "--replay-with")
    require(not args.failures or len(labels) == 2 and not opens, "four-fault release requires two completed full cold boots")
    for label, path, rev in args.case:
        require(re.fullmatch("[0-9a-f]{40}", rev), f"full observer commit required for {label}")
        build = Path(path)
        bid = sha(regular(build, "native/manifest.json"))
        if not (stage / "builds" / bid).exists():
            add_build(stage, args, build, bid)
        case = add_capture(stage, args, label, build, rev, bid, label in opens or "*" in opens, corrections.get(label))
        if label in commits:
            require(case["build_commit"] == commits[label], f"specified build commit differs for {label}")
        add_independent(stage, args, case, reports)
        cases.append(case)
    for file in (args.vendor / "elftools").rglob("*.py"):
        copy(regular(args.vendor, file.relative_to(args.vendor)), stage / "vendor" / file.relative_to(args.vendor))
    regular(stage, "vendor/elftools/elf/elffile.py")
    for name in ("LICENSE","METADATA"):
        rel = Path("pyelftools-0.32.dist-info") / name
        copy(regular(args.vendor, rel), stage / "vendor" / rel)
    copy(args.license, stage / "source/GPL-2.0")
    for report in args.report_note:
        require(report.suffix.lower() in (".md",".txt"), f"expected a text QA report {report}")
        copy(report, stage / "qa/notes" / report.name)
    for module in ("replay.py", "evidence_io.py"):
        copy(PM / module, stage / module)
    for file in ("build.sh","capture.sh","package_lifecycle.py"):
        copy(PM / file, stage / "provenance" / file)
    write(stage / "bundle.json", {"format": 1, "cases": cases})
    summary, commands = [], []
    for case in cases:
        label = case["label"]
        launch = read(stage / "captures" / label / "launch.json")
        mode = "first registration through first open, before traffic" if case["through_open"] else "two generations through final teardown"
        if args.failures:
            mode = "four test-only EL0 admission failures and clean recovery"
        qa = "recorded independent reader output compared in full" if "independent" in case else "frozen capture observer replay"
        summary.append(f"| {label} | {mode} | {case['build_commit']} | {case['observer_commit']} | {case.get('replay_commit',case['observer_commit'])} | {qa} |")
        cmds = [observer_args(case, launch)]
        if "independent" in case:
            cmds.append(case["independent"]["argv"])
        commands.extend("PYTHONPATH=vendor " + shlex.join(["python3","-B",*argv]) for argv in cmds)
    (stage / "README.md").write_text(
        "# Original Linux virtio-net native lifecycle\n\nExtract the archive in an empty Linux directory. "
        "From its root, run `python3 -B replay.py`. It requires Python 3.10+, GNU nm and aarch64-linux-gnu-nm. "
        "Pyelftools 0.32 and its license are under vendor/. Replay uses the retained files and scratch copies for corruption tests.\n\n"
        "| Capture | Captured extent | Build commit | Capture observer | Replay observer | Verification |\n|---|---|---|---|---|---|\n" +
        "\n".join(summary) + "\n\nThe kernel embeds the separate native AArch64 driver and peer ELFs. The import manifest identifies the original "
        "Linux source, the untreated and packet-profile object files, the linked callback object, both ELF maps and compiler commands. "
        "Each build's source-index.json maps every compiler dependency to exact archived bytes. The header manifest covers the full "
        "9,403-file build tree, while files/ contains the compiled dependencies and pinned generated headers. "
        "The board DTB and its QEMU binary digest are the observer's pinned model description. launch.json records the launched QEMU path and arguments.\n\n"
        "The stopped checkpoints contain QMP state and sparse physical reads. Each capture also retains the QEMU instruction, "
        "IRQ and MMIO trace, original host stream, Ethernet PCAP and UART. The scope in each independent JSON identifies "
        "the portion its reader checked. " + (
        "Each failure capture retains 15 checkpoints. Four bounded test-only EL0 provider returns exercise allocation, netdevice registration, "
        "CPU hotplug registration, and XDP memory-model registration during open. The fifth claim receives a fresh data frame and ACK. "
        "The launch records do not contain a capture-time QEMU executable digest. When capture and replay commits differ, corrections/ "
        "retains the capture observer log, corrected result and exact source patch. Detached replay reproduces the historical error, "
        "then runs the corrected observer with corruption controls. " if args.failures else "") +
        "Individual commands follow.\n\n```sh\n" + "\n".join(commands) + "\n```\n", encoding="utf-8")
    members = sorted(p for p in stage.rglob("*") if p.is_file())
    (stage / "SHA256SUMS").write_text("".join(f"{sha(p)}  {p.relative_to(stage).as_posix()}\n" for p in members))


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--case", nargs=3, action="append", required=True, metavar=("LABEL","BUILD","OBSERVER_COMMIT"))
    cli.add_argument("--failures", action="store_true", help="package two four-fault cold boots and independent reports")
    cli.add_argument("--replay-with", nargs=4, action="append", default=[], metavar=("LABEL","REPLAY_COMMIT","RESULT","ORIGINAL_LOG"))
    cli.add_argument("--through-open", nargs="?", action="append", default=[], const="*", metavar="LABEL",
                     help="select a first-open-only capture; omit the label to apply to all")
    cli.add_argument("--expect-build", nargs=2, action="append", default=[], metavar=("LABEL","COMMIT"))
    cli.add_argument("--output", required=True, type=Path, help="new release directory")
    cli.add_argument("--repo", type=Path, default=LAB / "src")
    cli.add_argument("--linux-source", type=Path, help="relocated pinned Linux C translation unit")
    cli.add_argument("--headers", type=Path, help="relocated pinned Alpine ARM64 header tree")
    cli.add_argument("--license", type=Path, default=PM.parent / "jnox424-pm/GPL-2.0")
    cli.add_argument("--vendor", type=Path, default=PM.parent / "jnox332-release-deps")
    cli.add_argument("--independent-dir", type=Path)
    cli.add_argument("--independent-reader", type=Path, help="override the independent replay.py source")
    cli.add_argument("--independent-report", nargs=2, action="append", default=[], metavar=("LABEL","JSON"))
    cli.add_argument("--report-note", type=Path, action="append", default=[], metavar="TEXT")
    args = cli.parse_args()
    if args.independent_dir is None:
        args.independent_dir = PM.parent / ("jnox438-unwind-independent" if args.failures else "jnox438-independent")
    output = args.output.absolute()
    output.parent.mkdir(parents=True, exist_ok=True)
    require(not output.exists(), f"release output exists {output}")
    with tempfile.TemporaryDirectory(prefix="jnox-lifecycle-offline-") as tmp, tempfile.TemporaryDirectory(
            prefix=".jnox-lifecycle-", dir=output.parent) as publishing:
        work, pub = Path(tmp), Path(publishing) / "release"
        stage = work / "stage"
        stage.mkdir()
        pub.mkdir()
        package(stage, args)
        tar = pub / ("lifecycle-failures.tar.xz" if args.failures else "lifecycle.tar.xz")
        archive(stage, tar)
        fresh = work / "extracted"
        extract(tar, fresh)
        result = json.loads(subprocess.check_output([sys.executable, "-B", "replay.py"], cwd=fresh))
        write(pub / "result.json", result)
        copy(fresh / "README.md", pub / "README.md")
        digest = sha(tar)
        (pub / (tar.name + ".sha256")).write_text(f"{digest}  {tar.name}\n")
        require(not output.exists(), f"release output appeared during packaging {output}")
        pub.rename(output)
        print(f"{digest}  {output / tar.name}")


if __name__ == "__main__":
    main()
