#!/usr/bin/env python3
"""Replay the frozen observers on the retained lifecycle captures under Linux."""
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
from evidence_io import checksums, read, regular, require, sha

VERIFIER = "tools/verify_linux_source_net_lifecycle.py"
FAILURE_VERIFIER = "tools/verify_linux_source_net_lifecycle_failures.py"
BOARD = "docs/evidence/native-linux-net-irq-board"
PROFILE = "drivers/linux-compat/profiles/virtio-net.json"
STAGES = ["first-probed", "first-open", "first-ack", "first-removed",
          "second-probed", "second-open", "second-ack", "final"]
FAILURE_STAGES = [f"case-{n}-{state}" for n in range(1,5) for state in ("armed","failed","retired")] + ["recovery-ready","recovery-ack","final"]
FAILURE_CONTROLS = {"absent register failure","unremoved hotplug instance","false DOWN registration","corrupted peer nonce"}
OPEN_CONTROLS = {"live original ndo_open pointer", "registered netdevice identity", "missing first original probe entry"}
RAW = ["net.events", "host.bin", "nonces.bin", "wire.pcap", "machine.log", "uart.log", "stderr.log",
       "launch.json", "result.json", "observer-commit.txt", "observer.sha256"]
LINUX = "4700e3adf3b24b39dd4929e9c6d62811ba3ccea8"
LINUX_HASH = "05e676f7fc4f91783c961c860b930fae33462348064887eea95be3a440282a29"
HEADERS_HASH = "901bb6ced9321e225b59395161f80a66146e3beaa9252f94c6430f545c84806b"


def git_identity(file, kind, oid):
    data = file.read_bytes()
    require(hashlib.sha1(f"{kind} {len(data)}\0".encode() + data).hexdigest() == oid, f"Git {kind} identity {file}")


def build_evidence(root, name, failures=False):
    base = root / "builds" / name
    native, imported = base / "native", base / "imported"
    pkg, imp = read(native / "manifest.json"), read(imported / "import.json")
    rev = pkg["commit"]
    require(re.fullmatch("[0-9a-f]{40}", rev) and sha(native / "manifest.json") == name and
            (pkg["tracked_changes"], pkg["board"], pkg["app"], pkg["policy"]) == ("", "virt", "process", "fifo") and
            imp["mode"] == ("lifecycle-failure-service" if failures else "lifecycle-service") and len(pkg["slots"]) == 2,
            "native lifecycle build")
    if failures:
        require(pkg["linux_source_net_lifecycle_failures"]["test_only"] is True and imp["fault_fixture"]["test_only"] is True,
                "failure fixture boundaries")
    sources = root / "source/jnox" / rev
    git_identity(sources / "commit.raw", "commit", rev)
    require(sha(native / "kernel.elf") == pkg["kernel_elf_sha256"] and
            sha(native / "build.log") == pkg["build_log_sha256"], "kernel digest or build log")
    kernel = (native / "kernel.elf").read_bytes()
    argv = pkg["package_argv"]
    require(("--linux-source-net-lifecycle-failures" if failures else "--linux-source-net-lifecycle") in argv and
            [argv[i+1] for i,k in enumerate(argv) if k in ("--elf","--peer-elf")] ==
            [s["input"]["path"] for s in pkg["slots"]], "selected ELF arguments")
    roles = []
    peer = imp["irq_peer"]
    spec = importlib.util.spec_from_file_location("linked_native_roots", regular(sources, "tools/native_amc_roots.py"))
    roots_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(roots_module)
    roots = roots_module.linked_roots(native / "kernel.elf", len(pkg["slots"]))
    for slot, (s, role, src, elf, digest, map_hash) in enumerate(zip(pkg["slots"], ("driver","peer"),
            ("examples/linux-source-net-lifecycle/" + ("failure_driver.c" if failures else "driver.c"), peer["source"]), ("service.elf","peer.elf"),
            (imp["service"]["sha256"], peer["elf"]["sha256"]), (imp["link_map_sha256"],peer["link_map_sha256"]))):
        app = regular(native, s["elf"])
        obj = ("driver.o","irq_peer.o")[slot]
        require((s["slot"],s["argv"],s["priority"]) == (slot,["/bin/app"],8) and src in imp["input_sha256_by_object"][obj],
                f"{role} slot or source")
        require(sha(app) == sha(imported / elf) == s["input"]["sha256"] == s["elf_sha256"] == digest ==
                pkg["source_sha256"][s["input"]["path"]] and app.read_bytes() in kernel and
                sha(imported / Path(elf).with_suffix(".map")) == map_hash, f"{role} link or embedded ELF")
        require(s.get("expected_ttbr0_el1", roots[slot]) == roots[slot], f"{role} linked address-space root")
        roles.append({"role": role, "slot": slot, "sha256": digest, "source": src,
                      "linked_ttbr0_el1": hex(roots[slot]), "map_sha256": map_hash})
    require(roles[0]["linked_ttbr0_el1"] != roles[1]["linked_ttbr0_el1"], "two distinct slot roots")
    for filename, item in imp["objects"].items():
        require(sha(regular(imported, filename)) == item["sha256"], f"object {filename}")
    for key in ("driver_object", "callback_object"):
        item = imp[key]
        require(sha(regular(imported, item["filename"])) == item["sha256"], key)
    for name in imp["input_sha256_by_object"]:
        regular(imported, name)
    index = read(base / "source-index.json")
    files = index["compiler_inputs"]
    require(set(files) == set(imp["input_sha256"]) and sha(sources / PROFILE) == imp["profile_sha256"],
            "compiler file inventory or import profile")
    profile = read(sources / PROFILE)
    require(profile["upstream"] == imp["upstream"] and profile["headers"] == imp["header_profile"], "intake source profile")
    upstream = imp["upstream"]
    require(upstream["commit"] == LINUX and upstream["sha256"] == imp["source"]["sha256"] == LINUX_HASH and
            upstream["path"] == "drivers/net/virtio_net.c", "pinned original Linux source")
    git_identity(regular(root, files[upstream["path"]]), "blob", upstream["git_blob_sha1"])
    header_root = root / "source/linux-headers" / HEADERS_HASH
    ledger = read(header_root / "tree.json")
    whole = hashlib.sha256()
    for path, digest in sorted(ledger.items()):
        whole.update(path.encode() + b"\0" + bytes.fromhex(digest))
    require(len(ledger) == 9403 and whole.hexdigest() == imp["header_tree_sha256"] == HEADERS_HASH, "header tree identity")
    for path, digest in profile["headers"]["generated_sha256"].items():
        require(ledger[path] == digest == sha(regular(header_root / "files", path)), f"generated header {path}")
    for path, target in files.items():
        digest = imp["input_sha256"][path]
        require(sha(regular(root, target)) == digest, f"compiler input {path}")
        if path.startswith("headers/"):
            require(ledger[path[8:]] == digest, f"header provenance {path}")
    for path, digest in pkg["kernel_build"]["config_sha256"].items():
        require(sha(regular(sources, path)) == digest, f"kernel configuration {path}")
    return {"source_commit": rev, "linux_commit": LINUX, "linux_tu_sha256": LINUX_HASH,
            "header_tree_sha256": HEADERS_HASH, "compiler_input_count": len(files), "roles": roles,
            "import_sha256": sha(imported / "import.json"), "kernel_sha256": pkg["kernel_elf_sha256"],
            "objects": {n:sha(imported / n) for n in ("virtio_net.original.o","virtio_net.packet.o","virtio_net.callback.o")}}


def python(root, args, **opts):
    env = dict(os.environ, LC_ALL="C", PYTHONPATH=str(root / "vendor"),
               PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1")
    env.pop("PYTHONOPTIMIZE", None)
    return subprocess.check_output([sys.executable, "-B", *args], cwd=root, env=env, **opts)


def observer_args(case, launch):
    base = "builds/" + case["build"]
    path = FAILURE_VERIFIER if case.get("failures") else VERIFIER
    rev = case.get("replay_commit", case["observer_commit"])
    argv = [f"observers/{rev}/{path}", "--replay", "--mutation-tests",
            "--package", base + "/native", "--driver-manifest", base + "/imported/import.json",
            "--out", "captures/" + case["label"], "--mac", launch["mac"], "--mtu", str(launch["mtu"])]
    if case["through_open"]:
        argv.append("--through-open")
    return argv


def replay(root):
    members = checksums(root)
    index = read(root / "bundle.json")
    cases, builds, nonces = {}, {}, set()
    for case in index["cases"]:
        label, rev, bid = (case[k] for k in ("label","observer_commit","build"))
        require(re.fullmatch(r"[A-Za-z0-9][\w.-]*", label) and label not in cases and
                re.fullmatch("[0-9a-f]{40}", rev) and re.fullmatch("[0-9a-f]{64}", bid), "case identity")
        failures = case.get("failures", False)
        if failures:
            require(len(index["cases"]) == 2 and all(c.get("failures") is True for c in index["cases"]), "two four-fault boots")
        if bid not in builds:
            builds[bid] = build_evidence(root, bid, failures)
        identity = builds[bid]
        cap = root / "captures" / label
        observer = root / "observers" / rev
        git_identity(observer / "commit.raw", "commit", rev)
        require((cap / "observer-commit.txt").read_text().strip() == rev and
                identity["source_commit"] == case["build_commit"], "separate source and observer commits")
        hashes = {}
        for line in (cap / "observer.sha256").read_text().splitlines():
            digest, name = line.split("  ", 1)
            require(name not in hashes, "duplicate observer digest")
            hashes[name] = digest
        for path in (observer / "tools").glob("*.py"):
            require(sha(path) == hashes["tools/" + path.name], f"observed module bytes {path}")
        launch = read(cap / "launch.json")
        board = read(observer / BOARD / "board.json")
        require(hashlib.sha256(gzip.decompress((observer / BOARD / "virt-net.dtb.gz").read_bytes())).hexdigest() ==
                board["sha256"] and (failures and "qemu_sha256" not in launch or board["qemu_sha256"] == launch.get("qemu_sha256")) and
                launch["kernel_sha256"] == identity["kernel_sha256"] and launch["import_sha256"] == identity["import_sha256"]
                and launch["driver_sha256"] == identity["roles"][0]["sha256"], "launch/board/binaries")
        data = (cap / ("nonce.bin" if failures else "nonces.bin")).read_bytes()
        halves = {data} if failures else {data[:8],data[8:]}
        require(len(data) == (8 if failures else 16) and len(halves) == (1 if failures else 2)
                and all(any(h) for h in halves) and not halves & nonces,
                "capture nonce independence")
        nonces.update(halves)
        through_open = case["through_open"]
        stages = FAILURE_STAGES if failures else STAGES[:2] if through_open else STAGES
        inventory = set(RAW) | set(stages)
        if failures:
            inventory = inventory - {"nonces.bin"} | {"nonce.bin"}
        if case.get("capture_without_result"):
            inventory.remove("result.json")
        require(set(p.name for p in cap.iterdir()) == inventory, f"unexpected capture contents {label}")
        argv = observer_args(case, launch)
        if case.get("replay_commit") and case["replay_commit"] != rev:
            git_identity(root / "observers" / case["replay_commit"] / "commit.raw", "commit", case["replay_commit"])
            correction = read(root / "corrections" / label / "change.json")
            require(correction["capture"] == rev and correction["replay"] == case["replay_commit"], "offline observer correction")
            for name in correction["capture_helpers"]:
                require(sha(root / "observers" / rev / name) == sha(root / "observers" / case["replay_commit"] / name),
                        f"capture dependency changed across observer correction {name}")
            original_argv = list(argv)
            original_argv[0] = f"observers/{rev}/{FAILURE_VERIFIER}"
            original_argv.remove("--mutation-tests")
            try:
                python(root, original_argv, stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError as exc:
                require(correction["original_error"].encode() in exc.output, f"unexpected original observer failure {label}")
            else:
                raise ValueError(f"original observer did not reproduce its recorded discrepancy for {label}")
        result = json.loads(python(root, argv))
        controls = result.pop("rejected_mutations")
        baseline = read(regular(root,case["baseline"])) if case.get("baseline") else read(cap / "result.json")
        recorded = baseline.pop("rejected_mutations", controls)
        required = FAILURE_CONTROLS if failures else OPEN_CONTROLS if through_open else OPEN_CONTROLS | {"second-generation private RX payload"}
        require(result == baseline and (failures or result["checkpoints"] == stages) and required <= set(controls)
                and len(controls) == len(set(controls)) and controls == recorded, f"{label} replay/mutation controls")
        if failures:
            require([r["case"] for r in result["injected"]] == [1,2,3,4] and all(r["errno"] == -12 for r in result["injected"])
                    and result["recovery_frames"] == 2 and len(result["entry_counts"]) == 5, "faults and clean recovery")
        elif through_open:
            require(result["scope"] == "first probe through open" and result["first_posts"] == 32 and
                    (cap / "host.bin").stat().st_size == 0 and (cap / "wire.pcap").stat().st_size == 24,
                    "pre-traffic scope")
        else:
            require(result["peer_frames"] == 83 and len(result["tokens"]) == 2 and result["tokens"][0] < result["tokens"][1],
                    "two-generation observer scope")
        output = {"build_commit": identity["source_commit"], "observer_commit": rev, "kernel_sha256": launch["kernel_sha256"],
                  "qemu_sha256": launch.get("qemu_sha256"), "board_dtb_sha256": board["sha256"],
                  "pinned_board_qemu_sha256": board["qemu_sha256"], "mac": launch["mac"], "mtu": launch["mtu"],
                  "capture_scope": "four injected failures and clean recovery" if failures else "through-open" if through_open else "two generations",
                  "replay_commit": case.get("replay_commit",rev), "checkpoints": stages,
                  "replay_argv": ["python3","-B",*argv], "rejected_mutations": controls, "result": result}
        if case.get("independent"):
            qa = case["independent"]
            decoded = json.loads(python(root, qa["argv"]))
            require(decoded == read(regular(root, qa["report"])), f"independent recorded result differs for {label}")
            if failures:
                require([row["case"] for row in decoded["cases"]] == [1,2,3,4] and
                        decoded["source_sha256"] == LINUX_HASH and decoded["recovery_token"] == result["recovery_token"],
                        f"independent fail-and-recover scope {label}")
            output["independent"] = {"replay_argv": ["python3","-B",*qa["argv"]], "report": decoded}
        cases[label] = output
    return {"checksummed_members": members, "builds": builds, "captures": cases}


if __name__ == "__main__":
    print(json.dumps(replay(Path(__file__).resolve().parent), indent=2))
