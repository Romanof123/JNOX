"""Independent reader for the bounded #438 AArch64 error-unwind fixture."""
import argparse
from elftools.elf.elffile import ELFFile
from elftools.elf.relocation import RelocationSection
import hashlib
import json
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys

PIN = "05e676f7fc4f91783c961c860b930fae33462348064887eea95be3a440282a29"
MASK = (1 << 64) - 1
PA = 0xfffffffff000
NAMES = ["netdev allocation", "netdev registration", "second CPU notifier", "PAGE_SHARED registration"]
def require(ok, why):
    if not ok:
        raise ValueError(why)

def symbols(elf):
    tool = shutil.which("aarch64-linux-gnu-nm") or "nm"
    rows = subprocess.check_output([tool, "-S", "--defined-only", str(elf)], text=True)
    return {name:(int(a,16),int(sz,16)) for a,sz,name in re.findall(r"^([\da-f]+) ([\da-f]+) \w (\S+)$", rows,re.M)}

class Ram:
    def __init__(self, stage):
        raw = json.loads((stage/"ram.json").read_text())
        self.pages = {}
        for key, value in raw.items():
            a, n = key.split("/")
            a, n, data = int(a,16), int(n), bytes.fromhex(value)
            require(len(data)==n, "RAM range size")
            while data:
                page, off = divmod(a,4096)
                chunk = data[:4096-off]
                buf, known = self.pages.setdefault(page,(bytearray(4096),bytearray(4096)))
                for i,b in enumerate(chunk,off):
                    require(not known[i] or b==buf[i],"conflicting physical bytes")
                buf[off:off+len(chunk)] = chunk
                known[off:off+len(chunk)] = b"\1"*len(chunk)
                a += len(chunk)
                data = data[len(chunk):]
    def phys(self,a,n):
        page,off=divmod(a,4096)
        buf,known=self.pages[page]
        require(n<=4096-off and all(known[off:off+n]),"uncaptured physical bytes")
        return bytes(buf[off:off+n])
    def user(self,root,a,n):
        out=bytearray()
        while n:
            p=root
            for shift in (30,21,12):
                desc=int.from_bytes(self.phys(p+8*((a>>shift)&511),8),"little")
                require(desc&3==3,"invalid translation")
                p=desc&PA
            require(desc&64,"supervisor leaf for user data")
            k=min(n,4096-a%4096)
            out.extend(self.phys(p+a%4096,k))
            a+=k
            n-=k
        return bytes(out)

def words(data):
    return [v for v, in struct.iter_unpack("<Q",data)]

def read_wire(raw):
    host=(raw/"host.bin").read_bytes()
    nonce=(raw/"nonce.bin").read_bytes()
    mac=bytes.fromhex(json.loads((raw/"launch.json").read_text())["mac"].replace(":",""))
    header=mac+bytes.fromhex("024a4e4f580188b5")
    require(len(nonce)==8 and any(nonce),"nonce")
    frames=[header+b"JNOXRECV"+nonce+bytes(4)+bytes(range(34,60)),header+b"JNOXACK!"+nonce+bytes(30)]
    require(host==b"".join(len(f).to_bytes(4,"big")+f for f in frames),"host stream")
    data=(raw/"wire.pcap").read_bytes()
    endian={bytes.fromhex("d4c3b2a1"):"<",bytes.fromhex("a1b2c3d4"):">"}[data[:4]]
    require(struct.unpack_from(endian+"I",data,20)[0]==1,"PCAP link type")
    off=24
    for f in frames:
        _,_,cap,n=struct.unpack_from(endian+"IIII",data,off)
        off+=16
        require(cap==n and data[off:off+n] in (f, bytes(10)+f,bytes(12)+f),"Ethernet capture")
        off+=cap
    require(off==len(data),"unexpected PCAP traffic")
    return frames

def trace(raw, sym):
    entries={sym[n][0]:n for n in ("virtnet_probe","virtnet_open","virtnet_close","virtnet_remove","unregister_netdev","jnox_lifecycle_fault_hit_v1","skb_recv_done","virtnet_poll","gro_receive_skb","xdp_rxq_info_reg_mem_model","register_netdevice","__cpuhp_state_add_instance","free_netdev","xdp_rxq_info_unreg","__cpuhp_state_remove_instance")}
    exe=re.compile(rb"^Trace 0: \S+ \[[\da-f]+/([\da-f]+)/")
    mm=re.compile(rb"memory_region_ops_(read|write).*?addr (0x[\da-f]+) value (0x[\da-f]+).*?'virtio-mmio'")
    nic=None
    epochs=[]
    pending=None
    with (raw/"machine.log").open("rb") as log:
        for line in log:
            if pending and not line.startswith(b"Stopped execution of TB chain before"):
                epochs[-1]["calls"].append(pending)
            pending=None
            if m:=mm.search(line):
                op,a,v=m[1],int(m[2],16),int(m[3],16)
                if op==b"read" and a%512==8 and v==1:
                    nic=a-8
                if nic is not None and a==nic+112 and op==b"write":
                    if v==1: epochs.append({"status":[],"calls":[]})
                    if epochs: epochs[-1]["status"].append(v)
            if epochs and (m:=exe.match(line)):
                pending=entries.get(int(m[1],16))
    require(len(epochs)==5,"five distinct hardware claims")
    for i,e in enumerate(epochs):
        calls=e["calls"]
        require("virtnet_probe" in calls and ("virtnet_open" in calls)==(i>=3),"upstream callback epoch")
        for name, needed in (("register_netdevice",i>=1),("__cpuhp_state_add_instance",i>=2),("xdp_rxq_info_reg_mem_model",i>=3),("virtnet_remove",i>=3),("free_netdev",i>=1)):
            require((name in calls)==needed,f"case {i+1} {name}")
        require(e["status"]==[1,3,11]+([15] if i>=2 else [])+([0,0] if i<4 else [0]),"virtio status transitions")
        require(calls.count("virtnet_probe")==1 and calls.count("virtnet_close")==int(i==4),"upstream probe and close count")
        require(calls.count("unregister_netdev")==int(i>=2),"unregistration count")
        require(calls.count("__cpuhp_state_add_instance")==2*int(i>=2),"online/dead notifier installation")
        require(calls.count("__cpuhp_state_remove_instance")==([0,0,1,2,2][i]),"notifier removal count")
        for fn in ("skb_recv_done","virtnet_poll","gro_receive_skb"):
            require((fn in calls)==(i==4),"recovery-only RX callback "+fn)
        require("jnox_lifecycle_fault_hit_v1" in calls,"injection decision hook")
        if i==2:
            second=[j for j,n in enumerate(calls) if n=="__cpuhp_state_add_instance"][1]
            require(second<calls.index("__cpuhp_state_remove_instance")<calls.index("unregister_netdev")<calls.index("free_netdev"),"second notifier unwind order")
        if i==3:
            positions=[calls.index(n) for n in ("virtnet_open","xdp_rxq_info_reg_mem_model","xdp_rxq_info_unreg","virtnet_remove")]
            require(positions==sorted(positions),"XDP registration rollback preceded removal")
        if i==4:
            require(calls.count("gro_receive_skb")==2,"fresh skbs reached GRO")
    return epochs

def upstream(native, folder):
    manifest_path, = [p for p in folder.glob("*.json") if json.loads(p.read_text()).get("mode")=="lifecycle-failure-service"]
    meta=json.loads(manifest_path.read_text())
    require(meta["source"]["sha256"]==meta["upstream"]["sha256"]==PIN,"Linux intake provenance")
    require(meta["upstream"]["commit"]=="4700e3adf3b24b39dd4929e9c6d62811ba3ccea8","Linux revision")
    require(meta["service"]["sha256"]==hashlib.sha256((native/"user.elf").read_bytes()).hexdigest(),"supplied service")
    for file,digest in (("virtio_net.packet.o",meta["driver_object"]["sha256"]),("virtio_net.original.o",meta["objects"]["virtio_net.original.o"]["sha256"]),("service.map",meta["link_map_sha256"])):
        require(hashlib.sha256((folder/file).read_bytes()).hexdigest()==digest,"intake identity "+file)
    def function(elf, symbol):
        matches=elf.get_section_by_name(".symtab").get_symbol_by_name(symbol)
        s,=[x for x in matches if x["st_info"]["type"]=="STT_FUNC" and x["st_size"]]
        sc=elf.get_section(s["st_shndx"])
        offset=s["st_value"]-sc["sh_addr"]
        return s,sc.data()[offset:offset+s["st_size"]]
    with (folder/"virtio_net.packet.o").open("rb") as f,(native/"user.elf").open("rb") as g:
        obj,exe=ELFFile(f),ELFFile(g)
        for name in ("virtnet_probe","virtnet_open","virtnet_close","virtnet_remove","virtnet_poll","skb_recv_done"):
            sym,source=function(obj,name)
            _,linked=function(exe,name)
            relocated=set()
            for sec in obj.iter_sections():
                if isinstance(sec,RelocationSection) and sec["sh_info"]==sym["st_shndx"]:
                    relocated.update(r["r_offset"]-sym["st_value"] for r in sec.iter_relocations())
            require(len(source)==len(linked) and all(source[k:k+4]==linked[k:k+4] for k in range(0,len(source),4) if k not in relocated),name+" original object instructions")
    return hashlib.sha256(manifest_path.read_bytes()).hexdigest()

def evaluate(build, raw, source):
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    require(digest==PIN,"pinned upstream source")
    native=build/"native" if (build/"native").is_dir() else build
    launch=json.loads((raw/"launch.json").read_text())
    for f,key in (("kernel.elf","kernel_sha256"),("user.elf","driver_sha256")):
        require(hashlib.sha256((native/f).read_bytes()).hexdigest()==launch[key],f+" identity")
    driver=symbols(native/"user.elf")
    peer=symbols(native/"native_peer.elf")
    kernel=symbols(native/"kernel.elf")
    (root,size),=[v for k,v in kernel.items() if "native_el0_mmu" in k and "6SPACES" in k]
    require(root%4096==0 and size%8192==0,"native address spaces")
    ring=kernel["jnox_linux_net_queue_pool"][0]
    buffers=kernel["jnox_linux_net_packet_buffers"][0]
    maps=list(build.rglob("service.map"))
    require(len(maps)==1,"unique linked driver map")
    require(upstream(native,maps[0].parent)==launch["import_sha256"],"captured build intake identity")
    linkmap=maps[0].read_text().splitlines()
    binary=(native/"kernel.elf").read_bytes()
    for artifact in ("user.elf","native_peer.elf"):
        require((native/artifact).read_bytes() in binary,"embedded process image "+artifact)
    private={}
    for name,unit in (("allocated","netdev"),("registered","netdev"),("rtnl_owner","netdev"),("online","platform"),("dead","platform"),("registered_rx","platform"),("shared_model","platform")):
        row,=[l for l in linkmap if l.strip().endswith(f"lifecycle_{unit}.o:(.bss.{name})")]
        private[name]=int(row.split()[0],16)
    def stage(label):
        path=raw/label
        before=json.loads((path/"qmp.json").read_text())
        after=json.loads((path/"halted.json").read_text())
        require(before["status"]["running"] and before["stop_return"]=={} and [cpu["cpu-index"] for cpu in before["cpus"]]==[0] and after["running"] is False and after["status"]=="paused",label+" halt")
        return Ram(path)
    def record(ram,name,index,count,other=False):
        syms,space=(peer,root+size//2) if other else (driver,root)
        va,extent=syms[name]
        require((index+count)*8<=extent,name+" bounds")
        return words(ram.user(space,va+index*8,count*8))
    def actual(ram,s):
        require(record(ram,"jnox_lifecycle_common_live",0,1)==[s[9]] and record(ram,"jnox_lifecycle_registered_driver",0,1)==[s[10]],"live module and common ownership")
        for key,field in (("allocated",0),("registered",1),("rtnl_owner",2),("online",4),("dead",5),("registered_rx",6),("shared_model",7)):
            va=private[key]+(24 if key in ("online","dead") else 0)
            require(int.from_bytes(ram.user(root,va,1 if key=="shared_model" else 8),"little")==s[field],"private "+key)
    def descriptors(ram):
        data=ram.phys(ring,4096)
        for j in range(32):
            require(struct.unpack_from("<QIHH",data,16*j)==(buffers+1536*j,1530,2,0),"writable DMA descriptor")
        require(struct.unpack_from("<H",data,514)[0]==32 and struct.unpack_from("<H",data,586)[0]==0,"RX ring indices")
    epochs=trace(raw,driver)
    result=[]
    tokens=[]
    states="jnox_lifecycle_fault_state"
    events="jnox_lifecycle_fault_events"
    resources="jnox_lifecycle_fault_resources"
    callers=("alloc_etherdev_mqs","register_netdevice","__cpuhp_state_add_instance","xdp_rxq_info_reg_mem_model")
    for i,name in enumerate(NAMES):
        case=i+1
        observed=[]
        for j,label in enumerate(("armed","failed","retired")):
            ram=stage(f"case-{case}-{label}")
            row=record(ram,"jnox_failure_driver",32*i,32)
            ev=record(ram,events,8*i,8)
            phase=(0,2,3)[j]
            s=record(ram,states,20*(4*i+phase),20)
            res=record(ram,resources,8*(4*i+phase),8)
            require(row[:2]==[case,j+1] and ev[6]==(1<<(phase+1))-1,"stage publication")
            actual(ram,s)
            observed.append(s)
            if j==0:
                require(ev[:2]==[case,0] and not any(s[:9]) and s[10]==driver["virtio_net_driver"][0],"armed resource baseline")
            elif j==1:
                f=record(ram,states,20*(4*i+1),20)
                require(ev[:3]==[case,1,case] and ev[3] and ev[4] and ev[5]==case and ev[7]==(0 if i==0 else MASK-11),"fault event")
                require(row[2:4]==([MASK-11,0] if i<3 else [0,MASK-11]),"callback errno")
                truth=[bool(f[k]) for k in (0,1,4,5,6,7,8)]
                require(truth==[i>=1,i>=2,i>=2,i==3,i==3,False,i>=1],"point of failure ownership")
                if i==1: require(ev[3]==f[0] and f[2],"registration candidate and RTNL")
                if i==2: require(ev[3]!=f[4] and f[0]==f[1],"second notifier candidate")
                if i==3: require(ev[3]==f[6],"XDP candidate")
                # Linux allocation wrapper can be tail-called. Decode actual AArch64 BL at LR-4.
                pc=ev[4]-4
                # ELF load segments are sufficient for the call-site word even when capture only contains entry prefixes.
                elf=(native/"user.elf").read_bytes()
                phoff=struct.unpack_from("<Q",elf,32)[0]
                phsz,phnum=struct.unpack_from("<HH",elf,54)
                for n in range(phnum):
                    typ,_,off,va,_,fs,_,_=struct.unpack_from("<IIQQQQQQ",elf,phoff+n*phsz)
                    if typ==1 and va<=pc and pc+4<=va+fs:
                        ins=struct.unpack_from("<I",elf,off+pc-va)[0]
                        break
                else: raise ValueError("unmapped caller")
                require(ins>>26==0b100101,"fault adapter must originate at a linked BL")
                displacement=ins&0x3ffffff
                if displacement&0x2000000: displacement-=0x4000000
                target=pc+4*displacement
                accepted=[callers[i]]+([] if i else [n for n in driver if re.fullmatch(r"alloc_netdev_mqs(?:\.part\.\d+)?",n)])
                require(target in [driver[n][0] for n in accepted],f"case {case} call target {target:#x}")
                if i<3:
                    require(not any(s[:11]) and not any(res[:4]) and row[5:9]==[0,MASK-18,0,0],"failed probe ownership")
                else:
                    require(s[0]==s[1]!=0 and not s[2] and not s[3]&1 and s[4] and s[5] and not any(s[6:8]),"registered down after open")
                    require(row[4]==row[5]==s[8]!=0 and row[6:8]==[15,32] and row[8]>0 and row[10]==MASK-99 and res[0]==32 and res[1]>0,"live transport before removal")
                    descriptors(ram)
                delta=[s[k]-observed[0][k] for k in range(11,15)]
                require(delta==([0,0,0,0],[1,1,0,0],[1,1,1,1],[1,0,1,0])[i],"allocation/free/register/unregister")
                if row[4]: tokens.append(row[4])
                result.append(dict(case=case,name=name,provider_argument=ev[3],caller=pc,callback_errno=-12,ownership_at_return=s,accounting_delta=delta,returned_resources=res))
            else:
                require(not any(s[:11]+s[15:]) and not any(res[:4]) and row[13:17]==[MASK-18,0,0,0],"retired resources")
                if row[4]: require(row[17:19]==[MASK-115]*2,"retired token still accepted")
    frames=read_wire(raw)
    for label,count in (("recovery-ready",0),("recovery-ack",1),("final",2)):
        ram=stage(label)
        d=record(ram,"jnox_failure_driver",128,32)
        p=record(ram,"jnox_failure_peer",32,8,True)
        require(d[4]==d[5]!=0 and d[4] not in tokens and len(set(tokens))==3 and p[:5]==[5,d[4],MASK-12,MASK-12,MASK-12],"fresh isolated grant")
        require(p[6]==count and ram.user(root+size//2,peer["jnox_failure_recovery_bytes"][0],120)==b"".join(frames[:count])+bytes(60*(2-count)),"peer recovery bytes")
        if count==0: descriptors(ram)
        if count==2:
            require(d[:4]==[5,100,0,0] and d[11:17]==[0,0,MASK-18,0,0,0] and d[20:23]==[MASK-115]*3 and d[25]==2 and not d[31] and not p[7],"successful fresh recovery")
    exits=re.findall(r"^NATIVE EL0 EXIT PID (\d+) (-?\d+)\s*$",(raw/"uart.log").read_text(),re.M)
    require(sorted(exits)==[("0","0"),("1","0")],"process exits")
    return dict(source_sha256=digest,cases=result,hardware_epochs=epochs,recovery_token=d[4],frame_sha256=[hashlib.sha256(f).hexdigest() for f in frames])

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("build_directory",type=Path)
    ap.add_argument("run_label",type=Path)
    ap.add_argument("pinned_source",type=Path)
    ap.add_argument("--full",action="store_true",help="all checks always run")
    args=ap.parse_args()
    try:
        raw=args.run_label
        if not raw.is_absolute(): raw=args.build_directory/raw
        payload=evaluate(args.build_directory,raw,args.pinned_source)
        print(json.dumps(payload,sort_keys=True,indent=2))
    except (ValueError,KeyError,OSError,struct.error,subprocess.CalledProcessError) as exc:
        print(json.dumps({"error":str(exc)},sort_keys=True))
        sys.exit(1)



