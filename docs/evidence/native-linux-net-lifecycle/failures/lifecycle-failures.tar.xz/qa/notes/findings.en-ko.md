# AArch64 virtio-net error unwind, independent findings

Cold boots cold-02 and cold-03 each exercised all four one-shot compatibility-provider failures and one fresh binding. The independently decoded errno was −12 for the first three probe calls and for the fourth open call. At the allocation hook the provider returned NULL, which the upstream probe translated to −ENOMEM.

| Failure point | Acquired and released before returning |
|---|---|
| Netdev allocation | Zero allocations or registrations. The failed probe held no queue token. |
| Netdev registration | One allocation and one free. The registration hook fired with RTNL held and before publication. |
| Second CPU notifier | One allocation, registration, unregistration and free. The online node existed when the dead-node installation failed. Its removal preceded unregistration. |
| XDP PAGE_SHARED model | Probe succeeded. Failed open undid RXQ registration and left the registered device down, with both notifier nodes, transport token 3, 32 writable RX descriptors and 49 page references. Receive returned −100. Subsequent removal released the ownership. |

The fresh binding used token 4. All three previously issued tokens returned −116. In each boot the receiver consumed both 60-byte nonce-bound Ethernet frames through GRO. The exact host stream and PCAP frames matched the separate peer's memory. Both processes exited zero. The frame hashes differed across boots.

The reader compared linked upstream callback instructions with the pinned intake object outside relocation words. The evidence measures deterministic injected provider failures in this build under QEMU. Physical hardware, system-wide memory pressure and unrelated driver error paths remain outside the experiment.

## 한국어

두 번의 콜드 부팅에서 할당, 등록, 두 번째 CPU 알림 등록 실패는 probe에서 −12를 반환했다. 할당 실패에서는 획득한 자원이 없었다. 등록 실패에서는 장치 한 개를 해제했다. 두 번째 알림 등록 실패에서는 먼저 설치한 온라인 알림을 제거한 뒤 장치 등록을 해제했다.

네 번째 사례는 probe가 성공한 뒤 XDP PAGE_SHARED 등록에서 open이 −12를 반환했다. RXQ 등록은 해제됐고, 장치는 등록된 DOWN 상태로 유지됐다. 제거 직전까지 RX 디스크립터 32개와 페이지 참조 49개가 남았고 수신은 −100을 반환했다. 이후 remove가 자원을 회수했다. 새 토큰 4로 복구한 다음 두 프레임이 호스트와 PCAP, 별도 수신 프로세스 메모리에서 바이트 단위로 일치했다. 두 프로세스 모두 종료 코드 0을 기록했다.

결과의 범위는 해당 AArch64 QEMU 빌드에서 시험용 호환 계층이 지정된 위치에 주입한 실패다. 실제 하드웨어나 시스템 메모리 고갈에서의 동작은 이번 실험으로 확인되지 않았다.
