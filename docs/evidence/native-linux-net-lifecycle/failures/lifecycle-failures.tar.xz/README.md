# Original Linux virtio-net native lifecycle

Extract the archive in an empty Linux directory. From its root, run `python3 -B replay.py`. It requires Python 3.10+, GNU nm and aarch64-linux-gnu-nm. Pyelftools 0.32 and its license are under vendor/. Replay uses the retained files and scratch copies for corruption tests.

| Capture | Captured extent | Build commit | Capture observer | Replay observer | Verification |
|---|---|---|---|---|---|
| cold-02 | four test-only EL0 admission failures and clean recovery | 311ebf62b345fb0398b892955e53e5bfbbfeb397 | 23c04015aa13c17c51ed7cd4c4eb45f0f9812aa7 | ae110c2af54853043f0f820266721e386665f97b | recorded independent reader output compared in full |
| cold-03 | four test-only EL0 admission failures and clean recovery | 311ebf62b345fb0398b892955e53e5bfbbfeb397 | ae110c2af54853043f0f820266721e386665f97b | ae110c2af54853043f0f820266721e386665f97b | recorded independent reader output compared in full |

The kernel embeds the separate native AArch64 driver and peer ELFs. The import manifest identifies the original Linux source, the untreated and packet-profile object files, the linked callback object, both ELF maps and compiler commands. Each build's source-index.json maps every compiler dependency to exact archived bytes. The header manifest covers the full 9,403-file build tree, while files/ contains the compiled dependencies and pinned generated headers. The board DTB and its QEMU binary digest are the observer's pinned model description. launch.json records the launched QEMU path and arguments.

The stopped checkpoints contain QMP state and sparse physical reads. Each capture also retains the QEMU instruction, IRQ and MMIO trace, original host stream, Ethernet PCAP and UART. The scope in each independent JSON identifies the portion its reader checked. Each failure capture retains 15 checkpoints. Four bounded test-only EL0 provider returns exercise allocation, netdevice registration, CPU hotplug registration, and XDP memory-model registration during open. The fifth claim receives a fresh data frame and ACK. The launch records do not contain a capture-time QEMU executable digest. When capture and replay commits differ, corrections/ retains the capture observer log, corrected result and exact source patch. Detached replay reproduces the historical error, then runs the corrected observer with corruption controls. Individual commands follow.

```sh
PYTHONPATH=vendor python3 -B observers/ae110c2af54853043f0f820266721e386665f97b/tools/verify_linux_source_net_lifecycle_failures.py --replay --mutation-tests --package builds/d97501201ebd4efe600a3d9c379c26ec37935bc65855bafef54911dfe0b90cfa/native --driver-manifest builds/d97501201ebd4efe600a3d9c379c26ec37935bc65855bafef54911dfe0b90cfa/imported/import.json --out captures/cold-02 --mac 52:54:00:19:26:41 --mtu 1410
PYTHONPATH=vendor python3 -B qa/replay.py builds/d97501201ebd4efe600a3d9c379c26ec37935bc65855bafef54911dfe0b90cfa ../../captures/cold-02 source/linux/4700e3adf3b24b39dd4929e9c6d62811ba3ccea8/drivers/net/virtio_net.c --full
PYTHONPATH=vendor python3 -B observers/ae110c2af54853043f0f820266721e386665f97b/tools/verify_linux_source_net_lifecycle_failures.py --replay --mutation-tests --package builds/d97501201ebd4efe600a3d9c379c26ec37935bc65855bafef54911dfe0b90cfa/native --driver-manifest builds/d97501201ebd4efe600a3d9c379c26ec37935bc65855bafef54911dfe0b90cfa/imported/import.json --out captures/cold-03 --mac 52:54:00:19:26:52 --mtu 1490
PYTHONPATH=vendor python3 -B qa/replay.py builds/d97501201ebd4efe600a3d9c379c26ec37935bc65855bafef54911dfe0b90cfa ../../captures/cold-03 source/linux/4700e3adf3b24b39dd4929e9c6d62811ba3ccea8/drivers/net/virtio_net.c --full
```
