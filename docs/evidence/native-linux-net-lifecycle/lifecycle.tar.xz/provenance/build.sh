#!/bin/bash
set -euo pipefail
b="$HOME/jnox406-lab"; cd "$b/src"; export PATH="$HOME/.cargo/bin:$PATH" CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=1 PYTHONDONTWRITEBYTECODE=1 LC_ALL=C PYTHONPATH=/mnt/d/codex/jnox332-release-deps
exec 9>"$b/run.lock"; flock 9
git checkout -q --detach "$1"; git restore --ignore-skip-worktree-bits --source=HEAD -- drivers examples/linux-source-net-lifecycle examples/linux-source-net-rx sdk tools kernel arch
test -z "$(git status --porcelain --untracked-files=no)"
dest="$b/$2"; mkdir "$dest"
run(){ if ! "$@" >>"$dest/build.log" 2>&1; then grep -Ei 'error:|fatal error|error\[|error |Traceback|undefined symbol|referenced by|cannot find|unsupported|differs|cannot be|not found|unexpected' "$dest/build.log" | tail -85 || :; tail -5 "$dest/build.log"; exit 1; fi; }
case "${3:-ordinary}" in
  ordinary) import_profile=(--lifecycle-service); kernel_profile=--linux-source-net-lifecycle ;;
  failures) import_profile=(--lifecycle-failure-service); kernel_profile=--linux-source-net-lifecycle-failures ;;
  assertion) import_profile=(--lifecycle-service --lifecycle-assert-test); kernel_profile=--linux-source-net-lifecycle ;;
  *) exit 2 ;;
esac
run python3 -B tools/build_linux_source_virtio_net.py "${import_profile[@]}" --source /mnt/d/codex/jnox-linux-driver-intake/virtio_net.c --headers "$b/426-headers/linux-headers-6.18.65-0-virt" --out "$dest/imported"
run python3 -B tools/build_native_el0.py --board virt "$kernel_profile" --policy fifo --priority 8 --peer-priority 8 --elf "$dest/imported/service.elf" --peer-elf "$dest/imported/peer.elf" --out "$dest/native"
tail -4 "$dest/build.log"
