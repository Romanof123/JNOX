"""Independent offline AArch64 split-ring / lifecycle reader, Python 3 and GNU nm."""
import argparse
import hashlib
import json
import re
import struct
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("build", type=Path)
parser.add_argument("capture", type=Path)
parser.add_argument("source", type=Path)
parser.add_argument("--full", action="store_true")
args = parser.parse_args()
raw = args.capture
native = args.build / "native"
errors = []
report = {}

def check(condition, label):
    if not condition:
        errors.append(label)

def syms(name):
    lines = subprocess.check_output(["nm", "-n", native / name], text=True).splitlines()
    return {p[2]: int(p[0],16) for line in lines if len(p := line.split()) == 3}

class Memory:
    def __init__(self, path):
        self.data = {}
        for key, encoded in json.loads(path.read_text()).items():
            addr, size = key.split("/")
            addr, block = int(addr,16), bytes.fromhex(encoded)
            check(len(block) == int(size), "RAM length " + key)
            for i, val in enumerate(block):
                check(self.data.setdefault(addr+i,val) == val, "inconsistent overlapping RAM")
    def read(self, addr, n):
        return bytes(self.data[addr+i] for i in range(n))
    def phys(self, root, va):
        table = root
        for shift in (30,21,12):
            entry = int.from_bytes(self.read(table + 8*((va >> shift) & 511),8),"little")
            if entry & 3 != 3:
                raise KeyError("table/page invalid")
            table = entry & 0xfffffffff000
        return table + (va & 4095)
    def locate(self, va, magic):
        hits = []
        for root in self.data:
            if root % 4096: continue
            try:
                if self.read(self.phys(root,va),8) == struct.pack("<Q",magic):
                    hits.append(root)
            except KeyError:
                pass
        if len(hits) != 1:
            raise ValueError(f"ambiguous/missing address space {hits}")
        return hits[0]
    def user(self, root, va, n):
        buf = bytearray()
        while len(buf) < n:
            addr = va+len(buf)
            length = min(n-len(buf),4096-addr%4096)
            buf.extend(self.read(self.phys(root,addr),length))
        return bytes(buf)
    def words(self, root, va, n):
        return struct.unpack("<"+"Q"*n,self.user(root,va,n*8))

drv = syms("user.elf")
peer = syms("native_peer.elf")
ring = syms("kernel.elf")["jnox_linux_net_queue_pool"]
callbacks = [drv[n] for n in ("virtio_net_driver","id_table","virtnet_validate","virtnet_probe","virtnet_open","virtnet_close","virtnet_remove")]
digest = hashlib.sha256(args.source.read_bytes()).hexdigest()
check(digest == "05e676f7fc4f91783c961c860b930fae33462348064887eea95be3a440282a29", "source bytes")
report["source_sha256"] = digest
trace = (raw/"machine.log").read_text()
mmio = re.findall(r"memory_region_ops_(read|write).*?addr (0x[0-9a-f]+) value (0x[0-9a-f]+).*?'virtio-mmio'",trace)
nic = {int(a,16)-8 for op,a,v in mmio if op=="read" and int(a,16)%512==8 and int(v,16)==1}
check(len(nic)==1,"virtio net device id")
statuses = [int(v,16) for op,a,v in mmio if op=="write" and int(a,16)-0x70 in nic]
report["device_status_writes"] = statuses
check(15 in statuses,"MMIO DRIVER_OK")
tokens = {}
def stage(label,g,phase):
    path = raw/label
    q = json.loads((path/"qmp.json").read_text())
    h = json.loads((path/"halted.json").read_text())
    check(q["status"]["running"] is True and q["stop_return"]=={} and h["running"] is False and h["status"]=="paused",label+" halt")
    m = Memory(path/"ram.json")
    r = m.locate(drv["jnox_lifecycle_driver"],0x4c49464544525631)
    d = m.words(r,drv["jnox_lifecycle_driver"]+128*g,16)
    idx = g*7 + phase
    ops = m.words(r,drv["jnox_lifecycle_ops"]+idx*96,12)
    s = m.words(r,drv["jnox_lifecycle_state"]+idx*40,5)
    token = d[2]
    check(token and ops[11]==token,label+" token")
    check(tokens.setdefault(g,token)==token,label+" epoch continuity")
    check(list(ops[:7])==callbacks,label+" callback ELF addresses")
    check(ops[7:11]==(g+1,2*g+int(phase>=1)+int(g==0 and phase>=4),2*g+int(phase>=3)+int(g==0 and phase>=5),g+int(phase==6)),label+" counters")
    page = m.read(ring,4096)
    avail, used = struct.unpack_from("<H",page,514)[0],struct.unpack_from("<H",page,586)[0]
    if phase in (0,1):
        n = 32*phase
        check(s[0]==15 and s[3:]==(n,token) and avail==n and used==0,label+" queue/status")
        ids = struct.unpack_from("<32H",page,516)
        ds = [struct.unpack_from("<QIHH",page,i*16) for i in range(32)]
        if n:
            check(sorted(ids)==list(range(32)) and len({a for a,_,_,_ in ds})==32 and all(a and l and f==2 for a,l,f,_ in ds),label+" posted RX buffers")
        else:
            check(not any(page[:512]),label+" unexpected RX descriptors")
    if phase==6:
        check(s==(2**64-19,2**64-116,2**64-116,0,0),label+" removed status")
    report[label] = dict(root=hex(r), token=token, status=s[0], posted=s[3], avail=avail, used=used, callbacks=list(ops[7:11]))
    report[label]["mac"] = ":".join(f"{b:02x}" for b in d[3].to_bytes(6,"big"))
    report[label]["mtu"] = d[8]
    return m,r,d

def pcap():
    data=(raw/"wire.pcap").read_bytes()
    endian={b"\xd4\xc3\xb2\xa1":"<",b"\xa1\xb2\xc3\xd4":">"}[data[:4]]
    check(struct.unpack_from(endian+"I",data,20)[0]==1,"PCAP Ethernet")
    frames=[]
    pos=24
    while pos<len(data):
        _,_,n,orig=struct.unpack_from(endian+"IIII",data,pos)
        frame=data[pos+16:pos+16+n]
        check(len(frame)==n==orig,"truncated PCAP")
        if frame[12:14]==b"\x88\xb5": frames.append(frame)
        pos+=16+n
    return frames

try:
    stage("first-probed",0,0)
    stage("first-open",0,1)
    frames=pcap()
    report["wire_protocol_frames"]=len(frames)
    if args.full:
        stage("first-removed",0,6)
        stage("second-probed",1,0)
        stage("second-open",1,1)
        m,r,d=stage("final",1,6)
        check(tokens[1]!=tokens[0] and d[11]==2**64-116,"distinct epoch/stale queue")
        pr=m.locate(peer["jnox_lifecycle_peer"],0x4c49464550454552)
        check(pr!=r,"distinct peer address space")
        pos=0
        check(statuses == [0,1,3,11,15,0,0,1,3,11,15,0],"reset and rebind MMIO sequence")
        report["peer_root"] = hex(pr)
        report["deliveries"] = []
        nonces=[]
        host=bytearray()
        for g,count in enumerate((80,1)):
            p=m.words(pr,peer["jnox_lifecycle_peer"]+96*g,12)
            check(p[1]==100 and p[2]==tokens[g] and p[5]==count and p[7:10]==(2**64-13,)*3 and p[10:]==(60,0),"peer accounting")
            nonces.append(p[4])
            total=0
            for seq in range(count+1):
                ack=seq==count
                size=60 if ack else 60+seq%32
                base=(peer["jnox_lifecycle_peer_second"]+60*int(ack) if g else peer["jnox_lifecycle_peer_ack"] if ack else peer["jnox_lifecycle_peer_frames"]+91*seq)
                wire=frames[pos]
                pos+=1
                host.extend(struct.pack(">I",len(wire))+wire)
                hdr=p[3].to_bytes(6,"big")+bytes.fromhex("024a4e4f580188b5")+(b"JNOXACK!" if ack else b"JNOXRECV")+p[4].to_bytes(8,"big")
                check(len(wire)==size and wire.startswith(hdr) and m.user(pr,base,size)==wire,"wire/peer payload "+str(pos))
                if not ack:
                    total+=size
                    check(wire[30:]==seq.to_bytes(4,"big")+bytes((seq+i)%256 for i in range(34,size)),"sequence/pattern "+str(pos))
            check(total==p[6],"peer byte total")
            report["deliveries"].append(dict(token=p[2],frames=count,bytes=total,ack_bytes=p[10],nonce=hex(p[4]),authority_denials=3))
        check(nonces[0]!=nonces[1] and pos==len(frames),"nonce/packet count")
        check((raw/"host.bin").read_bytes()==host,"host framed stream")
    else:
        check(not frames and not (raw/"host.bin").stat().st_size,"pre-traffic specimen contains frames")
except (KeyError,ValueError,IndexError,OSError,struct.error) as exc:
    errors.append(repr(exc))
report["errors"]=errors
report["scope"]="full" if args.full else "through-open"
print(json.dumps(report,indent=2))
raise SystemExit(bool(errors))

