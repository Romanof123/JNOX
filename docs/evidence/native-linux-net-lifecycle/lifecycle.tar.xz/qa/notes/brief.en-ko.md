# Independent lifecycle replay / 독립 생애주기 검증

## Through open / 첫 장치 열기

The frozen capture `438-build-04/cold-open-02` records probe and open on build `b0069650efff2c72789e874ab6c57ef4dcc56a66`. The independent reader decodes physical RAM through AArch64 translation tables and compares callback addresses with the service ELF. QEMU recorded device status writes 0, 1, 3, 11, 15. At probe completion the physical RX ring contained zero descriptors, with available and used indices both zero. After registered open, the same generation had 32 distinct writable DMA buffers, 32 available entries and zero used. Host stream and protocol packet counts were zero. Source SHA-256 was 05e676f7fc4f91783c961c860b930fae33462348064887eea95be3a440282a29. This source hash checks the supplied source file. The callback counters and addresses are guest observations, and the physical ring and MMIO trace independently corroborate the device transition.

첫 프로브가 끝났을 때 장치 상태는 DRIVER_OK(15)였고, 물리 RX 링의 디스크립터와 게시·소비 인덱스는 모두 0이었다. 등록된 열기 콜백이 실행된 뒤 같은 세대의 링에서 서로 다른 쓰기용 DMA 버퍼 32개와 게시 인덱스 32, 소비 인덱스 0을 확인했다. 이 기록은 프레임 주입 전에 종료되었다. 패킷 전달, 제거 및 재바인딩은 별도 전체 기록에서 검증해야 한다.

From the build directory run `python3 -B replay.py . cold-open-02 /path/to/virtio_net.c`. Supply the actual path to replay.py. The reader uses Python 3 and GNU nm. For a complete lifecycle capture pass its directory and add `--full`. The JSON output lists observations and contradictions. Exit status 1 indicates a mismatch.

## Full replay / 전체 실행 재검증

Both full-02 and full-03 completed the independent replay with zero mismatches. In each capture the consumer had a separate page-table root. Its 80 first-generation data frames (5,912 bytes), 60-byte acknowledgement, one second-generation data frame (60 bytes), and second acknowledgement exactly matched the host stream and PCAP. Each generation posted 32 distinct writable buffers after open. Removal invalidated the old token and the second generation used a different token and nonce. Device status returned to zero after each removal. The second capture used MAC 52:54:00:19:26:52 and MTU 1490.

두 전체 기록에서 독립 소비자 메모리, 호스트 스트림, PCAP의 프레임 83개가 바이트 단위로 일치했다. 첫 세대의 데이터는 80개, 둘째 세대는 1개이며 각 세대마다 60바이트 확인 프레임이 하나씩 있었다. 제거 후 이전 토큰 조회는 ESTALE이었고 새 바인딩에서는 토큰과 nonce가 모두 달라졌다. 이 검증은 보존된 실행 자료를 다시 해석했다. 컴파일러 재현과 명령어별 실행 추적은 검증 범위 밖이다.
