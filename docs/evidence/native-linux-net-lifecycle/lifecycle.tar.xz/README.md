# Original Linux virtio-net native lifecycle

Extract the archive in an empty Linux directory. From its root, run `python3 -B replay.py`. It requires Python 3.10+, GNU nm and aarch64-linux-gnu-nm. Pyelftools 0.32 and its license are under vendor/. Replay uses the retained files and scratch copies for corruption tests.

| Capture | Captured extent | Build commit | Observer commit | Verification |
|---|---|---|---|---|
| full-02 | two generations through final teardown | b0069650efff2c72789e874ab6c57ef4dcc56a66 | 47a538f1ca4b3c82a3dc4fd1a849f9bd82cdb179 | recorded independent reader output compared in full |
| full-03 | two generations through final teardown | b0069650efff2c72789e874ab6c57ef4dcc56a66 | 47a538f1ca4b3c82a3dc4fd1a849f9bd82cdb179 | recorded independent reader output compared in full |

The kernel embeds the separate native AArch64 driver and peer ELFs. The import manifest identifies the original Linux source, the untreated and packet-profile object files, the linked callback object, both ELF maps and compiler commands. Each build's source-index.json maps every compiler dependency to exact archived bytes. The header manifest covers the full 9,403-file build tree, while files/ contains the compiled dependencies and pinned generated headers. The board DTB is the observer's pinned model description. launch.json records the actual QEMU binary hash and process arguments.

The stopped checkpoints contain QMP state and sparse physical reads. Each capture also retains the QEMU instruction, IRQ and MMIO trace, original host stream, Ethernet PCAP and UART. The scope in each independent JSON identifies the portion its reader checked. Individual commands follow.

```sh
PYTHONPATH=vendor python3 -B observers/47a538f1ca4b3c82a3dc4fd1a849f9bd82cdb179/tools/verify_linux_source_net_lifecycle.py --replay --mutation-tests --package builds/16c26df5ece938576f2054781f1e43305f858e40756a87201a1e803359d46b51/native --driver-manifest builds/16c26df5ece938576f2054781f1e43305f858e40756a87201a1e803359d46b51/imported/import.json --out captures/full-02 --mac 52:54:00:19:26:41 --mtu 1410
PYTHONPATH=vendor python3 -B qa/replay.py builds/16c26df5ece938576f2054781f1e43305f858e40756a87201a1e803359d46b51 captures/full-02 source/linux/4700e3adf3b24b39dd4929e9c6d62811ba3ccea8/drivers/net/virtio_net.c --full
PYTHONPATH=vendor python3 -B observers/47a538f1ca4b3c82a3dc4fd1a849f9bd82cdb179/tools/verify_linux_source_net_lifecycle.py --replay --mutation-tests --package builds/16c26df5ece938576f2054781f1e43305f858e40756a87201a1e803359d46b51/native --driver-manifest builds/16c26df5ece938576f2054781f1e43305f858e40756a87201a1e803359d46b51/imported/import.json --out captures/full-03 --mac 52:54:00:19:26:52 --mtu 1490
PYTHONPATH=vendor python3 -B qa/replay.py builds/16c26df5ece938576f2054781f1e43305f858e40756a87201a1e803359d46b51 captures/full-03 source/linux/4700e3adf3b24b39dd4929e9c6d62811ba3ccea8/drivers/net/virtio_net.c --full
```
