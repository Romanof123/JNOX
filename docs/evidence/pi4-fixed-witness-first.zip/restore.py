from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
out=root/'restored'
out.mkdir()
for name,digest in json.loads((root/'paths.json').read_text()).items():
    p=out/name
    p.resolve().relative_to(out.resolve())
    b=(root/'objects'/digest).read_bytes()
    if hashlib.sha256(b).hexdigest()!=digest:
        raise ValueError(name)
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(b)
