#!/bin/bash
set -eu
cd /home/ywcho/source
export PATH="/home/ywcho/.cargo/bin:$PATH"
evidence=/home/ywcho/jnox-348-preflight-da689d6
mkdir -p "$evidence"
exec > >(tee "$evidence/summary.log") 2>&1
git rev-parse HEAD
git status --porcelain
findmnt -T . -no SOURCE,FSTYPE
for name in clang ld.lld rustc cargo python3 aarch64-linux-gnu-nm; do
    command -v "$name" || true
    "$name" --version | head -n 1 || true
done
cat kernel/rust-toolchain.toml 2>/dev/null || true
run() {
    label=$1; shift
    printf '%q ' "$@" > "$evidence/$label.command"; echo >> "$evidence/$label.command"
    cat "$evidence/$label.command"
    set +e
    "$@" > "$evidence/$label.stdout" 2> "$evidence/$label.stderr"
    rc=$?
    set -e
    echo "$rc" > "$evidence/$label.exit"
    echo "$label exit=$rc"
    if [ "$rc" != 0 ]; then tail -n 24 "$evidence/$label.stderr"; fi
}
out=output/native-amc
mkdir -p "$out"
for slot in 0 1 2 3; do
    run "slot$slot" sh sdk/native-aarch64/build.sh "examples/native-amc/slot$slot.c" "$out/slot$slot.elf"
done
if [ -f "$out/slot0.elf" ] && [ -f "$out/slot1.elf" ] && [ -f "$out/slot2.elf" ] && [ -f "$out/slot3.elf" ]; then
    sha256sum "$out"/*.elf | tee "$evidence/elf-sha256.txt"
    pack=(python3 tools/build_native_el0.py --policy amc --elf "$out/slot0.elf" --peer-elf "$out/slot1.elf")
    more=(--peer-elf "$out/slot2.elf" --peer-elf "$out/slot3.elf")
    run within-lo "${pack[@]}" --out "$out/within-lo" --amc-manifest examples/native-amc/config/within-lo.json
    run normal-hi "${pack[@]}" "${more[@]}" --out "$out/normal-hi" --amc-manifest examples/native-amc/config/normal-hi.json
    run invalid-budget "${pack[@]}" --out "$out/invalid-budget" --amc-manifest examples/native-amc/config/invalid-budget.json
    run fifth "${pack[@]}" "${more[@]}" --peer-elf "$out/slot0.elf" --out "$out/fifth" --amc-manifest examples/native-amc/config/normal-hi.json
    find "$out" -type f -maxdepth 3 -not -name 'slot*.elf' -print | tee "$evidence/outputs.txt"
fi
git status --porcelain
