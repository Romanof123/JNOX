sh sdk/native-aarch64/build.sh examples/native-amc/slot1.c output/native-amc/slot1.elf 
