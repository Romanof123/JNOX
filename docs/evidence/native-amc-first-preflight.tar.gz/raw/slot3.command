sh sdk/native-aarch64/build.sh examples/native-amc/slot3.c output/native-amc/slot3.elf 
