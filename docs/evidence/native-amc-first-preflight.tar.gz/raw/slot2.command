sh sdk/native-aarch64/build.sh examples/native-amc/slot2.c output/native-amc/slot2.elf 
