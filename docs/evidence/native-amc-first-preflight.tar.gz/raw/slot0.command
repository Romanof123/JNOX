sh sdk/native-aarch64/build.sh examples/native-amc/slot0.c output/native-amc/slot0.elf 
