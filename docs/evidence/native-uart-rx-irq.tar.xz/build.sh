#!/bin/bash
set -euo pipefail
base="$HOME/jnox406-lab"
cd "$base/src"
export PATH="$HOME/.cargo/bin:$PATH" CARGO_BUILD_JOBS=1 LC_ALL=C CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1
exec 9>"$base/run.lock"
flock 9
git checkout -q --detach "$1"
test -z "$(git status --porcelain --untracked-files=no)"
b="$base/$2"
mkdir "$b"
exec > >(tee "$b/run.log") 2>&1
python3 -B tools/test_native_service_slots.py -v
sh sdk/native-aarch64/build-rust.sh examples/native-uart-rx-irq/Cargo.toml "$b/app.elf"
args=(--board virt --policy fifo --elf "$b/app.elf" --priority 1)
devices=(--peer-elf "$b/app.elf" --peer-priority 2 --peer-arg denied --display-service 0)
python3 -B tools/build_native_el0.py "${args[@]}" "${devices[@]}" --uart-rx-irq --out "$b/irq"
python3 -B tools/build_native_el0.py "${args[@]}" "${devices[@]}" --out "$b/polled"
python3 -B tools/build_native_el0.py "${args[@]}" --out "$b/headless"
python3 -B tools/verify_native_uart_rx_irq.py --package "$b/irq" --polled-package "$b/polled" --headless-package "$b/headless" --out "$b/capture"
python3 -B tools/verify_native_uart_rx_irq.py --replay "$b/capture"
