#!/bin/bash
set -euo pipefail
base="$HOME/jnox406-lab"
exec 9>"$base/run.lock"
flock 9
build="$base/$1"
label="$2"
observer_rev="$3"
shift 3
case "$observer_rev" in (*[!0-9a-f]*|'') exit 2;; esac
test "${#observer_rev}" -eq 40
out="$build/$label"
test ! -e "$out"
observer=$(mktemp -d "$build/observer.XXXXXXXX")
git -C "$base/src" archive "$observer_rev" tools docs/evidence/native-linux-net-irq-board | tar -x -C "$observer"
(cd "$observer" && sha256sum tools/*.py) >"$observer/observer.sha256"
export LC_ALL=C PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/mnt/d/codex/jnox332-release-deps
status=0
python3 -B "$observer/tools/verify_linux_source_net_restart.py" --package "$build/native" --driver-manifest "$build/imported/import.json" --out "$out" "$@" >"$observer/output.log" 2>&1 || status=$?
if test -d "$out"; then
    cp "$observer/observer.sha256" "$out/observer.sha256"
    echo "$observer_rev" >"$out/observer-commit.txt"
fi
if test "$status" -ne 0; then tail -18 "$observer/output.log"; exit "$status"; fi
echo "Capture and replay passed at $out using $observer_rev"
