#!/usr/bin/env python3
"""Package two completed, ordinary JNOX three-role replacement boots for detached replay."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile

from replay import LABELS, STAGES, VERIFIER, read, regular, require, sha

PM = Path(__file__).resolve().parent
LAB = Path.home() / "jnox406-lab"
RAW = ("host.bin", "launch.json", "machine.log", "net.events", "nonce.bin", "observer-commit.txt",
       "observer.sha256", "result.json", "stderr.log", "uart.log", "wire.pcap")
GENERATED = {"jnox_rx_original_prefix.h", "jnox_rx_fault_select.inc", "jnox_virtnet_layout.h"}
TOOLS = ("verify_linux_source_net_restart", "verify_linux_source_net_irq", "verify_linux_source_net_rx_poll",
         "verify_linux_source_net_rx", "verify_linux_source_net_packets", "verify_linux_source_net_queues",
         "verify_linux_source_net", "verify_linux_source_rtc", "native_amc_roots", "native_el0_replay",
         "ordinary_amc_replay", "ordinary_amc_capture", "qemu_capture")
BOARD = "docs/evidence/native-linux-net-irq-board"
SOURCES = {"arch/aarch64", "boards", "kernel", "examples/linux-source-net-restart",
           "docs/native-linux-net-restart-design.en-ko.md", "drivers/linux-compat/profiles/virtio-net.json",
           "tools/build_linux_source_virtio_net.py", "tools/build_native_el0.py", "tools/build_kernel.py",
           "tools/import_linux_driver.py", "tools/linux_driver_el0_audit.py", "tools/linux_driver_relocations.py",
           "tools/linux_driver_tx_layout.py", "tools/prepare_linux_virtio_net_headers.py"}


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def copy(file, dest, digest=None):
    require(not file.is_symlink() and file.is_file(), f"missing or linked evidence file {file}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        require(sha(dest) == sha(file), f"conflicting inputs {dest}")
    else:
        shutil.copyfile(file, dest)
    if digest:
        require(sha(dest) == digest, f"source hash mismatch {file}")


def git(repo, *args):
    return subprocess.check_output(["git", "-c", f"safe.directory={repo.resolve().as_posix()}", "-C", repo, *args])


def export(repo, rev, paths, dest):
    require(re.fullmatch("[0-9a-f]{40}", rev), "invalid Git revision")
    for item in paths:
        p = Path(item)
        require(not p.is_absolute() and ".." not in p.parts, f"invalid git path {item}")
    data = git(repo, "archive", "--format=tar", rev, "--", *sorted(paths))
    with tarfile.open(fileobj=io.BytesIO(data)) as tar:
        for member in tar:
            if member.isdir():
                continue
            require(member.isfile() and not Path(member.name).is_absolute() and ".." not in Path(member.name).parts,
                    f"nonregular or external Git member {member.name}")
            target = dest / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(member) as src, target.open("wb") as out:
                shutil.copyfileobj(src, out)
    raw = git(repo, "cat-file", "commit", rev)
    require(hashlib.sha1(f"commit {len(raw)}\0".encode() + raw).hexdigest() == rev, "Git object identity")
    (dest / "commit.raw").write_bytes(raw)


def build(stage, args):
    original = args.build
    for part, names in (("native", ("manifest.json", "kernel.elf", "build.log", "user.elf", "native_peer.elf", "native_peer2.elf")),
                        ("imported", ("import.json",))):
        for name in names:
            copy(regular(original, Path(part) / name), stage / part / name)
    copy(regular(original, "build.log"), stage / "provenance/build.log")
    m, imp = read(stage / "native/manifest.json"), read(stage / "imported/import.json")
    imp_files = {r[f] for r in imp["restart_roles"] for f in ("elf", "map")} | GENERATED
    objects = {p.name for p in (original / "imported").glob("*.o")}
    require(set(imp["input_sha256_by_object"]) | {"virtio_net.callback.o"} <= objects, "missing compiled objects")
    for name in sorted(imp_files | objects):
        require(Path(name).name == name, f"unexpected imported filename {name}")
        rel = Path("imported") / name
        copy(regular(original, rel), stage / rel)
    files, tracked = {}, set(SOURCES)
    rev = m["commit"]
    require(re.fullmatch("[0-9a-f]{40}", rev), "source commit")
    for name, digest in imp["input_sha256"].items():
        p = Path(name)
        require(".." not in p.parts, f"compiler input escaped its root {name}")
        if name.startswith("headers/"):
            headers = args.headers or Path(imp["header_root"])
            rel = Path("source/linux-headers") / p.relative_to("headers")
            copy(regular(headers, p.relative_to("headers")), stage / rel, digest)
        elif name == imp["upstream"]["path"]:
            rel = Path("source/linux") / p
            copy(args.linux_source or Path(imp["source"]["path"]), stage / rel, digest)
        elif p.is_absolute():
            require(p.parent.name == "build" and p.name in GENERATED, f"unrecognized temporary input {name}")
            rel = Path("imported") / p.name
        else:
            tracked.add(name)
            rel = Path("source/jnox") / rev / p
        files[name] = rel.as_posix()
    export(args.repo, rev, tracked, stage / "source/jnox" / rev)
    write(stage / "source/index.json", {"commit": rev, "compiler_inputs": files,
          "header_root_at_build": imp["header_root"], "header_tree_sha256_at_build": imp["header_tree_sha256"]})
    copy(args.license, stage / "source/GPL-2.0")
    require(b"GNU GENERAL PUBLIC LICENSE" in (stage / "source/GPL-2.0").read_bytes(), "GPL license text")
    return m, imp


def capture(stage, args, label):
    origin = args.build / label
    require(origin.is_dir() and not origin.is_symlink() and not (origin / "failure.json").exists(),
            f"missing or failed {label}")
    paths = list(RAW)
    for s in STAGES:
        paths.extend(f"{s}/{name}" for name in ("ram.json", "qmp.json", "halted.json"))
    paths.extend(f"{s}/gate.json" for s in STAGES[:2])
    for path in paths:
        copy(regular(origin, path), stage / label / path)
    dest = stage / label
    rev = (dest / "observer-commit.txt").read_text().strip()
    require(re.fullmatch("[0-9a-f]{40}", rev), "observer commit")
    observer = stage / "observer" / rev
    if not observer.exists():
        files = {f"tools/{name}.py" for name in TOOLS} | {f"{BOARD}/board.json", f"{BOARD}/virt-net.dtb.gz"}
        export(args.repo, rev, files, observer)
        board = read(observer / BOARD / "board.json")
        require(hashlib.sha256(gzip.decompress((observer / BOARD / "virt-net.dtb.gz").read_bytes())).hexdigest()
                == board["sha256"], "pinned model DTB digest")
    require(read(dest / "launch.json")["qemu_sha256"] == read(observer / BOARD / "board.json")["qemu_sha256"],
            "recorded QEMU executable identity and pinned board provenance differ")
    return rev


def package(stage, args):
    m, imp = build(stage, args)
    revisions = {name: capture(stage, args, name) for name in LABELS}
    for p in (args.vendor / "elftools").rglob("*.py"):
        copy(regular(args.vendor, p.relative_to(args.vendor)), stage / "vendor" / p.relative_to(args.vendor))
    regular(stage, "vendor/elftools/elf/elffile.py")
    for name in ("LICENSE", "METADATA"):
        rel = Path("pyelftools-0.32.dist-info") / name
        copy(regular(args.vendor, rel), stage / "vendor" / rel)
    reader_dir = args.independent_dir
    reader = args.independent_reader
    if reader is None and reader_dir is not None and (reader_dir / "reader.py").is_file():
        reader = reader_dir / "reader.py"
    if reader:
        copy(reader, stage / "qa/reader.py")
        for label in LABELS:
            if reader_dir is not None and (reader_dir / f"{label}.json").is_file():
                copy(regular(reader_dir, f"{label}.json"), stage / "qa" / f"{label}.json")
        if reader_dir is not None and (reader_dir / "REPORT.en-ko.md").is_file():
            copy(regular(reader_dir, "REPORT.en-ko.md"), stage / "qa/REPORT.en-ko.md")
    for item in args.gate_log:
        label, sep, path = item.partition("=")
        require(sep and path and re.fullmatch(r"[\w.-]+", label) and label not in (".", ".."), "use --gate-log NAME=FILE")
        copy(Path(path), stage / "provenance/gates" / label)
    for name in ("build.sh", "capture.sh", "package_restart.py"):
        copy(PM / name, stage / "provenance" / name)
    copy(PM / "replay.py", stage / "replay.py")
    summaries = {}
    commands = []
    for label, rev in revisions.items():
        launch = read(stage / label / "launch.json")
        cmd = (f"PYTHONPATH=vendor python3 -B observer/{rev}/{VERIFIER} --replay --mutation-tests "
               f"--package native --driver-manifest imported/import.json --out {label} --mac {launch['mac']} --mtu {launch['mtu']}")
        commands.append(cmd)
        if reader:
            commands.append(f"PYTHONPATH=vendor python3 -B qa/reader.py native {label}")
        summaries[label] = {name: sha(stage / label / name) for name in RAW}
    write(stage / "bundle.json", {"captures": list(LABELS), "observer_commits": revisions, "raw_sha256": summaries,
          "source_commit": m["commit"], "kernel_sha256": m["kernel_elf_sha256"],
          "upstream": imp["upstream"], "independent_reader": bool(reader)})
    (stage / "README.md").write_text(
        "# Three-process native VirtIO-net replacement\n\nExtract in an empty Linux directory. Run "
        "`python3 -B replay.py` from the extracted root. Python 3.10 or newer and aarch64-linux-gnu-nm "
        "(Debian/Ubuntu binutils-aarch64-linux-gnu) are required. Pyelftools and its license are bundled. "
        "The replay reads local records and runs seven corruption controls per cold boot.\n\n"
        "Each capture retains the raw host socket stream, two host nonces, QEMU NIC filter PCAP, QEMU launch arguments "
        "and executable digest, MMIO/IRQ and instruction traces, UART, five stopped QMP/physical RAM checkpoints "
        "and both host gate records. The host wrote two test-only words in the survivor's private memory after "
        "the preexit and middle checkpoints. Their addresses, commands and before/after bytes are in gate.json. "
        "The observer checks both writes and the address translations against the captured physical pages. "
        "The decoded report gives ELF entries, QEMU trace line numbers for completed entry translations, distinct "
        "per-role live TTBR0 and first/exit SVC PCs. Several roles can share an ELF virtual entry address.\n\n"
        "source/index.json maps every recorded compilation input to archived bytes. imported/import.json retains "
        "the upstream Git blob identity, header profile, compiler commands, link map digests and object provenance. The original "
        "C text is under source/linux, and its GPL terms are under source/GPL-2.0. The archived board description "
        "is the historical pinned model record. Each launch records its own QEMU executable digest and command.\n\n"
        "Individual offline commands from this directory follow.\n\n```sh\n" + "\n".join(commands) + "\n```\n",
        encoding="utf-8")
    members = sorted(p for p in stage.rglob("*") if p.is_file())
    (stage / "SHA256SUMS").write_text("".join(f"{sha(p)}  {p.relative_to(stage).as_posix()}\n" for p in members))


def archive(stage, path):
    with tarfile.open(path, "x:xz", preset=4) as tar:
        for file in sorted(p for p in stage.rglob("*") if p.is_file()):
            rel = file.relative_to(stage).as_posix()
            regular(stage, rel)
            info = tarfile.TarInfo(rel)
            info.size = file.stat().st_size
            info.mode = 0o644
            with file.open("rb") as data:
                tar.addfile(info, data)


def extract(archive_path, dest):
    dest.mkdir()
    seen = set()
    with tarfile.open(archive_path, "r:xz") as tar:
        for member in tar:
            path = Path(member.name)
            require(member.isfile() and not path.is_absolute() and ".." not in path.parts and path not in seen,
                    f"unsafe or duplicate member {path}")
            seen.add(path)
            target = dest / path
            target.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(member) as data, target.open("xb") as stream:
                shutil.copyfileobj(data, stream)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--build", type=Path, default=LAB / "426-replacement-02")
    cli.add_argument("--output", type=Path, required=True, help="new release directory")
    cli.add_argument("--repo", type=Path, default=LAB / "src", help="Git repository containing the recorded commits")
    cli.add_argument("--linux-source", type=Path, help="relocated original Linux translation unit")
    cli.add_argument("--headers", type=Path, help="relocated header tree")
    cli.add_argument("--license", type=Path, default=PM.parent / "jnox424-pm/GPL-2.0")
    cli.add_argument("--vendor", type=Path, default=PM.parent / "jnox332-release-deps")
    cli.add_argument("--independent-dir", type=Path, default=PM / "independent", help="optional reader.py and boot reports")
    cli.add_argument("--independent-reader", type=Path, help="specific portable independent reader")
    cli.add_argument("--gate-log", action="append", default=[], metavar="NAME=FILE", help="additional external gate transcript")
    args = cli.parse_args()
    output = args.output.absolute()
    output.parent.mkdir(parents=True, exist_ok=True)
    require(not output.exists(), f"release path exists {output}")
    with tempfile.TemporaryDirectory(prefix="jnox-restart-offline-") as staging, tempfile.TemporaryDirectory(
            prefix=".jnox426-", dir=output.parent) as publishing:
        work = Path(staging)
        stage = work / "bundle"
        stage.mkdir()
        tempout = Path(publishing) / "release"
        tempout.mkdir()
        package(stage, args)
        path = tempout / "replacement.tar.xz"
        archive(stage, path)
        fresh = work / "extracted"
        extract(path, fresh)
        env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "LC_ALL": "C"}
        result = json.loads(subprocess.check_output([sys.executable, "-B", "replay.py"], cwd=fresh, env=env))
        write(tempout / "result.json", result)
        digest = sha(path)
        (tempout / (path.name + ".sha256")).write_text(f"{digest}  {path.name}\n")
        copy(fresh / "README.md", tempout / "README.md")
        require(not output.exists(), "release appeared concurrently")
        tempout.rename(output)
        print(f"{digest}  {output / path.name}", flush=True)


if __name__ == "__main__":
    main()
