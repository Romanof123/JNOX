# Three-process native VirtIO-net replacement

Extract in an empty Linux directory. Run `python3 -B replay.py` from the extracted root. Python 3.10 or newer and aarch64-linux-gnu-nm (Debian/Ubuntu binutils-aarch64-linux-gnu) are required. Pyelftools and its license are bundled. The replay reads local records and runs seven corruption controls per cold boot.

Each capture retains the raw host socket stream, two host nonces, QEMU NIC filter PCAP, QEMU launch arguments and executable digest, MMIO/IRQ and instruction traces, UART, five stopped QMP/physical RAM checkpoints and both host gate records. The host wrote two test-only words in the survivor's private memory after the preexit and middle checkpoints. Their addresses, commands and before/after bytes are in gate.json. The observer checks both writes and the address translations against the captured physical pages. The decoded report gives ELF entries, QEMU trace line numbers for completed entry translations, distinct per-role live TTBR0 and first/exit SVC PCs. Several roles can share an ELF virtual entry address.

source/index.json maps every recorded compilation input to archived bytes. imported/import.json retains the upstream Git blob identity, header profile, compiler commands, link map digests and object provenance. The original C text is under source/linux, and its GPL terms are under source/GPL-2.0. The archived board description is the historical pinned model record. Each launch records its own QEMU executable digest and command.

Individual offline commands from this directory follow.

```sh
PYTHONPATH=vendor python3 -B observer/74f9d2010bbcb63e97b7b39184b1b38db084d0e4/tools/verify_linux_source_net_restart.py --replay --mutation-tests --package native --driver-manifest imported/import.json --out handoff-a --mac 52:54:00:19:26:51 --mtu 1410
PYTHONPATH=vendor python3 -B qa/reader.py native handoff-a
PYTHONPATH=vendor python3 -B observer/74f9d2010bbcb63e97b7b39184b1b38db084d0e4/tools/verify_linux_source_net_restart.py --replay --mutation-tests --package native --driver-manifest imported/import.json --out handoff-b --mac 52:54:00:19:26:52 --mtu 1390
PYTHONPATH=vendor python3 -B qa/reader.py native handoff-b
```
