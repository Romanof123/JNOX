# Independent offline replay / 독립 오프라인 재검증

Both AArch64 QEMU captures passed. The reader used the embedded executable files, live SVC records, three-level page-table walks, five guest-memory checkpoints, socket bytes, NIC PCAP, native exit transcript and QEMU device trace. The reader has no dependencies on the project's verifier. Its two JSON outputs retain the full kernel, role, PCAP and machine-log digests.

두 부팅 모두 통과했다. 커널에 포함된 실행 파일 세 개의 해시와 실제 SVC 직후 명령·TTBR0를 대조했다. 슬롯 0·1·2의 TTBR0는 각각 0x1000040284000, 0x2000040699000, 0x3000040aae000이다. 슬롯 1의 타이머 기록은 교체 전·중·후 계속 진행했다.

| Boot | Old nonce → new nonce | INTID 79 deliveries with used-buffer status, primary / successor |
|---|---|---|
| handoff-a | 8af952c8fd8188ac → 7424ab708cae3e99 | 2 / 11 |
| handoff-b | e645551ed33618fc → 561fc944ff6d6fb1 | 2 / 10 |

The primary received one frame and exited with status 86. The device had completed a second frame on descriptor 1. Its used length and bounce bytes matched the second ingress frame, while the driver and peer still recorded one delivery. Descriptor 2 belonged to a different outstanding writable grant. Both GIC pending and VirtIO interrupt status were zero in the retirement record. Earlier CPU deliveries therefore coexist with an unreaped completion at exit.

두 수명주기 모두 장치 Status 리셋 쓰기, 0 재확인, RX·TX QueueReady 0 읽기를 관측했다. 교체 중간 시점에 링·DMA 버퍼·권한 표가 모두 0이었고 예비 드라이버는 아직 새 권한을 획득하기 전이었다. 토큰 2를 얻은 슬롯 2에서 토큰 1을 전달한 호출 여섯 개는 모두 -116이었다. 소비자의 권한 검사 세 개는 -13이었다. 슬롯 1의 전용 메모리에 도착한 새 프레임 80개와 60바이트 ACK는 모두 전송 원본 및 PCAP과 일치했다. 슬롯 0의 이전 수신 목적지는 다섯 시점 모두 같은 바이트를 유지했다.

The live captures exercised successful reset on the emulated device. The reset-failure quarantine branch is a source-level property here. In native_linux_net_queues.rs, reset invalidates ACTIVE_TOKEN, retires IRQ and checks reset completion. Failure sets QUARANTINED and returns before grant or ring clearing. A failed-reset model run, physical board and pending CPU interrupt at the precise moment of handoff are outside this reader's observations.

실측 범위는 QEMU의 정상 리셋 경로다. 실패 시 격리와 재사용 차단 순서는 소스에서 확인했다. 이 독립 판독에는 리셋 실패 모델 실행과 실물 보드 시험이 포함되지 않는다.
