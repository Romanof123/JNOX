#!/usr/bin/env python3
"""Replay a detached three-role JNOX replacement evidence bundle on Linux."""
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys


CONTROLS = ["same-root spare", "authorized stale grant", "reused nonce", "pending DMA bytes",
            "missing TX QueueReady reset readbacks", "old nonce in replacement delivery", "gate outside authorized word"]
STAGES = ("preexit", "middle", "spare", "active", "final")
LABELS = ("handoff-a", "handoff-b")
VERIFIER = "tools/verify_linux_source_net_restart.py"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def regular(root, relative):
    path = Path(relative)
    require(not path.is_absolute() and ".." not in path.parts, f"invalid relative path {relative}")
    file = root / path
    require(file.is_file() and not file.is_symlink() and file.resolve().is_relative_to(root.resolve()), str(file))
    return file


def checksums(root):
    ledger = {}
    for row in (root / "SHA256SUMS").read_text().splitlines():
        digest, name = row.split("  ", 1)
        require(re.fullmatch(r"[0-9a-f]{64}", digest) and name not in ledger, "invalid or duplicate checksum")
        require(sha(regular(root, name)) == digest, f"changed archive member {name}")
        ledger[name] = digest
    require(not any(p.is_symlink() for p in root.rglob("*")), "symlink in extracted bundle")
    members = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    require(members == set(ledger) | {"SHA256SUMS"}, "archive member inventory differs")
    return len(ledger)


def check_build(root):
    native, imported = root / "native", root / "imported"
    m, imp = read(native / "manifest.json"), read(imported / "import.json")
    require(m["tracked_changes"] == "" and (m["profile"], m["app"], m["board"], m["policy"]) ==
            ("native", "process", "virt", "fifo") and imp["mode"] == "rx-restart-service", "clean native build profile")
    require(sha(native / "kernel.elf") == m["kernel_elf_sha256"] and sha(native / "build.log") == m["build_log_sha256"],
            "native build hashes")
    require(len(m["slots"]) == len(imp["restart_roles"]) == 3, "three-slot intake")
    argv = m["package_argv"]
    require("--linux-source-net-restart" in argv and "--linux-source-net-restart-pending-test" not in argv,
            "ordinary replacement package arguments")
    inputs = [argv[i + 1] for i, value in enumerate(argv) if value in ("--elf", "--peer-elf")]
    require(inputs == [s["input"]["path"] for s in m["slots"]], "three packaged ELF arguments")
    kernel = (native / "kernel.elf").read_bytes()
    for slot, (s, r) in enumerate(zip(m["slots"], imp["restart_roles"])):
        require(s["slot"] == r["slot"] == slot and r["role"] == ("primary", "survivor", "spare")[slot]
                and (s["priority"], s["argv"]) == (8, ["/bin/app"]), "role binding")
        app = regular(native, s["elf"])
        require(r["sha256"] == sha(app) == sha(regular(imported, r["elf"])) == s["elf_sha256"]
                == s["input"]["sha256"] == m["source_sha256"][s["input"]["path"]]
                and app.read_bytes() in kernel and sha(regular(imported, r["map"])) == r["map_sha256"],
                f"linked slot {slot}")
        obj = ("driver.o", "irq_peer.o", "spare.o")[slot]
        require(r["source"] in imp["input_sha256_by_object"][obj], f"missing role source input {slot}")
    for name, data in imp["objects"].items():
        require(sha(regular(imported, name)) == data["sha256"], f"object {name}")
    for key in ("driver_object", "callback_object"):
        data = imp[key]
        require(sha(regular(imported, data["filename"])) == data["sha256"], key)
    src = read(root / "source/index.json")
    require(src["commit"] == m["commit"] and set(src["compiler_inputs"]) == set(imp["input_sha256"]),
            "compiler input inventory")
    for name, target in src["compiler_inputs"].items():
        require(sha(regular(root, target)) == imp["input_sha256"][name], f"compiler dependency {name}")
    for name, digest in m["kernel_build"]["config_sha256"].items():
        require(sha(regular(root / "source/jnox" / m["commit"], name)) == digest, f"kernel config {name}")
    upstream = imp["upstream"]
    tu = regular(root, src["compiler_inputs"][upstream["path"]]).read_bytes()
    require(hashlib.sha256(tu).hexdigest() == upstream["sha256"] == imp["source"]["sha256"]
            and hashlib.sha1(f"blob {len(tu)}\0".encode() + tu).hexdigest() == upstream["git_blob_sha1"],
            "upstream translation unit identity")
    return m, imp


def role_records(root, capture, m):
    """Read ELF entry values, live SVC journals and completed entry TB trace positions."""
    table = subprocess.check_output(["aarch64-linux-gnu-nm", "-S", "--defined-only", root / "native/kernel.elf"], text=True)
    records = read(capture / "final/ram.json")

    def journal(symbol):
        fields, = [line.split() for line in table.splitlines() if line.split()[-1:] == [symbol]]
        pa, left = int(fields[0], 16), int(fields[1], 16)
        buf = b""
        while left:
            n = min(4096 - pa % 4096, left)
            chunk = bytes.fromhex(records[f"{pa:x}/{n}"])
            require(len(chunk) == n, f"short {symbol} record")
            buf += chunk
            pa += n
            left -= n
        return [value for value, in struct.iter_unpack("<Q", buf)]

    journal_rows = journal("jnox_linux_net_restart_roles")
    startup = journal("jnox_native_startup_slots")
    require(len(journal_rows) == 21 and len(startup) >= 12, "startup and SVC extent")
    roles = []
    for i, slot in enumerate(m["slots"]):
        b = regular(root / "native", slot["elf"]).read_bytes()
        require(b[:6] == b"\x7fELF\x02\x01", "expected a little-endian ELF64")
        entry = struct.unpack_from("<Q", b, 24)[0]
        tick, pc, first_root, nr, exit_tick, exit_pc, exit_root = journal_rows[7*i:7*i+7]
        require(entry == startup[4*i] and 0 < tick <= exit_tick and first_root == exit_root ==
                slot["expected_ttbr0_el1"], f"recorded slot {i} entry, exit and live root")
        roles.append(dict(slot=i, elf=slot["elf"], elf_sha256=slot["elf_sha256"], elf_entry_pc=hex(entry),
                          startup_pc=hex(startup[4*i]), first_svc_tick=tick, first_svc_instruction_pc=hex(pc-4),
                          first_svc_return_pc=hex(pc), first_svc_number=nr, first_svc_ttbr0=hex(first_root),
                          exit_svc_tick=exit_tick, exit_svc_instruction_pc=hex(exit_pc-4),
                          exit_svc_return_pc=hex(exit_pc), exit_svc_ttbr0=hex(exit_root)))
    entries = [r["elf_entry_pc"] for r in roles]
    trace = (capture / "machine.log").read_bytes().splitlines()
    starts = {pc: [] for pc in set(entries)}
    for i, line in enumerate(trace):
        found = re.match(rb"^Trace 0: 0x[0-9a-f]+ \[[0-9a-f]+/([0-9a-f]+)/", line, re.I)
        if found and (pc := hex(int(found[1], 16))) in starts:
            if i + 1 == len(trace) or not trace[i+1].startswith(b"Stopped execution of TB chain before"):
                starts[pc].append(i+1)
    require(all(len(rows) == entries.count(pc) for pc, rows in starts.items()), "executed entry count")
    return {"roles": roles, "completed_entry_trace_lines_by_pc": starts}


def run(root, args):
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1", "PYTHONPATH": str(root / "vendor")}
    return json.loads(subprocess.check_output([sys.executable, "-B", *args], cwd=root, env=env))


def replay(root):
    member_count = checksums(root)
    m, imp = check_build(root)
    index = read(root / "bundle.json")
    require(index["captures"] == list(LABELS), "ordinary capture inventory")
    cases, nonces = {}, set()
    for label in LABELS:
        cap = root / label
        rev = (cap / "observer-commit.txt").read_text().strip()
        require(re.fullmatch("[0-9a-f]{40}", rev), "observer revision")
        observer = root / "observer" / rev
        measured = dict((n, h) for h, n in [row.split("  ", 1) for row in (cap / "observer.sha256").read_text().splitlines()])
        for path in (observer / "tools").glob("*.py"):
            require(sha(path) == measured["tools/" + path.name], f"capture-time module {path.name}")
        launch = read(cap / "launch.json")
        require(launch["roles"] == [s["elf_sha256"] for s in m["slots"]] and
                launch["import_sha256"] == sha(root / "imported/import.json"), "launch identity")
        raw_nonce = (cap / "nonce.bin").read_bytes()
        halves = {raw_nonce[:8], raw_nonce[8:]}
        require(len(raw_nonce) == 16 and len(halves) == 2 and not halves & nonces, "fresh boot/owner nonces")
        nonces.update(halves)
        args = [f"observer/{rev}/{VERIFIER}", "--replay", "--mutation-tests", "--package", "native",
                "--driver-manifest", "imported/import.json", "--out", label, "--mac", launch["mac"],
                "--mtu", str(launch["mtu"])]
        decoded = run(root, args)
        expected = read(cap / "result.json")
        require(decoded.pop("rejected_mutations") == CONTROLS and expected.pop("rejected_mutations", CONTROLS) == CONTROLS,
                f"{label} corruption controls")
        require(decoded == expected and decoded["ingress_packets"] == 83, f"{label} raw result")
        evidence = role_records(root, cap, m)
        require([int(r["first_svc_ttbr0"], 16) for r in evidence["roles"]] == decoded["roots"], "independent live roots")
        gates = {stage: read(cap / stage / "gate.json") for stage in STAGES[:2]}
        rec = {"replay_argv": ["python3", "-B", *args], "rejected_mutations": CONTROLS, **decoded, **evidence,
               "test_only_survivor_gate_writes": gates, "host_nonces_hex": raw_nonce.hex()}
        if index["independent_reader"]:
            argv = ["qa/reader.py", "native", label]
            ind = run(root, argv)
            if (root / f"qa/{label}.json").is_file():
                require(ind == read(root / f"qa/{label}.json"), f"{label} historical independent report")
            require(ind["role_sha256"] == launch["roles"] and ind["wire_sha256"] == sha(cap / "wire.pcap")
                    and ind["nonces"] == raw_nonce.hex() and [int(n,16) for n in ind["roots"]] == decoded["roots"]
                    and ind["tokens"] == decoded["epochs"] and ind["fresh_frames"] == 80 and ind["ack_bytes"] == 60,
                    f"{label} independent reader result")
            rec["independent_replay_argv"] = ["python3", "-B", *argv]
            rec["independent"] = ind
        cases[label] = rec
    return {"checksummed_members": member_count, "source_commit": m["commit"], "kernel_sha256": m["kernel_elf_sha256"],
            "linux_source": imp["upstream"], "captures": cases}


if __name__ == "__main__":
    print(json.dumps(replay(Path(__file__).resolve().parent), indent=2))
