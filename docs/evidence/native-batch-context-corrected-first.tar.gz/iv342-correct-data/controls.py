import hashlib,json,pathlib,subprocess,sys,tempfile
from collections import Counter
base=pathlib.Path.cwd()
products=pathlib.Path.home()/'jnox342-25a4198'/'products'
tool=pathlib.Path.home()/'iv342-correct-src/tools/native_batch_context.py'
digest=lambda b:hashlib.sha256(b).hexdigest()
for name,c in [('wrong-release-pa','tie-sjf'),('wrong-restored-x23','arrival-srtf')]:
 with tempfile.TemporaryDirectory() as raw:
  root=pathlib.Path(raw); dst=root/c;dst.mkdir()
  src=base/'observed'/c
  for f in src.iterdir():
   if f.name not in ('context.jsonl','session.json'): (dst/f.name).symlink_to(f)
  rows=[json.loads(line) for line in (src/'context.jsonl').read_text().splitlines()]
  if c=='tie-sjf':next(r for r in rows if r['kind']=='release')['pa']+=8
  else:[r for r in rows if r['kind']=='restore'][-1]['frame'][23]^=1
  stream=''.join(json.dumps(r)+'\n' for r in rows).encode()
  (dst/'context.jsonl').write_bytes(stream)
  session=json.loads((src/'session.json').read_bytes());session['hashes']['context.jsonl']=digest(stream)
  data=json.dumps(session).encode();(dst/'session.json').write_bytes(data)
  proc=subprocess.run([sys.executable,str(tool),'observed',str(products),raw,c,digest(data),session['hashes']['observer.so']],capture_output=True,text=True)
  print(name,proc.returncode,proc.stdout.strip(),proc.stderr);assert proc.returncode==1
s=(base/'observed/tie-sjf/exceptions.log').read_text().split('PC 0x400000',2)[1]
import re
print('A exception ELRs',Counter(re.findall('with ELR (0x[0-9a-f]+)',s)))
s=(base/'observed/arrival-srtf/context.jsonl').read_text().splitlines()
rows=list(map(json.loads,s));saved=rows[3];restored=rows[6]
import struct
for name,r in [('irq',saved),('restore',restored)]:
 (base/(name+'.frame')).write_bytes(struct.pack('<35Q',*r['frame']))
assert saved['frame']==restored['frame'] and saved['pa']==restored['pa']
