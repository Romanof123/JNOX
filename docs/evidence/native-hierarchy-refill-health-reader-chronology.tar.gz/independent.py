from totals import *
# A retained raw observation predates every arm in the discarded suffix.
fixture('omitted-arm-before-retained-transfer',mutate(prefix(wake,60),'FIRST',None,7,lambda v:1),[2])
# A retained idle landing at row 59 may be prior or inactive; in any case all programming for the omitted
# arm happens after the last retained decision's transfer. The same arm always precedes idle landing.
fixture('omitted-arm-finishes-after-own-landing',mutate(prefix(wake,60),'FIRST',None,10,lambda v:241304000),[2])
# A second omitted late sample can account for a larger max, as can a genuinely retained late with no
# need for an additional unseen maximum.
p=mult(prefix(wake,60),[('HEALTH',1,8,2),('HEALTH',1,9,10000200)])
z=fixture('unknown-second-omitted-maximum',p,[1]);assert z and z['detail']=='retained_prefix' and z['instrumentation']=='valid'
# Alter only possible regular-maximum magnitude with actual scored observations omitted.
p=crop(sat,8);z=fixture('unknown-regular-maximum',mutate(p,'HEALTH',1,9,lambda v:v+1),[0]);assert z and z['detail']=='retained_prefix'
Path('results.json').write_text(json.dumps(results,indent=2))
print([(k,v['rc']) for k,v in results.items() if not v['pass_control']])
