from hardware import *
def mult(lines,items):
 for tag,row,f,v in items:lines=mutate(lines,tag,row,f,lambda _,v=v:v)
 return lines
fixture('all-late-retained-wrong-max',mutate(prefix(wake,62),'HEALTH',1,9,lambda x:x+1),[2])
fixture('too-many-violations-after-FIRST',mult(prefix(wake,0),[('FIRST',None,1,87),('FIRST',None,4,87),('FIRST',None,2,75),('HEALTH',1,8,4)]),[2])
fixture('final-omitted-terminal-counted-as-irq',mutate(prefix(wake,88),'HEALTH',1,4,lambda x:x+1),[2])
fixture('all-scored-retained-wrong-within-limit-max',mutate(
 [s if not s.startswith('NATIVE HIERARCHY DROPPED') else 'NATIVE HIERARCHY DROPPED 1' for s in
 [l for l in sat if not l.startswith(('NATIVE HIERARCHY EVENT 100 ','NATIVE HIERARCHY TIMER 100 '))]],'HEALTH',1,9,lambda x:x+1),[2]) if False else None
# Last hidden decision is known terminal even without a retained adjacent first violation.
def crop(lines,keep):
 n=int(next(l for l in lines if l.startswith('NATIVE HIERARCHY HEALTH 1 ')).split()[-3])
 out=[]
 for line in lines:
  t=line.split()
  if line.startswith(('NATIVE HIERARCHY EVENT ','NATIVE HIERARCHY TIMER ')) and int(t[3])>=keep:continue
  if line.startswith('NATIVE HIERARCHY DROPPED '):line='NATIVE HIERARCHY DROPPED '+str(n-keep)
  if line.startswith('NATIVE HIERARCHY HEALTH 1 '):t[-2:]=[str(keep),str(n-keep)];line=' '.join(t)
  out.append(line)
 return out
fixture('all-scored-retained-wrong-within-limit-max',mutate(crop(sat,100),'HEALTH',1,9,lambda x:x+1),[2])
Path('results.json').write_text(json.dumps(results,indent=2))
print([k for k,v in results.items() if not v['pass_control']])
