from pathlib import Path
import json,subprocess as sp,sys
first=Path('../iv340-a1a6-first')
results={}
def run(name,p,want,expected=[]):
 cmd=[sys.executable,'src/tools/read_hierarchy_health.py',str(p)]
 for e in expected:cmd+=['--expect-exit',str(e)]
 v=sp.run(cmd,capture_output=True);out=v.stdout or v.stderr
 Path('outputs',name+'.txt').write_bytes(out)
 results[name]=dict(want=want,rc=v.returncode,pass_control=v.returncode in want,reason=v.stderr.decode().strip())
 return json.loads(out) if v.stdout else None
def fixture(name,lines,want):
 p=Path('cases',name+'.uart');p.write_text('\n'.join(lines)+'\n');return run(name,p,want)
for d in sorted((first/'raw').iterdir()):
 orig=d/'reader.json';o=json.loads(orig.read_text()) if orig.exists() else None
 want=[1 if o['timing']=='late' else 0] if o else [2]
 r=run(d.name,d/'uart',want,o['process_exits'] if o else [])
 if o:
  assert all(r[k]==v for k,v in o.items()),d
for name in ('false_terminal','lost_wrong_arm'):
 run('original_'+name,first/'host-controls'/(name+'.uart'),[2])
sat=(first/'raw/saturated-plain/uart').read_text().splitlines()
wake=(first/'raw/wake-trace/uart').read_text().splitlines()
def mutate(lines,tag,row,index,func):
 out=lines.copy();prefix='NATIVE HIERARCHY '+tag+' '+(str(row)+' ' if row is not None else '')
 i=next(i for i,l in enumerate(out) if l.startswith(prefix));w=out[i].split();w[3+index]=str(func(int(w[3+index])));out[i]=' '.join(w);return out
run('impossible-unmask',Path('cases/impossible-unmask.uart'),[1,2])
for n,tag,row,index,func in [('masked-interrupted-idle','TIMER',3,15,lambda v:v|128),('wrong-idle-DAIF','TIMER',3,20,lambda v:v&~128),('unmatched-idle-landing','TIMER',3,18,lambda v:v+1),('unmatched-pre-cval','TIMER',3,5,lambda v:v+1),('spontaneous-wake','EVENT',0,11,lambda v:1),('inverted-entry-settlement','EVENT',3,5,lambda v:0),('wrong-arm-kind','TIMER',0,2,lambda v:6),('bad-entry-PC','TIMER',3,16,lambda v:v+4),('lost-previous-id','TIMER',3,10,lambda v:v-1)]:
 fixture(n,mutate(sat,tag,row,index,func),[1,2])
def prefix(lines,n):
 out=[]
 for l in lines:
  t=l.split()
  if t[:2]==['NATIVE','HIERARCHY']:
   if t[2] in ('EVENT','TIMER') and int(t[3])>=n:continue
   if t[2]=='DROPPED':l='NATIVE HIERARCHY DROPPED '+str(89-n)
   if t[2]=='HEALTH' and t[3]!='END':t[-2:]=[str(n),str(89-n)];l=' '.join(t)
  out.append(l)
 return out
for j in (0,10,60,61,62,88):
 result=fixture('valid-prefix-'+str(j),prefix(wake,j),[1]);assert result and result['health']['max_lag']==9989268 and result['first_violation']['arm_seq']==61
for name,index,func in [('missing-arm-id',4,lambda v:v-1),('missing-pre-cval',8,lambda v:v+1),('missing-event',2,lambda v:v+1),('missing-landing',20,lambda v:v+1),('missing-spsr',17,lambda v:v|128)]:
 fixture(name,mutate(prefix(wake,61),'FIRST',None,index,func),[2])
Path('results.json').write_text(json.dumps(results,indent=2))
print([(k,v['rc']) for k,v in results.items() if not v['pass_control']])
