from verify import *
fixture('only-late-impossible-maximum',mutate(prefix(wake,61),'HEALTH',1,9,lambda v:v+1),[2])
fixture('impossible-remaining-IRQ-count',mutate(prefix(wake,0),'FIRST',None,2,lambda v:1),[2])
Path('results.json').write_text(json.dumps(results,indent=2))
print({k:v for k,v in results.items() if not v['pass_control']})
