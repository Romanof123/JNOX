from startup import *
# At distance one the sticky arm immediately follows the final checked programming.
fixture('mapped-prior-cval-mismatch',mutate(prefix(wake,60),'FIRST',None,8,lambda v:v^1),[2])
r=fixture('unknown-prior-cval-between-missing-arms',mutate(prefix(wake,59),'FIRST',None,8,lambda v:v^1),[1]);assert r and r['instrumentation']=='valid'
fixture('mapped-landing-mismatch',mutate(prefix(wake,61),'FIRST',None,20,lambda v:v+1),[2])
r=fixture('unmapped-landing-within-known-interval',mutate(prefix(wake,59),'FIRST',None,20,lambda v:v+1),[1]);assert r and r['instrumentation']=='valid'
fixture('readback-reserved-ctl',mutate(prefix(wake,60),'FIRST',None,15,lambda v:v|8),[2])
fixture('retained-interrupted-idle-fiq-mask-mismatch',mutate(sat,'TIMER',3,15,lambda v:v^64),[1,2])
fixture('omitted-DAIF-reserved-bits',mutate(prefix(wake,60),'FIRST',None,22,lambda v:v|1),[2])
Path('results.json').write_text(json.dumps(results,indent=2))
print([(k,v['rc']) for k,v in results.items() if not v['pass_control']])
