import sys
sys.path.insert(0,'src/tools')
from native_hierarchy_arm_replay import Hierarchy, DISTANCE
for name,wake,slots,k,d in [('tie',140,2,2,140),('wake-earlier',139,2,3,139),('grid-earlier',141,2,1,140),('horizon',106+DISTANCE+1,1,5,106+DISTANCE),('edge-in-range',106+DISTANCE,1,3,106+DISTANCE)]:
 groups={'PARENT':[[0,5]],'CHILD':[[0,0,5]],'LEAF':[[i,0,5] for i in range(slots)]}
 h=Hierarchy([1,100,62500000,40,1,1,slots],groups)
 row=[0]*47;row[4]=100;row[8:11]=[3,0,2**slots-1];row[14]=105;row[28]=5
 for i in range(slots):row[35+3*i:38+3*i]=[5]*3
 h.decision(row,dict(kind=4,due=105))
 r=[0]*47;r[4]=106;r[8:11]=[0,3,2**slots-2];r[14:19]=[d,100,105,6,1];r[29:32]=[1]*3;r[32]=wake
 if slots==2:r[38:41]=[0,0,5]
 h.decision(r,dict(kind=k,due=d))
 print(name,k,d)
