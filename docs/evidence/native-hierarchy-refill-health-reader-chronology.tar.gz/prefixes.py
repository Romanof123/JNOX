from pathlib import Path
import json,tempfile,sys
sys.path.insert(0,'src/tools')
from read_hierarchy_health import read_uart
table={}
for d in sorted(Path('../iv340-a1a6-first/raw').glob('*')):
 if not (d/'reader.json').exists():continue
 orig=json.loads((d/'reader.json').read_text()); lines=(d/'uart').read_text().splitlines()
 detail=[l for l in lines if l.startswith(('NATIVE HIERARCHY EVENT ','NATIVE HIERARCHY TIMER '))]
 header=[l for l in lines if l.startswith(('NATIVE HIERARCHY CONFIG ','NATIVE HIERARCHY PARENT ','NATIVE HIERARCHY CHILD ','NATIVE HIERARCHY LEAF '))]
 tail=[l for l in lines if l.startswith(('NATIVE HIERARCHY DROPPED ','NATIVE HIERARCHY HEALTH ','NATIVE HIERARCHY FIRST ','NATIVE EL0 EXIT ')) and ' END ' not in l]
 N=len(detail)//2;ok=0;fail=[]
 with tempfile.TemporaryDirectory() as tmp:
  p=Path(tmp,'uart')
  for n in range(N+1):
   t=[]
   for l in tail:
    if l.startswith('NATIVE HIERARCHY DROPPED '):l='NATIVE HIERARCHY DROPPED '+str(N-n)
    if l.startswith('NATIVE HIERARCHY HEALTH '):w=l.split();w[-2:]=[str(n),str(N-n)];l=' '.join(w)
    t.append(l)
   p.write_text('\n'.join(header+detail[:2*n]+t+['NATIVE HIERARCHY HEALTH END 1'])+'\n')
   try:
    r=read_uart(p,orig['process_exits']);assert all(r[k]==orig[k] for k in ('timing','instrumentation','first_violation','maximum_scored_lag_ticks','process_exits'));ok+=1
   except Exception as e:fail.append((n,str(e)))
 table[d.name]=dict(rows=N,accepted=ok,fail=fail)
Path('natural-prefixes.json').write_text(json.dumps(table,indent=2));print(sum(c['accepted'] for c in table.values()),[(k,c['fail']) for k,c in table.items() if c['fail']])
