from independent import *
fixture('startup-cannot-directly-arm-idle-first',mult(prefix(wake,0),[('FIRST',None,1,1),('FIRST',None,2,1),('FIRST',None,4,1)]),[2])
Path('results.json').write_text(json.dumps(results,indent=2))
print(results['startup-cannot-directly-arm-idle-first'])
