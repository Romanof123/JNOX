from additional import *
sys.path.insert(0,'src/tools')
from read_hierarchy_health import TIMER, ARM, ENTRY
def hw():
 lines=sat[:]
 ts=[dict(zip(TIMER,map(int,l.split()[3:]))) for l in lines if l.startswith('NATIVE HIERARCHY TIMER ')]
 evs=[list(map(int,l.split()[3:])) for l in lines if l.startswith('NATIVE HIERARCHY EVENT ')]
 i=next(i for i,t in enumerate(ts) if t['outcome']==1)
 a,t=ts[i-1],ts[i];t['entry_ctl']=4;t['outcome']=4
 h=next(l.split() for l in lines if l.startswith('NATIVE HIERARCHY HEALTH 1 '));h[8]=str(int(h[8])-1);h[10]='1'
 h[12]=str(max(t['earliest_irq']-ts[j-1]['due'] for j,t in enumerate(ts) if t['outcome']==1))
 first=[1,i,sum(v[1]==1 for v in evs[:i+1]),4,*[a[k] for k in ARM],*[t[k] for k in ENTRY],0,0]
 def line(l):
  if l.startswith('NATIVE HIERARCHY TIMER '+str(i)+' '):return 'NATIVE HIERARCHY TIMER '+' '.join(str(t[k]) for k in TIMER)
  if l.startswith('NATIVE HIERARCHY HEALTH 1 '):return ' '.join(h)
  if l.startswith('NATIVE HIERARCHY FIRST '):return 'NATIVE HIERARCHY FIRST '+' '.join(map(str,first))
  return l
 return list(map(line,lines))
r=fixture('consistent-invalid-hardware-readback',hw(),[1])
assert r and r['health']['invalid']==1 and r['timing']=='unqualified' and r['instrumentation']=='invalid_or_incomplete'
fixture('inconsistent-invalid-hardware-readback',mutate(hw(),'FIRST',None,15,lambda v:v^1),[2])
Path('results.json').write_text(json.dumps(results,indent=2))
