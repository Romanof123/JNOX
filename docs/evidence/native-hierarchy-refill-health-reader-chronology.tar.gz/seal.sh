set -eu
find cases outputs -type f > members
ls *.py *.json *.md *.log seal.sh >> members
sort -u members -o members
xargs -d '\n' sha256sum < members > MEMBER-SHA256
tar -czf reader-15a2-first.tar.gz -T members MEMBER-SHA256
mkdir recheck
tar xf reader-15a2-first.tar.gz -C recheck
(cd recheck && sha256sum -c MEMBER-SHA256 > ../verification.log)
dest=/mnt/d/codex/.jnox-work/next-fixed/340-verification-15a2
mkdir -p "$dest"
cp reader-15a2-first.tar.gz reader-supplement.en-ko.md "$dest/"
sha256sum reader-15a2-first.tar.gz reader-supplement.en-ko.md "$dest"/*
