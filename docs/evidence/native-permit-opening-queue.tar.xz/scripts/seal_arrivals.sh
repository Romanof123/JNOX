#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1 LC_ALL=C TZ=UTC
shared=$(cd "$(dirname "$0")" && pwd)
packet="$HOME/permit403-integration/arrivals/packet"
checks=/mnt/d/codex/permit401-queue-readback
cp "$shared"/{seal.py,replay.sh,seal_arrivals.sh} "$packet/scripts/"
cp "$checks"/{check_native.py,check_queue.py,raw_capture.py,native_controls.py,native-observations.json,NATIVE-REPORT.en-ko.md} "$packet/verification/"
python3 -B "$packet/verification/native_controls.py" "$packet" > "$packet/verification/native-controls.txt"
echo '9802c66bf711efa7ce786a2ed30a2b4604e86078914fd87d2c3d3d0384d3abca  native-observations.json' | (cd "$packet/verification" && sha256sum -c)
rsync -aS --exclude target/ --exclude __pycache__/ "$packet/" "$shared/arrivals/packet/"
python3 -B "$shared/seal.py" "$packet" "$shared"
