#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C TZ=UTC PYTHONDONTWRITEBYTECODE=1
packet=$(realpath "${1:-.}")
cd "$packet"
sha256sum --quiet -c SHA256SUMS
temp=$(mktemp -d)
trap 'rm -r -- "$temp"' EXIT
revision=$(sed -n 's/^built_local_commit=//p' identities.txt)
if [[ -f scripts/component_cold.py ]]; then lane=component; else lane=arrivals; fi
python3 -B scripts/identity.py . "$lane" > "$temp/identity.txt"
cmp "$temp/identity.txt" verification/identity.txt
cat "$temp/identity.txt"
if [[ $lane == arrivals ]]; then
    python3 -B verification/check_native.py . "$revision" > "$temp/native-observations.json"
    cmp "$temp/native-observations.json" verification/native-observations.json
    python3 -B verification/native_controls.py . > "$temp/native-controls.txt"
    cmp "$temp/native-controls.txt" verification/native-controls.txt
    cat "$temp/native-controls.txt"
else
    python3 -B verification/verify.py . --commit "$revision" --out "$temp/component"
    cmp "$temp/component/boots.json" verification/boots.json
    cmp "$temp/component/mutations.json" verification/mutations.json
    if [[ -f verification/raw_controls.py ]]; then
        bash verification/run_raw_controls.sh "$packet" "$temp"
    fi
fi
echo "All $lane verifier results reproduced from the extracted packet."
