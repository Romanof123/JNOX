"""Offline corrupt-record controls for the native queue comparison. No guest operations."""
import argparse
from pathlib import Path
from check_native import opening_heads


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("packet", type=Path)
    root = p.parse_args().packet
    runs = sorted((root / "runs").iterdir())
    for run in runs:
        lines = (run/"cap/uart.bin").read_text().splitlines()
        events = [list(map(int, line.split()[3:])) for line in lines if line.startswith("NATIVE SAFETY EVENT ")]
        opening_heads(events)
        selected = next((i for i,e in enumerate(events) if e[0]==17 and e[6:8]==[16,44]),None)
        if selected is not None:
            break
    else:
        raise ValueError("no positive full-frame control")
    # Use copies of captured records. Change only identity, ownership, or reporting fields.
    def test(label,index,field,value):
        altered = [e.copy() for e in events]
        if field is None:
            altered.pop(index)
        else:
            altered[index][field]=value
        try:
            opening_heads(altered)
        except ValueError:
            print(f"Rejected {label}")
            return
        raise ValueError(f"accepted corrupted input {label}")
    test("missing observation",selected,None,None)
    test("wrong head handle",selected,6,12)
    test("short frame",selected,7,43)
    test("zero occupancy for queued frame",selected,5,0)
    test("missing queue metadata sentinel",selected,7,2**64-1)
    test("wrong activation state",selected,8,0)
    test("wrong gate/fault flags",selected,9,0)
    test("different generation",selected,3,2)
    test("wrong subsequent SVC owner",selected+1,2,0)
    publication = next(i for i,e in enumerate(events) if e[0]==6 and e[2:5]==[0,34,0] and e[6]==16)
    test("post-publication occupancy disagrees",publication,5,0)


if __name__ == "__main__":
    main()
