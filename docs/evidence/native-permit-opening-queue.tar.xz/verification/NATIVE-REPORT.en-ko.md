# Native opening-CHECK queue observations

Twelve three-process boots ran the fixed arrival calendars on the stock virtual Cortex-A72. In **four** boots the full 44-byte seq4 frame was already queued at nominal expiry D. In **eight** boots the protected opening CHECK directly observed one 44-byte loan at the head, handle 16. All 12 opening expiry operands C fell after D. Each measurement uses one guest counter tick of 16 ns.

| Run | Publication bounds − D | C − D | Head at C | Private seq4 decision − C |
|---|---:|---:|---:|---:|
| 001 default FIFO before | −45,495 to −45,162 | 4,499 | 16 | 7,241 |
| 002 default FIFO same | 7,066 to 7,333 | 17,347 | 16 | 6,402 |
| 003 default FIFO after | 67,694 to 67,995 | 5,131 | empty | 384,776 |
| 004 default RR before | −46,873 to −46,548 | 7,370 | 16 | 8,472 |
| 005 default RR same | 7,087 to 7,430 | 17,521 | 16 | 6,600 |
| 006 default RR after | 67,945 to 68,391 | 5,664 | empty | 386,123 |
| 007 count0 FIFO before | −61,684 to −61,551 | 135 | 16 | 491 |
| 008 count0 FIFO same | 286 to 418 | 813 | 16 | 490 |
| 009 count0 FIFO after | 62,781 to 62,914 | 140 | empty | 375,471 |
| 010 count0 RR before | −61,660 to −61,528 | 141 | 16 | 508 |
| 011 count0 RR same | 405 to 537 | 956 | 16 | 507 |
| 012 count0 RR after | 62,788 to 62,920 | 146 | empty | 375,491 |

The observer reports the opening CHECK's own counter operand, generation, old accepted sequence, current occupancy, head handle and length, active state and post-decision gate/fault flags. It samples after the expiry decision in the same serialized kernel service. A separate process cannot dequeue between the operand and sample on this single vCPU. Each opening was joined to the preceding event 12 and ensuing successful PID1/SVC60 opening return. The real head agreed with an independent replay of the ordinary loan operations in all 204 opening observations. All 2,004 safety journal rows agreed byte-for-byte between UART and the linked kernel's retained RAM journal.

D was reconstructed from the accepted seq3 issue and its 20 ms validity. The four positive findings at D use whole publication brackets before D and a later lower bound on dequeue, obtained from the receiver's private activation entry. The MMU trace identified the same writer and read-only receiver backing page. All 12 dumps held the expected CRC-valid 44 bytes followed by 4,052 zero bytes on this page. The wire bytes also matched sender staging, sender publication data, the protected receive snapshot and receiver-private memory.

Both the authority and controller observed gen1, seq3, gate open, ENABLE high before staging. Every expiry CHECK latched the fault and recorded the output fall. The receiver's private expiry operand followed C by 87 to 2,815 ticks. Sequence 4 was subsequently received, released and declined with private status 17. The service journal showed zero further COMMIT calls, the previous seq3 was retained, both subsequent authority readings returned flags 5, and terminal ENABLE read zero. Every boot contained a protected inter-completion gap with a lower bound above 312,500 ticks (5 ms). The generic scheduler dropped 229–233 rows per boot. The complete safety and mapping journals and private RAM support the results here.

## 한국어

세 프로세스가 실행된 12개 부팅에서 고정된 일정을 그대로 관측했다. 네 `before` 실행에서는 순번 4의 44바이트 프레임을 명목 만료 D 전에 게시했고, D 이후에 수신했다. 네 `same` 실행에서는 D 이후에 게시했지만 늦게 실행된 실제 CHECK 때에는 이미 대기열에 있었다. 네 `after` 실행의 CHECK는 빈 대기열을 관측했다. D에서의 대기 상태는 게시 구간과 수신 하한으로 입증했으며, 실제 CHECK에서는 커널이 대기열을 직접 읽었다. 정확히 D에서 CHECK가 실행된 경우는 0건이다.

커널의 직접 관측 204건이 독립적으로 복원한 대기열과 일치했고, UART 기록 2,004행은 커널 RAM과 일치했다. 만료 전에는 감독자와 제어기가 순번 3, 열린 게이트, ENABLE 1을 확인했다. 12건 모두 CHECK에서 출력이 내려갔고, 수신기는 순번 4를 처리하려 할 때 오류 17을 기록하고 COMMIT을 건너뛰었다. 이후 감독자 관측 두 번에서 순번 3과 고장 래치가 유지됐다. 모든 부팅에서 적어도 한 번 완료 간격의 하한이 5 ms를 넘었다.

## Reproduction

Measured local source commit `a69bc6948c1d57c6df89d395e9307de5e0c6d6dc`, Git tree `a851e772eff77659b16d9a372de6d353be803757`, production source archive SHA-256 `bdca92f52717784e04c2e719e9d2a70a413a690dfbb3ed1e44279bf62919931e`. The per-run hashes, operands, flags and times are in `native-observations.json`.

With Python 3, GNU AArch64 nm and an extracted arrivals packet, run the following commands from the directory containing this report and the checkers. The ten negative controls alter copies of evidence records in memory and do not run a guest.

```sh
python3 -B check_native.py "$ARRIVAL_PACKET" a69bc6948c1d57c6df89d395e9307de5e0c6d6dc > /tmp/permit-native-queue.json
cmp native-observations.json /tmp/permit-native-queue.json
python3 -B native_controls.py "$ARRIVAL_PACKET"
```
