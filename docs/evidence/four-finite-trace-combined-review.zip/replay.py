"""Run from exact candidate checkout: python -B path/to/replay.py"""
import csv, hashlib, io, json, re, subprocess, sys, tarfile, zipfile
from pathlib import Path

def git(*args):
    return subprocess.check_output(["git","-C",sys.argv[1], *args])

def run(*args, cwd="."):
    p = subprocess.run([sys.executable, "-B", *args], cwd=cwd, capture_output=True)
    return p.returncode, p.stdout.decode("utf-8", "replace"), p.stderr.decode("utf-8", "replace")

head = git("rev-parse", "211febe8").decode().strip()
assert head == "211febe81eaba8c5a786b0f02b43a08bab20ce46"
def edges(rev):
    return set(tuple(row) for row in list(csv.reader(git("show", rev+":trace/links.csv").decode().splitlines()))[1:])
old, new = edges("7c84e293"), edges(head)
assert old <= new and len(new-old) == 64
print("graph unique triples",len(old),len(new)); print(head, "parent", git("rev-parse",head+"^2").decode().strip(), "64 added edges")
cases = [
("091","091","003",211,214,"e015d25b2ead31b43367922e94f0db5b4e650c82","batch_telemetry.rs","JobClass","admitted-telemetry-batch-first","d2dafdf3a6629005857bf24ba352d4731c2532134e087e6c6c37102226ac8274"),
("092","038","016",212,215,"59de3c67fcca3c911d3fd6a9bdbad7b4d2cf64ee","group_apps.rs","mod recurring","recurring-hierarchical-first","ccff2b51a34ff272f4ffedab1a71273374aa2bca125689c0350350532ff42304"),
("093","093","018",221,223,"3aec626ef802c990f1e977ab8308775c10d554fa","extension_normal_jobs.rs","normal_job_tick","ordinary-extension-jobs-first","ca89286cbc6469280620f65c96cbca36101ccdbc8a3ee15c4827302528a98ba1"),
("094","094","013",228,229,"4d8ea7af9c2a2cc0482025bd56809f5df98b6c66","pi4_migration_tasks.rs","pi4_stream_crc32_loop_v1","pi4-crc-mainline-first","a0ec8c9cfe651c4e0c3b6d74006b52e36eb616882b051701e65ef84f74a904da")]
for n,i,p,issue,pr,rev,src,symbol,name,sha in cases:
    chg,imp,pol,ev = "CHG-"+n,"IMP-"+i,"POL-"+p,"EVD-"+n
    for r,d in [("002","003"),("005","003"),("023","012")]+([("008","004")] if n=="094" else []):
        req,des,ver = "REQ-"+r,"DES-"+d,"VER-"+r
        assert {(req,"implemented-by-design",des),(des,"implemented-by",imp),(chg,"affects",req),(req,"partially-implemented-by",imp),(imp,"partially-verified-by",ver),(ver,"has-partial-evidence",ev)} <= new
    assert {(pol,"partially-implemented-by",imp),(imp,"tested-in",ev),(pol,"has-switch-evidence",ev)} <= new
    source = git("show",rev+":kernel/src/"+src)
    assert symbol.encode() in source
    base = Path("docs/evidence")
    report = (base/(name+".en-ko.md")).read_text(encoding="utf-8")
    archive = base/(name+".zip")
    assert rev in report and hashlib.sha256(archive.read_bytes()).hexdigest()==sha
    for suffix in [".en.md",".md"]:
        doc = base/(ev.lower()+suffix)
        text = doc.read_text(encoding="utf-8")
        assert set(re.findall(r"\b(?:IMP|CHG)-\d{3}\b",text))=={chg,imp}
        for s in [chg,imp,pol,"2026-11-25",rev,src,name+".en-ko.md",name+".zip",sha,"/issues/"+str(issue),"/pull/"+str(pr)]:
            assert s in text,(n,s)
        for link in re.findall(r"\]\(([^)]+)\)",text):
            if not link.startswith("https://"):
                assert (doc.parent/link).exists()
    with zipfile.ZipFile(archive) as z:
        if n=="091":
            for mode in ["normal","trace"]:
                for policy in ["sjf","srtf","hrrn"]:
                    uart=z.read(f"{mode}-{policy}/uart.log")
                    assert b"SUMMARY 3 0 65535 65542" in uart and uart.count(b"TELEMETRY JOB ")==3
                    if mode=="trace": assert uart.count(b"BATCH EVENT ")==9
        if n=="092":
            with tarfile.open(fileobj=io.BytesIO(z.read("first-records.tar.gz"))) as t:
                def read(s): return t.extractfile("record/"+s).read()
                rows=json.loads(read("traced-ordinary-groups-recurring/ledger.json"))
                assert len(rows)==14 and b"10162" in read("model-result")
                for path in ["traced-ordinary-groups-recurring/raw/uart.bin","plain-ordinary-groups-recurring/raw/run-1/uart"]:
                    assert b"GROUP ACK 3 0000000000008380 0000000000018780" in read(path)
        if n=="093":
            with zipfile.ZipFile(io.BytesIO(z.read("jnox223-first-raw.zip"))) as raw:
                assert b"EXTENSION NORMAL PASS" in raw.read("normal.capture/uart.bin")
                assert raw.read("normal.replay").strip()==b"PASS"
                rows=json.loads(z.read("crosscheck.log").decode().splitlines()[0].split(" ",1)[1])
                assert [r["slot"] for r in rows if r["decision"]==7]==[2,5,8]
                for pos,row in enumerate(rows):
                    prior=[r for r in rows[:pos] if r["job"]==row["job"]]
                    if prior: assert row["dispatch"]==prior[-1]["interrupted"]
        if n=="094":
            for mode in ["global","partitioned","clustered"]:
                for j in [1,2]:
                    replay=json.loads(z.read(f"stream-{mode}/replay-{j}.json"))
                    assert replay["qualifying_inner_pc"] and replay["destination_cpu"]==int(mode=="global")
                    uart=z.read(f"stream-{mode}/frozen/first-{j}/uart.bin")
                    assert b"4096 8765611335505774534 4194304 2027039441" in uart
    print(ev,pol,chg,imp,rev,sha,"source file SHA256",hashlib.sha256(source).hexdigest(),"PASS")
rc,_,err=run("tools/requirement_graph.py")
assert rc==0,err
rc,out,err=run("tools/scheduling_evidence.py")
findings=json.loads(out)["findings"]
assert rc==0 and findings==[]
print("requirement_graph PASS; scheduling_evidence PASS",json.dumps(findings))
rc,out,err=run("-m","unittest","test_requirement_graph","test_scheduling_evidence","test_pi4_stream_v1",cwd="tools")
assert rc==0,err
print(err.strip())

for path in ["docs/scheduling-release-cases.en.md","docs/scheduling-release-cases.md"]:
    matrix=Path(path).read_bytes().splitlines()
    parent=git("show","7c84e293:"+path).splitlines()
    amc=next(row for row in parent if row.startswith(b"| POL-015 "))
    assert amc in matrix and b"154.192160" in amc
    for n,i,p,*_ in cases:
        assert any(row.startswith(("| POL-"+p+" ").encode()) and ("evd-"+n).encode() in row for row in matrix)
    print(path,"AMC row identical to main and four evidence references present")
print("graph nodes",len(set(v for a,b,c in new for v in (a,c))))
