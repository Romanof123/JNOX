"""Read original sealed evidence. Usage: python audit.py REPO/docs/evidence"""
import collections, hashlib, io, json, re, struct, sys, tarfile, zlib
from pathlib import Path

root=Path(sys.argv[1])
accepted={
    "native-safety-channel-corrected.tar.gz": "ac1ccebba5a87122971cfa2c6c601765abddbd09d8193c1e28a659e4b4fb6587",
    "native-safety-fused-first.tar.gz": "a86b87964850374a00b2b07818d6f5f1fe4d43f286d4b482e50a88245f181233",
}
def sha(b): return hashlib.sha256(b).hexdigest()
def data(t, name):
    return t[name] if isinstance(t,dict) else t.extractfile(name).read()
def signed(x): return x if x<2**63 else x-2**64
def measure(t, basename, decl):
    uart=data(t,basename+"uart.bin")
    session=json.loads(data(t,basename+"session.json"))
    header=json.loads(data(t,basename+"launch.json"))
    assert sha(uart)==session["hashes"]["uart.bin"]
    assert header["revision"]==decl==header["argument_package"]["commit"]
    assert "-icount" not in header["argv"] and header["argv"][header["argv"].index("-smp")+1]=="1"
    lines=uart.decode().splitlines()
    def rows(tag):
        return [list(map(int,l[len(tag):].split())) for l in lines if l.startswith(tag+" ")]
    events=rows("NATIVE SAFETY EVENT")
    assert rows("NATIVE SAFETY DROPPED")==[[0]]
    rates={r[2] for r in events if r[0]==1}
    assert rates=={62500000}
    types=lambda n:[r for r in events if r[0]==n]
    calls,dev,comp,pubs,rec,marks=map(types,(5,2,10,11,7,4))
    checks=sorted(comp,key=lambda r:r[2])
    gaps=[[v[2]-u[3],v[3]-u[2]] for u,v in zip(checks,checks[1:])]
    f=[]
    for m in marks:
        before=[d for d in dev if d[3]<=m[2]]
        active=bool(before and before[-1][5]==1)
        det=next((r for r in types(3) if r[2]>=m[3]),None)
        safe=next((r for r in dev if det and r[4:6]==[1,0] and r[2]>=det[1]),None)
        preceding=[r for r in rec if r[1]<=m[2]]
        f.append(dict(command=m[4],pre_enabled=active,last_sequence=m[6],last_issue=m[7],mark=m[2:4],
                      last_receive_to_fault_lower=m[2]-preceding[-1][1] if preceding else None,
                      detect=[det[2],det[1]] if det else None,safe=safe[2:4] if safe else None,
                      limits=[det[1]-m[2],safe[3]-det[2],safe[3]-m[2]] if det and safe and active else None,
                      post_published=sum(r[2]>=m[3] and signed(r[5])==0 for r in pubs),
                      post_receives=sum(r[1]>=m[3] for r in rec),
                      queue_refused_post=sum(r[2]>=m[3] and signed(r[5])==-11 for r in pubs)))
    out=dict(sha_uart=sha(uart),sha_kernel=header["kernel_sha256"],exits=rows("NATIVE EL0 EXIT PID"),
             output=[r[4:6] for r in dev],fixed_dropped=rows("NATIVE FIXED DROPPED")[0][0],
             complete=len(comp),gap=[max(r[0] for r in gaps),max(r[1] for r in gaps)],fault=f,
             pub_status=[signed(r[5]) for r in pubs],
             supervisor_commands=[r[4:6] for r in calls if r[2:4]==[2,59]])
    return out, events
allout={}
for file,expected in accepted.items():
    b=(root/file).read_bytes(); assert sha(b)==expected
    with tarfile.open(fileobj=io.BytesIO(b),mode="r|gz") as stream:
        t={m.name:stream.extractfile(m).read() for m in stream if m.isfile() and
           (m.name.startswith("decoded/") or m.name.endswith(("/uart.bin","/session.json","/launch.json")) or
            re.fullmatch("(rr|fifo)-(silence|invalid|saturation|collision|boundary-witness|healthy|live)\\.tgz",m.name))}
        if file.startswith("native-safety-channel"):
            rows={}
            for name in t:
                if not re.fullmatch("decoded/(rr|fifo)-[a-z-]+.json",name): continue
                tag=Path(name).stem
                d=json.loads(data(t,name))
                out,events=measure(t,"raw/"+tag+"/cap/","b741028b2b81cb188b5bc9ebe2ab2707b4488aed")
                assert events==d["events"]
                rx=[r for r in events if r[0]==7]
                results=[]
                for e,r,h in zip(rx,d["received_rows"],d["received_bytes"]):
                    wire=bytes.fromhex(h)
                    assert wire==b"".join(x.to_bytes(8,"little") for x in e[4:])[:44] and e[2]==r[2]
                    candidates=[s for s,raw in zip(d["sender_rows"],d["sender_bytes"]) if s[8]==r[2] and raw==h and s[10]==0]
                    assert candidates
                    s=candidates[0]
                    results.append(dict(kind=s[4],status=r[5],generation=s[5],sequence=s[6],
                                        channel=int.from_bytes(wire[4:6],"little"),data_id=int.from_bytes(wire[6:8],"little"),
                                        crc_correct=zlib.crc32(wire[:40])==int.from_bytes(wire[40:44],"little"),
                                        valid_state_same=r[12:16]==r[16:20]))
                assert len(rx)==len(results)==len(d["received_bytes"])
                assert all(x["valid_state_same"] for x in results if x["status"])
                out.update(received=results, sender_status=[signed(s[10]) for s in d["sender_rows"]],
                           clock_clone=d["exact_clock_control"],rearm_clone=d["exact_rearm_control"],live_pair=d["live_startup"],
                           header_errors=[d[role+"_header"][4] for role in ("sender","receiver","supervisor")])
                rows[tag]=out
            assert len(rows)==32
            allout["ordinary"]=rows
        else:
            rows={}
            for name in t:
                if not re.fullmatch("(rr|fifo)-(silence|invalid|saturation|collision|boundary-witness|healthy|live)\\.tgz",name): continue
                with tarfile.open(fileobj=io.BytesIO(data(t,name)),mode="r:gz") as inn:
                    rows[Path(name).stem],_=measure(inn,"cap/","c5ab397e93d345a4fef4420fe9cf7fa3e4be97ac")
            assert len(rows)==14
            allout["fused"]=rows
print(json.dumps(allout,indent=1,sort_keys=True))
