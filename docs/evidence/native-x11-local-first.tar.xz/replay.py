#!/usr/bin/env python3
"""Read archived native screen and X server observations without starting either system."""
from pathlib import Path
import collections, hashlib, json, re, struct, sys, zlib

def need(ok, msg):
    if not ok:
        raise ValueError(msg)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def png(path):
    data=path.read_bytes()
    need(data[:8]==b'\x89PNG\r\n\x1a\n',str(path))
    offset=8; blocks=[]; size=None
    while offset<len(data):
        length,=struct.unpack_from('>I', data, offset)
        kind=data[offset+4:offset+8]; payload=data[offset+8:offset+8+length]
        expected,=struct.unpack_from('>I',data,offset+8+length)
        need(zlib.crc32(kind+payload)==expected,'PNG CRC')
        if kind==b'IHDR':
            w,h,bits,ctype,comp,flt,interlace=struct.unpack('>IIBBBBB',payload)
            need(bits==8 and ctype==2 and (comp,flt,interlace)==(0,0,0),'RGB8')
            size=(w,h)
        elif kind==b'IDAT':
            blocks.append(payload)
        offset+=length+12
    w,h=size
    raw=zlib.decompress(b''.join(blocks)); stride=1+w*3
    need(len(raw)==h*stride and all(raw[i]==0 for i in range(0,len(raw),stride)),'original filter-zero RGB')
    return w,h,b''.join(raw[i+1:i+stride] for i in range(0,len(raw),stride))

def run(root):
    for mode in ('local','remote'):
        cap=root/mode
        d=json.loads((cap/'status.json').read_text())
        need(d['result']=='passed' and d['guest_exits']==[[0,0],[1,0]] and d['invalid_cookie_rejected'],'terminal evidence')
        uart=(cap/'uart').read_text()
        for slot,key in enumerate(('client','broker')):
            need(d['package']['sha256'][key]==sha(root/('x11.elf' if slot==0 else 'inet.elf')),'caller/broker digest')
            need(d['package']['sha256'][key] in uart,'UART startup identity')
        frames=[]
        for label in ('before','after'):
            obs=d['frames'][label]
            need(sha(cap/(label+'.png'))==obs['png_sha256'] and obs['matched_pixels']==38400,'X server capture')
            xw,xh,xrgb=png(cap/(label+'.png'))
            x,y,w,h=d['geometry']
            need((w,h)==(240,160) and x+w<=xw and y+h<=xh,'X window bounds')
            crop=[xrgb[((y+i)*xw+x)*3:((y+i)*xw+x+w)*3] for i in range(h)]
            frames.append(b''.join(crop))
            if mode=='local':
                rgb=bytearray(320*240*3)
                for i,row in enumerate(crop):
                    k=((i+40)*320+40)*3
                    rgb[k:k+len(row)]=row
                name='local-'+label
                state=d['frames'][name]
                need(sha(cap/(name+'.png'))==state['png_sha256'] and png(cap/(name+'.png'))==(320,240,bytes(rgb)),'JNOX scanout vs X server')
                for suffix in ('.ppm','-repeat.ppm'):
                    raw=(cap/(name+suffix)).read_bytes()
                    need(raw.startswith(b'P6\n320 240\n255\n') and raw.split(b'255\n',1)[1]==rgb,'independent device scanout')
                need(state['matched_pixels']==76800 and hashlib.sha256(rgb).hexdigest()==state['rgb_sha256'],'full frame')
        need(frames[0]!=frames[1], 'input changes window')
        if mode=='local':
            need(len(d['relay']['get_image'])==10,'ten guest GetImage requests')
        print(mode,'two distinct verified window states, both guest processes exited 0')
if __name__=='__main__':
    run(Path(__file__).resolve().parent)
