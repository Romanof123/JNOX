import sys, subprocess as sp, tempfile, zipfile, io, json, hashlib, re, struct, csv
from pathlib import Path
repo=Path(sys.argv[1]).resolve()
out=Path(__file__).resolve().parent
base="2a24bf993a4f326437ad93b1d84bc780410c1417"
head="577b49fad60aff8bbf95d6da7811730de021df11"
plan="17e640b962267b4f8819a27aaae05faff6e7deba"
def git(*a): return sp.check_output(["git","-C",str(repo),*a])
def sha(b): return hashlib.sha256(b).hexdigest()
def save(n,x): (out/n).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding="utf8")
assert git("rev-parse",head+"^").decode().strip()==plan
assert git("rev-parse",plan+"^").decode().strip()==base
changed=git("diff","--name-only",base,head).decode().splitlines()
assert len(changed)==6 and all(p.startswith("docs/") or p=="trace/links.csv" for p in changed)
records={}
for rev,label in [(base,"before"),(head,"after")]:
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp)
  paths=["tools/scheduling_evidence.py","tools/requirement_graph.py","trace/links.csv","docs/*.md","docs/*.json","docs/evidence/*.md","docs/evidence/*.json"]
  zipfile.ZipFile(io.BytesIO(git("archive","--format=zip",rev,*paths))).extractall(root)
  def run(tool,case,expected):
   c=sp.run([sys.executable,str(root/"tools"/(tool+".py"))],capture_output=True)
   raw=c.stdout+c.stderr
   (out/(case+".txt")).write_bytes(raw)
   assert c.returncode==expected,(case,c.returncode,raw[-500:])
   records[case]=[c.returncode,json.loads(raw)["findings"] if tool.startswith("scheduling") else len(raw.splitlines())]
  run("scheduling_evidence",label+"-catalog",1)
  run("requirement_graph",label+"-graph",0)
  if label=="before":
   assert len(records["before-catalog"][1])==4
   continue
  assert records["after-catalog"][1]==["bilingual change/implementation references disagree for EVD-058"]
  edge=root/"trace/links.csv"
  orig=edge.read_bytes()
  target=b"IMP-058,tested-in,EVD-058"
  assert orig.count(target)==1
  edge.write_bytes(b"".join(x for x in orig.splitlines(True) if not x.startswith(target)))
  run("scheduling_evidence","missing-edge",1)
  edge.write_bytes(orig)
  for ev in ["058","090"]:
   for suffix in ["md","en.md"]:
    path=root/"docs/evidence"/("evd-"+ev+"."+suffix)
    raw=path.read_bytes()
    path.unlink()
    run("scheduling_evidence","missing-"+path.name,1)
    path.write_bytes(raw)
    txt=raw.decode()
    for link in re.findall(r'\]\(([^)]+)\)',txt):
     dest=(path.parent/link).resolve().relative_to(root).as_posix()
     git("cat-file","-e",head+":"+dest)
    token="10,507" if ev=="058" else "20,496"
    assert txt.count(token)==1
    altered=txt.replace(token,"999,999")
    assert token not in altered
    records["independent-false-scope-"+path.name]="rejected wrong numeric literal"
  path=root/"docs/evidence/evd-058.md"
  korean=path.read_text(encoding="utf8")
  expr=r"\b(?:CHG|IMP)-[0-9]{3}\b"
  eng=(path.parent/"evd-058.en.md").read_text(encoding="utf8")
  records["extracted-before"]=[re.findall(expr,korean),re.findall(expr,eng)]
  path.write_text(korean.replace("IMP-058은","`IMP-058`은").replace("CHG-076에서","`CHG-076`에서"),encoding="utf8")
  run("scheduling_evidence","disposable-token-delimiter-control",0)
  edges=set(tuple(x) for x in csv.reader(orig.decode("utf-8-sig").splitlines()))
  required=["DES-003,implemented-by,IMP-058","DES-012,implemented-by,IMP-058","POL-015,partially-implemented-by,IMP-058","IMP-058,tested-in,EVD-058","POL-015,has-partial-policy-evidence,EVD-058","REQ-009,verified-by,VER-009","VER-009,has-partial-evidence,EVD-090"]
  for ver in ["002","005","023"]:
   required+=["IMP-058,partially-verified-by,VER-"+ver,"VER-"+ver+",has-partial-evidence,EVD-058"]
  assert all(tuple(x.split(",")) in edges for x in required)
  records["typed-edges"]=required
save("catalog-results.json",records)
def blob(p): return git("show",head+":docs/evidence/"+p)
archives={}
def archive(name,reference):
 data=blob(name)
 h=sha(data)
 assert h.encode() in blob(reference)
 z=zipfile.ZipFile(io.BytesIO(data))
 assert z.testzip() is None
 archives[name]={"sha256":h,"members":len(z.namelist()),"digest_reference":reference}
 return z
def j(z,n): return json.loads(z.read(n))
a=archive("ordinary-amc-first.zip","ordinary-amc-first.json")
b=archive("ordinary-amc-finite-first.zip","ordinary-amc-finite-first.json")
c=archive("ordinary-amc-integrated.zip","ordinary-amc-finite-first.en-ko.md")
d=archive("evd-090-virt-static-first.zip","evd-090-virt-static-first.json")
e=archive("evd-090-virt-static-corrected.zip","evd-090-virt-static-corrected.en-ko.md")
f=archive("evd-090-virt-static-blind.zip","evd-090-virt-static-corrected.en-ko.md")
idx=json.loads(blob("ordinary-amc-first.json"))
for case in idx["cases"]:
 n=case["case"]
 assert sha(a.read(n+"/kernel.elf"))==case["elf_sha256"]
 assert sha(a.read(n+"/first/session.json"))==case["session_sha256"]
 if n!="exact-lo": assert j(a,n+"-verdict.json")["outcome"]=="rejected"
 for z,member in [(b,n+"-replay.json"),(c,"integrated/"+n+"-combined.json")]:
  result=j(z,member)
  if n!="exact-lo":
   fresh=result["generation_products"][-1]
   assert (fresh["samples"],fresh["checksum"])==(8,36)
  assert result["case"]==n
for name,ex in [("minimal",(275,20496)),("fixed-rr",(14728,115056))]:
 data=d.read(name+".elf")
 ph=struct.unpack_from("<Q",data,32)[0]
 size,count=struct.unpack_from("<HH",data,54)
 loads=[struct.unpack_from("<IIQQQQQQ",data,ph+i*size) for i in range(count)]
 rx,rw=sorted([s for s in loads if s[0]==1],key=lambda s:s[3])
 assert (rx[6],rw[3]+rw[6]-rx[3])==ex
 assert sha(data)==j(d,"independent.json")[name]["sha256"]
correct=j(e,"replayed.json")["cases"]
blind=j(f,"candidate-results.json")
assert len(correct)==30 and all(x["matched"] for x in correct)
assert len(blind["runs"])==20 and all(x["code"]==x["predicted"] for x in blind["runs"])
subjects={}
for rev,p in [(idx["candidate"],"kernel/src/ordinary_amc.rs"),("420eaaa2f7d85507b716cfb862fb2c7c137dfabf","kernel/src/ordinary_amc.rs"),("6a336318e265785b5c0d8df3b5a8649632520919","kernel/src/ordinary_amc.rs"),("34454f955a30b0d3be0a4dfc73435a344f2dbff9","tools/virt_footprint.py"),(blind["candidate"],"tools/virt_footprint.py")]:
 subjects[rev]=[p,git("rev-parse",rev+":"+p).decode().strip()]
assert subjects[blind["candidate"]][1]==blind["tool_git_blob"]
save("provenance.json",dict(base=base,plan=plan,head=head,changed=changed,archives=archives,subjects=subjects))
print("Candidate REJECT. Audit assertions passed.")


