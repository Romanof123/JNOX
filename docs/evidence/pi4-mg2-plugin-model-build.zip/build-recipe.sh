#!/usr/bin/env bash
# #198 model-only reproduction, inside newly created empty local directory.
# Supply the same private/reference inputs locally. No guest or plugin is run here.
set -euo pipefail
umask 077
export LC_ALL=C PYTHONDONTWRITEBYTECODE=1
: "${LAB:?set LAB to the matching local ARM-Speed System 0.3.0 package root}"
: "${HISTORICAL_QEMU_SOURCE:?set HISTORICAL_QEMU_SOURCE to the preserved patched source}"
: "${HISTORICAL_VENV:?set HISTORICAL_VENV to the preserved Python 3.10.12 and Meson 1.12.1 environment}"
: "${BUILD_PARENT:?set BUILD_PARENT to an existing Linux build directory}"
recipe_root=$(cd "$(dirname "$0")" && pwd)
out=$(mktemp -d "$BUILD_PARENT/model-198-XXXXXX")
src="$out/qemu-11.1.3"
py="$HISTORICAL_VENV/bin/python"
(cd "$LAB"; sha256sum -c "$recipe_root/inputs.sha256")
tar -xJf "$LAB/vendor/qemu-11.1.3.tar.xz" -C "$out"
"$py" "$LAB/system/prepare_source.py" "$src"
# The release patch generator introduces one blank line. Restore the exact
# build input after confirming the difference is blank lines only.
diff -B "$HISTORICAL_QEMU_SOURCE/accel/tcg/cpu-exec.c" "$src/accel/tcg/cpu-exec.c"
cp -- "$HISTORICAL_QEMU_SOURCE/accel/tcg/cpu-exec.c" "$src/accel/tcg/cpu-exec.c"
printf '%s  %s\n' 0c17eb979eb82cb0cfe87f86e52eba44ddb968426bec44d4882259e5d42580d5 "$recipe_root/patched-files.sha256" | sha256sum -c -
(cd "$src"; sha256sum -c "$recipe_root/patched-files.sha256")
mkdir "$out/build"
cd "$out/build"
core=$("$py" -c 'import os; print(min(os.sched_getaffinity(0)))')
nice -n 15 taskset -c "$core" "$src/configure" --python="$py" --target-list=arm-softmmu,aarch64-softmmu --enable-plugins --disable-docs --disable-tools --disable-werror --disable-gtk --disable-sdl --disable-vnc --disable-curses --disable-opengl --disable-virglrenderer --disable-slirp > "$out/configure.log" 2>&1
grep -E '^#define CONFIG_(PLUGIN|TRACE_LOG)' config-host.h
nice -n 15 taskset -c "$core" /usr/bin/ninja -j1 qemu-system-aarch64 > "$out/build.log" 2>&1
sha256sum qemu-system-aarch64 config-host.h config.status "$src/include/plugins/qemu-plugin.h"
readelf -n qemu-system-aarch64 | grep 'Build ID'
nm -D --defined-only qemu-system-aarch64 | awk '$3 ~ /^qemu_plugin_/{print $3}' | LC_ALL=C sort
printf 'New isolated build is at %s\n' "$out"

