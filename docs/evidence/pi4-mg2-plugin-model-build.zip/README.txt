JNOX #198 Integration model build. Verify SHA256SUMS after extracting.
The generic recipe expects the original inputs on the local operator's machine.
The receipt identifies complete original configure and Ninja logs by SHA-256 and length.
A fresh reproduction has a distinct build path; exact ELF file bytes are not promised.
