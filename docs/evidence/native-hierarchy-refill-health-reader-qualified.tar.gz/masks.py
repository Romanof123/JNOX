from mapped import *
for scope,lines,tag,row,sp,da in [('retained',sat,'TIMER',3,15,20),('omitted',prefix(wake,60),'FIRST',None,17,22)]:
 for n in range(8):
  mask=sum(bit for j,bit in enumerate((64,256,512)) if (n>>j)&1)
  m=mutate(lines,tag,row,sp,lambda x:(x&~0x340)|mask)
  m=mutate(m,tag,row,da,lambda x:(x&~0x340)|mask)
  r=fixture(scope+'-DAF-'+str(n),m,[0] if scope=='retained' else [1]);assert r and r['instrumentation']=='valid'
 for b in (64,256,512):
  fixture(scope+'-contradictory-mask-'+str(b),mutate(lines,tag,row,sp,lambda x:x^b),[2])
 for b in (1,32,1024,1<<63):
  fixture(scope+'-DAIF-reserved-'+str(b),mutate(lines,tag,row,da,lambda x:x|b),[2])
 for b in (28,29,30,31):
  r=fixture(scope+'-NZCV-'+str(b),mutate(lines,tag,row,sp,lambda x:x^(1<<b)),[0] if scope=='retained' else [1]);assert r and r['instrumentation']=='valid'
 # Same EL1 IRQ cannot originate in EL0t.
 fixture(scope+'-EL0-contradicts-idle',mutate(lines,tag,row,sp,lambda x:x&~15),[2])
# User IRQ has no idle ingress measurements; genuine user flags are independent of these masks.
r=fixture('active-NZCV',mutate(sat,'TIMER',1,15,lambda x:x^0xf0000000),[0]);assert r and r['instrumentation']=='valid'
fixture('active-spurious-idle-sample',mutate(sat,'TIMER',1,18,lambda x:17),[2])
Path('results.json').write_text(json.dumps(results,indent=2));print(len(results),[k for k,v in results.items() if not v['pass_control']])
