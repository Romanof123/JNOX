set -eu
d=/mnt/d/codex/.jnox-work/next-fixed/mg2-independent-17cff17
x=$(mktemp -d /home/ywcho/qa199-XXXXXX)
echo "$x" > "$d/native.txt"
cd "$x"
mkdir src
git -C /mnt/d/codex/j-nox archive 17cff17fa6873c3dc1dcbbb9519b8dae79479bcd tools docs/boards/pi4-mg2-sparse.en-ko.md docs/evidence/pi4-migration-mg2-first.zip | tar -xC src
cd src
export PYTHONPATH=/home/ywcho/jnox-169-first-e203caa/deps
m=/home/ywcho/jnox198-model-Al60nH
b=/home/ywcho/jnox199-build-dz30zjz6
a=/mnt/d/codex/.jnox-work/next-fixed/mg2-199-observer-compile-17cff17/model-attestation.json
p=tools/pi4_mg2_sparse.py
python3 tools/test_pi4_mg2_sparse.py > "$d/tests.txt" 2>&1
f=$(python3 "$p" freeze "$x/pair" "$m/build/qemu-system-aarch64" "$b/observer.so" "$b/build-receipt.json" "$a" "$m/qemu-11.1.3/include/plugins/qemu-plugin.h" 2e465436514c0dc203eb2e9c3440187252cb84ebcdcc3fee6de76c9fa1c95fe6 ef73da8a108e97b7d11566630ac676893c2f3ef8)
cp -r "$x/pair" "$d/pair"
for n in 1 2
do
  set +e
  python3 "$p" run "$x/pair" "$f" "$n" > "$d/run-$n.txt" 2>&1
  echo $? > "$d/run-$n.rc"
  set -e
  cp -r "$x/pair/first-$n" "$d/pair/"
  (cd "$x/pair"; find "first-$n" -type f -print0 | sort -z | xargs -0 sha256sum) > "$d/position-$n.sha256"
  (cd "$d/pair"; sha256sum -c "$d/position-$n.sha256") > "$d/reopen-$n.txt"
  if test -f "$x/pair/first-$n/session.json"; then
    h=$(sha256sum "$x/pair/first-$n/session.json" | cut -d' ' -f1)
    set +e
    python3 "$p" replay "$x/pair" "$f" "$n" "$h" > "$d/replay-$n.txt" 2>&1
    echo $? > "$d/replay-$n.rc"
    set -e
  fi
done