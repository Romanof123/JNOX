from pathlib import Path
import json, struct
d=Path(__file__).parent
for n in (1,2):
    f=d/"pair"/f"first-{n}"
    raw=(f/"terminal-ram.bin").read_bytes()
    for cpu in (0,1):
        j=0xa9178-577536+cpu*6944
        used,lost=struct.unpack_from("<QQ",raw,j+6912)
        rows=[struct.unpack_from("<9Q",raw,j+i*72) for i in range(used)]
        for i,r in enumerate(rows):
            if r[8] in (11,7) or r[8]==5 and r[3]==65536:
                print(n,cpu,i,r)
        if cpu==0:
            r=rows[14]
            assert (r[8],*r[:5],r[6])==(5,0,1,1,65536,2147516416,0x801f0)
            assert [r for r in rows[:14] if r[8]==11][-1][:3]==(0,0,1)
        else:
            assert rows[7][:2]==(0,0x18001) and rows[7][8]==7
        assert lost==0