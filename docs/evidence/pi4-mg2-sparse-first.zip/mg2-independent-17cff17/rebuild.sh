set -eu
d=/mnt/d/codex/.jnox-work/next-fixed/mg2-independent-17cff17
x=$(cat "$d/native.txt")
cd "$x/src"
python3 -c 'import json, subprocess; subprocess.run(json.load(open("../pair/build-receipt"))["compiler_argv"],check=True)'
cmp observer.so ../pair/observer.so
sha256sum observer.so > "$d/rebuild.txt"
mkdir -p "$d/source"
cp tools/pi4_mg2_sparse.* tools/test_pi4_mg2_sparse.py tools/pi4_migration_{capture,replay}.py tools/pi4_mg2_terminal.py tools/qemu_capture.py "$d/source"
cp docs/boards/pi4-mg2-sparse.en-ko.md "$d/source"
m=/home/ywcho/jnox198-model-Al60nH/qemu-11.1.3
sed -n '294,326p;397,432p' "$m/tcg/tcg-op-ldst.c" > "$d/source/tcg-store-excerpts.txt"
sed -n '1498,1562p' "$m/hw/intc/arm_gic.c" > "$d/source/gic-store-excerpt.txt"
git -C /mnt/d/codex/j-nox show 75845a7f211e86bb4215eed396c169c725479e9a:docs/evidence/pi4-mg2-plugin-model-build.json | cmp - ../pair/model-attestation
git -C /mnt/d/codex/j-nox show acc45c95:docs/boards/pi4-mg2-sparse.en-ko.md > "$d/source/plan.en-ko.md"