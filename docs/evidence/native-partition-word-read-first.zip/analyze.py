import csv,hashlib,json,statistics as s,sys
from pathlib import Path as P
from collections import defaultdict
sys.path.insert(0,'parent/tools')
from native_partition_phase import compare
from native_partition_replay import ROW,Snapshot,symbol,elf_file
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def export(n,rows):
 with open('analysis/'+n+'.csv','w') as f:
  w=csv.DictWriter(f,fieldnames=rows[0]); w.writeheader(); w.writerows(rows)
def dist(vals): return '/'.join(str(i) for i in (min(vals),s.median(vals),max(vals)))
wins=[]; stages=[]; results=[]; cells=[]
for a in ('p','q'):
 for c in ('default','icount3'):
  for v in ('parent','candidate'):
   for r in range(1,6):
    folders=[P(f'evidence/{r}-{v}-partition-{a}-{c}-{m}') for m in ('plain','phase')]
    paired=compare(folders[0],sha(folders[0]/'session.json'),folders[1],sha(folders[1]/'session.json'))
    for t in paired['transitions']:
     raw=t['raw']; stages.append(dict(a=a,c=c,v=v,r=r,gen=t['new_generation'],same=t['old_pid']==t['new_pid'],ticks=raw['audit_begin']-raw['result_begin'],**raw))
    for m,d in zip(('plain','phase'),folders):
     j=json.loads(P(str(d)+'.json').read_text()); launch=json.loads((d/'launch.json').read_text())
     kernel=elf_file((d/'kernel.elf').read_bytes()); addr,sz=symbol(kernel,'native_vruntime_journal'); mem=Snapshot(launch['ram_base'],(d/'ram.bin').read_bytes()); head,*rows=ROW.iter_unpack(mem.read(addr,sz))
     for row in rows[:head[6]]:
      if row[0]==23: results.append(dict(a=a,c=c,v=v,m=m,r=r,entry=row[1],pid=row[2],gen=row[3],identity=row[4],seen=row[5],first=row[6],chunks=row[7],checksum=row[8],status=row[9]))
     for w in j['windows']: wins.append(dict(a=a,c=c,v=v,m=m,r=r,**w))
   for m in ('plain','phase'):
    ws=[w for w in wins if (w['a'],w['c'],w['v'],w['m'])==(a,c,v,m)]
    st=[t for t in stages if (t['a'],t['c'],t['v'])==(a,c,v)]
    miss=[(w['r'],w['generation'],w['latency']) for w in ws if w['latency']>62500]
    cells.append(dict(table=a,clock=c,build=v,image=m,missed=len(set(x[0] for x in miss)),miss_details=str(miss),initial=dist([w['latency'] for w in ws if w['generation']==1]),first=dist([w['latency'] for w in ws if w['generation']==2]),later=dist([w['latency'] for w in ws if w['generation']>2]),first_stage=dist([t['ticks'] for t in st if t['gen']==2]) if m=='phase' else '-',later_stage=dist([t['ticks'] for t in st if t['gen']>2]) if m=='phase' else '-',same_stage=dist([t['ticks'] for t in st if t['same']]) if m=='phase' else '-',cross_stage=dist([t['ticks'] for t in st if not t['same']]) if m=='phase' else '-'))
export('windows',wins); export('result-rows',results); export('stages',stages); export('cells',cells)
print(len(wins),len(results),len(stages))
