set -eu
cd ~/jnox231-first; R=$PWD
export CARGO_BUILD_JOBS=1 PYTHONPATH=$HOME/jnox-169-first-e203caa/deps PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH
mkdir -p controls historical
unzip -qo parent/docs/evidence/native-partition-ordinary-first.zip -d historical
for d in historical/*/session.json; do s=${d%/*}; n=${s##*/}; case "$n" in partition*) rep=native_partition_replay;; weighted*) rep=native_weighted_replay;; startup*) rep=native_el0_replay;; *) continue;; esac; rc=0; python3 candidate/tools/$rep.py "$s" "$(sha256sum "$d" | cut -d' ' -f1)" >"controls/old-$n.json" 2>"controls/old-$n.err" || rc=$?; echo "$rc" >"controls/old-$n.rc"; done
cd candidate
for arm in weighted-share weighted-wake startup-probe; do b="$R/build-candidate-$arm"; python3 tools/build_native_el0.py --app "$arm" --out "$b"; case "$arm" in weighted*) clocks="default icount3"; src=native_weighted_monitor; t=native_weighted_capture; rep=native_weighted_replay;; *) clocks=default; src=native_startup_probe; t=native_el0_capture; rep=native_el0_replay;; esac; for c in $clocks; do d="$R/controls/new-$arm-$c"; args=""; test "$arm" = startup-probe || args="${arm#weighted-} $c"; rc=0; python3 tools/$t.py $args "$d" "$b/kernel.elf" "$b/user.elf" "examples/portability/$src.c" "$(git rev-parse HEAD)" >"$d.log" 2>&1 || rc=$?; echo "$rc" >"$d.capture"; rc=0; python3 "$R/parent/tools/$rep.py" "$d" "$(sha256sum "$d/session.json" | cut -d' ' -f1)" >"$d.json" 2>"$d.err" || rc=$?; echo "$rc" >"$d.rc"; done; done
