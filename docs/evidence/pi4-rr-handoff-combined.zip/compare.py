from pathlib import Path
import json,struct,hashlib
d=Path(__file__).parent
def decode(blob,phs,off):
 for fieldoff in [16,17,18,19]:
  j=off-fieldoff
  if j<0:continue
  p,n,line,col=struct.unpack_from('<QQII',blob,j)
  if n<1 or n>256 or col>5000:continue
  for q in phs:
   if q[3]<=p and p+n<=q[3]+q[5]:
    start=q[2]+p-q[3];raw=blob[start:start+n]
    try:name=raw.decode()
    except UnicodeError:continue
    if name.endswith('.rs'):return [name,line,col,fieldoff]
 return None
r={}
for f in sorted((d/'images/combined').glob('*/identity.json')):
 name=f.parent.name;ref='pi' if name in ['rr','rr-eng','fixed-fifo-v1','fixed-rr-v1'] else 'main'
 a=d/'images'/ref/name/'identity.json';x=json.loads(a.read_text());y=json.loads(f.read_text());v=dict(reference=x,candidate=y,whole_elf=x['elf']==y['elf'],load_segments=x['loads']==y['loads'],text=x['sections']['.text']==y['sections']['.text'],entry=x['entry']==y['entry'],differences=[])
 if not v['load_segments']:
  left=(a.parent/'kernel.elf').read_bytes();right=(f.parent/'kernel.elf').read_bytes()
  for l,q in zip(x['loads'],y['loads']):
   if l[:-1]!=q[:-1]:v['different_segment_header']=True
   for i,(ba,bb) in enumerate(zip(left[l[2]:l[2]+l[5]],right[q[2]:q[2]+q[5]])):
    if ba!=bb:
     old=decode(left,x['loads'],l[2]+i);new=decode(right,y['loads'],q[2]+i);v['differences'].append([hex(l[3]+i),ba,bb,old,new])
  v['line_metadata_only']=bool(v['differences']) and v['entry'] and v['text'] and not v.get('different_segment_header') and all(z and w and z[0]==w[0] and z[2:]==w[2:] for _,_,_,z,w in v['differences'])
 r[name]=v;print(name,ref,v['whole_elf'],v['load_segments'],len(v['differences']),v.get('line_metadata_only'))
(d/'comparisons.json').write_text(json.dumps(r,indent=2))
