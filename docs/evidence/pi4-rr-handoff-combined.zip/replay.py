from pathlib import Path
import json,hashlib,zipfile,subprocess as s,sys,tempfile
d=Path(__file__).parent;repo=Path(str(d)+'-evidence');sys.path.insert(0,str(repo/'tools'))
from fixed_runtime_observer import validate
h=lambda b:hashlib.sha256(b).hexdigest()
result={}
with zipfile.ZipFile(repo/'docs/evidence/pi4-rr-handoff-integration.zip') as z:
 for label,case in [('O1','rr'),('E1','rr-eng'),('E2','rr-eng'),('O2','rr')]:
  base=d/'images/combined'/case;elf=base/'kernel.elf';img=base/'kernel8.img'
  if not img.exists():s.run(['aarch64-linux-gnu-objcopy','-O','binary',str(elf),str(img)],check=True)
  old='valid/'+('rr-normal' if case=='rr' else case)
  assert img.read_bytes()==z.read(old+'/kernel8.img')
  m=json.loads(z.read(old+'/manifest.json'));m['elf_sha256']=h(elf.read_bytes());m['image_sha256']=h(img.read_bytes());m['commit']='42a1ffe678a015913fda9c8656a30e204927dafd'
  raw=z.read('captures/'+label+'/uart.bin')
  if case=='rr':r=dict(valid=validate(raw,b'FIXED RR',b'PI4'));assert r['valid'];rc=0
  else:
   with tempfile.TemporaryDirectory() as tmp:
    p=Path(tmp);(p/'uart').write_bytes(raw);(p/'manifest.json').write_text(json.dumps(m))
    o=s.run([sys.executable,str(repo/'tools/pi4_fixed_witness.py'),str(p/'uart'),'--profile',m['profile'],'--manifest',str(p/'manifest.json'),'--elf',str(elf),'--image',str(img)],capture_output=True)
    rc=o.returncode;r=json.loads(o.stdout)
  result[label]=dict(rc=rc,uart_sha256=h(raw),image_sha256=h(img.read_bytes()),archived_full_elf_sha256=h(z.read(old+'/kernel.elf')),combined_full_elf_sha256=h(elf.read_bytes()),observed=r)
  print(label,rc,r.get('handoff_status'))
(d/'blind.json').write_text(json.dumps(result,indent=2))
