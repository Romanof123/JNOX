from pathlib import Path
import subprocess as s,os,json,struct,hashlib,shutil
d=Path(__file__).parent;k=d/'build-src';out=d/'images'
opt={'pi4-default':('pi4',None,None,{},[])}
for a in ['fixed-fifo','fixed-rr','fixed-empty','fixed-delayed','fixed-ties','fixed-late','coop-events','coop-single']:
 if a not in ['fixed-fifo','fixed-rr']:opt[a]=('virt','fixed',a,{},[])
 if not a.startswith('coop'):opt[a+'-trace']=('virt','fixed',a,{'JNOX_FIXED_TRACE':'1'},[])
 if a in ['fixed-fifo','fixed-rr']:opt[a+'-cost']=('virt','fixed',a,{'JNOX_FIXED_COST':'1'},[])
for rev,commit in [('main','29b7f79c4c50e8c92a7abde4e74bc4fc9476d4c9'),('combined','42a1ffe678a015913fda9c8656a30e204927dafd')]:
 s.run(['git','checkout','-q','--detach',commit],cwd=k,check=True)
 for name,(board,prof,app,extras,flags) in opt.items():
  if (rev=='pi' and name not in ['rr','rr-eng','fixed-fifo-v1','fixed-rr-v1']) or (rev=='main' and name in ['rr','rr-eng']):continue
  p=out/rev/name;p.mkdir(parents=True)
  target=d/'target';assert not target.exists()
  env={a:b for a,b in os.environ.items() if not a.startswith(('JNOX_','CARGO_','RUSTFLAGS'))}; env.update(CARGO_TARGET_DIR=str(target),JNOX_BOARD=board,**extras)
  if prof:env['JNOX_PROFILE']=prof
  if app:env['JNOX_APP']=app
  cmd=['cargo','+1.95.0','build','--locked','--release','-j1',*flags]
  with (p/'build.log').open('xb') as log:rc=s.run(cmd,cwd=k/'kernel',env=env,stdout=log,stderr=s.STDOUT).returncode
  if rc:raise SystemExit(f'{rev} {name} {rc}')
  f=p/'kernel.elf';shutil.copy2(target/'aarch64-unknown-none/release/jnox-kernel',f);target.rename(p/'target')
  b=f.read_bytes();h=lambda x:hashlib.sha256(x).hexdigest();entry,ph,sh=struct.unpack_from('<3Q',b,24);ps,pn,ss,sn,si=struct.unpack_from('<5H',b,54);loads=[]
  for i in range(pn):
   v=struct.unpack_from('<II6Q',b,ph+i*ps)
   if v[0]==1:loads.append([*v,h(b[v[2]:v[2]+v[5]])])
  sec={}
  strtab=struct.unpack_from('<Q',b,sh+si*ss+24)[0]
  for i in range(sn):
   j=sh+i*ss;start=strtab+struct.unpack_from('<I',b,j)[0];n=b[start:b.index(0,start)].decode();off,size=struct.unpack_from('<2Q',b,j+24)
   if n in ['.text','.rodata','.data']:sec[n]=[size,h(b[off:off+size])]
  m=dict(source=commit,selector=name,env={a:b for a,b in env.items() if a.startswith('JNOX_')},cmd=cmd,elf=h(b),entry=entry,loads=loads,sections=sec)
  (p/'identity.json').write_text(json.dumps(m,indent=2))
  print(rev,name,m['elf'][:10],flush=True)
