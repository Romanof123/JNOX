from pathlib import Path
import hashlib,json,sys,tarfile,struct,subprocess as sp,tempfile,shutil,time,os,difflib,re
p=Path(__file__).resolve().parent;b=p.parent;ref=b/'service53-corrected-builds';cold=b/'cold-merged-gates'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def save(f,v):f.write_text(json.dumps(v,indent=2)+'\n')
def get(f):return json.loads(f.read_bytes())
cfg=get(ref/'protocol.json');idx=get(p/'builds.json');tmp=Path(tempfile.mkdtemp(dir='/tmp',prefix='jnox-i53-'))
os.environ.update(TMPDIR=str(tmp),PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0,str(ref));from capture import loads_image,snapshot
sys.path.insert(0,str(b/'markers-integrated-pinned/tools'));from qemu_capture import request
q=Path(cfg['qemu']);assert sha(q)==cfg['qemu_sha256'];save(p/'host.json',dict(tmp=str(tmp),qemu=sha(q),boot_id=Path('/proc/sys/kernel/random/boot_id').read_text(),fs=sp.check_output(['df','-T',tmp],text=True)))
def cmd(d,tag,argv):
 r=sp.run(list(map(str,argv)),capture_output=True);(d/(tag+'.stdout')).write_bytes(r.stdout);(d/(tag+'.stderr')).write_bytes(r.stderr);save(d/(tag+'.json'),dict(argv=list(map(str,argv)),exit=r.returncode));return r
comparisons={};boots={};sealed={}
for tag in [f'descriptor-{pol}-{arm}' for pol in ('rm','dm') for arm in ('baseline','descriptor','cold')]:
 head,pol,arm=tag.split('-');d=tmp/tag;d.mkdir();elf=d/'kernel.elf';shutil.copy2(p/tag/'kernel.elf',elf)
 uart=d/'uart';ext=d/'exceptions';sock=d/'q';argv=[str(q),*cfg['qemu_options'],'-serial','file:'+str(uart)]
 marker=None
 if arm=='marker':
  sym=sp.check_output(['aarch64-linux-gnu-nm','-nS',elf],text=True);m=re.search(r'^([0-9a-f]+) ([0-9a-f]+) \w control_marker_journal$',sym,re.M);marker=tuple(int(x,16) for x in m.groups())
 if arm=='cold':
  inp=d/'cold-mode.bin';inp.write_bytes(b'2');argv+=['-fw_cfg','name=opt/jnox/cold-mode,file='+str(inp)]
 else:argv+=['-d','int','-D',str(ext)]
 argv+=['-qmp','unix:'+str(sock)+',server=on,wait=off','-kernel',str(elf)]
 with (d/'stderr').open('wb') as err,(d/'stdout').open('wb') as out:
  t=time.monotonic();proc=sp.Popen(argv,stderr=err,stdout=out)
  try:
   while time.monotonic()-t<10 and proc.poll()==None and not (uart.exists() and uart.read_bytes().endswith(b'CONTROL END\n')): time.sleep(.001)
   terminal=uart.exists() and uart.read_bytes().endswith(b'CONTROL END\n')
   if terminal:snapshot(sock,d,marker,request)
  finally:
   proc.terminate();proc.wait(5)
 if sock.exists():sock.unlink()
 z=boots[tag]=dict(argv=argv,elf=sha(elf),terminal=terminal,exit=proc.returncode)
 score=cmd(d,'score',[sys.executable,'-B',b/'marker-release-pinned/tools/control_observations.py','healthy',uart]);z['score_exit']=score.returncode
 if arm=='marker':z['marker_exit']=cmd(d,'marker',[sys.executable,'-B',b/(head+'-integrated-pinned/tools/control_service_markers.py'),d/'markers.bin',uart,'--exceptions',ext]).returncode
 if arm=='cold':
  rows=[list(map(int,l.split())) for l in uart.read_text().splitlines() if l and l[0].isdigit()];x,= [r for r in rows if r[0]==48];epoch,=[r for r in rows if r[0]==1];z['cold_fixed_no_probe']=x[3]==2 and epoch[1]==x[1]+x[2]//4 and not any(r[0] in [57,60] for r in rows)
 shutil.copytree(d,p/tag/'guest');save(p/'boots.json',boots)

