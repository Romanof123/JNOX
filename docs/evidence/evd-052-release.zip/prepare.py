from pathlib import Path
import json,copy
p=Path(__file__).resolve().parent;r=p.parent
cfg=json.loads((r/'descriptor-release-protocol/commands.json').read_text(encoding='utf-8-sig'));cases=cfg['cases']
for c in cases:
 k=c['tag']
 if k.startswith('descriptor-') and c['ref']:
  c['prior']='descriptor-release-gates/'+k+'/kernel.elf';c['ref']=c['ref'].replace('/descriptor-','/markers-')
for pol in ['rm','dm']:
 c=copy.deepcopy(next(c for c in cases if c['tag']==f'descriptor-{pol}-baseline'));c['tag']=f'markers-{pol}-marker';c['env']['JNOX_CONTROL_MARKERS']='1';c['ref']=f'control53-integrated-gate/{c["tag"]}/kernel.elf';del c['prior'];cases.append(c)
 if pol=='rm':
  for name,extra,msg in [('marker+cold',{'JNOX_CONTROL_COLD':'diagnostic'},'control marker, descriptor and cold comparison arms must be built separately'),('marker-loss',{'JNOX_CONTROL_CASE':'loss'},'JNOX_CONTROL_MARKERS=1 requires ordinary healthy periodic control-rm or control-dm')]:
   row=copy.deepcopy(c);row.update(tag=name,ref=None,expected=msg);row['env'].update(extra);cases.append(row)
cfg.update(cwd='marker-release-pinned/kernel',source='3d314b0a188b1e93f1b2a6ad9ee35a47c30a7c9b')
(p/'commands.json').write_text(json.dumps(cfg,indent=2));s=(r/'descriptor-release-gates/build.py').read_text();s=s.replace("m=r/'descriptor-release-protocol/commands.json'","m=p/'commands.json'");s='\n'.join(x for x in s.splitlines() if not x.startswith('assert h(m)'));(p/'build.py').write_text(s)
