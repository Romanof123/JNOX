from pathlib import Path
import subprocess as sp,json,hashlib,os,shutil
p=Path(__file__).resolve().parent;r=p.parent
h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
m=p/'commands.json'
cfg=json.loads(m.read_text(encoding='utf-8-sig'));src=r/cfg['cwd']
assert sp.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()==cfg['source'] and not sp.check_output(['git','status','--porcelain'],cwd=src)
exec((r/'partition-parent-builds/batches.py').read_text().split('def batch(')[0])
out={}
for c in cfg['cases']:
 k=c['tag'];d=p/k;d.mkdir();env={k:v for k,v in os.environ.items() if not k.startswith(('JNOX_','CARGO_PROFILE_','CARGO_TARGET_','RUST')) and k!='CARGO_ENCODED_RUSTFLAGS'};env.update(c['env'],CARGO_TARGET_DIR=str(p/'target'),CARGO_BUILD_JOBS='1',TEMP=str(d),TMP=str(d))
 with (d/'build.log').open('wb') as f:rc=sp.run(c['argv'],cwd=src,env=env,stdout=f,stderr=sp.STDOUT).returncode
 z=out[k]=dict(exit=rc,expected=c['expected'],argv=c['argv'],selectors=c['env'],log_sha=h((d/'build.log').read_bytes()))
 if rc==0:
  e=d/'kernel.elf';shutil.copy2(p/'target/aarch64-unknown-none/release/jnox-kernel',e);z['elf']=h(e.read_bytes())
  for field in ['ref','prior']:
   if c.get(field):
    ref=r/c[field];z[field]=compare(e,ref);z[field]['whole_elf_equal']=e.read_bytes()==ref.read_bytes()
 z['ok']=bool(c['expected']=='build' and rc==0 or rc and c['expected']!='build' and c['expected'] in (d/'build.log').read_text(errors='replace'))
 print(k,z['ok'],z.get('ref',{}).get('identical'),flush=True)
 (p/'builds.json').write_text(json.dumps(out,indent=2))