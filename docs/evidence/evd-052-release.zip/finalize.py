from pathlib import Path
import json,hashlib,zipfile,subprocess as sp,sys
p=Path(__file__).resolve().parent;r=p.parent
h=lambda b:hashlib.sha256(b).hexdigest()
out={}
for tag,pin in [('marker-release-pinned','3d314b0a188b1e93f1b2a6ad9ee35a47c30a7c9b')]:
 s=r/tag;assert sp.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()==pin and not sp.check_output(['git','status','--porcelain'],cwd=s)
 a=[sys.executable,'-B',str(s/'tools/scheduling_evidence.py'),'--root',str(s)];v=sp.run(a,capture_output=True);(p/(tag+'.audit.json')).write_bytes(v.stdout);(p/(tag+'.stderr')).write_bytes(v.stderr);j=json.loads(v.stdout);out[tag]=dict(commit=pin,argv=a,exit=v.returncode,policies=len(j['policies']),findings=j['findings'],audit_sha=h(v.stdout))
s=r/'marker-release-pinned/docs/evidence';j=json.loads((s/'evd-052.json').read_bytes());f=s/'evd-052-marker-replay.zip'
with zipfile.ZipFile(f) as z:
 rows=[a.split('  ',1) for a in z.read('FILES.sha256').decode().splitlines()]
 checks={k:h(z.read(k))==v for v,k in rows};names=set(checks)|{'FILES.sha256'}
 out['evd052']=dict(sha=h(f.read_bytes()),size=f.stat().st_size,entries=len(z.namelist()),hashed_entries=len(rows),all_match=all(checks.values()) and names==set(z.namelist()),declared_entries=j['archive']['entries'],archive_hash_match=h(f.read_bytes())==j['archive']['sha256'],report_hash_match=h(z.read('report.json'))==j['report_sha256'],manifest_hash_match=h(z.read('manifest.json'))==j['manifest_sha256'],historical=j['original_audit'],historical_hash_match=h((r/'control53-integrated-gate/markers-integrated-pinned.audit.json').read_bytes())==j['original_audit']['sha256'])
b=json.loads((p/'builds.json').read_bytes());out['builds']=dict(images=sum(v['exit']==0 for v in b.values()),expected_rejections=sum(v['exit']!=0 and v['ok'] for v in b.values()),all_expected=all(v['ok'] for v in b.values()),comparisons=sum(k in v for v in b.values() for k in ['ref','prior']),all_elf_load_text_match=all(v[k]['whole_elf_equal'] and v[k]['identical'] and v[k]['text_identical'] for v in b.values() for k in ['ref','prior'] if k in v),index_sha=h((p/'builds.json').read_bytes()),new_guest_launches=0)
(p/'summary.json').write_text(json.dumps(out,indent=2));print(json.dumps(out));print(h((p/'summary.json').read_bytes()))

