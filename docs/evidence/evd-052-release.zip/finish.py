from pathlib import Path
import json,hashlib,struct
p=Path(__file__).resolve().parent
def read(f):return json.loads(f.read_bytes())
b=read(p/'builds.json');s=read(p/'summary.json');boots=read(p/'boots.json');deltas={}
for k,v in b.items():
 if 'prior' not in v or v['prior']['identical']:continue
 data=(p/k/'kernel.elf').read_bytes();ph=struct.unpack_from('<Q',data,32)[0];segs=[struct.unpack_from('<II6Q',data,ph+i*56) for i in range(struct.unpack_from('<H',data,56)[0])];segs=[x for x in segs if x[0]==1];rows=[]
 for seg,z in zip(segs,v['prior']['segments']):
  for off,a,c in z['differences'] or []:
   pos=seg[2]+off;ptr,length,line,col=struct.unpack_from('<QQII',data,pos-16);mapped=next(t for t in segs if t[3]<=ptr< t[3]+t[5]);f=mapped[2]+ptr-mapped[3];rows.append(dict(file=data[f:f+length].decode(),old_line=line-c+a,new_line=line,column=col))
 deltas[k]=rows
s['source_location_changes']=deltas;s['builds'].update(new_guest_launches=len(boots),identical_immediate_references=13,cross_branch_changed_loads=6);s['observations']={k:dict(terminal=v['terminal'],score=read(p/k/'guest/score.stdout')['failures'],cold_fixed_no_probe=v.get('cold_fixed_no_probe')) for k,v in boots.items()};s['boots_index_sha']=hashlib.sha256((p/'boots.json').read_bytes()).hexdigest();(p/'summary.json').write_text(json.dumps(s,indent=2));print(hashlib.sha256((p/'summary.json').read_bytes()).hexdigest(),next(iter(deltas.values()))[:2])
