"""Inspect frozen receipts and today's WSL execution context, without starting QEMU."""
import argparse
import datetime
import hashlib
import json
import os
import platform
import resource
import subprocess
import time
from pathlib import Path

MANIFEST="fe0fa8c67e58b5ec93bb2f7c4c8607209825662765dcd4dbdc305b1bab275ce7"
QEMU="0a63468782d096485932acf6aa0a69d358b3e3a6f68f655e960e9f5e3fc578d8"
PREFIX=["/usr/bin/qemu-system-aarch64","-machine","virt,gic-version=2","-cpu","cortex-a72",
        "-smp","1","-accel","tcg","-m","128M","-nodefaults","-display","none","-monitor",
        "none","-no-reboot","-qmp","stdio"]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def required(ok,why):
    if not ok:
        raise ValueError(why)


def output(*args):
    return subprocess.run(args,check=True,capture_output=True,text=True).stdout.strip()


def archived(base):
    manifest=(base/"SHA256SUMS").read_bytes()
    required(sha(manifest)==MANIFEST,"source manifest SHA-256")
    sums={p.removeprefix("./"):h for h,p in (l.split("  ",1) for l in manifest.decode().splitlines())}
    def get(p):
        data=(base/p).read_bytes()
        required(sha(data)==sums[p],p)
        return data
    paths=sorted(k for k in sums if k.startswith("runs/") and k.endswith("/cap/launch.json"))
    versions=set()
    freq=[]
    for path in paths:
        parent=path.rsplit("/",1)[0]+"/"
        launch=get(path)
        session=json.loads(get(parent+"session.json"))
        required(sha(launch)==session["hashes"]["launch.json"],path)
        record=json.loads(launch)
        argv=record["argv"]
        required(argv[:-4]==PREFIX and argv[-4]=="-serial" and argv[-3].startswith("file:")
                 and argv[-2]=="-kernel" and record["qemu_sha256"]==QEMU,path)
        versions.add(str(record["qemu_version"]))
        if "-fused-" in path:
            data=get(parent+"uart.bin")
            required(sha(data)==session["hashes"]["uart.bin"],"UART")
            rows=[line.split() for line in data.splitlines() if line.startswith(b"NATIVE QUAL COUNTS ")]
            required(len(rows)==1 and rows[0][3]==b"62500000" and rows[0][-1]==b"0","guest frequency")
            freq.append(int(rows[0][3]))
    required(len(paths)==56 and len(freq)==48 and len(versions)==1,"campaign inventory")
    host=get("logs/host.txt").decode().splitlines()
    # uname -a includes the local node name between the OS name and kernel release.
    os_name, _node, release_and_version = host[1].split(maxsplit=2)
    required(os_name=="Linux" and release_and_version.split()[0].endswith("WSL2"),"archived kernel identity")
    return dict(manifest_sha256=MANIFEST,launches=len(paths),fused_frequency_receipts=len(freq),
                nominal_frequency_hz=sorted(set(freq)),common_argv=PREFIX+["-serial","file:<run>/cap/uart.bin","-kernel","<run>/cap/kernel.elf"],
                qemu_sha256=QEMU,qemu_version=sorted(versions),host_log_utc=host[0],
                host_kernel=f"{os_name} {release_and_version}",host_log_sha256=sums["logs/host.txt"])


def current():
    keys=["/proc/self/cgroup","/sys/fs/cgroup/cpu.max","/sys/fs/cgroup/cpu.weight",
          "/sys/fs/cgroup/non-systemd/cpu.max","/sys/fs/cgroup/non-systemd/cpu.weight",
          "/sys/devices/system/cpu/isolated","/sys/devices/system/clocksource/clocksource0/current_clocksource",
          "/sys/devices/system/clocksource/clocksource0/available_clocksource",
          "/proc/sys/kernel/sched_rt_runtime_us","/proc/sys/kernel/sched_rt_period_us"]
    live={key:(Path(key).read_text().strip() if Path(key).is_file() else None) for key in keys}
    pkg=output("dpkg-query","-W","-f=${Version}","qemu-system-arm")
    cpu=output("lscpu").splitlines()
    return dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),kernel=platform.release(),
                qemu_installed_sha256=sha(Path(PREFIX[0]).read_bytes()),package_version=pkg,
                qemu_file_capabilities=output("getcap",PREFIX[0]),probe_policy=os.sched_getscheduler(0),
                probe_priority=os.sched_getparam(0).sched_priority,probe_nice=os.getpriority(os.PRIO_PROCESS,0),
                probe_cpus=sorted(os.sched_getaffinity(0)),probe_rlimit_rtprio=resource.getrlimit(resource.RLIMIT_RTPRIO),
                probe_cap_eff=next(l.split()[1] for l in Path("/proc/self/status").read_text().splitlines() if l.startswith("CapEff:")),
                probe_clock_gettime_monotonic_success=time.clock_gettime_ns(time.CLOCK_MONOTONIC)>0,
                probe_clock_resolution=time.clock_getres(time.CLOCK_MONOTONIC),fs=live,
                virtualization=[l for l in cpu if l.startswith(("Hypervisor vendor:","Virtualization type:"))])


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("source",type=Path,help="extracted four-arm source packet")
    args=p.parse_args()
    print(json.dumps(dict(archived=archived(args.source),live_linux=current()),indent=2))
