# Read the outer Windows/WSL context without changing VM or scheduling settings.
$os = Get-CimInstance Win32_OperatingSystem
$machine = Get-CimInstance Win32_ComputerSystem
$wslVm = @(hcsdiag list -raw | ConvertFrom-Json | Where-Object Owner -eq 'WSL')
$vmm = Get-Process -Name vmmemWSL -ErrorAction SilentlyContinue | Select-Object -First 1
$mgmt = try {
    Get-CimClass -Namespace root/virtualization/v2 -ClassName Msvm_ProcessorSettingData -OperationTimeoutSec 5 -ErrorAction Stop | Out-Null
    'available'
} catch {
    $_.Exception.Message
}
[ordered]@{
    utc = (Get-Date).ToUniversalTime().ToString('o')
    windows = $os.Caption
    build = $os.BuildNumber
    revision = Get-ItemPropertyValue 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' UBR
    hypervisor_present = $machine.HypervisorPresent
    logical_processors = $machine.NumberOfLogicalProcessors
    wsl_vm = @($wslVm | Select-Object Owner,SystemType,State)
    vmmem_process_priority = if ($vmm) { $vmm.PriorityClass.ToString() }
    vmmem_process_affinity_mask = if ($vmm) { $vmm.ProcessorAffinity.ToInt64() }
    hyperv_management_namespace = $mgmt
    user_wslconfig_present = Test-Path -LiteralPath (Join-Path $env:USERPROFILE '.wslconfig')
} | ConvertTo-Json -Depth 4
