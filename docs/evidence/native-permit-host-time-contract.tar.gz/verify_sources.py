"""Check Ubuntu source-to-upstream identity and the distributed QEMU executable. No build or boot."""
import argparse
import hashlib
import json
import re
import subprocess
import tarfile
import tempfile
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

REV = "44f28df24767cf9dca1ddc9b23157737c4cbb645"
UBUNTU = "https://security.ubuntu.com/ubuntu/pool/main/q/qemu/"
UPSTREAM = f"https://raw.githubusercontent.com/qemu/qemu/{REV}/"
DSC = "qemu_6.2+dfsg-2ubuntu6.31.dsc"
ORIG = "qemu_6.2+dfsg.orig.tar.xz"
DEBIAN = "qemu_6.2+dfsg-2ubuntu6.31.debian.tar.xz"
BINARY = "qemu-system-arm_6.2+dfsg-2ubuntu6.31_amd64.deb"
EXECUTABLE = "0a63468782d096485932acf6aa0a69d358b3e3a6f68f655e960e9f5e3fc578d8"
INPUTS = {DSC:"d13c0322809860a49ad377dd825ad597ece93f0b7f40e713a165dba59bb369ca",
          ORIG:"470d4202ab6302f184bf934008d2306c144d3221aa3b8ceb8a710414755af61b",
          DEBIAN:"97dd9f9b065452e02b00f87e70e94d9f6369716de7d739ae605240d2522183a2",
          BINARY:"f6a5fed88a976b4966f9ca847288ee0ffe798c769690c3c703ab4f54f2eeaa64"}
FILES = ["target/arm/helper.c","target/arm/cpu.c","target/arm/internals.h","hw/arm/virt.c",
         "util/qemu-timer.c","util/qemu-timer-common.c","include/qemu/timer.h","softmmu/cpu-timers.c",
         "softmmu/cpus.c","softmmu/icount.c","accel/tcg/tcg-accel-ops.c","softmmu/vl.c","qemu-options.hx"]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(ok, name):
    if not ok:
        raise ValueError(name)


def fetch(pair):
    url,dest=pair
    if not dest.is_file():
        dest.parent.mkdir(parents=True,exist_ok=True)
        with urllib.request.urlopen(url,timeout=40) as response:
            dest.write_bytes(response.read())


def verify(cache):
    cache.mkdir(parents=True,exist_ok=True)
    jobs=[(UBUNTU+name,cache/name) for name in INPUTS]
    jobs += [(UPSTREAM+f,cache/"upstream"/f) for f in FILES]
    with ThreadPoolExecutor(6) as pool:
        list(pool.map(fetch,jobs))
    for name,digest in INPUTS.items():
        require(sha((cache/name).read_bytes())==digest,name)
    dsc=(cache/DSC).read_text()
    for name in (ORIG,DEBIAN):
        require(f"{INPUTS[name]} {(cache/name).stat().st_size} {name}" in dsc, "DSC digest")
    same={}
    with tarfile.open(cache/ORIG,"r:xz") as tar:
        for name in FILES:
            orig=tar.extractfile("qemu-6.2+dfsg/"+name).read()
            require(orig==(cache/"upstream"/name).read_bytes(),"upstream mismatch: "+name)
            same[name]=sha(orig)
    with tarfile.open(cache/DEBIAN,"r:xz") as tar:
        series=tar.extractfile("debian/patches/series").read().decode().splitlines()
        patches=[l.split("#")[0].strip().split()[0] for l in series if l.split("#")[0].strip()]
        for patch in patches:
            body=tar.extractfile("debian/patches/"+patch).read().decode(errors="replace")
            headers=re.findall(r"^(?:---|\+\+\+|rename from|rename to)\s+(\S+)",body,re.M)
            for name in FILES:
                require(not any(h==name or h.endswith("/"+name) for h in headers),
                        f"Ubuntu patch touches {name}: {patch}")
    proc=subprocess.Popen(["dpkg-deb","--fsys-tarfile",str(cache/BINARY)],stdout=subprocess.PIPE)
    binary_hash=None
    with tarfile.open(fileobj=proc.stdout,mode="r|") as tar:
        for m in tar:
            if m.name.removeprefix("./")=="usr/bin/qemu-system-aarch64":
                binary_hash=sha(tar.extractfile(m).read())
    proc.stdout.close()
    require(proc.wait()==0 and binary_hash==EXECUTABLE,"binary from Ubuntu .deb")
    return dict(ubuntu_pool=UBUNTU,package_version="1:6.2+dfsg-2ubuntu6.31",upstream_commit=REV,
                package_hashes=INPUTS,quilt_entries_checked=len(patches),
                identical_unpatched_file_sha256=same,distributed_executable_sha256=binary_hash)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--cache",type=Path,help="optional persistent download cache")
    args=p.parse_args()
    with tempfile.TemporaryDirectory() as tmp:
        print(json.dumps(verify(args.cache or Path(tmp)),indent=2))
