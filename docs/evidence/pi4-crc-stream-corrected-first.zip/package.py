import hashlib,json,sys,zlib,zipfile
from pathlib import Path
e=Path.home()/"jnox225-b14-first/evidence"
out=Path("/mnt/d/codex/jnox225-b14-first")
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
r=["# Pi 4 finite CRC stream · 최초 6회 독립 검증","","**6/6 qualified on stock Pi 4 QEMU. 최초 여섯 건 모두 모델 기준 통과.**","","Source / 소스 · b14b044f1e548f13ddf48bd5bfa5f91001cabcca. Plan / 계획 · 3a76d3e83ac5576a89ed0770cb3747e59cc26cc1. Clean checkout, one build or guest at a time. All three images and byte-loop disassemblies frozen before global 1. 별도 클린 빌드에서 세 이미지를 실행 전에 고정하고 정해진 순서대로 한 번씩 실행했다.","","Stock SHA-256 · 3ae2c079d4491362fece2abb641f0ff17d88e9008c9fcd13600f249b9bd1c862. Ordinary model only, no faults or hardware. 일반 모델 실행이며 결함 주입·실기 검증은 수행하지 않았다.","","### Build selectors / 빌드 선택","","Three CRC and three legacy sum applications built and froze. Wrong board, wrong application, extra benchmark and partial virt cooperative combination each failed in Cargo build.rs (101). Selector-free virt --all-features built cooperative (0). 세 스트림 앱과 기존 합산 앱 세 건 모두 빌드·고정. 잘못된 선택 네 건은 거부됐으며 virt 전체 기능 빌드는 협력형으로 성공했다.","","### First positions / 최초 실행","","PC is the matched external IRQ/ERET address. SP and X21 remained identical at resumed dispatch. Each before/after byte count is a retained checkpoint wholly owned by its lease. 표의 전후 진행 지점은 각각 단일 리스 소유이며, IRQ와 ERET의 PC, 복귀 SP·X21 및 독립 접두 CRC를 확인했다.","","|Case / 배치|#|IRQ/ERET PC|SP|X21|CPU; lease / 리스|Bytes before → after (prefix CRC)|","|---|---:|---|---|---|---|---|"]
prefix={}; crc=h=0
for n in range(4096):
 end=(n+1)*1024
 crc=zlib.crc32(bytes((i^(i>>8)^(i>>16))&255 for i in range(end-1024,end)),crc);prefix[end]=crc
 h=((((h<<7)|(h>>57))&((1<<64)-1))^end)+crc; h%=1<<64
assert (h,crc)==(8765611335505774534,0x78d22ad1)
last=0
for c in ('global','partitioned','clustered'):
 d=e/('stream-'+c)
 for n in (1,2):
  root=d/'frozen'/f'first-{n}'; s=read(root/'session.json'); a=read(d/f'replay-{n}.json')
  assert s['wall_start_ns']>=last and s['reason']=='terminal_quiet' and a['qualifying_inner_pc']; last=s['wall_end_ns']
  rows=[list(map(int,l.split()[2:])) for l in (root/'uart.bin').read_text().splitlines() if l.startswith('MG ROW')]
  irq=next(x[3:] for x in rows if x[0]==0 and x[2]==4 and x[4]==0 and x[9]!=65535)
  pc,sp,x21=irq[3:6]; dest=a['destination_cpu']
  points=[(x[0],*x[3:]) for x in rows if x[2]==5 and x[3]==0]
  for cpu,t,b,af,i,v,local,_,_ in points: assert prefix[i]==v and local==x21
  owned=[p for p in points if p[2]==p[3]]; before=max((p for p in owned if p[2]==1),key=lambda x:x[4]);after=min((p for p in owned if p[2]!=1),key=lambda x:x[4])
  assert before[0]==0 and after[0]==dest and after[4]>before[4] and pc==a['migration_pc'] and x21==a['saved_x21']
  r.append(f"|{c}|{n}|{pc:#x}|{sp:#x}|{x21:#x}|0→{dest}; {before[2]}→{after[2]}|{before[4]} ({before[5]:08x}) → {after[4]} ({after[5]:08x})|")
r.extend(["","Loop ranges (exclusive end) / 링크 루프 [시작, 끝) · global [0x8220c,0x8224c), partitioned [0x82210,0x82250), clustered [0x822bc,0x822fc). X21 anchors byte count at +0 and CRC at +8. X21이 가리키는 로컬 상태의 바이트 수와 CRC를 실제 루프가 읽고 갱신했다.","","All six completed 4,096 blocks and 4,194,304 bytes, CRC 0x78d22ad1, ordered digest 8765611335505774534. Independent zlib regenerated every expected prefix. UART carries sparse owned checkpoints and an ordered summary of all blocks. Terminal peer products 528, 136 and 392 also matched. 여섯 건 모두 최종 CRC와 4096개 체크포인트 순서 다이제스트, 피어 결과가 일치했다. UART 개별 행은 일부 블록을 보존한다.","","Original c2ef996 build failures precede these positions. The earlier six sum-model positions remain 0/6 for the inner-loop criterion. 기존 빌드 실패와 합산 앱의 0/6 판정은 별도 기록이다."])
report='\n'.join(r)+'\n'; (e/'report.en-ko.md').write_text(report);(out/'report.en-ko.md').write_text(report)
files=sorted(p for p in e.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
(e/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.relative_to(e).as_posix()+'\n' for p in files))
with zipfile.ZipFile(out/'raw.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files+[e/'SHA256SUMS']:z.write(p,p.relative_to(e))
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for p in files:assert hashlib.sha256(z.read(p.relative_to(e).as_posix())).hexdigest()==sha(p)
print(sha(out/'raw.zip'))