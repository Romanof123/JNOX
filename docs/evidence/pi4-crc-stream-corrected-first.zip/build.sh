set -eu
base=$HOME/jnox225-b14-first
ev=$base/evidence
cd "$base/src"
test "$(git rev-parse HEAD)" = b14b044f1e548f13ddf48bd5bfa5f91001cabcca
git status --porcelain > "$ev/source-status.txt"; test ! -s "$ev/source-status.txt"
git rev-parse HEAD > "$ev/source.txt"
git diff 3a76d3e HEAD > "$ev/correction.diff"
git diff cc864a3 HEAD -- kernel tools > "$ev/implementation.diff"
git show 3a76d3e:docs/boards/pi4-stream-v1.en-ko.md > "$ev/plan.md"
export PATH="$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH" CARGO_BUILD_JOBS=1 PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_TARGET_DIR="$base/build" PYTHONDONTWRITEBYTECODE=1
q=/mnt/d/codex/arm-speed-lab/build/system/qemu-system-aarch64
sha256sum "$q" > "$ev/qemu.sha256"; rustc -Vv > "$ev/toolchain"
python3 -m unittest discover -s tools -p test_pi4_stream_v1.py > "$ev/oracle-test.log" 2>&1
cd kernel
export JNOX_BOARD=pi4 JNOX_PROFILE=smp
elf=$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel
for workload in stream legacy; do
 for c in global partitioned clustered; do
  d="$ev/$workload-$c"; mkdir "$d"; export JNOX_APP=migration-$c
  feat=(); w=sum-65536; if [ "$workload" = stream ]; then feat=(--features pi4-stream-v1); w=sample-crc32-v1; fi
  if cargo rustc --locked --release -j1 "${feat[@]}" > "$d/build.log" 2>&1; then echo 0 > "$d/build.rc"; else echo $? > "$d/build.rc"; continue; fi
  aarch64-linux-gnu-objcopy -O binary "$elf" "$base/img"
  aarch64-linux-gnu-objdump -dC "$elf" > "$base/dis"
  if python3 ../tools/pi4_migration_capture.py freeze "$JNOX_APP" "$d/frozen" "$elf" "$base/img" "$base/dis" "$q" --source "$(git rev-parse HEAD)" --workload "$w" > "$d/freeze.sha" 2> "$d/freeze.err"; then echo 0 > "$d/freeze.rc"; else echo $? > "$d/freeze.rc"; fi
 done
done
for test in board app extra partial all; do
 d="$ev/selector-$test"; mkdir "$d"; export JNOX_BOARD=pi4 JNOX_APP=migration-global JNOX_PROFILE=smp; f=(--features pi4-stream-v1)
 case $test in board) export JNOX_BOARD=virt;; app) export JNOX_APP=mg2-global;; extra) f=(--features pi4-stream-v1,sched-bench);; partial) unset JNOX_BOARD JNOX_APP JNOX_PROFILE; f=(--features pi4-stream-v1,coop-bench);; all) unset JNOX_BOARD JNOX_APP JNOX_PROFILE; f=(--all-features);; esac
 if cargo rustc -vv --locked --release -j1 "${f[@]}" > "$d/build.log" 2>&1; then echo 0 > "$d/build.rc"; cp "$elf" "$d/kernel.elf"; else echo $? > "$d/build.rc"; fi
done