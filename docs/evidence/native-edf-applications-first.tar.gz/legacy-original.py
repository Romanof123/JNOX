import tarfile,base64,json,io,pathlib,hashlib
chunks=[]
for p in sorted(pathlib.Path('docs/evidence').glob('evd-048-raw*')):
 d=json.loads(p.read_text());b=base64.b64decode(d['base64']);assert hashlib.sha256(b).hexdigest()==d['sha256']
 chunks.append(b)
if chunks:
 b=b''.join(chunks)
 try:
  t=tarfile.open(fileobj=io.BytesIO(b));print(p,t.getnames()[:22])
  for m in t:
   if m.isfile() and pathlib.Path(m.name).name in ['collect.py','verify.py','cross.py','controls.rs']:
    (pathlib.Path(__file__).parent/pathlib.Path(m.name).name).write_bytes(t.extractfile(m).read())
 except Exception as e:print(e)

