from pathlib import Path
import struct,json,re
root=Path(__file__).resolve().parent
def pick(q,owner,key):
 c=([owner] if owner!=3 else [])+q
 return min(c,key=key) if c else 3
assert pick([2,0],3,lambda i:1)==2 and pick([1],0,lambda i:1)==0
def replay(d):
 ll='llf' in d.name;over='overload' in d.name;overrun='overrun' in d.name
 u=(d/'uart').read_text().splitlines();assert u[-1]=='ORDINARY DEADLINE FINISHED'
 vals=lambda label:[list(map(int,s.split()[1:])) for s in u if s.startswith(label+' ')]
 hz,S,Q,policy,override,refusal,horizon,fb=vals('CONFIG')[0]
 assert (hz,Q,policy,override,refusal,horizon,fb)==(62500000,6250000,int(ll),int(over),9 if over else 0,16,832)
 jobs=vals('JOB'); n=len(jobs)
 expected=([(0,8,1,25),(0,10,8,850)]+([(7,8,3,25)] if over else [])) if ll else [(0,8,2,370 if overrun else 175),(0,12,8,100),(1,4,1,20)]
 assert [tuple(j[1:5]) for j in jobs]==expected
 sy=(d/'symbols').read_text().splitlines()
 def symbol(s):
  x=next(x.split() for x in sy if x.endswith(' '+s));return int(x[0],16),int(x[1],16) if len(x)==4 else 0
 spans=[symbol('deadline_worker_'+x) for x in 'abc']
 assert all(j[5]==spans[i][0] for i,j in enumerate(jobs))
 assert all(j[6]==jobs[0][6]+i*16384 for i,j in enumerate(jobs))
 mem=(d/'ordinary_deadline_rows').read_bytes();N=int.from_bytes((d/'ordinary_deadline_row_count').read_bytes(),'little')
 ex=(d/'exceptions').read_text(); kinds=re.findall(r'Taking exception \d+ \[(\w+)\]',ex)
 elrs=[int(x,16) for x in re.findall(r'with ELR 0x(\w+)',ex)]
 returns=[int(x,16) for x in re.findall(r'Exception return .* PC 0x(\w+)',ex)]
 assert len(kinds)==N==len(elrs)==len(returns)
 asm=(d/'asm').read_text(); pc=int(re.search(r'PC=([0-9a-f]+)',(d/'registers').read_text())[1],16)
 assert 'wfe' in next(l for l in asm.splitlines() if l.strip().startswith(f'{pc-4:x}:')) and format(pc-4,'x') in next(l for l in asm.splitlines() if l.strip().startswith(f'{pc:x}:'))
 q=[];own=3;lastk=0;lastentry=0;grid=0;remain={};released=set();done={};service=[0]*3;used=[0]*3;prog=[0]*3;frames={};switch=[];late=[];rows=[];exhaust={};observed={};gaps=[];saves=[]
 for ix in range(N):
  b=mem[ix*448:(ix+1)*448];ev=list(struct.unpack_from('<19Q',b));jj=[[int.from_bytes(b[160+i*96+j*16:176+i*96+j*16],'little',signed=True) for j in range(6)] for i in range(3)]
  kind,k,gr,nom,cv,iar,stamp,e,h,o,p,f,el,nf,ne,waiting,rel,xh,miss=ev
  assert (gr,nom,k,o)==(grid,S+grid*Q,(e-S)//Q,own) and lastentry<=stamp<=e<=h
  if ix:gaps.append(stamp-lastentry); assert stamp>=rows[-1]['event'][8]
  saves.append(h-e)
  assert kinds[ix]==('IRQ' if kind==1 else 'SVC') and elrs[ix]==el
  if ix<N-1:assert returns[ix+1]==ne
  for id,frame in ((o,f),(p,nf)):
   top=jobs[0][6]+id*16384;assert top-16384<=frame<=top-fb and frame%16==0
  frames[o]=(f,el)
  if o!=3:
   used[o]+=k-lastk;service[o]+=e-stamp;remain[o]=max(1,remain[o]-(k-lastk))
  mask=0
  if o!=3 and used[o]>=jobs[o][3] and o not in exhaust:mask=1<<o;exhaust[o]=service[o]
  assert mask==xh
  if kind==1:
   assert (k,cv,iar&1023)==(grid,nom,30) and 0<=e-nom<Q;grid+=1;late.append(e-nom)
   if o!=3:assert spans[o][0]<=el<sum(spans[o])
   else:assert returns[0]<=el<returns[0]+8
  else:
   assert cv==iar==0 and k<grid and o not in done and o!=3 and el==symbol('ordinary_deadline_after_svc')[0]
   done[o]=e;del remain[o];own=3
  assert miss==int(kind==2 and e>S+jobs[o][2]*Q)
  rmask=0
  for i,r,dd,c,ms,ep,sp in jobs:
   if i not in released and r<=k:
    released.add(i);remain[i]=c;q.append(i);rmask|=1<<i;observed[i]=e
  assert rmask==rel and waiting==int(''.join(str(i+1) for i in q) or '0')
  key=lambda i: jobs[i][2]-k-remain[i] if ll else jobs[i][2]
  selected=pick(q,own,key);assert selected==p
  if p!=own:
   q.remove(p)
   if own!=3:q.append(own);switch.append((k,e,o,p))
  if p in frames:assert (nf,ne)==frames[p]
  elif p!=3:assert ne==jobs[p][5]
  for i,(id,rem,slack,cons,svc,progress) in enumerate(jj):
   assert (id,rem,slack,cons,svc)==(i,remain.get(i,-1),jobs[i][2]-k-remain[i] if i in remain else -(2**127),used[i],service[i])
   assert progress>=prog[i] if i==o else progress==prog[i]
   if i==o:assert progress>prog[i]
   prog[i]=progress
  if vals('D'): assert ev==vals('D')[ix] and jj==vals('J')[3*ix:3*ix+3]
  rows.append(dict(event=ev,jobs=jj));own=p;lastk=k;lastentry=e
 assert len(done)==n and own==3 and all(done[i]<=S+j[2]*Q for i,j in enumerate(jobs))
 seq=[(k,o,p) for k,e,o,p in switch];assert seq==([(6,1,0)]+([(7,1,2)] if over else []) if ll else [(1,0,2)])
 if ll:
  tie=next(r for r in rows if r['event'][:2]==[1,5]);assert tie['jobs'][0][2]==tie['jobs'][1][2]==2 and tie['event'][9:11]==[1,1]
  assert S+6*Q<done[0]<S+7*Q and next(r for r in rows if r['event'][7]==done[0])['event'][10]==1
  if over: assert next(r for r in rows if r['event'][:2]==[1,7])['jobs'][2][2]==-2 and next(r for r in rows if r['event'][7]==done[2])['event'][10]==1
 else:assert list(done)==[2,0,1] and next(r for r in rows if r['event'][7]==done[2])['event'][10]==0
 if overrun:assert used[0]>jobs[0][3] and service[0]>exhaust[0]
 (d/'rows.json').write_text(json.dumps(rows))
 return dict(case=d.name,rows=N,hz=hz,S=S,Q=Q,release=observed,completion=done,deadline={i:S+j[2]*Q for i,j in enumerate(jobs)},switch=switch,dwell=[b[1]-a[1] for a,b in zip(switch,switch[1:])],late_max=max(late),save_range=[min(saves),max(saves)],gap_range=[min(gaps),max(gaps)],service=service,progress=prog,exhaustion_subsequent_service={i:service[i]-v for i,v in exhaust.items()},terminal_pc=hex(pc))
if __name__=='__main__':
 results=[replay(d) for d in sorted(root.glob('ordinary-*')) if d.is_dir()];assert len(results)==8
 (root/'results.json').write_text(json.dumps(results,indent=2))
