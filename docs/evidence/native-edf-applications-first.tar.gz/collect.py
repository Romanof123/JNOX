from pathlib import Path
import subprocess as sp,tempfile,time,json,hashlib,shutil,socket,sys,struct
out=Path(__file__).resolve().parent
build=out.parent/'edf48-builds'
src=out.parent/'edf48-src'
sys.path.insert(0,str(src/'tools'))
from qemu_capture import request,journal_location
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert sha(build/'index.json')=='34488e66ab51e6ae4d860163943cd41cb51abd43b88a85968e28b844f50c82cc'
for name,meta in json.loads((build/'index.json').read_bytes())['images'].items():
 elf=build/meta['path'];assert sha(elf)==meta['sha256'] and sha(build/meta['build_log'])==meta['log_sha256']
 dst=out/name; dst.mkdir()
 with tempfile.TemporaryDirectory(dir='/tmp') as tmp:
  d=Path(tmp); local=d/'kernel.elf';shutil.copyfile(elf,local)
  for sym in ['ordinary_deadline_rows','ordinary_deadline_row_count']: journal_location(local,sym)
  for tool,args,f in [('nm',['-nS'],'symbols'),('objdump',['-dC'],'asm')]:
   (dst/f).write_bytes(sp.check_output(['aarch64-linux-gnu-'+tool,*args,local]))
  cmd=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-accel','tcg','-smp','1','-m','128M','-nographic','-monitor','none','-nic','none','-serial','file:'+str(d/'uart'),'-d','int','-D',str(d/'exceptions'),'-qmp','unix:'+str(d/'qmp')+',server=on,wait=off','-kernel',str(local)]
  with (d/'stderr').open('wb') as err:
   t=time.monotonic();p=sp.Popen(cmd,stderr=err); terminal=None
   try:
    while time.monotonic()-t<10 and p.poll() is None:
     if (d/'uart').exists() and any(s in (d/'uart').read_bytes() for s in (b'ORDINARY DEADLINE FINISHED\n',b'ORDINARY DEADLINE FAIL\n')):
      terminal=time.monotonic()-t;time.sleep(.1);break
     time.sleep(.003)
    with socket.socket(socket.AF_UNIX) as sock:
     sock.settimeout(2);sock.connect(str(d/'qmp'))
     with sock.makefile('rwb',buffering=0) as stream:
      greet=json.loads(stream.readline());request(stream,'qmp_capabilities');status=request(stream,'query-status');request(stream,'stop')
      (d/'registers').write_text(request(stream,'human-monitor-command',**{'command-line':'info registers'}))
      for sym in ['ordinary_deadline_rows','ordinary_deadline_row_count']:
       addr,size=journal_location(local,sym);request(stream,'pmemsave',val=addr,size=size,filename=str(d/sym))
   finally:
    p.terminate();p.wait(timeout=2)
    for f in d.iterdir():
     if f.is_file() and f!=local:shutil.copyfile(f,dst/f.name)
    (dst/'launch.json').write_text(json.dumps(dict(cmd=cmd,elf=sha(elf),terminal=terminal,elapsed=time.monotonic()-t,exit=p.returncode,qmp=greet,status=status)))
  print(name,terminal,(d/'uart').read_bytes().splitlines()[-1:],flush=True)
