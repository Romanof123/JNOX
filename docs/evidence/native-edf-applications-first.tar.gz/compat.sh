set -eu
D=/mnt/d/codex/jnox299-independent-evidence
cd ~/jnox299-independent
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
mkdir -p "$D/compat"
for p in startup cooperative fifo rr weighted; do
 out="$D/compat/$p";mkdir -p "$out";args=()
 if [[ $p != startup ]]; then args=(--elf "$D/elf/batch.elf" --peer-elf "$D/elf/urgent.elf");fi
 case "$p" in fifo) args+=(--policy fifo --priority 3 --peer-priority 3);; rr) args+=(--policy rr --priority 3 --peer-priority 3 --quantum-ticks 625000);; weighted) args+=(--policy weighted --weight 1 --peer-weight 2 --quantum-ticks 625000);; esac
 python3 tools/build_native_el0.py --out "$HOME/jnox299-pkgs/compat-$p" "${args[@]}" >"$out/build.log" 2>&1
 cp "$HOME/jnox299-pkgs/compat-$p/"{manifest.json,kernel.elf} "$out/"
 timeout 2s qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -accel tcg -m 128M -nodefaults -display none -monitor none -serial stdio -kernel "$out/kernel.elf" >"$out/uart" 2>"$out/stderr" || test $? = 124
done
python3 "$D/rejections.py"
