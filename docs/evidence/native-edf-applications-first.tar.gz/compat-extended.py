import subprocess as sp,pathlib,time,json
D=pathlib.Path(__file__).resolve().parent
for n in ('fifo','rr','weighted'):
 d=D/'compat'/n;r=d/'extended';r.mkdir();a=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','file:'+str(r/'uart'),'-kernel',str(d/'kernel.elf')];(r/'command.json').write_text(json.dumps(a))
 with (r/'stderr').open('w') as err,sp.Popen(a,stderr=err) as p:
  try:
   start=time.monotonic()
   while time.monotonic()-start<60:
    if (r/'uart').exists() and (r/'uart').read_bytes().count(b'NATIVE EL0 EXIT PID')==2:break
    time.sleep(.1)
  finally:p.terminate();p.wait(5)
 print(n,(r/'uart').read_bytes().splitlines()[-2:],flush=True)
