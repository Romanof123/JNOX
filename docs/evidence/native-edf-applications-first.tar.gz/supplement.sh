set -eu
D=/mnt/d/codex/jnox299-independent-evidence
cd ~/jnox299-independent
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
test ! -e /dev/shm/jnox299-supplement-exceptions.log
sha256sum "$D/supplement.py" "$D/supplement-protocol.txt" "$D/elf/principal/kernel.elf" >"$D/supplement-prelaunch.sha256"
python3 "$D/supplement.py"
cp /dev/shm/jnox299-supplement-exceptions.log "$D/runs/principal-supplement/exceptions.log"
mkdir -p "$D/invalid-peer"
echo 'this is a text file' >"$D/invalid-peer/input.txt"
python3 tools/build_native_el0.py --out "$HOME/jnox299-pkgs/invalid-peer" --policy edf --elf "$D/elf/urgent.elf" --job 0,4,1 --peer-elf "$D/invalid-peer/input.txt" --peer-job 0,8,2 >"$D/invalid-peer/package.log" 2>&1
cp "$HOME/jnox299-pkgs/invalid-peer/"{manifest.json,kernel.elf} "$D/invalid-peer/"
timeout 2s qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -accel tcg -m 128M -nodefaults -display none -monitor none -serial "file:$D/invalid-peer/uart" -kernel "$D/invalid-peer/kernel.elf" || test $? = 124
