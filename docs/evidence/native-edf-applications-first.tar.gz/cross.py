from pathlib import Path
import json,re,hashlib
from verify import pick
root=Path(__file__).resolve().parent
results=json.loads((root/'results.json').read_text())
def model(table,ll):
 rem={};queue=[];owner=3;done={}
 for k in range(17):
  for i,(r,d,c) in enumerate(table):
   if r==k:rem[i]=c;queue.append(i)
  sel=pick(queue,owner,lambda i:table[i][1]-k-rem[i] if ll else table[i][1])
  if sel!=owner:
   queue.remove(sel)
   if owner!=3:queue.append(owner)
  owner=sel
  if owner==3:continue
  rem[owner]-=1
  if rem[owner]==0:done[owner]=k+1;owner=3
 return done
edf=[(0,8,2),(0,12,8),(1,4,1)]
llf=[(0,8,1),(0,10,8)]
assert model(edf,False)=={2:2,0:3,1:11} and model(llf,True)=={0:7,1:9}
assert model(llf+[(7,8,3)],True)[2]>8
assert min(range(2),key=lambda i:edf[i][1]-edf[i][2])==1 and min(range(2),key=lambda i:llf[i][1])==0
for r in results:
 d=root/r['case'];asm=(d/'asm').read_text()
 assert re.search(r'bl\s+\w+ <jnox_kernel::ordinary_deadline::Runtime::at>\n\s*\w+:\s+\w+\s+cmp\s+x\d+, x0\n\s*\w+:\s+\w+\s+cset\s+w\d+, hi',asm)
 deadline=r['deadline']['0']
 # AArch64 CMP sets C for unsigned no-borrow, Z for equality; HI = C && !Z.
 for stamp,want in [(deadline-1,False),(deadline,False),(deadline+1,True)]:
  C=stamp>=deadline;Z=(stamp-deadline)%(1<<64)==0;assert (C and not Z)==want
 rows=json.loads((d/'rows.json').read_text());ex=(d/'exceptions').read_text()
 vec=int(next(x.split()[0] for x in (d/'symbols').read_text().splitlines() if x.endswith(' sched_vectors')),16)
 assert [int(x,16) for x in re.findall(r'to EL1 PC 0x(\w+) PSTATE',ex)]==[vec+(0x280 if row['event'][0]==1 else 0x200) for row in rows]
 assert ex.count('0x15/0x56000001')>=len(r['completion'])
 assert len({a[0] for a in r['switch']})==len(r['switch'])
 for i,row in enumerate(rows):
  if row['event'][0]==2:
   assert 'svc' in next(x for x in asm.splitlines() if x.strip().startswith(f"{row['event'][12]-4:x}:"))
 assert len(re.findall(r'^D ',(d/'uart').read_text(),re.M))==(len(rows) if d.name.endswith('-trace') else 0)
print('PASS independent model and cross-policy replay, exception vectors, SVC trampoline and linked unsigned HI equality/one-count-late controls on eight images')
