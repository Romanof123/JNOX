import pathlib,json,re,struct
D=pathlib.Path(__file__).resolve().parent
U=2**64-1
def words(b,s):return [int.from_bytes(b[i:i+s],'little') for i in range(0,len(b),s)]
def stamp_miss(s,d,q,t):return t>s+d*q
assert [stamp_miss(7,3,10,t) for t in (36,37,38)]==[False,False,True]
model=[(0,8,2),(0,12,8),(1,4,1)];rem=[j[2] for j in model];done={}
for k in range(16):
 ready=[i for i,(r,d,c) in enumerate(model) if r<=k and rem[i]]
 if ready:
  i=min(ready,key=lambda i:(model[i][1],i));rem[i]-=1
  if not rem[i]:done[i]=k+1
assert done=={2:2,0:3,1:11}
out={}
for r in sorted((D/'runs').iterdir()):
 u=(r/'uart.log').read_text();apps=json.loads((r/'command.json').read_text())['apps'];raw=json.loads((r/'ram.json').read_text())
 if r.name.startswith('refusal'):
  assert 'NATIVE EDF REFUSED 8' in u and 'NATIVE EL0 FAULT 14' in u and 'NATIVE EDF EVENT' not in u and int(raw[0]['private_progress'],16)==0;out[r.name]={'refusal':8,'fault':14};continue
 def rows(s):return [list(map(int,v.split())) for v in re.findall('^NATIVE EDF '+s+r' (.*)$',u,re.M)]
 S,Q,hz=rows('CONFIG')[0]; assert Q*10==hz and rows('DROPPED')==[[0]]
 ev=rows('EVENT');js=rows('JOB');products=[];stats=[int(x.split()[-1]) for x in u.splitlines() if 'NATIVE EL0 EXIT' in x];assert len(stats)==len(apps)
 for i,(app,f) in enumerate(zip(apps,raw)):
  prog=words(bytes.fromhex(f['private_progress']),4)[0];res=words(bytes.fromhex(f['private_result']),8 if app=='batch' else 4)
  if app=='batch':assert 0<prog<=65536 and res==[prog*522240] and stats[i]==17
  elif app=='histogram':assert prog==128 and res==[32768]*16 and stats[i]==29
  elif app=='urgent':assert prog==8 and res==[2048] and stats[i]==43
  else:
   assert prog==2 and res==[{'sleep_first':53,'sleep_last':59,'midgrid':61}[app]] and stats[i]==res[0]
   assert words(bytes.fromhex(f['observed_ns']),8)>=words(bytes.fromhex(f['request_ns']),8)
  products.append([prog,res])
 total=[0]*len(apps); switches=[]; irq=[];exits={};changes=[]
 for ix,e in enumerate(ev):
  reason,t,k,prior,nxt=e[:5];assert (t-S)//Q==k and not e[19]
  if prior!=U:assert t-e[5]==e[6];total[prior]+=e[6]
  assert total==e[24:24+len(apps)]
  if prior!=nxt:changes.append([t,prior,nxt,reason])
  if reason==4:
   assert t>=e[8];irq.append([k,e[8],t,t-e[8],e[19]])
   if prior!=U and nxt!=U and prior!=nxt:switches.append([k,prior,nxt,t])
  if reason==3:assert prior not in exits and e[30+prior]==t;exits[prior]=t
 assert len({x[0] for x in switches})==len(switches)
 margins=[S+j[2]*Q-exits[i] for i,j in enumerate(js)]
 assert all(m>=0 for m in margins) if not r.name.startswith('miss') else margins[0]<0
 extra={}
 if r.name.startswith('principal'):
  assert [e[4] for e in ev]==[0,2,0,1,U] and ev[1][2]==1 and ev[1][11]==4
  assert ev[1][20:22]==ev[2][22:24] and ev[1][34]==ev[2][35]
  ps=[json.loads(l)[1] for l in (r/'progress.jsonl').read_text().splitlines()]
  assert max(p[0] for p in ps if p[2]==0)<ps[-1][0] and any(0<p[0]<ps[-1][0] for p in ps)
  extra.update(interrupted_pc=hex(ev[1][20]),inside_batch_reduce=0x4001a4<=ev[1][20]<0x4001cc,sp=hex(ev[1][21]),frame=hex(ev[1][34]))
  if (r/'exceptions.log').exists():
   ex=(r/'exceptions.log').read_text()
   match=re.search(r'Taking exception 5 \[IRQ\]\n\.\.\.from EL0 to EL1.*?with ELR (0x\w+).*?Exception return from AArch64 EL1 to AArch64 EL0 PC (0x\w+)',ex,re.S)
   assert int(match[1],16)==ev[1][20] and int(match[2],16)==ev[1][22]
   assert f'Exception return from AArch64 EL1 to AArch64 EL0 PC {hex(ev[2][22])}' in ex[match.end():]
 if r.name.startswith('equal'):assert ev[0][4]==0 and all(e[4]==0 for e in ev if e[0]==4) and list(exits)==[0,1]
 if r.name.startswith('idle'):assert ev[0][2]==1 and ev[0][3:5]==[U,0]
 if r.name.startswith(('overrun','miss')):assert total[0]>Q and ev[-1][1]>ev[1][1] and stats==[17]
 if r.name.startswith('sleep'):
  assert [(e[0],e[3],e[4]) for e in ev]==[(4,U,0),(1,0,1),(2,1,0),(2,0,U),(4,U,0),(3,0,U),(4,U,1),(1,1,1),(3,1,U)]
  for i,block,wake in [(0,3,4),(1,2,6)]:assert ev[block][24+i]==ev[wake][24+i] and ev[block][27+i]==ev[wake][27+i] and ev[wake][1]>=ev[block][10]
 if r.name.startswith('mid'):assert ev[2][12]==1 and ev[2][3:5]==[1,1] and ev[3][2]==1 and ev[3][3:5]==[1,0]
 out[r.name]=dict(epoch=S,Q=Q,hz=hz,service=total,exits=exits,deadline_margins=margins,irq=irq,switches=switches,changes=changes,dwell=[b[0]-a[0] for a,b in zip(changes,changes[1:])],products=products,**extra)
(D/'scores.json').write_text(json.dumps(out,indent=2))
