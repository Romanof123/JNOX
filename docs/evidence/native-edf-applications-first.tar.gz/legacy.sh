set -euo pipefail
D=/mnt/d/codex/jnox299-independent-evidence
cd ~/jnox299-independent
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
mkdir -p "$D/legacy" "$D/host"
for test in scheduling_tests deadline_supply_tests; do rustc --edition 2021 --test "tools/$test.rs" -o "/tmp/299-$test"; "/tmp/299-$test" > "$D/host/$test.log"; done
sed "s|../edf48-src|$PWD|g" "$D/controls.rs" >/tmp/299-admission.rs
rustc --edition 2021 -A warnings /tmp/299-admission.rs -o /tmp/299-admission && /tmp/299-admission >"$D/host/legacy-admission.log"
export CARGO_TARGET_DIR=$HOME/jnox299-pkgs/legacy-target
for app in ordinary-edf ordinary-edf-overrun ordinary-llf ordinary-llf-overload; do
 for trace in '' '-trace'; do
  n=$app$trace; d="$D/legacy/$n"; mkdir -p "$d"; unset JNOX_DEADLINE_TRACE
  if [[ -n $trace ]]; then export JNOX_DEADLINE_TRACE=1; fi
  JNOX_PROFILE=deadline JNOX_APP=$app JNOX_BOARD=virt python3 tools/build_kernel.py > "$d/build.log" 2>&1
  cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" "$d/kernel.elf"
 done
done
python3 "$D/legacy-collect.py"

