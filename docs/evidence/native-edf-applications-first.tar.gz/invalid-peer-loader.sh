set -eu
D=/mnt/d/codex/jnox299-independent-evidence
cd ~/jnox299-independent
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
mkdir -p "$D/invalid-peer-loader"
echo 'This plain text peer is deliberately longer than the minimal ELF header size so packaging passes its size check.' >"$D/invalid-peer-loader/input.txt"
python3 tools/build_native_el0.py --out "$HOME/jnox299-pkgs/invalid-peer-loader" --policy edf --elf "$D/elf/urgent.elf" --job 0,4,1 --peer-elf "$D/invalid-peer-loader/input.txt" --peer-job 0,8,2 >"$D/invalid-peer-loader/package.log" 2>&1
cp "$HOME/jnox299-pkgs/invalid-peer-loader/"{manifest.json,kernel.elf} "$D/invalid-peer-loader/"
timeout 2s qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -accel tcg -m 128M -nodefaults -display none -monitor none -serial "file:$D/invalid-peer-loader/uart" -kernel "$D/invalid-peer-loader/kernel.elf" || test $? = 124

