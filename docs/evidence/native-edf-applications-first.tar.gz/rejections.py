import os,sys,json,subprocess as sp,pathlib,hashlib
D=pathlib.Path(__file__).resolve().parent
elf=D/'elf/urgent.elf'; base=['python3','tools/build_native_el0.py','--out','/tmp/jnox299-invalid','--elf',str(elf),'--policy','edf']
out={}
for name,extra in {'missing':[],'negative':['--job=-1,4,1'],'sign':['--job=+0,4,1'],'shape':['--job=0,4'],'horizon':['--job=0,17,1'],'overcost':['--job=0,2,18446744073709551616'],'double':['--job=0,2,1']*2,'priority':['--job=0,2,1','--priority=2'],'quantum':['--job=0,2,1','--quantum-ticks=3'],'weight':['--job=0,2,1','--weight=1'],'peer':['--job=0,2,1','--peer-elf',str(elf)],'source':['--job=0,2,1','--source','examples/native-edf/urgent.c']}.items():
 r=sp.run(base+extra,capture_output=True,text=True);assert r.returncode;out[name]=[r.args,r.returncode,r.stderr]
args=['python3','tools/build_kernel.py']
env=dict(os.environ,JNOX_PROFILE='native',JNOX_APP='process',JNOX_BOARD='virt',JNOX_NATIVE_ELF=str(elf),JNOX_NATIVE_ELF_SHA256=hashlib.sha256(elf.read_bytes()).hexdigest(),JNOX_NATIVE_POLICY='edf',CARGO_TARGET_DIR=str(pathlib.Path.home()/'jnox299-pkgs/raw'))
for name,extra in {'count':{'JNOX_NATIVE_EDF_JOBS':'0,2,1;0,3,1'},'missing':{},'malformed':{'JNOX_NATIVE_EDF_JOBS':'0,+2,1'},'weights':{'JNOX_NATIVE_EDF_JOBS':'0,2,1','JNOX_NATIVE_WEIGHTS':'1'},'quantum':{'JNOX_NATIVE_EDF_JOBS':'0,2,1','JNOX_NATIVE_QUANTUM_TICKS':'42'},'priority':{'JNOX_NATIVE_EDF_JOBS':'0,2,1','JNOX_NATIVE_PRIORITIES':'3'}}.items():
 r=sp.run(args,env=env|extra,capture_output=True,text=True);assert r.returncode and 'panicked' in r.stderr;out['raw-'+name]=[extra,r.returncode,r.stderr[-1600:]]
(D/'host/rejections.json').write_text(json.dumps(out,indent=2))
