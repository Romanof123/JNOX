from pathlib import Path
import json,re,struct,zlib,collections,gzip
from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
q=lambda n:struct.pack("<Q",n)
def run(d):
    stream="stream" in d.name
    syms={}
    for l in (d/"symbols.txt").read_text().splitlines():
        if m:=re.match(r"(\w+) (\w+) \w (.+)",l): syms[m[3]]=(int(m[1],16),int(m[2],16))
    sy=lambda s:next(v[0] for k,v in syms.items() if s in k)
    raw=(d/"kernel8.img").read_bytes()
    with (d/"kernel.elf").open("rb") as file:
        sect=ELFFile(file).get_section_by_name(".text")
        assert sect.data()==raw[sect["sh_addr"]-0x80000:sect["sh_addr"]-0x80000+sect["sh_size"]]
        textsize=sect["sh_size"]
    lines={}
    for l in (d/"disassembly.txt").read_text().splitlines():
        if m:=re.match(r"\s*([\da-f]+):\s+([\da-f]{8})\s+(\S+)\s*(.*)",l):
            lines[int(m[1],16)]=(m[2],m[3],m[4])
    entry=sy("pi4_stream_crc32_m_v1" if stream else "pi4_migration_m"); acquire=next(p for p in range(entry,entry+96,4) if lines[p][1]=="ldar")
    tls=sy("PI4_MIG_TLS_M")
    def prepare(ptr,token):
        u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0x80000,0x40000);u.mem_write(0x80000,raw);u.mem_map(0x100000,0x20000);u.reg_write(UC_ARM64_REG_SP,0x110000)
        u.reg_write(UC_ARM64_REG_TPIDR_EL0,ptr);u.reg_write(UC_ARM64_REG_TPIDRRO_EL0,token);return u
    u=prepare(tls,0x10601);u.emu_start(entry,acquire)
    step=1024 if stream else 16
    digest=0
    def prefix(i):
        return zlib.crc32(bytes((a^(a>>8)^(a>>16))%256 for a in range(i))) if stream else i*(i+1)//2
    for i in [step,2*step,3*step]:
        digest=((((digest<<7)|(digest>>57))%(1<<64)^i)+prefix(i))%(1<<64)
        if i==2*step: prior=digest
    sp=u.reg_read(UC_ARM64_REG_SP)
    u.mem_write(sp,struct.pack("<6Q",2*step,prefix(2*step),1,2,2,2*step))
    u.mem_write(sy("10TASK_LEASE"),q(1));u.mem_write(tls,q(prior))
    path=[]; accesses=[]; predicates={};total=collections.Counter()
    def code(u,p,size,user):
        if p==acquire and path: u.emu_stop();return
        path.append(p)
        op,args=lines[p][1:]
        if op.startswith("b.") or op in ("cbz","cbnz","tbz","tbnz"):
            testreg=args.split(",")[0]
            reg=globals().get("UC_ARM64_REG_"+testreg.upper())
            predicates[len(path)-1]=f"third block, stable M lease 1, two sparse rows already published; {op} {args}; NZCV={u.reg_read(UC_ARM64_REG_NZCV):#x}"+(f" {testreg}={u.reg_read(reg):#x}" if reg else "")
    def mem(u,access,address,size,value,user):
        kind="read" if access==UC_MEM_READ else "write"
        if 0x100000<=address<0x120000 or address==tls:
            accesses.append((path[-1],kind,address,size))
    u.hook_add(UC_HOOK_CODE,code);u.hook_add(UC_HOOK_MEM_READ|UC_HOOK_MEM_WRITE,mem)
    u.emu_start(acquire,0,count=100000)
    assert u.reg_read(UC_ARM64_REG_PC)==acquire and bytes(u.mem_read(tls,8))==q(digest)
    assert bytes(u.mem_read(sp,48))==struct.pack("<6Q",3*step,prefix(3*step),1,2,3,3*step)
    for pc in path:
        opcode,op,args=lines[pc]
        assert int(opcode,16)==int.from_bytes(raw[pc-0x80000:pc-0x80000+4],"little")
        total["instructions"]+=1
        if op in ("bl","ret"):total[op]+=1
        if op.startswith("b.") or op in ("cbz","cbnz","tbz","tbnz"):total["conditional"]+=1
        if "[sp" in args: total["sp_"+("read" if op.startswith("ld") else "write")]+=1
    spans=[]
    first=path[0]
    for k,pc in enumerate(path):
        op=lines[pc][1]
        if k==len(path)-1 or k in predicates or op in ("b","bl","ret") or path[k+1]!=pc+4:
            span=dict(first=hex(first),last=hex(pc))
            if k in predicates:span["why"]=predicates[k]
            spans.append(span)
            if k+1<len(path):first=path[k+1]
    (d/"spans.json").write_text(json.dumps(spans))
    controls=[]
    if d.parent.name=="side-candidate":
        ptrs=[sy("PI4_MIG_TLS_"+s) for s in ("M","P0","P1_OPEN","P1_REPLACEMENT")]
        for a in range(5):
            for mode in (["invalid"] if a==4 else ["valid","badptr","badtoken"]):
                ptr=ptrs[a%4];token=0x10601+a
                v=prepare(ptrs[(a+1)%4] if mode=="badptr" else ptr,token^int(mode=="badtoken"))
                v.reg_write(UC_ARM64_REG_X0,a);v.reg_write(UC_ARM64_REG_X30,0x110000)
                fail=sy("11pi4_smp_bsp4fail");seen=[]
                def probe(v,pc,sz,data):
                    if pc in (fail,0x110000):seen.append((pc,v.reg_read(UC_ARM64_REG_X0)));v.emu_stop()
                touched=[]
                def watch(v,kind,addr,size,val,data):
                    if addr in ptrs:touched.append((kind,addr))
                v.hook_add(UC_HOOK_CODE,probe);v.hook_add(UC_HOOK_MEM_READ|UC_HOOK_MEM_WRITE,watch)
                v.emu_start(sy("12checked_word"),0,count=100)
                assert not touched and seen==[(0x110000,ptr) if mode=="valid" else (fail,0x33 if mode=="invalid" else 0x34)]
                controls.append((a,mode,seen))
    with gzip.open(d/"executed.tsv.gz","wt") as f:
        for pc in path:f.write(f'{pc:x}\t'+'\t'.join(lines[pc])+'\n')
    with gzip.open(d/"memory.tsv.gz","wt") as f:
        for a in accesses:f.write('%x\t%s\t%x\t%d\n'%a)
    return dict(side=d.parent.name,case=d.name,entry=hex(entry),acquire=hex(acquire),counts=total,text=textsize,raw=len(raw),controls=controls,symbols={k:v for k,v in syms.items() if any(x in k for x in ("10checkpoint","10activation","checked_word","checked_tls","observe_tls","6digest","13pi4_migration6finish","pi4_stream_crc32_m_v1","pi4_migration_m","checked_registers"))})
records=[]
for d in sorted(Path(".").glob("side-*/*/freeze.json")):
    records.append(run(d.parent))
    print(records[-1]["side"],d.parent.name,records[-1]["counts"],flush=True)
Path("linked.json").write_text(json.dumps(records,indent=2))
