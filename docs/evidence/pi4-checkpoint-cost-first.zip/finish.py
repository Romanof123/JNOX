import gzip,json,re,zipfile,hashlib,subprocess
from pathlib import Path
from collections import Counter
from itertools import groupby
D=Path.cwd()
L=json.loads(Path("linked.json").read_text())
R=[]
for a in json.loads(Path("independent.json").read_text()):
    d=Path("side-candidate")/a["image"]; n=a["i"];r=json.JSONDecoder().raw_decode((d/f"replay-{n}.log").read_text())[0]
    rows=[]
    for line in (d/f"first-{n}/uart.bin").read_text().splitlines():
        if line.startswith("MG ROW "):rows.append(list(map(int,line.split()[2:])))
    irq=next(k for k in rows if k[2]==4 and k[3:5]==[0,0] and k[9]!=65535)
    dest=next(k for k in rows if k[2]==11 and k[3:5]==[1,0]);cpu=dest[0];lease=dest[5]
    live=next(k for k in rows if k[2]==15 and k[3]==0 and k[5]==lease)
    saved=next(k for k in rows if k[2]==14 and k[3]==0 and k[5]==1)
    cross=next(k for k in rows if k[2]==5 and k[3]==0 and k[5]==lease)
    a.update(frame=hex(irq[5]),sp=hex(irq[7]),x21=hex(irq[8]),eret=hex(dest[7]),dst_lease=lease,saved_tls=saved[7:9],live_tls=live[7:9],prefix=cross[6:8],prefix_digest=live[10])
    assert a["eret"]==a["pc"] and saved[7:9]==live[7:9]
    R.append(a)
Path("positions.json").write_text(json.dumps(R,indent=2))
for e in ("virt","sw1","all"):
    dis=subprocess.check_output(["aarch64-linux-gnu-objdump","-d",f"controls/{e}.elf"],text=True)
    lines=[l for l in dis.splitlines() if re.search(r"\b(mrs|msr)\b.*\b(tpidr[^, ]*|sp_el0)\b",l)]
    (Path("controls")/(e+"-ownership.txt")).write_text("\n".join(lines)+"\n")
    old=Path.home()/"jnox279-first.COMmu3"/"controls"/(e+".elf")
    old_dis=subprocess.check_output(["aarch64-linux-gnu-objdump","-d",old],text=True)
    old_lines=[l for l in old_dis.splitlines() if re.search(r"\b(mrs|msr)\b.*\b(tpidr[^, ]*|sp_el0)\b",l)]
    assert [l.split(":")[1].strip() for l in lines]==[l.split(":")[1].strip() for l in old_lines],e
report="""# #283 independent paired TLS checkpoint evidence / TLS 체크포인트 독립 검증

Integration parent 9207337f95edfd7365a3cabf39b03d58607181f6, candidate 2545d64ed05e5945b9258d8368920f2cad2d4d3e, public predeclared plan b79d8e4ba70c7ac9c90ddba2b725c4db514fb522. Both trees use MG3. The original #279 release used ce8aebc872612cb036c05928fc8764d947d76145. This pair excludes #281. Twelve builds from exact Git archives used identical paths/toolchain, separate clean targets for each side, and the same release options. See pairs.sh, pairs.log, isolated.patch, source-tracking files, and per-image freeze.json for hashes, stock-QEMU identity, observer and ELF/raw inputs. input-contract.sha256 predates candidate inspection. scored-freeze.sha256 predates all 12 scored boots.

## Linked path / 링크 경로

Each active M prologue was executed from its linked entry to the first acquire. At that boundary the ordinary third-block state was supplied: one stable lease, count two, two sparse rows retained, independent prefix and digest through block two. Unicorn 2.1.4 executed every instruction through the return to the same acquire. The third prefix, digest and count matched independent arithmetic. Branch operands/NZCV and ELF/raw checked opcodes are in per-image spans.json and executed.tsv.gz. memory.tsv.gz records effective stack and TLS accesses including aliases. linked.json records symbol addresses/sizes, image by image; public.py separately passed all six inputs through the candidate's path verifier. It validates the submitted path, direct edges and SP-literal accesses. It requires independent predicate, alias and data-flow evidence.

|Workload (all three policies)|Instructions before → after|Calls/returns|Conditional executions|Direct SP loads/stores before → after|.text bytes|Raw bytes|
|---|---:|---:|---:|---:|---:|---:|
|Short|250 → 245|4/4|29|12/8 → 11/8|20,468 → 20,468|53,448 → 53,448|
|Stream|16,490 → 16,485|4/4|1,035|12/8 → 11/8|20,468 → 20,468|53,448 → 53,448|

All six baseline helpers save the indirect destination X8 into X19, then STP X0,X8,[X19] and STR X1,[X19,#16] materialize three 64-bit words; the caller reloads the word pointer from its stack. All six candidate helpers retain the activation lookup and both live MRS reads with CMP/CCMP, return the validated pointer in X0, and the caller performs LDR [X0], rotate/XOR/add, STR [X0]. The ordinary candidate path has no extra spills or conditional executions and no alias stores into an indirect result. The helper saves/restores X30 alone instead of X30/X19 together. Stack reads/writes through the arithmetic X21 cursor remain present as in the baseline. checked_registers is inlined, and update_digest is fused into checkpoint. Symbol sizes of retained helpers and terminal paths are in linked.json. The whole-image ELF/raw section and instruction bytes matched independently. All 78 linked helper probes (13 per candidate image) reached correct valid returns or failure 0x34/0x33 before any TLS-word access.

동일한 제3 블록의 acquire에서 다음 acquire 전까지 실행한 결과 여섯 쌍 모두 명령 5개와 SP 직접 읽기 1개가 줄었다. 세 워드 간접 반환 저장과 호출자의 포인터 재읽기가 사라졌다. 두 TLS 레지스터의 실제 읽기·검증, 활성화 조회, 다이제스트 갱신은 유지됐다. 링크된 기계어에서 측정한 수치이며 실제 경과 시간과 실물 보드 성능은 측정하지 않았다.

## Original positions / 최초 순번

|Workload/policy|#|CPU/lease from → to|IRQ = ERET|Strict bounds [lo,hi)|Frame / SP / X21|Resumed index, product|Strict|
|---|---:|---|---|---|---|---|---|
"""
for a in R:
    report+=f'|{a["image"]}|{a["i"]}|0/1 → {a["dest"]}/{a["dst_lease"]}|{a["pc"]}|{", ".join(a["loop"])}|{a["frame"]} / {a["sp"]} / {a["x21"]}|{a["prefix"][0]}, {a["prefix"][1]}|{"yes" if a["inner"] else "miss"}|\n'
report+="""
Short 2/6, stream 6/6. All twelve reached their terminal products. All saved IRQ PCs matched external ERET and frame/SP/X21 continuation. Four short misses had out-of-loop saved PCs. No early completion. Historical #279 short 3/6 and stream 6/6. The new short sample has one fewer qualifying position. Global resumed on CPU1, partitioned and clustered on CPU0. positions.json records actual saved/live TLS, first resumed digest and terminal count/digest/index/product per original. For short the terminal tuple is 4096 / 18080812676020141577 / 65536 / 2147516416. For stream it is 4096 / 8765611335505774534 / 4194304 / 2027031249 (CRC32 0x78d22ad1). Independent zlib/sum/prefix and all four activation outcomes are checked by independent.py.

짧은 작업 2/6, 스트림 6/6. 첫 순번을 교체하지 않았다. 짧은 작업의 네 번은 IRQ와 복귀가 실제로 관측됐으나 엄격한 산술 구간 밖에 있었다. 조기 종료는 없었다. #279의 3/6과 비교해 짧은 작업의 적격 순번은 하나 줄었다. #47 상위 이주 판정 및 실물 보드 결과는 이 자료의 범위 밖이다.

## Controls / 대조 검증

The integrated reader replayed all 30 archived positions (MG1 1/6, MG2 0/6, original CRC 6/6, MG3 short 3/6 and stream 6/6). Historical early completions retain their original dispositions. Four resealed semantic corruption cases were rejected. Ten MG3 mutations rejected with the positive witness accepted. Nineteen independent host vectors passed. Fresh generic SMP and SW1 stock-model controls passed; ownership listings are included. The initial bounded SW1 offline replay lacked pyelftools; reopening the identical sealed session with the dependency yielded observed software and matched CPU-tagged PCs. All-feature and invalid configuration build logs are retained. No physical-board or wall-clock speed claim.

과거 원본 30개와 네 계열의 손상 대조, MG3 증인 변조 10개 및 호스트 테스트 19개를 확인했다. 일반 SMP와 SW1도 새로 실행하고 링크된 레지스터 사용을 대조했다. SW1의 최초 판독 환경에서 누락된 라이브러리를 복구한 다음 동일한 원본을 재판독했다.
"""
report=report.replace("2027031249",str(0x78d22ad1))
Path("REPORT.en-ko.md").write_text(report)
PYFILES=["contract.txt","input-contract.sha256","pairs.sh","pairs.sha256","pairs.log","toolchain.txt","isolated.patch","scored-freeze.sha256","session-digests","measure.py","measure.log","linked.json","independent.py","independent.json","positions.json","negative.py","public.py","public.log","controls-more.sh","controls-more.log","check.sh","order","REPORT.en-ko.md","finish.py","attempt-fetch.log"]
allfiles=[Path(f) for f in PYFILES]+list(Path().glob("pair-*.json"))+list(Path().glob("cost-*.json"))
for base in ("side-baseline","side-candidate","controls"):
    allfiles.extend(f for f in Path(base).rglob("*") if f.is_file())
for base in ("source-candidate","source-baseline"):
    for f in ("kernel/src/pi4_migration_local.rs","kernel/src/pi4_migration.rs","kernel/src/pi4_migration_tasks.rs","tools/pi4_migration_capture.py","tools/pi4_migration_replay.py"):
        allfiles.append(Path(base)/f)
allfiles.append(Path("source-candidate/tools/pi4_checkpoint_cost.py"))
out=Path("/mnt/d/codex/jnox283-2545d64-independent.zip")
with zipfile.ZipFile(out,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for f in allfiles:z.write(f)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(out,hashlib.sha256(out.read_bytes()).hexdigest())
