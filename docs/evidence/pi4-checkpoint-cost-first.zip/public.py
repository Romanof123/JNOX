from pathlib import Path
import json,subprocess,hashlib
from collections import Counter
D=Path.cwd()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for side in sorted(Path("side-candidate").glob("*/freeze.json")):
    case=side.parent.name
    spec=dict(selection=Path("contract.txt").read_text())
    for s in ("baseline","candidate"):
        p=Path("side-"+s)/case
        spans=json.loads((p/"spans.json").read_text())
        spec[s]=dict(elf=str(p/"kernel.elf"),raw=str(p/"kernel8.img"),raw_base="0x80000",stop=spans[0]["first"],path=spans)
    name=Path("pair-"+case+".json")
    name.write_text(json.dumps(spec))
    result=subprocess.run(["python3","source/tools/pi4_checkpoint_cost.py",name],capture_output=True,text=True)
    assert not result.returncode,result.stderr
    Path("cost-"+case+".json").write_text(result.stdout)
    print(case,json.loads(result.stdout)["delta"])