set -euo pipefail
D=$(pwd)
export PATH="$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH"
export CARGO_HOME="$HOME/jnox-169-first-e203caa/cargo" PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
Q=/mnt/d/codex/arm-speed-lab/build/system/qemu-system-aarch64
repo=/mnt/d/codex/j-nox
parent=9207337f95edfd7365a3cabf39b03d58607181f6
head=2545d64ed05e5945b9258d8368920f2cad2d4d3e
sha256sum -c input-contract.sha256
test ! -e side-baseline
{ rustc -vV; cargo -V; aarch64-linux-gnu-objdump --version; sha256sum "$Q"; } > toolchain.txt
git -C "$repo" diff "$parent" "$head" > isolated.patch
for side in baseline candidate; do
 ref=$parent; if [[ $side == candidate ]]; then ref=$head; fi
 mkdir src "side-$side"
 git -C "$repo" archive "$ref" | tar xf - -C src
 git -C "$repo" rev-parse "$ref^{tree}" > "side-$side/tree"
 export CARGO_TARGET_DIR="$D/target"
 cd src/kernel
 for w in short stream; do
  f=(); work=sum-65536
  if [[ $w == stream ]]; then f=(--features pi4-stream-v1); work=sample-crc32-v1; fi
  for p in global partitioned clustered; do
   JNOX_PROFILE=smp JNOX_BOARD=pi4 JNOX_APP=migration-$p cargo build -j1 --locked --offline --release "${f[@]}"
   e="$D/target/aarch64-unknown-none/release/jnox-kernel"
   out="$D/side-$side/$w-$p"
   aarch64-linux-gnu-objcopy -O binary "$e" "$D/raw"
   aarch64-linux-gnu-objdump -d "$e" > "$D/dis"
   python3 ../tools/pi4_migration_capture.py freeze migration-$p "$out" "$e" "$D/raw" "$D/dis" "$Q" --source "$ref" --wire-version 3 --compiler "$(rustc -V)" --workload "$work" >> "$D/side-$side/freeze-digests"
   aarch64-linux-gnu-nm -anS "$e" > "$out/symbols.txt"
   aarch64-linux-gnu-objdump -h "$e" > "$out/sections.txt"
  done
 done
 cd "$D"
 mv src "source-$side"
 mv target "target-$side"
done
sha256sum contract.txt side-candidate/*/freeze.json source-candidate/tools/pi4_migration_{capture,replay}.py > scored-freeze.sha256
for w in short stream; do for p in global partitioned clustered; do for i in 1 2; do
 d=side-candidate/$w-$p
 h=$(sha256sum "$d/freeze.json" | cut -d' ' -f1)
 echo "START $w $p $i"
 python3 source-candidate/tools/pi4_migration_capture.py run "$d" "$h" "$i" > "$d/run-$i.log" 2>&1 || echo "exit=$?" >> "$d/run-$i.log"
 s="$d/first-$i/session.json"
 if test -f "$s"; then
 sh=$(sha256sum "$s" | cut -d' ' -f1)
 echo "$w $p $i $sh" >> session-digests
 python3 source-candidate/tools/pi4_migration_replay.py "$d" "$i" "$sh" > "$d/replay-$i.log" 2>&1 || echo "exit=$?" >> "$d/replay-$i.log"
 fi
done; done; done
