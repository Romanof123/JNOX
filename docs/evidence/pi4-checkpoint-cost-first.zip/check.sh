set -eu
cd ~/jnox283-independent-2545d64
old=~/jnox279-first.COMmu3
ln -s side-candidate frozen
ln -s source-candidate source
cp "$old/order" "$old/independent.py" .
mkdir controls
cp "$old"/controls/{history.py,mutations.py,regress.sh,sw1_model.py,opcodes.py} controls/
python3 independent.py > independent.json
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
python3 controls/history.py > controls/history.log
bash controls/regress.sh > controls/regress.log 2>&1
