from pathlib import Path
import subprocess,json,shutil,hashlib,re
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
root=Path("controls/negatives");root.mkdir(exist_ok=True)
for src in map(Path,["historical/mg1/partitioned","historical/mg2/global","historical/crc/stream-global/frozen","historical/mg3/frozen/stream-global"]):
    name=src.parts[1];d=root/name;d.mkdir(exist_ok=True)
    for f in ["freeze.json","kernel.elf","kernel8.img","disassembly.txt"]:shutil.copyfile(src/f,d/f)
    sess=d/"first-1";shutil.copytree(src/"first-1",sess,dirs_exist_ok=True)
    f=sess/"uart.bin";b=f.read_bytes()
    b,n=re.subn(rb"(?m)^MG ROW 0 0 ",b"MG ROW 0 9 ",b,count=1)
    if not n: assert name=="mg2";b=b.replace(b"M FINISHED BEFORE IRQ",b"CORRUPT DIAGNOSTIC")
    f.write_bytes(b);s=sess/"session.json";j=json.loads(s.read_text());j["hashes"][f.name]=sha(f);s.write_text(json.dumps(j))
    r=subprocess.run(["python3","source/tools/pi4_migration_replay.py",d,"1",sha(s)],text=True,capture_output=True)
    assert r.returncode and "invalid or incomplete evidence" in r.stdout,(r.stdout,r.stderr)
    (d/"reject.log").write_text(r.stdout+r.stderr);print(name,r.stdout.strip())