set -eu
D=$(pwd)
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
python3 source/tools/pi4_smp_replay.py controls/sw1-bounded "$(sha256sum controls/sw1-bounded/session.json | cut -c1-64)" > controls/sw1-reopened.log
mkdir -p historical/mg3
unzip -oq source/docs/evidence/pi4-migration-local-first.zip 'frozen/*' -d historical/mg3
for d in historical/mg3/frozen/*; do for i in 1 2; do
 python3 source/tools/pi4_migration_replay.py "$d" "$i" "$(sha256sum "$d/first-$i/session.json" | cut -c1-64)" > "controls/mg3-$(basename "$d")-$i.log" || true
done; done
for f in source/tools/test_pi4_{mg2_gic,mg2_sparse,mg2_terminal,mg3_freeze,mg3_replay,stream_v1}.py; do python3 "$f" > "controls/$(basename "$f").log" 2>&1; done