"""Independent replay of a sealed #397 cohort. Writes only to the output directory."""
import argparse
import copy
import csv
import hashlib
import json
import tarfile
from pathlib import Path

from decode import read_run
from score import evaluate


def save(path,obj):
    path.write_text(json.dumps(obj,sort_keys=True,indent=1)+"\n",encoding="utf8")


def mutations(records):
    trials=[]
    def check(case,name,alter,required):
        data=copy.deepcopy(records[("fifo",case)])
        alter(data)
        dropped=[k for k,v in evaluate(data)["tests"].items() if not v]
        if required not in dropped:
            raise ValueError("replay accepted perturbation: "+name)
        trials.append(dict(case=case,change=name,required_failed_check=required,all_failed_checks=dropped))
    check("recover-latch","remove real expiry",lambda a:a.update(events=[e for e in a["events"] if e[0]!=3]),"gen1 live seq3 and actual expiry before gen2 open")
    check("recover-hold","omit kind2 fall",lambda a:a.update(events=[e for e in a["events"] if e[0]!=2 or e[5]!=0]),"every expected output edge in order")
    check("recover-latch","forge command issuer",lambda a:next(e for e in a["events"] if e[0]==5 and e[2:7]==[2,59,2,0,2]).__setitem__(2,0),"distinct later command and consumption while both permits fresh")
    check("recover-hold","one safety record dropped",lambda a:a.update(safety_loss=[[1]]),"complete safety trace")
    check("recover-latch","alter actual received CRC",lambda a:a["received_bytes"].__setitem__(0,"00"*44),"all ordinary 44-byte inputs and original private commits")
    return trials


def blob_hash(data):
    return hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()


def source_check(root):
    source=root/"source"
    expected={line.split("\t",1)[1]:line.split()[2] for line in (source/"tree.txt").read_text().splitlines()}
    found={}
    with tarfile.open(source/"production.tar") as archive:
        for item in archive.getmembers():
            if item.isfile(): found[item.name]=blob_hash(archive.extractfile(item).read())
            elif item.issym(): found[item.name]=blob_hash(item.linkname.encode())
    if found!=expected:
        raise ValueError("archived production source differs from frozen Git blobs")
    complete=(source/"complete-tree.txt").read_text().splitlines()
    if not set((source/"tree.txt").read_text().splitlines()).issubset(complete):
        raise ValueError("build inputs are absent from the complete recursive tree")
    from collections import defaultdict
    tree={}
    for line in complete:
        left,name=line.split("\t",1); mode,kind,obj=left.split()
        tree[name]=(mode,bytes.fromhex(obj))
    while any("/" in name for name in tree):
        maximum=max(name.count("/") for name in tree)
        groups=defaultdict(dict)
        for name in list(tree):
            if name.count("/")==maximum:
                parent,leaf=name.rsplit("/",1)
                groups[parent][leaf]=tree.pop(name)
        for parent,items in groups.items():
            tree[parent]=("40000",git_tree(items))
    tree_sha=git_tree(tree).hex()
    for sha in ("e2328a76ead53df8cc34287cab74050265ce08f6","088d94a412a9420723a6a98e7918ccc1751ba396"):
        raw=(source/(sha+".commit")).read_bytes()
        actual=hashlib.sha1(b"commit "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
        if actual!=sha or raw.splitlines()[0]!=b"tree "+tree_sha.encode():
            raise ValueError("source identity mismatch "+sha)
    return tree_sha


def git_tree(items):
    order=sorted(items,key=lambda n:(n+("/" if items[n][0]=="40000" else "")).encode())
    raw=b"".join(items[n][0].encode()+b" "+n.encode()+b"\0"+items[n][1] for n in order)
    return hashlib.sha1(b"tree "+str(len(raw)).encode()+b"\0"+raw).digest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("root",type=Path)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    root=args.root.resolve(); out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=True); (out/"decoded").mkdir(exist_ok=True)
    tree=source_check(root)
    records={}; scores=[]; retired=[]
    with (root/"ledger.tsv").open() as f:
        ledger=list(csv.DictReader(f,delimiter="\t"))
    cases=["recover-latch","recover-hold","restart"]
    if [(x["policy"],x["case"]) for x in ledger]!=[(p,c) for p in ("fifo","rr") for c in cases]:
        raise ValueError("incomplete first-attempt ledger")
    for row in ledger:
        tag=f'{int(row["ordinal"]):02d}-{row["policy"]}-{row["case"]}'
        run=root/"runs"/tag
        if row["build"]!="0" or row["capture"]!="0":
            retired.append(tag)
        try:
            data=read_run(root,run); summary=evaluate(data)
            if data["revision"]!="e2328a76ead53df8cc34287cab74050265ce08f6":
                raise ValueError("unexpected capture revision")
            save(out/"decoded"/(tag+".json"),data)
            records[(row["policy"],row["case"])]=data
            summary["name"]=tag
            scores.append(summary)
        except Exception as err:
            scores.append(dict(name=tag,error=repr(err),tests={"raw decode succeeded":False}))
    save(out/"by-boot.json",scores)
    rejected=sorted(set(retired+[s["name"] for s in scores if not all(s["tests"].values())]))
    if rejected:
        raise SystemExit("REPLAY FAILED: "+", ".join(rejected))
    trials=mutations(records)
    save(out/"mutation-tests.json",trials)
    print(f"{len(scores)} original boots verified; {len(trials)} replay mutations rejected; source tree {tree}")


if __name__=="__main__":
    main()
