"""Read protected UART and each process's ELF symbols through its own saved TTBR."""
import functools
import hashlib
import json
import re
import struct
import subprocess
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


@functools.lru_cache(maxsize=64)
def symtab(path):
    text = subprocess.check_output(["aarch64-linux-gnu-nm", "-CS", "--defined-only", str(path)], text=True)
    result = {}
    for line in text.splitlines():
        fields = line.split(None, 3)
        if len(fields) == 4:
            result[fields[3]] = tuple(int(v, 16) for v in fields[:2])
    return result


def grouped(values, width):
    if len(values) % width:
        raise ValueError("incomplete row")
    return [values[i:i+width] for i in range(0, len(values), width)]


def read_run(root, run):
    _, policy, case = run.name.split("-", 2)
    cap = run / "cap"
    receipt = json.loads((cap / "session.json").read_text())
    launch = json.loads((cap / "launch.json").read_text())
    manifest = json.loads((run / "manifest.json").read_text())
    lines = (cap / "uart.bin").read_text().splitlines()
    def rows(tag):
        return [list(map(int, line[len(tag)+1:].split())) for line in lines if line.startswith(tag+" ")]
    elf = cap / "kernel.elf"
    apps = [root / "apps" / (n + ".elf") for n in ("sender", "receiver", "supervisor")]
    symbols = symtab(elf)
    base, size = symbols["jnox_kernel::native_el0_mmu::SPACES"]
    if size % (4096*3) or base % 4096:
        raise ValueError("unexpected address-space array")
    roots = [base + pid * (size // 3) for pid in range(3)]
    ram = (cap / "ram.bin").read_bytes()
    def physical(pa, count):
        i = pa - launch["ram_base"]
        if not 0 <= i <= len(ram)-count:
            raise ValueError("physical address outside dump")
        return ram[i:i+count]
    def data(pid, name):
        va, length = symtab(apps[pid])["safety_"+name]
        data = bytearray()
        while len(data) < length:
            cur = va + len(data)
            page = roots[pid]
            for shift in (30,21,12):
                descriptor = int.from_bytes(physical(page+8*((cur>>shift)&511),8), "little")
                if descriptor & 3 != 3:
                    raise ValueError("unmapped private data " + name)
                page = descriptor & 0x0000fffffffff000
            offset = cur % 4096
            data.extend(physical(page+offset, min(length-len(data),4096-offset)))
        return bytes(data)
    def words(pid,name):
        return [v[0] for v in struct.iter_unpack("<Q",data(pid,name))]
    result = dict(policy=policy, case=case, revision=launch["revision"], marker=receipt["marker"],
                  session_hash=digest(cap/"session.json"), roots=roots, kernel=digest(elf), qemu=launch["qemu_sha256"],
                  app_hashes=[digest(p) for p in apps], exits=rows("NATIVE EL0 EXIT PID"),
                  safety_loss=rows("NATIVE SAFETY DROPPED"), fixed_loss=rows("NATIVE FIXED DROPPED"),
                  events=rows("NATIVE SAFETY EVENT"),terminal=int.from_bytes(physical(symbols["jnox_virtual_permit_enable"][0],8),"little"))
    tests = {}
    def test(label, verdict):
        tests[label] = bool(verdict)
    test("capture manifest and file digests",set(receipt["hashes"]) == {"kernel.elf","launch.json","probe.c","ram.bin","stderr","uart.bin","user.elf"} and all(digest(cap/n)==h for n,h in receipt["hashes"].items()))
    test("stock QEMU without icount or tracing", launch["qemu_sha256"] == "0a63468782d096485932acf6aa0a69d358b3e3a6f68f655e960e9f5e3fc578d8" and launch["argv"][1:-4]==["-machine","virt,gic-version=2","-cpu","cortex-a72","-smp","1","-accel","tcg","-m","128M","-nodefaults","-display","none","-monitor","none","-no-reboot","-qmp","stdio"] and launch["argv"][-4::2]==["-serial","-kernel"])
    test("source and binary provenance", manifest==launch["argument_package"] and manifest["tracked_changes"]=="" and manifest["commit"]==launch["revision"] and manifest["kernel_elf_sha256"]==result["kernel"]==launch["kernel_sha256"] and digest(run/"kernel-build.log")==manifest["build_log_sha256"] and launch["ram_bytes"]==len(ram))
    test("guest ELF and packaged ELF hashes", result["app_hashes"]==[slot["elf_sha256"] for slot in manifest["slots"]]==[line.split()[-1] for line in lines if re.match(r"^NATIVE EL0 (PEER2? )?ELF ",line)])
    test("ordinary profile and immutable selectors", manifest["board"]=="virt" and manifest["profile"]=="native" and manifest["policy"]==policy and manifest["quantum_ticks"]==(625000 if policy=="rr" else None) and [s["argv"][1:] for s in manifest["slots"]]==[[case]]*3 and [s["priority"] for s in manifest["slots"]]==[7,6,4] and manifest["loan_route"]=={"producer":0,"consumer":1} and manifest["ipc_routes"]==[{"caller":2,"server":0},{"caller":2,"server":1}] and manifest["safety_channel"]["validity_ms"]==20 and not manifest.get("safety_qualification") and not manifest.get("safety_watchdog"))
    for pid,name in enumerate(("sender","receiver","supervisor")):
        result[name+"_header"]=words(pid,name+"_header")
    for pid,name,count,width in ((0,"sender_rows","sender",11),(1,"activations","activation",19),(1,"received_rows","received",20),(1,"active_received","received",16),(2,"supervisor_rows","supervisor",16)):
        n=words(pid,count+"_count")[0]
        all_rows=grouped(words(pid,name),width)
        if n>len(all_rows): raise ValueError("invalid private count "+name)
        result[name]=all_rows[:n]
    for pid,name in ((0,"sender"),(1,"received")):
        n=words(pid,name+"_count")[0]
        result[name+"_bytes"]=[bytes(v).hex() for v in grouped(data(pid,name+"_bytes"),44)[:n]]
    result["active_ack"]=words(1,"active_ack")
    result["active_ipc"]=grouped(words(2,"active_ipc"),4)
    result["wrong_owner"]=words(2,"wrong_owner")
    result["provenance"]=tests
    return result
