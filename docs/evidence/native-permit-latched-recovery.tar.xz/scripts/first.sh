#!/usr/bin/env bash
set -euo pipefail
scripts=/mnt/d/codex/permit11-latched-first
rev=e2328a76ead53df8cc34287cab74050265ce08f6
bash "$scripts/lane.sh" checkout "$rev"
bash "$scripts/lane.sh" apps "$rev"
bash "$scripts/lane.sh" matrix "$rev"
