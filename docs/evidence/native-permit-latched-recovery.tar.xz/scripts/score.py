import struct, zlib
SKIP=1<<63

def evaluate(a):
    tests=dict(a["provenance"])
    def t(name,ok):
        tests[name]=bool(ok)
    c=a["case"]; ev=a["events"]; s=a["sender_rows"]; r=a["received_rows"]
    def event(k):
        return [v for v in ev if v[0]==k]
    def fresh(i,v):
        return 0<=(v-i)*1000<hz*20
    def on(tick):
        state=0
        for v in event(2):
            if v[2]<=tick<v[3]: return None
            if v[3]<=tick: state=v[5]
        return state
    def no_disruption(early,late):
        return not any(early<=v[1]<=late and
                       (v[0] in (2,3,4) or v[0]==5 and v[2:5]==[2,59,1] and v[5]==0)
                       for v in ev)
    def committed(v):
        return v[0]==5 and v[2:5]==[1,60,2]
    def exactly(rows,label):
        t(label,len(rows)==1)
        return rows[0] if rows else None
    sh=a["sender_header"];rh=a["receiver_header"];uh=a["supervisor_header"]
    epoch,hz=rh[2:4]
    out={"case":c,"policy":a["policy"],"tests":tests,"hz":hz,"epoch":epoch,"first_exits":a["exits"],
         "terminal":a["terminal"],"safety_loss":a["safety_loss"],"fixed_loss":a["fixed_loss"],
         "decision_codes":[v[5] for v in r], "kernel":a["kernel"],"session":a["session_hash"]}
    t("all three original exit codes",a["exits"]==[[0,71],[1,72],[2,73]] and a["marker"]=="EXIT 71")
    t("agreeing clocks, selectors and zero app errors",sh[:1]==[0x53465030] and rh[:1]==[0x53465031] and uh[:1]==[0x53465032] and sh[1:4]==rh[1:4]==uh[1:4] and sh[4:]==[0] and rh[4:]==uh[4:]==[0,0] and hz==62500000)
    t("complete safety trace",a["safety_loss"]==[[0]] and all(len(v)==10 for v in ev) and len(a["activations"])==len(event(10))>0)
    if len(a["activations"])==len(event(10)) and len(event(10))>1:
        spans=[(e[2]-v[0],e[3]-v[0]) for v,e in zip(a["activations"],event(10))]
        gaps=[(b[2]-v[3],b[3]-v[2]) for v,b in zip(event(10),event(10)[1:])]
        out["response_max"]=[max(v[i] for v in spans) for i in (0,1)]
        out["completion_gap_max"]=[max(v[i] for v in gaps) for i in (0,1)]
    t("terminal virtual output low",a["terminal"]==0)
    t("supervisor observations",bool(a["supervisor_rows"]) and all(v[15]==1 for v in a["supervisor_rows"]))
    # Validate the three copies using the actual grant ID, never a sequence-only match.
    sender={}
    for k,v in enumerate(s):
        if v[3]!=1 and v[8] and v[9:11]==[0,0]:
            sender[v[8]]=a["sender_bytes"][k]
    pub=event(11);rx=event(7)
    out["joins"]=[]
    for k,v in enumerate(r):
        handle=v[2];h=a["received_bytes"][k]
        records=[z for z in rx if z[2]==handle]
        pubs=[z for z in pub if z[4]==handle and z[5]==0]
        read=[z for z in event(6) if z[2:5]==[1,35,0] and z[7]==handle and z[8]==44]
        release=[z for z in event(6) if z[2:5]==[1,36,0] and z[6]==handle]
        booljoin=(v[4]==44 and v[3]==0x01600000+(handle&3)*4096 and (handle&3)<3 and sender.get(handle)==h
                  and len(records)==len(pubs)==len(read)==len(release)==1
                  and b"".join(q.to_bytes(8,"little") for q in records[0][4:])[:44].hex()==h
                  and pubs[0][3]<=records[0][1]<=read[0][1]<=release[0][1]<=v[7]<=v[8])
        out["joins"].append(booljoin)
    t("every received frame joins sender, kernel and receiver by handle and time",len(rx)==len(r)>0 and all(out["joins"]))
    commits=[v for v in ev if committed(v)]
    good=[v for v in r if v[5:7]==[0,0]]
    t("private and protected commit chronology",len(commits)==len(good) and all(v[7]<=k[1]<=v[8] and [v[9],v[16],v[17],v[19]]==k[6:10] and k[5]==0 for v,k in zip(good,commits)))
    t("all local rejections skip commit and preserve last accepted data",all(v[6]==SKIP and v[12:16]==v[16:20] and not any(v[7]<=k[1]<=v[8] for k in commits) for v in r if v[5]))
    expected = [(1,1,1), (1,2,1), (1,3,1)]
    if c == "restart":
        expected.extend([(1,4,0),(2,1,1),(2,2,1),(2,3,1),(2,4,0)])

    else:
        expected.extend([(2,1,1),(2,2,1)])
        if c == "recover-latch":
            expected.append((2,3,0))
    triples=[]
    valid_wire=True
    for v,h in zip(r,a["received_bytes"]):
        raw=bytes.fromhex(h)
        ver,typ,size,chan,did,g,seq,issue,life,permit,pad,crc=struct.unpack("<BBHHHQQQIB3sI",raw)
        valid_wire &= (ver,typ,size,chan,did,life,pad,crc)==(1,1,44,1,257,20,bytes(3),zlib.crc32(raw[:40]))
        if c=="restart" and v[5]==7 and g==1 and seq==1: continue
        valid_wire &= v[5:7]==[0,0] and [g,seq,issue,permit]==[v[9],v[16],v[17],v[18]] and fresh(issue,v[7])
        triples.append((g,seq,permit))
    t("all ordinary 44-byte inputs and original private commits",valid_wire and triples==expected)
    t("every expected output edge in order",[v[4:6] for v in event(2)]==([[0,1],[1,0]] if c=="recover-hold" else [[0,1],[1,0],[0,1],[1,0]]))
    commands=[v for v in event(5) if v[2:4]==[2,59]]
    opens=[v for v in commands if v[4:6]==[1,0]]
    t("two authenticated generation opens",[v[6] for v in opens]==[1,2])
    if len(opens)!=2 or len(good)!=len(expected): return out
    edges=event(2)
    seq3=good[2]
    pair=[v for v in good if v[9]==2][:2]
    t("gen2 pair issued 10ms apart",(pair[1][17]-pair[0][17])*1000==10*hz)
    out["timing"]={"response_ticks":[min(v[0] for v in spans),max(v[1] for v in spans)],"gap_ticks":[min(v[0] for v in gaps),max(v[1] for v in gaps)],"gap_bounds":gaps,"response_bounds":spans}
    if c=="restart": return out
    latches=[e for e in event(3) if seq3[8]<e[1]<opens[1][1]]
    t("gen1 live seq3 and actual expiry before gen2 open",on(seq3[8])==1 and len(latches)==1 and latches[0][3:6]==[1,3,seq3[17]] and (latches[0][2]-seq3[17])*1000>=20*hz and len(edges)>=2 and latches[0][1]<=edges[1][2]<=edges[1][3]<opens[1][1])
    sup=a["supervisor_rows"]
    gen2_open=[v for v in sup if v[3:6]==[1,2,0]]
    t("gen2 open clears protected prior state",len(gen2_open)==1 and opens[1][7:10]==[0,0,0] and gen2_open[0][8]==1 and gen2_open[0][10]==2 and gen2_open[0][12]==gen2_open[0][14]==0 and pair[0][12:16]==[0,0,0,0])
    rearm=[v for v in commands if v[4]==2 and v[6]==2]
    early=[v for v in rearm if pair[0][8]<=v[1]<pair[1][7] and v[5]!=0]
    t("early supervisor rearm refused and no pending request",len(early)==1 and any(v[3:5]==[2,2] and v[5]!=0 and v[1]<=early[0][1]<=v[2] and v[8]==1 and v[12]==1 for v in sup))
    t("pair committed low before subsequent command",pair[0][16:20]==[1,pair[0][17],1,1] and pair[1][16:20]==[2,pair[1][17],1,2] and pair[1][10]==1 and on(pair[1][8])==0)
    consume=[v for v in event(5) if v[2:7]==[1,60,4,0,2]]
    if c=="recover-hold":
        t("omission held to termination",len(rearm)==1 and not consume and all(e[5]==0 for e in edges[1:]))
    else:
        t("distinct later command and consumption while both permits fresh",len(rearm)==2 and rearm[1][5]==0 and len(consume)==1 and len(edges)==4 and pair[1][8]<rearm[1][1]<=edges[2][2]<=edges[2][3]<=consume[0][1] and all(fresh(v[17],consume[0][1]) for v in pair))
        withdrawal=good[-1]
        t("gen2 sequence three withdrawal at actual device",len(edges)==4 and withdrawal[7]<=edges[3][2]<=edges[3][3]<=withdrawal[8] and withdrawal[18:20]==[0,0])
    planned=lambda ms: epoch+hz*ms//1000
    actual_id=37 if c=="recover-latch" else 38
    t("frozen selector, epochs and original gen2 issue schedule",rh[1]==actual_id and seq3[17]==planned(20) and [v[17] for v in pair]==[planned(55),planned(65)])
    def observed(ms,flags,g,seq,issue):
        return any(v[0]==planned(ms) and v[3]==0 and v[7:15]==[flags,flags,g,g,seq,seq,planned(issue),planned(issue)] and v[1]>=v[0] for v in sup)
    t("independent supervisor observes live, latched, pair and final states",observed(23,3,1,3,20) and observed(48,5,1,3,20) and observed(68,1,2,2,65) and observed(73,3 if c=="recover-latch" else 1,2,2,65) and (observed(82,1,2,3,76) if c=="recover-latch" else observed(82,1,2,2,65)))
    t("private expiry and recovery activation",any(v[4]==1 and v[6]==1 and v[14:19]==[3,seq3[17],2,0,1] for v in a["activations"]) and any(v[4]==2 and v[14:19]==[2,pair[1][17],2,0,0] for v in a["activations"]))
    if c=="recover-latch":
        t("one live private and protected controller rearm",len([v for v in a["activations"] if v[4]==2 and v[9:11]==[0,0] and v[14:19]==[2,pair[1][17],2,1,0]])==1)
    out.update(edges=edges,opens=opens,gen1_expiry=latches,gen2_rearms=rearm,gen2_consume=consume)
    return out