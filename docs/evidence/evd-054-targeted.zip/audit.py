from pathlib import Path
import json,hashlib,io,tarfile,zipfile,struct,re,subprocess as sp,sys,collections
p=Path(__file__).resolve().parent;b=p.parent;src=b/'phase-proportional-release-pinned';docs=src/'docs/evidence';idx=json.loads((p/'index.json').read_bytes());phase=b/'phase131-integrated-gate';prop=b/'ordinary-136-integrated-gate'
def get(f):return json.loads(f.read_bytes())
def save(n,val):(p/n).write_text(json.dumps(val,indent=2)+'\n')
h=lambda data:hashlib.sha256(data).hexdigest()
def strict(a,b):return type(a)==type(b) and (a.keys()==b.keys() and all(strict(a[k],b[k]) for k in a) if isinstance(a,dict) else len(a)==len(b) and all(strict(x,y) for x,y in zip(a,b)) if isinstance(a,list) else a==b)
assert not strict(1,True)
def ledger(m,n):
 lines=m[n].decode().splitlines();pairs=[x.split(None,1) for x in lines];assert len(pairs)==len(set(x[1] for x in pairs)) and set(m)=={x[1] for x in pairs}|{n}
 for dig,name in pairs:assert name[0]!='/' and '..' not in Path(name).parts and h(m[name])==dig
def members(data,tar=False):
 if tar:
  with tarfile.open(fileobj=io.BytesIO(data)) as a:
   ns=a.getnames();assert all(x.isfile() for x in a.getmembers());m={n:a.extractfile(n).read() for n in ns}
 else:
  with zipfile.ZipFile(io.BytesIO(data)) as a:ns=a.namelist();m={n:a.read(n) for n in ns}
 assert len(ns)==len(m);return m
def selected(v,keys):return [{k:x[k] for k in keys} for x in v]
ags={};reuse=[];binary={}
for case,v in idx['images'].items():
 log=(p/case/'build.log').read_bytes();assert h(log)==v['log'] and (v['exit']==0)==v['expected_success'] and v['reason_found']
 if v['exit']:
  reason=re.search(rb'panicked at build.rs:\d+:\d+:\s*\r?\n\s*([^\r\n]+)',log).group(1).decode().strip().removeprefix('[jnox-kernel 0.1.0] ');assert reason in (src/'kernel/build.rs').read_text()
  ags[case]=reason;continue
 assert v['same_load'];cur=p/case/'kernel.elf';ref=b/v['reference'].replace(chr(92),'/');raw=cur.read_bytes();old=ref.read_bytes();assert h(old)==v['reference_sha'] and h(raw)==v['sha256'];assert raw[:16]==old[:16] and struct.unpack_from('<HHIQ',raw,16)==struct.unpack_from('<HHIQ',old,16)
 def interface(f):
  asm=sp.check_output(['aarch64-linux-gnu-objdump','-d',f],text=True)
  symbols=sp.check_output(['aarch64-linux-gnu-nm','-nS',f],text=True)
  def sel(pattern):
   return [(int(m[1],16),int(m[2],16)) for l in symbols.splitlines() if (m:=re.match(r'^([0-9a-f]+) ([0-9a-f]+) \w (.*)$',l)) and re.search(pattern,m[3])]
  return dict(entry=struct.unpack_from('<Q',f.read_bytes(),24)[0],vectors=sel(r'^sched_vectors$'),restore=sel(r'^sched_start_frame$'),stacks=sel(r'6STACKS17h'),eret=[m[1] for m in re.finditer(r'^\s*([0-9a-f]+):\s+[0-9a-f]+\s+eret\b',asm,re.M)],sp_frame_adjust=sorted(set(m[0].strip() for m in re.finditer(r'(?:sub|add)\s+sp, sp, #0x340',asm))))
 a=interface(cur);assert a==interface(ref) and a['vectors'] and a['restore'] and a['eret'] and a['stacks'] and a['sp_frame_adjust'] and bytes.fromhex('ff030dd1') in raw,(case,a,interface(ref))
 assert all(addr%16==0 and size%16384==0 for addr,size in a['stacks']);binary[case]=a
for code in ('054','055'):
 for suffix in ('','-integration'):
  name='evd-'+code+suffix;j=get(docs/(name+'.json'));spec=j['archive'];file=spec['file'] if isinstance(spec,dict) else spec;raw=(docs/file).read_bytes();digest=spec['sha256'] if isinstance(spec,dict) else j['archive_sha256'];assert h(raw)==digest and j['evidence_id']=='EVD-'+code
  if isinstance(spec,dict):assert strict(spec['bytes'],len(raw))
  m=members(raw)
  if 'FILES.sha256' in m:ledger(m,'FILES.sha256')
  if code=='054':
   tname=next(k for k in m if k.endswith('.tar.gz'));tar=m[tname];assert h(tar)==j['original_archive_sha256']
   if suffix:assert strict(j['original_archive_bytes'],len(tar))
   x=members(tar,True);ledger(x,'SHA256SUMS');manifest=x['SHA256SUMS'];assert h(manifest)==j.get('manifest_sha256',j.get('reviewer_manifest_sha256'));rs=json.loads(x['results.json']);frozen=json.loads(x['freeze.json'])['positions'];assert [v['id'] for v in rs]==[v['id'] for v in frozen]
   hashes=j['original_records'] if suffix else j['inputs_and_outcomes_sha256'];assert all(h(x[k])==v for k,v in hashes.items())
   assert strict(j['positions'],selected(rs,j['positions'][0].keys()))
   op=[r for r in rs if r['id'].startswith('operational')];off=[r for r in rs if r['id'].startswith('characterization')];assert strict(j['operational_healthy'],sum(r['terminal'][1]!=0 for r in op)) and strict(j['operational_positions'],len(op)) and strict(j['off_icount_completed'],sum('icount' in r['id'] and r['disposition']=='observed-full-phase-horizon' for r in off))
   assert strict(j.get('off_default_stopped',j.get('off_default_early_stops')),sum('default' in r['id'] and r['disposition']=='observed-early-stop' for r in off))
   if suffix:
    assert strict(j['manifest_entries'],len(manifest.splitlines())) and j['source']=='2adccb563a525863e0f56c82703852082f5bc709' and strict(j['strict_findings'],[])
    for z in frozen:
     case=z['key'];d='raw/'+z['id']+'/';r=json.loads(x[d+'runner.json']);assert z['elf']==idx['images'][case]['reference_sha'] and all(h(x[d+k])==v for k,v in r['files'].items())
     reuse.append(dict(position=z['id'],case=case,source=j['source'],elf=z['elf'],candidate=idx['images'][case]['sha256'],launch=z['argv'],clock=z['clock'],raw=r['files'],archive=digest,guest='historical'))
   else:
    counts=dict(operational_a1_a2_refused=sum(r['disposition']=='refused-before-workers' for r in op),operational_a0_faulted=sum(not r['arm'] and bool(r['latch']) for r in op),off_icount_accepted_permits=sum(r['accepted'] for r in off if 'icount' in r['id']),positive_device_edges=sum(r['device']['bit0_output_notifications'].count('1') for r in rs))
    assert all(strict(j[k],v) for k,v in counts.items())
  else:
   vkey='reviewer_report' if suffix else 'measurement';vn='verification.json' if suffix else 'ordinary-136-first-three/verification.json';v=json.loads(m[vn]);assert strict(v,j[vkey]) and h(m[vn])==j['reviewer_report_sha256' if suffix else 'verifier_sha256'];assert strict(len(m)-1,j['archive_files']) if suffix else strict(len(m),spec['entries'])
   if suffix:
    assert v['source']=='589e927bdc2e21ed68de1315d030d6231d18bacb' and v['audit']['findings']==[]
    for case,z in v['guests'].items():
     d='guests/'+case+'/';assert z['qualified'] is True and not z['findings'] and all(h(m[d+k])==val for k,val in z['hashes'].items()) and z['hashes']['kernel.elf']==idx['images'][case]['reference_sha']
     reuse.append(dict(case=case,source=v['source'],guest='historical',freeze=v['freeze_sha'],launch_script=v['launch_sha'],elf=z['hashes']['kernel.elf'],candidate=idx['images'][case]['sha256'],raw=z['hashes'],clock='default',archive=digest))
  print(name,len(m),digest,flush=True)
save('interfaces.json',binary);save('denials.json',ags);save('historical-runs.json',reuse)




