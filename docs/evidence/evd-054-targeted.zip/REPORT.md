# Final intersecting phase and proportional verification

Candidate 3b5a9f69034ecc2b7a7b093ddb786ee74f820be6, tree 0255fa8787fc9f4c86a5bd5416e397024d58ef71. All 65 release Cargo configurations were executed serially using Rust 1.95.0. All 21 admitted images matched their true integrated references across every executable loader input, including ELF entry point, flags, addresses, file/memory sizes, alignment, initialized bytes and implicit zero fill. Whole-file ELF hashes matched for 0/21. All 44 rejected configurations produced a specific build-script selector rejection. The pinned working tree remained clean.

| Reference | Fresh candidate builds | Historical boot records reused | New boots |
|---|---:|---|---:|
| Phase 2adccb56 | 10 | 32 separate operational and inhibited positions | 0 |
| Control comparison 2adccb56 | 8 | 8 matching baseline/marker/descriptor/cold boots; two additional mode-3 probe captures | 0 |
| Proportional 589e927b | 3 | lottery1, lottery2, stride with 32, 32 and 16 grants respectively | 0 |

Both linked interfaces have matching vector bases, restore entries, actual ERET instruction addresses, stack-array bounds and 832-byte frame allocation/restoration. Individual stacks retain 16-byte alignment and 16 KiB per task. The earlier exception traces, sender continuation evidence and proportional private-frame/continuation checks remain associated with their own run IDs. historical-runs.json binds each phase/proportional candidate to the earlier ELF and raw hashes. Control probes and their original healthy-checker failures remain recorded in results.json.

Strict evidence graph findings were empty, and all six graph tests passed. Both first and integrated EVD-054 and EVD-055 archive digests, typed result projections, member manifests and nested phase archives were checked. Source changes are recorded per reference in results.json. The virtual phase admission refusals, timing stops, observational limits and product qualification remain as previously reported. No fresh guest timing, intervention, board or positive output was observed in this final gate.
