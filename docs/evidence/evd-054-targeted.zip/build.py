from pathlib import Path
import hashlib,json,os,subprocess as sp,sys,shutil,struct
p=Path(__file__).resolve().parent;b=p.parent;src=Path(sys.argv[1]).resolve()
def git(*args):return sp.check_output(['git',*args],cwd=src,text=True).strip()
tree='0255fa8787fc9f4c86a5bd5416e397024d58ef71'
assert git('rev-parse','HEAD^{tree}')==tree and not git('status','--porcelain')
assert sp.run(['git','symbolic-ref','-q','HEAD'],cwd=src,stdout=sp.DEVNULL).returncode==1
load=lambda f:json.loads(f.read_bytes())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
phase=b/'phase131-integrated-gate';prop=b/'ordinary-136-integrated-gate';cases={}
phaseidx=load(phase/'builds.json');reg=load(phase/'reg-builds.json');pr=load(prop/'index.json')
assert load(phase/'plan.json')['commit']=='2adccb563a525863e0f56c82703852082f5bc709' and pr['revision']=='589e927bdc2e21ed68de1315d030d6231d18bacb'
args=['cargo','+1.95.0','build','--release','--locked','-j1','-vv']
for k,v in phaseidx.items():cases[k]=(v['env'],args,phase/k/'kernel.elf' if v['exit']==0 else None,v.get('elf'),None)
for k,v in reg.items():
 if k.startswith(('markers-','denied-')):cases[k]=(v['env'],args,phase/'reg'/k/'kernel.elf' if v['valid'] else None,v.get('elf'),None)
for k,v in pr['images'].items():
 if k.startswith('markers-'):continue
 cases[k]=(v['env'],v['argv'],prop/k/'kernel.elf' if v['exit']==0 else None,v.get('sha256'),v.get('expected_error'))
for app in ('lottery1','lottery2','stride'):
 for ext,edit in [('case',{'JNOX_CONTROL_CASE':'healthy'}),('nominal',{'JNOX_PERMIT_PHASE':'nominal'}),('anchor-descriptor',{'JNOX_PERMIT_PHASE':'anchor','JNOX_CONTROL_DESCRIPTOR':'1'}),('marker',{'JNOX_CONTROL_MARKERS':'1'}),('cold',{'JNOX_CONTROL_COLD':'diagnostic'})]:
  cases['cross-'+app+'-'+ext]=(dict(pr['images'][app]['env'],**edit),args,None,None,None)
def seg(f):
 raw=f.read_bytes();begin=struct.unpack_from('<Q',raw,32)[0];step,num=struct.unpack_from('<HH',raw,54);v=[]
 for i in range(num):
  k,flags,off,va,pa,fs,ms,align=struct.unpack_from('<II6Q',raw,begin+i*step)
  if k==1:v.append(((flags,va,pa,fs,ms,align),raw[off:off+fs]))
 return v
info=dict(head=git('rev-parse','HEAD'),tree=tree,rust=sp.check_output(['rustc','+1.95.0','-vV'],text=True),images={})
for k,(opts,cmd,ref,digest,err) in cases.items():
 d=p/k;d.mkdir();env={a:v for a,v in os.environ.items() if not a.startswith(('JNOX_','RUST','CARGO_TARGET_','CARGO_PROFILE_')) and a!='CARGO_ENCODED_RUSTFLAGS'};opts={a:v for a,v in opts.items() if a.startswith('JNOX_')}
 env.update(opts,CARGO_TARGET_DIR=str(p/'target'),CARGO_BUILD_JOBS='1',TEMP=str(d),TMP=str(d));r=sp.run(cmd,cwd=src/'kernel',env=env,capture_output=True);log=d/'build.log';log.write_bytes(r.stdout+r.stderr)
 v=info['images'][k]=dict(env=opts,command=cmd,exit=r.returncode,expected_success=bool(ref),expected_reason=err,reason_found=not err or err.encode() in log.read_bytes(),log=sha(log))
 if r.returncode==0:
  elf=d/'kernel.elf';shutil.copy2(p/'target/aarch64-unknown-none/release/jnox-kernel',elf);v['sha256']=sha(elf)
  if ref:
   assert sha(ref)==digest;ss,tt=seg(ref),seg(elf);v.update(reference=str(ref.relative_to(b)),reference_sha=digest,same_load=ss==tt,reference_segments=[(lo,hashlib.sha256(raw).hexdigest()) for lo,raw in ss],candidate_segments=[(lo,hashlib.sha256(raw).hexdigest()) for lo,raw in tt])
 (p/'index.json').write_text(json.dumps(info,indent=2));print(k,r.returncode,v.get('same_load'),flush=True)

