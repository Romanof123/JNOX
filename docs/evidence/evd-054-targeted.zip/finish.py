from pathlib import Path
import json,hashlib,subprocess as sp,zipfile,collections
p=Path(__file__).resolve().parent;b=p.parent;src=b/'phase-proportional-release-pinned';phase=b/'phase131-integrated-gate';prop=b/'ordinary-136-integrated-gate'
get=lambda f:json.loads(f.read_bytes())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def git(*args):return sp.check_output(['git',*args],cwd=src,text=True).strip()
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');assert head=='3b5a9f69034ecc2b7a7b093ddb786ee74f820be6' and tree=='0255fa8787fc9f4c86a5bd5416e397024d58ef71' and git('status','--porcelain')==''
idx=get(p/'index.json')['images'];refs=get(p/'historical-runs.json');controls={}
for k,v in get(phase/'boots.json').items():
 assert v['elf']==idx[k]['reference_sha'] and v['terminal'];d=phase/'reg'/k/'guest';controls[k]={'argv':v['argv'],'uart':sha(d/'uart'),'score':get(d/'score.stdout')['failures'],'marker_exit':v.get('marker_exit'),'cold_fixed_no_probe':v.get('cold_fixed_no_probe')}
for k,v in get(phase/'probes.json').items():
 assert v['elf']==idx[k]['reference_sha'] and v['probe_acked_clear'];controls[k]['mode3_uart']=sha(phase/'reg'/k/'probe-guest/uart')
source={}
for ref in ['2adccb563a525863e0f56c82703852082f5bc709','589e927bdc2e21ed68de1315d030d6231d18bacb']:
 paths=git('diff','--name-only',ref,head,'--','kernel').splitlines()
 source[ref]={n:{'candidate_git_blob':git('rev-parse',head+':'+n),'candidate_sha':sha(src/n)} for n in paths}
g=get(p/'graph.json');assert g['findings']==[] and len(refs)==35 and len(get(p/'denials.json'))==44 and len(get(p/'interfaces.json'))==21
whole=sum(v['sha256']==v['reference_sha'] for v in idx.values() if v['expected_success'])
result=dict(head=head,tree=tree,accepted=21,rejected=44,same_load=21,same_whole_elf=whole,current_boots=0,reused_phase_positions=32,reused_normal_proportional_boots=3,reused_control_boots=controls,source_deltas=source,evidence_graph={k:g['evidence'][k] for k in ['EVD-054','EVD-055']},archive_hashes={f.name:sha(f) for f in (src/'docs/evidence').glob('evd-05[45]*.zip')},scope='Host builds and static validation on final tree. All guest execution is attributed to prior frozen artifacts.')
(p/'results.json').write_text(json.dumps(result,indent=2)+'\n')
(p/'REPORT.md').write_text(f"""# Final intersecting phase and proportional verification

Candidate {head}, tree {tree}. All 65 release Cargo configurations were executed serially using Rust 1.95.0. All 21 admitted images matched their true integrated references across every executable loader input, including ELF entry point, flags, addresses, file/memory sizes, alignment, initialized bytes and implicit zero fill. Whole-file ELF hashes matched for {whole}/21. All 44 rejected configurations produced a specific build-script selector rejection. The pinned working tree remained clean.

| Reference | Fresh candidate builds | Historical boot records reused | New boots |
|---|---:|---|---:|
| Phase 2adccb56 | 10 | 32 separate operational and inhibited positions | 0 |
| Control comparison 2adccb56 | 8 | 8 matching baseline/marker/descriptor/cold boots; two additional mode-3 probe captures | 0 |
| Proportional 589e927b | 3 | lottery1, lottery2, stride with 32, 32 and 16 grants respectively | 0 |

Both linked interfaces have matching vector bases, restore entries, actual ERET instruction addresses, stack-array bounds and 832-byte frame allocation/restoration. Individual stacks retain 16-byte alignment and 16 KiB per task. The earlier exception traces, sender continuation evidence and proportional private-frame/continuation checks remain associated with their own run IDs. historical-runs.json binds each phase/proportional candidate to the earlier ELF and raw hashes. Control probes and their original healthy-checker failures remain recorded in results.json.

Strict evidence graph findings were empty, and all six graph tests passed. Both first and integrated EVD-054 and EVD-055 archive digests, typed result projections, member manifests and nested phase archives were checked. Source changes are recorded per reference in results.json. The virtual phase admission refusals, timing stops, observational limits and product qualification remain as previously reported. No fresh guest timing, intervention, board or positive output was observed in this final gate.
""",encoding='utf-8')
files=sorted([*p.glob('*.py'),*p.glob('*.json'),*p.glob('*.md'),*p.glob('*.txt'),*p.glob('*.log'),*p.glob('*/build.log'),*p.glob('*/kernel.elf')]);manifest=p/'SHA256SUMS';manifest.write_text(''.join(sha(f)+'  '+f.relative_to(p).as_posix()+'\n' for f in files));archive=p/'final-gate.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files+[manifest]:z.write(f,f.relative_to(p).as_posix())
with zipfile.ZipFile(archive) as z:
 assert all(hashlib.sha256(z.read(f.relative_to(p).as_posix())).hexdigest()==sha(f) for f in files)
(p/'archive.sha256').write_text(sha(archive)+'  final-gate.zip\n');print(whole,len(files),archive.stat().st_size,sha(archive))
