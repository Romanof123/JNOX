import os,sys,json
from pathlib import Path
from argparse import Namespace,ArgumentParser
sys.path.insert(0,str(Path.home()/'verify309/source/tools'))
from build_native_el0 import native_schedule
base=dict(elf='client',source=None,peer_elf=[],policy=[],priority=[],peer_priority=[],weight=[],peer_weight=[],job=[],peer_job=[],periodic=[],peer_periodic=[],reservation=[],peer_reservation=[],quantum_ticks=[],primary_class=[],peer_class=[],allotment_ticks=[],boost_ticks=[])
out=[]
for p,fields in [(None,{}),('rr',dict(priority=[4],quantum_ticks=['625000'])),('fifo',dict(priority=[4])),('weighted',dict(weight=[2],quantum_ticks=['625000'])),('edf',dict(job=[(0,1,1)])),('llf',dict(job=[(0,1,1)])),('cbs',dict(reservation=[(1,2)])),('rm',dict(periodic=[(0,10,10)])),('dm',dict(periodic=[(0,10,10)]))]:
 args=base|fields|dict(policy=[p] if p else [])
 result=native_schedule(ArgumentParser(),Namespace(**args));assert result[0]==p;out.append([p,result])
Path('legacy.json').write_text(json.dumps(out,indent=2))
