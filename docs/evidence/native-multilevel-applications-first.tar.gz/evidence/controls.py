import subprocess as s,os,json,hashlib
from pathlib import Path
D=Path.cwd();src=D.parent/'source'; f=D/'elf/report.elf';env=dict(os.environ); tool=Path.home()/'jnox-169-first-e203caa';env.update(RUSTUP_HOME=str(tool/'rustup'),CARGO_HOME=str(tool/'cargo'),PATH=str(tool/'cargo/bin')+':'+env['PATH'])
e=dict(JNOX_ARCH='aarch64',JNOX_BOARD='virt',JNOX_PROFILE='native',JNOX_APP='process',JNOX_NATIVE_ELF=str(f),JNOX_NATIVE_ELF_SHA256=hashlib.sha256(f.read_bytes()).hexdigest(),CARGO_TARGET_DIR=str(D.parent/'raw-target'))
out=[]
def cmd(kind,name,argv,cwd,en,want):
 p=s.run(argv,cwd=cwd,env=en,stdout=s.PIPE,stderr=s.STDOUT,text=True);(D/'controls'/name).write_text(p.stdout);out.append([kind,name,p.returncode,(p.returncode==0)==want]);(D/'controls.json').write_text(json.dumps(out,indent=2))
(D/'controls').mkdir()
mlq='--policy mlq --class 7 --quantum-ticks 625000';mlfq='--policy mlfq --allotment-ticks 625000,1250000,2500000 --boost-ticks 6250000'
for name,args in {'missing':'--policy mlq --quantum-ticks 1','range':mlq.replace('class 7','class 256'),'repeat-class':mlq+' --class 7','mixed':mlq+' --boost-ticks 3','bad-digits':mlq.replace('625000','+1'),'duplicate':mlfq+' --boost-ticks 4','arity':mlfq.replace(',2500000',''),'overflow':mlfq.replace('6250000','9223372036854775808'),'zero':mlfq.replace('625000,','0,'),'startup':mlq,'fourth':mlq+(' --peer-elf '+str(f)+' --peer-class 1')*3}.items():
 cmd('CLI',name,['python3','tools/build_native_el0.py','--out',str(D.parent/('invalid-'+name))]+([] if name=='startup' else ['--elf',str(f)])+args.split(),src,env,False)
q=dict(POLICY='mlq',CLASSES='7',QUANTUM_TICKS='1');fb=dict(POLICY='mlfq',ALLOTMENT_TICKS='1,2,3',BOOST_TICKS='4')
for name,vs in {'valid':q,'missing':dict(POLICY='mlq',QUANTUM_TICKS='1'),'range':q|dict(CLASSES='256'),'extra':q|dict(CLASSES='1,2'),'mixed':q|dict(BOOST_TICKS='3'),'digits':fb|dict(BOOST_TICKS='+1'),'arity':fb|dict(ALLOTMENT_TICKS='1,2'),'zero':fb|dict(ALLOTMENT_TICKS='1,0,2'),'overflow':fb|dict(BOOST_TICKS=str(2**63)),'fourth':q|dict(PEER3_ELF=str(f)),'startup':q}.items():
 en=env|e|{'JNOX_NATIVE_'+k:v for k,v in vs.items()}
 if name=='startup':en['JNOX_APP']='startup-probe'
 cmd('raw','raw-'+name,['cargo','build','--locked','--release','-j1','--target','aarch64-unknown-none'],src/'kernel',en,name=='valid')
cmd('host','host-build',['rustc','--edition=2021','--test','tools/scheduling_tests.rs','-o',str(D.parent/'tests')],src,env,True)
if (D.parent/'tests').exists():cmd('host','host-tests',[str(D.parent/'tests')],src,env,True)
