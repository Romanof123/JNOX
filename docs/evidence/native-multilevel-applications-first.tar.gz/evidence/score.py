import json,re,zlib,struct,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text())
def order(q):return int('0'+''.join(hex(i+1)[2:] for i in q),16)
def check(r):
 uart=(r/'uart.log').read_text(); data=load(r/'terminal.json'); n=len(data); fb='MLFQ' in uart; NA=2**64-1; apps=[]; outputs=[]
 for i,d in enumerate(data):
  app=d['app'];apps.append(app);fields=d['fields']
  def v(k,w=0):
   b=bytes.fromhex(fields[k]['hex'])
   return int.from_bytes(b,'little') if not w else [int.from_bytes(b[j:j+w],'little') for j in range(0,len(b),w)]
  N=v('private_blocks');B=v('private_bytes');assert 0<N<=1048576 and B==4096*N
  x=v('private_result',8) if app=='histogram' else v('private_result')
  if app=='crc':
   crc=0
   for _ in range(N):crc=zlib.crc32(bytes(range(256))*16,crc)
   assert crc==x
  if app=='histogram':assert x==[256*N]*16
  if app=='report':assert N==3 and v('round_count',4)==[256]*3 and v('cumulative_count',4)==[256,512,768] and all(a>=b for a,b in zip(v('observed_ns',8),v('request_ns',8))) and x==768
  if app=='yield':assert N==16384 and x==4194304
  exit=int(re.search(r'NATIVE EL0 EXIT '+(f'PID {i} ' if n>1 else '')+r'(-?\d+)',uart)[1]);assert exit==dict(crc=17,histogram=29,report=53,**{'yield':59})[app]
  outputs.append([app,N,B,x,exit])
 m=load(D/(r.name.split('.')[0]+'-manifest.json')); assert m['commit']==load(D/'freeze.json')['sha'] and m['timing_unit']=='physical_counter_ticks'
 for a,s in zip(apps,m['slots']):assert hashlib.sha256((D/'elf'/(a+'.elf')).read_bytes()).hexdigest()==s['elf_sha256']
 rows=[list(map(int,l.split()[3:])) for l in uart.splitlines() if ' EVENT ' in l]; drop=int(re.search(r'DROPPED (\d+)',uart)[1])
 classes=[int(t) for t in re.findall(r' JOB \d+ (\d+)',uart)]; rank=[2]*n if fb else classes; left=[625000]*n; grants=[2500000,1250000,625000]
 q=list(range(n)); sleepers={};svc=[0]*n;boost=0;exited=0;owner=NA; saved={};frames={};restores=[]; wake=[];dem=[];idle=0;multi=[];tie=[];resets=[];yield_series=[0]*n
 for j,row in enumerate(rows):
  reason,t,old,new,start,elapsed=row[:6]; assert len(row)==56 and old==owner and row[21]==order(q)
  assert row[38:38+n]==rank and row[41:41+n]==left
  if j:
   pr=rows[j-1]; assert row[4]==pr[11] and row[6:11]==[pr[12],pr[13],pr[14],pr[15],pr[16]]
  if reason==4:assert t>=row[10] and row[10]>0
  if row[10] and sum(k==row[10] for k in row[7:10])>1:tie.append(j)
  due=sorted((s,i) for i,s in sleepers.items() if s<=t);assert row[17]==order([i for _,i in due])
  for _,i in due:q.append(i);del sleepers[i]
  if old!=NA:
   assert elapsed==t-start and elapsed>=0;saved[old]=tuple(row[24:26]);svc[old]+=elapsed
   if reason==2:sleepers[old]=row[30]
   if reason==3:exited|=1<<old
   if reason not in (2,3):q.append(old)
   if fb:
    rank0=rank[old];yield_series[old]+=reason==1
    delta=elapsed
    while delta>=left[old]:
     delta-=left[old];rank[old]=max(0,rank[old]-1);left[old]=grants[rank[old]]
    left[old]-=delta
    if rank0>rank[old]:dem.append([j,old,rank0,rank[old],yield_series[old],reason])
    if rank0-rank[old]>=2:multi.append(j)
  else:assert elapsed==0
  assert row[44:44+n]==rank and row[47:47+n]==left and row[22]==order(q) and row[31]==exited
  assert row[32:32+n]==svc and row[18]==sum(svc) and row[35:35+n]==[sleepers.get(i,0) for i in range(n)]
  if fb:
   crosses=sum(svc)//6250000-boost;assert row[19]==crosses;boost+=crosses
   if crosses:resets.append([j,crosses,list(sleepers)]);rank=[2]*n;left=[625000]*n;yield_series=[0]*n
   assert row[20]==(boost+1)*6250000
  assert row[50:50+n]==rank and row[53:53+n]==left
  pick=max(q,key=lambda i:rank[i]) if q else NA;assert new==pick
  if q:
   q.remove(pick); assert row[12]==left[pick] and row[13]==row[11]+left[pick] and row[11]>=t
   assert row[14]==(row[11]+row[20]-sum(svc) if fb else 0)
   assert row[16]==min(x for x in row[13:16] if x)
   assert tuple(row[26:28])==saved.get(pick,(4194304,16846768))
   assert frames.setdefault(pick,row[29])==row[29];restores.append(row[26])
  else:
   assert row[16]==min(sleepers.values(),default=0);idle+=bool(sleepers)
  if old!=NA:assert row[28]==frames[old]
  assert row[23]==order(q)
  if due:wake.append(dict(row=j,old=old,new=new,delta=t-due[0][0],wake_only=reason==4 and row[9]==row[10] and all(not x or t<x for x in row[7:9]),higher=old!=NA and new!=NA and rank[new]>rank[old],to_restore=row[11]-due[0][0] if row[11] else None))
  owner=pick
 full=list(map(int,re.search(r' SERVICE ([0-9 ]+)',uart)[1].split()))
 if drop:assert len(rows)==512 and all(a<=b for a,b in zip(svc,full))
 else:assert svc==full and exited==(1<<n)-1 and owner==NA
 if (r/'exceptions.log').exists():
  raw=(r/'exceptions.log').read_text();returns=[int(x,16) for x in re.findall(r'Exception return from AArch64 EL1 to AArch64 EL0 PC 0x([a-f0-9]+)',raw)]
  # Match both actual entry and next ERET as adjacent EL0 exception transactions.
  pat=r'Taking exception \d+ \[(IRQ|SVC)\]\n\.\.\.from EL0 to EL1\n.*?\.\.\.with ELR 0x([a-f0-9]+)\n[^\n]*\nException return from AArch64 EL1 to AArch64 EL0 PC 0x([a-f0-9]+)'
  pairs=[(a,int(b,16),int(c,16)) for a,b,c in re.findall(pat,raw,re.S)]
  k=0
  for row in rows:
   if row[2]==NA or row[3]==NA:continue
   target=('IRQ' if row[0]==4 else 'SVC',row[24],row[26])
   while k<len(pairs) and pairs[k]!=target:k+=1
   assert k<len(pairs),(r,j,target);k+=1
 if r.name=='three':
  assert [v[3] for v in rows[:3]]==[0,1,0] and all(v[3]!=2 for v in rows if v[31]&3!=3)
 if r.name=='idle':assert idle==3 and not boost
 return dict(products=outputs,rows=len(rows),dropped=drop,service=full,wake=wake,boost=resets,demotions=dem,multilevel_late=multi,exact_compare_ties=tie,idle=idle)
out={}
for name in load(D/'freeze.json')['order']:
 out[name]=check(D/name);(D/'score.json').write_text(json.dumps(out,indent=2))
