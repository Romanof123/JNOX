import json,struct,time,subprocess as sp,shutil,hashlib,re
from pathlib import Path
D=Path.cwd(); P=D.parent/'pkg'
cases={'strict':['report','crc'],'feedback':['report','crc'],'three':['crc','histogram','report'],'equal':['yield','crc'],'cumulative':['yield','crc'],'idle':['report'],'solo':['yield']}
order=['strict','strict.trace','feedback','feedback.trace','three','equal','cumulative','idle','solo']
def syms(p):return sp.check_output(['aarch64-linux-gnu-nm','-S',p],text=True).splitlines()
def save(p,v):p.write_text(json.dumps(v,indent=2))
save(D/'freeze.json',dict(order=order,capacity=512,reference_hz=62500000,sha=sp.check_output(['git','rev-parse','HEAD'],cwd=D.parent/'source',text=True).strip(),qemu=sp.check_output(['qemu-system-aarch64','--version'],text=True),capturescript=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
for k in cases:shutil.copy(P/k/'manifest.json',D/(k+'-manifest.json'))
for label in order:
 k=label.split('.')[0]; a=cases[k]; r=D/label;r.mkdir(); kern=P/k/'kernel.elf'; blob=kern.read_bytes()
 off=struct.unpack_from('<Q',blob,32)[0]; heads=[struct.unpack_from('<II6Q',blob,off+i*56) for i in range(struct.unpack_from('<H',blob,56)[0])]
 _,_,fo,_,pa,*_=next(h for h in heads if h[0]==1 and h[5]>=256)
 base,size=[int(v,16) for v in next(l for l in syms(kern) if '6SPACES' in l).split()[:2]]
 assert size==len(a)*0x415000
 cmd=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-no-reboot','-serial','stdio','-kernel',str(kern)]
 if label.endswith('.trace'):cmd+=['-d','int','-D',str(r/'exceptions.log')]
 save(r/'argv.json',cmd)
 with (r/'uart.log').open('wb') as u,(r/'stderr').open('wb') as err,sp.Popen(cmd,stdout=u,stderr=err,stdin=sp.DEVNULL) as p:
  try:
   start=time.monotonic(); proc=Path('/proc')/str(p.pid)
   while len(re.findall(rb'NATIVE EL0 EXIT [^\n]+\n',(r/'uart.log').read_bytes()))<len(a):
    assert time.monotonic()-start<45 and p.poll() is None,'missing terminal UART'
    time.sleep(.025)
   with (proc/'mem').open('rb',buffering=0) as mem:
    for line in (proc/'maps').read_text().splitlines():
     l,h=map(lambda n:int(n,16),line.split()[0].split('-'))
     if h-l<128*1024**2 or 'rw' not in line.split()[1]:continue
     mem.seek(l+pa-0x40000000)
     if mem.read(256)==blob[fo:fo+256]:break
    else:raise ValueError('guest RAM identity')
    result=[]
    for i,app in enumerate(a):
     fields={}
     for line in syms(D/'elf'/(app+'.elf')):
      s=line.split()
      if len(s)!=4 or s[3] not in ('private_blocks','private_bytes','private_result','request_ns','observed_ns','round_count','cumulative_count'):continue
      addr=base+i*0x415000+5*4096+int(s[0],16)-0x400000
      mem.seek(l+addr-0x40000000); fields[s[3]]=dict(addr=addr,hex=mem.read(int(s[1],16)).hex())
     result.append(dict(app=app,fields=fields))
    save(r/'terminal.json',result)
  finally:
   if p.poll() is None:p.terminate();p.wait(5)
