import re,json
from pathlib import Path
from collections import Counter
D=Path.cwd();out={}
for name in ('strict.trace','feedback.trace'):
 r=D/name;rows=[list(map(int,l.split()[3:])) for l in (r/'uart.log').read_text().splitlines() if ' EVENT ' in l];text=(r/'exceptions.log').read_text()
 events=re.split(r'(?=Taking exception \d+ \[)',text)[1:]
 pairs=[]
 for e in events:
  if 'from EL0 to EL1' not in e:continue
  cause=re.search(r'\[(\w+)\]',e)[1];saved=int(re.search(r'with ELR 0x([a-f0-9]+)',e)[1],16);m=re.search(r'to AArch64 EL0 PC 0x([a-f0-9]+)',e);pairs.append([cause,saved,int(m[1],16) if m else 0])
 prior=-1; spans=[]; bg=None
 for i,row in enumerate(rows[1:],1):
  target=['IRQ' if row[0]==4 else 'SVC',row[24],row[26]]
  j=next(k for k in range(prior+1,len(pairs)) if pairs[k]==target);prior=j
  if row[0]==2 and row[2]==0:bg=j
  if row[17]==1 and bg is not None:
   calls=Counter(hex(saved) for cause,saved,_ in pairs[bg+1:j] if cause=='SVC');assert sum(calls.values())>=2
   spans.append(dict(wake_row=i,external_exception_index=j,background_SVC_PCs=calls));bg=None
 out[name]=spans
(D/'external-order.json').write_text(json.dumps(out,indent=2))
