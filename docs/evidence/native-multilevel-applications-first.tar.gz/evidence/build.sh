set -eux
cd ~/verify309/source
export RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo
export PATH=$CARGO_HOME/bin:$PATH
e=$HOME/verify309/evidence
mkdir -p "$e/elf"
for app in report yield; do sh sdk/native-aarch64/build.sh examples/native-multilevel/$app.c "$e/elf/$app.elf"; done
sh sdk/native-aarch64/build.sh examples/native-cbs/crc.c "$e/elf/crc.elf"
sh sdk/native-aarch64/build-rust.sh examples/native-cbs-rust/Cargo.toml "$e/elf/histogram.elf"
for f in "$e"/elf/*.elf; do aarch64-linux-gnu-objdump -d "$f" > "$f.dis"; done
mlq() { python3 tools/build_native_el0.py --policy mlq --quantum-ticks 625000 "$@"; }
mlfq() { python3 tools/build_native_el0.py --policy mlfq --allotment-ticks 625000,1250000,2500000 --boost-ticks 6250000 "$@"; }
p=$HOME/verify309/pkg
f=$e/elf
mlq --out $p/strict --elf $f/report.elf --class 7 --peer-elf $f/crc.elf --peer-class 1
mlfq --out $p/feedback --elf $f/report.elf --peer-elf $f/crc.elf
mlq --out $p/three --elf $f/crc.elf --class 7 --peer-elf $f/histogram.elf --peer-class 7 --peer-elf $f/report.elf --peer-class 1
mlq --out $p/equal --elf $f/yield.elf --class 7 --peer-elf $f/crc.elf --peer-class 7
mlfq --out $p/cumulative --elf $f/yield.elf --peer-elf $f/crc.elf
mlfq --out $p/idle --elf $f/report.elf
mlfq --out $p/solo --elf $f/yield.elf
