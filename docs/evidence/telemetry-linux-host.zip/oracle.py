from pathlib import Path
import re,json
r=Path('host-run/host')
out={}
for p in sorted(r.iterdir()):
 if not p.is_dir():continue
 n=p.name; args=json.loads((p/'argv.json').read_bytes())
 if len(args)!=1: exp=(2,b'',b'usage: telemetry_monitor PATH\n')
 elif not (p/args[0]).exists():exp=(5,b'',b'input error\n')
 else:
  b=(p/args[0]).read_bytes()
  if not b:exp=(3,b'',b'empty input\n')
  elif not re.fullmatch(rb'(?:[0-9]+\n)+',b) or any(int(x)>65535 for x in b.splitlines()):exp=(4,b'',b'invalid sample\n')
  else:
   v=[int(x) for x in b.splitlines()];exp=(0,f'samples={len(v)} min={min(v)} max={max(v)} sum={sum(v)}\n'.encode(),b'')
  if n=='split-token':assert b[254:260]==b'65535\n' and len(b)==260
 actual=tuple((p/f).read_bytes() for f in ('status.txt','stdout.bin','stderr.bin'))
 assert actual==(f'{exp[0]}\n'.encode(),*exp[1:]),n
 out[n]=exp[0]
assert len(out)==17
print(json.dumps(out,indent=2))
