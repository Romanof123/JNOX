#!/bin/bash
set -eu
root=/home/ywcho/jnox348-f2b2cd7.rEb0sLeQ
cd "$root"
mkdir source raw
cd source
git init -q
git remote add origin https://github.com/Romanof123/JNOX.git
git fetch --depth=2 origin f2b2cd724ff8e3d8e7e403c5cc6a6e819f5f4ff0
git checkout -q --detach FETCH_HEAD
git rev-parse HEAD
git log --oneline -3
find . -iname '*native*amc*' -o -iname '*amc*observ*' -o -name AGENTS.md
