import collections, hashlib, json, re, struct
from pathlib import Path
root=Path(__file__).resolve().parent; frozen=json.loads((root/'raw/freeze.json').read_bytes())
ring=(2,5,1,6,3,7,4,8)
def analyze(folder):
    checks=collections.defaultdict(list)
    def ck(group,ok,detail=None):
        if not ok: checks[group].append(str(detail))
    case,mode=folder.name.rsplit('-',1)
    caseinfo=frozen['cases'][case]; slots=caseinfo['slots']; n=len(slots); roots=[int(x['expected_ttbr0_el1'],16) for x in slots]
    session=json.loads((folder/'session.json').read_bytes()); launch=json.loads((folder/'launch.json').read_bytes())
    ck('seal',session['marker']=='end' and all(hashlib.sha256((folder/p).read_bytes()).hexdigest()==h for p,h in session['hashes'].items()))
    uart=(folder/'uart.bin').read_text(); rec=collections.defaultdict(list)
    for line in uart.splitlines():
        fields=line.split()
        if fields[:2]==['NATIVE','AMC']: rec[fields[2]].append(tuple(map(int,fields[3:])))
    ck('boot',re.findall(r'^NATIVE EL0 (?:PEER[23]? )?ELF ([0-9a-f]+)$',uart,re.M)==[x['elf_sha256'] for x in slots])
    _,epoch,hz,q,_,_,_,origin=rec['CONFIG'][0]
    ck('config',hz==62500000 and q==3125000)
    base=launch['ram_base']; ram=(folder/'ram.bin').read_bytes(); read=lambda a,l:ram[a-base:a-base+l]
    def mapped(ttbr,va):
        table=ttbr&0x0000fffffffff000
        for shift in [30,21,12]:
            entry=struct.unpack('<Q',read(table+8*((va>>shift)&511),8))[0]
            assert entry&3==3
            table=entry&0x0000fffffffff000
        return table+(va&4095)
    ra,num,width,loss=rec['INTERVALS'][0]; prod,_,stride=rec['RESULTS'][0]; rows=list(struct.iter_unpack('<23Q',read(ra,num*width*8)))
    life=rec['LIFE'];ck('log',rec['END'][0][0]==len(life) and rec['END'][0][1]==loss==0)
    acc=collections.Counter(); frames={}; spill=[]; attempts=collections.defaultdict(list); terminal={}; adm={}; physical={}; stamps={}
    for i,r in enumerate(rows):
        cause,op,entry,start,src,gen,delta,used=r[:8];dst,dg=r[13:15]
        if src<n:
            ck('root',r[12]==roots[src],i)
            frames[src,gen]=r[10:12]
            if cause!=3:
                acc[src,gen]+=delta
                ck('charge',entry-start==delta and start and acc[src,gen]==used and (i==0 or start>=rows[i-1][2]),i)
            if r[8]: spill.append([i,src,gen,r[8]])
        else: ck('charge',delta==0,i)
        if dst<n:
            ck('root',r[21] in [0,roots[dst]],i)
            if (dst,dg) in frames: ck('frame',r[15:17]==frames[dst,dg],i)
            else: ck('entry',r[15]==int(slots[dst]['entry'],16),i)
    for e in life:
        kind,t,slot,g=e[:4]
        if kind in (1,2):
            task=slots[slot]['task'];attempt=e[7];release=epoch+(task['offset']+attempt*task['period'])*q
            ck('calendar',release==e[5] and release+q*task['deadline']==e[6])
            attempts[slot].append([kind,g,attempt,e[8]])
            if kind==1: adm[slot,g]=e
        elif kind in (3,4,5):
            data=read(prod+(16*slot+g)*stride,936)
            kindnames={3:'exit',4:'exhaust',5:'discard'}
            version,s,g0,index=struct.unpack_from('<4I',data)
            j=slots[slot]['task']['argv'][adm[slot,g][7]]
            ck('budget',acc[slot,g]==e[5],(slot,g))
            va=int(slots[slot]['product_va'],16)
            if g==max(a[3] for a in life if a[0]==1 and a[2]==slot):
                phys=mapped(roots[slot],va); physical[slot]=hex(phys)
                ck('private_memory',read(phys,936)==data,(slot,g))
            if not any(data): ck('empty_discard',kind==5); cnt=total=fn=fs=ckn=cks=0; ticks=[]
            else:
                ck('id',(version,s,g0)==(1,slot,g) and index<2)
                cnt,total=struct.unpack_from('<2Q',data,16+16*index)
                expected=lambda k:36*(k//8)+sum(ring[(slot+g+i)%8] for i in range(k%8))
                ck('ring',total==expected(cnt)%(2**64),(slot,g))
                ckn,fn,cks,fs,ns,overflow=struct.unpack_from('<IIQQII',data,112)
                ticks=[struct.unpack_from('<3Q',data,144+k*24) for k in range(ns)]
                ck('stamp_capacity',ns<=32 and overflow==0)
                if kind==3:
                    exit_rows=[r for r in rows if r[:2]==(2,1) and r[4:6]==(slot,g) and r[2]==t and r[19]==slot]
                    ck('exit',len(exit_rows)==1 and e[7]==slot,(slot,g))
                    final=struct.unpack_from('<3Q',data,912)
                    ck('publication',final[2]==cnt and final[0]*hz//10**9+origin<=t)
                    if j[1]!='stream':
                        finite=list(struct.unpack_from('<16I',data,48))[:fn]
                        ck('finite',fn==(int(j[2]) if j[1]=='finite' else 16) and finite==[ring[(slot+g+k)%8] for k in range(fn)] and fs==expected(fn))
                    if j[1]=='survivor':ck('checkpoint',(ckn,cks)==(8,36))
            stamps[slot,g]=ticks
            terminal[f'{slot}.{g}']=dict(kind=kindnames[kind],service_ticks=e[5],samples=cnt,sum=total,finite=[fn,fs],checkpoint=[ckn,cks],terminal_tick=t,release_to_terminal_ns=(t-adm[slot,g][5])*16,deadline_slack_ticks=e[6]-t)
    for i,s in enumerate(slots): ck('admission',[a[2] for a in attempts[i]]==list(range(s['task']['generations'])))
    ck('retired',set(terminal)=={f'{s}.{g}' for s,g in adm})
    crossing=None
    if case in ('normal-hi','over-hi','staggered'):
        b=epoch+q*(5 if case=='staggered' else 2); life9=next(e for e in life if e[0]==9); c=life9[1]
        first=next(r for r in rows if r[4:6]==(1,0) and r[7]>=q)
        near=[r for r in rows if r[0]==1 and (r[1]&1023)==30 and r[4:6]==(1,0) and b<=r[2]<=c]
        seen={v[0] for v in stamps[1,0]}
        wx=[r for r in rows if r[0:2]==(2,6) and r[4:6]==(1,0) and r[19:21]==(1,0) and r[2]>=c and (r[2]-origin)*16 in seen]
        crossing=dict(b=b,c=c,x=wx[0][2] if wx else None,witness_delta_ns=(wx[0][2]-b)*16 if wx else None,PPI=[r[2] for r in near],first_budget_cause=first[0],first_op=first[1],first_entry=first[2],CVAL=first[9],entitlement_delta=first[7]-q,grid_to_compare_ticks=first[9]-b,compare_to_entry_ticks=first[2]-first[9])
        crossing['meets']=bool(near and wx and b<=near[-1][2]<=c<=wx[0][2]<b+q)
    trace=None
    if mode=='trace':
        blocks=(folder/'exceptions.log').read_text().split('Taking exception ')[1:]
        actual=[]
        for block in blocks:
            lines=block.splitlines()
            if len(lines)>1 and lines[1]=='...from EL0 to EL1':
                pc=next(t for t in lines[2:] if t.startswith('...with ELR '))
                actual.append([lines[0].split()[1],int(pc.split()[-1],16)])
        ideal=[['[IRQ]' if r[0]==1 else '[SVC]',r[10]] for r in rows if r[0] in (1,2) and r[4]<n]
        ck('qemu_pc',actual==ideal)
        trace=len(actual)
    return dict(case=case,mode=mode,rows=num,life=len(life),drops=[loss,rec['END'][0][1]],admissions=dict(attempts),terminals=terminal,roots=[hex(x) for x in roots],live_product_pa=physical,crossing=crossing,spills=len(spill),max_spill_ticks=max([s[-1] for s in spill]+[0]),deadline_faults=[e for e in life if e[0]==7],resets=[e for e in life if e[0]==6],trace_el0_events=trace,issues=dict(checks))
out={}
for case,mode in frozen['capture_order']:
    name=case+'-'+mode;out[name]=analyze(root/'captures'/name)
    v=out[name];print(name,v['issues'],v['crossing'],flush=True)
(root/'independent.json').write_text(json.dumps(out,indent=2)+'\n')
