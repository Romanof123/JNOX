import json, re, struct
from pathlib import Path
root=Path(__file__).resolve().parent
ind=json.loads((root/'independent.json').read_bytes())
for name,v in ind.items():
    d=root/'captures'/name; image=(d/'ram.bin').read_bytes();b0=json.loads((d/'launch.json').read_bytes())['ram_base']
    raw=(d/'uart.bin').read_text(); add,n,width,loss=map(int,re.search(r'NATIVE AMC INTERVALS ([0-9 ]+)',raw).group(1).split())
    rows=list(struct.iter_unpack('<23Q',image[add-b0:add-b0+n*width*8])); cfg=tuple(map(int,re.search(r'NATIVE AMC CONFIG ([0-9 ]+)',raw).group(1).split()))
    gap=v.get('crossing')
    if gap:
        b,c,x=gap['b'],gap['c'],gap['x']
        i=next(i for i,r in enumerate(rows) if r[2]==gap['first_entry'] and r[4:6]==(1,0))
        row=rows[i]
        def detail(r):
            return dict(cause=r[0],op_or_IAR=r[1],entry=r[2],actual_return_start=r[3],source=r[4],generation=r[5],delta=r[6],used=r[7],spill=r[8],CVAL=r[9],saved_pc=hex(r[10]),saved_sp=hex(r[11]),saved_ttbr=hex(r[12]),returned_slot=r[13],returned_gen=r[14],returned_pc=hex(r[15]),returned_sp=hex(r[16]),granted_ticks=r[18],arg=r[19],result=r[20],prepared_ttbr=hex(r[21]))
        origin=cfg[-1]
        irq=[r for r in rows if r[0]==1 and r[1]&1023==30]
        actual=[r for r in rows if r[0]==2 and r[1]==6 and r[4:6]==(1,0) and r[2]>=c and r[20]==0]
        gap.update(frozen_source_and_return=detail(row),first_clock_syscall=detail(actual[0]) if actual else None,first_postcommit_monotonic_syscall=next((detail(r) for r in actual if r[19]==1),None),first_stored_app_witness=next((dict(ticks=r[2],monotonic_ns=(r[2]-origin)*16,prior_service_ns=next((k[7]*16 for k in reversed(rows[:j]) if k[0:2]==(2,6) and k[4:6]==(1,0) and k[19:21]==(2,0)),None)) for j,r in enumerate(rows) if x and r[2]==x and r[4:6]==(1,0) and r[0:2]==(2,6) and r[19]==1),None),previous_PPI_any_owner=next((detail(r) for r in reversed(irq) if r[2]<row[2]),None),next_PPI_any_owner=next((detail(r) for r in irq if r[2]>row[2]),None),same_generation_PPI=[detail(r) for r in irq if r[4:6]==(1,0)],external_trace_zero_loss=(v['trace_el0_events'] is not None and not v['issues'] and not any(v['drops'])))
    # Evaluate named functional conditions without overriding original scorer rows.
    # Include independent raw event timing, even where a specific fault was intentional.
    life=[tuple(map(int,l.split()[3:])) for l in raw.splitlines() if l.startswith('NATIVE AMC LIFE ')]
    switches=[e for e in life if e[0]==9]
    v['transitions']=switches
    v['timing_hz']=cfg[2];v['epoch']=cfg[1];v['q']=cfg[3]
    v['rejected_releases']=[e for e in life if e[0]==2]
    if switches:
        snap=life[:life.index(switches[0])]; live={(e[2],e[3]) for e in snap if e[0]==1}-{(e[2],e[3]) for e in snap if e[0] in (3,4,5)}
        old=cfg[1];ts=json.loads((d/'deployment.json').read_bytes())['tasks']; v['carry_in']=[]
        for i,g in sorted(live):
            dispatched=[r for r in rows if r[4:6]==(i,g) and r[2]<=switches[0][1]]
            used=dispatched[-1][7] if dispatched else 0
            v['carry_in'].append([i,g,used,max(0,ts[i]['c_lo']*cfg[3]-used),max(0,ts[i]['c_hi']*cfg[3]-used)])
    if name in ['normal-hi-trace','staggered-trace']:
        print(name,gap['frozen_source_and_return'],gap['first_stored_app_witness'],[(r['source'],r['entry']) for r in gap['same_generation_PPI']],flush=True)
(root/'independent-detailed.json').write_text(json.dumps(ind,indent=2)+'\n')
