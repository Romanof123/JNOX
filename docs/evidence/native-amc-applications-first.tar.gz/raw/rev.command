git rev-parse HEAD
