qemu-system-aarch64 --version
