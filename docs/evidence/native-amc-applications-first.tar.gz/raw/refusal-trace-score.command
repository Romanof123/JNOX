/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-f2b2cd7.rEb0sLeQ/captures/refusal-trace 9113f01ac448e82b1b3509f9eef01b04a78012bb99504ec0a362d8c3b09378d1
