/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-f2b2cd7.rEb0sLeQ/captures/staggered-trace 521cc69a0958dafbdb0d3773524492af82bf254dcb0055f06d5076fd71958cb9
