git status --porcelain --untracked-files=no
