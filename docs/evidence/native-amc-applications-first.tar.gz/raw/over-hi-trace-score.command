/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-f2b2cd7.rEb0sLeQ/captures/over-hi-trace ba7c242cd1c7eae476d9fab7ec1993d14cd2dc048720821fac9bdb52ad46afd7
