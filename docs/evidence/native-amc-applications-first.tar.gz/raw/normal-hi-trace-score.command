/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-f2b2cd7.rEb0sLeQ/captures/normal-hi-trace 951bb90fc5c2cd6fd5876a4007b864ca6aa24477673dc36caba6eb0944a06be8
