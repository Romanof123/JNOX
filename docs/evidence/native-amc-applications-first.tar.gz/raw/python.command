/usr/bin/python3 -V
