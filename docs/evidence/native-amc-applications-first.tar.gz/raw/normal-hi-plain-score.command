/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-f2b2cd7.rEb0sLeQ/captures/normal-hi-plain fc3ab046ba434333ac0a008bdf9744128c494252d8de4dcdcfb5c14582aa5de7
