findmnt -T /home/ywcho/jnox348-f2b2cd7.rEb0sLeQ/source -no SOURCE,FSTYPE
