/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-f2b2cd7.rEb0sLeQ/captures/overlap-plain f7b514aed503df1cda5adc34aefec2b40c762d5556de9e8819e5dfb77510cc5f
