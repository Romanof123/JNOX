/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/jnox348-f2b2cd7.rEb0sLeQ/captures/refusal-plain 52650eb3f0e7909b7e7443c482c470dfc0c514035becedffd81d8357c01c5e9e
