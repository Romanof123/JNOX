aarch64-linux-gnu-readelf --wide --symbols /home/ywcho/jnox348-f2b2cd7.rEb0sLeQ/source/output/native-amc/within-lo/kernel.elf
