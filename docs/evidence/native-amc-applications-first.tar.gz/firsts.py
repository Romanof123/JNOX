from pathlib import Path
import datetime,hashlib,json,subprocess,shlex,sys
root=Path(__file__).resolve().parent; raw=root/'raw';src=root/'source'; caps=root/'captures'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
freeze=raw/'freeze.json';assert sha(freeze)==(raw/'freeze.sha256').read_text().strip()
data=json.loads(freeze.read_bytes());assert sha(Path(__file__))==data['fixed']['capture_script_sha256']
caps.mkdir()
for name,mode in data['capture_order']:
    d=caps/(name+'-'+mode); pk=src/'output/native-amc'/name
    cfg=src/'examples/native-amc/config'/(name+'.json')
    assert sha(pk/'manifest.json')==data['cases'][name]['manifest_sha256'] and sha(pk/'kernel.elf')==data['cases'][name]['kernel_sha256'] and sha(cfg)==data['cases'][name]['deployment_sha256']
    for s in json.loads((pk/'manifest.json').read_bytes())['slots']: assert sha(pk/s['elf'])==s['elf_sha256']
    cmd=[sys.executable,'tools/native_amc_report.py','capture',str(pk),str(cfg),str(d),name,'--timeout','30']+(['--trace'] if mode=='trace' else [])
    def run(label,c):
        stem=raw/(d.name+'-'+label); start=datetime.datetime.now(datetime.timezone.utc).isoformat()
        (Path(str(stem)+'.command')).write_text(shlex.join(c)+'\n')
        r=subprocess.run(c,cwd=src,capture_output=True)
        for ext,b in [('stdout',r.stdout),('stderr',r.stderr),('exit',f'{r.returncode}\n'.encode()),('started',start.encode())]: Path(str(stem)+'.'+ext).write_bytes(b)
        print(d.name,label,r.returncode,(r.stderr.decode(errors='replace') or r.stdout.decode(errors='replace'))[:240],flush=True)
        return r
    cap=run('capture',cmd)
    if (d/'session.json').exists(): run('score',[sys.executable,'tools/native_amc_report.py','report',str(d),sha(d/'session.json')])
