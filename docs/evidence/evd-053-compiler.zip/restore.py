from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
out=root/'restored'
out.mkdir()
for key,digest in json.loads((root/'paths.json').read_text()).items():
    path=out/key
    path.resolve().relative_to(out.resolve())
    data=(root/'objects'/digest).read_bytes()
    if hashlib.sha256(data).hexdigest()!=digest:
        raise ValueError(key)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(data)
