set -eu
cd ~/package096
R=$PWD
export CARGO_BUILD_JOBS=1 PYTHONPATH=$HOME/jnox-169-first-e203caa/deps PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH
cd src
for app in startup-probe weighted-share weighted-wake partition-p; do
 value=irq-v1; if [ "$app" = partition-p ]; then value=irq-v2; fi
 rc=0; python3 tools/build_native_el0.py --out "$R/invalid-$app" --app "$app" --partition-phase "$value" >"$R/evidence/invalid-$app.log" 2>&1 || rc=$?
 test "$rc" = 2; test ! -e "$R/invalid-$app"; echo "$app $value rc=$rc output_absent" >> "$R/evidence/controls.txt"
done
python3 tools/test_build_native_partition_phase.py >"$R/evidence/mocked.log" 2>&1
python3 tools/test_partition_selectors.py >"$R/evidence/selectors.log" 2>&1
echo 'selector checks passed' >> "$R/evidence/selectors.log"
for app in startup-probe weighted-share weighted-wake; do
 JNOX_PARTITION_PHASE=irq-v1 python3 tools/build_native_el0.py --out "$R/build-$app" --app "$app" > "$R/evidence/build-$app.log" 2>&1
 cp "$R/build-$app/manifest.json" "$R/evidence/$app-manifest.json"
 readelf -Ws "$R/build-$app/kernel.elf" | awk '$NF=="native_partition_irq_phase_v1" && $7!="UND" {n++} END {exit(n+0!=0)}'
done
