set -eu
cd ~/package096
R=$PWD
export CARGO_BUILD_JOBS=1 PYTHONPATH=$HOME/jnox-169-first-e203caa/deps PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH
cd src
rev=$(git rev-parse HEAD)
export JNOX_PARTITION_PHASE=irq-v1
for t in p q; do for v in plain phase; do
 args=(); if [ "$v" = phase ]; then args=(--partition-phase irq-v1); fi
 b="$R/build-$t-$v"; python3 tools/build_native_el0.py --out "$b" --app partition-$t "${args[@]}" >"$R/evidence/build-$t-$v.log" 2>&1
 readelf -Ws "$b/kernel.elf" > "$R/evidence/$t-$v-symbols.txt"
 count=$(awk '$NF=="native_partition_irq_phase_v1" && $7!="UND" {n++} END{print n+0}' "$R/evidence/$t-$v-symbols.txt"); echo "$t $v $count" >> "$R/evidence/symbols.txt"
 if [ "$v" = phase ]; then test "$count" = 1; else test "$count" = 0; fi
 cp "$b/manifest.json" "$R/evidence/$t-$v-manifest.json"
 done; cmp "$R/build-$t-plain/user.elf" "$R/build-$t-phase/user.elf"; done
unset JNOX_PARTITION_PHASE
touch "$R/qualified"
for n in 1 2 3 4 5; do for c in default icount3; do for t in p q; do
 order="plain phase"; case $n in 2|4) order="phase plain";; esac
 prefix="$R/evidence/$n-$t-$c"
 for v in $order; do
  d="$prefix-$v"; b="$R/build-$t-$v"; rc=0
  python3 tools/native_weighted_capture.py partition-$t "$c" "$d" "$b/kernel.elf" "$b/user.elf" examples/portability/native_partition_monitor.c "$rev" >"$d.out" 2>"$d.err" || rc=$?
  echo "$rc" > "$d.rc"
 done
 if [ -f "$prefix-plain/session.json" ] && [ -f "$prefix-phase/session.json" ]; then
  rc=0
  python3 tools/native_partition_phase.py "$prefix-plain" "$(sha256sum "$prefix-plain/session.json"|cut -d' ' -f1)" "$prefix-phase" "$(sha256sum "$prefix-phase/session.json"|cut -d' ' -f1)" >"$prefix.json" 2>"$prefix.err" || rc=$?
  echo "$rc" >"$prefix.rc"
 fi
 echo "$n $t $c"
done;done;done
