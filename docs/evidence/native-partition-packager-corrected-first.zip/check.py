from pathlib import Path
import sys,json,struct,hashlib,statistics,csv,subprocess,os
from collections import defaultdict
from elftools.elf.elffile import ELFFile
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'src/tools'))
from native_partition_replay import replay
E=R/'evidence'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
groups=defaultdict(list)
out=open(R/'transitions.tsv','w'); w=csv.writer(out,delimiter='\t')
stages='entry observe result audit record_gap schedule mmu publish post_publish'.split()
metrics='irq_to_selection selection_to_return return_to_user opening_to_user margin'.split()
w.writerow(['round','table','clock','oldgen','oldpid','newgen','newpid',*stages,*[m+'_'+v for m in metrics for v in ('plain','phase','delta')]])
for base in sorted(E.glob('[1-5]-*.json')):
 if base.stat().st_size == 0: continue
 j=json.loads(base.read_text()); n,t,c=base.stem.split('-'); runs=[]
 for v in ('plain','phase'):
  d=E/(base.stem+'-'+v); runs.append(replay(d,sha(d/'session.json')))
 with (d/'kernel.elf').open('rb') as f:
  s=ELFFile(f).get_section_by_name('.symtab').get_symbol_by_name('native_partition_irq_phase_v1')[0]
  at=s['st_value']-json.loads((d/'launch.json').read_text())['ram_base']
 rows=list(struct.iter_unpack('<17Q',(d/'ram.bin').read_bytes()[at:at+s['st_size']]))
 for i,tr in enumerate(j['transitions']):
  old,new=runs[1]['windows'][i:i+2]; r=rows[i]; assert r[:3]==(old['generation'],old['pid'],old['irq_entry']) and r[7:10]==(1152,new['generation'],new['pid']) and r[14:]==(new['selected'],new['release'],new['close'])
  stamps=list(r[2:7]+r[10:15]); assert stamps==list(tr['raw'].values())==sorted(stamps)
  st=[b-a for a,b in zip(stamps,stamps[1:])]; assert sum(st)==tr['phase']['irq_to_selection']
  for run,v in zip(runs,['plain','phase']):
   o,k=run['windows'][i:i+2]; x=[k['selected']-o['irq_entry'],k['return_sample']-k['selected'],k['user_tick']-k['return_sample'],k['user_tick']-k['release'],62500-k['latency']]
   assert sum(x[:3])+o['irq_entry']-k['release']==x[3] and x==[tr[v][m] for m in metrics]
  w.writerow([n,t,c,*r[:2],*r[8:10],*st,*[tr[v][m] for m in metrics for v in ('plain','phase','delta')]])
 assert all(not any(r) for r in rows[len(j['transitions']):])
 groups[t,c].append(j)
out.close()
for (t,c),js in groups.items():
 print(t,c,'miss plain/phase',[(j['plain_misses'],j['phase_misses']) for j in js])
 for which in ('first','later'):
  ts=[tr for j in js for tr in (j['transitions'][:1] if which=='first' else j['transitions'][1:])]
  print(which,'delta median',[statistics.median([x['delta'][m] for x in ts]) for m in metrics[:4]],'margins minima',[min(x[v]['margin'] for x in ts) for v in ('plain','phase')])
 print('round1 stages first', [b-a for a,b in zip(list(js[0]['transitions'][0]['raw'].values()),list(js[0]['transitions'][0]['raw'].values())[1:])])