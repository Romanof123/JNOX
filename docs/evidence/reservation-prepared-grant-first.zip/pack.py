from pathlib import Path
import hashlib,zipfile
p=Path(__file__).parent
def sha(b):return hashlib.sha256(b).hexdigest()
files=[x for x in sorted(p.rglob('*')) if x.is_file() and '__pycache__' not in x.parts and x.name!='SHA256SUMS' and not x.parent.name.startswith('pos')]
(p/'SHA256SUMS').write_text(''.join(sha(x.read_bytes())+'  '+x.relative_to(p).as_posix()+'\n' for x in files))
dest=p.with_suffix('.zip')
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for x in files+[p/'SHA256SUMS']:z.write(x,x.relative_to(p).as_posix())
with zipfile.ZipFile(dest) as z:
 for x in files+[p/'SHA256SUMS']:assert sha(z.read(x.relative_to(p).as_posix()))==sha(x.read_bytes())
print(dest,dest.stat().st_size,sha(dest.read_bytes()))
