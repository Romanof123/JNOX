import json,statistics,sys
from pathlib import Path
p=Path(__file__).parent
get=lambda s:json.loads((s/'observations.json').read_text())
groups=[get(p.parent/s) for s in ('permit389-first-fbbb','permit389-recheck-7c5b0c2','permit389-fused-c5ab397')]
ds=groups[-1]; trace=json.loads((p/'trace-audit.json').read_text())
def summary(x):
 c=x['private'][1]['admission_controller_rows']
 return dict(exits=x['exits'],samples=[x['enabled18'],x['enabled37']],complete=x['completed_checks'],received=len(x['receive_bytes_join']),rx_join=all(x['receive_bytes_join']),pub_join=all(x['publication_join']),accepted=sum(c[i+5]==0 for i in range(0,32*18,18)),rejections=len(x['private_rejections']),rearms=x['rearm'],missing=x['missing_wait'],open=x['open_ctrl'],faults=x['fault_to_detect_safe'])
def counts(x):return {k:x[k] for k in ('samples','received','accepted','rejections','rearms')}
comparison={k:[summary(g[k]) for g in groups] for k in ds if k.startswith(('fifo','rr'))}
(p/'useful-work.json').write_text(json.dumps(comparison,indent=1))
res=['','## Comparable work and availability / 유효 작업과 가용성','', 'Each cell gives original / corrected / fused accepted COMMIT count and virtual ENABLE samples at 18 and 37 ms. Per-run counts of actual receives, private rejections, rearm outcomes, fault intervals and joins are in useful-work.json. Changes in the work or device outcome preclude attributing raw duration changes solely to fusion.','', '|Position|Accepted COMMIT|ENABLE 18,37|','|---|---|---|']
for n,x in comparison.items():res.append('|'+n+'|'+' / '.join(str(v['accepted']) for v in x)+'|'+' / '.join(','.join(map(str,v['samples'])) for v in x)+'|')
res+=['','All 24 observed controller phases sets had complete pre-wake waits, ready and dispatch witnesses and bounded finishes. The largest job, sender and COMPLETE-gap upper endpoints were 252561, 277012 and 225705 ticks. Grid IRQ arrival-to-return exceeded 31250 ticks in FIFO and RR boundary-witness (35463, 84945). Each optional interference position recorded 26 completed IRQ27s. The boundary private clones recorded the one-tick-before and exact-expiry cases separately from the real 2.5-ms dispatch. Live first-pair spacings of 523142/563428 ticks missed the exact 625000-tick target. Both remained inhibited at the two sampled instants. FIFO invalid and FIFO lower-work remained inhibited at 18 ms and were enabled at 37 ms.','', 'Across all 24 fused boots, maximum syscall entry-to-decision samples were 65822 ticks for CHECK and 4725 for COMPLETE. Real healthy fixed prefixes show empty 6→4 calls and accepted 9→7. All measured full phase upper endpoints remained below the 156250-tick next release, yet all positions exceeded the independent 62500-tick limit. Qualifier and safety rows had zero drops. Fixed drops are reported independently.','', '실제 수신·반영 횟수와 두 시점의 출력 상태를 실행별로 대조했다. FIFO invalid 및 lower-work는 18 ms에 억제, 37 ms에 활성 상태였다. FIFO·RR 경계 사례에서 가상 타이머 인터럽트의 compare→복귀 시간이 500 µs를 넘었다.']
with (p/'DECISION.en-ko.md').open('a',encoding='utf8') as f:f.write('\n'.join(res)+'\n')
