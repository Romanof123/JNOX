set -eu
source ~/.cargo/env
base=$HOME/permit389-fused-c5ab397
dest=/mnt/d/codex/permit389-fused-c5ab397
cd "$base/src"
rev=c5ab397e93d345a4fef4420fe9cf7fa3e4be97ac
cp "$base"/*.elf "$base"/*.log "$dest"/
for p in fifo rr; do
 q=(); if [[ $p == rr ]]; then q=(--quantum-ticks 625000); fi
 for s in healthy; do
  n=legacy-$p-$s; a=$s; x=(); if [[ $s == *-irq ]]; then a=${s%-irq}; x=(--safety-interference); fi
  mkdir "$base/$n"
  (set -x; python3 tools/build_native_el0.py --out "$base/$n/pkg" --board virt --policy "$p" "${q[@]}" --elf "$base/sender.elf" --peer-elf "$base/controller.elf" --peer-elf "$base/supervisor.elf" --arg "$a" --peer-arg "$a" --peer2-arg "$a" --priority 6 --peer-priority 7 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel --safety-qualification "${x[@]}") > "$base/$n/build.log" 2>&1 || { cp -r "$base/$n" "$dest/"; tail -40 "$base/$n/build.log"; exit 1; }
  (set -x; python3 tools/native_el0_capture.py "$base/$n/cap" "$base/$n/pkg/kernel.elf" "$base/sender.elf" examples/native-safety-admission/sender/src/main.rs "$rev" --manifest "$base/$n/pkg/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608) > "$base/$n/boot.log" 2>&1 || echo UNRESOLVED >> "$base/$n/boot.log"
  (cd "$base/$n"; tar -czf "$dest/$n.tgz" cap pkg/kernel.elf pkg/manifest.json build.log boot.log)
  echo "$n"; tail -2 "$base/$n/boot.log"
 done
done
