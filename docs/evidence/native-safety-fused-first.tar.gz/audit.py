import json,sys,collections,hashlib
from pathlib import Path
dst,live,first,corrected=map(Path,sys.argv[1:])
def load(d):return json.loads((d/'observations.json').read_text())
orig,prev,obs=map(load,(first,corrected,dst))
packet={}
rows=[]
for arc in sorted(dst.glob('*.tgz')):
 n=arc.stem
 cap=live/n/'cap'
 lines=(cap/'uart.bin').read_text().splitlines()
 def get(tag):return [list(map(int,l[len(tag):].split())) for l in lines if l.startswith(tag+' ')]
 q=[r[1:] for r in get('NATIVE QUAL ROW')];safe=get('NATIVE SAFETY EVENT');fixed=get('NATIVE FIXED EVENT')
 dec=[r for r in q if r[0]==4 and r[2]==63]; sev=[r for r in safe if r[0]==5 and r[3]==63]
 joins=[a[1:4]==b[2:5] and a[7]==b[5] and a[4]<=b[1]<=a[6] for a,b in zip(dec,sev)]
 complete=[r for r in safe if r[0]==10]
 cdec=[r for r in dec if r[3]==3]
 cj=[a[4]<=b[2]<=b[3]<=a[6] for a,b in zip(cdec,complete)]
 ex=get('NATIVE EL0 EXIT PID');assert ex==[[0,71],[1,72],[2,73]]
 fused=n.startswith(('fifo','rr'))
 assert len(dec)==len(sev)==(64 if fused else 0) and all(joins) and all(cj) and len(complete)==32
 assert all(r[1]==1 and r[3] in (1,3) for r in dec)
 prefix=[r[1] for r in fixed if r[3]==1]
 marks=[i for i,s in enumerate(prefix) if s==62]
 spans=[prefix[a+1:b] for a,b in zip(marks,marks[1:]) if b>a+1]
 info=dict(exits=ex,complete=len(complete),qual_counts=get('NATIVE QUAL COUNTS'),fixed_dropped=get('NATIVE FIXED DROPPED'),safety_dropped=get('NATIVE SAFETY DROPPED'),fusion_rows=len(sev),match_count=sum(joins),complete_join=sum(cj),fused_entry_to_decision_ticks={str(c):[r[6]-r[4] for r in dec if r[3]==c] for c in (1,3)},controller_prefix_bodies=spans,archive_sha256=hashlib.sha256(arc.read_bytes()).hexdigest())
 packet[n]=info
 if not fused: continue
 x=obs[n]; a=orig[n]; b=prev[n]
 js=[j for j in x['jobs'] if j['pid']==1]
 full=all(j['wait'] and j['wait'][1]<j['target'] and j['ready'] and j['dispatch'] and j['finish'] for j in js)
 info.update(prewake_all=full,safety_status=[s[5:10] for s in sev],phase_upper=x['max_ctrl_hi'],phase_lower=x['max_ctrl_lo'])
 rows.append(f"|{n}|{a['max_ctrl_hi']} / {b['max_ctrl_hi']}|{x['max_ctrl_lo']}–{x['max_ctrl_hi']}|{x['job_max_hi']} / {x['max_sender_hi']} / {x['max_complete_gap_upper']}|{x['irq_grid_max_upper']}|{x['enabled18']} / {x['enabled37']}|{int(full)}|")
(dst/'trace-audit.json').write_text(json.dumps(packet,indent=1))
report=['# Independent fused firsts / 결합 연산 독립 최초 실측','', 'Frozen c5ab397e93d345a4fef4420fe9cf7fa3e4be97ac. Refuse admission for FIFO and RR. Every fused position has a measured phase lower bound above the inclusive 62,500-tick limit. QEMU virt, single Cortex-A72, wall-clock TCG, 62.5 MHz. No physical evidence or justified analytical bounds. Each tar contains terminal RAM, UART, manifest and kernel. All 28 exited 71/72/73. The four healthy controls used current legacy selection or the archived corrected controller (rollback) without fused-phase. All 24 fused boots joined 64 real PID1 SVC63 CHECK/COMPLETE pairs of qualifier and safety records each, including 32 COMPLETE timestamp brackets. Qualification and safety journals are authoritative for the recorded scope, fixed journals retain prefixes only.', '', 'FIFO와 RR의 24개 결합 실행은 모두 위상 응답 하한이 1 ms를 넘었다. 기존 방식 및 이전 제어기 복귀 표본 4개도 종료값 71/72/73을 기록했다. 고정 저널은 유한한 앞부분만 남긴다. 물리 장치나 분석적 최악 시간 상한은 검증하지 않았다.', '', '|Position|Original / corrected phase upper|Fused phase lower–upper|Job / sender / COMPLETE gap upper|Grid IRQ upper|ENABLE 18 / 37 ms|All controller pre-wakes & finishes|','|---|---:|---:|---:|---:|---:|---:|',*rows,'','All entries are raw ticks. Compare phase ≤62500, job ≤312500, sender ≤625000, COMPLETE gap ≤312500, grid IRQ ≤31250, and require finish strictly before the next phase. A bracket spanning an exact boundary is inconclusive. Job = final B response plus 156250. See observations.json for each blocked-to-ready transition, actual continuation, phase finish endpoints, missing records, fault-to-detect/safe, private rows, boundary clones, rank and publication joins. A post-wake selection by itself does not prove pre-wake service. A qualifying hardware bound remains unavailable.', '', 'trace-audit.json includes each actual SVC63 entry-to-decision duration (excludes full architectural return), syscall bodies within the 128-row prefix, prefix losses and per-archive SHA-256. Legacy and rollback have zero SVC63 rows. Candidate source restricts SVC63 to the qualification build and PID1 commands 1/3. Negative role/command calls were source-reviewed only. Safety ABI 60/61 remains visible in healthy legacy controls. No guest position was retried. Earlier shell line-ending and uninitialized Git-archive package setup errors preceded all boots. The live sources were rebuilt from a detached Git checkout.', '', '수치는 가상 카운터 틱이다. 상한과 하한 사이에 판정 기준이 걸리면 결과는 미확정이다. 세부 상태·발행·재개·출력 전이는 observations.json, 시스템콜 표본과 해시는 trace-audit.json에 보존했다.']
(dst/'DECISION.en-ko.md').write_text('\n'.join(report)+'\n')
