from pathlib import Path
import json, subprocess as sp, sys, hashlib, re, zipfile,os
d=Path(__file__).resolve().parent;t=d/'tree';ev=t/'docs/evidence';repo='D:/codex/j-nox'
os.environ['PYTHONPATH']=str(d/'deps')
out={}; sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return sp.check_output(['git','-C',repo,*args])
def run(*args):
 p=sp.run([sys.executable,*map(str,args)],capture_output=True)
 return p.returncode,p.stdout.decode(),p.stderr.decode()
def cat(tree): 
 c,s,_=run(tree/'tools/scheduling_evidence.py');return c,json.loads(s)['findings']
for loc in ['base','tree']:
 root=d/loc; out[loc]=cat(root); c,s,e=run(root/'tools/requirement_graph.py');out[loc+' graph']=[c,len(s.splitlines()),e];assert c==0
assert [len(out[x][1]) for x in ['base','tree']]==[4,0]
out['diff']=git('diff','--name-status','2a24bf9','ea95956').decode().splitlines()
sourcepaths={'c4a63be':'kernel/src/ordinary_amc.rs','420eaaa':'kernel/src/ordinary_amc.rs','6a33631':'kernel/src/ordinary_amc.rs','34454f9':'tools/virt_footprint.py','812cfd8':'tools/virt_footprint.py'}
out['sources']={git('rev-parse',k).decode().strip():[v,git('rev-parse',k+':'+v).decode().strip()] for k,v in sourcepaths.items()}
out['edges']=[x for x in (t/'trace/links.csv').read_text().splitlines() if re.search(r'IMP-058|EVD-058|EVD-090|REQ-009,verified-by,VER-009',x)]
out['links']={};out['controls']={}
for n in ['058','090']:
 for suffix in ['.en.md','.md']:
  p=ev/('evd-'+n+suffix); s=p.read_bytes();v=s.decode('utf-8-sig')
  for link in re.findall(r'\]\(([^)]+)\)',v):
   a=(ev/link).resolve();assert a.is_file();out['links'][p.name+' '+link]=sha(a)
  try:
   p.unlink();c,f=cat(t);assert c==1 and any('EVD-'+n in x or p.name in x for x in f);out['controls']['remove '+p.name]=f
  finally:p.write_bytes(s)
  if n=='058':
   for token in ['IMP-058','CHG-076']:
    for prefix,post,valid in [('A','','bad'),('','_','bad'),('·','·','ok')]:
     try:
      p.write_text(v.replace(token,prefix+token+post),encoding='utf8');c,f=cat(t);assert (c==0)==(valid=='ok'),f;out['controls'][p.name+' '+prefix+token+post]=f
     finally:p.write_bytes(s)
p=t/'trace/links.csv';s=p.read_bytes()
for edge in ['IMP-058,tested-in,EVD-058','POL-015,has-partial-policy-evidence,EVD-058']:
 try:
  p.write_bytes(b''.join(x for x in s.splitlines(True) if x.strip()!=edge.encode()));c,f=cat(t);assert edge not in p.read_text();out['controls']['remove '+edge]=[c,f]
 finally:p.write_bytes(s)
out['archives']={};out['amc']={}
for p in sorted(set(ev.glob('ordinary-amc*.zip'))|set(ev.glob('evd-090-virt*.zip'))):
 z=zipfile.ZipFile(p);assert z.testzip() is None;digest=sha(p);pins=[x.name for x in ev.iterdir() if x.suffix in ('.md','.json') and digest in x.read_text(encoding='utf-8-sig').lower()];out['archives'][p.name]=[digest,pins]
 dest=d/'originals'/p.stem;z.extractall(dest)
 if p.name.startswith('ordinary-amc'):
  for case in ['exact-lo','exact-hi','over-hi']:
   root=next(x.parent for x in dest.rglob('freeze.json') if x.parent.name==case)
   c,s,e=run(t/'tools/ordinary_amc_replay.py',root,sha(root/'first/session.json'));v=json.loads(s);out['amc'][p.name+' '+case]=[c,v.get('reason'),v.get('outcome'),v.get('generation_products',[])];assert c==int(p.name=='ordinary-amc-first.zip' and case!='exact-lo'),(case,v)
orig=d/'originals'; corr=orig/'evd-090-virt-static-corrected';blind=orig/'evd-090-virt-static-blind'
lookup={x.stem:x for x in corr.rglob('*.elf')};hashes={sha(x):x for x in corr.rglob('*.elf')}
def measure(a,b):return run(corr/'source/tools/virt_footprint.py','--minimal',a,'--fixed-rr',b)
out['role checks']=[]
for r in json.loads((corr/'replayed.json').read_bytes())['cases']:
 c,s,e=measure(lookup[r['minimal']],lookup[r['fixed_rr']]);assert c==r['exit'];out['role checks'].append([r['minimal'],r['fixed_rr'],c])
ids=json.loads((blind/'inputs.json').read_bytes());out['blind']=[]
for r in json.loads((blind/'candidate-results.json').read_bytes())['runs']:
 a,b=[hashes[ids[r[k]]] for k in ['name','opposite']]
 if r['role']!='minimal':a,b=b,a
 c,s,e=measure(a,b);assert c==r['predicted'];out['blind'].append([r['name'],r['role'],c])
out['static']=json.loads(measure(lookup['minimal'],lookup['fixed-rr'])[1]);(d/'observations.json').write_text(json.dumps(out,indent=2),encoding='utf8')


