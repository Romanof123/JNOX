import json,hashlib,zipfile,subprocess as sp
from pathlib import Path
d=Path(__file__).resolve().parent;o=json.loads((d/'observations.json').read_text());e=d/'tree/docs/evidence'
expected=['REQ-009,verified-by,VER-009','POL-015,partially-implemented-by,IMP-058','IMP-058,tested-in,EVD-058','POL-015,has-partial-policy-evidence,EVD-058','VER-009,has-partial-evidence,EVD-090']
for n in ['003','012']:expected+=['DES-'+n+',implemented-by,IMP-058']
for n in ['002','005','023']:expected+=['IMP-058,partially-verified-by,VER-'+n,'VER-'+n+',has-partial-evidence,EVD-058']
assert sorted(expected)==sorted(o['edges'])
o['exact edge omissions']={x:sorted(set(expected)-(set(o['edges'])-{x})) for x in expected}
o['historical archive commits']={}
for n,(digest,pins) in o['archives'].items():
 assert pins
 path='docs/evidence/'+n;git=['git','-C','D:/codex/j-nox'];commit=sp.check_output(git+['log','-1','--format=%H','2a24bf9','--',path]).decode().strip()
 assert hashlib.sha256(sp.check_output(git+['show',commit+':'+path])).hexdigest()==digest;o['historical archive commits'][n]=commit
o['checker blobs']={}
for name in ['scheduling_evidence','requirement_graph','test_requirement_graph','test_scheduling_evidence']:
 path='tools/'+name+'.py';ids=[sp.check_output(git+['rev-parse',k+':'+path]).decode().strip() for k in ['2a24bf9','ea95956']];assert ids[0]==ids[1];o['checker blobs'][path]=ids[0]
(d/'observations.json').write_text(json.dumps(o,indent=2))
