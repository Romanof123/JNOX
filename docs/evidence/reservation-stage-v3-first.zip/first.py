from pathlib import Path
import subprocess as s,hashlib,json,time,os,shutil
D=Path(__file__).parent; H=Path.home()/'jnox-chg071-v3-df8fde7'; H.mkdir()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
q=Path('/usr/bin/qemu-system-aarch64')
assert h(q)=='0a63468782d096485932acf6aa0a69d358b3e3a6f68f655e960e9f5e3fc578d8'
frozen={str(p):h(p) for p in [q,*D.glob('*.py'),*D.glob('*.elf'),*D.glob('*.asm'),*D.glob('*.map'),*D.glob('*.tar'),D/'toolchain.txt',D/'candidate/tools/reservation_stage.py',D/'candidate/tools/reservation_handoff.py']}
items=[]
for i,tag in enumerate('WB WE WF SF SE SB SB SE SF WF WE WB'.split(),1):
 a,v=tag; app={'S':'cbs-saturated','W':'aligned-wake'}[a]
 p=H/f'{i:02}-{tag}';p.mkdir();f=p/'kernel.elf';shutil.copy2(D/('candidate-'+tag+'.elf'),f)
 args=[str(q),'-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','stdio','-kernel',str(f)]
 if a=='S':args+=['-d','int','-D',str(p/'exceptions.log')]
 launch=dict(ordinal=i,selector=app,site=v,elf_sha256=h(f),counter_pc={'B':None,'E':0x402013f0,'F':0x4020196c}[v])
 items.append(dict(path=str(p),launch=launch,argv=['timeout','15s',*args]))
(H/'freeze.json').write_text(json.dumps(dict(source='df8fde7f5241a722724f06b073ea3fb53e701659',identities=frozen,plans=items),indent=2));shutil.copy2(H/'freeze.json',D/'freeze.json')
for m in items:
 p=Path(m['path']);m['load']=os.getloadavg();m['utc']=time.time();start=time.monotonic()
 with (p/'uart').open('xb') as u,(p/'stderr').open('xb') as err:
  m['status']=s.run(m['argv'],cwd=p,stdout=u,stderr=err).returncode
 m['elapsed']=time.monotonic()-start;m['launch']['uart_sha256']=h(p/'uart')
 (p/'launch.json').write_text(json.dumps(m['launch'],indent=2));(p/'meta.json').write_text(json.dumps(m,indent=2))
 shutil.copytree(p,D/'raw'/p.name);print(p.name,m['status'],(p/'uart').read_bytes()[-120:],flush=True)
