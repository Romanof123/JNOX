from pathlib import Path
import json,hashlib,shutil,zipfile,collections,subprocess
D=Path(__file__).parent;H=Path.home()/'jnox-chg071-v3-df8fde7'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=['# Reservation CHG-071 v3 first cohort','',
'Source df8fde7f5241a722724f06b073ea3fb53e701659. Both full B ELF hashes differ from the historical files. Both baseline selectors matched both historical and independently rebuilt aacdbebe958feca152b358ce8cf36033cd7d6749 references, all load bytes and segment headers. Both E ELFs store IAR at 0x402013d4. CBNZ selects the ordinary single DSB at 0x40201428 or the single sampled DSB/ISB/MRS at 0x402013e8/ec/f0, witnessed by ADR at f4. Sampled branch skips the alternate barrier. In each F ELF the frame check loop advances by eight to 16, failures reach the nonreturning call at 0x40201964. Successful second exit at 0x4020185c reaches ISB/MRS 0x40201968/6c and ADR at 70 before destination-bank access. Each B has 26 CNTPCT instructions, E/F have 27. Whole linked images, section maps, probe and source manifests are in the archive. Prior refusals are separate, with zero guest launches apiece.','',
'QEMU virt A72, one CPU, TCG, 128 MiB, default clock. Each guest retained the full first 15 s timeout and terminal UART. W plain, S external IRQ/SVC/ERET trace. Frequency 62,500,000 Hz, original 62,500-tick opening bound. Code 2/5 is an opening-guard stop before selection; 2/2 is a late worker marker. Detailed actual stage receipts, operands, marker, grants, real returns, per-owner cumulative service and linked exception audit are in per-position audit.json. A dash denotes an unobserved endpoint.','',
'| Position | Mask | terminal slot/owner/status/reason | guard operands | IRQ−epoch | reads | prefix | suffix | whole | marker−epoch | grants |','|---|---:|---|---|---:|---:|---:|---:|---:|---:|---:|']
groups=collections.defaultdict(list); counts=collections.Counter()
for p in sorted(H.glob('[0-9]*')):
 r=json.loads((p/'audit.json').read_text());a=r['independent'];z=r['terminal'];grp=p.name[-2:];groups[grp].append(r);counts[(grp[0],z[4],z[5])]+=1
 vs=[p.name,r['mask'],'/'.join(map(str,z[2:6])),' / '.join(map(str,z[6:])),a.get('irq_offset'),a.get('source_reads'),r['prefix'],r['suffix'],r['whole'],a.get('first_offset'),len(a['grants'])]
 report.append('| '+' | '.join('—' if x is None else str(x) for x in vs)+' |')
 shutil.copy2(p/'audit.json',D/'raw'/p.name/'audit.json')
 for f in p.iterdir():
  if f.is_file():assert h(f)==h(D/'raw'/p.name/f.name)
assert sum(counts.values())==12
report.extend(['','## Repeat comparisons',''])
for case in 'WS':
 b=groups[case+'B']
 for site in 'EF':
  g=groups[case+site];rat=[(r['prefix'],r['suffix'],r['whole']) for r in g];baseline=[r['whole'] for r in b];br=[r['whole'] for r in g]
  same=all(x>y for x,y,w in rat) or all(x<y for x,y,w in rat)
  reach=lambda r:(r['mask'],r['terminal'][4:6],bool(r['first_service']))
  transfer=all(reach(x)==reach(y) for x,y in zip(g,b)) and min(br)<=max(baseline) and min(baseline)<=max(br)
  report.append(f'- {case}/{site}: '+', '.join(f'prefix {x}/{w} ({x/w:.1%}), suffix {y}/{w} ({y/w:.1%}), signed prefix minus suffix {x-y:+}' for x,y,w in rat)+f'. Same side larger in both: {same}. B whole {baseline}, diagnostic whole {br}. Transfer to B supported by range and reach checks: {transfer}.')
report+=['','No cross-boot subtraction or imputed counter values. These results only identify potential regions for further source investigation. High-water stack depth and physical-board timing are unmeasured.','', '## Linked footprint','']
report.append('Bytes by image (text/data/bss).')
report.append('');report.append('~~~')
report.append(subprocess.check_output(['aarch64-linux-gnu-size',*map(str,sorted(D.glob('candidate-*.elf')))],text=True).replace(str(D)+'/','').strip());report.append('~~~')
report+=['','## 한국어','', '두 기준 이미지의 적재 바이트가 모두 보존 원본 및 새로 빌드한 원본과 일치했고, E/F 네 이미지가 실제 명령 순서 검사를 통과했다. 고정 순서로 부팅한 열두 건의 원본을 모두 보존했다. 표의 수치는 같은 부팅에서 측정한 카운터 틱이며, 실패 시 슬롯·소유자·사유·피연산자를 기록했다. 작업자 표식 지연(2/2)과 선택 전 가드 중단(2/5)은 별개다. 물리 보드 시간이나 배포 적합성은 측정하지 않았다.']
(D/'REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
with zipfile.ZipFile(D/'first-captures.zip','w',zipfile.ZIP_DEFLATED) as z:
 for pattern in ['*.py','*.elf','*.map','*.asm','*.log','*.txt','*.tar','freeze.json','REPORT.md','raw/**/*']:
  for f in sorted(D.glob(pattern)):
   if f.is_file():z.write(f,f.relative_to(D))
shutil.copy2(D/'first-captures.zip',H/'first-captures.zip')
assert h(H/'first-captures.zip')==h(D/'first-captures.zip')
print(counts,h(D/'first-captures.zip'))

