
candidate-SE.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000040200000 <_start>:
    40200000:	d5034fdf 	msr	daifset, #0xf
    40200004:	d5384240 	mrs	x0, currentel
    40200008:	f100101f 	cmp	x0, #0x4
    4020000c:	54000241 	b.ne	40200054 <_start+0x54>  // b.any
    40200010:	d50041bf 	msr	spsel, #0x1
    40200014:	58000260 	ldr	x0, 40200060 <_start+0x60>
    40200018:	9100001f 	mov	sp, x0
    4020001c:	d5381040 	mrs	x0, cpacr_el1
    40200020:	b26c0400 	orr	x0, x0, #0x300000
    40200024:	d5181040 	msr	cpacr_el1, x0
    40200028:	d5033fdf 	isb
    4020002c:	580001e0 	ldr	x0, 40200068 <_start+0x68>
    40200030:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    40200034:	f9000001 	str	x1, [x0]
    40200038:	580001c0 	ldr	x0, 40200070 <_start+0x70>
    4020003c:	580001e1 	ldr	x1, 40200078 <_start+0x78>
    40200040:	eb01001f 	cmp	x0, x1
    40200044:	54000062 	b.cs	40200050 <_start+0x50>  // b.hs, b.nlast
    40200048:	f800841f 	str	xzr, [x0], #8
    4020004c:	17fffffd 	b	40200040 <_start+0x40>
    40200050:	1400107c 	b	40204240 <jnox_kernel::kernel_main>
    40200054:	d503205f 	wfe
    40200058:	17ffffff 	b	40200054 <_start+0x54>
    4020005c:	00000000 	udf	#0
    40200060:	40227e40 	.word	0x40227e40
    40200064:	00000000 	.word	0x00000000
    40200068:	40223e20 	.word	0x40223e20
    4020006c:	00000000 	.word	0x00000000
    40200070:	40207710 	.word	0x40207710
    40200074:	00000000 	.word	0x00000000
    40200078:	40223e40 	.word	0x40223e40
	...

0000000040200800 <sched_vectors>:
    40200800:	14000200 00000000 00000000 00000000     ................
	...
    40200880:	140001e0 00000000 00000000 00000000     ................
	...
    40200900:	140001c0 00000000 00000000 00000000     ................
	...
    40200980:	140001a0 00000000 00000000 00000000     ................
	...
    40200a00:	140001b6 00000000 00000000 00000000     ................
	...
    40200a80:	14000161 00000000 00000000 00000000     a...............
	...
    40200b00:	14000140 00000000 00000000 00000000     @...............
	...
    40200b80:	14000120 00000000 00000000 00000000      ...............
	...
    40200c00:	14000100 00000000 00000000 00000000     ................
	...
    40200c80:	140000e0 00000000 00000000 00000000     ................
	...
    40200d00:	140000c0 00000000 00000000 00000000     ................
	...
    40200d80:	140000a0 00000000 00000000 00000000     ................
	...
    40200e00:	14000080 00000000 00000000 00000000     ................
	...
    40200e80:	14000060 00000000 00000000 00000000     `...............
	...
    40200f00:	14000040 00000000 00000000 00000000     @...............
	...
    40200f80:	14000020 00000000 00000000 00000000      ...............
	...
    40201000:	140000aa d10d03ff f90027e9 d5033fdf     .........'...?..
    40201010:	d53be029 f9009fe9 f94027e9 a90007e0     ).;......'@.....
    40201020:	a9010fe2 a90217e4 a9031fe6 a90427e8     .............'..
    40201030:	a9052fea a90637ec a9073fee a90847f0     ./...7...?...G..
    40201040:	a9094ff2 a90a57f4 a90b5ff6 a90c67f8     .O...W..._...g..
    40201050:	a90d6ffa a90e77fc f9007bfe ad0a07e0     .o...w...{......
    40201060:	ad0b0fe2 ad0c17e4 ad0d1fe6 ad0e27e8     .............'..
    40201070:	ad0f2fea ad1037ec ad113fee ad1247f0     ./...7...?...G..
    40201080:	ad134ff2 ad1457f4 ad155ff6 ad1667f8     .O...W..._...g..
    40201090:	ad176ffa ad1877fc ad197ffe d5384029     .o...w......)@8.
    402010a0:	d538400a a90fabe9 d53b4409 d53b442a     .@8......D;.*D;.
    402010b0:	a910abe9 d538d089 d538410a a911abe9     ......8..A8.....
    402010c0:	d53bd049 d53bd06a a912abe9 910003e0     I.;.j.;.........
    402010d0:	9400007e 14000036 d10d03ff f90027e9     ~...6........'..
    402010e0:	d5033fdf d53be029 f9009fe9 f94027e9     .?..).;......'@.
    402010f0:	a90007e0 a9010fe2 a90217e4 a9031fe6     ................
    40201100:	a90427e8 a9052fea a90637ec a9073fee     .'.../...7...?..
    40201110:	a90847f0 a9094ff2 a90a57f4 a90b5ff6     .G...O...W..._..
    40201120:	a90c67f8 a90d6ffa a90e77fc f9007bfe     .g...o...w...{..
    40201130:	ad0a07e0 ad0b0fe2 ad0c17e4 ad0d1fe6     ................
    40201140:	ad0e27e8 ad0f2fea ad1037ec ad113fee     .'.../...7...?..
    40201150:	ad1247f0 ad134ff2 ad1457f4 ad155ff6     .G...O...W..._..
    40201160:	ad1667f8 ad176ffa ad1877fc ad197ffe     .g...o...w......
    40201170:	d5384029 d538400a a90fabe9 d53b4409     )@8..@8......D;.
    40201180:	d53b442a a910abe9 d538d089 d538410a     *D;.......8..A8.
    40201190:	a911abe9 d53bd049 d53bd06a a912abe9     ....I.;.j.;.....
    402011a0:	910003e0 940003c3 14000001              ............

00000000402011ac <sched_start_frame>:
    402011ac:	9100001f 	mov	sp, x0
    402011b0:	a94fabe9 	ldp	x9, x10, [sp, #248]
    402011b4:	d5184029 	msr	elr_el1, x9
    402011b8:	d518400a 	msr	spsr_el1, x10
    402011bc:	a950abe9 	ldp	x9, x10, [sp, #264]
    402011c0:	d51b4409 	msr	fpcr, x9
    402011c4:	d51b442a 	msr	fpsr, x10
    402011c8:	a951abe9 	ldp	x9, x10, [sp, #280]
    402011cc:	d518d089 	msr	tpidr_el1, x9
    402011d0:	d518410a 	msr	sp_el0, x10
    402011d4:	a952abe9 	ldp	x9, x10, [sp, #296]
    402011d8:	d51bd049 	msr	tpidr_el0, x9
    402011dc:	d51bd06a 	msr	tpidrro_el0, x10
    402011e0:	ad4a07e0 	ldp	q0, q1, [sp, #320]
    402011e4:	ad4b0fe2 	ldp	q2, q3, [sp, #352]
    402011e8:	ad4c17e4 	ldp	q4, q5, [sp, #384]
    402011ec:	ad4d1fe6 	ldp	q6, q7, [sp, #416]
    402011f0:	ad4e27e8 	ldp	q8, q9, [sp, #448]
    402011f4:	ad4f2fea 	ldp	q10, q11, [sp, #480]
    402011f8:	ad5037ec 	ldp	q12, q13, [sp, #512]
    402011fc:	ad513fee 	ldp	q14, q15, [sp, #544]
    40201200:	ad5247f0 	ldp	q16, q17, [sp, #576]
    40201204:	ad534ff2 	ldp	q18, q19, [sp, #608]
    40201208:	ad5457f4 	ldp	q20, q21, [sp, #640]
    4020120c:	ad555ff6 	ldp	q22, q23, [sp, #672]
    40201210:	ad5667f8 	ldp	q24, q25, [sp, #704]
    40201214:	ad576ffa 	ldp	q26, q27, [sp, #736]
    40201218:	ad5877fc 	ldp	q28, q29, [sp, #768]
    4020121c:	ad597ffe 	ldp	q30, q31, [sp, #800]
    40201220:	d503201f 	nop
    40201224:	10112e29 	adr	x9, 402237e8 <jnox_ap_returns>
    40201228:	f940012a 	ldr	x10, [x9]
    4020122c:	f101015f 	cmp	x10, #0x40
    40201230:	54ffee82 	b.cs	40201000 <sched_vectors+0x800>  // b.hs, b.nlast
    40201234:	9100054b 	add	x11, x10, #0x1
    40201238:	f800852b 	str	x11, [x9], #8
    4020123c:	d280030b 	mov	x11, #0x18                  	// #24
    40201240:	9b0b2549 	madd	x9, x10, x11, x9
    40201244:	910003ea 	mov	x10, sp
    40201248:	d538402b 	mrs	x11, elr_el1
    4020124c:	a9002d2a 	stp	x10, x11, [x9]
    40201250:	d5033fdf 	isb
    40201254:	d53be02a 	mrs	x10, cntpct_el0
    40201258:	f900092a 	str	x10, [x9, #16]
    4020125c:	a94007e0 	ldp	x0, x1, [sp]
    40201260:	a9410fe2 	ldp	x2, x3, [sp, #16]
    40201264:	a94217e4 	ldp	x4, x5, [sp, #32]
    40201268:	a9431fe6 	ldp	x6, x7, [sp, #48]
    4020126c:	a94427e8 	ldp	x8, x9, [sp, #64]
    40201270:	a9452fea 	ldp	x10, x11, [sp, #80]
    40201274:	a94637ec 	ldp	x12, x13, [sp, #96]
    40201278:	a9473fee 	ldp	x14, x15, [sp, #112]
    4020127c:	a94847f0 	ldp	x16, x17, [sp, #128]
    40201280:	a9494ff2 	ldp	x18, x19, [sp, #144]
    40201284:	a94a57f4 	ldp	x20, x21, [sp, #160]
    40201288:	a94b5ff6 	ldp	x22, x23, [sp, #176]
    4020128c:	a94c67f8 	ldp	x24, x25, [sp, #192]
    40201290:	a94d6ffa 	ldp	x26, x27, [sp, #208]
    40201294:	a94e77fc 	ldp	x28, x29, [sp, #224]
    40201298:	f9407bfe 	ldr	x30, [sp, #240]
    4020129c:	910d03ff 	add	sp, sp, #0x340
    402012a0:	d5033f5f 	clrex
    402012a4:	d69f03e0 	eret

00000000402012a8 <jnox_kernel::ordinary_reservations::unexpected>:
    402012a8:	f81f0ffe 	str	x30, [sp, #-16]!
    402012ac:	52800060 	mov	w0, #0x3                   	// #3
    402012b0:	52800021 	mov	w1, #0x1                   	// #1
    402012b4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    402012b8:	52800043 	mov	w3, #0x2                   	// #2
    402012bc:	aa1f03e4 	mov	x4, xzr
    402012c0:	aa1f03e5 	mov	x5, xzr
    402012c4:	9400050b 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>

00000000402012c8 <jnox_kernel::ordinary_reservations::irq>:
    402012c8:	d10583ff 	sub	sp, sp, #0x160
    402012cc:	a9107bfd 	stp	x29, x30, [sp, #256]
    402012d0:	a9116ffc 	stp	x28, x27, [sp, #272]
    402012d4:	a91267fa 	stp	x26, x25, [sp, #288]
    402012d8:	a9135ff8 	stp	x24, x23, [sp, #304]
    402012dc:	a91457f6 	stp	x22, x21, [sp, #320]
    402012e0:	a9154ff4 	stp	x20, x19, [sp, #336]
    402012e4:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402012e8:	f9420108 	ldr	x8, [x8, #1024]
    402012ec:	f100091f 	cmp	x8, #0x2
    402012f0:	54003600 	b.eq	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.none
    402012f4:	aa0003f4 	mov	x20, x0
    402012f8:	d0000038 	adrp	x24, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402012fc:	d503201f 	nop
    40201300:	100b2108 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062>
    40201304:	f942b309 	ldr	x9, [x24, #1376]
    40201308:	8b09390a 	add	x10, x8, x9, lsl #14
    4020130c:	eb00015f 	cmp	x10, x0
    40201310:	54003508 	b.hi	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.pmore
    40201314:	b10d069f 	cmn	x20, #0x341
    40201318:	540034c8 	b.hi	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.pmore
    4020131c:	d372c529 	lsl	x9, x9, #14
    40201320:	8b090108 	add	x8, x8, x9
    40201324:	91401108 	add	x8, x8, #0x4, lsl #12
    40201328:	910d0289 	add	x9, x20, #0x340
    4020132c:	eb08013f 	cmp	x9, x8
    40201330:	54003408 	b.hi	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.pmore
    40201334:	52800199 	mov	w25, #0xc                   	// #12
    40201338:	72a10039 	movk	w25, #0x801, lsl #16
    4020133c:	f9409e95 	ldr	x21, [x20, #312]
    40201340:	b9400336 	ldr	w22, [x25]
    40201344:	d53be237 	mrs	x23, cntp_ctl_el0
    40201348:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020134c:	91156129 	add	x9, x9, #0x558
    40201350:	f9401928 	ldr	x8, [x9, #48]
    40201354:	f9400133 	ldr	x19, [x9]
    40201358:	f100051f 	cmp	x8, #0x1
    4020135c:	540000e0 	b.eq	40201378 <jnox_kernel::ordinary_reservations::irq+0xb0>  // b.none
    40201360:	b100067f 	cmn	x19, #0x1
    40201364:	54000060 	b.eq	40201370 <jnox_kernel::ordinary_reservations::irq+0xa8>  // b.none
    40201368:	91000673 	add	x19, x19, #0x1
    4020136c:	14000003 	b	40201378 <jnox_kernel::ordinary_reservations::irq+0xb0>
    40201370:	b4004648 	cbz	x8, 40201c38 <jnox_kernel::ordinary_reservations::irq+0x970>
    40201374:	aa1f03f3 	mov	x19, xzr
    40201378:	d000003a 	adrp	x26, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020137c:	9115835a 	add	x26, x26, #0x560
    40201380:	f9401349 	ldr	x9, [x26, #32]
    40201384:	a909a3e9 	stp	x9, x8, [sp, #152]
    40201388:	f9400343 	ldr	x3, [x26]
    4020138c:	a90adff6 	stp	x22, x23, [sp, #168]
    40201390:	910263e4 	add	x4, sp, #0x98
    40201394:	52800080 	mov	w0, #0x4                   	// #4
    40201398:	aa1503e1 	mov	x1, x21
    4020139c:	aa1303e2 	mov	x2, x19
    402013a0:	9400047d 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    402013a4:	f9401348 	ldr	x8, [x26, #32]
    402013a8:	120026c9 	and	w9, w22, #0x3ff
    402013ac:	7100793f 	cmp	w9, #0x1e
    402013b0:	54004ec1 	b.ne	40201d88 <jnox_kernel::ordinary_reservations::irq+0xac0>  // b.any
    402013b4:	92400ae9 	and	x9, x23, #0x7
    402013b8:	f100153f 	cmp	x9, #0x5
    402013bc:	54004e61 	b.ne	40201d88 <jnox_kernel::ordinary_reservations::irq+0xac0>  // b.any
    402013c0:	eb0802bf 	cmp	x21, x8
    402013c4:	54004e23 	b.cc	40201d88 <jnox_kernel::ordinary_reservations::irq+0xac0>  // b.lo, b.ul, b.last
    402013c8:	d51be23f 	msr	cntp_ctl_el0, xzr
    402013cc:	d5033fdf 	isb
    402013d0:	d5033f9f 	dsb	sy
    402013d4:	b9000736 	str	w22, [x25, #4]
    402013d8:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402013dc:	f942c509 	ldr	x9, [x8, #1416]
    402013e0:	aa090269 	orr	x9, x19, x9
    402013e4:	b5000229 	cbnz	x9, 40201428 <jnox_kernel::ordinary_reservations::irq+0x160>
    402013e8:	d5033f9f 	dsb	sy
    402013ec:	d5033fdf 	isb
    402013f0:	d53be029 	mrs	x9, cntpct_el0
    402013f4:	10ffffea 	adr	x10, 402013f0 <jnox_kernel::ordinary_reservations::irq+0x128>
    402013f8:	a902a7ea 	stp	x10, x9, [sp, #40]
    402013fc:	52800029 	mov	w9, #0x1                   	// #1
    40201400:	f9004fe9 	str	x9, [sp, #152]
    40201404:	d503201f 	nop
    40201408:	10115109 	adr	x9, 40223e28 <jnox_kernel::ordinary_reservations::stage_hooks::stage_probe::OBSERVATION>
    4020140c:	f9404fea 	ldr	x10, [sp, #152]
    40201410:	f900012a 	str	x10, [x9]
    40201414:	f9401bea 	ldr	x10, [sp, #48]
    40201418:	f900052a 	str	x10, [x9, #8]
    4020141c:	f94017ea 	ldr	x10, [sp, #40]
    40201420:	f900092a 	str	x10, [x9, #16]
    40201424:	14000002 	b	4020142c <jnox_kernel::ordinary_reservations::irq+0x164>
    40201428:	d5033f9f 	dsb	sy
    4020142c:	f942c508 	ldr	x8, [x8, #1416]
    40201430:	f100051f 	cmp	x8, #0x1
    40201434:	540003e1 	b.ne	402014b0 <jnox_kernel::ordinary_reservations::irq+0x1e8>  // b.any
    40201438:	aa1403e0 	mov	x0, x20
    4020143c:	aa1503e1 	mov	x1, x21
    40201440:	2a1f03e2 	mov	w2, wzr
    40201444:	aa1f03e3 	mov	x3, xzr
    40201448:	9400065f 	bl	40202dc4 <jnox_kernel::ordinary_reservations::Runtime::close>
    4020144c:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201450:	9114e108 	add	x8, x8, #0x538
    40201454:	91000669 	add	x9, x19, #0x1
    40201458:	a9402908 	ldp	x8, x10, [x8]
    4020145c:	9bca7d2b 	umulh	x11, x9, x10
    40201460:	eb0b03ff 	cmp	xzr, x11
    40201464:	1a9f07eb 	cset	w11, ne  // ne = any
    40201468:	9b0a7d29 	mul	x9, x9, x10
    4020146c:	ab080122 	adds	x2, x9, x8
    40201470:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40201474:	3700486b 	tbnz	w11, #0, 40201d80 <jnox_kernel::ordinary_reservations::irq+0xab8>
    40201478:	35004848 	cbnz	w8, 40201d80 <jnox_kernel::ordinary_reservations::irq+0xab8>
    4020147c:	aa1303e0 	mov	x0, x19
    40201480:	aa1f03e1 	mov	x1, xzr
    40201484:	9400062f 	bl	40202d40 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201488:	aa1303e0 	mov	x0, x19
    4020148c:	52800041 	mov	w1, #0x2                   	// #2
    40201490:	a9554ff4 	ldp	x20, x19, [sp, #336]
    40201494:	a95457f6 	ldp	x22, x21, [sp, #320]
    40201498:	a9535ff8 	ldp	x24, x23, [sp, #304]
    4020149c:	a95267fa 	ldp	x26, x25, [sp, #288]
    402014a0:	a9516ffc 	ldp	x28, x27, [sp, #272]
    402014a4:	a9507bfd 	ldp	x29, x30, [sp, #256]
    402014a8:	910583ff 	add	sp, sp, #0x160
    402014ac:	1400077f 	b	402032a8 <jnox_kernel::ordinary_reservations::Runtime::select>
    402014b0:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014b4:	9114c129 	add	x9, x9, #0x530
    402014b8:	f940192a 	ldr	x10, [x9, #48]
    402014bc:	f100095f 	cmp	x10, #0x2
    402014c0:	54002781 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    402014c4:	39400129 	ldrb	w9, [x9]
    402014c8:	71000d3f 	cmp	w9, #0x3
    402014cc:	54002721 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    402014d0:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014d4:	91152129 	add	x9, x9, #0x548
    402014d8:	f9001934 	str	x20, [x9, #48]
    402014dc:	f9401d25 	ldr	x5, [x9, #56]
    402014e0:	cb0502aa 	sub	x10, x21, x5
    402014e4:	f9400129 	ldr	x9, [x9]
    402014e8:	eb09015f 	cmp	x10, x9
    402014ec:	54004668 	b.hi	40201db8 <jnox_kernel::ordinary_reservations::irq+0xaf0>  // b.pmore
    402014f0:	b40013f3 	cbz	x19, 4020176c <jnox_kernel::ordinary_reservations::irq+0x4a4>
    402014f4:	92800028 	mov	x8, #0xfffffffffffffffe    	// #-2
    402014f8:	d0000037 	adrp	x23, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014fc:	d0000038 	adrp	x24, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201500:	91174318 	add	x24, x24, #0x5d0
    40201504:	b4000428 	cbz	x8, 40201588 <jnox_kernel::ordinary_reservations::irq+0x2c0>
    40201508:	aa0803f6 	mov	x22, x8
    4020150c:	910263e8 	add	x8, sp, #0x98
    40201510:	91000ac0 	add	x0, x22, #0x2
    40201514:	940007a1 	bl	40203398 <jnox_kernel::ordinary_reservations::snapshot>
    40201518:	a949d7f4 	ldp	x20, x21, [sp, #152]
    4020151c:	f942aae8 	ldr	x8, [x23, #1360]
    40201520:	eb08027f 	cmp	x19, x8
    40201524:	54000161 	b.ne	40201550 <jnox_kernel::ordinary_reservations::irq+0x288>  // b.any
    40201528:	f94057e8 	ldr	x8, [sp, #168]
    4020152c:	d5033fdf 	isb
    40201530:	d53be021 	mrs	x1, cntpct_el0
    40201534:	a909d7f4 	stp	x20, x21, [sp, #152]
    40201538:	a90affe8 	stp	x8, xzr, [sp, #168]
    4020153c:	91000ac3 	add	x3, x22, #0x2
    40201540:	910263e4 	add	x4, sp, #0x98
    40201544:	528002a0 	mov	w0, #0x15                  	// #21
    40201548:	aa1303e2 	mov	x2, x19
    4020154c:	94000412 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40201550:	f85f0308 	ldur	x8, [x24, #-16]
    40201554:	eb08029f 	cmp	x20, x8
    40201558:	540000a1 	b.ne	4020156c <jnox_kernel::ordinary_reservations::irq+0x2a4>  // b.any
    4020155c:	f8408709 	ldr	x9, [x24], #8
    40201560:	910006c8 	add	x8, x22, #0x1
    40201564:	eb0902bf 	cmp	x21, x9
    40201568:	54fffce0 	b.eq	40201504 <jnox_kernel::ordinary_reservations::irq+0x23c>  // b.none
    4020156c:	91000ac3 	add	x3, x22, #0x2
    40201570:	52800060 	mov	w0, #0x3                   	// #3
    40201574:	52800101 	mov	w1, #0x8                   	// #8
    40201578:	aa1303e2 	mov	x2, x19
    4020157c:	aa1403e4 	mov	x4, x20
    40201580:	aa1503e5 	mov	x5, x21
    40201584:	9400045b 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>
    40201588:	f942aae8 	ldr	x8, [x23, #1360]
    4020158c:	eb08027f 	cmp	x19, x8
    40201590:	540043a0 	b.eq	40201e04 <jnox_kernel::ordinary_reservations::irq+0xb3c>  // b.none
    40201594:	94000734 	bl	40203264 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    40201598:	910263e8 	add	x8, sp, #0x98
    4020159c:	aa1303e1 	mov	x1, x19
    402015a0:	940008c8 	bl	402038c0 <jnox_kernel::reservation_jobs::Jobs::open>
    402015a4:	f9404fe8 	ldr	x8, [sp, #152]
    402015a8:	f100091f 	cmp	x8, #0x2
    402015ac:	54004380 	b.eq	40201e1c <jnox_kernel::ordinary_reservations::irq+0xb54>  // b.none
    402015b0:	9100c3e0 	add	x0, sp, #0x30
    402015b4:	910263e1 	add	x1, sp, #0x98
    402015b8:	52800d02 	mov	w2, #0x68                  	// #104
    402015bc:	94001127 	bl	40205a58 <memcpy>
    402015c0:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402015c4:	9114e129 	add	x9, x9, #0x538
    402015c8:	a9402129 	ldp	x9, x8, [x9]
    402015cc:	9bc87e6a 	umulh	x10, x19, x8
    402015d0:	eb0a03ff 	cmp	xzr, x10
    402015d4:	1a9f07eb 	cset	w11, ne  // ne = any
    402015d8:	9b087e6a 	mul	x10, x19, x8
    402015dc:	ab09014c 	adds	x12, x10, x9
    402015e0:	1a9f37ea 	cset	w10, cs  // cs = hs, nlast
    402015e4:	37003ceb 	tbnz	w11, #0, 40201d80 <jnox_kernel::ordinary_reservations::irq+0xab8>
    402015e8:	35003cca 	cbnz	w10, 40201d80 <jnox_kernel::ordinary_reservations::irq+0xab8>
    402015ec:	9100066b 	add	x11, x19, #0x1
    402015f0:	9bc87d6a 	umulh	x10, x11, x8
    402015f4:	eb0a03ff 	cmp	xzr, x10
    402015f8:	1a9f07ea 	cset	w10, ne  // ne = any
    402015fc:	9b087d68 	mul	x8, x11, x8
    40201600:	ab090108 	adds	x8, x8, x9
    40201604:	a901a3ec 	stp	x12, x8, [sp, #24]
    40201608:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    4020160c:	37003baa 	tbnz	w10, #0, 40201d80 <jnox_kernel::ordinary_reservations::irq+0xab8>
    40201610:	35003b88 	cbnz	w8, 40201d80 <jnox_kernel::ordinary_reservations::irq+0xab8>
    40201614:	aa1f03f6 	mov	x22, xzr
    40201618:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020161c:	39424beb 	ldrb	w11, [sp, #146]
    40201620:	9100c3e9 	add	x9, sp, #0x30
    40201624:	9100613d 	add	x29, x9, #0x18
    40201628:	b94033fc 	ldr	w28, [sp, #48]
    4020162c:	9100e137 	add	x23, x9, #0x38
    40201630:	91004138 	add	x24, x9, #0x10
    40201634:	f9401ff5 	ldr	x21, [sp, #56]
    40201638:	9100056a 	add	x10, x11, #0x1
    4020163c:	71000d7f 	cmp	w11, #0x3
    40201640:	f902ad13 	str	x19, [x8, #1368]
    40201644:	91000568 	add	x8, x11, #0x1
    40201648:	a900afe8 	stp	x8, x11, [sp, #8]
    4020164c:	1a8a03f9 	csel	w25, wzr, w10, eq  // eq = none
    40201650:	91016134 	add	x20, x9, #0x58
    40201654:	9101813a 	add	x26, x9, #0x60
    40201658:	52800028 	mov	w8, #0x1                   	// #1
    4020165c:	8b1613a9 	add	x9, x29, x22, lsl #4
    40201660:	8b1612ea 	add	x10, x23, x22, lsl #4
    40201664:	d5033fdf 	isb
    40201668:	d53be021 	mrs	x1, cntpct_el0
    4020166c:	2a0803fb 	mov	w27, w8
    40201670:	a9402528 	ldp	x8, x9, [x9]
    40201674:	a909a7e8 	stp	x8, x9, [sp, #152]
    40201678:	a9402548 	ldp	x8, x9, [x10]
    4020167c:	a90aa7e8 	stp	x8, x9, [sp, #168]
    40201680:	910263e4 	add	x4, sp, #0x98
    40201684:	528000a0 	mov	w0, #0x5                   	// #5
    40201688:	aa1303e2 	mov	x2, x19
    4020168c:	aa1603e3 	mov	x3, x22
    40201690:	940003c1 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40201694:	d5033fdf 	isb
    40201698:	d53be021 	mrs	x1, cntpct_el0
    4020169c:	b8767b08 	ldr	w8, [x24, x22, lsl #2]
    402016a0:	eb1502df 	cmp	x22, x21
    402016a4:	b8767a89 	ldr	w9, [x20, x22, lsl #2]
    402016a8:	38766b4a 	ldrb	w10, [x26, x22]
    402016ac:	1a9f17eb 	cset	w11, eq  // eq = none
    402016b0:	a909a7e8 	stp	x8, x9, [sp, #152]
    402016b4:	6a0b039f 	tst	w28, w11
    402016b8:	9a9f1328 	csel	x8, x25, xzr, ne  // ne = any
    402016bc:	a90aa3ea 	stp	x10, x8, [sp, #168]
    402016c0:	910263e4 	add	x4, sp, #0x98
    402016c4:	528000c0 	mov	w0, #0x6                   	// #6
    402016c8:	aa1303e2 	mov	x2, x19
    402016cc:	aa1603e3 	mov	x3, x22
    402016d0:	940003b1 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    402016d4:	2a1f03e8 	mov	w8, wzr
    402016d8:	52800036 	mov	w22, #0x1                   	// #1
    402016dc:	3707fc1b 	tbnz	w27, #0, 4020165c <jnox_kernel::ordinary_reservations::irq+0x394>
    402016e0:	340029fc 	cbz	w28, 40201c1c <jnox_kernel::ordinary_reservations::irq+0x954>
    402016e4:	f9400bf6 	ldr	x22, [sp, #16]
    402016e8:	71000edf 	cmp	w22, #0x3
    402016ec:	54001620 	b.eq	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.none
    402016f0:	910263e8 	add	x8, sp, #0x98
    402016f4:	aa1503e0 	mov	x0, x21
    402016f8:	94000728 	bl	40203398 <jnox_kernel::ordinary_reservations::snapshot>
    402016fc:	f1000abf 	cmp	x21, #0x2
    40201700:	54003a42 	b.cs	40201e48 <jnox_kernel::ordinary_reservations::irq+0xb80>  // b.hs, b.nlast
    40201704:	a949a7e8 	ldp	x8, x9, [sp, #152]
    40201708:	d503201f 	nop
    4020170c:	1002e7aa 	adr	x10, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40201710:	8b150d4b 	add	x11, x10, x21, lsl #3
    40201714:	f940c96c 	ldr	x12, [x11, #400]
    40201718:	9100c3ea 	add	x10, sp, #0x30
    4020171c:	8b15114a 	add	x10, x10, x21, lsl #4
    40201720:	f940214a 	ldr	x10, [x10, #64]
    40201724:	eb0a019f 	cmp	x12, x10
    40201728:	54000060 	b.eq	40201734 <jnox_kernel::ordinary_reservations::irq+0x46c>  // b.none
    4020172c:	f900c96a 	str	x10, [x11, #400]
    40201730:	f900d17f 	str	xzr, [x11, #416]
    40201734:	d000010b 	adrp	x11, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0xb8e0>
    40201738:	f943f56b 	ldr	x11, [x11, #2024]
    4020173c:	d000002c 	adrp	x12, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201740:	9114018c 	add	x12, x12, #0x500
    40201744:	a9004d95 	stp	x21, x19, [x12]
    40201748:	a901218b 	stp	x11, x8, [x12, #16]
    4020174c:	a9022989 	stp	x9, x10, [x12, #32]
    40201750:	3900c196 	strb	w22, [x12, #48]
    40201754:	f94013f4 	ldr	x20, [sp, #32]
    40201758:	340029b6 	cbz	w22, 40201c8c <jnox_kernel::ordinary_reservations::irq+0x9c4>
    4020175c:	b104011f 	cmn	x8, #0x100
    40201760:	540037e2 	b.cs	40201e5c <jnox_kernel::ordinary_reservations::irq+0xb94>  // b.hs, b.nlast
    40201764:	91040108 	add	x8, x8, #0x100
    40201768:	1400014a 	b	40201c90 <jnox_kernel::ordinary_reservations::irq+0x9c8>
    4020176c:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201770:	f942f129 	ldr	x9, [x9, #1504]
    40201774:	f100093f 	cmp	x9, #0x2
    40201778:	540011c0 	b.eq	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.none
    4020177c:	b50011a8 	cbnz	x8, 402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>
    40201780:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201784:	f942ad08 	ldr	x8, [x8, #1368]
    40201788:	b100051f 	cmn	x8, #0x1
    4020178c:	54001121 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201790:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201794:	f9432d08 	ldr	x8, [x8, #1624]
    40201798:	eb0800bf 	cmp	x5, x8
    4020179c:	540010a1 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    402017a0:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402017a4:	f9429d29 	ldr	x9, [x9, #1336]
    402017a8:	eb08013f 	cmp	x9, x8
    402017ac:	54001021 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    402017b0:	d0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0xb8e0>
    402017b4:	f943f508 	ldr	x8, [x8, #2024]
    402017b8:	f100051f 	cmp	x8, #0x1
    402017bc:	54000fa1 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    402017c0:	d503201f 	nop
    402017c4:	101100e8 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    402017c8:	c8dffd09 	ldar	x9, [x8]
    402017cc:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402017d0:	f942354a 	ldr	x10, [x10, #1128]
    402017d4:	aa0a0129 	orr	x9, x9, x10
    402017d8:	b5000ec9 	cbnz	x9, 402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>
    402017dc:	aa1f03eb 	mov	x11, xzr
    402017e0:	5280002a 	mov	w10, #0x1                   	// #1
    402017e4:	d503201f 	nop
    402017e8:	1002e0d7 	adr	x23, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402017ec:	8b0b02e9 	add	x9, x23, x11
    402017f0:	3941e129 	ldrb	w9, [x9, #120]
    402017f4:	3600008a 	tbz	w10, #0, 40201804 <jnox_kernel::ordinary_reservations::irq+0x53c>
    402017f8:	2a1f03ea 	mov	w10, wzr
    402017fc:	5280002b 	mov	w11, #0x1                   	// #1
    40201800:	34ffff69 	cbz	w9, 402017ec <jnox_kernel::ordinary_reservations::irq+0x524>
    40201804:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201808:	9111814a 	add	x10, x10, #0x460
    4020180c:	3940014b 	ldrb	w11, [x10]
    40201810:	f940094a 	ldr	x10, [x10, #16]
    40201814:	7100013f 	cmp	w9, #0x0
    40201818:	7a430960 	ccmp	w11, #0x3, #0x0, eq  // eq = none
    4020181c:	fa400940 	ccmp	x10, #0x0, #0x0, eq  // eq = none
    40201820:	54000c81 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201824:	d000010b 	adrp	x11, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0xb8e0>
    40201828:	911fc16b 	add	x11, x11, #0x7f0
    4020182c:	f9400969 	ldr	x9, [x11, #16]
    40201830:	f940056a 	ldr	x10, [x11, #8]
    40201834:	f940016b 	ldr	x11, [x11]
    40201838:	d000010c 	adrp	x12, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0xb8e0>
    4020183c:	910f818c 	add	x12, x12, #0x3e0
    40201840:	eb0c017f 	cmp	x11, x12
    40201844:	54000b61 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201848:	d503201f 	nop
    4020184c:	10004a6b 	adr	x11, 40202198 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062>
    40201850:	eb0b015f 	cmp	x10, x11
    40201854:	54000ae1 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201858:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020185c:	f943254a 	ldr	x10, [x10, #1608]
    40201860:	eb0a013f 	cmp	x9, x10
    40201864:	54000a68 	b.hi	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.pmore
    40201868:	aa1f03e9 	mov	x9, xzr
    4020186c:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201870:	911aa14a 	add	x10, x10, #0x6a8
    40201874:	d00000cb 	adrp	x11, 4021b000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0x38e0>
    40201878:	911c816b 	add	x11, x11, #0x720
    4020187c:	d503201f 	nop
    40201880:	1002f359 	adr	x25, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40201884:	d503201f 	nop
    40201888:	10112b5a 	adr	x26, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    4020188c:	d503201f 	nop
    40201890:	1002f35c 	adr	x28, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40201894:	d503201f 	nop
    40201898:	10112b5b 	adr	x27, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    4020189c:	d503201f 	nop
    402018a0:	10112b8c 	adr	x12, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    402018a4:	f100413f 	cmp	x9, #0x10
    402018a8:	54000860 	b.eq	402019b4 <jnox_kernel::ordinary_reservations::irq+0x6ec>  // b.none
    402018ac:	8b0902ed 	add	x13, x23, x9
    402018b0:	f940b5ad 	ldr	x13, [x13, #360]
    402018b4:	f85d014e 	ldur	x14, [x10, #-48]
    402018b8:	eb0d01df 	cmp	x14, x13
    402018bc:	540007a1 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    402018c0:	d10d016e 	sub	x14, x11, #0x340
    402018c4:	d140116f 	sub	x15, x11, #0x4, lsl #12
    402018c8:	eb0d01df 	cmp	x14, x13
    402018cc:	fa4d01e2 	ccmp	x15, x13, #0x2, eq  // eq = none
    402018d0:	54000708 	b.hi	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.pmore
    402018d4:	b10d05bf 	cmn	x13, #0x341
    402018d8:	540006c8 	b.hi	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.pmore
    402018dc:	910d01ae 	add	x14, x13, #0x340
    402018e0:	eb0b01df 	cmp	x14, x11
    402018e4:	54000668 	b.hi	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.pmore
    402018e8:	f9407dae 	ldr	x14, [x13, #248]
    402018ec:	f85d814f 	ldur	x15, [x10, #-40]
    402018f0:	eb0f01df 	cmp	x14, x15
    402018f4:	540005e1 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    402018f8:	f94081ae 	ldr	x14, [x13, #256]
    402018fc:	f85e014f 	ldur	x15, [x10, #-32]
    40201900:	eb0f01df 	cmp	x14, x15
    40201904:	54000561 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201908:	f9404dae 	ldr	x14, [x13, #152]
    4020190c:	f85e814f 	ldur	x15, [x10, #-24]
    40201910:	eb0f01df 	cmp	x14, x15
    40201914:	540004e1 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201918:	f9408dad 	ldr	x13, [x13, #280]
    4020191c:	f85f014e 	ldur	x14, [x10, #-16]
    40201920:	eb0e01bf 	cmp	x13, x14
    40201924:	54000461 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201928:	8b09032d 	add	x13, x25, x9
    4020192c:	c8dffdad 	ldar	x13, [x13]
    40201930:	b10005bf 	cmn	x13, #0x1
    40201934:	540003e1 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201938:	8b09034d 	add	x13, x26, x9
    4020193c:	c8dffdad 	ldar	x13, [x13]
    40201940:	b500038d 	cbnz	x13, 402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>
    40201944:	8b09038d 	add	x13, x28, x9
    40201948:	c8dffdad 	ldar	x13, [x13]
    4020194c:	b10005bf 	cmn	x13, #0x1
    40201950:	54000301 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201954:	8b09036d 	add	x13, x27, x9
    40201958:	c8dffdad 	ldar	x13, [x13]
    4020195c:	b50002ad 	cbnz	x13, 402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>
    40201960:	8b09018d 	add	x13, x12, x9
    40201964:	c8dffdad 	ldar	x13, [x13]
    40201968:	b500024d 	cbnz	x13, 402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>
    4020196c:	8b0902ed 	add	x13, x23, x9
    40201970:	f940e1ae 	ldr	x14, [x13, #448]
    40201974:	f85f814f 	ldur	x15, [x10, #-8]
    40201978:	eb0f01df 	cmp	x14, x15
    4020197c:	540001a1 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201980:	f940e9ad 	ldr	x13, [x13, #464]
    40201984:	f843854e 	ldr	x14, [x10], #56
    40201988:	eb0e01bf 	cmp	x13, x14
    4020198c:	54000121 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201990:	8b0902ed 	add	x13, x23, x9
    40201994:	f940c9ae 	ldr	x14, [x13, #400]
    40201998:	b10005df 	cmn	x14, #0x1
    4020199c:	540000a1 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    402019a0:	f940d1ad 	ldr	x13, [x13, #416]
    402019a4:	91002129 	add	x9, x9, #0x8
    402019a8:	9140116b 	add	x11, x11, #0x4, lsl #12
    402019ac:	b4fff7cd 	cbz	x13, 402018a4 <jnox_kernel::ordinary_reservations::irq+0x5dc>
    402019b0:	97fffe3e 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402019b4:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402019b8:	f942412a 	ldr	x10, [x9, #1152]
    402019bc:	f100095f 	cmp	x10, #0x2
    402019c0:	54ffff80 	b.eq	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.none
    402019c4:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402019c8:	91136129 	add	x9, x9, #0x4d8
    402019cc:	39402138 	ldrb	w24, [x9, #8]
    402019d0:	71000f1f 	cmp	w24, #0x3
    402019d4:	54fffee0 	b.eq	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.none
    402019d8:	3941eaeb 	ldrb	w11, [x23, #122]
    402019dc:	3943eaec 	ldrb	w12, [x23, #250]
    402019e0:	6b0c017f 	cmp	w11, w12
    402019e4:	54fffe61 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    402019e8:	f94002eb 	ldr	x11, [x23]
    402019ec:	eb0a017f 	cmp	x11, x10
    402019f0:	54fffe01 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    402019f4:	d503201f 	nop
    402019f8:	1002df54 	adr	x20, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    402019fc:	f940028a 	ldr	x10, [x20]
    40201a00:	b4fffd8a 	cbz	x10, 402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>
    40201a04:	f9400133 	ldr	x19, [x9]
    40201a08:	f9400689 	ldr	x9, [x20, #8]
    40201a0c:	eb13013f 	cmp	x9, x19
    40201a10:	54fffd01 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201a14:	39418a89 	ldrb	w9, [x20, #98]
    40201a18:	6b09031f 	cmp	w24, w9
    40201a1c:	54fffca1 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201a20:	f90013e5 	str	x5, [sp, #32]
    40201a24:	d000011d 	adrp	x29, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0xb8e0>
    40201a28:	911cc3bd 	add	x29, x29, #0x730
    40201a2c:	d5033fdf 	isb
    40201a30:	d53be036 	mrs	x22, cntpct_el0
    40201a34:	f9001fb6 	str	x22, [x29, #56]
    40201a38:	f94003a9 	ldr	x9, [x29]
    40201a3c:	b27f0129 	orr	x9, x9, #0x2
    40201a40:	f90003a9 	str	x9, [x29]
    40201a44:	eb1502df 	cmp	x22, x21
    40201a48:	54001c43 	b.cc	40201dd0 <jnox_kernel::ordinary_reservations::irq+0xb08>  // b.lo, b.ul, b.last
    40201a4c:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201a50:	9114e14a 	add	x10, x10, #0x538
    40201a54:	f9400149 	ldr	x9, [x10]
    40201a58:	eb0902c9 	subs	x9, x22, x9
    40201a5c:	54001ba3 	b.cc	40201dd0 <jnox_kernel::ordinary_reservations::irq+0xb08>  // b.lo, b.ul, b.last
    40201a60:	f940094a 	ldr	x10, [x10, #16]
    40201a64:	eb0a013f 	cmp	x9, x10
    40201a68:	54001b48 	b.hi	40201dd0 <jnox_kernel::ordinary_reservations::irq+0xb08>  // b.pmore
    40201a6c:	52800069 	mov	w9, #0x3                   	// #3
    40201a70:	c89ffd09 	stlr	x9, [x8]
    40201a74:	c8dffd15 	ldar	x21, [x8]
    40201a78:	940005fb 	bl	40203264 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    40201a7c:	f9402c08 	ldr	x8, [x0, #88]
    40201a80:	39418009 	ldrb	w9, [x0, #96]
    40201a84:	d5033fdf 	isb
    40201a88:	d53be024 	mrs	x4, cntpct_el0
    40201a8c:	f94003aa 	ldr	x10, [x29]
    40201a90:	a90457a4 	stp	x4, x21, [x29, #64]
    40201a94:	71000d3f 	cmp	w9, #0x3
    40201a98:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40201a9c:	f9002ba8 	str	x8, [x29, #80]
    40201aa0:	b27e0149 	orr	x9, x10, #0x4
    40201aa4:	f90003a9 	str	x9, [x29]
    40201aa8:	f1000ebf 	cmp	x21, #0x3
    40201aac:	54fff821 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201ab0:	eb13011f 	cmp	x8, x19
    40201ab4:	54fff7e1 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201ab8:	eb16009f 	cmp	x4, x22
    40201abc:	d000002e 	adrp	x14, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201ac0:	9114e1ce 	add	x14, x14, #0x538
    40201ac4:	54001703 	b.cc	40201da4 <jnox_kernel::ordinary_reservations::irq+0xadc>  // b.lo, b.ul, b.last
    40201ac8:	f94001c8 	ldr	x8, [x14]
    40201acc:	eb080088 	subs	x8, x4, x8
    40201ad0:	540016a3 	b.cc	40201da4 <jnox_kernel::ordinary_reservations::irq+0xadc>  // b.lo, b.ul, b.last
    40201ad4:	f94009c9 	ldr	x9, [x14, #16]
    40201ad8:	eb09011f 	cmp	x8, x9
    40201adc:	54001648 	b.hi	40201da4 <jnox_kernel::ordinary_reservations::irq+0xadc>  // b.pmore
    40201ae0:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201ae4:	f902ad1f 	str	xzr, [x8, #1368]
    40201ae8:	f100067f 	cmp	x19, #0x1
    40201aec:	54001a68 	b.hi	40201e38 <jnox_kernel::ordinary_reservations::irq+0xb70>  // b.pmore
    40201af0:	8b131288 	add	x8, x20, x19, lsl #4
    40201af4:	f9402108 	ldr	x8, [x8, #64]
    40201af8:	8b130ee9 	add	x9, x23, x19, lsl #3
    40201afc:	f900c928 	str	x8, [x9, #400]
    40201b00:	f940e12a 	ldr	x10, [x9, #448]
    40201b04:	f940e92b 	ldr	x11, [x9, #464]
    40201b08:	a9107ef3 	stp	x19, xzr, [x23, #256]
    40201b0c:	5280002c 	mov	w12, #0x1                   	// #1
    40201b10:	a9112aec 	stp	x12, x10, [x23, #272]
    40201b14:	a91222eb 	stp	x11, x8, [x23, #288]
    40201b18:	3904c2f8 	strb	w24, [x23, #304]
    40201b1c:	8b130f88 	add	x8, x28, x19, lsl #3
    40201b20:	a948aa8b 	ldp	x11, x10, [x20, #136]
    40201b24:	c89ffd0a 	stlr	x10, [x8]
    40201b28:	91000708 	add	x8, x24, #0x1
    40201b2c:	f8337b48 	str	x8, [x26, x19, lsl #3]
    40201b30:	f8337b7f 	str	xzr, [x27, x19, lsl #3]
    40201b34:	8b130f28 	add	x8, x25, x19, lsl #3
    40201b38:	c89ffd1f 	stlr	xzr, [x8]
    40201b3c:	a91832eb 	stp	x11, x12, [x23, #384]
    40201b40:	d51be24b 	msr	cntp_cval_el0, x11
    40201b44:	d51be22c 	msr	cntp_ctl_el0, x12
    40201b48:	d5033fdf 	isb
    40201b4c:	d53be24d 	mrs	x13, cntp_cval_el0
    40201b50:	d53be228 	mrs	x8, cntp_ctl_el0
    40201b54:	d5033fdf 	isb
    40201b58:	d53be02a 	mrs	x10, cntpct_el0
    40201b5c:	a906a3ad 	stp	x13, x8, [x29, #104]
    40201b60:	a905afaa 	stp	x10, x11, [x29, #88]
    40201b64:	f94003ac 	ldr	x12, [x29]
    40201b68:	b27d018c 	orr	x12, x12, #0x8
    40201b6c:	f90003ac 	str	x12, [x29]
    40201b70:	eb0b01bf 	cmp	x13, x11
    40201b74:	54fff1e1 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201b78:	92400508 	and	x8, x8, #0x3
    40201b7c:	f100051f 	cmp	x8, #0x1
    40201b80:	54fff181 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201b84:	d5033fdf 	isb
    40201b88:	d53be028 	mrs	x8, cntpct_el0
    40201b8c:	eb04015f 	cmp	x10, x4
    40201b90:	540012c3 	b.cc	40201de8 <jnox_kernel::ordinary_reservations::irq+0xb20>  // b.lo, b.ul, b.last
    40201b94:	eb0a011f 	cmp	x8, x10
    40201b98:	54001283 	b.cc	40201de8 <jnox_kernel::ordinary_reservations::irq+0xb20>  // b.lo, b.ul, b.last
    40201b9c:	f94001ca 	ldr	x10, [x14]
    40201ba0:	eb0a010a 	subs	x10, x8, x10
    40201ba4:	54001223 	b.cc	40201de8 <jnox_kernel::ordinary_reservations::irq+0xb20>  // b.lo, b.ul, b.last
    40201ba8:	f94009cb 	ldr	x11, [x14, #16]
    40201bac:	eb0b015f 	cmp	x10, x11
    40201bb0:	540011c8 	b.hi	40201de8 <jnox_kernel::ordinary_reservations::irq+0xb20>  // b.pmore
    40201bb4:	f940b536 	ldr	x22, [x9, #360]
    40201bb8:	d5033fdf 	isb
    40201bbc:	d53be024 	mrs	x4, cntpct_el0
    40201bc0:	f9409ee8 	ldr	x8, [x23, #312]
    40201bc4:	eb080088 	subs	x8, x4, x8
    40201bc8:	54000ee3 	b.cc	40201da4 <jnox_kernel::ordinary_reservations::irq+0xadc>  // b.lo, b.ul, b.last
    40201bcc:	f940a6ea 	ldr	x10, [x23, #328]
    40201bd0:	eb0a011f 	cmp	x8, x10
    40201bd4:	54000e88 	b.hi	40201da4 <jnox_kernel::ordinary_reservations::irq+0xadc>  // b.pmore
    40201bd8:	f900b53f 	str	xzr, [x9, #360]
    40201bdc:	f900b2f3 	str	x19, [x23, #352]
    40201be0:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201be4:	91004108 	add	x8, x8, #0x10
    40201be8:	f9407ec9 	ldr	x9, [x22, #248]
    40201bec:	a907dba4 	stp	x4, x22, [x29, #120]
    40201bf0:	5280002a 	mov	w10, #0x1                   	// #1
    40201bf4:	a9004d1f 	stp	xzr, x19, [x8]
    40201bf8:	f9408ec8 	ldr	x8, [x22, #280]
    40201bfc:	f90047a9 	str	x9, [x29, #136]
    40201c00:	f9404ec9 	ldr	x9, [x22, #152]
    40201c04:	a909aba8 	stp	x8, x10, [x29, #152]
    40201c08:	f9004ba9 	str	x9, [x29, #144]
    40201c0c:	f94003a8 	ldr	x8, [x29]
    40201c10:	b27c0108 	orr	x8, x8, #0x10
    40201c14:	f90003a8 	str	x8, [x29]
    40201c18:	14000051 	b	40201d5c <jnox_kernel::ordinary_reservations::irq+0xa94>
    40201c1c:	aa1303e0 	mov	x0, x19
    40201c20:	aa1f03e1 	mov	x1, xzr
    40201c24:	f94013f4 	ldr	x20, [sp, #32]
    40201c28:	aa1403e2 	mov	x2, x20
    40201c2c:	94000445 	bl	40202d40 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201c30:	52800055 	mov	w21, #0x2                   	// #2
    40201c34:	1400003b 	b	40201d20 <jnox_kernel::ordinary_reservations::irq+0xa58>
    40201c38:	d000010a 	adrp	x10, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0xb8e0>
    40201c3c:	911cc14a 	add	x10, x10, #0x730
    40201c40:	d53be248 	mrs	x8, cntp_cval_el0
    40201c44:	d5033fdf 	isb
    40201c48:	d53be029 	mrs	x9, cntpct_el0
    40201c4c:	a9022157 	stp	x23, x8, [x10, #32]
    40201c50:	a9015949 	stp	x9, x22, [x10, #16]
    40201c54:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201c58:	9114e129 	add	x9, x9, #0x538
    40201c5c:	f940252b 	ldr	x11, [x9, #72]
    40201c60:	f900194b 	str	x11, [x10, #48]
    40201c64:	f940014c 	ldr	x12, [x10]
    40201c68:	b240018c 	orr	x12, x12, #0x1
    40201c6c:	a900554c 	stp	x12, x21, [x10]
    40201c70:	eb0b011f 	cmp	x8, x11
    40201c74:	54ffe9e1 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201c78:	f9400129 	ldr	x9, [x9]
    40201c7c:	eb09011f 	cmp	x8, x9
    40201c80:	54ffe981 	b.ne	402019b0 <jnox_kernel::ordinary_reservations::irq+0x6e8>  // b.any
    40201c84:	aa1f03f3 	mov	x19, xzr
    40201c88:	17fffdc8 	b	402013a8 <jnox_kernel::ordinary_reservations::irq+0xe0>
    40201c8c:	92800008 	mov	x8, #0xffffffffffffffff    	// #-1
    40201c90:	d503201f 	nop
    40201c94:	1002d329 	adr	x9, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40201c98:	d503201f 	nop
    40201c9c:	10110aaa 	adr	x10, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40201ca0:	d503201f 	nop
    40201ca4:	1002d22b 	adr	x11, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40201ca8:	d503201f 	nop
    40201cac:	10110aac 	adr	x12, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40201cb0:	8b150d29 	add	x9, x9, x21, lsl #3
    40201cb4:	c89ffd28 	stlr	x8, [x9]
    40201cb8:	f94007e8 	ldr	x8, [sp, #8]
    40201cbc:	f8357948 	str	x8, [x10, x21, lsl #3]
    40201cc0:	f835799f 	str	xzr, [x12, x21, lsl #3]
    40201cc4:	8b150d68 	add	x8, x11, x21, lsl #3
    40201cc8:	c89ffd13 	stlr	x19, [x8]
    40201ccc:	b100067f 	cmn	x19, #0x1
    40201cd0:	54000580 	b.eq	40201d80 <jnox_kernel::ordinary_reservations::irq+0xab8>  // b.none
    40201cd4:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201cd8:	9114e129 	add	x9, x9, #0x538
    40201cdc:	a9402129 	ldp	x9, x8, [x9]
    40201ce0:	9100066b 	add	x11, x19, #0x1
    40201ce4:	9bc87d6a 	umulh	x10, x11, x8
    40201ce8:	eb0a03ff 	cmp	xzr, x10
    40201cec:	1a9f07ea 	cset	w10, ne  // ne = any
    40201cf0:	9b087d68 	mul	x8, x11, x8
    40201cf4:	ab090108 	adds	x8, x8, x9
    40201cf8:	1a9f37e9 	cset	w9, cs  // cs = hs, nlast
    40201cfc:	3700042a 	tbnz	w10, #0, 40201d80 <jnox_kernel::ordinary_reservations::irq+0xab8>
    40201d00:	37000409 	tbnz	w9, #0, 40201d80 <jnox_kernel::ordinary_reservations::irq+0xab8>
    40201d04:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201d08:	f942a529 	ldr	x9, [x9, #1352]
    40201d0c:	eb090102 	subs	x2, x8, x9
    40201d10:	54000383 	b.cc	40201d80 <jnox_kernel::ordinary_reservations::irq+0xab8>  // b.lo, b.ul, b.last
    40201d14:	aa1303e0 	mov	x0, x19
    40201d18:	52800021 	mov	w1, #0x1                   	// #1
    40201d1c:	94000409 	bl	40202d40 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201d20:	aa1303e0 	mov	x0, x19
    40201d24:	aa1503e1 	mov	x1, x21
    40201d28:	94000560 	bl	402032a8 <jnox_kernel::ordinary_reservations::Runtime::select>
    40201d2c:	aa0003f6 	mov	x22, x0
    40201d30:	d5033fdf 	isb
    40201d34:	d53be021 	mrs	x1, cntpct_el0
    40201d38:	f9407c08 	ldr	x8, [x0, #248]
    40201d3c:	f9400fe9 	ldr	x9, [sp, #24]
    40201d40:	a909d3e9 	stp	x9, x20, [sp, #152]
    40201d44:	a90aa3e0 	stp	x0, x8, [sp, #168]
    40201d48:	910263e4 	add	x4, sp, #0x98
    40201d4c:	528000e0 	mov	w0, #0x7                   	// #7
    40201d50:	aa1303e2 	mov	x2, x19
    40201d54:	aa1503e3 	mov	x3, x21
    40201d58:	9400020f 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40201d5c:	aa1603e0 	mov	x0, x22
    40201d60:	a9554ff4 	ldp	x20, x19, [sp, #336]
    40201d64:	a95457f6 	ldp	x22, x21, [sp, #320]
    40201d68:	a9535ff8 	ldp	x24, x23, [sp, #304]
    40201d6c:	a95267fa 	ldp	x26, x25, [sp, #288]
    40201d70:	a9516ffc 	ldp	x28, x27, [sp, #272]
    40201d74:	a9507bfd 	ldp	x29, x30, [sp, #256]
    40201d78:	910583ff 	add	sp, sp, #0x160
    40201d7c:	d65f03c0 	ret
    40201d80:	52800060 	mov	w0, #0x3                   	// #3
    40201d84:	9400057d 	bl	40203378 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    40201d88:	f942b303 	ldr	x3, [x24, #1376]
    40201d8c:	52800060 	mov	w0, #0x3                   	// #3
    40201d90:	52800081 	mov	w1, #0x4                   	// #4
    40201d94:	aa1303e2 	mov	x2, x19
    40201d98:	aa1603e4 	mov	x4, x22
    40201d9c:	aa1703e5 	mov	x5, x23
    40201da0:	94000254 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>
    40201da4:	52800040 	mov	w0, #0x2                   	// #2
    40201da8:	528000a1 	mov	w1, #0x5                   	// #5
    40201dac:	aa1f03e2 	mov	x2, xzr
    40201db0:	52800043 	mov	w3, #0x2                   	// #2
    40201db4:	14000012 	b	40201dfc <jnox_kernel::ordinary_reservations::irq+0xb34>
    40201db8:	52800040 	mov	w0, #0x2                   	// #2
    40201dbc:	528000a1 	mov	w1, #0x5                   	// #5
    40201dc0:	aa1303e2 	mov	x2, x19
    40201dc4:	52800043 	mov	w3, #0x2                   	// #2
    40201dc8:	aa1503e4 	mov	x4, x21
    40201dcc:	94000249 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>
    40201dd0:	52800040 	mov	w0, #0x2                   	// #2
    40201dd4:	528000a1 	mov	w1, #0x5                   	// #5
    40201dd8:	aa1f03e2 	mov	x2, xzr
    40201ddc:	52800043 	mov	w3, #0x2                   	// #2
    40201de0:	aa1603e4 	mov	x4, x22
    40201de4:	14000006 	b	40201dfc <jnox_kernel::ordinary_reservations::irq+0xb34>
    40201de8:	52800040 	mov	w0, #0x2                   	// #2
    40201dec:	528000a1 	mov	w1, #0x5                   	// #5
    40201df0:	aa1f03e2 	mov	x2, xzr
    40201df4:	52800043 	mov	w3, #0x2                   	// #2
    40201df8:	aa0803e4 	mov	x4, x8
    40201dfc:	f94013e5 	ldr	x5, [sp, #32]
    40201e00:	9400023c 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>
    40201e04:	aa1f03e0 	mov	x0, xzr
    40201e08:	aa1f03e1 	mov	x1, xzr
    40201e0c:	aa1303e2 	mov	x2, x19
    40201e10:	52800043 	mov	w3, #0x2                   	// #2
    40201e14:	aa1f03e4 	mov	x4, xzr
    40201e18:	14000006 	b	40201e30 <jnox_kernel::ordinary_reservations::irq+0xb68>
    40201e1c:	394283e4 	ldrb	w4, [sp, #160]
    40201e20:	52800060 	mov	w0, #0x3                   	// #3
    40201e24:	52800041 	mov	w1, #0x2                   	// #2
    40201e28:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201e2c:	52800043 	mov	w3, #0x2                   	// #2
    40201e30:	aa1f03e5 	mov	x5, xzr
    40201e34:	9400022f 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>
    40201e38:	d503201f 	nop
    40201e3c:	100204e2 	adr	x2, 40205ed8 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.17900666132547781062+0x30>
    40201e40:	aa1303e0 	mov	x0, x19
    40201e44:	14000004 	b	40201e54 <jnox_kernel::ordinary_reservations::irq+0xb8c>
    40201e48:	d503201f 	nop
    40201e4c:	100205e2 	adr	x2, 40205f08 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.17900666132547781062+0x60>
    40201e50:	aa1503e0 	mov	x0, x21
    40201e54:	52800041 	mov	w1, #0x2                   	// #2
    40201e58:	94000bb0 	bl	40204d18 <core::panicking::panic_bounds_check>
    40201e5c:	94000093 	bl	402020a8 <jnox_kernel::ordinary_reservations::run::{{closure}}>

0000000040201e60 <jnox_kernel::ordinary_reservations::run>:
    40201e60:	d105c3ff 	sub	sp, sp, #0x170
    40201e64:	a9127bfd 	stp	x29, x30, [sp, #288]
    40201e68:	a91367fa 	stp	x26, x25, [sp, #304]
    40201e6c:	a9145ff8 	stp	x24, x23, [sp, #320]
    40201e70:	a91557f6 	stp	x22, x21, [sp, #336]
    40201e74:	a9164ff4 	stp	x20, x19, [sp, #352]
    40201e78:	d5033fdf 	isb
    40201e7c:	d53be038 	mrs	x24, cntpct_el0
    40201e80:	d53be014 	mrs	x20, cntfrq_el0
    40201e84:	d5033fdf 	isb
    40201e88:	d53be028 	mrs	x8, cntpct_el0
    40201e8c:	b202e7e9 	mov	x9, #0xcccccccccccccccc    	// #-3689348814741910324
    40201e90:	f29999a9 	movk	x9, #0xcccd
    40201e94:	9bc97e89 	umulh	x9, x20, x9
    40201e98:	ab491113 	adds	x19, x8, x9, lsr #4
    40201e9c:	54000043 	b.cc	40201ea4 <jnox_kernel::ordinary_reservations::run+0x44>  // b.lo, b.ul, b.last
    40201ea0:	94000082 	bl	402020a8 <jnox_kernel::ordinary_reservations::run::{{closure}}>
    40201ea4:	910223e8 	add	x8, sp, #0x88
    40201ea8:	aa1303e0 	mov	x0, x19
    40201eac:	aa1403e1 	mov	x1, x20
    40201eb0:	52800022 	mov	w2, #0x1                   	// #1
    40201eb4:	9400080d 	bl	40203ee8 <jnox_kernel::reservation_jobs::Clock::new>
    40201eb8:	394223e8 	ldrb	w8, [sp, #136]
    40201ebc:	7100051f 	cmp	w8, #0x1
    40201ec0:	54000061 	b.ne	40201ecc <jnox_kernel::ordinary_reservations::run+0x6c>  // b.any
    40201ec4:	394227e4 	ldrb	w4, [sp, #137]
    40201ec8:	14000015 	b	40201f1c <jnox_kernel::ordinary_reservations::run+0xbc>
    40201ecc:	a9495bf7 	ldp	x23, x22, [sp, #144]
    40201ed0:	f94053f5 	ldr	x21, [sp, #160]
    40201ed4:	d5033fdf 	isb
    40201ed8:	d53be021 	mrs	x1, cntpct_el0
    40201edc:	a908dbf4 	stp	x20, x22, [sp, #136]
    40201ee0:	52800028 	mov	w8, #0x1                   	// #1
    40201ee4:	a909a3e8 	stp	x8, x8, [sp, #152]
    40201ee8:	910223e4 	add	x4, sp, #0x88
    40201eec:	52800020 	mov	w0, #0x1                   	// #1
    40201ef0:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201ef4:	52800043 	mov	w3, #0x2                   	// #2
    40201ef8:	940001a7 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40201efc:	910223e8 	add	x8, sp, #0x88
    40201f00:	52800020 	mov	w0, #0x1                   	// #1
    40201f04:	52800021 	mov	w1, #0x1                   	// #1
    40201f08:	94000610 	bl	40203748 <jnox_kernel::reservation_jobs::Jobs::new>
    40201f0c:	f94047e8 	ldr	x8, [sp, #136]
    40201f10:	f100091f 	cmp	x8, #0x2
    40201f14:	54000101 	b.ne	40201f34 <jnox_kernel::ordinary_reservations::run+0xd4>  // b.any
    40201f18:	394243e4 	ldrb	w4, [sp, #144]
    40201f1c:	52800060 	mov	w0, #0x3                   	// #3
    40201f20:	52800041 	mov	w1, #0x2                   	// #2
    40201f24:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201f28:	52800043 	mov	w3, #0x2                   	// #2
    40201f2c:	aa1f03e5 	mov	x5, xzr
    40201f30:	940001f0 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>
    40201f34:	910023e0 	add	x0, sp, #0x8
    40201f38:	910223e1 	add	x1, sp, #0x88
    40201f3c:	52801002 	mov	w2, #0x80                  	// #128
    40201f40:	94000ec6 	bl	40205a58 <memcpy>
    40201f44:	d5033fdf 	isb
    40201f48:	d53be021 	mrs	x1, cntpct_el0
    40201f4c:	a908cff8 	stp	x24, x19, [sp, #136]
    40201f50:	a909ffff 	stp	xzr, xzr, [sp, #152]
    40201f54:	910223e4 	add	x4, sp, #0x88
    40201f58:	52800300 	mov	w0, #0x18                  	// #24
    40201f5c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201f60:	52800043 	mov	w3, #0x2                   	// #2
    40201f64:	9400018c 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40201f68:	94000a29 	bl	4020480c <jnox_kernel::context::init_timer_irq>
    40201f6c:	aa1f03f4 	mov	x20, xzr
    40201f70:	910423f8 	add	x24, sp, #0x108
    40201f74:	aa1403e0 	mov	x0, x20
    40201f78:	940001a8 	bl	40202618 <jnox_kernel::ordinary_reservations::fresh>
    40201f7c:	f8347b00 	str	x0, [x24, x20, lsl #3]
    40201f80:	91000694 	add	x20, x20, #0x1
    40201f84:	f1000e9f 	cmp	x20, #0x3
    40201f88:	54ffff61 	b.ne	40201f74 <jnox_kernel::ordinary_reservations::run+0x114>  // b.any
    40201f8c:	aa1f03f4 	mov	x20, xzr
    40201f90:	d503201f 	nop
    40201f94:	100abc68 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062>
    40201f98:	52800318 	mov	w24, #0x18                  	// #24
    40201f9c:	d503201f 	nop
    40201fa0:	1001f719 	adr	x25, 40205e80 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.17900666132547781062>
    40201fa4:	d5033fdf 	isb
    40201fa8:	d53be021 	mrs	x1, cntpct_el0
    40201fac:	f1000a9f 	cmp	x20, #0x2
    40201fb0:	54000062 	b.cs	40201fbc <jnox_kernel::ordinary_reservations::run+0x15c>  // b.hs, b.nlast
    40201fb4:	f8747b29 	ldr	x9, [x25, x20, lsl #3]
    40201fb8:	14000002 	b	40201fc0 <jnox_kernel::ordinary_reservations::run+0x160>
    40201fbc:	52818329 	mov	w9, #0xc19                 	// #3097
    40201fc0:	9140111a 	add	x26, x8, #0x4, lsl #12
    40201fc4:	a908ebe8 	stp	x8, x26, [sp, #136]
    40201fc8:	a909ffe9 	stp	x9, xzr, [sp, #152]
    40201fcc:	910223e4 	add	x4, sp, #0x88
    40201fd0:	52800220 	mov	w0, #0x11                  	// #17
    40201fd4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201fd8:	aa1403e3 	mov	x3, x20
    40201fdc:	9400016e 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40201fe0:	f1002318 	subs	x24, x24, #0x8
    40201fe4:	91000694 	add	x20, x20, #0x1
    40201fe8:	aa1a03e8 	mov	x8, x26
    40201fec:	54fffdc1 	b.ne	40201fa4 <jnox_kernel::ordinary_reservations::run+0x144>  // b.any
    40201ff0:	d503201f 	nop
    40201ff4:	1002a074 	adr	x20, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40201ff8:	910023e1 	add	x1, sp, #0x8
    40201ffc:	aa1403e0 	mov	x0, x20
    40202000:	52801002 	mov	w2, #0x80                  	// #128
    40202004:	94000e95 	bl	40205a58 <memcpy>
    40202008:	52800048 	mov	w8, #0x2                   	// #2
    4020200c:	f9004288 	str	x8, [x20, #128]
    40202010:	52800069 	mov	w9, #0x3                   	// #3
    40202014:	3904c289 	strb	w9, [x20, #304]
    40202018:	a913da97 	stp	x23, x22, [x20, #312]
    4020201c:	52800149 	mov	w9, #0xa                   	// #10
    40202020:	a914a695 	stp	x21, x9, [x20, #328]
    40202024:	9280000a 	mov	x10, #0xffffffffffffffff    	// #-1
    40202028:	a915a28a 	stp	x10, x8, [x20, #344]
    4020202c:	a950afe8 	ldp	x8, x11, [sp, #264]
    40202030:	a916ae88 	stp	x8, x11, [x20, #360]
    40202034:	f9408fe8 	ldr	x8, [sp, #280]
    40202038:	a917fe88 	stp	x8, xzr, [x20, #376]
    4020203c:	a918aa9f 	stp	xzr, x10, [x20, #392]
    40202040:	a919fe8a 	stp	x10, xzr, [x20, #408]
    40202044:	52800028 	mov	w8, #0x1                   	// #1
    40202048:	a91aa29f 	stp	xzr, x8, [x20, #424]
    4020204c:	a91bfe88 	stp	x8, xzr, [x20, #440]
    40202050:	52814328 	mov	w8, #0xa19                 	// #2585
    40202054:	a91ca29f 	stp	xzr, x8, [x20, #456]
    40202058:	52816328 	mov	w8, #0xb19                 	// #2841
    4020205c:	f900ee88 	str	x8, [x20, #472]
    40202060:	d5033fdf 	isb
    40202064:	d53be021 	mrs	x1, cntpct_el0
    40202068:	a908a7f3 	stp	x19, x9, [sp, #136]
    4020206c:	a909ffff 	stp	xzr, xzr, [sp, #152]
    40202070:	910223e4 	add	x4, sp, #0x88
    40202074:	52800040 	mov	w0, #0x2                   	// #2
    40202078:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4020207c:	52800043 	mov	w3, #0x2                   	// #2
    40202080:	94000145 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202084:	94000194 	bl	402026d4 <jnox_kernel::ordinary_reservations::state>
    40202088:	aa1f03e0 	mov	x0, xzr
    4020208c:	aa1f03e1 	mov	x1, xzr
    40202090:	aa1303e2 	mov	x2, x19
    40202094:	9400032b 	bl	40202d40 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40202098:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    4020209c:	52800041 	mov	w1, #0x2                   	// #2
    402020a0:	94000482 	bl	402032a8 <jnox_kernel::ordinary_reservations::Runtime::select>
    402020a4:	97fffc42 	bl	402011ac <sched_start_frame>

00000000402020a8 <jnox_kernel::ordinary_reservations::run::{{closure}}>:
    402020a8:	f81f0ffe 	str	x30, [sp, #-16]!
    402020ac:	97fffc7f 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

00000000402020b0 <jnox_kernel::ordinary_reservations::svc>:
    402020b0:	f81f0ffe 	str	x30, [sp, #-16]!
    402020b4:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402020b8:	f9420108 	ldr	x8, [x8, #1024]
    402020bc:	f100091f 	cmp	x8, #0x2
    402020c0:	54000660 	b.eq	4020218c <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.none
    402020c4:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402020c8:	f942b108 	ldr	x8, [x8, #1376]
    402020cc:	d503201f 	nop
    402020d0:	100ab289 	adr	x9, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062>
    402020d4:	f100091f 	cmp	x8, #0x2
    402020d8:	8b08392a 	add	x10, x9, x8, lsl #14
    402020dc:	fa401142 	ccmp	x10, x0, #0x2, ne  // ne = any
    402020e0:	54000568 	b.hi	4020218c <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    402020e4:	b10d041f 	cmn	x0, #0x341
    402020e8:	54000528 	b.hi	4020218c <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    402020ec:	d372c508 	lsl	x8, x8, #14
    402020f0:	8b080128 	add	x8, x9, x8
    402020f4:	91401108 	add	x8, x8, #0x4, lsl #12
    402020f8:	910d0009 	add	x9, x0, #0x340
    402020fc:	eb08013f 	cmp	x9, x8
    40202100:	54000468 	b.hi	4020218c <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    40202104:	f9409c01 	ldr	x1, [x0, #312]
    40202108:	d5385203 	mrs	x3, esr_el1
    4020210c:	d35afc68 	lsr	x8, x3, #26
    40202110:	f100551f 	cmp	x8, #0x15
    40202114:	540003c1 	b.ne	4020218c <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.any
    40202118:	12003c68 	and	w8, w3, #0xffff
    4020211c:	7100051f 	cmp	w8, #0x1
    40202120:	540000a0 	b.eq	40202134 <jnox_kernel::ordinary_reservations::svc+0x84>  // b.none
    40202124:	7100091f 	cmp	w8, #0x2
    40202128:	54000321 	b.ne	4020218c <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.any
    4020212c:	52800042 	mov	w2, #0x2                   	// #2
    40202130:	14000002 	b	40202138 <jnox_kernel::ordinary_reservations::svc+0x88>
    40202134:	52800022 	mov	w2, #0x1                   	// #1
    40202138:	94000323 	bl	40202dc4 <jnox_kernel::ordinary_reservations::Runtime::close>
    4020213c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202140:	9114e108 	add	x8, x8, #0x538
    40202144:	f9401100 	ldr	x0, [x8, #32]
    40202148:	91000409 	add	x9, x0, #0x1
    4020214c:	a9402908 	ldp	x8, x10, [x8]
    40202150:	9bca7d2b 	umulh	x11, x9, x10
    40202154:	eb0b03ff 	cmp	xzr, x11
    40202158:	1a9f07eb 	cset	w11, ne  // ne = any
    4020215c:	9b0a7d29 	mul	x9, x9, x10
    40202160:	ab080122 	adds	x2, x9, x8
    40202164:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40202168:	3700014b 	tbnz	w11, #0, 40202190 <jnox_kernel::ordinary_reservations::svc+0xe0>
    4020216c:	35000128 	cbnz	w8, 40202190 <jnox_kernel::ordinary_reservations::svc+0xe0>
    40202170:	aa1f03e1 	mov	x1, xzr
    40202174:	940002f3 	bl	40202d40 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40202178:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020217c:	f942ad00 	ldr	x0, [x8, #1368]
    40202180:	52800041 	mov	w1, #0x2                   	// #2
    40202184:	f84107fe 	ldr	x30, [sp], #16
    40202188:	14000448 	b	402032a8 <jnox_kernel::ordinary_reservations::Runtime::select>
    4020218c:	97fffc47 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40202190:	52800060 	mov	w0, #0x3                   	// #3
    40202194:	94000479 	bl	40203378 <jnox_kernel::ordinary_reservations::checked::{{closure}}>

0000000040202198 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062>:
    40202198:	d10743ff 	sub	sp, sp, #0x1d0
    4020219c:	a9177bfd 	stp	x29, x30, [sp, #368]
    402021a0:	a9186ffc 	stp	x28, x27, [sp, #384]
    402021a4:	a91967fa 	stp	x26, x25, [sp, #400]
    402021a8:	a91a5ff8 	stp	x24, x23, [sp, #416]
    402021ac:	a91b57f6 	stp	x22, x21, [sp, #432]
    402021b0:	a91c4ff4 	stp	x20, x19, [sp, #448]
    402021b4:	d50342df 	msr	daifset, #0x2
    402021b8:	d5033fdf 	isb
    402021bc:	d5033fdf 	isb
    402021c0:	d53be036 	mrs	x22, cntpct_el0
    402021c4:	b0000035 	adrp	x21, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021c8:	f94202a8 	ldr	x8, [x21, #1024]
    402021cc:	f100091f 	cmp	x8, #0x2
    402021d0:	54001ac0 	b.eq	40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>  // b.none
    402021d4:	d5033fdf 	isb
    402021d8:	d53be038 	mrs	x24, cntpct_el0
    402021dc:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021e0:	f942f108 	ldr	x8, [x8, #1504]
    402021e4:	f100091f 	cmp	x8, #0x2
    402021e8:	54001a01 	b.ne	40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>  // b.any
    402021ec:	b0000037 	adrp	x23, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021f0:	f9429ef3 	ldr	x19, [x23, #1336]
    402021f4:	d503201f 	nop
    402021f8:	1010af48 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    402021fc:	c8dffd08 	ldar	x8, [x8]
    40202200:	b5001948 	cbnz	x8, 40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>
    40202204:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202208:	91156108 	add	x8, x8, #0x558
    4020220c:	f9400109 	ldr	x9, [x8]
    40202210:	b100053f 	cmn	x9, #0x1
    40202214:	540018a1 	b.ne	40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>  // b.any
    40202218:	f9400508 	ldr	x8, [x8, #8]
    4020221c:	f100091f 	cmp	x8, #0x2
    40202220:	54001841 	b.ne	40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>  // b.any
    40202224:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202228:	9114c108 	add	x8, x8, #0x530
    4020222c:	39400109 	ldrb	w9, [x8]
    40202230:	71000d3f 	cmp	w9, #0x3
    40202234:	540017a1 	b.ne	40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>  // b.any
    40202238:	f9402d09 	ldr	x9, [x8, #88]
    4020223c:	b5001769 	cbnz	x9, 40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>
    40202240:	f9402908 	ldr	x8, [x8, #80]
    40202244:	eb13011f 	cmp	x8, x19
    40202248:	54001701 	b.ne	40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>  // b.any
    4020224c:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0xb8e0>
    40202250:	f943f508 	ldr	x8, [x8, #2024]
    40202254:	f100051f 	cmp	x8, #0x1
    40202258:	54001681 	b.ne	40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>  // b.any
    4020225c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202260:	f9423508 	ldr	x8, [x8, #1128]
    40202264:	b5001628 	cbnz	x8, 40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>
    40202268:	5280002a 	mov	w10, #0x1                   	// #1
    4020226c:	d503201f 	nop
    40202270:	10028c99 	adr	x25, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40202274:	8b080328 	add	x8, x25, x8
    40202278:	3941e109 	ldrb	w9, [x8, #120]
    4020227c:	3600008a 	tbz	w10, #0, 4020228c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0xf4>
    40202280:	2a1f03ea 	mov	w10, wzr
    40202284:	52800028 	mov	w8, #0x1                   	// #1
    40202288:	34ffff69 	cbz	w9, 40202274 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0xdc>
    4020228c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202290:	39518108 	ldrb	w8, [x8, #1120]
    40202294:	7100013f 	cmp	w9, #0x0
    40202298:	7a430900 	ccmp	w8, #0x3, #0x0, eq  // eq = none
    4020229c:	54001461 	b.ne	40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>  // b.any
    402022a0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402022a4:	9111c108 	add	x8, x8, #0x470
    402022a8:	f9400109 	ldr	x9, [x8]
    402022ac:	b50013e9 	cbnz	x9, 40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>
    402022b0:	f9400908 	ldr	x8, [x8, #16]
    402022b4:	f100091f 	cmp	x8, #0x2
    402022b8:	54001381 	b.ne	40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>  // b.any
    402022bc:	f94202a8 	ldr	x8, [x21, #1024]
    402022c0:	f100051f 	cmp	x8, #0x1
    402022c4:	54000121 	b.ne	402022e8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x150>  // b.any
    402022c8:	b0000021 	adrp	x1, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402022cc:	91102021 	add	x1, x1, #0x408
    402022d0:	f940183a 	ldr	x26, [x1, #48]
    402022d4:	910243e0 	add	x0, sp, #0x90
    402022d8:	52800602 	mov	w2, #0x30                  	// #48
    402022dc:	94000ddf 	bl	40205a58 <memcpy>
    402022e0:	52800028 	mov	w8, #0x1                   	// #1
    402022e4:	14000017 	b	40202340 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x1a8>
    402022e8:	910303e0 	add	x0, sp, #0xc0
    402022ec:	9100a014 	add	x20, x0, #0x28
    402022f0:	52800028 	mov	w8, #0x1                   	// #1
    402022f4:	b0000021 	adrp	x1, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402022f8:	91102021 	add	x1, x1, #0x408
    402022fc:	2a0803fa 	mov	w26, w8
    40202300:	9100a03b 	add	x27, x1, #0x28
    40202304:	52800502 	mov	w2, #0x28                  	// #40
    40202308:	94000dd4 	bl	40205a58 <memcpy>
    4020230c:	2a1f03e8 	mov	w8, wzr
    40202310:	aa1b03e1 	mov	x1, x27
    40202314:	aa1403e0 	mov	x0, x20
    40202318:	3707ff3a 	tbnz	w26, #0, 402022fc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x164>
    4020231c:	910243e0 	add	x0, sp, #0x90
    40202320:	910303e1 	add	x1, sp, #0xc0
    40202324:	52800602 	mov	w2, #0x30                  	// #48
    40202328:	94000dcc 	bl	40205a58 <memcpy>
    4020232c:	aa1f03e8 	mov	x8, xzr
    40202330:	a94f27fa 	ldp	x26, x9, [sp, #240]
    40202334:	a9502fea 	ldp	x10, x11, [sp, #256]
    40202338:	a907abe9 	stp	x9, x10, [sp, #120]
    4020233c:	f90047eb 	str	x11, [sp, #136]
    40202340:	b000003b 	adrp	x27, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202344:	9111e37b 	add	x27, x27, #0x478
    40202348:	39400b7c 	ldrb	w28, [x27, #2]
    4020234c:	7940037d 	ldrh	w29, [x27]
    40202350:	aa1b03f4 	mov	x20, x27
    40202354:	f8008e88 	str	x8, [x20, #8]!
    40202358:	91004360 	add	x0, x27, #0x10
    4020235c:	910243e1 	add	x1, sp, #0x90
    40202360:	52800602 	mov	w2, #0x30                  	// #48
    40202364:	94000dbd 	bl	40205a58 <memcpy>
    40202368:	52800068 	mov	w8, #0x3                   	// #3
    4020236c:	3901a368 	strb	w8, [x27, #104]
    40202370:	a947a7e8 	ldp	x8, x9, [sp, #120]
    40202374:	a904237a 	stp	x26, x8, [x27, #64]
    40202378:	f94047e8 	ldr	x8, [sp, #136]
    4020237c:	a9052369 	stp	x9, x8, [x27, #80]
    40202380:	a9077f7f 	stp	xzr, xzr, [x27, #112]
    40202384:	7901037d 	strh	w29, [x27, #128]
    40202388:	39020b7c 	strb	w28, [x27, #130]
    4020238c:	910303e8 	add	x8, sp, #0xc0
    40202390:	aa1403e0 	mov	x0, x20
    40202394:	9400047c 	bl	40203584 <jnox_kernel::reservation_jobs::Jobs::prepare_destination>
    40202398:	f94063e8 	ldr	x8, [sp, #192]
    4020239c:	f100091f 	cmp	x8, #0x2
    402023a0:	54000cc0 	b.eq	40202538 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x3a0>  // b.none
    402023a4:	910043e0 	add	x0, sp, #0x10
    402023a8:	910303e1 	add	x1, sp, #0xc0
    402023ac:	52800d02 	mov	w2, #0x68                  	// #104
    402023b0:	94000daa 	bl	40205a58 <memcpy>
    402023b4:	b0000020 	adrp	x0, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402023b8:	91120000 	add	x0, x0, #0x480
    402023bc:	910043e1 	add	x1, sp, #0x10
    402023c0:	94000488 	bl	402035e0 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision>
    402023c4:	36000b20 	tbz	w0, #0, 40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>
    402023c8:	b94013e8 	ldr	w8, [sp, #16]
    402023cc:	36000b48 	tbz	w8, #0, 40202534 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x39c>
    402023d0:	3941cbe8 	ldrb	w8, [sp, #114]
    402023d4:	34000188 	cbz	w8, 40202404 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x26c>
    402023d8:	71000d1f 	cmp	w8, #0x3
    402023dc:	54000a60 	b.eq	40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>  // b.none
    402023e0:	f9400fe0 	ldr	x0, [sp, #24]
    402023e4:	f100041f 	cmp	x0, #0x1
    402023e8:	54000ce8 	b.hi	40202584 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x3ec>  // b.pmore
    402023ec:	8b000f28 	add	x8, x25, x0, lsl #3
    402023f0:	f940e108 	ldr	x8, [x8, #448]
    402023f4:	b104011f 	cmn	x8, #0x100
    402023f8:	540009e2 	b.cs	40202534 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x39c>  // b.hs, b.nlast
    402023fc:	9104011a 	add	x26, x8, #0x100
    40202400:	14000002 	b	40202408 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x270>
    40202404:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40202408:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020240c:	9114e108 	add	x8, x8, #0x538
    40202410:	a9402508 	ldp	x8, x9, [x8]
    40202414:	ab09011b 	adds	x27, x8, x9
    40202418:	540008a2 	b.cs	4020252c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x394>  // b.hs, b.nlast
    4020241c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202420:	f942a508 	ldr	x8, [x8, #1352]
    40202424:	eb08037c 	subs	x28, x27, x8
    40202428:	54000823 	b.cc	4020252c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x394>  // b.lo, b.ul, b.last
    4020242c:	f9009bf9 	str	x25, [sp, #304]
    40202430:	910303f4 	add	x20, sp, #0xc0
    40202434:	9104e3e8 	add	x8, sp, #0x138
    40202438:	9104c3e0 	add	x0, sp, #0x130
    4020243c:	aa1f03e1 	mov	x1, xzr
    40202440:	94000717 	bl	4020409c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    40202444:	910303e0 	add	x0, sp, #0xc0
    40202448:	9104e3e1 	add	x1, sp, #0x138
    4020244c:	52800702 	mov	w2, #0x38                  	// #56
    40202450:	94000d82 	bl	40205a58 <memcpy>
    40202454:	9104e3e8 	add	x8, sp, #0x138
    40202458:	9104c3e0 	add	x0, sp, #0x130
    4020245c:	52800021 	mov	w1, #0x1                   	// #1
    40202460:	9400070f 	bl	4020409c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    40202464:	9100e280 	add	x0, x20, #0x38
    40202468:	9104e3e1 	add	x1, sp, #0x138
    4020246c:	52800702 	mov	w2, #0x38                  	// #56
    40202470:	94000d7a 	bl	40205a58 <memcpy>
    40202474:	d503201f 	nop
    40202478:	10028b54 	adr	x20, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    4020247c:	910043e1 	add	x1, sp, #0x10
    40202480:	aa1403e0 	mov	x0, x20
    40202484:	52800d02 	mov	w2, #0x68                  	// #104
    40202488:	94000d74 	bl	40205a58 <memcpy>
    4020248c:	52800088 	mov	w8, #0x4                   	// #4
    40202490:	a906a298 	stp	x24, x8, [x20, #104]
    40202494:	a907ee93 	stp	x19, x27, [x20, #120]
    40202498:	a908ea9c 	stp	x28, x26, [x20, #136]
    4020249c:	91026280 	add	x0, x20, #0x98
    402024a0:	910303e1 	add	x1, sp, #0xc0
    402024a4:	52800e02 	mov	w2, #0x70                  	// #112
    402024a8:	94000d6c 	bl	40205a58 <memcpy>
    402024ac:	d5033fdf 	isb
    402024b0:	d53be034 	mrs	x20, cntpct_el0
    402024b4:	eb140268 	subs	x8, x19, x20
    402024b8:	9a8833e8 	csel	x8, xzr, x8, cc  // cc = lo, ul, last
    402024bc:	a913cff8 	stp	x24, x19, [sp, #312]
    402024c0:	a914ffe8 	stp	x8, xzr, [sp, #328]
    402024c4:	9104e3e4 	add	x4, sp, #0x138
    402024c8:	528002c0 	mov	w0, #0x16                  	// #22
    402024cc:	aa1403e1 	mov	x1, x20
    402024d0:	aa1f03e2 	mov	x2, xzr
    402024d4:	52800043 	mov	w3, #0x2                   	// #2
    402024d8:	9400002f 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    402024dc:	eb18029f 	cmp	x20, x24
    402024e0:	540003a3 	b.cc	40202554 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x3bc>  // b.lo, b.ul, b.last
    402024e4:	eb13029f 	cmp	x20, x19
    402024e8:	54000362 	b.cs	40202554 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x3bc>  // b.hs, b.nlast
    402024ec:	d5033fdf 	isb
    402024f0:	d53be024 	mrs	x4, cntpct_el0
    402024f4:	d503201f 	nop
    402024f8:	10109148 	adr	x8, 40223720 <jnox_kernel::ordinary_reservations::RECEIPT>
    402024fc:	a9001116 	stp	x22, x4, [x8]
    40202500:	f94202a8 	ldr	x8, [x21, #1024]
    40202504:	f100091f 	cmp	x8, #0x2
    40202508:	54000100 	b.eq	40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x390>  // b.none
    4020250c:	f9429ee5 	ldr	x5, [x23, #1336]
    40202510:	eb05009f 	cmp	x4, x5
    40202514:	540002e2 	b.cs	40202570 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x3d8>  // b.hs, b.nlast
    40202518:	d50342ff 	msr	daifclr, #0x2
    4020251c:	d5033fdf 	isb
    40202520:	d503207f 	wfi
    40202524:	17ffffff 	b	40202520 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062+0x388>
    40202528:	97fffb60 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    4020252c:	52800060 	mov	w0, #0x3                   	// #3
    40202530:	94000392 	bl	40203378 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    40202534:	97fffedd 	bl	402020a8 <jnox_kernel::ordinary_reservations::run::{{closure}}>
    40202538:	394323e4 	ldrb	w4, [sp, #200]
    4020253c:	52800060 	mov	w0, #0x3                   	// #3
    40202540:	52800041 	mov	w1, #0x2                   	// #2
    40202544:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40202548:	52800043 	mov	w3, #0x2                   	// #2
    4020254c:	aa1f03e5 	mov	x5, xzr
    40202550:	94000068 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>
    40202554:	52800040 	mov	w0, #0x2                   	// #2
    40202558:	52800121 	mov	w1, #0x9                   	// #9
    4020255c:	aa1f03e2 	mov	x2, xzr
    40202560:	52800043 	mov	w3, #0x2                   	// #2
    40202564:	aa1403e4 	mov	x4, x20
    40202568:	aa1303e5 	mov	x5, x19
    4020256c:	94000061 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>
    40202570:	52800040 	mov	w0, #0x2                   	// #2
    40202574:	52800161 	mov	w1, #0xb                   	// #11
    40202578:	aa1f03e2 	mov	x2, xzr
    4020257c:	52800043 	mov	w3, #0x2                   	// #2
    40202580:	9400005c 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>
    40202584:	d503201f 	nop
    40202588:	1001cb42 	adr	x2, 40205ef0 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.17900666132547781062+0x48>
    4020258c:	52800041 	mov	w1, #0x2                   	// #2
    40202590:	940009e2 	bl	40204d18 <core::panicking::panic_bounds_check>

0000000040202594 <jnox_kernel::ordinary_reservations::event>:
    40202594:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202598:	f9438909 	ldr	x9, [x8, #1808]
    4020259c:	f110013f 	cmp	x9, #0x400
    402025a0:	54000241 	b.ne	402025e8 <jnox_kernel::ordinary_reservations::event+0x54>  // b.any
    402025a4:	aa1f03e8 	mov	x8, xzr
    402025a8:	52800309 	mov	w9, #0x18                  	// #24
    402025ac:	72a12009 	movk	w9, #0x900, lsl #16
    402025b0:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    402025b4:	d503201f 	nop
    402025b8:	1001c6cb 	adr	x11, 40205e90 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.17900666132547781062+0x10>
    402025bc:	3868696c 	ldrb	w12, [x11, x8]
    402025c0:	b940012d 	ldr	w13, [x9]
    402025c4:	3628006d 	tbz	w13, #5, 402025d0 <jnox_kernel::ordinary_reservations::event+0x3c>
    402025c8:	d5033fdf 	isb
    402025cc:	17fffffd 	b	402025c0 <jnox_kernel::ordinary_reservations::event+0x2c>
    402025d0:	91000508 	add	x8, x8, #0x1
    402025d4:	b900014c 	str	w12, [x10]
    402025d8:	f100511f 	cmp	x8, #0x14
    402025dc:	54ffff01 	b.ne	402025bc <jnox_kernel::ordinary_reservations::event+0x28>  // b.any
    402025e0:	d503205f 	wfe
    402025e4:	17ffffff 	b	402025e0 <jnox_kernel::ordinary_reservations::event+0x4c>
    402025e8:	d503201f 	nop
    402025ec:	1002896a 	adr	x10, 40207718 <jnox_kernel::ordinary_reservations::TRACE>
    402025f0:	8b09194a 	add	x10, x10, x9, lsl #6
    402025f4:	a9000540 	stp	x0, x1, [x10]
    402025f8:	a940308b 	ldp	x11, x12, [x4]
    402025fc:	a9010d42 	stp	x2, x3, [x10, #16]
    40202600:	a941388d 	ldp	x13, x14, [x4, #16]
    40202604:	a902314b 	stp	x11, x12, [x10, #32]
    40202608:	a903394d 	stp	x13, x14, [x10, #48]
    4020260c:	91000529 	add	x9, x9, #0x1
    40202610:	f9038909 	str	x9, [x8, #1808]
    40202614:	d65f03c0 	ret

0000000040202618 <jnox_kernel::ordinary_reservations::fresh>:
    40202618:	d10143ff 	sub	sp, sp, #0x50
    4020261c:	a90357f6 	stp	x22, x21, [sp, #48]
    40202620:	a9044ff4 	stp	x20, x19, [sp, #64]
    40202624:	aa0003f3 	mov	x19, x0
    40202628:	d503201f 	nop
    4020262c:	10007a08 	adr	x8, 4020356c <reservation_worker_a>
    40202630:	d503201f 	nop
    40202634:	10007a29 	adr	x9, 40203578 <reservation_worker_b>
    40202638:	d503201f 	nop
    4020263c:	10ffdaea 	adr	x10, 40202198 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.17900666132547781062>
    40202640:	a900a7e8 	stp	x8, x9, [sp, #8]
    40202644:	a901fbea 	stp	x10, x30, [sp, #24]
    40202648:	f100081f 	cmp	x0, #0x2
    4020264c:	540003a8 	b.hi	402026c0 <jnox_kernel::ordinary_reservations::fresh+0xa8>  // b.pmore
    40202650:	910023e8 	add	x8, sp, #0x8
    40202654:	f8737915 	ldr	x21, [x8, x19, lsl #3]
    40202658:	d503201f 	nop
    4020265c:	100a8628 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062>
    40202660:	8b133916 	add	x22, x8, x19, lsl #14
    40202664:	52879808 	mov	w8, #0x3cc0                	// #15552
    40202668:	8b0802d4 	add	x20, x22, x8
    4020266c:	aa1403e0 	mov	x0, x20
    40202670:	2a1f03e1 	mov	w1, wzr
    40202674:	52806802 	mov	w2, #0x340                 	// #832
    40202678:	94000d84 	bl	40205c88 <memset>
    4020267c:	f91eded5 	str	x21, [x22, #15800]
    40202680:	528068a8 	mov	w8, #0x345                 	// #837
    40202684:	f91ee2c8 	str	x8, [x22, #15808]
    40202688:	f1000a7f 	cmp	x19, #0x2
    4020268c:	54000061 	b.ne	40202698 <jnox_kernel::ordinary_reservations::fresh+0x80>  // b.any
    40202690:	52818328 	mov	w8, #0xc19                 	// #3097
    40202694:	14000004 	b	402026a4 <jnox_kernel::ordinary_reservations::fresh+0x8c>
    40202698:	d503201f 	nop
    4020269c:	1001bf28 	adr	x8, 40205e80 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.17900666132547781062>
    402026a0:	f8737908 	ldr	x8, [x8, x19, lsl #3]
    402026a4:	f9008e88 	str	x8, [x20, #280]
    402026a8:	aa1403e0 	mov	x0, x20
    402026ac:	a9444ff4 	ldp	x20, x19, [sp, #64]
    402026b0:	a94357f6 	ldp	x22, x21, [sp, #48]
    402026b4:	f94013fe 	ldr	x30, [sp, #32]
    402026b8:	910143ff 	add	sp, sp, #0x50
    402026bc:	d65f03c0 	ret
    402026c0:	d503201f 	nop
    402026c4:	1001bf22 	adr	x2, 40205ea8 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.17900666132547781062>
    402026c8:	aa1303e0 	mov	x0, x19
    402026cc:	52800061 	mov	w1, #0x3                   	// #3
    402026d0:	94000992 	bl	40204d18 <core::panicking::panic_bounds_check>

00000000402026d4 <jnox_kernel::ordinary_reservations::state>:
    402026d4:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402026d8:	f9420108 	ldr	x8, [x8, #1024]
    402026dc:	f100091f 	cmp	x8, #0x2
    402026e0:	54000040 	b.eq	402026e8 <jnox_kernel::ordinary_reservations::state+0x14>  // b.none
    402026e4:	d65f03c0 	ret
    402026e8:	f81f0ffe 	str	x30, [sp, #-16]!
    402026ec:	97fffaef 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

00000000402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>:
    402026f0:	d10603ff 	sub	sp, sp, #0x180
    402026f4:	a9127bfd 	stp	x29, x30, [sp, #288]
    402026f8:	a9136ffc 	stp	x28, x27, [sp, #304]
    402026fc:	a91467fa 	stp	x26, x25, [sp, #320]
    40202700:	a9155ff8 	stp	x24, x23, [sp, #336]
    40202704:	a91657f6 	stp	x22, x21, [sp, #352]
    40202708:	a9174ff4 	stp	x20, x19, [sp, #368]
    4020270c:	d5034fdf 	msr	daifset, #0xf
    40202710:	d51be23f 	msr	cntp_ctl_el0, xzr
    40202714:	d5033fdf 	isb
    40202718:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0xb8e0>
    4020271c:	395f6109 	ldrb	w9, [x8, #2008]
    40202720:	7100053f 	cmp	w9, #0x1
    40202724:	54000061 	b.ne	40202730 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x40>  // b.any
    40202728:	d503205f 	wfe
    4020272c:	17ffffff 	b	40202728 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x38>
    40202730:	aa0303fb 	mov	x27, x3
    40202734:	aa0203fc 	mov	x28, x2
    40202738:	a90807e0 	stp	x0, x1, [sp, #128]
    4020273c:	a90917e4 	stp	x4, x5, [sp, #144]
    40202740:	52800029 	mov	w9, #0x1                   	// #1
    40202744:	391f6109 	strb	w9, [x8, #2008]
    40202748:	d503201f 	nop
    4020274c:	1010b6e8 	adr	x8, 40223e28 <jnox_kernel::ordinary_reservations::stage_hooks::stage_probe::OBSERVATION>
    40202750:	f940050a 	ldr	x10, [x8, #8]
    40202754:	f940090b 	ldr	x11, [x8, #16]
    40202758:	f9400108 	ldr	x8, [x8]
    4020275c:	7200011f 	tst	w8, #0x1
    40202760:	9a9f116b 	csel	x11, x11, xzr, ne  // ne = any
    40202764:	9a9f1141 	csel	x1, x10, xzr, ne  // ne = any
    40202768:	5280008a 	mov	w10, #0x4                   	// #4
    4020276c:	a90babe9 	stp	x9, x10, [sp, #184]
    40202770:	f100011f 	cmp	x8, #0x0
    40202774:	1a9f07e8 	cset	w8, ne  // ne = any
    40202778:	a90cafe8 	stp	x8, x11, [sp, #200]
    4020277c:	9102e3e4 	add	x4, sp, #0xb8
    40202780:	528004c0 	mov	w0, #0x26                  	// #38
    40202784:	aa1f03e2 	mov	x2, xzr
    40202788:	52800043 	mov	w3, #0x2                   	// #2
    4020278c:	97ffff82 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202790:	d503201f 	nop
    40202794:	10107c69 	adr	x9, 40223720 <jnox_kernel::ordinary_reservations::RECEIPT>
    40202798:	a9400528 	ldp	x8, x1, [x9]
    4020279c:	a9415538 	ldp	x24, x21, [x9, #16]
    402027a0:	a9424d34 	ldp	x20, x19, [x9, #32]
    402027a4:	a943692b 	ldp	x11, x26, [x9, #48]
    402027a8:	f940212a 	ldr	x10, [x9, #64]
    402027ac:	a9012fea 	stp	x10, x11, [sp, #16]
    402027b0:	a944a92b 	ldp	x11, x10, [x9, #72]
    402027b4:	a9022beb 	stp	x11, x10, [sp, #32]
    402027b8:	a945a93d 	ldp	x29, x10, [x9, #88]
    402027bc:	f9005bea 	str	x10, [sp, #176]
    402027c0:	a946a92b 	ldp	x11, x10, [x9, #104]
    402027c4:	f9001fea 	str	x10, [sp, #56]
    402027c8:	f9403d2a 	ldr	x10, [x9, #120]
    402027cc:	a9042fea 	stp	x10, x11, [sp, #64]
    402027d0:	a948292b 	ldp	x11, x10, [x9, #128]
    402027d4:	f9001beb 	str	x11, [sp, #48]
    402027d8:	f9003fea 	str	x10, [sp, #120]
    402027dc:	a949292b 	ldp	x11, x10, [x9, #144]
    402027e0:	a9062fea 	stp	x10, x11, [sp, #96]
    402027e4:	a94a292b 	ldp	x11, x10, [x9, #160]
    402027e8:	a9052fea 	stp	x10, x11, [sp, #80]
    402027ec:	f9405929 	ldr	x9, [x9, #176]
    402027f0:	f9003be9 	str	x9, [sp, #112]
    402027f4:	d5033fdf 	isb
    402027f8:	d53be039 	mrs	x25, cntpct_el0
    402027fc:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202800:	d503201f 	nop
    40202804:	10026ef6 	adr	x22, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    40202808:	f942f137 	ldr	x23, [x9, #1504]
    4020280c:	a90a6ffc 	stp	x28, x27, [sp, #160]
    40202810:	b40001a1 	cbz	x1, 40202844 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x154>
    40202814:	f9403ec9 	ldr	x9, [x22, #120]
    40202818:	f1000aff 	cmp	x23, #0x2
    4020281c:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    40202820:	a90b87e8 	stp	x8, x1, [sp, #184]
    40202824:	a90cffe9 	stp	x9, xzr, [sp, #200]
    40202828:	9102e3e4 	add	x4, sp, #0xb8
    4020282c:	52800480 	mov	w0, #0x24                  	// #36
    40202830:	aa1f03e2 	mov	x2, xzr
    40202834:	52800043 	mov	w3, #0x2                   	// #2
    40202838:	97ffff57 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    4020283c:	f94002c8 	ldr	x8, [x22]
    40202840:	14000002 	b	40202848 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x158>
    40202844:	aa1703e8 	mov	x8, x23
    40202848:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020284c:	9117a129 	add	x9, x9, #0x5e8
    40202850:	f940012a 	ldr	x10, [x9]
    40202854:	7200011f 	tst	w8, #0x1
    40202858:	52800048 	mov	w8, #0x2                   	// #2
    4020285c:	f9403529 	ldr	x9, [x9, #104]
    40202860:	9a881148 	csel	x8, x10, x8, ne  // ne = any
    40202864:	f1000aff 	cmp	x23, #0x2
    40202868:	da9f113b 	csinv	x27, x9, xzr, ne  // ne = any
    4020286c:	9a8802fc 	csel	x28, x23, x8, eq  // eq = none
    40202870:	d503201f 	nop
    40202874:	10107b68 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    40202878:	c8dffd08 	ldar	x8, [x8]
    4020287c:	a90be3fb 	stp	x27, x24, [sp, #184]
    40202880:	f27e031f 	tst	x24, #0x4
    40202884:	f9405be9 	ldr	x9, [sp, #176]
    40202888:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    4020288c:	a90ca7e8 	stp	x8, x9, [sp, #200]
    40202890:	9102e3e4 	add	x4, sp, #0xb8
    40202894:	52800300 	mov	w0, #0x18                  	// #24
    40202898:	aa1903e1 	mov	x1, x25
    4020289c:	aa1f03e2 	mov	x2, xzr
    402028a0:	aa1c03e3 	mov	x3, x28
    402028a4:	97ffff3c 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    402028a8:	37001d58 	tbnz	w24, #0, 40202c50 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x560>
    402028ac:	37081f78 	tbnz	w24, #1, 40202c98 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x5a8>
    402028b0:	371020f8 	tbnz	w24, #2, 40202ccc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x5dc>
    402028b4:	37182258 	tbnz	w24, #3, 40202cfc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x60c>
    402028b8:	36200378 	tbz	w24, #4, 40202924 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x234>
    402028bc:	a94627e8 	ldp	x8, x9, [sp, #96]
    402028c0:	a90ba3e9 	stp	x9, x8, [sp, #184]
    402028c4:	a94527e8 	ldp	x8, x9, [sp, #80]
    402028c8:	a90ca3e9 	stp	x9, x8, [sp, #200]
    402028cc:	9102e3e4 	add	x4, sp, #0xb8
    402028d0:	528003a0 	mov	w0, #0x1d                  	// #29
    402028d4:	f9403ff3 	ldr	x19, [sp, #120]
    402028d8:	aa1303e1 	mov	x1, x19
    402028dc:	aa1f03e2 	mov	x2, xzr
    402028e0:	aa1c03e3 	mov	x3, x28
    402028e4:	97ffff2c 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    402028e8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402028ec:	91196108 	add	x8, x8, #0x658
    402028f0:	a9402109 	ldp	x9, x8, [x8]
    402028f4:	f1000aff 	cmp	x23, #0x2
    402028f8:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    402028fc:	f9403bea 	ldr	x10, [sp, #112]
    40202900:	a90ba7ea 	stp	x10, x9, [sp, #184]
    40202904:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40202908:	a90cefe8 	stp	x8, x27, [sp, #200]
    4020290c:	9102e3e4 	add	x4, sp, #0xb8
    40202910:	528003c0 	mov	w0, #0x1e                  	// #30
    40202914:	aa1303e1 	mov	x1, x19
    40202918:	aa1f03e2 	mov	x2, xzr
    4020291c:	aa1c03e3 	mov	x3, x28
    40202920:	97ffff1d 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202924:	f1000aff 	cmp	x23, #0x2
    40202928:	54000800 	b.eq	40202a28 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x338>  // b.none
    4020292c:	aa1f03f3 	mov	x19, xzr
    40202930:	52800028 	mov	w8, #0x1                   	// #1
    40202934:	52800714 	mov	w20, #0x38                  	// #56
    40202938:	9b145a77 	madd	x23, x19, x20, x22
    4020293c:	2a0803f5 	mov	w21, w8
    40202940:	a949a6e8 	ldp	x8, x9, [x23, #152]
    40202944:	f94056ea 	ldr	x10, [x23, #168]
    40202948:	a90ba7e8 	stp	x8, x9, [sp, #184]
    4020294c:	f9405ee8 	ldr	x8, [x23, #184]
    40202950:	a90ca3ea 	stp	x10, x8, [sp, #200]
    40202954:	9102e3e4 	add	x4, sp, #0xb8
    40202958:	52800440 	mov	w0, #0x22                  	// #34
    4020295c:	aa1903e1 	mov	x1, x25
    40202960:	aa1f03e2 	mov	x2, xzr
    40202964:	aa1303e3 	mov	x3, x19
    40202968:	97ffff0b 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    4020296c:	f9405ae8 	ldr	x8, [x23, #176]
    40202970:	a94c2ae9 	ldp	x9, x10, [x23, #192]
    40202974:	a90ba7e8 	stp	x8, x9, [sp, #184]
    40202978:	f9404ac8 	ldr	x8, [x22, #144]
    4020297c:	a90ca3ea 	stp	x10, x8, [sp, #200]
    40202980:	9102e3e4 	add	x4, sp, #0xb8
    40202984:	52800460 	mov	w0, #0x23                  	// #35
    40202988:	aa1903e1 	mov	x1, x25
    4020298c:	aa1f03e2 	mov	x2, xzr
    40202990:	aa1303e3 	mov	x3, x19
    40202994:	97ffff00 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202998:	8b1312c8 	add	x8, x22, x19, lsl #4
    4020299c:	a941a909 	ldp	x9, x10, [x8, #24]
    402029a0:	a90babe9 	stp	x9, x10, [sp, #184]
    402029a4:	a943a109 	ldp	x9, x8, [x8, #56]
    402029a8:	a90ca3e9 	stp	x9, x8, [sp, #200]
    402029ac:	9102e3e4 	add	x4, sp, #0xb8
    402029b0:	528003e0 	mov	w0, #0x1f                  	// #31
    402029b4:	aa1903e1 	mov	x1, x25
    402029b8:	aa1f03e2 	mov	x2, xzr
    402029bc:	aa1303e3 	mov	x3, x19
    402029c0:	97fffef5 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    402029c4:	8b130ac8 	add	x8, x22, x19, lsl #2
    402029c8:	b9401109 	ldr	w9, [x8, #16]
    402029cc:	b9405908 	ldr	w8, [x8, #88]
    402029d0:	8b1302ca 	add	x10, x22, x19
    402029d4:	3941814a 	ldrb	w10, [x10, #96]
    402029d8:	b94002cb 	ldr	w11, [x22]
    402029dc:	f94006cc 	ldr	x12, [x22, #8]
    402029e0:	eb13019f 	cmp	x12, x19
    402029e4:	1a9f17ec 	cset	w12, eq  // eq = none
    402029e8:	39418acd 	ldrb	w13, [x22, #98]
    402029ec:	71000dbf 	cmp	w13, #0x3
    402029f0:	1a8d07ed 	csinc	w13, wzr, w13, eq  // eq = none
    402029f4:	a90ba3e9 	stp	x9, x8, [sp, #184]
    402029f8:	6a0c017f 	tst	w11, w12
    402029fc:	9a9f11a8 	csel	x8, x13, xzr, ne  // ne = any
    40202a00:	a90ca3ea 	stp	x10, x8, [sp, #200]
    40202a04:	9102e3e4 	add	x4, sp, #0xb8
    40202a08:	52800400 	mov	w0, #0x20                  	// #32
    40202a0c:	aa1903e1 	mov	x1, x25
    40202a10:	aa1f03e2 	mov	x2, xzr
    40202a14:	aa1303e3 	mov	x3, x19
    40202a18:	97fffedf 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202a1c:	2a1f03e8 	mov	w8, wzr
    40202a20:	52800033 	mov	w19, #0x1                   	// #1
    40202a24:	3707f8b5 	tbnz	w21, #0, 40202938 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x248>
    40202a28:	52801008 	mov	w8, #0x80                  	// #128
    40202a2c:	52802109 	mov	w9, #0x108                 	// #264
    40202a30:	a90ba3e8 	stp	x8, x8, [sp, #184]
    40202a34:	52801708 	mov	w8, #0xb8                  	// #184
    40202a38:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202a3c:	9102e3e4 	add	x4, sp, #0xb8
    40202a40:	52800420 	mov	w0, #0x21                  	// #33
    40202a44:	aa1903e1 	mov	x1, x25
    40202a48:	aa1f03e2 	mov	x2, xzr
    40202a4c:	52800043 	mov	w3, #0x2                   	// #2
    40202a50:	97fffed1 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202a54:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0xb8e0>
    40202a58:	f943f508 	ldr	x8, [x8, #2024]
    40202a5c:	f101011f 	cmp	x8, #0x40
    40202a60:	52800809 	mov	w9, #0x40                  	// #64
    40202a64:	9a893113 	csel	x19, x8, x9, cc  // cc = lo, ul, last
    40202a68:	a94a5ff8 	ldp	x24, x23, [sp, #160]
    40202a6c:	b4000288 	cbz	x8, 40202abc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x3cc>
    40202a70:	aa1f03f4 	mov	x20, xzr
    40202a74:	b0000035 	adrp	x21, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202a78:	910022b5 	add	x21, x21, #0x8
    40202a7c:	b0000116 	adrp	x22, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0xb8e0>
    40202a80:	911fc2d6 	add	x22, x22, #0x7f0
    40202a84:	f9400ac1 	ldr	x1, [x22, #16]
    40202a88:	f94006c8 	ldr	x8, [x22, #8]
    40202a8c:	f84186c9 	ldr	x9, [x22], #24
    40202a90:	aa1403ea 	mov	x10, x20
    40202a94:	91000694 	add	x20, x20, #0x1
    40202a98:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202a9c:	a97f8ea2 	ldp	x2, x3, [x21, #-8]
    40202aa0:	a90cffea 	stp	x10, xzr, [sp, #200]
    40202aa4:	9102e3e4 	add	x4, sp, #0xb8
    40202aa8:	52800180 	mov	w0, #0xc                   	// #12
    40202aac:	97fffeba 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202ab0:	910042b5 	add	x21, x21, #0x10
    40202ab4:	eb14027f 	cmp	x19, x20
    40202ab8:	54fffe61 	b.ne	40202a84 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x394>  // b.any
    40202abc:	52800314 	mov	w20, #0x18                  	// #24
    40202ac0:	72a12014 	movk	w20, #0x900, lsl #16
    40202ac4:	d5033fdf 	isb
    40202ac8:	d53be021 	mrs	x1, cntpct_el0
    40202acc:	a94823e9 	ldp	x9, x8, [sp, #128]
    40202ad0:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202ad4:	a94923e9 	ldp	x9, x8, [sp, #144]
    40202ad8:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202adc:	9102e3e4 	add	x4, sp, #0xb8
    40202ae0:	528001a0 	mov	w0, #0xd                   	// #13
    40202ae4:	aa1803e2 	mov	x2, x24
    40202ae8:	aa1703e3 	mov	x3, x23
    40202aec:	97fffeaa 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202af0:	aa1f03e8 	mov	x8, xzr
    40202af4:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202af8:	d503201f 	nop
    40202afc:	10019e2a 	adr	x10, 40205ec0 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.17900666132547781062+0x18>
    40202b00:	3868694b 	ldrb	w11, [x10, x8]
    40202b04:	b940028c 	ldr	w12, [x20]
    40202b08:	3628006c 	tbz	w12, #5, 40202b14 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x424>
    40202b0c:	d5033fdf 	isb
    40202b10:	17fffffd 	b	40202b04 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x414>
    40202b14:	91000508 	add	x8, x8, #0x1
    40202b18:	b900012b 	str	w11, [x9]
    40202b1c:	f1002d1f 	cmp	x8, #0xb
    40202b20:	54ffff01 	b.ne	40202b00 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x410>  // b.any
    40202b24:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202b28:	f9438915 	ldr	x21, [x8, #1808]
    40202b2c:	b4000755 	cbz	x21, 40202c14 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x524>
    40202b30:	aa1f03f6 	mov	x22, xzr
    40202b34:	9102e3e8 	add	x8, sp, #0xb8
    40202b38:	b202e7f7 	mov	x23, #0xcccccccccccccccc    	// #-3689348814741910324
    40202b3c:	f29999b7 	movk	x23, #0xcccd
    40202b40:	91004113 	add	x19, x8, #0x10
    40202b44:	52800158 	mov	w24, #0xa                   	// #10
    40202b48:	910423f9 	add	x25, sp, #0x108
    40202b4c:	52a1201a 	mov	w26, #0x9000000             	// #150994944
    40202b50:	5280041b 	mov	w27, #0x20                  	// #32
    40202b54:	d503201f 	nop
    40202b58:	10025e1c 	adr	x28, 40207718 <jnox_kernel::ordinary_reservations::TRACE>
    40202b5c:	8b161b81 	add	x1, x28, x22, lsl #6
    40202b60:	910006d6 	add	x22, x22, #0x1
    40202b64:	aa1303e0 	mov	x0, x19
    40202b68:	52800802 	mov	w2, #0x40                  	// #64
    40202b6c:	94000bbb 	bl	40205a58 <memcpy>
    40202b70:	aa1f03e8 	mov	x8, xzr
    40202b74:	b9011bff 	str	wzr, [sp, #280]
    40202b78:	f8687a69 	ldr	x9, [x19, x8, lsl #3]
    40202b7c:	91000508 	add	x8, x8, #0x1
    40202b80:	5280026a 	mov	w10, #0x13                  	// #19
    40202b84:	a910ffff 	stp	xzr, xzr, [sp, #264]
    40202b88:	f1004d5f 	cmp	x10, #0x13
    40202b8c:	54000d08 	b.hi	40202d2c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x63c>  // b.pmore
    40202b90:	9bd77d2b 	umulh	x11, x9, x23
    40202b94:	d343fd6b 	lsr	x11, x11, #3
    40202b98:	1b18a56c 	msub	w12, w11, w24, w9
    40202b9c:	321c058c 	orr	w12, w12, #0x30
    40202ba0:	382a6b2c 	strb	w12, [x25, x10]
    40202ba4:	d100054a 	sub	x10, x10, #0x1
    40202ba8:	f100293f 	cmp	x9, #0xa
    40202bac:	aa0b03e9 	mov	x9, x11
    40202bb0:	54fffec2 	b.cs	40202b88 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x498>  // b.hs, b.nlast
    40202bb4:	91000549 	add	x9, x10, #0x1
    40202bb8:	38696b2a 	ldrb	w10, [x25, x9]
    40202bbc:	b940028b 	ldr	w11, [x20]
    40202bc0:	3628006b 	tbz	w11, #5, 40202bcc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x4dc>
    40202bc4:	d5033fdf 	isb
    40202bc8:	17fffffd 	b	40202bbc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x4cc>
    40202bcc:	91000529 	add	x9, x9, #0x1
    40202bd0:	b900034a 	str	w10, [x26]
    40202bd4:	f100513f 	cmp	x9, #0x14
    40202bd8:	54ffff01 	b.ne	40202bb8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x4c8>  // b.any
    40202bdc:	14000002 	b	40202be4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x4f4>
    40202be0:	d5033fdf 	isb
    40202be4:	b9400289 	ldr	w9, [x20]
    40202be8:	372fffc9 	tbnz	w9, #5, 40202be0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x4f0>
    40202bec:	b900035b 	str	w27, [x26]
    40202bf0:	f100211f 	cmp	x8, #0x8
    40202bf4:	54fffc01 	b.ne	40202b74 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x484>  // b.any
    40202bf8:	14000002 	b	40202c00 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x510>
    40202bfc:	d5033fdf 	isb
    40202c00:	b9400288 	ldr	w8, [x20]
    40202c04:	372fffc8 	tbnz	w8, #5, 40202bfc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x50c>
    40202c08:	b9000358 	str	w24, [x26]
    40202c0c:	eb1502df 	cmp	x22, x21
    40202c10:	54fffa61 	b.ne	40202b5c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x46c>  // b.any
    40202c14:	aa1f03e8 	mov	x8, xzr
    40202c18:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202c1c:	d503201f 	nop
    40202c20:	7001954a 	adr	x10, 40205ecb <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.17900666132547781062+0x23>
    40202c24:	3868694b 	ldrb	w11, [x10, x8]
    40202c28:	b940028c 	ldr	w12, [x20]
    40202c2c:	3628006c 	tbz	w12, #5, 40202c38 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x548>
    40202c30:	d5033fdf 	isb
    40202c34:	17fffffd 	b	40202c28 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x538>
    40202c38:	91000508 	add	x8, x8, #0x1
    40202c3c:	b900012b 	str	w11, [x9]
    40202c40:	f100251f 	cmp	x8, #0x9
    40202c44:	54ffff01 	b.ne	40202c24 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x534>  // b.any
    40202c48:	d503205f 	wfe
    40202c4c:	17ffffff 	b	40202c48 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x558>
    40202c50:	a94127e8 	ldp	x8, x9, [sp, #16]
    40202c54:	a90ba7f3 	stp	x19, x9, [sp, #184]
    40202c58:	a90ca3fa 	stp	x26, x8, [sp, #200]
    40202c5c:	9102e3e4 	add	x4, sp, #0xb8
    40202c60:	52800320 	mov	w0, #0x19                  	// #25
    40202c64:	aa1503e1 	mov	x1, x21
    40202c68:	aa1f03e2 	mov	x2, xzr
    40202c6c:	52800043 	mov	w3, #0x2                   	// #2
    40202c70:	97fffe49 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202c74:	a90bd3f5 	stp	x21, x20, [sp, #184]
    40202c78:	a90ccffa 	stp	x26, x19, [sp, #200]
    40202c7c:	9102e3e4 	add	x4, sp, #0xb8
    40202c80:	528004a0 	mov	w0, #0x25                  	// #37
    40202c84:	aa1403e1 	mov	x1, x20
    40202c88:	aa1f03e2 	mov	x2, xzr
    40202c8c:	52800043 	mov	w3, #0x2                   	// #2
    40202c90:	97fffe41 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202c94:	360fe0f8 	tbz	w24, #1, 402028b0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x1c0>
    40202c98:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202c9c:	f9432d08 	ldr	x8, [x8, #1624]
    40202ca0:	f1000aff 	cmp	x23, #0x2
    40202ca4:	a90bfffb 	stp	x27, xzr, [sp, #184]
    40202ca8:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40202cac:	a90cffe8 	stp	x8, xzr, [sp, #200]
    40202cb0:	9102e3e4 	add	x4, sp, #0xb8
    40202cb4:	52800340 	mov	w0, #0x1a                  	// #26
    40202cb8:	f94013e1 	ldr	x1, [sp, #32]
    40202cbc:	aa1f03e2 	mov	x2, xzr
    40202cc0:	52800043 	mov	w3, #0x2                   	// #2
    40202cc4:	97fffe34 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202cc8:	3617df78 	tbz	w24, #2, 402028b4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x1c4>
    40202ccc:	924003a8 	and	x8, x29, #0x1
    40202cd0:	d341ffa9 	lsr	x9, x29, #1
    40202cd4:	a90ba3fd 	stp	x29, x8, [sp, #184]
    40202cd8:	f9405be8 	ldr	x8, [sp, #176]
    40202cdc:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202ce0:	9102e3e4 	add	x4, sp, #0xb8
    40202ce4:	52800360 	mov	w0, #0x1b                  	// #27
    40202ce8:	f94017e1 	ldr	x1, [sp, #40]
    40202cec:	aa1f03e2 	mov	x2, xzr
    40202cf0:	aa1c03e3 	mov	x3, x28
    40202cf4:	97fffe28 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202cf8:	361fde18 	tbz	w24, #3, 402028b8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x1c8>
    40202cfc:	a94327e8 	ldp	x8, x9, [sp, #48]
    40202d00:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202d04:	52800028 	mov	w8, #0x1                   	// #1
    40202d08:	a94407e9 	ldp	x9, x1, [sp, #64]
    40202d0c:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202d10:	9102e3e4 	add	x4, sp, #0xb8
    40202d14:	52800380 	mov	w0, #0x1c                  	// #28
    40202d18:	aa1f03e2 	mov	x2, xzr
    40202d1c:	aa1c03e3 	mov	x3, x28
    40202d20:	97fffe1d 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202d24:	3727dcd8 	tbnz	w24, #4, 402028bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x1cc>
    40202d28:	17fffeff 	b	40202924 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062+0x234>
    40202d2c:	d503201f 	nop
    40202d30:	10019042 	adr	x2, 40205f38 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.17900666132547781062+0x90>
    40202d34:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    40202d38:	52800281 	mov	w1, #0x14                  	// #20
    40202d3c:	940007f7 	bl	40204d18 <core::panicking::panic_bounds_check>

0000000040202d40 <jnox_kernel::ordinary_reservations::Runtime::arm>:
    40202d40:	d10103ff 	sub	sp, sp, #0x40
    40202d44:	a90257fe 	stp	x30, x21, [sp, #32]
    40202d48:	a9034ff4 	stp	x20, x19, [sp, #48]
    40202d4c:	aa0203f3 	mov	x19, x2
    40202d50:	aa0003e2 	mov	x2, x0
    40202d54:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202d58:	91158129 	add	x9, x9, #0x560
    40202d5c:	a9020533 	stp	x19, x1, [x9, #32]
    40202d60:	52800028 	mov	w8, #0x1                   	// #1
    40202d64:	d51be253 	msr	cntp_cval_el0, x19
    40202d68:	d51be228 	msr	cntp_ctl_el0, x8
    40202d6c:	d5033fdf 	isb
    40202d70:	d53be255 	mrs	x21, cntp_cval_el0
    40202d74:	d53be234 	mrs	x20, cntp_ctl_el0
    40202d78:	d5033fdf 	isb
    40202d7c:	d53be028 	mrs	x8, cntpct_el0
    40202d80:	a90053f3 	stp	x19, x20, [sp]
    40202d84:	f9400123 	ldr	x3, [x9]
    40202d88:	a90107f5 	stp	x21, x1, [sp, #16]
    40202d8c:	910003e4 	mov	x4, sp
    40202d90:	52800060 	mov	w0, #0x3                   	// #3
    40202d94:	aa0803e1 	mov	x1, x8
    40202d98:	97fffdff 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202d9c:	eb1302bf 	cmp	x21, x19
    40202da0:	54000101 	b.ne	40202dc0 <jnox_kernel::ordinary_reservations::Runtime::arm+0x80>  // b.any
    40202da4:	92400688 	and	x8, x20, #0x3
    40202da8:	f100051f 	cmp	x8, #0x1
    40202dac:	540000a1 	b.ne	40202dc0 <jnox_kernel::ordinary_reservations::Runtime::arm+0x80>  // b.any
    40202db0:	a9434ff4 	ldp	x20, x19, [sp, #48]
    40202db4:	a94257fe 	ldp	x30, x21, [sp, #32]
    40202db8:	910103ff 	add	sp, sp, #0x40
    40202dbc:	d65f03c0 	ret
    40202dc0:	97fff93a 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

0000000040202dc4 <jnox_kernel::ordinary_reservations::Runtime::close>:
    40202dc4:	d103c3ff 	sub	sp, sp, #0xf0
    40202dc8:	a9097bfd 	stp	x29, x30, [sp, #144]
    40202dcc:	a90a6ffc 	stp	x28, x27, [sp, #160]
    40202dd0:	a90b67fa 	stp	x26, x25, [sp, #176]
    40202dd4:	a90c5ff8 	stp	x24, x23, [sp, #192]
    40202dd8:	a90d57f6 	stp	x22, x21, [sp, #208]
    40202ddc:	a90e4ff4 	stp	x20, x19, [sp, #224]
    40202de0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202de4:	91140108 	add	x8, x8, #0x500
    40202de8:	a9405113 	ldp	x19, x20, [x8]
    40202dec:	a9412518 	ldp	x24, x9, [x8, #16]
    40202df0:	f90037e9 	str	x9, [sp, #104]
    40202df4:	a942691d 	ldp	x29, x26, [x8, #32]
    40202df8:	3940c119 	ldrb	w25, [x8, #48]
    40202dfc:	52800069 	mov	w9, #0x3                   	// #3
    40202e00:	3900c109 	strb	w9, [x8, #48]
    40202e04:	71000f3f 	cmp	w25, #0x3
    40202e08:	54001d20 	b.eq	402031ac <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.none
    40202e0c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202e10:	f942b108 	ldr	x8, [x8, #1376]
    40202e14:	eb13011f 	cmp	x8, x19
    40202e18:	54001ca1 	b.ne	402031ac <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.any
    40202e1c:	aa0003f5 	mov	x21, x0
    40202e20:	d503201f 	nop
    40202e24:	100a47e8 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062>
    40202e28:	8b133909 	add	x9, x8, x19, lsl #14
    40202e2c:	eb00013f 	cmp	x9, x0
    40202e30:	54001be8 	b.hi	402031ac <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202e34:	b10d06bf 	cmn	x21, #0x341
    40202e38:	54001ba8 	b.hi	402031ac <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202e3c:	d372c669 	lsl	x9, x19, #14
    40202e40:	8b090108 	add	x8, x8, x9
    40202e44:	91401108 	add	x8, x8, #0x4, lsl #12
    40202e48:	910d02a9 	add	x9, x21, #0x340
    40202e4c:	eb08013f 	cmp	x9, x8
    40202e50:	54001ae8 	b.hi	402031ac <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202e54:	aa0303fc 	mov	x28, x3
    40202e58:	2a0203f7 	mov	w23, w2
    40202e5c:	aa0103f6 	mov	x22, x1
    40202e60:	9101c3e8 	add	x8, sp, #0x70
    40202e64:	aa1303e0 	mov	x0, x19
    40202e68:	9400014c 	bl	40203398 <jnox_kernel::ordinary_reservations::snapshot>
    40202e6c:	f1000a7f 	cmp	x19, #0x2
    40202e70:	54001d62 	b.cs	4020321c <jnox_kernel::ordinary_reservations::Runtime::close+0x458>  // b.hs, b.nlast
    40202e74:	a94733fb 	ldp	x27, x12, [sp, #112]
    40202e78:	f94043ef 	ldr	x15, [sp, #128]
    40202e7c:	d503201f 	nop
    40202e80:	10107c08 	adr	x8, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40202e84:	8b130d08 	add	x8, x8, x19, lsl #3
    40202e88:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202e8c:	9114e129 	add	x9, x9, #0x538
    40202e90:	c8dffd0e 	ldar	x14, [x8]
    40202e94:	a9402129 	ldp	x9, x8, [x9]
    40202e98:	9bc87e8a 	umulh	x10, x20, x8
    40202e9c:	eb0a03ff 	cmp	xzr, x10
    40202ea0:	1a9f07eb 	cset	w11, ne  // ne = any
    40202ea4:	9b087e8a 	mul	x10, x20, x8
    40202ea8:	ab09014d 	adds	x13, x10, x9
    40202eac:	1a9f37ea 	cset	w10, cs  // cs = hs, nlast
    40202eb0:	3700180b 	tbnz	w11, #0, 402031b0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202eb4:	350017ea 	cbnz	w10, 402031b0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202eb8:	9100068a 	add	x10, x20, #0x1
    40202ebc:	9bc87d4b 	umulh	x11, x10, x8
    40202ec0:	eb0b03ff 	cmp	xzr, x11
    40202ec4:	1a9f07eb 	cset	w11, ne  // ne = any
    40202ec8:	9b087d48 	mul	x8, x10, x8
    40202ecc:	ab090109 	adds	x9, x8, x9
    40202ed0:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40202ed4:	370016eb 	tbnz	w11, #0, 402031b0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202ed8:	350016c8 	cbnz	w8, 402031b0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202edc:	b100069f 	cmn	x20, #0x1
    40202ee0:	54001680 	b.eq	402031b0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.none
    40202ee4:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202ee8:	f942a508 	ldr	x8, [x8, #1352]
    40202eec:	eb08012a 	subs	x10, x9, x8
    40202ef0:	54001603 	b.cc	402031b0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.lo, b.ul, b.last
    40202ef4:	a9056bfc 	stp	x28, x26, [sp, #80]
    40202ef8:	f9000fe9 	str	x9, [sp, #24]
    40202efc:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0xb8e0>
    40202f00:	f943f508 	ldr	x8, [x8, #2024]
    40202f04:	91000709 	add	x9, x24, #0x1
    40202f08:	eb09011f 	cmp	x8, x9
    40202f0c:	54001501 	b.ne	402031ac <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.any
    40202f10:	b9004ff9 	str	w25, [sp, #76]
    40202f14:	d503201f 	nop
    40202f18:	10104688 	adr	x8, 402237e8 <jnox_ap_returns>
    40202f1c:	52800309 	mov	w9, #0x18                  	// #24
    40202f20:	9b092308 	madd	x8, x24, x9, x8
    40202f24:	f9400509 	ldr	x9, [x8, #8]
    40202f28:	f940090b 	ldr	x11, [x8, #16]
    40202f2c:	f9400d1c 	ldr	x28, [x8, #24]
    40202f30:	eb1c02da 	subs	x26, x22, x28
    40202f34:	540017e3 	b.cc	40203230 <jnox_kernel::ordinary_reservations::Runtime::close+0x46c>  // b.lo, b.ul, b.last
    40202f38:	a902a7eb 	stp	x11, x9, [sp, #40]
    40202f3c:	a903b7ef 	stp	x15, x13, [sp, #56]
    40202f40:	f90033ee 	str	x14, [sp, #96]
    40202f44:	f9000bea 	str	x10, [sp, #16]
    40202f48:	d503201f 	nop
    40202f4c:	100225a8 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40202f50:	8b130d18 	add	x24, x8, x19, lsl #3
    40202f54:	f940d308 	ldr	x8, [x24, #416]
    40202f58:	ab1a0119 	adds	x25, x8, x26
    40202f5c:	540012a2 	b.cs	402031b0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.hs, b.nlast
    40202f60:	f900d319 	str	x25, [x24, #416]
    40202f64:	f94037e8 	ldr	x8, [sp, #104]
    40202f68:	a9076fe8 	stp	x8, x27, [sp, #112]
    40202f6c:	a90833fd 	stp	x29, x12, [sp, #128]
    40202f70:	f90013fb 	str	x27, [sp, #32]
    40202f74:	9101c3e4 	add	x4, sp, #0x70
    40202f78:	52800100 	mov	w0, #0x8                   	// #8
    40202f7c:	aa1603e1 	mov	x1, x22
    40202f80:	aa1403e2 	mov	x2, x20
    40202f84:	aa1303e3 	mov	x3, x19
    40202f88:	aa0c03fb 	mov	x27, x12
    40202f8c:	97fffd82 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202f90:	f9407ea8 	ldr	x8, [x21, #248]
    40202f94:	f9404ea9 	ldr	x9, [x21, #152]
    40202f98:	a90723f5 	stp	x21, x8, [sp, #112]
    40202f9c:	f9408ea8 	ldr	x8, [x21, #280]
    40202fa0:	a90823e9 	stp	x9, x8, [sp, #128]
    40202fa4:	9101c3e4 	add	x4, sp, #0x70
    40202fa8:	52800120 	mov	w0, #0x9                   	// #9
    40202fac:	aa1603e1 	mov	x1, x22
    40202fb0:	aa1403e2 	mov	x2, x20
    40202fb4:	aa1303e3 	mov	x3, x19
    40202fb8:	97fffd77 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202fbc:	f94033e8 	ldr	x8, [sp, #96]
    40202fc0:	a90723fc 	stp	x28, x8, [sp, #112]
    40202fc4:	a9086bf6 	stp	x22, x26, [sp, #128]
    40202fc8:	f90007fa 	str	x26, [sp, #8]
    40202fcc:	9101c3e4 	add	x4, sp, #0x70
    40202fd0:	52800140 	mov	w0, #0xa                   	// #10
    40202fd4:	aa1603e1 	mov	x1, x22
    40202fd8:	aa1403e2 	mov	x2, x20
    40202fdc:	aa1303e3 	mov	x3, x19
    40202fe0:	97fffd6d 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40202fe4:	110006e8 	add	w8, w23, #0x1
    40202fe8:	92401d09 	and	x9, x8, #0xff
    40202fec:	f9402be8 	ldr	x8, [sp, #80]
    40202ff0:	a90723e9 	stp	x9, x8, [sp, #112]
    40202ff4:	f9401fe9 	ldr	x9, [sp, #56]
    40202ff8:	910d02a8 	add	x8, x21, #0x340
    40202ffc:	a90823e9 	stp	x9, x8, [sp, #128]
    40203000:	9101c3e4 	add	x4, sp, #0x70
    40203004:	52800160 	mov	w0, #0xb                   	// #11
    40203008:	aa1603e1 	mov	x1, x22
    4020300c:	aa1403e2 	mov	x2, x20
    40203010:	aa1303e3 	mov	x3, x19
    40203014:	97fffd60 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40203018:	f9402fe8 	ldr	x8, [sp, #88]
    4020301c:	a90767e8 	stp	x8, x25, [sp, #112]
    40203020:	aa1903fa 	mov	x26, x25
    40203024:	a942a7e8 	ldp	x8, x9, [sp, #40]
    40203028:	a90823e9 	stp	x9, x8, [sp, #128]
    4020302c:	9101c3e4 	add	x4, sp, #0x70
    40203030:	52800260 	mov	w0, #0x13                  	// #19
    40203034:	aa1603e1 	mov	x1, x22
    40203038:	aa1403e2 	mov	x2, x20
    4020303c:	aa1303e3 	mov	x3, x19
    40203040:	97fffd55 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40203044:	f94013e4 	ldr	x4, [sp, #32]
    40203048:	b9404fe8 	ldr	w8, [sp, #76]
    4020304c:	6b37011f 	cmp	w8, w23, uxtb
    40203050:	f94023e5 	ldr	x5, [sp, #64]
    40203054:	54000b21 	b.ne	402031b8 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203058:	f94037e8 	ldr	x8, [sp, #104]
    4020305c:	eb080088 	subs	x8, x4, x8
    40203060:	54000ac9 	b.ls	402031b8 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.plast
    40203064:	f9408ea9 	ldr	x9, [x21, #280]
    40203068:	d503201f 	nop
    4020306c:	100170aa 	adr	x10, 40205e80 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.17900666132547781062>
    40203070:	f873794a 	ldr	x10, [x10, x19, lsl #3]
    40203074:	eb0a013f 	cmp	x9, x10
    40203078:	54000a01 	b.ne	402031b8 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    4020307c:	f94082a9 	ldr	x9, [x21, #256]
    40203080:	528011ea 	mov	w10, #0x8f                  	// #143
    40203084:	8a0a0129 	and	x9, x9, x10
    40203088:	f100153f 	cmp	x9, #0x5
    4020308c:	54000961 	b.ne	402031b8 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203090:	52800029 	mov	w9, #0x1                   	// #1
    40203094:	5280006a 	mov	w10, #0x3                   	// #3
    40203098:	aa0803eb 	mov	x11, x8
    4020309c:	9b1d254c 	madd	x12, x10, x29, x9
    402030a0:	f240017f 	tst	x11, #0x1
    402030a4:	9a8c03bd 	csel	x29, x29, x12, eq  // eq = none
    402030a8:	9b0a2529 	madd	x9, x9, x10, x9
    402030ac:	9b0a7d4a 	mul	x10, x10, x10
    402030b0:	d341fd6b 	lsr	x11, x11, #1
    402030b4:	b5ffff4b 	cbnz	x11, 4020309c <jnox_kernel::ordinary_reservations::Runtime::close+0x2d8>
    402030b8:	eb1b03bf 	cmp	x29, x27
    402030bc:	540007e1 	b.ne	402031b8 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    402030c0:	72001eff 	tst	w23, #0xff
    402030c4:	54000060 	b.eq	402030d0 <jnox_kernel::ordinary_reservations::Runtime::close+0x30c>  // b.none
    402030c8:	f104011f 	cmp	x8, #0x100
    402030cc:	54000761 	b.ne	402031b8 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    402030d0:	f94033ea 	ldr	x10, [sp, #96]
    402030d4:	eb16015f 	cmp	x10, x22
    402030d8:	540007c8 	b.hi	402031d0 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.pmore
    402030dc:	eb05039f 	cmp	x28, x5
    402030e0:	54000783 	b.cc	402031d0 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.lo, b.ul, b.last
    402030e4:	eb1c015f 	cmp	x10, x28
    402030e8:	54000743 	b.cc	402031d0 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.lo, b.ul, b.last
    402030ec:	cb050149 	sub	x9, x10, x5
    402030f0:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402030f4:	f942a508 	ldr	x8, [x8, #1352]
    402030f8:	eb08013f 	cmp	x9, x8
    402030fc:	540006a8 	b.hi	402031d0 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.pmore
    40203100:	a9412fe5 	ldp	x5, x11, [sp, #16]
    40203104:	eb0b02df 	cmp	x22, x11
    40203108:	54000708 	b.hi	402031e8 <jnox_kernel::ordinary_reservations::Runtime::close+0x424>  // b.pmore
    4020310c:	12001eea 	and	w10, w23, #0xff
    40203110:	eb0502c9 	subs	x9, x22, x5
    40203114:	9a8933e9 	csel	x9, xzr, x9, cc  // cc = lo, ul, last
    40203118:	3500006a 	cbnz	w10, 40203124 <jnox_kernel::ordinary_reservations::Runtime::close+0x360>
    4020311c:	eb08013f 	cmp	x9, x8
    40203120:	54000648 	b.hi	402031e8 <jnox_kernel::ordinary_reservations::Runtime::close+0x424>  // b.pmore
    40203124:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203128:	f942a108 	ldr	x8, [x8, #1344]
    4020312c:	f94007ea 	ldr	x10, [sp, #8]
    40203130:	eb08015f 	cmp	x10, x8
    40203134:	aa1a03eb 	mov	x11, x26
    40203138:	54000648 	b.hi	40203200 <jnox_kernel::ordinary_reservations::Runtime::close+0x43c>  // b.pmore
    4020313c:	f940db09 	ldr	x9, [x24, #432]
    40203140:	9b087d28 	mul	x8, x9, x8
    40203144:	eb08017f 	cmp	x11, x8
    40203148:	540005c8 	b.hi	40203200 <jnox_kernel::ordinary_reservations::Runtime::close+0x43c>  // b.pmore
    4020314c:	72001eff 	tst	w23, #0xff
    40203150:	54000060 	b.eq	4020315c <jnox_kernel::ordinary_reservations::Runtime::close+0x398>  // b.none
    40203154:	eb0502df 	cmp	x22, x5
    40203158:	540006e2 	b.cs	40203234 <jnox_kernel::ordinary_reservations::Runtime::close+0x470>  // b.hs, b.nlast
    4020315c:	f900e304 	str	x4, [x24, #448]
    40203160:	f900eb1b 	str	x27, [x24, #464]
    40203164:	94000040 	bl	40203264 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    40203168:	aa1303e1 	mov	x1, x19
    4020316c:	2a1703e2 	mov	w2, w23
    40203170:	94000240 	bl	40203a70 <jnox_kernel::reservation_jobs::Jobs::trap>
    40203174:	72001c04 	ands	w4, w0, #0xff
    40203178:	540006a1 	b.ne	4020324c <jnox_kernel::ordinary_reservations::Runtime::close+0x488>  // b.any
    4020317c:	12001ee8 	and	w8, w23, #0xff
    40203180:	7100091f 	cmp	w8, #0x2
    40203184:	54000040 	b.eq	4020318c <jnox_kernel::ordinary_reservations::Runtime::close+0x3c8>  // b.none
    40203188:	f900b715 	str	x21, [x24, #360]
    4020318c:	a94e4ff4 	ldp	x20, x19, [sp, #224]
    40203190:	a94d57f6 	ldp	x22, x21, [sp, #208]
    40203194:	a94c5ff8 	ldp	x24, x23, [sp, #192]
    40203198:	a94b67fa 	ldp	x26, x25, [sp, #176]
    4020319c:	a94a6ffc 	ldp	x28, x27, [sp, #160]
    402031a0:	a9497bfd 	ldp	x29, x30, [sp, #144]
    402031a4:	9103c3ff 	add	sp, sp, #0xf0
    402031a8:	d65f03c0 	ret
    402031ac:	97fff83f 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402031b0:	52800060 	mov	w0, #0x3                   	// #3
    402031b4:	94000071 	bl	40203378 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    402031b8:	52800060 	mov	w0, #0x3                   	// #3
    402031bc:	52800061 	mov	w1, #0x3                   	// #3
    402031c0:	aa1403e2 	mov	x2, x20
    402031c4:	aa1303e3 	mov	x3, x19
    402031c8:	f94037e5 	ldr	x5, [sp, #104]
    402031cc:	97fffd49 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>
    402031d0:	52800040 	mov	w0, #0x2                   	// #2
    402031d4:	52800041 	mov	w1, #0x2                   	// #2
    402031d8:	aa1403e2 	mov	x2, x20
    402031dc:	aa1303e3 	mov	x3, x19
    402031e0:	aa0a03e4 	mov	x4, x10
    402031e4:	97fffd43 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>
    402031e8:	52800040 	mov	w0, #0x2                   	// #2
    402031ec:	52800021 	mov	w1, #0x1                   	// #1
    402031f0:	aa1403e2 	mov	x2, x20
    402031f4:	aa1303e3 	mov	x3, x19
    402031f8:	aa1603e4 	mov	x4, x22
    402031fc:	14000006 	b	40203214 <jnox_kernel::ordinary_reservations::Runtime::close+0x450>
    40203200:	52800040 	mov	w0, #0x2                   	// #2
    40203204:	528000e1 	mov	w1, #0x7                   	// #7
    40203208:	aa1403e2 	mov	x2, x20
    4020320c:	aa1303e3 	mov	x3, x19
    40203210:	aa0a03e4 	mov	x4, x10
    40203214:	aa0b03e5 	mov	x5, x11
    40203218:	97fffd36 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>
    4020321c:	d503201f 	nop
    40203220:	10016802 	adr	x2, 40205f20 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.17900666132547781062+0x78>
    40203224:	aa1303e0 	mov	x0, x19
    40203228:	52800041 	mov	w1, #0x2                   	// #2
    4020322c:	940006bb 	bl	40204d18 <core::panicking::panic_bounds_check>
    40203230:	97fffb9e 	bl	402020a8 <jnox_kernel::ordinary_reservations::run::{{closure}}>
    40203234:	52800040 	mov	w0, #0x2                   	// #2
    40203238:	52800121 	mov	w1, #0x9                   	// #9
    4020323c:	aa1403e2 	mov	x2, x20
    40203240:	aa1303e3 	mov	x3, x19
    40203244:	aa1603e4 	mov	x4, x22
    40203248:	97fffd2a 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>
    4020324c:	52800060 	mov	w0, #0x3                   	// #3
    40203250:	52800041 	mov	w1, #0x2                   	// #2
    40203254:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40203258:	52800043 	mov	w3, #0x2                   	// #2
    4020325c:	aa1f03e5 	mov	x5, xzr
    40203260:	97fffd24 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>

0000000040203264 <jnox_kernel::ordinary_reservations::Runtime::ledger>:
    40203264:	f81f0ffe 	str	x30, [sp, #-16]!
    40203268:	d503201f 	nop
    4020326c:	10102ba8 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    40203270:	c8dffd08 	ldar	x8, [x8]
    40203274:	b4000128 	cbz	x8, 40203298 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x34>
    40203278:	f1000d1f 	cmp	x8, #0x3
    4020327c:	540000c1 	b.ne	40203294 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x30>  // b.any
    40203280:	90000020 	adrp	x0, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203284:	91120000 	add	x0, x0, #0x480
    40203288:	f9400008 	ldr	x8, [x0]
    4020328c:	f100091f 	cmp	x8, #0x2
    40203290:	54000081 	b.ne	402032a0 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x3c>  // b.any
    40203294:	97fff805 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40203298:	d503201f 	nop
    4020329c:	10020b20 	adr	x0, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402032a0:	f84107fe 	ldr	x30, [sp], #16
    402032a4:	d65f03c0 	ret

00000000402032a8 <jnox_kernel::ordinary_reservations::Runtime::select>:
    402032a8:	d10143ff 	sub	sp, sp, #0x50
    402032ac:	f90013fe 	str	x30, [sp, #32]
    402032b0:	a90357f6 	stp	x22, x21, [sp, #48]
    402032b4:	a9044ff4 	stp	x20, x19, [sp, #64]
    402032b8:	d503201f 	nop
    402032bc:	10020a28 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402032c0:	8b010d09 	add	x9, x8, x1, lsl #3
    402032c4:	f940b534 	ldr	x20, [x9, #360]
    402032c8:	d503201f 	nop
    402032cc:	100a22a8 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062>
    402032d0:	f900b53f 	str	xzr, [x9, #360]
    402032d4:	8b013909 	add	x9, x8, x1, lsl #14
    402032d8:	eb14013f 	cmp	x9, x20
    402032dc:	540004c8 	b.hi	40203374 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    402032e0:	aa0103f3 	mov	x19, x1
    402032e4:	d372c429 	lsl	x9, x1, #14
    402032e8:	8b090108 	add	x8, x8, x9
    402032ec:	91401108 	add	x8, x8, #0x4, lsl #12
    402032f0:	910d0289 	add	x9, x20, #0x340
    402032f4:	b10d069f 	cmn	x20, #0x341
    402032f8:	fa489122 	ccmp	x9, x8, #0x2, ls  // ls = plast
    402032fc:	540003c8 	b.hi	40203374 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    40203300:	90000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0xb8e0>
    40203304:	f943f516 	ldr	x22, [x8, #2024]
    40203308:	f100fedf 	cmp	x22, #0x3f
    4020330c:	54000348 	b.hi	40203374 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    40203310:	aa0003f5 	mov	x21, x0
    40203314:	d5033fdf 	isb
    40203318:	d53be021 	mrs	x1, cntpct_el0
    4020331c:	f9407e88 	ldr	x8, [x20, #248]
    40203320:	f9404e89 	ldr	x9, [x20, #152]
    40203324:	a90023f4 	stp	x20, x8, [sp]
    40203328:	f9408e88 	ldr	x8, [x20, #280]
    4020332c:	a90123e9 	stp	x9, x8, [sp, #16]
    40203330:	910003e4 	mov	x4, sp
    40203334:	52800240 	mov	w0, #0x12                  	// #18
    40203338:	aa1503e2 	mov	x2, x21
    4020333c:	aa1303e3 	mov	x3, x19
    40203340:	97fffc95 	bl	40202594 <jnox_kernel::ordinary_reservations::event>
    40203344:	d503201f 	nop
    40203348:	1001e5c8 	adr	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020334c:	8b161108 	add	x8, x8, x22, lsl #4
    40203350:	a9004d15 	stp	x21, x19, [x8]
    40203354:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203358:	f902b113 	str	x19, [x8, #1376]
    4020335c:	aa1403e0 	mov	x0, x20
    40203360:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40203364:	a94357f6 	ldp	x22, x21, [sp, #48]
    40203368:	f94013fe 	ldr	x30, [sp, #32]
    4020336c:	910143ff 	add	sp, sp, #0x50
    40203370:	d65f03c0 	ret
    40203374:	97fff7cd 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

0000000040203378 <jnox_kernel::ordinary_reservations::checked::{{closure}}>:
    40203378:	f81f0ffe 	str	x30, [sp, #-16]!
    4020337c:	92401c04 	and	x4, x0, #0xff
    40203380:	52800060 	mov	w0, #0x3                   	// #3
    40203384:	52800041 	mov	w1, #0x2                   	// #2
    40203388:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4020338c:	52800043 	mov	w3, #0x2                   	// #2
    40203390:	aa1f03e5 	mov	x5, xzr
    40203394:	97fffcd7 	bl	402026f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.17900666132547781062>

0000000040203398 <jnox_kernel::ordinary_reservations::snapshot>:
    40203398:	f81f0ffe 	str	x30, [sp, #-16]!
    4020339c:	f100041f 	cmp	x0, #0x1
    402033a0:	54000488 	b.hi	40203430 <jnox_kernel::ordinary_reservations::snapshot+0x98>  // b.pmore
    402033a4:	d503201f 	nop
    402033a8:	10105349 	adr	x9, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    402033ac:	8b000d29 	add	x9, x9, x0, lsl #3
    402033b0:	c8dffd29 	ldar	x9, [x9]
    402033b4:	b40002c9 	cbz	x9, 4020340c <jnox_kernel::ordinary_reservations::snapshot+0x74>
    402033b8:	d503201f 	nop
    402033bc:	100a1b2a 	adr	x10, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062>
    402033c0:	8b00394b 	add	x11, x10, x0, lsl #14
    402033c4:	eb09017f 	cmp	x11, x9
    402033c8:	54000328 	b.hi	4020342c <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    402033cc:	b100a53f 	cmn	x9, #0x29
    402033d0:	540002e8 	b.hi	4020342c <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    402033d4:	d372c40b 	lsl	x11, x0, #14
    402033d8:	8b0b014a 	add	x10, x10, x11
    402033dc:	9140114a 	add	x10, x10, #0x4, lsl #12
    402033e0:	9100a12b 	add	x11, x9, #0x28
    402033e4:	eb0a017f 	cmp	x11, x10
    402033e8:	54000228 	b.hi	4020342c <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    402033ec:	9100812a 	add	x10, x9, #0x20
    402033f0:	c8dffd40 	ldar	x0, [x10]
    402033f4:	f100041f 	cmp	x0, #0x1
    402033f8:	54000228 	b.hi	4020343c <jnox_kernel::ordinary_reservations::snapshot+0xa4>  // b.pmore
    402033fc:	8b00112b 	add	x11, x9, x0, lsl #4
    40203400:	f940016a 	ldr	x10, [x11]
    40203404:	f940056b 	ldr	x11, [x11, #8]
    40203408:	14000005 	b	4020341c <jnox_kernel::ordinary_reservations::snapshot+0x84>
    4020340c:	aa1f03ea 	mov	x10, xzr
    40203410:	d503201f 	nop
    40203414:	1001536b 	adr	x11, 40205e80 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.17900666132547781062>
    40203418:	f860796b 	ldr	x11, [x11, x0, lsl #3]
    4020341c:	a9002d0a 	stp	x10, x11, [x8]
    40203420:	f9000909 	str	x9, [x8, #16]
    40203424:	f84107fe 	ldr	x30, [sp], #16
    40203428:	d65f03c0 	ret
    4020342c:	97fff79f 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40203430:	d503201f 	nop
    40203434:	100158e2 	adr	x2, 40205f50 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.17900666132547781062+0xa8>
    40203438:	14000003 	b	40203444 <jnox_kernel::ordinary_reservations::snapshot+0xac>
    4020343c:	d503201f 	nop
    40203440:	10015942 	adr	x2, 40205f68 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.17900666132547781062+0xc0>
    40203444:	52800041 	mov	w1, #0x2                   	// #2
    40203448:	94000634 	bl	40204d18 <core::panicking::panic_bounds_check>

000000004020344c <reservation_rust_work>:
    4020344c:	d10103ff 	sub	sp, sp, #0x40
    40203450:	f9001bfe 	str	x30, [sp, #48]
    40203454:	f100041f 	cmp	x0, #0x1
    40203458:	54000768 	b.hi	40203544 <reservation_rust_work+0xf8>  // b.pmore
    4020345c:	aa1f03e9 	mov	x9, xzr
    40203460:	d503201f 	nop
    40203464:	100150e8 	adr	x8, 40205e80 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.17900666132547781062>
    40203468:	910023ea 	add	x10, sp, #0x8
    4020346c:	9280000b 	mov	x11, #0xffffffffffffffff    	// #-1
    40203470:	f860790d 	ldr	x13, [x8, x0, lsl #3]
    40203474:	9100e3ec 	add	x12, sp, #0x38
    40203478:	d503201f 	nop
    4020347c:	10104ca8 	adr	x8, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    40203480:	5280002e 	mov	w14, #0x1                   	// #1
    40203484:	d503201f 	nop
    40203488:	1002130f 	adr	x15, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    4020348c:	8b000d08 	add	x8, x8, x0, lsl #3
    40203490:	8b000def 	add	x15, x15, x0, lsl #3
    40203494:	a900b7ff 	stp	xzr, x13, [sp, #8]
    40203498:	f9000fff 	str	xzr, [sp, #24]
    4020349c:	a9027fed 	stp	x13, xzr, [sp, #32]
    402034a0:	c89ffd0a 	stlr	x10, [x8]
    402034a4:	d503201f 	nop
    402034a8:	10021288 	adr	x8, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    402034ac:	8b000d10 	add	x16, x8, x0, lsl #3
    402034b0:	d503201f 	nop
    402034b4:	101049f1 	adr	x17, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    402034b8:	d503201f 	nop
    402034bc:	10104a28 	adr	x8, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    402034c0:	8b000d12 	add	x18, x8, x0, lsl #3
    402034c4:	c8dffde8 	ldar	x8, [x15]
    402034c8:	eb0b011f 	cmp	x8, x11
    402034cc:	540000a0 	b.eq	402034e0 <reservation_rust_work+0x94>  // b.none
    402034d0:	d5033fdf 	isb
    402034d4:	d53be02b 	mrs	x11, cntpct_el0
    402034d8:	c89ffe4b 	stlr	x11, [x18]
    402034dc:	aa0803eb 	mov	x11, x8
    402034e0:	52800208 	mov	w8, #0x10                  	// #16
    402034e4:	8b0d05ad 	add	x13, x13, x13, lsl #1
    402034e8:	910005ad 	add	x13, x13, #0x1
    402034ec:	f9001fed 	str	x13, [sp, #56]
    402034f0:	f9401fed 	ldr	x13, [sp, #56]
    402034f4:	71000508 	subs	w8, w8, #0x1
    402034f8:	54ffff61 	b.ne	402034e4 <reservation_rust_work+0x98>  // b.any
    402034fc:	f94017e8 	ldr	x8, [sp, #40]
    40203500:	cb0801c8 	sub	x8, x14, x8
    40203504:	f100051f 	cmp	x8, #0x1
    40203508:	54000248 	b.hi	40203550 <reservation_rust_work+0x104>  // b.pmore
    4020350c:	91004129 	add	x9, x9, #0x10
    40203510:	8b081141 	add	x1, x10, x8, lsl #4
    40203514:	f9000029 	str	x9, [x1]
    40203518:	f900042d 	str	x13, [x1, #8]
    4020351c:	91008141 	add	x1, x10, #0x20
    40203520:	c89ffc28 	stlr	x8, [x1]
    40203524:	c8dffe08 	ldar	x8, [x16]
    40203528:	eb08013f 	cmp	x9, x8
    4020352c:	54fffcc1 	b.ne	402034c4 <reservation_rust_work+0x78>  // b.any
    40203530:	f8607a28 	ldr	x8, [x17, x0, lsl #3]
    40203534:	f100091f 	cmp	x8, #0x2
    40203538:	54000161 	b.ne	40203564 <reservation_rust_work+0x118>  // b.any
    4020353c:	d4000021 	svc	#0x1
    40203540:	17ffffe1 	b	402034c4 <reservation_rust_work+0x78>
    40203544:	d503201f 	nop
    40203548:	100151c2 	adr	x2, 40205f80 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.17900666132547781062+0xd8>
    4020354c:	14000004 	b	4020355c <reservation_rust_work+0x110>
    40203550:	d503201f 	nop
    40203554:	10015222 	adr	x2, 40205f98 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.17900666132547781062+0xf0>
    40203558:	aa0803e0 	mov	x0, x8
    4020355c:	52800041 	mov	w1, #0x2                   	// #2
    40203560:	940005ee 	bl	40204d18 <core::panicking::panic_bounds_check>
    40203564:	d4000041 	svc	#0x2
    40203568:	d4200020 	brk	#0x1

000000004020356c <reservation_worker_a>:
    4020356c:	f81f0ffe 	str	x30, [sp, #-16]!
    40203570:	aa1f03e0 	mov	x0, xzr
    40203574:	97ffffb6 	bl	4020344c <reservation_rust_work>

0000000040203578 <reservation_worker_b>:
    40203578:	f81f0ffe 	str	x30, [sp, #-16]!
    4020357c:	52800020 	mov	w0, #0x1                   	// #1
    40203580:	97ffffb3 	bl	4020344c <reservation_rust_work>

0000000040203584 <jnox_kernel::reservation_jobs::Jobs::prepare_destination>:
    40203584:	f9403409 	ldr	x9, [x0, #104]
    40203588:	b40000c9 	cbz	x9, 402035a0 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x1c>
    4020358c:	52800089 	mov	w9, #0x4                   	// #4
    40203590:	39002109 	strb	w9, [x8, #8]
    40203594:	52800049 	mov	w9, #0x2                   	// #2
    40203598:	f9000109 	str	x9, [x8]
    4020359c:	d65f03c0 	ret
    402035a0:	aa1f03ea 	mov	x10, xzr
    402035a4:	9101e009 	add	x9, x0, #0x78
    402035a8:	5280002b 	mov	w11, #0x1                   	// #1
    402035ac:	386a692c 	ldrb	w12, [x9, x10]
    402035b0:	3600008b 	tbz	w11, #0, 402035c0 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x3c>
    402035b4:	2a1f03eb 	mov	w11, wzr
    402035b8:	5280002a 	mov	w10, #0x1                   	// #1
    402035bc:	34ffff8c 	cbz	w12, 402035ac <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x28>
    402035c0:	35fffe6c 	cbnz	w12, 4020358c <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>
    402035c4:	39418009 	ldrb	w9, [x0, #96]
    402035c8:	71000d3f 	cmp	w9, #0x3
    402035cc:	54fffe01 	b.ne	4020358c <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>  // b.any
    402035d0:	f9403809 	ldr	x9, [x0, #112]
    402035d4:	b5fffdc9 	cbnz	x9, 4020358c <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>
    402035d8:	aa1f03e1 	mov	x1, xzr
    402035dc:	14000141 	b	40203ae0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>

00000000402035e0 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision>:
    402035e0:	f9403408 	ldr	x8, [x0, #104]
    402035e4:	f100051f 	cmp	x8, #0x1
    402035e8:	54000321 	b.ne	4020364c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x6c>  // b.any
    402035ec:	d10143ff 	sub	sp, sp, #0x50
    402035f0:	a9025ffe 	stp	x30, x23, [sp, #32]
    402035f4:	a90357f6 	stp	x22, x21, [sp, #48]
    402035f8:	a9044ff4 	stp	x20, x19, [sp, #64]
    402035fc:	aa0003f3 	mov	x19, x0
    40203600:	b9400028 	ldr	w8, [x1]
    40203604:	39418829 	ldrb	w9, [x1, #98]
    40203608:	7100011f 	cmp	w8, #0x0
    4020360c:	52800068 	mov	w8, #0x3                   	// #3
    40203610:	1a881128 	csel	w8, w9, w8, ne  // ne = any
    40203614:	39418009 	ldrb	w9, [x0, #96]
    40203618:	71000d3f 	cmp	w9, #0x3
    4020361c:	540001c0 	b.eq	40203654 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x74>  // b.none
    40203620:	71000d1f 	cmp	w8, #0x3
    40203624:	54000180 	b.eq	40203654 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x74>  // b.none
    40203628:	2a1f03e0 	mov	w0, wzr
    4020362c:	f940042a 	ldr	x10, [x1, #8]
    40203630:	f9402e6b 	ldr	x11, [x19, #88]
    40203634:	eb0b015f 	cmp	x10, x11
    40203638:	1a9f17ea 	cset	w10, eq  // eq = none
    4020363c:	6b08013f 	cmp	w9, w8
    40203640:	540007a1 	b.ne	40203734 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    40203644:	3700012a 	tbnz	w10, #0, 40203668 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x88>
    40203648:	1400003b 	b	40203734 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>
    4020364c:	2a1f03e0 	mov	w0, wzr
    40203650:	d65f03c0 	ret
    40203654:	2a1f03e0 	mov	w0, wzr
    40203658:	71000d3f 	cmp	w9, #0x3
    4020365c:	540006c1 	b.ne	40203734 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    40203660:	71000d1f 	cmp	w8, #0x3
    40203664:	54000681 	b.ne	40203734 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    40203668:	aa1f03eb 	mov	x11, xzr
    4020366c:	9101e268 	add	x8, x19, #0x78
    40203670:	91018029 	add	x9, x1, #0x60
    40203674:	5280002a 	mov	w10, #0x1                   	// #1
    40203678:	386b690c 	ldrb	w12, [x8, x11]
    4020367c:	386b692d 	ldrb	w13, [x9, x11]
    40203680:	360000aa 	tbz	w10, #0, 40203694 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xb4>
    40203684:	2a1f03ea 	mov	w10, wzr
    40203688:	6b0d019f 	cmp	w12, w13
    4020368c:	5280002b 	mov	w11, #0x1                   	// #1
    40203690:	54ffff40 	b.eq	40203678 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x98>  // b.none
    40203694:	6b0d019f 	cmp	w12, w13
    40203698:	540004c1 	b.ne	40203730 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x150>  // b.any
    4020369c:	f9403a68 	ldr	x8, [x19, #112]
    402036a0:	f9402c29 	ldr	x9, [x1, #88]
    402036a4:	eb09011f 	cmp	x8, x9
    402036a8:	54000441 	b.ne	40203730 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x150>  // b.any
    402036ac:	aa1f03e8 	mov	x8, xzr
    402036b0:	91002274 	add	x20, x19, #0x8
    402036b4:	b8418675 	ldr	w21, [x19], #24
    402036b8:	91010037 	add	x23, x1, #0x40
    402036bc:	aa0803f6 	mov	x22, x8
    402036c0:	f100091f 	cmp	x8, #0x2
    402036c4:	54000300 	b.eq	40203724 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.none
    402036c8:	360000b5 	tbz	w21, #0, 402036dc <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xfc>
    402036cc:	b9400268 	ldr	w8, [x19]
    402036d0:	f85f0269 	ldur	x9, [x19, #-16]
    402036d4:	a90127e8 	stp	x8, x9, [sp, #16]
    402036d8:	14000009 	b	402036fc <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x11c>
    402036dc:	910023e8 	add	x8, sp, #0x8
    402036e0:	aa1403e0 	mov	x0, x20
    402036e4:	aa1f03e1 	mov	x1, xzr
    402036e8:	940002ec 	bl	40204298 <jnox_kernel::service_policy::PeriodicReservation::allocation_at>
    402036ec:	f94007e8 	ldr	x8, [sp, #8]
    402036f0:	f100051f 	cmp	x8, #0x1
    402036f4:	54000181 	b.ne	40203724 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.any
    402036f8:	f9400be8 	ldr	x8, [sp, #16]
    402036fc:	f85f82e9 	ldur	x9, [x23, #-8]
    40203700:	eb09011f 	cmp	x8, x9
    40203704:	54000101 	b.ne	40203724 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.any
    40203708:	f84106e9 	ldr	x9, [x23], #16
    4020370c:	91006273 	add	x19, x19, #0x18
    40203710:	f9400fea 	ldr	x10, [sp, #24]
    40203714:	9100a294 	add	x20, x20, #0x28
    40203718:	910006c8 	add	x8, x22, #0x1
    4020371c:	eb09015f 	cmp	x10, x9
    40203720:	54fffce0 	b.eq	402036bc <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xdc>  // b.none
    40203724:	f10006df 	cmp	x22, #0x1
    40203728:	1a9f97e0 	cset	w0, hi  // hi = pmore
    4020372c:	14000002 	b	40203734 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>
    40203730:	2a1f03e0 	mov	w0, wzr
    40203734:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40203738:	a94357f6 	ldp	x22, x21, [sp, #48]
    4020373c:	a9425ffe 	ldp	x30, x23, [sp, #32]
    40203740:	910143ff 	add	sp, sp, #0x50
    40203744:	d65f03c0 	ret

0000000040203748 <jnox_kernel::reservation_jobs::Jobs::new>:
    40203748:	d10203ff 	sub	sp, sp, #0x80
    4020374c:	a90657fe 	stp	x30, x21, [sp, #96]
    40203750:	a9074ff4 	stp	x20, x19, [sp, #112]
    40203754:	2a0103f4 	mov	w20, w1
    40203758:	2a0003f5 	mov	w21, w0
    4020375c:	aa0803f3 	mov	x19, x8
    40203760:	72001c3f 	tst	w1, #0xff
    40203764:	540002c0 	b.eq	402037bc <jnox_kernel::reservation_jobs::Jobs::new+0x74>  // b.none
    40203768:	52800028 	mov	w8, #0x1                   	// #1
    4020376c:	52800049 	mov	w9, #0x2                   	// #2
    40203770:	290027e8 	stp	w8, w9, [sp]
    40203774:	12001e8a 	and	w10, w20, #0xff
    40203778:	7100095f 	cmp	w10, #0x2
    4020377c:	290127e8 	stp	w8, w9, [sp, #8]
    40203780:	540002a1 	b.ne	402037d4 <jnox_kernel::reservation_jobs::Jobs::new+0x8c>  // b.any
    40203784:	29402be9 	ldp	w9, w10, [sp]
    40203788:	29022be9 	stp	w9, w10, [sp, #16]
    4020378c:	29412be9 	ldp	w9, w10, [sp, #8]
    40203790:	29032be9 	stp	w9, w10, [sp, #24]
    40203794:	52800109 	mov	w9, #0x8                   	// #8
    40203798:	290427e8 	stp	w8, w9, [sp, #32]
    4020379c:	910043e0 	add	x0, sp, #0x10
    402037a0:	52800061 	mov	w1, #0x3                   	// #3
    402037a4:	940003cc 	bl	402046d4 <jnox_kernel::temporal_policy::admit_reservations>
    402037a8:	12001c08 	and	w8, w0, #0xff
    402037ac:	71000d1f 	cmp	w8, #0x3
    402037b0:	54000401 	b.ne	40203830 <jnox_kernel::reservation_jobs::Jobs::new+0xe8>  // b.any
    402037b4:	52800088 	mov	w8, #0x4                   	// #4
    402037b8:	1400003b 	b	402038a4 <jnox_kernel::reservation_jobs::Jobs::new+0x15c>
    402037bc:	52800048 	mov	w8, #0x2                   	// #2
    402037c0:	52800109 	mov	w9, #0x8                   	// #8
    402037c4:	5280002a 	mov	w10, #0x1                   	// #1
    402037c8:	290027e8 	stp	w8, w9, [sp]
    402037cc:	52800088 	mov	w8, #0x4                   	// #4
    402037d0:	290123ea 	stp	w10, w8, [sp, #8]
    402037d4:	910003e0 	mov	x0, sp
    402037d8:	52800041 	mov	w1, #0x2                   	// #2
    402037dc:	940003be 	bl	402046d4 <jnox_kernel::temporal_policy::admit_reservations>
    402037e0:	12001c08 	and	w8, w0, #0xff
    402037e4:	71000d1f 	cmp	w8, #0x3
    402037e8:	54000241 	b.ne	40203830 <jnox_kernel::reservation_jobs::Jobs::new+0xe8>  // b.any
    402037ec:	34000275 	cbz	w21, 40203838 <jnox_kernel::reservation_jobs::Jobs::new+0xf0>
    402037f0:	294027e8 	ldp	w8, w9, [sp]
    402037f4:	290a27e8 	stp	w8, w9, [sp, #80]
    402037f8:	294127e8 	ldp	w8, w9, [sp, #8]
    402037fc:	290b27e8 	stp	w8, w9, [sp, #88]
    40203800:	910043e8 	add	x8, sp, #0x10
    40203804:	910143e1 	add	x1, sp, #0x50
    40203808:	aa1f03e0 	mov	x0, xzr
    4020380c:	940002e4 	bl	4020439c <jnox_kernel::temporal_policy::HardCbs<_>::new>
    40203810:	b94013e8 	ldr	w8, [sp, #16]
    40203814:	36000468 	tbz	w8, #0, 402038a0 <jnox_kernel::reservation_jobs::Jobs::new+0x158>
    40203818:	a941a7ee 	ldp	x14, x9, [sp, #24]
    4020381c:	a942a3eb 	ldp	x11, x8, [sp, #40]
    40203820:	a943abec 	ldp	x12, x10, [sp, #56]
    40203824:	5280002f 	mov	w15, #0x1                   	// #1
    40203828:	f94027ed 	ldr	x13, [sp, #72]
    4020382c:	14000011 	b	40203870 <jnox_kernel::reservation_jobs::Jobs::new+0x128>
    40203830:	11000508 	add	w8, w8, #0x1
    40203834:	1400001c 	b	402038a4 <jnox_kernel::reservation_jobs::Jobs::new+0x15c>
    40203838:	294027e8 	ldp	w8, w9, [sp]
    4020383c:	d100050a 	sub	x10, x8, #0x1
    40203840:	eb09015f 	cmp	x10, x9
    40203844:	540002e2 	b.cs	402038a0 <jnox_kernel::reservation_jobs::Jobs::new+0x158>  // b.hs, b.nlast
    40203848:	294137ea 	ldp	w10, w13, [sp, #8]
    4020384c:	d100054b 	sub	x11, x10, #0x1
    40203850:	eb0d017f 	cmp	x11, x13
    40203854:	54000262 	b.cs	402038a0 <jnox_kernel::reservation_jobs::Jobs::new+0x158>  // b.hs, b.nlast
    40203858:	aa1f03ec 	mov	x12, xzr
    4020385c:	aa1f03eb 	mov	x11, xzr
    40203860:	aa1f03ef 	mov	x15, xzr
    40203864:	72001e9f 	tst	w20, #0xff
    40203868:	1a9f17f0 	cset	w16, eq  // eq = none
    4020386c:	aa0803ee 	mov	x14, x8
    40203870:	a9003a6f 	stp	x15, x14, [x19]
    40203874:	a9012e69 	stp	x9, x11, [x19, #16]
    40203878:	a9023268 	stp	x8, x12, [x19, #32]
    4020387c:	a903366a 	stp	x10, x13, [x19, #48]
    40203880:	a9042a70 	stp	x16, x10, [x19, #64]
    40203884:	f9002a70 	str	x16, [x19, #80]
    40203888:	52800068 	mov	w8, #0x3                   	// #3
    4020388c:	39018268 	strb	w8, [x19, #96]
    40203890:	a906fe7f 	stp	xzr, xzr, [x19, #104]
    40203894:	7900f27f 	strh	wzr, [x19, #120]
    40203898:	3901ea74 	strb	w20, [x19, #122]
    4020389c:	14000005 	b	402038b0 <jnox_kernel::reservation_jobs::Jobs::new+0x168>
    402038a0:	52800028 	mov	w8, #0x1                   	// #1
    402038a4:	39002268 	strb	w8, [x19, #8]
    402038a8:	52800048 	mov	w8, #0x2                   	// #2
    402038ac:	f9000268 	str	x8, [x19]
    402038b0:	a9474ff4 	ldp	x20, x19, [sp, #112]
    402038b4:	a94657fe 	ldp	x30, x21, [sp, #96]
    402038b8:	910203ff 	add	sp, sp, #0x80
    402038bc:	d65f03c0 	ret

00000000402038c0 <jnox_kernel::reservation_jobs::Jobs::open>:
    402038c0:	d10783ff 	sub	sp, sp, #0x1e0
    402038c4:	a9197bfd 	stp	x29, x30, [sp, #400]
    402038c8:	a91a67fa 	stp	x26, x25, [sp, #416]
    402038cc:	a91b5ff8 	stp	x24, x23, [sp, #432]
    402038d0:	a91c57f6 	stp	x22, x21, [sp, #448]
    402038d4:	a91d4ff4 	stp	x20, x19, [sp, #464]
    402038d8:	aa0803f3 	mov	x19, x8
    402038dc:	f9403408 	ldr	x8, [x0, #104]
    402038e0:	eb08003f 	cmp	x1, x8
    402038e4:	540002e1 	b.ne	40203940 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.any
    402038e8:	aa0103f5 	mov	x21, x1
    402038ec:	aa0003f4 	mov	x20, x0
    402038f0:	3941e816 	ldrb	w22, [x0, #122]
    402038f4:	710002df 	cmp	w22, #0x0
    402038f8:	52800148 	mov	w8, #0xa                   	// #10
    402038fc:	52800449 	mov	w9, #0x22                  	// #34
    40203900:	9a880128 	csel	x8, x9, x8, eq  // eq = none
    40203904:	eb08003f 	cmp	x1, x8
    40203908:	540001c2 	b.cs	40203940 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.hs, b.nlast
    4020390c:	39418288 	ldrb	w8, [x20, #96]
    40203910:	71000d1f 	cmp	w8, #0x3
    40203914:	54000161 	b.ne	40203940 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.any
    40203918:	aa1403e1 	mov	x1, x20
    4020391c:	f8408428 	ldr	x8, [x1], #8
    40203920:	f100051f 	cmp	x8, #0x1
    40203924:	54000241 	b.ne	4020396c <jnox_kernel::reservation_jobs::Jobs::open+0xac>  // b.any
    40203928:	f9401e97 	ldr	x23, [x20, #56]
    4020392c:	910583e0 	add	x0, sp, #0x160
    40203930:	52800602 	mov	w2, #0x30                  	// #48
    40203934:	94000849 	bl	40205a58 <memcpy>
    40203938:	52800028 	mov	w8, #0x1                   	// #1
    4020393c:	14000021 	b	402039c0 <jnox_kernel::reservation_jobs::Jobs::open+0x100>
    40203940:	52800088 	mov	w8, #0x4                   	// #4
    40203944:	39002268 	strb	w8, [x19, #8]
    40203948:	52800048 	mov	w8, #0x2                   	// #2
    4020394c:	f9000268 	str	x8, [x19]
    40203950:	a95d4ff4 	ldp	x20, x19, [sp, #464]
    40203954:	a95c57f6 	ldp	x22, x21, [sp, #448]
    40203958:	a95b5ff8 	ldp	x24, x23, [sp, #432]
    4020395c:	a95a67fa 	ldp	x26, x25, [sp, #416]
    40203960:	a9597bfd 	ldp	x29, x30, [sp, #400]
    40203964:	910783ff 	add	sp, sp, #0x1e0
    40203968:	d65f03c0 	ret
    4020396c:	910203e0 	add	x0, sp, #0x80
    40203970:	9100a017 	add	x23, x0, #0x28
    40203974:	52800028 	mov	w8, #0x1                   	// #1
    40203978:	2a0803f8 	mov	w24, w8
    4020397c:	9100a039 	add	x25, x1, #0x28
    40203980:	52800502 	mov	w2, #0x28                  	// #40
    40203984:	94000835 	bl	40205a58 <memcpy>
    40203988:	2a1f03e8 	mov	w8, wzr
    4020398c:	aa1903e1 	mov	x1, x25
    40203990:	aa1703e0 	mov	x0, x23
    40203994:	3707ff38 	tbnz	w24, #0, 40203978 <jnox_kernel::reservation_jobs::Jobs::open+0xb8>
    40203998:	910583e0 	add	x0, sp, #0x160
    4020399c:	910203e1 	add	x1, sp, #0x80
    402039a0:	52800602 	mov	w2, #0x30                  	// #48
    402039a4:	9400082d 	bl	40205a58 <memcpy>
    402039a8:	aa1f03e8 	mov	x8, xzr
    402039ac:	a94b27f7 	ldp	x23, x9, [sp, #176]
    402039b0:	a94c2fea 	ldp	x10, x11, [sp, #192]
    402039b4:	a914abe9 	stp	x9, x10, [sp, #328]
    402039b8:	f900afeb 	str	x11, [sp, #344]
    402039bc:	f9402e98 	ldr	x24, [x20, #88]
    402039c0:	f9403a99 	ldr	x25, [x20, #112]
    402039c4:	f90003e8 	str	x8, [sp]
    402039c8:	910003e8 	mov	x8, sp
    402039cc:	7940f29a 	ldrh	w26, [x20, #120]
    402039d0:	91002100 	add	x0, x8, #0x8
    402039d4:	910583e1 	add	x1, sp, #0x160
    402039d8:	52800602 	mov	w2, #0x30                  	// #48
    402039dc:	9400081f 	bl	40205a58 <memcpy>
    402039e0:	3901ebf6 	strb	w22, [sp, #122]
    402039e4:	a954a7e8 	ldp	x8, x9, [sp, #328]
    402039e8:	a903a3f7 	stp	x23, x8, [sp, #56]
    402039ec:	f940afe8 	ldr	x8, [sp, #344]
    402039f0:	a904a3e9 	stp	x9, x8, [sp, #72]
    402039f4:	a906e7f5 	stp	x21, x25, [sp, #104]
    402039f8:	7900f3fa 	strh	w26, [sp, #120]
    402039fc:	f9002ff8 	str	x24, [sp, #88]
    40203a00:	52800068 	mov	w8, #0x3                   	// #3
    40203a04:	390183e8 	strb	w8, [sp, #96]
    40203a08:	910203f7 	add	x23, sp, #0x80
    40203a0c:	910203e8 	add	x8, sp, #0x80
    40203a10:	910003e0 	mov	x0, sp
    40203a14:	aa1503e1 	mov	x1, x21
    40203a18:	94000032 	bl	40203ae0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>
    40203a1c:	f94043f6 	ldr	x22, [sp, #128]
    40203a20:	394223f5 	ldrb	w21, [sp, #136]
    40203a24:	f1000adf 	cmp	x22, #0x2
    40203a28:	54000061 	b.ne	40203a34 <jnox_kernel::reservation_jobs::Jobs::open+0x174>  // b.any
    40203a2c:	39002275 	strb	w21, [x19, #8]
    40203a30:	17ffffc6 	b	40203948 <jnox_kernel::reservation_jobs::Jobs::open+0x88>
    40203a34:	9103a3e0 	add	x0, sp, #0xe8
    40203a38:	910026e1 	add	x1, x23, #0x9
    40203a3c:	52800be2 	mov	w2, #0x5f                  	// #95
    40203a40:	94000806 	bl	40205a58 <memcpy>
    40203a44:	910003e1 	mov	x1, sp
    40203a48:	aa1403e0 	mov	x0, x20
    40203a4c:	52801002 	mov	w2, #0x80                  	// #128
    40203a50:	94000802 	bl	40205a58 <memcpy>
    40203a54:	f9000276 	str	x22, [x19]
    40203a58:	39002275 	strb	w21, [x19, #8]
    40203a5c:	91002660 	add	x0, x19, #0x9
    40203a60:	9103a3e1 	add	x1, sp, #0xe8
    40203a64:	52800be2 	mov	w2, #0x5f                  	// #95
    40203a68:	940007fc 	bl	40205a58 <memcpy>
    40203a6c:	17ffffb9 	b	40203950 <jnox_kernel::reservation_jobs::Jobs::open+0x90>

0000000040203a70 <jnox_kernel::reservation_jobs::Jobs::trap>:
    40203a70:	3941800a 	ldrb	w10, [x0, #96]
    40203a74:	71000d5f 	cmp	w10, #0x3
    40203a78:	54000061 	b.ne	40203a84 <jnox_kernel::reservation_jobs::Jobs::trap+0x14>  // b.any
    40203a7c:	52800080 	mov	w0, #0x4                   	// #4
    40203a80:	d65f03c0 	ret
    40203a84:	aa0003e8 	mov	x8, x0
    40203a88:	12001c49 	and	w9, w2, #0xff
    40203a8c:	52800080 	mov	w0, #0x4                   	// #4
    40203a90:	6b09015f 	cmp	w10, w9
    40203a94:	54000181 	b.ne	40203ac4 <jnox_kernel::reservation_jobs::Jobs::trap+0x54>  // b.any
    40203a98:	f9402d0a 	ldr	x10, [x8, #88]
    40203a9c:	eb01015f 	cmp	x10, x1
    40203aa0:	54000121 	b.ne	40203ac4 <jnox_kernel::reservation_jobs::Jobs::trap+0x54>  // b.any
    40203aa4:	f100043f 	cmp	x1, #0x1
    40203aa8:	54000108 	b.hi	40203ac8 <jnox_kernel::reservation_jobs::Jobs::trap+0x58>  // b.pmore
    40203aac:	2a1f03e0 	mov	w0, wzr
    40203ab0:	11000929 	add	w9, w9, #0x2
    40203ab4:	8b01010a 	add	x10, x8, x1
    40203ab8:	3901e149 	strb	w9, [x10, #120]
    40203abc:	52800069 	mov	w9, #0x3                   	// #3
    40203ac0:	39018109 	strb	w9, [x8, #96]
    40203ac4:	d65f03c0 	ret
    40203ac8:	f81f0ffe 	str	x30, [sp, #-16]!
    40203acc:	d503201f 	nop
    40203ad0:	10012702 	adr	x2, 40205fb0 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236>
    40203ad4:	aa0103e0 	mov	x0, x1
    40203ad8:	52800041 	mov	w1, #0x2                   	// #2
    40203adc:	9400048f 	bl	40204d18 <core::panicking::panic_bounds_check>

0000000040203ae0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>:
    40203ae0:	d10483ff 	sub	sp, sp, #0x120
    40203ae4:	a90c7bfd 	stp	x29, x30, [sp, #192]
    40203ae8:	a90d6ffc 	stp	x28, x27, [sp, #208]
    40203aec:	a90e67fa 	stp	x26, x25, [sp, #224]
    40203af0:	a90f5ff8 	stp	x24, x23, [sp, #240]
    40203af4:	a91057f6 	stp	x22, x21, [sp, #256]
    40203af8:	a9114ff4 	stp	x20, x19, [sp, #272]
    40203afc:	aa0103f5 	mov	x21, x1
    40203b00:	aa0003f4 	mov	x20, x0
    40203b04:	aa0803f3 	mov	x19, x8
    40203b08:	3941e808 	ldrb	w8, [x0, #122]
    40203b0c:	910083e9 	add	x9, sp, #0x20
    40203b10:	9100413b 	add	x27, x9, #0x10
    40203b14:	340000e8 	cbz	w8, 40203b30 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x50>
    40203b18:	f10002bf 	cmp	x21, #0x0
    40203b1c:	b21e03e9 	mov	x9, #0x400000004           	// #17179869188
    40203b20:	9a9f0129 	csel	x9, x9, xzr, eq  // eq = none
    40203b24:	7100051f 	cmp	w8, #0x1
    40203b28:	9a9f012a 	csel	x10, x9, xzr, eq  // eq = none
    40203b2c:	1400000b 	b	40203b58 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203b30:	aa1f03ea 	mov	x10, xzr
    40203b34:	f1005ebf 	cmp	x21, #0x17
    40203b38:	54000108 	b.hi	40203b58 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>  // b.pmore
    40203b3c:	52800028 	mov	w8, #0x1                   	// #1
    40203b40:	9ad52108 	lsl	x8, x8, x21
    40203b44:	52840629 	mov	w9, #0x2031                	// #8241
    40203b48:	72a00809 	movk	w9, #0x40, lsl #16
    40203b4c:	ea09011f 	tst	x8, x9
    40203b50:	54000da0 	b.eq	40203d04 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x224>  // b.none
    40203b54:	5280002a 	mov	w10, #0x1                   	// #1
    40203b58:	aa1f03f6 	mov	x22, xzr
    40203b5c:	a9012bea 	stp	x10, x10, [sp, #16]
    40203b60:	5280011d 	mov	w29, #0x8                   	// #8
    40203b64:	910063fa 	add	x26, sp, #0x18
    40203b68:	5280003c 	mov	w28, #0x1                   	// #1
    40203b6c:	b8767b57 	ldr	w23, [x26, x22, lsl #2]
    40203b70:	34000297 	cbz	w23, 40203bc0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0xe0>
    40203b74:	8b160298 	add	x24, x20, x22
    40203b78:	3941e308 	ldrb	w8, [x24, #120]
    40203b7c:	71000d1f 	cmp	w8, #0x3
    40203b80:	7a401904 	ccmp	w8, #0x0, #0x4, ne  // ne = any
    40203b84:	540014a1 	b.ne	40203e18 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.any
    40203b88:	8b160a99 	add	x25, x20, x22, lsl #2
    40203b8c:	b9407328 	ldr	w8, [x25, #112]
    40203b90:	35001448 	cbnz	w8, 40203e18 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203b94:	f9400288 	ldr	x8, [x20]
    40203b98:	f100051f 	cmp	x8, #0x1
    40203b9c:	540000e1 	b.ne	40203bb8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0xd8>  // b.any
    40203ba0:	91002280 	add	x0, x20, #0x8
    40203ba4:	aa1603e1 	mov	x1, x22
    40203ba8:	2a1703e2 	mov	w2, w23
    40203bac:	9400027e 	bl	402045a4 <jnox_kernel::temporal_policy::HardCbs<_>::release>
    40203bb0:	f100141f 	cmp	x0, #0x5
    40203bb4:	54000a01 	b.ne	40203cf4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x214>  // b.any
    40203bb8:	b9007337 	str	w23, [x25, #112]
    40203bbc:	3901e31c 	strb	w28, [x24, #120]
    40203bc0:	f10013bd 	subs	x29, x29, #0x4
    40203bc4:	910006d6 	add	x22, x22, #0x1
    40203bc8:	54fffd21 	b.ne	40203b6c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x8c>  // b.any
    40203bcc:	6f00e400 	movi	v0.2d, #0x0
    40203bd0:	ad0103e0 	stp	q0, q0, [sp, #32]
    40203bd4:	f9400288 	ldr	x8, [x20]
    40203bd8:	f100051f 	cmp	x8, #0x1
    40203bdc:	54000421 	b.ne	40203c60 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x180>  // b.any
    40203be0:	aa1f03f5 	mov	x21, xzr
    40203be4:	aa1f03fb 	mov	x27, xzr
    40203be8:	91006296 	add	x22, x20, #0x18
    40203bec:	910083f7 	add	x23, sp, #0x20
    40203bf0:	910203e8 	add	x8, sp, #0x80
    40203bf4:	91002280 	add	x0, x20, #0x8
    40203bf8:	aa1503e1 	mov	x1, x21
    40203bfc:	94000290 	bl	4020463c <jnox_kernel::temporal_policy::HardCbs<_>::available>
    40203c00:	a94823e9 	ldp	x9, x8, [sp, #128]
    40203c04:	f100093f 	cmp	x9, #0x2
    40203c08:	54000280 	b.eq	40203c58 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x178>  // b.none
    40203c0c:	36000069 	tbz	w9, #0, 40203c18 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x138>
    40203c10:	f9404be9 	ldr	x9, [sp, #144]
    40203c14:	14000003 	b	40203c20 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x140>
    40203c18:	b94002c8 	ldr	w8, [x22]
    40203c1c:	f85f02c9 	ldur	x9, [x22, #-16]
    40203c20:	8b1b02ea 	add	x10, x23, x27
    40203c24:	9100437b 	add	x27, x27, #0x10
    40203c28:	2a0803e8 	mov	w8, w8
    40203c2c:	a9002548 	stp	x8, x9, [x10]
    40203c30:	910062d6 	add	x22, x22, #0x18
    40203c34:	910006b5 	add	x21, x21, #0x1
    40203c38:	f100837f 	cmp	x27, #0x20
    40203c3c:	54fffda1 	b.ne	40203bf0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x110>  // b.any
    40203c40:	910203e8 	add	x8, sp, #0x80
    40203c44:	91002280 	add	x0, x20, #0x8
    40203c48:	940001f9 	bl	4020442c <jnox_kernel::temporal_policy::HardCbs<_>::tick>
    40203c4c:	a94823e9 	ldp	x9, x8, [sp, #128]
    40203c50:	f100053f 	cmp	x9, #0x1
    40203c54:	54000641 	b.ne	40203d1c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x23c>  // b.any
    40203c58:	f100111f 	cmp	x8, #0x4
    40203c5c:	14000027 	b	40203cf8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x218>
    40203c60:	910083e8 	add	x8, sp, #0x20
    40203c64:	b27d0117 	orr	x23, x8, #0x8
    40203c68:	52800a1a 	mov	w26, #0x50                  	// #80
    40203c6c:	91002296 	add	x22, x20, #0x8
    40203c70:	910203e8 	add	x8, sp, #0x80
    40203c74:	aa1603e0 	mov	x0, x22
    40203c78:	aa1503e1 	mov	x1, x21
    40203c7c:	94000187 	bl	40204298 <jnox_kernel::service_policy::PeriodicReservation::allocation_at>
    40203c80:	b94083e8 	ldr	w8, [sp, #128]
    40203c84:	36001108 	tbz	w8, #0, 40203ea4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c4>
    40203c88:	a948a7e8 	ldp	x8, x9, [sp, #136]
    40203c8c:	f100a35a 	subs	x26, x26, #0x28
    40203c90:	a93fa6e8 	stp	x8, x9, [x23, #-8]
    40203c94:	9100a2d6 	add	x22, x22, #0x28
    40203c98:	910042f7 	add	x23, x23, #0x10
    40203c9c:	54fffea1 	b.ne	40203c70 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x190>  // b.any
    40203ca0:	aa1f03e8 	mov	x8, xzr
    40203ca4:	910083e9 	add	x9, sp, #0x20
    40203ca8:	9101c28c 	add	x12, x20, #0x70
    40203cac:	a90827ec 	stp	x12, x9, [sp, #128]
    40203cb0:	5280004a 	mov	w10, #0x2                   	// #2
    40203cb4:	a909a7ea 	stp	x10, x9, [sp, #152]
    40203cb8:	f9400bf7 	ldr	x23, [sp, #16]
    40203cbc:	9100050a 	add	x10, x8, #0x1
    40203cc0:	b868798b 	ldr	w11, [x12, x8, lsl #2]
    40203cc4:	3400006b 	cbz	w11, 40203cd0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x1f0>
    40203cc8:	f940012b 	ldr	x11, [x9]
    40203ccc:	b50003cb 	cbnz	x11, 40203d44 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x264>
    40203cd0:	f100095f 	cmp	x10, #0x2
    40203cd4:	aa1b03e9 	mov	x9, x27
    40203cd8:	52800028 	mov	w8, #0x1                   	// #1
    40203cdc:	54ffff01 	b.ne	40203cbc <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x1dc>  // b.any
    40203ce0:	aa1f03e9 	mov	x9, xzr
    40203ce4:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203ce8:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203cec:	52800068 	mov	w8, #0x3                   	// #3
    40203cf0:	14000059 	b	40203e54 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x374>
    40203cf4:	f100101f 	cmp	x0, #0x4
    40203cf8:	52800068 	mov	w8, #0x3                   	// #3
    40203cfc:	1a880508 	cinc	w8, w8, ne  // ne = any
    40203d00:	1400006a 	b	40203ea8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c8>
    40203d04:	f10006bf 	cmp	x21, #0x1
    40203d08:	540008c0 	b.eq	40203e20 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x340>  // b.none
    40203d0c:	f1005ebf 	cmp	x21, #0x17
    40203d10:	54fff241 	b.ne	40203b58 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>  // b.any
    40203d14:	52800c8a 	mov	w10, #0x64                  	// #100
    40203d18:	17ffff90 	b	40203b58 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203d1c:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203d20:	f9404bf6 	ldr	x22, [sp, #144]
    40203d24:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203d28:	36000808 	tbz	w8, #0, 40203e28 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x348>
    40203d2c:	f10006df 	cmp	x22, #0x1
    40203d30:	f9400bf7 	ldr	x23, [sp, #16]
    40203d34:	54000369 	b.ls	40203da0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x2c0>  // b.plast
    40203d38:	d503201f 	nop
    40203d3c:	10011522 	adr	x2, 40205fe0 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x30>
    40203d40:	14000067 	b	40203edc <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3fc>
    40203d44:	f9004bea 	str	x10, [sp, #144]
    40203d48:	f9400529 	ldr	x9, [x9, #8]
    40203d4c:	a90aa3e9 	stp	x9, x8, [sp, #168]
    40203d50:	f9005fe8 	str	x8, [sp, #184]
    40203d54:	910183e8 	add	x8, sp, #0x60
    40203d58:	91002108 	add	x8, x8, #0x8
    40203d5c:	910203e0 	add	x0, sp, #0x80
    40203d60:	9102a3e1 	add	x1, sp, #0xa8
    40203d64:	94000098 	bl	40203fc4 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold>
    40203d68:	f9403ff6 	ldr	x22, [sp, #120]
    40203d6c:	f1000adf 	cmp	x22, #0x2
    40203d70:	54000b22 	b.cs	40203ed4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3f4>  // b.hs, b.nlast
    40203d74:	52800508 	mov	w8, #0x28                  	// #40
    40203d78:	91002289 	add	x9, x20, #0x8
    40203d7c:	9b0826c0 	madd	x0, x22, x8, x9
    40203d80:	aa1503e1 	mov	x1, x21
    40203d84:	52800022 	mov	w2, #0x1                   	// #1
    40203d88:	9400015f 	bl	40204304 <jnox_kernel::service_policy::PeriodicReservation::grant_at>
    40203d8c:	f100041f 	cmp	x0, #0x1
    40203d90:	fa410820 	ccmp	x1, #0x1, #0x0, eq  // eq = none
    40203d94:	54000421 	b.ne	40203e18 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.any
    40203d98:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203d9c:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203da0:	9101e288 	add	x8, x20, #0x78
    40203da4:	38766908 	ldrb	w8, [x8, x22]
    40203da8:	51000508 	sub	w8, w8, #0x1
    40203dac:	7100091f 	cmp	w8, #0x2
    40203db0:	54000342 	b.cs	40203e18 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.hs, b.nlast
    40203db4:	9101c28a 	add	x10, x20, #0x70
    40203db8:	b8767948 	ldr	w8, [x10, x22, lsl #2]
    40203dbc:	51000509 	sub	w9, w8, #0x1
    40203dc0:	d3607d29 	lsl	x9, x9, #32
    40203dc4:	7100011f 	cmp	w8, #0x0
    40203dc8:	52808028 	mov	w8, #0x401                 	// #1025
    40203dcc:	9a890108 	csel	x8, x8, x9, eq  // eq = none
    40203dd0:	37000248 	tbnz	w8, #0, 40203e18 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203dd4:	d360fd08 	lsr	x8, x8, #32
    40203dd8:	b8367948 	str	w8, [x10, x22, lsl #2]
    40203ddc:	910103e9 	add	x9, sp, #0x40
    40203de0:	8b161129 	add	x9, x9, x22, lsl #4
    40203de4:	f940012a 	ldr	x10, [x9]
    40203de8:	b400018a 	cbz	x10, 40203e18 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203dec:	d100054a 	sub	x10, x10, #0x1
    40203df0:	f900012a 	str	x10, [x9]
    40203df4:	3941ea89 	ldrb	w9, [x20, #122]
    40203df8:	7100093f 	cmp	w9, #0x2
    40203dfc:	540001e0 	b.eq	40203e38 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x358>  // b.none
    40203e00:	7100053f 	cmp	w9, #0x1
    40203e04:	540001e1 	b.ne	40203e40 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x360>  // b.any
    40203e08:	f100011f 	cmp	x8, #0x0
    40203e0c:	52800048 	mov	w8, #0x2                   	// #2
    40203e10:	1a9f0108 	csel	w8, w8, wzr, eq  // eq = none
    40203e14:	1400000d 	b	40203e48 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x368>
    40203e18:	52800088 	mov	w8, #0x4                   	// #4
    40203e1c:	14000023 	b	40203ea8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c8>
    40203e20:	d2c00c8a 	mov	x10, #0x6400000000          	// #429496729600
    40203e24:	17ffff4d 	b	40203b58 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203e28:	aa1f03e9 	mov	x9, xzr
    40203e2c:	52800068 	mov	w8, #0x3                   	// #3
    40203e30:	f9400bf7 	ldr	x23, [sp, #16]
    40203e34:	14000008 	b	40203e54 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x374>
    40203e38:	2a1f03e8 	mov	w8, wzr
    40203e3c:	14000003 	b	40203e48 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x368>
    40203e40:	f100011f 	cmp	x8, #0x0
    40203e44:	1a9f17e8 	cset	w8, eq  // eq = none
    40203e48:	f9002e96 	str	x22, [x20, #88]
    40203e4c:	52800029 	mov	w9, #0x1                   	// #1
    40203e50:	39018288 	strb	w8, [x20, #96]
    40203e54:	f940368a 	ldr	x10, [x20, #104]
    40203e58:	b100055f 	cmn	x10, #0x1
    40203e5c:	54000240 	b.eq	40203ea4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c4>  // b.none
    40203e60:	9100054a 	add	x10, x10, #0x1
    40203e64:	f900368a 	str	x10, [x20, #104]
    40203e68:	a9422fea 	ldp	x10, x11, [sp, #32]
    40203e6c:	a94337ec 	ldp	x12, x13, [sp, #48]
    40203e70:	a902326b 	stp	x11, x12, [x19, #32]
    40203e74:	a94433eb 	ldp	x11, x12, [sp, #64]
    40203e78:	a9032e6d 	stp	x13, x11, [x19, #48]
    40203e7c:	a9452fed 	ldp	x13, x11, [sp, #80]
    40203e80:	a904366c 	stp	x12, x13, [x19, #64]
    40203e84:	a9005a69 	stp	x9, x22, [x19]
    40203e88:	7940f289 	ldrh	w9, [x20, #120]
    40203e8c:	f9403a8c 	ldr	x12, [x20, #112]
    40203e90:	a9012a77 	stp	x23, x10, [x19, #16]
    40203e94:	a905326b 	stp	x11, x12, [x19, #80]
    40203e98:	7900c269 	strh	w9, [x19, #96]
    40203e9c:	39018a68 	strb	w8, [x19, #98]
    40203ea0:	14000005 	b	40203eb4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3d4>
    40203ea4:	52800068 	mov	w8, #0x3                   	// #3
    40203ea8:	39002268 	strb	w8, [x19, #8]
    40203eac:	52800048 	mov	w8, #0x2                   	// #2
    40203eb0:	f9000268 	str	x8, [x19]
    40203eb4:	a9514ff4 	ldp	x20, x19, [sp, #272]
    40203eb8:	a95057f6 	ldp	x22, x21, [sp, #256]
    40203ebc:	a94f5ff8 	ldp	x24, x23, [sp, #240]
    40203ec0:	a94e67fa 	ldp	x26, x25, [sp, #224]
    40203ec4:	a94d6ffc 	ldp	x28, x27, [sp, #208]
    40203ec8:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    40203ecc:	910483ff 	add	sp, sp, #0x120
    40203ed0:	d65f03c0 	ret
    40203ed4:	d503201f 	nop
    40203ed8:	10010782 	adr	x2, 40205fc8 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x18>
    40203edc:	aa1603e0 	mov	x0, x22
    40203ee0:	52800041 	mov	w1, #0x2                   	// #2
    40203ee4:	9400038d 	bl	40204d18 <core::panicking::panic_bounds_check>

0000000040203ee8 <jnox_kernel::reservation_jobs::Clock::new>:
    40203ee8:	b40005a1 	cbz	x1, 40203f9c <jnox_kernel::reservation_jobs::Clock::new+0xb4>
    40203eec:	d343fc29 	lsr	x9, x1, #3
    40203ef0:	d29ef9ea 	mov	x10, #0xf7cf                	// #63439
    40203ef4:	f2bc6a6a 	movk	x10, #0xe353, lsl #16
    40203ef8:	f2d374aa 	movk	x10, #0x9ba5, lsl #32
    40203efc:	f2e4188a 	movk	x10, #0x20c4, lsl #48
    40203f00:	9bca7d29 	umulh	x9, x9, x10
    40203f04:	d344fd29 	lsr	x9, x9, #4
    40203f08:	52807d0a 	mov	w10, #0x3e8                 	// #1000
    40203f0c:	9b0a852a 	msub	x10, x9, x10, x1
    40203f10:	b500046a 	cbnz	x10, 40203f9c <jnox_kernel::reservation_jobs::Clock::new+0xb4>
    40203f14:	b202e7ea 	mov	x10, #0xcccccccccccccccc    	// #-3689348814741910324
    40203f18:	f29999aa 	movk	x10, #0xcccd
    40203f1c:	9bca7c2a 	umulh	x10, x1, x10
    40203f20:	d344fd4a 	lsr	x10, x10, #4
    40203f24:	72001c5f 	tst	w2, #0xff
    40203f28:	5280014b 	mov	w11, #0xa                   	// #10
    40203f2c:	5280050c 	mov	w12, #0x28                  	// #40
    40203f30:	9a8b018b 	csel	x11, x12, x11, eq  // eq = none
    40203f34:	9bca7d6c 	umulh	x12, x11, x10
    40203f38:	eb0c03ff 	cmp	xzr, x12
    40203f3c:	1a9f07ec 	cset	w12, ne  // ne = any
    40203f40:	9b0a7d6b 	mul	x11, x11, x10
    40203f44:	ab0b001f 	cmn	x0, x11
    40203f48:	1a9f37eb 	cset	w11, cs  // cs = hs, nlast
    40203f4c:	3700020c 	tbnz	w12, #0, 40203f8c <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f50:	350001eb 	cbnz	w11, 40203f8c <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f54:	72001c5f 	tst	w2, #0xff
    40203f58:	5280014b 	mov	w11, #0xa                   	// #10
    40203f5c:	5280044c 	mov	w12, #0x22                  	// #34
    40203f60:	9a8b018b 	csel	x11, x12, x11, eq  // eq = none
    40203f64:	9bca7d6c 	umulh	x12, x11, x10
    40203f68:	eb0c03ff 	cmp	xzr, x12
    40203f6c:	1a9f07ed 	cset	w13, ne  // ne = any
    40203f70:	9b0a7d6b 	mul	x11, x11, x10
    40203f74:	ab00016b 	adds	x11, x11, x0
    40203f78:	1a9f37ec 	cset	w12, cs  // cs = hs, nlast
    40203f7c:	3700008d 	tbnz	w13, #0, 40203f8c <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f80:	3500006c 	cbnz	w12, 40203f8c <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f84:	ab09057f 	cmn	x11, x9, lsl #1
    40203f88:	54000123 	b.cc	40203fac <jnox_kernel::reservation_jobs::Clock::new+0xc4>  // b.lo, b.ul, b.last
    40203f8c:	52800069 	mov	w9, #0x3                   	// #3
    40203f90:	39000509 	strb	w9, [x8, #1]
    40203f94:	5280002b 	mov	w11, #0x1                   	// #1
    40203f98:	14000003 	b	40203fa4 <jnox_kernel::reservation_jobs::Clock::new+0xbc>
    40203f9c:	5280002b 	mov	w11, #0x1                   	// #1
    40203fa0:	3900050b 	strb	w11, [x8, #1]
    40203fa4:	3900010b 	strb	w11, [x8]
    40203fa8:	d65f03c0 	ret
    40203fac:	2a1f03eb 	mov	w11, wzr
    40203fb0:	a900a900 	stp	x0, x10, [x8, #8]
    40203fb4:	f9000d09 	str	x9, [x8, #24]
    40203fb8:	17fffffb 	b	40203fa4 <jnox_kernel::reservation_jobs::Clock::new+0xbc>

0000000040203fbc <__rustc::rust_begin_unwind>:
    40203fbc:	d503205f 	wfe
    40203fc0:	17ffffff 	b	40203fbc <__rustc::rust_begin_unwind>

0000000040203fc4 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold>:
    40203fc4:	d10103ff 	sub	sp, sp, #0x40
    40203fc8:	f9001bfe 	str	x30, [sp, #48]
    40203fcc:	a9412809 	ldp	x9, x10, [x0, #16]
    40203fd0:	eb0a013f 	cmp	x9, x10
    40203fd4:	540004e2 	b.cs	40204070 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0xac>  // b.hs, b.nlast
    40203fd8:	f940100e 	ldr	x14, [x0, #32]
    40203fdc:	a940340b 	ldp	x11, x13, [x0]
    40203fe0:	910003ec 	mov	x12, sp
    40203fe4:	9100618c 	add	x12, x12, #0x18
    40203fe8:	f100093f 	cmp	x9, #0x2
    40203fec:	5280004f 	mov	w15, #0x2                   	// #2
    40203ff0:	9a8f8120 	csel	x0, x9, x15, hi  // hi = pmore
    40203ff4:	8b0911ad 	add	x13, x13, x9, lsl #4
    40203ff8:	8b0911ce 	add	x14, x14, x9, lsl #4
    40203ffc:	910021ce 	add	x14, x14, #0x8
    40204000:	eb09001f 	cmp	x0, x9
    40204004:	54000440 	b.eq	4020408c <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0xc8>  // b.none
    40204008:	b869796f 	ldr	w15, [x11, x9, lsl #2]
    4020400c:	3400028f 	cbz	w15, 4020405c <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x98>
    40204010:	f94001af 	ldr	x15, [x13]
    40204014:	b400024f 	cbz	x15, 4020405c <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x98>
    40204018:	f94001cf 	ldr	x15, [x14]
    4020401c:	a9404430 	ldp	x16, x17, [x1]
    40204020:	a90047f0 	stp	x16, x17, [sp]
    40204024:	f9400831 	ldr	x17, [x1, #16]
    40204028:	a9013ff1 	stp	x17, x15, [sp, #16]
    4020402c:	eb0f021f 	cmp	x16, x15
    40204030:	a90227e9 	stp	x9, x9, [sp, #32]
    40204034:	54000061 	b.ne	40204040 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x7c>  // b.any
    40204038:	f94007ef 	ldr	x15, [sp, #8]
    4020403c:	eb0901ff 	cmp	x15, x9
    40204040:	aa0c03ef 	mov	x15, x12
    40204044:	54000048 	b.hi	4020404c <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x88>  // b.pmore
    40204048:	910003ef 	mov	x15, sp
    4020404c:	a94045f0 	ldp	x16, x17, [x15]
    40204050:	a9004430 	stp	x16, x17, [x1]
    40204054:	f94009ef 	ldr	x15, [x15, #16]
    40204058:	f900082f 	str	x15, [x1, #16]
    4020405c:	91000529 	add	x9, x9, #0x1
    40204060:	910041ad 	add	x13, x13, #0x10
    40204064:	910041ce 	add	x14, x14, #0x10
    40204068:	eb09015f 	cmp	x10, x9
    4020406c:	54fffca1 	b.ne	40204000 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x3c>  // b.any
    40204070:	a9402829 	ldp	x9, x10, [x1]
    40204074:	a9002909 	stp	x9, x10, [x8]
    40204078:	f9400829 	ldr	x9, [x1, #16]
    4020407c:	f9000909 	str	x9, [x8, #16]
    40204080:	f9401bfe 	ldr	x30, [sp, #48]
    40204084:	910103ff 	add	sp, sp, #0x40
    40204088:	d65f03c0 	ret
    4020408c:	d503201f 	nop
    40204090:	1000ff42 	adr	x2, 40206078 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.12776753234347168069>
    40204094:	52800041 	mov	w1, #0x2                   	// #2
    40204098:	94000320 	bl	40204d18 <core::panicking::panic_bounds_check>

000000004020409c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>:
    4020409c:	d10083ff 	sub	sp, sp, #0x20
    402040a0:	d503201f 	nop
    402040a4:	10ffa649 	adr	x9, 4020356c <reservation_worker_a>
    402040a8:	d503201f 	nop
    402040ac:	10ffa66a 	adr	x10, 40203578 <reservation_worker_b>
    402040b0:	f90003e9 	str	x9, [sp]
    402040b4:	a900fbea 	stp	x10, x30, [sp, #8]
    402040b8:	f100043f 	cmp	x1, #0x1
    402040bc:	540009c8 	b.hi	402041f4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x158>  // b.pmore
    402040c0:	d503201f 	nop
    402040c4:	1009b2e9 	adr	x9, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062>
    402040c8:	8b01392a 	add	x10, x9, x1, lsl #14
    402040cc:	9140114b 	add	x11, x10, #0x4, lsl #12
    402040d0:	52879809 	mov	w9, #0x3cc0                	// #15552
    402040d4:	8b090149 	add	x9, x10, x9
    402040d8:	eb09017f 	cmp	x11, x9
    402040dc:	540008a3 	b.cc	402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.lo, b.ul, b.last
    402040e0:	eb0a013f 	cmp	x9, x10
    402040e4:	54000863 	b.cc	402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.lo, b.ul, b.last
    402040e8:	f940000a 	ldr	x10, [x0]
    402040ec:	8b010d4b 	add	x11, x10, x1, lsl #3
    402040f0:	f940b56d 	ldr	x13, [x11, #360]
    402040f4:	eb0d013f 	cmp	x9, x13
    402040f8:	540007c1 	b.ne	402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    402040fc:	910003ea 	mov	x10, sp
    40204100:	f861794a 	ldr	x10, [x10, x1, lsl #3]
    40204104:	f9407dac 	ldr	x12, [x13, #248]
    40204108:	eb0a019f 	cmp	x12, x10
    4020410c:	54000721 	b.ne	402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    40204110:	f94081ac 	ldr	x12, [x13, #256]
    40204114:	f10d159f 	cmp	x12, #0x345
    40204118:	540006c1 	b.ne	402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    4020411c:	f9404dac 	ldr	x12, [x13, #152]
    40204120:	b500068c 	cbnz	x12, 402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    40204124:	d503201f 	nop
    40204128:	1000eacc 	adr	x12, 40205e80 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.17900666132547781062>
    4020412c:	f861798c 	ldr	x12, [x12, x1, lsl #3]
    40204130:	f9408dad 	ldr	x13, [x13, #280]
    40204134:	eb0c01bf 	cmp	x13, x12
    40204138:	540005c1 	b.ne	402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    4020413c:	d503201f 	nop
    40204140:	1001ad4d 	adr	x13, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40204144:	8b010dad 	add	x13, x13, x1, lsl #3
    40204148:	c8dffdad 	ldar	x13, [x13]
    4020414c:	b10005bf 	cmn	x13, #0x1
    40204150:	54000501 	b.ne	402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    40204154:	d503201f 	nop
    40204158:	100fe4cd 	adr	x13, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    4020415c:	8b010dad 	add	x13, x13, x1, lsl #3
    40204160:	c8dffdad 	ldar	x13, [x13]
    40204164:	b500046d 	cbnz	x13, 402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    40204168:	d503201f 	nop
    4020416c:	1001ac6d 	adr	x13, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40204170:	8b010dad 	add	x13, x13, x1, lsl #3
    40204174:	c8dffdad 	ldar	x13, [x13]
    40204178:	b10005bf 	cmn	x13, #0x1
    4020417c:	540003a1 	b.ne	402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    40204180:	d503201f 	nop
    40204184:	100fe3ed 	adr	x13, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40204188:	8b010dad 	add	x13, x13, x1, lsl #3
    4020418c:	c8dffdad 	ldar	x13, [x13]
    40204190:	b500030d 	cbnz	x13, 402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    40204194:	d503201f 	nop
    40204198:	100fe3cd 	adr	x13, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    4020419c:	8b010dad 	add	x13, x13, x1, lsl #3
    402041a0:	c8dffdad 	ldar	x13, [x13]
    402041a4:	b500026d 	cbnz	x13, 402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    402041a8:	f940e16d 	ldr	x13, [x11, #448]
    402041ac:	b500022d 	cbnz	x13, 402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    402041b0:	f940e96d 	ldr	x13, [x11, #464]
    402041b4:	eb0c01bf 	cmp	x13, x12
    402041b8:	540001c1 	b.ne	402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    402041bc:	f940c96d 	ldr	x13, [x11, #400]
    402041c0:	b10005bf 	cmn	x13, #0x1
    402041c4:	54000161 	b.ne	402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    402041c8:	f940d16b 	ldr	x11, [x11, #416]
    402041cc:	b500012b 	cbnz	x11, 402041f0 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    402041d0:	a9002909 	stp	x9, x10, [x8]
    402041d4:	528068a9 	mov	w9, #0x345                 	// #837
    402041d8:	a9017d09 	stp	x9, xzr, [x8, #16]
    402041dc:	a9027d0c 	stp	x12, xzr, [x8, #32]
    402041e0:	f900190c 	str	x12, [x8, #48]
    402041e4:	f9400bfe 	ldr	x30, [sp, #16]
    402041e8:	910083ff 	add	sp, sp, #0x20
    402041ec:	d65f03c0 	ret
    402041f0:	97fff42e 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402041f4:	d503201f 	nop
    402041f8:	1000f4c2 	adr	x2, 40206090 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.12776753234347168069+0x18>
    402041fc:	aa0103e0 	mov	x0, x1
    40204200:	52800041 	mov	w1, #0x2                   	// #2
    40204204:	940002c5 	bl	40204d18 <core::panicking::panic_bounds_check>

0000000040204208 <jnox_kernel::uart_write>:
    40204208:	b40001a1 	cbz	x1, 4020423c <jnox_kernel::uart_write+0x34>
    4020420c:	8b010008 	add	x8, x0, x1
    40204210:	52800309 	mov	w9, #0x18                  	// #24
    40204214:	72a12009 	movk	w9, #0x900, lsl #16
    40204218:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    4020421c:	3840140b 	ldrb	w11, [x0], #1
    40204220:	b940012c 	ldr	w12, [x9]
    40204224:	3628006c 	tbz	w12, #5, 40204230 <jnox_kernel::uart_write+0x28>
    40204228:	d5033fdf 	isb
    4020422c:	17fffffd 	b	40204220 <jnox_kernel::uart_write+0x18>
    40204230:	b900014b 	str	w11, [x10]
    40204234:	eb08001f 	cmp	x0, x8
    40204238:	54ffff21 	b.ne	4020421c <jnox_kernel::uart_write+0x14>  // b.any
    4020423c:	d65f03c0 	ret

0000000040204240 <jnox_kernel::kernel_main>:
    40204240:	f00000e8 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.17900666132547781062+0xb8e0>
    40204244:	f9471108 	ldr	x8, [x8, #3616]
    40204248:	b4000068 	cbz	x8, 40204254 <jnox_kernel::kernel_main+0x14>
    4020424c:	d503205f 	wfe
    40204250:	17ffffff 	b	4020424c <jnox_kernel::kernel_main+0xc>
    40204254:	f81f0ffe 	str	x30, [sp, #-16]!
    40204258:	52800608 	mov	w8, #0x30                  	// #48
    4020425c:	72a12008 	movk	w8, #0x900, lsl #16
    40204260:	b900011f 	str	wzr, [x8]
    40204264:	528001a9 	mov	w9, #0xd                   	// #13
    40204268:	5280002a 	mov	w10, #0x1                   	// #1
    4020426c:	b81f4109 	stur	w9, [x8, #-12]
    40204270:	b81f810a 	stur	w10, [x8, #-8]
    40204274:	52800c09 	mov	w9, #0x60                  	// #96
    40204278:	b81fc109 	stur	w9, [x8, #-4]
    4020427c:	52802029 	mov	w9, #0x101                 	// #257
    40204280:	b9000109 	str	w9, [x8]
    40204284:	d503201f 	nop
    40204288:	1000eb80 	adr	x0, 40205ff8 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x48>
    4020428c:	52800361 	mov	w1, #0x1b                  	// #27
    40204290:	97ffffde 	bl	40204208 <jnox_kernel::uart_write>
    40204294:	97fff6f3 	bl	40201e60 <jnox_kernel::ordinary_reservations::run>

0000000040204298 <jnox_kernel::service_policy::PeriodicReservation::allocation_at>:
    40204298:	f9400809 	ldr	x9, [x0, #16]
    4020429c:	eb09002a 	subs	x10, x1, x9
    402042a0:	54000062 	b.cs	402042ac <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x14>  // b.hs, b.nlast
    402042a4:	aa1f03ea 	mov	x10, xzr
    402042a8:	1400000f 	b	402042e4 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x4c>
    402042ac:	f940040b 	ldr	x11, [x0, #8]
    402042b0:	b400022b 	cbz	x11, 402042f4 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x5c>
    402042b4:	9acb0949 	udiv	x9, x10, x11
    402042b8:	cb0a03ec 	neg	x12, x10
    402042bc:	9b0b3129 	madd	x9, x9, x11, x12
    402042c0:	8b090029 	add	x9, x1, x9
    402042c4:	ab0b0129 	adds	x9, x9, x11
    402042c8:	54000063 	b.cc	402042d4 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x3c>  // b.lo, b.ul, b.last
    402042cc:	aa1f03eb 	mov	x11, xzr
    402042d0:	14000007 	b	402042ec <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x54>
    402042d4:	eb0b015f 	cmp	x10, x11
    402042d8:	5280030a 	mov	w10, #0x18                  	// #24
    402042dc:	9a9f314a 	csel	x10, x10, xzr, cc  // cc = lo, ul, last
    402042e0:	f86a680a 	ldr	x10, [x0, x10]
    402042e4:	5280002b 	mov	w11, #0x1                   	// #1
    402042e8:	a900a50a 	stp	x10, x9, [x8, #8]
    402042ec:	f900010b 	str	x11, [x8]
    402042f0:	d65f03c0 	ret
    402042f4:	f81f0ffe 	str	x30, [sp, #-16]!
    402042f8:	d503201f 	nop
    402042fc:	1000e8e0 	adr	x0, 40206018 <anon.2d5d436b87d2a0d6f444a14986a49844.2.llvm.12776753234347168069>
    40204300:	9400048c 	bl	40205530 <core::panicking::panic_const::panic_const_rem_by_zero>

0000000040204304 <jnox_kernel::service_policy::PeriodicReservation::grant_at>:
    40204304:	f9401008 	ldr	x8, [x0, #32]
    40204308:	eb08003f 	cmp	x1, x8
    4020430c:	54000062 	b.cs	40204318 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x14>  // b.hs, b.nlast
    40204310:	aa1f03e0 	mov	x0, xzr
    40204314:	1400001c 	b	40204384 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x80>
    40204318:	f9400408 	ldr	x8, [x0, #8]
    4020431c:	b4000388 	cbz	x8, 4020438c <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x88>
    40204320:	f9400809 	ldr	x9, [x0, #16]
    40204324:	cb09002a 	sub	x10, x1, x9
    40204328:	9ac80949 	udiv	x9, x10, x8
    4020432c:	9b08a929 	msub	x9, x9, x8, x10
    40204330:	eb08015f 	cmp	x10, x8
    40204334:	54000062 	b.cs	40204340 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x3c>  // b.hs, b.nlast
    40204338:	9100600a 	add	x10, x0, #0x18
    4020433c:	14000004 	b	4020434c <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x48>
    40204340:	cb09002a 	sub	x10, x1, x9
    40204344:	f900080a 	str	x10, [x0, #16]
    40204348:	aa0003ea 	mov	x10, x0
    4020434c:	f940014a 	ldr	x10, [x10]
    40204350:	eb02015f 	cmp	x10, x2
    40204354:	9a82314b 	csel	x11, x10, x2, cc  // cc = lo, ul, last
    40204358:	cb090108 	sub	x8, x8, x9
    4020435c:	eb0b011f 	cmp	x8, x11
    40204360:	9a8b3109 	csel	x9, x8, x11, cc  // cc = lo, ul, last
    40204364:	aa2103e8 	mvn	x8, x1
    40204368:	eb09011f 	cmp	x8, x9
    4020436c:	da812128 	csinv	x8, x9, x1, cs  // cs = hs, nlast
    40204370:	cb08014a 	sub	x10, x10, x8
    40204374:	ab010129 	adds	x9, x9, x1
    40204378:	da9f3129 	csinv	x9, x9, xzr, cc  // cc = lo, ul, last
    4020437c:	a901a40a 	stp	x10, x9, [x0, #24]
    40204380:	52800020 	mov	w0, #0x1                   	// #1
    40204384:	aa0803e1 	mov	x1, x8
    40204388:	d65f03c0 	ret
    4020438c:	f81f0ffe 	str	x30, [sp, #-16]!
    40204390:	d503201f 	nop
    40204394:	1000e4e0 	adr	x0, 40206030 <anon.2d5d436b87d2a0d6f444a14986a49844.3.llvm.12776753234347168069>
    40204398:	94000466 	bl	40205530 <core::panicking::panic_const::panic_const_rem_by_zero>

000000004020439c <jnox_kernel::temporal_policy::HardCbs<_>::new>:
    4020439c:	d10143ff 	sub	sp, sp, #0x50
    402043a0:	a90357fe 	stp	x30, x21, [sp, #48]
    402043a4:	a9044ff4 	stp	x20, x19, [sp, #64]
    402043a8:	aa0103f5 	mov	x21, x1
    402043ac:	aa0003f4 	mov	x20, x0
    402043b0:	aa0803f3 	mov	x19, x8
    402043b4:	aa0103e0 	mov	x0, x1
    402043b8:	52800041 	mov	w1, #0x2                   	// #2
    402043bc:	940000c6 	bl	402046d4 <jnox_kernel::temporal_policy::admit_reservations>
    402043c0:	12001c08 	and	w8, w0, #0xff
    402043c4:	71000d1f 	cmp	w8, #0x3
    402043c8:	54000261 	b.ne	40204414 <jnox_kernel::temporal_policy::HardCbs<_>::new+0x78>  // b.any
    402043cc:	910003e9 	mov	x9, sp
    402043d0:	91006128 	add	x8, x9, #0x18
    402043d4:	5280002a 	mov	w10, #0x1                   	// #1
    402043d8:	f9000134 	str	x20, [x9]
    402043dc:	28c132ab 	ldp	w11, w12, [x21], #8
    402043e0:	2a0a03ed 	mov	w13, w10
    402043e4:	2901312b 	stp	w11, w12, [x9, #8]
    402043e8:	f900093f 	str	xzr, [x9, #16]
    402043ec:	aa0803e9 	mov	x9, x8
    402043f0:	2a1f03ea 	mov	w10, wzr
    402043f4:	3707ff2d 	tbnz	w13, #0, 402043d8 <jnox_kernel::temporal_policy::HardCbs<_>::new+0x3c>
    402043f8:	91002260 	add	x0, x19, #0x8
    402043fc:	910003e1 	mov	x1, sp
    40204400:	52800602 	mov	w2, #0x30                  	// #48
    40204404:	94000595 	bl	40205a58 <memcpy>
    40204408:	f9001e74 	str	x20, [x19, #56]
    4020440c:	52800028 	mov	w8, #0x1                   	// #1
    40204410:	14000002 	b	40204418 <jnox_kernel::temporal_policy::HardCbs<_>::new+0x7c>
    40204414:	aa1f03e8 	mov	x8, xzr
    40204418:	f9000268 	str	x8, [x19]
    4020441c:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40204420:	a94357fe 	ldp	x30, x21, [sp, #48]
    40204424:	910143ff 	add	sp, sp, #0x50
    40204428:	d65f03c0 	ret

000000004020442c <jnox_kernel::temporal_policy::HardCbs<_>::tick>:
    4020442c:	d10203ff 	sub	sp, sp, #0x80
    40204430:	a9027bfd 	stp	x29, x30, [sp, #32]
    40204434:	a9036ffc 	stp	x28, x27, [sp, #48]
    40204438:	a90467fa 	stp	x26, x25, [sp, #64]
    4020443c:	a9055ff8 	stp	x24, x23, [sp, #80]
    40204440:	a90657f6 	stp	x22, x21, [sp, #96]
    40204444:	a9074ff4 	stp	x20, x19, [sp, #112]
    40204448:	aa0803f3 	mov	x19, x8
    4020444c:	f940181b 	ldr	x27, [x0, #48]
    40204450:	b100077a 	adds	x26, x27, #0x1
    40204454:	540000a3 	b.cc	40204468 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x3c>  // b.lo, b.ul, b.last
    40204458:	aa1f03f4 	mov	x20, xzr
    4020445c:	52800037 	mov	w23, #0x1                   	// #1
    40204460:	52800089 	mov	w9, #0x4                   	// #4
    40204464:	1400003e 	b	4020455c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    40204468:	aa0003f5 	mov	x21, x0
    4020446c:	2a1f03fc 	mov	w28, wzr
    40204470:	aa1f03e8 	mov	x8, xzr
    40204474:	aa1f03fd 	mov	x29, xzr
    40204478:	91005018 	add	x24, x0, #0x14
    4020447c:	52800037 	mov	w23, #0x1                   	// #1
    40204480:	910063bd 	add	x29, x29, #0x18
    40204484:	aa0803f6 	mov	x22, x8
    40204488:	8b1d0308 	add	x8, x24, x29
    4020448c:	b85e8108 	ldur	w8, [x8, #-24]
    40204490:	340000e8 	cbz	w8, 402044ac <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x80>
    40204494:	910023e8 	add	x8, sp, #0x8
    40204498:	aa1503e0 	mov	x0, x21
    4020449c:	aa1603e1 	mov	x1, x22
    402044a0:	94000067 	bl	4020463c <jnox_kernel::temporal_policy::HardCbs<_>::available>
    402044a4:	f94007e8 	ldr	x8, [sp, #8]
    402044a8:	b50000c8 	cbnz	x8, 402044c0 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x94>
    402044ac:	910063bd 	add	x29, x29, #0x18
    402044b0:	910006d6 	add	x22, x22, #0x1
    402044b4:	f10123bf 	cmp	x29, #0x48
    402044b8:	54fffe81 	b.ne	40204488 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x5c>  // b.any
    402044bc:	14000014 	b	4020450c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0xe0>
    402044c0:	f100091f 	cmp	x8, #0x2
    402044c4:	a9412be9 	ldp	x9, x10, [sp, #16]
    402044c8:	54000400 	b.eq	40204548 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x11c>  // b.none
    402044cc:	eb1b015f 	cmp	x10, x27
    402044d0:	540005a9 	b.ls	40204584 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x158>  // b.plast
    402044d4:	910006c8 	add	x8, x22, #0x1
    402044d8:	eb19015f 	cmp	x10, x25
    402044dc:	1a9f37eb 	cset	w11, cs  // cs = hs, nlast
    402044e0:	6a0b039f 	tst	w28, w11
    402044e4:	9a961294 	csel	x20, x20, x22, ne  // ne = any
    402044e8:	9a8a1339 	csel	x25, x25, x10, ne  // ne = any
    402044ec:	b94007ea 	ldr	w10, [sp, #4]
    402044f0:	1a89114a 	csel	w10, w10, w9, ne  // ne = any
    402044f4:	b90007ea 	str	w10, [sp, #4]
    402044f8:	5280003c 	mov	w28, #0x1                   	// #1
    402044fc:	f100c3bf 	cmp	x29, #0x30
    40204500:	54fffc01 	b.ne	40204480 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x54>  // b.any
    40204504:	f9001aba 	str	x26, [x21, #48]
    40204508:	14000003 	b	40204514 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0xe8>
    4020450c:	f9001aba 	str	x26, [x21, #48]
    40204510:	3600023c 	tbz	w28, #0, 40204554 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x128>
    40204514:	f1000a9f 	cmp	x20, #0x2
    40204518:	540003c2 	b.cs	40204590 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x164>  // b.hs, b.nlast
    4020451c:	aa1f03f7 	mov	x23, xzr
    40204520:	52800308 	mov	w8, #0x18                  	// #24
    40204524:	9b085688 	madd	x8, x20, x8, x21
    40204528:	f9000119 	str	x25, [x8]
    4020452c:	b94007e9 	ldr	w9, [sp, #4]
    40204530:	51000529 	sub	w9, w9, #0x1
    40204534:	b940150a 	ldr	w10, [x8, #20]
    40204538:	5100054a 	sub	w10, w10, #0x1
    4020453c:	29022909 	stp	w9, w10, [x8, #16]
    40204540:	52800029 	mov	w9, #0x1                   	// #1
    40204544:	14000006 	b	4020455c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    40204548:	52800037 	mov	w23, #0x1                   	// #1
    4020454c:	aa0a03f4 	mov	x20, x10
    40204550:	14000003 	b	4020455c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    40204554:	aa1f03e9 	mov	x9, xzr
    40204558:	aa1f03f7 	mov	x23, xzr
    4020455c:	a900d269 	stp	x9, x20, [x19, #8]
    40204560:	f9000277 	str	x23, [x19]
    40204564:	a9474ff4 	ldp	x20, x19, [sp, #112]
    40204568:	a94657f6 	ldp	x22, x21, [sp, #96]
    4020456c:	a9455ff8 	ldp	x24, x23, [sp, #80]
    40204570:	a94467fa 	ldp	x26, x25, [sp, #64]
    40204574:	a9436ffc 	ldp	x28, x27, [sp, #48]
    40204578:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4020457c:	910203ff 	add	sp, sp, #0x80
    40204580:	d65f03c0 	ret
    40204584:	52800069 	mov	w9, #0x3                   	// #3
    40204588:	aa1603f4 	mov	x20, x22
    4020458c:	17fffff4 	b	4020455c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    40204590:	d503201f 	nop
    40204594:	1000d5a2 	adr	x2, 40206048 <anon.2d5d436b87d2a0d6f444a14986a49844.5.llvm.12776753234347168069>
    40204598:	aa1403e0 	mov	x0, x20
    4020459c:	52800041 	mov	w1, #0x2                   	// #2
    402045a0:	940001de 	bl	40204d18 <core::panicking::panic_bounds_check>

00000000402045a4 <jnox_kernel::temporal_policy::HardCbs<_>::release>:
    402045a4:	f100043f 	cmp	x1, #0x1
    402045a8:	54000089 	b.ls	402045b8 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x14>  // b.plast
    402045ac:	aa1f03e1 	mov	x1, xzr
    402045b0:	aa1f03e0 	mov	x0, xzr
    402045b4:	d65f03c0 	ret
    402045b8:	340000e2 	cbz	w2, 402045d4 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x30>
    402045bc:	52800308 	mov	w8, #0x18                  	// #24
    402045c0:	9b080028 	madd	x8, x1, x8, x0
    402045c4:	b9401509 	ldr	w9, [x8, #20]
    402045c8:	340000a9 	cbz	w9, 402045dc <jnox_kernel::temporal_policy::HardCbs<_>::release+0x38>
    402045cc:	52800040 	mov	w0, #0x2                   	// #2
    402045d0:	d65f03c0 	ret
    402045d4:	52800020 	mov	w0, #0x1                   	// #1
    402045d8:	d65f03c0 	ret
    402045dc:	f940010a 	ldr	x10, [x8]
    402045e0:	f9401809 	ldr	x9, [x0, #48]
    402045e4:	eb09014b 	subs	x11, x10, x9
    402045e8:	54000149 	b.ls	40204610 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x6c>  // b.plast
    402045ec:	2941b10a 	ldp	w10, w12, [x8, #12]
    402045f0:	b940090d 	ldr	w13, [x8, #8]
    402045f4:	9bac7d4c 	umull	x12, w10, w12
    402045f8:	9bcb7dae 	umulh	x14, x13, x11
    402045fc:	9b0b7dab 	mul	x11, x13, x11
    40204600:	eb0c017f 	cmp	x11, x12
    40204604:	fa1f01df 	sbcs	xzr, x14, xzr
    40204608:	54000063 	b.cc	40204614 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x70>  // b.lo, b.ul, b.last
    4020460c:	14000009 	b	40204630 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x8c>
    40204610:	b9400d0a 	ldr	w10, [x8, #12]
    40204614:	ab2a4121 	adds	x1, x9, w10, uxtw
    40204618:	54000063 	b.cc	40204624 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x80>  // b.lo, b.ul, b.last
    4020461c:	52800080 	mov	w0, #0x4                   	// #4
    40204620:	d65f03c0 	ret
    40204624:	f9000101 	str	x1, [x8]
    40204628:	b9400909 	ldr	w9, [x8, #8]
    4020462c:	b9001109 	str	w9, [x8, #16]
    40204630:	b9001502 	str	w2, [x8, #20]
    40204634:	528000a0 	mov	w0, #0x5                   	// #5
    40204638:	d65f03c0 	ret

000000004020463c <jnox_kernel::temporal_policy::HardCbs<_>::available>:
    4020463c:	f100083f 	cmp	x1, #0x2
    40204640:	540000a3 	b.cc	40204654 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x18>  // b.lo, b.ul, b.last
    40204644:	a900fd1f 	stp	xzr, xzr, [x8, #8]
    40204648:	52800049 	mov	w9, #0x2                   	// #2
    4020464c:	f9000109 	str	x9, [x8]
    40204650:	d65f03c0 	ret
    40204654:	52800309 	mov	w9, #0x18                  	// #24
    40204658:	9b090029 	madd	x9, x1, x9, x0
    4020465c:	b940152a 	ldr	w10, [x9, #20]
    40204660:	340001aa 	cbz	w10, 40204694 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x58>
    40204664:	b940112a 	ldr	w10, [x9, #16]
    40204668:	340000ea 	cbz	w10, 40204684 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x48>
    4020466c:	5280002b 	mov	w11, #0x1                   	// #1
    40204670:	f900010b 	str	x11, [x8]
    40204674:	f9400129 	ldr	x9, [x9]
    40204678:	b900090a 	str	w10, [x8, #8]
    4020467c:	f9000909 	str	x9, [x8, #16]
    40204680:	d65f03c0 	ret
    40204684:	f940180b 	ldr	x11, [x0, #48]
    40204688:	f940012a 	ldr	x10, [x9]
    4020468c:	eb0a017f 	cmp	x11, x10
    40204690:	54000062 	b.cs	4020469c <jnox_kernel::temporal_policy::HardCbs<_>::available+0x60>  // b.hs, b.nlast
    40204694:	f900011f 	str	xzr, [x8]
    40204698:	d65f03c0 	ret
    4020469c:	b9400d2b 	ldr	w11, [x9, #12]
    402046a0:	ab0b014a 	adds	x10, x10, x11
    402046a4:	540000c3 	b.cc	402046bc <jnox_kernel::temporal_policy::HardCbs<_>::available+0x80>  // b.lo, b.ul, b.last
    402046a8:	52800089 	mov	w9, #0x4                   	// #4
    402046ac:	a900a909 	stp	x9, x10, [x8, #8]
    402046b0:	5280004a 	mov	w10, #0x2                   	// #2
    402046b4:	f900010a 	str	x10, [x8]
    402046b8:	d65f03c0 	ret
    402046bc:	5280002b 	mov	w11, #0x1                   	// #1
    402046c0:	f900010b 	str	x11, [x8]
    402046c4:	b9400929 	ldr	w9, [x9, #8]
    402046c8:	b9000909 	str	w9, [x8, #8]
    402046cc:	f900090a 	str	x10, [x8, #16]
    402046d0:	d65f03c0 	ret

00000000402046d4 <jnox_kernel::temporal_policy::admit_reservations>:
    402046d4:	f81b0ffe 	str	x30, [sp, #-80]!
    402046d8:	a90167fa 	stp	x26, x25, [sp, #16]
    402046dc:	a9025ff8 	stp	x24, x23, [sp, #32]
    402046e0:	a90357f6 	stp	x22, x21, [sp, #48]
    402046e4:	a9044ff4 	stp	x20, x19, [sp, #64]
    402046e8:	b4000721 	cbz	x1, 402047cc <jnox_kernel::temporal_policy::admit_reservations+0xf8>
    402046ec:	aa0003f3 	mov	x19, x0
    402046f0:	aa1f03f6 	mov	x22, xzr
    402046f4:	8b010c1a 	add	x26, x0, x1, lsl #3
    402046f8:	52800020 	mov	w0, #0x1                   	// #1
    402046fc:	29402269 	ldp	w9, w8, [x19]
    40204700:	5100052a 	sub	w10, w9, #0x1
    40204704:	6b08015f 	cmp	w10, w8
    40204708:	540006a2 	b.cs	402047dc <jnox_kernel::temporal_policy::admit_reservations+0x108>  // b.hs, b.nlast
    4020470c:	9bd67d0a 	umulh	x10, x8, x22
    40204710:	9b167d0b 	mul	x11, x8, x22
    40204714:	9bc07d2c 	umulh	x12, x9, x0
    40204718:	9b007d29 	mul	x9, x9, x0
    4020471c:	ab090176 	adds	x22, x11, x9
    40204720:	9a0c0157 	adc	x23, x10, x12
    40204724:	9bc07d14 	umulh	x20, x8, x0
    40204728:	9b007d15 	mul	x21, x8, x0
    4020472c:	eb1602bf 	cmp	x21, x22
    40204730:	fa17029f 	sbcs	xzr, x20, x23
    40204734:	54000583 	b.cc	402047e4 <jnox_kernel::temporal_policy::admit_reservations+0x110>  // b.lo, b.ul, b.last
    40204738:	b4000220 	cbz	x0, 4020477c <jnox_kernel::temporal_policy::admit_reservations+0xa8>
    4020473c:	aa1603e0 	mov	x0, x22
    40204740:	aa1703e1 	mov	x1, x23
    40204744:	aa1503e8 	mov	x8, x21
    40204748:	aa1403e9 	mov	x9, x20
    4020474c:	aa0903f8 	mov	x24, x9
    40204750:	aa0803f9 	mov	x25, x8
    40204754:	aa0803e2 	mov	x2, x8
    40204758:	aa0903e3 	mov	x3, x9
    4020475c:	94000542 	bl	40205c64 <__umodti3>
    40204760:	aa0003e8 	mov	x8, x0
    40204764:	aa0103e9 	mov	x9, x1
    40204768:	aa01000a 	orr	x10, x0, x1
    4020476c:	aa1903e0 	mov	x0, x25
    40204770:	aa1803e1 	mov	x1, x24
    40204774:	b5fffeca 	cbnz	x10, 4020474c <jnox_kernel::temporal_policy::admit_reservations+0x78>
    40204778:	14000005 	b	4020478c <jnox_kernel::temporal_policy::admit_reservations+0xb8>
    4020477c:	aa1702c8 	orr	x8, x22, x23
    40204780:	aa1603f9 	mov	x25, x22
    40204784:	aa1703f8 	mov	x24, x23
    40204788:	b40003c8 	cbz	x8, 40204800 <jnox_kernel::temporal_policy::admit_reservations+0x12c>
    4020478c:	aa1603e0 	mov	x0, x22
    40204790:	aa1703e1 	mov	x1, x23
    40204794:	aa1903e2 	mov	x2, x25
    40204798:	aa1803e3 	mov	x3, x24
    4020479c:	940003e3 	bl	40205728 <__udivti3>
    402047a0:	b50001a1 	cbnz	x1, 402047d4 <jnox_kernel::temporal_policy::admit_reservations+0x100>
    402047a4:	aa0003f6 	mov	x22, x0
    402047a8:	aa1503e0 	mov	x0, x21
    402047ac:	aa1403e1 	mov	x1, x20
    402047b0:	aa1903e2 	mov	x2, x25
    402047b4:	aa1803e3 	mov	x3, x24
    402047b8:	940003dc 	bl	40205728 <__udivti3>
    402047bc:	b50000c1 	cbnz	x1, 402047d4 <jnox_kernel::temporal_policy::admit_reservations+0x100>
    402047c0:	91002273 	add	x19, x19, #0x8
    402047c4:	eb1a027f 	cmp	x19, x26
    402047c8:	54fff9a1 	b.ne	402046fc <jnox_kernel::temporal_policy::admit_reservations+0x28>  // b.any
    402047cc:	52800060 	mov	w0, #0x3                   	// #3
    402047d0:	14000006 	b	402047e8 <jnox_kernel::temporal_policy::admit_reservations+0x114>
    402047d4:	52800040 	mov	w0, #0x2                   	// #2
    402047d8:	14000004 	b	402047e8 <jnox_kernel::temporal_policy::admit_reservations+0x114>
    402047dc:	2a1f03e0 	mov	w0, wzr
    402047e0:	14000002 	b	402047e8 <jnox_kernel::temporal_policy::admit_reservations+0x114>
    402047e4:	52800020 	mov	w0, #0x1                   	// #1
    402047e8:	a9444ff4 	ldp	x20, x19, [sp, #64]
    402047ec:	a94357f6 	ldp	x22, x21, [sp, #48]
    402047f0:	a9425ff8 	ldp	x24, x23, [sp, #32]
    402047f4:	a94167fa 	ldp	x26, x25, [sp, #16]
    402047f8:	f84507fe 	ldr	x30, [sp], #80
    402047fc:	d65f03c0 	ret
    40204800:	d503201f 	nop
    40204804:	1000c2e0 	adr	x0, 40206060 <anon.2d5d436b87d2a0d6f444a14986a49844.6.llvm.12776753234347168069>
    40204808:	94000343 	bl	40205514 <core::panicking::panic_const::panic_const_div_by_zero>

000000004020480c <jnox_kernel::context::init_timer_irq>:
    4020480c:	d503201f 	nop
    40204810:	10fdff88 	adr	x8, 40200800 <sched_vectors>
    40204814:	d518c008 	msr	vbar_el1, x8
    40204818:	d51be23f 	msr	cntp_ctl_el0, xzr
    4020481c:	d5033fdf 	isb
    40204820:	52a10008 	mov	w8, #0x8000000             	// #134217728
    40204824:	b900011f 	str	wzr, [x8]
    40204828:	52a10029 	mov	w9, #0x8010000             	// #134283264
    4020482c:	b900013f 	str	wzr, [x9]
    40204830:	5280100a 	mov	w10, #0x80                  	// #128
    40204834:	72a1000a 	movk	w10, #0x800, lsl #16
    40204838:	b940014b 	ldr	w11, [x10]
    4020483c:	1201796b 	and	w11, w11, #0xbfffffff
    40204840:	b900014b 	str	w11, [x10]
    40204844:	5280100b 	mov	w11, #0x80                  	// #128
    40204848:	390e794b 	strb	w11, [x10, #926]
    4020484c:	52a8000b 	mov	w11, #0x40000000            	// #1073741824
    40204850:	b902014b 	str	w11, [x10, #512]
    40204854:	b900814b 	str	w11, [x10, #128]
    40204858:	5280008a 	mov	w10, #0x4                   	// #4
    4020485c:	72a1002a 	movk	w10, #0x801, lsl #16
    40204860:	52801feb 	mov	w11, #0xff                  	// #255
    40204864:	b900014b 	str	w11, [x10]
    40204868:	5280002a 	mov	w10, #0x1                   	// #1
    4020486c:	b900010a 	str	w10, [x8]
    40204870:	b900012a 	str	w10, [x9]
    40204874:	d5033f9f 	dsb	sy
    40204878:	d5033fdf 	isb
    4020487c:	d65f03c0 	ret

0000000040204880 <<core::fmt::Formatter>::pad_integral>:
    40204880:	d101c3ff 	sub	sp, sp, #0x70
    40204884:	a9017bfd 	stp	x29, x30, [sp, #16]
    40204888:	a9026ffc 	stp	x28, x27, [sp, #32]
    4020488c:	a90367fa 	stp	x26, x25, [sp, #48]
    40204890:	a9045ff8 	stp	x24, x23, [sp, #64]
    40204894:	a90557f6 	stp	x22, x21, [sp, #80]
    40204898:	a9064ff4 	stp	x20, x19, [sp, #96]
    4020489c:	910043fd 	add	x29, sp, #0x10
    402048a0:	b940101a 	ldr	w26, [x0, #16]
    402048a4:	52a00229 	mov	w9, #0x110000              	// #1114112
    402048a8:	aa0503f3 	mov	x19, x5
    402048ac:	aa0403fc 	mov	x28, x4
    402048b0:	aa0303f6 	mov	x22, x3
    402048b4:	aa0003f5 	mov	x21, x0
    402048b8:	926b0348 	and	x8, x26, #0x200000
    402048bc:	d355574a 	ubfx	x10, x26, #21, #1
    402048c0:	7100011f 	cmp	w8, #0x0
    402048c4:	52800568 	mov	w8, #0x2b                  	// #43
    402048c8:	1a880128 	csel	w8, w9, w8, eq  // eq = none
    402048cc:	7100003f 	cmp	w1, #0x0
    402048d0:	528005a9 	mov	w9, #0x2d                  	// #45
    402048d4:	9a9f154a 	csinc	x10, x10, xzr, ne  // ne = any
    402048d8:	1a891118 	csel	w24, w8, w9, ne  // ne = any
    402048dc:	8b05015b 	add	x27, x10, x5
    402048e0:	37b8033a 	tbnz	w26, #23, 40204944 <<core::fmt::Formatter>::pad_integral+0xc4>
    402048e4:	aa1f03f7 	mov	x23, xzr
    402048e8:	79402ab4 	ldrh	w20, [x21, #20]
    402048ec:	eb14037f 	cmp	x27, x20
    402048f0:	54001503 	b.cc	40204b90 <<core::fmt::Formatter>::pad_integral+0x310>  // b.lo, b.ul, b.last
    402048f4:	a94056b9 	ldp	x25, x21, [x21]
    402048f8:	2a1803e2 	mov	w2, w24
    402048fc:	aa1703e3 	mov	x3, x23
    40204900:	aa1603e4 	mov	x4, x22
    40204904:	aa1903e0 	mov	x0, x25
    40204908:	aa1503e1 	mov	x1, x21
    4020490c:	94000310 	bl	4020554c <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204910:	37001d60 	tbnz	w0, #0, 40204cbc <<core::fmt::Formatter>::pad_integral+0x43c>
    40204914:	f9400ea3 	ldr	x3, [x21, #24]
    40204918:	aa1903e0 	mov	x0, x25
    4020491c:	aa1c03e1 	mov	x1, x28
    40204920:	aa1303e2 	mov	x2, x19
    40204924:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40204928:	a94557f6 	ldp	x22, x21, [sp, #80]
    4020492c:	a9445ff8 	ldp	x24, x23, [sp, #64]
    40204930:	a94367fa 	ldp	x26, x25, [sp, #48]
    40204934:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40204938:	a9417bfd 	ldp	x29, x30, [sp, #16]
    4020493c:	9101c3ff 	add	sp, sp, #0x70
    40204940:	d61f0060 	br	x3
    40204944:	aa0203f7 	mov	x23, x2
    40204948:	f10082df 	cmp	x22, #0x20
    4020494c:	540000e2 	b.cs	40204968 <<core::fmt::Formatter>::pad_integral+0xe8>  // b.hs, b.nlast
    40204950:	b4000156 	cbz	x22, 40204978 <<core::fmt::Formatter>::pad_integral+0xf8>
    40204954:	f10022df 	cmp	x22, #0x8
    40204958:	54000142 	b.cs	40204980 <<core::fmt::Formatter>::pad_integral+0x100>  // b.hs, b.nlast
    4020495c:	aa1f03e8 	mov	x8, xzr
    40204960:	aa1f03e0 	mov	x0, xzr
    40204964:	14000080 	b	40204b64 <<core::fmt::Formatter>::pad_integral+0x2e4>
    40204968:	aa1703e0 	mov	x0, x23
    4020496c:	aa1603e1 	mov	x1, x22
    40204970:	94000102 	bl	40204d78 <core::str::count::do_count_chars>
    40204974:	14000083 	b	40204b80 <<core::fmt::Formatter>::pad_integral+0x300>
    40204978:	aa1f03e0 	mov	x0, xzr
    4020497c:	14000081 	b	40204b80 <<core::fmt::Formatter>::pad_integral+0x300>
    40204980:	aa1703ea 	mov	x10, x23
    40204984:	39400ae9 	ldrb	w9, [x23, #2]
    40204988:	394006e8 	ldrb	w8, [x23, #1]
    4020498c:	38404d4b 	ldrb	w11, [x10, #4]!
    40204990:	3940094c 	ldrb	w12, [x10, #2]
    40204994:	394002ed 	ldrb	w13, [x23]
    40204998:	39400eee 	ldrb	w14, [x23, #3]
    4020499c:	d370bd29 	lsl	x9, x9, #16
    402049a0:	394016ef 	ldrb	w15, [x23, #5]
    402049a4:	39400d4a 	ldrb	w10, [x10, #3]
    402049a8:	53103d8c 	lsl	w12, w12, #16
    402049ac:	aa0821a8 	orr	x8, x13, x8, lsl #8
    402049b0:	aa0e6129 	orr	x9, x9, x14, lsl #24
    402049b4:	0f05e7e4 	movi	v4.8b, #0xbf
    402049b8:	2a0f216b 	orr	w11, w11, w15, lsl #8
    402049bc:	2a0a618a 	orr	w10, w12, w10, lsl #24
    402049c0:	aa080128 	orr	x8, x9, x8
    402049c4:	2a0b0149 	orr	w9, w10, w11
    402049c8:	aa098108 	orr	x8, x8, x9, lsl #32
    402049cc:	9e670100 	fmov	d0, x8
    402049d0:	52800028 	mov	w8, #0x1                   	// #1
    402049d4:	4e080d03 	dup	v3.2d, x8
    402049d8:	927d06c8 	and	x8, x22, #0x18
    402049dc:	f100211f 	cmp	x8, #0x8
    402049e0:	0e243400 	cmgt	v0.8b, v0.8b, v4.8b
    402049e4:	2f08a400 	uxtl	v0.8h, v0.8b
    402049e8:	6f10a401 	uxtl2	v1.4s, v0.8h
    402049ec:	2f10a400 	uxtl	v0.4s, v0.4h
    402049f0:	6f20a422 	uxtl2	v2.2d, v1.4s
    402049f4:	2f20a421 	uxtl	v1.2d, v1.2s
    402049f8:	6f20a405 	uxtl2	v5.2d, v0.4s
    402049fc:	2f20a406 	uxtl	v6.2d, v0.2s
    40204a00:	4e231c40 	and	v0.16b, v2.16b, v3.16b
    40204a04:	4e231c22 	and	v2.16b, v1.16b, v3.16b
    40204a08:	4e231ca1 	and	v1.16b, v5.16b, v3.16b
    40204a0c:	4e231cc3 	and	v3.16b, v6.16b, v3.16b
    40204a10:	540009c0 	b.eq	40204b48 <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    40204a14:	aa1703e9 	mov	x9, x23
    40204a18:	f100411f 	cmp	x8, #0x10
    40204a1c:	38408d2a 	ldrb	w10, [x9, #8]!
    40204a20:	3940052b 	ldrb	w11, [x9, #1]
    40204a24:	39400d2c 	ldrb	w12, [x9, #3]
    40204a28:	3940092d 	ldrb	w13, [x9, #2]
    40204a2c:	3940152e 	ldrb	w14, [x9, #5]
    40204a30:	38404d2f 	ldrb	w15, [x9, #4]!
    40204a34:	39400930 	ldrb	w16, [x9, #2]
    40204a38:	39400d29 	ldrb	w9, [x9, #3]
    40204a3c:	d370bdad 	lsl	x13, x13, #16
    40204a40:	aa0b214a 	orr	x10, x10, x11, lsl #8
    40204a44:	53103e10 	lsl	w16, w16, #16
    40204a48:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40204a4c:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40204a50:	2a096209 	orr	w9, w16, w9, lsl #24
    40204a54:	aa0a018a 	orr	x10, x12, x10
    40204a58:	2a0b0129 	orr	w9, w9, w11
    40204a5c:	aa098149 	orr	x9, x10, x9, lsl #32
    40204a60:	9e670125 	fmov	d5, x9
    40204a64:	52800029 	mov	w9, #0x1                   	// #1
    40204a68:	4e080d26 	dup	v6.2d, x9
    40204a6c:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40204a70:	2f08a484 	uxtl	v4.8h, v4.8b
    40204a74:	6f10a485 	uxtl2	v5.4s, v4.8h
    40204a78:	2f10a484 	uxtl	v4.4s, v4.4h
    40204a7c:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40204a80:	2f20a490 	uxtl	v16.2d, v4.2s
    40204a84:	6f20a484 	uxtl2	v4.2d, v4.4s
    40204a88:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40204a8c:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40204a90:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40204a94:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40204a98:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40204a9c:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40204aa0:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40204aa4:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40204aa8:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40204aac:	540004e0 	b.eq	40204b48 <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    40204ab0:	aa1703e9 	mov	x9, x23
    40204ab4:	0f05e7e4 	movi	v4.8b, #0xbf
    40204ab8:	38410d2a 	ldrb	w10, [x9, #16]!
    40204abc:	3940052b 	ldrb	w11, [x9, #1]
    40204ac0:	39400d2c 	ldrb	w12, [x9, #3]
    40204ac4:	3940092d 	ldrb	w13, [x9, #2]
    40204ac8:	3940152e 	ldrb	w14, [x9, #5]
    40204acc:	38404d2f 	ldrb	w15, [x9, #4]!
    40204ad0:	39400930 	ldrb	w16, [x9, #2]
    40204ad4:	39400d29 	ldrb	w9, [x9, #3]
    40204ad8:	d370bdad 	lsl	x13, x13, #16
    40204adc:	aa0b214a 	orr	x10, x10, x11, lsl #8
    40204ae0:	53103e10 	lsl	w16, w16, #16
    40204ae4:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40204ae8:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40204aec:	2a096209 	orr	w9, w16, w9, lsl #24
    40204af0:	aa0a018a 	orr	x10, x12, x10
    40204af4:	2a0b0129 	orr	w9, w9, w11
    40204af8:	aa098149 	orr	x9, x10, x9, lsl #32
    40204afc:	9e670125 	fmov	d5, x9
    40204b00:	52800029 	mov	w9, #0x1                   	// #1
    40204b04:	4e080d26 	dup	v6.2d, x9
    40204b08:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40204b0c:	2f08a484 	uxtl	v4.8h, v4.8b
    40204b10:	6f10a485 	uxtl2	v5.4s, v4.8h
    40204b14:	2f10a484 	uxtl	v4.4s, v4.4h
    40204b18:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40204b1c:	2f20a490 	uxtl	v16.2d, v4.2s
    40204b20:	6f20a484 	uxtl2	v4.2d, v4.4s
    40204b24:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40204b28:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40204b2c:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40204b30:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40204b34:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40204b38:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40204b3c:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40204b40:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40204b44:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40204b48:	4ee28462 	add	v2.2d, v3.2d, v2.2d
    40204b4c:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    40204b50:	eb0802df 	cmp	x22, x8
    40204b54:	4ee08440 	add	v0.2d, v2.2d, v0.2d
    40204b58:	5ef1b800 	addp	d0, v0.2d
    40204b5c:	9e660000 	fmov	x0, d0
    40204b60:	54000100 	b.eq	40204b80 <<core::fmt::Formatter>::pad_integral+0x300>  // b.none
    40204b64:	cb0802c9 	sub	x9, x22, x8
    40204b68:	8b0802e8 	add	x8, x23, x8
    40204b6c:	38c0150a 	ldrsb	w10, [x8], #1
    40204b70:	3101055f 	cmn	w10, #0x41
    40204b74:	9a80d400 	cinc	x0, x0, gt
    40204b78:	f1000529 	subs	x9, x9, #0x1
    40204b7c:	54ffff81 	b.ne	40204b6c <<core::fmt::Formatter>::pad_integral+0x2ec>  // b.any
    40204b80:	8b1b001b 	add	x27, x0, x27
    40204b84:	79402ab4 	ldrh	w20, [x21, #20]
    40204b88:	eb14037f 	cmp	x27, x20
    40204b8c:	54ffeb42 	b.cs	402048f4 <<core::fmt::Formatter>::pad_integral+0x74>  // b.hs, b.nlast
    40204b90:	f90007fc 	str	x28, [sp, #8]
    40204b94:	37c0011a 	tbnz	w26, #24, 40204bb4 <<core::fmt::Formatter>::pad_integral+0x334>
    40204b98:	531d7b48 	ubfx	w8, w26, #29, #2
    40204b9c:	4b1b029b 	sub	w27, w20, w27
    40204ba0:	7100051f 	cmp	w8, #0x1
    40204ba4:	540003cc 	b.gt	40204c1c <<core::fmt::Formatter>::pad_integral+0x39c>
    40204ba8:	35000568 	cbnz	w8, 40204c54 <<core::fmt::Formatter>::pad_integral+0x3d4>
    40204bac:	2a1f03fc 	mov	w28, wzr
    40204bb0:	1400002a 	b	40204c58 <<core::fmt::Formatter>::pad_integral+0x3d8>
    40204bb4:	a940f2ba 	ldp	x26, x28, [x21, #8]
    40204bb8:	52b3fc08 	mov	w8, #0x9fe00000            	// #-1612709888
    40204bbc:	f94002b9 	ldr	x25, [x21]
    40204bc0:	2a1803e2 	mov	w2, w24
    40204bc4:	aa1703e3 	mov	x3, x23
    40204bc8:	aa1603e4 	mov	x4, x22
    40204bcc:	0a080388 	and	w8, w28, w8
    40204bd0:	aa1903e0 	mov	x0, x25
    40204bd4:	aa1a03e1 	mov	x1, x26
    40204bd8:	321c0508 	orr	w8, w8, #0x30
    40204bdc:	32030108 	orr	w8, w8, #0x20000000
    40204be0:	b90012a8 	str	w8, [x21, #16]
    40204be4:	9400025a 	bl	4020554c <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204be8:	370006a0 	tbnz	w0, #0, 40204cbc <<core::fmt::Formatter>::pad_integral+0x43c>
    40204bec:	2a1f03f6 	mov	w22, wzr
    40204bf0:	4b1b0294 	sub	w20, w20, w27
    40204bf4:	12003ec8 	and	w8, w22, #0xffff
    40204bf8:	6b34211f 	cmp	w8, w20, uxth
    40204bfc:	540001a2 	b.cs	40204c30 <<core::fmt::Formatter>::pad_integral+0x3b0>  // b.hs, b.nlast
    40204c00:	f9401348 	ldr	x8, [x26, #32]
    40204c04:	aa1903e0 	mov	x0, x25
    40204c08:	52800601 	mov	w1, #0x30                  	// #48
    40204c0c:	110006d6 	add	w22, w22, #0x1
    40204c10:	d63f0100 	blr	x8
    40204c14:	3607ff00 	tbz	w0, #0, 40204bf4 <<core::fmt::Formatter>::pad_integral+0x374>
    40204c18:	14000029 	b	40204cbc <<core::fmt::Formatter>::pad_integral+0x43c>
    40204c1c:	7100091f 	cmp	w8, #0x2
    40204c20:	2a1b03fc 	mov	w28, w27
    40204c24:	540001a1 	b.ne	40204c58 <<core::fmt::Formatter>::pad_integral+0x3d8>  // b.any
    40204c28:	53013f7c 	ubfx	w28, w27, #1, #15
    40204c2c:	1400000b 	b	40204c58 <<core::fmt::Formatter>::pad_integral+0x3d8>
    40204c30:	f9400f48 	ldr	x8, [x26, #24]
    40204c34:	f94007e1 	ldr	x1, [sp, #8]
    40204c38:	aa1903e0 	mov	x0, x25
    40204c3c:	aa1303e2 	mov	x2, x19
    40204c40:	d63f0100 	blr	x8
    40204c44:	370003c0 	tbnz	w0, #0, 40204cbc <<core::fmt::Formatter>::pad_integral+0x43c>
    40204c48:	2a1f03f3 	mov	w19, wzr
    40204c4c:	f9000abc 	str	x28, [x21, #16]
    40204c50:	1400001c 	b	40204cc0 <<core::fmt::Formatter>::pad_integral+0x440>
    40204c54:	2a1b03fc 	mov	w28, w27
    40204c58:	a94056b9 	ldp	x25, x21, [x21]
    40204c5c:	2a1f03f4 	mov	w20, wzr
    40204c60:	12003e88 	and	w8, w20, #0xffff
    40204c64:	6b3c211f 	cmp	w8, w28, uxth
    40204c68:	54000102 	b.cs	40204c88 <<core::fmt::Formatter>::pad_integral+0x408>  // b.hs, b.nlast
    40204c6c:	f94012a8 	ldr	x8, [x21, #32]
    40204c70:	12005341 	and	w1, w26, #0x1fffff
    40204c74:	aa1903e0 	mov	x0, x25
    40204c78:	11000694 	add	w20, w20, #0x1
    40204c7c:	d63f0100 	blr	x8
    40204c80:	3607ff00 	tbz	w0, #0, 40204c60 <<core::fmt::Formatter>::pad_integral+0x3e0>
    40204c84:	1400000e 	b	40204cbc <<core::fmt::Formatter>::pad_integral+0x43c>
    40204c88:	aa1903e0 	mov	x0, x25
    40204c8c:	aa1503e1 	mov	x1, x21
    40204c90:	2a1803e2 	mov	w2, w24
    40204c94:	aa1703e3 	mov	x3, x23
    40204c98:	aa1603e4 	mov	x4, x22
    40204c9c:	9400022c 	bl	4020554c <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204ca0:	370000e0 	tbnz	w0, #0, 40204cbc <<core::fmt::Formatter>::pad_integral+0x43c>
    40204ca4:	f9400ea8 	ldr	x8, [x21, #24]
    40204ca8:	f94007e1 	ldr	x1, [sp, #8]
    40204cac:	aa1903e0 	mov	x0, x25
    40204cb0:	aa1303e2 	mov	x2, x19
    40204cb4:	d63f0100 	blr	x8
    40204cb8:	36000160 	tbz	w0, #0, 40204ce4 <<core::fmt::Formatter>::pad_integral+0x464>
    40204cbc:	52800033 	mov	w19, #0x1                   	// #1
    40204cc0:	2a1303e0 	mov	w0, w19
    40204cc4:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40204cc8:	a94557f6 	ldp	x22, x21, [sp, #80]
    40204ccc:	a9445ff8 	ldp	x24, x23, [sp, #64]
    40204cd0:	a94367fa 	ldp	x26, x25, [sp, #48]
    40204cd4:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40204cd8:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40204cdc:	9101c3ff 	add	sp, sp, #0x70
    40204ce0:	d65f03c0 	ret
    40204ce4:	2a1f03f4 	mov	w20, wzr
    40204ce8:	4b1c0376 	sub	w22, w27, w28
    40204cec:	12003e88 	and	w8, w20, #0xffff
    40204cf0:	6b36211f 	cmp	w8, w22, uxth
    40204cf4:	1a9f27f3 	cset	w19, cc  // cc = lo, ul, last
    40204cf8:	54fffe42 	b.cs	40204cc0 <<core::fmt::Formatter>::pad_integral+0x440>  // b.hs, b.nlast
    40204cfc:	f94012a8 	ldr	x8, [x21, #32]
    40204d00:	12005341 	and	w1, w26, #0x1fffff
    40204d04:	aa1903e0 	mov	x0, x25
    40204d08:	11000694 	add	w20, w20, #0x1
    40204d0c:	d63f0100 	blr	x8
    40204d10:	3607fee0 	tbz	w0, #0, 40204cec <<core::fmt::Formatter>::pad_integral+0x46c>
    40204d14:	17ffffeb 	b	40204cc0 <<core::fmt::Formatter>::pad_integral+0x440>

0000000040204d18 <core::panicking::panic_bounds_check>:
    40204d18:	d10103ff 	sub	sp, sp, #0x40
    40204d1c:	a9037bfd 	stp	x29, x30, [sp, #48]
    40204d20:	9100c3fd 	add	x29, sp, #0x30
    40204d24:	910023e8 	add	x8, sp, #0x8
    40204d28:	d503201f 	nop
    40204d2c:	10004549 	adr	x9, 402055d4 <<u64 as core::fmt::Display>::fmt>
    40204d30:	a90007e0 	stp	x0, x1, [sp]
    40204d34:	b0000000 	adrp	x0, 40205000 <core::str::count::do_count_chars+0x288>
    40204d38:	91383400 	add	x0, x0, #0xe0d
    40204d3c:	a90127e8 	stp	x8, x9, [sp, #16]
    40204d40:	910003e8 	mov	x8, sp
    40204d44:	910043e1 	add	x1, sp, #0x10
    40204d48:	a90227e8 	stp	x8, x9, [sp, #32]
    40204d4c:	94000001 	bl	40204d50 <core::panicking::panic_fmt>

0000000040204d50 <core::panicking::panic_fmt>:
    40204d50:	d10103ff 	sub	sp, sp, #0x40
    40204d54:	a9037bfd 	stp	x29, x30, [sp, #48]
    40204d58:	9100c3fd 	add	x29, sp, #0x30
    40204d5c:	910023e8 	add	x8, sp, #0x8
    40204d60:	a90087e0 	stp	x0, x1, [sp, #8]
    40204d64:	910063e0 	add	x0, sp, #0x18
    40204d68:	a9018be8 	stp	x8, x2, [sp, #24]
    40204d6c:	52800028 	mov	w8, #0x1                   	// #1
    40204d70:	790053e8 	strh	w8, [sp, #40]
    40204d74:	97fffc92 	bl	40203fbc <__rustc::rust_begin_unwind>

0000000040204d78 <core::str::count::do_count_chars>:
    40204d78:	d10183ff 	sub	sp, sp, #0x60
    40204d7c:	fd0023ea 	str	d10, [sp, #64]
    40204d80:	6d0523e9 	stp	d9, d8, [sp, #80]
    40204d84:	91001c08 	add	x8, x0, #0x7
    40204d88:	927df10d 	and	x13, x8, #0xfffffffffffffff8
    40204d8c:	cb0001ac 	sub	x12, x13, x0
    40204d90:	eb0c002b 	subs	x11, x1, x12
    40204d94:	540000e2 	b.cs	40204db0 <core::str::count::do_count_chars+0x38>  // b.hs, b.nlast
    40204d98:	b4000721 	cbz	x1, 40204e7c <core::str::count::do_count_chars+0x104>
    40204d9c:	f100203f 	cmp	x1, #0x8
    40204da0:	54001b82 	b.cs	40205110 <core::str::count::do_count_chars+0x398>  // b.hs, b.nlast
    40204da4:	aa1f03e9 	mov	x9, xzr
    40204da8:	aa1f03e8 	mov	x8, xzr
    40204dac:	140001d2 	b	402054f4 <core::str::count::do_count_chars+0x77c>
    40204db0:	d343fd69 	lsr	x9, x11, #3
    40204db4:	b4ffff29 	cbz	x9, 40204d98 <core::str::count::do_count_chars+0x20>
    40204db8:	eb0001bf 	cmp	x13, x0
    40204dbc:	9240096a 	and	x10, x11, #0x7
    40204dc0:	aa1f03e8 	mov	x8, xzr
    40204dc4:	54000100 	b.eq	40204de4 <core::str::count::do_count_chars+0x6c>  // b.none
    40204dc8:	cb0d000d 	sub	x13, x0, x13
    40204dcc:	aa0003ee 	mov	x14, x0
    40204dd0:	38c015cf 	ldrsb	w15, [x14], #1
    40204dd4:	310105ff 	cmn	w15, #0x41
    40204dd8:	9a88d508 	cinc	x8, x8, gt
    40204ddc:	b10005ad 	adds	x13, x13, #0x1
    40204de0:	54ffff83 	b.cc	40204dd0 <core::str::count::do_count_chars+0x58>  // b.lo, b.ul, b.last
    40204de4:	8b0c000e 	add	x14, x0, x12
    40204de8:	b400056a 	cbz	x10, 40204e94 <core::str::count::do_count_chars+0x11c>
    40204dec:	927ded6b 	and	x11, x11, #0x7ffffffffffffff8
    40204df0:	8b0b01cc 	add	x12, x14, x11
    40204df4:	39c0018b 	ldrsb	w11, [x12]
    40204df8:	3101057f 	cmn	w11, #0x41
    40204dfc:	1a9fd7eb 	cset	w11, gt
    40204e00:	f100055f 	cmp	x10, #0x1
    40204e04:	540004a0 	b.eq	40204e98 <core::str::count::do_count_chars+0x120>  // b.none
    40204e08:	39c0058d 	ldrsb	w13, [x12, #1]
    40204e0c:	310105bf 	cmn	w13, #0x41
    40204e10:	9a8bd56b 	cinc	x11, x11, gt
    40204e14:	f100095f 	cmp	x10, #0x2
    40204e18:	54000400 	b.eq	40204e98 <core::str::count::do_count_chars+0x120>  // b.none
    40204e1c:	39c0098d 	ldrsb	w13, [x12, #2]
    40204e20:	310105bf 	cmn	w13, #0x41
    40204e24:	9a8bd56b 	cinc	x11, x11, gt
    40204e28:	f1000d5f 	cmp	x10, #0x3
    40204e2c:	54000360 	b.eq	40204e98 <core::str::count::do_count_chars+0x120>  // b.none
    40204e30:	39c00d8d 	ldrsb	w13, [x12, #3]
    40204e34:	310105bf 	cmn	w13, #0x41
    40204e38:	9a8bd56b 	cinc	x11, x11, gt
    40204e3c:	f100115f 	cmp	x10, #0x4
    40204e40:	540002c0 	b.eq	40204e98 <core::str::count::do_count_chars+0x120>  // b.none
    40204e44:	39c0118d 	ldrsb	w13, [x12, #4]
    40204e48:	310105bf 	cmn	w13, #0x41
    40204e4c:	9a8bd56b 	cinc	x11, x11, gt
    40204e50:	f100155f 	cmp	x10, #0x5
    40204e54:	54000220 	b.eq	40204e98 <core::str::count::do_count_chars+0x120>  // b.none
    40204e58:	39c0158d 	ldrsb	w13, [x12, #5]
    40204e5c:	310105bf 	cmn	w13, #0x41
    40204e60:	9a8bd56b 	cinc	x11, x11, gt
    40204e64:	f100195f 	cmp	x10, #0x6
    40204e68:	54000180 	b.eq	40204e98 <core::str::count::do_count_chars+0x120>  // b.none
    40204e6c:	39c0198a 	ldrsb	w10, [x12, #6]
    40204e70:	3101055f 	cmn	w10, #0x41
    40204e74:	9a8bd56b 	cinc	x11, x11, gt
    40204e78:	14000008 	b	40204e98 <core::str::count::do_count_chars+0x120>
    40204e7c:	aa1f03e8 	mov	x8, xzr
    40204e80:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40204e84:	aa0803e0 	mov	x0, x8
    40204e88:	fd4023ea 	ldr	d10, [sp, #64]
    40204e8c:	910183ff 	add	sp, sp, #0x60
    40204e90:	d65f03c0 	ret
    40204e94:	aa1f03eb 	mov	x11, xzr
    40204e98:	4f00e420 	movi	v0.16b, #0x1
    40204e9c:	8b080168 	add	x8, x11, x8
    40204ea0:	5280180a 	mov	w10, #0xc0                  	// #192
    40204ea4:	b20083eb 	mov	x11, #0x1000100010001       	// #281479271743489
    40204ea8:	1400000c 	b	40204ed8 <core::str::count::do_count_chars+0x160>
    40204eac:	aa1f03f1 	mov	x17, xzr
    40204eb0:	d348fe2f 	lsr	x15, x17, #8
    40204eb4:	92009e30 	and	x16, x17, #0xff00ff00ff00ff
    40204eb8:	8b0e018e 	add	x14, x12, x14
    40204ebc:	cb0d0129 	sub	x9, x9, x13
    40204ec0:	92009def 	and	x15, x15, #0xff00ff00ff00ff
    40204ec4:	8b1001ef 	add	x15, x15, x16
    40204ec8:	9b0b7df0 	mul	x16, x15, x11
    40204ecc:	924005af 	and	x15, x13, #0x3
    40204ed0:	8b50c108 	add	x8, x8, x16, lsr #48
    40204ed4:	b5000d8f 	cbnz	x15, 40205084 <core::str::count::do_count_chars+0x30c>
    40204ed8:	b4fffd49 	cbz	x9, 40204e80 <core::str::count::do_count_chars+0x108>
    40204edc:	f103013f 	cmp	x9, #0xc0
    40204ee0:	aa0e03ec 	mov	x12, x14
    40204ee4:	9a8a312d 	csel	x13, x9, x10, cc  // cc = lo, ul, last
    40204ee8:	d37df1ae 	lsl	x14, x13, #3
    40204eec:	f27b15d0 	ands	x16, x14, #0x7e0
    40204ef0:	54fffde0 	b.eq	40204eac <core::str::count::do_count_chars+0x134>  // b.none
    40204ef4:	d10081cf 	sub	x15, x14, #0x20
    40204ef8:	f10181ff 	cmp	x15, #0x60
    40204efc:	54000082 	b.cs	40204f0c <core::str::count::do_count_chars+0x194>  // b.hs, b.nlast
    40204f00:	aa1f03f1 	mov	x17, xzr
    40204f04:	aa0c03ef 	mov	x15, x12
    40204f08:	14000044 	b	40205018 <core::str::count::do_count_chars+0x2a0>
    40204f0c:	d345fdef 	lsr	x15, x15, #5
    40204f10:	6f00e401 	movi	v1.2d, #0x0
    40204f14:	6f00e402 	movi	v2.2d, #0x0
    40204f18:	91010180 	add	x0, x12, #0x40
    40204f1c:	910005f1 	add	x17, x15, #0x1
    40204f20:	927ee632 	and	x18, x17, #0xffffffffffffffc
    40204f24:	927ee621 	and	x1, x17, #0xffffffffffffffc
    40204f28:	8b12158f 	add	x15, x12, x18, lsl #5
    40204f2c:	d1010002 	sub	x2, x0, #0x40
    40204f30:	4c400c10 	ld4	{v16.2d-v19.2d}, [x0]
    40204f34:	f1001021 	subs	x1, x1, #0x4
    40204f38:	91020000 	add	x0, x0, #0x80
    40204f3c:	4c400c43 	ld4	{v3.2d-v6.2d}, [x2]
    40204f40:	6e205a07 	mvn	v7.16b, v16.16b
    40204f44:	6e205a35 	mvn	v21.16b, v17.16b
    40204f48:	6e205a5a 	mvn	v26.16b, v18.16b
    40204f4c:	6e205876 	mvn	v22.16b, v3.16b
    40204f50:	6e205897 	mvn	v23.16b, v4.16b
    40204f54:	6e2058b8 	mvn	v24.16b, v5.16b
    40204f58:	6f7a0614 	ushr	v20.2d, v16.2d, #6
    40204f5c:	6f7a0639 	ushr	v25.2d, v17.2d, #6
    40204f60:	6f7a065b 	ushr	v27.2d, v18.2d, #6
    40204f64:	6f7a047c 	ushr	v28.2d, v3.2d, #6
    40204f68:	6f7a049d 	ushr	v29.2d, v4.2d, #6
    40204f6c:	6f7a04be 	ushr	v30.2d, v5.2d, #6
    40204f70:	6f7906d6 	ushr	v22.2d, v22.2d, #7
    40204f74:	6f7906f7 	ushr	v23.2d, v23.2d, #7
    40204f78:	6f790718 	ushr	v24.2d, v24.2d, #7
    40204f7c:	6f7904e7 	ushr	v7.2d, v7.2d, #7
    40204f80:	6f7906b5 	ushr	v21.2d, v21.2d, #7
    40204f84:	6f79075a 	ushr	v26.2d, v26.2d, #7
    40204f88:	6e205a7f 	mvn	v31.16b, v19.16b
    40204f8c:	6f7a0670 	ushr	v16.2d, v19.2d, #6
    40204f90:	6e2058d1 	mvn	v17.16b, v6.16b
    40204f94:	4ebc1ed2 	orr	v18.16b, v22.16b, v28.16b
    40204f98:	4ebd1ef3 	orr	v19.16b, v23.16b, v29.16b
    40204f9c:	4ebe1f16 	orr	v22.16b, v24.16b, v30.16b
    40204fa0:	4eb41ce7 	orr	v7.16b, v7.16b, v20.16b
    40204fa4:	4eb91eb4 	orr	v20.16b, v21.16b, v25.16b
    40204fa8:	4ebb1f55 	orr	v21.16b, v26.16b, v27.16b
    40204fac:	6f7a04c3 	ushr	v3.2d, v6.2d, #6
    40204fb0:	6f7907e4 	ushr	v4.2d, v31.2d, #7
    40204fb4:	6f790625 	ushr	v5.2d, v17.2d, #7
    40204fb8:	4e201e46 	and	v6.16b, v18.16b, v0.16b
    40204fbc:	4e201e71 	and	v17.16b, v19.16b, v0.16b
    40204fc0:	4e201ed2 	and	v18.16b, v22.16b, v0.16b
    40204fc4:	4e201ce7 	and	v7.16b, v7.16b, v0.16b
    40204fc8:	4e201e93 	and	v19.16b, v20.16b, v0.16b
    40204fcc:	4e201eb4 	and	v20.16b, v21.16b, v0.16b
    40204fd0:	4eb01c84 	orr	v4.16b, v4.16b, v16.16b
    40204fd4:	4ea31ca3 	orr	v3.16b, v5.16b, v3.16b
    40204fd8:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40204fdc:	4ef18646 	add	v6.2d, v18.2d, v17.2d
    40204fe0:	4ee284e2 	add	v2.2d, v7.2d, v2.2d
    40204fe4:	4ef38685 	add	v5.2d, v20.2d, v19.2d
    40204fe8:	4e201c63 	and	v3.16b, v3.16b, v0.16b
    40204fec:	4e201c84 	and	v4.16b, v4.16b, v0.16b
    40204ff0:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40204ff4:	4ee284a2 	add	v2.2d, v5.2d, v2.2d
    40204ff8:	4ee18461 	add	v1.2d, v3.2d, v1.2d
    40204ffc:	4ee28482 	add	v2.2d, v4.2d, v2.2d
    40205000:	54fff961 	b.ne	40204f2c <core::str::count::do_count_chars+0x1b4>  // b.any
    40205004:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40205008:	eb12023f 	cmp	x17, x18
    4020500c:	5ef1b821 	addp	d1, v1.2d
    40205010:	9e660031 	fmov	x17, d1
    40205014:	54fff4e0 	b.eq	40204eb0 <core::str::count::do_count_chars+0x138>  // b.none
    40205018:	8b100190 	add	x16, x12, x16
    4020501c:	f9400df2 	ldr	x18, [x15, #24]
    40205020:	f9001ff2 	str	x18, [sp, #56]
    40205024:	f94009f2 	ldr	x18, [x15, #16]
    40205028:	f9001bf2 	str	x18, [sp, #48]
    4020502c:	f94005f2 	ldr	x18, [x15, #8]
    40205030:	f90017f2 	str	x18, [sp, #40]
    40205034:	f84205f2 	ldr	x18, [x15], #32
    40205038:	eb1001ff 	cmp	x15, x16
    4020503c:	f90013f2 	str	x18, [sp, #32]
    40205040:	ad4107e2 	ldp	q2, q1, [sp, #32]
    40205044:	6e205823 	mvn	v3.16b, v1.16b
    40205048:	6e205844 	mvn	v4.16b, v2.16b
    4020504c:	6f7a0421 	ushr	v1.2d, v1.2d, #6
    40205050:	6f7a0442 	ushr	v2.2d, v2.2d, #6
    40205054:	6f790463 	ushr	v3.2d, v3.2d, #7
    40205058:	6f790484 	ushr	v4.2d, v4.2d, #7
    4020505c:	4ea21c82 	orr	v2.16b, v4.16b, v2.16b
    40205060:	4ea11c61 	orr	v1.16b, v3.16b, v1.16b
    40205064:	4e201c21 	and	v1.16b, v1.16b, v0.16b
    40205068:	4e201c42 	and	v2.16b, v2.16b, v0.16b
    4020506c:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40205070:	5ef1b821 	addp	d1, v1.2d
    40205074:	9e660032 	fmov	x18, d1
    40205078:	8b110251 	add	x17, x18, x17
    4020507c:	54fffd01 	b.ne	4020501c <core::str::count::do_count_chars+0x2a4>  // b.any
    40205080:	17ffff8c 	b	40204eb0 <core::str::count::do_count_chars+0x138>
    40205084:	927e15a9 	and	x9, x13, #0xfc
    40205088:	f10005ff 	cmp	x15, #0x1
    4020508c:	8b090d8a 	add	x10, x12, x9, lsl #3
    40205090:	f9400149 	ldr	x9, [x10]
    40205094:	aa2903eb 	mvn	x11, x9
    40205098:	d347fd6b 	lsr	x11, x11, #7
    4020509c:	aa491969 	orr	x9, x11, x9, lsr #6
    402050a0:	9200c129 	and	x9, x9, #0x101010101010101
    402050a4:	540001e0 	b.eq	402050e0 <core::str::count::do_count_chars+0x368>  // b.none
    402050a8:	f940054b 	ldr	x11, [x10, #8]
    402050ac:	f10009ff 	cmp	x15, #0x2
    402050b0:	aa2b03ec 	mvn	x12, x11
    402050b4:	d347fd8c 	lsr	x12, x12, #7
    402050b8:	aa4b198b 	orr	x11, x12, x11, lsr #6
    402050bc:	9200c16b 	and	x11, x11, #0x101010101010101
    402050c0:	8b090169 	add	x9, x11, x9
    402050c4:	540000e0 	b.eq	402050e0 <core::str::count::do_count_chars+0x368>  // b.none
    402050c8:	f940094a 	ldr	x10, [x10, #16]
    402050cc:	aa2a03eb 	mvn	x11, x10
    402050d0:	d347fd6b 	lsr	x11, x11, #7
    402050d4:	aa4a196a 	orr	x10, x11, x10, lsr #6
    402050d8:	9200c14a 	and	x10, x10, #0x101010101010101
    402050dc:	8b090149 	add	x9, x10, x9
    402050e0:	d348fd2a 	lsr	x10, x9, #8
    402050e4:	92009d29 	and	x9, x9, #0xff00ff00ff00ff
    402050e8:	92009d4a 	and	x10, x10, #0xff00ff00ff00ff
    402050ec:	8b090149 	add	x9, x10, x9
    402050f0:	b20083ea 	mov	x10, #0x1000100010001       	// #281479271743489
    402050f4:	9b0a7d29 	mul	x9, x9, x10
    402050f8:	8b49c108 	add	x8, x8, x9, lsr #48
    402050fc:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40205100:	aa0803e0 	mov	x0, x8
    40205104:	fd4023ea 	ldr	d10, [sp, #64]
    40205108:	910183ff 	add	sp, sp, #0x60
    4020510c:	d65f03c0 	ret
    40205110:	f100803f 	cmp	x1, #0x20
    40205114:	54000082 	b.cs	40205124 <core::str::count::do_count_chars+0x3ac>  // b.hs, b.nlast
    40205118:	aa1f03e9 	mov	x9, xzr
    4020511c:	aa1f03e8 	mov	x8, xzr
    40205120:	140000bc 	b	40205410 <core::str::count::do_count_chars+0x698>
    40205124:	6f00e400 	movi	v0.2d, #0x0
    40205128:	4f05e7e3 	movi	v3.16b, #0xbf
    4020512c:	52800028 	mov	w8, #0x1                   	// #1
    40205130:	6f00e402 	movi	v2.2d, #0x0
    40205134:	6f00e407 	movi	v7.2d, #0x0
    40205138:	927d042a 	and	x10, x1, #0x18
    4020513c:	6f00e401 	movi	v1.2d, #0x0
    40205140:	6f00e412 	movi	v18.2d, #0x0
    40205144:	927be829 	and	x9, x1, #0xffffffffffffffe0
    40205148:	6f00e405 	movi	v5.2d, #0x0
    4020514c:	6f00e406 	movi	v6.2d, #0x0
    40205150:	927be82b 	and	x11, x1, #0xffffffffffffffe0
    40205154:	6f00e404 	movi	v4.2d, #0x0
    40205158:	6f00e416 	movi	v22.2d, #0x0
    4020515c:	6f00e411 	movi	v17.2d, #0x0
    40205160:	6f00e410 	movi	v16.2d, #0x0
    40205164:	6f00e417 	movi	v23.2d, #0x0
    40205168:	6f00e414 	movi	v20.2d, #0x0
    4020516c:	6f00e415 	movi	v21.2d, #0x0
    40205170:	6f00e413 	movi	v19.2d, #0x0
    40205174:	6f00e418 	movi	v24.2d, #0x0
    40205178:	4e080d19 	dup	v25.2d, x8
    4020517c:	91004008 	add	x8, x0, #0x10
    40205180:	aa0803ec 	mov	x12, x8
    40205184:	385f1112 	ldurb	w18, [x8, #-15]
    40205188:	385f5102 	ldurb	w2, [x8, #-11]
    4020518c:	385f0d8d 	ldrb	w13, [x12, #-16]!
    40205190:	aa0c03ef 	mov	x15, x12
    40205194:	3940098e 	ldrb	w14, [x12, #2]
    40205198:	38404df0 	ldrb	w16, [x15, #4]!
    4020519c:	394009f1 	ldrb	w17, [x15, #2]
    402051a0:	39400d83 	ldrb	w3, [x12, #3]
    402051a4:	39400def 	ldrb	w15, [x15, #3]
    402051a8:	d370bdce 	lsl	x14, x14, #16
    402051ac:	aa1221ad 	orr	x13, x13, x18, lsl #8
    402051b0:	2a022210 	orr	w16, w16, w2, lsl #8
    402051b4:	53103e31 	lsl	w17, w17, #16
    402051b8:	f100816b 	subs	x11, x11, #0x20
    402051bc:	aa0361ce 	orr	x14, x14, x3, lsl #24
    402051c0:	2a0f622f 	orr	w15, w17, w15, lsl #24
    402051c4:	aa0d01cd 	orr	x13, x14, x13
    402051c8:	2a1001ee 	orr	w14, w15, w16
    402051cc:	aa0e81ad 	orr	x13, x13, x14, lsl #32
    402051d0:	f9000bed 	str	x13, [sp, #16]
    402051d4:	aa0c03ed 	mov	x13, x12
    402051d8:	38408dae 	ldrb	w14, [x13, #8]!
    402051dc:	39400daf 	ldrb	w15, [x13, #3]
    402051e0:	394009b0 	ldrb	w16, [x13, #2]
    402051e4:	38404db1 	ldrb	w17, [x13, #4]!
    402051e8:	394009b2 	ldrb	w18, [x13, #2]
    402051ec:	39402582 	ldrb	w2, [x12, #9]
    402051f0:	3940358c 	ldrb	w12, [x12, #13]
    402051f4:	39400dad 	ldrb	w13, [x13, #3]
    402051f8:	d370be10 	lsl	x16, x16, #16
    402051fc:	53103e52 	lsl	w18, w18, #16
    40205200:	aa0221ce 	orr	x14, x14, x2, lsl #8
    40205204:	2a0c222c 	orr	w12, w17, w12, lsl #8
    40205208:	aa0f620f 	orr	x15, x16, x15, lsl #24
    4020520c:	2a0d624d 	orr	w13, w18, w13, lsl #24
    40205210:	aa0e01ee 	orr	x14, x15, x14
    40205214:	2a0c01ac 	orr	w12, w13, w12
    40205218:	aa0c81cc 	orr	x12, x14, x12, lsl #32
    4020521c:	f9000fec 	str	x12, [sp, #24]
    40205220:	aa0803ec 	mov	x12, x8
    40205224:	3940090e 	ldrb	w14, [x8, #2]
    40205228:	38404d8f 	ldrb	w15, [x12, #4]!
    4020522c:	39400990 	ldrb	w16, [x12, #2]
    40205230:	3940050d 	ldrb	w13, [x8, #1]
    40205234:	39400111 	ldrb	w17, [x8]
    40205238:	39400d12 	ldrb	w18, [x8, #3]
    4020523c:	39401502 	ldrb	w2, [x8, #5]
    40205240:	39400d8c 	ldrb	w12, [x12, #3]
    40205244:	d370bdce 	lsl	x14, x14, #16
    40205248:	53103e10 	lsl	w16, w16, #16
    4020524c:	aa0d222d 	orr	x13, x17, x13, lsl #8
    40205250:	2a0221ef 	orr	w15, w15, w2, lsl #8
    40205254:	3dc007fa 	ldr	q26, [sp, #16]
    40205258:	aa1261ce 	orr	x14, x14, x18, lsl #24
    4020525c:	2a0c620c 	orr	w12, w16, w12, lsl #24
    40205260:	4e23375a 	cmgt	v26.16b, v26.16b, v3.16b
    40205264:	aa0d01cd 	orr	x13, x14, x13
    40205268:	2a0f018c 	orr	w12, w12, w15
    4020526c:	aa0c81ac 	orr	x12, x13, x12, lsl #32
    40205270:	aa0803ed 	mov	x13, x8
    40205274:	6f08a75b 	uxtl2	v27.8h, v26.16b
    40205278:	2f08a75a 	uxtl	v26.8h, v26.8b
    4020527c:	f90003ec 	str	x12, [sp]
    40205280:	38408dac 	ldrb	w12, [x13, #8]!
    40205284:	39400dae 	ldrb	w14, [x13, #3]
    40205288:	394009af 	ldrb	w15, [x13, #2]
    4020528c:	38404db0 	ldrb	w16, [x13, #4]!
    40205290:	394009b1 	ldrb	w17, [x13, #2]
    40205294:	39402512 	ldrb	w18, [x8, #9]
    40205298:	39403502 	ldrb	w2, [x8, #13]
    4020529c:	39400dad 	ldrb	w13, [x13, #3]
    402052a0:	d370bdef 	lsl	x15, x15, #16
    402052a4:	6f10a77c 	uxtl2	v28.4s, v27.8h
    402052a8:	53103e31 	lsl	w17, w17, #16
    402052ac:	aa12218c 	orr	x12, x12, x18, lsl #8
    402052b0:	2a022210 	orr	w16, w16, w2, lsl #8
    402052b4:	aa0e61ee 	orr	x14, x15, x14, lsl #24
    402052b8:	2f10a77b 	uxtl	v27.4s, v27.4h
    402052bc:	2f10a75e 	uxtl	v30.4s, v26.4h
    402052c0:	2a0d622d 	orr	w13, w17, w13, lsl #24
    402052c4:	6f20a79d 	uxtl2	v29.2d, v28.4s
    402052c8:	6f10a75a 	uxtl2	v26.4s, v26.8h
    402052cc:	aa0c01cc 	orr	x12, x14, x12
    402052d0:	2f20a79c 	uxtl	v28.2d, v28.2s
    402052d4:	91008108 	add	x8, x8, #0x20
    402052d8:	2a1001ad 	orr	w13, w13, w16
    402052dc:	6f20a768 	uxtl2	v8.2d, v27.4s
    402052e0:	6f20a7c9 	uxtl2	v9.2d, v30.4s
    402052e4:	aa0d818c 	orr	x12, x12, x13, lsl #32
    402052e8:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    402052ec:	6f20a74a 	uxtl2	v10.2d, v26.4s
    402052f0:	2f20a75a 	uxtl	v26.2d, v26.2s
    402052f4:	2f20a77b 	uxtl	v27.2d, v27.2s
    402052f8:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    402052fc:	f90007ec 	str	x12, [sp, #8]
    40205300:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    40205304:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    40205308:	3dc003ff 	ldr	q31, [sp]
    4020530c:	4efd86d6 	add	v22.2d, v22.2d, v29.2d
    40205310:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40205314:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    40205318:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    4020531c:	4efc8484 	add	v4.2d, v4.2d, v28.2d
    40205320:	4e2337ff 	cmgt	v31.16b, v31.16b, v3.16b
    40205324:	4ee884c6 	add	v6.2d, v6.2d, v8.2d
    40205328:	2f20a7de 	uxtl	v30.2d, v30.2s
    4020532c:	4eea8652 	add	v18.2d, v18.2d, v10.2d
    40205330:	4ee984e7 	add	v7.2d, v7.2d, v9.2d
    40205334:	4efa8421 	add	v1.2d, v1.2d, v26.2d
    40205338:	4efb84a5 	add	v5.2d, v5.2d, v27.2d
    4020533c:	6f08a7fd 	uxtl2	v29.8h, v31.16b
    40205340:	2f08a7ff 	uxtl	v31.8h, v31.8b
    40205344:	4e391fde 	and	v30.16b, v30.16b, v25.16b
    40205348:	6f10a7bc 	uxtl2	v28.4s, v29.8h
    4020534c:	6f10a7e8 	uxtl2	v8.4s, v31.8h
    40205350:	2f10a7bd 	uxtl	v29.4s, v29.4h
    40205354:	2f10a7fa 	uxtl	v26.4s, v31.4h
    40205358:	4efe8442 	add	v2.2d, v2.2d, v30.2d
    4020535c:	2f20a79b 	uxtl	v27.2d, v28.2s
    40205360:	6f20a79c 	uxtl2	v28.2d, v28.4s
    40205364:	2f20a7bf 	uxtl	v31.2d, v29.2s
    40205368:	6f20a509 	uxtl2	v9.2d, v8.4s
    4020536c:	6f20a7bd 	uxtl2	v29.2d, v29.4s
    40205370:	2f20a74a 	uxtl	v10.2d, v26.2s
    40205374:	6f20a75a 	uxtl2	v26.2d, v26.4s
    40205378:	2f20a508 	uxtl	v8.2d, v8.2s
    4020537c:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    40205380:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    40205384:	4e391fff 	and	v31.16b, v31.16b, v25.16b
    40205388:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    4020538c:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    40205390:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40205394:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    40205398:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    4020539c:	4efc8718 	add	v24.2d, v24.2d, v28.2d
    402053a0:	4efb8673 	add	v19.2d, v19.2d, v27.2d
    402053a4:	4eff8694 	add	v20.2d, v20.2d, v31.2d
    402053a8:	4efd86b5 	add	v21.2d, v21.2d, v29.2d
    402053ac:	4ee986f7 	add	v23.2d, v23.2d, v9.2d
    402053b0:	4eea8631 	add	v17.2d, v17.2d, v10.2d
    402053b4:	4ee88610 	add	v16.2d, v16.2d, v8.2d
    402053b8:	4efa8400 	add	v0.2d, v0.2d, v26.2d
    402053bc:	54ffee21 	b.ne	40205180 <core::str::count::do_count_chars+0x408>  // b.any
    402053c0:	4ef286e3 	add	v3.2d, v23.2d, v18.2d
    402053c4:	4ef68712 	add	v18.2d, v24.2d, v22.2d
    402053c8:	eb09003f 	cmp	x1, x9
    402053cc:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    402053d0:	4ee28622 	add	v2.2d, v17.2d, v2.2d
    402053d4:	4ee58685 	add	v5.2d, v20.2d, v5.2d
    402053d8:	4ee686a6 	add	v6.2d, v21.2d, v6.2d
    402053dc:	4ee18601 	add	v1.2d, v16.2d, v1.2d
    402053e0:	4ee48664 	add	v4.2d, v19.2d, v4.2d
    402053e4:	4ef28463 	add	v3.2d, v3.2d, v18.2d
    402053e8:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    402053ec:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    402053f0:	4ee68400 	add	v0.2d, v0.2d, v6.2d
    402053f4:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    402053f8:	4ee38400 	add	v0.2d, v0.2d, v3.2d
    402053fc:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    40205400:	5ef1b800 	addp	d0, v0.2d
    40205404:	9e660008 	fmov	x8, d0
    40205408:	54ffd3c0 	b.eq	40204e80 <core::str::count::do_count_chars+0x108>  // b.none
    4020540c:	b400074a 	cbz	x10, 402054f4 <core::str::count::do_count_chars+0x77c>
    40205410:	6f00e400 	movi	v0.2d, #0x0
    40205414:	6f00e401 	movi	v1.2d, #0x0
    40205418:	aa0903ea 	mov	x10, x9
    4020541c:	0f05e7e2 	movi	v2.8b, #0xbf
    40205420:	6f00e403 	movi	v3.2d, #0x0
    40205424:	927df029 	and	x9, x1, #0xfffffffffffffff8
    40205428:	6f00e404 	movi	v4.2d, #0x0
    4020542c:	4e081d00 	mov	v0.d[0], x8
    40205430:	52800028 	mov	w8, #0x1                   	// #1
    40205434:	4e080d05 	dup	v5.2d, x8
    40205438:	cb090148 	sub	x8, x10, x9
    4020543c:	8b0a000a 	add	x10, x0, x10
    40205440:	aa0a03ed 	mov	x13, x10
    40205444:	3940094c 	ldrb	w12, [x10, #2]
    40205448:	3940054b 	ldrb	w11, [x10, #1]
    4020544c:	38404dae 	ldrb	w14, [x13, #4]!
    40205450:	394009af 	ldrb	w15, [x13, #2]
    40205454:	39400150 	ldrb	w16, [x10]
    40205458:	39400d51 	ldrb	w17, [x10, #3]
    4020545c:	d370bd8c 	lsl	x12, x12, #16
    40205460:	39401552 	ldrb	w18, [x10, #5]
    40205464:	39400dad 	ldrb	w13, [x13, #3]
    40205468:	53103def 	lsl	w15, w15, #16
    4020546c:	aa0b220b 	orr	x11, x16, x11, lsl #8
    40205470:	aa11618c 	orr	x12, x12, x17, lsl #24
    40205474:	b1002108 	adds	x8, x8, #0x8
    40205478:	2a1221ce 	orr	w14, w14, w18, lsl #8
    4020547c:	2a0d61ed 	orr	w13, w15, w13, lsl #24
    40205480:	9100214a 	add	x10, x10, #0x8
    40205484:	aa0b018b 	orr	x11, x12, x11
    40205488:	2a0e01ac 	orr	w12, w13, w14
    4020548c:	aa0c816b 	orr	x11, x11, x12, lsl #32
    40205490:	9e670166 	fmov	d6, x11
    40205494:	0e2234c6 	cmgt	v6.8b, v6.8b, v2.8b
    40205498:	2f08a4c6 	uxtl	v6.8h, v6.8b
    4020549c:	6f10a4c7 	uxtl2	v7.4s, v6.8h
    402054a0:	2f10a4c6 	uxtl	v6.4s, v6.4h
    402054a4:	6f20a4f0 	uxtl2	v16.2d, v7.4s
    402054a8:	2f20a4d1 	uxtl	v17.2d, v6.2s
    402054ac:	6f20a4c6 	uxtl2	v6.2d, v6.4s
    402054b0:	2f20a4e7 	uxtl	v7.2d, v7.2s
    402054b4:	4e251e10 	and	v16.16b, v16.16b, v5.16b
    402054b8:	4e251e31 	and	v17.16b, v17.16b, v5.16b
    402054bc:	4e251cc6 	and	v6.16b, v6.16b, v5.16b
    402054c0:	4e251ce7 	and	v7.16b, v7.16b, v5.16b
    402054c4:	4ef08484 	add	v4.2d, v4.2d, v16.2d
    402054c8:	4ee68463 	add	v3.2d, v3.2d, v6.2d
    402054cc:	4ef18400 	add	v0.2d, v0.2d, v17.2d
    402054d0:	4ee78421 	add	v1.2d, v1.2d, v7.2d
    402054d4:	54fffb61 	b.ne	40205440 <core::str::count::do_count_chars+0x6c8>  // b.any
    402054d8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    402054dc:	4ee48461 	add	v1.2d, v3.2d, v4.2d
    402054e0:	eb09003f 	cmp	x1, x9
    402054e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    402054e8:	5ef1b800 	addp	d0, v0.2d
    402054ec:	9e660008 	fmov	x8, d0
    402054f0:	54ffcc80 	b.eq	40204e80 <core::str::count::do_count_chars+0x108>  // b.none
    402054f4:	cb09002a 	sub	x10, x1, x9
    402054f8:	8b090009 	add	x9, x0, x9
    402054fc:	38c0152b 	ldrsb	w11, [x9], #1
    40205500:	3101057f 	cmn	w11, #0x41
    40205504:	9a88d508 	cinc	x8, x8, gt
    40205508:	f100054a 	subs	x10, x10, #0x1
    4020550c:	54ffff81 	b.ne	402054fc <core::str::count::do_count_chars+0x784>  // b.any
    40205510:	17fffe5c 	b	40204e80 <core::str::count::do_count_chars+0x108>

0000000040205514 <core::panicking::panic_const::panic_const_div_by_zero>:
    40205514:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    40205518:	910003fd 	mov	x29, sp
    4020551c:	aa0003e2 	mov	x2, x0
    40205520:	d503201f 	nop
    40205524:	10006260 	adr	x0, 40206170 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.12776753234347168069+0xf8>
    40205528:	52800661 	mov	w1, #0x33                  	// #51
    4020552c:	97fffe09 	bl	40204d50 <core::panicking::panic_fmt>

0000000040205530 <core::panicking::panic_const::panic_const_rem_by_zero>:
    40205530:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    40205534:	910003fd 	mov	x29, sp
    40205538:	aa0003e2 	mov	x2, x0
    4020553c:	d503201f 	nop
    40205540:	30006240 	adr	x0, 40206189 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.12776753234347168069+0x111>
    40205544:	52800e61 	mov	w1, #0x73                  	// #115
    40205548:	97fffe02 	bl	40204d50 <core::panicking::panic_fmt>

000000004020554c <<core::fmt::Formatter>::pad_integral::write_prefix>:
    4020554c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40205550:	a90157f6 	stp	x22, x21, [sp, #16]
    40205554:	a9024ff4 	stp	x20, x19, [sp, #32]
    40205558:	910003fd 	mov	x29, sp
    4020555c:	aa0403f3 	mov	x19, x4
    40205560:	aa0303f4 	mov	x20, x3
    40205564:	aa0103f5 	mov	x21, x1
    40205568:	7144405f 	cmp	w2, #0x110, lsl #12
    4020556c:	540001a0 	b.eq	402055a0 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>  // b.none
    40205570:	f94012a8 	ldr	x8, [x21, #32]
    40205574:	2a0203e1 	mov	w1, w2
    40205578:	aa0003f6 	mov	x22, x0
    4020557c:	d63f0100 	blr	x8
    40205580:	2a0003e8 	mov	w8, w0
    40205584:	aa1603e0 	mov	x0, x22
    40205588:	360000c8 	tbz	w8, #0, 402055a0 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>
    4020558c:	52800020 	mov	w0, #0x1                   	// #1
    40205590:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40205594:	a94157f6 	ldp	x22, x21, [sp, #16]
    40205598:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4020559c:	d65f03c0 	ret
    402055a0:	b4000114 	cbz	x20, 402055c0 <<core::fmt::Formatter>::pad_integral::write_prefix+0x74>
    402055a4:	f9400ea3 	ldr	x3, [x21, #24]
    402055a8:	aa1403e1 	mov	x1, x20
    402055ac:	aa1303e2 	mov	x2, x19
    402055b0:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402055b4:	a94157f6 	ldp	x22, x21, [sp, #16]
    402055b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402055bc:	d61f0060 	br	x3
    402055c0:	2a1f03e0 	mov	w0, wzr
    402055c4:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402055c8:	a94157f6 	ldp	x22, x21, [sp, #16]
    402055cc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402055d0:	d65f03c0 	ret

00000000402055d4 <<u64 as core::fmt::Display>::fmt>:
    402055d4:	d100c3ff 	sub	sp, sp, #0x30
    402055d8:	a9027bfd 	stp	x29, x30, [sp, #32]
    402055dc:	910083fd 	add	x29, sp, #0x20
    402055e0:	f9400009 	ldr	x9, [x0]
    402055e4:	d503201f 	nop
    402055e8:	10005608 	adr	x8, 402060a8 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.12776753234347168069+0x30>
    402055ec:	f10fa13f 	cmp	x9, #0x3e8
    402055f0:	540004e3 	b.cc	4020568c <<u64 as core::fmt::Display>::fmt+0xb8>  // b.lo, b.ul, b.last
    402055f4:	d28b296c 	mov	x12, #0x594b                	// #22859
    402055f8:	910033ea 	add	x10, sp, #0xc
    402055fc:	5292cff1 	mov	w17, #0x967f                	// #38527
    40205600:	f2a710cc 	movk	x12, #0x3886, lsl #16
    40205604:	9280026b 	mov	x11, #0xffffffffffffffec    	// #-20
    40205608:	5284e20d 	mov	w13, #0x2710                	// #10000
    4020560c:	f2d8bacc 	movk	x12, #0xc5d6, lsl #32
    40205610:	52828f6e 	mov	w14, #0x147b                	// #5243
    40205614:	91004d4f 	add	x15, x10, #0x13
    40205618:	f2e68dac 	movk	x12, #0x346d, lsl #48
    4020561c:	52800c90 	mov	w16, #0x64                  	// #100
    40205620:	72a01311 	movk	w17, #0x98, lsl #16
    40205624:	aa0903ea 	mov	x10, x9
    40205628:	aa0a03f2 	mov	x18, x10
    4020562c:	9bcc7d4a 	umulh	x10, x10, x12
    40205630:	9100116b 	add	x11, x11, #0x4
    40205634:	eb11025f 	cmp	x18, x17
    40205638:	d34bfd4a 	lsr	x10, x10, #11
    4020563c:	1b0dc940 	msub	w0, w10, w13, w18
    40205640:	53023c02 	ubfx	w2, w0, #2, #14
    40205644:	1b0e7c42 	mul	w2, w2, w14
    40205648:	53117c42 	lsr	w2, w2, #17
    4020564c:	1b108040 	msub	w0, w2, w16, w0
    40205650:	8b224502 	add	x2, x8, w2, uxtw #1
    40205654:	39400043 	ldrb	w3, [x2]
    40205658:	39400442 	ldrb	w2, [x2, #1]
    4020565c:	8b202500 	add	x0, x8, w0, uxth #1
    40205660:	381fd1e3 	sturb	w3, [x15, #-3]
    40205664:	39400003 	ldrb	w3, [x0]
    40205668:	39400400 	ldrb	w0, [x0, #1]
    4020566c:	381fe1e2 	sturb	w2, [x15, #-2]
    40205670:	381ff1e3 	sturb	w3, [x15, #-1]
    40205674:	381fc5e0 	strb	w0, [x15], #-4
    40205678:	54fffd88 	b.hi	40205628 <<u64 as core::fmt::Display>::fmt+0x54>  // b.pmore
    4020567c:	cb0b03eb 	neg	x11, x11
    40205680:	f100255f 	cmp	x10, #0x9
    40205684:	540000c8 	b.hi	4020569c <<u64 as core::fmt::Display>::fmt+0xc8>  // b.pmore
    40205688:	14000015 	b	402056dc <<u64 as core::fmt::Display>::fmt+0x108>
    4020568c:	5280028b 	mov	w11, #0x14                  	// #20
    40205690:	aa0903ea 	mov	x10, x9
    40205694:	f100253f 	cmp	x9, #0x9
    40205698:	54000229 	b.ls	402056dc <<u64 as core::fmt::Display>::fmt+0x108>  // b.plast
    4020569c:	53023d4c 	ubfx	w12, w10, #2, #14
    402056a0:	52828f6d 	mov	w13, #0x147b                	// #5243
    402056a4:	910033ef 	add	x15, sp, #0xc
    402056a8:	1b0d7d8c 	mul	w12, w12, w13
    402056ac:	52800c8d 	mov	w13, #0x64                  	// #100
    402056b0:	53117d8c 	lsr	w12, w12, #17
    402056b4:	1b0da98a 	msub	w10, w12, w13, w10
    402056b8:	d100096d 	sub	x13, x11, #0x2
    402056bc:	8b0b01eb 	add	x11, x15, x11
    402056c0:	8b2a250a 	add	x10, x8, w10, uxth #1
    402056c4:	3940014e 	ldrb	w14, [x10]
    402056c8:	3940054a 	ldrb	w10, [x10, #1]
    402056cc:	382d69ee 	strb	w14, [x15, x13]
    402056d0:	381ff16a 	sturb	w10, [x11, #-1]
    402056d4:	aa0c03ea 	mov	x10, x12
    402056d8:	aa0d03eb 	mov	x11, x13
    402056dc:	b4000049 	cbz	x9, 402056e4 <<u64 as core::fmt::Display>::fmt+0x110>
    402056e0:	b40000ca 	cbz	x10, 402056f8 <<u64 as core::fmt::Display>::fmt+0x124>
    402056e4:	8b0a0508 	add	x8, x8, x10, lsl #1
    402056e8:	d100056b 	sub	x11, x11, #0x1
    402056ec:	910033e9 	add	x9, sp, #0xc
    402056f0:	39400508 	ldrb	w8, [x8, #1]
    402056f4:	382b6928 	strb	w8, [x9, x11]
    402056f8:	52800288 	mov	w8, #0x14                  	// #20
    402056fc:	aa0103e0 	mov	x0, x1
    40205700:	52800021 	mov	w1, #0x1                   	// #1
    40205704:	cb0b0105 	sub	x5, x8, x11
    40205708:	910033e8 	add	x8, sp, #0xc
    4020570c:	52800022 	mov	w2, #0x1                   	// #1
    40205710:	8b0b0104 	add	x4, x8, x11
    40205714:	aa1f03e3 	mov	x3, xzr
    40205718:	97fffc5a 	bl	40204880 <<core::fmt::Formatter>::pad_integral>
    4020571c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40205720:	9100c3ff 	add	sp, sp, #0x30
    40205724:	d65f03c0 	ret

0000000040205728 <__udivti3>:
    40205728:	d100c3ff 	sub	sp, sp, #0x30
    4020572c:	a9027bfd 	stp	x29, x30, [sp, #32]
    40205730:	910083fd 	add	x29, sp, #0x20
    40205734:	910003e8 	mov	x8, sp
    40205738:	94000005 	bl	4020574c <compiler_builtins::int::specialized_div_rem::u128_div_rem>
    4020573c:	a94007e0 	ldp	x0, x1, [sp]
    40205740:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40205744:	9100c3ff 	add	sp, sp, #0x30
    40205748:	d65f03c0 	ret

000000004020574c <compiler_builtins::int::specialized_div_rem::u128_div_rem>:
    4020574c:	dac01049 	clz	x9, x2
    40205750:	dac0106a 	clz	x10, x3
    40205754:	f100007f 	cmp	x3, #0x0
    40205758:	11010129 	add	w9, w9, #0x40
    4020575c:	dac0100c 	clz	x12, x0
    40205760:	1a89114b 	csel	w11, w10, w9, ne  // ne = any
    40205764:	dac01029 	clz	x9, x1
    40205768:	1101018a 	add	w10, w12, #0x40
    4020576c:	f100003f 	cmp	x1, #0x0
    40205770:	1a8a112f 	csel	w15, w9, w10, ne  // ne = any
    40205774:	6b0f0169 	subs	w9, w11, w15
    40205778:	54000149 	b.ls	402057a0 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x54>  // b.plast
    4020577c:	7100fdff 	cmp	w15, #0x3f
    40205780:	540001c9 	b.ls	402057b8 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x6c>  // b.plast
    40205784:	9ac20809 	udiv	x9, x0, x2
    40205788:	aa1f03ea 	mov	x10, xzr
    4020578c:	aa1f03e1 	mov	x1, xzr
    40205790:	9b028120 	msub	x0, x9, x2, x0
    40205794:	a9002909 	stp	x9, x10, [x8]
    40205798:	a9010500 	stp	x0, x1, [x8, #16]
    4020579c:	d65f03c0 	ret
    402057a0:	eb02001f 	cmp	x0, x2
    402057a4:	fa03003f 	sbcs	xzr, x1, x3
    402057a8:	54000282 	b.cs	402057f8 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0xac>  // b.hs, b.nlast
    402057ac:	a9007d1f 	stp	xzr, xzr, [x8]
    402057b0:	a9010500 	stp	x0, x1, [x8, #16]
    402057b4:	d65f03c0 	ret
    402057b8:	71017d7f 	cmp	w11, #0x5f
    402057bc:	540002a9 	b.ls	40205810 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0xc4>  // b.plast
    402057c0:	2a0203e9 	mov	w9, w2
    402057c4:	9ac9082a 	udiv	x10, x1, x9
    402057c8:	1b02854b 	msub	w11, w10, w2, w1
    402057cc:	93c0816b 	extr	x11, x11, x0, #32
    402057d0:	9ac9096c 	udiv	x12, x11, x9
    402057d4:	1b02ad8b 	msub	w11, w12, w2, w11
    402057d8:	aa4c814a 	orr	x10, x10, x12, lsr #32
    402057dc:	b3607d60 	bfi	x0, x11, #32, #32
    402057e0:	9ac9080b 	udiv	x11, x0, x9
    402057e4:	9b098160 	msub	x0, x11, x9, x0
    402057e8:	aa0c8169 	orr	x9, x11, x12, lsl #32
    402057ec:	a9002909 	stp	x9, x10, [x8]
    402057f0:	a9017d00 	stp	x0, xzr, [x8, #16]
    402057f4:	d65f03c0 	ret
    402057f8:	eb020000 	subs	x0, x0, x2
    402057fc:	52800029 	mov	w9, #0x1                   	// #1
    40205800:	da030021 	sbc	x1, x1, x3
    40205804:	a9007d09 	stp	x9, xzr, [x8]
    40205808:	a9010500 	stp	x0, x1, [x8, #16]
    4020580c:	d65f03c0 	ret
    40205810:	7100813f 	cmp	w9, #0x20
    40205814:	54000422 	b.cs	40205898 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x14c>  // b.hs, b.nlast
    40205818:	d37ff829 	lsl	x9, x1, #1
    4020581c:	5280080a 	mov	w10, #0x40                  	// #64
    40205820:	d37ff86c 	lsl	x12, x3, #1
    40205824:	510005eb 	sub	w11, w15, #0x1
    40205828:	4b0f014a 	sub	w10, w10, w15
    4020582c:	9acb2129 	lsl	x9, x9, x11
    40205830:	9aca240d 	lsr	x13, x0, x10
    40205834:	9acb218b 	lsl	x11, x12, x11
    40205838:	9aca244c 	lsr	x12, x2, x10
    4020583c:	9aca242e 	lsr	x14, x1, x10
    40205840:	9aca246f 	lsr	x15, x3, x10
    40205844:	f27a015f 	tst	x10, #0x40
    40205848:	aa0d0129 	orr	x9, x9, x13
    4020584c:	aa0c016a 	orr	x10, x11, x12
    40205850:	9a8911c9 	csel	x9, x14, x9, ne  // ne = any
    40205854:	9a8a11ea 	csel	x10, x15, x10, ne  // ne = any
    40205858:	9aca0929 	udiv	x9, x9, x10
    4020585c:	9bc97c4a 	umulh	x10, x2, x9
    40205860:	9b097c6b 	mul	x11, x3, x9
    40205864:	9bc97c6d 	umulh	x13, x3, x9
    40205868:	9b097c4c 	mul	x12, x2, x9
    4020586c:	ab0b014b 	adds	x11, x10, x11
    40205870:	9a8d35aa 	cinc	x10, x13, cs  // cs = hs, nlast
    40205874:	b500090a 	cbnz	x10, 40205994 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x248>
    40205878:	eb0c001f 	cmp	x0, x12
    4020587c:	fa0b003f 	sbcs	xzr, x1, x11
    40205880:	540008a3 	b.cc	40205994 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x248>  // b.lo, b.ul, b.last
    40205884:	eb0c0000 	subs	x0, x0, x12
    40205888:	da0b0021 	sbc	x1, x1, x11
    4020588c:	a9007d09 	stp	x9, xzr, [x8]
    40205890:	a9010500 	stp	x0, x1, [x8, #16]
    40205894:	d65f03c0 	ret
    40205898:	52800c0d 	mov	w13, #0x60                  	// #96
    4020589c:	d37ff86c 	lsl	x12, x3, #1
    402058a0:	5101856e 	sub	w14, w11, #0x61
    402058a4:	4b0b01ad 	sub	w13, w13, w11
    402058a8:	aa1f03e9 	mov	x9, xzr
    402058ac:	aa1f03ea 	mov	x10, xzr
    402058b0:	9ace218e 	lsl	x14, x12, x14
    402058b4:	9acd2450 	lsr	x16, x2, x13
    402058b8:	9acd2471 	lsr	x17, x3, x13
    402058bc:	f27a01bf 	tst	x13, #0x40
    402058c0:	aa1001ce 	orr	x14, x14, x16
    402058c4:	52800810 	mov	w16, #0x40                  	// #64
    402058c8:	9a8e122e 	csel	x14, x17, x14, ne  // ne = any
    402058cc:	2a0e03ee 	mov	w14, w14
    402058d0:	910005ce 	add	x14, x14, #0x1
    402058d4:	d37ff832 	lsl	x18, x1, #1
    402058d8:	4b0f0211 	sub	w17, w16, w15
    402058dc:	510005ef 	sub	w15, w15, #0x1
    402058e0:	9ad12424 	lsr	x4, x1, x17
    402058e4:	f27a023f 	tst	x17, #0x40
    402058e8:	9acf224f 	lsl	x15, x18, x15
    402058ec:	9ad12412 	lsr	x18, x0, x17
    402058f0:	aa1201ef 	orr	x15, x15, x18
    402058f4:	9a8f1092 	csel	x18, x4, x15, ne  // ne = any
    402058f8:	6b0d022f 	subs	w15, w17, w13
    402058fc:	540005c3 	b.cc	402059b4 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x268>  // b.lo, b.ul, b.last
    40205900:	9ace0a51 	udiv	x17, x18, x14
    40205904:	2a2f03e6 	mvn	w6, w15
    40205908:	f27a01ff 	tst	x15, #0x40
    4020590c:	9bd17c52 	umulh	x18, x2, x17
    40205910:	d341fe25 	lsr	x5, x17, #1
    40205914:	9b117c44 	mul	x4, x2, x17
    40205918:	9ac624a5 	lsr	x5, x5, x6
    4020591c:	9b114872 	madd	x18, x3, x17, x18
    40205920:	9acf2231 	lsl	x17, x17, x15
    40205924:	d341fc87 	lsr	x7, x4, #1
    40205928:	9ac624e6 	lsr	x6, x7, x6
    4020592c:	9acf2252 	lsl	x18, x18, x15
    40205930:	9acf208f 	lsl	x15, x4, x15
    40205934:	9a851224 	csel	x4, x17, x5, ne  // ne = any
    40205938:	9a9113f1 	csel	x17, xzr, x17, ne  // ne = any
    4020593c:	aa060252 	orr	x18, x18, x6
    40205940:	9a9211f2 	csel	x18, x15, x18, ne  // ne = any
    40205944:	9a8f13ef 	csel	x15, xzr, x15, ne  // ne = any
    40205948:	ab090229 	adds	x9, x17, x9
    4020594c:	9a0a008a 	adc	x10, x4, x10
    40205950:	eb0f0000 	subs	x0, x0, x15
    40205954:	fa120021 	sbcs	x1, x1, x18
    40205958:	dac0100f 	clz	x15, x0
    4020595c:	dac01031 	clz	x17, x1
    40205960:	110101ef 	add	w15, w15, #0x40
    40205964:	1a8f122f 	csel	w15, w17, w15, ne  // ne = any
    40205968:	6b0f017f 	cmp	w11, w15
    4020596c:	54000549 	b.ls	40205a14 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x2c8>  // b.plast
    40205970:	7100fdff 	cmp	w15, #0x3f
    40205974:	54fffb09 	b.ls	402058d4 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x188>  // b.plast
    40205978:	9ac2080b 	udiv	x11, x0, x2
    4020597c:	9b028160 	msub	x0, x11, x2, x0
    40205980:	ab0b0129 	adds	x9, x9, x11
    40205984:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40205988:	a9002909 	stp	x9, x10, [x8]
    4020598c:	a9017d00 	stp	x0, xzr, [x8, #16]
    40205990:	d65f03c0 	ret
    40205994:	ab00004d 	adds	x13, x2, x0
    40205998:	d1000529 	sub	x9, x9, #0x1
    4020599c:	9a01006e 	adc	x14, x3, x1
    402059a0:	eb0c01a0 	subs	x0, x13, x12
    402059a4:	da0b01c1 	sbc	x1, x14, x11
    402059a8:	a9007d09 	stp	x9, xzr, [x8]
    402059ac:	a9010500 	stp	x0, x1, [x8, #16]
    402059b0:	d65f03c0 	ret
    402059b4:	2a3103eb 	mvn	w11, w17
    402059b8:	9ad1244d 	lsr	x13, x2, x17
    402059bc:	f27a023f 	tst	x17, #0x40
    402059c0:	9acb218b 	lsl	x11, x12, x11
    402059c4:	9ad1246c 	lsr	x12, x3, x17
    402059c8:	aa0d016b 	orr	x11, x11, x13
    402059cc:	9a8b118b 	csel	x11, x12, x11, ne  // ne = any
    402059d0:	9acb0a4d 	udiv	x13, x18, x11
    402059d4:	9bcd7c4b 	umulh	x11, x2, x13
    402059d8:	9b0d7c4c 	mul	x12, x2, x13
    402059dc:	9b0d2c6b 	madd	x11, x3, x13, x11
    402059e0:	eb0c001f 	cmp	x0, x12
    402059e4:	fa0b003f 	sbcs	xzr, x1, x11
    402059e8:	540002a2 	b.cs	40205a3c <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x2f0>  // b.hs, b.nlast
    402059ec:	d10005ad 	sub	x13, x13, #0x1
    402059f0:	ab0d0129 	adds	x9, x9, x13
    402059f4:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    402059f8:	ab02000d 	adds	x13, x0, x2
    402059fc:	9a03002e 	adc	x14, x1, x3
    40205a00:	eb0c01a0 	subs	x0, x13, x12
    40205a04:	da0b01c1 	sbc	x1, x14, x11
    40205a08:	a9002909 	stp	x9, x10, [x8]
    40205a0c:	a9010500 	stp	x0, x1, [x8, #16]
    40205a10:	d65f03c0 	ret
    40205a14:	eb02001f 	cmp	x0, x2
    40205a18:	fa03003f 	sbcs	xzr, x1, x3
    40205a1c:	54ffebc3 	b.cc	40205794 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x48>  // b.lo, b.ul, b.last
    40205a20:	b1000529 	adds	x9, x9, #0x1
    40205a24:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40205a28:	eb020000 	subs	x0, x0, x2
    40205a2c:	da030021 	sbc	x1, x1, x3
    40205a30:	a9002909 	stp	x9, x10, [x8]
    40205a34:	a9010500 	stp	x0, x1, [x8, #16]
    40205a38:	d65f03c0 	ret
    40205a3c:	ab0d0129 	adds	x9, x9, x13
    40205a40:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40205a44:	eb0c0000 	subs	x0, x0, x12
    40205a48:	da0b0021 	sbc	x1, x1, x11
    40205a4c:	a9002909 	stp	x9, x10, [x8]
    40205a50:	a9010500 	stp	x0, x1, [x8, #16]
    40205a54:	d65f03c0 	ret

0000000040205a58 <memcpy>:
    40205a58:	f100405f 	cmp	x2, #0x10
    40205a5c:	54000723 	b.cc	40205b40 <memcpy+0xe8>  // b.lo, b.ul, b.last
    40205a60:	cb0003ec 	neg	x12, x0
    40205a64:	92400988 	and	x8, x12, #0x7
    40205a68:	8b080009 	add	x9, x0, x8
    40205a6c:	eb09001f 	cmp	x0, x9
    40205a70:	54000422 	b.cs	40205af4 <memcpy+0x9c>  // b.hs, b.nlast
    40205a74:	f100111f 	cmp	x8, #0x4
    40205a78:	aa0003ea 	mov	x10, x0
    40205a7c:	aa0103eb 	mov	x11, x1
    40205a80:	54000323 	b.cc	40205ae4 <memcpy+0x8c>  // b.lo, b.ul, b.last
    40205a84:	cb01000a 	sub	x10, x0, x1
    40205a88:	aa0103eb 	mov	x11, x1
    40205a8c:	f100815f 	cmp	x10, #0x20
    40205a90:	aa0003ea 	mov	x10, x0
    40205a94:	54000283 	b.cc	40205ae4 <memcpy+0x8c>  // b.lo, b.ul, b.last
    40205a98:	927e018c 	and	x12, x12, #0x4
    40205a9c:	aa0003ed 	mov	x13, x0
    40205aa0:	aa0103ee 	mov	x14, x1
    40205aa4:	8b0c000a 	add	x10, x0, x12
    40205aa8:	8b0c002b 	add	x11, x1, x12
    40205aac:	aa0c03ef 	mov	x15, x12
    40205ab0:	39400dd0 	ldrb	w16, [x14, #3]
    40205ab4:	394009d1 	ldrb	w17, [x14, #2]
    40205ab8:	f10011ef 	subs	x15, x15, #0x4
    40205abc:	394001d2 	ldrb	w18, [x14]
    40205ac0:	394005c3 	ldrb	w3, [x14, #1]
    40205ac4:	910011ce 	add	x14, x14, #0x4
    40205ac8:	39000db0 	strb	w16, [x13, #3]
    40205acc:	390009b1 	strb	w17, [x13, #2]
    40205ad0:	390005a3 	strb	w3, [x13, #1]
    40205ad4:	380045b2 	strb	w18, [x13], #4
    40205ad8:	54fffec1 	b.ne	40205ab0 <memcpy+0x58>  // b.any
    40205adc:	eb0c011f 	cmp	x8, x12
    40205ae0:	540000a0 	b.eq	40205af4 <memcpy+0x9c>  // b.none
    40205ae4:	3840156c 	ldrb	w12, [x11], #1
    40205ae8:	3800154c 	strb	w12, [x10], #1
    40205aec:	eb09015f 	cmp	x10, x9
    40205af0:	54ffffa1 	b.ne	40205ae4 <memcpy+0x8c>  // b.any
    40205af4:	cb08004b 	sub	x11, x2, x8
    40205af8:	8b08002a 	add	x10, x1, x8
    40205afc:	927df16c 	and	x12, x11, #0xfffffffffffffff8
    40205b00:	f240095f 	tst	x10, #0x7
    40205b04:	8b0c0128 	add	x8, x9, x12
    40205b08:	540007a1 	b.ne	40205bfc <memcpy+0x1a4>  // b.any
    40205b0c:	eb08013f 	cmp	x9, x8
    40205b10:	540000c2 	b.cs	40205b28 <memcpy+0xd0>  // b.hs, b.nlast
    40205b14:	aa0a03ed 	mov	x13, x10
    40205b18:	f84085ae 	ldr	x14, [x13], #8
    40205b1c:	f800852e 	str	x14, [x9], #8
    40205b20:	eb08013f 	cmp	x9, x8
    40205b24:	54ffffa3 	b.cc	40205b18 <memcpy+0xc0>  // b.lo, b.ul, b.last
    40205b28:	8b0c0141 	add	x1, x10, x12
    40205b2c:	92400962 	and	x2, x11, #0x7
    40205b30:	8b020109 	add	x9, x8, x2
    40205b34:	eb09011f 	cmp	x8, x9
    40205b38:	540000c3 	b.cc	40205b50 <memcpy+0xf8>  // b.lo, b.ul, b.last
    40205b3c:	1400002f 	b	40205bf8 <memcpy+0x1a0>
    40205b40:	aa0003e8 	mov	x8, x0
    40205b44:	8b020009 	add	x9, x0, x2
    40205b48:	eb09001f 	cmp	x0, x9
    40205b4c:	54000562 	b.cs	40205bf8 <memcpy+0x1a0>  // b.hs, b.nlast
    40205b50:	f100105f 	cmp	x2, #0x4
    40205b54:	540004a3 	b.cc	40205be8 <memcpy+0x190>  // b.lo, b.ul, b.last
    40205b58:	cb01010a 	sub	x10, x8, x1
    40205b5c:	f100815f 	cmp	x10, #0x20
    40205b60:	54000443 	b.cc	40205be8 <memcpy+0x190>  // b.lo, b.ul, b.last
    40205b64:	39400c2a 	ldrb	w10, [x1, #3]
    40205b68:	3940082b 	ldrb	w11, [x1, #2]
    40205b6c:	3940002c 	ldrb	w12, [x1]
    40205b70:	3940042d 	ldrb	w13, [x1, #1]
    40205b74:	39000d0a 	strb	w10, [x8, #3]
    40205b78:	927e044a 	and	x10, x2, #0xc
    40205b7c:	f100115f 	cmp	x10, #0x4
    40205b80:	3900090b 	strb	w11, [x8, #2]
    40205b84:	3900050d 	strb	w13, [x8, #1]
    40205b88:	3900010c 	strb	w12, [x8]
    40205b8c:	54000260 	b.eq	40205bd8 <memcpy+0x180>  // b.none
    40205b90:	39401c2b 	ldrb	w11, [x1, #7]
    40205b94:	3940182c 	ldrb	w12, [x1, #6]
    40205b98:	f100215f 	cmp	x10, #0x8
    40205b9c:	3940102d 	ldrb	w13, [x1, #4]
    40205ba0:	3940142e 	ldrb	w14, [x1, #5]
    40205ba4:	39001d0b 	strb	w11, [x8, #7]
    40205ba8:	3900190c 	strb	w12, [x8, #6]
    40205bac:	3900150e 	strb	w14, [x8, #5]
    40205bb0:	3900110d 	strb	w13, [x8, #4]
    40205bb4:	54000120 	b.eq	40205bd8 <memcpy+0x180>  // b.none
    40205bb8:	39402c2b 	ldrb	w11, [x1, #11]
    40205bbc:	3940282c 	ldrb	w12, [x1, #10]
    40205bc0:	3940202d 	ldrb	w13, [x1, #8]
    40205bc4:	3940242e 	ldrb	w14, [x1, #9]
    40205bc8:	39002d0b 	strb	w11, [x8, #11]
    40205bcc:	3900290c 	strb	w12, [x8, #10]
    40205bd0:	3900250e 	strb	w14, [x8, #9]
    40205bd4:	3900210d 	strb	w13, [x8, #8]
    40205bd8:	eb0a005f 	cmp	x2, x10
    40205bdc:	540000e0 	b.eq	40205bf8 <memcpy+0x1a0>  // b.none
    40205be0:	8b0a0108 	add	x8, x8, x10
    40205be4:	8b0a0021 	add	x1, x1, x10
    40205be8:	3840142a 	ldrb	w10, [x1], #1
    40205bec:	3800150a 	strb	w10, [x8], #1
    40205bf0:	eb09011f 	cmp	x8, x9
    40205bf4:	54ffffa1 	b.ne	40205be8 <memcpy+0x190>  // b.any
    40205bf8:	d65f03c0 	ret
    40205bfc:	eb08013f 	cmp	x9, x8
    40205c00:	54fff942 	b.cs	40205b28 <memcpy+0xd0>  // b.hs, b.nlast
    40205c04:	aa0a03ed 	mov	x13, x10
    40205c08:	aa0d03f0 	mov	x16, x13
    40205c0c:	394009af 	ldrb	w15, [x13, #2]
    40205c10:	394005ae 	ldrb	w14, [x13, #1]
    40205c14:	38404e11 	ldrb	w17, [x16, #4]!
    40205c18:	39400a12 	ldrb	w18, [x16, #2]
    40205c1c:	394001a1 	ldrb	w1, [x13]
    40205c20:	39400da2 	ldrb	w2, [x13, #3]
    40205c24:	d370bdef 	lsl	x15, x15, #16
    40205c28:	394015a3 	ldrb	w3, [x13, #5]
    40205c2c:	39400e10 	ldrb	w16, [x16, #3]
    40205c30:	53103e52 	lsl	w18, w18, #16
    40205c34:	aa0e202e 	orr	x14, x1, x14, lsl #8
    40205c38:	aa0261ef 	orr	x15, x15, x2, lsl #24
    40205c3c:	910021ad 	add	x13, x13, #0x8
    40205c40:	2a032231 	orr	w17, w17, w3, lsl #8
    40205c44:	2a106250 	orr	w16, w18, w16, lsl #24
    40205c48:	aa0e01ee 	orr	x14, x15, x14
    40205c4c:	2a11020f 	orr	w15, w16, w17
    40205c50:	aa0f81ce 	orr	x14, x14, x15, lsl #32
    40205c54:	f800852e 	str	x14, [x9], #8
    40205c58:	eb08013f 	cmp	x9, x8
    40205c5c:	54fffd63 	b.cc	40205c08 <memcpy+0x1b0>  // b.lo, b.ul, b.last
    40205c60:	17ffffb2 	b	40205b28 <memcpy+0xd0>

0000000040205c64 <__umodti3>:
    40205c64:	d100c3ff 	sub	sp, sp, #0x30
    40205c68:	a9027bfd 	stp	x29, x30, [sp, #32]
    40205c6c:	910083fd 	add	x29, sp, #0x20
    40205c70:	910003e8 	mov	x8, sp
    40205c74:	97fffeb6 	bl	4020574c <compiler_builtins::int::specialized_div_rem::u128_div_rem>
    40205c78:	a94107e0 	ldp	x0, x1, [sp, #16]
    40205c7c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40205c80:	9100c3ff 	add	sp, sp, #0x30
    40205c84:	d65f03c0 	ret

0000000040205c88 <memset>:
    40205c88:	f100405f 	cmp	x2, #0x10
    40205c8c:	540009e3 	b.cc	40205dc8 <memset+0x140>  // b.lo, b.ul, b.last
    40205c90:	cb0003eb 	neg	x11, x0
    40205c94:	92400968 	and	x8, x11, #0x7
    40205c98:	8b080009 	add	x9, x0, x8
    40205c9c:	eb09001f 	cmp	x0, x9
    40205ca0:	54000302 	b.cs	40205d00 <memset+0x78>  // b.hs, b.nlast
    40205ca4:	f100111f 	cmp	x8, #0x4
    40205ca8:	aa0003ea 	mov	x10, x0
    40205cac:	54000243 	b.cc	40205cf4 <memset+0x6c>  // b.lo, b.ul, b.last
    40205cb0:	0e020c20 	dup	v0.4h, w1
    40205cb4:	927e016b 	and	x11, x11, #0x4
    40205cb8:	aa0003ec 	mov	x12, x0
    40205cbc:	8b0b000a 	add	x10, x0, x11
    40205cc0:	aa0b03ed 	mov	x13, x11
    40205cc4:	5e0e0401 	mov	h1, v0.h[3]
    40205cc8:	5e0a0402 	mov	h2, v0.h[2]
    40205ccc:	5e060403 	mov	h3, v0.h[1]
    40205cd0:	3d000180 	str	b0, [x12]
    40205cd4:	f10011ad 	subs	x13, x13, #0x4
    40205cd8:	3c003181 	stur	b1, [x12, #3]
    40205cdc:	3c002182 	stur	b2, [x12, #2]
    40205ce0:	3c001183 	stur	b3, [x12, #1]
    40205ce4:	9100118c 	add	x12, x12, #0x4
    40205ce8:	54ffff41 	b.ne	40205cd0 <memset+0x48>  // b.any
    40205cec:	eb0b011f 	cmp	x8, x11
    40205cf0:	54000080 	b.eq	40205d00 <memset+0x78>  // b.none
    40205cf4:	38001541 	strb	w1, [x10], #1
    40205cf8:	eb09015f 	cmp	x10, x9
    40205cfc:	54ffffc1 	b.ne	40205cf4 <memset+0x6c>  // b.any
    40205d00:	cb08004a 	sub	x10, x2, x8
    40205d04:	927df148 	and	x8, x10, #0xfffffffffffffff8
    40205d08:	8b080128 	add	x8, x9, x8
    40205d0c:	eb08013f 	cmp	x9, x8
    40205d10:	54000102 	b.cs	40205d30 <memset+0xa8>  // b.hs, b.nlast
    40205d14:	12001c2b 	and	w11, w1, #0xff
    40205d18:	3200c3ec 	mov	w12, #0x1010101             	// #16843009
    40205d1c:	1b0c7d6b 	mul	w11, w11, w12
    40205d20:	aa0b816b 	orr	x11, x11, x11, lsl #32
    40205d24:	f800852b 	str	x11, [x9], #8
    40205d28:	eb08013f 	cmp	x9, x8
    40205d2c:	54ffffc3 	b.cc	40205d24 <memset+0x9c>  // b.lo, b.ul, b.last
    40205d30:	92400942 	and	x2, x10, #0x7
    40205d34:	8b020109 	add	x9, x8, x2
    40205d38:	eb09011f 	cmp	x8, x9
    40205d3c:	54000442 	b.cs	40205dc4 <memset+0x13c>  // b.hs, b.nlast
    40205d40:	f100105f 	cmp	x2, #0x4
    40205d44:	540003a3 	b.cc	40205db8 <memset+0x130>  // b.lo, b.ul, b.last
    40205d48:	927e044a 	and	x10, x2, #0xc
    40205d4c:	39000d01 	strb	w1, [x8, #3]
    40205d50:	f100115f 	cmp	x10, #0x4
    40205d54:	8b0a010b 	add	x11, x8, x10
    40205d58:	39000901 	strb	w1, [x8, #2]
    40205d5c:	39000501 	strb	w1, [x8, #1]
    40205d60:	39000101 	strb	w1, [x8]
    40205d64:	54000240 	b.eq	40205dac <memset+0x124>  // b.none
    40205d68:	0e020c20 	dup	v0.4h, w1
    40205d6c:	f100215f 	cmp	x10, #0x8
    40205d70:	5e0e0401 	mov	h1, v0.h[3]
    40205d74:	5e0a0402 	mov	h2, v0.h[2]
    40205d78:	5e060403 	mov	h3, v0.h[1]
    40205d7c:	3c004100 	stur	b0, [x8, #4]
    40205d80:	3c007101 	stur	b1, [x8, #7]
    40205d84:	3c006102 	stur	b2, [x8, #6]
    40205d88:	3c005103 	stur	b3, [x8, #5]
    40205d8c:	54000100 	b.eq	40205dac <memset+0x124>  // b.none
    40205d90:	5e0e0401 	mov	h1, v0.h[3]
    40205d94:	5e0a0402 	mov	h2, v0.h[2]
    40205d98:	3c008100 	stur	b0, [x8, #8]
    40205d9c:	5e060403 	mov	h3, v0.h[1]
    40205da0:	3c00b101 	stur	b1, [x8, #11]
    40205da4:	3c00a102 	stur	b2, [x8, #10]
    40205da8:	3c009103 	stur	b3, [x8, #9]
    40205dac:	eb0a005f 	cmp	x2, x10
    40205db0:	aa0b03e8 	mov	x8, x11
    40205db4:	54000080 	b.eq	40205dc4 <memset+0x13c>  // b.none
    40205db8:	38001501 	strb	w1, [x8], #1
    40205dbc:	eb09011f 	cmp	x8, x9
    40205dc0:	54ffffc1 	b.ne	40205db8 <memset+0x130>  // b.any
    40205dc4:	d65f03c0 	ret
    40205dc8:	aa0003e8 	mov	x8, x0
    40205dcc:	8b020009 	add	x9, x0, x2
    40205dd0:	eb09001f 	cmp	x0, x9
    40205dd4:	54fffb63 	b.cc	40205d40 <memset+0xb8>  // b.lo, b.ul, b.last
    40205dd8:	17fffffb 	b	40205dc4 <memset+0x13c>
