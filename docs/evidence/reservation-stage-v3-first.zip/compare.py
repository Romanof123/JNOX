import struct,hashlib
from pathlib import Path
def loads(p):
 b=p.read_bytes(); off=struct.unpack_from('<Q',b,32)[0]; size,num=struct.unpack_from('<HH',b,54)
 seg=[]
 for i in range(num):
  h=struct.unpack_from('<IIQQQQQQ',b,off+i*size)
  if h[0]==1:seg.append((h,b[h[2]:h[2]+h[5]]))
 return seg
for case in 'WS':
 r,p,b=[loads(Path(n+'.elf')) for n in ['reference-'+case,'parent-'+case+'B','candidate-'+case+'B']]
 assert r==p
 print(case, 'load-images equal',r==b)
 for (h,a),(k,c) in zip(r,b):
  diff=[(hex(h[3]+i),x,y) for i,(x,y) in enumerate(zip(a,c)) if x!=y]
  print(h==k,h[3:],hashlib.sha256(a).hexdigest(),hashlib.sha256(c).hexdigest(),len(diff),diff[:16])
