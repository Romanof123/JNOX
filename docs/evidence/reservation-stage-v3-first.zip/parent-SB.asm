
parent-SB.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000040200000 <_start>:
    40200000:	d5034fdf 	msr	daifset, #0xf
    40200004:	d5384240 	mrs	x0, currentel
    40200008:	f100101f 	cmp	x0, #0x4
    4020000c:	54000241 	b.ne	40200054 <_start+0x54>  // b.any
    40200010:	d50041bf 	msr	spsel, #0x1
    40200014:	58000260 	ldr	x0, 40200060 <_start+0x60>
    40200018:	9100001f 	mov	sp, x0
    4020001c:	d5381040 	mrs	x0, cpacr_el1
    40200020:	b26c0400 	orr	x0, x0, #0x300000
    40200024:	d5181040 	msr	cpacr_el1, x0
    40200028:	d5033fdf 	isb
    4020002c:	580001e0 	ldr	x0, 40200068 <_start+0x68>
    40200030:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    40200034:	f9000001 	str	x1, [x0]
    40200038:	580001c0 	ldr	x0, 40200070 <_start+0x70>
    4020003c:	580001e1 	ldr	x1, 40200078 <_start+0x78>
    40200040:	eb01001f 	cmp	x0, x1
    40200044:	54000062 	b.cs	40200050 <_start+0x50>  // b.hs, b.nlast
    40200048:	f800841f 	str	xzr, [x0], #8
    4020004c:	17fffffd 	b	40200040 <_start+0x40>
    40200050:	14001054 	b	402041a0 <jnox_kernel::kernel_main>
    40200054:	d503205f 	wfe
    40200058:	17ffffff 	b	40200054 <_start+0x54>
    4020005c:	00000000 	udf	#0
    40200060:	40227e30 	.word	0x40227e30
    40200064:	00000000 	.word	0x00000000
    40200068:	40223e20 	.word	0x40223e20
    4020006c:	00000000 	.word	0x00000000
    40200070:	40207710 	.word	0x40207710
    40200074:	00000000 	.word	0x00000000
    40200078:	40223e28 	.word	0x40223e28
	...

0000000040200800 <sched_vectors>:
    40200800:	14000200 00000000 00000000 00000000     ................
	...
    40200880:	140001e0 00000000 00000000 00000000     ................
	...
    40200900:	140001c0 00000000 00000000 00000000     ................
	...
    40200980:	140001a0 00000000 00000000 00000000     ................
	...
    40200a00:	140001b6 00000000 00000000 00000000     ................
	...
    40200a80:	14000161 00000000 00000000 00000000     a...............
	...
    40200b00:	14000140 00000000 00000000 00000000     @...............
	...
    40200b80:	14000120 00000000 00000000 00000000      ...............
	...
    40200c00:	14000100 00000000 00000000 00000000     ................
	...
    40200c80:	140000e0 00000000 00000000 00000000     ................
	...
    40200d00:	140000c0 00000000 00000000 00000000     ................
	...
    40200d80:	140000a0 00000000 00000000 00000000     ................
	...
    40200e00:	14000080 00000000 00000000 00000000     ................
	...
    40200e80:	14000060 00000000 00000000 00000000     `...............
	...
    40200f00:	14000040 00000000 00000000 00000000     @...............
	...
    40200f80:	14000020 00000000 00000000 00000000      ...............
	...
    40201000:	140000aa d10d03ff f90027e9 d5033fdf     .........'...?..
    40201010:	d53be029 f9009fe9 f94027e9 a90007e0     ).;......'@.....
    40201020:	a9010fe2 a90217e4 a9031fe6 a90427e8     .............'..
    40201030:	a9052fea a90637ec a9073fee a90847f0     ./...7...?...G..
    40201040:	a9094ff2 a90a57f4 a90b5ff6 a90c67f8     .O...W..._...g..
    40201050:	a90d6ffa a90e77fc f9007bfe ad0a07e0     .o...w...{......
    40201060:	ad0b0fe2 ad0c17e4 ad0d1fe6 ad0e27e8     .............'..
    40201070:	ad0f2fea ad1037ec ad113fee ad1247f0     ./...7...?...G..
    40201080:	ad134ff2 ad1457f4 ad155ff6 ad1667f8     .O...W..._...g..
    40201090:	ad176ffa ad1877fc ad197ffe d5384029     .o...w......)@8.
    402010a0:	d538400a a90fabe9 d53b4409 d53b442a     .@8......D;.*D;.
    402010b0:	a910abe9 d538d089 d538410a a911abe9     ......8..A8.....
    402010c0:	d53bd049 d53bd06a a912abe9 910003e0     I.;.j.;.........
    402010d0:	9400007e 14000036 d10d03ff f90027e9     ~...6........'..
    402010e0:	d5033fdf d53be029 f9009fe9 f94027e9     .?..).;......'@.
    402010f0:	a90007e0 a9010fe2 a90217e4 a9031fe6     ................
    40201100:	a90427e8 a9052fea a90637ec a9073fee     .'.../...7...?..
    40201110:	a90847f0 a9094ff2 a90a57f4 a90b5ff6     .G...O...W..._..
    40201120:	a90c67f8 a90d6ffa a90e77fc f9007bfe     .g...o...w...{..
    40201130:	ad0a07e0 ad0b0fe2 ad0c17e4 ad0d1fe6     ................
    40201140:	ad0e27e8 ad0f2fea ad1037ec ad113fee     .'.../...7...?..
    40201150:	ad1247f0 ad134ff2 ad1457f4 ad155ff6     .G...O...W..._..
    40201160:	ad1667f8 ad176ffa ad1877fc ad197ffe     .g...o...w......
    40201170:	d5384029 d538400a a90fabe9 d53b4409     )@8..@8......D;.
    40201180:	d53b442a a910abe9 d538d089 d538410a     *D;.......8..A8.
    40201190:	a911abe9 d53bd049 d53bd06a a912abe9     ....I.;.j.;.....
    402011a0:	910003e0 940003b0 14000001              ............

00000000402011ac <sched_start_frame>:
    402011ac:	9100001f 	mov	sp, x0
    402011b0:	a94fabe9 	ldp	x9, x10, [sp, #248]
    402011b4:	d5184029 	msr	elr_el1, x9
    402011b8:	d518400a 	msr	spsr_el1, x10
    402011bc:	a950abe9 	ldp	x9, x10, [sp, #264]
    402011c0:	d51b4409 	msr	fpcr, x9
    402011c4:	d51b442a 	msr	fpsr, x10
    402011c8:	a951abe9 	ldp	x9, x10, [sp, #280]
    402011cc:	d518d089 	msr	tpidr_el1, x9
    402011d0:	d518410a 	msr	sp_el0, x10
    402011d4:	a952abe9 	ldp	x9, x10, [sp, #296]
    402011d8:	d51bd049 	msr	tpidr_el0, x9
    402011dc:	d51bd06a 	msr	tpidrro_el0, x10
    402011e0:	ad4a07e0 	ldp	q0, q1, [sp, #320]
    402011e4:	ad4b0fe2 	ldp	q2, q3, [sp, #352]
    402011e8:	ad4c17e4 	ldp	q4, q5, [sp, #384]
    402011ec:	ad4d1fe6 	ldp	q6, q7, [sp, #416]
    402011f0:	ad4e27e8 	ldp	q8, q9, [sp, #448]
    402011f4:	ad4f2fea 	ldp	q10, q11, [sp, #480]
    402011f8:	ad5037ec 	ldp	q12, q13, [sp, #512]
    402011fc:	ad513fee 	ldp	q14, q15, [sp, #544]
    40201200:	ad5247f0 	ldp	q16, q17, [sp, #576]
    40201204:	ad534ff2 	ldp	q18, q19, [sp, #608]
    40201208:	ad5457f4 	ldp	q20, q21, [sp, #640]
    4020120c:	ad555ff6 	ldp	q22, q23, [sp, #672]
    40201210:	ad5667f8 	ldp	q24, q25, [sp, #704]
    40201214:	ad576ffa 	ldp	q26, q27, [sp, #736]
    40201218:	ad5877fc 	ldp	q28, q29, [sp, #768]
    4020121c:	ad597ffe 	ldp	q30, q31, [sp, #800]
    40201220:	d503201f 	nop
    40201224:	10112e29 	adr	x9, 402237e8 <jnox_ap_returns>
    40201228:	f940012a 	ldr	x10, [x9]
    4020122c:	f101015f 	cmp	x10, #0x40
    40201230:	54ffee82 	b.cs	40201000 <sched_vectors+0x800>  // b.hs, b.nlast
    40201234:	9100054b 	add	x11, x10, #0x1
    40201238:	f800852b 	str	x11, [x9], #8
    4020123c:	d280030b 	mov	x11, #0x18                  	// #24
    40201240:	9b0b2549 	madd	x9, x10, x11, x9
    40201244:	910003ea 	mov	x10, sp
    40201248:	d538402b 	mrs	x11, elr_el1
    4020124c:	a9002d2a 	stp	x10, x11, [x9]
    40201250:	d5033fdf 	isb
    40201254:	d53be02a 	mrs	x10, cntpct_el0
    40201258:	f900092a 	str	x10, [x9, #16]
    4020125c:	a94007e0 	ldp	x0, x1, [sp]
    40201260:	a9410fe2 	ldp	x2, x3, [sp, #16]
    40201264:	a94217e4 	ldp	x4, x5, [sp, #32]
    40201268:	a9431fe6 	ldp	x6, x7, [sp, #48]
    4020126c:	a94427e8 	ldp	x8, x9, [sp, #64]
    40201270:	a9452fea 	ldp	x10, x11, [sp, #80]
    40201274:	a94637ec 	ldp	x12, x13, [sp, #96]
    40201278:	a9473fee 	ldp	x14, x15, [sp, #112]
    4020127c:	a94847f0 	ldp	x16, x17, [sp, #128]
    40201280:	a9494ff2 	ldp	x18, x19, [sp, #144]
    40201284:	a94a57f4 	ldp	x20, x21, [sp, #160]
    40201288:	a94b5ff6 	ldp	x22, x23, [sp, #176]
    4020128c:	a94c67f8 	ldp	x24, x25, [sp, #192]
    40201290:	a94d6ffa 	ldp	x26, x27, [sp, #208]
    40201294:	a94e77fc 	ldp	x28, x29, [sp, #224]
    40201298:	f9407bfe 	ldr	x30, [sp, #240]
    4020129c:	910d03ff 	add	sp, sp, #0x340
    402012a0:	d5033f5f 	clrex
    402012a4:	d69f03e0 	eret

00000000402012a8 <jnox_kernel::ordinary_reservations::unexpected>:
    402012a8:	f81f0ffe 	str	x30, [sp, #-16]!
    402012ac:	52800060 	mov	w0, #0x3                   	// #3
    402012b0:	52800021 	mov	w1, #0x1                   	// #1
    402012b4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    402012b8:	52800043 	mov	w3, #0x2                   	// #2
    402012bc:	aa1f03e4 	mov	x4, xzr
    402012c0:	aa1f03e5 	mov	x5, xzr
    402012c4:	940004f8 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>

00000000402012c8 <jnox_kernel::ordinary_reservations::irq>:
    402012c8:	d10583ff 	sub	sp, sp, #0x160
    402012cc:	a9107bfd 	stp	x29, x30, [sp, #256]
    402012d0:	a9116ffc 	stp	x28, x27, [sp, #272]
    402012d4:	a91267fa 	stp	x26, x25, [sp, #288]
    402012d8:	a9135ff8 	stp	x24, x23, [sp, #304]
    402012dc:	a91457f6 	stp	x22, x21, [sp, #320]
    402012e0:	a9154ff4 	stp	x20, x19, [sp, #336]
    402012e4:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402012e8:	f9420108 	ldr	x8, [x8, #1024]
    402012ec:	f100091f 	cmp	x8, #0x2
    402012f0:	540033a0 	b.eq	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.none
    402012f4:	aa0003f4 	mov	x20, x0
    402012f8:	d0000038 	adrp	x24, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402012fc:	d503201f 	nop
    40201300:	100b2108 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308>
    40201304:	f942b309 	ldr	x9, [x24, #1376]
    40201308:	8b09390a 	add	x10, x8, x9, lsl #14
    4020130c:	eb00015f 	cmp	x10, x0
    40201310:	540032a8 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    40201314:	b10d069f 	cmn	x20, #0x341
    40201318:	54003268 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    4020131c:	d372c529 	lsl	x9, x9, #14
    40201320:	8b090108 	add	x8, x8, x9
    40201324:	91401108 	add	x8, x8, #0x4, lsl #12
    40201328:	910d0289 	add	x9, x20, #0x340
    4020132c:	eb08013f 	cmp	x9, x8
    40201330:	540031a8 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    40201334:	52800199 	mov	w25, #0xc                   	// #12
    40201338:	72a10039 	movk	w25, #0x801, lsl #16
    4020133c:	f9409e95 	ldr	x21, [x20, #312]
    40201340:	b9400336 	ldr	w22, [x25]
    40201344:	d53be237 	mrs	x23, cntp_ctl_el0
    40201348:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020134c:	91156129 	add	x9, x9, #0x558
    40201350:	f9401928 	ldr	x8, [x9, #48]
    40201354:	f9400133 	ldr	x19, [x9]
    40201358:	f100051f 	cmp	x8, #0x1
    4020135c:	540000e0 	b.eq	40201378 <jnox_kernel::ordinary_reservations::irq+0xb0>  // b.none
    40201360:	b100067f 	cmn	x19, #0x1
    40201364:	54000060 	b.eq	40201370 <jnox_kernel::ordinary_reservations::irq+0xa8>  // b.none
    40201368:	91000673 	add	x19, x19, #0x1
    4020136c:	14000003 	b	40201378 <jnox_kernel::ordinary_reservations::irq+0xb0>
    40201370:	b40043e8 	cbz	x8, 40201bec <jnox_kernel::ordinary_reservations::irq+0x924>
    40201374:	aa1f03f3 	mov	x19, xzr
    40201378:	d000003a 	adrp	x26, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020137c:	9115835a 	add	x26, x26, #0x560
    40201380:	f9401349 	ldr	x9, [x26, #32]
    40201384:	a909a3e9 	stp	x9, x8, [sp, #152]
    40201388:	f9400343 	ldr	x3, [x26]
    4020138c:	a90adff6 	stp	x22, x23, [sp, #168]
    40201390:	910263e4 	add	x4, sp, #0x98
    40201394:	52800080 	mov	w0, #0x4                   	// #4
    40201398:	aa1503e1 	mov	x1, x21
    4020139c:	aa1303e2 	mov	x2, x19
    402013a0:	9400046a 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    402013a4:	f9401348 	ldr	x8, [x26, #32]
    402013a8:	120026c9 	and	w9, w22, #0x3ff
    402013ac:	7100793f 	cmp	w9, #0x1e
    402013b0:	54004c61 	b.ne	40201d3c <jnox_kernel::ordinary_reservations::irq+0xa74>  // b.any
    402013b4:	92400ae9 	and	x9, x23, #0x7
    402013b8:	f100153f 	cmp	x9, #0x5
    402013bc:	54004c01 	b.ne	40201d3c <jnox_kernel::ordinary_reservations::irq+0xa74>  // b.any
    402013c0:	eb0802bf 	cmp	x21, x8
    402013c4:	54004bc3 	b.cc	40201d3c <jnox_kernel::ordinary_reservations::irq+0xa74>  // b.lo, b.ul, b.last
    402013c8:	d51be23f 	msr	cntp_ctl_el0, xzr
    402013cc:	d5033fdf 	isb
    402013d0:	d5033f9f 	dsb	sy
    402013d4:	b9000736 	str	w22, [x25, #4]
    402013d8:	d5033f9f 	dsb	sy
    402013dc:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402013e0:	f942c508 	ldr	x8, [x8, #1416]
    402013e4:	f100051f 	cmp	x8, #0x1
    402013e8:	540003e1 	b.ne	40201464 <jnox_kernel::ordinary_reservations::irq+0x19c>  // b.any
    402013ec:	aa1403e0 	mov	x0, x20
    402013f0:	aa1503e1 	mov	x1, x21
    402013f4:	2a1f03e2 	mov	w2, wzr
    402013f8:	aa1f03e3 	mov	x3, xzr
    402013fc:	9400064a 	bl	40202d24 <jnox_kernel::ordinary_reservations::Runtime::close>
    40201400:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201404:	9114e108 	add	x8, x8, #0x538
    40201408:	91000669 	add	x9, x19, #0x1
    4020140c:	a9402908 	ldp	x8, x10, [x8]
    40201410:	9bca7d2b 	umulh	x11, x9, x10
    40201414:	eb0b03ff 	cmp	xzr, x11
    40201418:	1a9f07eb 	cset	w11, ne  // ne = any
    4020141c:	9b0a7d29 	mul	x9, x9, x10
    40201420:	ab080122 	adds	x2, x9, x8
    40201424:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40201428:	3700486b 	tbnz	w11, #0, 40201d34 <jnox_kernel::ordinary_reservations::irq+0xa6c>
    4020142c:	35004848 	cbnz	w8, 40201d34 <jnox_kernel::ordinary_reservations::irq+0xa6c>
    40201430:	aa1303e0 	mov	x0, x19
    40201434:	aa1f03e1 	mov	x1, xzr
    40201438:	9400061a 	bl	40202ca0 <jnox_kernel::ordinary_reservations::Runtime::arm>
    4020143c:	aa1303e0 	mov	x0, x19
    40201440:	52800041 	mov	w1, #0x2                   	// #2
    40201444:	a9554ff4 	ldp	x20, x19, [sp, #336]
    40201448:	a95457f6 	ldp	x22, x21, [sp, #320]
    4020144c:	a9535ff8 	ldp	x24, x23, [sp, #304]
    40201450:	a95267fa 	ldp	x26, x25, [sp, #288]
    40201454:	a9516ffc 	ldp	x28, x27, [sp, #272]
    40201458:	a9507bfd 	ldp	x29, x30, [sp, #256]
    4020145c:	910583ff 	add	sp, sp, #0x160
    40201460:	1400076a 	b	40203208 <jnox_kernel::ordinary_reservations::Runtime::select>
    40201464:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201468:	9114c129 	add	x9, x9, #0x530
    4020146c:	f940192a 	ldr	x10, [x9, #48]
    40201470:	f100095f 	cmp	x10, #0x2
    40201474:	54002781 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201478:	39400129 	ldrb	w9, [x9]
    4020147c:	71000d3f 	cmp	w9, #0x3
    40201480:	54002721 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201484:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201488:	91152129 	add	x9, x9, #0x548
    4020148c:	f9001934 	str	x20, [x9, #48]
    40201490:	f9401d25 	ldr	x5, [x9, #56]
    40201494:	cb0502aa 	sub	x10, x21, x5
    40201498:	f9400129 	ldr	x9, [x9]
    4020149c:	eb09015f 	cmp	x10, x9
    402014a0:	54004668 	b.hi	40201d6c <jnox_kernel::ordinary_reservations::irq+0xaa4>  // b.pmore
    402014a4:	b40013f3 	cbz	x19, 40201720 <jnox_kernel::ordinary_reservations::irq+0x458>
    402014a8:	92800028 	mov	x8, #0xfffffffffffffffe    	// #-2
    402014ac:	d0000037 	adrp	x23, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014b0:	d0000038 	adrp	x24, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014b4:	91174318 	add	x24, x24, #0x5d0
    402014b8:	b4000428 	cbz	x8, 4020153c <jnox_kernel::ordinary_reservations::irq+0x274>
    402014bc:	aa0803f6 	mov	x22, x8
    402014c0:	910263e8 	add	x8, sp, #0x98
    402014c4:	91000ac0 	add	x0, x22, #0x2
    402014c8:	9400078c 	bl	402032f8 <jnox_kernel::ordinary_reservations::snapshot>
    402014cc:	a949d7f4 	ldp	x20, x21, [sp, #152]
    402014d0:	f942aae8 	ldr	x8, [x23, #1360]
    402014d4:	eb08027f 	cmp	x19, x8
    402014d8:	54000161 	b.ne	40201504 <jnox_kernel::ordinary_reservations::irq+0x23c>  // b.any
    402014dc:	f94057e8 	ldr	x8, [sp, #168]
    402014e0:	d5033fdf 	isb
    402014e4:	d53be021 	mrs	x1, cntpct_el0
    402014e8:	a909d7f4 	stp	x20, x21, [sp, #152]
    402014ec:	a90affe8 	stp	x8, xzr, [sp, #168]
    402014f0:	91000ac3 	add	x3, x22, #0x2
    402014f4:	910263e4 	add	x4, sp, #0x98
    402014f8:	528002a0 	mov	w0, #0x15                  	// #21
    402014fc:	aa1303e2 	mov	x2, x19
    40201500:	94000412 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40201504:	f85f0308 	ldur	x8, [x24, #-16]
    40201508:	eb08029f 	cmp	x20, x8
    4020150c:	540000a1 	b.ne	40201520 <jnox_kernel::ordinary_reservations::irq+0x258>  // b.any
    40201510:	f8408709 	ldr	x9, [x24], #8
    40201514:	910006c8 	add	x8, x22, #0x1
    40201518:	eb0902bf 	cmp	x21, x9
    4020151c:	54fffce0 	b.eq	402014b8 <jnox_kernel::ordinary_reservations::irq+0x1f0>  // b.none
    40201520:	91000ac3 	add	x3, x22, #0x2
    40201524:	52800060 	mov	w0, #0x3                   	// #3
    40201528:	52800101 	mov	w1, #0x8                   	// #8
    4020152c:	aa1303e2 	mov	x2, x19
    40201530:	aa1403e4 	mov	x4, x20
    40201534:	aa1503e5 	mov	x5, x21
    40201538:	9400045b 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>
    4020153c:	f942aae8 	ldr	x8, [x23, #1360]
    40201540:	eb08027f 	cmp	x19, x8
    40201544:	540043a0 	b.eq	40201db8 <jnox_kernel::ordinary_reservations::irq+0xaf0>  // b.none
    40201548:	9400071f 	bl	402031c4 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    4020154c:	910263e8 	add	x8, sp, #0x98
    40201550:	aa1303e1 	mov	x1, x19
    40201554:	940008b3 	bl	40203820 <jnox_kernel::reservation_jobs::Jobs::open>
    40201558:	f9404fe8 	ldr	x8, [sp, #152]
    4020155c:	f100091f 	cmp	x8, #0x2
    40201560:	54004380 	b.eq	40201dd0 <jnox_kernel::ordinary_reservations::irq+0xb08>  // b.none
    40201564:	9100c3e0 	add	x0, sp, #0x30
    40201568:	910263e1 	add	x1, sp, #0x98
    4020156c:	52800d02 	mov	w2, #0x68                  	// #104
    40201570:	94001112 	bl	402059b8 <memcpy>
    40201574:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201578:	9114e129 	add	x9, x9, #0x538
    4020157c:	a9402129 	ldp	x9, x8, [x9]
    40201580:	9bc87e6a 	umulh	x10, x19, x8
    40201584:	eb0a03ff 	cmp	xzr, x10
    40201588:	1a9f07eb 	cset	w11, ne  // ne = any
    4020158c:	9b087e6a 	mul	x10, x19, x8
    40201590:	ab09014c 	adds	x12, x10, x9
    40201594:	1a9f37ea 	cset	w10, cs  // cs = hs, nlast
    40201598:	37003ceb 	tbnz	w11, #0, 40201d34 <jnox_kernel::ordinary_reservations::irq+0xa6c>
    4020159c:	35003cca 	cbnz	w10, 40201d34 <jnox_kernel::ordinary_reservations::irq+0xa6c>
    402015a0:	9100066b 	add	x11, x19, #0x1
    402015a4:	9bc87d6a 	umulh	x10, x11, x8
    402015a8:	eb0a03ff 	cmp	xzr, x10
    402015ac:	1a9f07ea 	cset	w10, ne  // ne = any
    402015b0:	9b087d68 	mul	x8, x11, x8
    402015b4:	ab090108 	adds	x8, x8, x9
    402015b8:	a90223ec 	stp	x12, x8, [sp, #32]
    402015bc:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    402015c0:	37003baa 	tbnz	w10, #0, 40201d34 <jnox_kernel::ordinary_reservations::irq+0xa6c>
    402015c4:	35003b88 	cbnz	w8, 40201d34 <jnox_kernel::ordinary_reservations::irq+0xa6c>
    402015c8:	aa1f03f6 	mov	x22, xzr
    402015cc:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402015d0:	39424beb 	ldrb	w11, [sp, #146]
    402015d4:	9100c3e9 	add	x9, sp, #0x30
    402015d8:	9100613d 	add	x29, x9, #0x18
    402015dc:	b94033fc 	ldr	w28, [sp, #48]
    402015e0:	9100e137 	add	x23, x9, #0x38
    402015e4:	91004138 	add	x24, x9, #0x10
    402015e8:	f9401ff5 	ldr	x21, [sp, #56]
    402015ec:	9100056a 	add	x10, x11, #0x1
    402015f0:	71000d7f 	cmp	w11, #0x3
    402015f4:	f902ad13 	str	x19, [x8, #1368]
    402015f8:	91000568 	add	x8, x11, #0x1
    402015fc:	a9012fe8 	stp	x8, x11, [sp, #16]
    40201600:	1a8a03f9 	csel	w25, wzr, w10, eq  // eq = none
    40201604:	91016134 	add	x20, x9, #0x58
    40201608:	9101813a 	add	x26, x9, #0x60
    4020160c:	52800028 	mov	w8, #0x1                   	// #1
    40201610:	8b1613a9 	add	x9, x29, x22, lsl #4
    40201614:	8b1612ea 	add	x10, x23, x22, lsl #4
    40201618:	d5033fdf 	isb
    4020161c:	d53be021 	mrs	x1, cntpct_el0
    40201620:	2a0803fb 	mov	w27, w8
    40201624:	a9402528 	ldp	x8, x9, [x9]
    40201628:	a909a7e8 	stp	x8, x9, [sp, #152]
    4020162c:	a9402548 	ldp	x8, x9, [x10]
    40201630:	a90aa7e8 	stp	x8, x9, [sp, #168]
    40201634:	910263e4 	add	x4, sp, #0x98
    40201638:	528000a0 	mov	w0, #0x5                   	// #5
    4020163c:	aa1303e2 	mov	x2, x19
    40201640:	aa1603e3 	mov	x3, x22
    40201644:	940003c1 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40201648:	d5033fdf 	isb
    4020164c:	d53be021 	mrs	x1, cntpct_el0
    40201650:	b8767b08 	ldr	w8, [x24, x22, lsl #2]
    40201654:	eb1502df 	cmp	x22, x21
    40201658:	b8767a89 	ldr	w9, [x20, x22, lsl #2]
    4020165c:	38766b4a 	ldrb	w10, [x26, x22]
    40201660:	1a9f17eb 	cset	w11, eq  // eq = none
    40201664:	a909a7e8 	stp	x8, x9, [sp, #152]
    40201668:	6a0b039f 	tst	w28, w11
    4020166c:	9a9f1328 	csel	x8, x25, xzr, ne  // ne = any
    40201670:	a90aa3ea 	stp	x10, x8, [sp, #168]
    40201674:	910263e4 	add	x4, sp, #0x98
    40201678:	528000c0 	mov	w0, #0x6                   	// #6
    4020167c:	aa1303e2 	mov	x2, x19
    40201680:	aa1603e3 	mov	x3, x22
    40201684:	940003b1 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40201688:	2a1f03e8 	mov	w8, wzr
    4020168c:	52800036 	mov	w22, #0x1                   	// #1
    40201690:	3707fc1b 	tbnz	w27, #0, 40201610 <jnox_kernel::ordinary_reservations::irq+0x348>
    40201694:	340029fc 	cbz	w28, 40201bd0 <jnox_kernel::ordinary_reservations::irq+0x908>
    40201698:	f9400ff6 	ldr	x22, [sp, #24]
    4020169c:	71000edf 	cmp	w22, #0x3
    402016a0:	54001620 	b.eq	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.none
    402016a4:	910263e8 	add	x8, sp, #0x98
    402016a8:	aa1503e0 	mov	x0, x21
    402016ac:	94000713 	bl	402032f8 <jnox_kernel::ordinary_reservations::snapshot>
    402016b0:	f1000abf 	cmp	x21, #0x2
    402016b4:	54003a42 	b.cs	40201dfc <jnox_kernel::ordinary_reservations::irq+0xb34>  // b.hs, b.nlast
    402016b8:	a949a7e8 	ldp	x8, x9, [sp, #152]
    402016bc:	d503201f 	nop
    402016c0:	1002ea0a 	adr	x10, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402016c4:	8b150d4b 	add	x11, x10, x21, lsl #3
    402016c8:	f940c96c 	ldr	x12, [x11, #400]
    402016cc:	9100c3ea 	add	x10, sp, #0x30
    402016d0:	8b15114a 	add	x10, x10, x21, lsl #4
    402016d4:	f940214a 	ldr	x10, [x10, #64]
    402016d8:	eb0a019f 	cmp	x12, x10
    402016dc:	54000060 	b.eq	402016e8 <jnox_kernel::ordinary_reservations::irq+0x420>  // b.none
    402016e0:	f900c96a 	str	x10, [x11, #400]
    402016e4:	f900d17f 	str	xzr, [x11, #416]
    402016e8:	d000010b 	adrp	x11, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0xb8e0>
    402016ec:	f943f56b 	ldr	x11, [x11, #2024]
    402016f0:	d000002c 	adrp	x12, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402016f4:	9114018c 	add	x12, x12, #0x500
    402016f8:	a9004d95 	stp	x21, x19, [x12]
    402016fc:	a901218b 	stp	x11, x8, [x12, #16]
    40201700:	a9022989 	stp	x9, x10, [x12, #32]
    40201704:	3900c196 	strb	w22, [x12, #48]
    40201708:	f94017f4 	ldr	x20, [sp, #40]
    4020170c:	340029b6 	cbz	w22, 40201c40 <jnox_kernel::ordinary_reservations::irq+0x978>
    40201710:	b104011f 	cmn	x8, #0x100
    40201714:	540037e2 	b.cs	40201e10 <jnox_kernel::ordinary_reservations::irq+0xb48>  // b.hs, b.nlast
    40201718:	91040108 	add	x8, x8, #0x100
    4020171c:	1400014a 	b	40201c44 <jnox_kernel::ordinary_reservations::irq+0x97c>
    40201720:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201724:	f942f129 	ldr	x9, [x9, #1504]
    40201728:	f100093f 	cmp	x9, #0x2
    4020172c:	540011c0 	b.eq	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.none
    40201730:	b50011a8 	cbnz	x8, 40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>
    40201734:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201738:	f942ad08 	ldr	x8, [x8, #1368]
    4020173c:	b100051f 	cmn	x8, #0x1
    40201740:	54001121 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201744:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201748:	f9432d08 	ldr	x8, [x8, #1624]
    4020174c:	eb0800bf 	cmp	x5, x8
    40201750:	540010a1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201754:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201758:	f9429d29 	ldr	x9, [x9, #1336]
    4020175c:	eb08013f 	cmp	x9, x8
    40201760:	54001021 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201764:	d0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0xb8e0>
    40201768:	f943f508 	ldr	x8, [x8, #2024]
    4020176c:	f100051f 	cmp	x8, #0x1
    40201770:	54000fa1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201774:	d503201f 	nop
    40201778:	10110348 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    4020177c:	c8dffd09 	ldar	x9, [x8]
    40201780:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201784:	f942354a 	ldr	x10, [x10, #1128]
    40201788:	aa0a0129 	orr	x9, x9, x10
    4020178c:	b5000ec9 	cbnz	x9, 40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>
    40201790:	aa1f03eb 	mov	x11, xzr
    40201794:	5280002a 	mov	w10, #0x1                   	// #1
    40201798:	d503201f 	nop
    4020179c:	1002e337 	adr	x23, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402017a0:	8b0b02e9 	add	x9, x23, x11
    402017a4:	3941e129 	ldrb	w9, [x9, #120]
    402017a8:	3600008a 	tbz	w10, #0, 402017b8 <jnox_kernel::ordinary_reservations::irq+0x4f0>
    402017ac:	2a1f03ea 	mov	w10, wzr
    402017b0:	5280002b 	mov	w11, #0x1                   	// #1
    402017b4:	34ffff69 	cbz	w9, 402017a0 <jnox_kernel::ordinary_reservations::irq+0x4d8>
    402017b8:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402017bc:	9111814a 	add	x10, x10, #0x460
    402017c0:	3940014b 	ldrb	w11, [x10]
    402017c4:	f940094a 	ldr	x10, [x10, #16]
    402017c8:	7100013f 	cmp	w9, #0x0
    402017cc:	7a430960 	ccmp	w11, #0x3, #0x0, eq  // eq = none
    402017d0:	fa400940 	ccmp	x10, #0x0, #0x0, eq  // eq = none
    402017d4:	54000c81 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402017d8:	d000010b 	adrp	x11, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0xb8e0>
    402017dc:	911fc16b 	add	x11, x11, #0x7f0
    402017e0:	f9400969 	ldr	x9, [x11, #16]
    402017e4:	f940056a 	ldr	x10, [x11, #8]
    402017e8:	f940016b 	ldr	x11, [x11]
    402017ec:	d000010c 	adrp	x12, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0xb8e0>
    402017f0:	910f818c 	add	x12, x12, #0x3e0
    402017f4:	eb0c017f 	cmp	x11, x12
    402017f8:	54000b61 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402017fc:	d503201f 	nop
    40201800:	10004a6b 	adr	x11, 4020214c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308>
    40201804:	eb0b015f 	cmp	x10, x11
    40201808:	54000ae1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    4020180c:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201810:	f943254a 	ldr	x10, [x10, #1608]
    40201814:	eb0a013f 	cmp	x9, x10
    40201818:	54000a68 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    4020181c:	aa1f03e9 	mov	x9, xzr
    40201820:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201824:	911aa14a 	add	x10, x10, #0x6a8
    40201828:	d00000cb 	adrp	x11, 4021b000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0x38e0>
    4020182c:	911c816b 	add	x11, x11, #0x720
    40201830:	d503201f 	nop
    40201834:	1002f5b9 	adr	x25, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40201838:	d503201f 	nop
    4020183c:	10112dba 	adr	x26, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40201840:	d503201f 	nop
    40201844:	1002f5bc 	adr	x28, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40201848:	d503201f 	nop
    4020184c:	10112dbb 	adr	x27, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40201850:	d503201f 	nop
    40201854:	10112dec 	adr	x12, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    40201858:	f100413f 	cmp	x9, #0x10
    4020185c:	54000860 	b.eq	40201968 <jnox_kernel::ordinary_reservations::irq+0x6a0>  // b.none
    40201860:	8b0902ed 	add	x13, x23, x9
    40201864:	f940b5ad 	ldr	x13, [x13, #360]
    40201868:	f85d014e 	ldur	x14, [x10, #-48]
    4020186c:	eb0d01df 	cmp	x14, x13
    40201870:	540007a1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201874:	d10d016e 	sub	x14, x11, #0x340
    40201878:	d140116f 	sub	x15, x11, #0x4, lsl #12
    4020187c:	eb0d01df 	cmp	x14, x13
    40201880:	fa4d01e2 	ccmp	x15, x13, #0x2, eq  // eq = none
    40201884:	54000708 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    40201888:	b10d05bf 	cmn	x13, #0x341
    4020188c:	540006c8 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    40201890:	910d01ae 	add	x14, x13, #0x340
    40201894:	eb0b01df 	cmp	x14, x11
    40201898:	54000668 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    4020189c:	f9407dae 	ldr	x14, [x13, #248]
    402018a0:	f85d814f 	ldur	x15, [x10, #-40]
    402018a4:	eb0f01df 	cmp	x14, x15
    402018a8:	540005e1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402018ac:	f94081ae 	ldr	x14, [x13, #256]
    402018b0:	f85e014f 	ldur	x15, [x10, #-32]
    402018b4:	eb0f01df 	cmp	x14, x15
    402018b8:	54000561 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402018bc:	f9404dae 	ldr	x14, [x13, #152]
    402018c0:	f85e814f 	ldur	x15, [x10, #-24]
    402018c4:	eb0f01df 	cmp	x14, x15
    402018c8:	540004e1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402018cc:	f9408dad 	ldr	x13, [x13, #280]
    402018d0:	f85f014e 	ldur	x14, [x10, #-16]
    402018d4:	eb0e01bf 	cmp	x13, x14
    402018d8:	54000461 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402018dc:	8b09032d 	add	x13, x25, x9
    402018e0:	c8dffdad 	ldar	x13, [x13]
    402018e4:	b10005bf 	cmn	x13, #0x1
    402018e8:	540003e1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402018ec:	8b09034d 	add	x13, x26, x9
    402018f0:	c8dffdad 	ldar	x13, [x13]
    402018f4:	b500038d 	cbnz	x13, 40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>
    402018f8:	8b09038d 	add	x13, x28, x9
    402018fc:	c8dffdad 	ldar	x13, [x13]
    40201900:	b10005bf 	cmn	x13, #0x1
    40201904:	54000301 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201908:	8b09036d 	add	x13, x27, x9
    4020190c:	c8dffdad 	ldar	x13, [x13]
    40201910:	b50002ad 	cbnz	x13, 40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>
    40201914:	8b09018d 	add	x13, x12, x9
    40201918:	c8dffdad 	ldar	x13, [x13]
    4020191c:	b500024d 	cbnz	x13, 40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>
    40201920:	8b0902ed 	add	x13, x23, x9
    40201924:	f940e1ae 	ldr	x14, [x13, #448]
    40201928:	f85f814f 	ldur	x15, [x10, #-8]
    4020192c:	eb0f01df 	cmp	x14, x15
    40201930:	540001a1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201934:	f940e9ad 	ldr	x13, [x13, #464]
    40201938:	f843854e 	ldr	x14, [x10], #56
    4020193c:	eb0e01bf 	cmp	x13, x14
    40201940:	54000121 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201944:	8b0902ed 	add	x13, x23, x9
    40201948:	f940c9ae 	ldr	x14, [x13, #400]
    4020194c:	b10005df 	cmn	x14, #0x1
    40201950:	540000a1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201954:	f940d1ad 	ldr	x13, [x13, #416]
    40201958:	91002129 	add	x9, x9, #0x8
    4020195c:	9140116b 	add	x11, x11, #0x4, lsl #12
    40201960:	b4fff7cd 	cbz	x13, 40201858 <jnox_kernel::ordinary_reservations::irq+0x590>
    40201964:	97fffe51 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40201968:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020196c:	f942412a 	ldr	x10, [x9, #1152]
    40201970:	f100095f 	cmp	x10, #0x2
    40201974:	54ffff80 	b.eq	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.none
    40201978:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020197c:	91136129 	add	x9, x9, #0x4d8
    40201980:	39402138 	ldrb	w24, [x9, #8]
    40201984:	71000f1f 	cmp	w24, #0x3
    40201988:	54fffee0 	b.eq	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.none
    4020198c:	3941eaeb 	ldrb	w11, [x23, #122]
    40201990:	3943eaec 	ldrb	w12, [x23, #250]
    40201994:	6b0c017f 	cmp	w11, w12
    40201998:	54fffe61 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    4020199c:	f94002eb 	ldr	x11, [x23]
    402019a0:	eb0a017f 	cmp	x11, x10
    402019a4:	54fffe01 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402019a8:	d503201f 	nop
    402019ac:	1002e1b4 	adr	x20, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    402019b0:	f940028a 	ldr	x10, [x20]
    402019b4:	b4fffd8a 	cbz	x10, 40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>
    402019b8:	f9400133 	ldr	x19, [x9]
    402019bc:	f9400689 	ldr	x9, [x20, #8]
    402019c0:	eb13013f 	cmp	x9, x19
    402019c4:	54fffd01 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402019c8:	39418a89 	ldrb	w9, [x20, #98]
    402019cc:	6b09031f 	cmp	w24, w9
    402019d0:	54fffca1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402019d4:	f90017e5 	str	x5, [sp, #40]
    402019d8:	d000011d 	adrp	x29, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0xb8e0>
    402019dc:	911cc3bd 	add	x29, x29, #0x730
    402019e0:	d5033fdf 	isb
    402019e4:	d53be036 	mrs	x22, cntpct_el0
    402019e8:	f9001fb6 	str	x22, [x29, #56]
    402019ec:	f94003a9 	ldr	x9, [x29]
    402019f0:	b27f0129 	orr	x9, x9, #0x2
    402019f4:	f90003a9 	str	x9, [x29]
    402019f8:	eb1502df 	cmp	x22, x21
    402019fc:	54001c43 	b.cc	40201d84 <jnox_kernel::ordinary_reservations::irq+0xabc>  // b.lo, b.ul, b.last
    40201a00:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201a04:	9114e14a 	add	x10, x10, #0x538
    40201a08:	f9400149 	ldr	x9, [x10]
    40201a0c:	eb0902c9 	subs	x9, x22, x9
    40201a10:	54001ba3 	b.cc	40201d84 <jnox_kernel::ordinary_reservations::irq+0xabc>  // b.lo, b.ul, b.last
    40201a14:	f940094a 	ldr	x10, [x10, #16]
    40201a18:	eb0a013f 	cmp	x9, x10
    40201a1c:	54001b48 	b.hi	40201d84 <jnox_kernel::ordinary_reservations::irq+0xabc>  // b.pmore
    40201a20:	52800069 	mov	w9, #0x3                   	// #3
    40201a24:	c89ffd09 	stlr	x9, [x8]
    40201a28:	c8dffd15 	ldar	x21, [x8]
    40201a2c:	940005e6 	bl	402031c4 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    40201a30:	f9402c08 	ldr	x8, [x0, #88]
    40201a34:	39418009 	ldrb	w9, [x0, #96]
    40201a38:	d5033fdf 	isb
    40201a3c:	d53be024 	mrs	x4, cntpct_el0
    40201a40:	f94003aa 	ldr	x10, [x29]
    40201a44:	a90457a4 	stp	x4, x21, [x29, #64]
    40201a48:	71000d3f 	cmp	w9, #0x3
    40201a4c:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40201a50:	f9002ba8 	str	x8, [x29, #80]
    40201a54:	b27e0149 	orr	x9, x10, #0x4
    40201a58:	f90003a9 	str	x9, [x29]
    40201a5c:	f1000ebf 	cmp	x21, #0x3
    40201a60:	54fff821 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201a64:	eb13011f 	cmp	x8, x19
    40201a68:	54fff7e1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201a6c:	eb16009f 	cmp	x4, x22
    40201a70:	d000002e 	adrp	x14, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201a74:	9114e1ce 	add	x14, x14, #0x538
    40201a78:	54001703 	b.cc	40201d58 <jnox_kernel::ordinary_reservations::irq+0xa90>  // b.lo, b.ul, b.last
    40201a7c:	f94001c8 	ldr	x8, [x14]
    40201a80:	eb080088 	subs	x8, x4, x8
    40201a84:	540016a3 	b.cc	40201d58 <jnox_kernel::ordinary_reservations::irq+0xa90>  // b.lo, b.ul, b.last
    40201a88:	f94009c9 	ldr	x9, [x14, #16]
    40201a8c:	eb09011f 	cmp	x8, x9
    40201a90:	54001648 	b.hi	40201d58 <jnox_kernel::ordinary_reservations::irq+0xa90>  // b.pmore
    40201a94:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201a98:	f902ad1f 	str	xzr, [x8, #1368]
    40201a9c:	f100067f 	cmp	x19, #0x1
    40201aa0:	54001a68 	b.hi	40201dec <jnox_kernel::ordinary_reservations::irq+0xb24>  // b.pmore
    40201aa4:	8b131288 	add	x8, x20, x19, lsl #4
    40201aa8:	f9402108 	ldr	x8, [x8, #64]
    40201aac:	8b130ee9 	add	x9, x23, x19, lsl #3
    40201ab0:	f900c928 	str	x8, [x9, #400]
    40201ab4:	f940e12a 	ldr	x10, [x9, #448]
    40201ab8:	f940e92b 	ldr	x11, [x9, #464]
    40201abc:	a9107ef3 	stp	x19, xzr, [x23, #256]
    40201ac0:	5280002c 	mov	w12, #0x1                   	// #1
    40201ac4:	a9112aec 	stp	x12, x10, [x23, #272]
    40201ac8:	a91222eb 	stp	x11, x8, [x23, #288]
    40201acc:	3904c2f8 	strb	w24, [x23, #304]
    40201ad0:	8b130f88 	add	x8, x28, x19, lsl #3
    40201ad4:	a948aa8b 	ldp	x11, x10, [x20, #136]
    40201ad8:	c89ffd0a 	stlr	x10, [x8]
    40201adc:	91000708 	add	x8, x24, #0x1
    40201ae0:	f8337b48 	str	x8, [x26, x19, lsl #3]
    40201ae4:	f8337b7f 	str	xzr, [x27, x19, lsl #3]
    40201ae8:	8b130f28 	add	x8, x25, x19, lsl #3
    40201aec:	c89ffd1f 	stlr	xzr, [x8]
    40201af0:	a91832eb 	stp	x11, x12, [x23, #384]
    40201af4:	d51be24b 	msr	cntp_cval_el0, x11
    40201af8:	d51be22c 	msr	cntp_ctl_el0, x12
    40201afc:	d5033fdf 	isb
    40201b00:	d53be24d 	mrs	x13, cntp_cval_el0
    40201b04:	d53be228 	mrs	x8, cntp_ctl_el0
    40201b08:	d5033fdf 	isb
    40201b0c:	d53be02a 	mrs	x10, cntpct_el0
    40201b10:	a906a3ad 	stp	x13, x8, [x29, #104]
    40201b14:	a905afaa 	stp	x10, x11, [x29, #88]
    40201b18:	f94003ac 	ldr	x12, [x29]
    40201b1c:	b27d018c 	orr	x12, x12, #0x8
    40201b20:	f90003ac 	str	x12, [x29]
    40201b24:	eb0b01bf 	cmp	x13, x11
    40201b28:	54fff1e1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201b2c:	92400508 	and	x8, x8, #0x3
    40201b30:	f100051f 	cmp	x8, #0x1
    40201b34:	54fff181 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201b38:	d5033fdf 	isb
    40201b3c:	d53be028 	mrs	x8, cntpct_el0
    40201b40:	eb04015f 	cmp	x10, x4
    40201b44:	540012c3 	b.cc	40201d9c <jnox_kernel::ordinary_reservations::irq+0xad4>  // b.lo, b.ul, b.last
    40201b48:	eb0a011f 	cmp	x8, x10
    40201b4c:	54001283 	b.cc	40201d9c <jnox_kernel::ordinary_reservations::irq+0xad4>  // b.lo, b.ul, b.last
    40201b50:	f94001ca 	ldr	x10, [x14]
    40201b54:	eb0a010a 	subs	x10, x8, x10
    40201b58:	54001223 	b.cc	40201d9c <jnox_kernel::ordinary_reservations::irq+0xad4>  // b.lo, b.ul, b.last
    40201b5c:	f94009cb 	ldr	x11, [x14, #16]
    40201b60:	eb0b015f 	cmp	x10, x11
    40201b64:	540011c8 	b.hi	40201d9c <jnox_kernel::ordinary_reservations::irq+0xad4>  // b.pmore
    40201b68:	f940b536 	ldr	x22, [x9, #360]
    40201b6c:	d5033fdf 	isb
    40201b70:	d53be024 	mrs	x4, cntpct_el0
    40201b74:	f9409ee8 	ldr	x8, [x23, #312]
    40201b78:	eb080088 	subs	x8, x4, x8
    40201b7c:	54000ee3 	b.cc	40201d58 <jnox_kernel::ordinary_reservations::irq+0xa90>  // b.lo, b.ul, b.last
    40201b80:	f940a6ea 	ldr	x10, [x23, #328]
    40201b84:	eb0a011f 	cmp	x8, x10
    40201b88:	54000e88 	b.hi	40201d58 <jnox_kernel::ordinary_reservations::irq+0xa90>  // b.pmore
    40201b8c:	f900b53f 	str	xzr, [x9, #360]
    40201b90:	f900b2f3 	str	x19, [x23, #352]
    40201b94:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201b98:	91004108 	add	x8, x8, #0x10
    40201b9c:	f9407ec9 	ldr	x9, [x22, #248]
    40201ba0:	a907dba4 	stp	x4, x22, [x29, #120]
    40201ba4:	5280002a 	mov	w10, #0x1                   	// #1
    40201ba8:	a9004d1f 	stp	xzr, x19, [x8]
    40201bac:	f9408ec8 	ldr	x8, [x22, #280]
    40201bb0:	f90047a9 	str	x9, [x29, #136]
    40201bb4:	f9404ec9 	ldr	x9, [x22, #152]
    40201bb8:	a909aba8 	stp	x8, x10, [x29, #152]
    40201bbc:	f9004ba9 	str	x9, [x29, #144]
    40201bc0:	f94003a8 	ldr	x8, [x29]
    40201bc4:	b27c0108 	orr	x8, x8, #0x10
    40201bc8:	f90003a8 	str	x8, [x29]
    40201bcc:	14000051 	b	40201d10 <jnox_kernel::ordinary_reservations::irq+0xa48>
    40201bd0:	aa1303e0 	mov	x0, x19
    40201bd4:	aa1f03e1 	mov	x1, xzr
    40201bd8:	f94017f4 	ldr	x20, [sp, #40]
    40201bdc:	aa1403e2 	mov	x2, x20
    40201be0:	94000430 	bl	40202ca0 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201be4:	52800055 	mov	w21, #0x2                   	// #2
    40201be8:	1400003b 	b	40201cd4 <jnox_kernel::ordinary_reservations::irq+0xa0c>
    40201bec:	d000010a 	adrp	x10, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0xb8e0>
    40201bf0:	911cc14a 	add	x10, x10, #0x730
    40201bf4:	d53be248 	mrs	x8, cntp_cval_el0
    40201bf8:	d5033fdf 	isb
    40201bfc:	d53be029 	mrs	x9, cntpct_el0
    40201c00:	a9022157 	stp	x23, x8, [x10, #32]
    40201c04:	a9015949 	stp	x9, x22, [x10, #16]
    40201c08:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201c0c:	9114e129 	add	x9, x9, #0x538
    40201c10:	f940252b 	ldr	x11, [x9, #72]
    40201c14:	f900194b 	str	x11, [x10, #48]
    40201c18:	f940014c 	ldr	x12, [x10]
    40201c1c:	b240018c 	orr	x12, x12, #0x1
    40201c20:	a900554c 	stp	x12, x21, [x10]
    40201c24:	eb0b011f 	cmp	x8, x11
    40201c28:	54ffe9e1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201c2c:	f9400129 	ldr	x9, [x9]
    40201c30:	eb09011f 	cmp	x8, x9
    40201c34:	54ffe981 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201c38:	aa1f03f3 	mov	x19, xzr
    40201c3c:	17fffddb 	b	402013a8 <jnox_kernel::ordinary_reservations::irq+0xe0>
    40201c40:	92800008 	mov	x8, #0xffffffffffffffff    	// #-1
    40201c44:	d503201f 	nop
    40201c48:	1002d589 	adr	x9, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40201c4c:	d503201f 	nop
    40201c50:	10110d0a 	adr	x10, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40201c54:	d503201f 	nop
    40201c58:	1002d48b 	adr	x11, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40201c5c:	d503201f 	nop
    40201c60:	10110d0c 	adr	x12, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40201c64:	8b150d29 	add	x9, x9, x21, lsl #3
    40201c68:	c89ffd28 	stlr	x8, [x9]
    40201c6c:	f9400be8 	ldr	x8, [sp, #16]
    40201c70:	f8357948 	str	x8, [x10, x21, lsl #3]
    40201c74:	f835799f 	str	xzr, [x12, x21, lsl #3]
    40201c78:	8b150d68 	add	x8, x11, x21, lsl #3
    40201c7c:	c89ffd13 	stlr	x19, [x8]
    40201c80:	b100067f 	cmn	x19, #0x1
    40201c84:	54000580 	b.eq	40201d34 <jnox_kernel::ordinary_reservations::irq+0xa6c>  // b.none
    40201c88:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201c8c:	9114e129 	add	x9, x9, #0x538
    40201c90:	a9402129 	ldp	x9, x8, [x9]
    40201c94:	9100066b 	add	x11, x19, #0x1
    40201c98:	9bc87d6a 	umulh	x10, x11, x8
    40201c9c:	eb0a03ff 	cmp	xzr, x10
    40201ca0:	1a9f07ea 	cset	w10, ne  // ne = any
    40201ca4:	9b087d68 	mul	x8, x11, x8
    40201ca8:	ab090108 	adds	x8, x8, x9
    40201cac:	1a9f37e9 	cset	w9, cs  // cs = hs, nlast
    40201cb0:	3700042a 	tbnz	w10, #0, 40201d34 <jnox_kernel::ordinary_reservations::irq+0xa6c>
    40201cb4:	37000409 	tbnz	w9, #0, 40201d34 <jnox_kernel::ordinary_reservations::irq+0xa6c>
    40201cb8:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201cbc:	f942a529 	ldr	x9, [x9, #1352]
    40201cc0:	eb090102 	subs	x2, x8, x9
    40201cc4:	54000383 	b.cc	40201d34 <jnox_kernel::ordinary_reservations::irq+0xa6c>  // b.lo, b.ul, b.last
    40201cc8:	aa1303e0 	mov	x0, x19
    40201ccc:	52800021 	mov	w1, #0x1                   	// #1
    40201cd0:	940003f4 	bl	40202ca0 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201cd4:	aa1303e0 	mov	x0, x19
    40201cd8:	aa1503e1 	mov	x1, x21
    40201cdc:	9400054b 	bl	40203208 <jnox_kernel::ordinary_reservations::Runtime::select>
    40201ce0:	aa0003f6 	mov	x22, x0
    40201ce4:	d5033fdf 	isb
    40201ce8:	d53be021 	mrs	x1, cntpct_el0
    40201cec:	f9407c08 	ldr	x8, [x0, #248]
    40201cf0:	f94013e9 	ldr	x9, [sp, #32]
    40201cf4:	a909d3e9 	stp	x9, x20, [sp, #152]
    40201cf8:	a90aa3e0 	stp	x0, x8, [sp, #168]
    40201cfc:	910263e4 	add	x4, sp, #0x98
    40201d00:	528000e0 	mov	w0, #0x7                   	// #7
    40201d04:	aa1303e2 	mov	x2, x19
    40201d08:	aa1503e3 	mov	x3, x21
    40201d0c:	9400020f 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40201d10:	aa1603e0 	mov	x0, x22
    40201d14:	a9554ff4 	ldp	x20, x19, [sp, #336]
    40201d18:	a95457f6 	ldp	x22, x21, [sp, #320]
    40201d1c:	a9535ff8 	ldp	x24, x23, [sp, #304]
    40201d20:	a95267fa 	ldp	x26, x25, [sp, #288]
    40201d24:	a9516ffc 	ldp	x28, x27, [sp, #272]
    40201d28:	a9507bfd 	ldp	x29, x30, [sp, #256]
    40201d2c:	910583ff 	add	sp, sp, #0x160
    40201d30:	d65f03c0 	ret
    40201d34:	52800060 	mov	w0, #0x3                   	// #3
    40201d38:	94000568 	bl	402032d8 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    40201d3c:	f942b303 	ldr	x3, [x24, #1376]
    40201d40:	52800060 	mov	w0, #0x3                   	// #3
    40201d44:	52800081 	mov	w1, #0x4                   	// #4
    40201d48:	aa1303e2 	mov	x2, x19
    40201d4c:	aa1603e4 	mov	x4, x22
    40201d50:	aa1703e5 	mov	x5, x23
    40201d54:	94000254 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>
    40201d58:	52800040 	mov	w0, #0x2                   	// #2
    40201d5c:	528000a1 	mov	w1, #0x5                   	// #5
    40201d60:	aa1f03e2 	mov	x2, xzr
    40201d64:	52800043 	mov	w3, #0x2                   	// #2
    40201d68:	14000012 	b	40201db0 <jnox_kernel::ordinary_reservations::irq+0xae8>
    40201d6c:	52800040 	mov	w0, #0x2                   	// #2
    40201d70:	528000a1 	mov	w1, #0x5                   	// #5
    40201d74:	aa1303e2 	mov	x2, x19
    40201d78:	52800043 	mov	w3, #0x2                   	// #2
    40201d7c:	aa1503e4 	mov	x4, x21
    40201d80:	94000249 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>
    40201d84:	52800040 	mov	w0, #0x2                   	// #2
    40201d88:	528000a1 	mov	w1, #0x5                   	// #5
    40201d8c:	aa1f03e2 	mov	x2, xzr
    40201d90:	52800043 	mov	w3, #0x2                   	// #2
    40201d94:	aa1603e4 	mov	x4, x22
    40201d98:	14000006 	b	40201db0 <jnox_kernel::ordinary_reservations::irq+0xae8>
    40201d9c:	52800040 	mov	w0, #0x2                   	// #2
    40201da0:	528000a1 	mov	w1, #0x5                   	// #5
    40201da4:	aa1f03e2 	mov	x2, xzr
    40201da8:	52800043 	mov	w3, #0x2                   	// #2
    40201dac:	aa0803e4 	mov	x4, x8
    40201db0:	f94017e5 	ldr	x5, [sp, #40]
    40201db4:	9400023c 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>
    40201db8:	aa1f03e0 	mov	x0, xzr
    40201dbc:	aa1f03e1 	mov	x1, xzr
    40201dc0:	aa1303e2 	mov	x2, x19
    40201dc4:	52800043 	mov	w3, #0x2                   	// #2
    40201dc8:	aa1f03e4 	mov	x4, xzr
    40201dcc:	14000006 	b	40201de4 <jnox_kernel::ordinary_reservations::irq+0xb1c>
    40201dd0:	394283e4 	ldrb	w4, [sp, #160]
    40201dd4:	52800060 	mov	w0, #0x3                   	// #3
    40201dd8:	52800041 	mov	w1, #0x2                   	// #2
    40201ddc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201de0:	52800043 	mov	w3, #0x2                   	// #2
    40201de4:	aa1f03e5 	mov	x5, xzr
    40201de8:	9400022f 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>
    40201dec:	d503201f 	nop
    40201df0:	10020242 	adr	x2, 40205e38 <anon.d8c123e08f096c2ebe8598f45112ff88.3.llvm.6038828230051623308+0x30>
    40201df4:	aa1303e0 	mov	x0, x19
    40201df8:	14000004 	b	40201e08 <jnox_kernel::ordinary_reservations::irq+0xb40>
    40201dfc:	d503201f 	nop
    40201e00:	10020342 	adr	x2, 40205e68 <anon.d8c123e08f096c2ebe8598f45112ff88.3.llvm.6038828230051623308+0x60>
    40201e04:	aa1503e0 	mov	x0, x21
    40201e08:	52800041 	mov	w1, #0x2                   	// #2
    40201e0c:	94000b9b 	bl	40204c78 <core::panicking::panic_bounds_check>
    40201e10:	94000093 	bl	4020205c <jnox_kernel::ordinary_reservations::run::{{closure}}>

0000000040201e14 <jnox_kernel::ordinary_reservations::run>:
    40201e14:	d105c3ff 	sub	sp, sp, #0x170
    40201e18:	a9127bfd 	stp	x29, x30, [sp, #288]
    40201e1c:	a91367fa 	stp	x26, x25, [sp, #304]
    40201e20:	a9145ff8 	stp	x24, x23, [sp, #320]
    40201e24:	a91557f6 	stp	x22, x21, [sp, #336]
    40201e28:	a9164ff4 	stp	x20, x19, [sp, #352]
    40201e2c:	d5033fdf 	isb
    40201e30:	d53be038 	mrs	x24, cntpct_el0
    40201e34:	d53be014 	mrs	x20, cntfrq_el0
    40201e38:	d5033fdf 	isb
    40201e3c:	d53be028 	mrs	x8, cntpct_el0
    40201e40:	b202e7e9 	mov	x9, #0xcccccccccccccccc    	// #-3689348814741910324
    40201e44:	f29999a9 	movk	x9, #0xcccd
    40201e48:	9bc97e89 	umulh	x9, x20, x9
    40201e4c:	ab491113 	adds	x19, x8, x9, lsr #4
    40201e50:	54000043 	b.cc	40201e58 <jnox_kernel::ordinary_reservations::run+0x44>  // b.lo, b.ul, b.last
    40201e54:	94000082 	bl	4020205c <jnox_kernel::ordinary_reservations::run::{{closure}}>
    40201e58:	910223e8 	add	x8, sp, #0x88
    40201e5c:	aa1303e0 	mov	x0, x19
    40201e60:	aa1403e1 	mov	x1, x20
    40201e64:	52800022 	mov	w2, #0x1                   	// #1
    40201e68:	940007f8 	bl	40203e48 <jnox_kernel::reservation_jobs::Clock::new>
    40201e6c:	394223e8 	ldrb	w8, [sp, #136]
    40201e70:	7100051f 	cmp	w8, #0x1
    40201e74:	54000061 	b.ne	40201e80 <jnox_kernel::ordinary_reservations::run+0x6c>  // b.any
    40201e78:	394227e4 	ldrb	w4, [sp, #137]
    40201e7c:	14000015 	b	40201ed0 <jnox_kernel::ordinary_reservations::run+0xbc>
    40201e80:	a9495bf7 	ldp	x23, x22, [sp, #144]
    40201e84:	f94053f5 	ldr	x21, [sp, #160]
    40201e88:	d5033fdf 	isb
    40201e8c:	d53be021 	mrs	x1, cntpct_el0
    40201e90:	a908dbf4 	stp	x20, x22, [sp, #136]
    40201e94:	52800028 	mov	w8, #0x1                   	// #1
    40201e98:	a909a3e8 	stp	x8, x8, [sp, #152]
    40201e9c:	910223e4 	add	x4, sp, #0x88
    40201ea0:	52800020 	mov	w0, #0x1                   	// #1
    40201ea4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201ea8:	52800043 	mov	w3, #0x2                   	// #2
    40201eac:	940001a7 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40201eb0:	910223e8 	add	x8, sp, #0x88
    40201eb4:	52800020 	mov	w0, #0x1                   	// #1
    40201eb8:	52800021 	mov	w1, #0x1                   	// #1
    40201ebc:	940005fb 	bl	402036a8 <jnox_kernel::reservation_jobs::Jobs::new>
    40201ec0:	f94047e8 	ldr	x8, [sp, #136]
    40201ec4:	f100091f 	cmp	x8, #0x2
    40201ec8:	54000101 	b.ne	40201ee8 <jnox_kernel::ordinary_reservations::run+0xd4>  // b.any
    40201ecc:	394243e4 	ldrb	w4, [sp, #144]
    40201ed0:	52800060 	mov	w0, #0x3                   	// #3
    40201ed4:	52800041 	mov	w1, #0x2                   	// #2
    40201ed8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201edc:	52800043 	mov	w3, #0x2                   	// #2
    40201ee0:	aa1f03e5 	mov	x5, xzr
    40201ee4:	940001f0 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>
    40201ee8:	910023e0 	add	x0, sp, #0x8
    40201eec:	910223e1 	add	x1, sp, #0x88
    40201ef0:	52801002 	mov	w2, #0x80                  	// #128
    40201ef4:	94000eb1 	bl	402059b8 <memcpy>
    40201ef8:	d5033fdf 	isb
    40201efc:	d53be021 	mrs	x1, cntpct_el0
    40201f00:	a908cff8 	stp	x24, x19, [sp, #136]
    40201f04:	a909ffff 	stp	xzr, xzr, [sp, #152]
    40201f08:	910223e4 	add	x4, sp, #0x88
    40201f0c:	52800300 	mov	w0, #0x18                  	// #24
    40201f10:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201f14:	52800043 	mov	w3, #0x2                   	// #2
    40201f18:	9400018c 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40201f1c:	94000a14 	bl	4020476c <jnox_kernel::context::init_timer_irq>
    40201f20:	aa1f03f4 	mov	x20, xzr
    40201f24:	910423f8 	add	x24, sp, #0x108
    40201f28:	aa1403e0 	mov	x0, x20
    40201f2c:	940001a8 	bl	402025cc <jnox_kernel::ordinary_reservations::fresh>
    40201f30:	f8347b00 	str	x0, [x24, x20, lsl #3]
    40201f34:	91000694 	add	x20, x20, #0x1
    40201f38:	f1000e9f 	cmp	x20, #0x3
    40201f3c:	54ffff61 	b.ne	40201f28 <jnox_kernel::ordinary_reservations::run+0x114>  // b.any
    40201f40:	aa1f03f4 	mov	x20, xzr
    40201f44:	d503201f 	nop
    40201f48:	100abec8 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308>
    40201f4c:	52800318 	mov	w24, #0x18                  	// #24
    40201f50:	d503201f 	nop
    40201f54:	1001f479 	adr	x25, 40205de0 <anon.d8c123e08f096c2ebe8598f45112ff88.1.llvm.6038828230051623308>
    40201f58:	d5033fdf 	isb
    40201f5c:	d53be021 	mrs	x1, cntpct_el0
    40201f60:	f1000a9f 	cmp	x20, #0x2
    40201f64:	54000062 	b.cs	40201f70 <jnox_kernel::ordinary_reservations::run+0x15c>  // b.hs, b.nlast
    40201f68:	f8747b29 	ldr	x9, [x25, x20, lsl #3]
    40201f6c:	14000002 	b	40201f74 <jnox_kernel::ordinary_reservations::run+0x160>
    40201f70:	52818329 	mov	w9, #0xc19                 	// #3097
    40201f74:	9140111a 	add	x26, x8, #0x4, lsl #12
    40201f78:	a908ebe8 	stp	x8, x26, [sp, #136]
    40201f7c:	a909ffe9 	stp	x9, xzr, [sp, #152]
    40201f80:	910223e4 	add	x4, sp, #0x88
    40201f84:	52800220 	mov	w0, #0x11                  	// #17
    40201f88:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201f8c:	aa1403e3 	mov	x3, x20
    40201f90:	9400016e 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40201f94:	f1002318 	subs	x24, x24, #0x8
    40201f98:	91000694 	add	x20, x20, #0x1
    40201f9c:	aa1a03e8 	mov	x8, x26
    40201fa0:	54fffdc1 	b.ne	40201f58 <jnox_kernel::ordinary_reservations::run+0x144>  // b.any
    40201fa4:	d503201f 	nop
    40201fa8:	1002a2d4 	adr	x20, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40201fac:	910023e1 	add	x1, sp, #0x8
    40201fb0:	aa1403e0 	mov	x0, x20
    40201fb4:	52801002 	mov	w2, #0x80                  	// #128
    40201fb8:	94000e80 	bl	402059b8 <memcpy>
    40201fbc:	52800048 	mov	w8, #0x2                   	// #2
    40201fc0:	f9004288 	str	x8, [x20, #128]
    40201fc4:	52800069 	mov	w9, #0x3                   	// #3
    40201fc8:	3904c289 	strb	w9, [x20, #304]
    40201fcc:	a913da97 	stp	x23, x22, [x20, #312]
    40201fd0:	52800149 	mov	w9, #0xa                   	// #10
    40201fd4:	a914a695 	stp	x21, x9, [x20, #328]
    40201fd8:	9280000a 	mov	x10, #0xffffffffffffffff    	// #-1
    40201fdc:	a915a28a 	stp	x10, x8, [x20, #344]
    40201fe0:	a950afe8 	ldp	x8, x11, [sp, #264]
    40201fe4:	a916ae88 	stp	x8, x11, [x20, #360]
    40201fe8:	f9408fe8 	ldr	x8, [sp, #280]
    40201fec:	a917fe88 	stp	x8, xzr, [x20, #376]
    40201ff0:	a918aa9f 	stp	xzr, x10, [x20, #392]
    40201ff4:	a919fe8a 	stp	x10, xzr, [x20, #408]
    40201ff8:	52800028 	mov	w8, #0x1                   	// #1
    40201ffc:	a91aa29f 	stp	xzr, x8, [x20, #424]
    40202000:	a91bfe88 	stp	x8, xzr, [x20, #440]
    40202004:	52814328 	mov	w8, #0xa19                 	// #2585
    40202008:	a91ca29f 	stp	xzr, x8, [x20, #456]
    4020200c:	52816328 	mov	w8, #0xb19                 	// #2841
    40202010:	f900ee88 	str	x8, [x20, #472]
    40202014:	d5033fdf 	isb
    40202018:	d53be021 	mrs	x1, cntpct_el0
    4020201c:	a908a7f3 	stp	x19, x9, [sp, #136]
    40202020:	a909ffff 	stp	xzr, xzr, [sp, #152]
    40202024:	910223e4 	add	x4, sp, #0x88
    40202028:	52800040 	mov	w0, #0x2                   	// #2
    4020202c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40202030:	52800043 	mov	w3, #0x2                   	// #2
    40202034:	94000145 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202038:	94000194 	bl	40202688 <jnox_kernel::ordinary_reservations::state>
    4020203c:	aa1f03e0 	mov	x0, xzr
    40202040:	aa1f03e1 	mov	x1, xzr
    40202044:	aa1303e2 	mov	x2, x19
    40202048:	94000316 	bl	40202ca0 <jnox_kernel::ordinary_reservations::Runtime::arm>
    4020204c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    40202050:	52800041 	mov	w1, #0x2                   	// #2
    40202054:	9400046d 	bl	40203208 <jnox_kernel::ordinary_reservations::Runtime::select>
    40202058:	97fffc55 	bl	402011ac <sched_start_frame>

000000004020205c <jnox_kernel::ordinary_reservations::run::{{closure}}>:
    4020205c:	f81f0ffe 	str	x30, [sp, #-16]!
    40202060:	97fffc92 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

0000000040202064 <jnox_kernel::ordinary_reservations::svc>:
    40202064:	f81f0ffe 	str	x30, [sp, #-16]!
    40202068:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020206c:	f9420108 	ldr	x8, [x8, #1024]
    40202070:	f100091f 	cmp	x8, #0x2
    40202074:	54000660 	b.eq	40202140 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.none
    40202078:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020207c:	f942b108 	ldr	x8, [x8, #1376]
    40202080:	d503201f 	nop
    40202084:	100ab4e9 	adr	x9, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308>
    40202088:	f100091f 	cmp	x8, #0x2
    4020208c:	8b08392a 	add	x10, x9, x8, lsl #14
    40202090:	fa401142 	ccmp	x10, x0, #0x2, ne  // ne = any
    40202094:	54000568 	b.hi	40202140 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    40202098:	b10d041f 	cmn	x0, #0x341
    4020209c:	54000528 	b.hi	40202140 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    402020a0:	d372c508 	lsl	x8, x8, #14
    402020a4:	8b080128 	add	x8, x9, x8
    402020a8:	91401108 	add	x8, x8, #0x4, lsl #12
    402020ac:	910d0009 	add	x9, x0, #0x340
    402020b0:	eb08013f 	cmp	x9, x8
    402020b4:	54000468 	b.hi	40202140 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    402020b8:	f9409c01 	ldr	x1, [x0, #312]
    402020bc:	d5385203 	mrs	x3, esr_el1
    402020c0:	d35afc68 	lsr	x8, x3, #26
    402020c4:	f100551f 	cmp	x8, #0x15
    402020c8:	540003c1 	b.ne	40202140 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.any
    402020cc:	12003c68 	and	w8, w3, #0xffff
    402020d0:	7100051f 	cmp	w8, #0x1
    402020d4:	540000a0 	b.eq	402020e8 <jnox_kernel::ordinary_reservations::svc+0x84>  // b.none
    402020d8:	7100091f 	cmp	w8, #0x2
    402020dc:	54000321 	b.ne	40202140 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.any
    402020e0:	52800042 	mov	w2, #0x2                   	// #2
    402020e4:	14000002 	b	402020ec <jnox_kernel::ordinary_reservations::svc+0x88>
    402020e8:	52800022 	mov	w2, #0x1                   	// #1
    402020ec:	9400030e 	bl	40202d24 <jnox_kernel::ordinary_reservations::Runtime::close>
    402020f0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402020f4:	9114e108 	add	x8, x8, #0x538
    402020f8:	f9401100 	ldr	x0, [x8, #32]
    402020fc:	91000409 	add	x9, x0, #0x1
    40202100:	a9402908 	ldp	x8, x10, [x8]
    40202104:	9bca7d2b 	umulh	x11, x9, x10
    40202108:	eb0b03ff 	cmp	xzr, x11
    4020210c:	1a9f07eb 	cset	w11, ne  // ne = any
    40202110:	9b0a7d29 	mul	x9, x9, x10
    40202114:	ab080122 	adds	x2, x9, x8
    40202118:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    4020211c:	3700014b 	tbnz	w11, #0, 40202144 <jnox_kernel::ordinary_reservations::svc+0xe0>
    40202120:	35000128 	cbnz	w8, 40202144 <jnox_kernel::ordinary_reservations::svc+0xe0>
    40202124:	aa1f03e1 	mov	x1, xzr
    40202128:	940002de 	bl	40202ca0 <jnox_kernel::ordinary_reservations::Runtime::arm>
    4020212c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202130:	f942ad00 	ldr	x0, [x8, #1368]
    40202134:	52800041 	mov	w1, #0x2                   	// #2
    40202138:	f84107fe 	ldr	x30, [sp], #16
    4020213c:	14000433 	b	40203208 <jnox_kernel::ordinary_reservations::Runtime::select>
    40202140:	97fffc5a 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40202144:	52800060 	mov	w0, #0x3                   	// #3
    40202148:	94000464 	bl	402032d8 <jnox_kernel::ordinary_reservations::checked::{{closure}}>

000000004020214c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308>:
    4020214c:	d10743ff 	sub	sp, sp, #0x1d0
    40202150:	a9177bfd 	stp	x29, x30, [sp, #368]
    40202154:	a9186ffc 	stp	x28, x27, [sp, #384]
    40202158:	a91967fa 	stp	x26, x25, [sp, #400]
    4020215c:	a91a5ff8 	stp	x24, x23, [sp, #416]
    40202160:	a91b57f6 	stp	x22, x21, [sp, #432]
    40202164:	a91c4ff4 	stp	x20, x19, [sp, #448]
    40202168:	d50342df 	msr	daifset, #0x2
    4020216c:	d5033fdf 	isb
    40202170:	d5033fdf 	isb
    40202174:	d53be036 	mrs	x22, cntpct_el0
    40202178:	b0000035 	adrp	x21, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020217c:	f94202a8 	ldr	x8, [x21, #1024]
    40202180:	f100091f 	cmp	x8, #0x2
    40202184:	54001ac0 	b.eq	402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>  // b.none
    40202188:	d5033fdf 	isb
    4020218c:	d53be038 	mrs	x24, cntpct_el0
    40202190:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202194:	f942f108 	ldr	x8, [x8, #1504]
    40202198:	f100091f 	cmp	x8, #0x2
    4020219c:	54001a01 	b.ne	402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>  // b.any
    402021a0:	b0000037 	adrp	x23, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021a4:	f9429ef3 	ldr	x19, [x23, #1336]
    402021a8:	d503201f 	nop
    402021ac:	1010b1a8 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    402021b0:	c8dffd08 	ldar	x8, [x8]
    402021b4:	b5001948 	cbnz	x8, 402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>
    402021b8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021bc:	91156108 	add	x8, x8, #0x558
    402021c0:	f9400109 	ldr	x9, [x8]
    402021c4:	b100053f 	cmn	x9, #0x1
    402021c8:	540018a1 	b.ne	402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>  // b.any
    402021cc:	f9400508 	ldr	x8, [x8, #8]
    402021d0:	f100091f 	cmp	x8, #0x2
    402021d4:	54001841 	b.ne	402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>  // b.any
    402021d8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021dc:	9114c108 	add	x8, x8, #0x530
    402021e0:	39400109 	ldrb	w9, [x8]
    402021e4:	71000d3f 	cmp	w9, #0x3
    402021e8:	540017a1 	b.ne	402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>  // b.any
    402021ec:	f9402d09 	ldr	x9, [x8, #88]
    402021f0:	b5001769 	cbnz	x9, 402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>
    402021f4:	f9402908 	ldr	x8, [x8, #80]
    402021f8:	eb13011f 	cmp	x8, x19
    402021fc:	54001701 	b.ne	402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>  // b.any
    40202200:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0xb8e0>
    40202204:	f943f508 	ldr	x8, [x8, #2024]
    40202208:	f100051f 	cmp	x8, #0x1
    4020220c:	54001681 	b.ne	402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>  // b.any
    40202210:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202214:	f9423508 	ldr	x8, [x8, #1128]
    40202218:	b5001628 	cbnz	x8, 402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>
    4020221c:	5280002a 	mov	w10, #0x1                   	// #1
    40202220:	d503201f 	nop
    40202224:	10028ef9 	adr	x25, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40202228:	8b080328 	add	x8, x25, x8
    4020222c:	3941e109 	ldrb	w9, [x8, #120]
    40202230:	3600008a 	tbz	w10, #0, 40202240 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0xf4>
    40202234:	2a1f03ea 	mov	w10, wzr
    40202238:	52800028 	mov	w8, #0x1                   	// #1
    4020223c:	34ffff69 	cbz	w9, 40202228 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0xdc>
    40202240:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202244:	39518108 	ldrb	w8, [x8, #1120]
    40202248:	7100013f 	cmp	w9, #0x0
    4020224c:	7a430900 	ccmp	w8, #0x3, #0x0, eq  // eq = none
    40202250:	54001461 	b.ne	402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>  // b.any
    40202254:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202258:	9111c108 	add	x8, x8, #0x470
    4020225c:	f9400109 	ldr	x9, [x8]
    40202260:	b50013e9 	cbnz	x9, 402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>
    40202264:	f9400908 	ldr	x8, [x8, #16]
    40202268:	f100091f 	cmp	x8, #0x2
    4020226c:	54001381 	b.ne	402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>  // b.any
    40202270:	f94202a8 	ldr	x8, [x21, #1024]
    40202274:	f100051f 	cmp	x8, #0x1
    40202278:	54000121 	b.ne	4020229c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x150>  // b.any
    4020227c:	b0000021 	adrp	x1, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202280:	91102021 	add	x1, x1, #0x408
    40202284:	f940183a 	ldr	x26, [x1, #48]
    40202288:	910243e0 	add	x0, sp, #0x90
    4020228c:	52800602 	mov	w2, #0x30                  	// #48
    40202290:	94000dca 	bl	402059b8 <memcpy>
    40202294:	52800028 	mov	w8, #0x1                   	// #1
    40202298:	14000017 	b	402022f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x1a8>
    4020229c:	910303e0 	add	x0, sp, #0xc0
    402022a0:	9100a014 	add	x20, x0, #0x28
    402022a4:	52800028 	mov	w8, #0x1                   	// #1
    402022a8:	b0000021 	adrp	x1, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402022ac:	91102021 	add	x1, x1, #0x408
    402022b0:	2a0803fa 	mov	w26, w8
    402022b4:	9100a03b 	add	x27, x1, #0x28
    402022b8:	52800502 	mov	w2, #0x28                  	// #40
    402022bc:	94000dbf 	bl	402059b8 <memcpy>
    402022c0:	2a1f03e8 	mov	w8, wzr
    402022c4:	aa1b03e1 	mov	x1, x27
    402022c8:	aa1403e0 	mov	x0, x20
    402022cc:	3707ff3a 	tbnz	w26, #0, 402022b0 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x164>
    402022d0:	910243e0 	add	x0, sp, #0x90
    402022d4:	910303e1 	add	x1, sp, #0xc0
    402022d8:	52800602 	mov	w2, #0x30                  	// #48
    402022dc:	94000db7 	bl	402059b8 <memcpy>
    402022e0:	aa1f03e8 	mov	x8, xzr
    402022e4:	a94f27fa 	ldp	x26, x9, [sp, #240]
    402022e8:	a9502fea 	ldp	x10, x11, [sp, #256]
    402022ec:	a907abe9 	stp	x9, x10, [sp, #120]
    402022f0:	f90047eb 	str	x11, [sp, #136]
    402022f4:	b000003b 	adrp	x27, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402022f8:	9111e37b 	add	x27, x27, #0x478
    402022fc:	39400b7c 	ldrb	w28, [x27, #2]
    40202300:	7940037d 	ldrh	w29, [x27]
    40202304:	aa1b03f4 	mov	x20, x27
    40202308:	f8008e88 	str	x8, [x20, #8]!
    4020230c:	91004360 	add	x0, x27, #0x10
    40202310:	910243e1 	add	x1, sp, #0x90
    40202314:	52800602 	mov	w2, #0x30                  	// #48
    40202318:	94000da8 	bl	402059b8 <memcpy>
    4020231c:	52800068 	mov	w8, #0x3                   	// #3
    40202320:	3901a368 	strb	w8, [x27, #104]
    40202324:	a947a7e8 	ldp	x8, x9, [sp, #120]
    40202328:	a904237a 	stp	x26, x8, [x27, #64]
    4020232c:	f94047e8 	ldr	x8, [sp, #136]
    40202330:	a9052369 	stp	x9, x8, [x27, #80]
    40202334:	a9077f7f 	stp	xzr, xzr, [x27, #112]
    40202338:	7901037d 	strh	w29, [x27, #128]
    4020233c:	39020b7c 	strb	w28, [x27, #130]
    40202340:	910303e8 	add	x8, sp, #0xc0
    40202344:	aa1403e0 	mov	x0, x20
    40202348:	94000467 	bl	402034e4 <jnox_kernel::reservation_jobs::Jobs::prepare_destination>
    4020234c:	f94063e8 	ldr	x8, [sp, #192]
    40202350:	f100091f 	cmp	x8, #0x2
    40202354:	54000cc0 	b.eq	402024ec <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x3a0>  // b.none
    40202358:	910043e0 	add	x0, sp, #0x10
    4020235c:	910303e1 	add	x1, sp, #0xc0
    40202360:	52800d02 	mov	w2, #0x68                  	// #104
    40202364:	94000d95 	bl	402059b8 <memcpy>
    40202368:	b0000020 	adrp	x0, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020236c:	91120000 	add	x0, x0, #0x480
    40202370:	910043e1 	add	x1, sp, #0x10
    40202374:	94000473 	bl	40203540 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision>
    40202378:	36000b20 	tbz	w0, #0, 402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>
    4020237c:	b94013e8 	ldr	w8, [sp, #16]
    40202380:	36000b48 	tbz	w8, #0, 402024e8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x39c>
    40202384:	3941cbe8 	ldrb	w8, [sp, #114]
    40202388:	34000188 	cbz	w8, 402023b8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x26c>
    4020238c:	71000d1f 	cmp	w8, #0x3
    40202390:	54000a60 	b.eq	402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>  // b.none
    40202394:	f9400fe0 	ldr	x0, [sp, #24]
    40202398:	f100041f 	cmp	x0, #0x1
    4020239c:	54000ce8 	b.hi	40202538 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x3ec>  // b.pmore
    402023a0:	8b000f28 	add	x8, x25, x0, lsl #3
    402023a4:	f940e108 	ldr	x8, [x8, #448]
    402023a8:	b104011f 	cmn	x8, #0x100
    402023ac:	540009e2 	b.cs	402024e8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x39c>  // b.hs, b.nlast
    402023b0:	9104011a 	add	x26, x8, #0x100
    402023b4:	14000002 	b	402023bc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x270>
    402023b8:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    402023bc:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402023c0:	9114e108 	add	x8, x8, #0x538
    402023c4:	a9402508 	ldp	x8, x9, [x8]
    402023c8:	ab09011b 	adds	x27, x8, x9
    402023cc:	540008a2 	b.cs	402024e0 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x394>  // b.hs, b.nlast
    402023d0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402023d4:	f942a508 	ldr	x8, [x8, #1352]
    402023d8:	eb08037c 	subs	x28, x27, x8
    402023dc:	54000823 	b.cc	402024e0 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x394>  // b.lo, b.ul, b.last
    402023e0:	f9009bf9 	str	x25, [sp, #304]
    402023e4:	910303f4 	add	x20, sp, #0xc0
    402023e8:	9104e3e8 	add	x8, sp, #0x138
    402023ec:	9104c3e0 	add	x0, sp, #0x130
    402023f0:	aa1f03e1 	mov	x1, xzr
    402023f4:	94000702 	bl	40203ffc <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    402023f8:	910303e0 	add	x0, sp, #0xc0
    402023fc:	9104e3e1 	add	x1, sp, #0x138
    40202400:	52800702 	mov	w2, #0x38                  	// #56
    40202404:	94000d6d 	bl	402059b8 <memcpy>
    40202408:	9104e3e8 	add	x8, sp, #0x138
    4020240c:	9104c3e0 	add	x0, sp, #0x130
    40202410:	52800021 	mov	w1, #0x1                   	// #1
    40202414:	940006fa 	bl	40203ffc <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    40202418:	9100e280 	add	x0, x20, #0x38
    4020241c:	9104e3e1 	add	x1, sp, #0x138
    40202420:	52800702 	mov	w2, #0x38                  	// #56
    40202424:	94000d65 	bl	402059b8 <memcpy>
    40202428:	d503201f 	nop
    4020242c:	10028db4 	adr	x20, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    40202430:	910043e1 	add	x1, sp, #0x10
    40202434:	aa1403e0 	mov	x0, x20
    40202438:	52800d02 	mov	w2, #0x68                  	// #104
    4020243c:	94000d5f 	bl	402059b8 <memcpy>
    40202440:	52800088 	mov	w8, #0x4                   	// #4
    40202444:	a906a298 	stp	x24, x8, [x20, #104]
    40202448:	a907ee93 	stp	x19, x27, [x20, #120]
    4020244c:	a908ea9c 	stp	x28, x26, [x20, #136]
    40202450:	91026280 	add	x0, x20, #0x98
    40202454:	910303e1 	add	x1, sp, #0xc0
    40202458:	52800e02 	mov	w2, #0x70                  	// #112
    4020245c:	94000d57 	bl	402059b8 <memcpy>
    40202460:	d5033fdf 	isb
    40202464:	d53be034 	mrs	x20, cntpct_el0
    40202468:	eb140268 	subs	x8, x19, x20
    4020246c:	9a8833e8 	csel	x8, xzr, x8, cc  // cc = lo, ul, last
    40202470:	a913cff8 	stp	x24, x19, [sp, #312]
    40202474:	a914ffe8 	stp	x8, xzr, [sp, #328]
    40202478:	9104e3e4 	add	x4, sp, #0x138
    4020247c:	528002c0 	mov	w0, #0x16                  	// #22
    40202480:	aa1403e1 	mov	x1, x20
    40202484:	aa1f03e2 	mov	x2, xzr
    40202488:	52800043 	mov	w3, #0x2                   	// #2
    4020248c:	9400002f 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202490:	eb18029f 	cmp	x20, x24
    40202494:	540003a3 	b.cc	40202508 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x3bc>  // b.lo, b.ul, b.last
    40202498:	eb13029f 	cmp	x20, x19
    4020249c:	54000362 	b.cs	40202508 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x3bc>  // b.hs, b.nlast
    402024a0:	d5033fdf 	isb
    402024a4:	d53be024 	mrs	x4, cntpct_el0
    402024a8:	d503201f 	nop
    402024ac:	101093a8 	adr	x8, 40223720 <jnox_kernel::ordinary_reservations::RECEIPT>
    402024b0:	a9001116 	stp	x22, x4, [x8]
    402024b4:	f94202a8 	ldr	x8, [x21, #1024]
    402024b8:	f100091f 	cmp	x8, #0x2
    402024bc:	54000100 	b.eq	402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x390>  // b.none
    402024c0:	f9429ee5 	ldr	x5, [x23, #1336]
    402024c4:	eb05009f 	cmp	x4, x5
    402024c8:	540002e2 	b.cs	40202524 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x3d8>  // b.hs, b.nlast
    402024cc:	d50342ff 	msr	daifclr, #0x2
    402024d0:	d5033fdf 	isb
    402024d4:	d503207f 	wfi
    402024d8:	17ffffff 	b	402024d4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308+0x388>
    402024dc:	97fffb73 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402024e0:	52800060 	mov	w0, #0x3                   	// #3
    402024e4:	9400037d 	bl	402032d8 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    402024e8:	97fffedd 	bl	4020205c <jnox_kernel::ordinary_reservations::run::{{closure}}>
    402024ec:	394323e4 	ldrb	w4, [sp, #200]
    402024f0:	52800060 	mov	w0, #0x3                   	// #3
    402024f4:	52800041 	mov	w1, #0x2                   	// #2
    402024f8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    402024fc:	52800043 	mov	w3, #0x2                   	// #2
    40202500:	aa1f03e5 	mov	x5, xzr
    40202504:	94000068 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>
    40202508:	52800040 	mov	w0, #0x2                   	// #2
    4020250c:	52800121 	mov	w1, #0x9                   	// #9
    40202510:	aa1f03e2 	mov	x2, xzr
    40202514:	52800043 	mov	w3, #0x2                   	// #2
    40202518:	aa1403e4 	mov	x4, x20
    4020251c:	aa1303e5 	mov	x5, x19
    40202520:	94000061 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>
    40202524:	52800040 	mov	w0, #0x2                   	// #2
    40202528:	52800161 	mov	w1, #0xb                   	// #11
    4020252c:	aa1f03e2 	mov	x2, xzr
    40202530:	52800043 	mov	w3, #0x2                   	// #2
    40202534:	9400005c 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>
    40202538:	d503201f 	nop
    4020253c:	1001c8a2 	adr	x2, 40205e50 <anon.d8c123e08f096c2ebe8598f45112ff88.3.llvm.6038828230051623308+0x48>
    40202540:	52800041 	mov	w1, #0x2                   	// #2
    40202544:	940009cd 	bl	40204c78 <core::panicking::panic_bounds_check>

0000000040202548 <jnox_kernel::ordinary_reservations::event>:
    40202548:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020254c:	f9438909 	ldr	x9, [x8, #1808]
    40202550:	f110013f 	cmp	x9, #0x400
    40202554:	54000241 	b.ne	4020259c <jnox_kernel::ordinary_reservations::event+0x54>  // b.any
    40202558:	aa1f03e8 	mov	x8, xzr
    4020255c:	52800309 	mov	w9, #0x18                  	// #24
    40202560:	72a12009 	movk	w9, #0x900, lsl #16
    40202564:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    40202568:	d503201f 	nop
    4020256c:	1001c42b 	adr	x11, 40205df0 <anon.d8c123e08f096c2ebe8598f45112ff88.1.llvm.6038828230051623308+0x10>
    40202570:	3868696c 	ldrb	w12, [x11, x8]
    40202574:	b940012d 	ldr	w13, [x9]
    40202578:	3628006d 	tbz	w13, #5, 40202584 <jnox_kernel::ordinary_reservations::event+0x3c>
    4020257c:	d5033fdf 	isb
    40202580:	17fffffd 	b	40202574 <jnox_kernel::ordinary_reservations::event+0x2c>
    40202584:	91000508 	add	x8, x8, #0x1
    40202588:	b900014c 	str	w12, [x10]
    4020258c:	f100511f 	cmp	x8, #0x14
    40202590:	54ffff01 	b.ne	40202570 <jnox_kernel::ordinary_reservations::event+0x28>  // b.any
    40202594:	d503205f 	wfe
    40202598:	17ffffff 	b	40202594 <jnox_kernel::ordinary_reservations::event+0x4c>
    4020259c:	d503201f 	nop
    402025a0:	10028bca 	adr	x10, 40207718 <jnox_kernel::ordinary_reservations::TRACE>
    402025a4:	8b09194a 	add	x10, x10, x9, lsl #6
    402025a8:	a9000540 	stp	x0, x1, [x10]
    402025ac:	a940308b 	ldp	x11, x12, [x4]
    402025b0:	a9010d42 	stp	x2, x3, [x10, #16]
    402025b4:	a941388d 	ldp	x13, x14, [x4, #16]
    402025b8:	a902314b 	stp	x11, x12, [x10, #32]
    402025bc:	a903394d 	stp	x13, x14, [x10, #48]
    402025c0:	91000529 	add	x9, x9, #0x1
    402025c4:	f9038909 	str	x9, [x8, #1808]
    402025c8:	d65f03c0 	ret

00000000402025cc <jnox_kernel::ordinary_reservations::fresh>:
    402025cc:	d10143ff 	sub	sp, sp, #0x50
    402025d0:	a90357f6 	stp	x22, x21, [sp, #48]
    402025d4:	a9044ff4 	stp	x20, x19, [sp, #64]
    402025d8:	aa0003f3 	mov	x19, x0
    402025dc:	d503201f 	nop
    402025e0:	10007768 	adr	x8, 402034cc <reservation_worker_a>
    402025e4:	d503201f 	nop
    402025e8:	10007789 	adr	x9, 402034d8 <reservation_worker_b>
    402025ec:	d503201f 	nop
    402025f0:	10ffdaea 	adr	x10, 4020214c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.6038828230051623308>
    402025f4:	a900a7e8 	stp	x8, x9, [sp, #8]
    402025f8:	a901fbea 	stp	x10, x30, [sp, #24]
    402025fc:	f100081f 	cmp	x0, #0x2
    40202600:	540003a8 	b.hi	40202674 <jnox_kernel::ordinary_reservations::fresh+0xa8>  // b.pmore
    40202604:	910023e8 	add	x8, sp, #0x8
    40202608:	f8737915 	ldr	x21, [x8, x19, lsl #3]
    4020260c:	d503201f 	nop
    40202610:	100a8888 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308>
    40202614:	8b133916 	add	x22, x8, x19, lsl #14
    40202618:	52879808 	mov	w8, #0x3cc0                	// #15552
    4020261c:	8b0802d4 	add	x20, x22, x8
    40202620:	aa1403e0 	mov	x0, x20
    40202624:	2a1f03e1 	mov	w1, wzr
    40202628:	52806802 	mov	w2, #0x340                 	// #832
    4020262c:	94000d6f 	bl	40205be8 <memset>
    40202630:	f91eded5 	str	x21, [x22, #15800]
    40202634:	528068a8 	mov	w8, #0x345                 	// #837
    40202638:	f91ee2c8 	str	x8, [x22, #15808]
    4020263c:	f1000a7f 	cmp	x19, #0x2
    40202640:	54000061 	b.ne	4020264c <jnox_kernel::ordinary_reservations::fresh+0x80>  // b.any
    40202644:	52818328 	mov	w8, #0xc19                 	// #3097
    40202648:	14000004 	b	40202658 <jnox_kernel::ordinary_reservations::fresh+0x8c>
    4020264c:	d503201f 	nop
    40202650:	1001bc88 	adr	x8, 40205de0 <anon.d8c123e08f096c2ebe8598f45112ff88.1.llvm.6038828230051623308>
    40202654:	f8737908 	ldr	x8, [x8, x19, lsl #3]
    40202658:	f9008e88 	str	x8, [x20, #280]
    4020265c:	aa1403e0 	mov	x0, x20
    40202660:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40202664:	a94357f6 	ldp	x22, x21, [sp, #48]
    40202668:	f94013fe 	ldr	x30, [sp, #32]
    4020266c:	910143ff 	add	sp, sp, #0x50
    40202670:	d65f03c0 	ret
    40202674:	d503201f 	nop
    40202678:	1001bc82 	adr	x2, 40205e08 <anon.d8c123e08f096c2ebe8598f45112ff88.3.llvm.6038828230051623308>
    4020267c:	aa1303e0 	mov	x0, x19
    40202680:	52800061 	mov	w1, #0x3                   	// #3
    40202684:	9400097d 	bl	40204c78 <core::panicking::panic_bounds_check>

0000000040202688 <jnox_kernel::ordinary_reservations::state>:
    40202688:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020268c:	f9420108 	ldr	x8, [x8, #1024]
    40202690:	f100091f 	cmp	x8, #0x2
    40202694:	54000040 	b.eq	4020269c <jnox_kernel::ordinary_reservations::state+0x14>  // b.none
    40202698:	d65f03c0 	ret
    4020269c:	f81f0ffe 	str	x30, [sp, #-16]!
    402026a0:	97fffb02 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

00000000402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>:
    402026a4:	d10603ff 	sub	sp, sp, #0x180
    402026a8:	a9127bfd 	stp	x29, x30, [sp, #288]
    402026ac:	a9136ffc 	stp	x28, x27, [sp, #304]
    402026b0:	a91467fa 	stp	x26, x25, [sp, #320]
    402026b4:	a9155ff8 	stp	x24, x23, [sp, #336]
    402026b8:	a91657f6 	stp	x22, x21, [sp, #352]
    402026bc:	a9174ff4 	stp	x20, x19, [sp, #368]
    402026c0:	d5034fdf 	msr	daifset, #0xf
    402026c4:	d51be23f 	msr	cntp_ctl_el0, xzr
    402026c8:	d5033fdf 	isb
    402026cc:	b0000109 	adrp	x9, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0xb8e0>
    402026d0:	395f6128 	ldrb	w8, [x9, #2008]
    402026d4:	7100051f 	cmp	w8, #0x1
    402026d8:	54000061 	b.ne	402026e4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x40>  // b.any
    402026dc:	d503205f 	wfe
    402026e0:	17ffffff 	b	402026dc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x38>
    402026e4:	aa0103ec 	mov	x12, x1
    402026e8:	d503201f 	nop
    402026ec:	101081aa 	adr	x10, 40223720 <jnox_kernel::ordinary_reservations::RECEIPT>
    402026f0:	5280002b 	mov	w11, #0x1                   	// #1
    402026f4:	a9400548 	ldp	x8, x1, [x10]
    402026f8:	391f612b 	strb	w11, [x9, #2008]
    402026fc:	a9415558 	ldp	x24, x21, [x10, #16]
    40202700:	a9424d54 	ldp	x20, x19, [x10, #32]
    40202704:	a943694b 	ldp	x11, x26, [x10, #48]
    40202708:	a9447149 	ldp	x9, x28, [x10, #64]
    4020270c:	a9012fe9 	stp	x9, x11, [sp, #16]
    40202710:	a945755b 	ldp	x27, x29, [x10, #80]
    40202714:	a9464549 	ldp	x9, x17, [x10, #96]
    40202718:	f9005be9 	str	x9, [sp, #176]
    4020271c:	a9474946 	ldp	x6, x18, [x10, #112]
    40202720:	a9482d47 	ldp	x7, x11, [x10, #128]
    40202724:	a949394d 	ldp	x13, x14, [x10, #144]
    40202728:	a94a414f 	ldp	x15, x16, [x10, #160]
    4020272c:	f940594a 	ldr	x10, [x10, #176]
    40202730:	d5033fdf 	isb
    40202734:	d53be039 	mrs	x25, cntpct_el0
    40202738:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020273c:	d503201f 	nop
    40202740:	10027516 	adr	x22, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    40202744:	f942f137 	ldr	x23, [x9, #1504]
    40202748:	a90a0fe2 	stp	x2, x3, [sp, #160]
    4020274c:	a90917e4 	stp	x4, x5, [sp, #144]
    40202750:	a90833e0 	stp	x0, x12, [sp, #128]
    40202754:	a9072fea 	stp	x10, x11, [sp, #112]
    40202758:	a90637ee 	stp	x14, x13, [sp, #96]
    4020275c:	a9053ff0 	stp	x16, x15, [sp, #80]
    40202760:	a90447f2 	stp	x18, x17, [sp, #64]
    40202764:	a9031be7 	stp	x7, x6, [sp, #48]
    40202768:	a9026ffc 	stp	x28, x27, [sp, #32]
    4020276c:	b40001a1 	cbz	x1, 402027a0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0xfc>
    40202770:	f9403ec9 	ldr	x9, [x22, #120]
    40202774:	f1000aff 	cmp	x23, #0x2
    40202778:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    4020277c:	a90b87e8 	stp	x8, x1, [sp, #184]
    40202780:	a90cffe9 	stp	x9, xzr, [sp, #200]
    40202784:	9102e3e4 	add	x4, sp, #0xb8
    40202788:	52800480 	mov	w0, #0x24                  	// #36
    4020278c:	aa1f03e2 	mov	x2, xzr
    40202790:	52800043 	mov	w3, #0x2                   	// #2
    40202794:	97ffff6d 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202798:	f94002c8 	ldr	x8, [x22]
    4020279c:	14000002 	b	402027a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x100>
    402027a0:	aa1703e8 	mov	x8, x23
    402027a4:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402027a8:	9117a129 	add	x9, x9, #0x5e8
    402027ac:	f940012a 	ldr	x10, [x9]
    402027b0:	7200011f 	tst	w8, #0x1
    402027b4:	52800048 	mov	w8, #0x2                   	// #2
    402027b8:	f9403529 	ldr	x9, [x9, #104]
    402027bc:	9a881148 	csel	x8, x10, x8, ne  // ne = any
    402027c0:	f1000aff 	cmp	x23, #0x2
    402027c4:	da9f113b 	csinv	x27, x9, xzr, ne  // ne = any
    402027c8:	9a8802fc 	csel	x28, x23, x8, eq  // eq = none
    402027cc:	d503201f 	nop
    402027d0:	10108088 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    402027d4:	c8dffd08 	ldar	x8, [x8]
    402027d8:	a90be3fb 	stp	x27, x24, [sp, #184]
    402027dc:	f27e031f 	tst	x24, #0x4
    402027e0:	f9405be9 	ldr	x9, [sp, #176]
    402027e4:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    402027e8:	a90ca7e8 	stp	x8, x9, [sp, #200]
    402027ec:	9102e3e4 	add	x4, sp, #0xb8
    402027f0:	52800300 	mov	w0, #0x18                  	// #24
    402027f4:	aa1903e1 	mov	x1, x25
    402027f8:	aa1f03e2 	mov	x2, xzr
    402027fc:	aa1c03e3 	mov	x3, x28
    40202800:	97ffff52 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202804:	37001d78 	tbnz	w24, #0, 40202bb0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x50c>
    40202808:	37081f98 	tbnz	w24, #1, 40202bf8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x554>
    4020280c:	37102118 	tbnz	w24, #2, 40202c2c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x588>
    40202810:	37182278 	tbnz	w24, #3, 40202c5c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x5b8>
    40202814:	36200378 	tbz	w24, #4, 40202880 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x1dc>
    40202818:	a94627e8 	ldp	x8, x9, [sp, #96]
    4020281c:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202820:	a94527e8 	ldp	x8, x9, [sp, #80]
    40202824:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202828:	9102e3e4 	add	x4, sp, #0xb8
    4020282c:	528003a0 	mov	w0, #0x1d                  	// #29
    40202830:	f9403ff3 	ldr	x19, [sp, #120]
    40202834:	aa1303e1 	mov	x1, x19
    40202838:	aa1f03e2 	mov	x2, xzr
    4020283c:	aa1c03e3 	mov	x3, x28
    40202840:	97ffff42 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202844:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202848:	91196108 	add	x8, x8, #0x658
    4020284c:	a9402109 	ldp	x9, x8, [x8]
    40202850:	f1000aff 	cmp	x23, #0x2
    40202854:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    40202858:	f9403bea 	ldr	x10, [sp, #112]
    4020285c:	a90ba7ea 	stp	x10, x9, [sp, #184]
    40202860:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40202864:	a90cefe8 	stp	x8, x27, [sp, #200]
    40202868:	9102e3e4 	add	x4, sp, #0xb8
    4020286c:	528003c0 	mov	w0, #0x1e                  	// #30
    40202870:	aa1303e1 	mov	x1, x19
    40202874:	aa1f03e2 	mov	x2, xzr
    40202878:	aa1c03e3 	mov	x3, x28
    4020287c:	97ffff33 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202880:	f1000aff 	cmp	x23, #0x2
    40202884:	54000800 	b.eq	40202984 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x2e0>  // b.none
    40202888:	aa1f03f3 	mov	x19, xzr
    4020288c:	52800028 	mov	w8, #0x1                   	// #1
    40202890:	52800714 	mov	w20, #0x38                  	// #56
    40202894:	9b145a77 	madd	x23, x19, x20, x22
    40202898:	2a0803f5 	mov	w21, w8
    4020289c:	a949a6e8 	ldp	x8, x9, [x23, #152]
    402028a0:	f94056ea 	ldr	x10, [x23, #168]
    402028a4:	a90ba7e8 	stp	x8, x9, [sp, #184]
    402028a8:	f9405ee8 	ldr	x8, [x23, #184]
    402028ac:	a90ca3ea 	stp	x10, x8, [sp, #200]
    402028b0:	9102e3e4 	add	x4, sp, #0xb8
    402028b4:	52800440 	mov	w0, #0x22                  	// #34
    402028b8:	aa1903e1 	mov	x1, x25
    402028bc:	aa1f03e2 	mov	x2, xzr
    402028c0:	aa1303e3 	mov	x3, x19
    402028c4:	97ffff21 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    402028c8:	f9405ae8 	ldr	x8, [x23, #176]
    402028cc:	a94c2ae9 	ldp	x9, x10, [x23, #192]
    402028d0:	a90ba7e8 	stp	x8, x9, [sp, #184]
    402028d4:	f9404ac8 	ldr	x8, [x22, #144]
    402028d8:	a90ca3ea 	stp	x10, x8, [sp, #200]
    402028dc:	9102e3e4 	add	x4, sp, #0xb8
    402028e0:	52800460 	mov	w0, #0x23                  	// #35
    402028e4:	aa1903e1 	mov	x1, x25
    402028e8:	aa1f03e2 	mov	x2, xzr
    402028ec:	aa1303e3 	mov	x3, x19
    402028f0:	97ffff16 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    402028f4:	8b1312c8 	add	x8, x22, x19, lsl #4
    402028f8:	a941a909 	ldp	x9, x10, [x8, #24]
    402028fc:	a90babe9 	stp	x9, x10, [sp, #184]
    40202900:	a943a109 	ldp	x9, x8, [x8, #56]
    40202904:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202908:	9102e3e4 	add	x4, sp, #0xb8
    4020290c:	528003e0 	mov	w0, #0x1f                  	// #31
    40202910:	aa1903e1 	mov	x1, x25
    40202914:	aa1f03e2 	mov	x2, xzr
    40202918:	aa1303e3 	mov	x3, x19
    4020291c:	97ffff0b 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202920:	8b130ac8 	add	x8, x22, x19, lsl #2
    40202924:	b9401109 	ldr	w9, [x8, #16]
    40202928:	b9405908 	ldr	w8, [x8, #88]
    4020292c:	8b1302ca 	add	x10, x22, x19
    40202930:	3941814a 	ldrb	w10, [x10, #96]
    40202934:	b94002cb 	ldr	w11, [x22]
    40202938:	f94006cc 	ldr	x12, [x22, #8]
    4020293c:	eb13019f 	cmp	x12, x19
    40202940:	1a9f17ec 	cset	w12, eq  // eq = none
    40202944:	39418acd 	ldrb	w13, [x22, #98]
    40202948:	71000dbf 	cmp	w13, #0x3
    4020294c:	1a8d07ed 	csinc	w13, wzr, w13, eq  // eq = none
    40202950:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202954:	6a0c017f 	tst	w11, w12
    40202958:	9a9f11a8 	csel	x8, x13, xzr, ne  // ne = any
    4020295c:	a90ca3ea 	stp	x10, x8, [sp, #200]
    40202960:	9102e3e4 	add	x4, sp, #0xb8
    40202964:	52800400 	mov	w0, #0x20                  	// #32
    40202968:	aa1903e1 	mov	x1, x25
    4020296c:	aa1f03e2 	mov	x2, xzr
    40202970:	aa1303e3 	mov	x3, x19
    40202974:	97fffef5 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202978:	2a1f03e8 	mov	w8, wzr
    4020297c:	52800033 	mov	w19, #0x1                   	// #1
    40202980:	3707f8b5 	tbnz	w21, #0, 40202894 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x1f0>
    40202984:	52801008 	mov	w8, #0x80                  	// #128
    40202988:	52802109 	mov	w9, #0x108                 	// #264
    4020298c:	a90ba3e8 	stp	x8, x8, [sp, #184]
    40202990:	52801708 	mov	w8, #0xb8                  	// #184
    40202994:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202998:	9102e3e4 	add	x4, sp, #0xb8
    4020299c:	52800420 	mov	w0, #0x21                  	// #33
    402029a0:	aa1903e1 	mov	x1, x25
    402029a4:	aa1f03e2 	mov	x2, xzr
    402029a8:	52800043 	mov	w3, #0x2                   	// #2
    402029ac:	97fffee7 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    402029b0:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0xb8e0>
    402029b4:	f943f508 	ldr	x8, [x8, #2024]
    402029b8:	f101011f 	cmp	x8, #0x40
    402029bc:	52800809 	mov	w9, #0x40                  	// #64
    402029c0:	9a893113 	csel	x19, x8, x9, cc  // cc = lo, ul, last
    402029c4:	a94a5ff8 	ldp	x24, x23, [sp, #160]
    402029c8:	a94967fa 	ldp	x26, x25, [sp, #144]
    402029cc:	f94047fb 	ldr	x27, [sp, #136]
    402029d0:	b4000288 	cbz	x8, 40202a20 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x37c>
    402029d4:	aa1f03f4 	mov	x20, xzr
    402029d8:	b0000035 	adrp	x21, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402029dc:	910022b5 	add	x21, x21, #0x8
    402029e0:	b0000116 	adrp	x22, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0xb8e0>
    402029e4:	911fc2d6 	add	x22, x22, #0x7f0
    402029e8:	f9400ac1 	ldr	x1, [x22, #16]
    402029ec:	f94006c8 	ldr	x8, [x22, #8]
    402029f0:	f84186c9 	ldr	x9, [x22], #24
    402029f4:	aa1403ea 	mov	x10, x20
    402029f8:	91000694 	add	x20, x20, #0x1
    402029fc:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202a00:	a97f8ea2 	ldp	x2, x3, [x21, #-8]
    40202a04:	a90cffea 	stp	x10, xzr, [sp, #200]
    40202a08:	9102e3e4 	add	x4, sp, #0xb8
    40202a0c:	52800180 	mov	w0, #0xc                   	// #12
    40202a10:	97fffece 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202a14:	910042b5 	add	x21, x21, #0x10
    40202a18:	eb14027f 	cmp	x19, x20
    40202a1c:	54fffe61 	b.ne	402029e8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x344>  // b.any
    40202a20:	52800314 	mov	w20, #0x18                  	// #24
    40202a24:	72a12014 	movk	w20, #0x900, lsl #16
    40202a28:	d5033fdf 	isb
    40202a2c:	d53be021 	mrs	x1, cntpct_el0
    40202a30:	f94043e8 	ldr	x8, [sp, #128]
    40202a34:	a90befe8 	stp	x8, x27, [sp, #184]
    40202a38:	a90ce7fa 	stp	x26, x25, [sp, #200]
    40202a3c:	9102e3e4 	add	x4, sp, #0xb8
    40202a40:	528001a0 	mov	w0, #0xd                   	// #13
    40202a44:	aa1803e2 	mov	x2, x24
    40202a48:	aa1703e3 	mov	x3, x23
    40202a4c:	97fffebf 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202a50:	aa1f03e8 	mov	x8, xzr
    40202a54:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202a58:	d503201f 	nop
    40202a5c:	10019e2a 	adr	x10, 40205e20 <anon.d8c123e08f096c2ebe8598f45112ff88.3.llvm.6038828230051623308+0x18>
    40202a60:	3868694b 	ldrb	w11, [x10, x8]
    40202a64:	b940028c 	ldr	w12, [x20]
    40202a68:	3628006c 	tbz	w12, #5, 40202a74 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x3d0>
    40202a6c:	d5033fdf 	isb
    40202a70:	17fffffd 	b	40202a64 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x3c0>
    40202a74:	91000508 	add	x8, x8, #0x1
    40202a78:	b900012b 	str	w11, [x9]
    40202a7c:	f1002d1f 	cmp	x8, #0xb
    40202a80:	54ffff01 	b.ne	40202a60 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x3bc>  // b.any
    40202a84:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202a88:	f9438915 	ldr	x21, [x8, #1808]
    40202a8c:	b4000755 	cbz	x21, 40202b74 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x4d0>
    40202a90:	aa1f03f6 	mov	x22, xzr
    40202a94:	9102e3e8 	add	x8, sp, #0xb8
    40202a98:	b202e7f7 	mov	x23, #0xcccccccccccccccc    	// #-3689348814741910324
    40202a9c:	f29999b7 	movk	x23, #0xcccd
    40202aa0:	91004113 	add	x19, x8, #0x10
    40202aa4:	52800158 	mov	w24, #0xa                   	// #10
    40202aa8:	910423f9 	add	x25, sp, #0x108
    40202aac:	52a1201a 	mov	w26, #0x9000000             	// #150994944
    40202ab0:	5280041b 	mov	w27, #0x20                  	// #32
    40202ab4:	d503201f 	nop
    40202ab8:	1002631c 	adr	x28, 40207718 <jnox_kernel::ordinary_reservations::TRACE>
    40202abc:	8b161b81 	add	x1, x28, x22, lsl #6
    40202ac0:	910006d6 	add	x22, x22, #0x1
    40202ac4:	aa1303e0 	mov	x0, x19
    40202ac8:	52800802 	mov	w2, #0x40                  	// #64
    40202acc:	94000bbb 	bl	402059b8 <memcpy>
    40202ad0:	aa1f03e8 	mov	x8, xzr
    40202ad4:	b9011bff 	str	wzr, [sp, #280]
    40202ad8:	f8687a69 	ldr	x9, [x19, x8, lsl #3]
    40202adc:	91000508 	add	x8, x8, #0x1
    40202ae0:	5280026a 	mov	w10, #0x13                  	// #19
    40202ae4:	a910ffff 	stp	xzr, xzr, [sp, #264]
    40202ae8:	f1004d5f 	cmp	x10, #0x13
    40202aec:	54000d08 	b.hi	40202c8c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x5e8>  // b.pmore
    40202af0:	9bd77d2b 	umulh	x11, x9, x23
    40202af4:	d343fd6b 	lsr	x11, x11, #3
    40202af8:	1b18a56c 	msub	w12, w11, w24, w9
    40202afc:	321c058c 	orr	w12, w12, #0x30
    40202b00:	382a6b2c 	strb	w12, [x25, x10]
    40202b04:	d100054a 	sub	x10, x10, #0x1
    40202b08:	f100293f 	cmp	x9, #0xa
    40202b0c:	aa0b03e9 	mov	x9, x11
    40202b10:	54fffec2 	b.cs	40202ae8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x444>  // b.hs, b.nlast
    40202b14:	91000549 	add	x9, x10, #0x1
    40202b18:	38696b2a 	ldrb	w10, [x25, x9]
    40202b1c:	b940028b 	ldr	w11, [x20]
    40202b20:	3628006b 	tbz	w11, #5, 40202b2c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x488>
    40202b24:	d5033fdf 	isb
    40202b28:	17fffffd 	b	40202b1c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x478>
    40202b2c:	91000529 	add	x9, x9, #0x1
    40202b30:	b900034a 	str	w10, [x26]
    40202b34:	f100513f 	cmp	x9, #0x14
    40202b38:	54ffff01 	b.ne	40202b18 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x474>  // b.any
    40202b3c:	14000002 	b	40202b44 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x4a0>
    40202b40:	d5033fdf 	isb
    40202b44:	b9400289 	ldr	w9, [x20]
    40202b48:	372fffc9 	tbnz	w9, #5, 40202b40 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x49c>
    40202b4c:	b900035b 	str	w27, [x26]
    40202b50:	f100211f 	cmp	x8, #0x8
    40202b54:	54fffc01 	b.ne	40202ad4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x430>  // b.any
    40202b58:	14000002 	b	40202b60 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x4bc>
    40202b5c:	d5033fdf 	isb
    40202b60:	b9400288 	ldr	w8, [x20]
    40202b64:	372fffc8 	tbnz	w8, #5, 40202b5c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x4b8>
    40202b68:	b9000358 	str	w24, [x26]
    40202b6c:	eb1502df 	cmp	x22, x21
    40202b70:	54fffa61 	b.ne	40202abc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x418>  // b.any
    40202b74:	aa1f03e8 	mov	x8, xzr
    40202b78:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202b7c:	d503201f 	nop
    40202b80:	7001954a 	adr	x10, 40205e2b <anon.d8c123e08f096c2ebe8598f45112ff88.3.llvm.6038828230051623308+0x23>
    40202b84:	3868694b 	ldrb	w11, [x10, x8]
    40202b88:	b940028c 	ldr	w12, [x20]
    40202b8c:	3628006c 	tbz	w12, #5, 40202b98 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x4f4>
    40202b90:	d5033fdf 	isb
    40202b94:	17fffffd 	b	40202b88 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x4e4>
    40202b98:	91000508 	add	x8, x8, #0x1
    40202b9c:	b900012b 	str	w11, [x9]
    40202ba0:	f100251f 	cmp	x8, #0x9
    40202ba4:	54ffff01 	b.ne	40202b84 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x4e0>  // b.any
    40202ba8:	d503205f 	wfe
    40202bac:	17ffffff 	b	40202ba8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x504>
    40202bb0:	a94127e8 	ldp	x8, x9, [sp, #16]
    40202bb4:	a90ba7f3 	stp	x19, x9, [sp, #184]
    40202bb8:	a90ca3fa 	stp	x26, x8, [sp, #200]
    40202bbc:	9102e3e4 	add	x4, sp, #0xb8
    40202bc0:	52800320 	mov	w0, #0x19                  	// #25
    40202bc4:	aa1503e1 	mov	x1, x21
    40202bc8:	aa1f03e2 	mov	x2, xzr
    40202bcc:	52800043 	mov	w3, #0x2                   	// #2
    40202bd0:	97fffe5e 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202bd4:	a90bd3f5 	stp	x21, x20, [sp, #184]
    40202bd8:	a90ccffa 	stp	x26, x19, [sp, #200]
    40202bdc:	9102e3e4 	add	x4, sp, #0xb8
    40202be0:	528004a0 	mov	w0, #0x25                  	// #37
    40202be4:	aa1403e1 	mov	x1, x20
    40202be8:	aa1f03e2 	mov	x2, xzr
    40202bec:	52800043 	mov	w3, #0x2                   	// #2
    40202bf0:	97fffe56 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202bf4:	360fe0d8 	tbz	w24, #1, 4020280c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x168>
    40202bf8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202bfc:	f9432d08 	ldr	x8, [x8, #1624]
    40202c00:	f1000aff 	cmp	x23, #0x2
    40202c04:	a90bfffb 	stp	x27, xzr, [sp, #184]
    40202c08:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40202c0c:	a90cffe8 	stp	x8, xzr, [sp, #200]
    40202c10:	9102e3e4 	add	x4, sp, #0xb8
    40202c14:	52800340 	mov	w0, #0x1a                  	// #26
    40202c18:	f94013e1 	ldr	x1, [sp, #32]
    40202c1c:	aa1f03e2 	mov	x2, xzr
    40202c20:	52800043 	mov	w3, #0x2                   	// #2
    40202c24:	97fffe49 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202c28:	3617df58 	tbz	w24, #2, 40202810 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x16c>
    40202c2c:	924003a8 	and	x8, x29, #0x1
    40202c30:	d341ffa9 	lsr	x9, x29, #1
    40202c34:	a90ba3fd 	stp	x29, x8, [sp, #184]
    40202c38:	f9405be8 	ldr	x8, [sp, #176]
    40202c3c:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202c40:	9102e3e4 	add	x4, sp, #0xb8
    40202c44:	52800360 	mov	w0, #0x1b                  	// #27
    40202c48:	f94017e1 	ldr	x1, [sp, #40]
    40202c4c:	aa1f03e2 	mov	x2, xzr
    40202c50:	aa1c03e3 	mov	x3, x28
    40202c54:	97fffe3d 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202c58:	361fddf8 	tbz	w24, #3, 40202814 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x170>
    40202c5c:	a94327e8 	ldp	x8, x9, [sp, #48]
    40202c60:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202c64:	52800028 	mov	w8, #0x1                   	// #1
    40202c68:	a94407e9 	ldp	x9, x1, [sp, #64]
    40202c6c:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202c70:	9102e3e4 	add	x4, sp, #0xb8
    40202c74:	52800380 	mov	w0, #0x1c                  	// #28
    40202c78:	aa1f03e2 	mov	x2, xzr
    40202c7c:	aa1c03e3 	mov	x3, x28
    40202c80:	97fffe32 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202c84:	3727dcb8 	tbnz	w24, #4, 40202818 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x174>
    40202c88:	17fffefe 	b	40202880 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308+0x1dc>
    40202c8c:	d503201f 	nop
    40202c90:	10019042 	adr	x2, 40205e98 <anon.d8c123e08f096c2ebe8598f45112ff88.3.llvm.6038828230051623308+0x90>
    40202c94:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    40202c98:	52800281 	mov	w1, #0x14                  	// #20
    40202c9c:	940007f7 	bl	40204c78 <core::panicking::panic_bounds_check>

0000000040202ca0 <jnox_kernel::ordinary_reservations::Runtime::arm>:
    40202ca0:	d10103ff 	sub	sp, sp, #0x40
    40202ca4:	a90257fe 	stp	x30, x21, [sp, #32]
    40202ca8:	a9034ff4 	stp	x20, x19, [sp, #48]
    40202cac:	aa0203f3 	mov	x19, x2
    40202cb0:	aa0003e2 	mov	x2, x0
    40202cb4:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202cb8:	91158129 	add	x9, x9, #0x560
    40202cbc:	a9020533 	stp	x19, x1, [x9, #32]
    40202cc0:	52800028 	mov	w8, #0x1                   	// #1
    40202cc4:	d51be253 	msr	cntp_cval_el0, x19
    40202cc8:	d51be228 	msr	cntp_ctl_el0, x8
    40202ccc:	d5033fdf 	isb
    40202cd0:	d53be255 	mrs	x21, cntp_cval_el0
    40202cd4:	d53be234 	mrs	x20, cntp_ctl_el0
    40202cd8:	d5033fdf 	isb
    40202cdc:	d53be028 	mrs	x8, cntpct_el0
    40202ce0:	a90053f3 	stp	x19, x20, [sp]
    40202ce4:	f9400123 	ldr	x3, [x9]
    40202ce8:	a90107f5 	stp	x21, x1, [sp, #16]
    40202cec:	910003e4 	mov	x4, sp
    40202cf0:	52800060 	mov	w0, #0x3                   	// #3
    40202cf4:	aa0803e1 	mov	x1, x8
    40202cf8:	97fffe14 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202cfc:	eb1302bf 	cmp	x21, x19
    40202d00:	54000101 	b.ne	40202d20 <jnox_kernel::ordinary_reservations::Runtime::arm+0x80>  // b.any
    40202d04:	92400688 	and	x8, x20, #0x3
    40202d08:	f100051f 	cmp	x8, #0x1
    40202d0c:	540000a1 	b.ne	40202d20 <jnox_kernel::ordinary_reservations::Runtime::arm+0x80>  // b.any
    40202d10:	a9434ff4 	ldp	x20, x19, [sp, #48]
    40202d14:	a94257fe 	ldp	x30, x21, [sp, #32]
    40202d18:	910103ff 	add	sp, sp, #0x40
    40202d1c:	d65f03c0 	ret
    40202d20:	97fff962 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

0000000040202d24 <jnox_kernel::ordinary_reservations::Runtime::close>:
    40202d24:	d103c3ff 	sub	sp, sp, #0xf0
    40202d28:	a9097bfd 	stp	x29, x30, [sp, #144]
    40202d2c:	a90a6ffc 	stp	x28, x27, [sp, #160]
    40202d30:	a90b67fa 	stp	x26, x25, [sp, #176]
    40202d34:	a90c5ff8 	stp	x24, x23, [sp, #192]
    40202d38:	a90d57f6 	stp	x22, x21, [sp, #208]
    40202d3c:	a90e4ff4 	stp	x20, x19, [sp, #224]
    40202d40:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202d44:	91140108 	add	x8, x8, #0x500
    40202d48:	a9405113 	ldp	x19, x20, [x8]
    40202d4c:	a9412518 	ldp	x24, x9, [x8, #16]
    40202d50:	f90037e9 	str	x9, [sp, #104]
    40202d54:	a942691d 	ldp	x29, x26, [x8, #32]
    40202d58:	3940c119 	ldrb	w25, [x8, #48]
    40202d5c:	52800069 	mov	w9, #0x3                   	// #3
    40202d60:	3900c109 	strb	w9, [x8, #48]
    40202d64:	71000f3f 	cmp	w25, #0x3
    40202d68:	54001d20 	b.eq	4020310c <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.none
    40202d6c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202d70:	f942b108 	ldr	x8, [x8, #1376]
    40202d74:	eb13011f 	cmp	x8, x19
    40202d78:	54001ca1 	b.ne	4020310c <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.any
    40202d7c:	aa0003f5 	mov	x21, x0
    40202d80:	d503201f 	nop
    40202d84:	100a4ce8 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308>
    40202d88:	8b133909 	add	x9, x8, x19, lsl #14
    40202d8c:	eb00013f 	cmp	x9, x0
    40202d90:	54001be8 	b.hi	4020310c <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202d94:	b10d06bf 	cmn	x21, #0x341
    40202d98:	54001ba8 	b.hi	4020310c <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202d9c:	d372c669 	lsl	x9, x19, #14
    40202da0:	8b090108 	add	x8, x8, x9
    40202da4:	91401108 	add	x8, x8, #0x4, lsl #12
    40202da8:	910d02a9 	add	x9, x21, #0x340
    40202dac:	eb08013f 	cmp	x9, x8
    40202db0:	54001ae8 	b.hi	4020310c <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202db4:	aa0303fc 	mov	x28, x3
    40202db8:	2a0203f7 	mov	w23, w2
    40202dbc:	aa0103f6 	mov	x22, x1
    40202dc0:	9101c3e8 	add	x8, sp, #0x70
    40202dc4:	aa1303e0 	mov	x0, x19
    40202dc8:	9400014c 	bl	402032f8 <jnox_kernel::ordinary_reservations::snapshot>
    40202dcc:	f1000a7f 	cmp	x19, #0x2
    40202dd0:	54001d62 	b.cs	4020317c <jnox_kernel::ordinary_reservations::Runtime::close+0x458>  // b.hs, b.nlast
    40202dd4:	a94733fb 	ldp	x27, x12, [sp, #112]
    40202dd8:	f94043ef 	ldr	x15, [sp, #128]
    40202ddc:	d503201f 	nop
    40202de0:	10108108 	adr	x8, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40202de4:	8b130d08 	add	x8, x8, x19, lsl #3
    40202de8:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202dec:	9114e129 	add	x9, x9, #0x538
    40202df0:	c8dffd0e 	ldar	x14, [x8]
    40202df4:	a9402129 	ldp	x9, x8, [x9]
    40202df8:	9bc87e8a 	umulh	x10, x20, x8
    40202dfc:	eb0a03ff 	cmp	xzr, x10
    40202e00:	1a9f07eb 	cset	w11, ne  // ne = any
    40202e04:	9b087e8a 	mul	x10, x20, x8
    40202e08:	ab09014d 	adds	x13, x10, x9
    40202e0c:	1a9f37ea 	cset	w10, cs  // cs = hs, nlast
    40202e10:	3700180b 	tbnz	w11, #0, 40203110 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202e14:	350017ea 	cbnz	w10, 40203110 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202e18:	9100068a 	add	x10, x20, #0x1
    40202e1c:	9bc87d4b 	umulh	x11, x10, x8
    40202e20:	eb0b03ff 	cmp	xzr, x11
    40202e24:	1a9f07eb 	cset	w11, ne  // ne = any
    40202e28:	9b087d48 	mul	x8, x10, x8
    40202e2c:	ab090109 	adds	x9, x8, x9
    40202e30:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40202e34:	370016eb 	tbnz	w11, #0, 40203110 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202e38:	350016c8 	cbnz	w8, 40203110 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202e3c:	b100069f 	cmn	x20, #0x1
    40202e40:	54001680 	b.eq	40203110 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.none
    40202e44:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202e48:	f942a508 	ldr	x8, [x8, #1352]
    40202e4c:	eb08012a 	subs	x10, x9, x8
    40202e50:	54001603 	b.cc	40203110 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.lo, b.ul, b.last
    40202e54:	a9056bfc 	stp	x28, x26, [sp, #80]
    40202e58:	f9000fe9 	str	x9, [sp, #24]
    40202e5c:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0xb8e0>
    40202e60:	f943f508 	ldr	x8, [x8, #2024]
    40202e64:	91000709 	add	x9, x24, #0x1
    40202e68:	eb09011f 	cmp	x8, x9
    40202e6c:	54001501 	b.ne	4020310c <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.any
    40202e70:	b9004ff9 	str	w25, [sp, #76]
    40202e74:	d503201f 	nop
    40202e78:	10104b88 	adr	x8, 402237e8 <jnox_ap_returns>
    40202e7c:	52800309 	mov	w9, #0x18                  	// #24
    40202e80:	9b092308 	madd	x8, x24, x9, x8
    40202e84:	f9400509 	ldr	x9, [x8, #8]
    40202e88:	f940090b 	ldr	x11, [x8, #16]
    40202e8c:	f9400d1c 	ldr	x28, [x8, #24]
    40202e90:	eb1c02da 	subs	x26, x22, x28
    40202e94:	540017e3 	b.cc	40203190 <jnox_kernel::ordinary_reservations::Runtime::close+0x46c>  // b.lo, b.ul, b.last
    40202e98:	a902a7eb 	stp	x11, x9, [sp, #40]
    40202e9c:	a903b7ef 	stp	x15, x13, [sp, #56]
    40202ea0:	f90033ee 	str	x14, [sp, #96]
    40202ea4:	f9000bea 	str	x10, [sp, #16]
    40202ea8:	d503201f 	nop
    40202eac:	10022aa8 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40202eb0:	8b130d18 	add	x24, x8, x19, lsl #3
    40202eb4:	f940d308 	ldr	x8, [x24, #416]
    40202eb8:	ab1a0119 	adds	x25, x8, x26
    40202ebc:	540012a2 	b.cs	40203110 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.hs, b.nlast
    40202ec0:	f900d319 	str	x25, [x24, #416]
    40202ec4:	f94037e8 	ldr	x8, [sp, #104]
    40202ec8:	a9076fe8 	stp	x8, x27, [sp, #112]
    40202ecc:	a90833fd 	stp	x29, x12, [sp, #128]
    40202ed0:	f90013fb 	str	x27, [sp, #32]
    40202ed4:	9101c3e4 	add	x4, sp, #0x70
    40202ed8:	52800100 	mov	w0, #0x8                   	// #8
    40202edc:	aa1603e1 	mov	x1, x22
    40202ee0:	aa1403e2 	mov	x2, x20
    40202ee4:	aa1303e3 	mov	x3, x19
    40202ee8:	aa0c03fb 	mov	x27, x12
    40202eec:	97fffd97 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202ef0:	f9407ea8 	ldr	x8, [x21, #248]
    40202ef4:	f9404ea9 	ldr	x9, [x21, #152]
    40202ef8:	a90723f5 	stp	x21, x8, [sp, #112]
    40202efc:	f9408ea8 	ldr	x8, [x21, #280]
    40202f00:	a90823e9 	stp	x9, x8, [sp, #128]
    40202f04:	9101c3e4 	add	x4, sp, #0x70
    40202f08:	52800120 	mov	w0, #0x9                   	// #9
    40202f0c:	aa1603e1 	mov	x1, x22
    40202f10:	aa1403e2 	mov	x2, x20
    40202f14:	aa1303e3 	mov	x3, x19
    40202f18:	97fffd8c 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202f1c:	f94033e8 	ldr	x8, [sp, #96]
    40202f20:	a90723fc 	stp	x28, x8, [sp, #112]
    40202f24:	a9086bf6 	stp	x22, x26, [sp, #128]
    40202f28:	f90007fa 	str	x26, [sp, #8]
    40202f2c:	9101c3e4 	add	x4, sp, #0x70
    40202f30:	52800140 	mov	w0, #0xa                   	// #10
    40202f34:	aa1603e1 	mov	x1, x22
    40202f38:	aa1403e2 	mov	x2, x20
    40202f3c:	aa1303e3 	mov	x3, x19
    40202f40:	97fffd82 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202f44:	110006e8 	add	w8, w23, #0x1
    40202f48:	92401d09 	and	x9, x8, #0xff
    40202f4c:	f9402be8 	ldr	x8, [sp, #80]
    40202f50:	a90723e9 	stp	x9, x8, [sp, #112]
    40202f54:	f9401fe9 	ldr	x9, [sp, #56]
    40202f58:	910d02a8 	add	x8, x21, #0x340
    40202f5c:	a90823e9 	stp	x9, x8, [sp, #128]
    40202f60:	9101c3e4 	add	x4, sp, #0x70
    40202f64:	52800160 	mov	w0, #0xb                   	// #11
    40202f68:	aa1603e1 	mov	x1, x22
    40202f6c:	aa1403e2 	mov	x2, x20
    40202f70:	aa1303e3 	mov	x3, x19
    40202f74:	97fffd75 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202f78:	f9402fe8 	ldr	x8, [sp, #88]
    40202f7c:	a90767e8 	stp	x8, x25, [sp, #112]
    40202f80:	aa1903fa 	mov	x26, x25
    40202f84:	a942a7e8 	ldp	x8, x9, [sp, #40]
    40202f88:	a90823e9 	stp	x9, x8, [sp, #128]
    40202f8c:	9101c3e4 	add	x4, sp, #0x70
    40202f90:	52800260 	mov	w0, #0x13                  	// #19
    40202f94:	aa1603e1 	mov	x1, x22
    40202f98:	aa1403e2 	mov	x2, x20
    40202f9c:	aa1303e3 	mov	x3, x19
    40202fa0:	97fffd6a 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    40202fa4:	f94013e4 	ldr	x4, [sp, #32]
    40202fa8:	b9404fe8 	ldr	w8, [sp, #76]
    40202fac:	6b37011f 	cmp	w8, w23, uxtb
    40202fb0:	f94023e5 	ldr	x5, [sp, #64]
    40202fb4:	54000b21 	b.ne	40203118 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40202fb8:	f94037e8 	ldr	x8, [sp, #104]
    40202fbc:	eb080088 	subs	x8, x4, x8
    40202fc0:	54000ac9 	b.ls	40203118 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.plast
    40202fc4:	f9408ea9 	ldr	x9, [x21, #280]
    40202fc8:	d503201f 	nop
    40202fcc:	100170aa 	adr	x10, 40205de0 <anon.d8c123e08f096c2ebe8598f45112ff88.1.llvm.6038828230051623308>
    40202fd0:	f873794a 	ldr	x10, [x10, x19, lsl #3]
    40202fd4:	eb0a013f 	cmp	x9, x10
    40202fd8:	54000a01 	b.ne	40203118 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40202fdc:	f94082a9 	ldr	x9, [x21, #256]
    40202fe0:	528011ea 	mov	w10, #0x8f                  	// #143
    40202fe4:	8a0a0129 	and	x9, x9, x10
    40202fe8:	f100153f 	cmp	x9, #0x5
    40202fec:	54000961 	b.ne	40203118 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40202ff0:	52800029 	mov	w9, #0x1                   	// #1
    40202ff4:	5280006a 	mov	w10, #0x3                   	// #3
    40202ff8:	aa0803eb 	mov	x11, x8
    40202ffc:	9b1d254c 	madd	x12, x10, x29, x9
    40203000:	f240017f 	tst	x11, #0x1
    40203004:	9a8c03bd 	csel	x29, x29, x12, eq  // eq = none
    40203008:	9b0a2529 	madd	x9, x9, x10, x9
    4020300c:	9b0a7d4a 	mul	x10, x10, x10
    40203010:	d341fd6b 	lsr	x11, x11, #1
    40203014:	b5ffff4b 	cbnz	x11, 40202ffc <jnox_kernel::ordinary_reservations::Runtime::close+0x2d8>
    40203018:	eb1b03bf 	cmp	x29, x27
    4020301c:	540007e1 	b.ne	40203118 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203020:	72001eff 	tst	w23, #0xff
    40203024:	54000060 	b.eq	40203030 <jnox_kernel::ordinary_reservations::Runtime::close+0x30c>  // b.none
    40203028:	f104011f 	cmp	x8, #0x100
    4020302c:	54000761 	b.ne	40203118 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203030:	f94033ea 	ldr	x10, [sp, #96]
    40203034:	eb16015f 	cmp	x10, x22
    40203038:	540007c8 	b.hi	40203130 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.pmore
    4020303c:	eb05039f 	cmp	x28, x5
    40203040:	54000783 	b.cc	40203130 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.lo, b.ul, b.last
    40203044:	eb1c015f 	cmp	x10, x28
    40203048:	54000743 	b.cc	40203130 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.lo, b.ul, b.last
    4020304c:	cb050149 	sub	x9, x10, x5
    40203050:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203054:	f942a508 	ldr	x8, [x8, #1352]
    40203058:	eb08013f 	cmp	x9, x8
    4020305c:	540006a8 	b.hi	40203130 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.pmore
    40203060:	a9412fe5 	ldp	x5, x11, [sp, #16]
    40203064:	eb0b02df 	cmp	x22, x11
    40203068:	54000708 	b.hi	40203148 <jnox_kernel::ordinary_reservations::Runtime::close+0x424>  // b.pmore
    4020306c:	12001eea 	and	w10, w23, #0xff
    40203070:	eb0502c9 	subs	x9, x22, x5
    40203074:	9a8933e9 	csel	x9, xzr, x9, cc  // cc = lo, ul, last
    40203078:	3500006a 	cbnz	w10, 40203084 <jnox_kernel::ordinary_reservations::Runtime::close+0x360>
    4020307c:	eb08013f 	cmp	x9, x8
    40203080:	54000648 	b.hi	40203148 <jnox_kernel::ordinary_reservations::Runtime::close+0x424>  // b.pmore
    40203084:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203088:	f942a108 	ldr	x8, [x8, #1344]
    4020308c:	f94007ea 	ldr	x10, [sp, #8]
    40203090:	eb08015f 	cmp	x10, x8
    40203094:	aa1a03eb 	mov	x11, x26
    40203098:	54000648 	b.hi	40203160 <jnox_kernel::ordinary_reservations::Runtime::close+0x43c>  // b.pmore
    4020309c:	f940db09 	ldr	x9, [x24, #432]
    402030a0:	9b087d28 	mul	x8, x9, x8
    402030a4:	eb08017f 	cmp	x11, x8
    402030a8:	540005c8 	b.hi	40203160 <jnox_kernel::ordinary_reservations::Runtime::close+0x43c>  // b.pmore
    402030ac:	72001eff 	tst	w23, #0xff
    402030b0:	54000060 	b.eq	402030bc <jnox_kernel::ordinary_reservations::Runtime::close+0x398>  // b.none
    402030b4:	eb0502df 	cmp	x22, x5
    402030b8:	540006e2 	b.cs	40203194 <jnox_kernel::ordinary_reservations::Runtime::close+0x470>  // b.hs, b.nlast
    402030bc:	f900e304 	str	x4, [x24, #448]
    402030c0:	f900eb1b 	str	x27, [x24, #464]
    402030c4:	94000040 	bl	402031c4 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    402030c8:	aa1303e1 	mov	x1, x19
    402030cc:	2a1703e2 	mov	w2, w23
    402030d0:	94000240 	bl	402039d0 <jnox_kernel::reservation_jobs::Jobs::trap>
    402030d4:	72001c04 	ands	w4, w0, #0xff
    402030d8:	540006a1 	b.ne	402031ac <jnox_kernel::ordinary_reservations::Runtime::close+0x488>  // b.any
    402030dc:	12001ee8 	and	w8, w23, #0xff
    402030e0:	7100091f 	cmp	w8, #0x2
    402030e4:	54000040 	b.eq	402030ec <jnox_kernel::ordinary_reservations::Runtime::close+0x3c8>  // b.none
    402030e8:	f900b715 	str	x21, [x24, #360]
    402030ec:	a94e4ff4 	ldp	x20, x19, [sp, #224]
    402030f0:	a94d57f6 	ldp	x22, x21, [sp, #208]
    402030f4:	a94c5ff8 	ldp	x24, x23, [sp, #192]
    402030f8:	a94b67fa 	ldp	x26, x25, [sp, #176]
    402030fc:	a94a6ffc 	ldp	x28, x27, [sp, #160]
    40203100:	a9497bfd 	ldp	x29, x30, [sp, #144]
    40203104:	9103c3ff 	add	sp, sp, #0xf0
    40203108:	d65f03c0 	ret
    4020310c:	97fff867 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40203110:	52800060 	mov	w0, #0x3                   	// #3
    40203114:	94000071 	bl	402032d8 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    40203118:	52800060 	mov	w0, #0x3                   	// #3
    4020311c:	52800061 	mov	w1, #0x3                   	// #3
    40203120:	aa1403e2 	mov	x2, x20
    40203124:	aa1303e3 	mov	x3, x19
    40203128:	f94037e5 	ldr	x5, [sp, #104]
    4020312c:	97fffd5e 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>
    40203130:	52800040 	mov	w0, #0x2                   	// #2
    40203134:	52800041 	mov	w1, #0x2                   	// #2
    40203138:	aa1403e2 	mov	x2, x20
    4020313c:	aa1303e3 	mov	x3, x19
    40203140:	aa0a03e4 	mov	x4, x10
    40203144:	97fffd58 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>
    40203148:	52800040 	mov	w0, #0x2                   	// #2
    4020314c:	52800021 	mov	w1, #0x1                   	// #1
    40203150:	aa1403e2 	mov	x2, x20
    40203154:	aa1303e3 	mov	x3, x19
    40203158:	aa1603e4 	mov	x4, x22
    4020315c:	14000006 	b	40203174 <jnox_kernel::ordinary_reservations::Runtime::close+0x450>
    40203160:	52800040 	mov	w0, #0x2                   	// #2
    40203164:	528000e1 	mov	w1, #0x7                   	// #7
    40203168:	aa1403e2 	mov	x2, x20
    4020316c:	aa1303e3 	mov	x3, x19
    40203170:	aa0a03e4 	mov	x4, x10
    40203174:	aa0b03e5 	mov	x5, x11
    40203178:	97fffd4b 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>
    4020317c:	d503201f 	nop
    40203180:	10016802 	adr	x2, 40205e80 <anon.d8c123e08f096c2ebe8598f45112ff88.3.llvm.6038828230051623308+0x78>
    40203184:	aa1303e0 	mov	x0, x19
    40203188:	52800041 	mov	w1, #0x2                   	// #2
    4020318c:	940006bb 	bl	40204c78 <core::panicking::panic_bounds_check>
    40203190:	97fffbb3 	bl	4020205c <jnox_kernel::ordinary_reservations::run::{{closure}}>
    40203194:	52800040 	mov	w0, #0x2                   	// #2
    40203198:	52800121 	mov	w1, #0x9                   	// #9
    4020319c:	aa1403e2 	mov	x2, x20
    402031a0:	aa1303e3 	mov	x3, x19
    402031a4:	aa1603e4 	mov	x4, x22
    402031a8:	97fffd3f 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>
    402031ac:	52800060 	mov	w0, #0x3                   	// #3
    402031b0:	52800041 	mov	w1, #0x2                   	// #2
    402031b4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    402031b8:	52800043 	mov	w3, #0x2                   	// #2
    402031bc:	aa1f03e5 	mov	x5, xzr
    402031c0:	97fffd39 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>

00000000402031c4 <jnox_kernel::ordinary_reservations::Runtime::ledger>:
    402031c4:	f81f0ffe 	str	x30, [sp, #-16]!
    402031c8:	d503201f 	nop
    402031cc:	101030a8 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    402031d0:	c8dffd08 	ldar	x8, [x8]
    402031d4:	b4000128 	cbz	x8, 402031f8 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x34>
    402031d8:	f1000d1f 	cmp	x8, #0x3
    402031dc:	540000c1 	b.ne	402031f4 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x30>  // b.any
    402031e0:	90000020 	adrp	x0, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402031e4:	91120000 	add	x0, x0, #0x480
    402031e8:	f9400008 	ldr	x8, [x0]
    402031ec:	f100091f 	cmp	x8, #0x2
    402031f0:	54000081 	b.ne	40203200 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x3c>  // b.any
    402031f4:	97fff82d 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402031f8:	d503201f 	nop
    402031fc:	10021020 	adr	x0, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40203200:	f84107fe 	ldr	x30, [sp], #16
    40203204:	d65f03c0 	ret

0000000040203208 <jnox_kernel::ordinary_reservations::Runtime::select>:
    40203208:	d10143ff 	sub	sp, sp, #0x50
    4020320c:	f90013fe 	str	x30, [sp, #32]
    40203210:	a90357f6 	stp	x22, x21, [sp, #48]
    40203214:	a9044ff4 	stp	x20, x19, [sp, #64]
    40203218:	d503201f 	nop
    4020321c:	10020f28 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40203220:	8b010d09 	add	x9, x8, x1, lsl #3
    40203224:	f940b534 	ldr	x20, [x9, #360]
    40203228:	d503201f 	nop
    4020322c:	100a27a8 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308>
    40203230:	f900b53f 	str	xzr, [x9, #360]
    40203234:	8b013909 	add	x9, x8, x1, lsl #14
    40203238:	eb14013f 	cmp	x9, x20
    4020323c:	540004c8 	b.hi	402032d4 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    40203240:	aa0103f3 	mov	x19, x1
    40203244:	d372c429 	lsl	x9, x1, #14
    40203248:	8b090108 	add	x8, x8, x9
    4020324c:	91401108 	add	x8, x8, #0x4, lsl #12
    40203250:	910d0289 	add	x9, x20, #0x340
    40203254:	b10d069f 	cmn	x20, #0x341
    40203258:	fa489122 	ccmp	x9, x8, #0x2, ls  // ls = plast
    4020325c:	540003c8 	b.hi	402032d4 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    40203260:	90000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0xb8e0>
    40203264:	f943f516 	ldr	x22, [x8, #2024]
    40203268:	f100fedf 	cmp	x22, #0x3f
    4020326c:	54000348 	b.hi	402032d4 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    40203270:	aa0003f5 	mov	x21, x0
    40203274:	d5033fdf 	isb
    40203278:	d53be021 	mrs	x1, cntpct_el0
    4020327c:	f9407e88 	ldr	x8, [x20, #248]
    40203280:	f9404e89 	ldr	x9, [x20, #152]
    40203284:	a90023f4 	stp	x20, x8, [sp]
    40203288:	f9408e88 	ldr	x8, [x20, #280]
    4020328c:	a90123e9 	stp	x9, x8, [sp, #16]
    40203290:	910003e4 	mov	x4, sp
    40203294:	52800240 	mov	w0, #0x12                  	// #18
    40203298:	aa1503e2 	mov	x2, x21
    4020329c:	aa1303e3 	mov	x3, x19
    402032a0:	97fffcaa 	bl	40202548 <jnox_kernel::ordinary_reservations::event>
    402032a4:	d503201f 	nop
    402032a8:	1001eac8 	adr	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402032ac:	8b161108 	add	x8, x8, x22, lsl #4
    402032b0:	a9004d15 	stp	x21, x19, [x8]
    402032b4:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402032b8:	f902b113 	str	x19, [x8, #1376]
    402032bc:	aa1403e0 	mov	x0, x20
    402032c0:	a9444ff4 	ldp	x20, x19, [sp, #64]
    402032c4:	a94357f6 	ldp	x22, x21, [sp, #48]
    402032c8:	f94013fe 	ldr	x30, [sp, #32]
    402032cc:	910143ff 	add	sp, sp, #0x50
    402032d0:	d65f03c0 	ret
    402032d4:	97fff7f5 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

00000000402032d8 <jnox_kernel::ordinary_reservations::checked::{{closure}}>:
    402032d8:	f81f0ffe 	str	x30, [sp, #-16]!
    402032dc:	92401c04 	and	x4, x0, #0xff
    402032e0:	52800060 	mov	w0, #0x3                   	// #3
    402032e4:	52800041 	mov	w1, #0x2                   	// #2
    402032e8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    402032ec:	52800043 	mov	w3, #0x2                   	// #2
    402032f0:	aa1f03e5 	mov	x5, xzr
    402032f4:	97fffcec 	bl	402026a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.6038828230051623308>

00000000402032f8 <jnox_kernel::ordinary_reservations::snapshot>:
    402032f8:	f81f0ffe 	str	x30, [sp, #-16]!
    402032fc:	f100041f 	cmp	x0, #0x1
    40203300:	54000488 	b.hi	40203390 <jnox_kernel::ordinary_reservations::snapshot+0x98>  // b.pmore
    40203304:	d503201f 	nop
    40203308:	10105849 	adr	x9, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    4020330c:	8b000d29 	add	x9, x9, x0, lsl #3
    40203310:	c8dffd29 	ldar	x9, [x9]
    40203314:	b40002c9 	cbz	x9, 4020336c <jnox_kernel::ordinary_reservations::snapshot+0x74>
    40203318:	d503201f 	nop
    4020331c:	100a202a 	adr	x10, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308>
    40203320:	8b00394b 	add	x11, x10, x0, lsl #14
    40203324:	eb09017f 	cmp	x11, x9
    40203328:	54000328 	b.hi	4020338c <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    4020332c:	b100a53f 	cmn	x9, #0x29
    40203330:	540002e8 	b.hi	4020338c <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    40203334:	d372c40b 	lsl	x11, x0, #14
    40203338:	8b0b014a 	add	x10, x10, x11
    4020333c:	9140114a 	add	x10, x10, #0x4, lsl #12
    40203340:	9100a12b 	add	x11, x9, #0x28
    40203344:	eb0a017f 	cmp	x11, x10
    40203348:	54000228 	b.hi	4020338c <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    4020334c:	9100812a 	add	x10, x9, #0x20
    40203350:	c8dffd40 	ldar	x0, [x10]
    40203354:	f100041f 	cmp	x0, #0x1
    40203358:	54000228 	b.hi	4020339c <jnox_kernel::ordinary_reservations::snapshot+0xa4>  // b.pmore
    4020335c:	8b00112b 	add	x11, x9, x0, lsl #4
    40203360:	f940016a 	ldr	x10, [x11]
    40203364:	f940056b 	ldr	x11, [x11, #8]
    40203368:	14000005 	b	4020337c <jnox_kernel::ordinary_reservations::snapshot+0x84>
    4020336c:	aa1f03ea 	mov	x10, xzr
    40203370:	d503201f 	nop
    40203374:	1001536b 	adr	x11, 40205de0 <anon.d8c123e08f096c2ebe8598f45112ff88.1.llvm.6038828230051623308>
    40203378:	f860796b 	ldr	x11, [x11, x0, lsl #3]
    4020337c:	a9002d0a 	stp	x10, x11, [x8]
    40203380:	f9000909 	str	x9, [x8, #16]
    40203384:	f84107fe 	ldr	x30, [sp], #16
    40203388:	d65f03c0 	ret
    4020338c:	97fff7c7 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40203390:	d503201f 	nop
    40203394:	100158e2 	adr	x2, 40205eb0 <anon.d8c123e08f096c2ebe8598f45112ff88.3.llvm.6038828230051623308+0xa8>
    40203398:	14000003 	b	402033a4 <jnox_kernel::ordinary_reservations::snapshot+0xac>
    4020339c:	d503201f 	nop
    402033a0:	10015942 	adr	x2, 40205ec8 <anon.d8c123e08f096c2ebe8598f45112ff88.3.llvm.6038828230051623308+0xc0>
    402033a4:	52800041 	mov	w1, #0x2                   	// #2
    402033a8:	94000634 	bl	40204c78 <core::panicking::panic_bounds_check>

00000000402033ac <reservation_rust_work>:
    402033ac:	d10103ff 	sub	sp, sp, #0x40
    402033b0:	f9001bfe 	str	x30, [sp, #48]
    402033b4:	f100041f 	cmp	x0, #0x1
    402033b8:	54000768 	b.hi	402034a4 <reservation_rust_work+0xf8>  // b.pmore
    402033bc:	aa1f03e9 	mov	x9, xzr
    402033c0:	d503201f 	nop
    402033c4:	100150e8 	adr	x8, 40205de0 <anon.d8c123e08f096c2ebe8598f45112ff88.1.llvm.6038828230051623308>
    402033c8:	910023ea 	add	x10, sp, #0x8
    402033cc:	9280000b 	mov	x11, #0xffffffffffffffff    	// #-1
    402033d0:	f860790d 	ldr	x13, [x8, x0, lsl #3]
    402033d4:	9100e3ec 	add	x12, sp, #0x38
    402033d8:	d503201f 	nop
    402033dc:	101051a8 	adr	x8, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    402033e0:	5280002e 	mov	w14, #0x1                   	// #1
    402033e4:	d503201f 	nop
    402033e8:	1002180f 	adr	x15, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    402033ec:	8b000d08 	add	x8, x8, x0, lsl #3
    402033f0:	8b000def 	add	x15, x15, x0, lsl #3
    402033f4:	a900b7ff 	stp	xzr, x13, [sp, #8]
    402033f8:	f9000fff 	str	xzr, [sp, #24]
    402033fc:	a9027fed 	stp	x13, xzr, [sp, #32]
    40203400:	c89ffd0a 	stlr	x10, [x8]
    40203404:	d503201f 	nop
    40203408:	10021788 	adr	x8, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    4020340c:	8b000d10 	add	x16, x8, x0, lsl #3
    40203410:	d503201f 	nop
    40203414:	10104ef1 	adr	x17, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40203418:	d503201f 	nop
    4020341c:	10104f28 	adr	x8, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40203420:	8b000d12 	add	x18, x8, x0, lsl #3
    40203424:	c8dffde8 	ldar	x8, [x15]
    40203428:	eb0b011f 	cmp	x8, x11
    4020342c:	540000a0 	b.eq	40203440 <reservation_rust_work+0x94>  // b.none
    40203430:	d5033fdf 	isb
    40203434:	d53be02b 	mrs	x11, cntpct_el0
    40203438:	c89ffe4b 	stlr	x11, [x18]
    4020343c:	aa0803eb 	mov	x11, x8
    40203440:	52800208 	mov	w8, #0x10                  	// #16
    40203444:	8b0d05ad 	add	x13, x13, x13, lsl #1
    40203448:	910005ad 	add	x13, x13, #0x1
    4020344c:	f9001fed 	str	x13, [sp, #56]
    40203450:	f9401fed 	ldr	x13, [sp, #56]
    40203454:	71000508 	subs	w8, w8, #0x1
    40203458:	54ffff61 	b.ne	40203444 <reservation_rust_work+0x98>  // b.any
    4020345c:	f94017e8 	ldr	x8, [sp, #40]
    40203460:	cb0801c8 	sub	x8, x14, x8
    40203464:	f100051f 	cmp	x8, #0x1
    40203468:	54000248 	b.hi	402034b0 <reservation_rust_work+0x104>  // b.pmore
    4020346c:	91004129 	add	x9, x9, #0x10
    40203470:	8b081141 	add	x1, x10, x8, lsl #4
    40203474:	f9000029 	str	x9, [x1]
    40203478:	f900042d 	str	x13, [x1, #8]
    4020347c:	91008141 	add	x1, x10, #0x20
    40203480:	c89ffc28 	stlr	x8, [x1]
    40203484:	c8dffe08 	ldar	x8, [x16]
    40203488:	eb08013f 	cmp	x9, x8
    4020348c:	54fffcc1 	b.ne	40203424 <reservation_rust_work+0x78>  // b.any
    40203490:	f8607a28 	ldr	x8, [x17, x0, lsl #3]
    40203494:	f100091f 	cmp	x8, #0x2
    40203498:	54000161 	b.ne	402034c4 <reservation_rust_work+0x118>  // b.any
    4020349c:	d4000021 	svc	#0x1
    402034a0:	17ffffe1 	b	40203424 <reservation_rust_work+0x78>
    402034a4:	d503201f 	nop
    402034a8:	100151c2 	adr	x2, 40205ee0 <anon.d8c123e08f096c2ebe8598f45112ff88.3.llvm.6038828230051623308+0xd8>
    402034ac:	14000004 	b	402034bc <reservation_rust_work+0x110>
    402034b0:	d503201f 	nop
    402034b4:	10015222 	adr	x2, 40205ef8 <anon.d8c123e08f096c2ebe8598f45112ff88.3.llvm.6038828230051623308+0xf0>
    402034b8:	aa0803e0 	mov	x0, x8
    402034bc:	52800041 	mov	w1, #0x2                   	// #2
    402034c0:	940005ee 	bl	40204c78 <core::panicking::panic_bounds_check>
    402034c4:	d4000041 	svc	#0x2
    402034c8:	d4200020 	brk	#0x1

00000000402034cc <reservation_worker_a>:
    402034cc:	f81f0ffe 	str	x30, [sp, #-16]!
    402034d0:	aa1f03e0 	mov	x0, xzr
    402034d4:	97ffffb6 	bl	402033ac <reservation_rust_work>

00000000402034d8 <reservation_worker_b>:
    402034d8:	f81f0ffe 	str	x30, [sp, #-16]!
    402034dc:	52800020 	mov	w0, #0x1                   	// #1
    402034e0:	97ffffb3 	bl	402033ac <reservation_rust_work>

00000000402034e4 <jnox_kernel::reservation_jobs::Jobs::prepare_destination>:
    402034e4:	f9403409 	ldr	x9, [x0, #104]
    402034e8:	b40000c9 	cbz	x9, 40203500 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x1c>
    402034ec:	52800089 	mov	w9, #0x4                   	// #4
    402034f0:	39002109 	strb	w9, [x8, #8]
    402034f4:	52800049 	mov	w9, #0x2                   	// #2
    402034f8:	f9000109 	str	x9, [x8]
    402034fc:	d65f03c0 	ret
    40203500:	aa1f03ea 	mov	x10, xzr
    40203504:	9101e009 	add	x9, x0, #0x78
    40203508:	5280002b 	mov	w11, #0x1                   	// #1
    4020350c:	386a692c 	ldrb	w12, [x9, x10]
    40203510:	3600008b 	tbz	w11, #0, 40203520 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x3c>
    40203514:	2a1f03eb 	mov	w11, wzr
    40203518:	5280002a 	mov	w10, #0x1                   	// #1
    4020351c:	34ffff8c 	cbz	w12, 4020350c <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x28>
    40203520:	35fffe6c 	cbnz	w12, 402034ec <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>
    40203524:	39418009 	ldrb	w9, [x0, #96]
    40203528:	71000d3f 	cmp	w9, #0x3
    4020352c:	54fffe01 	b.ne	402034ec <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>  // b.any
    40203530:	f9403809 	ldr	x9, [x0, #112]
    40203534:	b5fffdc9 	cbnz	x9, 402034ec <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>
    40203538:	aa1f03e1 	mov	x1, xzr
    4020353c:	14000141 	b	40203a40 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>

0000000040203540 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision>:
    40203540:	f9403408 	ldr	x8, [x0, #104]
    40203544:	f100051f 	cmp	x8, #0x1
    40203548:	54000321 	b.ne	402035ac <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x6c>  // b.any
    4020354c:	d10143ff 	sub	sp, sp, #0x50
    40203550:	a9025ffe 	stp	x30, x23, [sp, #32]
    40203554:	a90357f6 	stp	x22, x21, [sp, #48]
    40203558:	a9044ff4 	stp	x20, x19, [sp, #64]
    4020355c:	aa0003f3 	mov	x19, x0
    40203560:	b9400028 	ldr	w8, [x1]
    40203564:	39418829 	ldrb	w9, [x1, #98]
    40203568:	7100011f 	cmp	w8, #0x0
    4020356c:	52800068 	mov	w8, #0x3                   	// #3
    40203570:	1a881128 	csel	w8, w9, w8, ne  // ne = any
    40203574:	39418009 	ldrb	w9, [x0, #96]
    40203578:	71000d3f 	cmp	w9, #0x3
    4020357c:	540001c0 	b.eq	402035b4 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x74>  // b.none
    40203580:	71000d1f 	cmp	w8, #0x3
    40203584:	54000180 	b.eq	402035b4 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x74>  // b.none
    40203588:	2a1f03e0 	mov	w0, wzr
    4020358c:	f940042a 	ldr	x10, [x1, #8]
    40203590:	f9402e6b 	ldr	x11, [x19, #88]
    40203594:	eb0b015f 	cmp	x10, x11
    40203598:	1a9f17ea 	cset	w10, eq  // eq = none
    4020359c:	6b08013f 	cmp	w9, w8
    402035a0:	540007a1 	b.ne	40203694 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    402035a4:	3700012a 	tbnz	w10, #0, 402035c8 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x88>
    402035a8:	1400003b 	b	40203694 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>
    402035ac:	2a1f03e0 	mov	w0, wzr
    402035b0:	d65f03c0 	ret
    402035b4:	2a1f03e0 	mov	w0, wzr
    402035b8:	71000d3f 	cmp	w9, #0x3
    402035bc:	540006c1 	b.ne	40203694 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    402035c0:	71000d1f 	cmp	w8, #0x3
    402035c4:	54000681 	b.ne	40203694 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    402035c8:	aa1f03eb 	mov	x11, xzr
    402035cc:	9101e268 	add	x8, x19, #0x78
    402035d0:	91018029 	add	x9, x1, #0x60
    402035d4:	5280002a 	mov	w10, #0x1                   	// #1
    402035d8:	386b690c 	ldrb	w12, [x8, x11]
    402035dc:	386b692d 	ldrb	w13, [x9, x11]
    402035e0:	360000aa 	tbz	w10, #0, 402035f4 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xb4>
    402035e4:	2a1f03ea 	mov	w10, wzr
    402035e8:	6b0d019f 	cmp	w12, w13
    402035ec:	5280002b 	mov	w11, #0x1                   	// #1
    402035f0:	54ffff40 	b.eq	402035d8 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x98>  // b.none
    402035f4:	6b0d019f 	cmp	w12, w13
    402035f8:	540004c1 	b.ne	40203690 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x150>  // b.any
    402035fc:	f9403a68 	ldr	x8, [x19, #112]
    40203600:	f9402c29 	ldr	x9, [x1, #88]
    40203604:	eb09011f 	cmp	x8, x9
    40203608:	54000441 	b.ne	40203690 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x150>  // b.any
    4020360c:	aa1f03e8 	mov	x8, xzr
    40203610:	91002274 	add	x20, x19, #0x8
    40203614:	b8418675 	ldr	w21, [x19], #24
    40203618:	91010037 	add	x23, x1, #0x40
    4020361c:	aa0803f6 	mov	x22, x8
    40203620:	f100091f 	cmp	x8, #0x2
    40203624:	54000300 	b.eq	40203684 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.none
    40203628:	360000b5 	tbz	w21, #0, 4020363c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xfc>
    4020362c:	b9400268 	ldr	w8, [x19]
    40203630:	f85f0269 	ldur	x9, [x19, #-16]
    40203634:	a90127e8 	stp	x8, x9, [sp, #16]
    40203638:	14000009 	b	4020365c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x11c>
    4020363c:	910023e8 	add	x8, sp, #0x8
    40203640:	aa1403e0 	mov	x0, x20
    40203644:	aa1f03e1 	mov	x1, xzr
    40203648:	940002ec 	bl	402041f8 <jnox_kernel::service_policy::PeriodicReservation::allocation_at>
    4020364c:	f94007e8 	ldr	x8, [sp, #8]
    40203650:	f100051f 	cmp	x8, #0x1
    40203654:	54000181 	b.ne	40203684 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.any
    40203658:	f9400be8 	ldr	x8, [sp, #16]
    4020365c:	f85f82e9 	ldur	x9, [x23, #-8]
    40203660:	eb09011f 	cmp	x8, x9
    40203664:	54000101 	b.ne	40203684 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.any
    40203668:	f84106e9 	ldr	x9, [x23], #16
    4020366c:	91006273 	add	x19, x19, #0x18
    40203670:	f9400fea 	ldr	x10, [sp, #24]
    40203674:	9100a294 	add	x20, x20, #0x28
    40203678:	910006c8 	add	x8, x22, #0x1
    4020367c:	eb09015f 	cmp	x10, x9
    40203680:	54fffce0 	b.eq	4020361c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xdc>  // b.none
    40203684:	f10006df 	cmp	x22, #0x1
    40203688:	1a9f97e0 	cset	w0, hi  // hi = pmore
    4020368c:	14000002 	b	40203694 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>
    40203690:	2a1f03e0 	mov	w0, wzr
    40203694:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40203698:	a94357f6 	ldp	x22, x21, [sp, #48]
    4020369c:	a9425ffe 	ldp	x30, x23, [sp, #32]
    402036a0:	910143ff 	add	sp, sp, #0x50
    402036a4:	d65f03c0 	ret

00000000402036a8 <jnox_kernel::reservation_jobs::Jobs::new>:
    402036a8:	d10203ff 	sub	sp, sp, #0x80
    402036ac:	a90657fe 	stp	x30, x21, [sp, #96]
    402036b0:	a9074ff4 	stp	x20, x19, [sp, #112]
    402036b4:	2a0103f4 	mov	w20, w1
    402036b8:	2a0003f5 	mov	w21, w0
    402036bc:	aa0803f3 	mov	x19, x8
    402036c0:	72001c3f 	tst	w1, #0xff
    402036c4:	540002c0 	b.eq	4020371c <jnox_kernel::reservation_jobs::Jobs::new+0x74>  // b.none
    402036c8:	52800028 	mov	w8, #0x1                   	// #1
    402036cc:	52800049 	mov	w9, #0x2                   	// #2
    402036d0:	290027e8 	stp	w8, w9, [sp]
    402036d4:	12001e8a 	and	w10, w20, #0xff
    402036d8:	7100095f 	cmp	w10, #0x2
    402036dc:	290127e8 	stp	w8, w9, [sp, #8]
    402036e0:	540002a1 	b.ne	40203734 <jnox_kernel::reservation_jobs::Jobs::new+0x8c>  // b.any
    402036e4:	29402be9 	ldp	w9, w10, [sp]
    402036e8:	29022be9 	stp	w9, w10, [sp, #16]
    402036ec:	29412be9 	ldp	w9, w10, [sp, #8]
    402036f0:	29032be9 	stp	w9, w10, [sp, #24]
    402036f4:	52800109 	mov	w9, #0x8                   	// #8
    402036f8:	290427e8 	stp	w8, w9, [sp, #32]
    402036fc:	910043e0 	add	x0, sp, #0x10
    40203700:	52800061 	mov	w1, #0x3                   	// #3
    40203704:	940003cc 	bl	40204634 <jnox_kernel::temporal_policy::admit_reservations>
    40203708:	12001c08 	and	w8, w0, #0xff
    4020370c:	71000d1f 	cmp	w8, #0x3
    40203710:	54000401 	b.ne	40203790 <jnox_kernel::reservation_jobs::Jobs::new+0xe8>  // b.any
    40203714:	52800088 	mov	w8, #0x4                   	// #4
    40203718:	1400003b 	b	40203804 <jnox_kernel::reservation_jobs::Jobs::new+0x15c>
    4020371c:	52800048 	mov	w8, #0x2                   	// #2
    40203720:	52800109 	mov	w9, #0x8                   	// #8
    40203724:	5280002a 	mov	w10, #0x1                   	// #1
    40203728:	290027e8 	stp	w8, w9, [sp]
    4020372c:	52800088 	mov	w8, #0x4                   	// #4
    40203730:	290123ea 	stp	w10, w8, [sp, #8]
    40203734:	910003e0 	mov	x0, sp
    40203738:	52800041 	mov	w1, #0x2                   	// #2
    4020373c:	940003be 	bl	40204634 <jnox_kernel::temporal_policy::admit_reservations>
    40203740:	12001c08 	and	w8, w0, #0xff
    40203744:	71000d1f 	cmp	w8, #0x3
    40203748:	54000241 	b.ne	40203790 <jnox_kernel::reservation_jobs::Jobs::new+0xe8>  // b.any
    4020374c:	34000275 	cbz	w21, 40203798 <jnox_kernel::reservation_jobs::Jobs::new+0xf0>
    40203750:	294027e8 	ldp	w8, w9, [sp]
    40203754:	290a27e8 	stp	w8, w9, [sp, #80]
    40203758:	294127e8 	ldp	w8, w9, [sp, #8]
    4020375c:	290b27e8 	stp	w8, w9, [sp, #88]
    40203760:	910043e8 	add	x8, sp, #0x10
    40203764:	910143e1 	add	x1, sp, #0x50
    40203768:	aa1f03e0 	mov	x0, xzr
    4020376c:	940002e4 	bl	402042fc <jnox_kernel::temporal_policy::HardCbs<_>::new>
    40203770:	b94013e8 	ldr	w8, [sp, #16]
    40203774:	36000468 	tbz	w8, #0, 40203800 <jnox_kernel::reservation_jobs::Jobs::new+0x158>
    40203778:	a941a7ee 	ldp	x14, x9, [sp, #24]
    4020377c:	a942a3eb 	ldp	x11, x8, [sp, #40]
    40203780:	a943abec 	ldp	x12, x10, [sp, #56]
    40203784:	5280002f 	mov	w15, #0x1                   	// #1
    40203788:	f94027ed 	ldr	x13, [sp, #72]
    4020378c:	14000011 	b	402037d0 <jnox_kernel::reservation_jobs::Jobs::new+0x128>
    40203790:	11000508 	add	w8, w8, #0x1
    40203794:	1400001c 	b	40203804 <jnox_kernel::reservation_jobs::Jobs::new+0x15c>
    40203798:	294027e8 	ldp	w8, w9, [sp]
    4020379c:	d100050a 	sub	x10, x8, #0x1
    402037a0:	eb09015f 	cmp	x10, x9
    402037a4:	540002e2 	b.cs	40203800 <jnox_kernel::reservation_jobs::Jobs::new+0x158>  // b.hs, b.nlast
    402037a8:	294137ea 	ldp	w10, w13, [sp, #8]
    402037ac:	d100054b 	sub	x11, x10, #0x1
    402037b0:	eb0d017f 	cmp	x11, x13
    402037b4:	54000262 	b.cs	40203800 <jnox_kernel::reservation_jobs::Jobs::new+0x158>  // b.hs, b.nlast
    402037b8:	aa1f03ec 	mov	x12, xzr
    402037bc:	aa1f03eb 	mov	x11, xzr
    402037c0:	aa1f03ef 	mov	x15, xzr
    402037c4:	72001e9f 	tst	w20, #0xff
    402037c8:	1a9f17f0 	cset	w16, eq  // eq = none
    402037cc:	aa0803ee 	mov	x14, x8
    402037d0:	a9003a6f 	stp	x15, x14, [x19]
    402037d4:	a9012e69 	stp	x9, x11, [x19, #16]
    402037d8:	a9023268 	stp	x8, x12, [x19, #32]
    402037dc:	a903366a 	stp	x10, x13, [x19, #48]
    402037e0:	a9042a70 	stp	x16, x10, [x19, #64]
    402037e4:	f9002a70 	str	x16, [x19, #80]
    402037e8:	52800068 	mov	w8, #0x3                   	// #3
    402037ec:	39018268 	strb	w8, [x19, #96]
    402037f0:	a906fe7f 	stp	xzr, xzr, [x19, #104]
    402037f4:	7900f27f 	strh	wzr, [x19, #120]
    402037f8:	3901ea74 	strb	w20, [x19, #122]
    402037fc:	14000005 	b	40203810 <jnox_kernel::reservation_jobs::Jobs::new+0x168>
    40203800:	52800028 	mov	w8, #0x1                   	// #1
    40203804:	39002268 	strb	w8, [x19, #8]
    40203808:	52800048 	mov	w8, #0x2                   	// #2
    4020380c:	f9000268 	str	x8, [x19]
    40203810:	a9474ff4 	ldp	x20, x19, [sp, #112]
    40203814:	a94657fe 	ldp	x30, x21, [sp, #96]
    40203818:	910203ff 	add	sp, sp, #0x80
    4020381c:	d65f03c0 	ret

0000000040203820 <jnox_kernel::reservation_jobs::Jobs::open>:
    40203820:	d10783ff 	sub	sp, sp, #0x1e0
    40203824:	a9197bfd 	stp	x29, x30, [sp, #400]
    40203828:	a91a67fa 	stp	x26, x25, [sp, #416]
    4020382c:	a91b5ff8 	stp	x24, x23, [sp, #432]
    40203830:	a91c57f6 	stp	x22, x21, [sp, #448]
    40203834:	a91d4ff4 	stp	x20, x19, [sp, #464]
    40203838:	aa0803f3 	mov	x19, x8
    4020383c:	f9403408 	ldr	x8, [x0, #104]
    40203840:	eb08003f 	cmp	x1, x8
    40203844:	540002e1 	b.ne	402038a0 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.any
    40203848:	aa0103f5 	mov	x21, x1
    4020384c:	aa0003f4 	mov	x20, x0
    40203850:	3941e816 	ldrb	w22, [x0, #122]
    40203854:	710002df 	cmp	w22, #0x0
    40203858:	52800148 	mov	w8, #0xa                   	// #10
    4020385c:	52800449 	mov	w9, #0x22                  	// #34
    40203860:	9a880128 	csel	x8, x9, x8, eq  // eq = none
    40203864:	eb08003f 	cmp	x1, x8
    40203868:	540001c2 	b.cs	402038a0 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.hs, b.nlast
    4020386c:	39418288 	ldrb	w8, [x20, #96]
    40203870:	71000d1f 	cmp	w8, #0x3
    40203874:	54000161 	b.ne	402038a0 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.any
    40203878:	aa1403e1 	mov	x1, x20
    4020387c:	f8408428 	ldr	x8, [x1], #8
    40203880:	f100051f 	cmp	x8, #0x1
    40203884:	54000241 	b.ne	402038cc <jnox_kernel::reservation_jobs::Jobs::open+0xac>  // b.any
    40203888:	f9401e97 	ldr	x23, [x20, #56]
    4020388c:	910583e0 	add	x0, sp, #0x160
    40203890:	52800602 	mov	w2, #0x30                  	// #48
    40203894:	94000849 	bl	402059b8 <memcpy>
    40203898:	52800028 	mov	w8, #0x1                   	// #1
    4020389c:	14000021 	b	40203920 <jnox_kernel::reservation_jobs::Jobs::open+0x100>
    402038a0:	52800088 	mov	w8, #0x4                   	// #4
    402038a4:	39002268 	strb	w8, [x19, #8]
    402038a8:	52800048 	mov	w8, #0x2                   	// #2
    402038ac:	f9000268 	str	x8, [x19]
    402038b0:	a95d4ff4 	ldp	x20, x19, [sp, #464]
    402038b4:	a95c57f6 	ldp	x22, x21, [sp, #448]
    402038b8:	a95b5ff8 	ldp	x24, x23, [sp, #432]
    402038bc:	a95a67fa 	ldp	x26, x25, [sp, #416]
    402038c0:	a9597bfd 	ldp	x29, x30, [sp, #400]
    402038c4:	910783ff 	add	sp, sp, #0x1e0
    402038c8:	d65f03c0 	ret
    402038cc:	910203e0 	add	x0, sp, #0x80
    402038d0:	9100a017 	add	x23, x0, #0x28
    402038d4:	52800028 	mov	w8, #0x1                   	// #1
    402038d8:	2a0803f8 	mov	w24, w8
    402038dc:	9100a039 	add	x25, x1, #0x28
    402038e0:	52800502 	mov	w2, #0x28                  	// #40
    402038e4:	94000835 	bl	402059b8 <memcpy>
    402038e8:	2a1f03e8 	mov	w8, wzr
    402038ec:	aa1903e1 	mov	x1, x25
    402038f0:	aa1703e0 	mov	x0, x23
    402038f4:	3707ff38 	tbnz	w24, #0, 402038d8 <jnox_kernel::reservation_jobs::Jobs::open+0xb8>
    402038f8:	910583e0 	add	x0, sp, #0x160
    402038fc:	910203e1 	add	x1, sp, #0x80
    40203900:	52800602 	mov	w2, #0x30                  	// #48
    40203904:	9400082d 	bl	402059b8 <memcpy>
    40203908:	aa1f03e8 	mov	x8, xzr
    4020390c:	a94b27f7 	ldp	x23, x9, [sp, #176]
    40203910:	a94c2fea 	ldp	x10, x11, [sp, #192]
    40203914:	a914abe9 	stp	x9, x10, [sp, #328]
    40203918:	f900afeb 	str	x11, [sp, #344]
    4020391c:	f9402e98 	ldr	x24, [x20, #88]
    40203920:	f9403a99 	ldr	x25, [x20, #112]
    40203924:	f90003e8 	str	x8, [sp]
    40203928:	910003e8 	mov	x8, sp
    4020392c:	7940f29a 	ldrh	w26, [x20, #120]
    40203930:	91002100 	add	x0, x8, #0x8
    40203934:	910583e1 	add	x1, sp, #0x160
    40203938:	52800602 	mov	w2, #0x30                  	// #48
    4020393c:	9400081f 	bl	402059b8 <memcpy>
    40203940:	3901ebf6 	strb	w22, [sp, #122]
    40203944:	a954a7e8 	ldp	x8, x9, [sp, #328]
    40203948:	a903a3f7 	stp	x23, x8, [sp, #56]
    4020394c:	f940afe8 	ldr	x8, [sp, #344]
    40203950:	a904a3e9 	stp	x9, x8, [sp, #72]
    40203954:	a906e7f5 	stp	x21, x25, [sp, #104]
    40203958:	7900f3fa 	strh	w26, [sp, #120]
    4020395c:	f9002ff8 	str	x24, [sp, #88]
    40203960:	52800068 	mov	w8, #0x3                   	// #3
    40203964:	390183e8 	strb	w8, [sp, #96]
    40203968:	910203f7 	add	x23, sp, #0x80
    4020396c:	910203e8 	add	x8, sp, #0x80
    40203970:	910003e0 	mov	x0, sp
    40203974:	aa1503e1 	mov	x1, x21
    40203978:	94000032 	bl	40203a40 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>
    4020397c:	f94043f6 	ldr	x22, [sp, #128]
    40203980:	394223f5 	ldrb	w21, [sp, #136]
    40203984:	f1000adf 	cmp	x22, #0x2
    40203988:	54000061 	b.ne	40203994 <jnox_kernel::reservation_jobs::Jobs::open+0x174>  // b.any
    4020398c:	39002275 	strb	w21, [x19, #8]
    40203990:	17ffffc6 	b	402038a8 <jnox_kernel::reservation_jobs::Jobs::open+0x88>
    40203994:	9103a3e0 	add	x0, sp, #0xe8
    40203998:	910026e1 	add	x1, x23, #0x9
    4020399c:	52800be2 	mov	w2, #0x5f                  	// #95
    402039a0:	94000806 	bl	402059b8 <memcpy>
    402039a4:	910003e1 	mov	x1, sp
    402039a8:	aa1403e0 	mov	x0, x20
    402039ac:	52801002 	mov	w2, #0x80                  	// #128
    402039b0:	94000802 	bl	402059b8 <memcpy>
    402039b4:	f9000276 	str	x22, [x19]
    402039b8:	39002275 	strb	w21, [x19, #8]
    402039bc:	91002660 	add	x0, x19, #0x9
    402039c0:	9103a3e1 	add	x1, sp, #0xe8
    402039c4:	52800be2 	mov	w2, #0x5f                  	// #95
    402039c8:	940007fc 	bl	402059b8 <memcpy>
    402039cc:	17ffffb9 	b	402038b0 <jnox_kernel::reservation_jobs::Jobs::open+0x90>

00000000402039d0 <jnox_kernel::reservation_jobs::Jobs::trap>:
    402039d0:	3941800a 	ldrb	w10, [x0, #96]
    402039d4:	71000d5f 	cmp	w10, #0x3
    402039d8:	54000061 	b.ne	402039e4 <jnox_kernel::reservation_jobs::Jobs::trap+0x14>  // b.any
    402039dc:	52800080 	mov	w0, #0x4                   	// #4
    402039e0:	d65f03c0 	ret
    402039e4:	aa0003e8 	mov	x8, x0
    402039e8:	12001c49 	and	w9, w2, #0xff
    402039ec:	52800080 	mov	w0, #0x4                   	// #4
    402039f0:	6b09015f 	cmp	w10, w9
    402039f4:	54000181 	b.ne	40203a24 <jnox_kernel::reservation_jobs::Jobs::trap+0x54>  // b.any
    402039f8:	f9402d0a 	ldr	x10, [x8, #88]
    402039fc:	eb01015f 	cmp	x10, x1
    40203a00:	54000121 	b.ne	40203a24 <jnox_kernel::reservation_jobs::Jobs::trap+0x54>  // b.any
    40203a04:	f100043f 	cmp	x1, #0x1
    40203a08:	54000108 	b.hi	40203a28 <jnox_kernel::reservation_jobs::Jobs::trap+0x58>  // b.pmore
    40203a0c:	2a1f03e0 	mov	w0, wzr
    40203a10:	11000929 	add	w9, w9, #0x2
    40203a14:	8b01010a 	add	x10, x8, x1
    40203a18:	3901e149 	strb	w9, [x10, #120]
    40203a1c:	52800069 	mov	w9, #0x3                   	// #3
    40203a20:	39018109 	strb	w9, [x8, #96]
    40203a24:	d65f03c0 	ret
    40203a28:	f81f0ffe 	str	x30, [sp, #-16]!
    40203a2c:	d503201f 	nop
    40203a30:	10012702 	adr	x2, 40205f10 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236>
    40203a34:	aa0103e0 	mov	x0, x1
    40203a38:	52800041 	mov	w1, #0x2                   	// #2
    40203a3c:	9400048f 	bl	40204c78 <core::panicking::panic_bounds_check>

0000000040203a40 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>:
    40203a40:	d10483ff 	sub	sp, sp, #0x120
    40203a44:	a90c7bfd 	stp	x29, x30, [sp, #192]
    40203a48:	a90d6ffc 	stp	x28, x27, [sp, #208]
    40203a4c:	a90e67fa 	stp	x26, x25, [sp, #224]
    40203a50:	a90f5ff8 	stp	x24, x23, [sp, #240]
    40203a54:	a91057f6 	stp	x22, x21, [sp, #256]
    40203a58:	a9114ff4 	stp	x20, x19, [sp, #272]
    40203a5c:	aa0103f5 	mov	x21, x1
    40203a60:	aa0003f4 	mov	x20, x0
    40203a64:	aa0803f3 	mov	x19, x8
    40203a68:	3941e808 	ldrb	w8, [x0, #122]
    40203a6c:	910083e9 	add	x9, sp, #0x20
    40203a70:	9100413b 	add	x27, x9, #0x10
    40203a74:	340000e8 	cbz	w8, 40203a90 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x50>
    40203a78:	f10002bf 	cmp	x21, #0x0
    40203a7c:	b21e03e9 	mov	x9, #0x400000004           	// #17179869188
    40203a80:	9a9f0129 	csel	x9, x9, xzr, eq  // eq = none
    40203a84:	7100051f 	cmp	w8, #0x1
    40203a88:	9a9f012a 	csel	x10, x9, xzr, eq  // eq = none
    40203a8c:	1400000b 	b	40203ab8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203a90:	aa1f03ea 	mov	x10, xzr
    40203a94:	f1005ebf 	cmp	x21, #0x17
    40203a98:	54000108 	b.hi	40203ab8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>  // b.pmore
    40203a9c:	52800028 	mov	w8, #0x1                   	// #1
    40203aa0:	9ad52108 	lsl	x8, x8, x21
    40203aa4:	52840629 	mov	w9, #0x2031                	// #8241
    40203aa8:	72a00809 	movk	w9, #0x40, lsl #16
    40203aac:	ea09011f 	tst	x8, x9
    40203ab0:	54000da0 	b.eq	40203c64 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x224>  // b.none
    40203ab4:	5280002a 	mov	w10, #0x1                   	// #1
    40203ab8:	aa1f03f6 	mov	x22, xzr
    40203abc:	a9012bea 	stp	x10, x10, [sp, #16]
    40203ac0:	5280011d 	mov	w29, #0x8                   	// #8
    40203ac4:	910063fa 	add	x26, sp, #0x18
    40203ac8:	5280003c 	mov	w28, #0x1                   	// #1
    40203acc:	b8767b57 	ldr	w23, [x26, x22, lsl #2]
    40203ad0:	34000297 	cbz	w23, 40203b20 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0xe0>
    40203ad4:	8b160298 	add	x24, x20, x22
    40203ad8:	3941e308 	ldrb	w8, [x24, #120]
    40203adc:	71000d1f 	cmp	w8, #0x3
    40203ae0:	7a401904 	ccmp	w8, #0x0, #0x4, ne  // ne = any
    40203ae4:	540014a1 	b.ne	40203d78 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.any
    40203ae8:	8b160a99 	add	x25, x20, x22, lsl #2
    40203aec:	b9407328 	ldr	w8, [x25, #112]
    40203af0:	35001448 	cbnz	w8, 40203d78 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203af4:	f9400288 	ldr	x8, [x20]
    40203af8:	f100051f 	cmp	x8, #0x1
    40203afc:	540000e1 	b.ne	40203b18 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0xd8>  // b.any
    40203b00:	91002280 	add	x0, x20, #0x8
    40203b04:	aa1603e1 	mov	x1, x22
    40203b08:	2a1703e2 	mov	w2, w23
    40203b0c:	9400027e 	bl	40204504 <jnox_kernel::temporal_policy::HardCbs<_>::release>
    40203b10:	f100141f 	cmp	x0, #0x5
    40203b14:	54000a01 	b.ne	40203c54 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x214>  // b.any
    40203b18:	b9007337 	str	w23, [x25, #112]
    40203b1c:	3901e31c 	strb	w28, [x24, #120]
    40203b20:	f10013bd 	subs	x29, x29, #0x4
    40203b24:	910006d6 	add	x22, x22, #0x1
    40203b28:	54fffd21 	b.ne	40203acc <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x8c>  // b.any
    40203b2c:	6f00e400 	movi	v0.2d, #0x0
    40203b30:	ad0103e0 	stp	q0, q0, [sp, #32]
    40203b34:	f9400288 	ldr	x8, [x20]
    40203b38:	f100051f 	cmp	x8, #0x1
    40203b3c:	54000421 	b.ne	40203bc0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x180>  // b.any
    40203b40:	aa1f03f5 	mov	x21, xzr
    40203b44:	aa1f03fb 	mov	x27, xzr
    40203b48:	91006296 	add	x22, x20, #0x18
    40203b4c:	910083f7 	add	x23, sp, #0x20
    40203b50:	910203e8 	add	x8, sp, #0x80
    40203b54:	91002280 	add	x0, x20, #0x8
    40203b58:	aa1503e1 	mov	x1, x21
    40203b5c:	94000290 	bl	4020459c <jnox_kernel::temporal_policy::HardCbs<_>::available>
    40203b60:	a94823e9 	ldp	x9, x8, [sp, #128]
    40203b64:	f100093f 	cmp	x9, #0x2
    40203b68:	54000280 	b.eq	40203bb8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x178>  // b.none
    40203b6c:	36000069 	tbz	w9, #0, 40203b78 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x138>
    40203b70:	f9404be9 	ldr	x9, [sp, #144]
    40203b74:	14000003 	b	40203b80 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x140>
    40203b78:	b94002c8 	ldr	w8, [x22]
    40203b7c:	f85f02c9 	ldur	x9, [x22, #-16]
    40203b80:	8b1b02ea 	add	x10, x23, x27
    40203b84:	9100437b 	add	x27, x27, #0x10
    40203b88:	2a0803e8 	mov	w8, w8
    40203b8c:	a9002548 	stp	x8, x9, [x10]
    40203b90:	910062d6 	add	x22, x22, #0x18
    40203b94:	910006b5 	add	x21, x21, #0x1
    40203b98:	f100837f 	cmp	x27, #0x20
    40203b9c:	54fffda1 	b.ne	40203b50 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x110>  // b.any
    40203ba0:	910203e8 	add	x8, sp, #0x80
    40203ba4:	91002280 	add	x0, x20, #0x8
    40203ba8:	940001f9 	bl	4020438c <jnox_kernel::temporal_policy::HardCbs<_>::tick>
    40203bac:	a94823e9 	ldp	x9, x8, [sp, #128]
    40203bb0:	f100053f 	cmp	x9, #0x1
    40203bb4:	54000641 	b.ne	40203c7c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x23c>  // b.any
    40203bb8:	f100111f 	cmp	x8, #0x4
    40203bbc:	14000027 	b	40203c58 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x218>
    40203bc0:	910083e8 	add	x8, sp, #0x20
    40203bc4:	b27d0117 	orr	x23, x8, #0x8
    40203bc8:	52800a1a 	mov	w26, #0x50                  	// #80
    40203bcc:	91002296 	add	x22, x20, #0x8
    40203bd0:	910203e8 	add	x8, sp, #0x80
    40203bd4:	aa1603e0 	mov	x0, x22
    40203bd8:	aa1503e1 	mov	x1, x21
    40203bdc:	94000187 	bl	402041f8 <jnox_kernel::service_policy::PeriodicReservation::allocation_at>
    40203be0:	b94083e8 	ldr	w8, [sp, #128]
    40203be4:	36001108 	tbz	w8, #0, 40203e04 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c4>
    40203be8:	a948a7e8 	ldp	x8, x9, [sp, #136]
    40203bec:	f100a35a 	subs	x26, x26, #0x28
    40203bf0:	a93fa6e8 	stp	x8, x9, [x23, #-8]
    40203bf4:	9100a2d6 	add	x22, x22, #0x28
    40203bf8:	910042f7 	add	x23, x23, #0x10
    40203bfc:	54fffea1 	b.ne	40203bd0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x190>  // b.any
    40203c00:	aa1f03e8 	mov	x8, xzr
    40203c04:	910083e9 	add	x9, sp, #0x20
    40203c08:	9101c28c 	add	x12, x20, #0x70
    40203c0c:	a90827ec 	stp	x12, x9, [sp, #128]
    40203c10:	5280004a 	mov	w10, #0x2                   	// #2
    40203c14:	a909a7ea 	stp	x10, x9, [sp, #152]
    40203c18:	f9400bf7 	ldr	x23, [sp, #16]
    40203c1c:	9100050a 	add	x10, x8, #0x1
    40203c20:	b868798b 	ldr	w11, [x12, x8, lsl #2]
    40203c24:	3400006b 	cbz	w11, 40203c30 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x1f0>
    40203c28:	f940012b 	ldr	x11, [x9]
    40203c2c:	b50003cb 	cbnz	x11, 40203ca4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x264>
    40203c30:	f100095f 	cmp	x10, #0x2
    40203c34:	aa1b03e9 	mov	x9, x27
    40203c38:	52800028 	mov	w8, #0x1                   	// #1
    40203c3c:	54ffff01 	b.ne	40203c1c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x1dc>  // b.any
    40203c40:	aa1f03e9 	mov	x9, xzr
    40203c44:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203c48:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203c4c:	52800068 	mov	w8, #0x3                   	// #3
    40203c50:	14000059 	b	40203db4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x374>
    40203c54:	f100101f 	cmp	x0, #0x4
    40203c58:	52800068 	mov	w8, #0x3                   	// #3
    40203c5c:	1a880508 	cinc	w8, w8, ne  // ne = any
    40203c60:	1400006a 	b	40203e08 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c8>
    40203c64:	f10006bf 	cmp	x21, #0x1
    40203c68:	540008c0 	b.eq	40203d80 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x340>  // b.none
    40203c6c:	f1005ebf 	cmp	x21, #0x17
    40203c70:	54fff241 	b.ne	40203ab8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>  // b.any
    40203c74:	52800c8a 	mov	w10, #0x64                  	// #100
    40203c78:	17ffff90 	b	40203ab8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203c7c:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203c80:	f9404bf6 	ldr	x22, [sp, #144]
    40203c84:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203c88:	36000808 	tbz	w8, #0, 40203d88 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x348>
    40203c8c:	f10006df 	cmp	x22, #0x1
    40203c90:	f9400bf7 	ldr	x23, [sp, #16]
    40203c94:	54000369 	b.ls	40203d00 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x2c0>  // b.plast
    40203c98:	d503201f 	nop
    40203c9c:	10011522 	adr	x2, 40205f40 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x30>
    40203ca0:	14000067 	b	40203e3c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3fc>
    40203ca4:	f9004bea 	str	x10, [sp, #144]
    40203ca8:	f9400529 	ldr	x9, [x9, #8]
    40203cac:	a90aa3e9 	stp	x9, x8, [sp, #168]
    40203cb0:	f9005fe8 	str	x8, [sp, #184]
    40203cb4:	910183e8 	add	x8, sp, #0x60
    40203cb8:	91002108 	add	x8, x8, #0x8
    40203cbc:	910203e0 	add	x0, sp, #0x80
    40203cc0:	9102a3e1 	add	x1, sp, #0xa8
    40203cc4:	94000098 	bl	40203f24 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold>
    40203cc8:	f9403ff6 	ldr	x22, [sp, #120]
    40203ccc:	f1000adf 	cmp	x22, #0x2
    40203cd0:	54000b22 	b.cs	40203e34 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3f4>  // b.hs, b.nlast
    40203cd4:	52800508 	mov	w8, #0x28                  	// #40
    40203cd8:	91002289 	add	x9, x20, #0x8
    40203cdc:	9b0826c0 	madd	x0, x22, x8, x9
    40203ce0:	aa1503e1 	mov	x1, x21
    40203ce4:	52800022 	mov	w2, #0x1                   	// #1
    40203ce8:	9400015f 	bl	40204264 <jnox_kernel::service_policy::PeriodicReservation::grant_at>
    40203cec:	f100041f 	cmp	x0, #0x1
    40203cf0:	fa410820 	ccmp	x1, #0x1, #0x0, eq  // eq = none
    40203cf4:	54000421 	b.ne	40203d78 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.any
    40203cf8:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203cfc:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203d00:	9101e288 	add	x8, x20, #0x78
    40203d04:	38766908 	ldrb	w8, [x8, x22]
    40203d08:	51000508 	sub	w8, w8, #0x1
    40203d0c:	7100091f 	cmp	w8, #0x2
    40203d10:	54000342 	b.cs	40203d78 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.hs, b.nlast
    40203d14:	9101c28a 	add	x10, x20, #0x70
    40203d18:	b8767948 	ldr	w8, [x10, x22, lsl #2]
    40203d1c:	51000509 	sub	w9, w8, #0x1
    40203d20:	d3607d29 	lsl	x9, x9, #32
    40203d24:	7100011f 	cmp	w8, #0x0
    40203d28:	52808028 	mov	w8, #0x401                 	// #1025
    40203d2c:	9a890108 	csel	x8, x8, x9, eq  // eq = none
    40203d30:	37000248 	tbnz	w8, #0, 40203d78 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203d34:	d360fd08 	lsr	x8, x8, #32
    40203d38:	b8367948 	str	w8, [x10, x22, lsl #2]
    40203d3c:	910103e9 	add	x9, sp, #0x40
    40203d40:	8b161129 	add	x9, x9, x22, lsl #4
    40203d44:	f940012a 	ldr	x10, [x9]
    40203d48:	b400018a 	cbz	x10, 40203d78 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203d4c:	d100054a 	sub	x10, x10, #0x1
    40203d50:	f900012a 	str	x10, [x9]
    40203d54:	3941ea89 	ldrb	w9, [x20, #122]
    40203d58:	7100093f 	cmp	w9, #0x2
    40203d5c:	540001e0 	b.eq	40203d98 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x358>  // b.none
    40203d60:	7100053f 	cmp	w9, #0x1
    40203d64:	540001e1 	b.ne	40203da0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x360>  // b.any
    40203d68:	f100011f 	cmp	x8, #0x0
    40203d6c:	52800048 	mov	w8, #0x2                   	// #2
    40203d70:	1a9f0108 	csel	w8, w8, wzr, eq  // eq = none
    40203d74:	1400000d 	b	40203da8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x368>
    40203d78:	52800088 	mov	w8, #0x4                   	// #4
    40203d7c:	14000023 	b	40203e08 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c8>
    40203d80:	d2c00c8a 	mov	x10, #0x6400000000          	// #429496729600
    40203d84:	17ffff4d 	b	40203ab8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203d88:	aa1f03e9 	mov	x9, xzr
    40203d8c:	52800068 	mov	w8, #0x3                   	// #3
    40203d90:	f9400bf7 	ldr	x23, [sp, #16]
    40203d94:	14000008 	b	40203db4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x374>
    40203d98:	2a1f03e8 	mov	w8, wzr
    40203d9c:	14000003 	b	40203da8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x368>
    40203da0:	f100011f 	cmp	x8, #0x0
    40203da4:	1a9f17e8 	cset	w8, eq  // eq = none
    40203da8:	f9002e96 	str	x22, [x20, #88]
    40203dac:	52800029 	mov	w9, #0x1                   	// #1
    40203db0:	39018288 	strb	w8, [x20, #96]
    40203db4:	f940368a 	ldr	x10, [x20, #104]
    40203db8:	b100055f 	cmn	x10, #0x1
    40203dbc:	54000240 	b.eq	40203e04 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c4>  // b.none
    40203dc0:	9100054a 	add	x10, x10, #0x1
    40203dc4:	f900368a 	str	x10, [x20, #104]
    40203dc8:	a9422fea 	ldp	x10, x11, [sp, #32]
    40203dcc:	a94337ec 	ldp	x12, x13, [sp, #48]
    40203dd0:	a902326b 	stp	x11, x12, [x19, #32]
    40203dd4:	a94433eb 	ldp	x11, x12, [sp, #64]
    40203dd8:	a9032e6d 	stp	x13, x11, [x19, #48]
    40203ddc:	a9452fed 	ldp	x13, x11, [sp, #80]
    40203de0:	a904366c 	stp	x12, x13, [x19, #64]
    40203de4:	a9005a69 	stp	x9, x22, [x19]
    40203de8:	7940f289 	ldrh	w9, [x20, #120]
    40203dec:	f9403a8c 	ldr	x12, [x20, #112]
    40203df0:	a9012a77 	stp	x23, x10, [x19, #16]
    40203df4:	a905326b 	stp	x11, x12, [x19, #80]
    40203df8:	7900c269 	strh	w9, [x19, #96]
    40203dfc:	39018a68 	strb	w8, [x19, #98]
    40203e00:	14000005 	b	40203e14 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3d4>
    40203e04:	52800068 	mov	w8, #0x3                   	// #3
    40203e08:	39002268 	strb	w8, [x19, #8]
    40203e0c:	52800048 	mov	w8, #0x2                   	// #2
    40203e10:	f9000268 	str	x8, [x19]
    40203e14:	a9514ff4 	ldp	x20, x19, [sp, #272]
    40203e18:	a95057f6 	ldp	x22, x21, [sp, #256]
    40203e1c:	a94f5ff8 	ldp	x24, x23, [sp, #240]
    40203e20:	a94e67fa 	ldp	x26, x25, [sp, #224]
    40203e24:	a94d6ffc 	ldp	x28, x27, [sp, #208]
    40203e28:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    40203e2c:	910483ff 	add	sp, sp, #0x120
    40203e30:	d65f03c0 	ret
    40203e34:	d503201f 	nop
    40203e38:	10010782 	adr	x2, 40205f28 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x18>
    40203e3c:	aa1603e0 	mov	x0, x22
    40203e40:	52800041 	mov	w1, #0x2                   	// #2
    40203e44:	9400038d 	bl	40204c78 <core::panicking::panic_bounds_check>

0000000040203e48 <jnox_kernel::reservation_jobs::Clock::new>:
    40203e48:	b40005a1 	cbz	x1, 40203efc <jnox_kernel::reservation_jobs::Clock::new+0xb4>
    40203e4c:	d343fc29 	lsr	x9, x1, #3
    40203e50:	d29ef9ea 	mov	x10, #0xf7cf                	// #63439
    40203e54:	f2bc6a6a 	movk	x10, #0xe353, lsl #16
    40203e58:	f2d374aa 	movk	x10, #0x9ba5, lsl #32
    40203e5c:	f2e4188a 	movk	x10, #0x20c4, lsl #48
    40203e60:	9bca7d29 	umulh	x9, x9, x10
    40203e64:	d344fd29 	lsr	x9, x9, #4
    40203e68:	52807d0a 	mov	w10, #0x3e8                 	// #1000
    40203e6c:	9b0a852a 	msub	x10, x9, x10, x1
    40203e70:	b500046a 	cbnz	x10, 40203efc <jnox_kernel::reservation_jobs::Clock::new+0xb4>
    40203e74:	b202e7ea 	mov	x10, #0xcccccccccccccccc    	// #-3689348814741910324
    40203e78:	f29999aa 	movk	x10, #0xcccd
    40203e7c:	9bca7c2a 	umulh	x10, x1, x10
    40203e80:	d344fd4a 	lsr	x10, x10, #4
    40203e84:	72001c5f 	tst	w2, #0xff
    40203e88:	5280014b 	mov	w11, #0xa                   	// #10
    40203e8c:	5280050c 	mov	w12, #0x28                  	// #40
    40203e90:	9a8b018b 	csel	x11, x12, x11, eq  // eq = none
    40203e94:	9bca7d6c 	umulh	x12, x11, x10
    40203e98:	eb0c03ff 	cmp	xzr, x12
    40203e9c:	1a9f07ec 	cset	w12, ne  // ne = any
    40203ea0:	9b0a7d6b 	mul	x11, x11, x10
    40203ea4:	ab0b001f 	cmn	x0, x11
    40203ea8:	1a9f37eb 	cset	w11, cs  // cs = hs, nlast
    40203eac:	3700020c 	tbnz	w12, #0, 40203eec <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203eb0:	350001eb 	cbnz	w11, 40203eec <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203eb4:	72001c5f 	tst	w2, #0xff
    40203eb8:	5280014b 	mov	w11, #0xa                   	// #10
    40203ebc:	5280044c 	mov	w12, #0x22                  	// #34
    40203ec0:	9a8b018b 	csel	x11, x12, x11, eq  // eq = none
    40203ec4:	9bca7d6c 	umulh	x12, x11, x10
    40203ec8:	eb0c03ff 	cmp	xzr, x12
    40203ecc:	1a9f07ed 	cset	w13, ne  // ne = any
    40203ed0:	9b0a7d6b 	mul	x11, x11, x10
    40203ed4:	ab00016b 	adds	x11, x11, x0
    40203ed8:	1a9f37ec 	cset	w12, cs  // cs = hs, nlast
    40203edc:	3700008d 	tbnz	w13, #0, 40203eec <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203ee0:	3500006c 	cbnz	w12, 40203eec <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203ee4:	ab09057f 	cmn	x11, x9, lsl #1
    40203ee8:	54000123 	b.cc	40203f0c <jnox_kernel::reservation_jobs::Clock::new+0xc4>  // b.lo, b.ul, b.last
    40203eec:	52800069 	mov	w9, #0x3                   	// #3
    40203ef0:	39000509 	strb	w9, [x8, #1]
    40203ef4:	5280002b 	mov	w11, #0x1                   	// #1
    40203ef8:	14000003 	b	40203f04 <jnox_kernel::reservation_jobs::Clock::new+0xbc>
    40203efc:	5280002b 	mov	w11, #0x1                   	// #1
    40203f00:	3900050b 	strb	w11, [x8, #1]
    40203f04:	3900010b 	strb	w11, [x8]
    40203f08:	d65f03c0 	ret
    40203f0c:	2a1f03eb 	mov	w11, wzr
    40203f10:	a900a900 	stp	x0, x10, [x8, #8]
    40203f14:	f9000d09 	str	x9, [x8, #24]
    40203f18:	17fffffb 	b	40203f04 <jnox_kernel::reservation_jobs::Clock::new+0xbc>

0000000040203f1c <__rustc::rust_begin_unwind>:
    40203f1c:	d503205f 	wfe
    40203f20:	17ffffff 	b	40203f1c <__rustc::rust_begin_unwind>

0000000040203f24 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold>:
    40203f24:	d10103ff 	sub	sp, sp, #0x40
    40203f28:	f9001bfe 	str	x30, [sp, #48]
    40203f2c:	a9412809 	ldp	x9, x10, [x0, #16]
    40203f30:	eb0a013f 	cmp	x9, x10
    40203f34:	540004e2 	b.cs	40203fd0 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0xac>  // b.hs, b.nlast
    40203f38:	f940100e 	ldr	x14, [x0, #32]
    40203f3c:	a940340b 	ldp	x11, x13, [x0]
    40203f40:	910003ec 	mov	x12, sp
    40203f44:	9100618c 	add	x12, x12, #0x18
    40203f48:	f100093f 	cmp	x9, #0x2
    40203f4c:	5280004f 	mov	w15, #0x2                   	// #2
    40203f50:	9a8f8120 	csel	x0, x9, x15, hi  // hi = pmore
    40203f54:	8b0911ad 	add	x13, x13, x9, lsl #4
    40203f58:	8b0911ce 	add	x14, x14, x9, lsl #4
    40203f5c:	910021ce 	add	x14, x14, #0x8
    40203f60:	eb09001f 	cmp	x0, x9
    40203f64:	54000440 	b.eq	40203fec <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0xc8>  // b.none
    40203f68:	b869796f 	ldr	w15, [x11, x9, lsl #2]
    40203f6c:	3400028f 	cbz	w15, 40203fbc <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x98>
    40203f70:	f94001af 	ldr	x15, [x13]
    40203f74:	b400024f 	cbz	x15, 40203fbc <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x98>
    40203f78:	f94001cf 	ldr	x15, [x14]
    40203f7c:	a9404430 	ldp	x16, x17, [x1]
    40203f80:	a90047f0 	stp	x16, x17, [sp]
    40203f84:	f9400831 	ldr	x17, [x1, #16]
    40203f88:	a9013ff1 	stp	x17, x15, [sp, #16]
    40203f8c:	eb0f021f 	cmp	x16, x15
    40203f90:	a90227e9 	stp	x9, x9, [sp, #32]
    40203f94:	54000061 	b.ne	40203fa0 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x7c>  // b.any
    40203f98:	f94007ef 	ldr	x15, [sp, #8]
    40203f9c:	eb0901ff 	cmp	x15, x9
    40203fa0:	aa0c03ef 	mov	x15, x12
    40203fa4:	54000048 	b.hi	40203fac <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x88>  // b.pmore
    40203fa8:	910003ef 	mov	x15, sp
    40203fac:	a94045f0 	ldp	x16, x17, [x15]
    40203fb0:	a9004430 	stp	x16, x17, [x1]
    40203fb4:	f94009ef 	ldr	x15, [x15, #16]
    40203fb8:	f900082f 	str	x15, [x1, #16]
    40203fbc:	91000529 	add	x9, x9, #0x1
    40203fc0:	910041ad 	add	x13, x13, #0x10
    40203fc4:	910041ce 	add	x14, x14, #0x10
    40203fc8:	eb09015f 	cmp	x10, x9
    40203fcc:	54fffca1 	b.ne	40203f60 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x3c>  // b.any
    40203fd0:	a9402829 	ldp	x9, x10, [x1]
    40203fd4:	a9002909 	stp	x9, x10, [x8]
    40203fd8:	f9400829 	ldr	x9, [x1, #16]
    40203fdc:	f9000909 	str	x9, [x8, #16]
    40203fe0:	f9401bfe 	ldr	x30, [sp, #48]
    40203fe4:	910103ff 	add	sp, sp, #0x40
    40203fe8:	d65f03c0 	ret
    40203fec:	d503201f 	nop
    40203ff0:	1000ff42 	adr	x2, 40205fd8 <anon.e5cf9e378689f0b52d762c1b402a78cc.8.llvm.5630279096503145348>
    40203ff4:	52800041 	mov	w1, #0x2                   	// #2
    40203ff8:	94000320 	bl	40204c78 <core::panicking::panic_bounds_check>

0000000040203ffc <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>:
    40203ffc:	d10083ff 	sub	sp, sp, #0x20
    40204000:	d503201f 	nop
    40204004:	10ffa649 	adr	x9, 402034cc <reservation_worker_a>
    40204008:	d503201f 	nop
    4020400c:	10ffa66a 	adr	x10, 402034d8 <reservation_worker_b>
    40204010:	f90003e9 	str	x9, [sp]
    40204014:	a900fbea 	stp	x10, x30, [sp, #8]
    40204018:	f100043f 	cmp	x1, #0x1
    4020401c:	540009c8 	b.hi	40204154 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x158>  // b.pmore
    40204020:	d503201f 	nop
    40204024:	1009b7e9 	adr	x9, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308>
    40204028:	8b01392a 	add	x10, x9, x1, lsl #14
    4020402c:	9140114b 	add	x11, x10, #0x4, lsl #12
    40204030:	52879809 	mov	w9, #0x3cc0                	// #15552
    40204034:	8b090149 	add	x9, x10, x9
    40204038:	eb09017f 	cmp	x11, x9
    4020403c:	540008a3 	b.cc	40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.lo, b.ul, b.last
    40204040:	eb0a013f 	cmp	x9, x10
    40204044:	54000863 	b.cc	40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.lo, b.ul, b.last
    40204048:	f940000a 	ldr	x10, [x0]
    4020404c:	8b010d4b 	add	x11, x10, x1, lsl #3
    40204050:	f940b56d 	ldr	x13, [x11, #360]
    40204054:	eb0d013f 	cmp	x9, x13
    40204058:	540007c1 	b.ne	40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    4020405c:	910003ea 	mov	x10, sp
    40204060:	f861794a 	ldr	x10, [x10, x1, lsl #3]
    40204064:	f9407dac 	ldr	x12, [x13, #248]
    40204068:	eb0a019f 	cmp	x12, x10
    4020406c:	54000721 	b.ne	40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    40204070:	f94081ac 	ldr	x12, [x13, #256]
    40204074:	f10d159f 	cmp	x12, #0x345
    40204078:	540006c1 	b.ne	40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    4020407c:	f9404dac 	ldr	x12, [x13, #152]
    40204080:	b500068c 	cbnz	x12, 40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    40204084:	d503201f 	nop
    40204088:	1000eacc 	adr	x12, 40205de0 <anon.d8c123e08f096c2ebe8598f45112ff88.1.llvm.6038828230051623308>
    4020408c:	f861798c 	ldr	x12, [x12, x1, lsl #3]
    40204090:	f9408dad 	ldr	x13, [x13, #280]
    40204094:	eb0c01bf 	cmp	x13, x12
    40204098:	540005c1 	b.ne	40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    4020409c:	d503201f 	nop
    402040a0:	1001b24d 	adr	x13, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    402040a4:	8b010dad 	add	x13, x13, x1, lsl #3
    402040a8:	c8dffdad 	ldar	x13, [x13]
    402040ac:	b10005bf 	cmn	x13, #0x1
    402040b0:	54000501 	b.ne	40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    402040b4:	d503201f 	nop
    402040b8:	100fe9cd 	adr	x13, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    402040bc:	8b010dad 	add	x13, x13, x1, lsl #3
    402040c0:	c8dffdad 	ldar	x13, [x13]
    402040c4:	b500046d 	cbnz	x13, 40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    402040c8:	d503201f 	nop
    402040cc:	1001b16d 	adr	x13, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    402040d0:	8b010dad 	add	x13, x13, x1, lsl #3
    402040d4:	c8dffdad 	ldar	x13, [x13]
    402040d8:	b10005bf 	cmn	x13, #0x1
    402040dc:	540003a1 	b.ne	40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    402040e0:	d503201f 	nop
    402040e4:	100fe8ed 	adr	x13, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    402040e8:	8b010dad 	add	x13, x13, x1, lsl #3
    402040ec:	c8dffdad 	ldar	x13, [x13]
    402040f0:	b500030d 	cbnz	x13, 40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    402040f4:	d503201f 	nop
    402040f8:	100fe8cd 	adr	x13, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    402040fc:	8b010dad 	add	x13, x13, x1, lsl #3
    40204100:	c8dffdad 	ldar	x13, [x13]
    40204104:	b500026d 	cbnz	x13, 40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    40204108:	f940e16d 	ldr	x13, [x11, #448]
    4020410c:	b500022d 	cbnz	x13, 40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    40204110:	f940e96d 	ldr	x13, [x11, #464]
    40204114:	eb0c01bf 	cmp	x13, x12
    40204118:	540001c1 	b.ne	40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    4020411c:	f940c96d 	ldr	x13, [x11, #400]
    40204120:	b10005bf 	cmn	x13, #0x1
    40204124:	54000161 	b.ne	40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    40204128:	f940d16b 	ldr	x11, [x11, #416]
    4020412c:	b500012b 	cbnz	x11, 40204150 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    40204130:	a9002909 	stp	x9, x10, [x8]
    40204134:	528068a9 	mov	w9, #0x345                 	// #837
    40204138:	a9017d09 	stp	x9, xzr, [x8, #16]
    4020413c:	a9027d0c 	stp	x12, xzr, [x8, #32]
    40204140:	f900190c 	str	x12, [x8, #48]
    40204144:	f9400bfe 	ldr	x30, [sp, #16]
    40204148:	910083ff 	add	sp, sp, #0x20
    4020414c:	d65f03c0 	ret
    40204150:	97fff456 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40204154:	d503201f 	nop
    40204158:	1000f4c2 	adr	x2, 40205ff0 <anon.e5cf9e378689f0b52d762c1b402a78cc.8.llvm.5630279096503145348+0x18>
    4020415c:	aa0103e0 	mov	x0, x1
    40204160:	52800041 	mov	w1, #0x2                   	// #2
    40204164:	940002c5 	bl	40204c78 <core::panicking::panic_bounds_check>

0000000040204168 <jnox_kernel::uart_write>:
    40204168:	b40001a1 	cbz	x1, 4020419c <jnox_kernel::uart_write+0x34>
    4020416c:	8b010008 	add	x8, x0, x1
    40204170:	52800309 	mov	w9, #0x18                  	// #24
    40204174:	72a12009 	movk	w9, #0x900, lsl #16
    40204178:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    4020417c:	3840140b 	ldrb	w11, [x0], #1
    40204180:	b940012c 	ldr	w12, [x9]
    40204184:	3628006c 	tbz	w12, #5, 40204190 <jnox_kernel::uart_write+0x28>
    40204188:	d5033fdf 	isb
    4020418c:	17fffffd 	b	40204180 <jnox_kernel::uart_write+0x18>
    40204190:	b900014b 	str	w11, [x10]
    40204194:	eb08001f 	cmp	x0, x8
    40204198:	54ffff21 	b.ne	4020417c <jnox_kernel::uart_write+0x14>  // b.any
    4020419c:	d65f03c0 	ret

00000000402041a0 <jnox_kernel::kernel_main>:
    402041a0:	f00000e8 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.6038828230051623308+0xb8e0>
    402041a4:	f9471108 	ldr	x8, [x8, #3616]
    402041a8:	b4000068 	cbz	x8, 402041b4 <jnox_kernel::kernel_main+0x14>
    402041ac:	d503205f 	wfe
    402041b0:	17ffffff 	b	402041ac <jnox_kernel::kernel_main+0xc>
    402041b4:	f81f0ffe 	str	x30, [sp, #-16]!
    402041b8:	52800608 	mov	w8, #0x30                  	// #48
    402041bc:	72a12008 	movk	w8, #0x900, lsl #16
    402041c0:	b900011f 	str	wzr, [x8]
    402041c4:	528001a9 	mov	w9, #0xd                   	// #13
    402041c8:	5280002a 	mov	w10, #0x1                   	// #1
    402041cc:	b81f4109 	stur	w9, [x8, #-12]
    402041d0:	b81f810a 	stur	w10, [x8, #-8]
    402041d4:	52800c09 	mov	w9, #0x60                  	// #96
    402041d8:	b81fc109 	stur	w9, [x8, #-4]
    402041dc:	52802029 	mov	w9, #0x101                 	// #257
    402041e0:	b9000109 	str	w9, [x8]
    402041e4:	d503201f 	nop
    402041e8:	1000eb80 	adr	x0, 40205f58 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x48>
    402041ec:	52800361 	mov	w1, #0x1b                  	// #27
    402041f0:	97ffffde 	bl	40204168 <jnox_kernel::uart_write>
    402041f4:	97fff708 	bl	40201e14 <jnox_kernel::ordinary_reservations::run>

00000000402041f8 <jnox_kernel::service_policy::PeriodicReservation::allocation_at>:
    402041f8:	f9400809 	ldr	x9, [x0, #16]
    402041fc:	eb09002a 	subs	x10, x1, x9
    40204200:	54000062 	b.cs	4020420c <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x14>  // b.hs, b.nlast
    40204204:	aa1f03ea 	mov	x10, xzr
    40204208:	1400000f 	b	40204244 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x4c>
    4020420c:	f940040b 	ldr	x11, [x0, #8]
    40204210:	b400022b 	cbz	x11, 40204254 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x5c>
    40204214:	9acb0949 	udiv	x9, x10, x11
    40204218:	cb0a03ec 	neg	x12, x10
    4020421c:	9b0b3129 	madd	x9, x9, x11, x12
    40204220:	8b090029 	add	x9, x1, x9
    40204224:	ab0b0129 	adds	x9, x9, x11
    40204228:	54000063 	b.cc	40204234 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x3c>  // b.lo, b.ul, b.last
    4020422c:	aa1f03eb 	mov	x11, xzr
    40204230:	14000007 	b	4020424c <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x54>
    40204234:	eb0b015f 	cmp	x10, x11
    40204238:	5280030a 	mov	w10, #0x18                  	// #24
    4020423c:	9a9f314a 	csel	x10, x10, xzr, cc  // cc = lo, ul, last
    40204240:	f86a680a 	ldr	x10, [x0, x10]
    40204244:	5280002b 	mov	w11, #0x1                   	// #1
    40204248:	a900a50a 	stp	x10, x9, [x8, #8]
    4020424c:	f900010b 	str	x11, [x8]
    40204250:	d65f03c0 	ret
    40204254:	f81f0ffe 	str	x30, [sp, #-16]!
    40204258:	d503201f 	nop
    4020425c:	1000e8e0 	adr	x0, 40205f78 <anon.e5cf9e378689f0b52d762c1b402a78cc.2.llvm.5630279096503145348>
    40204260:	9400048c 	bl	40205490 <core::panicking::panic_const::panic_const_rem_by_zero>

0000000040204264 <jnox_kernel::service_policy::PeriodicReservation::grant_at>:
    40204264:	f9401008 	ldr	x8, [x0, #32]
    40204268:	eb08003f 	cmp	x1, x8
    4020426c:	54000062 	b.cs	40204278 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x14>  // b.hs, b.nlast
    40204270:	aa1f03e0 	mov	x0, xzr
    40204274:	1400001c 	b	402042e4 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x80>
    40204278:	f9400408 	ldr	x8, [x0, #8]
    4020427c:	b4000388 	cbz	x8, 402042ec <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x88>
    40204280:	f9400809 	ldr	x9, [x0, #16]
    40204284:	cb09002a 	sub	x10, x1, x9
    40204288:	9ac80949 	udiv	x9, x10, x8
    4020428c:	9b08a929 	msub	x9, x9, x8, x10
    40204290:	eb08015f 	cmp	x10, x8
    40204294:	54000062 	b.cs	402042a0 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x3c>  // b.hs, b.nlast
    40204298:	9100600a 	add	x10, x0, #0x18
    4020429c:	14000004 	b	402042ac <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x48>
    402042a0:	cb09002a 	sub	x10, x1, x9
    402042a4:	f900080a 	str	x10, [x0, #16]
    402042a8:	aa0003ea 	mov	x10, x0
    402042ac:	f940014a 	ldr	x10, [x10]
    402042b0:	eb02015f 	cmp	x10, x2
    402042b4:	9a82314b 	csel	x11, x10, x2, cc  // cc = lo, ul, last
    402042b8:	cb090108 	sub	x8, x8, x9
    402042bc:	eb0b011f 	cmp	x8, x11
    402042c0:	9a8b3109 	csel	x9, x8, x11, cc  // cc = lo, ul, last
    402042c4:	aa2103e8 	mvn	x8, x1
    402042c8:	eb09011f 	cmp	x8, x9
    402042cc:	da812128 	csinv	x8, x9, x1, cs  // cs = hs, nlast
    402042d0:	cb08014a 	sub	x10, x10, x8
    402042d4:	ab010129 	adds	x9, x9, x1
    402042d8:	da9f3129 	csinv	x9, x9, xzr, cc  // cc = lo, ul, last
    402042dc:	a901a40a 	stp	x10, x9, [x0, #24]
    402042e0:	52800020 	mov	w0, #0x1                   	// #1
    402042e4:	aa0803e1 	mov	x1, x8
    402042e8:	d65f03c0 	ret
    402042ec:	f81f0ffe 	str	x30, [sp, #-16]!
    402042f0:	d503201f 	nop
    402042f4:	1000e4e0 	adr	x0, 40205f90 <anon.e5cf9e378689f0b52d762c1b402a78cc.3.llvm.5630279096503145348>
    402042f8:	94000466 	bl	40205490 <core::panicking::panic_const::panic_const_rem_by_zero>

00000000402042fc <jnox_kernel::temporal_policy::HardCbs<_>::new>:
    402042fc:	d10143ff 	sub	sp, sp, #0x50
    40204300:	a90357fe 	stp	x30, x21, [sp, #48]
    40204304:	a9044ff4 	stp	x20, x19, [sp, #64]
    40204308:	aa0103f5 	mov	x21, x1
    4020430c:	aa0003f4 	mov	x20, x0
    40204310:	aa0803f3 	mov	x19, x8
    40204314:	aa0103e0 	mov	x0, x1
    40204318:	52800041 	mov	w1, #0x2                   	// #2
    4020431c:	940000c6 	bl	40204634 <jnox_kernel::temporal_policy::admit_reservations>
    40204320:	12001c08 	and	w8, w0, #0xff
    40204324:	71000d1f 	cmp	w8, #0x3
    40204328:	54000261 	b.ne	40204374 <jnox_kernel::temporal_policy::HardCbs<_>::new+0x78>  // b.any
    4020432c:	910003e9 	mov	x9, sp
    40204330:	91006128 	add	x8, x9, #0x18
    40204334:	5280002a 	mov	w10, #0x1                   	// #1
    40204338:	f9000134 	str	x20, [x9]
    4020433c:	28c132ab 	ldp	w11, w12, [x21], #8
    40204340:	2a0a03ed 	mov	w13, w10
    40204344:	2901312b 	stp	w11, w12, [x9, #8]
    40204348:	f900093f 	str	xzr, [x9, #16]
    4020434c:	aa0803e9 	mov	x9, x8
    40204350:	2a1f03ea 	mov	w10, wzr
    40204354:	3707ff2d 	tbnz	w13, #0, 40204338 <jnox_kernel::temporal_policy::HardCbs<_>::new+0x3c>
    40204358:	91002260 	add	x0, x19, #0x8
    4020435c:	910003e1 	mov	x1, sp
    40204360:	52800602 	mov	w2, #0x30                  	// #48
    40204364:	94000595 	bl	402059b8 <memcpy>
    40204368:	f9001e74 	str	x20, [x19, #56]
    4020436c:	52800028 	mov	w8, #0x1                   	// #1
    40204370:	14000002 	b	40204378 <jnox_kernel::temporal_policy::HardCbs<_>::new+0x7c>
    40204374:	aa1f03e8 	mov	x8, xzr
    40204378:	f9000268 	str	x8, [x19]
    4020437c:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40204380:	a94357fe 	ldp	x30, x21, [sp, #48]
    40204384:	910143ff 	add	sp, sp, #0x50
    40204388:	d65f03c0 	ret

000000004020438c <jnox_kernel::temporal_policy::HardCbs<_>::tick>:
    4020438c:	d10203ff 	sub	sp, sp, #0x80
    40204390:	a9027bfd 	stp	x29, x30, [sp, #32]
    40204394:	a9036ffc 	stp	x28, x27, [sp, #48]
    40204398:	a90467fa 	stp	x26, x25, [sp, #64]
    4020439c:	a9055ff8 	stp	x24, x23, [sp, #80]
    402043a0:	a90657f6 	stp	x22, x21, [sp, #96]
    402043a4:	a9074ff4 	stp	x20, x19, [sp, #112]
    402043a8:	aa0803f3 	mov	x19, x8
    402043ac:	f940181b 	ldr	x27, [x0, #48]
    402043b0:	b100077a 	adds	x26, x27, #0x1
    402043b4:	540000a3 	b.cc	402043c8 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x3c>  // b.lo, b.ul, b.last
    402043b8:	aa1f03f4 	mov	x20, xzr
    402043bc:	52800037 	mov	w23, #0x1                   	// #1
    402043c0:	52800089 	mov	w9, #0x4                   	// #4
    402043c4:	1400003e 	b	402044bc <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    402043c8:	aa0003f5 	mov	x21, x0
    402043cc:	2a1f03fc 	mov	w28, wzr
    402043d0:	aa1f03e8 	mov	x8, xzr
    402043d4:	aa1f03fd 	mov	x29, xzr
    402043d8:	91005018 	add	x24, x0, #0x14
    402043dc:	52800037 	mov	w23, #0x1                   	// #1
    402043e0:	910063bd 	add	x29, x29, #0x18
    402043e4:	aa0803f6 	mov	x22, x8
    402043e8:	8b1d0308 	add	x8, x24, x29
    402043ec:	b85e8108 	ldur	w8, [x8, #-24]
    402043f0:	340000e8 	cbz	w8, 4020440c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x80>
    402043f4:	910023e8 	add	x8, sp, #0x8
    402043f8:	aa1503e0 	mov	x0, x21
    402043fc:	aa1603e1 	mov	x1, x22
    40204400:	94000067 	bl	4020459c <jnox_kernel::temporal_policy::HardCbs<_>::available>
    40204404:	f94007e8 	ldr	x8, [sp, #8]
    40204408:	b50000c8 	cbnz	x8, 40204420 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x94>
    4020440c:	910063bd 	add	x29, x29, #0x18
    40204410:	910006d6 	add	x22, x22, #0x1
    40204414:	f10123bf 	cmp	x29, #0x48
    40204418:	54fffe81 	b.ne	402043e8 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x5c>  // b.any
    4020441c:	14000014 	b	4020446c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0xe0>
    40204420:	f100091f 	cmp	x8, #0x2
    40204424:	a9412be9 	ldp	x9, x10, [sp, #16]
    40204428:	54000400 	b.eq	402044a8 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x11c>  // b.none
    4020442c:	eb1b015f 	cmp	x10, x27
    40204430:	540005a9 	b.ls	402044e4 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x158>  // b.plast
    40204434:	910006c8 	add	x8, x22, #0x1
    40204438:	eb19015f 	cmp	x10, x25
    4020443c:	1a9f37eb 	cset	w11, cs  // cs = hs, nlast
    40204440:	6a0b039f 	tst	w28, w11
    40204444:	9a961294 	csel	x20, x20, x22, ne  // ne = any
    40204448:	9a8a1339 	csel	x25, x25, x10, ne  // ne = any
    4020444c:	b94007ea 	ldr	w10, [sp, #4]
    40204450:	1a89114a 	csel	w10, w10, w9, ne  // ne = any
    40204454:	b90007ea 	str	w10, [sp, #4]
    40204458:	5280003c 	mov	w28, #0x1                   	// #1
    4020445c:	f100c3bf 	cmp	x29, #0x30
    40204460:	54fffc01 	b.ne	402043e0 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x54>  // b.any
    40204464:	f9001aba 	str	x26, [x21, #48]
    40204468:	14000003 	b	40204474 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0xe8>
    4020446c:	f9001aba 	str	x26, [x21, #48]
    40204470:	3600023c 	tbz	w28, #0, 402044b4 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x128>
    40204474:	f1000a9f 	cmp	x20, #0x2
    40204478:	540003c2 	b.cs	402044f0 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x164>  // b.hs, b.nlast
    4020447c:	aa1f03f7 	mov	x23, xzr
    40204480:	52800308 	mov	w8, #0x18                  	// #24
    40204484:	9b085688 	madd	x8, x20, x8, x21
    40204488:	f9000119 	str	x25, [x8]
    4020448c:	b94007e9 	ldr	w9, [sp, #4]
    40204490:	51000529 	sub	w9, w9, #0x1
    40204494:	b940150a 	ldr	w10, [x8, #20]
    40204498:	5100054a 	sub	w10, w10, #0x1
    4020449c:	29022909 	stp	w9, w10, [x8, #16]
    402044a0:	52800029 	mov	w9, #0x1                   	// #1
    402044a4:	14000006 	b	402044bc <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    402044a8:	52800037 	mov	w23, #0x1                   	// #1
    402044ac:	aa0a03f4 	mov	x20, x10
    402044b0:	14000003 	b	402044bc <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    402044b4:	aa1f03e9 	mov	x9, xzr
    402044b8:	aa1f03f7 	mov	x23, xzr
    402044bc:	a900d269 	stp	x9, x20, [x19, #8]
    402044c0:	f9000277 	str	x23, [x19]
    402044c4:	a9474ff4 	ldp	x20, x19, [sp, #112]
    402044c8:	a94657f6 	ldp	x22, x21, [sp, #96]
    402044cc:	a9455ff8 	ldp	x24, x23, [sp, #80]
    402044d0:	a94467fa 	ldp	x26, x25, [sp, #64]
    402044d4:	a9436ffc 	ldp	x28, x27, [sp, #48]
    402044d8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    402044dc:	910203ff 	add	sp, sp, #0x80
    402044e0:	d65f03c0 	ret
    402044e4:	52800069 	mov	w9, #0x3                   	// #3
    402044e8:	aa1603f4 	mov	x20, x22
    402044ec:	17fffff4 	b	402044bc <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    402044f0:	d503201f 	nop
    402044f4:	1000d5a2 	adr	x2, 40205fa8 <anon.e5cf9e378689f0b52d762c1b402a78cc.5.llvm.5630279096503145348>
    402044f8:	aa1403e0 	mov	x0, x20
    402044fc:	52800041 	mov	w1, #0x2                   	// #2
    40204500:	940001de 	bl	40204c78 <core::panicking::panic_bounds_check>

0000000040204504 <jnox_kernel::temporal_policy::HardCbs<_>::release>:
    40204504:	f100043f 	cmp	x1, #0x1
    40204508:	54000089 	b.ls	40204518 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x14>  // b.plast
    4020450c:	aa1f03e1 	mov	x1, xzr
    40204510:	aa1f03e0 	mov	x0, xzr
    40204514:	d65f03c0 	ret
    40204518:	340000e2 	cbz	w2, 40204534 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x30>
    4020451c:	52800308 	mov	w8, #0x18                  	// #24
    40204520:	9b080028 	madd	x8, x1, x8, x0
    40204524:	b9401509 	ldr	w9, [x8, #20]
    40204528:	340000a9 	cbz	w9, 4020453c <jnox_kernel::temporal_policy::HardCbs<_>::release+0x38>
    4020452c:	52800040 	mov	w0, #0x2                   	// #2
    40204530:	d65f03c0 	ret
    40204534:	52800020 	mov	w0, #0x1                   	// #1
    40204538:	d65f03c0 	ret
    4020453c:	f940010a 	ldr	x10, [x8]
    40204540:	f9401809 	ldr	x9, [x0, #48]
    40204544:	eb09014b 	subs	x11, x10, x9
    40204548:	54000149 	b.ls	40204570 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x6c>  // b.plast
    4020454c:	2941b10a 	ldp	w10, w12, [x8, #12]
    40204550:	b940090d 	ldr	w13, [x8, #8]
    40204554:	9bac7d4c 	umull	x12, w10, w12
    40204558:	9bcb7dae 	umulh	x14, x13, x11
    4020455c:	9b0b7dab 	mul	x11, x13, x11
    40204560:	eb0c017f 	cmp	x11, x12
    40204564:	fa1f01df 	sbcs	xzr, x14, xzr
    40204568:	54000063 	b.cc	40204574 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x70>  // b.lo, b.ul, b.last
    4020456c:	14000009 	b	40204590 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x8c>
    40204570:	b9400d0a 	ldr	w10, [x8, #12]
    40204574:	ab2a4121 	adds	x1, x9, w10, uxtw
    40204578:	54000063 	b.cc	40204584 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x80>  // b.lo, b.ul, b.last
    4020457c:	52800080 	mov	w0, #0x4                   	// #4
    40204580:	d65f03c0 	ret
    40204584:	f9000101 	str	x1, [x8]
    40204588:	b9400909 	ldr	w9, [x8, #8]
    4020458c:	b9001109 	str	w9, [x8, #16]
    40204590:	b9001502 	str	w2, [x8, #20]
    40204594:	528000a0 	mov	w0, #0x5                   	// #5
    40204598:	d65f03c0 	ret

000000004020459c <jnox_kernel::temporal_policy::HardCbs<_>::available>:
    4020459c:	f100083f 	cmp	x1, #0x2
    402045a0:	540000a3 	b.cc	402045b4 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x18>  // b.lo, b.ul, b.last
    402045a4:	a900fd1f 	stp	xzr, xzr, [x8, #8]
    402045a8:	52800049 	mov	w9, #0x2                   	// #2
    402045ac:	f9000109 	str	x9, [x8]
    402045b0:	d65f03c0 	ret
    402045b4:	52800309 	mov	w9, #0x18                  	// #24
    402045b8:	9b090029 	madd	x9, x1, x9, x0
    402045bc:	b940152a 	ldr	w10, [x9, #20]
    402045c0:	340001aa 	cbz	w10, 402045f4 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x58>
    402045c4:	b940112a 	ldr	w10, [x9, #16]
    402045c8:	340000ea 	cbz	w10, 402045e4 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x48>
    402045cc:	5280002b 	mov	w11, #0x1                   	// #1
    402045d0:	f900010b 	str	x11, [x8]
    402045d4:	f9400129 	ldr	x9, [x9]
    402045d8:	b900090a 	str	w10, [x8, #8]
    402045dc:	f9000909 	str	x9, [x8, #16]
    402045e0:	d65f03c0 	ret
    402045e4:	f940180b 	ldr	x11, [x0, #48]
    402045e8:	f940012a 	ldr	x10, [x9]
    402045ec:	eb0a017f 	cmp	x11, x10
    402045f0:	54000062 	b.cs	402045fc <jnox_kernel::temporal_policy::HardCbs<_>::available+0x60>  // b.hs, b.nlast
    402045f4:	f900011f 	str	xzr, [x8]
    402045f8:	d65f03c0 	ret
    402045fc:	b9400d2b 	ldr	w11, [x9, #12]
    40204600:	ab0b014a 	adds	x10, x10, x11
    40204604:	540000c3 	b.cc	4020461c <jnox_kernel::temporal_policy::HardCbs<_>::available+0x80>  // b.lo, b.ul, b.last
    40204608:	52800089 	mov	w9, #0x4                   	// #4
    4020460c:	a900a909 	stp	x9, x10, [x8, #8]
    40204610:	5280004a 	mov	w10, #0x2                   	// #2
    40204614:	f900010a 	str	x10, [x8]
    40204618:	d65f03c0 	ret
    4020461c:	5280002b 	mov	w11, #0x1                   	// #1
    40204620:	f900010b 	str	x11, [x8]
    40204624:	b9400929 	ldr	w9, [x9, #8]
    40204628:	b9000909 	str	w9, [x8, #8]
    4020462c:	f900090a 	str	x10, [x8, #16]
    40204630:	d65f03c0 	ret

0000000040204634 <jnox_kernel::temporal_policy::admit_reservations>:
    40204634:	f81b0ffe 	str	x30, [sp, #-80]!
    40204638:	a90167fa 	stp	x26, x25, [sp, #16]
    4020463c:	a9025ff8 	stp	x24, x23, [sp, #32]
    40204640:	a90357f6 	stp	x22, x21, [sp, #48]
    40204644:	a9044ff4 	stp	x20, x19, [sp, #64]
    40204648:	b4000721 	cbz	x1, 4020472c <jnox_kernel::temporal_policy::admit_reservations+0xf8>
    4020464c:	aa0003f3 	mov	x19, x0
    40204650:	aa1f03f6 	mov	x22, xzr
    40204654:	8b010c1a 	add	x26, x0, x1, lsl #3
    40204658:	52800020 	mov	w0, #0x1                   	// #1
    4020465c:	29402269 	ldp	w9, w8, [x19]
    40204660:	5100052a 	sub	w10, w9, #0x1
    40204664:	6b08015f 	cmp	w10, w8
    40204668:	540006a2 	b.cs	4020473c <jnox_kernel::temporal_policy::admit_reservations+0x108>  // b.hs, b.nlast
    4020466c:	9bd67d0a 	umulh	x10, x8, x22
    40204670:	9b167d0b 	mul	x11, x8, x22
    40204674:	9bc07d2c 	umulh	x12, x9, x0
    40204678:	9b007d29 	mul	x9, x9, x0
    4020467c:	ab090176 	adds	x22, x11, x9
    40204680:	9a0c0157 	adc	x23, x10, x12
    40204684:	9bc07d14 	umulh	x20, x8, x0
    40204688:	9b007d15 	mul	x21, x8, x0
    4020468c:	eb1602bf 	cmp	x21, x22
    40204690:	fa17029f 	sbcs	xzr, x20, x23
    40204694:	54000583 	b.cc	40204744 <jnox_kernel::temporal_policy::admit_reservations+0x110>  // b.lo, b.ul, b.last
    40204698:	b4000220 	cbz	x0, 402046dc <jnox_kernel::temporal_policy::admit_reservations+0xa8>
    4020469c:	aa1603e0 	mov	x0, x22
    402046a0:	aa1703e1 	mov	x1, x23
    402046a4:	aa1503e8 	mov	x8, x21
    402046a8:	aa1403e9 	mov	x9, x20
    402046ac:	aa0903f8 	mov	x24, x9
    402046b0:	aa0803f9 	mov	x25, x8
    402046b4:	aa0803e2 	mov	x2, x8
    402046b8:	aa0903e3 	mov	x3, x9
    402046bc:	94000542 	bl	40205bc4 <__umodti3>
    402046c0:	aa0003e8 	mov	x8, x0
    402046c4:	aa0103e9 	mov	x9, x1
    402046c8:	aa01000a 	orr	x10, x0, x1
    402046cc:	aa1903e0 	mov	x0, x25
    402046d0:	aa1803e1 	mov	x1, x24
    402046d4:	b5fffeca 	cbnz	x10, 402046ac <jnox_kernel::temporal_policy::admit_reservations+0x78>
    402046d8:	14000005 	b	402046ec <jnox_kernel::temporal_policy::admit_reservations+0xb8>
    402046dc:	aa1702c8 	orr	x8, x22, x23
    402046e0:	aa1603f9 	mov	x25, x22
    402046e4:	aa1703f8 	mov	x24, x23
    402046e8:	b40003c8 	cbz	x8, 40204760 <jnox_kernel::temporal_policy::admit_reservations+0x12c>
    402046ec:	aa1603e0 	mov	x0, x22
    402046f0:	aa1703e1 	mov	x1, x23
    402046f4:	aa1903e2 	mov	x2, x25
    402046f8:	aa1803e3 	mov	x3, x24
    402046fc:	940003e3 	bl	40205688 <__udivti3>
    40204700:	b50001a1 	cbnz	x1, 40204734 <jnox_kernel::temporal_policy::admit_reservations+0x100>
    40204704:	aa0003f6 	mov	x22, x0
    40204708:	aa1503e0 	mov	x0, x21
    4020470c:	aa1403e1 	mov	x1, x20
    40204710:	aa1903e2 	mov	x2, x25
    40204714:	aa1803e3 	mov	x3, x24
    40204718:	940003dc 	bl	40205688 <__udivti3>
    4020471c:	b50000c1 	cbnz	x1, 40204734 <jnox_kernel::temporal_policy::admit_reservations+0x100>
    40204720:	91002273 	add	x19, x19, #0x8
    40204724:	eb1a027f 	cmp	x19, x26
    40204728:	54fff9a1 	b.ne	4020465c <jnox_kernel::temporal_policy::admit_reservations+0x28>  // b.any
    4020472c:	52800060 	mov	w0, #0x3                   	// #3
    40204730:	14000006 	b	40204748 <jnox_kernel::temporal_policy::admit_reservations+0x114>
    40204734:	52800040 	mov	w0, #0x2                   	// #2
    40204738:	14000004 	b	40204748 <jnox_kernel::temporal_policy::admit_reservations+0x114>
    4020473c:	2a1f03e0 	mov	w0, wzr
    40204740:	14000002 	b	40204748 <jnox_kernel::temporal_policy::admit_reservations+0x114>
    40204744:	52800020 	mov	w0, #0x1                   	// #1
    40204748:	a9444ff4 	ldp	x20, x19, [sp, #64]
    4020474c:	a94357f6 	ldp	x22, x21, [sp, #48]
    40204750:	a9425ff8 	ldp	x24, x23, [sp, #32]
    40204754:	a94167fa 	ldp	x26, x25, [sp, #16]
    40204758:	f84507fe 	ldr	x30, [sp], #80
    4020475c:	d65f03c0 	ret
    40204760:	d503201f 	nop
    40204764:	1000c2e0 	adr	x0, 40205fc0 <anon.e5cf9e378689f0b52d762c1b402a78cc.6.llvm.5630279096503145348>
    40204768:	94000343 	bl	40205474 <core::panicking::panic_const::panic_const_div_by_zero>

000000004020476c <jnox_kernel::context::init_timer_irq>:
    4020476c:	d503201f 	nop
    40204770:	10fe0488 	adr	x8, 40200800 <sched_vectors>
    40204774:	d518c008 	msr	vbar_el1, x8
    40204778:	d51be23f 	msr	cntp_ctl_el0, xzr
    4020477c:	d5033fdf 	isb
    40204780:	52a10008 	mov	w8, #0x8000000             	// #134217728
    40204784:	b900011f 	str	wzr, [x8]
    40204788:	52a10029 	mov	w9, #0x8010000             	// #134283264
    4020478c:	b900013f 	str	wzr, [x9]
    40204790:	5280100a 	mov	w10, #0x80                  	// #128
    40204794:	72a1000a 	movk	w10, #0x800, lsl #16
    40204798:	b940014b 	ldr	w11, [x10]
    4020479c:	1201796b 	and	w11, w11, #0xbfffffff
    402047a0:	b900014b 	str	w11, [x10]
    402047a4:	5280100b 	mov	w11, #0x80                  	// #128
    402047a8:	390e794b 	strb	w11, [x10, #926]
    402047ac:	52a8000b 	mov	w11, #0x40000000            	// #1073741824
    402047b0:	b902014b 	str	w11, [x10, #512]
    402047b4:	b900814b 	str	w11, [x10, #128]
    402047b8:	5280008a 	mov	w10, #0x4                   	// #4
    402047bc:	72a1002a 	movk	w10, #0x801, lsl #16
    402047c0:	52801feb 	mov	w11, #0xff                  	// #255
    402047c4:	b900014b 	str	w11, [x10]
    402047c8:	5280002a 	mov	w10, #0x1                   	// #1
    402047cc:	b900010a 	str	w10, [x8]
    402047d0:	b900012a 	str	w10, [x9]
    402047d4:	d5033f9f 	dsb	sy
    402047d8:	d5033fdf 	isb
    402047dc:	d65f03c0 	ret

00000000402047e0 <<core::fmt::Formatter>::pad_integral>:
    402047e0:	d101c3ff 	sub	sp, sp, #0x70
    402047e4:	a9017bfd 	stp	x29, x30, [sp, #16]
    402047e8:	a9026ffc 	stp	x28, x27, [sp, #32]
    402047ec:	a90367fa 	stp	x26, x25, [sp, #48]
    402047f0:	a9045ff8 	stp	x24, x23, [sp, #64]
    402047f4:	a90557f6 	stp	x22, x21, [sp, #80]
    402047f8:	a9064ff4 	stp	x20, x19, [sp, #96]
    402047fc:	910043fd 	add	x29, sp, #0x10
    40204800:	b940101a 	ldr	w26, [x0, #16]
    40204804:	52a00229 	mov	w9, #0x110000              	// #1114112
    40204808:	aa0503f3 	mov	x19, x5
    4020480c:	aa0403fc 	mov	x28, x4
    40204810:	aa0303f6 	mov	x22, x3
    40204814:	aa0003f5 	mov	x21, x0
    40204818:	926b0348 	and	x8, x26, #0x200000
    4020481c:	d355574a 	ubfx	x10, x26, #21, #1
    40204820:	7100011f 	cmp	w8, #0x0
    40204824:	52800568 	mov	w8, #0x2b                  	// #43
    40204828:	1a880128 	csel	w8, w9, w8, eq  // eq = none
    4020482c:	7100003f 	cmp	w1, #0x0
    40204830:	528005a9 	mov	w9, #0x2d                  	// #45
    40204834:	9a9f154a 	csinc	x10, x10, xzr, ne  // ne = any
    40204838:	1a891118 	csel	w24, w8, w9, ne  // ne = any
    4020483c:	8b05015b 	add	x27, x10, x5
    40204840:	37b8033a 	tbnz	w26, #23, 402048a4 <<core::fmt::Formatter>::pad_integral+0xc4>
    40204844:	aa1f03f7 	mov	x23, xzr
    40204848:	79402ab4 	ldrh	w20, [x21, #20]
    4020484c:	eb14037f 	cmp	x27, x20
    40204850:	54001503 	b.cc	40204af0 <<core::fmt::Formatter>::pad_integral+0x310>  // b.lo, b.ul, b.last
    40204854:	a94056b9 	ldp	x25, x21, [x21]
    40204858:	2a1803e2 	mov	w2, w24
    4020485c:	aa1703e3 	mov	x3, x23
    40204860:	aa1603e4 	mov	x4, x22
    40204864:	aa1903e0 	mov	x0, x25
    40204868:	aa1503e1 	mov	x1, x21
    4020486c:	94000310 	bl	402054ac <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204870:	37001d60 	tbnz	w0, #0, 40204c1c <<core::fmt::Formatter>::pad_integral+0x43c>
    40204874:	f9400ea3 	ldr	x3, [x21, #24]
    40204878:	aa1903e0 	mov	x0, x25
    4020487c:	aa1c03e1 	mov	x1, x28
    40204880:	aa1303e2 	mov	x2, x19
    40204884:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40204888:	a94557f6 	ldp	x22, x21, [sp, #80]
    4020488c:	a9445ff8 	ldp	x24, x23, [sp, #64]
    40204890:	a94367fa 	ldp	x26, x25, [sp, #48]
    40204894:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40204898:	a9417bfd 	ldp	x29, x30, [sp, #16]
    4020489c:	9101c3ff 	add	sp, sp, #0x70
    402048a0:	d61f0060 	br	x3
    402048a4:	aa0203f7 	mov	x23, x2
    402048a8:	f10082df 	cmp	x22, #0x20
    402048ac:	540000e2 	b.cs	402048c8 <<core::fmt::Formatter>::pad_integral+0xe8>  // b.hs, b.nlast
    402048b0:	b4000156 	cbz	x22, 402048d8 <<core::fmt::Formatter>::pad_integral+0xf8>
    402048b4:	f10022df 	cmp	x22, #0x8
    402048b8:	54000142 	b.cs	402048e0 <<core::fmt::Formatter>::pad_integral+0x100>  // b.hs, b.nlast
    402048bc:	aa1f03e8 	mov	x8, xzr
    402048c0:	aa1f03e0 	mov	x0, xzr
    402048c4:	14000080 	b	40204ac4 <<core::fmt::Formatter>::pad_integral+0x2e4>
    402048c8:	aa1703e0 	mov	x0, x23
    402048cc:	aa1603e1 	mov	x1, x22
    402048d0:	94000102 	bl	40204cd8 <core::str::count::do_count_chars>
    402048d4:	14000083 	b	40204ae0 <<core::fmt::Formatter>::pad_integral+0x300>
    402048d8:	aa1f03e0 	mov	x0, xzr
    402048dc:	14000081 	b	40204ae0 <<core::fmt::Formatter>::pad_integral+0x300>
    402048e0:	aa1703ea 	mov	x10, x23
    402048e4:	39400ae9 	ldrb	w9, [x23, #2]
    402048e8:	394006e8 	ldrb	w8, [x23, #1]
    402048ec:	38404d4b 	ldrb	w11, [x10, #4]!
    402048f0:	3940094c 	ldrb	w12, [x10, #2]
    402048f4:	394002ed 	ldrb	w13, [x23]
    402048f8:	39400eee 	ldrb	w14, [x23, #3]
    402048fc:	d370bd29 	lsl	x9, x9, #16
    40204900:	394016ef 	ldrb	w15, [x23, #5]
    40204904:	39400d4a 	ldrb	w10, [x10, #3]
    40204908:	53103d8c 	lsl	w12, w12, #16
    4020490c:	aa0821a8 	orr	x8, x13, x8, lsl #8
    40204910:	aa0e6129 	orr	x9, x9, x14, lsl #24
    40204914:	0f05e7e4 	movi	v4.8b, #0xbf
    40204918:	2a0f216b 	orr	w11, w11, w15, lsl #8
    4020491c:	2a0a618a 	orr	w10, w12, w10, lsl #24
    40204920:	aa080128 	orr	x8, x9, x8
    40204924:	2a0b0149 	orr	w9, w10, w11
    40204928:	aa098108 	orr	x8, x8, x9, lsl #32
    4020492c:	9e670100 	fmov	d0, x8
    40204930:	52800028 	mov	w8, #0x1                   	// #1
    40204934:	4e080d03 	dup	v3.2d, x8
    40204938:	927d06c8 	and	x8, x22, #0x18
    4020493c:	f100211f 	cmp	x8, #0x8
    40204940:	0e243400 	cmgt	v0.8b, v0.8b, v4.8b
    40204944:	2f08a400 	uxtl	v0.8h, v0.8b
    40204948:	6f10a401 	uxtl2	v1.4s, v0.8h
    4020494c:	2f10a400 	uxtl	v0.4s, v0.4h
    40204950:	6f20a422 	uxtl2	v2.2d, v1.4s
    40204954:	2f20a421 	uxtl	v1.2d, v1.2s
    40204958:	6f20a405 	uxtl2	v5.2d, v0.4s
    4020495c:	2f20a406 	uxtl	v6.2d, v0.2s
    40204960:	4e231c40 	and	v0.16b, v2.16b, v3.16b
    40204964:	4e231c22 	and	v2.16b, v1.16b, v3.16b
    40204968:	4e231ca1 	and	v1.16b, v5.16b, v3.16b
    4020496c:	4e231cc3 	and	v3.16b, v6.16b, v3.16b
    40204970:	540009c0 	b.eq	40204aa8 <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    40204974:	aa1703e9 	mov	x9, x23
    40204978:	f100411f 	cmp	x8, #0x10
    4020497c:	38408d2a 	ldrb	w10, [x9, #8]!
    40204980:	3940052b 	ldrb	w11, [x9, #1]
    40204984:	39400d2c 	ldrb	w12, [x9, #3]
    40204988:	3940092d 	ldrb	w13, [x9, #2]
    4020498c:	3940152e 	ldrb	w14, [x9, #5]
    40204990:	38404d2f 	ldrb	w15, [x9, #4]!
    40204994:	39400930 	ldrb	w16, [x9, #2]
    40204998:	39400d29 	ldrb	w9, [x9, #3]
    4020499c:	d370bdad 	lsl	x13, x13, #16
    402049a0:	aa0b214a 	orr	x10, x10, x11, lsl #8
    402049a4:	53103e10 	lsl	w16, w16, #16
    402049a8:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    402049ac:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    402049b0:	2a096209 	orr	w9, w16, w9, lsl #24
    402049b4:	aa0a018a 	orr	x10, x12, x10
    402049b8:	2a0b0129 	orr	w9, w9, w11
    402049bc:	aa098149 	orr	x9, x10, x9, lsl #32
    402049c0:	9e670125 	fmov	d5, x9
    402049c4:	52800029 	mov	w9, #0x1                   	// #1
    402049c8:	4e080d26 	dup	v6.2d, x9
    402049cc:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    402049d0:	2f08a484 	uxtl	v4.8h, v4.8b
    402049d4:	6f10a485 	uxtl2	v5.4s, v4.8h
    402049d8:	2f10a484 	uxtl	v4.4s, v4.4h
    402049dc:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    402049e0:	2f20a490 	uxtl	v16.2d, v4.2s
    402049e4:	6f20a484 	uxtl2	v4.2d, v4.4s
    402049e8:	2f20a4a5 	uxtl	v5.2d, v5.2s
    402049ec:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    402049f0:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    402049f4:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    402049f8:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    402049fc:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40204a00:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40204a04:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40204a08:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40204a0c:	540004e0 	b.eq	40204aa8 <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    40204a10:	aa1703e9 	mov	x9, x23
    40204a14:	0f05e7e4 	movi	v4.8b, #0xbf
    40204a18:	38410d2a 	ldrb	w10, [x9, #16]!
    40204a1c:	3940052b 	ldrb	w11, [x9, #1]
    40204a20:	39400d2c 	ldrb	w12, [x9, #3]
    40204a24:	3940092d 	ldrb	w13, [x9, #2]
    40204a28:	3940152e 	ldrb	w14, [x9, #5]
    40204a2c:	38404d2f 	ldrb	w15, [x9, #4]!
    40204a30:	39400930 	ldrb	w16, [x9, #2]
    40204a34:	39400d29 	ldrb	w9, [x9, #3]
    40204a38:	d370bdad 	lsl	x13, x13, #16
    40204a3c:	aa0b214a 	orr	x10, x10, x11, lsl #8
    40204a40:	53103e10 	lsl	w16, w16, #16
    40204a44:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40204a48:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40204a4c:	2a096209 	orr	w9, w16, w9, lsl #24
    40204a50:	aa0a018a 	orr	x10, x12, x10
    40204a54:	2a0b0129 	orr	w9, w9, w11
    40204a58:	aa098149 	orr	x9, x10, x9, lsl #32
    40204a5c:	9e670125 	fmov	d5, x9
    40204a60:	52800029 	mov	w9, #0x1                   	// #1
    40204a64:	4e080d26 	dup	v6.2d, x9
    40204a68:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40204a6c:	2f08a484 	uxtl	v4.8h, v4.8b
    40204a70:	6f10a485 	uxtl2	v5.4s, v4.8h
    40204a74:	2f10a484 	uxtl	v4.4s, v4.4h
    40204a78:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40204a7c:	2f20a490 	uxtl	v16.2d, v4.2s
    40204a80:	6f20a484 	uxtl2	v4.2d, v4.4s
    40204a84:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40204a88:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40204a8c:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40204a90:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40204a94:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40204a98:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40204a9c:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40204aa0:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40204aa4:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40204aa8:	4ee28462 	add	v2.2d, v3.2d, v2.2d
    40204aac:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    40204ab0:	eb0802df 	cmp	x22, x8
    40204ab4:	4ee08440 	add	v0.2d, v2.2d, v0.2d
    40204ab8:	5ef1b800 	addp	d0, v0.2d
    40204abc:	9e660000 	fmov	x0, d0
    40204ac0:	54000100 	b.eq	40204ae0 <<core::fmt::Formatter>::pad_integral+0x300>  // b.none
    40204ac4:	cb0802c9 	sub	x9, x22, x8
    40204ac8:	8b0802e8 	add	x8, x23, x8
    40204acc:	38c0150a 	ldrsb	w10, [x8], #1
    40204ad0:	3101055f 	cmn	w10, #0x41
    40204ad4:	9a80d400 	cinc	x0, x0, gt
    40204ad8:	f1000529 	subs	x9, x9, #0x1
    40204adc:	54ffff81 	b.ne	40204acc <<core::fmt::Formatter>::pad_integral+0x2ec>  // b.any
    40204ae0:	8b1b001b 	add	x27, x0, x27
    40204ae4:	79402ab4 	ldrh	w20, [x21, #20]
    40204ae8:	eb14037f 	cmp	x27, x20
    40204aec:	54ffeb42 	b.cs	40204854 <<core::fmt::Formatter>::pad_integral+0x74>  // b.hs, b.nlast
    40204af0:	f90007fc 	str	x28, [sp, #8]
    40204af4:	37c0011a 	tbnz	w26, #24, 40204b14 <<core::fmt::Formatter>::pad_integral+0x334>
    40204af8:	531d7b48 	ubfx	w8, w26, #29, #2
    40204afc:	4b1b029b 	sub	w27, w20, w27
    40204b00:	7100051f 	cmp	w8, #0x1
    40204b04:	540003cc 	b.gt	40204b7c <<core::fmt::Formatter>::pad_integral+0x39c>
    40204b08:	35000568 	cbnz	w8, 40204bb4 <<core::fmt::Formatter>::pad_integral+0x3d4>
    40204b0c:	2a1f03fc 	mov	w28, wzr
    40204b10:	1400002a 	b	40204bb8 <<core::fmt::Formatter>::pad_integral+0x3d8>
    40204b14:	a940f2ba 	ldp	x26, x28, [x21, #8]
    40204b18:	52b3fc08 	mov	w8, #0x9fe00000            	// #-1612709888
    40204b1c:	f94002b9 	ldr	x25, [x21]
    40204b20:	2a1803e2 	mov	w2, w24
    40204b24:	aa1703e3 	mov	x3, x23
    40204b28:	aa1603e4 	mov	x4, x22
    40204b2c:	0a080388 	and	w8, w28, w8
    40204b30:	aa1903e0 	mov	x0, x25
    40204b34:	aa1a03e1 	mov	x1, x26
    40204b38:	321c0508 	orr	w8, w8, #0x30
    40204b3c:	32030108 	orr	w8, w8, #0x20000000
    40204b40:	b90012a8 	str	w8, [x21, #16]
    40204b44:	9400025a 	bl	402054ac <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204b48:	370006a0 	tbnz	w0, #0, 40204c1c <<core::fmt::Formatter>::pad_integral+0x43c>
    40204b4c:	2a1f03f6 	mov	w22, wzr
    40204b50:	4b1b0294 	sub	w20, w20, w27
    40204b54:	12003ec8 	and	w8, w22, #0xffff
    40204b58:	6b34211f 	cmp	w8, w20, uxth
    40204b5c:	540001a2 	b.cs	40204b90 <<core::fmt::Formatter>::pad_integral+0x3b0>  // b.hs, b.nlast
    40204b60:	f9401348 	ldr	x8, [x26, #32]
    40204b64:	aa1903e0 	mov	x0, x25
    40204b68:	52800601 	mov	w1, #0x30                  	// #48
    40204b6c:	110006d6 	add	w22, w22, #0x1
    40204b70:	d63f0100 	blr	x8
    40204b74:	3607ff00 	tbz	w0, #0, 40204b54 <<core::fmt::Formatter>::pad_integral+0x374>
    40204b78:	14000029 	b	40204c1c <<core::fmt::Formatter>::pad_integral+0x43c>
    40204b7c:	7100091f 	cmp	w8, #0x2
    40204b80:	2a1b03fc 	mov	w28, w27
    40204b84:	540001a1 	b.ne	40204bb8 <<core::fmt::Formatter>::pad_integral+0x3d8>  // b.any
    40204b88:	53013f7c 	ubfx	w28, w27, #1, #15
    40204b8c:	1400000b 	b	40204bb8 <<core::fmt::Formatter>::pad_integral+0x3d8>
    40204b90:	f9400f48 	ldr	x8, [x26, #24]
    40204b94:	f94007e1 	ldr	x1, [sp, #8]
    40204b98:	aa1903e0 	mov	x0, x25
    40204b9c:	aa1303e2 	mov	x2, x19
    40204ba0:	d63f0100 	blr	x8
    40204ba4:	370003c0 	tbnz	w0, #0, 40204c1c <<core::fmt::Formatter>::pad_integral+0x43c>
    40204ba8:	2a1f03f3 	mov	w19, wzr
    40204bac:	f9000abc 	str	x28, [x21, #16]
    40204bb0:	1400001c 	b	40204c20 <<core::fmt::Formatter>::pad_integral+0x440>
    40204bb4:	2a1b03fc 	mov	w28, w27
    40204bb8:	a94056b9 	ldp	x25, x21, [x21]
    40204bbc:	2a1f03f4 	mov	w20, wzr
    40204bc0:	12003e88 	and	w8, w20, #0xffff
    40204bc4:	6b3c211f 	cmp	w8, w28, uxth
    40204bc8:	54000102 	b.cs	40204be8 <<core::fmt::Formatter>::pad_integral+0x408>  // b.hs, b.nlast
    40204bcc:	f94012a8 	ldr	x8, [x21, #32]
    40204bd0:	12005341 	and	w1, w26, #0x1fffff
    40204bd4:	aa1903e0 	mov	x0, x25
    40204bd8:	11000694 	add	w20, w20, #0x1
    40204bdc:	d63f0100 	blr	x8
    40204be0:	3607ff00 	tbz	w0, #0, 40204bc0 <<core::fmt::Formatter>::pad_integral+0x3e0>
    40204be4:	1400000e 	b	40204c1c <<core::fmt::Formatter>::pad_integral+0x43c>
    40204be8:	aa1903e0 	mov	x0, x25
    40204bec:	aa1503e1 	mov	x1, x21
    40204bf0:	2a1803e2 	mov	w2, w24
    40204bf4:	aa1703e3 	mov	x3, x23
    40204bf8:	aa1603e4 	mov	x4, x22
    40204bfc:	9400022c 	bl	402054ac <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204c00:	370000e0 	tbnz	w0, #0, 40204c1c <<core::fmt::Formatter>::pad_integral+0x43c>
    40204c04:	f9400ea8 	ldr	x8, [x21, #24]
    40204c08:	f94007e1 	ldr	x1, [sp, #8]
    40204c0c:	aa1903e0 	mov	x0, x25
    40204c10:	aa1303e2 	mov	x2, x19
    40204c14:	d63f0100 	blr	x8
    40204c18:	36000160 	tbz	w0, #0, 40204c44 <<core::fmt::Formatter>::pad_integral+0x464>
    40204c1c:	52800033 	mov	w19, #0x1                   	// #1
    40204c20:	2a1303e0 	mov	w0, w19
    40204c24:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40204c28:	a94557f6 	ldp	x22, x21, [sp, #80]
    40204c2c:	a9445ff8 	ldp	x24, x23, [sp, #64]
    40204c30:	a94367fa 	ldp	x26, x25, [sp, #48]
    40204c34:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40204c38:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40204c3c:	9101c3ff 	add	sp, sp, #0x70
    40204c40:	d65f03c0 	ret
    40204c44:	2a1f03f4 	mov	w20, wzr
    40204c48:	4b1c0376 	sub	w22, w27, w28
    40204c4c:	12003e88 	and	w8, w20, #0xffff
    40204c50:	6b36211f 	cmp	w8, w22, uxth
    40204c54:	1a9f27f3 	cset	w19, cc  // cc = lo, ul, last
    40204c58:	54fffe42 	b.cs	40204c20 <<core::fmt::Formatter>::pad_integral+0x440>  // b.hs, b.nlast
    40204c5c:	f94012a8 	ldr	x8, [x21, #32]
    40204c60:	12005341 	and	w1, w26, #0x1fffff
    40204c64:	aa1903e0 	mov	x0, x25
    40204c68:	11000694 	add	w20, w20, #0x1
    40204c6c:	d63f0100 	blr	x8
    40204c70:	3607fee0 	tbz	w0, #0, 40204c4c <<core::fmt::Formatter>::pad_integral+0x46c>
    40204c74:	17ffffeb 	b	40204c20 <<core::fmt::Formatter>::pad_integral+0x440>

0000000040204c78 <core::panicking::panic_bounds_check>:
    40204c78:	d10103ff 	sub	sp, sp, #0x40
    40204c7c:	a9037bfd 	stp	x29, x30, [sp, #48]
    40204c80:	9100c3fd 	add	x29, sp, #0x30
    40204c84:	910023e8 	add	x8, sp, #0x8
    40204c88:	d503201f 	nop
    40204c8c:	10004549 	adr	x9, 40205534 <<u64 as core::fmt::Display>::fmt>
    40204c90:	a90007e0 	stp	x0, x1, [sp]
    40204c94:	b0000000 	adrp	x0, 40205000 <core::str::count::do_count_chars+0x328>
    40204c98:	9135b400 	add	x0, x0, #0xd6d
    40204c9c:	a90127e8 	stp	x8, x9, [sp, #16]
    40204ca0:	910003e8 	mov	x8, sp
    40204ca4:	910043e1 	add	x1, sp, #0x10
    40204ca8:	a90227e8 	stp	x8, x9, [sp, #32]
    40204cac:	94000001 	bl	40204cb0 <core::panicking::panic_fmt>

0000000040204cb0 <core::panicking::panic_fmt>:
    40204cb0:	d10103ff 	sub	sp, sp, #0x40
    40204cb4:	a9037bfd 	stp	x29, x30, [sp, #48]
    40204cb8:	9100c3fd 	add	x29, sp, #0x30
    40204cbc:	910023e8 	add	x8, sp, #0x8
    40204cc0:	a90087e0 	stp	x0, x1, [sp, #8]
    40204cc4:	910063e0 	add	x0, sp, #0x18
    40204cc8:	a9018be8 	stp	x8, x2, [sp, #24]
    40204ccc:	52800028 	mov	w8, #0x1                   	// #1
    40204cd0:	790053e8 	strh	w8, [sp, #40]
    40204cd4:	97fffc92 	bl	40203f1c <__rustc::rust_begin_unwind>

0000000040204cd8 <core::str::count::do_count_chars>:
    40204cd8:	d10183ff 	sub	sp, sp, #0x60
    40204cdc:	fd0023ea 	str	d10, [sp, #64]
    40204ce0:	6d0523e9 	stp	d9, d8, [sp, #80]
    40204ce4:	91001c08 	add	x8, x0, #0x7
    40204ce8:	927df10d 	and	x13, x8, #0xfffffffffffffff8
    40204cec:	cb0001ac 	sub	x12, x13, x0
    40204cf0:	eb0c002b 	subs	x11, x1, x12
    40204cf4:	540000e2 	b.cs	40204d10 <core::str::count::do_count_chars+0x38>  // b.hs, b.nlast
    40204cf8:	b4000721 	cbz	x1, 40204ddc <core::str::count::do_count_chars+0x104>
    40204cfc:	f100203f 	cmp	x1, #0x8
    40204d00:	54001b82 	b.cs	40205070 <core::str::count::do_count_chars+0x398>  // b.hs, b.nlast
    40204d04:	aa1f03e9 	mov	x9, xzr
    40204d08:	aa1f03e8 	mov	x8, xzr
    40204d0c:	140001d2 	b	40205454 <core::str::count::do_count_chars+0x77c>
    40204d10:	d343fd69 	lsr	x9, x11, #3
    40204d14:	b4ffff29 	cbz	x9, 40204cf8 <core::str::count::do_count_chars+0x20>
    40204d18:	eb0001bf 	cmp	x13, x0
    40204d1c:	9240096a 	and	x10, x11, #0x7
    40204d20:	aa1f03e8 	mov	x8, xzr
    40204d24:	54000100 	b.eq	40204d44 <core::str::count::do_count_chars+0x6c>  // b.none
    40204d28:	cb0d000d 	sub	x13, x0, x13
    40204d2c:	aa0003ee 	mov	x14, x0
    40204d30:	38c015cf 	ldrsb	w15, [x14], #1
    40204d34:	310105ff 	cmn	w15, #0x41
    40204d38:	9a88d508 	cinc	x8, x8, gt
    40204d3c:	b10005ad 	adds	x13, x13, #0x1
    40204d40:	54ffff83 	b.cc	40204d30 <core::str::count::do_count_chars+0x58>  // b.lo, b.ul, b.last
    40204d44:	8b0c000e 	add	x14, x0, x12
    40204d48:	b400056a 	cbz	x10, 40204df4 <core::str::count::do_count_chars+0x11c>
    40204d4c:	927ded6b 	and	x11, x11, #0x7ffffffffffffff8
    40204d50:	8b0b01cc 	add	x12, x14, x11
    40204d54:	39c0018b 	ldrsb	w11, [x12]
    40204d58:	3101057f 	cmn	w11, #0x41
    40204d5c:	1a9fd7eb 	cset	w11, gt
    40204d60:	f100055f 	cmp	x10, #0x1
    40204d64:	540004a0 	b.eq	40204df8 <core::str::count::do_count_chars+0x120>  // b.none
    40204d68:	39c0058d 	ldrsb	w13, [x12, #1]
    40204d6c:	310105bf 	cmn	w13, #0x41
    40204d70:	9a8bd56b 	cinc	x11, x11, gt
    40204d74:	f100095f 	cmp	x10, #0x2
    40204d78:	54000400 	b.eq	40204df8 <core::str::count::do_count_chars+0x120>  // b.none
    40204d7c:	39c0098d 	ldrsb	w13, [x12, #2]
    40204d80:	310105bf 	cmn	w13, #0x41
    40204d84:	9a8bd56b 	cinc	x11, x11, gt
    40204d88:	f1000d5f 	cmp	x10, #0x3
    40204d8c:	54000360 	b.eq	40204df8 <core::str::count::do_count_chars+0x120>  // b.none
    40204d90:	39c00d8d 	ldrsb	w13, [x12, #3]
    40204d94:	310105bf 	cmn	w13, #0x41
    40204d98:	9a8bd56b 	cinc	x11, x11, gt
    40204d9c:	f100115f 	cmp	x10, #0x4
    40204da0:	540002c0 	b.eq	40204df8 <core::str::count::do_count_chars+0x120>  // b.none
    40204da4:	39c0118d 	ldrsb	w13, [x12, #4]
    40204da8:	310105bf 	cmn	w13, #0x41
    40204dac:	9a8bd56b 	cinc	x11, x11, gt
    40204db0:	f100155f 	cmp	x10, #0x5
    40204db4:	54000220 	b.eq	40204df8 <core::str::count::do_count_chars+0x120>  // b.none
    40204db8:	39c0158d 	ldrsb	w13, [x12, #5]
    40204dbc:	310105bf 	cmn	w13, #0x41
    40204dc0:	9a8bd56b 	cinc	x11, x11, gt
    40204dc4:	f100195f 	cmp	x10, #0x6
    40204dc8:	54000180 	b.eq	40204df8 <core::str::count::do_count_chars+0x120>  // b.none
    40204dcc:	39c0198a 	ldrsb	w10, [x12, #6]
    40204dd0:	3101055f 	cmn	w10, #0x41
    40204dd4:	9a8bd56b 	cinc	x11, x11, gt
    40204dd8:	14000008 	b	40204df8 <core::str::count::do_count_chars+0x120>
    40204ddc:	aa1f03e8 	mov	x8, xzr
    40204de0:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40204de4:	aa0803e0 	mov	x0, x8
    40204de8:	fd4023ea 	ldr	d10, [sp, #64]
    40204dec:	910183ff 	add	sp, sp, #0x60
    40204df0:	d65f03c0 	ret
    40204df4:	aa1f03eb 	mov	x11, xzr
    40204df8:	4f00e420 	movi	v0.16b, #0x1
    40204dfc:	8b080168 	add	x8, x11, x8
    40204e00:	5280180a 	mov	w10, #0xc0                  	// #192
    40204e04:	b20083eb 	mov	x11, #0x1000100010001       	// #281479271743489
    40204e08:	1400000c 	b	40204e38 <core::str::count::do_count_chars+0x160>
    40204e0c:	aa1f03f1 	mov	x17, xzr
    40204e10:	d348fe2f 	lsr	x15, x17, #8
    40204e14:	92009e30 	and	x16, x17, #0xff00ff00ff00ff
    40204e18:	8b0e018e 	add	x14, x12, x14
    40204e1c:	cb0d0129 	sub	x9, x9, x13
    40204e20:	92009def 	and	x15, x15, #0xff00ff00ff00ff
    40204e24:	8b1001ef 	add	x15, x15, x16
    40204e28:	9b0b7df0 	mul	x16, x15, x11
    40204e2c:	924005af 	and	x15, x13, #0x3
    40204e30:	8b50c108 	add	x8, x8, x16, lsr #48
    40204e34:	b5000d8f 	cbnz	x15, 40204fe4 <core::str::count::do_count_chars+0x30c>
    40204e38:	b4fffd49 	cbz	x9, 40204de0 <core::str::count::do_count_chars+0x108>
    40204e3c:	f103013f 	cmp	x9, #0xc0
    40204e40:	aa0e03ec 	mov	x12, x14
    40204e44:	9a8a312d 	csel	x13, x9, x10, cc  // cc = lo, ul, last
    40204e48:	d37df1ae 	lsl	x14, x13, #3
    40204e4c:	f27b15d0 	ands	x16, x14, #0x7e0
    40204e50:	54fffde0 	b.eq	40204e0c <core::str::count::do_count_chars+0x134>  // b.none
    40204e54:	d10081cf 	sub	x15, x14, #0x20
    40204e58:	f10181ff 	cmp	x15, #0x60
    40204e5c:	54000082 	b.cs	40204e6c <core::str::count::do_count_chars+0x194>  // b.hs, b.nlast
    40204e60:	aa1f03f1 	mov	x17, xzr
    40204e64:	aa0c03ef 	mov	x15, x12
    40204e68:	14000044 	b	40204f78 <core::str::count::do_count_chars+0x2a0>
    40204e6c:	d345fdef 	lsr	x15, x15, #5
    40204e70:	6f00e401 	movi	v1.2d, #0x0
    40204e74:	6f00e402 	movi	v2.2d, #0x0
    40204e78:	91010180 	add	x0, x12, #0x40
    40204e7c:	910005f1 	add	x17, x15, #0x1
    40204e80:	927ee632 	and	x18, x17, #0xffffffffffffffc
    40204e84:	927ee621 	and	x1, x17, #0xffffffffffffffc
    40204e88:	8b12158f 	add	x15, x12, x18, lsl #5
    40204e8c:	d1010002 	sub	x2, x0, #0x40
    40204e90:	4c400c10 	ld4	{v16.2d-v19.2d}, [x0]
    40204e94:	f1001021 	subs	x1, x1, #0x4
    40204e98:	91020000 	add	x0, x0, #0x80
    40204e9c:	4c400c43 	ld4	{v3.2d-v6.2d}, [x2]
    40204ea0:	6e205a07 	mvn	v7.16b, v16.16b
    40204ea4:	6e205a35 	mvn	v21.16b, v17.16b
    40204ea8:	6e205a5a 	mvn	v26.16b, v18.16b
    40204eac:	6e205876 	mvn	v22.16b, v3.16b
    40204eb0:	6e205897 	mvn	v23.16b, v4.16b
    40204eb4:	6e2058b8 	mvn	v24.16b, v5.16b
    40204eb8:	6f7a0614 	ushr	v20.2d, v16.2d, #6
    40204ebc:	6f7a0639 	ushr	v25.2d, v17.2d, #6
    40204ec0:	6f7a065b 	ushr	v27.2d, v18.2d, #6
    40204ec4:	6f7a047c 	ushr	v28.2d, v3.2d, #6
    40204ec8:	6f7a049d 	ushr	v29.2d, v4.2d, #6
    40204ecc:	6f7a04be 	ushr	v30.2d, v5.2d, #6
    40204ed0:	6f7906d6 	ushr	v22.2d, v22.2d, #7
    40204ed4:	6f7906f7 	ushr	v23.2d, v23.2d, #7
    40204ed8:	6f790718 	ushr	v24.2d, v24.2d, #7
    40204edc:	6f7904e7 	ushr	v7.2d, v7.2d, #7
    40204ee0:	6f7906b5 	ushr	v21.2d, v21.2d, #7
    40204ee4:	6f79075a 	ushr	v26.2d, v26.2d, #7
    40204ee8:	6e205a7f 	mvn	v31.16b, v19.16b
    40204eec:	6f7a0670 	ushr	v16.2d, v19.2d, #6
    40204ef0:	6e2058d1 	mvn	v17.16b, v6.16b
    40204ef4:	4ebc1ed2 	orr	v18.16b, v22.16b, v28.16b
    40204ef8:	4ebd1ef3 	orr	v19.16b, v23.16b, v29.16b
    40204efc:	4ebe1f16 	orr	v22.16b, v24.16b, v30.16b
    40204f00:	4eb41ce7 	orr	v7.16b, v7.16b, v20.16b
    40204f04:	4eb91eb4 	orr	v20.16b, v21.16b, v25.16b
    40204f08:	4ebb1f55 	orr	v21.16b, v26.16b, v27.16b
    40204f0c:	6f7a04c3 	ushr	v3.2d, v6.2d, #6
    40204f10:	6f7907e4 	ushr	v4.2d, v31.2d, #7
    40204f14:	6f790625 	ushr	v5.2d, v17.2d, #7
    40204f18:	4e201e46 	and	v6.16b, v18.16b, v0.16b
    40204f1c:	4e201e71 	and	v17.16b, v19.16b, v0.16b
    40204f20:	4e201ed2 	and	v18.16b, v22.16b, v0.16b
    40204f24:	4e201ce7 	and	v7.16b, v7.16b, v0.16b
    40204f28:	4e201e93 	and	v19.16b, v20.16b, v0.16b
    40204f2c:	4e201eb4 	and	v20.16b, v21.16b, v0.16b
    40204f30:	4eb01c84 	orr	v4.16b, v4.16b, v16.16b
    40204f34:	4ea31ca3 	orr	v3.16b, v5.16b, v3.16b
    40204f38:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40204f3c:	4ef18646 	add	v6.2d, v18.2d, v17.2d
    40204f40:	4ee284e2 	add	v2.2d, v7.2d, v2.2d
    40204f44:	4ef38685 	add	v5.2d, v20.2d, v19.2d
    40204f48:	4e201c63 	and	v3.16b, v3.16b, v0.16b
    40204f4c:	4e201c84 	and	v4.16b, v4.16b, v0.16b
    40204f50:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40204f54:	4ee284a2 	add	v2.2d, v5.2d, v2.2d
    40204f58:	4ee18461 	add	v1.2d, v3.2d, v1.2d
    40204f5c:	4ee28482 	add	v2.2d, v4.2d, v2.2d
    40204f60:	54fff961 	b.ne	40204e8c <core::str::count::do_count_chars+0x1b4>  // b.any
    40204f64:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40204f68:	eb12023f 	cmp	x17, x18
    40204f6c:	5ef1b821 	addp	d1, v1.2d
    40204f70:	9e660031 	fmov	x17, d1
    40204f74:	54fff4e0 	b.eq	40204e10 <core::str::count::do_count_chars+0x138>  // b.none
    40204f78:	8b100190 	add	x16, x12, x16
    40204f7c:	f9400df2 	ldr	x18, [x15, #24]
    40204f80:	f9001ff2 	str	x18, [sp, #56]
    40204f84:	f94009f2 	ldr	x18, [x15, #16]
    40204f88:	f9001bf2 	str	x18, [sp, #48]
    40204f8c:	f94005f2 	ldr	x18, [x15, #8]
    40204f90:	f90017f2 	str	x18, [sp, #40]
    40204f94:	f84205f2 	ldr	x18, [x15], #32
    40204f98:	eb1001ff 	cmp	x15, x16
    40204f9c:	f90013f2 	str	x18, [sp, #32]
    40204fa0:	ad4107e2 	ldp	q2, q1, [sp, #32]
    40204fa4:	6e205823 	mvn	v3.16b, v1.16b
    40204fa8:	6e205844 	mvn	v4.16b, v2.16b
    40204fac:	6f7a0421 	ushr	v1.2d, v1.2d, #6
    40204fb0:	6f7a0442 	ushr	v2.2d, v2.2d, #6
    40204fb4:	6f790463 	ushr	v3.2d, v3.2d, #7
    40204fb8:	6f790484 	ushr	v4.2d, v4.2d, #7
    40204fbc:	4ea21c82 	orr	v2.16b, v4.16b, v2.16b
    40204fc0:	4ea11c61 	orr	v1.16b, v3.16b, v1.16b
    40204fc4:	4e201c21 	and	v1.16b, v1.16b, v0.16b
    40204fc8:	4e201c42 	and	v2.16b, v2.16b, v0.16b
    40204fcc:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40204fd0:	5ef1b821 	addp	d1, v1.2d
    40204fd4:	9e660032 	fmov	x18, d1
    40204fd8:	8b110251 	add	x17, x18, x17
    40204fdc:	54fffd01 	b.ne	40204f7c <core::str::count::do_count_chars+0x2a4>  // b.any
    40204fe0:	17ffff8c 	b	40204e10 <core::str::count::do_count_chars+0x138>
    40204fe4:	927e15a9 	and	x9, x13, #0xfc
    40204fe8:	f10005ff 	cmp	x15, #0x1
    40204fec:	8b090d8a 	add	x10, x12, x9, lsl #3
    40204ff0:	f9400149 	ldr	x9, [x10]
    40204ff4:	aa2903eb 	mvn	x11, x9
    40204ff8:	d347fd6b 	lsr	x11, x11, #7
    40204ffc:	aa491969 	orr	x9, x11, x9, lsr #6
    40205000:	9200c129 	and	x9, x9, #0x101010101010101
    40205004:	540001e0 	b.eq	40205040 <core::str::count::do_count_chars+0x368>  // b.none
    40205008:	f940054b 	ldr	x11, [x10, #8]
    4020500c:	f10009ff 	cmp	x15, #0x2
    40205010:	aa2b03ec 	mvn	x12, x11
    40205014:	d347fd8c 	lsr	x12, x12, #7
    40205018:	aa4b198b 	orr	x11, x12, x11, lsr #6
    4020501c:	9200c16b 	and	x11, x11, #0x101010101010101
    40205020:	8b090169 	add	x9, x11, x9
    40205024:	540000e0 	b.eq	40205040 <core::str::count::do_count_chars+0x368>  // b.none
    40205028:	f940094a 	ldr	x10, [x10, #16]
    4020502c:	aa2a03eb 	mvn	x11, x10
    40205030:	d347fd6b 	lsr	x11, x11, #7
    40205034:	aa4a196a 	orr	x10, x11, x10, lsr #6
    40205038:	9200c14a 	and	x10, x10, #0x101010101010101
    4020503c:	8b090149 	add	x9, x10, x9
    40205040:	d348fd2a 	lsr	x10, x9, #8
    40205044:	92009d29 	and	x9, x9, #0xff00ff00ff00ff
    40205048:	92009d4a 	and	x10, x10, #0xff00ff00ff00ff
    4020504c:	8b090149 	add	x9, x10, x9
    40205050:	b20083ea 	mov	x10, #0x1000100010001       	// #281479271743489
    40205054:	9b0a7d29 	mul	x9, x9, x10
    40205058:	8b49c108 	add	x8, x8, x9, lsr #48
    4020505c:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40205060:	aa0803e0 	mov	x0, x8
    40205064:	fd4023ea 	ldr	d10, [sp, #64]
    40205068:	910183ff 	add	sp, sp, #0x60
    4020506c:	d65f03c0 	ret
    40205070:	f100803f 	cmp	x1, #0x20
    40205074:	54000082 	b.cs	40205084 <core::str::count::do_count_chars+0x3ac>  // b.hs, b.nlast
    40205078:	aa1f03e9 	mov	x9, xzr
    4020507c:	aa1f03e8 	mov	x8, xzr
    40205080:	140000bc 	b	40205370 <core::str::count::do_count_chars+0x698>
    40205084:	6f00e400 	movi	v0.2d, #0x0
    40205088:	4f05e7e3 	movi	v3.16b, #0xbf
    4020508c:	52800028 	mov	w8, #0x1                   	// #1
    40205090:	6f00e402 	movi	v2.2d, #0x0
    40205094:	6f00e407 	movi	v7.2d, #0x0
    40205098:	927d042a 	and	x10, x1, #0x18
    4020509c:	6f00e401 	movi	v1.2d, #0x0
    402050a0:	6f00e412 	movi	v18.2d, #0x0
    402050a4:	927be829 	and	x9, x1, #0xffffffffffffffe0
    402050a8:	6f00e405 	movi	v5.2d, #0x0
    402050ac:	6f00e406 	movi	v6.2d, #0x0
    402050b0:	927be82b 	and	x11, x1, #0xffffffffffffffe0
    402050b4:	6f00e404 	movi	v4.2d, #0x0
    402050b8:	6f00e416 	movi	v22.2d, #0x0
    402050bc:	6f00e411 	movi	v17.2d, #0x0
    402050c0:	6f00e410 	movi	v16.2d, #0x0
    402050c4:	6f00e417 	movi	v23.2d, #0x0
    402050c8:	6f00e414 	movi	v20.2d, #0x0
    402050cc:	6f00e415 	movi	v21.2d, #0x0
    402050d0:	6f00e413 	movi	v19.2d, #0x0
    402050d4:	6f00e418 	movi	v24.2d, #0x0
    402050d8:	4e080d19 	dup	v25.2d, x8
    402050dc:	91004008 	add	x8, x0, #0x10
    402050e0:	aa0803ec 	mov	x12, x8
    402050e4:	385f1112 	ldurb	w18, [x8, #-15]
    402050e8:	385f5102 	ldurb	w2, [x8, #-11]
    402050ec:	385f0d8d 	ldrb	w13, [x12, #-16]!
    402050f0:	aa0c03ef 	mov	x15, x12
    402050f4:	3940098e 	ldrb	w14, [x12, #2]
    402050f8:	38404df0 	ldrb	w16, [x15, #4]!
    402050fc:	394009f1 	ldrb	w17, [x15, #2]
    40205100:	39400d83 	ldrb	w3, [x12, #3]
    40205104:	39400def 	ldrb	w15, [x15, #3]
    40205108:	d370bdce 	lsl	x14, x14, #16
    4020510c:	aa1221ad 	orr	x13, x13, x18, lsl #8
    40205110:	2a022210 	orr	w16, w16, w2, lsl #8
    40205114:	53103e31 	lsl	w17, w17, #16
    40205118:	f100816b 	subs	x11, x11, #0x20
    4020511c:	aa0361ce 	orr	x14, x14, x3, lsl #24
    40205120:	2a0f622f 	orr	w15, w17, w15, lsl #24
    40205124:	aa0d01cd 	orr	x13, x14, x13
    40205128:	2a1001ee 	orr	w14, w15, w16
    4020512c:	aa0e81ad 	orr	x13, x13, x14, lsl #32
    40205130:	f9000bed 	str	x13, [sp, #16]
    40205134:	aa0c03ed 	mov	x13, x12
    40205138:	38408dae 	ldrb	w14, [x13, #8]!
    4020513c:	39400daf 	ldrb	w15, [x13, #3]
    40205140:	394009b0 	ldrb	w16, [x13, #2]
    40205144:	38404db1 	ldrb	w17, [x13, #4]!
    40205148:	394009b2 	ldrb	w18, [x13, #2]
    4020514c:	39402582 	ldrb	w2, [x12, #9]
    40205150:	3940358c 	ldrb	w12, [x12, #13]
    40205154:	39400dad 	ldrb	w13, [x13, #3]
    40205158:	d370be10 	lsl	x16, x16, #16
    4020515c:	53103e52 	lsl	w18, w18, #16
    40205160:	aa0221ce 	orr	x14, x14, x2, lsl #8
    40205164:	2a0c222c 	orr	w12, w17, w12, lsl #8
    40205168:	aa0f620f 	orr	x15, x16, x15, lsl #24
    4020516c:	2a0d624d 	orr	w13, w18, w13, lsl #24
    40205170:	aa0e01ee 	orr	x14, x15, x14
    40205174:	2a0c01ac 	orr	w12, w13, w12
    40205178:	aa0c81cc 	orr	x12, x14, x12, lsl #32
    4020517c:	f9000fec 	str	x12, [sp, #24]
    40205180:	aa0803ec 	mov	x12, x8
    40205184:	3940090e 	ldrb	w14, [x8, #2]
    40205188:	38404d8f 	ldrb	w15, [x12, #4]!
    4020518c:	39400990 	ldrb	w16, [x12, #2]
    40205190:	3940050d 	ldrb	w13, [x8, #1]
    40205194:	39400111 	ldrb	w17, [x8]
    40205198:	39400d12 	ldrb	w18, [x8, #3]
    4020519c:	39401502 	ldrb	w2, [x8, #5]
    402051a0:	39400d8c 	ldrb	w12, [x12, #3]
    402051a4:	d370bdce 	lsl	x14, x14, #16
    402051a8:	53103e10 	lsl	w16, w16, #16
    402051ac:	aa0d222d 	orr	x13, x17, x13, lsl #8
    402051b0:	2a0221ef 	orr	w15, w15, w2, lsl #8
    402051b4:	3dc007fa 	ldr	q26, [sp, #16]
    402051b8:	aa1261ce 	orr	x14, x14, x18, lsl #24
    402051bc:	2a0c620c 	orr	w12, w16, w12, lsl #24
    402051c0:	4e23375a 	cmgt	v26.16b, v26.16b, v3.16b
    402051c4:	aa0d01cd 	orr	x13, x14, x13
    402051c8:	2a0f018c 	orr	w12, w12, w15
    402051cc:	aa0c81ac 	orr	x12, x13, x12, lsl #32
    402051d0:	aa0803ed 	mov	x13, x8
    402051d4:	6f08a75b 	uxtl2	v27.8h, v26.16b
    402051d8:	2f08a75a 	uxtl	v26.8h, v26.8b
    402051dc:	f90003ec 	str	x12, [sp]
    402051e0:	38408dac 	ldrb	w12, [x13, #8]!
    402051e4:	39400dae 	ldrb	w14, [x13, #3]
    402051e8:	394009af 	ldrb	w15, [x13, #2]
    402051ec:	38404db0 	ldrb	w16, [x13, #4]!
    402051f0:	394009b1 	ldrb	w17, [x13, #2]
    402051f4:	39402512 	ldrb	w18, [x8, #9]
    402051f8:	39403502 	ldrb	w2, [x8, #13]
    402051fc:	39400dad 	ldrb	w13, [x13, #3]
    40205200:	d370bdef 	lsl	x15, x15, #16
    40205204:	6f10a77c 	uxtl2	v28.4s, v27.8h
    40205208:	53103e31 	lsl	w17, w17, #16
    4020520c:	aa12218c 	orr	x12, x12, x18, lsl #8
    40205210:	2a022210 	orr	w16, w16, w2, lsl #8
    40205214:	aa0e61ee 	orr	x14, x15, x14, lsl #24
    40205218:	2f10a77b 	uxtl	v27.4s, v27.4h
    4020521c:	2f10a75e 	uxtl	v30.4s, v26.4h
    40205220:	2a0d622d 	orr	w13, w17, w13, lsl #24
    40205224:	6f20a79d 	uxtl2	v29.2d, v28.4s
    40205228:	6f10a75a 	uxtl2	v26.4s, v26.8h
    4020522c:	aa0c01cc 	orr	x12, x14, x12
    40205230:	2f20a79c 	uxtl	v28.2d, v28.2s
    40205234:	91008108 	add	x8, x8, #0x20
    40205238:	2a1001ad 	orr	w13, w13, w16
    4020523c:	6f20a768 	uxtl2	v8.2d, v27.4s
    40205240:	6f20a7c9 	uxtl2	v9.2d, v30.4s
    40205244:	aa0d818c 	orr	x12, x12, x13, lsl #32
    40205248:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    4020524c:	6f20a74a 	uxtl2	v10.2d, v26.4s
    40205250:	2f20a75a 	uxtl	v26.2d, v26.2s
    40205254:	2f20a77b 	uxtl	v27.2d, v27.2s
    40205258:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    4020525c:	f90007ec 	str	x12, [sp, #8]
    40205260:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    40205264:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    40205268:	3dc003ff 	ldr	q31, [sp]
    4020526c:	4efd86d6 	add	v22.2d, v22.2d, v29.2d
    40205270:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40205274:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    40205278:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    4020527c:	4efc8484 	add	v4.2d, v4.2d, v28.2d
    40205280:	4e2337ff 	cmgt	v31.16b, v31.16b, v3.16b
    40205284:	4ee884c6 	add	v6.2d, v6.2d, v8.2d
    40205288:	2f20a7de 	uxtl	v30.2d, v30.2s
    4020528c:	4eea8652 	add	v18.2d, v18.2d, v10.2d
    40205290:	4ee984e7 	add	v7.2d, v7.2d, v9.2d
    40205294:	4efa8421 	add	v1.2d, v1.2d, v26.2d
    40205298:	4efb84a5 	add	v5.2d, v5.2d, v27.2d
    4020529c:	6f08a7fd 	uxtl2	v29.8h, v31.16b
    402052a0:	2f08a7ff 	uxtl	v31.8h, v31.8b
    402052a4:	4e391fde 	and	v30.16b, v30.16b, v25.16b
    402052a8:	6f10a7bc 	uxtl2	v28.4s, v29.8h
    402052ac:	6f10a7e8 	uxtl2	v8.4s, v31.8h
    402052b0:	2f10a7bd 	uxtl	v29.4s, v29.4h
    402052b4:	2f10a7fa 	uxtl	v26.4s, v31.4h
    402052b8:	4efe8442 	add	v2.2d, v2.2d, v30.2d
    402052bc:	2f20a79b 	uxtl	v27.2d, v28.2s
    402052c0:	6f20a79c 	uxtl2	v28.2d, v28.4s
    402052c4:	2f20a7bf 	uxtl	v31.2d, v29.2s
    402052c8:	6f20a509 	uxtl2	v9.2d, v8.4s
    402052cc:	6f20a7bd 	uxtl2	v29.2d, v29.4s
    402052d0:	2f20a74a 	uxtl	v10.2d, v26.2s
    402052d4:	6f20a75a 	uxtl2	v26.2d, v26.4s
    402052d8:	2f20a508 	uxtl	v8.2d, v8.2s
    402052dc:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    402052e0:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    402052e4:	4e391fff 	and	v31.16b, v31.16b, v25.16b
    402052e8:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    402052ec:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    402052f0:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    402052f4:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    402052f8:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    402052fc:	4efc8718 	add	v24.2d, v24.2d, v28.2d
    40205300:	4efb8673 	add	v19.2d, v19.2d, v27.2d
    40205304:	4eff8694 	add	v20.2d, v20.2d, v31.2d
    40205308:	4efd86b5 	add	v21.2d, v21.2d, v29.2d
    4020530c:	4ee986f7 	add	v23.2d, v23.2d, v9.2d
    40205310:	4eea8631 	add	v17.2d, v17.2d, v10.2d
    40205314:	4ee88610 	add	v16.2d, v16.2d, v8.2d
    40205318:	4efa8400 	add	v0.2d, v0.2d, v26.2d
    4020531c:	54ffee21 	b.ne	402050e0 <core::str::count::do_count_chars+0x408>  // b.any
    40205320:	4ef286e3 	add	v3.2d, v23.2d, v18.2d
    40205324:	4ef68712 	add	v18.2d, v24.2d, v22.2d
    40205328:	eb09003f 	cmp	x1, x9
    4020532c:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40205330:	4ee28622 	add	v2.2d, v17.2d, v2.2d
    40205334:	4ee58685 	add	v5.2d, v20.2d, v5.2d
    40205338:	4ee686a6 	add	v6.2d, v21.2d, v6.2d
    4020533c:	4ee18601 	add	v1.2d, v16.2d, v1.2d
    40205340:	4ee48664 	add	v4.2d, v19.2d, v4.2d
    40205344:	4ef28463 	add	v3.2d, v3.2d, v18.2d
    40205348:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    4020534c:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40205350:	4ee68400 	add	v0.2d, v0.2d, v6.2d
    40205354:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40205358:	4ee38400 	add	v0.2d, v0.2d, v3.2d
    4020535c:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    40205360:	5ef1b800 	addp	d0, v0.2d
    40205364:	9e660008 	fmov	x8, d0
    40205368:	54ffd3c0 	b.eq	40204de0 <core::str::count::do_count_chars+0x108>  // b.none
    4020536c:	b400074a 	cbz	x10, 40205454 <core::str::count::do_count_chars+0x77c>
    40205370:	6f00e400 	movi	v0.2d, #0x0
    40205374:	6f00e401 	movi	v1.2d, #0x0
    40205378:	aa0903ea 	mov	x10, x9
    4020537c:	0f05e7e2 	movi	v2.8b, #0xbf
    40205380:	6f00e403 	movi	v3.2d, #0x0
    40205384:	927df029 	and	x9, x1, #0xfffffffffffffff8
    40205388:	6f00e404 	movi	v4.2d, #0x0
    4020538c:	4e081d00 	mov	v0.d[0], x8
    40205390:	52800028 	mov	w8, #0x1                   	// #1
    40205394:	4e080d05 	dup	v5.2d, x8
    40205398:	cb090148 	sub	x8, x10, x9
    4020539c:	8b0a000a 	add	x10, x0, x10
    402053a0:	aa0a03ed 	mov	x13, x10
    402053a4:	3940094c 	ldrb	w12, [x10, #2]
    402053a8:	3940054b 	ldrb	w11, [x10, #1]
    402053ac:	38404dae 	ldrb	w14, [x13, #4]!
    402053b0:	394009af 	ldrb	w15, [x13, #2]
    402053b4:	39400150 	ldrb	w16, [x10]
    402053b8:	39400d51 	ldrb	w17, [x10, #3]
    402053bc:	d370bd8c 	lsl	x12, x12, #16
    402053c0:	39401552 	ldrb	w18, [x10, #5]
    402053c4:	39400dad 	ldrb	w13, [x13, #3]
    402053c8:	53103def 	lsl	w15, w15, #16
    402053cc:	aa0b220b 	orr	x11, x16, x11, lsl #8
    402053d0:	aa11618c 	orr	x12, x12, x17, lsl #24
    402053d4:	b1002108 	adds	x8, x8, #0x8
    402053d8:	2a1221ce 	orr	w14, w14, w18, lsl #8
    402053dc:	2a0d61ed 	orr	w13, w15, w13, lsl #24
    402053e0:	9100214a 	add	x10, x10, #0x8
    402053e4:	aa0b018b 	orr	x11, x12, x11
    402053e8:	2a0e01ac 	orr	w12, w13, w14
    402053ec:	aa0c816b 	orr	x11, x11, x12, lsl #32
    402053f0:	9e670166 	fmov	d6, x11
    402053f4:	0e2234c6 	cmgt	v6.8b, v6.8b, v2.8b
    402053f8:	2f08a4c6 	uxtl	v6.8h, v6.8b
    402053fc:	6f10a4c7 	uxtl2	v7.4s, v6.8h
    40205400:	2f10a4c6 	uxtl	v6.4s, v6.4h
    40205404:	6f20a4f0 	uxtl2	v16.2d, v7.4s
    40205408:	2f20a4d1 	uxtl	v17.2d, v6.2s
    4020540c:	6f20a4c6 	uxtl2	v6.2d, v6.4s
    40205410:	2f20a4e7 	uxtl	v7.2d, v7.2s
    40205414:	4e251e10 	and	v16.16b, v16.16b, v5.16b
    40205418:	4e251e31 	and	v17.16b, v17.16b, v5.16b
    4020541c:	4e251cc6 	and	v6.16b, v6.16b, v5.16b
    40205420:	4e251ce7 	and	v7.16b, v7.16b, v5.16b
    40205424:	4ef08484 	add	v4.2d, v4.2d, v16.2d
    40205428:	4ee68463 	add	v3.2d, v3.2d, v6.2d
    4020542c:	4ef18400 	add	v0.2d, v0.2d, v17.2d
    40205430:	4ee78421 	add	v1.2d, v1.2d, v7.2d
    40205434:	54fffb61 	b.ne	402053a0 <core::str::count::do_count_chars+0x6c8>  // b.any
    40205438:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    4020543c:	4ee48461 	add	v1.2d, v3.2d, v4.2d
    40205440:	eb09003f 	cmp	x1, x9
    40205444:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    40205448:	5ef1b800 	addp	d0, v0.2d
    4020544c:	9e660008 	fmov	x8, d0
    40205450:	54ffcc80 	b.eq	40204de0 <core::str::count::do_count_chars+0x108>  // b.none
    40205454:	cb09002a 	sub	x10, x1, x9
    40205458:	8b090009 	add	x9, x0, x9
    4020545c:	38c0152b 	ldrsb	w11, [x9], #1
    40205460:	3101057f 	cmn	w11, #0x41
    40205464:	9a88d508 	cinc	x8, x8, gt
    40205468:	f100054a 	subs	x10, x10, #0x1
    4020546c:	54ffff81 	b.ne	4020545c <core::str::count::do_count_chars+0x784>  // b.any
    40205470:	17fffe5c 	b	40204de0 <core::str::count::do_count_chars+0x108>

0000000040205474 <core::panicking::panic_const::panic_const_div_by_zero>:
    40205474:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    40205478:	910003fd 	mov	x29, sp
    4020547c:	aa0003e2 	mov	x2, x0
    40205480:	d503201f 	nop
    40205484:	10006260 	adr	x0, 402060d0 <anon.e5cf9e378689f0b52d762c1b402a78cc.8.llvm.5630279096503145348+0xf8>
    40205488:	52800661 	mov	w1, #0x33                  	// #51
    4020548c:	97fffe09 	bl	40204cb0 <core::panicking::panic_fmt>

0000000040205490 <core::panicking::panic_const::panic_const_rem_by_zero>:
    40205490:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    40205494:	910003fd 	mov	x29, sp
    40205498:	aa0003e2 	mov	x2, x0
    4020549c:	d503201f 	nop
    402054a0:	30006240 	adr	x0, 402060e9 <anon.e5cf9e378689f0b52d762c1b402a78cc.8.llvm.5630279096503145348+0x111>
    402054a4:	52800e61 	mov	w1, #0x73                  	// #115
    402054a8:	97fffe02 	bl	40204cb0 <core::panicking::panic_fmt>

00000000402054ac <<core::fmt::Formatter>::pad_integral::write_prefix>:
    402054ac:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    402054b0:	a90157f6 	stp	x22, x21, [sp, #16]
    402054b4:	a9024ff4 	stp	x20, x19, [sp, #32]
    402054b8:	910003fd 	mov	x29, sp
    402054bc:	aa0403f3 	mov	x19, x4
    402054c0:	aa0303f4 	mov	x20, x3
    402054c4:	aa0103f5 	mov	x21, x1
    402054c8:	7144405f 	cmp	w2, #0x110, lsl #12
    402054cc:	540001a0 	b.eq	40205500 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>  // b.none
    402054d0:	f94012a8 	ldr	x8, [x21, #32]
    402054d4:	2a0203e1 	mov	w1, w2
    402054d8:	aa0003f6 	mov	x22, x0
    402054dc:	d63f0100 	blr	x8
    402054e0:	2a0003e8 	mov	w8, w0
    402054e4:	aa1603e0 	mov	x0, x22
    402054e8:	360000c8 	tbz	w8, #0, 40205500 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>
    402054ec:	52800020 	mov	w0, #0x1                   	// #1
    402054f0:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402054f4:	a94157f6 	ldp	x22, x21, [sp, #16]
    402054f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402054fc:	d65f03c0 	ret
    40205500:	b4000114 	cbz	x20, 40205520 <<core::fmt::Formatter>::pad_integral::write_prefix+0x74>
    40205504:	f9400ea3 	ldr	x3, [x21, #24]
    40205508:	aa1403e1 	mov	x1, x20
    4020550c:	aa1303e2 	mov	x2, x19
    40205510:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40205514:	a94157f6 	ldp	x22, x21, [sp, #16]
    40205518:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4020551c:	d61f0060 	br	x3
    40205520:	2a1f03e0 	mov	w0, wzr
    40205524:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40205528:	a94157f6 	ldp	x22, x21, [sp, #16]
    4020552c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40205530:	d65f03c0 	ret

0000000040205534 <<u64 as core::fmt::Display>::fmt>:
    40205534:	d100c3ff 	sub	sp, sp, #0x30
    40205538:	a9027bfd 	stp	x29, x30, [sp, #32]
    4020553c:	910083fd 	add	x29, sp, #0x20
    40205540:	f9400009 	ldr	x9, [x0]
    40205544:	d503201f 	nop
    40205548:	10005608 	adr	x8, 40206008 <anon.e5cf9e378689f0b52d762c1b402a78cc.8.llvm.5630279096503145348+0x30>
    4020554c:	f10fa13f 	cmp	x9, #0x3e8
    40205550:	540004e3 	b.cc	402055ec <<u64 as core::fmt::Display>::fmt+0xb8>  // b.lo, b.ul, b.last
    40205554:	d28b296c 	mov	x12, #0x594b                	// #22859
    40205558:	910033ea 	add	x10, sp, #0xc
    4020555c:	5292cff1 	mov	w17, #0x967f                	// #38527
    40205560:	f2a710cc 	movk	x12, #0x3886, lsl #16
    40205564:	9280026b 	mov	x11, #0xffffffffffffffec    	// #-20
    40205568:	5284e20d 	mov	w13, #0x2710                	// #10000
    4020556c:	f2d8bacc 	movk	x12, #0xc5d6, lsl #32
    40205570:	52828f6e 	mov	w14, #0x147b                	// #5243
    40205574:	91004d4f 	add	x15, x10, #0x13
    40205578:	f2e68dac 	movk	x12, #0x346d, lsl #48
    4020557c:	52800c90 	mov	w16, #0x64                  	// #100
    40205580:	72a01311 	movk	w17, #0x98, lsl #16
    40205584:	aa0903ea 	mov	x10, x9
    40205588:	aa0a03f2 	mov	x18, x10
    4020558c:	9bcc7d4a 	umulh	x10, x10, x12
    40205590:	9100116b 	add	x11, x11, #0x4
    40205594:	eb11025f 	cmp	x18, x17
    40205598:	d34bfd4a 	lsr	x10, x10, #11
    4020559c:	1b0dc940 	msub	w0, w10, w13, w18
    402055a0:	53023c02 	ubfx	w2, w0, #2, #14
    402055a4:	1b0e7c42 	mul	w2, w2, w14
    402055a8:	53117c42 	lsr	w2, w2, #17
    402055ac:	1b108040 	msub	w0, w2, w16, w0
    402055b0:	8b224502 	add	x2, x8, w2, uxtw #1
    402055b4:	39400043 	ldrb	w3, [x2]
    402055b8:	39400442 	ldrb	w2, [x2, #1]
    402055bc:	8b202500 	add	x0, x8, w0, uxth #1
    402055c0:	381fd1e3 	sturb	w3, [x15, #-3]
    402055c4:	39400003 	ldrb	w3, [x0]
    402055c8:	39400400 	ldrb	w0, [x0, #1]
    402055cc:	381fe1e2 	sturb	w2, [x15, #-2]
    402055d0:	381ff1e3 	sturb	w3, [x15, #-1]
    402055d4:	381fc5e0 	strb	w0, [x15], #-4
    402055d8:	54fffd88 	b.hi	40205588 <<u64 as core::fmt::Display>::fmt+0x54>  // b.pmore
    402055dc:	cb0b03eb 	neg	x11, x11
    402055e0:	f100255f 	cmp	x10, #0x9
    402055e4:	540000c8 	b.hi	402055fc <<u64 as core::fmt::Display>::fmt+0xc8>  // b.pmore
    402055e8:	14000015 	b	4020563c <<u64 as core::fmt::Display>::fmt+0x108>
    402055ec:	5280028b 	mov	w11, #0x14                  	// #20
    402055f0:	aa0903ea 	mov	x10, x9
    402055f4:	f100253f 	cmp	x9, #0x9
    402055f8:	54000229 	b.ls	4020563c <<u64 as core::fmt::Display>::fmt+0x108>  // b.plast
    402055fc:	53023d4c 	ubfx	w12, w10, #2, #14
    40205600:	52828f6d 	mov	w13, #0x147b                	// #5243
    40205604:	910033ef 	add	x15, sp, #0xc
    40205608:	1b0d7d8c 	mul	w12, w12, w13
    4020560c:	52800c8d 	mov	w13, #0x64                  	// #100
    40205610:	53117d8c 	lsr	w12, w12, #17
    40205614:	1b0da98a 	msub	w10, w12, w13, w10
    40205618:	d100096d 	sub	x13, x11, #0x2
    4020561c:	8b0b01eb 	add	x11, x15, x11
    40205620:	8b2a250a 	add	x10, x8, w10, uxth #1
    40205624:	3940014e 	ldrb	w14, [x10]
    40205628:	3940054a 	ldrb	w10, [x10, #1]
    4020562c:	382d69ee 	strb	w14, [x15, x13]
    40205630:	381ff16a 	sturb	w10, [x11, #-1]
    40205634:	aa0c03ea 	mov	x10, x12
    40205638:	aa0d03eb 	mov	x11, x13
    4020563c:	b4000049 	cbz	x9, 40205644 <<u64 as core::fmt::Display>::fmt+0x110>
    40205640:	b40000ca 	cbz	x10, 40205658 <<u64 as core::fmt::Display>::fmt+0x124>
    40205644:	8b0a0508 	add	x8, x8, x10, lsl #1
    40205648:	d100056b 	sub	x11, x11, #0x1
    4020564c:	910033e9 	add	x9, sp, #0xc
    40205650:	39400508 	ldrb	w8, [x8, #1]
    40205654:	382b6928 	strb	w8, [x9, x11]
    40205658:	52800288 	mov	w8, #0x14                  	// #20
    4020565c:	aa0103e0 	mov	x0, x1
    40205660:	52800021 	mov	w1, #0x1                   	// #1
    40205664:	cb0b0105 	sub	x5, x8, x11
    40205668:	910033e8 	add	x8, sp, #0xc
    4020566c:	52800022 	mov	w2, #0x1                   	// #1
    40205670:	8b0b0104 	add	x4, x8, x11
    40205674:	aa1f03e3 	mov	x3, xzr
    40205678:	97fffc5a 	bl	402047e0 <<core::fmt::Formatter>::pad_integral>
    4020567c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40205680:	9100c3ff 	add	sp, sp, #0x30
    40205684:	d65f03c0 	ret

0000000040205688 <__udivti3>:
    40205688:	d100c3ff 	sub	sp, sp, #0x30
    4020568c:	a9027bfd 	stp	x29, x30, [sp, #32]
    40205690:	910083fd 	add	x29, sp, #0x20
    40205694:	910003e8 	mov	x8, sp
    40205698:	94000005 	bl	402056ac <compiler_builtins::int::specialized_div_rem::u128_div_rem>
    4020569c:	a94007e0 	ldp	x0, x1, [sp]
    402056a0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    402056a4:	9100c3ff 	add	sp, sp, #0x30
    402056a8:	d65f03c0 	ret

00000000402056ac <compiler_builtins::int::specialized_div_rem::u128_div_rem>:
    402056ac:	dac01049 	clz	x9, x2
    402056b0:	dac0106a 	clz	x10, x3
    402056b4:	f100007f 	cmp	x3, #0x0
    402056b8:	11010129 	add	w9, w9, #0x40
    402056bc:	dac0100c 	clz	x12, x0
    402056c0:	1a89114b 	csel	w11, w10, w9, ne  // ne = any
    402056c4:	dac01029 	clz	x9, x1
    402056c8:	1101018a 	add	w10, w12, #0x40
    402056cc:	f100003f 	cmp	x1, #0x0
    402056d0:	1a8a112f 	csel	w15, w9, w10, ne  // ne = any
    402056d4:	6b0f0169 	subs	w9, w11, w15
    402056d8:	54000149 	b.ls	40205700 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x54>  // b.plast
    402056dc:	7100fdff 	cmp	w15, #0x3f
    402056e0:	540001c9 	b.ls	40205718 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x6c>  // b.plast
    402056e4:	9ac20809 	udiv	x9, x0, x2
    402056e8:	aa1f03ea 	mov	x10, xzr
    402056ec:	aa1f03e1 	mov	x1, xzr
    402056f0:	9b028120 	msub	x0, x9, x2, x0
    402056f4:	a9002909 	stp	x9, x10, [x8]
    402056f8:	a9010500 	stp	x0, x1, [x8, #16]
    402056fc:	d65f03c0 	ret
    40205700:	eb02001f 	cmp	x0, x2
    40205704:	fa03003f 	sbcs	xzr, x1, x3
    40205708:	54000282 	b.cs	40205758 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0xac>  // b.hs, b.nlast
    4020570c:	a9007d1f 	stp	xzr, xzr, [x8]
    40205710:	a9010500 	stp	x0, x1, [x8, #16]
    40205714:	d65f03c0 	ret
    40205718:	71017d7f 	cmp	w11, #0x5f
    4020571c:	540002a9 	b.ls	40205770 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0xc4>  // b.plast
    40205720:	2a0203e9 	mov	w9, w2
    40205724:	9ac9082a 	udiv	x10, x1, x9
    40205728:	1b02854b 	msub	w11, w10, w2, w1
    4020572c:	93c0816b 	extr	x11, x11, x0, #32
    40205730:	9ac9096c 	udiv	x12, x11, x9
    40205734:	1b02ad8b 	msub	w11, w12, w2, w11
    40205738:	aa4c814a 	orr	x10, x10, x12, lsr #32
    4020573c:	b3607d60 	bfi	x0, x11, #32, #32
    40205740:	9ac9080b 	udiv	x11, x0, x9
    40205744:	9b098160 	msub	x0, x11, x9, x0
    40205748:	aa0c8169 	orr	x9, x11, x12, lsl #32
    4020574c:	a9002909 	stp	x9, x10, [x8]
    40205750:	a9017d00 	stp	x0, xzr, [x8, #16]
    40205754:	d65f03c0 	ret
    40205758:	eb020000 	subs	x0, x0, x2
    4020575c:	52800029 	mov	w9, #0x1                   	// #1
    40205760:	da030021 	sbc	x1, x1, x3
    40205764:	a9007d09 	stp	x9, xzr, [x8]
    40205768:	a9010500 	stp	x0, x1, [x8, #16]
    4020576c:	d65f03c0 	ret
    40205770:	7100813f 	cmp	w9, #0x20
    40205774:	54000422 	b.cs	402057f8 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x14c>  // b.hs, b.nlast
    40205778:	d37ff829 	lsl	x9, x1, #1
    4020577c:	5280080a 	mov	w10, #0x40                  	// #64
    40205780:	d37ff86c 	lsl	x12, x3, #1
    40205784:	510005eb 	sub	w11, w15, #0x1
    40205788:	4b0f014a 	sub	w10, w10, w15
    4020578c:	9acb2129 	lsl	x9, x9, x11
    40205790:	9aca240d 	lsr	x13, x0, x10
    40205794:	9acb218b 	lsl	x11, x12, x11
    40205798:	9aca244c 	lsr	x12, x2, x10
    4020579c:	9aca242e 	lsr	x14, x1, x10
    402057a0:	9aca246f 	lsr	x15, x3, x10
    402057a4:	f27a015f 	tst	x10, #0x40
    402057a8:	aa0d0129 	orr	x9, x9, x13
    402057ac:	aa0c016a 	orr	x10, x11, x12
    402057b0:	9a8911c9 	csel	x9, x14, x9, ne  // ne = any
    402057b4:	9a8a11ea 	csel	x10, x15, x10, ne  // ne = any
    402057b8:	9aca0929 	udiv	x9, x9, x10
    402057bc:	9bc97c4a 	umulh	x10, x2, x9
    402057c0:	9b097c6b 	mul	x11, x3, x9
    402057c4:	9bc97c6d 	umulh	x13, x3, x9
    402057c8:	9b097c4c 	mul	x12, x2, x9
    402057cc:	ab0b014b 	adds	x11, x10, x11
    402057d0:	9a8d35aa 	cinc	x10, x13, cs  // cs = hs, nlast
    402057d4:	b500090a 	cbnz	x10, 402058f4 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x248>
    402057d8:	eb0c001f 	cmp	x0, x12
    402057dc:	fa0b003f 	sbcs	xzr, x1, x11
    402057e0:	540008a3 	b.cc	402058f4 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x248>  // b.lo, b.ul, b.last
    402057e4:	eb0c0000 	subs	x0, x0, x12
    402057e8:	da0b0021 	sbc	x1, x1, x11
    402057ec:	a9007d09 	stp	x9, xzr, [x8]
    402057f0:	a9010500 	stp	x0, x1, [x8, #16]
    402057f4:	d65f03c0 	ret
    402057f8:	52800c0d 	mov	w13, #0x60                  	// #96
    402057fc:	d37ff86c 	lsl	x12, x3, #1
    40205800:	5101856e 	sub	w14, w11, #0x61
    40205804:	4b0b01ad 	sub	w13, w13, w11
    40205808:	aa1f03e9 	mov	x9, xzr
    4020580c:	aa1f03ea 	mov	x10, xzr
    40205810:	9ace218e 	lsl	x14, x12, x14
    40205814:	9acd2450 	lsr	x16, x2, x13
    40205818:	9acd2471 	lsr	x17, x3, x13
    4020581c:	f27a01bf 	tst	x13, #0x40
    40205820:	aa1001ce 	orr	x14, x14, x16
    40205824:	52800810 	mov	w16, #0x40                  	// #64
    40205828:	9a8e122e 	csel	x14, x17, x14, ne  // ne = any
    4020582c:	2a0e03ee 	mov	w14, w14
    40205830:	910005ce 	add	x14, x14, #0x1
    40205834:	d37ff832 	lsl	x18, x1, #1
    40205838:	4b0f0211 	sub	w17, w16, w15
    4020583c:	510005ef 	sub	w15, w15, #0x1
    40205840:	9ad12424 	lsr	x4, x1, x17
    40205844:	f27a023f 	tst	x17, #0x40
    40205848:	9acf224f 	lsl	x15, x18, x15
    4020584c:	9ad12412 	lsr	x18, x0, x17
    40205850:	aa1201ef 	orr	x15, x15, x18
    40205854:	9a8f1092 	csel	x18, x4, x15, ne  // ne = any
    40205858:	6b0d022f 	subs	w15, w17, w13
    4020585c:	540005c3 	b.cc	40205914 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x268>  // b.lo, b.ul, b.last
    40205860:	9ace0a51 	udiv	x17, x18, x14
    40205864:	2a2f03e6 	mvn	w6, w15
    40205868:	f27a01ff 	tst	x15, #0x40
    4020586c:	9bd17c52 	umulh	x18, x2, x17
    40205870:	d341fe25 	lsr	x5, x17, #1
    40205874:	9b117c44 	mul	x4, x2, x17
    40205878:	9ac624a5 	lsr	x5, x5, x6
    4020587c:	9b114872 	madd	x18, x3, x17, x18
    40205880:	9acf2231 	lsl	x17, x17, x15
    40205884:	d341fc87 	lsr	x7, x4, #1
    40205888:	9ac624e6 	lsr	x6, x7, x6
    4020588c:	9acf2252 	lsl	x18, x18, x15
    40205890:	9acf208f 	lsl	x15, x4, x15
    40205894:	9a851224 	csel	x4, x17, x5, ne  // ne = any
    40205898:	9a9113f1 	csel	x17, xzr, x17, ne  // ne = any
    4020589c:	aa060252 	orr	x18, x18, x6
    402058a0:	9a9211f2 	csel	x18, x15, x18, ne  // ne = any
    402058a4:	9a8f13ef 	csel	x15, xzr, x15, ne  // ne = any
    402058a8:	ab090229 	adds	x9, x17, x9
    402058ac:	9a0a008a 	adc	x10, x4, x10
    402058b0:	eb0f0000 	subs	x0, x0, x15
    402058b4:	fa120021 	sbcs	x1, x1, x18
    402058b8:	dac0100f 	clz	x15, x0
    402058bc:	dac01031 	clz	x17, x1
    402058c0:	110101ef 	add	w15, w15, #0x40
    402058c4:	1a8f122f 	csel	w15, w17, w15, ne  // ne = any
    402058c8:	6b0f017f 	cmp	w11, w15
    402058cc:	54000549 	b.ls	40205974 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x2c8>  // b.plast
    402058d0:	7100fdff 	cmp	w15, #0x3f
    402058d4:	54fffb09 	b.ls	40205834 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x188>  // b.plast
    402058d8:	9ac2080b 	udiv	x11, x0, x2
    402058dc:	9b028160 	msub	x0, x11, x2, x0
    402058e0:	ab0b0129 	adds	x9, x9, x11
    402058e4:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    402058e8:	a9002909 	stp	x9, x10, [x8]
    402058ec:	a9017d00 	stp	x0, xzr, [x8, #16]
    402058f0:	d65f03c0 	ret
    402058f4:	ab00004d 	adds	x13, x2, x0
    402058f8:	d1000529 	sub	x9, x9, #0x1
    402058fc:	9a01006e 	adc	x14, x3, x1
    40205900:	eb0c01a0 	subs	x0, x13, x12
    40205904:	da0b01c1 	sbc	x1, x14, x11
    40205908:	a9007d09 	stp	x9, xzr, [x8]
    4020590c:	a9010500 	stp	x0, x1, [x8, #16]
    40205910:	d65f03c0 	ret
    40205914:	2a3103eb 	mvn	w11, w17
    40205918:	9ad1244d 	lsr	x13, x2, x17
    4020591c:	f27a023f 	tst	x17, #0x40
    40205920:	9acb218b 	lsl	x11, x12, x11
    40205924:	9ad1246c 	lsr	x12, x3, x17
    40205928:	aa0d016b 	orr	x11, x11, x13
    4020592c:	9a8b118b 	csel	x11, x12, x11, ne  // ne = any
    40205930:	9acb0a4d 	udiv	x13, x18, x11
    40205934:	9bcd7c4b 	umulh	x11, x2, x13
    40205938:	9b0d7c4c 	mul	x12, x2, x13
    4020593c:	9b0d2c6b 	madd	x11, x3, x13, x11
    40205940:	eb0c001f 	cmp	x0, x12
    40205944:	fa0b003f 	sbcs	xzr, x1, x11
    40205948:	540002a2 	b.cs	4020599c <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x2f0>  // b.hs, b.nlast
    4020594c:	d10005ad 	sub	x13, x13, #0x1
    40205950:	ab0d0129 	adds	x9, x9, x13
    40205954:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40205958:	ab02000d 	adds	x13, x0, x2
    4020595c:	9a03002e 	adc	x14, x1, x3
    40205960:	eb0c01a0 	subs	x0, x13, x12
    40205964:	da0b01c1 	sbc	x1, x14, x11
    40205968:	a9002909 	stp	x9, x10, [x8]
    4020596c:	a9010500 	stp	x0, x1, [x8, #16]
    40205970:	d65f03c0 	ret
    40205974:	eb02001f 	cmp	x0, x2
    40205978:	fa03003f 	sbcs	xzr, x1, x3
    4020597c:	54ffebc3 	b.cc	402056f4 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x48>  // b.lo, b.ul, b.last
    40205980:	b1000529 	adds	x9, x9, #0x1
    40205984:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40205988:	eb020000 	subs	x0, x0, x2
    4020598c:	da030021 	sbc	x1, x1, x3
    40205990:	a9002909 	stp	x9, x10, [x8]
    40205994:	a9010500 	stp	x0, x1, [x8, #16]
    40205998:	d65f03c0 	ret
    4020599c:	ab0d0129 	adds	x9, x9, x13
    402059a0:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    402059a4:	eb0c0000 	subs	x0, x0, x12
    402059a8:	da0b0021 	sbc	x1, x1, x11
    402059ac:	a9002909 	stp	x9, x10, [x8]
    402059b0:	a9010500 	stp	x0, x1, [x8, #16]
    402059b4:	d65f03c0 	ret

00000000402059b8 <memcpy>:
    402059b8:	f100405f 	cmp	x2, #0x10
    402059bc:	54000723 	b.cc	40205aa0 <memcpy+0xe8>  // b.lo, b.ul, b.last
    402059c0:	cb0003ec 	neg	x12, x0
    402059c4:	92400988 	and	x8, x12, #0x7
    402059c8:	8b080009 	add	x9, x0, x8
    402059cc:	eb09001f 	cmp	x0, x9
    402059d0:	54000422 	b.cs	40205a54 <memcpy+0x9c>  // b.hs, b.nlast
    402059d4:	f100111f 	cmp	x8, #0x4
    402059d8:	aa0003ea 	mov	x10, x0
    402059dc:	aa0103eb 	mov	x11, x1
    402059e0:	54000323 	b.cc	40205a44 <memcpy+0x8c>  // b.lo, b.ul, b.last
    402059e4:	cb01000a 	sub	x10, x0, x1
    402059e8:	aa0103eb 	mov	x11, x1
    402059ec:	f100815f 	cmp	x10, #0x20
    402059f0:	aa0003ea 	mov	x10, x0
    402059f4:	54000283 	b.cc	40205a44 <memcpy+0x8c>  // b.lo, b.ul, b.last
    402059f8:	927e018c 	and	x12, x12, #0x4
    402059fc:	aa0003ed 	mov	x13, x0
    40205a00:	aa0103ee 	mov	x14, x1
    40205a04:	8b0c000a 	add	x10, x0, x12
    40205a08:	8b0c002b 	add	x11, x1, x12
    40205a0c:	aa0c03ef 	mov	x15, x12
    40205a10:	39400dd0 	ldrb	w16, [x14, #3]
    40205a14:	394009d1 	ldrb	w17, [x14, #2]
    40205a18:	f10011ef 	subs	x15, x15, #0x4
    40205a1c:	394001d2 	ldrb	w18, [x14]
    40205a20:	394005c3 	ldrb	w3, [x14, #1]
    40205a24:	910011ce 	add	x14, x14, #0x4
    40205a28:	39000db0 	strb	w16, [x13, #3]
    40205a2c:	390009b1 	strb	w17, [x13, #2]
    40205a30:	390005a3 	strb	w3, [x13, #1]
    40205a34:	380045b2 	strb	w18, [x13], #4
    40205a38:	54fffec1 	b.ne	40205a10 <memcpy+0x58>  // b.any
    40205a3c:	eb0c011f 	cmp	x8, x12
    40205a40:	540000a0 	b.eq	40205a54 <memcpy+0x9c>  // b.none
    40205a44:	3840156c 	ldrb	w12, [x11], #1
    40205a48:	3800154c 	strb	w12, [x10], #1
    40205a4c:	eb09015f 	cmp	x10, x9
    40205a50:	54ffffa1 	b.ne	40205a44 <memcpy+0x8c>  // b.any
    40205a54:	cb08004b 	sub	x11, x2, x8
    40205a58:	8b08002a 	add	x10, x1, x8
    40205a5c:	927df16c 	and	x12, x11, #0xfffffffffffffff8
    40205a60:	f240095f 	tst	x10, #0x7
    40205a64:	8b0c0128 	add	x8, x9, x12
    40205a68:	540007a1 	b.ne	40205b5c <memcpy+0x1a4>  // b.any
    40205a6c:	eb08013f 	cmp	x9, x8
    40205a70:	540000c2 	b.cs	40205a88 <memcpy+0xd0>  // b.hs, b.nlast
    40205a74:	aa0a03ed 	mov	x13, x10
    40205a78:	f84085ae 	ldr	x14, [x13], #8
    40205a7c:	f800852e 	str	x14, [x9], #8
    40205a80:	eb08013f 	cmp	x9, x8
    40205a84:	54ffffa3 	b.cc	40205a78 <memcpy+0xc0>  // b.lo, b.ul, b.last
    40205a88:	8b0c0141 	add	x1, x10, x12
    40205a8c:	92400962 	and	x2, x11, #0x7
    40205a90:	8b020109 	add	x9, x8, x2
    40205a94:	eb09011f 	cmp	x8, x9
    40205a98:	540000c3 	b.cc	40205ab0 <memcpy+0xf8>  // b.lo, b.ul, b.last
    40205a9c:	1400002f 	b	40205b58 <memcpy+0x1a0>
    40205aa0:	aa0003e8 	mov	x8, x0
    40205aa4:	8b020009 	add	x9, x0, x2
    40205aa8:	eb09001f 	cmp	x0, x9
    40205aac:	54000562 	b.cs	40205b58 <memcpy+0x1a0>  // b.hs, b.nlast
    40205ab0:	f100105f 	cmp	x2, #0x4
    40205ab4:	540004a3 	b.cc	40205b48 <memcpy+0x190>  // b.lo, b.ul, b.last
    40205ab8:	cb01010a 	sub	x10, x8, x1
    40205abc:	f100815f 	cmp	x10, #0x20
    40205ac0:	54000443 	b.cc	40205b48 <memcpy+0x190>  // b.lo, b.ul, b.last
    40205ac4:	39400c2a 	ldrb	w10, [x1, #3]
    40205ac8:	3940082b 	ldrb	w11, [x1, #2]
    40205acc:	3940002c 	ldrb	w12, [x1]
    40205ad0:	3940042d 	ldrb	w13, [x1, #1]
    40205ad4:	39000d0a 	strb	w10, [x8, #3]
    40205ad8:	927e044a 	and	x10, x2, #0xc
    40205adc:	f100115f 	cmp	x10, #0x4
    40205ae0:	3900090b 	strb	w11, [x8, #2]
    40205ae4:	3900050d 	strb	w13, [x8, #1]
    40205ae8:	3900010c 	strb	w12, [x8]
    40205aec:	54000260 	b.eq	40205b38 <memcpy+0x180>  // b.none
    40205af0:	39401c2b 	ldrb	w11, [x1, #7]
    40205af4:	3940182c 	ldrb	w12, [x1, #6]
    40205af8:	f100215f 	cmp	x10, #0x8
    40205afc:	3940102d 	ldrb	w13, [x1, #4]
    40205b00:	3940142e 	ldrb	w14, [x1, #5]
    40205b04:	39001d0b 	strb	w11, [x8, #7]
    40205b08:	3900190c 	strb	w12, [x8, #6]
    40205b0c:	3900150e 	strb	w14, [x8, #5]
    40205b10:	3900110d 	strb	w13, [x8, #4]
    40205b14:	54000120 	b.eq	40205b38 <memcpy+0x180>  // b.none
    40205b18:	39402c2b 	ldrb	w11, [x1, #11]
    40205b1c:	3940282c 	ldrb	w12, [x1, #10]
    40205b20:	3940202d 	ldrb	w13, [x1, #8]
    40205b24:	3940242e 	ldrb	w14, [x1, #9]
    40205b28:	39002d0b 	strb	w11, [x8, #11]
    40205b2c:	3900290c 	strb	w12, [x8, #10]
    40205b30:	3900250e 	strb	w14, [x8, #9]
    40205b34:	3900210d 	strb	w13, [x8, #8]
    40205b38:	eb0a005f 	cmp	x2, x10
    40205b3c:	540000e0 	b.eq	40205b58 <memcpy+0x1a0>  // b.none
    40205b40:	8b0a0108 	add	x8, x8, x10
    40205b44:	8b0a0021 	add	x1, x1, x10
    40205b48:	3840142a 	ldrb	w10, [x1], #1
    40205b4c:	3800150a 	strb	w10, [x8], #1
    40205b50:	eb09011f 	cmp	x8, x9
    40205b54:	54ffffa1 	b.ne	40205b48 <memcpy+0x190>  // b.any
    40205b58:	d65f03c0 	ret
    40205b5c:	eb08013f 	cmp	x9, x8
    40205b60:	54fff942 	b.cs	40205a88 <memcpy+0xd0>  // b.hs, b.nlast
    40205b64:	aa0a03ed 	mov	x13, x10
    40205b68:	aa0d03f0 	mov	x16, x13
    40205b6c:	394009af 	ldrb	w15, [x13, #2]
    40205b70:	394005ae 	ldrb	w14, [x13, #1]
    40205b74:	38404e11 	ldrb	w17, [x16, #4]!
    40205b78:	39400a12 	ldrb	w18, [x16, #2]
    40205b7c:	394001a1 	ldrb	w1, [x13]
    40205b80:	39400da2 	ldrb	w2, [x13, #3]
    40205b84:	d370bdef 	lsl	x15, x15, #16
    40205b88:	394015a3 	ldrb	w3, [x13, #5]
    40205b8c:	39400e10 	ldrb	w16, [x16, #3]
    40205b90:	53103e52 	lsl	w18, w18, #16
    40205b94:	aa0e202e 	orr	x14, x1, x14, lsl #8
    40205b98:	aa0261ef 	orr	x15, x15, x2, lsl #24
    40205b9c:	910021ad 	add	x13, x13, #0x8
    40205ba0:	2a032231 	orr	w17, w17, w3, lsl #8
    40205ba4:	2a106250 	orr	w16, w18, w16, lsl #24
    40205ba8:	aa0e01ee 	orr	x14, x15, x14
    40205bac:	2a11020f 	orr	w15, w16, w17
    40205bb0:	aa0f81ce 	orr	x14, x14, x15, lsl #32
    40205bb4:	f800852e 	str	x14, [x9], #8
    40205bb8:	eb08013f 	cmp	x9, x8
    40205bbc:	54fffd63 	b.cc	40205b68 <memcpy+0x1b0>  // b.lo, b.ul, b.last
    40205bc0:	17ffffb2 	b	40205a88 <memcpy+0xd0>

0000000040205bc4 <__umodti3>:
    40205bc4:	d100c3ff 	sub	sp, sp, #0x30
    40205bc8:	a9027bfd 	stp	x29, x30, [sp, #32]
    40205bcc:	910083fd 	add	x29, sp, #0x20
    40205bd0:	910003e8 	mov	x8, sp
    40205bd4:	97fffeb6 	bl	402056ac <compiler_builtins::int::specialized_div_rem::u128_div_rem>
    40205bd8:	a94107e0 	ldp	x0, x1, [sp, #16]
    40205bdc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40205be0:	9100c3ff 	add	sp, sp, #0x30
    40205be4:	d65f03c0 	ret

0000000040205be8 <memset>:
    40205be8:	f100405f 	cmp	x2, #0x10
    40205bec:	540009e3 	b.cc	40205d28 <memset+0x140>  // b.lo, b.ul, b.last
    40205bf0:	cb0003eb 	neg	x11, x0
    40205bf4:	92400968 	and	x8, x11, #0x7
    40205bf8:	8b080009 	add	x9, x0, x8
    40205bfc:	eb09001f 	cmp	x0, x9
    40205c00:	54000302 	b.cs	40205c60 <memset+0x78>  // b.hs, b.nlast
    40205c04:	f100111f 	cmp	x8, #0x4
    40205c08:	aa0003ea 	mov	x10, x0
    40205c0c:	54000243 	b.cc	40205c54 <memset+0x6c>  // b.lo, b.ul, b.last
    40205c10:	0e020c20 	dup	v0.4h, w1
    40205c14:	927e016b 	and	x11, x11, #0x4
    40205c18:	aa0003ec 	mov	x12, x0
    40205c1c:	8b0b000a 	add	x10, x0, x11
    40205c20:	aa0b03ed 	mov	x13, x11
    40205c24:	5e0e0401 	mov	h1, v0.h[3]
    40205c28:	5e0a0402 	mov	h2, v0.h[2]
    40205c2c:	5e060403 	mov	h3, v0.h[1]
    40205c30:	3d000180 	str	b0, [x12]
    40205c34:	f10011ad 	subs	x13, x13, #0x4
    40205c38:	3c003181 	stur	b1, [x12, #3]
    40205c3c:	3c002182 	stur	b2, [x12, #2]
    40205c40:	3c001183 	stur	b3, [x12, #1]
    40205c44:	9100118c 	add	x12, x12, #0x4
    40205c48:	54ffff41 	b.ne	40205c30 <memset+0x48>  // b.any
    40205c4c:	eb0b011f 	cmp	x8, x11
    40205c50:	54000080 	b.eq	40205c60 <memset+0x78>  // b.none
    40205c54:	38001541 	strb	w1, [x10], #1
    40205c58:	eb09015f 	cmp	x10, x9
    40205c5c:	54ffffc1 	b.ne	40205c54 <memset+0x6c>  // b.any
    40205c60:	cb08004a 	sub	x10, x2, x8
    40205c64:	927df148 	and	x8, x10, #0xfffffffffffffff8
    40205c68:	8b080128 	add	x8, x9, x8
    40205c6c:	eb08013f 	cmp	x9, x8
    40205c70:	54000102 	b.cs	40205c90 <memset+0xa8>  // b.hs, b.nlast
    40205c74:	12001c2b 	and	w11, w1, #0xff
    40205c78:	3200c3ec 	mov	w12, #0x1010101             	// #16843009
    40205c7c:	1b0c7d6b 	mul	w11, w11, w12
    40205c80:	aa0b816b 	orr	x11, x11, x11, lsl #32
    40205c84:	f800852b 	str	x11, [x9], #8
    40205c88:	eb08013f 	cmp	x9, x8
    40205c8c:	54ffffc3 	b.cc	40205c84 <memset+0x9c>  // b.lo, b.ul, b.last
    40205c90:	92400942 	and	x2, x10, #0x7
    40205c94:	8b020109 	add	x9, x8, x2
    40205c98:	eb09011f 	cmp	x8, x9
    40205c9c:	54000442 	b.cs	40205d24 <memset+0x13c>  // b.hs, b.nlast
    40205ca0:	f100105f 	cmp	x2, #0x4
    40205ca4:	540003a3 	b.cc	40205d18 <memset+0x130>  // b.lo, b.ul, b.last
    40205ca8:	927e044a 	and	x10, x2, #0xc
    40205cac:	39000d01 	strb	w1, [x8, #3]
    40205cb0:	f100115f 	cmp	x10, #0x4
    40205cb4:	8b0a010b 	add	x11, x8, x10
    40205cb8:	39000901 	strb	w1, [x8, #2]
    40205cbc:	39000501 	strb	w1, [x8, #1]
    40205cc0:	39000101 	strb	w1, [x8]
    40205cc4:	54000240 	b.eq	40205d0c <memset+0x124>  // b.none
    40205cc8:	0e020c20 	dup	v0.4h, w1
    40205ccc:	f100215f 	cmp	x10, #0x8
    40205cd0:	5e0e0401 	mov	h1, v0.h[3]
    40205cd4:	5e0a0402 	mov	h2, v0.h[2]
    40205cd8:	5e060403 	mov	h3, v0.h[1]
    40205cdc:	3c004100 	stur	b0, [x8, #4]
    40205ce0:	3c007101 	stur	b1, [x8, #7]
    40205ce4:	3c006102 	stur	b2, [x8, #6]
    40205ce8:	3c005103 	stur	b3, [x8, #5]
    40205cec:	54000100 	b.eq	40205d0c <memset+0x124>  // b.none
    40205cf0:	5e0e0401 	mov	h1, v0.h[3]
    40205cf4:	5e0a0402 	mov	h2, v0.h[2]
    40205cf8:	3c008100 	stur	b0, [x8, #8]
    40205cfc:	5e060403 	mov	h3, v0.h[1]
    40205d00:	3c00b101 	stur	b1, [x8, #11]
    40205d04:	3c00a102 	stur	b2, [x8, #10]
    40205d08:	3c009103 	stur	b3, [x8, #9]
    40205d0c:	eb0a005f 	cmp	x2, x10
    40205d10:	aa0b03e8 	mov	x8, x11
    40205d14:	54000080 	b.eq	40205d24 <memset+0x13c>  // b.none
    40205d18:	38001501 	strb	w1, [x8], #1
    40205d1c:	eb09011f 	cmp	x8, x9
    40205d20:	54ffffc1 	b.ne	40205d18 <memset+0x130>  // b.any
    40205d24:	d65f03c0 	ret
    40205d28:	aa0003e8 	mov	x8, x0
    40205d2c:	8b020009 	add	x9, x0, x2
    40205d30:	eb09001f 	cmp	x0, x9
    40205d34:	54fffb63 	b.cc	40205ca0 <memset+0xb8>  // b.lo, b.ul, b.last
    40205d38:	17fffffb 	b	40205d24 <memset+0x13c>
