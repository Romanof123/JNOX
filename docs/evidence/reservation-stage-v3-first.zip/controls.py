from pathlib import Path
from dataclasses import replace
import sys,hashlib
d=Path(__file__).parent
sys.path.insert(0,str(d/'candidate/tools'))
from reservation_stage import replay,Launch
h=lambda b:hashlib.sha256(b).hexdigest()
for path in [d.parent/'reservation-compact-fresh/raw/new/aligned-wake/plain',d.parent/'reservation-profile-fresh/raw/S/aligned-wake/plain']:
 raw=(path/'uart').read_bytes();elf=(path/'kernel.elf').read_bytes()
 r=replay(raw,elf,Launch(1,'aligned-wake','B',h(elf),h(raw),None));print(path,r['terminal'],r['mask'])
p=d/'raw/02-WE';raw=(p/'uart').read_bytes();elf=(p/'kernel.elf').read_bytes()
l=Launch(2,'aligned-wake','E',h(elf),h(raw),0x402013f0)
probe=next(x for x in raw.splitlines(keepends=True) if x.startswith(b'38 '))
for name,b,desc in [('wrong ELF hash',raw,replace(l,elf_sha256='0'*64)),('wrong UART hash',raw,replace(l,uart_sha256='0'*64)),('duplicate',raw.replace(probe,probe*2),None),('missing',raw.replace(probe,b''),None),('wrong PC',raw,replace(l,counter_pc=0x402013ec))]:
 try:replay(b,elf,desc or replace(l,uart_sha256=h(b)))
 except ValueError as exc:print(name,'rejected',exc)
 else:raise ValueError(name)
