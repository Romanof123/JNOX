from pathlib import Path
import subprocess as s,re
for f in sorted(Path('.').glob('*.elf')):
 for suffix,cmd in [('asm',['aarch64-linux-gnu-objdump','-dC']),('map',['readelf','-aW'])]:
  f.with_suffix('.'+suffix).write_bytes(s.check_output(cmd+[str(f)]))
 lines=f.with_suffix('.asm').read_text().splitlines()
 sites=[i for i,l in enumerate(lines) if 'cntpct_el0' in l.lower()]
 print(f,len(sites))
 for i in sites:
  if 'adr' in lines[i+1] and lines[i].split(':')[0].strip() in lines[i+1]:
   print('\n'.join(lines[i-9:i+10]))
