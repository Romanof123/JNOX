# POL-010 ordinary first-launch accounting

Freeze the source, exact selector, ELF SHA-256, tooling/build paths, QEMU argv and version, native Linux capture directory, affinity, timeout and default virtual clock before launch. Use a separate fresh process and retain the first result in each of these ordered positions. A timeout, prior natural failure or partial transcript stays in its position.

1. lottery1, cold seed 1, 32 physical one-tick grants.
2. lottery2, cold seed 2, 32 physical one-tick grants.
3. stride, 16 grants with C admitted before slot 8.
4. lottery-miss, first timer intentionally programmed for two ticks and evaluated against one.
5. stride-delay, weight-one two-tick compare. Distinguish measured residency ≥3 and its full charge from deliberately keeping an already asserted IRQ pending. This source has no controlled IRQ-delay instrument.

The firmware emits seven unsigned decimal columns per raw row (tag plus six fields). Nine columns belong to the derived per-grant table. Unexpected raw widths invalidate the capture. Zero source line carries no committed failure. Line, mode, slot and operands on early failure must map to the exact retained source and ELF before classifying its cause. Synthetic mutations, legacy assembly and host windows each have separate provenance.

Commands from this directory on the permitted machine:

```sh
python3 score.py order > first-launch-order.json
python3 score.py controls > synthetic-controls.json
python3 score.py calendar > host-windows.json
python3 score.py score lottery1 /capture/lottery1/uart --elf /capture/lottery1/kernel.elf --exceptions /capture/lottery1/exceptions > seed1.json
python3 score.py mutate /capture/lottery1/uart rng-word > synthetic-rng.uart
python3 score.py score lottery1 synthetic-rng.uart --elf /capture/lottery1/kernel.elf --exceptions /capture/lottery1/exceptions > synthetic-rng.json
```

Repeat scoring for each named position using its own same-launch artifacts. JSON findings and the complete-observation field carry verdicts; CLI exit zero indicates report generation. Require immutable source-to-image build provenance separately. The scorer correlates ordered exception entries/returns and compares frame fingerprints across resumptions. It conservatively requires interrupted PCs in the corresponding linked entry function. If an out-of-line shared helper contains the stop, retain the failure and establish the call path from disassembly before qualification. IRQ/SVC entry mechanism and integer residency measurements do not establish instruction-level service or pending-IRQ manipulation. The empty dispatch is evidenced by the idle selection and first RNG preceding state; the guest schema lacks a separate ready-mask/RNG snapshot for the idle interval.

The three historical lines LOTTERY SEED A, LOTTERY SEED B and STRIDE SERVICE JOIN identify the old benchmark. EVD-021's corrected 81-row, 75-IRQ, six-SVC result included deliberately delayed charge. The initial 80-row record used the wrong stride frequency and grant-based charging. The historical four-IRQ failure remains unattributed. These expected legacy observations are separate from the ordinary application's five first launches. The ordinary expected counts are [10,8,14] and [5,11,16] for seeds 1 and 2. Expected stride service is [4,8,0] followed by [2,4,8]. Preserve measured service separately from grant counts.

Mutations rng-word, ticket-owner, counter-stop, resume-pc and frozen-client each change one field in a complete captured seed-1 parent. Each must produce a specific failed replay, independent of the retained footer. Preserve its parent and mutation name. Neither scorer nor tests were run during authoring.
