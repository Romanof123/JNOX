import json,re,hashlib
from pathlib import Path
d=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((d/'freeze.json').read_text())
r=dict(schema='jnox.ordinary-136.three-first-captures/1',revision=f['revision'],tree='6ba8e4e2f4b1b9e8ac41ba02299ee73461e6c35e',freeze_sha256=sha(d/'freeze.json'),launch_script_sha256=sha(d/'launch.py'),cases={},unexecuted=['lottery-miss','stride-delay'],limitations=['Single default-clock QEMU TCG virtual CPU per image; external trace confirms exception order and PC, not exact instruction-level service, counter samples, GIC state or fingerprint values independently. Private-state progress and timer data are guest records cross-checked with physical exception transfers. Empty-ready RNG state inferred across idle. Build provenance from frozen index; retained Windows-built ELF was copied and hashed on native Linux. No physical board, interference, enforcement or late-charge experiment.'])
for k in f['cases']:
    p=d/k
    q=json.loads((p/'score.json').read_text())
    assert q['complete_arithmetic_and_mechanism_observation']
    e=(p/'exceptions').read_text()
    rows=q['raw_rows'];g=q['grants']
    phases=[[sum(a[6] for a in g[l:h] if a[1]==i) for i in range(3)] for l,h in [(0,8),(8,16)]] if k=='stride' else None
    r['cases'][k]=dict(outcome=json.loads((p/'outcome.json').read_text()),qualified=True,counts=q['counts'],whole_service=q['whole_service'],stride_phase_service=phases,irq=e.count('[IRQ]'),svc=e.count('[SVC]'),eret=e.count('Exception return'),uart_bytes=(p/'uart').stat().st_size,raw_rows=len(rows),first_failure_record=q['first_guest_record'],completed_work_counts=[next(a[3] for a in reversed(rows) if a[0]==12 and a[2]==i) for i in range(3)],stream=[a[1] for a in g],hashes={a.name:sha(a) for a in sorted(p.iterdir())})
h=d.parent/'ordinary-proportional-pinned/docs/evidence'
r['historical_reference_only']=dict(summary='EVD-021 initial 80 decisions had 40 Hz stride instead of 25 Hz and grant-based accounting. Corrected EVD-021 81 rows,75 IRQ,6 SVC, includes delayed grant. EVD-035 historical four IRQ failure was unattributed.',pinned_file_hashes={k:sha(h/k) for k in ['evd-021-initial.json','evd-021.json','evd-035.json','evd-021.en.md','evd-035.en.md']})
(d/'verification.json').write_bytes((json.dumps(r,indent=2)+'\n').encode())
print(sha(d/'verification.json'))
for k,c in r['cases'].items():print(k,c['irq'],c['svc'],c['eret'],c['stride_phase_service'],c['completed_work_counts'])