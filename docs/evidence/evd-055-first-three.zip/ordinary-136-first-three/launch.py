import hashlib,json,os,sys,subprocess,time,tempfile,shutil
from pathlib import Path
dest=Path(sys.argv[1]); root=dest.parent; native=Path(tempfile.mkdtemp(prefix='jnox-ordinary-136-'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
index=root/'mask-prop-builds/index.json'; images=json.loads(index.read_text())['images']
order=['lottery1','lottery2','stride']; version=subprocess.check_output(['qemu-system-aarch64','--version']).decode()
freeze=dict(revision='b3994a99c2f40b57ed6cad779fde6a5f2488c7ed',index_sha=sha(index),scorer_sha=sha(root/'ordinary-proportional-independent/score.py'),qemu_version=version,affinity=sorted(os.sched_getaffinity(0)),timeout_seconds=25,quiet_after_footer_seconds=.15,clock='QEMU default',cases={})
for k in order:
    d=native/k;d.mkdir();elf=d/'kernel.elf';shutil.copyfile(root/'mask-prop-builds'/k/'kernel.elf',elf)
    assert sha(elf)==images[k]['sha256']
    argv=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-m','128M','-accel','tcg','-nodefaults','-display','none','-monitor','none','-serial','file:'+str(d/'uart'),'-d','int','-D',str(d/'exceptions'),'-kernel',str(elf)]
    freeze['cases'][k]=dict(argv=argv,elf_sha=sha(elf),build=images[k])
(dest/'freeze.json').write_text(json.dumps(freeze,indent=2))
for k in order:
    d=native/k; start=time.monotonic(); terminal=None
    with (d/'stdout').open('wb') as out,(d/'stderr').open('wb') as err:
        proc=subprocess.Popen(freeze['cases'][k]['argv'],stdin=subprocess.DEVNULL,stdout=out,stderr=err)
        while proc.poll() is None and time.monotonic()-start<25:
            if (d/'uart').exists() and any(line.startswith(b'PROP END ') and line.endswith(b'\n') for line in (d/'uart').read_bytes().splitlines(True)):
                terminal='complete footer';time.sleep(.15);break
            time.sleep(.025)
        if proc.poll() is None:
            terminal=terminal or 'timeout';proc.terminate();proc.wait(timeout=5)
        else: terminal=terminal or 'early exit'
    (d/'outcome.json').write_text(json.dumps(dict(reason=terminal,elapsed_s=time.monotonic()-start,pid=proc.pid,exit=proc.returncode)))
    shutil.copytree(d,dest/k)
    print(k,terminal,proc.returncode,flush=True)