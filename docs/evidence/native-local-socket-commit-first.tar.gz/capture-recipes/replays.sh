#!/usr/bin/env bash
set -euo pipefail
prep=$(cd "$(dirname "$0")" && pwd); source "$prep/env.sh"
bash "$prep/types.sh"
aarch64-linux-gnu-objdump -d "$raw/broker.elf" > "$raw/broker.dis"
cases=()
for pol in fifo rr; do
    for mode in expired ready backlog fullexpire fullready death stream dgram seq; do
        cases+=("$mode-$pol")
    done
done
python3 "$prep/trace.py" "$src" "$raw" "${cases[@]}" | tee "$raw/trace-status.txt"
