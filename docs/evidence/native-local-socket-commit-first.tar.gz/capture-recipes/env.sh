#!/usr/bin/env bash
set -euo pipefail
source "$HOME/.cargo/env"
export CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
rev=9912ae3db95aec3f1a67f690d01c7379339168d1
raw=${RAW:-$HOME/v381-first-9912ae3}
src=${SRC:-$HOME/v381-source-9912ae3}
prep=$(cd "$(dirname "$0")" && pwd)
export CARGO_TARGET_DIR="$raw/app-target"
build() {
    local label=$1; shift
    printf '%q ' "$@" >> "$raw/commands.sh"; echo >> "$raw/commands.sh"
    local rc=0
    "$@" > "$raw/$label.log" 2>&1 || rc=$?
    echo "$label $rc" | tee -a "$raw/status.txt"
    if (( rc != 0 )); then tail -10 "$raw/$label.log"; fi
    return "$rc"
}
guest() {
    local mode=$1 pol=$2 owner=$3 peer=$4 arg0=$5 arg1=$6 exp=$7 probe=$8; shift 8
    local rr=()
    if [[ $pol == rr ]]; then rr=(--quantum-ticks 625000); fi
    local name=$mode-$pol
    build pkg-$name python3 tools/build_native_el0.py --policy "$pol" "${rr[@]}" --out "$raw/pkg-$name" --elf "$raw/$owner.elf" --arg "$arg0" --priority 7 --peer-elf "$raw/$peer.elf" --peer-arg "$arg1" --peer-priority 4 --peer-elf "$raw/broker.elf" --peer2-arg 3 --peer-priority 1 --socket-service 2 --ipc-route 0:2 --ipc-route 1:2 "$@" || return
    build cap-$name python3 tools/native_el0_capture.py "$raw/cap-$name" "$raw/pkg-$name/kernel.elf" "$raw/$owner.elf" "$probe" "$rev" --plain --manifest "$raw/pkg-$name/manifest.json" --expect-exit "$exp" --timeout 15
}

