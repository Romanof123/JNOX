#!/usr/bin/env bash
set -euo pipefail
prep=$(cd "$(dirname "$0")" && pwd); source "$prep/env.sh"; cd "$src"
mkdir -p "$raw/full-peer/src"
cp "$prep/full.c" "$raw/full.c"; cp "$prep/full.rs" "$raw/full-peer/src/main.rs"
sed -e "s#../../../../sdk/native-aarch64/rust#$src/sdk/native-aarch64/rust#" -e 's/local-extra-peer/full-peer/' examples/native-local-sockets/extra/peer/Cargo.toml > "$raw/full-peer/Cargo.toml"
build full-cc sh sdk/native-aarch64/build.sh --local-socket "$raw/full.c" "$raw/full.elf"
build full-rust sh sdk/native-aarch64/build-rust.sh --local-socket "$raw/full-peer/Cargo.toml" "$raw/full-peer.elf"
build death-cc sh sdk/native-aarch64/build.sh --local-socket "$prep/death.c" "$raw/death.elf"
for pol in fifo rr; do
    for mode in fullexpire fullready; do
        guest "$mode" "$pol" full full-peer "$mode" "$mode" 201 "$raw/full.c" --ipc-route 0:1 --ipc-route 1:0 || true
    done
    guest death "$pol" death death 0d 1d 62 "$prep/death.c" || true
done
