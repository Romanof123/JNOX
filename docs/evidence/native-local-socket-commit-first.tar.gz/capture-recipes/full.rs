#![no_std]
#![no_main]
use core::{panic::PanicInfo, ptr::write_volatile, time::Duration};
use jnox_native::{exit,ipc,local_socket as s,monotonic_time,sleep_until};
#[no_mangle]
static mut full_peer_result: [i64;16] = [0;16];
fn mark(i: usize,v: i64) { unsafe {write_volatile(&raw mut full_peer_result[i],v)} }
fn now() -> Result<i64,i32> { Ok(monotonic_time().map_err(|_| -1)?.as_nanos() as i64) }
fn control(expected: Option<u64>, ack: u64) -> Result<u64,i32> {
    let (token,word) = ipc::receive().map_err(|e| e as i32)?;
    if expected.is_some() && expected != Some(word) { return Err(-2); }
    ipc::reply(token,ack).map_err(|e| e as i32)?; Ok(word)
}
fn run(expire: bool) -> Result<(),i32> {
    s::set_broker(2)?;
    let fd=s::socket(s::SOCK_DGRAM,false)?;
    s::bind(fd,b"/sink")?;
    control(Some(0xb0),0xb1)?;
    let deadline=control(None,0xb2)?;
    mark(0,deadline as i64);
    let target=if expire {deadline+65000000} else {deadline-150000000};
    sleep_until(Duration::from_nanos(target)).map_err(|_| -3)?;
    mark(1,now()?);
    let mut scratch=[0u8;1];
    let n=if expire {4} else {5};
    for (i,expected) in [17u8,34,51,68,238].iter().take(n).enumerate() {
        if s::recv(fd,&mut scratch,s::MSG_DONTWAIT)?!=1 {return Err(-4);}
        mark(3+i,scratch[0] as i64);
        if scratch[0]!=*expected {return Err(-5);}
    }
    let empty=s::recv(fd,&mut scratch,s::MSG_DONTWAIT);
    mark(8,match empty {Err(errno)=>errno as i64,Ok(n)=>n as i64});
    if empty!=Err(-11) {mark(10,scratch[0] as i64);return Err(-6);}
    mark(2,now()?);
    if ipc::call(0,0xb3,u64::MAX).map_err(|e|e as i32)?!=0xb4 {return Err(-7);}
    control(Some(0xb5),0xb6)?;
    if s::recv(fd,&mut scratch,s::MSG_DONTWAIT)?!=1 {return Err(-8);}
    mark(9,scratch[0] as i64);
    if scratch[0]!=123 {return Err(-9);}
    s::close(fd)
}
#[panic_handler]
fn panic(_: &PanicInfo<'_>)->! {exit(219)}
#[no_mangle]
pub unsafe extern "C" fn main(argc:i32,argv:*const *const u8)->i32 {
    if argc!=2 || argv.is_null() {return 217;}
    match run(*(*argv.add(1)).add(4)==b'e') {Ok(())=>202,Err(e)=>{mark(15,e as i64);218}}
}
