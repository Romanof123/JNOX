#!/usr/bin/env bash
set -euo pipefail
prep=$(cd "$(dirname "$0")" && pwd); source "$prep/env.sh"; cd "$src"
python3 - "$src" "$raw" <<'PY'
from pathlib import Path
import sys
src,raw=map(Path,sys.argv[1:])
s=(src/'services/socket/src/main.rs').read_text()
part=s[s.index('const CLIENTS:'):s.index('fn execute(')]
part=part.replace('static mut BANKS:', '#[no_mangle]\npub static mut BANKS:').replace('static mut CLIENT_STATE:', '#[no_mangle]\npub static mut CLIENT_STATE:')
(raw/'broker-types.rs').write_text('#![no_std]\n#[path="'+str(src/'services/socket/src/local.rs')+'"] mod local;\nuse local::Local;\n'+part)
(raw/'endpoint-types.rs').write_text('\n'.join((src/'kernel/src/sync_ipc.rs').read_text().splitlines()[3:])+'\n')
(raw/'layout-kernel.rs').write_text('#![no_std]\ninclude!("endpoint-types.rs");\n#[no_mangle]\npub static LAYOUT: SyncIpc<3> = SyncIpc::with_broker([4,4,0],2);\n')
PY
build types-rust rustc --edition 2021 -C opt-level=3 -C debuginfo=2 --target aarch64-unknown-none-softfloat --crate-type lib --crate-name jnox_local_socket --emit=obj "$raw/broker-types.rs" -o "$raw/broker-types.o"
build types-kernel rustc --edition 2021 -C opt-level=3 -C debuginfo=2 --target aarch64-unknown-none-softfloat --crate-type lib --crate-name wire_layout --emit=obj "$raw/layout-kernel.rs" -o "$raw/layout-kernel.o"
python3 "$prep/layout.py" "$raw" > "$raw/layout.json"
