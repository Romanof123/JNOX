#!/usr/bin/env bash
set -euo pipefail
prep=$(cd "$(dirname "$0")" && pwd); source "$prep/env.sh"
mkdir "$src" "$raw"
git -C "$src" init -q
echo "${OBJECTS:-/mnt/d/codex/j-nox/.git/objects}" > "$src/.git/objects/info/alternates"
cd "$src"
git sparse-checkout init --cone
git sparse-checkout set arch boards examples kernel sdk services tools trace verification
git -c advice.detachedHead=false checkout -q --detach "$rev"
git rev-parse HEAD 'HEAD^{tree}' > "$raw/revision.txt"
test "$(git rev-parse 'HEAD^{tree}')" = fe8da16304f4c97b35533c35f897cab6cd048836
test -z "$(git status --porcelain --untracked-files=no)"
(date -u; uname -a; rustc -Vv; cargo -V; qemu-system-aarch64 --version; clang --version; python3 -V) > "$raw/platform.txt"
build cc sh sdk/native-aarch64/build.sh --local-socket examples/native-local-sockets/extra/owner.c "$raw/owner.elf"
build rust sh sdk/native-aarch64/build-rust.sh --local-socket examples/native-local-sockets/extra/peer/Cargo.toml "$raw/peer.elf"
build broker sh sdk/native-aarch64/build-rust.sh services/socket/Cargo.toml "$raw/broker.elf"
build regcc sh sdk/native-aarch64/build.sh --local-socket examples/native-local-sockets/server.c "$raw/server.elf"
build regrust sh sdk/native-aarch64/build-rust.sh --local-socket examples/native-local-sockets/client/Cargo.toml "$raw/client.elf"
for pol in fifo rr; do
    for mode in expired ready backlog; do
        guest "$mode" "$pol" owner peer "$mode" "$mode" 81 examples/native-local-sockets/extra/owner.c --ipc-route 0:1 --ipc-route 1:0 || true
    done
    for mode in stream dgram seq; do
        guest "$mode" "$pol" server client "$mode" "$mode" 73 examples/native-local-sockets/server.c || true
    done
done

