#include <errno.h>
#include <jnox/ipc.h>
#include <stdint.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <time.h>
#include <unistd.h>

volatile int64_t full_owner_result[16];
static const struct sockaddr_un sink = { AF_UNIX, "/sink" };
static uint64_t now(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) return 0;
    return (uint64_t)t.tv_sec * 1000000000ULL + t.tv_nsec;
}
static int handshake(uint64_t word, uint64_t ack) {
    jnox_ipc_response r = jnox_ipc_call(1, word, UINT64_MAX);
    return r.status == 0 && r.word == ack;
}
static int stage(uint64_t word) {
    jnox_ipc_response r = jnox_ipc_call(2, word, UINT64_MAX);
    return r.status == 0 && r.word == 0;
}
int main(int argc, char **argv) {
    if (argc != 2 || jnox_socket_broker(2)) return 203;
    const int expire = argv[1][4] == 'e';
    int fd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (fd != 64 || !handshake(0xb0, 0xb1)) return 204;
    for (unsigned i = 0; i < 4; ++i) {
        unsigned char marker = 17 * (i+1);
        full_owner_result[4+i] = sendto(fd,&marker,1,0,(const struct sockaddr *)&sink,sizeof sink);
        if (full_owner_result[4+i] != 1) return 205;
    }
    // Normal raw SEND for our own fd 0, with 5 pathname bytes and 1 payload byte.
    if (!stage(0x1106000005010000ULL) || !stage(0x1200ee6b6e69732fULL)) return 206;
    uint64_t t = now(), deadline = t + 300000000;
    full_owner_result[0] = deadline;
    if (!t || !handshake(deadline,0xb2)) return 207;
    jnox_ipc_response r = jnox_ipc_call(2,0x1300000000000000ULL,deadline);
    full_owner_result[1] = r.status;
    full_owner_result[2] = r.status ? 0 : (int64_t)r.word;
    full_owner_result[3] = now();
    if (expire ? (r.status != -110 || full_owner_result[3] < (int64_t)deadline)
               : (r.status || r.word != 1 || full_owner_result[3] >= (int64_t)deadline)) return 208;
    // Wait directly for the receiver to finish draining before any new broker call.
    jnox_ipc_request drained = jnox_ipc_receive();
    if (drained.status || drained.word != 0xb3 || jnox_ipc_reply(drained.token,0xb4)) return 209;
    unsigned char fresh = 0x7b;
    full_owner_result[8] = sendto(fd,&fresh,1,0,(const struct sockaddr *)&sink,sizeof sink);
    return full_owner_result[8] == 1 && handshake(0xb5,0xb6) && !close(fd) ? 201 : 210;
}
