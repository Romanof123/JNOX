"""Register-filtered replay of the same unmodified package. Fixed PCs are pinned to broker.dis."""
import argparse, hashlib, json, sys
from pathlib import Path
src,raw=map(Path,sys.argv[1:3])
sys.path.insert(0,str(src/'tools'))
import native_el0_capture as capture

points=[0x40222c,0x4015f0,0x401684,0x402050,0x402054,0x40206c,0x402288,
        0x400630,0x40069c,0x4008c4,0x400940,0x401334,0x401440,
        0x400d74,0x400db8,0x4005c8,0x400620]
filt=','.join(f'0x{x:x}+4' for x in points)
def command(qemu,directory,plain):
    return capture.command(qemu,directory,True)+['-singlestep','-d','cpu,nochain',
        '-dfilter',filt,'-D',str(directory/'registers.log')]
for case in sys.argv[3:]:
    pkg=raw/('pkg-'+case); out=raw/('trace-'+case); cap=raw/('cap-'+case)
    mode=case.rsplit('-',1)[0]
    expect=81 if mode in ('backlog','expired','ready') else 201 if mode.startswith('full') else 62 if mode=='death' else 73
    man=json.loads((pkg/'manifest.json').read_text())
    assert man['commit']=='9912ae3db95aec3f1a67f690d01c7379339168d1'
    assert (pkg/'native_peer2.elf').read_bytes()==(raw/'broker.elf').read_bytes()
    run=argparse.Namespace(root=out,kernel=pkg/'kernel.elf',user=pkg/'user.elf',
        probe=cap/'probe.c',revision=man['commit'],manifest=pkg/'manifest.json',
        arg=[],peer_arg=[],peer2_arg=[],plain=True,expect_exit=expect,timeout=16,
        qemu='qemu-system-aarch64',nm='aarch64-linux-gnu-nm')
    rc=capture.capture(run,command_factory=command)
    print('trace-'+case,rc,flush=True)
