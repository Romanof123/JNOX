from pathlib import Path
import hashlib, json, re, sys
def digest(p):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()
root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
results = []
for cap in sorted([*root.glob("cap-*/session.json"), *root.glob("trace-*/session.json")]):
    d = cap.parent
    session = json.loads(cap.read_text())
    for name, want in session["hashes"].items():
        assert Path(name).name == name and digest(d / name) == want, (d, name)
    uid = (d / "uart.bin").read_bytes()
    exits = [(int(p),int(n)) for p,n in re.findall(rb"^NATIVE EL0 EXIT PID (\d+) (-?\d+)\r?$", uid, re.MULTILINE)]
    assert len(exits) == 3 and len(dict(exits)) == 3 and dict(exits)[2] == 0, d
    drops = re.findall(rb"^NATIVE FIXED DROPPED (\d+)\r?$", uid, re.MULTILINE)
    assert len(drops) == 1, d
    results.append(dict(position=d.name, exits=sorted(exits), dropped=int(drops[0]),uart=digest(d / "uart.bin")))
assert len(results) == 36
for entry in results[:18]:
    assert entry["position"].startswith("cap-")
    twin = next(e for e in results if e["position"] == entry["position"].replace("cap-", "trace-", 1))
    assert entry["exits"] == twin["exits"]
print(json.dumps(results, indent=2))
