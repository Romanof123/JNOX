#include <errno.h>
#include <jnox/ipc.h>
#include <sys/un.h>
#include <time.h>

volatile long observed[64];
volatile unsigned observed_count;
static const struct sockaddr_un service = {AF_UNIX,"/012345678901234567890123456789"};
static const struct sockaddr_un gate = {AF_UNIX,"/gate"};
static const struct sockaddr_un origin = {AF_UNIX,"/origin"};

static int check(long actual, long expected) {
    observed[observed_count++] = actual;
    return actual == expected;
}
#define EXPECT(actual, expected) do { if (!check((actual), (expected))) return 80; } while (0)
static long outcome(long r) { return r < 0 ? -errno : r; }
static long openfd(int kind) { return outcome(socket(AF_UNIX, kind, 0)); }
static long named(int fd, const struct sockaddr_un *n) {
    return outcome(bind(fd, (const struct sockaddr *)n, sizeof(*n)));
}
static long linkto(int fd, const struct sockaddr_un *n) {
    return outcome(connect(fd, (const struct sockaddr *)n, sizeof(*n)));
}
static long put(int fd, const struct sockaddr_un *n, unsigned char byte) {
    return outcome(sendto(fd, &byte, 1, 0, (const struct sockaddr *)n, sizeof(*n)));
}
static long take(int fd, int flags) {
    unsigned char byte = 0;
    long len = outcome(recv(fd, &byte, 1, flags));
    return len == 1 ? byte : len;
}
static long rpc(uint64_t word) {
    jnox_ipc_response r = jnox_ipc_call(2, word, UINT64_MAX);
    return r.status ? r.status : (long)r.word;
}
#define TAG(t) ((uint64_t)(t) << 56)
static uint64_t begin(unsigned op, unsigned fd, unsigned arg, unsigned plen) {
    return TAG(0x11) | ((uint64_t)op<<48) | ((uint64_t)fd<<40) |
           ((uint64_t)arg<<32) | ((uint64_t)plen<<24);
}
static int death(int owner) {
    if (owner == 0) {
        EXPECT(openfd(SOCK_SEQPACKET),64);
        EXPECT(named(64,&service),0);
        EXPECT(outcome(listen(64,2)),0);
        EXPECT(outcome(accept(64,0,0)),65);
        for (unsigned char b=1; b<=4; ++b) EXPECT(outcome(send(65,&b,1,0)),1);
        EXPECT(outcome(send(65,"x",1,MSG_DONTWAIT)),-11);
        EXPECT(outcome(send(65,"y",1,0)),1);   /* resumes when first record drains */
        EXPECT(outcome(send(65,"z",1,0)),-32); /* resumes on owner exit */
        EXPECT(take(65,0),0);
        EXPECT(openfd(SOCK_DGRAM),66);
        EXPECT(named(66,&origin),0);            /* exit released the bound pathname */
    } else {
        EXPECT(openfd(SOCK_SEQPACKET),64);
        EXPECT(named(64,&origin),0);
        EXPECT(linkto(64,&service),0);
        EXPECT(take(64,0),1);
        EXPECT(openfd(SOCK_DGRAM),65);
        EXPECT(rpc(begin(2,1,0,7)),0);
        EXPECT(rpc(TAG(0x12) | 0x666564636261ULL),0);
        EXPECT(rpc(begin(2,1,0,7)),-16);
        /* Exit with four records unread, two live descriptors and a partial bind. */
    }
    return 62+owner;
}
int main(int argc, char **argv) { if (argc!=2 || jnox_socket_broker(2)<0) return 79; return death(argv[1][0]-'0'); }