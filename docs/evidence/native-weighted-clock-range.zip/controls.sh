set -euo pipefail
D=/mnt/d/codex/jnox297-clock-evidence
W=$HOME/jnox297-clock-bbf9
cd "$W/src"
test "$(git rev-parse HEAD)" = bbf9f907d93962dd87f6d529f788482fbf90320b
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
exec 9>"$D/lane.lock"; flock -n 9
mkdir -p "$D/controls"
cd "$D"
{ echo '#define COOPERATIVE'; cat clock.c; } >clock_coop.c
cd "$W/src"
for app in clock clock_coop peer; do sh sdk/native-aarch64/build.sh "$D/$app.c" "$D/controls/$app.elf"; done
for n in weighted fixed cooperative; do
 args=(); app=clock
 case $n in weighted) args=(--policy weighted --quantum-ticks 625000 --weight 1 --peer-weight 2);; fixed) args=(--policy rr --quantum-ticks 625000 --priority 3 --peer-priority 3);; cooperative) app=clock_coop;; esac
 d="$D/controls/$n"; mkdir -p "$d"
 python3 tools/build_native_el0.py --out "$W/control-$n" --elf "$D/controls/$app.elf" --peer-elf "$D/controls/peer.elf" "${args[@]}" >"$d/package.log" 2>&1
 cp "$W/control-$n/"{kernel.elf,manifest.json,build.log} "$d/"
 python3 "$D/control_guest.py" "$d"
done
