set -euo pipefail
B=/mnt/d/codex/jnox297-independent-evidence
D=/mnt/d/codex/jnox297-clock-evidence
W=$HOME/jnox297-clock-bbf9
SRC=$W/src
mkdir -p "$SRC"
test -z "$(git -C "$SRC" status --porcelain)"
cd "$SRC"
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
exec 9>"$D/lane.lock";flock -n 9
mkdir -p "$W" "$D/runs"
set -x
test "$(sha256sum "$B/extended-inputs/SHA256SUMS" | cut -d' ' -f1)" = 9892ad7392bd21ce87c71e96fbb91db9405a820ff9c476dfd9029ace92e863a7

for a in "$D/elf/"*.elf;do aarch64-linux-gnu-nm -nS "$a" >"$a.sym";aarch64-linux-gnu-objdump -d "$a" >"$a.dis";done
for spec in 'share checksum:1 histogram:2' 'triple checksum:1 histogram:2 continuous_reporter:3' 'wake checksum:1 reporter:2'; do
 read -ra a <<< "$spec"; name=${a[0]}; d="$D/elf/$name"; mkdir -p "$d"; args=(--policy weighted --quantum-ticks 625000)
 for ((j=1;j<${#a[@]};j++)); do s=${a[j]}; pre='--'; if ((j>1)); then pre=--peer-; fi; args+=("${pre}elf" "$D/elf/${s%:*}.elf" "${pre}weight" "${s#*:}"); done
 python3 tools/build_native_el0.py --out "$W/good-$name" "${args[@]}" >"$d/package.log" 2>&1 || { cp "$W/good-$name/build.log" "$d/" || true; exit 1; }
 cp "$W/good-$name/"{kernel.elf,manifest.json,build.log} "$d/"
done
sha256sum "$D/verified.tar" "$D/elf/"*.elf "$D/elf/"*/kernel.elf >"$D/prelaunch.sha256"