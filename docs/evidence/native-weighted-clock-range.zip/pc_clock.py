import pathlib,json,re
D=pathlib.Path(__file__).resolve().parent
out={}
for root in [D]:
 for r in (root/'runs').iterdir():
  names=json.loads((r/'command.json').read_text())['apps']
  text=(r/'uart.log').read_text()
  rows=[list(map(int,l.split()[3:])) for l in text.splitlines() if l.startswith('NATIVE WEIGHTED EVENT') and len(l.split())==42]
  h=60 if r.name.startswith('triple-') else 36
  hit={};clock=[]
  for i,name in enumerate(names):
   if name=='reporter':
    raw=json.loads((r/'ram.json').read_text())[i]
    import struct
    ns=lambda k:struct.unpack('<3Q',bytes.fromhex(raw[k]))
    dl,obs=ns('report_deadline_ns'),ns('report_observed_ns')
    clk=[list(map(int,l.split()[3:])) for l in text.splitlines() if l.startswith('NATIVE WEIGHTED CLOCK')]
    sleeps=[b for b in rows if b[0]==2 and b[2]==i]
    epoch=clk[0][1]-(dl[0]-40000000)//16
    clock=[len(sleeps)==3 and all(epoch+(d+15)//16==b[7] and o==(c[1]-epoch)*16 and d==(pre[1]-epoch)*16+40000000 and c[3]==pre[3]==0 for d,b,o,c,pre in zip(dl,sleeps,obs,clk[1::2],clk[::2])),len(sleeps),list(dl),list(obs),epoch]
   sym={'checksum':'checksum_stream','histogram':'histogram_stream','continuous_reporter':'measure_energy'}.get(name)
   if not sym:continue
   line=next(l for l in (root/'elf'/(name+'.elf.sym')).read_text().splitlines() if l.endswith(' '+sym))
   a,s=map(lambda x:int(x,16),line.split()[:2])
   hit[name]=sum(a<=b[17]<a+s for b in rows[1:h+1] if b[0]==4 and b[2]==i)
  out[str(r.relative_to(D))]=dict(interrupts_in_productive_symbols=hit,private_clock_check=clock)
(D/'pc-and-clock.json').write_text(json.dumps(out,indent=2))
