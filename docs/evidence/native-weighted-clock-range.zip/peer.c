#include <sched.h>
volatile unsigned private_result = 23;
int main(void)
{
    if (sched_yield() || private_result != 23) return 111;
    return (int)(private_result += 6);
}
