#define COOPERATIVE
#include <errno.h>
#include <sched.h>
#include <time.h>

volatile unsigned private_result = 31;
int main(void)
{
    struct timespec far = {150000000000L, 0};
#ifdef COOPERATIVE
    far.tv_sec = 400000000000L;
#endif
    int result = clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &far, 0);
    if (result != EOVERFLOW) return 101;
    private_result += (unsigned)result;
    struct timespec deadline;
    if (clock_gettime(CLOCK_MONOTONIC, &deadline)) return 102;
    if (clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &deadline, 0)) return 103;
    deadline.tv_nsec += 20000000;
    if (deadline.tv_nsec >= 1000000000) { deadline.tv_nsec -= 1000000000; ++deadline.tv_sec; }
    if (clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &deadline, 0)) return 104;
    struct timespec observed;
    if (clock_gettime(CLOCK_MONOTONIC, &observed)) return 105;
    if (observed.tv_sec < deadline.tv_sec || (observed.tv_sec == deadline.tv_sec && observed.tv_nsec < deadline.tv_nsec)) return 107;
    if (sched_yield() || private_result != 106) return 108;
    return (int)(private_result += 3);
}
