import pathlib,sys,json,re,struct,subprocess as sp,time,math,zlib,os,fcntl
D=pathlib.Path(__file__).resolve().parent
bins=[2097152*sum(i.bit_count()==k for i in range(256)) for k in range(9)]
crc=zlib.crc32(bytes(range(256))*524288)
energy=4194304*sum(i*i for i in range(-128,128))
expected={'checksum':(134217728,crc,crc%251),'histogram':(536870912,bins,sum((k+1)**2*v for k,v in enumerate(bins))%251),'continuous_reporter':(1073741824,energy,energy%251),'reporter':(3,7,7),'boundary':(3,17,17),'boundary_peer':(2,19,19)}
cases={'share':['checksum','histogram'],'wake':['checksum','reporter'],'swap':['checksum','histogram'],'triple':['checksum','histogram','continuous_reporter'],'mixed':['checksum','histogram','reporter'],'solo':['boundary'],'boundary':['boundary','boundary_peer']}
order=['share-default','triple-default','wake-default']
def argv(kernel,r,mode):
 return ['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(r/'uart.log')]+(['-icount','shift=3,align=off,sleep=off'] if mode=='icount' else [])+['-kernel',str(kernel)]
def launch(label):
 case,mode=label.split('-'); r=D/'runs'/label; r.mkdir()
 apps=cases[case]; kernel=D/'elf'/case/'kernel.elf'
 syms=sp.check_output(['aarch64-linux-gnu-nm','-S',kernel],text=True)
 base,size=map(lambda x:int(x,16),next(l for l in syms.splitlines() if '6SPACES' in l).split()[:2])
 stride=0x415000; assert size==stride*len(apps)
 fields=[]
 for slot,app in enumerate(apps):
  items={}
  for l in (D/'elf'/(app+'.elf.sym')).read_text().splitlines():
   s=l.split()
   if len(s)==4 and s[-1] in ('private_progress','private_result','report_deadline_ns','report_observed_ns','boundary_deadline_ns'):
    items[s[-1]]=(base+stride*slot+5*4096+int(s[0],16)-0x400000,int(s[1],16))
  fields.append(items)
 args=argv(kernel,r,mode)
 (r/'command.json').write_text(json.dumps(dict(argv=args,apps=apps,fields=fields)))
 with (r/'qemu.stderr').open('w') as err,(r/'progress.jsonl').open('w') as obs,sp.Popen(args,stdin=sp.PIPE,stdout=sp.PIPE,text=True,stderr=err) as p:
  try:
   def read():
    while True:
     data=json.loads(p.stdout.readline())
     if 'event' not in data:return data
   def cmd(name,**kwargs):
    p.stdin.write(json.dumps({'execute':name,'arguments':kwargs})+'\n');p.stdin.flush()
    return read()['return']
   def mem(address,width):
    out=cmd('human-monitor-command',**{'command-line':f'xp /{width}bx {address:#x}'})
    return bytes(int(b,16) for l in out.splitlines() for b in re.findall(r'0x([0-9a-fA-F]{2})\b',l.split(':',1)[1]))
   read();cmd('qmp_capabilities'); start=time.monotonic()
   while True:
    ps=[int.from_bytes(mem(*s['private_progress']),'little') for s in fields]
    print(json.dumps([time.monotonic_ns(),ps]),file=obs,flush=True)
    uart=(r/'uart.log').read_text(errors='replace')
    if uart.count('NATIVE EL0 EXIT')>=len(apps) or time.monotonic()-start>90:break
    time.sleep(.012)
   raw=[{k:mem(*v).hex() for k,v in s.items()} for s in fields]; (r/'ram.json').write_text(json.dumps(raw))
   cmd('quit');p.wait(4)
  finally:
   if p.poll() is None:p.kill();p.wait()
   (r/'qemu.status').write_text(str(p.returncode))
if __name__=='__main__':
 lock=(D/'lane.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 (D/'firsts.json').write_text(json.dumps(dict(expected=expected,order=order,Q=625000,frequency=62500000,journal=4096,clock_rows=128,argv=[argv(D/'elf'/n.split('-')[0]/'kernel.elf',D/'runs'/n,n.split('-')[1]) for n in order]),indent=2))
 ref=json.loads((D/'extended-inputs'/'expected.json').read_text())['expected'];assert all(list(expected[k])==v for k,v in ref.items())
 for n in order:
  assert not sp.run(['pgrep','-f','^qemu-system-aarch64'],capture_output=True).stdout
  try:launch(n)
  except Exception:
   import traceback
   (D/'runs'/n/'failure').write_text(traceback.format_exc())
