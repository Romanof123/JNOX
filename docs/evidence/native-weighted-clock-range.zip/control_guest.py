import pathlib,subprocess,sys,time,json
d=pathlib.Path(sys.argv[1])
args=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','file:'+str(d/'uart.log'),'-kernel',str(d/'kernel.elf')]
(d/'command.json').write_text(json.dumps(args))
with (d/'stderr.log').open('w') as err, subprocess.Popen(args,stderr=err) as proc:
    try:
        for _ in range(500):
            if (d/'uart.log').exists() and (d/'uart.log').read_text().count('NATIVE EL0 EXIT PID')==2: break
            time.sleep(.02)
        else: raise RuntimeError('expected both terminal statuses')
    finally:
        proc.terminate()
        proc.wait(4)
log=(d/'uart.log').read_text()
assert 'NATIVE EL0 EXIT PID 0 109' in log and 'NATIVE EL0 EXIT PID 1 29' in log,log
