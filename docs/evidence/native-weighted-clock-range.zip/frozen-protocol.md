# Independent first-observation protocol for #296 / #297

Design a49b70998cca64b1f79f71f468868fd60ea04316, docs/native-weighted-applications.en-ko.md. Preparation only. The public implementation and explicit coordinator LANE OPEN after #294/#295 are prerequisites for any build, technical review or test. Verify the candidate public SHA and verifier independence from authorship before starting. Acquire the coordinator's single-guest lock and verify exclusive native/WSL guest ownership before each launch. Stop on conflicting ownership. Release only after the owned guest exits and evidence is closed.

## Freeze before any candidate guest

Write an immutable, timestamped receipt with candidate and base SHAs, clean tree, tool identities, ELF sources, inputs, iterations, compiler/linker invocations, per-slot ELF and image hashes, private symbol addresses, full disassemblies, manifest and slot order. Record exact QEMU argv, machine, CPU0, frequency, memory, journal bounds, collection method, timeouts, expected counts and cold-boot sequence. Choose loops long enough for the defined windows in advance. Use separate C checksum, Rust histogram, and reporter ELFs. For each compute an independent host reference from algorithm, exact private input and integer width before execution. Freeze full checksum, every histogram bin, reporter's entire deterministic work result, all progress counts and individual statuses, including controls. For clock-dependent values freeze predicates and sample identity. Keep expected values, reference source and digest separate from implementation-supplied goldens. No unverifiable placeholder qualifies for execution.

## Cold boots in order

1. Continuous checksum weight 1, histogram weight 2, default clock.
2. Identical share package, shift=3 icount.
3. Computing peer weight 1, reporter weight 2, three ordinary SDK absolute 40 ms sleeps, default clock.
4. Identical wake package, shift=3 icount.
5. Swapped checksum/histogram weight assignments, default clock.
6. Distinct checksum, histogram, reporter weighted 1:2:3, default, with all three continuously ready for the first 60 contended grants.
7. Single returning/yielding ELF.
8. Separate sleep/exit control for all-sleep idle, co-due admissions and final solo yield.
9. Ordinary single startup, cooperative pair, and #294 FIFO and RR controls using frozen recipes and their output oracles.

Each position gets its own append-only directory including initial launch, failures, timeout, truncation or setup errors, raw stdout/stderr, argv, journal, RAM and symbol extracts. No warm-up guest. A later diagnostic or corrected image gets a separate identity. Do not pool clocks or substitute later windows.

## Replay and scoring

Map private RAM products/progress and exception/return PCs to each packaged ELF and address space. Check full products, counts and statuses through final exits. Relate advancing private progress samples to each required window. Retain all boundary samples, ready sets, causes, deadline programmed/delivered, previous and next frames, EL0 PC, sequence, start/stop, cumulative service, floor and placement. Independently reconstruct exact rational runtime from physical intervals and weights. Charge the outstanding lease once, exclude idle/dispatch gaps, close coincident intervals at zero, preserve lease on nonblocking syscalls, remove terminal/blocked slots, admit all due by deadline then slot, round lagging sleepers upward on their own grid, retain ahead debt, then choose minimum (runtime,slot). Check physical compare against competing grant end/earliest wake or sole/idle wake-only rule. Replay survivors and final exit tails, and check journal overrun reporting and ordinary completion after observation exhaustion.

Set Q=frequency/100 with Q divisible by four, H=5Q/4 and G=Q/4. Record selection correctness independently of timing qualification, wake latency and productive outputs. Lost rows, early exit or inadequate overlap leave the original timing position unqualified. Retain exact first offending row, measured value and bound.

* Share pair and swap: both ready for first 36 full timer closures. Every charged interval in (0,H], full timer intervals >=Q, dispatch gaps <=G. At each prefix -H <= 2A-B <= 2H (A and B denote weight 1 and 2 services). At 36, T=A+B >=36Q and abs(2A-B)*36Q <=2H*T. Map interrupt PCs to productive loops.
* Wake: each genuine sleep blocks the reporter until admission. Show >=3Q peer service plus positive private work progress during each blocked interval and zero incremental reporter charge. For each target D, IRQ I, admission W, actual EL0 return R and subsequent user clock sample bracket [L,U], require D<=I<=W<=R<=L<=U, I-D<=G, W-I<=G, R-W<=H+2G, U-R<=G, U-D<=H+5G. Capture resumed instruction/frame plus evidence it executed in user mode; a scheduler selection alone cannot establish R. Separate uninterrupted solo-to-wake interval from contended/full grants.
* Three slots: first 60 contiguous contended grants from zero. At each prefix, exact max(S_i/w_i)-min(S_i/w_i) <= H/min(w). Verify minimum selection, H/G interval and gap bounds, and progress by all three. Score post-exit selection against surviving set.
* Idle/control: capture idle start/end, earliest compare, wake order, late/coincident IRQ and final solo yield. If guest equality is absent, mark unobserved and test deterministic equality on host.

## Host and configuration controls after lane opens

Check weights 1 and u32::MAX, exact nonintegral-floor placement, multiple partial charges versus their sum, equal fractions with differing denominators, stale and duplicate leases, zero-time retirement, near-u64::MAX carry, service, sequence and start+Q overflow. Compare exact results or checked failure with unchanged state. Validate CLI and kernel build boundary independently: singleton duplication, missing/extra/zero/out-of-range weight, incompatible priority/quantum, quantum bounds, slot gaps and fourth ELF. Verify supported arbitrary weights and primary C or ELF path, peer order, manifest hashes, startup, cooperative, FIFO/RR compatibility.

Publish first-position score table by clock with selection, service, wake, private products and coverage individually marked. Preserve historical #177 four original misses, #183 and #178 3/4, #178 wake/default lease 14 excess 109296 ticks, and open #184 default-clock share. Board/integrated-load acceptance remains with #21.
