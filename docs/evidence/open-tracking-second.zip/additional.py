import pathlib,json,subprocess,sys
p=pathlib.Path(__file__).parent
out=[]
for i,(body,expected) in enumerate(json.loads((p/'additional-freeze.json').read_text(encoding='utf-8-sig')).items()):
 rows=json.loads((p/'prior/valid.json').read_bytes());rows[1]['body']=body
 f=p/'private-inputs'/f'extra-{i}.json';f.write_text(json.dumps(rows))
 r=subprocess.run([sys.executable,str(p.parent/'qa193-b679/tools/open_tracking.py'),str(f)],capture_output=True,text=True)
 out.append([body,expected,r.returncode,r.stdout+r.stderr])
(p/'additional-results.json').write_text(json.dumps(out,indent=2));print([(a,c) for a,b,c,d in out])
