import json,subprocess,sys,zipfile,urllib.request,datetime,pathlib
p=pathlib.Path(__file__).parent
repo=p.parent/'qa193-b679'
def run(*args):
 r=subprocess.run([sys.executable,*map(str,args)],cwd=repo,text=True,capture_output=True);return [r.returncode,r.stdout+r.stderr]
cli=repo/'tools/open_tracking.py'
old=p/'prior'
zipfile.ZipFile(repo/'docs/evidence/open-tracking-first.zip').extractall(old)
def record(name,data):
 (p/name).write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf8')
prior={f.name:run(cli,f) for f in old.glob('*.json') if not f.name.startswith(('results','meta'))}
record('prior-replay.json',prior)
print({k:v[0] for k,v in prior.items()})
reg=run('-m','unittest','discover','-s','tools','-p','test_open_tracking.py','-v');record('regression.json',reg);print(reg)
src=json.loads((old/'valid.json').read_bytes())
oracle=json.loads((p/'freeze.json').read_bytes())
results=[]
for kind,cases in oracle.items():
 for case,expect in cases.items():
  inp=json.loads(json.dumps(src))
  if kind=='roles':inp[0]['labels']=[dict(name='team:'+case)]
  else:inp[1]['body']=case
  f=p/'private-inputs'/f'{len(results)+1:02}.json';f.parent.mkdir(exist_ok=True);record(f.relative_to(p),inp)
  actual=run(cli,f);results.append([case,expect,actual])
record('private-results.json',results);print('mismatch',[(a,b,c[0]) for a,b,c in results if b!=(c[0]==0)])

