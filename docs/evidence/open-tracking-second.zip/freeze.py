import json,pathlib
p=pathlib.Path(__file__).parent
url='https://github.com/Romanof123/JNOX/issues/6'
cases={s:True for s in ['Tracks #6.',url,'<'+url+'>','[#9]('+url+')','> #9\n\nTracks #6','요구사항 #6 확인','~~old~~\n\nTracks #6']}
cases.update({s:False for s in ['owner/other#6','https://github.com/other/JNOX/issues/6','[#6](https://github.com/other/JNOX/issues/6)','  > #6','> prior\nlazy #6','    #6','~~~log\n#6\n~~~','`#6`','<!-- #6 -->','<pre>\n#6\n</pre>','<code class="lang">#6</code>','![#6]('+url+')','[#6][ex]\n\n[ex]: '+url,'~~~\n```\n#6\n~~~','````\n```\n#6\n````']})
roles={r:True for r in 'pm systems functional-safety development integration verification release'.split()}
roles.update({'releases':False,'unknown':False})
(p/'freeze.json').write_text(json.dumps(dict(cases=cases,roles=roles),ensure_ascii=False,indent=2),encoding='utf8')
