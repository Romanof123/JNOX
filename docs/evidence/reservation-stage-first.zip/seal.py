from pathlib import Path
import hashlib,subprocess as s,struct,shutil
d=Path.home()/'jnox-stage-first'; m=Path('/mnt/d/codex/.jnox-work/next-fixed/reservation-stage-first')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with (d/'baseline.txt').open('w') as out:
 for k in ('parent','candidate'):
  p=d/(k+'-W.elf');print(k,h(p),file=out)
  for sec in ['.text','.rodata']:
   f=d/(k+sec);s.run(['aarch64-linux-gnu-objcopy','--dump-section',sec+'='+str(f),str(p),'/dev/null'],check=True);print(sec,len(f.read_bytes()),h(f),file=out)
  print(s.check_output(['readelf','-WS',str(p)],text=True),file=out)
 print('Stock',h(m.parent/'reservation-profile-builds/S-aligned-wake/kernel.elf'),file=out)
 print('W B fails mandatory identical PT_LOAD criterion. No subsequent builds or guests. No dynamic attribution.',file=out)
(d/'loads.txt').write_bytes(s.check_output(['python3',str(d/'compare.py')]))
files=[p for p in sorted(d.iterdir()) if p.is_file() and p.name!='SHA256SUMS']
(d/'SHA256SUMS').write_text(''.join(h(p)+'  '+p.name+'\n' for p in files))
for p in [*files,d/'SHA256SUMS']:
 shutil.copy2(p,m/p.name);assert h(p)==h(m/p.name)
print((d/'baseline.txt').read_text()[:1600]);print(len(files),'plus manifest verified')
