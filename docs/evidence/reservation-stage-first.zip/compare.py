from pathlib import Path
import struct, subprocess as s, hashlib
d=Path.home()/'jnox-stage-first'
def load(name):
 b=(d/(name+'-W.elf')).read_bytes()
 off=struct.unpack_from('<Q',b,32)[0]; sz,n=struct.unpack_from('<HH',b,54)
 ans=[]
 for i in range(n):
  typ,flags,f,v,p,fs,ms,a=struct.unpack_from('<IIQQQQQQ',b,off+i*sz)
  if typ==1: ans.append(((flags,v,p,fs,ms,a),b[f:f+fs]))
 return ans
for k in ['parent','candidate']:
 path=d/(k+'-W.elf')
 for ext,cmd in [('asm',['aarch64-linux-gnu-objdump','-d',str(path)]),('map',['aarch64-linux-gnu-nm','-nS',str(path)])]:
  (d/(k+'-W.'+ext)).write_bytes(s.check_output(cmd))
a,b=load('parent'),load('candidate')
for i,(x,y) in enumerate(zip(a,b)):
 dif=[j for j,(p,q) in enumerate(zip(x[1],y[1])) if p!=q]
 print(i,x[0],y[0],len(dif),[hex(x[0][1]+z) for z in dif[:12]])
