from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
reference=Path(sys.argv[1])
out=root/'restored'
out.mkdir()
for name,digest in json.loads((root/'paths.json').read_bytes()).items():
    data=(reference if name=='reference.zip' else root/'objects'/digest).read_bytes()
    if hashlib.sha256(data).hexdigest()!=digest:
        raise ValueError(name)
    (out/name).write_bytes(data)
(out/'SHA256SUMS').write_bytes((root/'SHA256SUMS').read_bytes())
