"""Decode and verify captured ordinary-process data via each slot's private L1/L2/L3 tables."""
import hashlib
import json
import re
import struct
import subprocess
import sys
from pathlib import Path

REV = "10ccba0f3d4aaf9e259eb8713a844e9acc725cb4"
BASE = 0x40200000
CASES = {"official-fifo":[61,62], "official-rr":[61,62], "wake-fifo":[63,64], "wake-rr":[63,64], "time":[65,66], "width":[67,68], "call-only":[69,70], "mail-only":[69,70], "coexist":[71,72], "cleanup":[73,74]}
OFFICIAL = [
    {"notify_send_status":("<8q",[0,0,0,0,-11,0,0,0])},
    {"notify_codes":("<4I",[17,17,23,23]), "notify_words":("<4Q",[(i<<32)|w for i,w in enumerate([300,512,257,1025],1)]), "notify_channel_sums":("<2Q",[812,1282]), "notify_empty_pulse":("<q",[-11]),"notify_event_results":("<4q",[1,-11,12,-11])},
]

def dig(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def symbols(path):
    result = {}
    lines = subprocess.check_output(["aarch64-linux-gnu-nm","-nS",path], text=True).splitlines()
    for line in lines:
        fields = line.split()
        if len(fields) == 4:
            result[fields[3]] = (int(fields[0],16),int(fields[1],16))
    return result

def slot_read(ram, table, va, fmt):
    data = bytearray()
    while len(data) < struct.calcsize(fmt):
        page=table
        for shift in (30,21,12):
            desc=struct.unpack_from("<Q",ram,page-BASE+8*((va>>shift)&511))[0]
            assert desc&3==3
            page=desc&0x0000fffffffff000
        offset=va&4095
        n=min(4096-offset,struct.calcsize(fmt)-len(data))
        data.extend(ram[page-BASE+offset:page-BASE+offset+n])
        va+=n
    return list(struct.unpack(fmt,data))

def analyze(root,case,expected):
    pkg=root/("package-"+case)
    cap=root/("capture-"+case)
    manifest=json.loads((pkg/"manifest.json").read_text())
    session=json.loads((cap/"session.json").read_text())
    uart=(cap/"uart.bin").read_text()
    observed={int(i):int(n) for i,n in re.findall(r"NATIVE EL0 EXIT PID (\d+) (-?\d+)",uart)}
    assert manifest["commit"]==REV and not manifest["tracked_changes"]
    for name,h in session["hashes"].items():
        assert dig(cap/name)==h
    assert dig(cap/"kernel.elf")==manifest["kernel_elf_sha256"]
    kr=symbols(cap/"kernel.elf")
    ram=(cap/"ram.bin").read_bytes()
    sr=[v for k,v in kr.items() if "6SPACES" in k]
    assert len(sr)==1
    spaces,sz=sr[0]
    issues=[]
    if [observed.get(i) for i in range(2)]!=expected:
        issues.append("exits")
    if "NATIVE FIXED DROPPED 0" not in uart or "FAULT" in uart:
        issues.append("fixed journal/guest fault")
    result={"expected_exits":expected,"observed_exits":observed,"kernel_sha256":manifest["kernel_elf_sha256"],"issues":issues,"slots":[]}
    for i, slot in enumerate(manifest["slots"]):
        elf=pkg/slot["elf"]
        assert dig(elf)==slot["elf_sha256"]
        syms=symbols(elf)
        values={}
        fields=OFFICIAL[i] if case.startswith("official-") else {"probe_results":("<32Q",None)}
        for name,(fmt,expect) in fields.items():
            va,size=syms[name]
            assert size==struct.calcsize(fmt)
            arr=slot_read(ram,spaces+i*sz//2,va,fmt)
            values[name]=arr
            if expect is not None and arr!=expect:
                issues.append(name)
        result["slots"].append({"elf_sha256":slot["elf_sha256"],"private_data":values})
    result["notify_journal"]=[line.strip() for line in uart.splitlines() if "NOTIFY" in line]
    result["fixed_journal"]=[list(map(int,line.split()[3:])) for line in uart.splitlines() if line.startswith("NATIVE FIXED EVENT ")]
    return result

if __name__=="__main__":
    root=Path(sys.argv[1])
    rows={}
    for case,expected in CASES.items():
        try:
            rows[case]=analyze(root,case,expected)
        except Exception as exc:
            rows[case]={"issues":[repr(exc)]}
    print(json.dumps(rows,indent=2))
    sys.exit(any(r["issues"] for r in rows.values()))
