#!/bin/bash
set -euo pipefail
prep=/mnt/d/codex/.jnox-work/369-first-independent
d=$HOME/iv369-first-10ccba0-evidence
src=$HOME/iv369-first-10ccba0-src
sha=10ccba0f3d4aaf9e259eb8713a844e9acc725cb4
source "$HOME/.cargo/env"
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$d/app-target" CARGO_NET_OFFLINE=true
cd "$src"
cp "$prep"/{decode.py,controls.rs,qualify.sh} "$d"
python3 "$d/decode.py" "$d" > "$d/first-results.json" || :
mkdir "$d/corrected-width"
w=$d/corrected-width
printf '%s\n' 'The original reverse direction fixture expected EPERM or ENOSYS but a present notification facility uses EACCES (-13) for an ungranted direction. The contract requires denial. Preserve the original UART and private memory, then rerun after amending the verifier-only comparison. No candidate source or original guest packet changes.' > "$w/reason.txt"
sed 's/return x == -1 || x == -38;/return x == -1 || x == -13 || x == -38;/' "$d/probe.c" > "$w/probe.c"
rustc --edition 2021 "$d/controls.rs" -o "$d/controls" > "$d/host-independent-build.log" 2>&1
"$d/controls" > "$d/host-independent.log"
sh sdk/native-aarch64/build.sh "$w/probe.c" "$w/probe.elf" > "$w/build.log" 2>&1
python3 tools/build_native_el0.py --elf "$w/probe.elf" --peer-elf "$w/probe.elf" --policy fifo --priority 7 --peer-priority 1 --arg width-sender --peer-arg width-owner --notify-route 0:1 --out "$w/package-width" > "$w/package.log" 2>&1
python3 tools/native_el0_capture.py "$w/capture-width" "$w/package-width/kernel.elf" "$w/probe.elf" "$w/probe.c" "$sha" --plain --manifest "$w/package-width/manifest.json" --expect-exit 67 --timeout 9 > "$w/capture.log"
python3 - "$d" <<'PY'
import sys,json
from pathlib import Path
d=Path(sys.argv[1]);sys.path.insert(0,str(d))
import decode
j=decode.analyze(d/"corrected-width","width",[67,68])
(d/"corrected-width/results.json").write_text(json.dumps(j,indent=2))
for name,row in json.loads((d/"first-results.json").read_text()).items():
    print(name,row.get("observed_exits"),row["issues"])
print("corrected-width",j["observed_exits"],j["issues"])
PY
