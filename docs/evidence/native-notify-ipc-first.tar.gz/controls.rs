#[path = "/home/ywcho/iv369-first-10ccba0-src/kernel/src/notify_ipc.rs"]
mod notify;
use notify::NotifyIpc;

fn main() {
    let mut q=NotifyIpc::new([2,0]);
    let words=[(1u64<<32)|300,(2u64<<32)|512,(3u64<<32)|257,(4u64<<32)|1025];
    println!("initial len={} peak={} latch={}",q.occupancy(1),q.high_water(1),q.pending_mask(1));
    for (i,w) in words.into_iter().enumerate() {
        q.pulse_send(0,1,if i<2 {17} else {23},w,0).unwrap();
        assert_eq!(q.take(0).unwrap().status,0);
        assert_eq!(q.occupancy(1),i+1);
        println!("send {} len={} peak={}",i,q.occupancy(1),q.high_water(1));
    }
    assert_eq!(q.pulse_send(0,1,99,u64::MAX,1),Err(-11));
    assert_eq!(q.occupancy(1),4);
    for (mask,val) in [(9,9),(1,9),(4,13)] {
        q.event_set(0,1,mask,1).unwrap();
        q.take(0).unwrap();
        assert_eq!(q.pending_mask(1),val);
        println!("set {mask} len={} latch={}",q.occupancy(1),q.pending_mask(1));
    }
    q.exit(0,2);
    assert_eq!(q.occupancy(1),4);
    for (i,w) in words.into_iter().enumerate() {
        q.pulse_recv(1,0,3).unwrap();
        let p=q.take(1).unwrap();
        assert_eq!((p.x1,p.x2),(if i<2 {17} else {23},w));
        println!("recv {i} len={} peak={}",q.occupancy(1),q.high_water(1));
    }
    q.event_take(1,1,0,4).unwrap();
    assert_eq!((q.take(1).unwrap().x1,q.pending_mask(1)),(1,12));
    assert_eq!(q.event_take(1,1,0,4),Err(-11));
    assert_eq!(q.pending_mask(1),12);
    q.event_take(1,12,0,4).unwrap();
    assert_eq!((q.take(1).unwrap().x1,q.pending_mask(1)),(12,0));
    for kind in [0,1] {
        for at in [10,11,12] {
            let mut m=NotifyIpc::new([2,0]);
            if kind==0 {m.pulse_recv(1,11,1)} else {m.event_take(1,0x80000000,11,1)}.unwrap();
            assert!(m.blocked(1));
            assert_eq!(m.next_deadline(),Some(11));
            assert_eq!(m.event_take(1,1,0,1),Err(-16));
            if kind==0 {m.pulse_send(0,1,42,84,at)} else {m.event_set(0,1,0x80000000,at)}.unwrap();
            m.take(0).unwrap();
            let done=m.take(1).unwrap();
            println!("kind={kind} at={at} status={} occupancy={} pending={}",done.status,m.occupancy(1),m.pending_mask(1));
            assert_eq!(done.status,if at<11 {0} else {-110});
            assert!(!m.blocked(1));
            assert!(m.take(1).is_none());
            if at>=11 {
                if kind==0 {m.pulse_recv(1,0,12)} else {m.event_take(1,0x80000000,0,12)}.unwrap();
                let got=m.take(1).unwrap();
                assert_eq!((got.x1,got.x2),if kind==0 {(42,84)} else {(0x80000000,0)});
            }
        }
    }
    let mut all=NotifyIpc::new([2,0]);
    for i in 0..32 {
        all.event_set(0,1,1u64<<i,0).unwrap();
        all.take(0).unwrap();
    }
    assert_eq!(all.pending_mask(1),u32::MAX);
    for i in (0..32).rev() {
        all.event_take(1,1u64<<i,0,0).unwrap();
        assert_eq!(all.take(1).unwrap().x1,1u64<<i);
    }
    assert_eq!(all.pending_mask(1),0);
    all.pulse_send(0,1,0,99,0).unwrap(); all.take(0).unwrap();
    all.event_set(0,1,1,0).unwrap(); all.take(0).unwrap();
    all.event_take(1,2,u64::MAX,0).unwrap();
    assert!(all.blocked(1));
    all.exit(1,1);
    assert_eq!((all.blocked(1),all.take(1),all.occupancy(1),all.pending_mask(1)),(false,None,0,0));
    assert_eq!(all.pulse_send(0,1,0,2,2),Err(-32));
    println!("all 32 independent bits consumed; blocked owner plus queued pulse and unrelated bit cleared; peak={}",all.high_water(1));
}
