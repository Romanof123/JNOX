#include <time.h>
#include <jnox/notify.h>
#include <jnox/ipc.h>
#include <jnox/mailbox.h>

volatile unsigned long long probe_results[32];
static const uint64_t word = 0xabcdef0189abcdefULL;
static const uint32_t high_bit = 0x80000000U;
static unsigned int cursor;

static long save(long status) {
    probe_results[cursor++] = (uint64_t)status;
    return status;
}
static uint64_t now(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
}
static void delay(void) {
    uint64_t t = now() + 100000000ULL;
    struct timespec ts = {.tv_sec = (long)(t/1000000000ULL), .tv_nsec = (long)(t%1000000000ULL)};
    save(clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &ts, 0));
}
static long pulse(uint64_t dl, uint32_t code, uint64_t expected) {
    jnox_pulse_result p = jnox_pulse_recv(dl);
    save(p.status);
    if (!p.status) {
        probe_results[cursor++] = p.code;
        probe_results[cursor++] = p.word;
        if (p.code != code || p.word != expected) return -900;
    }
    return p.status;
}
static long bits(uint32_t mask, uint64_t dl) {
    jnox_event_result e = jnox_event_take(mask, dl);
    save(e.status);
    if (!e.status) probe_results[cursor++] = e.bits;
    return e.status ? e.status : (long)e.bits;
}
static int role(const char *a, const char *b) {
    while (*a && *a == *b) { ++a; ++b; }
    return *a == *b;
}
static int refused(long x) { return x == -1 || x == -13 || x == -38; }

int main(int argc, char **argv) {
    if (argc != 2) return 200;
    const char *r = argv[1];
    if (role(r, "wake-owner")) {
        if (pulse(UINT64_MAX, 19, word) != 0) return 101;
        if (bits(high_bit, UINT64_MAX) != high_bit) return 102;
        if (bits(8, 0) != 8 || bits(~0U, 0) != -11) return 103;
        if (pulse(0, 0, 0) != -11) return 104;
        return 64;
    }
    if (role(r, "wake-sender")) {
        if (save(jnox_pulse_send(1, 19, word))) return 105;
        delay();
        if (save(jnox_event_set(1, 8))) return 106;
        if (save(jnox_event_set(1, high_bit))) return 107;
        return 63;
    }
    if (role(r, "late-owner")) {
        uint64_t deadline = now() + 10000000ULL;
        probe_results[cursor++] = deadline;
        if (pulse(deadline, 0, 0) != -110) return 108;
        uint64_t after = now();
        probe_results[cursor++] = after;
        if (after < deadline) return 109;
        deadline = now() + 10000000ULL;
        probe_results[cursor++] = deadline;
        if (bits(high_bit, deadline) != -110) return 110;
        after = now();
        probe_results[cursor++] = after;
        if (after < deadline) return 111;
        delay();
        if (pulse(1, 0, 0) != -110 || bits(high_bit, 1) != -110) return 112;
        if (pulse(0, 19, word) || bits(high_bit, 0) != high_bit) return 113;
        return 66;
    }
    if (role(r, "late-sender")) {
        uint64_t t = now() + 45000000ULL;
        struct timespec ts = {.tv_sec=(long)(t/1000000000ULL), .tv_nsec=(long)(t%1000000000ULL)};
        if (save(clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &ts, 0))) return 114;
        if (save(jnox_pulse_send(1, 19, word)) || save(jnox_event_set(1, high_bit))) return 115;
        return 65;
    }
    if (role(r, "width-sender")) {
        if (save(jnox_notify_trap(26, 1, 1ULL<<32, word).status) != -22) return 116;
        if (save(jnox_notify_trap(28, 1, 1ULL<<32, 0).status) != -22) return 117;
        if (save(jnox_event_set(1, 0)) != -22) return 118;
        if (!save(jnox_notify_trap(26, (1ULL<<32)|1, 19, word).status)) return 119;
        if (!save(jnox_notify_trap(28, (1ULL<<32)|1, high_bit, 0).status)) return 120;
        if (save(jnox_pulse_send(1, 19, word)) || save(jnox_pulse_send(1, 19, word))) return 121;
        if (save(jnox_event_set(1, high_bit))) return 122;
        return 67;
    }
    if (role(r, "width-owner")) {
        if (!refused(save(jnox_pulse_send(0, 4, 543))) || !refused(save(jnox_event_set(0,1)))) return 123;
        if (save(jnox_notify_trap(29, (1ULL<<32)|high_bit, 0, 0).status) != -22) return 124;
        if (bits(0, 0) != -22 || bits(high_bit, 0) != high_bit || bits(~0U,0) != -11) return 125;
        if (pulse(0, 19, word) || pulse(0, 19, word) || pulse(0, 0, 0) != -11) return 126;
        return 68;
    }
    if (role(r, "denied")) {
        if (!refused(save(jnox_pulse_send(1, 19, word))) || !refused(save(jnox_event_set(1, high_bit)))) return 127;
        return 69;
    }
    if (role(r, "quiet")) {
        long p=pulse(0,0,0), e=bits(~0U,0);
        if ((p != -11 && p != -38) || (e != -11 && e != -38)) return 128;
        return 70;
    }
    if (role(r,"co-sender")) {
        if (save(jnox_pulse_send(1,19,word)) || save(jnox_event_set(1,high_bit))) return 129;
        if (save(jnox_mailbox_send(1,word+1,0))) return 130;
        jnox_ipc_response reply=jnox_ipc_call(1,word+2,UINT64_MAX);
        if (save(reply.status) || (probe_results[cursor++]=reply.word) != word+3) return 131;
        return 71;
    }
    if (role(r,"co-owner")) {
        jnox_mailbox_result msg=jnox_mailbox_receive(0);
        if (save(msg.status) || (probe_results[cursor++]=msg.word) != word+1) return 132;
        jnox_ipc_request req=jnox_ipc_receive();
        if (save(req.status) || (probe_results[cursor++]=req.word) != word+2) return 133;
        if (save(jnox_ipc_reply(req.token,req.word+1))) return 134;
        if (pulse(0,19,word) || bits(high_bit,0)!=high_bit) return 135;
        return 72;
    }
    if (role(r,"drop-sender")) {
        if (save(jnox_pulse_send(1,19,word)) || save(jnox_event_set(1,high_bit))) return 136;
        delay();
        if (save(jnox_pulse_send(1,19,word)) != -32 || save(jnox_event_set(1,high_bit)) != -32) return 137;
        return 73;
    }
    if (role(r,"drop-owner")) return 74;
    return 201;
}
