"""Verify control values, guest owner transitions and public-case peaks in the original raw packets."""
import json
import sys
from pathlib import Path
from decode import CASES,analyze

root=Path(sys.argv[1])
idle=(1<<64)-1
word=0xabcdef0189abcdef
high=1<<31
def unsigned(v): return v % (1<<64)
def report(case,pid):
    return all_rows[case]["slots"][pid]["private_data"]["probe_results"]
def prefix(case,pid,vals):
    actual=report(case,pid)
    assert actual[:len(vals)]==[unsigned(v) for v in vals],(case,pid,actual,vals)
    assert actual[len(vals):]==[0]*(len(actual)-len(vals))
all_rows={case:analyze(root,case,exits) for case,exits in CASES.items()}
all_rows["corrected-width"]=analyze(root/"corrected-width","width",[67,68])
for case,row in all_rows.items():
    assert row["issues"]==(["exits"] if case=="width" else []),(case,row["issues"])
    assert row["fixed_journal"][-1][4]==idle and row["fixed_journal"][-1][12:15]==[idle]*3
    if case in ("call-only","mail-only"):
        assert not row["notify_journal"]
    else:
        peak={"official-fifo":4,"official-rr":4,"wake-fifo":0,"wake-rr":0,"time":1,"width":2,"corrected-width":2,"coexist":1,"cleanup":1}[case]
        assert row["notify_journal"]==["NATIVE NOTIFY STATE 0 0 0 0 0","NATIVE NOTIFY STATE 0 1 0 0 0","NATIVE NOTIFY STATE 1 0 0 0 0",f"NATIVE NOTIFY STATE 1 1 0 {peak} 0"]
for case in ("official-fifo","official-rr"):
    ipc=[(r[1],r[3],r[4]) for r in all_rows[case]["fixed_journal"] if r[1] in (3,26,27,28,29)]
    assert ipc==[(26,0,0)]*5+[(28,0,0)]*3+[(3,0,1)]+[(27,1,1)]*5+[(29,1,1)]*4+[(3,1,idle)]
for case in ("wake-fifo","wake-rr"):
    rows=all_rows[case]["fixed_journal"]
    assert rows[0][4]==1
    ipc=[(r[1],r[3],r[4]) for r in rows if 26<=r[1]<=29]
    assert ipc==[(27,1,0),(26,0,1),(29,1,0),(28,0,0),(28,0,1),(29,1,1),(29,1,1),(27,1,1)]
    prefix(case,0,[0,0,0,0])
    prefix(case,1,[0,19,word,0,high,0,8,-11,-11])
v=report("time",1)
assert 0<v[0]<=v[2]<v[3]<=v[5]
prefix("time",1,[v[0],-110,v[2],v[3],-110,v[5],0,-110,-110,0,19,word,0,high])
assert all_rows["width"]["observed_exits"]=={0:67,1:123}
prefix("width",0,[-22]*5+[0,0,0])
prefix("width",1,[-13])
prefix("corrected-width",0,[-22]*5+[0,0,0])
prefix("corrected-width",1,[-13,-13,-22,-22,0,high,-11,0,19,word,0,19,word,-11])
for case in ("call-only","mail-only"):
    prefix(case,0,[-38,-38])
    prefix(case,1,[-38,-38])
prefix("coexist",0,[0,0,0,0,word+3])
prefix("coexist",1,[0,word+1,0,word+2,0,0,19,word,0,high])
prefix("cleanup",0,[0,0,0,-32,-32])
rows=all_rows["cleanup"]["fixed_journal"]
assert all(r[1] not in (27,29) for r in rows)
print("11 sessions validated: nine first controls matched both slot exits, one first fixture mismatch preserved, one corrected control matched both slot exits.")
print("Each captured file hash, package ELF, per-slot RAM and scheduler chronology checked. Final owner idle and ready queues empty in every cold boot.")
