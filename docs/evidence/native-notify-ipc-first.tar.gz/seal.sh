#!/bin/bash
set -euo pipefail
prep=/mnt/d/codex/.jnox-work/369-first-independent
d=$HOME/iv369-first-10ccba0-evidence
src=$HOME/iv369-first-10ccba0-src
sha=10ccba0f3d4aaf9e259eb8713a844e9acc725cb4
name=369-first-10ccba0.tar.gz
cp "$prep"/{verify_results.py,REPORT.en-ko.md,seal.sh} "$d"
cd "$d"
python3 verify_results.py . > replay-verification.txt
git -C "$src" branch frozen-ipc003 "$sha"
git -C "$src" bundle create "$d/candidate.bundle" refs/heads/frozen-ipc003 ^04d699c8a445fc837a423c96ba35825810550c4b
git -C "$src" bundle verify "$d/candidate.bundle" > "$d/candidate-bundle.txt" 2>&1
tar --exclude=target --exclude=app-target --exclude=__pycache__ --exclude=./controls --exclude=./host-tests -czf "$prep/$name" .
cd "$prep"
sha256sum "$name" > "$name.sha256"
sha256sum -c "$name.sha256"
mkdir "$d/archive-audit"
tar -xzf "$prep/$name" -C "$d/archive-audit"
cd "$d/archive-audit"
PYTHONDONTWRITEBYTECODE=1 python3 verify_results.py .
cat "$prep/$name.sha256"
stat -c '%s bytes' "$prep/$name"
