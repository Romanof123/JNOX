#!/bin/bash
set -euo pipefail
sha=10ccba0f3d4aaf9e259eb8713a844e9acc725cb4
src=$HOME/iv369-first-10ccba0-src
d=$HOME/iv369-first-10ccba0-evidence
prep=/mnt/d/codex/.jnox-work/369-first-independent
mkdir "$src" "$d"
cp "$prep"/{freeze.txt,probe.c,run.sh} "$d"
exec > >(tee "$d/run.log") 2>&1
source "$HOME/.cargo/env"
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$d/app-target" CARGO_NET_OFFLINE=true
git -C "$src" init -q
echo /mnt/d/codex/j-nox/.git/objects > "$src/.git/objects/info/alternates"
cd "$src"
git sparse-checkout init --cone
git sparse-checkout set arch boards examples kernel sdk tools trace verification
git -c advice.detachedHead=false checkout -q --detach "$sha"
git rev-parse HEAD HEAD^{tree} > "$d/source.txt"
git status --porcelain --untracked-files=no >> "$d/source.txt"
sha256sum "$d"/{freeze.txt,probe.c,run.sh} > "$d/frozen.sha256"
run() {
    local tag=$1 rc=0
    shift
    printf '%q ' "$@" >>"$d/commands"
    echo >>"$d/commands"
    "$@" >"$d/$tag.log" 2>&1 || rc=$?
    echo "$tag $rc" | tee -a "$d/status"
    if [ "$rc" -ne 0 ]; then tail -16 "$d/$tag.log"; fi
    return "$rc"
}
run host-build rustc --edition 2021 --test kernel/src/notify_ipc.rs -o "$d/host-tests" && run host-tests "$d/host-tests" --nocapture || :
run c sh sdk/native-aarch64/build.sh examples/native-notify/sender.c "$d/sender.elf"
run rust sh sdk/native-aarch64/build-rust.sh examples/native-notify/receiver/Cargo.toml "$d/receiver.elf"
run independent-c sh sdk/native-aarch64/build.sh "$d/probe.c" "$d/probe.elf"
probe() {
    local tag=$1 policy=$2 want=$3 elf=$4 sourcefile=$5 peer=$6 ap=$7 bp=$8
    shift 8
    local args=()
    if [ "$policy" = rr ]; then args+=(--quantum-ticks 625000); fi
    run "package-$tag" python3 tools/build_native_el0.py --elf "$elf" --peer-elf "$peer" --policy "$policy" --priority "$ap" --peer-priority "$bp" "${args[@]}" "$@" --out "$d/package-$tag" || return 0
    run "capture-$tag" python3 tools/native_el0_capture.py "$d/capture-$tag" "$d/package-$tag/kernel.elf" "$elf" "$sourcefile" "$sha" --plain --manifest "$d/package-$tag/manifest.json" --expect-exit "$want" --timeout 9 || :
    if test -e "$d/capture-$tag/uart.bin"; then awk '/EXIT PID|FAULT|DROPPED/{print}' "$d/capture-$tag/uart.bin"; fi
}
fixture() {
    local tag=$1 policy=$2 want=$3 ap=$4 bp=$5 rolea=$6 roleb=$7
    shift 7
    probe "$tag" "$policy" "$want" "$d/probe.elf" "$d/probe.c" "$d/probe.elf" "$ap" "$bp" --arg "$rolea" --peer-arg "$roleb" "$@"
}
for policy in fifo rr; do
    probe "official-$policy" "$policy" 61 "$d/sender.elf" examples/native-notify/sender.c "$d/receiver.elf" 7 1 --notify-route 0:1
done
for policy in fifo rr; do
    fixture "wake-$policy" "$policy" 63 1 7 wake-sender wake-owner --notify-route 0:1
done
fixture time fifo 65 1 7 late-sender late-owner --notify-route 0:1
fixture width fifo 67 7 1 width-sender width-owner --notify-route 0:1
fixture call-only fifo 69 7 1 denied quiet --ipc-route 0:1
fixture mail-only fifo 69 7 1 denied quiet --mailbox-route 0:1
fixture coexist fifo 71 7 1 co-sender co-owner --notify-route 0:1 --ipc-route 0:1 --mailbox-route 0:1
fixture cleanup fifo 73 7 1 drop-sender drop-owner --notify-route 0:1
