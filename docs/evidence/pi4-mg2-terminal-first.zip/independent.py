from pathlib import Path
import hashlib,json,re,struct
d=Path(__file__).parent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_bytes())
out=[]
for i,(case,n) in enumerate([(k,n) for k in ("global","partitioned","clustered") for n in (1,2)],1):
 f=d/"cohort"/("migration-"+case); p=f/f"first-{n}"; s=load(p/"session.json"); z=load(f/"freeze.json"); r=z["ram"]; raw=(p/"terminal-ram.bin").read_bytes(); uart=(p/"uart.bin").read_text().splitlines()
 assert H(p/"session.json")== (d/f"run-{i}.log").read_text().strip() and all(H(p/k)==v for k,v in s['hashes'].items()) and all(H(f/k)==v for k,v in z['hashes'].items())
 rows=[];counts=[];losts=[];seals=[]
 for cpu in (0,1):
  start=r["symbols"]["LOG"][0]-r["pa"]+cpu*6944
  count,lost,hz,seal=struct.unpack_from("<3QB",raw,start+6912);assert count<=96 and not lost
  counts.append(count);losts.append(lost);seals.append(seal)
  for seq in range(count):
   *w,kind=struct.unpack_from("<9Q",raw,start+seq*72);assert 1<=kind<=13
   rows.append([cpu,seq,kind,*w])
 assert next(x for x in rows if x[0]==1 and x[2]==13)[3:10]==[2,0,2,1,152,16,136]
 for row in [x for x in rows if x[2]==5 and x[3]==0]:
  idx,val=row[6:8];assert val==idx*(idx+1)//2
 fold=0
 for idx in range(16,65537,16):fold=((((fold<<7)|(fold>>57))&((1<<64)-1))^idx)+idx*(idx+1)//2;fold%=1<<64
 mframe=next(x for x in rows if x[2]==4 and x[4]==0)
 offset=mframe[5]-r["pa"]; reg=struct.unpack_from("<40Q",raw,offset)
 if i!=5:assert reg[:5]==(0,2147516416,4096,fold,65536) and reg[31]==mframe[6]
 else:
  assert rows==[list(map(int,x.split()[2:])) for x in uart if x.startswith("MG ROW ")]
  assert [x[3:10] for x in rows if x[2]==13 and x[3]==0]==[[0,1,5,4096,fold,65536,2147516416]]
 pcs=[re.search(r' PC=(\w+)',(p/f"cpu-{cpu}-registers.txt").read_text()).group(1) for cpu in range(4)]
 out.append(dict(position=i,terminal=s["terminal"],counts=counts,lost=losts,seals=seals,register_pc=pcs,entry_pc=hex(mframe[6]),x21=mframe[8],rows=rows))
(d/"independent.json").write_text(json.dumps(out,indent=2))

