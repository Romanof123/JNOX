#!/bin/bash
set -eu
cd /home/ywcho/jnox189-stage1-assessor
export PYTHONPATH=/home/ywcho/jnox-169-first-e203caa/deps
export PYTHONDONTWRITEBYTECODE=1
d=/mnt/d/codex/jnox189-stage1-independent
r=/home/ywcho/jnox189-stage1-cohort
cd "$d"
printf '%s\n' 'Frozen six positions G,G,P,P,C,C; no retries. Require exact source, model, guest; verify receipts and release prefix, arithmetic, P1 retire/send, external SVC/IRQ and actual restored PC/lease. Leave unobserved cross-core ordering open. No family credit or hardware inference.' >criteria.txt
cd /home/ywcho/jnox189-stage1-assessor
t=tools/pi4_mg2_terminal.py
python3 "$t" freeze "$r" /mnt/d/codex/arm-speed-lab/build/system/qemu-system-aarch64 | tee "$d/freeze.log"
c=$(sha256sum "$r/cohort.json" | cut -d' ' -f1)
cp -r "$r" "$d/cohort"
for i in 1 2 3 4 5 6; do
  python3 "$t" run "$r" "$c" "$i" >"$d/run-$i.log" 2>&1 || echo $? >"$d/run-$i.rc"
  f=$(find "$r" -name session.json | sort | while read -r f; do test -f "$d/cohort/${f#"$r/"}" || echo "$f"; done)
  test -f "$f"
  s=$(sha256sum "$f" | cut -d' ' -f1)
  python3 "$t" replay "$r" "$c" "$i" "$s" >"$d/replay-$i.json" 2>"$d/replay-$i.err" || echo $? >"$d/replay-$i.rc"
  rel=${f#"$r/"}
  part=$(dirname "$rel")
  cp -r "$r/$part" "$d/cohort/$part"
  (cd "$r"; find "$part" -type f -print0 | sort -z | xargs -0 sha256sum) >"$d/position-$i.sha256"
  (cd "$d/cohort"; sha256sum -c "$d/position-$i.sha256") >"$d/reopen-$i.log"
  echo "position $i $s"
done
