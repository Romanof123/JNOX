set -eu
export CARGO_HOME=/home/ywcho/jnox-169-first-e203caa/cargo RUSTUP_HOME=/home/ywcho/jnox-169-first-e203caa/rustup
export PATH="$CARGO_HOME/bin:$PATH"
cd /mnt/d/codex/jnox252-raw
rustc +1.95.0 --edition 2024 --cfg jnox_ordinary_deadline -O oracle.rs -o /tmp/jnox252-oracle
/tmp/jnox252-oracle > oracle.txt
rustc +1.95.0 --edition 2024 --test ../jnox252-independent/tools/scheduling_tests.rs -o /tmp/jnox252-scheduling
/tmp/jnox252-scheduling --test-threads=1 > scheduling.txt
