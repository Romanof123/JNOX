set -eu
out=/mnt/d/codex/jnox252-raw
src=/mnt/d/codex/jnox252-independent
cd "$src/kernel"
export GIT_DIR=$(wslpath "$(cut -d' ' -f2- "$src/.git" | tr -d '\r')") GIT_WORK_TREE="$src"
export CARGO_HOME=/home/ywcho/jnox-169-first-e203caa/cargo RUSTUP_HOME=/home/ywcho/jnox-169-first-e203caa/rustup
export PATH="$CARGO_HOME/bin:$PATH" CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR=$(mktemp -d)
for mode in trace plain; do
 for a in ordinary-edf-supply-refuse ordinary-llf-supply-refuse ordinary-edf-supply ordinary-llf-supply ordinary-edf ordinary-llf ordinary-llf-overload ordinary-edf-overrun coop-events coop-single; do
  profile=deadline; case "$a" in coop-*) [[ $mode = plain ]] || continue; profile=fixed;; esac
  d="$out/$a-$mode"; if [[ -d "$d" ]]; then if [[ $a-$mode = ordinary-llf-overload-trace ]]; then d="$d-retry"; else continue; fi; fi; mkdir "$d"
  opts=("JNOX_BOARD=virt" "JNOX_PROFILE=$profile" "JNOX_APP=$a"); if [[ $mode = trace ]]; then opts+=(JNOX_DEADLINE_TRACE=1); fi
  (set -x; env "${opts[@]}" cargo +1.95.0 build --locked --release -j1) > "$d/build.log" 2>&1
  cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" "$d/kernel.elf"
  if [[ $profile = deadline ]]; then python3 "$out/capture2.py" "$d"; fi
  if [[ $a = *supply* ]]; then arg=(); [[ $mode = trace ]] || arg+=(--plain); python3 "$src/tools/deadline_supply_replay.py" "$a" "$d/uart" "${arg[@]}" > "$d/replay" 2>&1 || true; fi
 done
done
for t in deadline_supply_tests deadline_tests; do rustc +1.95.0 --edition 2024 --test "../tools/$t.rs" -o "$CARGO_TARGET_DIR/$t" && "$CARGO_TARGET_DIR/$t" --test-threads=1 > "$out/$t.txt"; done

