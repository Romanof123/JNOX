import sys,time,subprocess,json,pathlib,hashlib
d=pathlib.Path(sys.argv[1]); elf=d/'kernel.elf'
sym=subprocess.check_output(['nm','-nS',elf],text=True);(d/'symbols').write_text(sym)
flags='-machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -accel tcg -m 128M -nodefaults -display none -monitor none -no-reboot -qmp stdio -d int'.split()
cmd=['qemu-system-aarch64',*flags,'-D',str(d/'exceptions'),'-serial','file:'+str(d/'uart'),'-kernel',str(elf)]
(d/'launch.json').write_text(json.dumps([cmd,hashlib.sha256(elf.read_bytes()).hexdigest(),time.time_ns()]))
p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(d/'stderr').open('wb'))
def q(op,**kw):
 p.stdin.write((json.dumps(dict(execute=op,arguments=kw))+'\n').encode());p.stdin.flush()
 while True:
  x=json.loads(p.stdout.readline())
  if 'return' in x:return x['return']
  if 'error' in x:raise Exception(x)
try:
 p.stdout.readline();q('qmp_capabilities')
 end=time.monotonic()+5
 while time.monotonic()<end:
  try: uart=(d/'uart').read_bytes()
  except OSError: uart=b''
  if any(m in uart for m in [b'FINISHED\n',b'LAUNCH\n',b'FAIL\n',b'FINISHED\r\n',b'LAUNCH\r\n',b'FAIL\r\n']):break
  time.sleep(.01)
 q('stop');(d/'regs').write_text(q('human-monitor-command',**{'command-line':'info registers'}))
 for l in sym.splitlines():
  f=l.split()
  if len(f)==4 and f[3] in ['ordinary_deadline_rows','ordinary_deadline_row_count']:
   q('pmemsave',val=int(f[0],16),size=int(f[1],16),filename=str(d/f[3]))
finally:
 p.terminate();p.wait()

