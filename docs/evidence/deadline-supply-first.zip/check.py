from pathlib import Path
import struct,json,re,hashlib,sys
root=Path(__file__).parent
baseline=json.loads((root.parent/'jnox-baseline-248250-evidence/manifest.json').read_text())
def load(raw):
 out=b''
 for i in range(struct.unpack_from('<H',raw,56)[0]):
  p=struct.unpack_from('<IIQQQQQQ',raw,struct.unpack_from('<Q',raw,32)[0]+i*56)
  if p[0]==1:out+=raw[p[2]:p[2]+p[5]]
 return out
def sha(x):return hashlib.sha256(x).hexdigest()
for b in baseline:
 p=root/b['case']/'kernel.elf'; v=load(p.read_bytes())
 print(b['case'],'LOAD',len(v)-b['load_bytes'],sha(v)==b['load_sha256'],'ELF identical',sha(p.read_bytes())==b['elf_sha256'])
sys.path.insert(0,str(root.parent/'jnox252-independent/tools'))
from deadline_supply_replay import replay
for path in sorted(root.glob('*/ordinary_deadline_rows')):
 d=path.parent; n=int.from_bytes((d/'ordinary_deadline_row_count').read_bytes(),'little'); raw=path.read_bytes();uart=(d/'uart').read_text(); lines=uart.splitlines()
 cfg=list(map(int,next(s for s in lines if s.startswith('CONFIG')).split()[1:]));hz,S,Q,llf,ov,ref,H,frame=cfg
 if 'refuse' in d.name:assert n==0 and not (d/'exceptions').read_text().strip();continue
 if 'FINISHED' not in uart:
  assert d.name=='ordinary-llf-supply-plain' and 'ORDINARY DEADLINE FAIL' in uart; print(d.name,'FIRST FAILED, rows',n);continue
 jobs=[list(map(int,l.split()[1:])) for l in lines if l.startswith('JOB')]
 saved={i:(top-frame,entry) for i,r,dl,c,ms,entry,top in jobs}
 trace=[];ds=[];js=[];rows=[]
 for index in range(n):
  pos=index*448;e=list(struct.unpack_from('<19Q',raw,pos));ds.append(e);j=[[int.from_bytes(raw[pos+160+k*96+l*16:pos+176+k*96+l*16],'little',signed=True) for l in range(6)] for k in range(3)];js.append(j)
  rows+=['D '+' '.join(map(str,e))]+['J '+' '.join(map(str,z)) for z in j]
  assert e[3]==S+e[2]*Q and e[18]==0 and e[7]<=e[8] and e[6]<=e[7]
  if e[0]==1:assert e[1]==e[2] and e[4]==e[3] and e[5]==30
  else:assert e[7]<=S+jobs[e[9]][2]*Q and j[e[9]][5]>0
  if e[9]<len(jobs):assert jobs[e[9]][6]-16384<=e[11]<=jobs[e[9]][6]-frame
  saved[e[9]]=tuple(e[11:13])
  if e[10] in saved:assert tuple(e[13:15])==saved[e[10]]
 ex=(d/'exceptions').read_text()
 assert [int(i,16) for i in re.findall(r'with ELR 0x([0-9a-f]+)',ex)]==[e[12] for e in ds]
 eret=[int(i,16) for i in re.findall(r'Exception return .* PC 0x([0-9a-f]+)',ex)]
 assert eret[1:]==[e[14] for e in ds[:-1]]
 assert sorted(e[9] for e in ds if e[0]==2)==list(range(len(jobs)))
 if 'trace' in d.name:assert rows==[l for l in lines if l.startswith(('D ','J '))]
 if 'supply' in d.name:
  p=d/'decoded'; p.write_text('\n'.join(l for l in lines if not l.startswith(('D ','J ')))+'\n'+'\n'.join(rows)+'\n')
  stats=replay('ordinary-'+('llf' if llf else 'edf')+'-supply',p)
  print(d.name,'frame/pc',ds[1][11:13],'service',stats['service_counts'],'completion/headroom',[(e[7],S+jobs[e[9]][2]*Q-e[7]) for e in ds if e[0]==2])
 else:
  seq=[(e[1],e[9],e[10]) for e in ds if e[0]==1]
  if llf:
   assert seq[5]==(5,1,1) and js[5][0][2]==js[5][1][2]==2 and seq[6]==(6,1,0)
   assert next(e for e in ds if e[0]==2 and e[9]==0)[7]<S+7*Q
   if ov:assert seq[7]==(7,1,2) and next(j[2][2] for e,j in zip(ds,js) if e[0]==1 and e[1]==7)==-2 and ref==9
  else:
   assert seq[:2]==[(0,3,0),(1,0,2)] and ds[2][9:11]==[2,0]
   if 'overrun' in d.name:assert any(e[17]&1 and e[1]==2 for e in ds)
  print(d.name,'rows',n,'peak IRQ entry lateness',max(e[7]-e[3] for e in ds if e[0]==1))

