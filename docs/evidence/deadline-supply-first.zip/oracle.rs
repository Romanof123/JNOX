#![allow(dead_code)]
#[path="/mnt/d/codex/jnox252-independent/kernel/src/deadline_jobs.rs"] mod deadline_jobs;
#[path="/mnt/d/codex/jnox252-independent/kernel/src/deadline_policy.rs"] mod deadline_policy;
#[path="/mnt/d/codex/jnox252-independent/kernel/src/ready_queue.rs"] mod ready_queue;
mod ordinary_deadline { pub fn counter()->u64 { unreachable!() } }
use deadline_jobs::*; use deadline_policy::*;
fn oracle(j:&[Job], mask:u64, llf:bool)->bool{
 let mut remaining=[0;3]; let mut ready=Vec::new(); let mut incumbent:Option<usize>=None;
 for tick in 0..=16{
  if j.iter().any(|x|x.deadline==tick && remaining[x.id]>0){return false}
  let held=(mask>>tick)&1==1;
  if held {if let Some(i)=incumbent.take(){ready.insert(0,i)}}
  for x in j.iter().filter(|x|x.release==tick){remaining[x.id]=x.cost;ready.push(x.id)}
  if held{continue}
  let rank=|i:usize|{let d=j.iter().find(|x|x.id==i).unwrap().deadline as i64; if llf {d-tick as i64-remaining[i] as i64} else {d}};
  if let Some((pos,&best))=ready.iter().enumerate().min_by_key(|&(_,i)|rank(*i)){
   if incumbent.is_none_or(|i|rank(best)<rank(i)){ready.remove(pos);if let Some(i)=incumbent.replace(best){ready.push(i)}}
  }
  if let Some(i)=incumbent{remaining[i]-=1;if remaining[i]==0{incumbent=None}}
 }
 true
}
fn main(){
 let mut n=0;let mut admit=0;
 for mask in 0..16{for llf in [false,true]{for variant in 0..216{for pair in 0..9{for order in [[0,1,2],[1,2,0],[2,1,0]]{
 let mut j=EDF;let mut v=variant;
 for x in &mut j {let i=x.id;x.release=if i==0{0}else{((pair/if i==1{1}else{3})%3) as u64};x.cost=1+v%2;x.deadline=x.release+2+v%3;v/=6;x.milliseconds=30;}
 let input=order.map(|i|j[i]);let predicted=oracle(&input,mask,llf);
 let actual=admit_with_supply(if llf{DeadlinePolicy::Llf}else{DeadlinePolicy::Edf},&input,1000,0,mask).is_ok();
 assert_eq!(actual,predicted,"mask={mask} llf={llf} v={variant} pair={pair} order={order:?}");
 n+=1;admit+=actual as usize;
 }}}}}
 println!("{n} comparisons; {admit} accepted; {} rejected",n-admit);
}
