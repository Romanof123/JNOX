set -eu
export CARGO_HOME=/home/ywcho/jnox-169-first-e203caa/cargo RUSTUP_HOME=/home/ywcho/jnox-169-first-e203caa/rustup
export PATH="$CARGO_HOME/bin:$PATH"
cd /mnt/d/codex/jnox252-raw
for t in deadline_supply_tests deadline_tests; do
 rustc +1.95.0 --edition 2024 --test "../jnox252-independent/tools/$t.rs" -o "/tmp/jnox252-$t"
 "/tmp/jnox252-$t" --test-threads=1 > "$t.txt"
done
rustc +1.95.0 --edition 2024 --cfg jnox_ordinary_deadline -O oracle.rs -o /tmp/jnox252-oracle
/tmp/jnox252-oracle > oracle.txt
