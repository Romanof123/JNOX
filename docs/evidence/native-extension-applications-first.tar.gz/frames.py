from pathlib import Path
from argparse import Namespace
import os,sys
sys.path.insert(0,str(Path.cwd()/"tools"))
from native_el0_capture import command,capture
out=Path(os.environ["out"])
import json,subprocess,re
name=sys.argv[1]
d=json.loads((out/(name+'-trace.replay')).read_text())
sym=subprocess.check_output(['aarch64-linux-gnu-nm','-nS',out/name/'kernel.elf'],text=True)
f=re.search(r'^(\w+) (\w+) T native_extension_evaluate$',sym,re.M)
lo=int(f[1],16);hi=lo+int(f[2],16)-1
filters=[f'{lo:#x}..{hi:#x}']+[f'{pc:#x}..{pc+3:#x}' for pc in sorted(set(d['expected_eret_pcs']))]
def factory(q,r,p):
    a=command(q,r,p); a[a.index("int")]="int,cpu,nochain"
    a+=["-dfilter",','.join(filters)]
    return a
args=Namespace(root=out/(name+"-frames"),kernel=out/name/"kernel.elf",user=out/"voltage.elf",probe=Path("examples/native-extension/voltage.c"),revision=(out/"source").read_text().strip(),manifest=None,arg=[],peer_arg=[],peer2_arg=[],qemu="qemu-system-aarch64",nm="aarch64-linux-gnu-nm",timeout=20,expect_exit=30,plain=False)
sys.exit(capture(args,command_factory=factory))
