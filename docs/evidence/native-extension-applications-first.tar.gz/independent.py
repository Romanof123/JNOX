import hashlib,json,os,re,struct,subprocess
from pathlib import Path
o=Path(os.environ['out']);mask=0xfffffffff000
def syms(p):
 t=subprocess.check_output(['aarch64-linux-gnu-nm','-nS',p],text=True)
 return {k:(int(a,16),int(z,16)) for a,z,k in re.findall(r'(?m)^([\da-f]+) ([\da-f]+) \w (\S+)$',t)}
apps=[syms(o/(n+'.elf')) for n in ('voltage','temperature','alarms')]
allruns={}
for name in ('accepted','cpu','fuel','stale','extended','sleep'):
 for mode in ('plain','trace','frames'):
  tag=name+'-'+mode;p=o/tag;uart=(p/'uart.bin').read_text(); rows=[list(map(int,r.split())) for r in re.findall(r'^NATIVE EXTENSION EVENT (.+)$',uart,re.M)]
  ver,epoch,f,q,*settings=map(int,re.search(r'CONFIG (.+)',uart)[1].split());assert f==62500000 and q==6250000 and settings==[5,2,3]
  decisions=[r for r in rows if r[18]<9]; owners=[r[10] for r in decisions]
  expected={'extended':[2,2,0,2,2,0,1,1,3,1],'sleep':[2,2,0,2,1,3,1,1,0],'accepted':[2,2,0,2,1,0,1,1]}.get(name,[1,1,0,1,2,0,2,2]);assert owners==expected
  assert all(not r[13] and not r[17] for r in rows)
  svc=[r for r in rows if r[0]==2];exits=[(r[9],r[33]) for r in svc if r[1]==1];assert sorted(exits)==[(0,30),(1,31),(2,32)]
  counter_bounds=[];service_lag=[]; evs=0
  for i,r in enumerate(decisions):
   start=epoch+i*q; owner=r[10]; assert r[1]==30 and r[38]&7==5 and r[37]==r[11]
   if i%3==2:assert r[18:20]==[7,0] and r[16]==0
   else:
    assert start<=r[16]<start+q//4<=r[2] and r[37]==start+q//4
    reason,steps=({'cpu':(1,1),'fuel':(2,5),'stale':(1,1)}.get(name,(0,2) if r[21]&4 else (6,2)));assert r[18:20]==[reason,steps];evs+=1
   upper=(next(x[2] for x in svc if x[5]==i and x[9]==owner and (x[1] in (1,8) or (name=='sleep' and i==2 and x[1]==6))) if owner!=3 else r[32])
   assert start<=upper<start+q//2;counter_bounds.append(upper-start)
   if i<len(decisions)-1:
    ends=next(x for x in rows if x[4]==i and x[5]==i+1)
    lag=ends[2]-(start+q);assert ends[0:2]==[1,30] and ends[37]==start+q and ends[38]&7==5 and 0<=lag<q//4;service_lag.append(lag)
  assert rows[-1][10]==4 and rows[-1][12]==0 and rows[-1][24]==7
  mem=(p/'ram.bin').read_bytes();base=json.loads((p/'launch.json').read_text())['ram_base'];roots=[next(x[29]&mask for x in svc if x[9]==i) for i in range(3)];assert len(set(roots))==3
  def read(i,key,fmt):
   va=apps[i][key][0]; table=roots[i]
   for shift in (30,21,12):
    d=struct.unpack_from('<Q',mem,table+8*((va>>shift)&511)-base)[0];assert d&3==3;table=d&mask
   assert d>>54&1 and (d>>6)&3==1
   return struct.unpack_from('<'+fmt,mem,table+(va&4095)-base)
  totals=[]
  for i,sums in enumerate(([6596,3304],[18,23,21],[65536]*(4 if name=='extended' else 3))):
   n=len(sums);counts=((2,1),(1,1,1),(1048576,)*n)[i]
   for k,fmt,exp in [('batch_sum','4Q',sums),('cumulative_sum','4Q',[sum(sums[:j+1]) for j in range(n)]),('batch_count','4I',counts)]:assert read(i,k,fmt)==tuple(exp)+(0,)*(4-n)
   totals.append(read(i,'private_result','Q')[0]);assert totals[-1]==sum(sums) and read(i,'private_batches','I')==(n,)
  d=dict(owners=owners,work_upper_ticks=counter_bounds,service_lag_ticks=service_lag,roots=roots,totals=totals,evaluations=evs)
  if mode=='frames':
   raw=(p/'exceptions.log').read_text()
   rec=[(int(pc,16),int(sp,16),int(ps,16),el) for pc,sp,ps,el in re.findall(r' PC=(\w+) X00=[^\n]+\n(?:X[^\n]+\n){9}X29=[^\n]+ SP=(\w+)\nPSTATE=(\w+) \S+ (EL\w+)',raw)]
   ker=syms(o/name/'kernel.elf'); a,z=ker['native_extension_evaluate']; stack,sz=next(v for k,v in ker.items() if 'EVALUATOR' in k)
   seen=[v for v in rec if a<=v[0]<a+z and v[3]=='EL1h' and not v[2]&128 and stack<=v[1]<stack+sz];assert seen
   # Each returned EL0 frame is sampled directly in QEMU at its next TB entry.
   needed=[(r[27],r[28]) for r in rows if r[10]<3 and r[31]]; observed=[(pc,sp) for pc,sp,ps,el in rec if el=='EL0t']
   cursor=iter(observed);assert all(any(v==pair for v in cursor) for pair in needed)
   d.update(unmasked_evaluator=seen[0],evaluator_samples=len(seen),external_EL0_frames=len(needed))
  allruns[tag]=d
print(json.dumps(allruns,indent=2))
