import subprocess as s,os,hashlib
from pathlib import Path
o=Path(os.environ['out']); n=o/'negative'; n.mkdir(); base=o/'accepted'
rule=base/'extension_program.txt'
files=[o/(k+'.elf') for k in ('voltage','temperature','alarms')]
cli=['python3','tools/build_native_el0.py','--out',str(n/'unexpected'),'--policy','extension','--elf',str(files[0]),'--peer-elf',str(files[1]),'--peer-elf',str(files[2]),'--extension-program',str(rule)]
env=dict(os.environ,JNOX_PROFILE='native',JNOX_APP='process',JNOX_BOARD='virt',JNOX_NATIVE_POLICY='extension',CARGO_TARGET_DIR=str(n/'target'))
for name,path in zip(['JNOX_NATIVE_ELF','JNOX_NATIVE_PEER_ELF','JNOX_NATIVE_PEER2_ELF'],files):
 env[name]=str(path); env[name+'_SHA256']=hashlib.sha256(path.read_bytes()).hexdigest()
def run(k,cmd,e,good=False):
 r=s.run(cmd,env=e,stdout=s.PIPE,stderr=s.STDOUT); (n/(k+'.log')).write_bytes(r.stdout); print(k,r.returncode,('OK' if (r.returncode==0)==good else 'UNEXPECTED'),flush=True)
raw=['python3','tools/build_kernel.py','--arch','aarch64']
for name,b in dict(valid=rule.read_bytes(),empty=b'\n',unreachable=b'yield\njump 2\n',overflow=b'propose 2 17 256 1\n',id=b'ready 3 0 0\n',extra=b'yield 1\n',opcode=b'call 0\n',size=b'yield\n'*17,decimal='jump ０\n'.encode(),badutf=b'\xff',wide=b'propose 4294967296 1 0 1\n',generation=b'propose 2 18446744073709551616 0 1\n',ticks=b'propose 2 17 0 18446744073709551616\n').items():
 p=n/(name+'.rule');p.write_bytes(b); e=dict(env,JNOX_NATIVE_EXTENSION_PROGRAM=str(p),JNOX_NATIVE_EXTENSION_SHA256=hashlib.sha256(b).hexdigest()); run('raw-'+name,raw,e,name=='valid')
 if name!='valid':run('cli-'+name,cli[:-1]+[str(p)],os.environ)
e=dict(env,JNOX_NATIVE_EXTENSION_PROGRAM=str(rule),JNOX_NATIVE_EXTENSION_SHA256='0'*64);run('raw-hash',raw,e)
e['JNOX_NATIVE_EXTENSION_SHA256']=hashlib.sha256(rule.read_bytes()).hexdigest()
for name,remove,add in [('missing-peer',['JNOX_NATIVE_PEER2_ELF','JNOX_NATIVE_PEER2_ELF_SHA256'],{}),('outside',[],{'JNOX_NATIVE_POLICY':'fixed'}),('mixed',[],{'JNOX_NATIVE_PRIORITIES':'1,2,3'})]:
 v=e.copy();v.update(add)
 for key in remove:v.pop(key)
 run('raw-'+name,raw,v)
run('cli-fourth',cli+['--peer-elf',str(files[1])],os.environ)
run('cli-missing-peer',cli[:9]+cli[11:],os.environ)
run('cli-outside',cli[:5]+['fixed']+cli[6:],os.environ)
run('cli-mixed',cli+['--priority','1'],os.environ)
