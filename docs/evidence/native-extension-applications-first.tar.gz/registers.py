from pathlib import Path
from argparse import Namespace
import os,sys
sys.path.insert(0,str(Path.cwd()/"tools"))
from native_el0_capture import command,capture
out=Path(os.environ["out"])
def factory(q,r,p):
    a=command(q,r,p); a[a.index("int")]="int,cpu,nochain"
    a+=["-dfilter","0x40203dfc..0x40203f7b,0x402014b8..0x402014df,0x400000..0x40004f"]
    return a
args=Namespace(root=out/"accepted-registers",kernel=out/"accepted/kernel.elf",user=out/"voltage.elf",probe=Path("examples/native-extension/voltage.c"),revision=(out/"source").read_text().strip(),manifest=None,arg=[],peer_arg=[],peer2_arg=[],qemu="qemu-system-aarch64",nm="aarch64-linux-gnu-nm",timeout=20,expect_exit=30,plain=False)
sys.exit(capture(args,command_factory=factory))
