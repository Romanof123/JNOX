from pathlib import Path
import struct,json,hashlib
e=Path(__file__).resolve().parent
w=struct.unpack('<79Q',(e/'ram.bin').read_bytes())
h=w[:9]; rows=[w[i:i+10] for i in range(9,59,10)]; runs=[w[i:i+6] for i in range(59,77,6)]
cost=[12500000,6250000]; sums=[]; q=[]; peak=0
for i,(r,b,id,allow) in enumerate(zip(rows,[1,2,9,8,3],[0,1,1,1,1],[50000000,50000000,0,12500000,50000000])):
 now=r[0]
 if i==3: assert q.pop(0)[1]==1
 rem=runs[0][2]+cost[0]-now if i>=3 else 0
 if i>=3: assert runs[0][2]<=now<=runs[0][3] and rem>0
 before=(len(q),sum(cost[x[0]] for x in q)); dl=now+allow
 finish=now+rem; ok=True
 for j,_,d in q+[(id,b,dl)]:
  finish+=cost[j];ok &= finish<=d
 if ok:q.append((id,b,dl))
 peak=max(peak,len(q))
 assert r==(now,id,b,dl,0 if ok else 3,*before,len(q),sum(cost[x[0]] for x in q),rem)
assert all(a[0]<=b[0] for a,b in zip(rows,rows[1:]))
assert q[0][1]==2 and q[1][1]==3
for i,(r,arr) in enumerate(zip(runs,[[3,1,4,1],[5,9,2,6],[5,3,5,8]])):
 id=int(i>0); s=sum(arr); sw=sum((j+1)*v for j,v in enumerate(arr)); sums.append((s,sw))
 assert r==(id,i+1,r[2],r[3],s,sw) and rows[[0,1,4][i]][0]<=r[2]<=r[3]<=min(r[2]+cost[id],rows[[0,1,4][i]][3])
 if i:assert runs[i-1][3]<=r[2]
assert rows[2][0]<=runs[0][2]
assert w[-2:]==tuple(map(sum,zip(*sums))) and h==(1,3,*cost,0,20,peak,5,3)
print(json.dumps(dict(header=h,decisions=rows,runs=runs,totals=w[-2:])))
def loads(f):
 d=f.read_bytes(); p=struct.unpack_from('<Q',d,32)[0]; size,n=struct.unpack_from('<HH',d,54)
 return b''.join(d[off:off+fs] for t,_,off,_,_,fs,_,_ in (struct.unpack_from('<II6Q',d,p+j*size) for j in range(n)) if t==1)
for f in sorted((e.parent/'base').glob('*/kernel.elf')):
 x=loads(e/(f.parent.name+'.elf')); y=loads(f);print(f.parent.name,len(x),hashlib.sha256(x).hexdigest(),len(y),hashlib.sha256(y).hexdigest(),x==y)
print('bounded LOAD',len(loads(e/'bounded.elf')))
