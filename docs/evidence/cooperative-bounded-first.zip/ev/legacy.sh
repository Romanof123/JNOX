set -eu
cd /mnt/d/codex/jnox253-first-independent
export CARGO_HOME=/home/ywcho/jnox-169-first-e203caa/cargo RUSTUP_HOME=/home/ywcho/jnox-169-first-e203caa/rustup
export PATH="$CARGO_HOME/bin:$PATH" CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR=$(mktemp -d)
{ rustc +1.95.0 -vV; cargo +1.95.0 -V; qemu-system-aarch64 --version; uname -a; } >ev/tools.txt
for dir in base/*/; do
 name=$(basename "$dir"); mode=${name##*-}; app=${name%-$mode}; profile=deadline
 case "$app" in coop-*) profile=fixed;; esac
 opts=("JNOX_BOARD=virt" "JNOX_PROFILE=$profile" "JNOX_APP=$app")
 if [[ $mode == trace ]]; then opts+=(JNOX_DEADLINE_TRACE=1); fi
 (cd src/kernel && set -x && env "${opts[@]}" cargo +1.95.0 build --release --locked -j1) >ev/$name.build 2>&1
 cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" ev/$name.elf
 if [[ $profile == fixed ]]; then timeout 3 qemu-system-aarch64 -M virt -cpu cortex-a53 -smp 1 -m 128M -nic none -nographic -monitor none -serial stdio -kernel ev/$name.elf >ev/$name.uart 2>ev/$name.err || test $? = 124; fi
done