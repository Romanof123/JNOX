#[path="../src/kernel/src/event_loop.rs"] mod event_loop;
#[path="../src/kernel/src/coop_bounded.rs"] mod coop_bounded;
use coop_bounded::*;
fn nop(_: &mut (), _:Request,_:&mut Post<'_>){}
fn req(d:u64)->Request{Request{handler:0,block:1,deadline:d}}
#[test]fn clock_after_refusal(){
 let mut s=Service::<(),3,1>::new([Handler{cost:5,call:nop}]);
 assert_eq!(s.post(req(500),10).decision,Decision::Accepted);
 assert_eq!(s.post(req(20),20).decision,Decision::Deadline);
 let r=s.post(req(500),15);
 assert_eq!(r.decision,Decision::InvalidInterval,"regressed 20 to 15 during a nonempty burst");
}
