"""Usage: python crossing.py path/to/ind238d01-first.zip > gen2.csv"""
import csv
import hashlib
import io
import json
import re
import sys
from pathlib import Path
from zipfile import ZipFile

data = Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(data).hexdigest() == "b1f46322f1c5ed73c7c28a8ef0cc033682453787a6507bde01d9e82a46a1de89"
keys = "irq observe_begin result_begin audit_begin audit_end schedule_begin mmu_begin publish_begin publish_end selected".split()
writer = csv.writer(sys.stdout, lineterminator="\n")
writer.writerow(["run", "release_tick", *keys, "pre_eret", "el0", "first_common_over", "first_recorded_over"])
runs = windows = misses = 0
with ZipFile(io.BytesIO(data)) as archive:
    read = lambda name: json.loads(archive.read(name))
    phase = {name.split("_")[1]: pair for name, pair in read("phase.json").items()}
    for name in sorted(archive.namelist()):
        match = re.fullmatch(r"evidence/(\d+-[pq]-(default|icount3)-[A-D])\.json", name)
        if not match:
            continue
        run, clock = match.groups()
        j = read(name)
        w = j["windows"]
        assert j["revision"] == "d01fd1587fb0563e1e8dd3d4eaeac39b9346e072" and j["frequency"] == 62500000
        over = [x["generation"] for x in w if x["user_tick"] - x["release"] > 62500]
        assert over == j["timing_misses"] and (not over or (over == [2] and clock == "default"))
        runs += 1
        windows += len(w)
        misses += len(over)
        cur = w[1]
        release = cur["release"]
        stamps = dict(irq=w[0]["irq_entry"], selected=cur["selected"], pre_eret=cur["return_sample"], el0=cur["user_tick"])
        common = next((k for k,v in stamps.items() if v-release > 62500), "")
        assert release == w[0]["close"]
        if run[-1] in "CD":
            pair = phase[run]
            assert pair["phase_sha256"] == j["session_sha256"]
            raw = pair["transitions"][0]["raw"]
            assert raw["irq"] == stamps["irq"] and raw["selected"] == stamps["selected"]
            stamps.update(raw)
        ordered = [(k, stamps[k]-release) for k in [*keys, "pre_eret","el0"] if k in stamps]
        assert [v for _,v in ordered] == sorted(v for _,v in ordered)
        first = next((k for k,v in ordered if v > 62500), "")
        values = dict(ordered)
        writer.writerow([run, release, *(values.get(k,"") for k in [*keys,"pre_eret","el0"]), common, first])
assert (runs, windows, misses) == (80, 920, 25)
