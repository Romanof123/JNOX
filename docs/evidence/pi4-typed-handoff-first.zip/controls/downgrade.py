from pathlib import Path
import sys
sys.path.insert(0,'src/tools')
from pi4_mg3_symbols import mg3_symbols
d=Path('frozen/stream-global')
raw=(d/'kernel8.img').read_bytes().replace(b'MG 4 BEGIN',b'MG 3 BEGIN')
try: mg3_symbols((d/'kernel.elf').read_bytes(),raw,'migration-global','sample-crc32-v1')
except ValueError as e: print('downgrade rejected',e)
else: raise AssertionError('downgrade accepted')