set -eu
export PYTHONPATH=$HOME/jnox-169-first-e203caa/deps
d=controls/sw1-bounded
h=$(sha256sum "$d/session.json" | cut -c1-64)
python3 src/tools/pi4_smp_replay.py "$d" "$h" > controls/sw1-corrected-reader.log