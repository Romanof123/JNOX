from pathlib import Path
import zipfile, subprocess, json, hashlib
D=Path.cwd()
for family,archive in [('mg3','pi4-migration-local-first'),('mg1','pi4-migration-first'),('mg2','pi4-migration-mg2-first'),('crc','pi4-crc-mainline-first')]:
    z=zipfile.ZipFile(D/f'src/docs/evidence/{archive}.zip')
    for m in [x for x in z.namelist() if x.endswith('freeze.json') and (family!='crc' or 'stream-' in x)]:
        p=m[:-11]
        out=D/'historical'/family
        for x in z.namelist():
            if x.startswith(p) and x.startswith(p+'first-') or x in [p+s for s in ('freeze.json','kernel.elf','kernel8.img','disassembly.txt')]:
                z.extract(x,out)
        for i in (1,2):
            d=out/p
            h=hashlib.sha256((d/f'first-{i}/session.json').read_bytes()).hexdigest()
            r=subprocess.run(['python3','src/tools/pi4_migration_replay.py',d,str(i),h],capture_output=True,text=True)
            stem=f'{family}-{d.parent.name if family=="crc" else d.name}-{i}'
            (D/f'controls/{stem}.log').write_text(r.stdout+r.stderr)
            print(stem,h,r.returncode, (json.loads(r.stdout).get('observation') if r.stdout.strip().startswith('{') else r.stderr[-150:]),flush=True)
