import json,re,zlib
from pathlib import Path
from functools import lru_cache
@lru_cache(None)
def history(stream,act):
    first,last,step=(0,4194304,1024) if stream and act==0 else [(0,65536,16),(0,32,16),(0,16,16),(16,32,16)][act]
    h=v=0; out={}
    for i in range(first+step,last+1,step):
        if step==1024:
            v=zlib.crc32(bytes((a^(a>>8)^(a>>16))%256 for a in range(i-step,i)),v)
        else:
            v+=step*(2*i-step+1)//2
        h=((((h<<7)|(h>>57))%(1<<64)^i)+v)%(1<<64)
        out[i]=(v,h)
    return out
def read(d,i):
    f=json.loads((d/'freeze.json').read_text()); sym=f['local_symbols']; local=lambda s:sym['PI4_MIG_'+s]['address']
    p=d/f'first-{i}'; raw=(p/'uart.bin').read_text(); threads=json.loads((p/'threads.json').read_text())
    sections=[[],[]]; saved={}; lives={}; sums=[]; irq=None; dst=None
    bounds=f['loop_range']
    for line in raw.splitlines():
        if not line.startswith('MG ROW'): continue
        c,seq,k,*a=map(int,line.split()[2:]); r=sections[c]; assert seq==len(r)<96; r.append((k,a)); prev=r[-2][1] if seq else []
        if k==4 and a[0:2]==[0,0] and a[6]!=65535: irq=a
        if k==11 and a[:2]==[1,0]: dst=(c,a)
        if k not in (14,15,13): continue
        if k==13:
            task,epoch,lease,n,h,index,v,res=a; act=task+(task==2 and epoch==1)
            ref=history('stream' in d.name,act); assert n==len(ref) and index==max(ref) and ref[index]==(v,h)
            sums.append((act,n,h,index,v)); continue
        task,t,l=a[:3]; act=t-0x10601; ptr=local('TLS_'+['M','P0','P1_OPEN','P1_REPLACEMENT'][act]); base=local('CPU'+str(c))
        assert task==min(act,2) and 0<=act<=3
        if k==14:
            assert r[-2][0]==4 and prev[1]==task and (prev[0]==1)==(act==3) if task==2 else r[-2][0]==4 and prev[1]==task
            assert a[3:]==[prev[2],ptr,t,base,l]; saved[l]=(c,ptr,t)
        else:
            assert r[-2][0]==5 and (prev[0],prev[2],prev[3])==(task,l,a[6]) and a[3:6]==[base,ptr,t]
            assert history('stream' in d.name,act)[a[6]]==(prev[4],a[7]); lives[l]=(c,ptr,t)
    assert len(sums)==4 and len(lives)==len(saved)==5 and lives==saved
    c,a=dst; pc=irq[3]; assert [a[3],a[4],a[5],a[6]]==[irq[2],pc,irq[4],irq[5]]
    assert lives[a[2]][1:]==saved[1][1:] and c==lives[a[2]][0] and saved[1][0]==0
    traces={int(v.split()[1][0]):(p/f'observer-{tid}.log').read_text() for tid,v in threads.items() if (p/f'observer-{tid}.log').is_file()}
    assert re.search(r'Taking exception 5 \[IRQ\] on CPU 0\n(?:\.\.\.[^\n]*\n)*?\.\.\.with ELR '+hex(pc)+r'\n',traces[0])
    assert 'Exception return from AArch64 EL1 to AArch64 EL1 PC '+hex(pc)+'\n' in traces[c]
    return dict(image=d.name,i=i,rows=list(map(len,sections)),saved=len(saved),live=len(lives),source=0,dest=c,pc=hex(pc),loop=list(map(hex,bounds)),inner=bounds[0]<=pc<bounds[1],M=sorted(sums)[0])

import struct
def more(d,i):
    raw=(d/f'first-{i}'/'uart.bin').read_text()
    rows=[tuple(map(int,l.split()[2:])) for l in raw.splitlines() if l.startswith('MG ROW')]
    if not rows:
        assert 'M FINISHED BEFORE IRQ' in raw and raw.rstrip().endswith('001d')
        return dict(name=d.name,ordinal=i,typed=[None,None],terminal=None)
    verified=read(d,i)
    tuples={}
    for edge,src,dst in [(1,1,0),(2,0,1)]:
        pub,=[r for r in rows if r[2:4]==(16,edge)]
        con,=[r for r in rows if r[2:4]==(17,edge)]
        assert pub[0]==src and con[0]==dst and pub[3:]==con[3:]
        ed,ep,t,lease,ret,ptr,ver,orig=pub[3:]
        claim,=[r for r in rows if r[2:6]==(2,ep,t,lease)]
        disp,=[r for r in rows if r[0]==dst and r[2:6]==(11,ep,t,lease)]
        signal=[r for r in rows if r[0]==src and r[2]==7 and r[1]>pub[1]]
        assert signal and claim[6]==disp[6]
        if edge==1:
            retire,=[r for r in rows if r[0]==src and r[2:6]==(3,0,2,ret)]
            assert retire[1]<pub[1] and (ptr,ver,orig)==(0,0,0)
        else:
            assert con[1]<disp[1] and ptr==disp[6] and ver==2 and ret==0
            if 'global' in d.name:
                trap,=[r for r in rows if r[2:5]==(4,0,0) and r[9]!=65535]
                assert orig==2 and trap[5]==ptr and t==0
            else:
                init,=[r for r in rows if r[2:5]==(2,0,2)]
                assert orig==1 and init[6]==ptr and t==2
        tuples[edge]=pub[3:]
    return dict(**verified,typed=tuples)
if __name__=='__main__':
    out=[more(d,i) for d in sorted(Path('frozen').iterdir()) for i in (1,2)]
    for n in ('D1','D2'):
        d=Path('diagnostic')/n/'first-1'
        words=struct.unpack('<32Q',(d/'pi4_handoff_terminal_v1.bin').read_bytes())
        assert words[:4]==(0x3130524554464f48,1,256,0) and not words[-1]
        assert (words[4],words[13])==((1,0) if n=='D1' else (2,2))
        assert words[5:13]==(1,0,0,1,2,0,0,0)
        assert words[14:22]==((0,)*8 if n=='D1' else (2,1,0,4,0,words[22],2,2))
        assert words[23:25]==((1,1) if n=='D1' else (2,2)) and words[26:28]==(1,1) and words[29:31]==((1,1) if n=='D1' else (2,1))
        out.append(dict(position=n,words=words))
    print(json.dumps(out,indent=2))