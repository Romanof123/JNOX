import struct,json,hashlib
from pathlib import Path
for label in ['D1','D2']:
    root=Path('diagnostic')/label
    d=root/'first-1'
    log=(d/'LOG.bin').read_bytes()
    rows=[]
    for cpu in range(2):
        base=cpu*6944
        used,lost,_,seal=struct.unpack_from('<3QB',log,base+6912)
        assert used<=96 and not lost and seal in (0,1)
        for j in range(used):
            *a,k=struct.unpack_from('<9Q',log,base+j*72)
            rows.append((cpu,j,k,a))
    phases=[];slots=[]
    for edge,src,dst in [(1,1,0),(2,0,1)]:
        pub=[a for c,j,k,a in rows if c==src and k==16 and a[0]==edge]
        con=[a for c,j,k,a in rows if c==dst and k==17 and a[0]==edge]
        assert len(pub)<=1 and len(con)<=1 and (not con or con==pub)
        phases.append(len(pub)+len(con));slots.extend([phases[-1],*(pub[0] if pub else [0]*8)])
    installs=[]
    for task in range(3):
        stack,=[a for c,j,k,a in rows if k==1 and a[0]==task]
        ptr,ver,origin=stack[2]-832,1,1
        if label=='D2' and task==0:
            saved,=[a for c,j,k,a in rows if c==0 and k==4 and a[:2]==[0,0] and a[6]!=65535]
            ptr,ver,origin=saved[2],2,2
        if label=='D2' and task==2: ver=2
        installs.extend([ptr,ver,origin])
    expected=struct.pack('<32Q',0x3130524554464f48,1,256,0,*slots,*installs,0)
    actual=(d/'pi4_handoff_terminal_v1.bin').read_bytes()
    assert actual==expected
    if label=='D2':
        rows_uart=[tuple(map(int,l.split()[2:])) for l in (d/'uart.bin').read_text().splitlines() if l.startswith('MG ROW')]
        assert rows_uart==[(c,j,k,*a) for c,j,k,a in rows]
    print(label,phases,installs,hashlib.sha256(actual).hexdigest(),len(rows))