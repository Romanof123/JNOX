export PYTHONPATH=$HOME/jnox-169-first-e203caa/deps
mkdir -p readers
for w in short stream; do
for p in global partitioned clustered; do
for n in 1 2; do
key=$w-$p-$n
python3 src/tools/pi4_migration_replay.py frozen/$w-$p $n "$(cat "$key.log")" > readers/$key.json
done
done
done