from pathlib import Path
import shutil,json,hashlib
for path,item in json.loads(Path('duplicates.json').read_text()).items():
    ref,digest=item
    assert hashlib.sha256(Path(ref).read_bytes()).hexdigest()==digest
    Path(path).parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(ref,path)
