from pathlib import Path
import hashlib,json,zipfile
p=Path('.')
def hashfile(f):return hashlib.sha256(f.read_bytes()).hexdigest()
duplicates={};seen={}
restore="""from pathlib import Path
import shutil,json,hashlib
for path,item in json.loads(Path('duplicates.json').read_text()).items():
    ref,digest=item
    assert hashlib.sha256(Path(ref).read_bytes()).hexdigest()==digest
    Path(path).parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(ref,path)
"""
with zipfile.ZipFile('/mnt/d/codex/jnox281-first.zip','w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for f in sorted(p.rglob('*')):
        if f.parts[0] in ('src','target','historical','diag-view','__pycache__') or not f.is_file() or f.name in ('raw','dis','host-tests'):continue
        if f.suffix in ('.elf','.img') or f.name=='disassembly.txt':
            h=hashfile(f)
            if h in seen:
                duplicates[str(f)]=[seen[h],h];continue
            seen[h]=str(f)
        z.write(f,str(f))
    z.writestr('restore.py',restore);z.writestr('duplicates.json',json.dumps(duplicates,indent=2))
with zipfile.ZipFile('/mnt/d/codex/jnox281-first.zip') as z: assert z.testzip() is None