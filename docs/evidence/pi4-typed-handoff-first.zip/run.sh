set -eu
export PYTHONPATH=$HOME/jnox-169-first-e203caa/deps
mapfile -t dig < freeze-digests
python3 src/tools/pi4_mg4_terminal.py freeze diagnostic frozen/short-clustered "${dig[2]}" frozen/stream-global "${dig[3]}" > diagnostic-sha
i=0
for w in short stream; do
for p in global partitioned clustered; do
for n in 1 2; do
python3 src/tools/pi4_migration_capture.py run frozen/$w-$p "${dig[i]}" $n > "$w-$p-$n.log" 2>&1 || echo "$?" >> "$w-$p-$n.log"
done
i=$((i+1))
done
done
for n in D1 D2; do
python3 src/tools/pi4_mg4_terminal.py run diagnostic "$(cat diagnostic-sha)" $n > "$n.log" 2>&1 || echo "$?" >> "$n.log"
done
