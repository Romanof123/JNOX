import sys,json,struct
from pathlib import Path
from independent import more
tmp=Path('diag-view'); tmp.mkdir(exist_ok=True)
v=tmp/'stream-global'
if not v.exists(): v.symlink_to(Path('diagnostic/D2').resolve(),target_is_directory=True)
record=more(v,1)
base=json.loads((v/'map.json').read_text())['STACKS'][0]
words=struct.unpack_from('<39Q',(v/'first-1/STACKS.bin').read_bytes(),601840-base)
# A resumed worker can overwrite a once-installed frame. Record observed stopped bytes only.
print(json.dumps(dict(verification=record,stopped_frame_prefix=words),indent=2))