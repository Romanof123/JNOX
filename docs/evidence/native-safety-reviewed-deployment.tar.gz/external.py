from pathlib import Path
import json,subprocess,hashlib,sys,shutil
d,r,old=map(Path,sys.argv[1:])
pin=(d/'freeze.txt').read_text().splitlines()[1].split()[1]
spec=d/'reviewed-profile.json'; example=d/'native_safety_deployment_example.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def invoke(case,out,args):
 z=subprocess.run([sys.executable,str(d/'native_safety_admission.py'),str(case),*map(str,args)],capture_output=True)
 out.write_bytes(z.stdout)
 j=json.loads(z.stdout);return [z.returncode,len(j.get('segments',[])),j.get('input_error'),j.get('deployment_profile_sha256')]
def flags(f,h):return ['--deployment-profile',f,'--deployment-profile-sha256',h]
v=d/'corrected';(v/'results').mkdir(parents=True,exist_ok=True)
for case in sorted(list(r.glob('rr-*'))+list(r.glob('fifo-*'))):
 ans=invoke(case,v/'results'/(case.name+'.json'),flags(spec,pin))
 assert ans==[1,40,None,pin]
controls=d/'profile-controls';controls.mkdir(exist_ok=True);table=[]
def go(name,case,args,expected):
 ans=invoke(case,controls/(name+'.json'),args)
 table.append([name]+ans);assert ans[:2]==expected,(name,ans)
p=r/'fifo-healthy';o=old/'fifo-healthy'
go('corrected-default',p,[],[2,0])
go('original-example',o,flags(example,sha(example)),[1,40])
go('no-fallback',old/'rr-healthy',flags(example,sha(example)),[2,0])
go('digest-only',p,['--deployment-profile-sha256',pin],[2,0])
go('file-only',p,['--deployment-profile',spec],[2,0])
go('wrong-digest',p,flags(spec,'0'*64),[2,0])
go('missing-profile',p,flags(d/'absent.json',pin),[2,0])
for key in ('cpu','slots','policy','case'):
 data=json.loads(spec.read_bytes());entry=data['positions']['fifo-healthy']
 if key=='cpu':data['platform']['cpu']='cortex-a53'
 if key=='slots':entry['slot_sha256'].reverse()
 if key=='policy':entry['policy']='rr'
 if key=='case':del data['positions']['fifo-healthy']
 f=controls/(key+'-input.json');f.write_text(json.dumps(data))
 go('profile-'+key,p,flags(f,sha(f)),[2,0])
# Deliberate changes on a scratch copy only. Rebind its local launch receipt to test independent pin.
scratch=r/'external-mutation';shutil.copytree(p,scratch,dirs_exist_ok=True)
for key in ('policy','option'):
 m=json.loads((p/'pkg/manifest.json').read_bytes());l=json.loads((p/'cap/launch.json').read_bytes());s=json.loads((p/'cap/session.json').read_bytes())
 if key=='policy':m['policy']='rr'
 else:m['package_argv']+=['--safety-interference']
 l['argument_package']=m;(scratch/'pkg/manifest.json').write_text(json.dumps(m));(scratch/'cap/launch.json').write_text(json.dumps(l));s['hashes']['launch.json']=sha(scratch/'cap/launch.json');(scratch/'cap/session.json').write_text(json.dumps(s))
 go('changed-package-'+key,scratch,flags(spec,pin),[2,0])
(d/'external-controls.json').write_text(json.dumps(table,indent=1))