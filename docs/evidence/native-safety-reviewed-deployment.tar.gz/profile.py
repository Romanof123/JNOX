from pathlib import Path
import json,subprocess,tarfile,hashlib,sys
from native_safety_admission import deployment_digest
d,r,build,mirror=map(Path,sys.argv[1:])
pin='5aef9adee569dfe1ea1b259f491157ec636eef82710c0b8b560b2a1291349bf8'
rev='7c5b0c2d20f1404f433cc0bf972d790f6a3faa45'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(mirror/'corrected.tar.gz')==pin
with tarfile.open(mirror/'corrected.tar.gz') as t:
 receipt=t.extractfile('SHA256SUMS').read().decode()
assert receipt==(mirror/'SHA256SUMS').read_text()
members={n.removeprefix('./'):h for h,n in (z.split(None,1) for z in receipt.splitlines())}
def git(*args):return subprocess.check_output(['git','-C',str(build/'src'),*args],text=True).strip()
assert git('rev-parse','HEAD')==rev and not git('status','--porcelain','--untracked-files=no')
x=json.loads((d/'native_safety_deployment_example.json').read_text());x['positions']={}
slots=[sha(build/(role+'.elf')) for role in ('sender','controller','supervisor')]
assert slots==[members[role+'.elf'] for role in ('sender','controller','supervisor')]
r.mkdir(exist_ok=True)
for archive in sorted(list(mirror.glob('fifo-*.tgz'))+list(mirror.glob('rr-*.tgz'))):
 n=archive.stem;assert sha(archive)==members[archive.name];p=r/n;p.mkdir(exist_ok=True)
 with tarfile.open(archive) as t:t.extractall(p)
 h=build/n/'pkg';m=json.loads((h/'manifest.json').read_bytes());kernel=sha(h/'kernel.elf')
 assert (h/'manifest.json').read_bytes()==(p/'pkg/manifest.json').read_bytes() and kernel==sha(p/'pkg/kernel.elf')==m['kernel_elf_sha256']
 assert m['commit']==rev and m['tracked_changes']=='' and m['policy']==n.split('-')[0]
 assert [s['priority'] for s in m['slots']]==[6,7,4] and [s['elf_sha256'] for s in m['slots']]==slots
 assert [sha(h/f) for f in ('user.elf','native_peer.elf','native_peer2.elf')]==slots
 assert m['quantum_ticks']==(625000 if m['policy']=='rr' else None)
 cmd=m['package_argv']; assert '--safety-qualification' in cmd and '--safety-channel' in cmd and ('--safety-interference' in cmd)==n.endswith('-irq')
 sym=subprocess.check_output(['aarch64-linux-gnu-nm','--defined-only',str(h/'kernel.elf')],text=True)
 addr={z.split()[-1]:int(z.split()[0],16) for z in sym.splitlines() if z.split()[-1] in ('_start','__stack_top')}
 extent=addr['__stack_top']-addr['_start'];assert addr['_start']==0x40200000 and extent==(p/'cap/ram.bin').stat().st_size
 x['positions'][n]=dict(policy=m['policy'],commit=rev,manifest_sha256=deployment_digest(m),kernel_sha256=kernel,slot_sha256=slots,ram_bytes=extent)
assert len(x['positions'])==24
out=d/'reviewed-profile.json';out.write_text(json.dumps(x,indent=2)+'\n')
(d/'freeze.txt').write_text(f'original_release {pin}\nreviewed_profile {sha(out)}\nsource_commit {rev}\nsource_tree {git("rev-parse","HEAD^{tree}")}\n')