#!/bin/bash
set -u
export PATH="$HOME/.cargo/bin:$PATH" PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
d=$HOME/iv355-s-data
cd "$HOME/iv355-s-src"
q=$HOME/arm-speed-lab-tools/qemu-11.1.3/build/qemu-system-aarch64
record() { name=$1; shift; printf '%q ' "$@" >>"$d/commands"; echo >>"$d/commands"; "$@" >"$d/$name.log" 2>&1; rc=$?; echo "$name $rc" >>"$d/status"; return $rc; }
record calendar sh sdk/native-aarch64/build.sh examples/native-fixed/calendar_report.c "$d/calendar.elf" || exit 1
p=(python3 tools/build_native_el0.py --board pi4 --elf "$d/low.elf" --priority 2 --peer-elf "$d/high.elf" --peer-priority 2)
s=(--policy smp-partitioned --cpu-mask 1 --peer-cpu-mask 2)
record zero "${p[@]}" --out "$d/zero" --policy smp-partitioned --cpu-mask 0 --peer-cpu-mask 2
record outside "${p[@]}" --out "$d/outside" --policy smp-partitioned --cpu-mask 1 --peer-cpu-mask 4
record extra "${p[@]}" --out "$d/extra" "${s[@]}" --peer-elf "$d/calendar.elf" --peer-priority 4 --peer-cpu-mask 2 --peer-elf "$d/calendar.elf" --peer-priority 4 --peer-cpu-mask 1
record virt python3 tools/build_native_el0.py --out "$d/virt" --board virt "${s[@]}" --elf "$d/low.elf" --priority 2 --peer-elf "$d/high.elf" --peer-priority 2
record pair "${p[@]}" --out "$d/pair" "${s[@]}"
record remote "${p[@]}" --out "$d/remote" "${s[@]}" --peer-elf "$d/calendar.elf" --peer-priority 4 --peer-cpu-mask 2 --release-cell 0 --peer-release-cell 0 --peer-release-cell 1
record swapped "${p[@]}" --out "$d/swapped" --policy smp-partitioned --cpu-mask 2 --peer-cpu-mask 1
record legacy "${p[@]}" --out "$d/legacy" --policy fifo
for pos in 1 2 3 4 5 6; do
 case $pos in 1|2) pkg=pair;;3|4) pkg=remote;;5) pkg=swapped;;6) pkg=legacy;;esac
 test -f "$d/$pkg/manifest.json" || continue
 opts=(); [[ $pos != 2 && $pos != 4 ]] || opts=(--trace)
 record "p$pos-capture" python3 tools/pi4_native_smp_capture.py "$d/$pkg" "$d/p$pos" --qemu "$q" "${opts[@]}"
 if test -f "$d/p$pos/session.json"; then
  hash=$(sha256sum "$d/p$pos/session.json"|cut -d' ' -f1)
  record "p$pos-replay" python3 tools/pi4_native_smp_replay.py "$d/p$pos" --session-sha256 "$hash" --candidate-register 8 11
 fi
done
