import pathlib,re,struct,json
out={}
for i in range(1,6):
 p=pathlib.Path('p'+str(i));d=(p/'ram.bin').read_bytes();base=json.loads((p/'launch.json').read_text())['ram_base'];s=(p/'uart.bin').read_text()
 def words(a,n):return struct.unpack_from('<%dQ'%n,d,a-base)
 rows=[]
 for core,addr,used,width,lost,frames,size in [list(map(int,l.split())) for l in re.findall(r'NATIVE SMP JOURNAL ([0-9 ]+)',s)]:
  for k in range(used):
   r=words(addr+k*width*8,width);f=words(frames+2*k*size,102)
   rows.append(dict(cpu=core,k=k,kind=r[2],op=r[3],entry=r[4],decision=r[5],src=r[6],dst=r[7],lease=r[8],service=r[9],release=r[14],publish=r[15],send=r[16],receive=r[17],wake=r[19],pc=hex(f[32]),index=f[8 if r[6]==0 else 11],tls=f[-2:]))
 out[str(i)]=rows
 if i in [3,4]:
  print('P',i,re.findall(r'NATIVE SMP (?:CONFIG|CAL) [0-9 ]+',s))
  for r in rows:
   if r['release']&4 or r['receive']&4 or r['src']==2 or r['wake']&4: print(r)
pathlib.Path('events.json').write_text(json.dumps(out,indent=1))
