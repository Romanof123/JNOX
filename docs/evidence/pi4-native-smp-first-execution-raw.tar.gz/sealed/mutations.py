from pathlib import Path
import shutil,tempfile,subprocess,json,hashlib,struct,re
src=Path('p3').resolve();replay=Path.home()/'iv355-s-src/tools/pi4_native_smp_replay.py'
sha=lambda b:hashlib.sha256(b).hexdigest()
journals=[list(map(int,s.split())) for s in re.findall(r'NATIVE SMP JOURNAL ([0-9 ]+)',(src/'uart.bin').read_text())]
for name,cpu,row,field,value in [('double-grant',1,3,6,2),('double-release',0,2,14,4),('wrong-charge',1,3,9,9999999),('missing-receive',1,3,17,0)]:
 with tempfile.TemporaryDirectory() as raw:
  root=Path(raw)
  for f in src.iterdir():
   if f.name not in ('ram.bin','session.json'):(root/f.name).symlink_to(f)
  b=bytearray((src/'ram.bin').read_bytes());addr=journals[cpu][1];struct.pack_into('<Q',b,addr-0x2000000+(37*row+field)*8,value);(root/'ram.bin').write_bytes(b)
  s=json.loads((src/'session.json').read_bytes());s['files']['ram.bin']=sha(b);z=json.dumps(s).encode();(root/'session.json').write_bytes(z)
  r=subprocess.run(['python3',str(replay),str(root),'--session-sha256',sha(z),'--candidate-register','8','11'],capture_output=True,text=True)
  print(name,r.returncode,r.stderr.strip() or json.loads(r.stdout)['unresolved']);assert r.returncode!=0
