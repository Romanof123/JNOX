"""Independent Release checks on the frozen IPC-005 first packet and matched disabled ELF."""
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import sys

raw, control = map(Path, sys.argv[1:])
revision = "66d988a0772fac3fd305b83bb123c5d966ea5f23"
page = 4096
pa_mask = 0xfffff000
aperture = 0x1600000
attributes = (3 | 3 << 8 | 1 << 10 | 1 << 6 | 1 << 11 | 1 << 53 | 1 << 54)

def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()

def objdump(file):
    return subprocess.check_output(["aarch64-linux-gnu-objdump", "-dC", file], text=True)

def syms(file):
    result = {}
    for line in subprocess.check_output(["aarch64-linux-gnu-nm", "-nS", file], text=True).splitlines():
        fields = line.split()
        if len(fields) == 4:
            result[fields[3]] = (int(fields[0], 16), int(fields[1], 16))
    return result

def instructions(dis, symbol):
    body = re.search(r"^[0-9a-f]+ <" + re.escape(symbol) + r">:\n(.*?)(?:\n\n|\Z)", dis, re.M | re.S)
    assert body, symbol
    return body[1]

def inspect_pages(dump, base, roots, tables, pool, stage):
    ram = dump.read_bytes()
    table_pages = set()
    accessible_pages = set()
    pool_aliases = {}
    for pid, root in enumerate(roots):
        def visit(table, level, va):
            table_pages.add(table)
            assert base <= table <= base + len(ram) - page
            for index, pte in enumerate(struct.unpack_from("<512Q", ram, table - base)):
                if pte & 1 == 0:
                    continue
                assert pte & 3 == 3
                next_va = va | index << (30 - level * 9)
                address = pte & pa_mask
                if level < 2:
                    if next_va == aperture and level == 1:
                        assert address == tables + pid * page
                    visit(address, level + 1, next_va)
                    continue
                if pte & (1 << 6):
                    accessible_pages.add(address)
                    if pool <= address < pool + 3 * page:
                        pool_aliases[(pid, next_va)] = pte
        visit(root, 0, 0)
    assert not table_pages.intersection(accessible_pages)
    owner = {1: 0, 3: 1, 5: 0}.get(stage)
    expected = {} if owner is None else {(owner, aperture): pool | attributes | (128 if stage == 3 else 0)}
    assert pool_aliases == expected, (dump, pool_aliases, expected)
    if stage:
        pattern = bytes((13 + 7 * i) % 256 for i in range(page))
        content = pattern if stage == 1 else pattern[:113] + bytes(page - 113)
        if stage == 5:
            content = bytes(page)
        assert ram[pool - base:pool - base + page] == content
    return len(table_pages)

cases = sorted(raw.glob("cap-*/launch.json"))
assert len(cases) == 11
for launch_path in cases:
    cap = launch_path.parent
    name = cap.name.removeprefix("cap-")
    pkg = raw / ("pkg-" + name)
    launch = json.loads(launch_path.read_bytes())
    manifest = json.loads((pkg / "manifest.json").read_bytes())
    assert launch["argument_package"] == manifest
    assert launch["revision"] == manifest["commit"] == revision and not manifest["tracked_changes"]
    options = launch["argv"]
    assert [options[options.index(k)+1] for k in ("-cpu","-smp","-accel","-machine")] == [
        "cortex-a72","1","tcg","virt,gic-version=2"]
    kernel = pkg / "kernel.elf"
    assert sha(kernel) == manifest["kernel_elf_sha256"]
    assert launch["qemu_sha256"] == "0a63468782d096485932acf6aa0a69d358b3e3a6f68f655e960e9f5e3fc578d8"
    for item, digest in json.loads((cap / "session.json").read_bytes())["hashes"].items():
        assert sha(cap / item) == digest, (name, item)
    uart = (cap / "uart.bin").read_text()
    elf_names = re.findall(r"^NATIVE EL0 (?:PEER2? )?ELF ([a-f0-9]{64})$", uart, re.M)
    assert elf_names == [sha(pkg / s["elf"]) for s in manifest["slots"]] == [s["elf_sha256"] for s in manifest["slots"]]
    drops = int(re.search(r"^NATIVE FIXED DROPPED (\d+)$", uart, re.M)[1])
    assert drops == {"official-fifo":2828, "official-rr":2611}.get(name, 0)
    if name == "disabled":
        assert "NATIVE LOAN" not in uart and "loan_route" not in manifest
        print(name, "no loan selector, two exits 84", "scheduler drops", drops)
        assert uart.count(" 84\n") >= 2 and "NATIVE EL0 EXIT PID 0 84\n" in uart and "NATIVE EL0 EXIT PID 1 84\n" in uart
        continue
    n = len(elf_names)
    symbols = syms(kernel)
    pool, pool_size = symbols["jnox_native_loan_pages"]
    tables, table_size = symbols["jnox_native_loan_l3_tables"]
    assert pool_size == page * 3 and table_size == n * page
    roots_base, roots_size = next(v for k,v in symbols.items() if "6SPACES" in k)
    roots = [roots_base + i * (roots_size // n) for i in range(n)]
    visited = inspect_pages(cap / "ram.bin", launch["ram_base"], roots, tables, pool, 0)
    stages = sorted(cap.glob("ram-*.bin"))
    assert len(stages) == (5 if name.startswith("stages") else 0)
    for s, snapshot in enumerate(stages, 1):
        inspect_pages(snapshot, launch["ram_base"], roots, tables, pool, s)
    state = list(map(int, re.search(r"^NATIVE LOAN STATE (.+)$",uart,re.M)[1].split()))
    maps = uart.count("\nNATIVE LOAN MAP ")
    assert state[0] == state[1] and state[2] == state[4] == state[5] == state[7] == 0
    assert state[6] == maps
    dis = objdump(kernel)
    service = instructions(dis, "jnox_kernel::native_el0::loans::service")
    assert re.search(r"\bldar\b", service) and re.search(r"\bstlr\b", service)
    assert re.search(r"\bstr\s+x\d+, \[x\d+\]\n[^\n]+dsb\s+ishst\n[^\n]+tlbi\s+vae1is, x\d+\n[^\n]+dsb\s+ish\n[^\n]+isb\b", dis)
    print(name, "roots", n, "reachable table pages", visited, "physical snapshots", 1 + len(stages),
          "head/tail/peak", [state[0],state[1],state[3]], "loan rows", maps, "scheduler drops", drops)

enabled = json.loads((raw / "pkg-official-fifo/manifest.json").read_bytes())
disabled = json.loads((control / "manifest.json").read_bytes())
for k in ("commit", "tracked_changes", "policy", "quantum_ticks", "rust", "cargo", "kernel_command"):
    assert enabled[k] == disabled[k], k
assert len(enabled["slots"]) == len(disabled["slots"]) == 2
for a, b in zip(enabled["slots"], disabled["slots"]):
    for k in ("slot", "elf", "elf_sha256", "argv", "priority"):
        assert a[k] == b[k], k
    assert sha(control / b["elf"]) == a["elf_sha256"]
assert "loan_route" not in disabled and sha(control / "kernel.elf") == disabled["kernel_elf_sha256"]
print("Matched FIFO control kernel SHA-256", disabled["kernel_elf_sha256"])
