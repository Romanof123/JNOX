#!/usr/bin/env bash
set -euo pipefail
source "$HOME/.cargo/env"
export CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true
raw=${1:?first evidence directory}
src=${2:?candidate checkout}
out=${3:?output directory}
cd "$src"
test "$(git rev-parse HEAD)" = 66d988a0772fac3fd305b83bb123c5d966ea5f23
test -z "$(git status --porcelain --untracked-files=no)"
mkdir -p "$out"
python3 tools/build_native_el0.py --out "$out/disabled" --elf "$raw/writer.elf" --peer-elf "$raw/reader.elf" --priority 7 --peer-priority 1 --policy fifo > "$out/package.log" 2>&1
for side in "$raw/pkg-official-fifo" "$out/disabled"; do
  aarch64-linux-gnu-size "$side/kernel.elf"
  aarch64-linux-gnu-readelf -lW "$side/kernel.elf"
  sha256sum "$side/kernel.elf" "$side/user.elf" "$side/native_peer.elf"
  stat -c '%s bytes, %n' "$side/kernel.elf"
done > "$out/size.txt"
