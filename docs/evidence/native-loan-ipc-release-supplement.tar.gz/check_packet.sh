#!/usr/bin/env bash
set -euo pipefail
first=${1:?first archive}
fresh=${2:?new extraction directory}
control=${3:?matched control package}
scriptdir=$(cd "$(dirname "$0")" && pwd)
test "$(sha256sum "$first" | cut -d' ' -f1)" = 01490e47c75da831bf32fc0a31b78db8e194c7d7ac24076ad72a09c842468c8e
mkdir "$fresh"
tar -xzf "$first" -C "$fresh"
cd "$fresh"
sha256sum --quiet -c SHA256SUMS
python3 verify.py . > first-recalculated.json
cmp results.json first-recalculated.json
python3 "$scriptdir/check_release.py" . "$control"
