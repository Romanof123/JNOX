from pathlib import Path
import subprocess as s
for d in Path(__file__).parent.glob('images/*'):
 for tool,opts,name in [('objdump','-dC','linked'),('nm','-nSC','symbols')]:
  with (d/(name+'.txt')).open('wb') as f:s.run(['aarch64-linux-gnu-'+tool,opts,d/'kernel.elf'],stdout=f,check=True)
