import struct, hashlib, json
from pathlib import Path
p=Path(__file__).parent
def elf(f):
 b=f.read_bytes(); sh=struct.unpack_from('<Q',b,40)[0]; sz,n,si=struct.unpack_from('<HHH',b,58)
 rows=[struct.unpack_from('<IIQQQQIIQQ',b,sh+i*sz) for i in range(n)]
 ntab=rows[si][4]; sections={}
 for name,typ,flags,va,at,size,*_ in rows:
  if flags&2:
   key=b[ntab+name:b.index(0,ntab+name)].decode()
   sections[key]=[va,size,hashlib.sha256(b[at:at+size]).hexdigest() if typ!=8 else 'NOBITS']
 return {'entry':struct.unpack_from('<Q',b,24)[0],'sections':sections}
loads=json.loads((p/'legacy-loads.json').read_text()); out={}
for key, sides in loads.items():
 pol,case=key.split('-')
 x={k:elf(p/'images'/f'{pol}-{k}-{case}'/'kernel.elf') for k in sides}
 out[key]={'load_equal':sides['P']==sides['C'],'entry_equal':x['P']['entry']==x['C']['entry'],'sections':x}
(p/'elf-comparison.json').write_text(json.dumps(out,indent=2))
print([(k,v['load_equal'],v['entry_equal'],v['sections']['P']['sections'].get('.data')==v['sections']['C']['sections'].get('.data')) for k,v in out.items()])
stats={}
for d in sorted((p/'raw').iterdir()):
 rows=[list(map(int,l.split())) for l in (d/'uart').read_text().splitlines() if l.split() and l.split()[0].isdigit() and len(l.split())==4]
 by=lambda k:[r[1:] for r in rows if r[0]==k]
 qs=by(21); diff=lambda a:max((b-x for x,b in zip(a,a[1:])),default=None)
 stats[d.name]=dict(phase_count=len(by(10)),irq_skips=[r for r in by(3) if r[1]!=r[2]],max_finish_gap=diff([r[0] for r in qs]),max_decision_gap=diff([r[2] for r in qs]),longest=by(33),mode=by(48))
(p/'passive.json').write_text(json.dumps(stats,indent=2))
print(stats['01-rm-C-a0'],stats['06-dm-C-a0'])
