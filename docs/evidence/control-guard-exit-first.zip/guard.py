import re, os, signal
def stop_process(proc):
 if proc.poll() is None:
  os.kill(proc.pid,signal.SIGSTOP)
  proc.kill()
class Guard:
 def __init__(self):
  self.offset=0;self.partial=b'';self.initial=False;self.writes=0;self.lines=0;self.reason=None
 def feed(self,data):
  if self.reason:return self.reason
  lines=(self.partial+data).split(b'\n');self.partial=lines.pop()
  for line in lines:
   self.lines+=1
   if line.startswith(b'pl061_set_output'):
    m=re.fullmatch(rb'pl061_set_output \S+ setting output (\d+) to ([01])',line)
    if not m:self.reason='malformed output'
    elif int(m[1])==0:
     if m[2]==b'1':self.reason='modeled output zero rose'
     else:self.initial=True
   elif line.startswith((b'pl061_write',b'pl061_read')):
    m=re.fullmatch(rb'pl061_(write|read) \S+ offset (0x[\da-fA-F]+) value (0x[\da-fA-F]+)',line)
    if not m:self.reason='malformed MMIO'
    else:
     off,val=int(m[2],16),int(m[3],16)
     if off<1024 and off&4:
      if val&1:self.reason='ON data '+m[1].decode()
      if m[1]==b'write':self.writes+=1
   if self.reason:return self.reason
 def poll(self,file,final=False):
  if file.exists():
   with file.open('rb') as f:
    f.seek(self.offset)
    while chunk:=f.read(262144):
     self.offset+=len(chunk)
     if self.feed(chunk):return self.reason
  if final and (self.partial or not self.initial or not self.writes):
   self.reason='incomplete corroborating stream'
  return self.reason
if __name__=='__main__':
 import subprocess as sp, time,tempfile
 from pathlib import Path
 prefix=b'pl061_set_output /machine/unattached/device[6] setting output 0 to '
 for split in range(1,len(prefix)+2):
  g=Guard();s=prefix+b'1\n';assert not g.feed(s[:split]);assert g.feed(s[split:])
 for line,bad in [(b'pl061_write /m offset 0x4 value 0x1',True),(b'pl061_write /m offset 0x3fc value 0x3',True),(b'pl061_write /m offset 0x400 value 0x1',False),(b'pl061_write /m offset 0x8 value 0x1',False),(prefix+b'0',False),(b'pl061_set_output /m setting output 2 to 1',False),(b'pl061_write unexpected',True)]:
  assert bool(Guard().feed(line+b'\n'))==bad
 with tempfile.TemporaryDirectory() as t:
  f=Path(t)/'trace';proc=sp.Popen(['python3','-c',"import sys,time;f=open(sys.argv[1],'wb',buffering=0);f.write(bytes.fromhex(sys.argv[2]));time.sleep(.02);f.write(b'1\\n');time.sleep(1);f.write(b'AFTER\\n')",str(f),prefix.hex()])
  g=Guard();deadline=time.monotonic()+2
  while time.monotonic()<deadline:
   if g.poll(f):stop_process(proc);break
   time.sleep(.001)
  proc.wait(2);assert proc.returncode==-signal.SIGKILL and b'AFTER' not in f.read_bytes()
 print('PASS split-lines, masked data aliases, direction/unrelated bits, malformed lines and live stop of synthetic host process')
