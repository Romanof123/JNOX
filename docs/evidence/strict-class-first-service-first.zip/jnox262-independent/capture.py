import os,sys,subprocess,signal,time
from pathlib import Path
base=Path.home()/'jnox262-independent'
sys.path.insert(0,str(base/'src/tools'))
import qemu_capture
d=Path(sys.argv[1])
if len(sys.argv)==3:
 env=dict(os.environ,CAPDIR=str(d/'raw'))
 p=subprocess.Popen([sys.executable,__file__,str(d),sys.argv[2],'child'],env=env)
 try: time.sleep(4)
 finally: p.send_signal(signal.SIGTERM)
 sys.exit(p.wait())
mode=sys.argv[2]
sys.argv=[sys.argv[0],'-M','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-m','128M','-nographic','-monitor','none','-nic','none','-kernel',str(d/'kernel.elf')]
sys.exit(qemu_capture.main('mlq_admission_witness','CAPDIR','fixed_runtime_idle',extra_symbols=('ordinary_multilevel_witness',) if mode=='trace' else ()))

