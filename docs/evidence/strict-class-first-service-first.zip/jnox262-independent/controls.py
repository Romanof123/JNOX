from pathlib import Path
import json,subprocess as sp,os,hashlib,struct
b=Path.home()/'jnox262-independent'; t=b/'src'; o=b/'controls';o.mkdir(exist_ok=True)
orig=Path('/mnt/d/codex/jnox259260-baseline')
tool=Path.home()/'jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin'
env=dict(os.environ,PATH=str(tool)+':/usr/bin:/bin',CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR=str(b/'control-target'))
results=[]
def run(cmd,d,env=env,cwd=t):
 r=sp.run(cmd,stdout=sp.PIPE,stderr=sp.STDOUT,env=env,cwd=cwd);d.write_bytes(r.stdout);return r.returncode
for r in json.loads((orig/'matrix.json').read_text()):
 if r['profile']!='multilevel':continue
 a=r['app'];m=r['mode'];d=o/(a+'-'+m);d.mkdir(exist_ok=True)
 e=dict(env,JNOX_PROFILE='multilevel',JNOX_APP=a)
 if m=='trace':e['JNOX_MULTILEVEL_TRACE']='1'
 assert run(['cargo','build','--release','--locked','--target','aarch64-unknown-none','-j','1'],d/'build',e,t/'kernel')==0
 elf=d/'kernel.elf';data=(b/'control-target/aarch64-unknown-none/release/jnox-kernel').read_bytes();elf.write_bytes(data)
 result=dict(app=a,mode=m,elf_equal=elf.read_bytes()==(orig/d.name/'kernel.elf').read_bytes())
 hdr=struct.unpack_from('<16sHHIQQQIHHHHHH',data)
 loads=[]
 for i in range(hdr[10]):
  typ,flags,off,va,pa,fs,ms,align=struct.unpack_from('<IIQQQQQQ',data,hdr[5]+i*hdr[9])
  if typ==1:loads.append([va,pa,fs,ms,hashlib.sha256(data[off:off+fs]).hexdigest()])
 result['loads_equal']=loads==[[s[k] for k in ('va','pa','filesz','memsz','sha256')] for s in r['segments']]
 cmd=['timeout','4','qemu-system-aarch64','-M','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-m','128M','-nographic','-monitor','none','-nic','none','-kernel',str(elf)]
 result['guest_rc']=run(cmd,d/'uart')
 results.append(result);(o/'results.json').write_text(json.dumps(results,indent=2))

