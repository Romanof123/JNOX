from pathlib import Path
import struct,json,re,subprocess as sp
b=Path.home()/'jnox262-independent'
out={}
for d in sorted((b/'supp').iterdir()):
 w=struct.unpack('<27Q',(d/'mlq_admission_witness.bin').read_bytes());j=d/'ordinary_multilevel_witness.bin'
 rows=[]
 if j.exists():
  raw=j.read_bytes()
  for i in range(struct.unpack_from('<Q',raw)[0]):
   r=struct.unpack_from('<131Q',raw,16+i*1048)
   rows.append(dict(kind=r[0],owner=r[3],start=r[4],due=r[5],stop=r[6],selected=r[10],service=r[23:27],source=hex(r[9])))
 irq=(d/'int.trace').read_text()
 pc=re.search(r'PC=(\w+)',(d/'registers').read_text())[1]
 elf=b/'first'/d.name/'kernel.elf'
 sym=sp.check_output(['aarch64-linux-gnu-addr2line','-fe',elf,pc],text=True)
 out[d.name]=dict(words=w,rows=rows,pc=pc,symbol=sym,IRQ=irq.count('[IRQ]'),SVC=irq.count('[SVC]'))
(b/'decode.json').write_text(json.dumps(out,indent=2));print(out['mlq-admit-trace'])

