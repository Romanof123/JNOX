#!/bin/bash
set -eu
base=$HOME/jnox262-independent
out=$base/first
export RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo
export PATH=$CARGO_HOME/bin:$PATH
export JNOX_BOARD=virt JNOX_PROFILE=multilevel CARGO_BUILD_JOBS=1
mkdir -p "$out"
cd "$base/src/kernel"
for app in mlq-admit mlq-refuse; do
 for mode in plain trace; do
 d=$out/$app-$mode
 if test -d "$d"; then continue; fi
 mkdir "$d"
 export JNOX_APP=$app CARGO_TARGET_DIR=$base/build-$app-$mode
 unset JNOX_MULTILEVEL_TRACE
 if test "$mode" = trace; then export JNOX_MULTILEVEL_TRACE=1; fi
 if cargo +1.95.0 build --locked --release -j1 >"$d/build.log" 2>&1; then
 cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" "$d/kernel.elf"
 python3 "$base/capture.py" "$d" "$mode" >"$d/console" 2>"$d/error" || echo CAPTURE_RED >"$d/RED"
 else echo BUILD_RED >"$d/RED"; fi
 (cd "$d"; find . -type f -print0 | sort -z | xargs -0 sha256sum > ../hash.tmp; mv ../hash.tmp SHA256SUMS)
 cp -r "$d" /mnt/d/codex/jnox262-independent/
 done
done
