from pathlib import Path
import subprocess as sp
b=Path.home()/'jnox262-independent';t=b/'src'
w=b/'package-netless.py';w.write_text("import sys,os\nos.execv('/usr/bin/qemu-system-aarch64',['qemu-system-aarch64','-nic','none',*sys.argv[1:]])\n")
for d in sorted((b/'first').iterdir()):
 if not d.is_dir(): continue
 a=d.name.rsplit('-',1)[0]
 r=sp.run(['python3','tools/qemu_boot.py','--profile',a,'--runs','1','--qemu',str(w),'--kernel',str(d/'kernel.elf')],cwd=t,capture_output=True)
 (b/('package-'+d.name+'.txt')).write_bytes(('returncode='+str(r.returncode)+'\n').encode()+r.stdout+r.stderr)

