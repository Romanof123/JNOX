from pathlib import Path
import json,struct
b=Path.home()/'jnox262-independent';orig=Path('/mnt/d/codex/jnox259260-baseline');out=[]
for r in json.loads((orig/'matrix.json').read_text()):
 if r['profile']!='multilevel':continue
 case=r['app']+'-'+r['mode'];s=r['segments'][0];off=s['offset'];v=s['va']
 a=(orig/case/'load0.bin').read_bytes();c=(b/'controls'/case/'kernel.elf').read_bytes()[off:off+len(a)]
 delta=[i for i in range(len(a)) if a[i]!=c[i]];records={}
 for i in delta:
  k=i//4*4
  ptr,length,lin,col=struct.unpack_from('<QQII',c,k-16);j=ptr-v
  records[k]=[c[j:j+length].decode(errors='replace') if j>=0 and j+length<=len(c) else None,struct.unpack_from('<I',a,k)[0],lin,col]
 out.append(dict(case=case,diff=records))
(b/'source-lines.json').write_text(json.dumps(out,indent=2));print(out[0])

