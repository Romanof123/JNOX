import os,sys,json,socket,time,subprocess
from pathlib import Path
base=Path.home()/'jnox262-independent'
sys.path.insert(0,str(base/'src/tools'))
from qemu_capture import request,journal_location
for d in sorted((base/'first').glob('*/')):
 o=base/'supp'/d.name
 o.mkdir(parents=True)
 elf=d/'kernel.elf'
 sock=str(o/'qmp.sock')
 args=['qemu-system-aarch64','-M','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-m','128M','-nographic','-monitor','none','-nic','none','-kernel',str(elf),'-serial','file:'+str(o/'uart.bin'),'-qmp','unix:'+sock+',server=on,wait=off','-d','int','-D',str(o/'int.trace')]
 p=subprocess.Popen(args)
 try:
  time.sleep(4)
  with socket.socket(socket.AF_UNIX) as c:
   c.connect(sock)
   with c.makefile('rwb',buffering=0) as f:
    f.readline(); request(f,'qmp_capabilities');request(f,'stop')
    (o/'registers').write_text(request(f,'human-monitor-command',**{'command-line':'info registers'}))
    for name in ('mlq_admission_witness','ordinary_multilevel_witness'):
     r=journal_location(elf,name,optional=True)
     if r: request(f,'pmemsave',val=r[0],size=r[1],filename=str(o/(name+'.bin')))
 finally: p.terminate();p.wait()

