#[path="src/kernel/src/mlq_bound.rs"] mod impls;
fn main(){
 let mut n=0; let mut seed=42u64;
 let mut next=||{seed=seed.wrapping_mul(6364136223846793005).wrapping_add(1);seed};
 for _ in 0..120000{
 let len=(next()>>32)%7;let t=((next()>>32)%7) as usize;
 let q=[0,1,12,u64::MAX][((next()>>32)%4)as usize];
 let mut draw=||[None,Some(0),Some(7),Some(13),Some(u64::MAX)][((next()>>32)%5) as usize];
 let a=draw(); let ds:Vec<_>=(0..len).map(|_|draw()).collect();
 let row:Vec<_>=ds.into_iter().map(|d|(((next()>>32)%3)as u8,d)).collect();
 let mut want=None;
 if let Some(al)=a {if len<=4 && t<row.len() && q>0{
 let mut ord:Vec<_>=(0..row.len()).collect();ord.sort_by_key(|&i|(std::cmp::Reverse(row[i].0),i));
 let mut sum=Some(al as u128);
 for &i in ord.iter().take_while(|&&i|i!=t){sum=sum.zip(row[i].1).map(|(s,x)|s+(if row[i].0==row[t].0{x.min(q)}else{x})as u128);}
 want=sum.and_then(|v|u64::try_from(v).ok());}}
 assert_eq!(impls::bound(&row,t,q,a),want);
 for d in [0,1,u64::MAX,want.unwrap_or(0),want.unwrap_or(0).saturating_sub(1)]{assert_eq!(impls::admits(want,d),want.map(|v|v<=d).unwrap_or(false));}
 n+=1;}
 println!("{n} independent stable priority/FIFO and wide integer vectors passed");
}
