from pathlib import Path
import json,struct,subprocess as sp,hashlib
b=Path.home()/'jnox262-independent';orig=Path('/mnt/d/codex/jnox259260-baseline');out=[]
for r in json.loads((orig/'matrix.json').read_text()):
 if r['profile']!='multilevel':continue
 case=r['app']+'-'+r['mode'];a=(orig/case/'kernel.elf').read_bytes();f=b/'controls'/case/'kernel.elf';c=f.read_bytes()
 def sections(data):
  h=struct.unpack_from('<16sHHIQQQIHHHHHH',data);ss=[struct.unpack_from('<IIQQQQIIQQ',data,h[6]+i*h[11]) for i in range(h[12])];names=ss[h[13]];strings=data[names[4]:names[4]+names[5]]
  return {strings[s[0]:].split(b'\x00')[0].decode():[s[3],s[5],hashlib.sha256(data[s[4]:s[4]+s[5]]).hexdigest() if s[1]!=8 else None] for s in ss}
 sa=sections(a);sc=sections(c);out.append(dict(case=case,sections={k:sa[k]==sc[k] for k in ('.text','.rodata','.data','.bss','.stack')},layout=all(sa[k][:2]==sc[k][:2] for k in ('.text','.rodata','.data','.bss','.stack'))))
print(out)
(b/'section-comparison.json').write_text(json.dumps(out,indent=2))

