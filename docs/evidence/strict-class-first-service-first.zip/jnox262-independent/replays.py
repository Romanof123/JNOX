from pathlib import Path
import sys,os,subprocess as sp,json,struct
b=Path.home()/'jnox262-independent';t=b/'src';o=b/'controls';orig=Path('/mnt/d/codex/jnox259260-baseline');rows=[]
for r in json.loads((orig/'matrix.json').read_text()):
 if r['profile']!='multilevel':continue
 a=r['app'];d=o/(a+'-'+r['mode']);data=(d/'kernel.elf').read_bytes();details=[]
 for i,s in enumerate(r['segments']):
  left=(orig/d.name/f'load{i}.bin').read_bytes();right=data[s['offset']:s['offset']+s['filesz']]
  dif=[k for k,(x,y) in enumerate(zip(left,right)) if x!=y];details.append(dict(first=dif[:15],count=len(dif)))
 rows.append(dict(case=d.name,details=details))
(o/'diff.json').write_text(json.dumps(rows,indent=2))
wrapper=b/'netless.py'
wrapper.write_text("import sys,runpy\nsys.argv.insert(1,'none');sys.argv.insert(1,'-nic')\nsys.path.insert(0,"+repr(str(t/'tools'))+")\nrunpy.run_path("+repr(str(t/'tools/ordinary_multilevel_capture.py'))+",run_name='__main__')\n")
for a in ['mlq','mlfq','mlq-saturated']:
 d=o/(a+'-trace');env=dict(os.environ,ORDINARY_MULTILEVEL_CAPTURE_DIR=str(d/'capture'))
 cmd=['python3','tools/qemu_boot.py','--profile',a,'--runs','1','--qemu',str(wrapper),'--kernel',str(d/'kernel.elf')]
 r=sp.run(cmd,cwd=t,env=env,capture_output=True);(d/'runner').write_bytes(r.stdout+r.stderr)
 if a in ('mlq','mlfq'):
  r=sp.run(['python3','tools/ordinary_multilevel_replay.py',a,str(d/'capture/audit.bin')],cwd=t,capture_output=True);(d/'replay').write_bytes(r.stdout+r.stderr)
 else:
  raw=(d/'capture/audit.bin').read_bytes();n=struct.unpack_from('<Q',raw)[0];rows=[struct.unpack_from('<131Q',raw,16+1048*i) for i in range(n)]
  (d/'replay').write_text(str([(r[3],r[0],r[10],r[6]-r[4]) for r in rows]))

