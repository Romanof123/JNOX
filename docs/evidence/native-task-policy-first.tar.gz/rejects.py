import sys,pathlib,struct,subprocess,os,hashlib,json
w=pathlib.Path(sys.argv[1]).resolve(); src=pathlib.Path(sys.argv[2]).resolve(); apps=w/'final-apps'; cases=w/'rejects'; cases.mkdir(exist_ok=True)
data=(w/'final-on/policy.bin').read_bytes(); off=struct.unpack_from('<I',data,16+32)[0]
elf=(apps/'sensor.elf').read_bytes(); note=bytes.fromhex('0500000004000000010000004a4e4f580000000001000000'); n=elf.index(note)+20
casespec=[('bad-note',off+n,b'\x02','ABI note'),('bad-elf-entry',off+24,struct.pack('<Q',0x400004),'entry'),('bad-task-entry',16+5*48+40,struct.pack('<Q',0x400000+struct.unpack_from('<Q',elf,64+32)[0]),'executable file data'),('too-many-asids',8,struct.pack('<I',256),'ASID'),('owner',16+5*48+32,struct.pack('<I',2),'task owner'),('header',0,b'FAIL','header'),('deadline',16+5*48+56,bytes(4),'priority or deadline'),('digest',0,data[:4],'SHA-256 mismatch')]
def checked(key,cmd,cwd,expected,env=None):
    r=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    log=cases/(key+'.log'); log.write_text(r.stdout)
    print(key,r.returncode,expected in r.stdout,flush=True); assert r.returncode and expected in r.stdout,(key,r.stdout[-1000:])
for key,at,value,reason in casespec:
    b=bytearray(data); b[at:at+len(value)]=value; path=cases/(key+'.bin'); path.write_bytes(b)
    env=dict(os.environ,JNOX_BOARD='virt',JNOX_ARCH='aarch64',JNOX_PROFILE='task-policy',JNOX_TASK_POLICY_BIN=str(path),JNOX_TASK_POLICY_SHA256='0'*64 if key=='digest' else hashlib.sha256(b).hexdigest(),CARGO_TARGET_DIR=str(w/'negative-final-target'))
    checked('raw-'+key,['cargo','build','--locked','--release','-j1','--target','aarch64-unknown-none'],src/'kernel',reason,env)
for key,at,value,reason in casespec[:2]:
    b=bytearray(elf); b[at-off:at-off+len(value)]=value; (cases/(key+'.elf')).write_bytes(b)
    (cases/'p.txt').write_text('version 1\napp s '+key+'.elf\ntask s sample sample_entry 50 20 2 off\n')
    checked('text-'+key,[sys.executable,str(src/'tools/build_native_el0.py'),'--task-policy',str(cases/'p.txt'),'--out',str(cases/'invalid-package')],src,reason)
for key,tail,reason in [('range','task sensor x sample_entry 50 256 1 off','priority'),('duplicate','task sensor sample sample_entry 100 10 10 off','duplicate')]:
    f=apps/(key+'.txt'); f.write_text((apps/'policy.txt').read_text()+tail+'\n')
    checked('text-'+key,[sys.executable,str(src/'tools/build_native_el0.py'),'--task-policy',str(f),'--out',str(cases/'invalid-package')],src,reason)
