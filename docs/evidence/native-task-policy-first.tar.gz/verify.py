import hashlib,json,pathlib,re,struct,sys
w=pathlib.Path(sys.argv[1]); runs=w/'runs'
def text(tag): return (runs/(tag+'.uart')).read_text()
def sha(b): return hashlib.sha256(b).hexdigest()
def manifest(tag): return json.loads((w/('final-'+tag)/'manifest.json').read_text())
assert [a['elf_sha256'] for a in manifest('on')['apps']]==[a['elf_sha256'] for a in manifest('off')['apps']]
for tag in ('on','off','scale','extra','edges'):
    m=manifest(tag); package=w/('final-'+tag)
    assert m['tracked_changes']=='' and sha((package/'kernel.elf').read_bytes())==m['kernel_elf_sha256']
    blob=(package/'policy.bin').read_bytes(); assert sha(blob)==m['policy_sha256'] and (package/'kernel.elf').read_bytes().count(blob)==1
    _,_,na,nt=struct.unpack_from('<4sIII',blob)
    assert na==len(m['apps']) and nt==sum(len(a['tasks']) for a in m['apps'])
    configured=(w/'final-apps'/dict(on='policy.txt',off='unmonitored.txt',scale='scale20.txt',extra='extra.txt',edges='edges.txt')[tag]).read_text().splitlines()
    terminal=[(a,t) for a,t in re.findall(r'SUMMARY app=(\w+) task=(\w+)',text(tag))]
    expected=[]
    for i,a in enumerate(m['apps']):
        name,offset,size,first,count=struct.unpack_from('<32s4I',blob,16+i*48)
        assert name.rstrip(b'\0').decode()==a['name'] and sha(blob[offset:offset+size])==a['elf_sha256']
        assert 'app '+a['name']+' '+a['path'] in configured
        for j,t in enumerate(a['tasks']):
            name,owner,slot=struct.unpack_from('<32s2I',blob,16+48*na+(first+j)*64)
            assert (name.rstrip(b'\0').decode(),owner,slot)==(t['name'],i,j)
            va,period,priority,deadline,wd=struct.unpack_from('<Q4I',blob,16+48*na+(first+j)*64+40)
            assert (va,period,priority,deadline,wd)==(t['entry'],t['period_ms'],t['priority'],t['deadline_ms'],t['watchdog_ms'] or 0)
            setting=' '.join(map(str,['task',a['name'],t['name'],t['symbol'],period,priority,deadline,wd or 'off']))
            assert setting in configured
            assert sha((w/'final-apps'/a['path']).read_bytes())==a['elf_sha256']
            expected.append((a['name'],t['name']))
    assert terminal==expected
    ram=json.loads((runs/(tag+'.ram.json')).read_text())
    if tag=='scale':
        assert len(ram)==20 and all(bytes.fromhex(r['rw_hex'])[:4]==b'\x08\0\0\0' for r in ram)
        assert re.findall(r'EXIT app=(\w+) task=beat .*status=25',text(tag))==[a['name'] for a in m['apps']]
        starts=re.findall(r'START app=(\w+) task=beat',text(tag))
        assert starts[:20]==[a['name'] for a in m['apps']]
    if tag in ('on','off'):
        words=struct.unpack_from('<II',bytes.fromhex(ram[0]['rw_hex']),12)
        assert words[0]==20 and 8<=words[1]<=20
        for a,t,status in [('sensor','observe',22),('sensor','sample',21),('heartbeat','beat',25),('late','batch',24)]:
            assert re.search(f'EXIT app={a} task={t} .*status={status}',text(tag))
        assert re.search('FAULT app=fault task=report .*source=svc status=37',text(tag))
assert re.search('WATCHDOG app=heavy task=burn .*irq_user irq=30 running_app=heavy running_task=burn',text('on'))
assert 'WATCHDOG' not in text('off') and re.search('EXIT app=heavy task=burn .*status=23',text('off'))
assert re.search('RELEASE app=sensor task=sample .*irq_user irq=30 running_app=late running_task=batch\nJNOX POLICY START app=sensor task=sample',text('on'))
for tag,pattern in [('edges','SUMMARY app=starved .*starts=0 completes=0 .*watchdogs=1'),('edges','SUMMARY app=periodic .*completes=1 .*watchdogs=1'),('edges','SUMMARY app=worker task=late .*completes=1 misses=1 watchdogs=0'),('edges','EXIT app=worker task=zero .*status=28'),('extra','SUMMARY app=worker .*completes=1 misses=1 watchdogs=1'),('extra','EXIT app=healthy .*status=25')]:
    assert re.search(pattern,text(tag)),(tag,pattern)
assert 'NATIVE EL0 EXIT 37' in text('legacy')
print('PASS source/manifest/embedded bytes/UART identities, equal-priority FIFO, preemption, distinct task/process memory, terminal values, watchdogs, deadlines, legacy')

