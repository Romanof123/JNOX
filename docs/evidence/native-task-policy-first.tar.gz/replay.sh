#!/usr/bin/env bash
set -euo pipefail
src=$(realpath "$1")
out=$(realpath -m "$2")
here=$(cd "$(dirname "$0")" && pwd)
mkdir "$out"
cd "$src"
test "$(git rev-parse 'HEAD^{tree}')" = cf7e7792da0c9dd12636c8b28daf711178e89c85
git diff --quiet
git diff --cached --quiet
git rev-parse HEAD 'HEAD^{tree}' > "$out/source.txt"
python3 tools/task_policy_regression.py > "$out/compiler.log" 2>&1
rustc --edition=2021 --test kernel/src/task_policy_scheduler.rs -o "$out/sched"
"$out/sched" > "$out/scheduler.log"
sh examples/native-task-policy/build.sh "$out/final-apps" > "$out/apps.log" 2>&1
(cd "$out/final-apps" && sha256sum -c apps.sha256)
sh sdk/native-aarch64/build.sh "$here/edges.c" "$out/final-apps/edges.elf"
sh sdk/native-aarch64/build.sh "$here/ongoing.c" "$out/final-apps/ongoing.elf"
cp "$here/edges.txt" "$here/extra.txt" "$out/final-apps/"
for pair in policy:on unmonitored:off scale20:scale edges:edges extra:extra; do
  name=${pair%:*}; tag=${pair#*:}
  python3 tools/build_native_el0.py --task-policy "$out/final-apps/$name.txt" --out "$out/final-$tag"
  python3 "$here/guest.py" "$out/runs" "$out/final-$tag" "$tag" "JNOX POLICY DONE"
done
python3 tools/build_native_el0.py --out "$out/legacy"
python3 "$here/guest.py" "$out/runs" "$out/legacy" legacy "NATIVE EL0 EXIT 37"
python3 "$here/rejects.py" "$out" "$src" | tee "$out/rejects.log"
python3 "$here/verify.py" "$out"
