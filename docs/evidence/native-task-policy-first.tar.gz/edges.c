#include <jnox/task_policy.h>
static volatile unsigned value;
void late_entry(void) {
    for (unsigned i=0;i<4000000;i++) value += i;
    if (jnox_task_complete()!=0) { (void)jnox_task_exit(99); return; }
    (void)jnox_task_exit(27);
}
void zero_entry(void) { (void)jnox_task_exit(jnox_task_fault(0)==-22 ? 28 : 98); }
int main(void) { late_entry(); return 99; }
