#include <jnox/task_policy.h>
static volatile unsigned long count;
void ongoing_entry(void) {
    if (jnox_task_complete() != 0) { (void)jnox_task_exit(99); return; }
    while (++count < 100000000) {}
    (void)jnox_task_exit(26);
}
int main(void) { ongoing_entry(); return 99; }
