import json,pathlib,socket,subprocess,sys,time,struct,hashlib
work=pathlib.Path(sys.argv[1]).resolve(); pkg=pathlib.Path(sys.argv[2]).resolve(); tag=sys.argv[3]; marker=sys.argv[4].encode()
work.mkdir(parents=True,exist_ok=True)
uart=work/(tag+'.uart'); sock=work/(tag+'.sock')
cmd=['qemu-system-aarch64','-M','virt,gic-version=2','-cpu','cortex-a53','-accel','tcg','-smp','1','-m','128M','-nodefaults','-display','none','-serial','file:'+str(uart),'-qmp','unix:'+str(sock)+',server=on,wait=off','-kernel',str(pkg/'kernel.elf')]
if uart.exists(): raise RuntimeError('preserve existing UART')
(work/(tag+'.command.json')).write_text(json.dumps(cmd))
p=subprocess.Popen(cmd); s=socket.socket(socket.AF_UNIX)
try:
    for _ in range(200):
        if sock.exists(): break
        time.sleep(.025)
    s.connect(str(sock)); f=s.makefile('rwb',buffering=0); f.readline()
    def q(op,**args):
        f.write((json.dumps(dict(execute=op,arguments=args))+'\n').encode())
        while True:
            r=json.loads(f.readline())
            if 'return' in r: return r['return']
            if 'error' in r: raise RuntimeError(r)
    q('qmp_capabilities')
    for _ in range(2500):
        if uart.exists() and marker in uart.read_bytes(): break
        if p.poll() is not None: break
        time.sleep(.02)
    q('stop'); info=q('query-cpus-fast'); (work/(tag+'.cpus.json')).write_text(json.dumps(info))
    assert len(info)==1 and marker in uart.read_bytes(), uart.read_text()[-3000:]
    if marker==b'JNOX POLICY DONE':
        manifest=json.loads((pkg/'manifest.json').read_text()); apps=manifest['apps']
        symbols=subprocess.check_output(['nm','-S',str(pkg/'kernel.elf')],text=True)
        ln=next(x for x in symbols.splitlines() if 'native_el0_mmu6SPACES' in x).split()
        base=int(ln[0],16); stride=int(ln[1],16)//len(apps)
        rows=[]
        for i,app in enumerate(apps):
            root=base+i*stride; name=app['name']
            temp=work/(tag+'-page.bin')
            def read(addr,n):
                q('pmemsave',val=addr,size=n,filename=str(temp)); return temp.read_bytes()
            def leaf(va):
                pa=root
                for shift in [30,21,12]:
                    d=struct.unpack('<Q',read(pa+8*((va>>shift)&511),8))[0]; 
                    if d&3!=3: return None
                    pa=d&0xfffff000
                return pa+(va&4095)
            va=0x402000; pa=leaf(va)
            data=read(pa,64)
            stacks=[]
            for slot in range(len(app['tasks'])):
                lo=0x1001000+slot*17*4096
                assert leaf(lo-4096) is None and leaf(lo+16*4096) is None
                assert leaf(lo) and leaf(lo+15*4096)
                stacks.append(dict(slot=slot,lo=hex(lo),first_pa=hex(leaf(lo)),last_pa=hex(leaf(lo+15*4096)),guard_before=0,guard_after=0))
            rows.append(dict(stacks=stacks,app=name,root=hex(root),rw_va=hex(va),rw_pa=hex(pa),rw_hex=data.hex()))
        assert len({r['rw_pa'] for r in rows})==len(rows)
        (work/(tag+'.ram.json')).write_text(json.dumps(rows,indent=2)); temp.unlink()
    print(tag,'marker found; vCPUs',len(info))
finally:
    p.terminate(); p.wait(timeout=3); s.close()

