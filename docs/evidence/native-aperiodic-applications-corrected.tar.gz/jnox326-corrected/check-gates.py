from pathlib import Path
import json, struct, subprocess, re
root=Path.home()/'v326c'; out=Path(__file__).parent
for name,dname in [('short','supplement-short-sleeps'),('idle','supplement-idle')]:
 d=root/'raw'/dname
 data=json.loads((out/(name+'-results.json')).read_text()); candidates=data['canceled']
 print(name,'candidates by dest',[(k,sum(e[8]==k for e,n,x in candidates)) for k in range(3)])
 for e,n,x in candidates:
  assert e[32]==0 and e[33]==0 and e[38]>=e[13] and n[1]==3 and n[2]==e[38] and n[34:36]==[0,0]
 ev=[list(map(int,l.split()[3:])) for l in (d/'uart').read_text().splitlines() if l.startswith('NATIVE SERVER EVENT ')]
 tr=(d/'trace').read_text()
 irqpc=[int(x,16) for x in re.findall(r'Taking exception 5 \[IRQ\]\n\.\.\.from EL0 to EL1\n[^\n]*\n\.\.\.with ELR 0x([0-9a-f]+)',tr)]
 assert irqpc==[e[26] for e in ev if e[1]==1 and e[7]<2]
 assert len(re.findall(r'Taking exception 5 \[IRQ\]\n\.\.\.from EL1 to EL1',tr))==sum(e[1]==1 and e[7]==2 for e in ev)
 ram=(d/'ram').read_bytes()
 def word(pa):return struct.unpack_from('<Q',ram,pa-0x40000000)[0]
 for pid,elf in enumerate(['short-service.elf','short-peer.elf'] if name=='idle' else ['short-service.elf']):
  tt=next(e[31] for e in ev if e[8]==pid and e[37]==1)
  for key,desired in [('product',(200 if pid else 160)*8128),('completed',200 if pid else 160)]:
   syms=subprocess.check_output(['aarch64-linux-gnu-nm',root/'raw'/elf],text=True)
   va=int(re.search(r'^([0-9a-f]+) B '+key+r'$',syms,re.M)[1],16); pa=tt & 0xfffff000
   for shift in (30,21,12):pa=word(pa+8*((va>>shift)&511))&0xfffff000
   result=word(pa+(va&4095)); assert result==desired; print(pid,key,result)
 print('all canceled rows had zero accepted-return and idle landing stamps, retries had zero occupancy; all actual IRQ sources matched external trace')
