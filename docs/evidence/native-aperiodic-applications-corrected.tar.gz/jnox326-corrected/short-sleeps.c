#include "clock.h"
volatile uint64_t completed, product;
int main(void) {
    for (unsigned i=0;i<160;i++) {
        uint64_t now;
        if (read_ns(&now)) return 90;
        for(unsigned j=0;j<128;j++) product+=j;
        /* Sweep the normal absolute-sleep interval using only the public SDK. */
        if (sleep_to(now + 1000 + 500*(i%80))) return 91;
        completed++;
    }
    return completed==160 && product==160*8128 ? 43 : 92;
}
