#[path="/home/ywcho/v326c/src/kernel/src/aperiodic_policy.rs"] mod ledger;
use ledger::*;
#[test]
fn restore_second_prepared_debit_with_older_credit_and_reselect() {
 for cap in [1usize,2] {
  let mut s=AperiodicServer::<2>::new_live(ServerKind::Sporadic,0,2,5,cap).unwrap();
  assert!(s.tick_live(true,true).unwrap());
  let mut snapshot=Some(s.clone());
  assert!(s.tick_live(true,true).unwrap());
  assert_eq!(discard_missed_grant(&mut s,&mut snapshot,4).unwrap(),Some(1));
  assert_eq!(s.remaining_quota(),1);
  assert_eq!(s.pending_replenishments().len(),1);
  assert_eq!(s.pending_replenishments()[0].due,5);
  s.skip_live_to(4,true).unwrap();
  assert!(s.tick_live(true,true).unwrap());
  assert_eq!(s.remaining_quota(),0);
  assert_eq!(s.pending_replenishments().iter().map(|r|r.amount).sum::<u32>(),2);
  assert_eq!(s.pending_replenishments()[cap-1].due,9);
  assert_eq!(discard_missed_grant(&mut s,&mut snapshot,5).unwrap(),None);
 }
}
