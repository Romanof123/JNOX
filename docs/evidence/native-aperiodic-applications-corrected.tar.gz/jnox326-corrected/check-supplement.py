from pathlib import Path
import re, json,subprocess as s,os
r=Path.home()/'v326c'; d=r/'raw/supplement-ms1'; out=Path(__file__).parent
ls=(d/'uart').read_text().splitlines()
ev=[list(map(int,l.split()[3:])) for l in ls if l.startswith('NATIVE SERVER EVENT ')]
trace=(d/'trace').read_text()
pc=[int(a,16) for a in re.findall(r'Exception return from AArch64 EL1 to AArch64 EL0 PC 0x([a-f0-9]+)',trace)]
summary={'journal_rows':len(ev),'real_irq':sum(e[1]==1 for e in ev),'trace_irq':trace.count('Taking exception 5 [IRQ]'),'external_returns':len(pc),'accepted_return_pcs_match':pc==[e[29] for e in ev if e[8]<2 and e[37]==1],'stale_accepted':[e[0] for e in ev if e[37]==1 and e[32]>=e[13]],'debit_rollbacks':[e for e in ev if e[39]!=2**64-1],'canceled':[(e,ev[i+1],next((r for r in ev[i+1:] if r[1]==1),None)) for i,e in enumerate(ev[:-1]) if e[37]==0],'tail':ls[-4:],'skips':sum(e[11] for e in ev)}
print(json.dumps(summary,indent=2))
