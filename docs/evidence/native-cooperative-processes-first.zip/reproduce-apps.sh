#!/bin/bash
# Run from a pristine checkout of the exact commit. Set EVIDENCE to the extracted archive.
set -eu
: "${EVIDENCE:?absolute path to extracted evidence}"
test "$(git rev-parse HEAD)" = 94bef763dbbcc7419e2d2902361052c6acec1f86
export RUSTUP_TOOLCHAIN=1.95.0
d=$(mktemp -d)
export CARGO_TARGET_DIR="$d/peer-target"
for t in pair running-v2 idle-v2 startup clock sleep; do
  case "$t" in
    pair|running-v2|idle-v2)
      manifest=examples/native-cooperative-rust/Cargo.toml
      if test "$t" != pair; then
        cp -r "$EVIDENCE/apps-serial/$t/$t-peer" "$d/$t-peer"
        sed -i "s|/home/ywcho/jnox-292-apps-evidence/src/sdk/native-aarch64/rust|$(pwd)/sdk/native-aarch64/rust|" "$d/$t-peer/Cargo.toml"
        manifest="$d/$t-peer/Cargo.toml"
      fi
      sh sdk/native-aarch64/build-rust.sh "$manifest" "$d/$t-peer.elf"
      args=(--source examples/portability/native_cooperative_report.c --peer-elf "$d/$t-peer.elf");;
    startup) args=();;
    clock) args=(--source examples/portability/clock_checksum.c);;
    sleep) args=(--source examples/portability/periodic_report.c);;
  esac
  python3 tools/build_native_el0.py --out "$d/$t" "${args[@]}"
  timeout 2 qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -accel tcg -m 128M -nodefaults -display none -monitor none -serial stdio -d int -D "$d/$t/interrupts.log" -kernel "$d/$t/kernel.elf" </dev/null >"$d/$t/uart.log" 2>"$d/$t/qemu.log" || test $? -eq 124
  cat "$d/$t/uart.log"
done
echo "$d"
