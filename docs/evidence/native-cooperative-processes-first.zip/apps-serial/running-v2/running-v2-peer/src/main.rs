#![no_std]
#![no_main]

use core::panic::PanicInfo;
use core::ptr::{addr_of_mut, read_volatile, write_volatile};
use jnox_native::{exit, yield_now};

#[link_section = ".data.private_report"]
#[no_mangle]
static mut peer_total: u32 = 20;

#[panic_handler]
fn panic(_: &PanicInfo<'_>) -> ! {
    exit(111)
}

#[no_mangle]
pub extern "C" fn main(_argc: i32, _argv: *const *const u8) -> i32 {
    let total = addr_of_mut!(peer_total);
    // Only this application accesses its private, aligned accumulator.
    unsafe { write_volatile(total, read_volatile(total) + 2) };
    if yield_now().is_err() || unsafe { read_volatile(total) } != 22 {
        return 113;
    }

    use core::time::Duration;
    let end = jnox_native::monotonic_time().unwrap() + Duration::from_millis(300);
    
    let mut rounds = 0u64;
    let mut checksum = 1u64;
    while jnox_native::monotonic_time().unwrap() < end {
        for i in 0..8192u64 { checksum = core::hint::black_box(checksum.wrapping_mul(33).wrapping_add(i)); }
        rounds += 1;
    }
    if rounds == 0 { return 114; }
    if yield_now().is_err() { return 115; }
        // The primary has begun its absolute sleep. Finish the report before exit.
    unsafe {
        write_volatile(total, read_volatile(total) + 7);
        read_volatile(total) as i32
    }
}
