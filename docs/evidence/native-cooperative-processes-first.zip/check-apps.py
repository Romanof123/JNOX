"""Offline check of the serial native application cohort. Run with Python 3."""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for line in (ROOT / "apps-files.sha256").read_text().splitlines():
    expected, name = line.split("  ", 1)
    assert digest(ROOT / name) == expected, name

cases = {
    "pair": "D0 D1 D0 S0 D1 X1=29 D0 X0=17",
    "running-v2": "D0 D1 D0 S0 D1 D0 D1 X1=29 D0 X0=17",
    "idle-v2": "D0 D1 D0 S0 D1 S1 D0 X0=17 D1 X1=29",
    "startup": "X37", "clock": "X0", "sleep": "X0",
}
for name, expected in cases.items():
    d = ROOT / "apps-serial" / name
    m = json.loads((d / "manifest.json").read_text())
    assert m["commit"] == "94bef763dbbcc7419e2d2902361052c6acec1f86" and not m["tracked_changes"]
    uart = (d / "uart.log").read_text().splitlines()
    assert uart[:2] == ["JNOX M1 BOOT", "JNOX M1 READY"]
    assert digest(d / "build.log") == m["build_log_sha256"]
    assert digest(d / "kernel.elf") == m["kernel_elf_sha256"]
    assert uart[2] == "NATIVE EL0 ELF " + digest(d / "user.elf")
    assert m["user_elf_sha256"] == digest(d / "user.elf")
    start = 3
    if "peer_elf_sha256" in m:
        assert uart[3] == "NATIVE EL0 PEER ELF " + digest(d / "native_peer.elf")
        assert m["peer_elf_sha256"] == digest(d / "native_peer.elf")
        start = 4
    labels = [s.removeprefix("NATIVE EL0 ").replace("DISPATCH PID ", "D").replace("SLEEP PID ", "S").replace("EXIT PID ", "X").replace("EXIT ", "X").replace(" ", "=") for s in uart[start:]]
    assert labels == expected.split(), (name, labels)
    irq = (d / "interrupts.log").read_text()
    if name == "running-v2":
        assert re.search(r'Taking exception 5 \[IRQ\]\n\.\.\.from EL0 to EL1\n[^\n]+\n\.\.\.with ELR (0x[0-9a-f]+)\n[^\n]+\nException return from AArch64 EL1 to AArch64 EL0 PC \1\b', irq)
    if name == "idle-v2":
        assert irq.count("Taking exception 5 [IRQ]\n...from EL1 to EL1") == 2
    print(name, expected)
pair = ROOT / "apps-serial/pair"
assert (pair/"uart-postexit.log").read_bytes() == (pair/"uart.log").read_bytes()
rows = dict((int(a,16),int(v,16)) for a,v in re.findall(rb'([0-9a-f]{16}): 0x([0-9a-f]+)',(pair/"postexit-monitor.log").read_bytes()))
for pte, expected in [(0x40228010,17),(0x4063d010,29)]:
    assert rows[rows[pte] & 0xfffff000] == expected
print("Physical frame payload, owner ordering and file hashes verified.")
