import hashlib,json,re,subprocess,sys,os
from pathlib import Path
root=Path(sys.argv[1]).resolve()
out={}
def run(*args):
 p=subprocess.run(args,cwd=root,capture_output=True,env={**os.environ,"PYTHONUTF8":"1"})
 return p.returncode,p.stdout,p.stderr
def git(*args):
 rc,s,e=run("git",*args)
 assert not rc,e
 return s.decode().strip()
def catalog(tag):
 rc,s,e=run(sys.executable,"tools/scheduling_evidence.py")
 j=json.loads(s)
 out[tag]=[rc,j["findings"],len(j["policies"]),len(j["evidence"]),hashlib.sha256(s).hexdigest()]
 return j
csv=root/"trace/links.csv"
for rev in ["07fe7ef","b129f1f","08219c9"]:
 git("checkout","--detach",rev)
 out[rev]=git("rev-parse","HEAD")
 j=catalog(rev+"-catalog")
 for tool in ["tools/requirement_graph.py","tools/test_requirement_graph.py","tools/test_scheduling_evidence.py"]:
  rc,s,e=run(sys.executable,tool)
  out[rev+tool]=[rc,hashlib.sha256(s).hexdigest(),e.decode().strip()]
 if rev=="07fe7ef":
  orig=j
  with csv.open("ab") as f:f.write(b"POL-014,has-switch-evidence,EVD-057\n")
  corrected=catalog("baseline-corrected")
  git("restore","trace/links.csv")
 if rev=="08219c9":
  out["corrected-baseline-equals-final"]=corrected==j
  out["legacy-deltas"]=[k for k in j if j[k]!=orig[k]]
paths=[root/"docs"/("scheduling-release-cases"+s) for s in [".en.md",".md"]]
before=[p.read_text("utf-8") for p in paths]
trace=csv.read_bytes()
for pol,evd in [("014","057"),("015","058")]:
 csv.write_bytes(b"".join(l for l in trace.splitlines(True) if not (l.startswith(("POL-"+pol+",").encode()) and l.strip().endswith(("EVD-"+evd).encode()))))
 catalog("delete"+pol)
csv.write_bytes(b"".join(l for l in trace.splitlines(True) if not(l.startswith(b"POL-015,") and l.strip().endswith(b"EVD-058"))))
link="[EVD-058](evidence/evd-058.md)"
for i,locale in enumerate(["en","ko"]):
 for name,cell,approval,tail in [
 ("plain",link,"",""),("pipe",r"LO \| HI "+link,"",""),("approval","",link,""),("inline","`"+link+"`","",""),("comment","<!-- "+link+" -->","",""),("escaped",chr(92)+link,"",""),("reference","[EVD-058][rec]","","\n[rec]: evidence/evd-058.md"),("detached","","","\n| POL-015 | "+link+" | |"),("fenced","","","\n~~~\nHEADER\n| POL-015 | "+link+" | |\n~~~"),("shared","[EVD-004](evidence/evd-004.md)","","")]:
  for n,p in enumerate(paths):
   source=before[n]
   h=next(k for k in source.splitlines() if k.startswith("| Policy") or k.startswith("| 정책"))
   targeted=re.sub(r"^\| POL-015 \|.*$",lambda _:f"| POL-015 | {cell if n==i else ''} | {approval if n==i else ''} |",source,flags=re.M)
   p.write_text(targeted+("\n"+tail.replace("HEADER",h+"\n|---|---|---|") if n==i else ""),"utf-8")
  catalog(locale+"-"+name)
git("restore","docs/scheduling-release-cases.md","docs/scheduling-release-cases.en.md","trace/links.csv")
print(json.dumps(out,ensure_ascii=False,indent=2))
