"""Decode the fixed #381 capture packet with Python 3. No emulator or cross tools."""
import argparse
import hashlib
import json
import re
import shutil
import struct
import sys
import tarfile
import tempfile
from pathlib import Path

REVISION = "9912ae3db95aec3f1a67f690d01c7379339168d1"
PACKET = "9819033ffec7ee0d1867f5348bb20b76cc37dac6c0284bccb5cb7fbe2dd96165"
BROKER = "2ba00646fd51b297dcc762fb4ff81df70036542376ffe4ddd32ae16cd9b4bdc5"
MODES = ("stream", "dgram", "seq", "expired", "ready", "fullexpire", "fullready", "backlog", "death")
ORDINARY = {
    "stream": ([1,1,2080,64,3,16,45,0,0,32,1,0], [1,7,57,0,0,-11,32,0,1,0,0,0]),
    "seq": ([5,5,150,12,3,3,3,3,0,150,1,0], [5,3,3,3,3,-11,150,0,1,0,0,0]),
    "dgram": ([2,2,74,5,5,2,0,0,10,74,1,0], [2,5,2,0,0,0,74,10,1,0,0,0]),
}
DEATH = ([64,0,0,65,1,1,1,1,-11,1,-32,0,66,0], [64,0,0,1,65,0,0,-16])


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def uint(buf, offset, size):
    assert 0 <= offset <= len(buf)-size
    return int.from_bytes(buf[offset:offset+size], "little")


def signed(n):
    return n if n < 1 << 63 else n - (1 << 64)


def elf_symbols(path):
    data = path.read_bytes()
    header = struct.unpack_from("<16sHHIQQQIHHHHHH", data)
    assert data[:6] == b"\x7fELF\x02\x01" and header[2] == 183
    sections = [struct.unpack_from("<II4QII2Q", data, header[6]+i*header[11]) for i in range(header[12])]
    symtab, = [s for s in sections if s[1] == 2]
    strings = sections[symtab[6]]
    names = data[strings[4]:strings[4]+strings[5]]
    symbols = {}
    for offset in range(symtab[4], symtab[4]+symtab[5], symtab[9]):
        name, _, _, _, addr, size = struct.unpack_from("<IBBHQQ", data, offset)
        if size:
            key = names[name:names.index(b"\x00", name)].decode()
            symbols[key] = (addr, size)
    return symbols


def unique(symbols, part):
    value, = [v for name, v in symbols.items() if part in name]
    return value


def private_read(ram, base, root, va, size, frames):
    out = bytearray()
    while size:
        page = root
        for shift in (30,21,12):
            entry = uint(ram, page-base + ((va >> shift) & 511)*8, 8)
            assert entry & 3 == 3
            page = entry & 0x0000fffffffff000
        assert entry & 0xc0 == 0x40  # EL0 read/write
        frames.add(page)
        n = min(4096-va%4096, size)
        at = page-base + va%4096
        assert 0 <= at <= len(ram)-n
        out.extend(ram[at:at+n])
        size -= n
        va += n
    return out


def final_state(banks, clients, endpoints, live, layout, routes):
    b, k = layout["broker"], layout["kernel"]
    size = b["Local"]["size"]
    assert len(banks) == 2*size and size == 4352 and len(clients) == 3*b["Client"]["size"]
    assert len(endpoints) == k["SyncIpc<3>"]["size"]

    def none(data, off, types, ty):
        f = types[ty]["fields"]
        return uint(data, off+f["discriminant"], f["disc_size"]) == f["None"]

    def socket_state(bank):
        parent = b["Local"]["fields"]
        obj = b["Socket"]["fields"]
        counts = {}
        for field, width in (("kind",1),("bound",1),("npending",8),("nbytes",8),("nrecords",8)):
            values = [uint(bank, parent["objects"]+i*b["Socket"]["size"]+obj[field], width) for i in range(8)]
            counts[field] = sum(bool(v) for v in values) if field == "kind" else sum(values)
        counts["fds"] = sum(not none(bank, parent["fds"]+i*b["Option<usize>"]["size"], b, "Option<usize>") for i in range(12))
        return counts

    live_counts = socket_state(banks[live*size:(live+1)*size])
    assert not any(live_counts.values())
    for i in range(3):
        cf = b["Client"]["fields"]
        for field, ty in (("pending","Option<u64>"), ("request","Option<jnox_local_socket::Request>"),
                          ("response","Option<jnox_local_socket::Response>")):
            assert none(clients, i*b["Client"]["size"]+cf[field], b, ty)
    ep = k["SyncIpc<3>"]["fields"]
    assert list(endpoints[ep["routes"]:ep["routes"]+3]) == routes and endpoints[ep["pending_exits"]] == 0
    for i in range(3):
        pos = ep["slots"]+i*k["Slot"]["size"]
        fields = k["Slot"]["fields"]
        assert endpoints[pos+fields["alive"]] == 0
        for field, ty in (("request","Option<wire_layout::Request>"), ("receiving","Option<wire_layout::ReceiveMode>"),
                          ("completion","Option<(wire_layout::Completion, core::option::Option<usize>)>")):
            assert none(endpoints, pos+fields[field], k, ty)
    return {"live_bank":live, "live_counts":live_counts, "all_client_options_none":True,
            "all_endpoint_slots_dead_and_empty":True, "pending_exits":0,
            "last_token":uint(endpoints, ep["last_token"], 8)}


def applications(mode, owner, peer):
    if mode in ORDINARY:
        assert (owner, peer) == ORDINARY[mode]
        return {}
    if mode == "death":
        assert (owner, peer) == DEATH
        return {}
    if mode == "backlog":
        starts = owner[10:13]
        assert owner[4:7] == [51,52,53]
        assert peer[0] < peer[1] < peer[2] < peer[3] < peer[4] < starts[0] < peer[5]
        assert starts[0] < starts[1] < starts[2]
        return {"third_connect_ns":peer[5]-peer[4], "accept1_after_connect3_start_ns":starts[0]-peer[4],
                "connect3_return_after_accept1_start_ns":peer[5]-starts[0]}
    deadline, status, value, completed = owner[:4]
    assert peer[0] == deadline > 0
    expire = mode in ("expired","fullexpire")
    assert (status,value) == ((-110,0) if expire else (0,1))
    assert (peer[1] > completed >= deadline) if expire else (peer[1] < completed < deadline and peer[2] < deadline)
    assert peer[1] < peer[2]
    if mode in ("ready","expired"):
        assert peer[3] == 1 and owner[6:8] == [-1,11]
        assert owner[4:6] == [1,109] if expire else owner[8:10] == [257,109]
    else:
        assert owner[4:9] == [1]*5
        assert peer[3:8] == [17,34,51,68,0 if expire else 238]
        assert peer[8:10] == [-11,123]
    return {"deadline_ns":deadline, "owner_return_minus_deadline_ns":completed-deadline,
            "peer_start_minus_deadline_ns":peer[1]-deadline, "peer_end_minus_deadline_ns":peer[2]-deadline}


def capture(raw, mode, policy, traced, layout):
    case = f"{mode}-{policy}"
    folder = raw / (("trace-" if traced else "cap-") + case)
    pkg = raw / ("pkg-"+case)
    session = json.loads((folder/"session.json").read_bytes())
    launch = json.loads((folder/"launch.json").read_bytes())
    manifest = json.loads((pkg/"manifest.json").read_bytes())
    assert manifest == launch["argument_package"] and manifest["commit"] == launch["revision"] == REVISION
    assert manifest["tracked_changes"] == "" and manifest["socket_service"] == {"slot":2,"authorized_clients":[0,1]}
    assert (manifest["policy"],manifest["board"],manifest["quantum_ticks"]) == (policy,"virt",625000 if policy=="rr" else None)
    args = launch["argv"]
    for flag, value in (("-machine","virt,gic-version=2"),("-cpu","cortex-a72"),("-smp","1"),("-accel","tcg")):
        assert args[args.index(flag)+1] == value
    assert ("-singlestep" in args) == traced
    expected_files = {"kernel.elf","user.elf","probe.c","ram.bin","uart.bin","launch.json","stderr"}
    if traced:
        expected_files.add("registers.log")
    assert set(session["hashes"]) == expected_files
    for name, want in session["hashes"].items():
        assert digest(folder/name) == want, (folder.name,name)
    assert digest(pkg/"kernel.elf") == session["hashes"]["kernel.elf"] == manifest["kernel_elf_sha256"] == launch["kernel_sha256"]
    uart = (folder/"uart.bin").read_text()
    slot_hashes = re.findall(r"^NATIVE EL0 (?:PEER2? )?ELF ([0-9a-f]{64})$",uart,re.M)
    assert len(slot_hashes)==3 and slot_hashes[2] == BROKER
    assert launch["user_sha256"] == session["hashes"]["user.elf"] == slot_hashes[0]
    exits = sorted((int(s),int(e)) for s,e in re.findall(r"^NATIVE EL0 EXIT PID (\d+) (-?\d+)$",uart,re.M))
    codes = (73,74,0) if mode in ORDINARY else (62,63,0) if mode=="death" else (201,202,0) if mode.startswith("full") else (81,82,0)
    assert exits == list(enumerate(codes)) and session["marker"] == f"EXIT {codes[0]}" and "FAULT" not in uart
    drops, = re.findall(r"^NATIVE FIXED DROPPED (\d+)$",uart,re.M)
    ram = (folder/"ram.bin").read_bytes()
    base = launch["ram_base"]
    assert len(ram) == launch["ram_bytes"]
    kernel = elf_symbols(pkg/"kernel.elf")
    spaces, size = unique(kernel,"6SPACES")
    assert size % 3 == 0
    physical = [set() for _ in range(3)]
    def fetch(slot, va, n):
        return private_read(ram,base,spaces+slot*(size//3),va,n,physical[slot])
    slots = manifest["slots"]
    assert [s["priority"] for s in slots] == [7,4,1]
    assert [s["argv"][1:] for s in slots] == [["0d" if mode=="death" else mode],["1d" if mode=="death" else mode],["3"]]
    vectors = []
    for i,s in enumerate(slots):
        elf = pkg/s["elf"]
        assert s["slot"] == i and digest(elf) == s["elf_sha256"] == slot_hashes[i]
        symbols = elf_symbols(elf)
        if i == 2:
            banks_va, banks_n = unique(symbols,"5BANKS")
            clients_va, clients_n = unique(symbols,"12CLIENT_STATE")
            startup, n = kernel["jnox_native_startup_slots"]
            assert n == 3*32
            stack = uint(ram,startup-base+2*32+8,8) - 128  # main's pinned 0x80-byte frame
            addr, live = struct.unpack("<QQ",fetch(2,stack,16))
            assert addr == banks_va and live in (0,1)
            endpoints, n = unique(kernel,"9ENDPOINTS")
            routes = [0,0,0]
            for route in manifest["ipc_routes"]:
                routes[route["caller"]] |= 1 << route["server"]
            assert routes == ([4,4,0] if mode in ORDINARY or mode=="death" else [6,5,0])
            state = final_state(fetch(i,banks_va,banks_n),fetch(i,clients_va,clients_n),
                                ram[endpoints-base:endpoints-base+n], live,layout,routes)
        else:
            key = ("socket_server_result","socket_client_result") if mode in ORDINARY else ("full_owner_result","full_peer_result") if mode.startswith("full") else ("extra_owner_result","extra_peer_result")
            va, n = symbols["observed" if mode=="death" else key[i]]
            vals = list(struct.unpack(f"<{n//8}q",fetch(i,va,n)))
            if mode=="death":
                length = uint(fetch(i,*symbols["observed_count"]),0,4)
                assert 0 <= length <= len(vals)
                vals = vals[:length]
            vectors.append(vals)
    assert all(physical[i].isdisjoint(physical[j]) for i,j in ((0,1),(0,2),(1,2)))
    offsets = applications(mode,*vectors)
    result = {"exits":codes,"kernel":manifest["kernel_elf_sha256"],"uart_dropped":int(drops),
              "owner":vectors[0],"peer":vectors[1],"guest_time":offsets,"terminal":state}
    if traced:
        result["registers"] = register_events(folder/"registers.log",mode,stack,banks_va,clients_va,live,state["last_token"])
    return result


def register_events(path, mode, stack, banks_va, clients_va, terminal_live, last_token):
    # QEMU's filter is virtual and all three programs share VAs. Identify the
    # broker with its private frame, client/bank addresses and ABI registers.
    # Indices below count raw register records, including incidental PC matches.
    events, calls, ops, deaths = [], {}, {}, []
    live, current = 0, None
    def mark(i, kind, token, **fields):
        record = {"index":i,"event":kind,"token":token,**fields}
        events.append(record)
        return record
    operations = {
        0x40069c: (7,21,"record_receive_remaining",9), 0x4008c4: (6,20,"record_send_occupancy",21),
        0x400940: (6,20,"record_send_new_count",8), 0x401334: (3,22,"connect_occupancy",10),
        0x401440: (3,22,"connect_new_count",8), 0x400d74: (5,20,"accept_occupancy",8),
        0x400db8: (5,20,"accept_remaining",9), 0x400620: (7,21,"stream_receive_remaining",9),
    }
    for i, record in enumerate(path.read_text().split(" PC=")[1:]):
        pc = int(record.split()[0],16)
        x = {int(k):int(v,16) for k,v in re.findall(r"X(\d+)=([0-9a-f]+)",record)}
        sp = int(re.search(r" SP=([0-9a-f]+)",record)[1],16)
        if "EL0t" not in record:
            continue
        if pc == 0x40222c and (sp,x[8],x[19]) == (stack,37,clients_va):
            assert x[0] == 0 and x[3] in (0,1)
            t, word, owner = x[1], x[2], x[3]
            current = None
            if t == 0:
                assert word == 0 and owner not in deaths
                deaths.append(owner)
                mark(i,"exit",0,owner=owner)
            else:
                tag = word >> 56
                if tag == 17:
                    ops[owner] = (word >> 48) & 255
                assert t not in calls and owner not in deaths
                calls[t] = dict(owner=owner,word=word,tag=tag,op=ops.get(owner),arrival=i,steps=[])
                mark(i,"arrival",t,owner=owner,tag=tag)
        elif pc == 0x402288 and sp == stack and x[19] == clients_va:
            assert x[3] == deaths[-1] and x[0] == banks_va+live*4352
            mark(i,"exit_cleanup",0,owner=x[3],bank=live)
        elif pc == 0x4015f0 and sp == stack and x[1] == stack and x[0] == stack+16:
            t, owner = x[4],x[3]
            assert t in calls and calls[t]["owner"] == owner and x[2] == clients_va+272*owner
            c = calls[t]
            assert "result" not in c
            assert x[5] == (0 if c["steps"] else 1)
            if x[5]:
                assert x[6] >> 56 == c["tag"]
            else:
                assert c["tag"] == 19
            current = t
            c["steps"].append(i)
            mark(i,"step",t,retry=x[5]==0)
        elif current is not None:
            c = calls[current]
            if pc == 0x401684 and x[21] == stack and x[27] == banks_va:
                assert c["tag"] == 19 and x[23] == live
                mark(i,"prepare",current,live=live)
            elif pc == 0x402050 and x[8] == 23 and x[21] == stack:
                assert x[0] == x[22] == current and "value" not in c
                c.update(value=signed(x[1]),reply=i)
                mark(i,"reply",current,value=c["value"])
            elif pc == 0x402054 and x[8] == 23 and x[21] == stack:
                assert x[22] == current and "value" in c and "result" not in c
                c.update(result=signed(x[0]),returned=i)
                assert c["result"] in (0,-116)
                mark(i,"returned",current,status=c["result"])
            elif pc == 0x40206c and x[21] == stack and x[20] == clients_va+c["owner"]*272:
                assert c["tag"] == 19 and c["result"] == 0 and c["value"] >= 0
                assert x[22] == current and x[23] == 1-live and "publish" not in c
                live = x[23]
                c["publish"] = i
                mark(i,"publish",current,bank=live)
            elif c["tag"] == 19 and pc in operations:
                op, ptr, label, reg = operations[pc]
                offset = x[ptr]-banks_va
                if c["op"] != op or not 0 <= offset < 2*4352:
                    continue
                bank, local = divmod(offset,4352)
                if local % 520 or local >= 4160:
                    continue
                assert bank == 1-live
                fields = {"count":x[reg], "bank":bank}
                if label == "connect_occupancy":
                    fields["limit"] = x[8]
                mark(i,label,current,**fields)
    assert set(deaths)=={0,1} and len([e for e in events if e["event"]=="exit_cleanup"])==2
    direct = 0 if mode in ORDINARY or mode=="death" else 4 if mode.startswith("full") else 2
    assert max(calls) <= last_token and len(calls)+direct==last_token and live == terminal_live
    assert all(c["steps"] and "result" in c and
               ("publish" in c)==(c["tag"]==19 and c["result"]==0 and c["value"]>=0) for c in calls.values())
    stale = [t for t,c in calls.items() if c["result"]==-116]
    assert len(stale)==int(mode in ("expired","fullexpire"))
    def matching(owner,op):
        return [t for t,c in calls.items() if (c["owner"],c["tag"],c["op"])==(owner,19,op)]
    def seen(t, name):
        return [e for e in events if e["token"]==t and e["event"]==name]
    def summarize(t):
        c = calls[t]
        return {"token":t,"owner":c["owner"],"op":c["op"],"arrival":c["arrival"], "attempts":len(c["steps"]),
                "last_attempt":c["steps"][-1],"reply":c["reply"],"value":c["value"],
                "returned":c["returned"],"status":c["result"],"publication":c.get("publish")}
    def assert_between(wait,activity):
        c,a = calls[wait],calls[activity]
        assert c["arrival"] < a["arrival"] < a["publish"] < c["steps"][-1] < c["reply"]
        assert len(c["steps"]) > 1
        assert not any(e["event"]=="arrival" and e["owner"]==c["owner"] and c["arrival"]<e["index"]<c["returned"]
                       for e in events)
    witness = {}
    if mode in ("expired","ready","fullexpire","fullready"):
        full = mode.startswith("full")
        expire = mode in ("expired","fullexpire")
        if full:
            wait, = [t for t in matching(0,6) if len(calls[t]["steps"])>1]
            activity = matching(1,7)[0]
            assert seen(wait,"record_send_occupancy")[0]["count"] == 4
            assert seen(activity,"record_receive_remaining")[-1]["count"] == 3
            after, = seen(wait,"record_send_new_count")
            assert after["count"] == 4
        else:
            wait, = [t for t in matching(0,7) if len(calls[t]["steps"])>1]
            activity, = matching(1,6)
            assert seen(activity,"record_send_new_count")[-1]["count"] == 1
            after, = seen(wait,"record_receive_remaining")
            assert after["count"] == 0
        assert_between(wait,activity)
        c = calls[wait]
        assert calls[activity]["publish"] < after["index"] < c["reply"]
        assert c["value"]==1 and c["result"]==(-116 if expire else 0)
        assert not any(c["tag"]==22 and c["owner"]==0 for c in calls.values())
        witness.update(wait=summarize(wait),peer=summarize(activity),trial_queue_store=after)
        following = [e for e in events if e["event"]=="prepare" and e["index"]>c["returned"]][0]
        assert following["live"] == (1-after["bank"] if expire else after["bank"])
        witness["next_commit_live"] = following
        if full:
            sends = matching(0,6)
            assert len(sends)==6 and all(calls[t]["value"]==1 for t in sends)
            chunks = [c["word"].to_bytes(8,"little")[:6] for c in calls.values()
                      if c["owner"]==0 and c["tag"]==18 and c["op"]==6]
            assert chunks == [b"/sink"+bytes([b]) for b in (17,34,51,68,238,123)]
            reads = [c["value"] for c in calls.values() if c["owner"]==1 and c["tag"]==21]
            assert reads == [17,34,51,68]+([] if expire else [238])+[123]
            empty, = [t for t in matching(1,7) if calls[t]["value"]==-11]
            next_owner = min(c["arrival"] for c in calls.values() if c["owner"]==0 and c["arrival"]>calls[wait]["returned"])
            assert calls[empty]["returned"] < next_owner
            witness.update(record_reads=reads,empty_receive=summarize(empty),next_owner_arrival=next_owner)
        else:
            reads = [c["value"] for c in calls.values() if c["owner"]==0 and c["tag"]==21]
            meta = [c["value"] for c in calls.values() if c["owner"]==0 and c["tag"]==20]
            assert reads == [109] and meta == [257]
            witness.update(read_words=reads,metadata=meta)
    elif mode=="backlog":
        connects, accepts = matching(1,3), matching(0,5)
        assert len(connects)==len(accepts)==3
        wait, activity = connects[2], accepts[0]
        assert_between(wait,activity)
        occupancies = seen(wait,"connect_occupancy")
        assert [x["count"] for x in occupancies[:-1]] == [2]*(len(occupancies)-1)
        assert len(occupancies)>1 and occupancies[-1]["count"]==1 and all(x["limit"]==2 for x in occupancies)
        assert [seen(t,"connect_new_count")[-1]["count"] for t in connects]==[1,2,2]
        assert [seen(t,"accept_remaining")[-1]["count"] for t in accepts]==[1,1,0]
        assert calls[wait]["value"]==0 and calls[wait]["result"]==0
        witness.update(wait=summarize(wait),accept=summarize(activity),connect_occupancy=occupancies,
                       accept_after=[1,1,0])
    elif mode=="death":
        waits = [t for t in matching(0,6) if len(calls[t]["steps"])>1]
        drained, closed = waits
        activity, = matching(1,7)
        assert_between(drained,activity)
        exit_event, = [e for e in events if e["event"]=="exit_cleanup" and e["owner"]==1]
        assert calls[closed]["arrival"]<exit_event["index"]<calls[closed]["steps"][-1]
        assert calls[drained]["value"]==1 and calls[closed]["value"]==-32
        witness.update(drain_wait=summarize(drained),receive=summarize(activity),exit_wait=summarize(closed),peer_exit=exit_event)
    return {"broker_requests":len(calls),"reply_syscalls":sum("reply" in c for c in calls.values()),
            "commit_publications":sum("publish" in c for c in calls.values()),"stale_tokens":stale,
            "exit_order":deaths, "witness":witness}


def run(raw):
    assert digest(raw/"broker.dis")=="29017c7912b86a16ae6606d373e8144eb5fe466857784c915db1026bbc32dfe9"
    assert digest(raw/"layout.json")=="573800a68555de508923ac90926cb34989a1efe39c71326d44db620bd91f9940"
    layout = json.loads((raw/"layout.json").read_bytes())
    out = {}
    for mode in MODES:
        for policy in ("fifo","rr"):
            case = mode+"-"+policy
            pair = {}
            for traced in (False,True):
                try:
                    pair["register_repeat" if traced else "original"] = capture(raw,mode,policy,traced,layout)
                except Exception as error:
                    raise ValueError(f"{case}, traced={traced}") from error
            assert pair["original"]["kernel"]==pair["register_repeat"]["kernel"]
            out[case] = pair
    return json.dumps(out,indent=2,sort_keys=True)+"\n"


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("packet",type=Path,help="original .tar.gz or previously extracted directory")
    p.add_argument("-o","--output",type=Path,help="write deterministic UTF-8 JSON with LF")
    args = p.parse_args()
    if not __debug__:
        raise SystemExit("Run without -O so evidence assertions are enabled.")
    with tempfile.TemporaryDirectory() as tmp:
        raw = args.packet
        if raw.is_file():
            assert digest(raw)==PACKET, "unexpected original capture archive"
            with tarfile.open(raw) as archive:
                for entry in archive:
                    # This pinned archive consists entirely of ordinary files.
                    target = Path(tmp)/entry.name
                    assert entry.isfile() and target.resolve().is_relative_to(Path(tmp).resolve())
                    target.parent.mkdir(parents=True,exist_ok=True)
                    with archive.extractfile(entry) as source, target.open("wb") as dest:
                        shutil.copyfileobj(source,dest)
            raw = Path(tmp)
        result = run(raw)
    if args.output:
        args.output.write_bytes(result.encode())
    else:
        sys.stdout.buffer.write(result.encode())
