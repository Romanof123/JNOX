
parent-SF.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000040200000 <_start>:
    40200000:	d5034fdf 	msr	daifset, #0xf
    40200004:	d5384240 	mrs	x0, currentel
    40200008:	f100101f 	cmp	x0, #0x4
    4020000c:	54000241 	b.ne	40200054 <_start+0x54>  // b.any
    40200010:	d50041bf 	msr	spsel, #0x1
    40200014:	58000260 	ldr	x0, 40200060 <_start+0x60>
    40200018:	9100001f 	mov	sp, x0
    4020001c:	d5381040 	mrs	x0, cpacr_el1
    40200020:	b26c0400 	orr	x0, x0, #0x300000
    40200024:	d5181040 	msr	cpacr_el1, x0
    40200028:	d5033fdf 	isb
    4020002c:	580001e0 	ldr	x0, 40200068 <_start+0x68>
    40200030:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    40200034:	f9000001 	str	x1, [x0]
    40200038:	580001c0 	ldr	x0, 40200070 <_start+0x70>
    4020003c:	580001e1 	ldr	x1, 40200078 <_start+0x78>
    40200040:	eb01001f 	cmp	x0, x1
    40200044:	54000062 	b.cs	40200050 <_start+0x50>  // b.hs, b.nlast
    40200048:	f800841f 	str	xzr, [x0], #8
    4020004c:	17fffffd 	b	40200040 <_start+0x40>
    40200050:	14001079 	b	40204234 <jnox_kernel::kernel_main>
    40200054:	d503205f 	wfe
    40200058:	17ffffff 	b	40200054 <_start+0x54>
    4020005c:	00000000 	udf	#0
    40200060:	40227e40 	.word	0x40227e40
    40200064:	00000000 	.word	0x00000000
    40200068:	40223e20 	.word	0x40223e20
    4020006c:	00000000 	.word	0x00000000
    40200070:	40207710 	.word	0x40207710
    40200074:	00000000 	.word	0x00000000
    40200078:	40223e40 	.word	0x40223e40
	...

0000000040200800 <sched_vectors>:
    40200800:	14000200 00000000 00000000 00000000     ................
	...
    40200880:	140001e0 00000000 00000000 00000000     ................
	...
    40200900:	140001c0 00000000 00000000 00000000     ................
	...
    40200980:	140001a0 00000000 00000000 00000000     ................
	...
    40200a00:	140001b6 00000000 00000000 00000000     ................
	...
    40200a80:	14000161 00000000 00000000 00000000     a...............
	...
    40200b00:	14000140 00000000 00000000 00000000     @...............
	...
    40200b80:	14000120 00000000 00000000 00000000      ...............
	...
    40200c00:	14000100 00000000 00000000 00000000     ................
	...
    40200c80:	140000e0 00000000 00000000 00000000     ................
	...
    40200d00:	140000c0 00000000 00000000 00000000     ................
	...
    40200d80:	140000a0 00000000 00000000 00000000     ................
	...
    40200e00:	14000080 00000000 00000000 00000000     ................
	...
    40200e80:	14000060 00000000 00000000 00000000     `...............
	...
    40200f00:	14000040 00000000 00000000 00000000     @...............
	...
    40200f80:	14000020 00000000 00000000 00000000      ...............
	...
    40201000:	140000aa d10d03ff f90027e9 d5033fdf     .........'...?..
    40201010:	d53be029 f9009fe9 f94027e9 a90007e0     ).;......'@.....
    40201020:	a9010fe2 a90217e4 a9031fe6 a90427e8     .............'..
    40201030:	a9052fea a90637ec a9073fee a90847f0     ./...7...?...G..
    40201040:	a9094ff2 a90a57f4 a90b5ff6 a90c67f8     .O...W..._...g..
    40201050:	a90d6ffa a90e77fc f9007bfe ad0a07e0     .o...w...{......
    40201060:	ad0b0fe2 ad0c17e4 ad0d1fe6 ad0e27e8     .............'..
    40201070:	ad0f2fea ad1037ec ad113fee ad1247f0     ./...7...?...G..
    40201080:	ad134ff2 ad1457f4 ad155ff6 ad1667f8     .O...W..._...g..
    40201090:	ad176ffa ad1877fc ad197ffe d5384029     .o...w......)@8.
    402010a0:	d538400a a90fabe9 d53b4409 d53b442a     .@8......D;.*D;.
    402010b0:	a910abe9 d538d089 d538410a a911abe9     ......8..A8.....
    402010c0:	d53bd049 d53bd06a a912abe9 910003e0     I.;.j.;.........
    402010d0:	9400007e 14000036 d10d03ff f90027e9     ~...6........'..
    402010e0:	d5033fdf d53be029 f9009fe9 f94027e9     .?..).;......'@.
    402010f0:	a90007e0 a9010fe2 a90217e4 a9031fe6     ................
    40201100:	a90427e8 a9052fea a90637ec a9073fee     .'.../...7...?..
    40201110:	a90847f0 a9094ff2 a90a57f4 a90b5ff6     .G...O...W..._..
    40201120:	a90c67f8 a90d6ffa a90e77fc f9007bfe     .g...o...w...{..
    40201130:	ad0a07e0 ad0b0fe2 ad0c17e4 ad0d1fe6     ................
    40201140:	ad0e27e8 ad0f2fea ad1037ec ad113fee     .'.../...7...?..
    40201150:	ad1247f0 ad134ff2 ad1457f4 ad155ff6     .G...O...W..._..
    40201160:	ad1667f8 ad176ffa ad1877fc ad197ffe     .g...o...w......
    40201170:	d5384029 d538400a a90fabe9 d53b4409     )@8..@8......D;.
    40201180:	d53b442a a910abe9 d538d089 d538410a     *D;.......8..A8.
    40201190:	a911abe9 d53bd049 d53bd06a a912abe9     ....I.;.j.;.....
    402011a0:	910003e0 940003bf 14000001              ............

00000000402011ac <sched_start_frame>:
    402011ac:	9100001f 	mov	sp, x0
    402011b0:	a94fabe9 	ldp	x9, x10, [sp, #248]
    402011b4:	d5184029 	msr	elr_el1, x9
    402011b8:	d518400a 	msr	spsr_el1, x10
    402011bc:	a950abe9 	ldp	x9, x10, [sp, #264]
    402011c0:	d51b4409 	msr	fpcr, x9
    402011c4:	d51b442a 	msr	fpsr, x10
    402011c8:	a951abe9 	ldp	x9, x10, [sp, #280]
    402011cc:	d518d089 	msr	tpidr_el1, x9
    402011d0:	d518410a 	msr	sp_el0, x10
    402011d4:	a952abe9 	ldp	x9, x10, [sp, #296]
    402011d8:	d51bd049 	msr	tpidr_el0, x9
    402011dc:	d51bd06a 	msr	tpidrro_el0, x10
    402011e0:	ad4a07e0 	ldp	q0, q1, [sp, #320]
    402011e4:	ad4b0fe2 	ldp	q2, q3, [sp, #352]
    402011e8:	ad4c17e4 	ldp	q4, q5, [sp, #384]
    402011ec:	ad4d1fe6 	ldp	q6, q7, [sp, #416]
    402011f0:	ad4e27e8 	ldp	q8, q9, [sp, #448]
    402011f4:	ad4f2fea 	ldp	q10, q11, [sp, #480]
    402011f8:	ad5037ec 	ldp	q12, q13, [sp, #512]
    402011fc:	ad513fee 	ldp	q14, q15, [sp, #544]
    40201200:	ad5247f0 	ldp	q16, q17, [sp, #576]
    40201204:	ad534ff2 	ldp	q18, q19, [sp, #608]
    40201208:	ad5457f4 	ldp	q20, q21, [sp, #640]
    4020120c:	ad555ff6 	ldp	q22, q23, [sp, #672]
    40201210:	ad5667f8 	ldp	q24, q25, [sp, #704]
    40201214:	ad576ffa 	ldp	q26, q27, [sp, #736]
    40201218:	ad5877fc 	ldp	q28, q29, [sp, #768]
    4020121c:	ad597ffe 	ldp	q30, q31, [sp, #800]
    40201220:	d503201f 	nop
    40201224:	10112e29 	adr	x9, 402237e8 <jnox_ap_returns>
    40201228:	f940012a 	ldr	x10, [x9]
    4020122c:	f101015f 	cmp	x10, #0x40
    40201230:	54ffee82 	b.cs	40201000 <sched_vectors+0x800>  // b.hs, b.nlast
    40201234:	9100054b 	add	x11, x10, #0x1
    40201238:	f800852b 	str	x11, [x9], #8
    4020123c:	d280030b 	mov	x11, #0x18                  	// #24
    40201240:	9b0b2549 	madd	x9, x10, x11, x9
    40201244:	910003ea 	mov	x10, sp
    40201248:	d538402b 	mrs	x11, elr_el1
    4020124c:	a9002d2a 	stp	x10, x11, [x9]
    40201250:	d5033fdf 	isb
    40201254:	d53be02a 	mrs	x10, cntpct_el0
    40201258:	f900092a 	str	x10, [x9, #16]
    4020125c:	a94007e0 	ldp	x0, x1, [sp]
    40201260:	a9410fe2 	ldp	x2, x3, [sp, #16]
    40201264:	a94217e4 	ldp	x4, x5, [sp, #32]
    40201268:	a9431fe6 	ldp	x6, x7, [sp, #48]
    4020126c:	a94427e8 	ldp	x8, x9, [sp, #64]
    40201270:	a9452fea 	ldp	x10, x11, [sp, #80]
    40201274:	a94637ec 	ldp	x12, x13, [sp, #96]
    40201278:	a9473fee 	ldp	x14, x15, [sp, #112]
    4020127c:	a94847f0 	ldp	x16, x17, [sp, #128]
    40201280:	a9494ff2 	ldp	x18, x19, [sp, #144]
    40201284:	a94a57f4 	ldp	x20, x21, [sp, #160]
    40201288:	a94b5ff6 	ldp	x22, x23, [sp, #176]
    4020128c:	a94c67f8 	ldp	x24, x25, [sp, #192]
    40201290:	a94d6ffa 	ldp	x26, x27, [sp, #208]
    40201294:	a94e77fc 	ldp	x28, x29, [sp, #224]
    40201298:	f9407bfe 	ldr	x30, [sp, #240]
    4020129c:	910d03ff 	add	sp, sp, #0x340
    402012a0:	d5033f5f 	clrex
    402012a4:	d69f03e0 	eret

00000000402012a8 <jnox_kernel::ordinary_reservations::unexpected>:
    402012a8:	f81f0ffe 	str	x30, [sp, #-16]!
    402012ac:	52800060 	mov	w0, #0x3                   	// #3
    402012b0:	52800021 	mov	w1, #0x1                   	// #1
    402012b4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    402012b8:	52800043 	mov	w3, #0x2                   	// #2
    402012bc:	aa1f03e4 	mov	x4, xzr
    402012c0:	aa1f03e5 	mov	x5, xzr
    402012c4:	94000507 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>

00000000402012c8 <jnox_kernel::ordinary_reservations::irq>:
    402012c8:	d10583ff 	sub	sp, sp, #0x160
    402012cc:	a9107bfd 	stp	x29, x30, [sp, #256]
    402012d0:	a9116ffc 	stp	x28, x27, [sp, #272]
    402012d4:	a91267fa 	stp	x26, x25, [sp, #288]
    402012d8:	a9135ff8 	stp	x24, x23, [sp, #304]
    402012dc:	a91457f6 	stp	x22, x21, [sp, #320]
    402012e0:	a9154ff4 	stp	x20, x19, [sp, #336]
    402012e4:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402012e8:	f9420108 	ldr	x8, [x8, #1024]
    402012ec:	f100091f 	cmp	x8, #0x2
    402012f0:	540033a0 	b.eq	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.none
    402012f4:	aa0003f4 	mov	x20, x0
    402012f8:	d0000038 	adrp	x24, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402012fc:	d503201f 	nop
    40201300:	100b2108 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241>
    40201304:	f942b309 	ldr	x9, [x24, #1376]
    40201308:	8b09390a 	add	x10, x8, x9, lsl #14
    4020130c:	eb00015f 	cmp	x10, x0
    40201310:	540032a8 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    40201314:	b10d069f 	cmn	x20, #0x341
    40201318:	54003268 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    4020131c:	d372c529 	lsl	x9, x9, #14
    40201320:	8b090108 	add	x8, x8, x9
    40201324:	91401108 	add	x8, x8, #0x4, lsl #12
    40201328:	910d0289 	add	x9, x20, #0x340
    4020132c:	eb08013f 	cmp	x9, x8
    40201330:	540031a8 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    40201334:	52800199 	mov	w25, #0xc                   	// #12
    40201338:	72a10039 	movk	w25, #0x801, lsl #16
    4020133c:	f9409e95 	ldr	x21, [x20, #312]
    40201340:	b9400336 	ldr	w22, [x25]
    40201344:	d53be237 	mrs	x23, cntp_ctl_el0
    40201348:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020134c:	91156129 	add	x9, x9, #0x558
    40201350:	f9401928 	ldr	x8, [x9, #48]
    40201354:	f9400133 	ldr	x19, [x9]
    40201358:	f100051f 	cmp	x8, #0x1
    4020135c:	540000e0 	b.eq	40201378 <jnox_kernel::ordinary_reservations::irq+0xb0>  // b.none
    40201360:	b100067f 	cmn	x19, #0x1
    40201364:	54000060 	b.eq	40201370 <jnox_kernel::ordinary_reservations::irq+0xa8>  // b.none
    40201368:	91000673 	add	x19, x19, #0x1
    4020136c:	14000003 	b	40201378 <jnox_kernel::ordinary_reservations::irq+0xb0>
    40201370:	b40045c8 	cbz	x8, 40201c28 <jnox_kernel::ordinary_reservations::irq+0x960>
    40201374:	aa1f03f3 	mov	x19, xzr
    40201378:	d000003a 	adrp	x26, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020137c:	9115835a 	add	x26, x26, #0x560
    40201380:	f9401349 	ldr	x9, [x26, #32]
    40201384:	a90923e9 	stp	x9, x8, [sp, #144]
    40201388:	f9400343 	ldr	x3, [x26]
    4020138c:	a90a5ff6 	stp	x22, x23, [sp, #160]
    40201390:	910243e4 	add	x4, sp, #0x90
    40201394:	52800080 	mov	w0, #0x4                   	// #4
    40201398:	aa1503e1 	mov	x1, x21
    4020139c:	aa1303e2 	mov	x2, x19
    402013a0:	94000479 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    402013a4:	f9401348 	ldr	x8, [x26, #32]
    402013a8:	120026c9 	and	w9, w22, #0x3ff
    402013ac:	7100793f 	cmp	w9, #0x1e
    402013b0:	54004e41 	b.ne	40201d78 <jnox_kernel::ordinary_reservations::irq+0xab0>  // b.any
    402013b4:	92400ae9 	and	x9, x23, #0x7
    402013b8:	f100153f 	cmp	x9, #0x5
    402013bc:	54004de1 	b.ne	40201d78 <jnox_kernel::ordinary_reservations::irq+0xab0>  // b.any
    402013c0:	eb0802bf 	cmp	x21, x8
    402013c4:	54004da3 	b.cc	40201d78 <jnox_kernel::ordinary_reservations::irq+0xab0>  // b.lo, b.ul, b.last
    402013c8:	d51be23f 	msr	cntp_ctl_el0, xzr
    402013cc:	d5033fdf 	isb
    402013d0:	d5033f9f 	dsb	sy
    402013d4:	b9000736 	str	w22, [x25, #4]
    402013d8:	d5033f9f 	dsb	sy
    402013dc:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402013e0:	f942c508 	ldr	x8, [x8, #1416]
    402013e4:	f100051f 	cmp	x8, #0x1
    402013e8:	540003e1 	b.ne	40201464 <jnox_kernel::ordinary_reservations::irq+0x19c>  // b.any
    402013ec:	aa1403e0 	mov	x0, x20
    402013f0:	aa1503e1 	mov	x1, x21
    402013f4:	2a1f03e2 	mov	w2, wzr
    402013f8:	aa1f03e3 	mov	x3, xzr
    402013fc:	9400066f 	bl	40202db8 <jnox_kernel::ordinary_reservations::Runtime::close>
    40201400:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201404:	9114e108 	add	x8, x8, #0x538
    40201408:	91000669 	add	x9, x19, #0x1
    4020140c:	a9402908 	ldp	x8, x10, [x8]
    40201410:	9bca7d2b 	umulh	x11, x9, x10
    40201414:	eb0b03ff 	cmp	xzr, x11
    40201418:	1a9f07eb 	cset	w11, ne  // ne = any
    4020141c:	9b0a7d29 	mul	x9, x9, x10
    40201420:	ab080122 	adds	x2, x9, x8
    40201424:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40201428:	37004a4b 	tbnz	w11, #0, 40201d70 <jnox_kernel::ordinary_reservations::irq+0xaa8>
    4020142c:	35004a28 	cbnz	w8, 40201d70 <jnox_kernel::ordinary_reservations::irq+0xaa8>
    40201430:	aa1303e0 	mov	x0, x19
    40201434:	aa1f03e1 	mov	x1, xzr
    40201438:	9400063f 	bl	40202d34 <jnox_kernel::ordinary_reservations::Runtime::arm>
    4020143c:	aa1303e0 	mov	x0, x19
    40201440:	52800041 	mov	w1, #0x2                   	// #2
    40201444:	a9554ff4 	ldp	x20, x19, [sp, #336]
    40201448:	a95457f6 	ldp	x22, x21, [sp, #320]
    4020144c:	a9535ff8 	ldp	x24, x23, [sp, #304]
    40201450:	a95267fa 	ldp	x26, x25, [sp, #288]
    40201454:	a9516ffc 	ldp	x28, x27, [sp, #272]
    40201458:	a9507bfd 	ldp	x29, x30, [sp, #256]
    4020145c:	910583ff 	add	sp, sp, #0x160
    40201460:	1400078f 	b	4020329c <jnox_kernel::ordinary_reservations::Runtime::select>
    40201464:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201468:	9114c129 	add	x9, x9, #0x530
    4020146c:	f940192a 	ldr	x10, [x9, #48]
    40201470:	f100095f 	cmp	x10, #0x2
    40201474:	54002781 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201478:	39400129 	ldrb	w9, [x9]
    4020147c:	71000d3f 	cmp	w9, #0x3
    40201480:	54002721 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201484:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201488:	91152129 	add	x9, x9, #0x548
    4020148c:	f9001934 	str	x20, [x9, #48]
    40201490:	f9401d25 	ldr	x5, [x9, #56]
    40201494:	cb0502aa 	sub	x10, x21, x5
    40201498:	f9400129 	ldr	x9, [x9]
    4020149c:	eb09015f 	cmp	x10, x9
    402014a0:	54004848 	b.hi	40201da8 <jnox_kernel::ordinary_reservations::irq+0xae0>  // b.pmore
    402014a4:	b40013f3 	cbz	x19, 40201720 <jnox_kernel::ordinary_reservations::irq+0x458>
    402014a8:	92800028 	mov	x8, #0xfffffffffffffffe    	// #-2
    402014ac:	d0000037 	adrp	x23, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014b0:	d0000038 	adrp	x24, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014b4:	91174318 	add	x24, x24, #0x5d0
    402014b8:	b4000428 	cbz	x8, 4020153c <jnox_kernel::ordinary_reservations::irq+0x274>
    402014bc:	aa0803f6 	mov	x22, x8
    402014c0:	910243e8 	add	x8, sp, #0x90
    402014c4:	91000ac0 	add	x0, x22, #0x2
    402014c8:	940007b1 	bl	4020338c <jnox_kernel::ordinary_reservations::snapshot>
    402014cc:	a94957f4 	ldp	x20, x21, [sp, #144]
    402014d0:	f942aae8 	ldr	x8, [x23, #1360]
    402014d4:	eb08027f 	cmp	x19, x8
    402014d8:	54000161 	b.ne	40201504 <jnox_kernel::ordinary_reservations::irq+0x23c>  // b.any
    402014dc:	f94053e8 	ldr	x8, [sp, #160]
    402014e0:	d5033fdf 	isb
    402014e4:	d53be021 	mrs	x1, cntpct_el0
    402014e8:	a90957f4 	stp	x20, x21, [sp, #144]
    402014ec:	a90a7fe8 	stp	x8, xzr, [sp, #160]
    402014f0:	91000ac3 	add	x3, x22, #0x2
    402014f4:	910243e4 	add	x4, sp, #0x90
    402014f8:	528002a0 	mov	w0, #0x15                  	// #21
    402014fc:	aa1303e2 	mov	x2, x19
    40201500:	94000421 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40201504:	f85f0308 	ldur	x8, [x24, #-16]
    40201508:	eb08029f 	cmp	x20, x8
    4020150c:	540000a1 	b.ne	40201520 <jnox_kernel::ordinary_reservations::irq+0x258>  // b.any
    40201510:	f8408709 	ldr	x9, [x24], #8
    40201514:	910006c8 	add	x8, x22, #0x1
    40201518:	eb0902bf 	cmp	x21, x9
    4020151c:	54fffce0 	b.eq	402014b8 <jnox_kernel::ordinary_reservations::irq+0x1f0>  // b.none
    40201520:	91000ac3 	add	x3, x22, #0x2
    40201524:	52800060 	mov	w0, #0x3                   	// #3
    40201528:	52800101 	mov	w1, #0x8                   	// #8
    4020152c:	aa1303e2 	mov	x2, x19
    40201530:	aa1403e4 	mov	x4, x20
    40201534:	aa1503e5 	mov	x5, x21
    40201538:	9400046a 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>
    4020153c:	f942aae8 	ldr	x8, [x23, #1360]
    40201540:	eb08027f 	cmp	x19, x8
    40201544:	54004580 	b.eq	40201df4 <jnox_kernel::ordinary_reservations::irq+0xb2c>  // b.none
    40201548:	94000744 	bl	40203258 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    4020154c:	910243e8 	add	x8, sp, #0x90
    40201550:	aa1303e1 	mov	x1, x19
    40201554:	940008d8 	bl	402038b4 <jnox_kernel::reservation_jobs::Jobs::open>
    40201558:	f9404be8 	ldr	x8, [sp, #144]
    4020155c:	f100091f 	cmp	x8, #0x2
    40201560:	54004560 	b.eq	40201e0c <jnox_kernel::ordinary_reservations::irq+0xb44>  // b.none
    40201564:	9100a3e0 	add	x0, sp, #0x28
    40201568:	910243e1 	add	x1, sp, #0x90
    4020156c:	52800d02 	mov	w2, #0x68                  	// #104
    40201570:	94001137 	bl	40205a4c <memcpy>
    40201574:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201578:	9114e129 	add	x9, x9, #0x538
    4020157c:	a9402129 	ldp	x9, x8, [x9]
    40201580:	9bc87e6a 	umulh	x10, x19, x8
    40201584:	eb0a03ff 	cmp	xzr, x10
    40201588:	1a9f07eb 	cset	w11, ne  // ne = any
    4020158c:	9b087e6a 	mul	x10, x19, x8
    40201590:	ab09014c 	adds	x12, x10, x9
    40201594:	1a9f37ea 	cset	w10, cs  // cs = hs, nlast
    40201598:	37003ecb 	tbnz	w11, #0, 40201d70 <jnox_kernel::ordinary_reservations::irq+0xaa8>
    4020159c:	35003eaa 	cbnz	w10, 40201d70 <jnox_kernel::ordinary_reservations::irq+0xaa8>
    402015a0:	9100066b 	add	x11, x19, #0x1
    402015a4:	9bc87d6a 	umulh	x10, x11, x8
    402015a8:	eb0a03ff 	cmp	xzr, x10
    402015ac:	1a9f07ea 	cset	w10, ne  // ne = any
    402015b0:	9b087d68 	mul	x8, x11, x8
    402015b4:	ab090108 	adds	x8, x8, x9
    402015b8:	a901a3ec 	stp	x12, x8, [sp, #24]
    402015bc:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    402015c0:	37003d8a 	tbnz	w10, #0, 40201d70 <jnox_kernel::ordinary_reservations::irq+0xaa8>
    402015c4:	35003d68 	cbnz	w8, 40201d70 <jnox_kernel::ordinary_reservations::irq+0xaa8>
    402015c8:	aa1f03f6 	mov	x22, xzr
    402015cc:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402015d0:	39422beb 	ldrb	w11, [sp, #138]
    402015d4:	9100a3e9 	add	x9, sp, #0x28
    402015d8:	9100613d 	add	x29, x9, #0x18
    402015dc:	b9402bfc 	ldr	w28, [sp, #40]
    402015e0:	9100e137 	add	x23, x9, #0x38
    402015e4:	91004138 	add	x24, x9, #0x10
    402015e8:	f9401bf5 	ldr	x21, [sp, #48]
    402015ec:	9100056a 	add	x10, x11, #0x1
    402015f0:	71000d7f 	cmp	w11, #0x3
    402015f4:	f902ad13 	str	x19, [x8, #1368]
    402015f8:	91000568 	add	x8, x11, #0x1
    402015fc:	a900afe8 	stp	x8, x11, [sp, #8]
    40201600:	1a8a03f9 	csel	w25, wzr, w10, eq  // eq = none
    40201604:	91016134 	add	x20, x9, #0x58
    40201608:	9101813a 	add	x26, x9, #0x60
    4020160c:	52800028 	mov	w8, #0x1                   	// #1
    40201610:	8b1613a9 	add	x9, x29, x22, lsl #4
    40201614:	8b1612ea 	add	x10, x23, x22, lsl #4
    40201618:	d5033fdf 	isb
    4020161c:	d53be021 	mrs	x1, cntpct_el0
    40201620:	2a0803fb 	mov	w27, w8
    40201624:	a9402528 	ldp	x8, x9, [x9]
    40201628:	a90927e8 	stp	x8, x9, [sp, #144]
    4020162c:	a9402548 	ldp	x8, x9, [x10]
    40201630:	a90a27e8 	stp	x8, x9, [sp, #160]
    40201634:	910243e4 	add	x4, sp, #0x90
    40201638:	528000a0 	mov	w0, #0x5                   	// #5
    4020163c:	aa1303e2 	mov	x2, x19
    40201640:	aa1603e3 	mov	x3, x22
    40201644:	940003d0 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40201648:	d5033fdf 	isb
    4020164c:	d53be021 	mrs	x1, cntpct_el0
    40201650:	b8767b08 	ldr	w8, [x24, x22, lsl #2]
    40201654:	eb1502df 	cmp	x22, x21
    40201658:	b8767a89 	ldr	w9, [x20, x22, lsl #2]
    4020165c:	38766b4a 	ldrb	w10, [x26, x22]
    40201660:	1a9f17eb 	cset	w11, eq  // eq = none
    40201664:	a90927e8 	stp	x8, x9, [sp, #144]
    40201668:	6a0b039f 	tst	w28, w11
    4020166c:	9a9f1328 	csel	x8, x25, xzr, ne  // ne = any
    40201670:	a90a23ea 	stp	x10, x8, [sp, #160]
    40201674:	910243e4 	add	x4, sp, #0x90
    40201678:	528000c0 	mov	w0, #0x6                   	// #6
    4020167c:	aa1303e2 	mov	x2, x19
    40201680:	aa1603e3 	mov	x3, x22
    40201684:	940003c0 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40201688:	2a1f03e8 	mov	w8, wzr
    4020168c:	52800036 	mov	w22, #0x1                   	// #1
    40201690:	3707fc1b 	tbnz	w27, #0, 40201610 <jnox_kernel::ordinary_reservations::irq+0x348>
    40201694:	34002bdc 	cbz	w28, 40201c0c <jnox_kernel::ordinary_reservations::irq+0x944>
    40201698:	f9400bf6 	ldr	x22, [sp, #16]
    4020169c:	71000edf 	cmp	w22, #0x3
    402016a0:	54001620 	b.eq	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.none
    402016a4:	910243e8 	add	x8, sp, #0x90
    402016a8:	aa1503e0 	mov	x0, x21
    402016ac:	94000738 	bl	4020338c <jnox_kernel::ordinary_reservations::snapshot>
    402016b0:	f1000abf 	cmp	x21, #0x2
    402016b4:	54003c22 	b.cs	40201e38 <jnox_kernel::ordinary_reservations::irq+0xb70>  // b.hs, b.nlast
    402016b8:	a94927e8 	ldp	x8, x9, [sp, #144]
    402016bc:	d503201f 	nop
    402016c0:	1002ea0a 	adr	x10, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402016c4:	8b150d4b 	add	x11, x10, x21, lsl #3
    402016c8:	f940c96c 	ldr	x12, [x11, #400]
    402016cc:	9100a3ea 	add	x10, sp, #0x28
    402016d0:	8b15114a 	add	x10, x10, x21, lsl #4
    402016d4:	f940214a 	ldr	x10, [x10, #64]
    402016d8:	eb0a019f 	cmp	x12, x10
    402016dc:	54000060 	b.eq	402016e8 <jnox_kernel::ordinary_reservations::irq+0x420>  // b.none
    402016e0:	f900c96a 	str	x10, [x11, #400]
    402016e4:	f900d17f 	str	xzr, [x11, #416]
    402016e8:	d000010b 	adrp	x11, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0xb8e0>
    402016ec:	f943f56b 	ldr	x11, [x11, #2024]
    402016f0:	d000002c 	adrp	x12, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402016f4:	9114018c 	add	x12, x12, #0x500
    402016f8:	a9004d95 	stp	x21, x19, [x12]
    402016fc:	a901218b 	stp	x11, x8, [x12, #16]
    40201700:	a9022989 	stp	x9, x10, [x12, #32]
    40201704:	3900c196 	strb	w22, [x12, #48]
    40201708:	f94013f4 	ldr	x20, [sp, #32]
    4020170c:	34002b96 	cbz	w22, 40201c7c <jnox_kernel::ordinary_reservations::irq+0x9b4>
    40201710:	b104011f 	cmn	x8, #0x100
    40201714:	540039c2 	b.cs	40201e4c <jnox_kernel::ordinary_reservations::irq+0xb84>  // b.hs, b.nlast
    40201718:	91040108 	add	x8, x8, #0x100
    4020171c:	14000159 	b	40201c80 <jnox_kernel::ordinary_reservations::irq+0x9b8>
    40201720:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201724:	f942f129 	ldr	x9, [x9, #1504]
    40201728:	f100093f 	cmp	x9, #0x2
    4020172c:	540011c0 	b.eq	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.none
    40201730:	b50011a8 	cbnz	x8, 40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>
    40201734:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201738:	f942ad08 	ldr	x8, [x8, #1368]
    4020173c:	b100051f 	cmn	x8, #0x1
    40201740:	54001121 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201744:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201748:	f9432d08 	ldr	x8, [x8, #1624]
    4020174c:	eb0800bf 	cmp	x5, x8
    40201750:	540010a1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201754:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201758:	f9429d29 	ldr	x9, [x9, #1336]
    4020175c:	eb08013f 	cmp	x9, x8
    40201760:	54001021 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201764:	d0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0xb8e0>
    40201768:	f943f508 	ldr	x8, [x8, #2024]
    4020176c:	f100051f 	cmp	x8, #0x1
    40201770:	54000fa1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201774:	d503201f 	nop
    40201778:	10110348 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    4020177c:	c8dffd09 	ldar	x9, [x8]
    40201780:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201784:	f942354a 	ldr	x10, [x10, #1128]
    40201788:	aa0a0129 	orr	x9, x9, x10
    4020178c:	b5000ec9 	cbnz	x9, 40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>
    40201790:	aa1f03eb 	mov	x11, xzr
    40201794:	5280002a 	mov	w10, #0x1                   	// #1
    40201798:	d503201f 	nop
    4020179c:	1002e337 	adr	x23, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402017a0:	8b0b02e9 	add	x9, x23, x11
    402017a4:	3941e129 	ldrb	w9, [x9, #120]
    402017a8:	3600008a 	tbz	w10, #0, 402017b8 <jnox_kernel::ordinary_reservations::irq+0x4f0>
    402017ac:	2a1f03ea 	mov	w10, wzr
    402017b0:	5280002b 	mov	w11, #0x1                   	// #1
    402017b4:	34ffff69 	cbz	w9, 402017a0 <jnox_kernel::ordinary_reservations::irq+0x4d8>
    402017b8:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402017bc:	9111814a 	add	x10, x10, #0x460
    402017c0:	3940014b 	ldrb	w11, [x10]
    402017c4:	f940094a 	ldr	x10, [x10, #16]
    402017c8:	7100013f 	cmp	w9, #0x0
    402017cc:	7a430960 	ccmp	w11, #0x3, #0x0, eq  // eq = none
    402017d0:	fa400940 	ccmp	x10, #0x0, #0x0, eq  // eq = none
    402017d4:	54000c81 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402017d8:	d000010b 	adrp	x11, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0xb8e0>
    402017dc:	911fc16b 	add	x11, x11, #0x7f0
    402017e0:	f9400969 	ldr	x9, [x11, #16]
    402017e4:	f940056a 	ldr	x10, [x11, #8]
    402017e8:	f940016b 	ldr	x11, [x11]
    402017ec:	d000010c 	adrp	x12, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0xb8e0>
    402017f0:	910f818c 	add	x12, x12, #0x3e0
    402017f4:	eb0c017f 	cmp	x11, x12
    402017f8:	54000b61 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402017fc:	d503201f 	nop
    40201800:	10004c4b 	adr	x11, 40202188 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241>
    40201804:	eb0b015f 	cmp	x10, x11
    40201808:	54000ae1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    4020180c:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201810:	f943254a 	ldr	x10, [x10, #1608]
    40201814:	eb0a013f 	cmp	x9, x10
    40201818:	54000a68 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    4020181c:	aa1f03e9 	mov	x9, xzr
    40201820:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201824:	911aa14a 	add	x10, x10, #0x6a8
    40201828:	d00000cb 	adrp	x11, 4021b000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0x38e0>
    4020182c:	911c816b 	add	x11, x11, #0x720
    40201830:	d503201f 	nop
    40201834:	1002f5b9 	adr	x25, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40201838:	d503201f 	nop
    4020183c:	10112dba 	adr	x26, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40201840:	d503201f 	nop
    40201844:	1002f5bc 	adr	x28, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40201848:	d503201f 	nop
    4020184c:	10112dbb 	adr	x27, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40201850:	d503201f 	nop
    40201854:	10112dec 	adr	x12, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    40201858:	f100413f 	cmp	x9, #0x10
    4020185c:	54000860 	b.eq	40201968 <jnox_kernel::ordinary_reservations::irq+0x6a0>  // b.none
    40201860:	8b0902ed 	add	x13, x23, x9
    40201864:	f940b5ad 	ldr	x13, [x13, #360]
    40201868:	f85d014e 	ldur	x14, [x10, #-48]
    4020186c:	eb0d01df 	cmp	x14, x13
    40201870:	540007a1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201874:	d10d016e 	sub	x14, x11, #0x340
    40201878:	d140116f 	sub	x15, x11, #0x4, lsl #12
    4020187c:	eb0d01df 	cmp	x14, x13
    40201880:	fa4d01e2 	ccmp	x15, x13, #0x2, eq  // eq = none
    40201884:	54000708 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    40201888:	b10d05bf 	cmn	x13, #0x341
    4020188c:	540006c8 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    40201890:	910d01ae 	add	x14, x13, #0x340
    40201894:	eb0b01df 	cmp	x14, x11
    40201898:	54000668 	b.hi	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.pmore
    4020189c:	f9407dae 	ldr	x14, [x13, #248]
    402018a0:	f85d814f 	ldur	x15, [x10, #-40]
    402018a4:	eb0f01df 	cmp	x14, x15
    402018a8:	540005e1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402018ac:	f94081ae 	ldr	x14, [x13, #256]
    402018b0:	f85e014f 	ldur	x15, [x10, #-32]
    402018b4:	eb0f01df 	cmp	x14, x15
    402018b8:	54000561 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402018bc:	f9404dae 	ldr	x14, [x13, #152]
    402018c0:	f85e814f 	ldur	x15, [x10, #-24]
    402018c4:	eb0f01df 	cmp	x14, x15
    402018c8:	540004e1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402018cc:	f9408dad 	ldr	x13, [x13, #280]
    402018d0:	f85f014e 	ldur	x14, [x10, #-16]
    402018d4:	eb0e01bf 	cmp	x13, x14
    402018d8:	54000461 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402018dc:	8b09032d 	add	x13, x25, x9
    402018e0:	c8dffdad 	ldar	x13, [x13]
    402018e4:	b10005bf 	cmn	x13, #0x1
    402018e8:	540003e1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402018ec:	8b09034d 	add	x13, x26, x9
    402018f0:	c8dffdad 	ldar	x13, [x13]
    402018f4:	b500038d 	cbnz	x13, 40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>
    402018f8:	8b09038d 	add	x13, x28, x9
    402018fc:	c8dffdad 	ldar	x13, [x13]
    40201900:	b10005bf 	cmn	x13, #0x1
    40201904:	54000301 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201908:	8b09036d 	add	x13, x27, x9
    4020190c:	c8dffdad 	ldar	x13, [x13]
    40201910:	b50002ad 	cbnz	x13, 40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>
    40201914:	8b09018d 	add	x13, x12, x9
    40201918:	c8dffdad 	ldar	x13, [x13]
    4020191c:	b500024d 	cbnz	x13, 40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>
    40201920:	8b0902ed 	add	x13, x23, x9
    40201924:	f940e1ae 	ldr	x14, [x13, #448]
    40201928:	f85f814f 	ldur	x15, [x10, #-8]
    4020192c:	eb0f01df 	cmp	x14, x15
    40201930:	540001a1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201934:	f940e9ad 	ldr	x13, [x13, #464]
    40201938:	f843854e 	ldr	x14, [x10], #56
    4020193c:	eb0e01bf 	cmp	x13, x14
    40201940:	54000121 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201944:	8b0902ed 	add	x13, x23, x9
    40201948:	f940c9ae 	ldr	x14, [x13, #400]
    4020194c:	b10005df 	cmn	x14, #0x1
    40201950:	540000a1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201954:	f940d1ad 	ldr	x13, [x13, #416]
    40201958:	91002129 	add	x9, x9, #0x8
    4020195c:	9140116b 	add	x11, x11, #0x4, lsl #12
    40201960:	b4fff7cd 	cbz	x13, 40201858 <jnox_kernel::ordinary_reservations::irq+0x590>
    40201964:	97fffe51 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40201968:	d5033fdf 	isb
    4020196c:	d53be029 	mrs	x9, cntpct_el0
    40201970:	10ffffea 	adr	x10, 4020196c <jnox_kernel::ordinary_reservations::irq+0x6a4>
    40201974:	f90017e9 	str	x9, [sp, #40]
    40201978:	f9007fea 	str	x10, [sp, #248]
    4020197c:	52800029 	mov	w9, #0x1                   	// #1
    40201980:	f9004be9 	str	x9, [sp, #144]
    40201984:	d503201f 	nop
    40201988:	10112509 	adr	x9, 40223e28 <jnox_kernel::ordinary_reservations::stage_hooks::stage_probe::OBSERVATION>
    4020198c:	f9404bea 	ldr	x10, [sp, #144]
    40201990:	f900012a 	str	x10, [x9]
    40201994:	f94017ea 	ldr	x10, [sp, #40]
    40201998:	f900052a 	str	x10, [x9, #8]
    4020199c:	f9407fea 	ldr	x10, [sp, #248]
    402019a0:	f900092a 	str	x10, [x9, #16]
    402019a4:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402019a8:	f942412a 	ldr	x10, [x9, #1152]
    402019ac:	f100095f 	cmp	x10, #0x2
    402019b0:	54fffda0 	b.eq	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.none
    402019b4:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402019b8:	91136129 	add	x9, x9, #0x4d8
    402019bc:	39402138 	ldrb	w24, [x9, #8]
    402019c0:	71000f1f 	cmp	w24, #0x3
    402019c4:	54fffd00 	b.eq	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.none
    402019c8:	3941eaeb 	ldrb	w11, [x23, #122]
    402019cc:	3943eaec 	ldrb	w12, [x23, #250]
    402019d0:	6b0c017f 	cmp	w11, w12
    402019d4:	54fffc81 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402019d8:	f94002eb 	ldr	x11, [x23]
    402019dc:	eb0a017f 	cmp	x11, x10
    402019e0:	54fffc21 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    402019e4:	d503201f 	nop
    402019e8:	1002dfd4 	adr	x20, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    402019ec:	f940028a 	ldr	x10, [x20]
    402019f0:	b4fffbaa 	cbz	x10, 40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>
    402019f4:	f9400133 	ldr	x19, [x9]
    402019f8:	f9400689 	ldr	x9, [x20, #8]
    402019fc:	eb13013f 	cmp	x9, x19
    40201a00:	54fffb21 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201a04:	39418a89 	ldrb	w9, [x20, #98]
    40201a08:	6b09031f 	cmp	w24, w9
    40201a0c:	54fffac1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201a10:	f90013e5 	str	x5, [sp, #32]
    40201a14:	d000011d 	adrp	x29, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0xb8e0>
    40201a18:	911cc3bd 	add	x29, x29, #0x730
    40201a1c:	d5033fdf 	isb
    40201a20:	d53be036 	mrs	x22, cntpct_el0
    40201a24:	f9001fb6 	str	x22, [x29, #56]
    40201a28:	f94003a9 	ldr	x9, [x29]
    40201a2c:	b27f0129 	orr	x9, x9, #0x2
    40201a30:	f90003a9 	str	x9, [x29]
    40201a34:	eb1502df 	cmp	x22, x21
    40201a38:	54001c43 	b.cc	40201dc0 <jnox_kernel::ordinary_reservations::irq+0xaf8>  // b.lo, b.ul, b.last
    40201a3c:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201a40:	9114e14a 	add	x10, x10, #0x538
    40201a44:	f9400149 	ldr	x9, [x10]
    40201a48:	eb0902c9 	subs	x9, x22, x9
    40201a4c:	54001ba3 	b.cc	40201dc0 <jnox_kernel::ordinary_reservations::irq+0xaf8>  // b.lo, b.ul, b.last
    40201a50:	f940094a 	ldr	x10, [x10, #16]
    40201a54:	eb0a013f 	cmp	x9, x10
    40201a58:	54001b48 	b.hi	40201dc0 <jnox_kernel::ordinary_reservations::irq+0xaf8>  // b.pmore
    40201a5c:	52800069 	mov	w9, #0x3                   	// #3
    40201a60:	c89ffd09 	stlr	x9, [x8]
    40201a64:	c8dffd15 	ldar	x21, [x8]
    40201a68:	940005fc 	bl	40203258 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    40201a6c:	f9402c08 	ldr	x8, [x0, #88]
    40201a70:	39418009 	ldrb	w9, [x0, #96]
    40201a74:	d5033fdf 	isb
    40201a78:	d53be024 	mrs	x4, cntpct_el0
    40201a7c:	f94003aa 	ldr	x10, [x29]
    40201a80:	a90457a4 	stp	x4, x21, [x29, #64]
    40201a84:	71000d3f 	cmp	w9, #0x3
    40201a88:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40201a8c:	f9002ba8 	str	x8, [x29, #80]
    40201a90:	b27e0149 	orr	x9, x10, #0x4
    40201a94:	f90003a9 	str	x9, [x29]
    40201a98:	f1000ebf 	cmp	x21, #0x3
    40201a9c:	54fff641 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201aa0:	eb13011f 	cmp	x8, x19
    40201aa4:	54fff601 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201aa8:	eb16009f 	cmp	x4, x22
    40201aac:	d000002e 	adrp	x14, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201ab0:	9114e1ce 	add	x14, x14, #0x538
    40201ab4:	54001703 	b.cc	40201d94 <jnox_kernel::ordinary_reservations::irq+0xacc>  // b.lo, b.ul, b.last
    40201ab8:	f94001c8 	ldr	x8, [x14]
    40201abc:	eb080088 	subs	x8, x4, x8
    40201ac0:	540016a3 	b.cc	40201d94 <jnox_kernel::ordinary_reservations::irq+0xacc>  // b.lo, b.ul, b.last
    40201ac4:	f94009c9 	ldr	x9, [x14, #16]
    40201ac8:	eb09011f 	cmp	x8, x9
    40201acc:	54001648 	b.hi	40201d94 <jnox_kernel::ordinary_reservations::irq+0xacc>  // b.pmore
    40201ad0:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201ad4:	f902ad1f 	str	xzr, [x8, #1368]
    40201ad8:	f100067f 	cmp	x19, #0x1
    40201adc:	54001a68 	b.hi	40201e28 <jnox_kernel::ordinary_reservations::irq+0xb60>  // b.pmore
    40201ae0:	8b131288 	add	x8, x20, x19, lsl #4
    40201ae4:	f9402108 	ldr	x8, [x8, #64]
    40201ae8:	8b130ee9 	add	x9, x23, x19, lsl #3
    40201aec:	f900c928 	str	x8, [x9, #400]
    40201af0:	f940e12a 	ldr	x10, [x9, #448]
    40201af4:	f940e92b 	ldr	x11, [x9, #464]
    40201af8:	a9107ef3 	stp	x19, xzr, [x23, #256]
    40201afc:	5280002c 	mov	w12, #0x1                   	// #1
    40201b00:	a9112aec 	stp	x12, x10, [x23, #272]
    40201b04:	a91222eb 	stp	x11, x8, [x23, #288]
    40201b08:	3904c2f8 	strb	w24, [x23, #304]
    40201b0c:	8b130f88 	add	x8, x28, x19, lsl #3
    40201b10:	a948aa8b 	ldp	x11, x10, [x20, #136]
    40201b14:	c89ffd0a 	stlr	x10, [x8]
    40201b18:	91000708 	add	x8, x24, #0x1
    40201b1c:	f8337b48 	str	x8, [x26, x19, lsl #3]
    40201b20:	f8337b7f 	str	xzr, [x27, x19, lsl #3]
    40201b24:	8b130f28 	add	x8, x25, x19, lsl #3
    40201b28:	c89ffd1f 	stlr	xzr, [x8]
    40201b2c:	a91832eb 	stp	x11, x12, [x23, #384]
    40201b30:	d51be24b 	msr	cntp_cval_el0, x11
    40201b34:	d51be22c 	msr	cntp_ctl_el0, x12
    40201b38:	d5033fdf 	isb
    40201b3c:	d53be24d 	mrs	x13, cntp_cval_el0
    40201b40:	d53be228 	mrs	x8, cntp_ctl_el0
    40201b44:	d5033fdf 	isb
    40201b48:	d53be02a 	mrs	x10, cntpct_el0
    40201b4c:	a906a3ad 	stp	x13, x8, [x29, #104]
    40201b50:	a905afaa 	stp	x10, x11, [x29, #88]
    40201b54:	f94003ac 	ldr	x12, [x29]
    40201b58:	b27d018c 	orr	x12, x12, #0x8
    40201b5c:	f90003ac 	str	x12, [x29]
    40201b60:	eb0b01bf 	cmp	x13, x11
    40201b64:	54fff001 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201b68:	92400508 	and	x8, x8, #0x3
    40201b6c:	f100051f 	cmp	x8, #0x1
    40201b70:	54ffefa1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201b74:	d5033fdf 	isb
    40201b78:	d53be028 	mrs	x8, cntpct_el0
    40201b7c:	eb04015f 	cmp	x10, x4
    40201b80:	540012c3 	b.cc	40201dd8 <jnox_kernel::ordinary_reservations::irq+0xb10>  // b.lo, b.ul, b.last
    40201b84:	eb0a011f 	cmp	x8, x10
    40201b88:	54001283 	b.cc	40201dd8 <jnox_kernel::ordinary_reservations::irq+0xb10>  // b.lo, b.ul, b.last
    40201b8c:	f94001ca 	ldr	x10, [x14]
    40201b90:	eb0a010a 	subs	x10, x8, x10
    40201b94:	54001223 	b.cc	40201dd8 <jnox_kernel::ordinary_reservations::irq+0xb10>  // b.lo, b.ul, b.last
    40201b98:	f94009cb 	ldr	x11, [x14, #16]
    40201b9c:	eb0b015f 	cmp	x10, x11
    40201ba0:	540011c8 	b.hi	40201dd8 <jnox_kernel::ordinary_reservations::irq+0xb10>  // b.pmore
    40201ba4:	f940b536 	ldr	x22, [x9, #360]
    40201ba8:	d5033fdf 	isb
    40201bac:	d53be024 	mrs	x4, cntpct_el0
    40201bb0:	f9409ee8 	ldr	x8, [x23, #312]
    40201bb4:	eb080088 	subs	x8, x4, x8
    40201bb8:	54000ee3 	b.cc	40201d94 <jnox_kernel::ordinary_reservations::irq+0xacc>  // b.lo, b.ul, b.last
    40201bbc:	f940a6ea 	ldr	x10, [x23, #328]
    40201bc0:	eb0a011f 	cmp	x8, x10
    40201bc4:	54000e88 	b.hi	40201d94 <jnox_kernel::ordinary_reservations::irq+0xacc>  // b.pmore
    40201bc8:	f900b53f 	str	xzr, [x9, #360]
    40201bcc:	f900b2f3 	str	x19, [x23, #352]
    40201bd0:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201bd4:	91004108 	add	x8, x8, #0x10
    40201bd8:	f9407ec9 	ldr	x9, [x22, #248]
    40201bdc:	a907dba4 	stp	x4, x22, [x29, #120]
    40201be0:	5280002a 	mov	w10, #0x1                   	// #1
    40201be4:	a9004d1f 	stp	xzr, x19, [x8]
    40201be8:	f9408ec8 	ldr	x8, [x22, #280]
    40201bec:	f90047a9 	str	x9, [x29, #136]
    40201bf0:	f9404ec9 	ldr	x9, [x22, #152]
    40201bf4:	a909aba8 	stp	x8, x10, [x29, #152]
    40201bf8:	f9004ba9 	str	x9, [x29, #144]
    40201bfc:	f94003a8 	ldr	x8, [x29]
    40201c00:	b27c0108 	orr	x8, x8, #0x10
    40201c04:	f90003a8 	str	x8, [x29]
    40201c08:	14000051 	b	40201d4c <jnox_kernel::ordinary_reservations::irq+0xa84>
    40201c0c:	aa1303e0 	mov	x0, x19
    40201c10:	aa1f03e1 	mov	x1, xzr
    40201c14:	f94013f4 	ldr	x20, [sp, #32]
    40201c18:	aa1403e2 	mov	x2, x20
    40201c1c:	94000446 	bl	40202d34 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201c20:	52800055 	mov	w21, #0x2                   	// #2
    40201c24:	1400003b 	b	40201d10 <jnox_kernel::ordinary_reservations::irq+0xa48>
    40201c28:	d000010a 	adrp	x10, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0xb8e0>
    40201c2c:	911cc14a 	add	x10, x10, #0x730
    40201c30:	d53be248 	mrs	x8, cntp_cval_el0
    40201c34:	d5033fdf 	isb
    40201c38:	d53be029 	mrs	x9, cntpct_el0
    40201c3c:	a9022157 	stp	x23, x8, [x10, #32]
    40201c40:	a9015949 	stp	x9, x22, [x10, #16]
    40201c44:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201c48:	9114e129 	add	x9, x9, #0x538
    40201c4c:	f940252b 	ldr	x11, [x9, #72]
    40201c50:	f900194b 	str	x11, [x10, #48]
    40201c54:	f940014c 	ldr	x12, [x10]
    40201c58:	b240018c 	orr	x12, x12, #0x1
    40201c5c:	a900554c 	stp	x12, x21, [x10]
    40201c60:	eb0b011f 	cmp	x8, x11
    40201c64:	54ffe801 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201c68:	f9400129 	ldr	x9, [x9]
    40201c6c:	eb09011f 	cmp	x8, x9
    40201c70:	54ffe7a1 	b.ne	40201964 <jnox_kernel::ordinary_reservations::irq+0x69c>  // b.any
    40201c74:	aa1f03f3 	mov	x19, xzr
    40201c78:	17fffdcc 	b	402013a8 <jnox_kernel::ordinary_reservations::irq+0xe0>
    40201c7c:	92800008 	mov	x8, #0xffffffffffffffff    	// #-1
    40201c80:	d503201f 	nop
    40201c84:	1002d3a9 	adr	x9, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40201c88:	d503201f 	nop
    40201c8c:	10110b2a 	adr	x10, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40201c90:	d503201f 	nop
    40201c94:	1002d2ab 	adr	x11, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40201c98:	d503201f 	nop
    40201c9c:	10110b2c 	adr	x12, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40201ca0:	8b150d29 	add	x9, x9, x21, lsl #3
    40201ca4:	c89ffd28 	stlr	x8, [x9]
    40201ca8:	f94007e8 	ldr	x8, [sp, #8]
    40201cac:	f8357948 	str	x8, [x10, x21, lsl #3]
    40201cb0:	f835799f 	str	xzr, [x12, x21, lsl #3]
    40201cb4:	8b150d68 	add	x8, x11, x21, lsl #3
    40201cb8:	c89ffd13 	stlr	x19, [x8]
    40201cbc:	b100067f 	cmn	x19, #0x1
    40201cc0:	54000580 	b.eq	40201d70 <jnox_kernel::ordinary_reservations::irq+0xaa8>  // b.none
    40201cc4:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201cc8:	9114e129 	add	x9, x9, #0x538
    40201ccc:	a9402129 	ldp	x9, x8, [x9]
    40201cd0:	9100066b 	add	x11, x19, #0x1
    40201cd4:	9bc87d6a 	umulh	x10, x11, x8
    40201cd8:	eb0a03ff 	cmp	xzr, x10
    40201cdc:	1a9f07ea 	cset	w10, ne  // ne = any
    40201ce0:	9b087d68 	mul	x8, x11, x8
    40201ce4:	ab090108 	adds	x8, x8, x9
    40201ce8:	1a9f37e9 	cset	w9, cs  // cs = hs, nlast
    40201cec:	3700042a 	tbnz	w10, #0, 40201d70 <jnox_kernel::ordinary_reservations::irq+0xaa8>
    40201cf0:	37000409 	tbnz	w9, #0, 40201d70 <jnox_kernel::ordinary_reservations::irq+0xaa8>
    40201cf4:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201cf8:	f942a529 	ldr	x9, [x9, #1352]
    40201cfc:	eb090102 	subs	x2, x8, x9
    40201d00:	54000383 	b.cc	40201d70 <jnox_kernel::ordinary_reservations::irq+0xaa8>  // b.lo, b.ul, b.last
    40201d04:	aa1303e0 	mov	x0, x19
    40201d08:	52800021 	mov	w1, #0x1                   	// #1
    40201d0c:	9400040a 	bl	40202d34 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201d10:	aa1303e0 	mov	x0, x19
    40201d14:	aa1503e1 	mov	x1, x21
    40201d18:	94000561 	bl	4020329c <jnox_kernel::ordinary_reservations::Runtime::select>
    40201d1c:	aa0003f6 	mov	x22, x0
    40201d20:	d5033fdf 	isb
    40201d24:	d53be021 	mrs	x1, cntpct_el0
    40201d28:	f9407c08 	ldr	x8, [x0, #248]
    40201d2c:	f9400fe9 	ldr	x9, [sp, #24]
    40201d30:	a90953e9 	stp	x9, x20, [sp, #144]
    40201d34:	a90a23e0 	stp	x0, x8, [sp, #160]
    40201d38:	910243e4 	add	x4, sp, #0x90
    40201d3c:	528000e0 	mov	w0, #0x7                   	// #7
    40201d40:	aa1303e2 	mov	x2, x19
    40201d44:	aa1503e3 	mov	x3, x21
    40201d48:	9400020f 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40201d4c:	aa1603e0 	mov	x0, x22
    40201d50:	a9554ff4 	ldp	x20, x19, [sp, #336]
    40201d54:	a95457f6 	ldp	x22, x21, [sp, #320]
    40201d58:	a9535ff8 	ldp	x24, x23, [sp, #304]
    40201d5c:	a95267fa 	ldp	x26, x25, [sp, #288]
    40201d60:	a9516ffc 	ldp	x28, x27, [sp, #272]
    40201d64:	a9507bfd 	ldp	x29, x30, [sp, #256]
    40201d68:	910583ff 	add	sp, sp, #0x160
    40201d6c:	d65f03c0 	ret
    40201d70:	52800060 	mov	w0, #0x3                   	// #3
    40201d74:	9400057e 	bl	4020336c <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    40201d78:	f942b303 	ldr	x3, [x24, #1376]
    40201d7c:	52800060 	mov	w0, #0x3                   	// #3
    40201d80:	52800081 	mov	w1, #0x4                   	// #4
    40201d84:	aa1303e2 	mov	x2, x19
    40201d88:	aa1603e4 	mov	x4, x22
    40201d8c:	aa1703e5 	mov	x5, x23
    40201d90:	94000254 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>
    40201d94:	52800040 	mov	w0, #0x2                   	// #2
    40201d98:	528000a1 	mov	w1, #0x5                   	// #5
    40201d9c:	aa1f03e2 	mov	x2, xzr
    40201da0:	52800043 	mov	w3, #0x2                   	// #2
    40201da4:	14000012 	b	40201dec <jnox_kernel::ordinary_reservations::irq+0xb24>
    40201da8:	52800040 	mov	w0, #0x2                   	// #2
    40201dac:	528000a1 	mov	w1, #0x5                   	// #5
    40201db0:	aa1303e2 	mov	x2, x19
    40201db4:	52800043 	mov	w3, #0x2                   	// #2
    40201db8:	aa1503e4 	mov	x4, x21
    40201dbc:	94000249 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>
    40201dc0:	52800040 	mov	w0, #0x2                   	// #2
    40201dc4:	528000a1 	mov	w1, #0x5                   	// #5
    40201dc8:	aa1f03e2 	mov	x2, xzr
    40201dcc:	52800043 	mov	w3, #0x2                   	// #2
    40201dd0:	aa1603e4 	mov	x4, x22
    40201dd4:	14000006 	b	40201dec <jnox_kernel::ordinary_reservations::irq+0xb24>
    40201dd8:	52800040 	mov	w0, #0x2                   	// #2
    40201ddc:	528000a1 	mov	w1, #0x5                   	// #5
    40201de0:	aa1f03e2 	mov	x2, xzr
    40201de4:	52800043 	mov	w3, #0x2                   	// #2
    40201de8:	aa0803e4 	mov	x4, x8
    40201dec:	f94013e5 	ldr	x5, [sp, #32]
    40201df0:	9400023c 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>
    40201df4:	aa1f03e0 	mov	x0, xzr
    40201df8:	aa1f03e1 	mov	x1, xzr
    40201dfc:	aa1303e2 	mov	x2, x19
    40201e00:	52800043 	mov	w3, #0x2                   	// #2
    40201e04:	aa1f03e4 	mov	x4, xzr
    40201e08:	14000006 	b	40201e20 <jnox_kernel::ordinary_reservations::irq+0xb58>
    40201e0c:	394263e4 	ldrb	w4, [sp, #152]
    40201e10:	52800060 	mov	w0, #0x3                   	// #3
    40201e14:	52800041 	mov	w1, #0x2                   	// #2
    40201e18:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201e1c:	52800043 	mov	w3, #0x2                   	// #2
    40201e20:	aa1f03e5 	mov	x5, xzr
    40201e24:	9400022f 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>
    40201e28:	d503201f 	nop
    40201e2c:	100204e2 	adr	x2, 40205ec8 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.16192825690684220241+0x30>
    40201e30:	aa1303e0 	mov	x0, x19
    40201e34:	14000004 	b	40201e44 <jnox_kernel::ordinary_reservations::irq+0xb7c>
    40201e38:	d503201f 	nop
    40201e3c:	100205e2 	adr	x2, 40205ef8 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.16192825690684220241+0x60>
    40201e40:	aa1503e0 	mov	x0, x21
    40201e44:	52800041 	mov	w1, #0x2                   	// #2
    40201e48:	94000bb1 	bl	40204d0c <core::panicking::panic_bounds_check>
    40201e4c:	94000093 	bl	40202098 <jnox_kernel::ordinary_reservations::run::{{closure}}>

0000000040201e50 <jnox_kernel::ordinary_reservations::run>:
    40201e50:	d105c3ff 	sub	sp, sp, #0x170
    40201e54:	a9127bfd 	stp	x29, x30, [sp, #288]
    40201e58:	a91367fa 	stp	x26, x25, [sp, #304]
    40201e5c:	a9145ff8 	stp	x24, x23, [sp, #320]
    40201e60:	a91557f6 	stp	x22, x21, [sp, #336]
    40201e64:	a9164ff4 	stp	x20, x19, [sp, #352]
    40201e68:	d5033fdf 	isb
    40201e6c:	d53be038 	mrs	x24, cntpct_el0
    40201e70:	d53be014 	mrs	x20, cntfrq_el0
    40201e74:	d5033fdf 	isb
    40201e78:	d53be028 	mrs	x8, cntpct_el0
    40201e7c:	b202e7e9 	mov	x9, #0xcccccccccccccccc    	// #-3689348814741910324
    40201e80:	f29999a9 	movk	x9, #0xcccd
    40201e84:	9bc97e89 	umulh	x9, x20, x9
    40201e88:	ab491113 	adds	x19, x8, x9, lsr #4
    40201e8c:	54000043 	b.cc	40201e94 <jnox_kernel::ordinary_reservations::run+0x44>  // b.lo, b.ul, b.last
    40201e90:	94000082 	bl	40202098 <jnox_kernel::ordinary_reservations::run::{{closure}}>
    40201e94:	910223e8 	add	x8, sp, #0x88
    40201e98:	aa1303e0 	mov	x0, x19
    40201e9c:	aa1403e1 	mov	x1, x20
    40201ea0:	52800022 	mov	w2, #0x1                   	// #1
    40201ea4:	9400080e 	bl	40203edc <jnox_kernel::reservation_jobs::Clock::new>
    40201ea8:	394223e8 	ldrb	w8, [sp, #136]
    40201eac:	7100051f 	cmp	w8, #0x1
    40201eb0:	54000061 	b.ne	40201ebc <jnox_kernel::ordinary_reservations::run+0x6c>  // b.any
    40201eb4:	394227e4 	ldrb	w4, [sp, #137]
    40201eb8:	14000015 	b	40201f0c <jnox_kernel::ordinary_reservations::run+0xbc>
    40201ebc:	a9495bf7 	ldp	x23, x22, [sp, #144]
    40201ec0:	f94053f5 	ldr	x21, [sp, #160]
    40201ec4:	d5033fdf 	isb
    40201ec8:	d53be021 	mrs	x1, cntpct_el0
    40201ecc:	a908dbf4 	stp	x20, x22, [sp, #136]
    40201ed0:	52800028 	mov	w8, #0x1                   	// #1
    40201ed4:	a909a3e8 	stp	x8, x8, [sp, #152]
    40201ed8:	910223e4 	add	x4, sp, #0x88
    40201edc:	52800020 	mov	w0, #0x1                   	// #1
    40201ee0:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201ee4:	52800043 	mov	w3, #0x2                   	// #2
    40201ee8:	940001a7 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40201eec:	910223e8 	add	x8, sp, #0x88
    40201ef0:	52800020 	mov	w0, #0x1                   	// #1
    40201ef4:	52800021 	mov	w1, #0x1                   	// #1
    40201ef8:	94000611 	bl	4020373c <jnox_kernel::reservation_jobs::Jobs::new>
    40201efc:	f94047e8 	ldr	x8, [sp, #136]
    40201f00:	f100091f 	cmp	x8, #0x2
    40201f04:	54000101 	b.ne	40201f24 <jnox_kernel::ordinary_reservations::run+0xd4>  // b.any
    40201f08:	394243e4 	ldrb	w4, [sp, #144]
    40201f0c:	52800060 	mov	w0, #0x3                   	// #3
    40201f10:	52800041 	mov	w1, #0x2                   	// #2
    40201f14:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201f18:	52800043 	mov	w3, #0x2                   	// #2
    40201f1c:	aa1f03e5 	mov	x5, xzr
    40201f20:	940001f0 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>
    40201f24:	910023e0 	add	x0, sp, #0x8
    40201f28:	910223e1 	add	x1, sp, #0x88
    40201f2c:	52801002 	mov	w2, #0x80                  	// #128
    40201f30:	94000ec7 	bl	40205a4c <memcpy>
    40201f34:	d5033fdf 	isb
    40201f38:	d53be021 	mrs	x1, cntpct_el0
    40201f3c:	a908cff8 	stp	x24, x19, [sp, #136]
    40201f40:	a909ffff 	stp	xzr, xzr, [sp, #152]
    40201f44:	910223e4 	add	x4, sp, #0x88
    40201f48:	52800300 	mov	w0, #0x18                  	// #24
    40201f4c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201f50:	52800043 	mov	w3, #0x2                   	// #2
    40201f54:	9400018c 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40201f58:	94000a2a 	bl	40204800 <jnox_kernel::context::init_timer_irq>
    40201f5c:	aa1f03f4 	mov	x20, xzr
    40201f60:	910423f8 	add	x24, sp, #0x108
    40201f64:	aa1403e0 	mov	x0, x20
    40201f68:	940001a8 	bl	40202608 <jnox_kernel::ordinary_reservations::fresh>
    40201f6c:	f8347b00 	str	x0, [x24, x20, lsl #3]
    40201f70:	91000694 	add	x20, x20, #0x1
    40201f74:	f1000e9f 	cmp	x20, #0x3
    40201f78:	54ffff61 	b.ne	40201f64 <jnox_kernel::ordinary_reservations::run+0x114>  // b.any
    40201f7c:	aa1f03f4 	mov	x20, xzr
    40201f80:	d503201f 	nop
    40201f84:	100abce8 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241>
    40201f88:	52800318 	mov	w24, #0x18                  	// #24
    40201f8c:	d503201f 	nop
    40201f90:	1001f719 	adr	x25, 40205e70 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.16192825690684220241>
    40201f94:	d5033fdf 	isb
    40201f98:	d53be021 	mrs	x1, cntpct_el0
    40201f9c:	f1000a9f 	cmp	x20, #0x2
    40201fa0:	54000062 	b.cs	40201fac <jnox_kernel::ordinary_reservations::run+0x15c>  // b.hs, b.nlast
    40201fa4:	f8747b29 	ldr	x9, [x25, x20, lsl #3]
    40201fa8:	14000002 	b	40201fb0 <jnox_kernel::ordinary_reservations::run+0x160>
    40201fac:	52818329 	mov	w9, #0xc19                 	// #3097
    40201fb0:	9140111a 	add	x26, x8, #0x4, lsl #12
    40201fb4:	a908ebe8 	stp	x8, x26, [sp, #136]
    40201fb8:	a909ffe9 	stp	x9, xzr, [sp, #152]
    40201fbc:	910223e4 	add	x4, sp, #0x88
    40201fc0:	52800220 	mov	w0, #0x11                  	// #17
    40201fc4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201fc8:	aa1403e3 	mov	x3, x20
    40201fcc:	9400016e 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40201fd0:	f1002318 	subs	x24, x24, #0x8
    40201fd4:	91000694 	add	x20, x20, #0x1
    40201fd8:	aa1a03e8 	mov	x8, x26
    40201fdc:	54fffdc1 	b.ne	40201f94 <jnox_kernel::ordinary_reservations::run+0x144>  // b.any
    40201fe0:	d503201f 	nop
    40201fe4:	1002a0f4 	adr	x20, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40201fe8:	910023e1 	add	x1, sp, #0x8
    40201fec:	aa1403e0 	mov	x0, x20
    40201ff0:	52801002 	mov	w2, #0x80                  	// #128
    40201ff4:	94000e96 	bl	40205a4c <memcpy>
    40201ff8:	52800048 	mov	w8, #0x2                   	// #2
    40201ffc:	f9004288 	str	x8, [x20, #128]
    40202000:	52800069 	mov	w9, #0x3                   	// #3
    40202004:	3904c289 	strb	w9, [x20, #304]
    40202008:	a913da97 	stp	x23, x22, [x20, #312]
    4020200c:	52800149 	mov	w9, #0xa                   	// #10
    40202010:	a914a695 	stp	x21, x9, [x20, #328]
    40202014:	9280000a 	mov	x10, #0xffffffffffffffff    	// #-1
    40202018:	a915a28a 	stp	x10, x8, [x20, #344]
    4020201c:	a950afe8 	ldp	x8, x11, [sp, #264]
    40202020:	a916ae88 	stp	x8, x11, [x20, #360]
    40202024:	f9408fe8 	ldr	x8, [sp, #280]
    40202028:	a917fe88 	stp	x8, xzr, [x20, #376]
    4020202c:	a918aa9f 	stp	xzr, x10, [x20, #392]
    40202030:	a919fe8a 	stp	x10, xzr, [x20, #408]
    40202034:	52800028 	mov	w8, #0x1                   	// #1
    40202038:	a91aa29f 	stp	xzr, x8, [x20, #424]
    4020203c:	a91bfe88 	stp	x8, xzr, [x20, #440]
    40202040:	52814328 	mov	w8, #0xa19                 	// #2585
    40202044:	a91ca29f 	stp	xzr, x8, [x20, #456]
    40202048:	52816328 	mov	w8, #0xb19                 	// #2841
    4020204c:	f900ee88 	str	x8, [x20, #472]
    40202050:	d5033fdf 	isb
    40202054:	d53be021 	mrs	x1, cntpct_el0
    40202058:	a908a7f3 	stp	x19, x9, [sp, #136]
    4020205c:	a909ffff 	stp	xzr, xzr, [sp, #152]
    40202060:	910223e4 	add	x4, sp, #0x88
    40202064:	52800040 	mov	w0, #0x2                   	// #2
    40202068:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4020206c:	52800043 	mov	w3, #0x2                   	// #2
    40202070:	94000145 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202074:	94000194 	bl	402026c4 <jnox_kernel::ordinary_reservations::state>
    40202078:	aa1f03e0 	mov	x0, xzr
    4020207c:	aa1f03e1 	mov	x1, xzr
    40202080:	aa1303e2 	mov	x2, x19
    40202084:	9400032c 	bl	40202d34 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40202088:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    4020208c:	52800041 	mov	w1, #0x2                   	// #2
    40202090:	94000483 	bl	4020329c <jnox_kernel::ordinary_reservations::Runtime::select>
    40202094:	97fffc46 	bl	402011ac <sched_start_frame>

0000000040202098 <jnox_kernel::ordinary_reservations::run::{{closure}}>:
    40202098:	f81f0ffe 	str	x30, [sp, #-16]!
    4020209c:	97fffc83 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

00000000402020a0 <jnox_kernel::ordinary_reservations::svc>:
    402020a0:	f81f0ffe 	str	x30, [sp, #-16]!
    402020a4:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402020a8:	f9420108 	ldr	x8, [x8, #1024]
    402020ac:	f100091f 	cmp	x8, #0x2
    402020b0:	54000660 	b.eq	4020217c <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.none
    402020b4:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402020b8:	f942b108 	ldr	x8, [x8, #1376]
    402020bc:	d503201f 	nop
    402020c0:	100ab309 	adr	x9, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241>
    402020c4:	f100091f 	cmp	x8, #0x2
    402020c8:	8b08392a 	add	x10, x9, x8, lsl #14
    402020cc:	fa401142 	ccmp	x10, x0, #0x2, ne  // ne = any
    402020d0:	54000568 	b.hi	4020217c <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    402020d4:	b10d041f 	cmn	x0, #0x341
    402020d8:	54000528 	b.hi	4020217c <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    402020dc:	d372c508 	lsl	x8, x8, #14
    402020e0:	8b080128 	add	x8, x9, x8
    402020e4:	91401108 	add	x8, x8, #0x4, lsl #12
    402020e8:	910d0009 	add	x9, x0, #0x340
    402020ec:	eb08013f 	cmp	x9, x8
    402020f0:	54000468 	b.hi	4020217c <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    402020f4:	f9409c01 	ldr	x1, [x0, #312]
    402020f8:	d5385203 	mrs	x3, esr_el1
    402020fc:	d35afc68 	lsr	x8, x3, #26
    40202100:	f100551f 	cmp	x8, #0x15
    40202104:	540003c1 	b.ne	4020217c <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.any
    40202108:	12003c68 	and	w8, w3, #0xffff
    4020210c:	7100051f 	cmp	w8, #0x1
    40202110:	540000a0 	b.eq	40202124 <jnox_kernel::ordinary_reservations::svc+0x84>  // b.none
    40202114:	7100091f 	cmp	w8, #0x2
    40202118:	54000321 	b.ne	4020217c <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.any
    4020211c:	52800042 	mov	w2, #0x2                   	// #2
    40202120:	14000002 	b	40202128 <jnox_kernel::ordinary_reservations::svc+0x88>
    40202124:	52800022 	mov	w2, #0x1                   	// #1
    40202128:	94000324 	bl	40202db8 <jnox_kernel::ordinary_reservations::Runtime::close>
    4020212c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202130:	9114e108 	add	x8, x8, #0x538
    40202134:	f9401100 	ldr	x0, [x8, #32]
    40202138:	91000409 	add	x9, x0, #0x1
    4020213c:	a9402908 	ldp	x8, x10, [x8]
    40202140:	9bca7d2b 	umulh	x11, x9, x10
    40202144:	eb0b03ff 	cmp	xzr, x11
    40202148:	1a9f07eb 	cset	w11, ne  // ne = any
    4020214c:	9b0a7d29 	mul	x9, x9, x10
    40202150:	ab080122 	adds	x2, x9, x8
    40202154:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40202158:	3700014b 	tbnz	w11, #0, 40202180 <jnox_kernel::ordinary_reservations::svc+0xe0>
    4020215c:	35000128 	cbnz	w8, 40202180 <jnox_kernel::ordinary_reservations::svc+0xe0>
    40202160:	aa1f03e1 	mov	x1, xzr
    40202164:	940002f4 	bl	40202d34 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40202168:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020216c:	f942ad00 	ldr	x0, [x8, #1368]
    40202170:	52800041 	mov	w1, #0x2                   	// #2
    40202174:	f84107fe 	ldr	x30, [sp], #16
    40202178:	14000449 	b	4020329c <jnox_kernel::ordinary_reservations::Runtime::select>
    4020217c:	97fffc4b 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40202180:	52800060 	mov	w0, #0x3                   	// #3
    40202184:	9400047a 	bl	4020336c <jnox_kernel::ordinary_reservations::checked::{{closure}}>

0000000040202188 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241>:
    40202188:	d10743ff 	sub	sp, sp, #0x1d0
    4020218c:	a9177bfd 	stp	x29, x30, [sp, #368]
    40202190:	a9186ffc 	stp	x28, x27, [sp, #384]
    40202194:	a91967fa 	stp	x26, x25, [sp, #400]
    40202198:	a91a5ff8 	stp	x24, x23, [sp, #416]
    4020219c:	a91b57f6 	stp	x22, x21, [sp, #432]
    402021a0:	a91c4ff4 	stp	x20, x19, [sp, #448]
    402021a4:	d50342df 	msr	daifset, #0x2
    402021a8:	d5033fdf 	isb
    402021ac:	d5033fdf 	isb
    402021b0:	d53be036 	mrs	x22, cntpct_el0
    402021b4:	b0000035 	adrp	x21, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021b8:	f94202a8 	ldr	x8, [x21, #1024]
    402021bc:	f100091f 	cmp	x8, #0x2
    402021c0:	54001ac0 	b.eq	40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>  // b.none
    402021c4:	d5033fdf 	isb
    402021c8:	d53be038 	mrs	x24, cntpct_el0
    402021cc:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021d0:	f942f108 	ldr	x8, [x8, #1504]
    402021d4:	f100091f 	cmp	x8, #0x2
    402021d8:	54001a01 	b.ne	40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>  // b.any
    402021dc:	b0000037 	adrp	x23, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021e0:	f9429ef3 	ldr	x19, [x23, #1336]
    402021e4:	d503201f 	nop
    402021e8:	1010afc8 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    402021ec:	c8dffd08 	ldar	x8, [x8]
    402021f0:	b5001948 	cbnz	x8, 40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>
    402021f4:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021f8:	91156108 	add	x8, x8, #0x558
    402021fc:	f9400109 	ldr	x9, [x8]
    40202200:	b100053f 	cmn	x9, #0x1
    40202204:	540018a1 	b.ne	40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>  // b.any
    40202208:	f9400508 	ldr	x8, [x8, #8]
    4020220c:	f100091f 	cmp	x8, #0x2
    40202210:	54001841 	b.ne	40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>  // b.any
    40202214:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202218:	9114c108 	add	x8, x8, #0x530
    4020221c:	39400109 	ldrb	w9, [x8]
    40202220:	71000d3f 	cmp	w9, #0x3
    40202224:	540017a1 	b.ne	40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>  // b.any
    40202228:	f9402d09 	ldr	x9, [x8, #88]
    4020222c:	b5001769 	cbnz	x9, 40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>
    40202230:	f9402908 	ldr	x8, [x8, #80]
    40202234:	eb13011f 	cmp	x8, x19
    40202238:	54001701 	b.ne	40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>  // b.any
    4020223c:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0xb8e0>
    40202240:	f943f508 	ldr	x8, [x8, #2024]
    40202244:	f100051f 	cmp	x8, #0x1
    40202248:	54001681 	b.ne	40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>  // b.any
    4020224c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202250:	f9423508 	ldr	x8, [x8, #1128]
    40202254:	b5001628 	cbnz	x8, 40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>
    40202258:	5280002a 	mov	w10, #0x1                   	// #1
    4020225c:	d503201f 	nop
    40202260:	10028d19 	adr	x25, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40202264:	8b080328 	add	x8, x25, x8
    40202268:	3941e109 	ldrb	w9, [x8, #120]
    4020226c:	3600008a 	tbz	w10, #0, 4020227c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0xf4>
    40202270:	2a1f03ea 	mov	w10, wzr
    40202274:	52800028 	mov	w8, #0x1                   	// #1
    40202278:	34ffff69 	cbz	w9, 40202264 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0xdc>
    4020227c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202280:	39518108 	ldrb	w8, [x8, #1120]
    40202284:	7100013f 	cmp	w9, #0x0
    40202288:	7a430900 	ccmp	w8, #0x3, #0x0, eq  // eq = none
    4020228c:	54001461 	b.ne	40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>  // b.any
    40202290:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202294:	9111c108 	add	x8, x8, #0x470
    40202298:	f9400109 	ldr	x9, [x8]
    4020229c:	b50013e9 	cbnz	x9, 40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>
    402022a0:	f9400908 	ldr	x8, [x8, #16]
    402022a4:	f100091f 	cmp	x8, #0x2
    402022a8:	54001381 	b.ne	40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>  // b.any
    402022ac:	f94202a8 	ldr	x8, [x21, #1024]
    402022b0:	f100051f 	cmp	x8, #0x1
    402022b4:	54000121 	b.ne	402022d8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x150>  // b.any
    402022b8:	b0000021 	adrp	x1, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402022bc:	91102021 	add	x1, x1, #0x408
    402022c0:	f940183a 	ldr	x26, [x1, #48]
    402022c4:	910243e0 	add	x0, sp, #0x90
    402022c8:	52800602 	mov	w2, #0x30                  	// #48
    402022cc:	94000de0 	bl	40205a4c <memcpy>
    402022d0:	52800028 	mov	w8, #0x1                   	// #1
    402022d4:	14000017 	b	40202330 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x1a8>
    402022d8:	910303e0 	add	x0, sp, #0xc0
    402022dc:	9100a014 	add	x20, x0, #0x28
    402022e0:	52800028 	mov	w8, #0x1                   	// #1
    402022e4:	b0000021 	adrp	x1, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402022e8:	91102021 	add	x1, x1, #0x408
    402022ec:	2a0803fa 	mov	w26, w8
    402022f0:	9100a03b 	add	x27, x1, #0x28
    402022f4:	52800502 	mov	w2, #0x28                  	// #40
    402022f8:	94000dd5 	bl	40205a4c <memcpy>
    402022fc:	2a1f03e8 	mov	w8, wzr
    40202300:	aa1b03e1 	mov	x1, x27
    40202304:	aa1403e0 	mov	x0, x20
    40202308:	3707ff3a 	tbnz	w26, #0, 402022ec <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x164>
    4020230c:	910243e0 	add	x0, sp, #0x90
    40202310:	910303e1 	add	x1, sp, #0xc0
    40202314:	52800602 	mov	w2, #0x30                  	// #48
    40202318:	94000dcd 	bl	40205a4c <memcpy>
    4020231c:	aa1f03e8 	mov	x8, xzr
    40202320:	a94f27fa 	ldp	x26, x9, [sp, #240]
    40202324:	a9502fea 	ldp	x10, x11, [sp, #256]
    40202328:	a907abe9 	stp	x9, x10, [sp, #120]
    4020232c:	f90047eb 	str	x11, [sp, #136]
    40202330:	b000003b 	adrp	x27, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202334:	9111e37b 	add	x27, x27, #0x478
    40202338:	39400b7c 	ldrb	w28, [x27, #2]
    4020233c:	7940037d 	ldrh	w29, [x27]
    40202340:	aa1b03f4 	mov	x20, x27
    40202344:	f8008e88 	str	x8, [x20, #8]!
    40202348:	91004360 	add	x0, x27, #0x10
    4020234c:	910243e1 	add	x1, sp, #0x90
    40202350:	52800602 	mov	w2, #0x30                  	// #48
    40202354:	94000dbe 	bl	40205a4c <memcpy>
    40202358:	52800068 	mov	w8, #0x3                   	// #3
    4020235c:	3901a368 	strb	w8, [x27, #104]
    40202360:	a947a7e8 	ldp	x8, x9, [sp, #120]
    40202364:	a904237a 	stp	x26, x8, [x27, #64]
    40202368:	f94047e8 	ldr	x8, [sp, #136]
    4020236c:	a9052369 	stp	x9, x8, [x27, #80]
    40202370:	a9077f7f 	stp	xzr, xzr, [x27, #112]
    40202374:	7901037d 	strh	w29, [x27, #128]
    40202378:	39020b7c 	strb	w28, [x27, #130]
    4020237c:	910303e8 	add	x8, sp, #0xc0
    40202380:	aa1403e0 	mov	x0, x20
    40202384:	9400047d 	bl	40203578 <jnox_kernel::reservation_jobs::Jobs::prepare_destination>
    40202388:	f94063e8 	ldr	x8, [sp, #192]
    4020238c:	f100091f 	cmp	x8, #0x2
    40202390:	54000cc0 	b.eq	40202528 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x3a0>  // b.none
    40202394:	910043e0 	add	x0, sp, #0x10
    40202398:	910303e1 	add	x1, sp, #0xc0
    4020239c:	52800d02 	mov	w2, #0x68                  	// #104
    402023a0:	94000dab 	bl	40205a4c <memcpy>
    402023a4:	b0000020 	adrp	x0, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402023a8:	91120000 	add	x0, x0, #0x480
    402023ac:	910043e1 	add	x1, sp, #0x10
    402023b0:	94000489 	bl	402035d4 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision>
    402023b4:	36000b20 	tbz	w0, #0, 40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>
    402023b8:	b94013e8 	ldr	w8, [sp, #16]
    402023bc:	36000b48 	tbz	w8, #0, 40202524 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x39c>
    402023c0:	3941cbe8 	ldrb	w8, [sp, #114]
    402023c4:	34000188 	cbz	w8, 402023f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x26c>
    402023c8:	71000d1f 	cmp	w8, #0x3
    402023cc:	54000a60 	b.eq	40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>  // b.none
    402023d0:	f9400fe0 	ldr	x0, [sp, #24]
    402023d4:	f100041f 	cmp	x0, #0x1
    402023d8:	54000ce8 	b.hi	40202574 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x3ec>  // b.pmore
    402023dc:	8b000f28 	add	x8, x25, x0, lsl #3
    402023e0:	f940e108 	ldr	x8, [x8, #448]
    402023e4:	b104011f 	cmn	x8, #0x100
    402023e8:	540009e2 	b.cs	40202524 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x39c>  // b.hs, b.nlast
    402023ec:	9104011a 	add	x26, x8, #0x100
    402023f0:	14000002 	b	402023f8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x270>
    402023f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    402023f8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402023fc:	9114e108 	add	x8, x8, #0x538
    40202400:	a9402508 	ldp	x8, x9, [x8]
    40202404:	ab09011b 	adds	x27, x8, x9
    40202408:	540008a2 	b.cs	4020251c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x394>  // b.hs, b.nlast
    4020240c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202410:	f942a508 	ldr	x8, [x8, #1352]
    40202414:	eb08037c 	subs	x28, x27, x8
    40202418:	54000823 	b.cc	4020251c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x394>  // b.lo, b.ul, b.last
    4020241c:	f9009bf9 	str	x25, [sp, #304]
    40202420:	910303f4 	add	x20, sp, #0xc0
    40202424:	9104e3e8 	add	x8, sp, #0x138
    40202428:	9104c3e0 	add	x0, sp, #0x130
    4020242c:	aa1f03e1 	mov	x1, xzr
    40202430:	94000718 	bl	40204090 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    40202434:	910303e0 	add	x0, sp, #0xc0
    40202438:	9104e3e1 	add	x1, sp, #0x138
    4020243c:	52800702 	mov	w2, #0x38                  	// #56
    40202440:	94000d83 	bl	40205a4c <memcpy>
    40202444:	9104e3e8 	add	x8, sp, #0x138
    40202448:	9104c3e0 	add	x0, sp, #0x130
    4020244c:	52800021 	mov	w1, #0x1                   	// #1
    40202450:	94000710 	bl	40204090 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    40202454:	9100e280 	add	x0, x20, #0x38
    40202458:	9104e3e1 	add	x1, sp, #0x138
    4020245c:	52800702 	mov	w2, #0x38                  	// #56
    40202460:	94000d7b 	bl	40205a4c <memcpy>
    40202464:	d503201f 	nop
    40202468:	10028bd4 	adr	x20, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    4020246c:	910043e1 	add	x1, sp, #0x10
    40202470:	aa1403e0 	mov	x0, x20
    40202474:	52800d02 	mov	w2, #0x68                  	// #104
    40202478:	94000d75 	bl	40205a4c <memcpy>
    4020247c:	52800088 	mov	w8, #0x4                   	// #4
    40202480:	a906a298 	stp	x24, x8, [x20, #104]
    40202484:	a907ee93 	stp	x19, x27, [x20, #120]
    40202488:	a908ea9c 	stp	x28, x26, [x20, #136]
    4020248c:	91026280 	add	x0, x20, #0x98
    40202490:	910303e1 	add	x1, sp, #0xc0
    40202494:	52800e02 	mov	w2, #0x70                  	// #112
    40202498:	94000d6d 	bl	40205a4c <memcpy>
    4020249c:	d5033fdf 	isb
    402024a0:	d53be034 	mrs	x20, cntpct_el0
    402024a4:	eb140268 	subs	x8, x19, x20
    402024a8:	9a8833e8 	csel	x8, xzr, x8, cc  // cc = lo, ul, last
    402024ac:	a913cff8 	stp	x24, x19, [sp, #312]
    402024b0:	a914ffe8 	stp	x8, xzr, [sp, #328]
    402024b4:	9104e3e4 	add	x4, sp, #0x138
    402024b8:	528002c0 	mov	w0, #0x16                  	// #22
    402024bc:	aa1403e1 	mov	x1, x20
    402024c0:	aa1f03e2 	mov	x2, xzr
    402024c4:	52800043 	mov	w3, #0x2                   	// #2
    402024c8:	9400002f 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    402024cc:	eb18029f 	cmp	x20, x24
    402024d0:	540003a3 	b.cc	40202544 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x3bc>  // b.lo, b.ul, b.last
    402024d4:	eb13029f 	cmp	x20, x19
    402024d8:	54000362 	b.cs	40202544 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x3bc>  // b.hs, b.nlast
    402024dc:	d5033fdf 	isb
    402024e0:	d53be024 	mrs	x4, cntpct_el0
    402024e4:	d503201f 	nop
    402024e8:	101091c8 	adr	x8, 40223720 <jnox_kernel::ordinary_reservations::RECEIPT>
    402024ec:	a9001116 	stp	x22, x4, [x8]
    402024f0:	f94202a8 	ldr	x8, [x21, #1024]
    402024f4:	f100091f 	cmp	x8, #0x2
    402024f8:	54000100 	b.eq	40202518 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x390>  // b.none
    402024fc:	f9429ee5 	ldr	x5, [x23, #1336]
    40202500:	eb05009f 	cmp	x4, x5
    40202504:	540002e2 	b.cs	40202560 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x3d8>  // b.hs, b.nlast
    40202508:	d50342ff 	msr	daifclr, #0x2
    4020250c:	d5033fdf 	isb
    40202510:	d503207f 	wfi
    40202514:	17ffffff 	b	40202510 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241+0x388>
    40202518:	97fffb64 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    4020251c:	52800060 	mov	w0, #0x3                   	// #3
    40202520:	94000393 	bl	4020336c <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    40202524:	97fffedd 	bl	40202098 <jnox_kernel::ordinary_reservations::run::{{closure}}>
    40202528:	394323e4 	ldrb	w4, [sp, #200]
    4020252c:	52800060 	mov	w0, #0x3                   	// #3
    40202530:	52800041 	mov	w1, #0x2                   	// #2
    40202534:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40202538:	52800043 	mov	w3, #0x2                   	// #2
    4020253c:	aa1f03e5 	mov	x5, xzr
    40202540:	94000068 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>
    40202544:	52800040 	mov	w0, #0x2                   	// #2
    40202548:	52800121 	mov	w1, #0x9                   	// #9
    4020254c:	aa1f03e2 	mov	x2, xzr
    40202550:	52800043 	mov	w3, #0x2                   	// #2
    40202554:	aa1403e4 	mov	x4, x20
    40202558:	aa1303e5 	mov	x5, x19
    4020255c:	94000061 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>
    40202560:	52800040 	mov	w0, #0x2                   	// #2
    40202564:	52800161 	mov	w1, #0xb                   	// #11
    40202568:	aa1f03e2 	mov	x2, xzr
    4020256c:	52800043 	mov	w3, #0x2                   	// #2
    40202570:	9400005c 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>
    40202574:	d503201f 	nop
    40202578:	1001cb42 	adr	x2, 40205ee0 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.16192825690684220241+0x48>
    4020257c:	52800041 	mov	w1, #0x2                   	// #2
    40202580:	940009e3 	bl	40204d0c <core::panicking::panic_bounds_check>

0000000040202584 <jnox_kernel::ordinary_reservations::event>:
    40202584:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202588:	f9438909 	ldr	x9, [x8, #1808]
    4020258c:	f110013f 	cmp	x9, #0x400
    40202590:	54000241 	b.ne	402025d8 <jnox_kernel::ordinary_reservations::event+0x54>  // b.any
    40202594:	aa1f03e8 	mov	x8, xzr
    40202598:	52800309 	mov	w9, #0x18                  	// #24
    4020259c:	72a12009 	movk	w9, #0x900, lsl #16
    402025a0:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    402025a4:	d503201f 	nop
    402025a8:	1001c6cb 	adr	x11, 40205e80 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.16192825690684220241+0x10>
    402025ac:	3868696c 	ldrb	w12, [x11, x8]
    402025b0:	b940012d 	ldr	w13, [x9]
    402025b4:	3628006d 	tbz	w13, #5, 402025c0 <jnox_kernel::ordinary_reservations::event+0x3c>
    402025b8:	d5033fdf 	isb
    402025bc:	17fffffd 	b	402025b0 <jnox_kernel::ordinary_reservations::event+0x2c>
    402025c0:	91000508 	add	x8, x8, #0x1
    402025c4:	b900014c 	str	w12, [x10]
    402025c8:	f100511f 	cmp	x8, #0x14
    402025cc:	54ffff01 	b.ne	402025ac <jnox_kernel::ordinary_reservations::event+0x28>  // b.any
    402025d0:	d503205f 	wfe
    402025d4:	17ffffff 	b	402025d0 <jnox_kernel::ordinary_reservations::event+0x4c>
    402025d8:	d503201f 	nop
    402025dc:	100289ea 	adr	x10, 40207718 <jnox_kernel::ordinary_reservations::TRACE>
    402025e0:	8b09194a 	add	x10, x10, x9, lsl #6
    402025e4:	a9000540 	stp	x0, x1, [x10]
    402025e8:	a940308b 	ldp	x11, x12, [x4]
    402025ec:	a9010d42 	stp	x2, x3, [x10, #16]
    402025f0:	a941388d 	ldp	x13, x14, [x4, #16]
    402025f4:	a902314b 	stp	x11, x12, [x10, #32]
    402025f8:	a903394d 	stp	x13, x14, [x10, #48]
    402025fc:	91000529 	add	x9, x9, #0x1
    40202600:	f9038909 	str	x9, [x8, #1808]
    40202604:	d65f03c0 	ret

0000000040202608 <jnox_kernel::ordinary_reservations::fresh>:
    40202608:	d10143ff 	sub	sp, sp, #0x50
    4020260c:	a90357f6 	stp	x22, x21, [sp, #48]
    40202610:	a9044ff4 	stp	x20, x19, [sp, #64]
    40202614:	aa0003f3 	mov	x19, x0
    40202618:	d503201f 	nop
    4020261c:	10007a28 	adr	x8, 40203560 <reservation_worker_a>
    40202620:	d503201f 	nop
    40202624:	10007a49 	adr	x9, 4020356c <reservation_worker_b>
    40202628:	d503201f 	nop
    4020262c:	10ffdaea 	adr	x10, 40202188 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16192825690684220241>
    40202630:	a900a7e8 	stp	x8, x9, [sp, #8]
    40202634:	a901fbea 	stp	x10, x30, [sp, #24]
    40202638:	f100081f 	cmp	x0, #0x2
    4020263c:	540003a8 	b.hi	402026b0 <jnox_kernel::ordinary_reservations::fresh+0xa8>  // b.pmore
    40202640:	910023e8 	add	x8, sp, #0x8
    40202644:	f8737915 	ldr	x21, [x8, x19, lsl #3]
    40202648:	d503201f 	nop
    4020264c:	100a86a8 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241>
    40202650:	8b133916 	add	x22, x8, x19, lsl #14
    40202654:	52879808 	mov	w8, #0x3cc0                	// #15552
    40202658:	8b0802d4 	add	x20, x22, x8
    4020265c:	aa1403e0 	mov	x0, x20
    40202660:	2a1f03e1 	mov	w1, wzr
    40202664:	52806802 	mov	w2, #0x340                 	// #832
    40202668:	94000d85 	bl	40205c7c <memset>
    4020266c:	f91eded5 	str	x21, [x22, #15800]
    40202670:	528068a8 	mov	w8, #0x345                 	// #837
    40202674:	f91ee2c8 	str	x8, [x22, #15808]
    40202678:	f1000a7f 	cmp	x19, #0x2
    4020267c:	54000061 	b.ne	40202688 <jnox_kernel::ordinary_reservations::fresh+0x80>  // b.any
    40202680:	52818328 	mov	w8, #0xc19                 	// #3097
    40202684:	14000004 	b	40202694 <jnox_kernel::ordinary_reservations::fresh+0x8c>
    40202688:	d503201f 	nop
    4020268c:	1001bf28 	adr	x8, 40205e70 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.16192825690684220241>
    40202690:	f8737908 	ldr	x8, [x8, x19, lsl #3]
    40202694:	f9008e88 	str	x8, [x20, #280]
    40202698:	aa1403e0 	mov	x0, x20
    4020269c:	a9444ff4 	ldp	x20, x19, [sp, #64]
    402026a0:	a94357f6 	ldp	x22, x21, [sp, #48]
    402026a4:	f94013fe 	ldr	x30, [sp, #32]
    402026a8:	910143ff 	add	sp, sp, #0x50
    402026ac:	d65f03c0 	ret
    402026b0:	d503201f 	nop
    402026b4:	1001bf22 	adr	x2, 40205e98 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.16192825690684220241>
    402026b8:	aa1303e0 	mov	x0, x19
    402026bc:	52800061 	mov	w1, #0x3                   	// #3
    402026c0:	94000993 	bl	40204d0c <core::panicking::panic_bounds_check>

00000000402026c4 <jnox_kernel::ordinary_reservations::state>:
    402026c4:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402026c8:	f9420108 	ldr	x8, [x8, #1024]
    402026cc:	f100091f 	cmp	x8, #0x2
    402026d0:	54000040 	b.eq	402026d8 <jnox_kernel::ordinary_reservations::state+0x14>  // b.none
    402026d4:	d65f03c0 	ret
    402026d8:	f81f0ffe 	str	x30, [sp, #-16]!
    402026dc:	97fffaf3 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

00000000402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>:
    402026e0:	d10603ff 	sub	sp, sp, #0x180
    402026e4:	a9127bfd 	stp	x29, x30, [sp, #288]
    402026e8:	a9136ffc 	stp	x28, x27, [sp, #304]
    402026ec:	a91467fa 	stp	x26, x25, [sp, #320]
    402026f0:	a9155ff8 	stp	x24, x23, [sp, #336]
    402026f4:	a91657f6 	stp	x22, x21, [sp, #352]
    402026f8:	a9174ff4 	stp	x20, x19, [sp, #368]
    402026fc:	d5034fdf 	msr	daifset, #0xf
    40202700:	d51be23f 	msr	cntp_ctl_el0, xzr
    40202704:	d5033fdf 	isb
    40202708:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0xb8e0>
    4020270c:	395f6109 	ldrb	w9, [x8, #2008]
    40202710:	7100053f 	cmp	w9, #0x1
    40202714:	54000061 	b.ne	40202720 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x40>  // b.any
    40202718:	d503205f 	wfe
    4020271c:	17ffffff 	b	40202718 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x38>
    40202720:	aa0303fb 	mov	x27, x3
    40202724:	aa0203fc 	mov	x28, x2
    40202728:	a90807e0 	stp	x0, x1, [sp, #128]
    4020272c:	a90917e4 	stp	x4, x5, [sp, #144]
    40202730:	52800029 	mov	w9, #0x1                   	// #1
    40202734:	d503201f 	nop
    40202738:	1010b78a 	adr	x10, 40223e28 <jnox_kernel::ordinary_reservations::stage_hooks::stage_probe::OBSERVATION>
    4020273c:	391f6109 	strb	w9, [x8, #2008]
    40202740:	f9400548 	ldr	x8, [x10, #8]
    40202744:	f9400949 	ldr	x9, [x10, #16]
    40202748:	f940014a 	ldr	x10, [x10]
    4020274c:	7200015f 	tst	w10, #0x1
    40202750:	9a9f1129 	csel	x9, x9, xzr, ne  // ne = any
    40202754:	9a9f1101 	csel	x1, x8, xzr, ne  // ne = any
    40202758:	52800048 	mov	w8, #0x2                   	// #2
    4020275c:	5280008b 	mov	w11, #0x4                   	// #4
    40202760:	a90bafe8 	stp	x8, x11, [sp, #184]
    40202764:	f100015f 	cmp	x10, #0x0
    40202768:	1a9f07e8 	cset	w8, ne  // ne = any
    4020276c:	a90ca7e8 	stp	x8, x9, [sp, #200]
    40202770:	9102e3e4 	add	x4, sp, #0xb8
    40202774:	528004c0 	mov	w0, #0x26                  	// #38
    40202778:	aa1f03e2 	mov	x2, xzr
    4020277c:	52800043 	mov	w3, #0x2                   	// #2
    40202780:	97ffff81 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202784:	d503201f 	nop
    40202788:	10107cc9 	adr	x9, 40223720 <jnox_kernel::ordinary_reservations::RECEIPT>
    4020278c:	a9400528 	ldp	x8, x1, [x9]
    40202790:	a9415538 	ldp	x24, x21, [x9, #16]
    40202794:	a9424d34 	ldp	x20, x19, [x9, #32]
    40202798:	a943692b 	ldp	x11, x26, [x9, #48]
    4020279c:	f940212a 	ldr	x10, [x9, #64]
    402027a0:	a9012fea 	stp	x10, x11, [sp, #16]
    402027a4:	a944a92b 	ldp	x11, x10, [x9, #72]
    402027a8:	a9022beb 	stp	x11, x10, [sp, #32]
    402027ac:	a945a93d 	ldp	x29, x10, [x9, #88]
    402027b0:	f9005bea 	str	x10, [sp, #176]
    402027b4:	a946a92b 	ldp	x11, x10, [x9, #104]
    402027b8:	f9001fea 	str	x10, [sp, #56]
    402027bc:	f9403d2a 	ldr	x10, [x9, #120]
    402027c0:	a9042fea 	stp	x10, x11, [sp, #64]
    402027c4:	a948292b 	ldp	x11, x10, [x9, #128]
    402027c8:	f9001beb 	str	x11, [sp, #48]
    402027cc:	f9003fea 	str	x10, [sp, #120]
    402027d0:	a949292b 	ldp	x11, x10, [x9, #144]
    402027d4:	a9062fea 	stp	x10, x11, [sp, #96]
    402027d8:	a94a292b 	ldp	x11, x10, [x9, #160]
    402027dc:	a9052fea 	stp	x10, x11, [sp, #80]
    402027e0:	f9405929 	ldr	x9, [x9, #176]
    402027e4:	f9003be9 	str	x9, [sp, #112]
    402027e8:	d5033fdf 	isb
    402027ec:	d53be039 	mrs	x25, cntpct_el0
    402027f0:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402027f4:	d503201f 	nop
    402027f8:	10026f56 	adr	x22, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    402027fc:	f942f137 	ldr	x23, [x9, #1504]
    40202800:	a90a6ffc 	stp	x28, x27, [sp, #160]
    40202804:	b40001a1 	cbz	x1, 40202838 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x158>
    40202808:	f9403ec9 	ldr	x9, [x22, #120]
    4020280c:	f1000aff 	cmp	x23, #0x2
    40202810:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    40202814:	a90b87e8 	stp	x8, x1, [sp, #184]
    40202818:	a90cffe9 	stp	x9, xzr, [sp, #200]
    4020281c:	9102e3e4 	add	x4, sp, #0xb8
    40202820:	52800480 	mov	w0, #0x24                  	// #36
    40202824:	aa1f03e2 	mov	x2, xzr
    40202828:	52800043 	mov	w3, #0x2                   	// #2
    4020282c:	97ffff56 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202830:	f94002c8 	ldr	x8, [x22]
    40202834:	14000002 	b	4020283c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x15c>
    40202838:	aa1703e8 	mov	x8, x23
    4020283c:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202840:	9117a129 	add	x9, x9, #0x5e8
    40202844:	f940012a 	ldr	x10, [x9]
    40202848:	7200011f 	tst	w8, #0x1
    4020284c:	52800048 	mov	w8, #0x2                   	// #2
    40202850:	f9403529 	ldr	x9, [x9, #104]
    40202854:	9a881148 	csel	x8, x10, x8, ne  // ne = any
    40202858:	f1000aff 	cmp	x23, #0x2
    4020285c:	da9f113b 	csinv	x27, x9, xzr, ne  // ne = any
    40202860:	9a8802fc 	csel	x28, x23, x8, eq  // eq = none
    40202864:	d503201f 	nop
    40202868:	10107bc8 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    4020286c:	c8dffd08 	ldar	x8, [x8]
    40202870:	a90be3fb 	stp	x27, x24, [sp, #184]
    40202874:	f27e031f 	tst	x24, #0x4
    40202878:	f9405be9 	ldr	x9, [sp, #176]
    4020287c:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    40202880:	a90ca7e8 	stp	x8, x9, [sp, #200]
    40202884:	9102e3e4 	add	x4, sp, #0xb8
    40202888:	52800300 	mov	w0, #0x18                  	// #24
    4020288c:	aa1903e1 	mov	x1, x25
    40202890:	aa1f03e2 	mov	x2, xzr
    40202894:	aa1c03e3 	mov	x3, x28
    40202898:	97ffff3b 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    4020289c:	37001d58 	tbnz	w24, #0, 40202c44 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x564>
    402028a0:	37081f78 	tbnz	w24, #1, 40202c8c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x5ac>
    402028a4:	371020f8 	tbnz	w24, #2, 40202cc0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x5e0>
    402028a8:	37182258 	tbnz	w24, #3, 40202cf0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x610>
    402028ac:	36200378 	tbz	w24, #4, 40202918 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x238>
    402028b0:	a94627e8 	ldp	x8, x9, [sp, #96]
    402028b4:	a90ba3e9 	stp	x9, x8, [sp, #184]
    402028b8:	a94527e8 	ldp	x8, x9, [sp, #80]
    402028bc:	a90ca3e9 	stp	x9, x8, [sp, #200]
    402028c0:	9102e3e4 	add	x4, sp, #0xb8
    402028c4:	528003a0 	mov	w0, #0x1d                  	// #29
    402028c8:	f9403ff3 	ldr	x19, [sp, #120]
    402028cc:	aa1303e1 	mov	x1, x19
    402028d0:	aa1f03e2 	mov	x2, xzr
    402028d4:	aa1c03e3 	mov	x3, x28
    402028d8:	97ffff2b 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    402028dc:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402028e0:	91196108 	add	x8, x8, #0x658
    402028e4:	a9402109 	ldp	x9, x8, [x8]
    402028e8:	f1000aff 	cmp	x23, #0x2
    402028ec:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    402028f0:	f9403bea 	ldr	x10, [sp, #112]
    402028f4:	a90ba7ea 	stp	x10, x9, [sp, #184]
    402028f8:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    402028fc:	a90cefe8 	stp	x8, x27, [sp, #200]
    40202900:	9102e3e4 	add	x4, sp, #0xb8
    40202904:	528003c0 	mov	w0, #0x1e                  	// #30
    40202908:	aa1303e1 	mov	x1, x19
    4020290c:	aa1f03e2 	mov	x2, xzr
    40202910:	aa1c03e3 	mov	x3, x28
    40202914:	97ffff1c 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202918:	f1000aff 	cmp	x23, #0x2
    4020291c:	54000800 	b.eq	40202a1c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x33c>  // b.none
    40202920:	aa1f03f3 	mov	x19, xzr
    40202924:	52800028 	mov	w8, #0x1                   	// #1
    40202928:	52800714 	mov	w20, #0x38                  	// #56
    4020292c:	9b145a77 	madd	x23, x19, x20, x22
    40202930:	2a0803f5 	mov	w21, w8
    40202934:	a949a6e8 	ldp	x8, x9, [x23, #152]
    40202938:	f94056ea 	ldr	x10, [x23, #168]
    4020293c:	a90ba7e8 	stp	x8, x9, [sp, #184]
    40202940:	f9405ee8 	ldr	x8, [x23, #184]
    40202944:	a90ca3ea 	stp	x10, x8, [sp, #200]
    40202948:	9102e3e4 	add	x4, sp, #0xb8
    4020294c:	52800440 	mov	w0, #0x22                  	// #34
    40202950:	aa1903e1 	mov	x1, x25
    40202954:	aa1f03e2 	mov	x2, xzr
    40202958:	aa1303e3 	mov	x3, x19
    4020295c:	97ffff0a 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202960:	f9405ae8 	ldr	x8, [x23, #176]
    40202964:	a94c2ae9 	ldp	x9, x10, [x23, #192]
    40202968:	a90ba7e8 	stp	x8, x9, [sp, #184]
    4020296c:	f9404ac8 	ldr	x8, [x22, #144]
    40202970:	a90ca3ea 	stp	x10, x8, [sp, #200]
    40202974:	9102e3e4 	add	x4, sp, #0xb8
    40202978:	52800460 	mov	w0, #0x23                  	// #35
    4020297c:	aa1903e1 	mov	x1, x25
    40202980:	aa1f03e2 	mov	x2, xzr
    40202984:	aa1303e3 	mov	x3, x19
    40202988:	97fffeff 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    4020298c:	8b1312c8 	add	x8, x22, x19, lsl #4
    40202990:	a941a909 	ldp	x9, x10, [x8, #24]
    40202994:	a90babe9 	stp	x9, x10, [sp, #184]
    40202998:	a943a109 	ldp	x9, x8, [x8, #56]
    4020299c:	a90ca3e9 	stp	x9, x8, [sp, #200]
    402029a0:	9102e3e4 	add	x4, sp, #0xb8
    402029a4:	528003e0 	mov	w0, #0x1f                  	// #31
    402029a8:	aa1903e1 	mov	x1, x25
    402029ac:	aa1f03e2 	mov	x2, xzr
    402029b0:	aa1303e3 	mov	x3, x19
    402029b4:	97fffef4 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    402029b8:	8b130ac8 	add	x8, x22, x19, lsl #2
    402029bc:	b9401109 	ldr	w9, [x8, #16]
    402029c0:	b9405908 	ldr	w8, [x8, #88]
    402029c4:	8b1302ca 	add	x10, x22, x19
    402029c8:	3941814a 	ldrb	w10, [x10, #96]
    402029cc:	b94002cb 	ldr	w11, [x22]
    402029d0:	f94006cc 	ldr	x12, [x22, #8]
    402029d4:	eb13019f 	cmp	x12, x19
    402029d8:	1a9f17ec 	cset	w12, eq  // eq = none
    402029dc:	39418acd 	ldrb	w13, [x22, #98]
    402029e0:	71000dbf 	cmp	w13, #0x3
    402029e4:	1a8d07ed 	csinc	w13, wzr, w13, eq  // eq = none
    402029e8:	a90ba3e9 	stp	x9, x8, [sp, #184]
    402029ec:	6a0c017f 	tst	w11, w12
    402029f0:	9a9f11a8 	csel	x8, x13, xzr, ne  // ne = any
    402029f4:	a90ca3ea 	stp	x10, x8, [sp, #200]
    402029f8:	9102e3e4 	add	x4, sp, #0xb8
    402029fc:	52800400 	mov	w0, #0x20                  	// #32
    40202a00:	aa1903e1 	mov	x1, x25
    40202a04:	aa1f03e2 	mov	x2, xzr
    40202a08:	aa1303e3 	mov	x3, x19
    40202a0c:	97fffede 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202a10:	2a1f03e8 	mov	w8, wzr
    40202a14:	52800033 	mov	w19, #0x1                   	// #1
    40202a18:	3707f8b5 	tbnz	w21, #0, 4020292c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x24c>
    40202a1c:	52801008 	mov	w8, #0x80                  	// #128
    40202a20:	52802109 	mov	w9, #0x108                 	// #264
    40202a24:	a90ba3e8 	stp	x8, x8, [sp, #184]
    40202a28:	52801708 	mov	w8, #0xb8                  	// #184
    40202a2c:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202a30:	9102e3e4 	add	x4, sp, #0xb8
    40202a34:	52800420 	mov	w0, #0x21                  	// #33
    40202a38:	aa1903e1 	mov	x1, x25
    40202a3c:	aa1f03e2 	mov	x2, xzr
    40202a40:	52800043 	mov	w3, #0x2                   	// #2
    40202a44:	97fffed0 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202a48:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0xb8e0>
    40202a4c:	f943f508 	ldr	x8, [x8, #2024]
    40202a50:	f101011f 	cmp	x8, #0x40
    40202a54:	52800809 	mov	w9, #0x40                  	// #64
    40202a58:	9a893113 	csel	x19, x8, x9, cc  // cc = lo, ul, last
    40202a5c:	a94a5ff8 	ldp	x24, x23, [sp, #160]
    40202a60:	b4000288 	cbz	x8, 40202ab0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x3d0>
    40202a64:	aa1f03f4 	mov	x20, xzr
    40202a68:	b0000035 	adrp	x21, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202a6c:	910022b5 	add	x21, x21, #0x8
    40202a70:	b0000116 	adrp	x22, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0xb8e0>
    40202a74:	911fc2d6 	add	x22, x22, #0x7f0
    40202a78:	f9400ac1 	ldr	x1, [x22, #16]
    40202a7c:	f94006c8 	ldr	x8, [x22, #8]
    40202a80:	f84186c9 	ldr	x9, [x22], #24
    40202a84:	aa1403ea 	mov	x10, x20
    40202a88:	91000694 	add	x20, x20, #0x1
    40202a8c:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202a90:	a97f8ea2 	ldp	x2, x3, [x21, #-8]
    40202a94:	a90cffea 	stp	x10, xzr, [sp, #200]
    40202a98:	9102e3e4 	add	x4, sp, #0xb8
    40202a9c:	52800180 	mov	w0, #0xc                   	// #12
    40202aa0:	97fffeb9 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202aa4:	910042b5 	add	x21, x21, #0x10
    40202aa8:	eb14027f 	cmp	x19, x20
    40202aac:	54fffe61 	b.ne	40202a78 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x398>  // b.any
    40202ab0:	52800314 	mov	w20, #0x18                  	// #24
    40202ab4:	72a12014 	movk	w20, #0x900, lsl #16
    40202ab8:	d5033fdf 	isb
    40202abc:	d53be021 	mrs	x1, cntpct_el0
    40202ac0:	a94823e9 	ldp	x9, x8, [sp, #128]
    40202ac4:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202ac8:	a94923e9 	ldp	x9, x8, [sp, #144]
    40202acc:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202ad0:	9102e3e4 	add	x4, sp, #0xb8
    40202ad4:	528001a0 	mov	w0, #0xd                   	// #13
    40202ad8:	aa1803e2 	mov	x2, x24
    40202adc:	aa1703e3 	mov	x3, x23
    40202ae0:	97fffea9 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202ae4:	aa1f03e8 	mov	x8, xzr
    40202ae8:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202aec:	d503201f 	nop
    40202af0:	10019e0a 	adr	x10, 40205eb0 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.16192825690684220241+0x18>
    40202af4:	3868694b 	ldrb	w11, [x10, x8]
    40202af8:	b940028c 	ldr	w12, [x20]
    40202afc:	3628006c 	tbz	w12, #5, 40202b08 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x428>
    40202b00:	d5033fdf 	isb
    40202b04:	17fffffd 	b	40202af8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x418>
    40202b08:	91000508 	add	x8, x8, #0x1
    40202b0c:	b900012b 	str	w11, [x9]
    40202b10:	f1002d1f 	cmp	x8, #0xb
    40202b14:	54ffff01 	b.ne	40202af4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x414>  // b.any
    40202b18:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202b1c:	f9438915 	ldr	x21, [x8, #1808]
    40202b20:	b4000755 	cbz	x21, 40202c08 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x528>
    40202b24:	aa1f03f6 	mov	x22, xzr
    40202b28:	9102e3e8 	add	x8, sp, #0xb8
    40202b2c:	b202e7f7 	mov	x23, #0xcccccccccccccccc    	// #-3689348814741910324
    40202b30:	f29999b7 	movk	x23, #0xcccd
    40202b34:	91004113 	add	x19, x8, #0x10
    40202b38:	52800158 	mov	w24, #0xa                   	// #10
    40202b3c:	910423f9 	add	x25, sp, #0x108
    40202b40:	52a1201a 	mov	w26, #0x9000000             	// #150994944
    40202b44:	5280041b 	mov	w27, #0x20                  	// #32
    40202b48:	d503201f 	nop
    40202b4c:	10025e7c 	adr	x28, 40207718 <jnox_kernel::ordinary_reservations::TRACE>
    40202b50:	8b161b81 	add	x1, x28, x22, lsl #6
    40202b54:	910006d6 	add	x22, x22, #0x1
    40202b58:	aa1303e0 	mov	x0, x19
    40202b5c:	52800802 	mov	w2, #0x40                  	// #64
    40202b60:	94000bbb 	bl	40205a4c <memcpy>
    40202b64:	aa1f03e8 	mov	x8, xzr
    40202b68:	b9011bff 	str	wzr, [sp, #280]
    40202b6c:	f8687a69 	ldr	x9, [x19, x8, lsl #3]
    40202b70:	91000508 	add	x8, x8, #0x1
    40202b74:	5280026a 	mov	w10, #0x13                  	// #19
    40202b78:	a910ffff 	stp	xzr, xzr, [sp, #264]
    40202b7c:	f1004d5f 	cmp	x10, #0x13
    40202b80:	54000d08 	b.hi	40202d20 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x640>  // b.pmore
    40202b84:	9bd77d2b 	umulh	x11, x9, x23
    40202b88:	d343fd6b 	lsr	x11, x11, #3
    40202b8c:	1b18a56c 	msub	w12, w11, w24, w9
    40202b90:	321c058c 	orr	w12, w12, #0x30
    40202b94:	382a6b2c 	strb	w12, [x25, x10]
    40202b98:	d100054a 	sub	x10, x10, #0x1
    40202b9c:	f100293f 	cmp	x9, #0xa
    40202ba0:	aa0b03e9 	mov	x9, x11
    40202ba4:	54fffec2 	b.cs	40202b7c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x49c>  // b.hs, b.nlast
    40202ba8:	91000549 	add	x9, x10, #0x1
    40202bac:	38696b2a 	ldrb	w10, [x25, x9]
    40202bb0:	b940028b 	ldr	w11, [x20]
    40202bb4:	3628006b 	tbz	w11, #5, 40202bc0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x4e0>
    40202bb8:	d5033fdf 	isb
    40202bbc:	17fffffd 	b	40202bb0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x4d0>
    40202bc0:	91000529 	add	x9, x9, #0x1
    40202bc4:	b900034a 	str	w10, [x26]
    40202bc8:	f100513f 	cmp	x9, #0x14
    40202bcc:	54ffff01 	b.ne	40202bac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x4cc>  // b.any
    40202bd0:	14000002 	b	40202bd8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x4f8>
    40202bd4:	d5033fdf 	isb
    40202bd8:	b9400289 	ldr	w9, [x20]
    40202bdc:	372fffc9 	tbnz	w9, #5, 40202bd4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x4f4>
    40202be0:	b900035b 	str	w27, [x26]
    40202be4:	f100211f 	cmp	x8, #0x8
    40202be8:	54fffc01 	b.ne	40202b68 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x488>  // b.any
    40202bec:	14000002 	b	40202bf4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x514>
    40202bf0:	d5033fdf 	isb
    40202bf4:	b9400288 	ldr	w8, [x20]
    40202bf8:	372fffc8 	tbnz	w8, #5, 40202bf0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x510>
    40202bfc:	b9000358 	str	w24, [x26]
    40202c00:	eb1502df 	cmp	x22, x21
    40202c04:	54fffa61 	b.ne	40202b50 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x470>  // b.any
    40202c08:	aa1f03e8 	mov	x8, xzr
    40202c0c:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202c10:	d503201f 	nop
    40202c14:	7001952a 	adr	x10, 40205ebb <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.16192825690684220241+0x23>
    40202c18:	3868694b 	ldrb	w11, [x10, x8]
    40202c1c:	b940028c 	ldr	w12, [x20]
    40202c20:	3628006c 	tbz	w12, #5, 40202c2c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x54c>
    40202c24:	d5033fdf 	isb
    40202c28:	17fffffd 	b	40202c1c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x53c>
    40202c2c:	91000508 	add	x8, x8, #0x1
    40202c30:	b900012b 	str	w11, [x9]
    40202c34:	f100251f 	cmp	x8, #0x9
    40202c38:	54ffff01 	b.ne	40202c18 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x538>  // b.any
    40202c3c:	d503205f 	wfe
    40202c40:	17ffffff 	b	40202c3c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x55c>
    40202c44:	a94127e8 	ldp	x8, x9, [sp, #16]
    40202c48:	a90ba7f3 	stp	x19, x9, [sp, #184]
    40202c4c:	a90ca3fa 	stp	x26, x8, [sp, #200]
    40202c50:	9102e3e4 	add	x4, sp, #0xb8
    40202c54:	52800320 	mov	w0, #0x19                  	// #25
    40202c58:	aa1503e1 	mov	x1, x21
    40202c5c:	aa1f03e2 	mov	x2, xzr
    40202c60:	52800043 	mov	w3, #0x2                   	// #2
    40202c64:	97fffe48 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202c68:	a90bd3f5 	stp	x21, x20, [sp, #184]
    40202c6c:	a90ccffa 	stp	x26, x19, [sp, #200]
    40202c70:	9102e3e4 	add	x4, sp, #0xb8
    40202c74:	528004a0 	mov	w0, #0x25                  	// #37
    40202c78:	aa1403e1 	mov	x1, x20
    40202c7c:	aa1f03e2 	mov	x2, xzr
    40202c80:	52800043 	mov	w3, #0x2                   	// #2
    40202c84:	97fffe40 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202c88:	360fe0f8 	tbz	w24, #1, 402028a4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x1c4>
    40202c8c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202c90:	f9432d08 	ldr	x8, [x8, #1624]
    40202c94:	f1000aff 	cmp	x23, #0x2
    40202c98:	a90bfffb 	stp	x27, xzr, [sp, #184]
    40202c9c:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40202ca0:	a90cffe8 	stp	x8, xzr, [sp, #200]
    40202ca4:	9102e3e4 	add	x4, sp, #0xb8
    40202ca8:	52800340 	mov	w0, #0x1a                  	// #26
    40202cac:	f94013e1 	ldr	x1, [sp, #32]
    40202cb0:	aa1f03e2 	mov	x2, xzr
    40202cb4:	52800043 	mov	w3, #0x2                   	// #2
    40202cb8:	97fffe33 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202cbc:	3617df78 	tbz	w24, #2, 402028a8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x1c8>
    40202cc0:	924003a8 	and	x8, x29, #0x1
    40202cc4:	d341ffa9 	lsr	x9, x29, #1
    40202cc8:	a90ba3fd 	stp	x29, x8, [sp, #184]
    40202ccc:	f9405be8 	ldr	x8, [sp, #176]
    40202cd0:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202cd4:	9102e3e4 	add	x4, sp, #0xb8
    40202cd8:	52800360 	mov	w0, #0x1b                  	// #27
    40202cdc:	f94017e1 	ldr	x1, [sp, #40]
    40202ce0:	aa1f03e2 	mov	x2, xzr
    40202ce4:	aa1c03e3 	mov	x3, x28
    40202ce8:	97fffe27 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202cec:	361fde18 	tbz	w24, #3, 402028ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x1cc>
    40202cf0:	a94327e8 	ldp	x8, x9, [sp, #48]
    40202cf4:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202cf8:	52800028 	mov	w8, #0x1                   	// #1
    40202cfc:	a94407e9 	ldp	x9, x1, [sp, #64]
    40202d00:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202d04:	9102e3e4 	add	x4, sp, #0xb8
    40202d08:	52800380 	mov	w0, #0x1c                  	// #28
    40202d0c:	aa1f03e2 	mov	x2, xzr
    40202d10:	aa1c03e3 	mov	x3, x28
    40202d14:	97fffe1c 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202d18:	3727dcd8 	tbnz	w24, #4, 402028b0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x1d0>
    40202d1c:	17fffeff 	b	40202918 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241+0x238>
    40202d20:	d503201f 	nop
    40202d24:	10019022 	adr	x2, 40205f28 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.16192825690684220241+0x90>
    40202d28:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    40202d2c:	52800281 	mov	w1, #0x14                  	// #20
    40202d30:	940007f7 	bl	40204d0c <core::panicking::panic_bounds_check>

0000000040202d34 <jnox_kernel::ordinary_reservations::Runtime::arm>:
    40202d34:	d10103ff 	sub	sp, sp, #0x40
    40202d38:	a90257fe 	stp	x30, x21, [sp, #32]
    40202d3c:	a9034ff4 	stp	x20, x19, [sp, #48]
    40202d40:	aa0203f3 	mov	x19, x2
    40202d44:	aa0003e2 	mov	x2, x0
    40202d48:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202d4c:	91158129 	add	x9, x9, #0x560
    40202d50:	a9020533 	stp	x19, x1, [x9, #32]
    40202d54:	52800028 	mov	w8, #0x1                   	// #1
    40202d58:	d51be253 	msr	cntp_cval_el0, x19
    40202d5c:	d51be228 	msr	cntp_ctl_el0, x8
    40202d60:	d5033fdf 	isb
    40202d64:	d53be255 	mrs	x21, cntp_cval_el0
    40202d68:	d53be234 	mrs	x20, cntp_ctl_el0
    40202d6c:	d5033fdf 	isb
    40202d70:	d53be028 	mrs	x8, cntpct_el0
    40202d74:	a90053f3 	stp	x19, x20, [sp]
    40202d78:	f9400123 	ldr	x3, [x9]
    40202d7c:	a90107f5 	stp	x21, x1, [sp, #16]
    40202d80:	910003e4 	mov	x4, sp
    40202d84:	52800060 	mov	w0, #0x3                   	// #3
    40202d88:	aa0803e1 	mov	x1, x8
    40202d8c:	97fffdfe 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202d90:	eb1302bf 	cmp	x21, x19
    40202d94:	54000101 	b.ne	40202db4 <jnox_kernel::ordinary_reservations::Runtime::arm+0x80>  // b.any
    40202d98:	92400688 	and	x8, x20, #0x3
    40202d9c:	f100051f 	cmp	x8, #0x1
    40202da0:	540000a1 	b.ne	40202db4 <jnox_kernel::ordinary_reservations::Runtime::arm+0x80>  // b.any
    40202da4:	a9434ff4 	ldp	x20, x19, [sp, #48]
    40202da8:	a94257fe 	ldp	x30, x21, [sp, #32]
    40202dac:	910103ff 	add	sp, sp, #0x40
    40202db0:	d65f03c0 	ret
    40202db4:	97fff93d 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

0000000040202db8 <jnox_kernel::ordinary_reservations::Runtime::close>:
    40202db8:	d103c3ff 	sub	sp, sp, #0xf0
    40202dbc:	a9097bfd 	stp	x29, x30, [sp, #144]
    40202dc0:	a90a6ffc 	stp	x28, x27, [sp, #160]
    40202dc4:	a90b67fa 	stp	x26, x25, [sp, #176]
    40202dc8:	a90c5ff8 	stp	x24, x23, [sp, #192]
    40202dcc:	a90d57f6 	stp	x22, x21, [sp, #208]
    40202dd0:	a90e4ff4 	stp	x20, x19, [sp, #224]
    40202dd4:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202dd8:	91140108 	add	x8, x8, #0x500
    40202ddc:	a9405113 	ldp	x19, x20, [x8]
    40202de0:	a9412518 	ldp	x24, x9, [x8, #16]
    40202de4:	f90037e9 	str	x9, [sp, #104]
    40202de8:	a942691d 	ldp	x29, x26, [x8, #32]
    40202dec:	3940c119 	ldrb	w25, [x8, #48]
    40202df0:	52800069 	mov	w9, #0x3                   	// #3
    40202df4:	3900c109 	strb	w9, [x8, #48]
    40202df8:	71000f3f 	cmp	w25, #0x3
    40202dfc:	54001d20 	b.eq	402031a0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.none
    40202e00:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202e04:	f942b108 	ldr	x8, [x8, #1376]
    40202e08:	eb13011f 	cmp	x8, x19
    40202e0c:	54001ca1 	b.ne	402031a0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.any
    40202e10:	aa0003f5 	mov	x21, x0
    40202e14:	d503201f 	nop
    40202e18:	100a4848 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241>
    40202e1c:	8b133909 	add	x9, x8, x19, lsl #14
    40202e20:	eb00013f 	cmp	x9, x0
    40202e24:	54001be8 	b.hi	402031a0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202e28:	b10d06bf 	cmn	x21, #0x341
    40202e2c:	54001ba8 	b.hi	402031a0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202e30:	d372c669 	lsl	x9, x19, #14
    40202e34:	8b090108 	add	x8, x8, x9
    40202e38:	91401108 	add	x8, x8, #0x4, lsl #12
    40202e3c:	910d02a9 	add	x9, x21, #0x340
    40202e40:	eb08013f 	cmp	x9, x8
    40202e44:	54001ae8 	b.hi	402031a0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202e48:	aa0303fc 	mov	x28, x3
    40202e4c:	2a0203f7 	mov	w23, w2
    40202e50:	aa0103f6 	mov	x22, x1
    40202e54:	9101c3e8 	add	x8, sp, #0x70
    40202e58:	aa1303e0 	mov	x0, x19
    40202e5c:	9400014c 	bl	4020338c <jnox_kernel::ordinary_reservations::snapshot>
    40202e60:	f1000a7f 	cmp	x19, #0x2
    40202e64:	54001d62 	b.cs	40203210 <jnox_kernel::ordinary_reservations::Runtime::close+0x458>  // b.hs, b.nlast
    40202e68:	a94733fb 	ldp	x27, x12, [sp, #112]
    40202e6c:	f94043ef 	ldr	x15, [sp, #128]
    40202e70:	d503201f 	nop
    40202e74:	10107c68 	adr	x8, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40202e78:	8b130d08 	add	x8, x8, x19, lsl #3
    40202e7c:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202e80:	9114e129 	add	x9, x9, #0x538
    40202e84:	c8dffd0e 	ldar	x14, [x8]
    40202e88:	a9402129 	ldp	x9, x8, [x9]
    40202e8c:	9bc87e8a 	umulh	x10, x20, x8
    40202e90:	eb0a03ff 	cmp	xzr, x10
    40202e94:	1a9f07eb 	cset	w11, ne  // ne = any
    40202e98:	9b087e8a 	mul	x10, x20, x8
    40202e9c:	ab09014d 	adds	x13, x10, x9
    40202ea0:	1a9f37ea 	cset	w10, cs  // cs = hs, nlast
    40202ea4:	3700180b 	tbnz	w11, #0, 402031a4 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202ea8:	350017ea 	cbnz	w10, 402031a4 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202eac:	9100068a 	add	x10, x20, #0x1
    40202eb0:	9bc87d4b 	umulh	x11, x10, x8
    40202eb4:	eb0b03ff 	cmp	xzr, x11
    40202eb8:	1a9f07eb 	cset	w11, ne  // ne = any
    40202ebc:	9b087d48 	mul	x8, x10, x8
    40202ec0:	ab090109 	adds	x9, x8, x9
    40202ec4:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40202ec8:	370016eb 	tbnz	w11, #0, 402031a4 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202ecc:	350016c8 	cbnz	w8, 402031a4 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202ed0:	b100069f 	cmn	x20, #0x1
    40202ed4:	54001680 	b.eq	402031a4 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.none
    40202ed8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202edc:	f942a508 	ldr	x8, [x8, #1352]
    40202ee0:	eb08012a 	subs	x10, x9, x8
    40202ee4:	54001603 	b.cc	402031a4 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.lo, b.ul, b.last
    40202ee8:	a9056bfc 	stp	x28, x26, [sp, #80]
    40202eec:	f9000fe9 	str	x9, [sp, #24]
    40202ef0:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0xb8e0>
    40202ef4:	f943f508 	ldr	x8, [x8, #2024]
    40202ef8:	91000709 	add	x9, x24, #0x1
    40202efc:	eb09011f 	cmp	x8, x9
    40202f00:	54001501 	b.ne	402031a0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.any
    40202f04:	b9004ff9 	str	w25, [sp, #76]
    40202f08:	d503201f 	nop
    40202f0c:	101046e8 	adr	x8, 402237e8 <jnox_ap_returns>
    40202f10:	52800309 	mov	w9, #0x18                  	// #24
    40202f14:	9b092308 	madd	x8, x24, x9, x8
    40202f18:	f9400509 	ldr	x9, [x8, #8]
    40202f1c:	f940090b 	ldr	x11, [x8, #16]
    40202f20:	f9400d1c 	ldr	x28, [x8, #24]
    40202f24:	eb1c02da 	subs	x26, x22, x28
    40202f28:	540017e3 	b.cc	40203224 <jnox_kernel::ordinary_reservations::Runtime::close+0x46c>  // b.lo, b.ul, b.last
    40202f2c:	a902a7eb 	stp	x11, x9, [sp, #40]
    40202f30:	a903b7ef 	stp	x15, x13, [sp, #56]
    40202f34:	f90033ee 	str	x14, [sp, #96]
    40202f38:	f9000bea 	str	x10, [sp, #16]
    40202f3c:	d503201f 	nop
    40202f40:	10022608 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40202f44:	8b130d18 	add	x24, x8, x19, lsl #3
    40202f48:	f940d308 	ldr	x8, [x24, #416]
    40202f4c:	ab1a0119 	adds	x25, x8, x26
    40202f50:	540012a2 	b.cs	402031a4 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.hs, b.nlast
    40202f54:	f900d319 	str	x25, [x24, #416]
    40202f58:	f94037e8 	ldr	x8, [sp, #104]
    40202f5c:	a9076fe8 	stp	x8, x27, [sp, #112]
    40202f60:	a90833fd 	stp	x29, x12, [sp, #128]
    40202f64:	f90013fb 	str	x27, [sp, #32]
    40202f68:	9101c3e4 	add	x4, sp, #0x70
    40202f6c:	52800100 	mov	w0, #0x8                   	// #8
    40202f70:	aa1603e1 	mov	x1, x22
    40202f74:	aa1403e2 	mov	x2, x20
    40202f78:	aa1303e3 	mov	x3, x19
    40202f7c:	aa0c03fb 	mov	x27, x12
    40202f80:	97fffd81 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202f84:	f9407ea8 	ldr	x8, [x21, #248]
    40202f88:	f9404ea9 	ldr	x9, [x21, #152]
    40202f8c:	a90723f5 	stp	x21, x8, [sp, #112]
    40202f90:	f9408ea8 	ldr	x8, [x21, #280]
    40202f94:	a90823e9 	stp	x9, x8, [sp, #128]
    40202f98:	9101c3e4 	add	x4, sp, #0x70
    40202f9c:	52800120 	mov	w0, #0x9                   	// #9
    40202fa0:	aa1603e1 	mov	x1, x22
    40202fa4:	aa1403e2 	mov	x2, x20
    40202fa8:	aa1303e3 	mov	x3, x19
    40202fac:	97fffd76 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202fb0:	f94033e8 	ldr	x8, [sp, #96]
    40202fb4:	a90723fc 	stp	x28, x8, [sp, #112]
    40202fb8:	a9086bf6 	stp	x22, x26, [sp, #128]
    40202fbc:	f90007fa 	str	x26, [sp, #8]
    40202fc0:	9101c3e4 	add	x4, sp, #0x70
    40202fc4:	52800140 	mov	w0, #0xa                   	// #10
    40202fc8:	aa1603e1 	mov	x1, x22
    40202fcc:	aa1403e2 	mov	x2, x20
    40202fd0:	aa1303e3 	mov	x3, x19
    40202fd4:	97fffd6c 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40202fd8:	110006e8 	add	w8, w23, #0x1
    40202fdc:	92401d09 	and	x9, x8, #0xff
    40202fe0:	f9402be8 	ldr	x8, [sp, #80]
    40202fe4:	a90723e9 	stp	x9, x8, [sp, #112]
    40202fe8:	f9401fe9 	ldr	x9, [sp, #56]
    40202fec:	910d02a8 	add	x8, x21, #0x340
    40202ff0:	a90823e9 	stp	x9, x8, [sp, #128]
    40202ff4:	9101c3e4 	add	x4, sp, #0x70
    40202ff8:	52800160 	mov	w0, #0xb                   	// #11
    40202ffc:	aa1603e1 	mov	x1, x22
    40203000:	aa1403e2 	mov	x2, x20
    40203004:	aa1303e3 	mov	x3, x19
    40203008:	97fffd5f 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    4020300c:	f9402fe8 	ldr	x8, [sp, #88]
    40203010:	a90767e8 	stp	x8, x25, [sp, #112]
    40203014:	aa1903fa 	mov	x26, x25
    40203018:	a942a7e8 	ldp	x8, x9, [sp, #40]
    4020301c:	a90823e9 	stp	x9, x8, [sp, #128]
    40203020:	9101c3e4 	add	x4, sp, #0x70
    40203024:	52800260 	mov	w0, #0x13                  	// #19
    40203028:	aa1603e1 	mov	x1, x22
    4020302c:	aa1403e2 	mov	x2, x20
    40203030:	aa1303e3 	mov	x3, x19
    40203034:	97fffd54 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40203038:	f94013e4 	ldr	x4, [sp, #32]
    4020303c:	b9404fe8 	ldr	w8, [sp, #76]
    40203040:	6b37011f 	cmp	w8, w23, uxtb
    40203044:	f94023e5 	ldr	x5, [sp, #64]
    40203048:	54000b21 	b.ne	402031ac <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    4020304c:	f94037e8 	ldr	x8, [sp, #104]
    40203050:	eb080088 	subs	x8, x4, x8
    40203054:	54000ac9 	b.ls	402031ac <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.plast
    40203058:	f9408ea9 	ldr	x9, [x21, #280]
    4020305c:	d503201f 	nop
    40203060:	1001708a 	adr	x10, 40205e70 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.16192825690684220241>
    40203064:	f873794a 	ldr	x10, [x10, x19, lsl #3]
    40203068:	eb0a013f 	cmp	x9, x10
    4020306c:	54000a01 	b.ne	402031ac <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203070:	f94082a9 	ldr	x9, [x21, #256]
    40203074:	528011ea 	mov	w10, #0x8f                  	// #143
    40203078:	8a0a0129 	and	x9, x9, x10
    4020307c:	f100153f 	cmp	x9, #0x5
    40203080:	54000961 	b.ne	402031ac <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203084:	52800029 	mov	w9, #0x1                   	// #1
    40203088:	5280006a 	mov	w10, #0x3                   	// #3
    4020308c:	aa0803eb 	mov	x11, x8
    40203090:	9b1d254c 	madd	x12, x10, x29, x9
    40203094:	f240017f 	tst	x11, #0x1
    40203098:	9a8c03bd 	csel	x29, x29, x12, eq  // eq = none
    4020309c:	9b0a2529 	madd	x9, x9, x10, x9
    402030a0:	9b0a7d4a 	mul	x10, x10, x10
    402030a4:	d341fd6b 	lsr	x11, x11, #1
    402030a8:	b5ffff4b 	cbnz	x11, 40203090 <jnox_kernel::ordinary_reservations::Runtime::close+0x2d8>
    402030ac:	eb1b03bf 	cmp	x29, x27
    402030b0:	540007e1 	b.ne	402031ac <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    402030b4:	72001eff 	tst	w23, #0xff
    402030b8:	54000060 	b.eq	402030c4 <jnox_kernel::ordinary_reservations::Runtime::close+0x30c>  // b.none
    402030bc:	f104011f 	cmp	x8, #0x100
    402030c0:	54000761 	b.ne	402031ac <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    402030c4:	f94033ea 	ldr	x10, [sp, #96]
    402030c8:	eb16015f 	cmp	x10, x22
    402030cc:	540007c8 	b.hi	402031c4 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.pmore
    402030d0:	eb05039f 	cmp	x28, x5
    402030d4:	54000783 	b.cc	402031c4 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.lo, b.ul, b.last
    402030d8:	eb1c015f 	cmp	x10, x28
    402030dc:	54000743 	b.cc	402031c4 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.lo, b.ul, b.last
    402030e0:	cb050149 	sub	x9, x10, x5
    402030e4:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402030e8:	f942a508 	ldr	x8, [x8, #1352]
    402030ec:	eb08013f 	cmp	x9, x8
    402030f0:	540006a8 	b.hi	402031c4 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.pmore
    402030f4:	a9412fe5 	ldp	x5, x11, [sp, #16]
    402030f8:	eb0b02df 	cmp	x22, x11
    402030fc:	54000708 	b.hi	402031dc <jnox_kernel::ordinary_reservations::Runtime::close+0x424>  // b.pmore
    40203100:	12001eea 	and	w10, w23, #0xff
    40203104:	eb0502c9 	subs	x9, x22, x5
    40203108:	9a8933e9 	csel	x9, xzr, x9, cc  // cc = lo, ul, last
    4020310c:	3500006a 	cbnz	w10, 40203118 <jnox_kernel::ordinary_reservations::Runtime::close+0x360>
    40203110:	eb08013f 	cmp	x9, x8
    40203114:	54000648 	b.hi	402031dc <jnox_kernel::ordinary_reservations::Runtime::close+0x424>  // b.pmore
    40203118:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020311c:	f942a108 	ldr	x8, [x8, #1344]
    40203120:	f94007ea 	ldr	x10, [sp, #8]
    40203124:	eb08015f 	cmp	x10, x8
    40203128:	aa1a03eb 	mov	x11, x26
    4020312c:	54000648 	b.hi	402031f4 <jnox_kernel::ordinary_reservations::Runtime::close+0x43c>  // b.pmore
    40203130:	f940db09 	ldr	x9, [x24, #432]
    40203134:	9b087d28 	mul	x8, x9, x8
    40203138:	eb08017f 	cmp	x11, x8
    4020313c:	540005c8 	b.hi	402031f4 <jnox_kernel::ordinary_reservations::Runtime::close+0x43c>  // b.pmore
    40203140:	72001eff 	tst	w23, #0xff
    40203144:	54000060 	b.eq	40203150 <jnox_kernel::ordinary_reservations::Runtime::close+0x398>  // b.none
    40203148:	eb0502df 	cmp	x22, x5
    4020314c:	540006e2 	b.cs	40203228 <jnox_kernel::ordinary_reservations::Runtime::close+0x470>  // b.hs, b.nlast
    40203150:	f900e304 	str	x4, [x24, #448]
    40203154:	f900eb1b 	str	x27, [x24, #464]
    40203158:	94000040 	bl	40203258 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    4020315c:	aa1303e1 	mov	x1, x19
    40203160:	2a1703e2 	mov	w2, w23
    40203164:	94000240 	bl	40203a64 <jnox_kernel::reservation_jobs::Jobs::trap>
    40203168:	72001c04 	ands	w4, w0, #0xff
    4020316c:	540006a1 	b.ne	40203240 <jnox_kernel::ordinary_reservations::Runtime::close+0x488>  // b.any
    40203170:	12001ee8 	and	w8, w23, #0xff
    40203174:	7100091f 	cmp	w8, #0x2
    40203178:	54000040 	b.eq	40203180 <jnox_kernel::ordinary_reservations::Runtime::close+0x3c8>  // b.none
    4020317c:	f900b715 	str	x21, [x24, #360]
    40203180:	a94e4ff4 	ldp	x20, x19, [sp, #224]
    40203184:	a94d57f6 	ldp	x22, x21, [sp, #208]
    40203188:	a94c5ff8 	ldp	x24, x23, [sp, #192]
    4020318c:	a94b67fa 	ldp	x26, x25, [sp, #176]
    40203190:	a94a6ffc 	ldp	x28, x27, [sp, #160]
    40203194:	a9497bfd 	ldp	x29, x30, [sp, #144]
    40203198:	9103c3ff 	add	sp, sp, #0xf0
    4020319c:	d65f03c0 	ret
    402031a0:	97fff842 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402031a4:	52800060 	mov	w0, #0x3                   	// #3
    402031a8:	94000071 	bl	4020336c <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    402031ac:	52800060 	mov	w0, #0x3                   	// #3
    402031b0:	52800061 	mov	w1, #0x3                   	// #3
    402031b4:	aa1403e2 	mov	x2, x20
    402031b8:	aa1303e3 	mov	x3, x19
    402031bc:	f94037e5 	ldr	x5, [sp, #104]
    402031c0:	97fffd48 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>
    402031c4:	52800040 	mov	w0, #0x2                   	// #2
    402031c8:	52800041 	mov	w1, #0x2                   	// #2
    402031cc:	aa1403e2 	mov	x2, x20
    402031d0:	aa1303e3 	mov	x3, x19
    402031d4:	aa0a03e4 	mov	x4, x10
    402031d8:	97fffd42 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>
    402031dc:	52800040 	mov	w0, #0x2                   	// #2
    402031e0:	52800021 	mov	w1, #0x1                   	// #1
    402031e4:	aa1403e2 	mov	x2, x20
    402031e8:	aa1303e3 	mov	x3, x19
    402031ec:	aa1603e4 	mov	x4, x22
    402031f0:	14000006 	b	40203208 <jnox_kernel::ordinary_reservations::Runtime::close+0x450>
    402031f4:	52800040 	mov	w0, #0x2                   	// #2
    402031f8:	528000e1 	mov	w1, #0x7                   	// #7
    402031fc:	aa1403e2 	mov	x2, x20
    40203200:	aa1303e3 	mov	x3, x19
    40203204:	aa0a03e4 	mov	x4, x10
    40203208:	aa0b03e5 	mov	x5, x11
    4020320c:	97fffd35 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>
    40203210:	d503201f 	nop
    40203214:	100167e2 	adr	x2, 40205f10 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.16192825690684220241+0x78>
    40203218:	aa1303e0 	mov	x0, x19
    4020321c:	52800041 	mov	w1, #0x2                   	// #2
    40203220:	940006bb 	bl	40204d0c <core::panicking::panic_bounds_check>
    40203224:	97fffb9d 	bl	40202098 <jnox_kernel::ordinary_reservations::run::{{closure}}>
    40203228:	52800040 	mov	w0, #0x2                   	// #2
    4020322c:	52800121 	mov	w1, #0x9                   	// #9
    40203230:	aa1403e2 	mov	x2, x20
    40203234:	aa1303e3 	mov	x3, x19
    40203238:	aa1603e4 	mov	x4, x22
    4020323c:	97fffd29 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>
    40203240:	52800060 	mov	w0, #0x3                   	// #3
    40203244:	52800041 	mov	w1, #0x2                   	// #2
    40203248:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4020324c:	52800043 	mov	w3, #0x2                   	// #2
    40203250:	aa1f03e5 	mov	x5, xzr
    40203254:	97fffd23 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>

0000000040203258 <jnox_kernel::ordinary_reservations::Runtime::ledger>:
    40203258:	f81f0ffe 	str	x30, [sp, #-16]!
    4020325c:	d503201f 	nop
    40203260:	10102c08 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    40203264:	c8dffd08 	ldar	x8, [x8]
    40203268:	b4000128 	cbz	x8, 4020328c <jnox_kernel::ordinary_reservations::Runtime::ledger+0x34>
    4020326c:	f1000d1f 	cmp	x8, #0x3
    40203270:	540000c1 	b.ne	40203288 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x30>  // b.any
    40203274:	90000020 	adrp	x0, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203278:	91120000 	add	x0, x0, #0x480
    4020327c:	f9400008 	ldr	x8, [x0]
    40203280:	f100091f 	cmp	x8, #0x2
    40203284:	54000081 	b.ne	40203294 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x3c>  // b.any
    40203288:	97fff808 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    4020328c:	d503201f 	nop
    40203290:	10020b80 	adr	x0, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40203294:	f84107fe 	ldr	x30, [sp], #16
    40203298:	d65f03c0 	ret

000000004020329c <jnox_kernel::ordinary_reservations::Runtime::select>:
    4020329c:	d10143ff 	sub	sp, sp, #0x50
    402032a0:	f90013fe 	str	x30, [sp, #32]
    402032a4:	a90357f6 	stp	x22, x21, [sp, #48]
    402032a8:	a9044ff4 	stp	x20, x19, [sp, #64]
    402032ac:	d503201f 	nop
    402032b0:	10020a88 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402032b4:	8b010d09 	add	x9, x8, x1, lsl #3
    402032b8:	f940b534 	ldr	x20, [x9, #360]
    402032bc:	d503201f 	nop
    402032c0:	100a2308 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241>
    402032c4:	f900b53f 	str	xzr, [x9, #360]
    402032c8:	8b013909 	add	x9, x8, x1, lsl #14
    402032cc:	eb14013f 	cmp	x9, x20
    402032d0:	540004c8 	b.hi	40203368 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    402032d4:	aa0103f3 	mov	x19, x1
    402032d8:	d372c429 	lsl	x9, x1, #14
    402032dc:	8b090108 	add	x8, x8, x9
    402032e0:	91401108 	add	x8, x8, #0x4, lsl #12
    402032e4:	910d0289 	add	x9, x20, #0x340
    402032e8:	b10d069f 	cmn	x20, #0x341
    402032ec:	fa489122 	ccmp	x9, x8, #0x2, ls  // ls = plast
    402032f0:	540003c8 	b.hi	40203368 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    402032f4:	90000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0xb8e0>
    402032f8:	f943f516 	ldr	x22, [x8, #2024]
    402032fc:	f100fedf 	cmp	x22, #0x3f
    40203300:	54000348 	b.hi	40203368 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    40203304:	aa0003f5 	mov	x21, x0
    40203308:	d5033fdf 	isb
    4020330c:	d53be021 	mrs	x1, cntpct_el0
    40203310:	f9407e88 	ldr	x8, [x20, #248]
    40203314:	f9404e89 	ldr	x9, [x20, #152]
    40203318:	a90023f4 	stp	x20, x8, [sp]
    4020331c:	f9408e88 	ldr	x8, [x20, #280]
    40203320:	a90123e9 	stp	x9, x8, [sp, #16]
    40203324:	910003e4 	mov	x4, sp
    40203328:	52800240 	mov	w0, #0x12                  	// #18
    4020332c:	aa1503e2 	mov	x2, x21
    40203330:	aa1303e3 	mov	x3, x19
    40203334:	97fffc94 	bl	40202584 <jnox_kernel::ordinary_reservations::event>
    40203338:	d503201f 	nop
    4020333c:	1001e628 	adr	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203340:	8b161108 	add	x8, x8, x22, lsl #4
    40203344:	a9004d15 	stp	x21, x19, [x8]
    40203348:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020334c:	f902b113 	str	x19, [x8, #1376]
    40203350:	aa1403e0 	mov	x0, x20
    40203354:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40203358:	a94357f6 	ldp	x22, x21, [sp, #48]
    4020335c:	f94013fe 	ldr	x30, [sp, #32]
    40203360:	910143ff 	add	sp, sp, #0x50
    40203364:	d65f03c0 	ret
    40203368:	97fff7d0 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

000000004020336c <jnox_kernel::ordinary_reservations::checked::{{closure}}>:
    4020336c:	f81f0ffe 	str	x30, [sp, #-16]!
    40203370:	92401c04 	and	x4, x0, #0xff
    40203374:	52800060 	mov	w0, #0x3                   	// #3
    40203378:	52800041 	mov	w1, #0x2                   	// #2
    4020337c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40203380:	52800043 	mov	w3, #0x2                   	// #2
    40203384:	aa1f03e5 	mov	x5, xzr
    40203388:	97fffcd6 	bl	402026e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16192825690684220241>

000000004020338c <jnox_kernel::ordinary_reservations::snapshot>:
    4020338c:	f81f0ffe 	str	x30, [sp, #-16]!
    40203390:	f100041f 	cmp	x0, #0x1
    40203394:	54000488 	b.hi	40203424 <jnox_kernel::ordinary_reservations::snapshot+0x98>  // b.pmore
    40203398:	d503201f 	nop
    4020339c:	101053a9 	adr	x9, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    402033a0:	8b000d29 	add	x9, x9, x0, lsl #3
    402033a4:	c8dffd29 	ldar	x9, [x9]
    402033a8:	b40002c9 	cbz	x9, 40203400 <jnox_kernel::ordinary_reservations::snapshot+0x74>
    402033ac:	d503201f 	nop
    402033b0:	100a1b8a 	adr	x10, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241>
    402033b4:	8b00394b 	add	x11, x10, x0, lsl #14
    402033b8:	eb09017f 	cmp	x11, x9
    402033bc:	54000328 	b.hi	40203420 <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    402033c0:	b100a53f 	cmn	x9, #0x29
    402033c4:	540002e8 	b.hi	40203420 <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    402033c8:	d372c40b 	lsl	x11, x0, #14
    402033cc:	8b0b014a 	add	x10, x10, x11
    402033d0:	9140114a 	add	x10, x10, #0x4, lsl #12
    402033d4:	9100a12b 	add	x11, x9, #0x28
    402033d8:	eb0a017f 	cmp	x11, x10
    402033dc:	54000228 	b.hi	40203420 <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    402033e0:	9100812a 	add	x10, x9, #0x20
    402033e4:	c8dffd40 	ldar	x0, [x10]
    402033e8:	f100041f 	cmp	x0, #0x1
    402033ec:	54000228 	b.hi	40203430 <jnox_kernel::ordinary_reservations::snapshot+0xa4>  // b.pmore
    402033f0:	8b00112b 	add	x11, x9, x0, lsl #4
    402033f4:	f940016a 	ldr	x10, [x11]
    402033f8:	f940056b 	ldr	x11, [x11, #8]
    402033fc:	14000005 	b	40203410 <jnox_kernel::ordinary_reservations::snapshot+0x84>
    40203400:	aa1f03ea 	mov	x10, xzr
    40203404:	d503201f 	nop
    40203408:	1001534b 	adr	x11, 40205e70 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.16192825690684220241>
    4020340c:	f860796b 	ldr	x11, [x11, x0, lsl #3]
    40203410:	a9002d0a 	stp	x10, x11, [x8]
    40203414:	f9000909 	str	x9, [x8, #16]
    40203418:	f84107fe 	ldr	x30, [sp], #16
    4020341c:	d65f03c0 	ret
    40203420:	97fff7a2 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40203424:	d503201f 	nop
    40203428:	100158c2 	adr	x2, 40205f40 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.16192825690684220241+0xa8>
    4020342c:	14000003 	b	40203438 <jnox_kernel::ordinary_reservations::snapshot+0xac>
    40203430:	d503201f 	nop
    40203434:	10015922 	adr	x2, 40205f58 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.16192825690684220241+0xc0>
    40203438:	52800041 	mov	w1, #0x2                   	// #2
    4020343c:	94000634 	bl	40204d0c <core::panicking::panic_bounds_check>

0000000040203440 <reservation_rust_work>:
    40203440:	d10103ff 	sub	sp, sp, #0x40
    40203444:	f9001bfe 	str	x30, [sp, #48]
    40203448:	f100041f 	cmp	x0, #0x1
    4020344c:	54000768 	b.hi	40203538 <reservation_rust_work+0xf8>  // b.pmore
    40203450:	aa1f03e9 	mov	x9, xzr
    40203454:	d503201f 	nop
    40203458:	100150c8 	adr	x8, 40205e70 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.16192825690684220241>
    4020345c:	910023ea 	add	x10, sp, #0x8
    40203460:	9280000b 	mov	x11, #0xffffffffffffffff    	// #-1
    40203464:	f860790d 	ldr	x13, [x8, x0, lsl #3]
    40203468:	9100e3ec 	add	x12, sp, #0x38
    4020346c:	d503201f 	nop
    40203470:	10104d08 	adr	x8, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    40203474:	5280002e 	mov	w14, #0x1                   	// #1
    40203478:	d503201f 	nop
    4020347c:	1002136f 	adr	x15, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40203480:	8b000d08 	add	x8, x8, x0, lsl #3
    40203484:	8b000def 	add	x15, x15, x0, lsl #3
    40203488:	a900b7ff 	stp	xzr, x13, [sp, #8]
    4020348c:	f9000fff 	str	xzr, [sp, #24]
    40203490:	a9027fed 	stp	x13, xzr, [sp, #32]
    40203494:	c89ffd0a 	stlr	x10, [x8]
    40203498:	d503201f 	nop
    4020349c:	100212e8 	adr	x8, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    402034a0:	8b000d10 	add	x16, x8, x0, lsl #3
    402034a4:	d503201f 	nop
    402034a8:	10104a51 	adr	x17, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    402034ac:	d503201f 	nop
    402034b0:	10104a88 	adr	x8, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    402034b4:	8b000d12 	add	x18, x8, x0, lsl #3
    402034b8:	c8dffde8 	ldar	x8, [x15]
    402034bc:	eb0b011f 	cmp	x8, x11
    402034c0:	540000a0 	b.eq	402034d4 <reservation_rust_work+0x94>  // b.none
    402034c4:	d5033fdf 	isb
    402034c8:	d53be02b 	mrs	x11, cntpct_el0
    402034cc:	c89ffe4b 	stlr	x11, [x18]
    402034d0:	aa0803eb 	mov	x11, x8
    402034d4:	52800208 	mov	w8, #0x10                  	// #16
    402034d8:	8b0d05ad 	add	x13, x13, x13, lsl #1
    402034dc:	910005ad 	add	x13, x13, #0x1
    402034e0:	f9001fed 	str	x13, [sp, #56]
    402034e4:	f9401fed 	ldr	x13, [sp, #56]
    402034e8:	71000508 	subs	w8, w8, #0x1
    402034ec:	54ffff61 	b.ne	402034d8 <reservation_rust_work+0x98>  // b.any
    402034f0:	f94017e8 	ldr	x8, [sp, #40]
    402034f4:	cb0801c8 	sub	x8, x14, x8
    402034f8:	f100051f 	cmp	x8, #0x1
    402034fc:	54000248 	b.hi	40203544 <reservation_rust_work+0x104>  // b.pmore
    40203500:	91004129 	add	x9, x9, #0x10
    40203504:	8b081141 	add	x1, x10, x8, lsl #4
    40203508:	f9000029 	str	x9, [x1]
    4020350c:	f900042d 	str	x13, [x1, #8]
    40203510:	91008141 	add	x1, x10, #0x20
    40203514:	c89ffc28 	stlr	x8, [x1]
    40203518:	c8dffe08 	ldar	x8, [x16]
    4020351c:	eb08013f 	cmp	x9, x8
    40203520:	54fffcc1 	b.ne	402034b8 <reservation_rust_work+0x78>  // b.any
    40203524:	f8607a28 	ldr	x8, [x17, x0, lsl #3]
    40203528:	f100091f 	cmp	x8, #0x2
    4020352c:	54000161 	b.ne	40203558 <reservation_rust_work+0x118>  // b.any
    40203530:	d4000021 	svc	#0x1
    40203534:	17ffffe1 	b	402034b8 <reservation_rust_work+0x78>
    40203538:	d503201f 	nop
    4020353c:	100151a2 	adr	x2, 40205f70 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.16192825690684220241+0xd8>
    40203540:	14000004 	b	40203550 <reservation_rust_work+0x110>
    40203544:	d503201f 	nop
    40203548:	10015202 	adr	x2, 40205f88 <anon.d6c364c9f4c098981b8152fc16ba3537.3.llvm.16192825690684220241+0xf0>
    4020354c:	aa0803e0 	mov	x0, x8
    40203550:	52800041 	mov	w1, #0x2                   	// #2
    40203554:	940005ee 	bl	40204d0c <core::panicking::panic_bounds_check>
    40203558:	d4000041 	svc	#0x2
    4020355c:	d4200020 	brk	#0x1

0000000040203560 <reservation_worker_a>:
    40203560:	f81f0ffe 	str	x30, [sp, #-16]!
    40203564:	aa1f03e0 	mov	x0, xzr
    40203568:	97ffffb6 	bl	40203440 <reservation_rust_work>

000000004020356c <reservation_worker_b>:
    4020356c:	f81f0ffe 	str	x30, [sp, #-16]!
    40203570:	52800020 	mov	w0, #0x1                   	// #1
    40203574:	97ffffb3 	bl	40203440 <reservation_rust_work>

0000000040203578 <jnox_kernel::reservation_jobs::Jobs::prepare_destination>:
    40203578:	f9403409 	ldr	x9, [x0, #104]
    4020357c:	b40000c9 	cbz	x9, 40203594 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x1c>
    40203580:	52800089 	mov	w9, #0x4                   	// #4
    40203584:	39002109 	strb	w9, [x8, #8]
    40203588:	52800049 	mov	w9, #0x2                   	// #2
    4020358c:	f9000109 	str	x9, [x8]
    40203590:	d65f03c0 	ret
    40203594:	aa1f03ea 	mov	x10, xzr
    40203598:	9101e009 	add	x9, x0, #0x78
    4020359c:	5280002b 	mov	w11, #0x1                   	// #1
    402035a0:	386a692c 	ldrb	w12, [x9, x10]
    402035a4:	3600008b 	tbz	w11, #0, 402035b4 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x3c>
    402035a8:	2a1f03eb 	mov	w11, wzr
    402035ac:	5280002a 	mov	w10, #0x1                   	// #1
    402035b0:	34ffff8c 	cbz	w12, 402035a0 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x28>
    402035b4:	35fffe6c 	cbnz	w12, 40203580 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>
    402035b8:	39418009 	ldrb	w9, [x0, #96]
    402035bc:	71000d3f 	cmp	w9, #0x3
    402035c0:	54fffe01 	b.ne	40203580 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>  // b.any
    402035c4:	f9403809 	ldr	x9, [x0, #112]
    402035c8:	b5fffdc9 	cbnz	x9, 40203580 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>
    402035cc:	aa1f03e1 	mov	x1, xzr
    402035d0:	14000141 	b	40203ad4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>

00000000402035d4 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision>:
    402035d4:	f9403408 	ldr	x8, [x0, #104]
    402035d8:	f100051f 	cmp	x8, #0x1
    402035dc:	54000321 	b.ne	40203640 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x6c>  // b.any
    402035e0:	d10143ff 	sub	sp, sp, #0x50
    402035e4:	a9025ffe 	stp	x30, x23, [sp, #32]
    402035e8:	a90357f6 	stp	x22, x21, [sp, #48]
    402035ec:	a9044ff4 	stp	x20, x19, [sp, #64]
    402035f0:	aa0003f3 	mov	x19, x0
    402035f4:	b9400028 	ldr	w8, [x1]
    402035f8:	39418829 	ldrb	w9, [x1, #98]
    402035fc:	7100011f 	cmp	w8, #0x0
    40203600:	52800068 	mov	w8, #0x3                   	// #3
    40203604:	1a881128 	csel	w8, w9, w8, ne  // ne = any
    40203608:	39418009 	ldrb	w9, [x0, #96]
    4020360c:	71000d3f 	cmp	w9, #0x3
    40203610:	540001c0 	b.eq	40203648 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x74>  // b.none
    40203614:	71000d1f 	cmp	w8, #0x3
    40203618:	54000180 	b.eq	40203648 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x74>  // b.none
    4020361c:	2a1f03e0 	mov	w0, wzr
    40203620:	f940042a 	ldr	x10, [x1, #8]
    40203624:	f9402e6b 	ldr	x11, [x19, #88]
    40203628:	eb0b015f 	cmp	x10, x11
    4020362c:	1a9f17ea 	cset	w10, eq  // eq = none
    40203630:	6b08013f 	cmp	w9, w8
    40203634:	540007a1 	b.ne	40203728 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    40203638:	3700012a 	tbnz	w10, #0, 4020365c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x88>
    4020363c:	1400003b 	b	40203728 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>
    40203640:	2a1f03e0 	mov	w0, wzr
    40203644:	d65f03c0 	ret
    40203648:	2a1f03e0 	mov	w0, wzr
    4020364c:	71000d3f 	cmp	w9, #0x3
    40203650:	540006c1 	b.ne	40203728 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    40203654:	71000d1f 	cmp	w8, #0x3
    40203658:	54000681 	b.ne	40203728 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    4020365c:	aa1f03eb 	mov	x11, xzr
    40203660:	9101e268 	add	x8, x19, #0x78
    40203664:	91018029 	add	x9, x1, #0x60
    40203668:	5280002a 	mov	w10, #0x1                   	// #1
    4020366c:	386b690c 	ldrb	w12, [x8, x11]
    40203670:	386b692d 	ldrb	w13, [x9, x11]
    40203674:	360000aa 	tbz	w10, #0, 40203688 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xb4>
    40203678:	2a1f03ea 	mov	w10, wzr
    4020367c:	6b0d019f 	cmp	w12, w13
    40203680:	5280002b 	mov	w11, #0x1                   	// #1
    40203684:	54ffff40 	b.eq	4020366c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x98>  // b.none
    40203688:	6b0d019f 	cmp	w12, w13
    4020368c:	540004c1 	b.ne	40203724 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x150>  // b.any
    40203690:	f9403a68 	ldr	x8, [x19, #112]
    40203694:	f9402c29 	ldr	x9, [x1, #88]
    40203698:	eb09011f 	cmp	x8, x9
    4020369c:	54000441 	b.ne	40203724 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x150>  // b.any
    402036a0:	aa1f03e8 	mov	x8, xzr
    402036a4:	91002274 	add	x20, x19, #0x8
    402036a8:	b8418675 	ldr	w21, [x19], #24
    402036ac:	91010037 	add	x23, x1, #0x40
    402036b0:	aa0803f6 	mov	x22, x8
    402036b4:	f100091f 	cmp	x8, #0x2
    402036b8:	54000300 	b.eq	40203718 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.none
    402036bc:	360000b5 	tbz	w21, #0, 402036d0 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xfc>
    402036c0:	b9400268 	ldr	w8, [x19]
    402036c4:	f85f0269 	ldur	x9, [x19, #-16]
    402036c8:	a90127e8 	stp	x8, x9, [sp, #16]
    402036cc:	14000009 	b	402036f0 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x11c>
    402036d0:	910023e8 	add	x8, sp, #0x8
    402036d4:	aa1403e0 	mov	x0, x20
    402036d8:	aa1f03e1 	mov	x1, xzr
    402036dc:	940002ec 	bl	4020428c <jnox_kernel::service_policy::PeriodicReservation::allocation_at>
    402036e0:	f94007e8 	ldr	x8, [sp, #8]
    402036e4:	f100051f 	cmp	x8, #0x1
    402036e8:	54000181 	b.ne	40203718 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.any
    402036ec:	f9400be8 	ldr	x8, [sp, #16]
    402036f0:	f85f82e9 	ldur	x9, [x23, #-8]
    402036f4:	eb09011f 	cmp	x8, x9
    402036f8:	54000101 	b.ne	40203718 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.any
    402036fc:	f84106e9 	ldr	x9, [x23], #16
    40203700:	91006273 	add	x19, x19, #0x18
    40203704:	f9400fea 	ldr	x10, [sp, #24]
    40203708:	9100a294 	add	x20, x20, #0x28
    4020370c:	910006c8 	add	x8, x22, #0x1
    40203710:	eb09015f 	cmp	x10, x9
    40203714:	54fffce0 	b.eq	402036b0 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xdc>  // b.none
    40203718:	f10006df 	cmp	x22, #0x1
    4020371c:	1a9f97e0 	cset	w0, hi  // hi = pmore
    40203720:	14000002 	b	40203728 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>
    40203724:	2a1f03e0 	mov	w0, wzr
    40203728:	a9444ff4 	ldp	x20, x19, [sp, #64]
    4020372c:	a94357f6 	ldp	x22, x21, [sp, #48]
    40203730:	a9425ffe 	ldp	x30, x23, [sp, #32]
    40203734:	910143ff 	add	sp, sp, #0x50
    40203738:	d65f03c0 	ret

000000004020373c <jnox_kernel::reservation_jobs::Jobs::new>:
    4020373c:	d10203ff 	sub	sp, sp, #0x80
    40203740:	a90657fe 	stp	x30, x21, [sp, #96]
    40203744:	a9074ff4 	stp	x20, x19, [sp, #112]
    40203748:	2a0103f4 	mov	w20, w1
    4020374c:	2a0003f5 	mov	w21, w0
    40203750:	aa0803f3 	mov	x19, x8
    40203754:	72001c3f 	tst	w1, #0xff
    40203758:	540002c0 	b.eq	402037b0 <jnox_kernel::reservation_jobs::Jobs::new+0x74>  // b.none
    4020375c:	52800028 	mov	w8, #0x1                   	// #1
    40203760:	52800049 	mov	w9, #0x2                   	// #2
    40203764:	290027e8 	stp	w8, w9, [sp]
    40203768:	12001e8a 	and	w10, w20, #0xff
    4020376c:	7100095f 	cmp	w10, #0x2
    40203770:	290127e8 	stp	w8, w9, [sp, #8]
    40203774:	540002a1 	b.ne	402037c8 <jnox_kernel::reservation_jobs::Jobs::new+0x8c>  // b.any
    40203778:	29402be9 	ldp	w9, w10, [sp]
    4020377c:	29022be9 	stp	w9, w10, [sp, #16]
    40203780:	29412be9 	ldp	w9, w10, [sp, #8]
    40203784:	29032be9 	stp	w9, w10, [sp, #24]
    40203788:	52800109 	mov	w9, #0x8                   	// #8
    4020378c:	290427e8 	stp	w8, w9, [sp, #32]
    40203790:	910043e0 	add	x0, sp, #0x10
    40203794:	52800061 	mov	w1, #0x3                   	// #3
    40203798:	940003cc 	bl	402046c8 <jnox_kernel::temporal_policy::admit_reservations>
    4020379c:	12001c08 	and	w8, w0, #0xff
    402037a0:	71000d1f 	cmp	w8, #0x3
    402037a4:	54000401 	b.ne	40203824 <jnox_kernel::reservation_jobs::Jobs::new+0xe8>  // b.any
    402037a8:	52800088 	mov	w8, #0x4                   	// #4
    402037ac:	1400003b 	b	40203898 <jnox_kernel::reservation_jobs::Jobs::new+0x15c>
    402037b0:	52800048 	mov	w8, #0x2                   	// #2
    402037b4:	52800109 	mov	w9, #0x8                   	// #8
    402037b8:	5280002a 	mov	w10, #0x1                   	// #1
    402037bc:	290027e8 	stp	w8, w9, [sp]
    402037c0:	52800088 	mov	w8, #0x4                   	// #4
    402037c4:	290123ea 	stp	w10, w8, [sp, #8]
    402037c8:	910003e0 	mov	x0, sp
    402037cc:	52800041 	mov	w1, #0x2                   	// #2
    402037d0:	940003be 	bl	402046c8 <jnox_kernel::temporal_policy::admit_reservations>
    402037d4:	12001c08 	and	w8, w0, #0xff
    402037d8:	71000d1f 	cmp	w8, #0x3
    402037dc:	54000241 	b.ne	40203824 <jnox_kernel::reservation_jobs::Jobs::new+0xe8>  // b.any
    402037e0:	34000275 	cbz	w21, 4020382c <jnox_kernel::reservation_jobs::Jobs::new+0xf0>
    402037e4:	294027e8 	ldp	w8, w9, [sp]
    402037e8:	290a27e8 	stp	w8, w9, [sp, #80]
    402037ec:	294127e8 	ldp	w8, w9, [sp, #8]
    402037f0:	290b27e8 	stp	w8, w9, [sp, #88]
    402037f4:	910043e8 	add	x8, sp, #0x10
    402037f8:	910143e1 	add	x1, sp, #0x50
    402037fc:	aa1f03e0 	mov	x0, xzr
    40203800:	940002e4 	bl	40204390 <jnox_kernel::temporal_policy::HardCbs<_>::new>
    40203804:	b94013e8 	ldr	w8, [sp, #16]
    40203808:	36000468 	tbz	w8, #0, 40203894 <jnox_kernel::reservation_jobs::Jobs::new+0x158>
    4020380c:	a941a7ee 	ldp	x14, x9, [sp, #24]
    40203810:	a942a3eb 	ldp	x11, x8, [sp, #40]
    40203814:	a943abec 	ldp	x12, x10, [sp, #56]
    40203818:	5280002f 	mov	w15, #0x1                   	// #1
    4020381c:	f94027ed 	ldr	x13, [sp, #72]
    40203820:	14000011 	b	40203864 <jnox_kernel::reservation_jobs::Jobs::new+0x128>
    40203824:	11000508 	add	w8, w8, #0x1
    40203828:	1400001c 	b	40203898 <jnox_kernel::reservation_jobs::Jobs::new+0x15c>
    4020382c:	294027e8 	ldp	w8, w9, [sp]
    40203830:	d100050a 	sub	x10, x8, #0x1
    40203834:	eb09015f 	cmp	x10, x9
    40203838:	540002e2 	b.cs	40203894 <jnox_kernel::reservation_jobs::Jobs::new+0x158>  // b.hs, b.nlast
    4020383c:	294137ea 	ldp	w10, w13, [sp, #8]
    40203840:	d100054b 	sub	x11, x10, #0x1
    40203844:	eb0d017f 	cmp	x11, x13
    40203848:	54000262 	b.cs	40203894 <jnox_kernel::reservation_jobs::Jobs::new+0x158>  // b.hs, b.nlast
    4020384c:	aa1f03ec 	mov	x12, xzr
    40203850:	aa1f03eb 	mov	x11, xzr
    40203854:	aa1f03ef 	mov	x15, xzr
    40203858:	72001e9f 	tst	w20, #0xff
    4020385c:	1a9f17f0 	cset	w16, eq  // eq = none
    40203860:	aa0803ee 	mov	x14, x8
    40203864:	a9003a6f 	stp	x15, x14, [x19]
    40203868:	a9012e69 	stp	x9, x11, [x19, #16]
    4020386c:	a9023268 	stp	x8, x12, [x19, #32]
    40203870:	a903366a 	stp	x10, x13, [x19, #48]
    40203874:	a9042a70 	stp	x16, x10, [x19, #64]
    40203878:	f9002a70 	str	x16, [x19, #80]
    4020387c:	52800068 	mov	w8, #0x3                   	// #3
    40203880:	39018268 	strb	w8, [x19, #96]
    40203884:	a906fe7f 	stp	xzr, xzr, [x19, #104]
    40203888:	7900f27f 	strh	wzr, [x19, #120]
    4020388c:	3901ea74 	strb	w20, [x19, #122]
    40203890:	14000005 	b	402038a4 <jnox_kernel::reservation_jobs::Jobs::new+0x168>
    40203894:	52800028 	mov	w8, #0x1                   	// #1
    40203898:	39002268 	strb	w8, [x19, #8]
    4020389c:	52800048 	mov	w8, #0x2                   	// #2
    402038a0:	f9000268 	str	x8, [x19]
    402038a4:	a9474ff4 	ldp	x20, x19, [sp, #112]
    402038a8:	a94657fe 	ldp	x30, x21, [sp, #96]
    402038ac:	910203ff 	add	sp, sp, #0x80
    402038b0:	d65f03c0 	ret

00000000402038b4 <jnox_kernel::reservation_jobs::Jobs::open>:
    402038b4:	d10783ff 	sub	sp, sp, #0x1e0
    402038b8:	a9197bfd 	stp	x29, x30, [sp, #400]
    402038bc:	a91a67fa 	stp	x26, x25, [sp, #416]
    402038c0:	a91b5ff8 	stp	x24, x23, [sp, #432]
    402038c4:	a91c57f6 	stp	x22, x21, [sp, #448]
    402038c8:	a91d4ff4 	stp	x20, x19, [sp, #464]
    402038cc:	aa0803f3 	mov	x19, x8
    402038d0:	f9403408 	ldr	x8, [x0, #104]
    402038d4:	eb08003f 	cmp	x1, x8
    402038d8:	540002e1 	b.ne	40203934 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.any
    402038dc:	aa0103f5 	mov	x21, x1
    402038e0:	aa0003f4 	mov	x20, x0
    402038e4:	3941e816 	ldrb	w22, [x0, #122]
    402038e8:	710002df 	cmp	w22, #0x0
    402038ec:	52800148 	mov	w8, #0xa                   	// #10
    402038f0:	52800449 	mov	w9, #0x22                  	// #34
    402038f4:	9a880128 	csel	x8, x9, x8, eq  // eq = none
    402038f8:	eb08003f 	cmp	x1, x8
    402038fc:	540001c2 	b.cs	40203934 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.hs, b.nlast
    40203900:	39418288 	ldrb	w8, [x20, #96]
    40203904:	71000d1f 	cmp	w8, #0x3
    40203908:	54000161 	b.ne	40203934 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.any
    4020390c:	aa1403e1 	mov	x1, x20
    40203910:	f8408428 	ldr	x8, [x1], #8
    40203914:	f100051f 	cmp	x8, #0x1
    40203918:	54000241 	b.ne	40203960 <jnox_kernel::reservation_jobs::Jobs::open+0xac>  // b.any
    4020391c:	f9401e97 	ldr	x23, [x20, #56]
    40203920:	910583e0 	add	x0, sp, #0x160
    40203924:	52800602 	mov	w2, #0x30                  	// #48
    40203928:	94000849 	bl	40205a4c <memcpy>
    4020392c:	52800028 	mov	w8, #0x1                   	// #1
    40203930:	14000021 	b	402039b4 <jnox_kernel::reservation_jobs::Jobs::open+0x100>
    40203934:	52800088 	mov	w8, #0x4                   	// #4
    40203938:	39002268 	strb	w8, [x19, #8]
    4020393c:	52800048 	mov	w8, #0x2                   	// #2
    40203940:	f9000268 	str	x8, [x19]
    40203944:	a95d4ff4 	ldp	x20, x19, [sp, #464]
    40203948:	a95c57f6 	ldp	x22, x21, [sp, #448]
    4020394c:	a95b5ff8 	ldp	x24, x23, [sp, #432]
    40203950:	a95a67fa 	ldp	x26, x25, [sp, #416]
    40203954:	a9597bfd 	ldp	x29, x30, [sp, #400]
    40203958:	910783ff 	add	sp, sp, #0x1e0
    4020395c:	d65f03c0 	ret
    40203960:	910203e0 	add	x0, sp, #0x80
    40203964:	9100a017 	add	x23, x0, #0x28
    40203968:	52800028 	mov	w8, #0x1                   	// #1
    4020396c:	2a0803f8 	mov	w24, w8
    40203970:	9100a039 	add	x25, x1, #0x28
    40203974:	52800502 	mov	w2, #0x28                  	// #40
    40203978:	94000835 	bl	40205a4c <memcpy>
    4020397c:	2a1f03e8 	mov	w8, wzr
    40203980:	aa1903e1 	mov	x1, x25
    40203984:	aa1703e0 	mov	x0, x23
    40203988:	3707ff38 	tbnz	w24, #0, 4020396c <jnox_kernel::reservation_jobs::Jobs::open+0xb8>
    4020398c:	910583e0 	add	x0, sp, #0x160
    40203990:	910203e1 	add	x1, sp, #0x80
    40203994:	52800602 	mov	w2, #0x30                  	// #48
    40203998:	9400082d 	bl	40205a4c <memcpy>
    4020399c:	aa1f03e8 	mov	x8, xzr
    402039a0:	a94b27f7 	ldp	x23, x9, [sp, #176]
    402039a4:	a94c2fea 	ldp	x10, x11, [sp, #192]
    402039a8:	a914abe9 	stp	x9, x10, [sp, #328]
    402039ac:	f900afeb 	str	x11, [sp, #344]
    402039b0:	f9402e98 	ldr	x24, [x20, #88]
    402039b4:	f9403a99 	ldr	x25, [x20, #112]
    402039b8:	f90003e8 	str	x8, [sp]
    402039bc:	910003e8 	mov	x8, sp
    402039c0:	7940f29a 	ldrh	w26, [x20, #120]
    402039c4:	91002100 	add	x0, x8, #0x8
    402039c8:	910583e1 	add	x1, sp, #0x160
    402039cc:	52800602 	mov	w2, #0x30                  	// #48
    402039d0:	9400081f 	bl	40205a4c <memcpy>
    402039d4:	3901ebf6 	strb	w22, [sp, #122]
    402039d8:	a954a7e8 	ldp	x8, x9, [sp, #328]
    402039dc:	a903a3f7 	stp	x23, x8, [sp, #56]
    402039e0:	f940afe8 	ldr	x8, [sp, #344]
    402039e4:	a904a3e9 	stp	x9, x8, [sp, #72]
    402039e8:	a906e7f5 	stp	x21, x25, [sp, #104]
    402039ec:	7900f3fa 	strh	w26, [sp, #120]
    402039f0:	f9002ff8 	str	x24, [sp, #88]
    402039f4:	52800068 	mov	w8, #0x3                   	// #3
    402039f8:	390183e8 	strb	w8, [sp, #96]
    402039fc:	910203f7 	add	x23, sp, #0x80
    40203a00:	910203e8 	add	x8, sp, #0x80
    40203a04:	910003e0 	mov	x0, sp
    40203a08:	aa1503e1 	mov	x1, x21
    40203a0c:	94000032 	bl	40203ad4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>
    40203a10:	f94043f6 	ldr	x22, [sp, #128]
    40203a14:	394223f5 	ldrb	w21, [sp, #136]
    40203a18:	f1000adf 	cmp	x22, #0x2
    40203a1c:	54000061 	b.ne	40203a28 <jnox_kernel::reservation_jobs::Jobs::open+0x174>  // b.any
    40203a20:	39002275 	strb	w21, [x19, #8]
    40203a24:	17ffffc6 	b	4020393c <jnox_kernel::reservation_jobs::Jobs::open+0x88>
    40203a28:	9103a3e0 	add	x0, sp, #0xe8
    40203a2c:	910026e1 	add	x1, x23, #0x9
    40203a30:	52800be2 	mov	w2, #0x5f                  	// #95
    40203a34:	94000806 	bl	40205a4c <memcpy>
    40203a38:	910003e1 	mov	x1, sp
    40203a3c:	aa1403e0 	mov	x0, x20
    40203a40:	52801002 	mov	w2, #0x80                  	// #128
    40203a44:	94000802 	bl	40205a4c <memcpy>
    40203a48:	f9000276 	str	x22, [x19]
    40203a4c:	39002275 	strb	w21, [x19, #8]
    40203a50:	91002660 	add	x0, x19, #0x9
    40203a54:	9103a3e1 	add	x1, sp, #0xe8
    40203a58:	52800be2 	mov	w2, #0x5f                  	// #95
    40203a5c:	940007fc 	bl	40205a4c <memcpy>
    40203a60:	17ffffb9 	b	40203944 <jnox_kernel::reservation_jobs::Jobs::open+0x90>

0000000040203a64 <jnox_kernel::reservation_jobs::Jobs::trap>:
    40203a64:	3941800a 	ldrb	w10, [x0, #96]
    40203a68:	71000d5f 	cmp	w10, #0x3
    40203a6c:	54000061 	b.ne	40203a78 <jnox_kernel::reservation_jobs::Jobs::trap+0x14>  // b.any
    40203a70:	52800080 	mov	w0, #0x4                   	// #4
    40203a74:	d65f03c0 	ret
    40203a78:	aa0003e8 	mov	x8, x0
    40203a7c:	12001c49 	and	w9, w2, #0xff
    40203a80:	52800080 	mov	w0, #0x4                   	// #4
    40203a84:	6b09015f 	cmp	w10, w9
    40203a88:	54000181 	b.ne	40203ab8 <jnox_kernel::reservation_jobs::Jobs::trap+0x54>  // b.any
    40203a8c:	f9402d0a 	ldr	x10, [x8, #88]
    40203a90:	eb01015f 	cmp	x10, x1
    40203a94:	54000121 	b.ne	40203ab8 <jnox_kernel::reservation_jobs::Jobs::trap+0x54>  // b.any
    40203a98:	f100043f 	cmp	x1, #0x1
    40203a9c:	54000108 	b.hi	40203abc <jnox_kernel::reservation_jobs::Jobs::trap+0x58>  // b.pmore
    40203aa0:	2a1f03e0 	mov	w0, wzr
    40203aa4:	11000929 	add	w9, w9, #0x2
    40203aa8:	8b01010a 	add	x10, x8, x1
    40203aac:	3901e149 	strb	w9, [x10, #120]
    40203ab0:	52800069 	mov	w9, #0x3                   	// #3
    40203ab4:	39018109 	strb	w9, [x8, #96]
    40203ab8:	d65f03c0 	ret
    40203abc:	f81f0ffe 	str	x30, [sp, #-16]!
    40203ac0:	d503201f 	nop
    40203ac4:	100126e2 	adr	x2, 40205fa0 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236>
    40203ac8:	aa0103e0 	mov	x0, x1
    40203acc:	52800041 	mov	w1, #0x2                   	// #2
    40203ad0:	9400048f 	bl	40204d0c <core::panicking::panic_bounds_check>

0000000040203ad4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>:
    40203ad4:	d10483ff 	sub	sp, sp, #0x120
    40203ad8:	a90c7bfd 	stp	x29, x30, [sp, #192]
    40203adc:	a90d6ffc 	stp	x28, x27, [sp, #208]
    40203ae0:	a90e67fa 	stp	x26, x25, [sp, #224]
    40203ae4:	a90f5ff8 	stp	x24, x23, [sp, #240]
    40203ae8:	a91057f6 	stp	x22, x21, [sp, #256]
    40203aec:	a9114ff4 	stp	x20, x19, [sp, #272]
    40203af0:	aa0103f5 	mov	x21, x1
    40203af4:	aa0003f4 	mov	x20, x0
    40203af8:	aa0803f3 	mov	x19, x8
    40203afc:	3941e808 	ldrb	w8, [x0, #122]
    40203b00:	910083e9 	add	x9, sp, #0x20
    40203b04:	9100413b 	add	x27, x9, #0x10
    40203b08:	340000e8 	cbz	w8, 40203b24 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x50>
    40203b0c:	f10002bf 	cmp	x21, #0x0
    40203b10:	b21e03e9 	mov	x9, #0x400000004           	// #17179869188
    40203b14:	9a9f0129 	csel	x9, x9, xzr, eq  // eq = none
    40203b18:	7100051f 	cmp	w8, #0x1
    40203b1c:	9a9f012a 	csel	x10, x9, xzr, eq  // eq = none
    40203b20:	1400000b 	b	40203b4c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203b24:	aa1f03ea 	mov	x10, xzr
    40203b28:	f1005ebf 	cmp	x21, #0x17
    40203b2c:	54000108 	b.hi	40203b4c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>  // b.pmore
    40203b30:	52800028 	mov	w8, #0x1                   	// #1
    40203b34:	9ad52108 	lsl	x8, x8, x21
    40203b38:	52840629 	mov	w9, #0x2031                	// #8241
    40203b3c:	72a00809 	movk	w9, #0x40, lsl #16
    40203b40:	ea09011f 	tst	x8, x9
    40203b44:	54000da0 	b.eq	40203cf8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x224>  // b.none
    40203b48:	5280002a 	mov	w10, #0x1                   	// #1
    40203b4c:	aa1f03f6 	mov	x22, xzr
    40203b50:	a9012bea 	stp	x10, x10, [sp, #16]
    40203b54:	5280011d 	mov	w29, #0x8                   	// #8
    40203b58:	910063fa 	add	x26, sp, #0x18
    40203b5c:	5280003c 	mov	w28, #0x1                   	// #1
    40203b60:	b8767b57 	ldr	w23, [x26, x22, lsl #2]
    40203b64:	34000297 	cbz	w23, 40203bb4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0xe0>
    40203b68:	8b160298 	add	x24, x20, x22
    40203b6c:	3941e308 	ldrb	w8, [x24, #120]
    40203b70:	71000d1f 	cmp	w8, #0x3
    40203b74:	7a401904 	ccmp	w8, #0x0, #0x4, ne  // ne = any
    40203b78:	540014a1 	b.ne	40203e0c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.any
    40203b7c:	8b160a99 	add	x25, x20, x22, lsl #2
    40203b80:	b9407328 	ldr	w8, [x25, #112]
    40203b84:	35001448 	cbnz	w8, 40203e0c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203b88:	f9400288 	ldr	x8, [x20]
    40203b8c:	f100051f 	cmp	x8, #0x1
    40203b90:	540000e1 	b.ne	40203bac <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0xd8>  // b.any
    40203b94:	91002280 	add	x0, x20, #0x8
    40203b98:	aa1603e1 	mov	x1, x22
    40203b9c:	2a1703e2 	mov	w2, w23
    40203ba0:	9400027e 	bl	40204598 <jnox_kernel::temporal_policy::HardCbs<_>::release>
    40203ba4:	f100141f 	cmp	x0, #0x5
    40203ba8:	54000a01 	b.ne	40203ce8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x214>  // b.any
    40203bac:	b9007337 	str	w23, [x25, #112]
    40203bb0:	3901e31c 	strb	w28, [x24, #120]
    40203bb4:	f10013bd 	subs	x29, x29, #0x4
    40203bb8:	910006d6 	add	x22, x22, #0x1
    40203bbc:	54fffd21 	b.ne	40203b60 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x8c>  // b.any
    40203bc0:	6f00e400 	movi	v0.2d, #0x0
    40203bc4:	ad0103e0 	stp	q0, q0, [sp, #32]
    40203bc8:	f9400288 	ldr	x8, [x20]
    40203bcc:	f100051f 	cmp	x8, #0x1
    40203bd0:	54000421 	b.ne	40203c54 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x180>  // b.any
    40203bd4:	aa1f03f5 	mov	x21, xzr
    40203bd8:	aa1f03fb 	mov	x27, xzr
    40203bdc:	91006296 	add	x22, x20, #0x18
    40203be0:	910083f7 	add	x23, sp, #0x20
    40203be4:	910203e8 	add	x8, sp, #0x80
    40203be8:	91002280 	add	x0, x20, #0x8
    40203bec:	aa1503e1 	mov	x1, x21
    40203bf0:	94000290 	bl	40204630 <jnox_kernel::temporal_policy::HardCbs<_>::available>
    40203bf4:	a94823e9 	ldp	x9, x8, [sp, #128]
    40203bf8:	f100093f 	cmp	x9, #0x2
    40203bfc:	54000280 	b.eq	40203c4c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x178>  // b.none
    40203c00:	36000069 	tbz	w9, #0, 40203c0c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x138>
    40203c04:	f9404be9 	ldr	x9, [sp, #144]
    40203c08:	14000003 	b	40203c14 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x140>
    40203c0c:	b94002c8 	ldr	w8, [x22]
    40203c10:	f85f02c9 	ldur	x9, [x22, #-16]
    40203c14:	8b1b02ea 	add	x10, x23, x27
    40203c18:	9100437b 	add	x27, x27, #0x10
    40203c1c:	2a0803e8 	mov	w8, w8
    40203c20:	a9002548 	stp	x8, x9, [x10]
    40203c24:	910062d6 	add	x22, x22, #0x18
    40203c28:	910006b5 	add	x21, x21, #0x1
    40203c2c:	f100837f 	cmp	x27, #0x20
    40203c30:	54fffda1 	b.ne	40203be4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x110>  // b.any
    40203c34:	910203e8 	add	x8, sp, #0x80
    40203c38:	91002280 	add	x0, x20, #0x8
    40203c3c:	940001f9 	bl	40204420 <jnox_kernel::temporal_policy::HardCbs<_>::tick>
    40203c40:	a94823e9 	ldp	x9, x8, [sp, #128]
    40203c44:	f100053f 	cmp	x9, #0x1
    40203c48:	54000641 	b.ne	40203d10 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x23c>  // b.any
    40203c4c:	f100111f 	cmp	x8, #0x4
    40203c50:	14000027 	b	40203cec <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x218>
    40203c54:	910083e8 	add	x8, sp, #0x20
    40203c58:	b27d0117 	orr	x23, x8, #0x8
    40203c5c:	52800a1a 	mov	w26, #0x50                  	// #80
    40203c60:	91002296 	add	x22, x20, #0x8
    40203c64:	910203e8 	add	x8, sp, #0x80
    40203c68:	aa1603e0 	mov	x0, x22
    40203c6c:	aa1503e1 	mov	x1, x21
    40203c70:	94000187 	bl	4020428c <jnox_kernel::service_policy::PeriodicReservation::allocation_at>
    40203c74:	b94083e8 	ldr	w8, [sp, #128]
    40203c78:	36001108 	tbz	w8, #0, 40203e98 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c4>
    40203c7c:	a948a7e8 	ldp	x8, x9, [sp, #136]
    40203c80:	f100a35a 	subs	x26, x26, #0x28
    40203c84:	a93fa6e8 	stp	x8, x9, [x23, #-8]
    40203c88:	9100a2d6 	add	x22, x22, #0x28
    40203c8c:	910042f7 	add	x23, x23, #0x10
    40203c90:	54fffea1 	b.ne	40203c64 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x190>  // b.any
    40203c94:	aa1f03e8 	mov	x8, xzr
    40203c98:	910083e9 	add	x9, sp, #0x20
    40203c9c:	9101c28c 	add	x12, x20, #0x70
    40203ca0:	a90827ec 	stp	x12, x9, [sp, #128]
    40203ca4:	5280004a 	mov	w10, #0x2                   	// #2
    40203ca8:	a909a7ea 	stp	x10, x9, [sp, #152]
    40203cac:	f9400bf7 	ldr	x23, [sp, #16]
    40203cb0:	9100050a 	add	x10, x8, #0x1
    40203cb4:	b868798b 	ldr	w11, [x12, x8, lsl #2]
    40203cb8:	3400006b 	cbz	w11, 40203cc4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x1f0>
    40203cbc:	f940012b 	ldr	x11, [x9]
    40203cc0:	b50003cb 	cbnz	x11, 40203d38 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x264>
    40203cc4:	f100095f 	cmp	x10, #0x2
    40203cc8:	aa1b03e9 	mov	x9, x27
    40203ccc:	52800028 	mov	w8, #0x1                   	// #1
    40203cd0:	54ffff01 	b.ne	40203cb0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x1dc>  // b.any
    40203cd4:	aa1f03e9 	mov	x9, xzr
    40203cd8:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203cdc:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203ce0:	52800068 	mov	w8, #0x3                   	// #3
    40203ce4:	14000059 	b	40203e48 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x374>
    40203ce8:	f100101f 	cmp	x0, #0x4
    40203cec:	52800068 	mov	w8, #0x3                   	// #3
    40203cf0:	1a880508 	cinc	w8, w8, ne  // ne = any
    40203cf4:	1400006a 	b	40203e9c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c8>
    40203cf8:	f10006bf 	cmp	x21, #0x1
    40203cfc:	540008c0 	b.eq	40203e14 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x340>  // b.none
    40203d00:	f1005ebf 	cmp	x21, #0x17
    40203d04:	54fff241 	b.ne	40203b4c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>  // b.any
    40203d08:	52800c8a 	mov	w10, #0x64                  	// #100
    40203d0c:	17ffff90 	b	40203b4c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203d10:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203d14:	f9404bf6 	ldr	x22, [sp, #144]
    40203d18:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203d1c:	36000808 	tbz	w8, #0, 40203e1c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x348>
    40203d20:	f10006df 	cmp	x22, #0x1
    40203d24:	f9400bf7 	ldr	x23, [sp, #16]
    40203d28:	54000369 	b.ls	40203d94 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x2c0>  // b.plast
    40203d2c:	d503201f 	nop
    40203d30:	10011502 	adr	x2, 40205fd0 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x30>
    40203d34:	14000067 	b	40203ed0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3fc>
    40203d38:	f9004bea 	str	x10, [sp, #144]
    40203d3c:	f9400529 	ldr	x9, [x9, #8]
    40203d40:	a90aa3e9 	stp	x9, x8, [sp, #168]
    40203d44:	f9005fe8 	str	x8, [sp, #184]
    40203d48:	910183e8 	add	x8, sp, #0x60
    40203d4c:	91002108 	add	x8, x8, #0x8
    40203d50:	910203e0 	add	x0, sp, #0x80
    40203d54:	9102a3e1 	add	x1, sp, #0xa8
    40203d58:	94000098 	bl	40203fb8 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold>
    40203d5c:	f9403ff6 	ldr	x22, [sp, #120]
    40203d60:	f1000adf 	cmp	x22, #0x2
    40203d64:	54000b22 	b.cs	40203ec8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3f4>  // b.hs, b.nlast
    40203d68:	52800508 	mov	w8, #0x28                  	// #40
    40203d6c:	91002289 	add	x9, x20, #0x8
    40203d70:	9b0826c0 	madd	x0, x22, x8, x9
    40203d74:	aa1503e1 	mov	x1, x21
    40203d78:	52800022 	mov	w2, #0x1                   	// #1
    40203d7c:	9400015f 	bl	402042f8 <jnox_kernel::service_policy::PeriodicReservation::grant_at>
    40203d80:	f100041f 	cmp	x0, #0x1
    40203d84:	fa410820 	ccmp	x1, #0x1, #0x0, eq  // eq = none
    40203d88:	54000421 	b.ne	40203e0c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.any
    40203d8c:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203d90:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203d94:	9101e288 	add	x8, x20, #0x78
    40203d98:	38766908 	ldrb	w8, [x8, x22]
    40203d9c:	51000508 	sub	w8, w8, #0x1
    40203da0:	7100091f 	cmp	w8, #0x2
    40203da4:	54000342 	b.cs	40203e0c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.hs, b.nlast
    40203da8:	9101c28a 	add	x10, x20, #0x70
    40203dac:	b8767948 	ldr	w8, [x10, x22, lsl #2]
    40203db0:	51000509 	sub	w9, w8, #0x1
    40203db4:	d3607d29 	lsl	x9, x9, #32
    40203db8:	7100011f 	cmp	w8, #0x0
    40203dbc:	52808028 	mov	w8, #0x401                 	// #1025
    40203dc0:	9a890108 	csel	x8, x8, x9, eq  // eq = none
    40203dc4:	37000248 	tbnz	w8, #0, 40203e0c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203dc8:	d360fd08 	lsr	x8, x8, #32
    40203dcc:	b8367948 	str	w8, [x10, x22, lsl #2]
    40203dd0:	910103e9 	add	x9, sp, #0x40
    40203dd4:	8b161129 	add	x9, x9, x22, lsl #4
    40203dd8:	f940012a 	ldr	x10, [x9]
    40203ddc:	b400018a 	cbz	x10, 40203e0c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203de0:	d100054a 	sub	x10, x10, #0x1
    40203de4:	f900012a 	str	x10, [x9]
    40203de8:	3941ea89 	ldrb	w9, [x20, #122]
    40203dec:	7100093f 	cmp	w9, #0x2
    40203df0:	540001e0 	b.eq	40203e2c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x358>  // b.none
    40203df4:	7100053f 	cmp	w9, #0x1
    40203df8:	540001e1 	b.ne	40203e34 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x360>  // b.any
    40203dfc:	f100011f 	cmp	x8, #0x0
    40203e00:	52800048 	mov	w8, #0x2                   	// #2
    40203e04:	1a9f0108 	csel	w8, w8, wzr, eq  // eq = none
    40203e08:	1400000d 	b	40203e3c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x368>
    40203e0c:	52800088 	mov	w8, #0x4                   	// #4
    40203e10:	14000023 	b	40203e9c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c8>
    40203e14:	d2c00c8a 	mov	x10, #0x6400000000          	// #429496729600
    40203e18:	17ffff4d 	b	40203b4c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203e1c:	aa1f03e9 	mov	x9, xzr
    40203e20:	52800068 	mov	w8, #0x3                   	// #3
    40203e24:	f9400bf7 	ldr	x23, [sp, #16]
    40203e28:	14000008 	b	40203e48 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x374>
    40203e2c:	2a1f03e8 	mov	w8, wzr
    40203e30:	14000003 	b	40203e3c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x368>
    40203e34:	f100011f 	cmp	x8, #0x0
    40203e38:	1a9f17e8 	cset	w8, eq  // eq = none
    40203e3c:	f9002e96 	str	x22, [x20, #88]
    40203e40:	52800029 	mov	w9, #0x1                   	// #1
    40203e44:	39018288 	strb	w8, [x20, #96]
    40203e48:	f940368a 	ldr	x10, [x20, #104]
    40203e4c:	b100055f 	cmn	x10, #0x1
    40203e50:	54000240 	b.eq	40203e98 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c4>  // b.none
    40203e54:	9100054a 	add	x10, x10, #0x1
    40203e58:	f900368a 	str	x10, [x20, #104]
    40203e5c:	a9422fea 	ldp	x10, x11, [sp, #32]
    40203e60:	a94337ec 	ldp	x12, x13, [sp, #48]
    40203e64:	a902326b 	stp	x11, x12, [x19, #32]
    40203e68:	a94433eb 	ldp	x11, x12, [sp, #64]
    40203e6c:	a9032e6d 	stp	x13, x11, [x19, #48]
    40203e70:	a9452fed 	ldp	x13, x11, [sp, #80]
    40203e74:	a904366c 	stp	x12, x13, [x19, #64]
    40203e78:	a9005a69 	stp	x9, x22, [x19]
    40203e7c:	7940f289 	ldrh	w9, [x20, #120]
    40203e80:	f9403a8c 	ldr	x12, [x20, #112]
    40203e84:	a9012a77 	stp	x23, x10, [x19, #16]
    40203e88:	a905326b 	stp	x11, x12, [x19, #80]
    40203e8c:	7900c269 	strh	w9, [x19, #96]
    40203e90:	39018a68 	strb	w8, [x19, #98]
    40203e94:	14000005 	b	40203ea8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3d4>
    40203e98:	52800068 	mov	w8, #0x3                   	// #3
    40203e9c:	39002268 	strb	w8, [x19, #8]
    40203ea0:	52800048 	mov	w8, #0x2                   	// #2
    40203ea4:	f9000268 	str	x8, [x19]
    40203ea8:	a9514ff4 	ldp	x20, x19, [sp, #272]
    40203eac:	a95057f6 	ldp	x22, x21, [sp, #256]
    40203eb0:	a94f5ff8 	ldp	x24, x23, [sp, #240]
    40203eb4:	a94e67fa 	ldp	x26, x25, [sp, #224]
    40203eb8:	a94d6ffc 	ldp	x28, x27, [sp, #208]
    40203ebc:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    40203ec0:	910483ff 	add	sp, sp, #0x120
    40203ec4:	d65f03c0 	ret
    40203ec8:	d503201f 	nop
    40203ecc:	10010762 	adr	x2, 40205fb8 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x18>
    40203ed0:	aa1603e0 	mov	x0, x22
    40203ed4:	52800041 	mov	w1, #0x2                   	// #2
    40203ed8:	9400038d 	bl	40204d0c <core::panicking::panic_bounds_check>

0000000040203edc <jnox_kernel::reservation_jobs::Clock::new>:
    40203edc:	b40005a1 	cbz	x1, 40203f90 <jnox_kernel::reservation_jobs::Clock::new+0xb4>
    40203ee0:	d343fc29 	lsr	x9, x1, #3
    40203ee4:	d29ef9ea 	mov	x10, #0xf7cf                	// #63439
    40203ee8:	f2bc6a6a 	movk	x10, #0xe353, lsl #16
    40203eec:	f2d374aa 	movk	x10, #0x9ba5, lsl #32
    40203ef0:	f2e4188a 	movk	x10, #0x20c4, lsl #48
    40203ef4:	9bca7d29 	umulh	x9, x9, x10
    40203ef8:	d344fd29 	lsr	x9, x9, #4
    40203efc:	52807d0a 	mov	w10, #0x3e8                 	// #1000
    40203f00:	9b0a852a 	msub	x10, x9, x10, x1
    40203f04:	b500046a 	cbnz	x10, 40203f90 <jnox_kernel::reservation_jobs::Clock::new+0xb4>
    40203f08:	b202e7ea 	mov	x10, #0xcccccccccccccccc    	// #-3689348814741910324
    40203f0c:	f29999aa 	movk	x10, #0xcccd
    40203f10:	9bca7c2a 	umulh	x10, x1, x10
    40203f14:	d344fd4a 	lsr	x10, x10, #4
    40203f18:	72001c5f 	tst	w2, #0xff
    40203f1c:	5280014b 	mov	w11, #0xa                   	// #10
    40203f20:	5280050c 	mov	w12, #0x28                  	// #40
    40203f24:	9a8b018b 	csel	x11, x12, x11, eq  // eq = none
    40203f28:	9bca7d6c 	umulh	x12, x11, x10
    40203f2c:	eb0c03ff 	cmp	xzr, x12
    40203f30:	1a9f07ec 	cset	w12, ne  // ne = any
    40203f34:	9b0a7d6b 	mul	x11, x11, x10
    40203f38:	ab0b001f 	cmn	x0, x11
    40203f3c:	1a9f37eb 	cset	w11, cs  // cs = hs, nlast
    40203f40:	3700020c 	tbnz	w12, #0, 40203f80 <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f44:	350001eb 	cbnz	w11, 40203f80 <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f48:	72001c5f 	tst	w2, #0xff
    40203f4c:	5280014b 	mov	w11, #0xa                   	// #10
    40203f50:	5280044c 	mov	w12, #0x22                  	// #34
    40203f54:	9a8b018b 	csel	x11, x12, x11, eq  // eq = none
    40203f58:	9bca7d6c 	umulh	x12, x11, x10
    40203f5c:	eb0c03ff 	cmp	xzr, x12
    40203f60:	1a9f07ed 	cset	w13, ne  // ne = any
    40203f64:	9b0a7d6b 	mul	x11, x11, x10
    40203f68:	ab00016b 	adds	x11, x11, x0
    40203f6c:	1a9f37ec 	cset	w12, cs  // cs = hs, nlast
    40203f70:	3700008d 	tbnz	w13, #0, 40203f80 <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f74:	3500006c 	cbnz	w12, 40203f80 <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f78:	ab09057f 	cmn	x11, x9, lsl #1
    40203f7c:	54000123 	b.cc	40203fa0 <jnox_kernel::reservation_jobs::Clock::new+0xc4>  // b.lo, b.ul, b.last
    40203f80:	52800069 	mov	w9, #0x3                   	// #3
    40203f84:	39000509 	strb	w9, [x8, #1]
    40203f88:	5280002b 	mov	w11, #0x1                   	// #1
    40203f8c:	14000003 	b	40203f98 <jnox_kernel::reservation_jobs::Clock::new+0xbc>
    40203f90:	5280002b 	mov	w11, #0x1                   	// #1
    40203f94:	3900050b 	strb	w11, [x8, #1]
    40203f98:	3900010b 	strb	w11, [x8]
    40203f9c:	d65f03c0 	ret
    40203fa0:	2a1f03eb 	mov	w11, wzr
    40203fa4:	a900a900 	stp	x0, x10, [x8, #8]
    40203fa8:	f9000d09 	str	x9, [x8, #24]
    40203fac:	17fffffb 	b	40203f98 <jnox_kernel::reservation_jobs::Clock::new+0xbc>

0000000040203fb0 <__rustc::rust_begin_unwind>:
    40203fb0:	d503205f 	wfe
    40203fb4:	17ffffff 	b	40203fb0 <__rustc::rust_begin_unwind>

0000000040203fb8 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold>:
    40203fb8:	d10103ff 	sub	sp, sp, #0x40
    40203fbc:	f9001bfe 	str	x30, [sp, #48]
    40203fc0:	a9412809 	ldp	x9, x10, [x0, #16]
    40203fc4:	eb0a013f 	cmp	x9, x10
    40203fc8:	540004e2 	b.cs	40204064 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0xac>  // b.hs, b.nlast
    40203fcc:	f940100e 	ldr	x14, [x0, #32]
    40203fd0:	a940340b 	ldp	x11, x13, [x0]
    40203fd4:	910003ec 	mov	x12, sp
    40203fd8:	9100618c 	add	x12, x12, #0x18
    40203fdc:	f100093f 	cmp	x9, #0x2
    40203fe0:	5280004f 	mov	w15, #0x2                   	// #2
    40203fe4:	9a8f8120 	csel	x0, x9, x15, hi  // hi = pmore
    40203fe8:	8b0911ad 	add	x13, x13, x9, lsl #4
    40203fec:	8b0911ce 	add	x14, x14, x9, lsl #4
    40203ff0:	910021ce 	add	x14, x14, #0x8
    40203ff4:	eb09001f 	cmp	x0, x9
    40203ff8:	54000440 	b.eq	40204080 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0xc8>  // b.none
    40203ffc:	b869796f 	ldr	w15, [x11, x9, lsl #2]
    40204000:	3400028f 	cbz	w15, 40204050 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x98>
    40204004:	f94001af 	ldr	x15, [x13]
    40204008:	b400024f 	cbz	x15, 40204050 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x98>
    4020400c:	f94001cf 	ldr	x15, [x14]
    40204010:	a9404430 	ldp	x16, x17, [x1]
    40204014:	a90047f0 	stp	x16, x17, [sp]
    40204018:	f9400831 	ldr	x17, [x1, #16]
    4020401c:	a9013ff1 	stp	x17, x15, [sp, #16]
    40204020:	eb0f021f 	cmp	x16, x15
    40204024:	a90227e9 	stp	x9, x9, [sp, #32]
    40204028:	54000061 	b.ne	40204034 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x7c>  // b.any
    4020402c:	f94007ef 	ldr	x15, [sp, #8]
    40204030:	eb0901ff 	cmp	x15, x9
    40204034:	aa0c03ef 	mov	x15, x12
    40204038:	54000048 	b.hi	40204040 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x88>  // b.pmore
    4020403c:	910003ef 	mov	x15, sp
    40204040:	a94045f0 	ldp	x16, x17, [x15]
    40204044:	a9004430 	stp	x16, x17, [x1]
    40204048:	f94009ef 	ldr	x15, [x15, #16]
    4020404c:	f900082f 	str	x15, [x1, #16]
    40204050:	91000529 	add	x9, x9, #0x1
    40204054:	910041ad 	add	x13, x13, #0x10
    40204058:	910041ce 	add	x14, x14, #0x10
    4020405c:	eb09015f 	cmp	x10, x9
    40204060:	54fffca1 	b.ne	40203ff4 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x3c>  // b.any
    40204064:	a9402829 	ldp	x9, x10, [x1]
    40204068:	a9002909 	stp	x9, x10, [x8]
    4020406c:	f9400829 	ldr	x9, [x1, #16]
    40204070:	f9000909 	str	x9, [x8, #16]
    40204074:	f9401bfe 	ldr	x30, [sp, #48]
    40204078:	910103ff 	add	sp, sp, #0x40
    4020407c:	d65f03c0 	ret
    40204080:	d503201f 	nop
    40204084:	1000ff22 	adr	x2, 40206068 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.6392299720734326547>
    40204088:	52800041 	mov	w1, #0x2                   	// #2
    4020408c:	94000320 	bl	40204d0c <core::panicking::panic_bounds_check>

0000000040204090 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>:
    40204090:	d10083ff 	sub	sp, sp, #0x20
    40204094:	d503201f 	nop
    40204098:	10ffa649 	adr	x9, 40203560 <reservation_worker_a>
    4020409c:	d503201f 	nop
    402040a0:	10ffa66a 	adr	x10, 4020356c <reservation_worker_b>
    402040a4:	f90003e9 	str	x9, [sp]
    402040a8:	a900fbea 	stp	x10, x30, [sp, #8]
    402040ac:	f100043f 	cmp	x1, #0x1
    402040b0:	540009c8 	b.hi	402041e8 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x158>  // b.pmore
    402040b4:	d503201f 	nop
    402040b8:	1009b349 	adr	x9, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241>
    402040bc:	8b01392a 	add	x10, x9, x1, lsl #14
    402040c0:	9140114b 	add	x11, x10, #0x4, lsl #12
    402040c4:	52879809 	mov	w9, #0x3cc0                	// #15552
    402040c8:	8b090149 	add	x9, x10, x9
    402040cc:	eb09017f 	cmp	x11, x9
    402040d0:	540008a3 	b.cc	402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.lo, b.ul, b.last
    402040d4:	eb0a013f 	cmp	x9, x10
    402040d8:	54000863 	b.cc	402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.lo, b.ul, b.last
    402040dc:	f940000a 	ldr	x10, [x0]
    402040e0:	8b010d4b 	add	x11, x10, x1, lsl #3
    402040e4:	f940b56d 	ldr	x13, [x11, #360]
    402040e8:	eb0d013f 	cmp	x9, x13
    402040ec:	540007c1 	b.ne	402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    402040f0:	910003ea 	mov	x10, sp
    402040f4:	f861794a 	ldr	x10, [x10, x1, lsl #3]
    402040f8:	f9407dac 	ldr	x12, [x13, #248]
    402040fc:	eb0a019f 	cmp	x12, x10
    40204100:	54000721 	b.ne	402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    40204104:	f94081ac 	ldr	x12, [x13, #256]
    40204108:	f10d159f 	cmp	x12, #0x345
    4020410c:	540006c1 	b.ne	402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    40204110:	f9404dac 	ldr	x12, [x13, #152]
    40204114:	b500068c 	cbnz	x12, 402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    40204118:	d503201f 	nop
    4020411c:	1000eaac 	adr	x12, 40205e70 <anon.d6c364c9f4c098981b8152fc16ba3537.1.llvm.16192825690684220241>
    40204120:	f861798c 	ldr	x12, [x12, x1, lsl #3]
    40204124:	f9408dad 	ldr	x13, [x13, #280]
    40204128:	eb0c01bf 	cmp	x13, x12
    4020412c:	540005c1 	b.ne	402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    40204130:	d503201f 	nop
    40204134:	1001adad 	adr	x13, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40204138:	8b010dad 	add	x13, x13, x1, lsl #3
    4020413c:	c8dffdad 	ldar	x13, [x13]
    40204140:	b10005bf 	cmn	x13, #0x1
    40204144:	54000501 	b.ne	402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    40204148:	d503201f 	nop
    4020414c:	100fe52d 	adr	x13, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40204150:	8b010dad 	add	x13, x13, x1, lsl #3
    40204154:	c8dffdad 	ldar	x13, [x13]
    40204158:	b500046d 	cbnz	x13, 402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    4020415c:	d503201f 	nop
    40204160:	1001accd 	adr	x13, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40204164:	8b010dad 	add	x13, x13, x1, lsl #3
    40204168:	c8dffdad 	ldar	x13, [x13]
    4020416c:	b10005bf 	cmn	x13, #0x1
    40204170:	540003a1 	b.ne	402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    40204174:	d503201f 	nop
    40204178:	100fe44d 	adr	x13, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    4020417c:	8b010dad 	add	x13, x13, x1, lsl #3
    40204180:	c8dffdad 	ldar	x13, [x13]
    40204184:	b500030d 	cbnz	x13, 402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    40204188:	d503201f 	nop
    4020418c:	100fe42d 	adr	x13, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    40204190:	8b010dad 	add	x13, x13, x1, lsl #3
    40204194:	c8dffdad 	ldar	x13, [x13]
    40204198:	b500026d 	cbnz	x13, 402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    4020419c:	f940e16d 	ldr	x13, [x11, #448]
    402041a0:	b500022d 	cbnz	x13, 402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    402041a4:	f940e96d 	ldr	x13, [x11, #464]
    402041a8:	eb0c01bf 	cmp	x13, x12
    402041ac:	540001c1 	b.ne	402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    402041b0:	f940c96d 	ldr	x13, [x11, #400]
    402041b4:	b10005bf 	cmn	x13, #0x1
    402041b8:	54000161 	b.ne	402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>  // b.any
    402041bc:	f940d16b 	ldr	x11, [x11, #416]
    402041c0:	b500012b 	cbnz	x11, 402041e4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x154>
    402041c4:	a9002909 	stp	x9, x10, [x8]
    402041c8:	528068a9 	mov	w9, #0x345                 	// #837
    402041cc:	a9017d09 	stp	x9, xzr, [x8, #16]
    402041d0:	a9027d0c 	stp	x12, xzr, [x8, #32]
    402041d4:	f900190c 	str	x12, [x8, #48]
    402041d8:	f9400bfe 	ldr	x30, [sp, #16]
    402041dc:	910083ff 	add	sp, sp, #0x20
    402041e0:	d65f03c0 	ret
    402041e4:	97fff431 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402041e8:	d503201f 	nop
    402041ec:	1000f4a2 	adr	x2, 40206080 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.6392299720734326547+0x18>
    402041f0:	aa0103e0 	mov	x0, x1
    402041f4:	52800041 	mov	w1, #0x2                   	// #2
    402041f8:	940002c5 	bl	40204d0c <core::panicking::panic_bounds_check>

00000000402041fc <jnox_kernel::uart_write>:
    402041fc:	b40001a1 	cbz	x1, 40204230 <jnox_kernel::uart_write+0x34>
    40204200:	8b010008 	add	x8, x0, x1
    40204204:	52800309 	mov	w9, #0x18                  	// #24
    40204208:	72a12009 	movk	w9, #0x900, lsl #16
    4020420c:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    40204210:	3840140b 	ldrb	w11, [x0], #1
    40204214:	b940012c 	ldr	w12, [x9]
    40204218:	3628006c 	tbz	w12, #5, 40204224 <jnox_kernel::uart_write+0x28>
    4020421c:	d5033fdf 	isb
    40204220:	17fffffd 	b	40204214 <jnox_kernel::uart_write+0x18>
    40204224:	b900014b 	str	w11, [x10]
    40204228:	eb08001f 	cmp	x0, x8
    4020422c:	54ffff21 	b.ne	40204210 <jnox_kernel::uart_write+0x14>  // b.any
    40204230:	d65f03c0 	ret

0000000040204234 <jnox_kernel::kernel_main>:
    40204234:	f00000e8 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16192825690684220241+0xb8e0>
    40204238:	f9471108 	ldr	x8, [x8, #3616]
    4020423c:	b4000068 	cbz	x8, 40204248 <jnox_kernel::kernel_main+0x14>
    40204240:	d503205f 	wfe
    40204244:	17ffffff 	b	40204240 <jnox_kernel::kernel_main+0xc>
    40204248:	f81f0ffe 	str	x30, [sp, #-16]!
    4020424c:	52800608 	mov	w8, #0x30                  	// #48
    40204250:	72a12008 	movk	w8, #0x900, lsl #16
    40204254:	b900011f 	str	wzr, [x8]
    40204258:	528001a9 	mov	w9, #0xd                   	// #13
    4020425c:	5280002a 	mov	w10, #0x1                   	// #1
    40204260:	b81f4109 	stur	w9, [x8, #-12]
    40204264:	b81f810a 	stur	w10, [x8, #-8]
    40204268:	52800c09 	mov	w9, #0x60                  	// #96
    4020426c:	b81fc109 	stur	w9, [x8, #-4]
    40204270:	52802029 	mov	w9, #0x101                 	// #257
    40204274:	b9000109 	str	w9, [x8]
    40204278:	d503201f 	nop
    4020427c:	1000eb60 	adr	x0, 40205fe8 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x48>
    40204280:	52800361 	mov	w1, #0x1b                  	// #27
    40204284:	97ffffde 	bl	402041fc <jnox_kernel::uart_write>
    40204288:	97fff6f2 	bl	40201e50 <jnox_kernel::ordinary_reservations::run>

000000004020428c <jnox_kernel::service_policy::PeriodicReservation::allocation_at>:
    4020428c:	f9400809 	ldr	x9, [x0, #16]
    40204290:	eb09002a 	subs	x10, x1, x9
    40204294:	54000062 	b.cs	402042a0 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x14>  // b.hs, b.nlast
    40204298:	aa1f03ea 	mov	x10, xzr
    4020429c:	1400000f 	b	402042d8 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x4c>
    402042a0:	f940040b 	ldr	x11, [x0, #8]
    402042a4:	b400022b 	cbz	x11, 402042e8 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x5c>
    402042a8:	9acb0949 	udiv	x9, x10, x11
    402042ac:	cb0a03ec 	neg	x12, x10
    402042b0:	9b0b3129 	madd	x9, x9, x11, x12
    402042b4:	8b090029 	add	x9, x1, x9
    402042b8:	ab0b0129 	adds	x9, x9, x11
    402042bc:	54000063 	b.cc	402042c8 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x3c>  // b.lo, b.ul, b.last
    402042c0:	aa1f03eb 	mov	x11, xzr
    402042c4:	14000007 	b	402042e0 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x54>
    402042c8:	eb0b015f 	cmp	x10, x11
    402042cc:	5280030a 	mov	w10, #0x18                  	// #24
    402042d0:	9a9f314a 	csel	x10, x10, xzr, cc  // cc = lo, ul, last
    402042d4:	f86a680a 	ldr	x10, [x0, x10]
    402042d8:	5280002b 	mov	w11, #0x1                   	// #1
    402042dc:	a900a50a 	stp	x10, x9, [x8, #8]
    402042e0:	f900010b 	str	x11, [x8]
    402042e4:	d65f03c0 	ret
    402042e8:	f81f0ffe 	str	x30, [sp, #-16]!
    402042ec:	d503201f 	nop
    402042f0:	1000e8c0 	adr	x0, 40206008 <anon.2d5d436b87d2a0d6f444a14986a49844.2.llvm.6392299720734326547>
    402042f4:	9400048c 	bl	40205524 <core::panicking::panic_const::panic_const_rem_by_zero>

00000000402042f8 <jnox_kernel::service_policy::PeriodicReservation::grant_at>:
    402042f8:	f9401008 	ldr	x8, [x0, #32]
    402042fc:	eb08003f 	cmp	x1, x8
    40204300:	54000062 	b.cs	4020430c <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x14>  // b.hs, b.nlast
    40204304:	aa1f03e0 	mov	x0, xzr
    40204308:	1400001c 	b	40204378 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x80>
    4020430c:	f9400408 	ldr	x8, [x0, #8]
    40204310:	b4000388 	cbz	x8, 40204380 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x88>
    40204314:	f9400809 	ldr	x9, [x0, #16]
    40204318:	cb09002a 	sub	x10, x1, x9
    4020431c:	9ac80949 	udiv	x9, x10, x8
    40204320:	9b08a929 	msub	x9, x9, x8, x10
    40204324:	eb08015f 	cmp	x10, x8
    40204328:	54000062 	b.cs	40204334 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x3c>  // b.hs, b.nlast
    4020432c:	9100600a 	add	x10, x0, #0x18
    40204330:	14000004 	b	40204340 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x48>
    40204334:	cb09002a 	sub	x10, x1, x9
    40204338:	f900080a 	str	x10, [x0, #16]
    4020433c:	aa0003ea 	mov	x10, x0
    40204340:	f940014a 	ldr	x10, [x10]
    40204344:	eb02015f 	cmp	x10, x2
    40204348:	9a82314b 	csel	x11, x10, x2, cc  // cc = lo, ul, last
    4020434c:	cb090108 	sub	x8, x8, x9
    40204350:	eb0b011f 	cmp	x8, x11
    40204354:	9a8b3109 	csel	x9, x8, x11, cc  // cc = lo, ul, last
    40204358:	aa2103e8 	mvn	x8, x1
    4020435c:	eb09011f 	cmp	x8, x9
    40204360:	da812128 	csinv	x8, x9, x1, cs  // cs = hs, nlast
    40204364:	cb08014a 	sub	x10, x10, x8
    40204368:	ab010129 	adds	x9, x9, x1
    4020436c:	da9f3129 	csinv	x9, x9, xzr, cc  // cc = lo, ul, last
    40204370:	a901a40a 	stp	x10, x9, [x0, #24]
    40204374:	52800020 	mov	w0, #0x1                   	// #1
    40204378:	aa0803e1 	mov	x1, x8
    4020437c:	d65f03c0 	ret
    40204380:	f81f0ffe 	str	x30, [sp, #-16]!
    40204384:	d503201f 	nop
    40204388:	1000e4c0 	adr	x0, 40206020 <anon.2d5d436b87d2a0d6f444a14986a49844.3.llvm.6392299720734326547>
    4020438c:	94000466 	bl	40205524 <core::panicking::panic_const::panic_const_rem_by_zero>

0000000040204390 <jnox_kernel::temporal_policy::HardCbs<_>::new>:
    40204390:	d10143ff 	sub	sp, sp, #0x50
    40204394:	a90357fe 	stp	x30, x21, [sp, #48]
    40204398:	a9044ff4 	stp	x20, x19, [sp, #64]
    4020439c:	aa0103f5 	mov	x21, x1
    402043a0:	aa0003f4 	mov	x20, x0
    402043a4:	aa0803f3 	mov	x19, x8
    402043a8:	aa0103e0 	mov	x0, x1
    402043ac:	52800041 	mov	w1, #0x2                   	// #2
    402043b0:	940000c6 	bl	402046c8 <jnox_kernel::temporal_policy::admit_reservations>
    402043b4:	12001c08 	and	w8, w0, #0xff
    402043b8:	71000d1f 	cmp	w8, #0x3
    402043bc:	54000261 	b.ne	40204408 <jnox_kernel::temporal_policy::HardCbs<_>::new+0x78>  // b.any
    402043c0:	910003e9 	mov	x9, sp
    402043c4:	91006128 	add	x8, x9, #0x18
    402043c8:	5280002a 	mov	w10, #0x1                   	// #1
    402043cc:	f9000134 	str	x20, [x9]
    402043d0:	28c132ab 	ldp	w11, w12, [x21], #8
    402043d4:	2a0a03ed 	mov	w13, w10
    402043d8:	2901312b 	stp	w11, w12, [x9, #8]
    402043dc:	f900093f 	str	xzr, [x9, #16]
    402043e0:	aa0803e9 	mov	x9, x8
    402043e4:	2a1f03ea 	mov	w10, wzr
    402043e8:	3707ff2d 	tbnz	w13, #0, 402043cc <jnox_kernel::temporal_policy::HardCbs<_>::new+0x3c>
    402043ec:	91002260 	add	x0, x19, #0x8
    402043f0:	910003e1 	mov	x1, sp
    402043f4:	52800602 	mov	w2, #0x30                  	// #48
    402043f8:	94000595 	bl	40205a4c <memcpy>
    402043fc:	f9001e74 	str	x20, [x19, #56]
    40204400:	52800028 	mov	w8, #0x1                   	// #1
    40204404:	14000002 	b	4020440c <jnox_kernel::temporal_policy::HardCbs<_>::new+0x7c>
    40204408:	aa1f03e8 	mov	x8, xzr
    4020440c:	f9000268 	str	x8, [x19]
    40204410:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40204414:	a94357fe 	ldp	x30, x21, [sp, #48]
    40204418:	910143ff 	add	sp, sp, #0x50
    4020441c:	d65f03c0 	ret

0000000040204420 <jnox_kernel::temporal_policy::HardCbs<_>::tick>:
    40204420:	d10203ff 	sub	sp, sp, #0x80
    40204424:	a9027bfd 	stp	x29, x30, [sp, #32]
    40204428:	a9036ffc 	stp	x28, x27, [sp, #48]
    4020442c:	a90467fa 	stp	x26, x25, [sp, #64]
    40204430:	a9055ff8 	stp	x24, x23, [sp, #80]
    40204434:	a90657f6 	stp	x22, x21, [sp, #96]
    40204438:	a9074ff4 	stp	x20, x19, [sp, #112]
    4020443c:	aa0803f3 	mov	x19, x8
    40204440:	f940181b 	ldr	x27, [x0, #48]
    40204444:	b100077a 	adds	x26, x27, #0x1
    40204448:	540000a3 	b.cc	4020445c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x3c>  // b.lo, b.ul, b.last
    4020444c:	aa1f03f4 	mov	x20, xzr
    40204450:	52800037 	mov	w23, #0x1                   	// #1
    40204454:	52800089 	mov	w9, #0x4                   	// #4
    40204458:	1400003e 	b	40204550 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    4020445c:	aa0003f5 	mov	x21, x0
    40204460:	2a1f03fc 	mov	w28, wzr
    40204464:	aa1f03e8 	mov	x8, xzr
    40204468:	aa1f03fd 	mov	x29, xzr
    4020446c:	91005018 	add	x24, x0, #0x14
    40204470:	52800037 	mov	w23, #0x1                   	// #1
    40204474:	910063bd 	add	x29, x29, #0x18
    40204478:	aa0803f6 	mov	x22, x8
    4020447c:	8b1d0308 	add	x8, x24, x29
    40204480:	b85e8108 	ldur	w8, [x8, #-24]
    40204484:	340000e8 	cbz	w8, 402044a0 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x80>
    40204488:	910023e8 	add	x8, sp, #0x8
    4020448c:	aa1503e0 	mov	x0, x21
    40204490:	aa1603e1 	mov	x1, x22
    40204494:	94000067 	bl	40204630 <jnox_kernel::temporal_policy::HardCbs<_>::available>
    40204498:	f94007e8 	ldr	x8, [sp, #8]
    4020449c:	b50000c8 	cbnz	x8, 402044b4 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x94>
    402044a0:	910063bd 	add	x29, x29, #0x18
    402044a4:	910006d6 	add	x22, x22, #0x1
    402044a8:	f10123bf 	cmp	x29, #0x48
    402044ac:	54fffe81 	b.ne	4020447c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x5c>  // b.any
    402044b0:	14000014 	b	40204500 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0xe0>
    402044b4:	f100091f 	cmp	x8, #0x2
    402044b8:	a9412be9 	ldp	x9, x10, [sp, #16]
    402044bc:	54000400 	b.eq	4020453c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x11c>  // b.none
    402044c0:	eb1b015f 	cmp	x10, x27
    402044c4:	540005a9 	b.ls	40204578 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x158>  // b.plast
    402044c8:	910006c8 	add	x8, x22, #0x1
    402044cc:	eb19015f 	cmp	x10, x25
    402044d0:	1a9f37eb 	cset	w11, cs  // cs = hs, nlast
    402044d4:	6a0b039f 	tst	w28, w11
    402044d8:	9a961294 	csel	x20, x20, x22, ne  // ne = any
    402044dc:	9a8a1339 	csel	x25, x25, x10, ne  // ne = any
    402044e0:	b94007ea 	ldr	w10, [sp, #4]
    402044e4:	1a89114a 	csel	w10, w10, w9, ne  // ne = any
    402044e8:	b90007ea 	str	w10, [sp, #4]
    402044ec:	5280003c 	mov	w28, #0x1                   	// #1
    402044f0:	f100c3bf 	cmp	x29, #0x30
    402044f4:	54fffc01 	b.ne	40204474 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x54>  // b.any
    402044f8:	f9001aba 	str	x26, [x21, #48]
    402044fc:	14000003 	b	40204508 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0xe8>
    40204500:	f9001aba 	str	x26, [x21, #48]
    40204504:	3600023c 	tbz	w28, #0, 40204548 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x128>
    40204508:	f1000a9f 	cmp	x20, #0x2
    4020450c:	540003c2 	b.cs	40204584 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x164>  // b.hs, b.nlast
    40204510:	aa1f03f7 	mov	x23, xzr
    40204514:	52800308 	mov	w8, #0x18                  	// #24
    40204518:	9b085688 	madd	x8, x20, x8, x21
    4020451c:	f9000119 	str	x25, [x8]
    40204520:	b94007e9 	ldr	w9, [sp, #4]
    40204524:	51000529 	sub	w9, w9, #0x1
    40204528:	b940150a 	ldr	w10, [x8, #20]
    4020452c:	5100054a 	sub	w10, w10, #0x1
    40204530:	29022909 	stp	w9, w10, [x8, #16]
    40204534:	52800029 	mov	w9, #0x1                   	// #1
    40204538:	14000006 	b	40204550 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    4020453c:	52800037 	mov	w23, #0x1                   	// #1
    40204540:	aa0a03f4 	mov	x20, x10
    40204544:	14000003 	b	40204550 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    40204548:	aa1f03e9 	mov	x9, xzr
    4020454c:	aa1f03f7 	mov	x23, xzr
    40204550:	a900d269 	stp	x9, x20, [x19, #8]
    40204554:	f9000277 	str	x23, [x19]
    40204558:	a9474ff4 	ldp	x20, x19, [sp, #112]
    4020455c:	a94657f6 	ldp	x22, x21, [sp, #96]
    40204560:	a9455ff8 	ldp	x24, x23, [sp, #80]
    40204564:	a94467fa 	ldp	x26, x25, [sp, #64]
    40204568:	a9436ffc 	ldp	x28, x27, [sp, #48]
    4020456c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40204570:	910203ff 	add	sp, sp, #0x80
    40204574:	d65f03c0 	ret
    40204578:	52800069 	mov	w9, #0x3                   	// #3
    4020457c:	aa1603f4 	mov	x20, x22
    40204580:	17fffff4 	b	40204550 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    40204584:	d503201f 	nop
    40204588:	1000d582 	adr	x2, 40206038 <anon.2d5d436b87d2a0d6f444a14986a49844.5.llvm.6392299720734326547>
    4020458c:	aa1403e0 	mov	x0, x20
    40204590:	52800041 	mov	w1, #0x2                   	// #2
    40204594:	940001de 	bl	40204d0c <core::panicking::panic_bounds_check>

0000000040204598 <jnox_kernel::temporal_policy::HardCbs<_>::release>:
    40204598:	f100043f 	cmp	x1, #0x1
    4020459c:	54000089 	b.ls	402045ac <jnox_kernel::temporal_policy::HardCbs<_>::release+0x14>  // b.plast
    402045a0:	aa1f03e1 	mov	x1, xzr
    402045a4:	aa1f03e0 	mov	x0, xzr
    402045a8:	d65f03c0 	ret
    402045ac:	340000e2 	cbz	w2, 402045c8 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x30>
    402045b0:	52800308 	mov	w8, #0x18                  	// #24
    402045b4:	9b080028 	madd	x8, x1, x8, x0
    402045b8:	b9401509 	ldr	w9, [x8, #20]
    402045bc:	340000a9 	cbz	w9, 402045d0 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x38>
    402045c0:	52800040 	mov	w0, #0x2                   	// #2
    402045c4:	d65f03c0 	ret
    402045c8:	52800020 	mov	w0, #0x1                   	// #1
    402045cc:	d65f03c0 	ret
    402045d0:	f940010a 	ldr	x10, [x8]
    402045d4:	f9401809 	ldr	x9, [x0, #48]
    402045d8:	eb09014b 	subs	x11, x10, x9
    402045dc:	54000149 	b.ls	40204604 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x6c>  // b.plast
    402045e0:	2941b10a 	ldp	w10, w12, [x8, #12]
    402045e4:	b940090d 	ldr	w13, [x8, #8]
    402045e8:	9bac7d4c 	umull	x12, w10, w12
    402045ec:	9bcb7dae 	umulh	x14, x13, x11
    402045f0:	9b0b7dab 	mul	x11, x13, x11
    402045f4:	eb0c017f 	cmp	x11, x12
    402045f8:	fa1f01df 	sbcs	xzr, x14, xzr
    402045fc:	54000063 	b.cc	40204608 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x70>  // b.lo, b.ul, b.last
    40204600:	14000009 	b	40204624 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x8c>
    40204604:	b9400d0a 	ldr	w10, [x8, #12]
    40204608:	ab2a4121 	adds	x1, x9, w10, uxtw
    4020460c:	54000063 	b.cc	40204618 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x80>  // b.lo, b.ul, b.last
    40204610:	52800080 	mov	w0, #0x4                   	// #4
    40204614:	d65f03c0 	ret
    40204618:	f9000101 	str	x1, [x8]
    4020461c:	b9400909 	ldr	w9, [x8, #8]
    40204620:	b9001109 	str	w9, [x8, #16]
    40204624:	b9001502 	str	w2, [x8, #20]
    40204628:	528000a0 	mov	w0, #0x5                   	// #5
    4020462c:	d65f03c0 	ret

0000000040204630 <jnox_kernel::temporal_policy::HardCbs<_>::available>:
    40204630:	f100083f 	cmp	x1, #0x2
    40204634:	540000a3 	b.cc	40204648 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x18>  // b.lo, b.ul, b.last
    40204638:	a900fd1f 	stp	xzr, xzr, [x8, #8]
    4020463c:	52800049 	mov	w9, #0x2                   	// #2
    40204640:	f9000109 	str	x9, [x8]
    40204644:	d65f03c0 	ret
    40204648:	52800309 	mov	w9, #0x18                  	// #24
    4020464c:	9b090029 	madd	x9, x1, x9, x0
    40204650:	b940152a 	ldr	w10, [x9, #20]
    40204654:	340001aa 	cbz	w10, 40204688 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x58>
    40204658:	b940112a 	ldr	w10, [x9, #16]
    4020465c:	340000ea 	cbz	w10, 40204678 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x48>
    40204660:	5280002b 	mov	w11, #0x1                   	// #1
    40204664:	f900010b 	str	x11, [x8]
    40204668:	f9400129 	ldr	x9, [x9]
    4020466c:	b900090a 	str	w10, [x8, #8]
    40204670:	f9000909 	str	x9, [x8, #16]
    40204674:	d65f03c0 	ret
    40204678:	f940180b 	ldr	x11, [x0, #48]
    4020467c:	f940012a 	ldr	x10, [x9]
    40204680:	eb0a017f 	cmp	x11, x10
    40204684:	54000062 	b.cs	40204690 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x60>  // b.hs, b.nlast
    40204688:	f900011f 	str	xzr, [x8]
    4020468c:	d65f03c0 	ret
    40204690:	b9400d2b 	ldr	w11, [x9, #12]
    40204694:	ab0b014a 	adds	x10, x10, x11
    40204698:	540000c3 	b.cc	402046b0 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x80>  // b.lo, b.ul, b.last
    4020469c:	52800089 	mov	w9, #0x4                   	// #4
    402046a0:	a900a909 	stp	x9, x10, [x8, #8]
    402046a4:	5280004a 	mov	w10, #0x2                   	// #2
    402046a8:	f900010a 	str	x10, [x8]
    402046ac:	d65f03c0 	ret
    402046b0:	5280002b 	mov	w11, #0x1                   	// #1
    402046b4:	f900010b 	str	x11, [x8]
    402046b8:	b9400929 	ldr	w9, [x9, #8]
    402046bc:	b9000909 	str	w9, [x8, #8]
    402046c0:	f900090a 	str	x10, [x8, #16]
    402046c4:	d65f03c0 	ret

00000000402046c8 <jnox_kernel::temporal_policy::admit_reservations>:
    402046c8:	f81b0ffe 	str	x30, [sp, #-80]!
    402046cc:	a90167fa 	stp	x26, x25, [sp, #16]
    402046d0:	a9025ff8 	stp	x24, x23, [sp, #32]
    402046d4:	a90357f6 	stp	x22, x21, [sp, #48]
    402046d8:	a9044ff4 	stp	x20, x19, [sp, #64]
    402046dc:	b4000721 	cbz	x1, 402047c0 <jnox_kernel::temporal_policy::admit_reservations+0xf8>
    402046e0:	aa0003f3 	mov	x19, x0
    402046e4:	aa1f03f6 	mov	x22, xzr
    402046e8:	8b010c1a 	add	x26, x0, x1, lsl #3
    402046ec:	52800020 	mov	w0, #0x1                   	// #1
    402046f0:	29402269 	ldp	w9, w8, [x19]
    402046f4:	5100052a 	sub	w10, w9, #0x1
    402046f8:	6b08015f 	cmp	w10, w8
    402046fc:	540006a2 	b.cs	402047d0 <jnox_kernel::temporal_policy::admit_reservations+0x108>  // b.hs, b.nlast
    40204700:	9bd67d0a 	umulh	x10, x8, x22
    40204704:	9b167d0b 	mul	x11, x8, x22
    40204708:	9bc07d2c 	umulh	x12, x9, x0
    4020470c:	9b007d29 	mul	x9, x9, x0
    40204710:	ab090176 	adds	x22, x11, x9
    40204714:	9a0c0157 	adc	x23, x10, x12
    40204718:	9bc07d14 	umulh	x20, x8, x0
    4020471c:	9b007d15 	mul	x21, x8, x0
    40204720:	eb1602bf 	cmp	x21, x22
    40204724:	fa17029f 	sbcs	xzr, x20, x23
    40204728:	54000583 	b.cc	402047d8 <jnox_kernel::temporal_policy::admit_reservations+0x110>  // b.lo, b.ul, b.last
    4020472c:	b4000220 	cbz	x0, 40204770 <jnox_kernel::temporal_policy::admit_reservations+0xa8>
    40204730:	aa1603e0 	mov	x0, x22
    40204734:	aa1703e1 	mov	x1, x23
    40204738:	aa1503e8 	mov	x8, x21
    4020473c:	aa1403e9 	mov	x9, x20
    40204740:	aa0903f8 	mov	x24, x9
    40204744:	aa0803f9 	mov	x25, x8
    40204748:	aa0803e2 	mov	x2, x8
    4020474c:	aa0903e3 	mov	x3, x9
    40204750:	94000542 	bl	40205c58 <__umodti3>
    40204754:	aa0003e8 	mov	x8, x0
    40204758:	aa0103e9 	mov	x9, x1
    4020475c:	aa01000a 	orr	x10, x0, x1
    40204760:	aa1903e0 	mov	x0, x25
    40204764:	aa1803e1 	mov	x1, x24
    40204768:	b5fffeca 	cbnz	x10, 40204740 <jnox_kernel::temporal_policy::admit_reservations+0x78>
    4020476c:	14000005 	b	40204780 <jnox_kernel::temporal_policy::admit_reservations+0xb8>
    40204770:	aa1702c8 	orr	x8, x22, x23
    40204774:	aa1603f9 	mov	x25, x22
    40204778:	aa1703f8 	mov	x24, x23
    4020477c:	b40003c8 	cbz	x8, 402047f4 <jnox_kernel::temporal_policy::admit_reservations+0x12c>
    40204780:	aa1603e0 	mov	x0, x22
    40204784:	aa1703e1 	mov	x1, x23
    40204788:	aa1903e2 	mov	x2, x25
    4020478c:	aa1803e3 	mov	x3, x24
    40204790:	940003e3 	bl	4020571c <__udivti3>
    40204794:	b50001a1 	cbnz	x1, 402047c8 <jnox_kernel::temporal_policy::admit_reservations+0x100>
    40204798:	aa0003f6 	mov	x22, x0
    4020479c:	aa1503e0 	mov	x0, x21
    402047a0:	aa1403e1 	mov	x1, x20
    402047a4:	aa1903e2 	mov	x2, x25
    402047a8:	aa1803e3 	mov	x3, x24
    402047ac:	940003dc 	bl	4020571c <__udivti3>
    402047b0:	b50000c1 	cbnz	x1, 402047c8 <jnox_kernel::temporal_policy::admit_reservations+0x100>
    402047b4:	91002273 	add	x19, x19, #0x8
    402047b8:	eb1a027f 	cmp	x19, x26
    402047bc:	54fff9a1 	b.ne	402046f0 <jnox_kernel::temporal_policy::admit_reservations+0x28>  // b.any
    402047c0:	52800060 	mov	w0, #0x3                   	// #3
    402047c4:	14000006 	b	402047dc <jnox_kernel::temporal_policy::admit_reservations+0x114>
    402047c8:	52800040 	mov	w0, #0x2                   	// #2
    402047cc:	14000004 	b	402047dc <jnox_kernel::temporal_policy::admit_reservations+0x114>
    402047d0:	2a1f03e0 	mov	w0, wzr
    402047d4:	14000002 	b	402047dc <jnox_kernel::temporal_policy::admit_reservations+0x114>
    402047d8:	52800020 	mov	w0, #0x1                   	// #1
    402047dc:	a9444ff4 	ldp	x20, x19, [sp, #64]
    402047e0:	a94357f6 	ldp	x22, x21, [sp, #48]
    402047e4:	a9425ff8 	ldp	x24, x23, [sp, #32]
    402047e8:	a94167fa 	ldp	x26, x25, [sp, #16]
    402047ec:	f84507fe 	ldr	x30, [sp], #80
    402047f0:	d65f03c0 	ret
    402047f4:	d503201f 	nop
    402047f8:	1000c2c0 	adr	x0, 40206050 <anon.2d5d436b87d2a0d6f444a14986a49844.6.llvm.6392299720734326547>
    402047fc:	94000343 	bl	40205508 <core::panicking::panic_const::panic_const_div_by_zero>

0000000040204800 <jnox_kernel::context::init_timer_irq>:
    40204800:	d503201f 	nop
    40204804:	10fdffe8 	adr	x8, 40200800 <sched_vectors>
    40204808:	d518c008 	msr	vbar_el1, x8
    4020480c:	d51be23f 	msr	cntp_ctl_el0, xzr
    40204810:	d5033fdf 	isb
    40204814:	52a10008 	mov	w8, #0x8000000             	// #134217728
    40204818:	b900011f 	str	wzr, [x8]
    4020481c:	52a10029 	mov	w9, #0x8010000             	// #134283264
    40204820:	b900013f 	str	wzr, [x9]
    40204824:	5280100a 	mov	w10, #0x80                  	// #128
    40204828:	72a1000a 	movk	w10, #0x800, lsl #16
    4020482c:	b940014b 	ldr	w11, [x10]
    40204830:	1201796b 	and	w11, w11, #0xbfffffff
    40204834:	b900014b 	str	w11, [x10]
    40204838:	5280100b 	mov	w11, #0x80                  	// #128
    4020483c:	390e794b 	strb	w11, [x10, #926]
    40204840:	52a8000b 	mov	w11, #0x40000000            	// #1073741824
    40204844:	b902014b 	str	w11, [x10, #512]
    40204848:	b900814b 	str	w11, [x10, #128]
    4020484c:	5280008a 	mov	w10, #0x4                   	// #4
    40204850:	72a1002a 	movk	w10, #0x801, lsl #16
    40204854:	52801feb 	mov	w11, #0xff                  	// #255
    40204858:	b900014b 	str	w11, [x10]
    4020485c:	5280002a 	mov	w10, #0x1                   	// #1
    40204860:	b900010a 	str	w10, [x8]
    40204864:	b900012a 	str	w10, [x9]
    40204868:	d5033f9f 	dsb	sy
    4020486c:	d5033fdf 	isb
    40204870:	d65f03c0 	ret

0000000040204874 <<core::fmt::Formatter>::pad_integral>:
    40204874:	d101c3ff 	sub	sp, sp, #0x70
    40204878:	a9017bfd 	stp	x29, x30, [sp, #16]
    4020487c:	a9026ffc 	stp	x28, x27, [sp, #32]
    40204880:	a90367fa 	stp	x26, x25, [sp, #48]
    40204884:	a9045ff8 	stp	x24, x23, [sp, #64]
    40204888:	a90557f6 	stp	x22, x21, [sp, #80]
    4020488c:	a9064ff4 	stp	x20, x19, [sp, #96]
    40204890:	910043fd 	add	x29, sp, #0x10
    40204894:	b940101a 	ldr	w26, [x0, #16]
    40204898:	52a00229 	mov	w9, #0x110000              	// #1114112
    4020489c:	aa0503f3 	mov	x19, x5
    402048a0:	aa0403fc 	mov	x28, x4
    402048a4:	aa0303f6 	mov	x22, x3
    402048a8:	aa0003f5 	mov	x21, x0
    402048ac:	926b0348 	and	x8, x26, #0x200000
    402048b0:	d355574a 	ubfx	x10, x26, #21, #1
    402048b4:	7100011f 	cmp	w8, #0x0
    402048b8:	52800568 	mov	w8, #0x2b                  	// #43
    402048bc:	1a880128 	csel	w8, w9, w8, eq  // eq = none
    402048c0:	7100003f 	cmp	w1, #0x0
    402048c4:	528005a9 	mov	w9, #0x2d                  	// #45
    402048c8:	9a9f154a 	csinc	x10, x10, xzr, ne  // ne = any
    402048cc:	1a891118 	csel	w24, w8, w9, ne  // ne = any
    402048d0:	8b05015b 	add	x27, x10, x5
    402048d4:	37b8033a 	tbnz	w26, #23, 40204938 <<core::fmt::Formatter>::pad_integral+0xc4>
    402048d8:	aa1f03f7 	mov	x23, xzr
    402048dc:	79402ab4 	ldrh	w20, [x21, #20]
    402048e0:	eb14037f 	cmp	x27, x20
    402048e4:	54001503 	b.cc	40204b84 <<core::fmt::Formatter>::pad_integral+0x310>  // b.lo, b.ul, b.last
    402048e8:	a94056b9 	ldp	x25, x21, [x21]
    402048ec:	2a1803e2 	mov	w2, w24
    402048f0:	aa1703e3 	mov	x3, x23
    402048f4:	aa1603e4 	mov	x4, x22
    402048f8:	aa1903e0 	mov	x0, x25
    402048fc:	aa1503e1 	mov	x1, x21
    40204900:	94000310 	bl	40205540 <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204904:	37001d60 	tbnz	w0, #0, 40204cb0 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204908:	f9400ea3 	ldr	x3, [x21, #24]
    4020490c:	aa1903e0 	mov	x0, x25
    40204910:	aa1c03e1 	mov	x1, x28
    40204914:	aa1303e2 	mov	x2, x19
    40204918:	a9464ff4 	ldp	x20, x19, [sp, #96]
    4020491c:	a94557f6 	ldp	x22, x21, [sp, #80]
    40204920:	a9445ff8 	ldp	x24, x23, [sp, #64]
    40204924:	a94367fa 	ldp	x26, x25, [sp, #48]
    40204928:	a9426ffc 	ldp	x28, x27, [sp, #32]
    4020492c:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40204930:	9101c3ff 	add	sp, sp, #0x70
    40204934:	d61f0060 	br	x3
    40204938:	aa0203f7 	mov	x23, x2
    4020493c:	f10082df 	cmp	x22, #0x20
    40204940:	540000e2 	b.cs	4020495c <<core::fmt::Formatter>::pad_integral+0xe8>  // b.hs, b.nlast
    40204944:	b4000156 	cbz	x22, 4020496c <<core::fmt::Formatter>::pad_integral+0xf8>
    40204948:	f10022df 	cmp	x22, #0x8
    4020494c:	54000142 	b.cs	40204974 <<core::fmt::Formatter>::pad_integral+0x100>  // b.hs, b.nlast
    40204950:	aa1f03e8 	mov	x8, xzr
    40204954:	aa1f03e0 	mov	x0, xzr
    40204958:	14000080 	b	40204b58 <<core::fmt::Formatter>::pad_integral+0x2e4>
    4020495c:	aa1703e0 	mov	x0, x23
    40204960:	aa1603e1 	mov	x1, x22
    40204964:	94000102 	bl	40204d6c <core::str::count::do_count_chars>
    40204968:	14000083 	b	40204b74 <<core::fmt::Formatter>::pad_integral+0x300>
    4020496c:	aa1f03e0 	mov	x0, xzr
    40204970:	14000081 	b	40204b74 <<core::fmt::Formatter>::pad_integral+0x300>
    40204974:	aa1703ea 	mov	x10, x23
    40204978:	39400ae9 	ldrb	w9, [x23, #2]
    4020497c:	394006e8 	ldrb	w8, [x23, #1]
    40204980:	38404d4b 	ldrb	w11, [x10, #4]!
    40204984:	3940094c 	ldrb	w12, [x10, #2]
    40204988:	394002ed 	ldrb	w13, [x23]
    4020498c:	39400eee 	ldrb	w14, [x23, #3]
    40204990:	d370bd29 	lsl	x9, x9, #16
    40204994:	394016ef 	ldrb	w15, [x23, #5]
    40204998:	39400d4a 	ldrb	w10, [x10, #3]
    4020499c:	53103d8c 	lsl	w12, w12, #16
    402049a0:	aa0821a8 	orr	x8, x13, x8, lsl #8
    402049a4:	aa0e6129 	orr	x9, x9, x14, lsl #24
    402049a8:	0f05e7e4 	movi	v4.8b, #0xbf
    402049ac:	2a0f216b 	orr	w11, w11, w15, lsl #8
    402049b0:	2a0a618a 	orr	w10, w12, w10, lsl #24
    402049b4:	aa080128 	orr	x8, x9, x8
    402049b8:	2a0b0149 	orr	w9, w10, w11
    402049bc:	aa098108 	orr	x8, x8, x9, lsl #32
    402049c0:	9e670100 	fmov	d0, x8
    402049c4:	52800028 	mov	w8, #0x1                   	// #1
    402049c8:	4e080d03 	dup	v3.2d, x8
    402049cc:	927d06c8 	and	x8, x22, #0x18
    402049d0:	f100211f 	cmp	x8, #0x8
    402049d4:	0e243400 	cmgt	v0.8b, v0.8b, v4.8b
    402049d8:	2f08a400 	uxtl	v0.8h, v0.8b
    402049dc:	6f10a401 	uxtl2	v1.4s, v0.8h
    402049e0:	2f10a400 	uxtl	v0.4s, v0.4h
    402049e4:	6f20a422 	uxtl2	v2.2d, v1.4s
    402049e8:	2f20a421 	uxtl	v1.2d, v1.2s
    402049ec:	6f20a405 	uxtl2	v5.2d, v0.4s
    402049f0:	2f20a406 	uxtl	v6.2d, v0.2s
    402049f4:	4e231c40 	and	v0.16b, v2.16b, v3.16b
    402049f8:	4e231c22 	and	v2.16b, v1.16b, v3.16b
    402049fc:	4e231ca1 	and	v1.16b, v5.16b, v3.16b
    40204a00:	4e231cc3 	and	v3.16b, v6.16b, v3.16b
    40204a04:	540009c0 	b.eq	40204b3c <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    40204a08:	aa1703e9 	mov	x9, x23
    40204a0c:	f100411f 	cmp	x8, #0x10
    40204a10:	38408d2a 	ldrb	w10, [x9, #8]!
    40204a14:	3940052b 	ldrb	w11, [x9, #1]
    40204a18:	39400d2c 	ldrb	w12, [x9, #3]
    40204a1c:	3940092d 	ldrb	w13, [x9, #2]
    40204a20:	3940152e 	ldrb	w14, [x9, #5]
    40204a24:	38404d2f 	ldrb	w15, [x9, #4]!
    40204a28:	39400930 	ldrb	w16, [x9, #2]
    40204a2c:	39400d29 	ldrb	w9, [x9, #3]
    40204a30:	d370bdad 	lsl	x13, x13, #16
    40204a34:	aa0b214a 	orr	x10, x10, x11, lsl #8
    40204a38:	53103e10 	lsl	w16, w16, #16
    40204a3c:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40204a40:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40204a44:	2a096209 	orr	w9, w16, w9, lsl #24
    40204a48:	aa0a018a 	orr	x10, x12, x10
    40204a4c:	2a0b0129 	orr	w9, w9, w11
    40204a50:	aa098149 	orr	x9, x10, x9, lsl #32
    40204a54:	9e670125 	fmov	d5, x9
    40204a58:	52800029 	mov	w9, #0x1                   	// #1
    40204a5c:	4e080d26 	dup	v6.2d, x9
    40204a60:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40204a64:	2f08a484 	uxtl	v4.8h, v4.8b
    40204a68:	6f10a485 	uxtl2	v5.4s, v4.8h
    40204a6c:	2f10a484 	uxtl	v4.4s, v4.4h
    40204a70:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40204a74:	2f20a490 	uxtl	v16.2d, v4.2s
    40204a78:	6f20a484 	uxtl2	v4.2d, v4.4s
    40204a7c:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40204a80:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40204a84:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40204a88:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40204a8c:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40204a90:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40204a94:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40204a98:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40204a9c:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40204aa0:	540004e0 	b.eq	40204b3c <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    40204aa4:	aa1703e9 	mov	x9, x23
    40204aa8:	0f05e7e4 	movi	v4.8b, #0xbf
    40204aac:	38410d2a 	ldrb	w10, [x9, #16]!
    40204ab0:	3940052b 	ldrb	w11, [x9, #1]
    40204ab4:	39400d2c 	ldrb	w12, [x9, #3]
    40204ab8:	3940092d 	ldrb	w13, [x9, #2]
    40204abc:	3940152e 	ldrb	w14, [x9, #5]
    40204ac0:	38404d2f 	ldrb	w15, [x9, #4]!
    40204ac4:	39400930 	ldrb	w16, [x9, #2]
    40204ac8:	39400d29 	ldrb	w9, [x9, #3]
    40204acc:	d370bdad 	lsl	x13, x13, #16
    40204ad0:	aa0b214a 	orr	x10, x10, x11, lsl #8
    40204ad4:	53103e10 	lsl	w16, w16, #16
    40204ad8:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40204adc:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40204ae0:	2a096209 	orr	w9, w16, w9, lsl #24
    40204ae4:	aa0a018a 	orr	x10, x12, x10
    40204ae8:	2a0b0129 	orr	w9, w9, w11
    40204aec:	aa098149 	orr	x9, x10, x9, lsl #32
    40204af0:	9e670125 	fmov	d5, x9
    40204af4:	52800029 	mov	w9, #0x1                   	// #1
    40204af8:	4e080d26 	dup	v6.2d, x9
    40204afc:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40204b00:	2f08a484 	uxtl	v4.8h, v4.8b
    40204b04:	6f10a485 	uxtl2	v5.4s, v4.8h
    40204b08:	2f10a484 	uxtl	v4.4s, v4.4h
    40204b0c:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40204b10:	2f20a490 	uxtl	v16.2d, v4.2s
    40204b14:	6f20a484 	uxtl2	v4.2d, v4.4s
    40204b18:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40204b1c:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40204b20:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40204b24:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40204b28:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40204b2c:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40204b30:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40204b34:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40204b38:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40204b3c:	4ee28462 	add	v2.2d, v3.2d, v2.2d
    40204b40:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    40204b44:	eb0802df 	cmp	x22, x8
    40204b48:	4ee08440 	add	v0.2d, v2.2d, v0.2d
    40204b4c:	5ef1b800 	addp	d0, v0.2d
    40204b50:	9e660000 	fmov	x0, d0
    40204b54:	54000100 	b.eq	40204b74 <<core::fmt::Formatter>::pad_integral+0x300>  // b.none
    40204b58:	cb0802c9 	sub	x9, x22, x8
    40204b5c:	8b0802e8 	add	x8, x23, x8
    40204b60:	38c0150a 	ldrsb	w10, [x8], #1
    40204b64:	3101055f 	cmn	w10, #0x41
    40204b68:	9a80d400 	cinc	x0, x0, gt
    40204b6c:	f1000529 	subs	x9, x9, #0x1
    40204b70:	54ffff81 	b.ne	40204b60 <<core::fmt::Formatter>::pad_integral+0x2ec>  // b.any
    40204b74:	8b1b001b 	add	x27, x0, x27
    40204b78:	79402ab4 	ldrh	w20, [x21, #20]
    40204b7c:	eb14037f 	cmp	x27, x20
    40204b80:	54ffeb42 	b.cs	402048e8 <<core::fmt::Formatter>::pad_integral+0x74>  // b.hs, b.nlast
    40204b84:	f90007fc 	str	x28, [sp, #8]
    40204b88:	37c0011a 	tbnz	w26, #24, 40204ba8 <<core::fmt::Formatter>::pad_integral+0x334>
    40204b8c:	531d7b48 	ubfx	w8, w26, #29, #2
    40204b90:	4b1b029b 	sub	w27, w20, w27
    40204b94:	7100051f 	cmp	w8, #0x1
    40204b98:	540003cc 	b.gt	40204c10 <<core::fmt::Formatter>::pad_integral+0x39c>
    40204b9c:	35000568 	cbnz	w8, 40204c48 <<core::fmt::Formatter>::pad_integral+0x3d4>
    40204ba0:	2a1f03fc 	mov	w28, wzr
    40204ba4:	1400002a 	b	40204c4c <<core::fmt::Formatter>::pad_integral+0x3d8>
    40204ba8:	a940f2ba 	ldp	x26, x28, [x21, #8]
    40204bac:	52b3fc08 	mov	w8, #0x9fe00000            	// #-1612709888
    40204bb0:	f94002b9 	ldr	x25, [x21]
    40204bb4:	2a1803e2 	mov	w2, w24
    40204bb8:	aa1703e3 	mov	x3, x23
    40204bbc:	aa1603e4 	mov	x4, x22
    40204bc0:	0a080388 	and	w8, w28, w8
    40204bc4:	aa1903e0 	mov	x0, x25
    40204bc8:	aa1a03e1 	mov	x1, x26
    40204bcc:	321c0508 	orr	w8, w8, #0x30
    40204bd0:	32030108 	orr	w8, w8, #0x20000000
    40204bd4:	b90012a8 	str	w8, [x21, #16]
    40204bd8:	9400025a 	bl	40205540 <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204bdc:	370006a0 	tbnz	w0, #0, 40204cb0 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204be0:	2a1f03f6 	mov	w22, wzr
    40204be4:	4b1b0294 	sub	w20, w20, w27
    40204be8:	12003ec8 	and	w8, w22, #0xffff
    40204bec:	6b34211f 	cmp	w8, w20, uxth
    40204bf0:	540001a2 	b.cs	40204c24 <<core::fmt::Formatter>::pad_integral+0x3b0>  // b.hs, b.nlast
    40204bf4:	f9401348 	ldr	x8, [x26, #32]
    40204bf8:	aa1903e0 	mov	x0, x25
    40204bfc:	52800601 	mov	w1, #0x30                  	// #48
    40204c00:	110006d6 	add	w22, w22, #0x1
    40204c04:	d63f0100 	blr	x8
    40204c08:	3607ff00 	tbz	w0, #0, 40204be8 <<core::fmt::Formatter>::pad_integral+0x374>
    40204c0c:	14000029 	b	40204cb0 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204c10:	7100091f 	cmp	w8, #0x2
    40204c14:	2a1b03fc 	mov	w28, w27
    40204c18:	540001a1 	b.ne	40204c4c <<core::fmt::Formatter>::pad_integral+0x3d8>  // b.any
    40204c1c:	53013f7c 	ubfx	w28, w27, #1, #15
    40204c20:	1400000b 	b	40204c4c <<core::fmt::Formatter>::pad_integral+0x3d8>
    40204c24:	f9400f48 	ldr	x8, [x26, #24]
    40204c28:	f94007e1 	ldr	x1, [sp, #8]
    40204c2c:	aa1903e0 	mov	x0, x25
    40204c30:	aa1303e2 	mov	x2, x19
    40204c34:	d63f0100 	blr	x8
    40204c38:	370003c0 	tbnz	w0, #0, 40204cb0 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204c3c:	2a1f03f3 	mov	w19, wzr
    40204c40:	f9000abc 	str	x28, [x21, #16]
    40204c44:	1400001c 	b	40204cb4 <<core::fmt::Formatter>::pad_integral+0x440>
    40204c48:	2a1b03fc 	mov	w28, w27
    40204c4c:	a94056b9 	ldp	x25, x21, [x21]
    40204c50:	2a1f03f4 	mov	w20, wzr
    40204c54:	12003e88 	and	w8, w20, #0xffff
    40204c58:	6b3c211f 	cmp	w8, w28, uxth
    40204c5c:	54000102 	b.cs	40204c7c <<core::fmt::Formatter>::pad_integral+0x408>  // b.hs, b.nlast
    40204c60:	f94012a8 	ldr	x8, [x21, #32]
    40204c64:	12005341 	and	w1, w26, #0x1fffff
    40204c68:	aa1903e0 	mov	x0, x25
    40204c6c:	11000694 	add	w20, w20, #0x1
    40204c70:	d63f0100 	blr	x8
    40204c74:	3607ff00 	tbz	w0, #0, 40204c54 <<core::fmt::Formatter>::pad_integral+0x3e0>
    40204c78:	1400000e 	b	40204cb0 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204c7c:	aa1903e0 	mov	x0, x25
    40204c80:	aa1503e1 	mov	x1, x21
    40204c84:	2a1803e2 	mov	w2, w24
    40204c88:	aa1703e3 	mov	x3, x23
    40204c8c:	aa1603e4 	mov	x4, x22
    40204c90:	9400022c 	bl	40205540 <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204c94:	370000e0 	tbnz	w0, #0, 40204cb0 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204c98:	f9400ea8 	ldr	x8, [x21, #24]
    40204c9c:	f94007e1 	ldr	x1, [sp, #8]
    40204ca0:	aa1903e0 	mov	x0, x25
    40204ca4:	aa1303e2 	mov	x2, x19
    40204ca8:	d63f0100 	blr	x8
    40204cac:	36000160 	tbz	w0, #0, 40204cd8 <<core::fmt::Formatter>::pad_integral+0x464>
    40204cb0:	52800033 	mov	w19, #0x1                   	// #1
    40204cb4:	2a1303e0 	mov	w0, w19
    40204cb8:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40204cbc:	a94557f6 	ldp	x22, x21, [sp, #80]
    40204cc0:	a9445ff8 	ldp	x24, x23, [sp, #64]
    40204cc4:	a94367fa 	ldp	x26, x25, [sp, #48]
    40204cc8:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40204ccc:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40204cd0:	9101c3ff 	add	sp, sp, #0x70
    40204cd4:	d65f03c0 	ret
    40204cd8:	2a1f03f4 	mov	w20, wzr
    40204cdc:	4b1c0376 	sub	w22, w27, w28
    40204ce0:	12003e88 	and	w8, w20, #0xffff
    40204ce4:	6b36211f 	cmp	w8, w22, uxth
    40204ce8:	1a9f27f3 	cset	w19, cc  // cc = lo, ul, last
    40204cec:	54fffe42 	b.cs	40204cb4 <<core::fmt::Formatter>::pad_integral+0x440>  // b.hs, b.nlast
    40204cf0:	f94012a8 	ldr	x8, [x21, #32]
    40204cf4:	12005341 	and	w1, w26, #0x1fffff
    40204cf8:	aa1903e0 	mov	x0, x25
    40204cfc:	11000694 	add	w20, w20, #0x1
    40204d00:	d63f0100 	blr	x8
    40204d04:	3607fee0 	tbz	w0, #0, 40204ce0 <<core::fmt::Formatter>::pad_integral+0x46c>
    40204d08:	17ffffeb 	b	40204cb4 <<core::fmt::Formatter>::pad_integral+0x440>

0000000040204d0c <core::panicking::panic_bounds_check>:
    40204d0c:	d10103ff 	sub	sp, sp, #0x40
    40204d10:	a9037bfd 	stp	x29, x30, [sp, #48]
    40204d14:	9100c3fd 	add	x29, sp, #0x30
    40204d18:	910023e8 	add	x8, sp, #0x8
    40204d1c:	d503201f 	nop
    40204d20:	10004549 	adr	x9, 402055c8 <<u64 as core::fmt::Display>::fmt>
    40204d24:	a90007e0 	stp	x0, x1, [sp]
    40204d28:	b0000000 	adrp	x0, 40205000 <core::str::count::do_count_chars+0x294>
    40204d2c:	9137f400 	add	x0, x0, #0xdfd
    40204d30:	a90127e8 	stp	x8, x9, [sp, #16]
    40204d34:	910003e8 	mov	x8, sp
    40204d38:	910043e1 	add	x1, sp, #0x10
    40204d3c:	a90227e8 	stp	x8, x9, [sp, #32]
    40204d40:	94000001 	bl	40204d44 <core::panicking::panic_fmt>

0000000040204d44 <core::panicking::panic_fmt>:
    40204d44:	d10103ff 	sub	sp, sp, #0x40
    40204d48:	a9037bfd 	stp	x29, x30, [sp, #48]
    40204d4c:	9100c3fd 	add	x29, sp, #0x30
    40204d50:	910023e8 	add	x8, sp, #0x8
    40204d54:	a90087e0 	stp	x0, x1, [sp, #8]
    40204d58:	910063e0 	add	x0, sp, #0x18
    40204d5c:	a9018be8 	stp	x8, x2, [sp, #24]
    40204d60:	52800028 	mov	w8, #0x1                   	// #1
    40204d64:	790053e8 	strh	w8, [sp, #40]
    40204d68:	97fffc92 	bl	40203fb0 <__rustc::rust_begin_unwind>

0000000040204d6c <core::str::count::do_count_chars>:
    40204d6c:	d10183ff 	sub	sp, sp, #0x60
    40204d70:	fd0023ea 	str	d10, [sp, #64]
    40204d74:	6d0523e9 	stp	d9, d8, [sp, #80]
    40204d78:	91001c08 	add	x8, x0, #0x7
    40204d7c:	927df10d 	and	x13, x8, #0xfffffffffffffff8
    40204d80:	cb0001ac 	sub	x12, x13, x0
    40204d84:	eb0c002b 	subs	x11, x1, x12
    40204d88:	540000e2 	b.cs	40204da4 <core::str::count::do_count_chars+0x38>  // b.hs, b.nlast
    40204d8c:	b4000721 	cbz	x1, 40204e70 <core::str::count::do_count_chars+0x104>
    40204d90:	f100203f 	cmp	x1, #0x8
    40204d94:	54001b82 	b.cs	40205104 <core::str::count::do_count_chars+0x398>  // b.hs, b.nlast
    40204d98:	aa1f03e9 	mov	x9, xzr
    40204d9c:	aa1f03e8 	mov	x8, xzr
    40204da0:	140001d2 	b	402054e8 <core::str::count::do_count_chars+0x77c>
    40204da4:	d343fd69 	lsr	x9, x11, #3
    40204da8:	b4ffff29 	cbz	x9, 40204d8c <core::str::count::do_count_chars+0x20>
    40204dac:	eb0001bf 	cmp	x13, x0
    40204db0:	9240096a 	and	x10, x11, #0x7
    40204db4:	aa1f03e8 	mov	x8, xzr
    40204db8:	54000100 	b.eq	40204dd8 <core::str::count::do_count_chars+0x6c>  // b.none
    40204dbc:	cb0d000d 	sub	x13, x0, x13
    40204dc0:	aa0003ee 	mov	x14, x0
    40204dc4:	38c015cf 	ldrsb	w15, [x14], #1
    40204dc8:	310105ff 	cmn	w15, #0x41
    40204dcc:	9a88d508 	cinc	x8, x8, gt
    40204dd0:	b10005ad 	adds	x13, x13, #0x1
    40204dd4:	54ffff83 	b.cc	40204dc4 <core::str::count::do_count_chars+0x58>  // b.lo, b.ul, b.last
    40204dd8:	8b0c000e 	add	x14, x0, x12
    40204ddc:	b400056a 	cbz	x10, 40204e88 <core::str::count::do_count_chars+0x11c>
    40204de0:	927ded6b 	and	x11, x11, #0x7ffffffffffffff8
    40204de4:	8b0b01cc 	add	x12, x14, x11
    40204de8:	39c0018b 	ldrsb	w11, [x12]
    40204dec:	3101057f 	cmn	w11, #0x41
    40204df0:	1a9fd7eb 	cset	w11, gt
    40204df4:	f100055f 	cmp	x10, #0x1
    40204df8:	540004a0 	b.eq	40204e8c <core::str::count::do_count_chars+0x120>  // b.none
    40204dfc:	39c0058d 	ldrsb	w13, [x12, #1]
    40204e00:	310105bf 	cmn	w13, #0x41
    40204e04:	9a8bd56b 	cinc	x11, x11, gt
    40204e08:	f100095f 	cmp	x10, #0x2
    40204e0c:	54000400 	b.eq	40204e8c <core::str::count::do_count_chars+0x120>  // b.none
    40204e10:	39c0098d 	ldrsb	w13, [x12, #2]
    40204e14:	310105bf 	cmn	w13, #0x41
    40204e18:	9a8bd56b 	cinc	x11, x11, gt
    40204e1c:	f1000d5f 	cmp	x10, #0x3
    40204e20:	54000360 	b.eq	40204e8c <core::str::count::do_count_chars+0x120>  // b.none
    40204e24:	39c00d8d 	ldrsb	w13, [x12, #3]
    40204e28:	310105bf 	cmn	w13, #0x41
    40204e2c:	9a8bd56b 	cinc	x11, x11, gt
    40204e30:	f100115f 	cmp	x10, #0x4
    40204e34:	540002c0 	b.eq	40204e8c <core::str::count::do_count_chars+0x120>  // b.none
    40204e38:	39c0118d 	ldrsb	w13, [x12, #4]
    40204e3c:	310105bf 	cmn	w13, #0x41
    40204e40:	9a8bd56b 	cinc	x11, x11, gt
    40204e44:	f100155f 	cmp	x10, #0x5
    40204e48:	54000220 	b.eq	40204e8c <core::str::count::do_count_chars+0x120>  // b.none
    40204e4c:	39c0158d 	ldrsb	w13, [x12, #5]
    40204e50:	310105bf 	cmn	w13, #0x41
    40204e54:	9a8bd56b 	cinc	x11, x11, gt
    40204e58:	f100195f 	cmp	x10, #0x6
    40204e5c:	54000180 	b.eq	40204e8c <core::str::count::do_count_chars+0x120>  // b.none
    40204e60:	39c0198a 	ldrsb	w10, [x12, #6]
    40204e64:	3101055f 	cmn	w10, #0x41
    40204e68:	9a8bd56b 	cinc	x11, x11, gt
    40204e6c:	14000008 	b	40204e8c <core::str::count::do_count_chars+0x120>
    40204e70:	aa1f03e8 	mov	x8, xzr
    40204e74:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40204e78:	aa0803e0 	mov	x0, x8
    40204e7c:	fd4023ea 	ldr	d10, [sp, #64]
    40204e80:	910183ff 	add	sp, sp, #0x60
    40204e84:	d65f03c0 	ret
    40204e88:	aa1f03eb 	mov	x11, xzr
    40204e8c:	4f00e420 	movi	v0.16b, #0x1
    40204e90:	8b080168 	add	x8, x11, x8
    40204e94:	5280180a 	mov	w10, #0xc0                  	// #192
    40204e98:	b20083eb 	mov	x11, #0x1000100010001       	// #281479271743489
    40204e9c:	1400000c 	b	40204ecc <core::str::count::do_count_chars+0x160>
    40204ea0:	aa1f03f1 	mov	x17, xzr
    40204ea4:	d348fe2f 	lsr	x15, x17, #8
    40204ea8:	92009e30 	and	x16, x17, #0xff00ff00ff00ff
    40204eac:	8b0e018e 	add	x14, x12, x14
    40204eb0:	cb0d0129 	sub	x9, x9, x13
    40204eb4:	92009def 	and	x15, x15, #0xff00ff00ff00ff
    40204eb8:	8b1001ef 	add	x15, x15, x16
    40204ebc:	9b0b7df0 	mul	x16, x15, x11
    40204ec0:	924005af 	and	x15, x13, #0x3
    40204ec4:	8b50c108 	add	x8, x8, x16, lsr #48
    40204ec8:	b5000d8f 	cbnz	x15, 40205078 <core::str::count::do_count_chars+0x30c>
    40204ecc:	b4fffd49 	cbz	x9, 40204e74 <core::str::count::do_count_chars+0x108>
    40204ed0:	f103013f 	cmp	x9, #0xc0
    40204ed4:	aa0e03ec 	mov	x12, x14
    40204ed8:	9a8a312d 	csel	x13, x9, x10, cc  // cc = lo, ul, last
    40204edc:	d37df1ae 	lsl	x14, x13, #3
    40204ee0:	f27b15d0 	ands	x16, x14, #0x7e0
    40204ee4:	54fffde0 	b.eq	40204ea0 <core::str::count::do_count_chars+0x134>  // b.none
    40204ee8:	d10081cf 	sub	x15, x14, #0x20
    40204eec:	f10181ff 	cmp	x15, #0x60
    40204ef0:	54000082 	b.cs	40204f00 <core::str::count::do_count_chars+0x194>  // b.hs, b.nlast
    40204ef4:	aa1f03f1 	mov	x17, xzr
    40204ef8:	aa0c03ef 	mov	x15, x12
    40204efc:	14000044 	b	4020500c <core::str::count::do_count_chars+0x2a0>
    40204f00:	d345fdef 	lsr	x15, x15, #5
    40204f04:	6f00e401 	movi	v1.2d, #0x0
    40204f08:	6f00e402 	movi	v2.2d, #0x0
    40204f0c:	91010180 	add	x0, x12, #0x40
    40204f10:	910005f1 	add	x17, x15, #0x1
    40204f14:	927ee632 	and	x18, x17, #0xffffffffffffffc
    40204f18:	927ee621 	and	x1, x17, #0xffffffffffffffc
    40204f1c:	8b12158f 	add	x15, x12, x18, lsl #5
    40204f20:	d1010002 	sub	x2, x0, #0x40
    40204f24:	4c400c10 	ld4	{v16.2d-v19.2d}, [x0]
    40204f28:	f1001021 	subs	x1, x1, #0x4
    40204f2c:	91020000 	add	x0, x0, #0x80
    40204f30:	4c400c43 	ld4	{v3.2d-v6.2d}, [x2]
    40204f34:	6e205a07 	mvn	v7.16b, v16.16b
    40204f38:	6e205a35 	mvn	v21.16b, v17.16b
    40204f3c:	6e205a5a 	mvn	v26.16b, v18.16b
    40204f40:	6e205876 	mvn	v22.16b, v3.16b
    40204f44:	6e205897 	mvn	v23.16b, v4.16b
    40204f48:	6e2058b8 	mvn	v24.16b, v5.16b
    40204f4c:	6f7a0614 	ushr	v20.2d, v16.2d, #6
    40204f50:	6f7a0639 	ushr	v25.2d, v17.2d, #6
    40204f54:	6f7a065b 	ushr	v27.2d, v18.2d, #6
    40204f58:	6f7a047c 	ushr	v28.2d, v3.2d, #6
    40204f5c:	6f7a049d 	ushr	v29.2d, v4.2d, #6
    40204f60:	6f7a04be 	ushr	v30.2d, v5.2d, #6
    40204f64:	6f7906d6 	ushr	v22.2d, v22.2d, #7
    40204f68:	6f7906f7 	ushr	v23.2d, v23.2d, #7
    40204f6c:	6f790718 	ushr	v24.2d, v24.2d, #7
    40204f70:	6f7904e7 	ushr	v7.2d, v7.2d, #7
    40204f74:	6f7906b5 	ushr	v21.2d, v21.2d, #7
    40204f78:	6f79075a 	ushr	v26.2d, v26.2d, #7
    40204f7c:	6e205a7f 	mvn	v31.16b, v19.16b
    40204f80:	6f7a0670 	ushr	v16.2d, v19.2d, #6
    40204f84:	6e2058d1 	mvn	v17.16b, v6.16b
    40204f88:	4ebc1ed2 	orr	v18.16b, v22.16b, v28.16b
    40204f8c:	4ebd1ef3 	orr	v19.16b, v23.16b, v29.16b
    40204f90:	4ebe1f16 	orr	v22.16b, v24.16b, v30.16b
    40204f94:	4eb41ce7 	orr	v7.16b, v7.16b, v20.16b
    40204f98:	4eb91eb4 	orr	v20.16b, v21.16b, v25.16b
    40204f9c:	4ebb1f55 	orr	v21.16b, v26.16b, v27.16b
    40204fa0:	6f7a04c3 	ushr	v3.2d, v6.2d, #6
    40204fa4:	6f7907e4 	ushr	v4.2d, v31.2d, #7
    40204fa8:	6f790625 	ushr	v5.2d, v17.2d, #7
    40204fac:	4e201e46 	and	v6.16b, v18.16b, v0.16b
    40204fb0:	4e201e71 	and	v17.16b, v19.16b, v0.16b
    40204fb4:	4e201ed2 	and	v18.16b, v22.16b, v0.16b
    40204fb8:	4e201ce7 	and	v7.16b, v7.16b, v0.16b
    40204fbc:	4e201e93 	and	v19.16b, v20.16b, v0.16b
    40204fc0:	4e201eb4 	and	v20.16b, v21.16b, v0.16b
    40204fc4:	4eb01c84 	orr	v4.16b, v4.16b, v16.16b
    40204fc8:	4ea31ca3 	orr	v3.16b, v5.16b, v3.16b
    40204fcc:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40204fd0:	4ef18646 	add	v6.2d, v18.2d, v17.2d
    40204fd4:	4ee284e2 	add	v2.2d, v7.2d, v2.2d
    40204fd8:	4ef38685 	add	v5.2d, v20.2d, v19.2d
    40204fdc:	4e201c63 	and	v3.16b, v3.16b, v0.16b
    40204fe0:	4e201c84 	and	v4.16b, v4.16b, v0.16b
    40204fe4:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40204fe8:	4ee284a2 	add	v2.2d, v5.2d, v2.2d
    40204fec:	4ee18461 	add	v1.2d, v3.2d, v1.2d
    40204ff0:	4ee28482 	add	v2.2d, v4.2d, v2.2d
    40204ff4:	54fff961 	b.ne	40204f20 <core::str::count::do_count_chars+0x1b4>  // b.any
    40204ff8:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40204ffc:	eb12023f 	cmp	x17, x18
    40205000:	5ef1b821 	addp	d1, v1.2d
    40205004:	9e660031 	fmov	x17, d1
    40205008:	54fff4e0 	b.eq	40204ea4 <core::str::count::do_count_chars+0x138>  // b.none
    4020500c:	8b100190 	add	x16, x12, x16
    40205010:	f9400df2 	ldr	x18, [x15, #24]
    40205014:	f9001ff2 	str	x18, [sp, #56]
    40205018:	f94009f2 	ldr	x18, [x15, #16]
    4020501c:	f9001bf2 	str	x18, [sp, #48]
    40205020:	f94005f2 	ldr	x18, [x15, #8]
    40205024:	f90017f2 	str	x18, [sp, #40]
    40205028:	f84205f2 	ldr	x18, [x15], #32
    4020502c:	eb1001ff 	cmp	x15, x16
    40205030:	f90013f2 	str	x18, [sp, #32]
    40205034:	ad4107e2 	ldp	q2, q1, [sp, #32]
    40205038:	6e205823 	mvn	v3.16b, v1.16b
    4020503c:	6e205844 	mvn	v4.16b, v2.16b
    40205040:	6f7a0421 	ushr	v1.2d, v1.2d, #6
    40205044:	6f7a0442 	ushr	v2.2d, v2.2d, #6
    40205048:	6f790463 	ushr	v3.2d, v3.2d, #7
    4020504c:	6f790484 	ushr	v4.2d, v4.2d, #7
    40205050:	4ea21c82 	orr	v2.16b, v4.16b, v2.16b
    40205054:	4ea11c61 	orr	v1.16b, v3.16b, v1.16b
    40205058:	4e201c21 	and	v1.16b, v1.16b, v0.16b
    4020505c:	4e201c42 	and	v2.16b, v2.16b, v0.16b
    40205060:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40205064:	5ef1b821 	addp	d1, v1.2d
    40205068:	9e660032 	fmov	x18, d1
    4020506c:	8b110251 	add	x17, x18, x17
    40205070:	54fffd01 	b.ne	40205010 <core::str::count::do_count_chars+0x2a4>  // b.any
    40205074:	17ffff8c 	b	40204ea4 <core::str::count::do_count_chars+0x138>
    40205078:	927e15a9 	and	x9, x13, #0xfc
    4020507c:	f10005ff 	cmp	x15, #0x1
    40205080:	8b090d8a 	add	x10, x12, x9, lsl #3
    40205084:	f9400149 	ldr	x9, [x10]
    40205088:	aa2903eb 	mvn	x11, x9
    4020508c:	d347fd6b 	lsr	x11, x11, #7
    40205090:	aa491969 	orr	x9, x11, x9, lsr #6
    40205094:	9200c129 	and	x9, x9, #0x101010101010101
    40205098:	540001e0 	b.eq	402050d4 <core::str::count::do_count_chars+0x368>  // b.none
    4020509c:	f940054b 	ldr	x11, [x10, #8]
    402050a0:	f10009ff 	cmp	x15, #0x2
    402050a4:	aa2b03ec 	mvn	x12, x11
    402050a8:	d347fd8c 	lsr	x12, x12, #7
    402050ac:	aa4b198b 	orr	x11, x12, x11, lsr #6
    402050b0:	9200c16b 	and	x11, x11, #0x101010101010101
    402050b4:	8b090169 	add	x9, x11, x9
    402050b8:	540000e0 	b.eq	402050d4 <core::str::count::do_count_chars+0x368>  // b.none
    402050bc:	f940094a 	ldr	x10, [x10, #16]
    402050c0:	aa2a03eb 	mvn	x11, x10
    402050c4:	d347fd6b 	lsr	x11, x11, #7
    402050c8:	aa4a196a 	orr	x10, x11, x10, lsr #6
    402050cc:	9200c14a 	and	x10, x10, #0x101010101010101
    402050d0:	8b090149 	add	x9, x10, x9
    402050d4:	d348fd2a 	lsr	x10, x9, #8
    402050d8:	92009d29 	and	x9, x9, #0xff00ff00ff00ff
    402050dc:	92009d4a 	and	x10, x10, #0xff00ff00ff00ff
    402050e0:	8b090149 	add	x9, x10, x9
    402050e4:	b20083ea 	mov	x10, #0x1000100010001       	// #281479271743489
    402050e8:	9b0a7d29 	mul	x9, x9, x10
    402050ec:	8b49c108 	add	x8, x8, x9, lsr #48
    402050f0:	6d4523e9 	ldp	d9, d8, [sp, #80]
    402050f4:	aa0803e0 	mov	x0, x8
    402050f8:	fd4023ea 	ldr	d10, [sp, #64]
    402050fc:	910183ff 	add	sp, sp, #0x60
    40205100:	d65f03c0 	ret
    40205104:	f100803f 	cmp	x1, #0x20
    40205108:	54000082 	b.cs	40205118 <core::str::count::do_count_chars+0x3ac>  // b.hs, b.nlast
    4020510c:	aa1f03e9 	mov	x9, xzr
    40205110:	aa1f03e8 	mov	x8, xzr
    40205114:	140000bc 	b	40205404 <core::str::count::do_count_chars+0x698>
    40205118:	6f00e400 	movi	v0.2d, #0x0
    4020511c:	4f05e7e3 	movi	v3.16b, #0xbf
    40205120:	52800028 	mov	w8, #0x1                   	// #1
    40205124:	6f00e402 	movi	v2.2d, #0x0
    40205128:	6f00e407 	movi	v7.2d, #0x0
    4020512c:	927d042a 	and	x10, x1, #0x18
    40205130:	6f00e401 	movi	v1.2d, #0x0
    40205134:	6f00e412 	movi	v18.2d, #0x0
    40205138:	927be829 	and	x9, x1, #0xffffffffffffffe0
    4020513c:	6f00e405 	movi	v5.2d, #0x0
    40205140:	6f00e406 	movi	v6.2d, #0x0
    40205144:	927be82b 	and	x11, x1, #0xffffffffffffffe0
    40205148:	6f00e404 	movi	v4.2d, #0x0
    4020514c:	6f00e416 	movi	v22.2d, #0x0
    40205150:	6f00e411 	movi	v17.2d, #0x0
    40205154:	6f00e410 	movi	v16.2d, #0x0
    40205158:	6f00e417 	movi	v23.2d, #0x0
    4020515c:	6f00e414 	movi	v20.2d, #0x0
    40205160:	6f00e415 	movi	v21.2d, #0x0
    40205164:	6f00e413 	movi	v19.2d, #0x0
    40205168:	6f00e418 	movi	v24.2d, #0x0
    4020516c:	4e080d19 	dup	v25.2d, x8
    40205170:	91004008 	add	x8, x0, #0x10
    40205174:	aa0803ec 	mov	x12, x8
    40205178:	385f1112 	ldurb	w18, [x8, #-15]
    4020517c:	385f5102 	ldurb	w2, [x8, #-11]
    40205180:	385f0d8d 	ldrb	w13, [x12, #-16]!
    40205184:	aa0c03ef 	mov	x15, x12
    40205188:	3940098e 	ldrb	w14, [x12, #2]
    4020518c:	38404df0 	ldrb	w16, [x15, #4]!
    40205190:	394009f1 	ldrb	w17, [x15, #2]
    40205194:	39400d83 	ldrb	w3, [x12, #3]
    40205198:	39400def 	ldrb	w15, [x15, #3]
    4020519c:	d370bdce 	lsl	x14, x14, #16
    402051a0:	aa1221ad 	orr	x13, x13, x18, lsl #8
    402051a4:	2a022210 	orr	w16, w16, w2, lsl #8
    402051a8:	53103e31 	lsl	w17, w17, #16
    402051ac:	f100816b 	subs	x11, x11, #0x20
    402051b0:	aa0361ce 	orr	x14, x14, x3, lsl #24
    402051b4:	2a0f622f 	orr	w15, w17, w15, lsl #24
    402051b8:	aa0d01cd 	orr	x13, x14, x13
    402051bc:	2a1001ee 	orr	w14, w15, w16
    402051c0:	aa0e81ad 	orr	x13, x13, x14, lsl #32
    402051c4:	f9000bed 	str	x13, [sp, #16]
    402051c8:	aa0c03ed 	mov	x13, x12
    402051cc:	38408dae 	ldrb	w14, [x13, #8]!
    402051d0:	39400daf 	ldrb	w15, [x13, #3]
    402051d4:	394009b0 	ldrb	w16, [x13, #2]
    402051d8:	38404db1 	ldrb	w17, [x13, #4]!
    402051dc:	394009b2 	ldrb	w18, [x13, #2]
    402051e0:	39402582 	ldrb	w2, [x12, #9]
    402051e4:	3940358c 	ldrb	w12, [x12, #13]
    402051e8:	39400dad 	ldrb	w13, [x13, #3]
    402051ec:	d370be10 	lsl	x16, x16, #16
    402051f0:	53103e52 	lsl	w18, w18, #16
    402051f4:	aa0221ce 	orr	x14, x14, x2, lsl #8
    402051f8:	2a0c222c 	orr	w12, w17, w12, lsl #8
    402051fc:	aa0f620f 	orr	x15, x16, x15, lsl #24
    40205200:	2a0d624d 	orr	w13, w18, w13, lsl #24
    40205204:	aa0e01ee 	orr	x14, x15, x14
    40205208:	2a0c01ac 	orr	w12, w13, w12
    4020520c:	aa0c81cc 	orr	x12, x14, x12, lsl #32
    40205210:	f9000fec 	str	x12, [sp, #24]
    40205214:	aa0803ec 	mov	x12, x8
    40205218:	3940090e 	ldrb	w14, [x8, #2]
    4020521c:	38404d8f 	ldrb	w15, [x12, #4]!
    40205220:	39400990 	ldrb	w16, [x12, #2]
    40205224:	3940050d 	ldrb	w13, [x8, #1]
    40205228:	39400111 	ldrb	w17, [x8]
    4020522c:	39400d12 	ldrb	w18, [x8, #3]
    40205230:	39401502 	ldrb	w2, [x8, #5]
    40205234:	39400d8c 	ldrb	w12, [x12, #3]
    40205238:	d370bdce 	lsl	x14, x14, #16
    4020523c:	53103e10 	lsl	w16, w16, #16
    40205240:	aa0d222d 	orr	x13, x17, x13, lsl #8
    40205244:	2a0221ef 	orr	w15, w15, w2, lsl #8
    40205248:	3dc007fa 	ldr	q26, [sp, #16]
    4020524c:	aa1261ce 	orr	x14, x14, x18, lsl #24
    40205250:	2a0c620c 	orr	w12, w16, w12, lsl #24
    40205254:	4e23375a 	cmgt	v26.16b, v26.16b, v3.16b
    40205258:	aa0d01cd 	orr	x13, x14, x13
    4020525c:	2a0f018c 	orr	w12, w12, w15
    40205260:	aa0c81ac 	orr	x12, x13, x12, lsl #32
    40205264:	aa0803ed 	mov	x13, x8
    40205268:	6f08a75b 	uxtl2	v27.8h, v26.16b
    4020526c:	2f08a75a 	uxtl	v26.8h, v26.8b
    40205270:	f90003ec 	str	x12, [sp]
    40205274:	38408dac 	ldrb	w12, [x13, #8]!
    40205278:	39400dae 	ldrb	w14, [x13, #3]
    4020527c:	394009af 	ldrb	w15, [x13, #2]
    40205280:	38404db0 	ldrb	w16, [x13, #4]!
    40205284:	394009b1 	ldrb	w17, [x13, #2]
    40205288:	39402512 	ldrb	w18, [x8, #9]
    4020528c:	39403502 	ldrb	w2, [x8, #13]
    40205290:	39400dad 	ldrb	w13, [x13, #3]
    40205294:	d370bdef 	lsl	x15, x15, #16
    40205298:	6f10a77c 	uxtl2	v28.4s, v27.8h
    4020529c:	53103e31 	lsl	w17, w17, #16
    402052a0:	aa12218c 	orr	x12, x12, x18, lsl #8
    402052a4:	2a022210 	orr	w16, w16, w2, lsl #8
    402052a8:	aa0e61ee 	orr	x14, x15, x14, lsl #24
    402052ac:	2f10a77b 	uxtl	v27.4s, v27.4h
    402052b0:	2f10a75e 	uxtl	v30.4s, v26.4h
    402052b4:	2a0d622d 	orr	w13, w17, w13, lsl #24
    402052b8:	6f20a79d 	uxtl2	v29.2d, v28.4s
    402052bc:	6f10a75a 	uxtl2	v26.4s, v26.8h
    402052c0:	aa0c01cc 	orr	x12, x14, x12
    402052c4:	2f20a79c 	uxtl	v28.2d, v28.2s
    402052c8:	91008108 	add	x8, x8, #0x20
    402052cc:	2a1001ad 	orr	w13, w13, w16
    402052d0:	6f20a768 	uxtl2	v8.2d, v27.4s
    402052d4:	6f20a7c9 	uxtl2	v9.2d, v30.4s
    402052d8:	aa0d818c 	orr	x12, x12, x13, lsl #32
    402052dc:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    402052e0:	6f20a74a 	uxtl2	v10.2d, v26.4s
    402052e4:	2f20a75a 	uxtl	v26.2d, v26.2s
    402052e8:	2f20a77b 	uxtl	v27.2d, v27.2s
    402052ec:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    402052f0:	f90007ec 	str	x12, [sp, #8]
    402052f4:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    402052f8:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    402052fc:	3dc003ff 	ldr	q31, [sp]
    40205300:	4efd86d6 	add	v22.2d, v22.2d, v29.2d
    40205304:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40205308:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    4020530c:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    40205310:	4efc8484 	add	v4.2d, v4.2d, v28.2d
    40205314:	4e2337ff 	cmgt	v31.16b, v31.16b, v3.16b
    40205318:	4ee884c6 	add	v6.2d, v6.2d, v8.2d
    4020531c:	2f20a7de 	uxtl	v30.2d, v30.2s
    40205320:	4eea8652 	add	v18.2d, v18.2d, v10.2d
    40205324:	4ee984e7 	add	v7.2d, v7.2d, v9.2d
    40205328:	4efa8421 	add	v1.2d, v1.2d, v26.2d
    4020532c:	4efb84a5 	add	v5.2d, v5.2d, v27.2d
    40205330:	6f08a7fd 	uxtl2	v29.8h, v31.16b
    40205334:	2f08a7ff 	uxtl	v31.8h, v31.8b
    40205338:	4e391fde 	and	v30.16b, v30.16b, v25.16b
    4020533c:	6f10a7bc 	uxtl2	v28.4s, v29.8h
    40205340:	6f10a7e8 	uxtl2	v8.4s, v31.8h
    40205344:	2f10a7bd 	uxtl	v29.4s, v29.4h
    40205348:	2f10a7fa 	uxtl	v26.4s, v31.4h
    4020534c:	4efe8442 	add	v2.2d, v2.2d, v30.2d
    40205350:	2f20a79b 	uxtl	v27.2d, v28.2s
    40205354:	6f20a79c 	uxtl2	v28.2d, v28.4s
    40205358:	2f20a7bf 	uxtl	v31.2d, v29.2s
    4020535c:	6f20a509 	uxtl2	v9.2d, v8.4s
    40205360:	6f20a7bd 	uxtl2	v29.2d, v29.4s
    40205364:	2f20a74a 	uxtl	v10.2d, v26.2s
    40205368:	6f20a75a 	uxtl2	v26.2d, v26.4s
    4020536c:	2f20a508 	uxtl	v8.2d, v8.2s
    40205370:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    40205374:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    40205378:	4e391fff 	and	v31.16b, v31.16b, v25.16b
    4020537c:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    40205380:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    40205384:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40205388:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    4020538c:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    40205390:	4efc8718 	add	v24.2d, v24.2d, v28.2d
    40205394:	4efb8673 	add	v19.2d, v19.2d, v27.2d
    40205398:	4eff8694 	add	v20.2d, v20.2d, v31.2d
    4020539c:	4efd86b5 	add	v21.2d, v21.2d, v29.2d
    402053a0:	4ee986f7 	add	v23.2d, v23.2d, v9.2d
    402053a4:	4eea8631 	add	v17.2d, v17.2d, v10.2d
    402053a8:	4ee88610 	add	v16.2d, v16.2d, v8.2d
    402053ac:	4efa8400 	add	v0.2d, v0.2d, v26.2d
    402053b0:	54ffee21 	b.ne	40205174 <core::str::count::do_count_chars+0x408>  // b.any
    402053b4:	4ef286e3 	add	v3.2d, v23.2d, v18.2d
    402053b8:	4ef68712 	add	v18.2d, v24.2d, v22.2d
    402053bc:	eb09003f 	cmp	x1, x9
    402053c0:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    402053c4:	4ee28622 	add	v2.2d, v17.2d, v2.2d
    402053c8:	4ee58685 	add	v5.2d, v20.2d, v5.2d
    402053cc:	4ee686a6 	add	v6.2d, v21.2d, v6.2d
    402053d0:	4ee18601 	add	v1.2d, v16.2d, v1.2d
    402053d4:	4ee48664 	add	v4.2d, v19.2d, v4.2d
    402053d8:	4ef28463 	add	v3.2d, v3.2d, v18.2d
    402053dc:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    402053e0:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    402053e4:	4ee68400 	add	v0.2d, v0.2d, v6.2d
    402053e8:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    402053ec:	4ee38400 	add	v0.2d, v0.2d, v3.2d
    402053f0:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    402053f4:	5ef1b800 	addp	d0, v0.2d
    402053f8:	9e660008 	fmov	x8, d0
    402053fc:	54ffd3c0 	b.eq	40204e74 <core::str::count::do_count_chars+0x108>  // b.none
    40205400:	b400074a 	cbz	x10, 402054e8 <core::str::count::do_count_chars+0x77c>
    40205404:	6f00e400 	movi	v0.2d, #0x0
    40205408:	6f00e401 	movi	v1.2d, #0x0
    4020540c:	aa0903ea 	mov	x10, x9
    40205410:	0f05e7e2 	movi	v2.8b, #0xbf
    40205414:	6f00e403 	movi	v3.2d, #0x0
    40205418:	927df029 	and	x9, x1, #0xfffffffffffffff8
    4020541c:	6f00e404 	movi	v4.2d, #0x0
    40205420:	4e081d00 	mov	v0.d[0], x8
    40205424:	52800028 	mov	w8, #0x1                   	// #1
    40205428:	4e080d05 	dup	v5.2d, x8
    4020542c:	cb090148 	sub	x8, x10, x9
    40205430:	8b0a000a 	add	x10, x0, x10
    40205434:	aa0a03ed 	mov	x13, x10
    40205438:	3940094c 	ldrb	w12, [x10, #2]
    4020543c:	3940054b 	ldrb	w11, [x10, #1]
    40205440:	38404dae 	ldrb	w14, [x13, #4]!
    40205444:	394009af 	ldrb	w15, [x13, #2]
    40205448:	39400150 	ldrb	w16, [x10]
    4020544c:	39400d51 	ldrb	w17, [x10, #3]
    40205450:	d370bd8c 	lsl	x12, x12, #16
    40205454:	39401552 	ldrb	w18, [x10, #5]
    40205458:	39400dad 	ldrb	w13, [x13, #3]
    4020545c:	53103def 	lsl	w15, w15, #16
    40205460:	aa0b220b 	orr	x11, x16, x11, lsl #8
    40205464:	aa11618c 	orr	x12, x12, x17, lsl #24
    40205468:	b1002108 	adds	x8, x8, #0x8
    4020546c:	2a1221ce 	orr	w14, w14, w18, lsl #8
    40205470:	2a0d61ed 	orr	w13, w15, w13, lsl #24
    40205474:	9100214a 	add	x10, x10, #0x8
    40205478:	aa0b018b 	orr	x11, x12, x11
    4020547c:	2a0e01ac 	orr	w12, w13, w14
    40205480:	aa0c816b 	orr	x11, x11, x12, lsl #32
    40205484:	9e670166 	fmov	d6, x11
    40205488:	0e2234c6 	cmgt	v6.8b, v6.8b, v2.8b
    4020548c:	2f08a4c6 	uxtl	v6.8h, v6.8b
    40205490:	6f10a4c7 	uxtl2	v7.4s, v6.8h
    40205494:	2f10a4c6 	uxtl	v6.4s, v6.4h
    40205498:	6f20a4f0 	uxtl2	v16.2d, v7.4s
    4020549c:	2f20a4d1 	uxtl	v17.2d, v6.2s
    402054a0:	6f20a4c6 	uxtl2	v6.2d, v6.4s
    402054a4:	2f20a4e7 	uxtl	v7.2d, v7.2s
    402054a8:	4e251e10 	and	v16.16b, v16.16b, v5.16b
    402054ac:	4e251e31 	and	v17.16b, v17.16b, v5.16b
    402054b0:	4e251cc6 	and	v6.16b, v6.16b, v5.16b
    402054b4:	4e251ce7 	and	v7.16b, v7.16b, v5.16b
    402054b8:	4ef08484 	add	v4.2d, v4.2d, v16.2d
    402054bc:	4ee68463 	add	v3.2d, v3.2d, v6.2d
    402054c0:	4ef18400 	add	v0.2d, v0.2d, v17.2d
    402054c4:	4ee78421 	add	v1.2d, v1.2d, v7.2d
    402054c8:	54fffb61 	b.ne	40205434 <core::str::count::do_count_chars+0x6c8>  // b.any
    402054cc:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    402054d0:	4ee48461 	add	v1.2d, v3.2d, v4.2d
    402054d4:	eb09003f 	cmp	x1, x9
    402054d8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    402054dc:	5ef1b800 	addp	d0, v0.2d
    402054e0:	9e660008 	fmov	x8, d0
    402054e4:	54ffcc80 	b.eq	40204e74 <core::str::count::do_count_chars+0x108>  // b.none
    402054e8:	cb09002a 	sub	x10, x1, x9
    402054ec:	8b090009 	add	x9, x0, x9
    402054f0:	38c0152b 	ldrsb	w11, [x9], #1
    402054f4:	3101057f 	cmn	w11, #0x41
    402054f8:	9a88d508 	cinc	x8, x8, gt
    402054fc:	f100054a 	subs	x10, x10, #0x1
    40205500:	54ffff81 	b.ne	402054f0 <core::str::count::do_count_chars+0x784>  // b.any
    40205504:	17fffe5c 	b	40204e74 <core::str::count::do_count_chars+0x108>

0000000040205508 <core::panicking::panic_const::panic_const_div_by_zero>:
    40205508:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4020550c:	910003fd 	mov	x29, sp
    40205510:	aa0003e2 	mov	x2, x0
    40205514:	d503201f 	nop
    40205518:	10006240 	adr	x0, 40206160 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.6392299720734326547+0xf8>
    4020551c:	52800661 	mov	w1, #0x33                  	// #51
    40205520:	97fffe09 	bl	40204d44 <core::panicking::panic_fmt>

0000000040205524 <core::panicking::panic_const::panic_const_rem_by_zero>:
    40205524:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    40205528:	910003fd 	mov	x29, sp
    4020552c:	aa0003e2 	mov	x2, x0
    40205530:	d503201f 	nop
    40205534:	30006220 	adr	x0, 40206179 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.6392299720734326547+0x111>
    40205538:	52800e61 	mov	w1, #0x73                  	// #115
    4020553c:	97fffe02 	bl	40204d44 <core::panicking::panic_fmt>

0000000040205540 <<core::fmt::Formatter>::pad_integral::write_prefix>:
    40205540:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40205544:	a90157f6 	stp	x22, x21, [sp, #16]
    40205548:	a9024ff4 	stp	x20, x19, [sp, #32]
    4020554c:	910003fd 	mov	x29, sp
    40205550:	aa0403f3 	mov	x19, x4
    40205554:	aa0303f4 	mov	x20, x3
    40205558:	aa0103f5 	mov	x21, x1
    4020555c:	7144405f 	cmp	w2, #0x110, lsl #12
    40205560:	540001a0 	b.eq	40205594 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>  // b.none
    40205564:	f94012a8 	ldr	x8, [x21, #32]
    40205568:	2a0203e1 	mov	w1, w2
    4020556c:	aa0003f6 	mov	x22, x0
    40205570:	d63f0100 	blr	x8
    40205574:	2a0003e8 	mov	w8, w0
    40205578:	aa1603e0 	mov	x0, x22
    4020557c:	360000c8 	tbz	w8, #0, 40205594 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>
    40205580:	52800020 	mov	w0, #0x1                   	// #1
    40205584:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40205588:	a94157f6 	ldp	x22, x21, [sp, #16]
    4020558c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40205590:	d65f03c0 	ret
    40205594:	b4000114 	cbz	x20, 402055b4 <<core::fmt::Formatter>::pad_integral::write_prefix+0x74>
    40205598:	f9400ea3 	ldr	x3, [x21, #24]
    4020559c:	aa1403e1 	mov	x1, x20
    402055a0:	aa1303e2 	mov	x2, x19
    402055a4:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402055a8:	a94157f6 	ldp	x22, x21, [sp, #16]
    402055ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402055b0:	d61f0060 	br	x3
    402055b4:	2a1f03e0 	mov	w0, wzr
    402055b8:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402055bc:	a94157f6 	ldp	x22, x21, [sp, #16]
    402055c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402055c4:	d65f03c0 	ret

00000000402055c8 <<u64 as core::fmt::Display>::fmt>:
    402055c8:	d100c3ff 	sub	sp, sp, #0x30
    402055cc:	a9027bfd 	stp	x29, x30, [sp, #32]
    402055d0:	910083fd 	add	x29, sp, #0x20
    402055d4:	f9400009 	ldr	x9, [x0]
    402055d8:	d503201f 	nop
    402055dc:	100055e8 	adr	x8, 40206098 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.6392299720734326547+0x30>
    402055e0:	f10fa13f 	cmp	x9, #0x3e8
    402055e4:	540004e3 	b.cc	40205680 <<u64 as core::fmt::Display>::fmt+0xb8>  // b.lo, b.ul, b.last
    402055e8:	d28b296c 	mov	x12, #0x594b                	// #22859
    402055ec:	910033ea 	add	x10, sp, #0xc
    402055f0:	5292cff1 	mov	w17, #0x967f                	// #38527
    402055f4:	f2a710cc 	movk	x12, #0x3886, lsl #16
    402055f8:	9280026b 	mov	x11, #0xffffffffffffffec    	// #-20
    402055fc:	5284e20d 	mov	w13, #0x2710                	// #10000
    40205600:	f2d8bacc 	movk	x12, #0xc5d6, lsl #32
    40205604:	52828f6e 	mov	w14, #0x147b                	// #5243
    40205608:	91004d4f 	add	x15, x10, #0x13
    4020560c:	f2e68dac 	movk	x12, #0x346d, lsl #48
    40205610:	52800c90 	mov	w16, #0x64                  	// #100
    40205614:	72a01311 	movk	w17, #0x98, lsl #16
    40205618:	aa0903ea 	mov	x10, x9
    4020561c:	aa0a03f2 	mov	x18, x10
    40205620:	9bcc7d4a 	umulh	x10, x10, x12
    40205624:	9100116b 	add	x11, x11, #0x4
    40205628:	eb11025f 	cmp	x18, x17
    4020562c:	d34bfd4a 	lsr	x10, x10, #11
    40205630:	1b0dc940 	msub	w0, w10, w13, w18
    40205634:	53023c02 	ubfx	w2, w0, #2, #14
    40205638:	1b0e7c42 	mul	w2, w2, w14
    4020563c:	53117c42 	lsr	w2, w2, #17
    40205640:	1b108040 	msub	w0, w2, w16, w0
    40205644:	8b224502 	add	x2, x8, w2, uxtw #1
    40205648:	39400043 	ldrb	w3, [x2]
    4020564c:	39400442 	ldrb	w2, [x2, #1]
    40205650:	8b202500 	add	x0, x8, w0, uxth #1
    40205654:	381fd1e3 	sturb	w3, [x15, #-3]
    40205658:	39400003 	ldrb	w3, [x0]
    4020565c:	39400400 	ldrb	w0, [x0, #1]
    40205660:	381fe1e2 	sturb	w2, [x15, #-2]
    40205664:	381ff1e3 	sturb	w3, [x15, #-1]
    40205668:	381fc5e0 	strb	w0, [x15], #-4
    4020566c:	54fffd88 	b.hi	4020561c <<u64 as core::fmt::Display>::fmt+0x54>  // b.pmore
    40205670:	cb0b03eb 	neg	x11, x11
    40205674:	f100255f 	cmp	x10, #0x9
    40205678:	540000c8 	b.hi	40205690 <<u64 as core::fmt::Display>::fmt+0xc8>  // b.pmore
    4020567c:	14000015 	b	402056d0 <<u64 as core::fmt::Display>::fmt+0x108>
    40205680:	5280028b 	mov	w11, #0x14                  	// #20
    40205684:	aa0903ea 	mov	x10, x9
    40205688:	f100253f 	cmp	x9, #0x9
    4020568c:	54000229 	b.ls	402056d0 <<u64 as core::fmt::Display>::fmt+0x108>  // b.plast
    40205690:	53023d4c 	ubfx	w12, w10, #2, #14
    40205694:	52828f6d 	mov	w13, #0x147b                	// #5243
    40205698:	910033ef 	add	x15, sp, #0xc
    4020569c:	1b0d7d8c 	mul	w12, w12, w13
    402056a0:	52800c8d 	mov	w13, #0x64                  	// #100
    402056a4:	53117d8c 	lsr	w12, w12, #17
    402056a8:	1b0da98a 	msub	w10, w12, w13, w10
    402056ac:	d100096d 	sub	x13, x11, #0x2
    402056b0:	8b0b01eb 	add	x11, x15, x11
    402056b4:	8b2a250a 	add	x10, x8, w10, uxth #1
    402056b8:	3940014e 	ldrb	w14, [x10]
    402056bc:	3940054a 	ldrb	w10, [x10, #1]
    402056c0:	382d69ee 	strb	w14, [x15, x13]
    402056c4:	381ff16a 	sturb	w10, [x11, #-1]
    402056c8:	aa0c03ea 	mov	x10, x12
    402056cc:	aa0d03eb 	mov	x11, x13
    402056d0:	b4000049 	cbz	x9, 402056d8 <<u64 as core::fmt::Display>::fmt+0x110>
    402056d4:	b40000ca 	cbz	x10, 402056ec <<u64 as core::fmt::Display>::fmt+0x124>
    402056d8:	8b0a0508 	add	x8, x8, x10, lsl #1
    402056dc:	d100056b 	sub	x11, x11, #0x1
    402056e0:	910033e9 	add	x9, sp, #0xc
    402056e4:	39400508 	ldrb	w8, [x8, #1]
    402056e8:	382b6928 	strb	w8, [x9, x11]
    402056ec:	52800288 	mov	w8, #0x14                  	// #20
    402056f0:	aa0103e0 	mov	x0, x1
    402056f4:	52800021 	mov	w1, #0x1                   	// #1
    402056f8:	cb0b0105 	sub	x5, x8, x11
    402056fc:	910033e8 	add	x8, sp, #0xc
    40205700:	52800022 	mov	w2, #0x1                   	// #1
    40205704:	8b0b0104 	add	x4, x8, x11
    40205708:	aa1f03e3 	mov	x3, xzr
    4020570c:	97fffc5a 	bl	40204874 <<core::fmt::Formatter>::pad_integral>
    40205710:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40205714:	9100c3ff 	add	sp, sp, #0x30
    40205718:	d65f03c0 	ret

000000004020571c <__udivti3>:
    4020571c:	d100c3ff 	sub	sp, sp, #0x30
    40205720:	a9027bfd 	stp	x29, x30, [sp, #32]
    40205724:	910083fd 	add	x29, sp, #0x20
    40205728:	910003e8 	mov	x8, sp
    4020572c:	94000005 	bl	40205740 <compiler_builtins::int::specialized_div_rem::u128_div_rem>
    40205730:	a94007e0 	ldp	x0, x1, [sp]
    40205734:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40205738:	9100c3ff 	add	sp, sp, #0x30
    4020573c:	d65f03c0 	ret

0000000040205740 <compiler_builtins::int::specialized_div_rem::u128_div_rem>:
    40205740:	dac01049 	clz	x9, x2
    40205744:	dac0106a 	clz	x10, x3
    40205748:	f100007f 	cmp	x3, #0x0
    4020574c:	11010129 	add	w9, w9, #0x40
    40205750:	dac0100c 	clz	x12, x0
    40205754:	1a89114b 	csel	w11, w10, w9, ne  // ne = any
    40205758:	dac01029 	clz	x9, x1
    4020575c:	1101018a 	add	w10, w12, #0x40
    40205760:	f100003f 	cmp	x1, #0x0
    40205764:	1a8a112f 	csel	w15, w9, w10, ne  // ne = any
    40205768:	6b0f0169 	subs	w9, w11, w15
    4020576c:	54000149 	b.ls	40205794 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x54>  // b.plast
    40205770:	7100fdff 	cmp	w15, #0x3f
    40205774:	540001c9 	b.ls	402057ac <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x6c>  // b.plast
    40205778:	9ac20809 	udiv	x9, x0, x2
    4020577c:	aa1f03ea 	mov	x10, xzr
    40205780:	aa1f03e1 	mov	x1, xzr
    40205784:	9b028120 	msub	x0, x9, x2, x0
    40205788:	a9002909 	stp	x9, x10, [x8]
    4020578c:	a9010500 	stp	x0, x1, [x8, #16]
    40205790:	d65f03c0 	ret
    40205794:	eb02001f 	cmp	x0, x2
    40205798:	fa03003f 	sbcs	xzr, x1, x3
    4020579c:	54000282 	b.cs	402057ec <compiler_builtins::int::specialized_div_rem::u128_div_rem+0xac>  // b.hs, b.nlast
    402057a0:	a9007d1f 	stp	xzr, xzr, [x8]
    402057a4:	a9010500 	stp	x0, x1, [x8, #16]
    402057a8:	d65f03c0 	ret
    402057ac:	71017d7f 	cmp	w11, #0x5f
    402057b0:	540002a9 	b.ls	40205804 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0xc4>  // b.plast
    402057b4:	2a0203e9 	mov	w9, w2
    402057b8:	9ac9082a 	udiv	x10, x1, x9
    402057bc:	1b02854b 	msub	w11, w10, w2, w1
    402057c0:	93c0816b 	extr	x11, x11, x0, #32
    402057c4:	9ac9096c 	udiv	x12, x11, x9
    402057c8:	1b02ad8b 	msub	w11, w12, w2, w11
    402057cc:	aa4c814a 	orr	x10, x10, x12, lsr #32
    402057d0:	b3607d60 	bfi	x0, x11, #32, #32
    402057d4:	9ac9080b 	udiv	x11, x0, x9
    402057d8:	9b098160 	msub	x0, x11, x9, x0
    402057dc:	aa0c8169 	orr	x9, x11, x12, lsl #32
    402057e0:	a9002909 	stp	x9, x10, [x8]
    402057e4:	a9017d00 	stp	x0, xzr, [x8, #16]
    402057e8:	d65f03c0 	ret
    402057ec:	eb020000 	subs	x0, x0, x2
    402057f0:	52800029 	mov	w9, #0x1                   	// #1
    402057f4:	da030021 	sbc	x1, x1, x3
    402057f8:	a9007d09 	stp	x9, xzr, [x8]
    402057fc:	a9010500 	stp	x0, x1, [x8, #16]
    40205800:	d65f03c0 	ret
    40205804:	7100813f 	cmp	w9, #0x20
    40205808:	54000422 	b.cs	4020588c <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x14c>  // b.hs, b.nlast
    4020580c:	d37ff829 	lsl	x9, x1, #1
    40205810:	5280080a 	mov	w10, #0x40                  	// #64
    40205814:	d37ff86c 	lsl	x12, x3, #1
    40205818:	510005eb 	sub	w11, w15, #0x1
    4020581c:	4b0f014a 	sub	w10, w10, w15
    40205820:	9acb2129 	lsl	x9, x9, x11
    40205824:	9aca240d 	lsr	x13, x0, x10
    40205828:	9acb218b 	lsl	x11, x12, x11
    4020582c:	9aca244c 	lsr	x12, x2, x10
    40205830:	9aca242e 	lsr	x14, x1, x10
    40205834:	9aca246f 	lsr	x15, x3, x10
    40205838:	f27a015f 	tst	x10, #0x40
    4020583c:	aa0d0129 	orr	x9, x9, x13
    40205840:	aa0c016a 	orr	x10, x11, x12
    40205844:	9a8911c9 	csel	x9, x14, x9, ne  // ne = any
    40205848:	9a8a11ea 	csel	x10, x15, x10, ne  // ne = any
    4020584c:	9aca0929 	udiv	x9, x9, x10
    40205850:	9bc97c4a 	umulh	x10, x2, x9
    40205854:	9b097c6b 	mul	x11, x3, x9
    40205858:	9bc97c6d 	umulh	x13, x3, x9
    4020585c:	9b097c4c 	mul	x12, x2, x9
    40205860:	ab0b014b 	adds	x11, x10, x11
    40205864:	9a8d35aa 	cinc	x10, x13, cs  // cs = hs, nlast
    40205868:	b500090a 	cbnz	x10, 40205988 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x248>
    4020586c:	eb0c001f 	cmp	x0, x12
    40205870:	fa0b003f 	sbcs	xzr, x1, x11
    40205874:	540008a3 	b.cc	40205988 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x248>  // b.lo, b.ul, b.last
    40205878:	eb0c0000 	subs	x0, x0, x12
    4020587c:	da0b0021 	sbc	x1, x1, x11
    40205880:	a9007d09 	stp	x9, xzr, [x8]
    40205884:	a9010500 	stp	x0, x1, [x8, #16]
    40205888:	d65f03c0 	ret
    4020588c:	52800c0d 	mov	w13, #0x60                  	// #96
    40205890:	d37ff86c 	lsl	x12, x3, #1
    40205894:	5101856e 	sub	w14, w11, #0x61
    40205898:	4b0b01ad 	sub	w13, w13, w11
    4020589c:	aa1f03e9 	mov	x9, xzr
    402058a0:	aa1f03ea 	mov	x10, xzr
    402058a4:	9ace218e 	lsl	x14, x12, x14
    402058a8:	9acd2450 	lsr	x16, x2, x13
    402058ac:	9acd2471 	lsr	x17, x3, x13
    402058b0:	f27a01bf 	tst	x13, #0x40
    402058b4:	aa1001ce 	orr	x14, x14, x16
    402058b8:	52800810 	mov	w16, #0x40                  	// #64
    402058bc:	9a8e122e 	csel	x14, x17, x14, ne  // ne = any
    402058c0:	2a0e03ee 	mov	w14, w14
    402058c4:	910005ce 	add	x14, x14, #0x1
    402058c8:	d37ff832 	lsl	x18, x1, #1
    402058cc:	4b0f0211 	sub	w17, w16, w15
    402058d0:	510005ef 	sub	w15, w15, #0x1
    402058d4:	9ad12424 	lsr	x4, x1, x17
    402058d8:	f27a023f 	tst	x17, #0x40
    402058dc:	9acf224f 	lsl	x15, x18, x15
    402058e0:	9ad12412 	lsr	x18, x0, x17
    402058e4:	aa1201ef 	orr	x15, x15, x18
    402058e8:	9a8f1092 	csel	x18, x4, x15, ne  // ne = any
    402058ec:	6b0d022f 	subs	w15, w17, w13
    402058f0:	540005c3 	b.cc	402059a8 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x268>  // b.lo, b.ul, b.last
    402058f4:	9ace0a51 	udiv	x17, x18, x14
    402058f8:	2a2f03e6 	mvn	w6, w15
    402058fc:	f27a01ff 	tst	x15, #0x40
    40205900:	9bd17c52 	umulh	x18, x2, x17
    40205904:	d341fe25 	lsr	x5, x17, #1
    40205908:	9b117c44 	mul	x4, x2, x17
    4020590c:	9ac624a5 	lsr	x5, x5, x6
    40205910:	9b114872 	madd	x18, x3, x17, x18
    40205914:	9acf2231 	lsl	x17, x17, x15
    40205918:	d341fc87 	lsr	x7, x4, #1
    4020591c:	9ac624e6 	lsr	x6, x7, x6
    40205920:	9acf2252 	lsl	x18, x18, x15
    40205924:	9acf208f 	lsl	x15, x4, x15
    40205928:	9a851224 	csel	x4, x17, x5, ne  // ne = any
    4020592c:	9a9113f1 	csel	x17, xzr, x17, ne  // ne = any
    40205930:	aa060252 	orr	x18, x18, x6
    40205934:	9a9211f2 	csel	x18, x15, x18, ne  // ne = any
    40205938:	9a8f13ef 	csel	x15, xzr, x15, ne  // ne = any
    4020593c:	ab090229 	adds	x9, x17, x9
    40205940:	9a0a008a 	adc	x10, x4, x10
    40205944:	eb0f0000 	subs	x0, x0, x15
    40205948:	fa120021 	sbcs	x1, x1, x18
    4020594c:	dac0100f 	clz	x15, x0
    40205950:	dac01031 	clz	x17, x1
    40205954:	110101ef 	add	w15, w15, #0x40
    40205958:	1a8f122f 	csel	w15, w17, w15, ne  // ne = any
    4020595c:	6b0f017f 	cmp	w11, w15
    40205960:	54000549 	b.ls	40205a08 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x2c8>  // b.plast
    40205964:	7100fdff 	cmp	w15, #0x3f
    40205968:	54fffb09 	b.ls	402058c8 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x188>  // b.plast
    4020596c:	9ac2080b 	udiv	x11, x0, x2
    40205970:	9b028160 	msub	x0, x11, x2, x0
    40205974:	ab0b0129 	adds	x9, x9, x11
    40205978:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    4020597c:	a9002909 	stp	x9, x10, [x8]
    40205980:	a9017d00 	stp	x0, xzr, [x8, #16]
    40205984:	d65f03c0 	ret
    40205988:	ab00004d 	adds	x13, x2, x0
    4020598c:	d1000529 	sub	x9, x9, #0x1
    40205990:	9a01006e 	adc	x14, x3, x1
    40205994:	eb0c01a0 	subs	x0, x13, x12
    40205998:	da0b01c1 	sbc	x1, x14, x11
    4020599c:	a9007d09 	stp	x9, xzr, [x8]
    402059a0:	a9010500 	stp	x0, x1, [x8, #16]
    402059a4:	d65f03c0 	ret
    402059a8:	2a3103eb 	mvn	w11, w17
    402059ac:	9ad1244d 	lsr	x13, x2, x17
    402059b0:	f27a023f 	tst	x17, #0x40
    402059b4:	9acb218b 	lsl	x11, x12, x11
    402059b8:	9ad1246c 	lsr	x12, x3, x17
    402059bc:	aa0d016b 	orr	x11, x11, x13
    402059c0:	9a8b118b 	csel	x11, x12, x11, ne  // ne = any
    402059c4:	9acb0a4d 	udiv	x13, x18, x11
    402059c8:	9bcd7c4b 	umulh	x11, x2, x13
    402059cc:	9b0d7c4c 	mul	x12, x2, x13
    402059d0:	9b0d2c6b 	madd	x11, x3, x13, x11
    402059d4:	eb0c001f 	cmp	x0, x12
    402059d8:	fa0b003f 	sbcs	xzr, x1, x11
    402059dc:	540002a2 	b.cs	40205a30 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x2f0>  // b.hs, b.nlast
    402059e0:	d10005ad 	sub	x13, x13, #0x1
    402059e4:	ab0d0129 	adds	x9, x9, x13
    402059e8:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    402059ec:	ab02000d 	adds	x13, x0, x2
    402059f0:	9a03002e 	adc	x14, x1, x3
    402059f4:	eb0c01a0 	subs	x0, x13, x12
    402059f8:	da0b01c1 	sbc	x1, x14, x11
    402059fc:	a9002909 	stp	x9, x10, [x8]
    40205a00:	a9010500 	stp	x0, x1, [x8, #16]
    40205a04:	d65f03c0 	ret
    40205a08:	eb02001f 	cmp	x0, x2
    40205a0c:	fa03003f 	sbcs	xzr, x1, x3
    40205a10:	54ffebc3 	b.cc	40205788 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x48>  // b.lo, b.ul, b.last
    40205a14:	b1000529 	adds	x9, x9, #0x1
    40205a18:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40205a1c:	eb020000 	subs	x0, x0, x2
    40205a20:	da030021 	sbc	x1, x1, x3
    40205a24:	a9002909 	stp	x9, x10, [x8]
    40205a28:	a9010500 	stp	x0, x1, [x8, #16]
    40205a2c:	d65f03c0 	ret
    40205a30:	ab0d0129 	adds	x9, x9, x13
    40205a34:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40205a38:	eb0c0000 	subs	x0, x0, x12
    40205a3c:	da0b0021 	sbc	x1, x1, x11
    40205a40:	a9002909 	stp	x9, x10, [x8]
    40205a44:	a9010500 	stp	x0, x1, [x8, #16]
    40205a48:	d65f03c0 	ret

0000000040205a4c <memcpy>:
    40205a4c:	f100405f 	cmp	x2, #0x10
    40205a50:	54000723 	b.cc	40205b34 <memcpy+0xe8>  // b.lo, b.ul, b.last
    40205a54:	cb0003ec 	neg	x12, x0
    40205a58:	92400988 	and	x8, x12, #0x7
    40205a5c:	8b080009 	add	x9, x0, x8
    40205a60:	eb09001f 	cmp	x0, x9
    40205a64:	54000422 	b.cs	40205ae8 <memcpy+0x9c>  // b.hs, b.nlast
    40205a68:	f100111f 	cmp	x8, #0x4
    40205a6c:	aa0003ea 	mov	x10, x0
    40205a70:	aa0103eb 	mov	x11, x1
    40205a74:	54000323 	b.cc	40205ad8 <memcpy+0x8c>  // b.lo, b.ul, b.last
    40205a78:	cb01000a 	sub	x10, x0, x1
    40205a7c:	aa0103eb 	mov	x11, x1
    40205a80:	f100815f 	cmp	x10, #0x20
    40205a84:	aa0003ea 	mov	x10, x0
    40205a88:	54000283 	b.cc	40205ad8 <memcpy+0x8c>  // b.lo, b.ul, b.last
    40205a8c:	927e018c 	and	x12, x12, #0x4
    40205a90:	aa0003ed 	mov	x13, x0
    40205a94:	aa0103ee 	mov	x14, x1
    40205a98:	8b0c000a 	add	x10, x0, x12
    40205a9c:	8b0c002b 	add	x11, x1, x12
    40205aa0:	aa0c03ef 	mov	x15, x12
    40205aa4:	39400dd0 	ldrb	w16, [x14, #3]
    40205aa8:	394009d1 	ldrb	w17, [x14, #2]
    40205aac:	f10011ef 	subs	x15, x15, #0x4
    40205ab0:	394001d2 	ldrb	w18, [x14]
    40205ab4:	394005c3 	ldrb	w3, [x14, #1]
    40205ab8:	910011ce 	add	x14, x14, #0x4
    40205abc:	39000db0 	strb	w16, [x13, #3]
    40205ac0:	390009b1 	strb	w17, [x13, #2]
    40205ac4:	390005a3 	strb	w3, [x13, #1]
    40205ac8:	380045b2 	strb	w18, [x13], #4
    40205acc:	54fffec1 	b.ne	40205aa4 <memcpy+0x58>  // b.any
    40205ad0:	eb0c011f 	cmp	x8, x12
    40205ad4:	540000a0 	b.eq	40205ae8 <memcpy+0x9c>  // b.none
    40205ad8:	3840156c 	ldrb	w12, [x11], #1
    40205adc:	3800154c 	strb	w12, [x10], #1
    40205ae0:	eb09015f 	cmp	x10, x9
    40205ae4:	54ffffa1 	b.ne	40205ad8 <memcpy+0x8c>  // b.any
    40205ae8:	cb08004b 	sub	x11, x2, x8
    40205aec:	8b08002a 	add	x10, x1, x8
    40205af0:	927df16c 	and	x12, x11, #0xfffffffffffffff8
    40205af4:	f240095f 	tst	x10, #0x7
    40205af8:	8b0c0128 	add	x8, x9, x12
    40205afc:	540007a1 	b.ne	40205bf0 <memcpy+0x1a4>  // b.any
    40205b00:	eb08013f 	cmp	x9, x8
    40205b04:	540000c2 	b.cs	40205b1c <memcpy+0xd0>  // b.hs, b.nlast
    40205b08:	aa0a03ed 	mov	x13, x10
    40205b0c:	f84085ae 	ldr	x14, [x13], #8
    40205b10:	f800852e 	str	x14, [x9], #8
    40205b14:	eb08013f 	cmp	x9, x8
    40205b18:	54ffffa3 	b.cc	40205b0c <memcpy+0xc0>  // b.lo, b.ul, b.last
    40205b1c:	8b0c0141 	add	x1, x10, x12
    40205b20:	92400962 	and	x2, x11, #0x7
    40205b24:	8b020109 	add	x9, x8, x2
    40205b28:	eb09011f 	cmp	x8, x9
    40205b2c:	540000c3 	b.cc	40205b44 <memcpy+0xf8>  // b.lo, b.ul, b.last
    40205b30:	1400002f 	b	40205bec <memcpy+0x1a0>
    40205b34:	aa0003e8 	mov	x8, x0
    40205b38:	8b020009 	add	x9, x0, x2
    40205b3c:	eb09001f 	cmp	x0, x9
    40205b40:	54000562 	b.cs	40205bec <memcpy+0x1a0>  // b.hs, b.nlast
    40205b44:	f100105f 	cmp	x2, #0x4
    40205b48:	540004a3 	b.cc	40205bdc <memcpy+0x190>  // b.lo, b.ul, b.last
    40205b4c:	cb01010a 	sub	x10, x8, x1
    40205b50:	f100815f 	cmp	x10, #0x20
    40205b54:	54000443 	b.cc	40205bdc <memcpy+0x190>  // b.lo, b.ul, b.last
    40205b58:	39400c2a 	ldrb	w10, [x1, #3]
    40205b5c:	3940082b 	ldrb	w11, [x1, #2]
    40205b60:	3940002c 	ldrb	w12, [x1]
    40205b64:	3940042d 	ldrb	w13, [x1, #1]
    40205b68:	39000d0a 	strb	w10, [x8, #3]
    40205b6c:	927e044a 	and	x10, x2, #0xc
    40205b70:	f100115f 	cmp	x10, #0x4
    40205b74:	3900090b 	strb	w11, [x8, #2]
    40205b78:	3900050d 	strb	w13, [x8, #1]
    40205b7c:	3900010c 	strb	w12, [x8]
    40205b80:	54000260 	b.eq	40205bcc <memcpy+0x180>  // b.none
    40205b84:	39401c2b 	ldrb	w11, [x1, #7]
    40205b88:	3940182c 	ldrb	w12, [x1, #6]
    40205b8c:	f100215f 	cmp	x10, #0x8
    40205b90:	3940102d 	ldrb	w13, [x1, #4]
    40205b94:	3940142e 	ldrb	w14, [x1, #5]
    40205b98:	39001d0b 	strb	w11, [x8, #7]
    40205b9c:	3900190c 	strb	w12, [x8, #6]
    40205ba0:	3900150e 	strb	w14, [x8, #5]
    40205ba4:	3900110d 	strb	w13, [x8, #4]
    40205ba8:	54000120 	b.eq	40205bcc <memcpy+0x180>  // b.none
    40205bac:	39402c2b 	ldrb	w11, [x1, #11]
    40205bb0:	3940282c 	ldrb	w12, [x1, #10]
    40205bb4:	3940202d 	ldrb	w13, [x1, #8]
    40205bb8:	3940242e 	ldrb	w14, [x1, #9]
    40205bbc:	39002d0b 	strb	w11, [x8, #11]
    40205bc0:	3900290c 	strb	w12, [x8, #10]
    40205bc4:	3900250e 	strb	w14, [x8, #9]
    40205bc8:	3900210d 	strb	w13, [x8, #8]
    40205bcc:	eb0a005f 	cmp	x2, x10
    40205bd0:	540000e0 	b.eq	40205bec <memcpy+0x1a0>  // b.none
    40205bd4:	8b0a0108 	add	x8, x8, x10
    40205bd8:	8b0a0021 	add	x1, x1, x10
    40205bdc:	3840142a 	ldrb	w10, [x1], #1
    40205be0:	3800150a 	strb	w10, [x8], #1
    40205be4:	eb09011f 	cmp	x8, x9
    40205be8:	54ffffa1 	b.ne	40205bdc <memcpy+0x190>  // b.any
    40205bec:	d65f03c0 	ret
    40205bf0:	eb08013f 	cmp	x9, x8
    40205bf4:	54fff942 	b.cs	40205b1c <memcpy+0xd0>  // b.hs, b.nlast
    40205bf8:	aa0a03ed 	mov	x13, x10
    40205bfc:	aa0d03f0 	mov	x16, x13
    40205c00:	394009af 	ldrb	w15, [x13, #2]
    40205c04:	394005ae 	ldrb	w14, [x13, #1]
    40205c08:	38404e11 	ldrb	w17, [x16, #4]!
    40205c0c:	39400a12 	ldrb	w18, [x16, #2]
    40205c10:	394001a1 	ldrb	w1, [x13]
    40205c14:	39400da2 	ldrb	w2, [x13, #3]
    40205c18:	d370bdef 	lsl	x15, x15, #16
    40205c1c:	394015a3 	ldrb	w3, [x13, #5]
    40205c20:	39400e10 	ldrb	w16, [x16, #3]
    40205c24:	53103e52 	lsl	w18, w18, #16
    40205c28:	aa0e202e 	orr	x14, x1, x14, lsl #8
    40205c2c:	aa0261ef 	orr	x15, x15, x2, lsl #24
    40205c30:	910021ad 	add	x13, x13, #0x8
    40205c34:	2a032231 	orr	w17, w17, w3, lsl #8
    40205c38:	2a106250 	orr	w16, w18, w16, lsl #24
    40205c3c:	aa0e01ee 	orr	x14, x15, x14
    40205c40:	2a11020f 	orr	w15, w16, w17
    40205c44:	aa0f81ce 	orr	x14, x14, x15, lsl #32
    40205c48:	f800852e 	str	x14, [x9], #8
    40205c4c:	eb08013f 	cmp	x9, x8
    40205c50:	54fffd63 	b.cc	40205bfc <memcpy+0x1b0>  // b.lo, b.ul, b.last
    40205c54:	17ffffb2 	b	40205b1c <memcpy+0xd0>

0000000040205c58 <__umodti3>:
    40205c58:	d100c3ff 	sub	sp, sp, #0x30
    40205c5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    40205c60:	910083fd 	add	x29, sp, #0x20
    40205c64:	910003e8 	mov	x8, sp
    40205c68:	97fffeb6 	bl	40205740 <compiler_builtins::int::specialized_div_rem::u128_div_rem>
    40205c6c:	a94107e0 	ldp	x0, x1, [sp, #16]
    40205c70:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40205c74:	9100c3ff 	add	sp, sp, #0x30
    40205c78:	d65f03c0 	ret

0000000040205c7c <memset>:
    40205c7c:	f100405f 	cmp	x2, #0x10
    40205c80:	540009e3 	b.cc	40205dbc <memset+0x140>  // b.lo, b.ul, b.last
    40205c84:	cb0003eb 	neg	x11, x0
    40205c88:	92400968 	and	x8, x11, #0x7
    40205c8c:	8b080009 	add	x9, x0, x8
    40205c90:	eb09001f 	cmp	x0, x9
    40205c94:	54000302 	b.cs	40205cf4 <memset+0x78>  // b.hs, b.nlast
    40205c98:	f100111f 	cmp	x8, #0x4
    40205c9c:	aa0003ea 	mov	x10, x0
    40205ca0:	54000243 	b.cc	40205ce8 <memset+0x6c>  // b.lo, b.ul, b.last
    40205ca4:	0e020c20 	dup	v0.4h, w1
    40205ca8:	927e016b 	and	x11, x11, #0x4
    40205cac:	aa0003ec 	mov	x12, x0
    40205cb0:	8b0b000a 	add	x10, x0, x11
    40205cb4:	aa0b03ed 	mov	x13, x11
    40205cb8:	5e0e0401 	mov	h1, v0.h[3]
    40205cbc:	5e0a0402 	mov	h2, v0.h[2]
    40205cc0:	5e060403 	mov	h3, v0.h[1]
    40205cc4:	3d000180 	str	b0, [x12]
    40205cc8:	f10011ad 	subs	x13, x13, #0x4
    40205ccc:	3c003181 	stur	b1, [x12, #3]
    40205cd0:	3c002182 	stur	b2, [x12, #2]
    40205cd4:	3c001183 	stur	b3, [x12, #1]
    40205cd8:	9100118c 	add	x12, x12, #0x4
    40205cdc:	54ffff41 	b.ne	40205cc4 <memset+0x48>  // b.any
    40205ce0:	eb0b011f 	cmp	x8, x11
    40205ce4:	54000080 	b.eq	40205cf4 <memset+0x78>  // b.none
    40205ce8:	38001541 	strb	w1, [x10], #1
    40205cec:	eb09015f 	cmp	x10, x9
    40205cf0:	54ffffc1 	b.ne	40205ce8 <memset+0x6c>  // b.any
    40205cf4:	cb08004a 	sub	x10, x2, x8
    40205cf8:	927df148 	and	x8, x10, #0xfffffffffffffff8
    40205cfc:	8b080128 	add	x8, x9, x8
    40205d00:	eb08013f 	cmp	x9, x8
    40205d04:	54000102 	b.cs	40205d24 <memset+0xa8>  // b.hs, b.nlast
    40205d08:	12001c2b 	and	w11, w1, #0xff
    40205d0c:	3200c3ec 	mov	w12, #0x1010101             	// #16843009
    40205d10:	1b0c7d6b 	mul	w11, w11, w12
    40205d14:	aa0b816b 	orr	x11, x11, x11, lsl #32
    40205d18:	f800852b 	str	x11, [x9], #8
    40205d1c:	eb08013f 	cmp	x9, x8
    40205d20:	54ffffc3 	b.cc	40205d18 <memset+0x9c>  // b.lo, b.ul, b.last
    40205d24:	92400942 	and	x2, x10, #0x7
    40205d28:	8b020109 	add	x9, x8, x2
    40205d2c:	eb09011f 	cmp	x8, x9
    40205d30:	54000442 	b.cs	40205db8 <memset+0x13c>  // b.hs, b.nlast
    40205d34:	f100105f 	cmp	x2, #0x4
    40205d38:	540003a3 	b.cc	40205dac <memset+0x130>  // b.lo, b.ul, b.last
    40205d3c:	927e044a 	and	x10, x2, #0xc
    40205d40:	39000d01 	strb	w1, [x8, #3]
    40205d44:	f100115f 	cmp	x10, #0x4
    40205d48:	8b0a010b 	add	x11, x8, x10
    40205d4c:	39000901 	strb	w1, [x8, #2]
    40205d50:	39000501 	strb	w1, [x8, #1]
    40205d54:	39000101 	strb	w1, [x8]
    40205d58:	54000240 	b.eq	40205da0 <memset+0x124>  // b.none
    40205d5c:	0e020c20 	dup	v0.4h, w1
    40205d60:	f100215f 	cmp	x10, #0x8
    40205d64:	5e0e0401 	mov	h1, v0.h[3]
    40205d68:	5e0a0402 	mov	h2, v0.h[2]
    40205d6c:	5e060403 	mov	h3, v0.h[1]
    40205d70:	3c004100 	stur	b0, [x8, #4]
    40205d74:	3c007101 	stur	b1, [x8, #7]
    40205d78:	3c006102 	stur	b2, [x8, #6]
    40205d7c:	3c005103 	stur	b3, [x8, #5]
    40205d80:	54000100 	b.eq	40205da0 <memset+0x124>  // b.none
    40205d84:	5e0e0401 	mov	h1, v0.h[3]
    40205d88:	5e0a0402 	mov	h2, v0.h[2]
    40205d8c:	3c008100 	stur	b0, [x8, #8]
    40205d90:	5e060403 	mov	h3, v0.h[1]
    40205d94:	3c00b101 	stur	b1, [x8, #11]
    40205d98:	3c00a102 	stur	b2, [x8, #10]
    40205d9c:	3c009103 	stur	b3, [x8, #9]
    40205da0:	eb0a005f 	cmp	x2, x10
    40205da4:	aa0b03e8 	mov	x8, x11
    40205da8:	54000080 	b.eq	40205db8 <memset+0x13c>  // b.none
    40205dac:	38001501 	strb	w1, [x8], #1
    40205db0:	eb09011f 	cmp	x8, x9
    40205db4:	54ffffc1 	b.ne	40205dac <memset+0x130>  // b.any
    40205db8:	d65f03c0 	ret
    40205dbc:	aa0003e8 	mov	x8, x0
    40205dc0:	8b020009 	add	x9, x0, x2
    40205dc4:	eb09001f 	cmp	x0, x9
    40205dc8:	54fffb63 	b.cc	40205d34 <memset+0xb8>  // b.lo, b.ul, b.last
    40205dcc:	17fffffb 	b	40205db8 <memset+0x13c>
