
source-SB.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000040200000 <_start>:
    40200000:	d5034fdf 	msr	daifset, #0xf
    40200004:	d5384240 	mrs	x0, currentel
    40200008:	f100101f 	cmp	x0, #0x4
    4020000c:	54000241 	b.ne	40200054 <_start+0x54>  // b.any
    40200010:	d50041bf 	msr	spsel, #0x1
    40200014:	58000260 	ldr	x0, 40200060 <_start+0x60>
    40200018:	9100001f 	mov	sp, x0
    4020001c:	d5381040 	mrs	x0, cpacr_el1
    40200020:	b26c0400 	orr	x0, x0, #0x300000
    40200024:	d5181040 	msr	cpacr_el1, x0
    40200028:	d5033fdf 	isb
    4020002c:	580001e0 	ldr	x0, 40200068 <_start+0x68>
    40200030:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    40200034:	f9000001 	str	x1, [x0]
    40200038:	580001c0 	ldr	x0, 40200070 <_start+0x70>
    4020003c:	580001e1 	ldr	x1, 40200078 <_start+0x78>
    40200040:	eb01001f 	cmp	x0, x1
    40200044:	54000062 	b.cs	40200050 <_start+0x50>  // b.hs, b.nlast
    40200048:	f800841f 	str	xzr, [x0], #8
    4020004c:	17fffffd 	b	40200040 <_start+0x40>
    40200050:	14001043 	b	4020415c <jnox_kernel::kernel_main>
    40200054:	d503205f 	wfe
    40200058:	17ffffff 	b	40200054 <_start+0x54>
    4020005c:	00000000 	udf	#0
    40200060:	40227e30 	.word	0x40227e30
    40200064:	00000000 	.word	0x00000000
    40200068:	40223e20 	.word	0x40223e20
    4020006c:	00000000 	.word	0x00000000
    40200070:	40207710 	.word	0x40207710
    40200074:	00000000 	.word	0x00000000
    40200078:	40223e28 	.word	0x40223e28
	...

0000000040200800 <sched_vectors>:
    40200800:	14000200 00000000 00000000 00000000     ................
	...
    40200880:	140001e0 00000000 00000000 00000000     ................
	...
    40200900:	140001c0 00000000 00000000 00000000     ................
	...
    40200980:	140001a0 00000000 00000000 00000000     ................
	...
    40200a00:	140001b6 00000000 00000000 00000000     ................
	...
    40200a80:	14000161 00000000 00000000 00000000     a...............
	...
    40200b00:	14000140 00000000 00000000 00000000     @...............
	...
    40200b80:	14000120 00000000 00000000 00000000      ...............
	...
    40200c00:	14000100 00000000 00000000 00000000     ................
	...
    40200c80:	140000e0 00000000 00000000 00000000     ................
	...
    40200d00:	140000c0 00000000 00000000 00000000     ................
	...
    40200d80:	140000a0 00000000 00000000 00000000     ................
	...
    40200e00:	14000080 00000000 00000000 00000000     ................
	...
    40200e80:	14000060 00000000 00000000 00000000     `...............
	...
    40200f00:	14000040 00000000 00000000 00000000     @...............
	...
    40200f80:	14000020 00000000 00000000 00000000      ...............
	...
    40201000:	140000aa d10d03ff f90027e9 d5033fdf     .........'...?..
    40201010:	d53be029 f9009fe9 f94027e9 a90007e0     ).;......'@.....
    40201020:	a9010fe2 a90217e4 a9031fe6 a90427e8     .............'..
    40201030:	a9052fea a90637ec a9073fee a90847f0     ./...7...?...G..
    40201040:	a9094ff2 a90a57f4 a90b5ff6 a90c67f8     .O...W..._...g..
    40201050:	a90d6ffa a90e77fc f9007bfe ad0a07e0     .o...w...{......
    40201060:	ad0b0fe2 ad0c17e4 ad0d1fe6 ad0e27e8     .............'..
    40201070:	ad0f2fea ad1037ec ad113fee ad1247f0     ./...7...?...G..
    40201080:	ad134ff2 ad1457f4 ad155ff6 ad1667f8     .O...W..._...g..
    40201090:	ad176ffa ad1877fc ad197ffe d5384029     .o...w......)@8.
    402010a0:	d538400a a90fabe9 d53b4409 d53b442a     .@8......D;.*D;.
    402010b0:	a910abe9 d538d089 d538410a a911abe9     ......8..A8.....
    402010c0:	d53bd049 d53bd06a a912abe9 910003e0     I.;.j.;.........
    402010d0:	9400007e 14000036 d10d03ff f90027e9     ~...6........'..
    402010e0:	d5033fdf d53be029 f9009fe9 f94027e9     .?..).;......'@.
    402010f0:	a90007e0 a9010fe2 a90217e4 a9031fe6     ................
    40201100:	a90427e8 a9052fea a90637ec a9073fee     .'.../...7...?..
    40201110:	a90847f0 a9094ff2 a90a57f4 a90b5ff6     .G...O...W..._..
    40201120:	a90c67f8 a90d6ffa a90e77fc f9007bfe     .g...o...w...{..
    40201130:	ad0a07e0 ad0b0fe2 ad0c17e4 ad0d1fe6     ................
    40201140:	ad0e27e8 ad0f2fea ad1037ec ad113fee     .'.../...7...?..
    40201150:	ad1247f0 ad134ff2 ad1457f4 ad155ff6     .G...O...W..._..
    40201160:	ad1667f8 ad176ffa ad1877fc ad197ffe     .g...o...w......
    40201170:	d5384029 d538400a a90fabe9 d53b4409     )@8..@8......D;.
    40201180:	d53b442a a910abe9 d538d089 d538410a     *D;.......8..A8.
    40201190:	a911abe9 d53bd049 d53bd06a a912abe9     ....I.;.j.;.....
    402011a0:	910003e0 940003a4 14000001              ............

00000000402011ac <sched_start_frame>:
    402011ac:	9100001f 	mov	sp, x0
    402011b0:	a94fabe9 	ldp	x9, x10, [sp, #248]
    402011b4:	d5184029 	msr	elr_el1, x9
    402011b8:	d518400a 	msr	spsr_el1, x10
    402011bc:	a950abe9 	ldp	x9, x10, [sp, #264]
    402011c0:	d51b4409 	msr	fpcr, x9
    402011c4:	d51b442a 	msr	fpsr, x10
    402011c8:	a951abe9 	ldp	x9, x10, [sp, #280]
    402011cc:	d518d089 	msr	tpidr_el1, x9
    402011d0:	d518410a 	msr	sp_el0, x10
    402011d4:	a952abe9 	ldp	x9, x10, [sp, #296]
    402011d8:	d51bd049 	msr	tpidr_el0, x9
    402011dc:	d51bd06a 	msr	tpidrro_el0, x10
    402011e0:	ad4a07e0 	ldp	q0, q1, [sp, #320]
    402011e4:	ad4b0fe2 	ldp	q2, q3, [sp, #352]
    402011e8:	ad4c17e4 	ldp	q4, q5, [sp, #384]
    402011ec:	ad4d1fe6 	ldp	q6, q7, [sp, #416]
    402011f0:	ad4e27e8 	ldp	q8, q9, [sp, #448]
    402011f4:	ad4f2fea 	ldp	q10, q11, [sp, #480]
    402011f8:	ad5037ec 	ldp	q12, q13, [sp, #512]
    402011fc:	ad513fee 	ldp	q14, q15, [sp, #544]
    40201200:	ad5247f0 	ldp	q16, q17, [sp, #576]
    40201204:	ad534ff2 	ldp	q18, q19, [sp, #608]
    40201208:	ad5457f4 	ldp	q20, q21, [sp, #640]
    4020120c:	ad555ff6 	ldp	q22, q23, [sp, #672]
    40201210:	ad5667f8 	ldp	q24, q25, [sp, #704]
    40201214:	ad576ffa 	ldp	q26, q27, [sp, #736]
    40201218:	ad5877fc 	ldp	q28, q29, [sp, #768]
    4020121c:	ad597ffe 	ldp	q30, q31, [sp, #800]
    40201220:	d503201f 	nop
    40201224:	10112e29 	adr	x9, 402237e8 <jnox_ap_returns>
    40201228:	f940012a 	ldr	x10, [x9]
    4020122c:	f101015f 	cmp	x10, #0x40
    40201230:	54ffee82 	b.cs	40201000 <sched_vectors+0x800>  // b.hs, b.nlast
    40201234:	9100054b 	add	x11, x10, #0x1
    40201238:	f800852b 	str	x11, [x9], #8
    4020123c:	d280030b 	mov	x11, #0x18                  	// #24
    40201240:	9b0b2549 	madd	x9, x10, x11, x9
    40201244:	910003ea 	mov	x10, sp
    40201248:	d538402b 	mrs	x11, elr_el1
    4020124c:	a9002d2a 	stp	x10, x11, [x9]
    40201250:	d5033fdf 	isb
    40201254:	d53be02a 	mrs	x10, cntpct_el0
    40201258:	f900092a 	str	x10, [x9, #16]
    4020125c:	a94007e0 	ldp	x0, x1, [sp]
    40201260:	a9410fe2 	ldp	x2, x3, [sp, #16]
    40201264:	a94217e4 	ldp	x4, x5, [sp, #32]
    40201268:	a9431fe6 	ldp	x6, x7, [sp, #48]
    4020126c:	a94427e8 	ldp	x8, x9, [sp, #64]
    40201270:	a9452fea 	ldp	x10, x11, [sp, #80]
    40201274:	a94637ec 	ldp	x12, x13, [sp, #96]
    40201278:	a9473fee 	ldp	x14, x15, [sp, #112]
    4020127c:	a94847f0 	ldp	x16, x17, [sp, #128]
    40201280:	a9494ff2 	ldp	x18, x19, [sp, #144]
    40201284:	a94a57f4 	ldp	x20, x21, [sp, #160]
    40201288:	a94b5ff6 	ldp	x22, x23, [sp, #176]
    4020128c:	a94c67f8 	ldp	x24, x25, [sp, #192]
    40201290:	a94d6ffa 	ldp	x26, x27, [sp, #208]
    40201294:	a94e77fc 	ldp	x28, x29, [sp, #224]
    40201298:	f9407bfe 	ldr	x30, [sp, #240]
    4020129c:	910d03ff 	add	sp, sp, #0x340
    402012a0:	d5033f5f 	clrex
    402012a4:	d69f03e0 	eret

00000000402012a8 <jnox_kernel::ordinary_reservations::unexpected>:
    402012a8:	f81f0ffe 	str	x30, [sp, #-16]!
    402012ac:	52800060 	mov	w0, #0x3                   	// #3
    402012b0:	52800021 	mov	w1, #0x1                   	// #1
    402012b4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    402012b8:	52800043 	mov	w3, #0x2                   	// #2
    402012bc:	aa1f03e4 	mov	x4, xzr
    402012c0:	aa1f03e5 	mov	x5, xzr
    402012c4:	940004ec 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>

00000000402012c8 <jnox_kernel::ordinary_reservations::irq>:
    402012c8:	d10583ff 	sub	sp, sp, #0x160
    402012cc:	a9107bfd 	stp	x29, x30, [sp, #256]
    402012d0:	a9116ffc 	stp	x28, x27, [sp, #272]
    402012d4:	a91267fa 	stp	x26, x25, [sp, #288]
    402012d8:	a9135ff8 	stp	x24, x23, [sp, #304]
    402012dc:	a91457f6 	stp	x22, x21, [sp, #320]
    402012e0:	a9154ff4 	stp	x20, x19, [sp, #336]
    402012e4:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402012e8:	f9420108 	ldr	x8, [x8, #1024]
    402012ec:	f100091f 	cmp	x8, #0x2
    402012f0:	54003220 	b.eq	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.none
    402012f4:	aa0003f4 	mov	x20, x0
    402012f8:	d0000038 	adrp	x24, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402012fc:	d503201f 	nop
    40201300:	100b2119 	adr	x25, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520>
    40201304:	f942b308 	ldr	x8, [x24, #1376]
    40201308:	8b083b29 	add	x9, x25, x8, lsl #14
    4020130c:	eb00013f 	cmp	x9, x0
    40201310:	54003128 	b.hi	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.pmore
    40201314:	b10d069f 	cmn	x20, #0x341
    40201318:	540030e8 	b.hi	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.pmore
    4020131c:	d372c508 	lsl	x8, x8, #14
    40201320:	8b080328 	add	x8, x25, x8
    40201324:	91401108 	add	x8, x8, #0x4, lsl #12
    40201328:	910d0289 	add	x9, x20, #0x340
    4020132c:	eb08013f 	cmp	x9, x8
    40201330:	54003028 	b.hi	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.pmore
    40201334:	5280019a 	mov	w26, #0xc                   	// #12
    40201338:	72a1003a 	movk	w26, #0x801, lsl #16
    4020133c:	f9409e95 	ldr	x21, [x20, #312]
    40201340:	b9400356 	ldr	w22, [x26]
    40201344:	d53be237 	mrs	x23, cntp_ctl_el0
    40201348:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020134c:	91156129 	add	x9, x9, #0x558
    40201350:	f9401928 	ldr	x8, [x9, #48]
    40201354:	f9400133 	ldr	x19, [x9]
    40201358:	f100051f 	cmp	x8, #0x1
    4020135c:	540000e0 	b.eq	40201378 <jnox_kernel::ordinary_reservations::irq+0xb0>  // b.none
    40201360:	b100067f 	cmn	x19, #0x1
    40201364:	54000060 	b.eq	40201370 <jnox_kernel::ordinary_reservations::irq+0xa8>  // b.none
    40201368:	91000673 	add	x19, x19, #0x1
    4020136c:	14000003 	b	40201378 <jnox_kernel::ordinary_reservations::irq+0xb0>
    40201370:	b4004268 	cbz	x8, 40201bbc <jnox_kernel::ordinary_reservations::irq+0x8f4>
    40201374:	aa1f03f3 	mov	x19, xzr
    40201378:	d000003b 	adrp	x27, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020137c:	9115837b 	add	x27, x27, #0x560
    40201380:	f9401369 	ldr	x9, [x27, #32]
    40201384:	a909a3e9 	stp	x9, x8, [sp, #152]
    40201388:	f9400363 	ldr	x3, [x27]
    4020138c:	a90adff6 	stp	x22, x23, [sp, #168]
    40201390:	910263e4 	add	x4, sp, #0x98
    40201394:	52800080 	mov	w0, #0x4                   	// #4
    40201398:	aa1503e1 	mov	x1, x21
    4020139c:	aa1303e2 	mov	x2, x19
    402013a0:	9400045e 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    402013a4:	f9401368 	ldr	x8, [x27, #32]
    402013a8:	120026c9 	and	w9, w22, #0x3ff
    402013ac:	7100793f 	cmp	w9, #0x1e
    402013b0:	54004ae1 	b.ne	40201d0c <jnox_kernel::ordinary_reservations::irq+0xa44>  // b.any
    402013b4:	92400ae9 	and	x9, x23, #0x7
    402013b8:	f100153f 	cmp	x9, #0x5
    402013bc:	54004a81 	b.ne	40201d0c <jnox_kernel::ordinary_reservations::irq+0xa44>  // b.any
    402013c0:	eb0802bf 	cmp	x21, x8
    402013c4:	54004a43 	b.cc	40201d0c <jnox_kernel::ordinary_reservations::irq+0xa44>  // b.lo, b.ul, b.last
    402013c8:	d51be23f 	msr	cntp_ctl_el0, xzr
    402013cc:	d5033fdf 	isb
    402013d0:	d5033f9f 	dsb	sy
    402013d4:	b9000756 	str	w22, [x26, #4]
    402013d8:	d5033f9f 	dsb	sy
    402013dc:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402013e0:	f942c508 	ldr	x8, [x8, #1416]
    402013e4:	f100051f 	cmp	x8, #0x1
    402013e8:	540003e1 	b.ne	40201464 <jnox_kernel::ordinary_reservations::irq+0x19c>  // b.any
    402013ec:	aa1403e0 	mov	x0, x20
    402013f0:	aa1503e1 	mov	x1, x21
    402013f4:	2a1f03e2 	mov	w2, wzr
    402013f8:	aa1f03e3 	mov	x3, xzr
    402013fc:	9400063e 	bl	40202cf4 <jnox_kernel::ordinary_reservations::Runtime::close>
    40201400:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201404:	9114e108 	add	x8, x8, #0x538
    40201408:	91000669 	add	x9, x19, #0x1
    4020140c:	a9402908 	ldp	x8, x10, [x8]
    40201410:	9bca7d2b 	umulh	x11, x9, x10
    40201414:	eb0b03ff 	cmp	xzr, x11
    40201418:	1a9f07eb 	cset	w11, ne  // ne = any
    4020141c:	9b0a7d29 	mul	x9, x9, x10
    40201420:	ab080122 	adds	x2, x9, x8
    40201424:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40201428:	370046eb 	tbnz	w11, #0, 40201d04 <jnox_kernel::ordinary_reservations::irq+0xa3c>
    4020142c:	350046c8 	cbnz	w8, 40201d04 <jnox_kernel::ordinary_reservations::irq+0xa3c>
    40201430:	aa1303e0 	mov	x0, x19
    40201434:	aa1f03e1 	mov	x1, xzr
    40201438:	9400060e 	bl	40202c70 <jnox_kernel::ordinary_reservations::Runtime::arm>
    4020143c:	aa1303e0 	mov	x0, x19
    40201440:	52800041 	mov	w1, #0x2                   	// #2
    40201444:	a9554ff4 	ldp	x20, x19, [sp, #336]
    40201448:	a95457f6 	ldp	x22, x21, [sp, #320]
    4020144c:	a9535ff8 	ldp	x24, x23, [sp, #304]
    40201450:	a95267fa 	ldp	x26, x25, [sp, #288]
    40201454:	a9516ffc 	ldp	x28, x27, [sp, #272]
    40201458:	a9507bfd 	ldp	x29, x30, [sp, #256]
    4020145c:	910583ff 	add	sp, sp, #0x160
    40201460:	1400075e 	b	402031d8 <jnox_kernel::ordinary_reservations::Runtime::select>
    40201464:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201468:	9114c129 	add	x9, x9, #0x530
    4020146c:	f940192a 	ldr	x10, [x9, #48]
    40201470:	f100095f 	cmp	x10, #0x2
    40201474:	54002601 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201478:	39400129 	ldrb	w9, [x9]
    4020147c:	71000d3f 	cmp	w9, #0x3
    40201480:	540025a1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201484:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201488:	91152129 	add	x9, x9, #0x548
    4020148c:	f9001934 	str	x20, [x9, #48]
    40201490:	f9401d25 	ldr	x5, [x9, #56]
    40201494:	cb0502aa 	sub	x10, x21, x5
    40201498:	f9400129 	ldr	x9, [x9]
    4020149c:	eb09015f 	cmp	x10, x9
    402014a0:	540044e8 	b.hi	40201d3c <jnox_kernel::ordinary_reservations::irq+0xa74>  // b.pmore
    402014a4:	b40013b3 	cbz	x19, 40201718 <jnox_kernel::ordinary_reservations::irq+0x450>
    402014a8:	92800028 	mov	x8, #0xfffffffffffffffe    	// #-2
    402014ac:	d0000037 	adrp	x23, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014b0:	d0000038 	adrp	x24, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014b4:	91174318 	add	x24, x24, #0x5d0
    402014b8:	b4000428 	cbz	x8, 4020153c <jnox_kernel::ordinary_reservations::irq+0x274>
    402014bc:	aa0803f6 	mov	x22, x8
    402014c0:	910263e8 	add	x8, sp, #0x98
    402014c4:	91000ac0 	add	x0, x22, #0x2
    402014c8:	94000780 	bl	402032c8 <jnox_kernel::ordinary_reservations::snapshot>
    402014cc:	a949d7f4 	ldp	x20, x21, [sp, #152]
    402014d0:	f942aae8 	ldr	x8, [x23, #1360]
    402014d4:	eb08027f 	cmp	x19, x8
    402014d8:	54000161 	b.ne	40201504 <jnox_kernel::ordinary_reservations::irq+0x23c>  // b.any
    402014dc:	f94057e8 	ldr	x8, [sp, #168]
    402014e0:	d5033fdf 	isb
    402014e4:	d53be021 	mrs	x1, cntpct_el0
    402014e8:	a909d7f4 	stp	x20, x21, [sp, #152]
    402014ec:	a90affe8 	stp	x8, xzr, [sp, #168]
    402014f0:	91000ac3 	add	x3, x22, #0x2
    402014f4:	910263e4 	add	x4, sp, #0x98
    402014f8:	528002a0 	mov	w0, #0x15                  	// #21
    402014fc:	aa1303e2 	mov	x2, x19
    40201500:	94000406 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40201504:	f85f0308 	ldur	x8, [x24, #-16]
    40201508:	eb08029f 	cmp	x20, x8
    4020150c:	540000a1 	b.ne	40201520 <jnox_kernel::ordinary_reservations::irq+0x258>  // b.any
    40201510:	f8408709 	ldr	x9, [x24], #8
    40201514:	910006c8 	add	x8, x22, #0x1
    40201518:	eb0902bf 	cmp	x21, x9
    4020151c:	54fffce0 	b.eq	402014b8 <jnox_kernel::ordinary_reservations::irq+0x1f0>  // b.none
    40201520:	91000ac3 	add	x3, x22, #0x2
    40201524:	52800060 	mov	w0, #0x3                   	// #3
    40201528:	52800101 	mov	w1, #0x8                   	// #8
    4020152c:	aa1303e2 	mov	x2, x19
    40201530:	aa1403e4 	mov	x4, x20
    40201534:	aa1503e5 	mov	x5, x21
    40201538:	9400044f 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>
    4020153c:	f942aae8 	ldr	x8, [x23, #1360]
    40201540:	eb08027f 	cmp	x19, x8
    40201544:	54004220 	b.eq	40201d88 <jnox_kernel::ordinary_reservations::irq+0xac0>  // b.none
    40201548:	94000713 	bl	40203194 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    4020154c:	910263e8 	add	x8, sp, #0x98
    40201550:	aa1303e1 	mov	x1, x19
    40201554:	940008a7 	bl	402037f0 <jnox_kernel::reservation_jobs::Jobs::open>
    40201558:	f9404fe8 	ldr	x8, [sp, #152]
    4020155c:	f100091f 	cmp	x8, #0x2
    40201560:	54004200 	b.eq	40201da0 <jnox_kernel::ordinary_reservations::irq+0xad8>  // b.none
    40201564:	9100c3e0 	add	x0, sp, #0x30
    40201568:	910263e1 	add	x1, sp, #0x98
    4020156c:	52800d02 	mov	w2, #0x68                  	// #104
    40201570:	94001101 	bl	40205974 <memcpy>
    40201574:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201578:	9114e129 	add	x9, x9, #0x538
    4020157c:	a9402129 	ldp	x9, x8, [x9]
    40201580:	9bc87e6a 	umulh	x10, x19, x8
    40201584:	eb0a03ff 	cmp	xzr, x10
    40201588:	1a9f07eb 	cset	w11, ne  // ne = any
    4020158c:	9b087e6a 	mul	x10, x19, x8
    40201590:	ab09014c 	adds	x12, x10, x9
    40201594:	1a9f37ea 	cset	w10, cs  // cs = hs, nlast
    40201598:	37003b6b 	tbnz	w11, #0, 40201d04 <jnox_kernel::ordinary_reservations::irq+0xa3c>
    4020159c:	35003b4a 	cbnz	w10, 40201d04 <jnox_kernel::ordinary_reservations::irq+0xa3c>
    402015a0:	9100066b 	add	x11, x19, #0x1
    402015a4:	9bc87d6a 	umulh	x10, x11, x8
    402015a8:	eb0a03ff 	cmp	xzr, x10
    402015ac:	1a9f07ea 	cset	w10, ne  // ne = any
    402015b0:	9b087d68 	mul	x8, x11, x8
    402015b4:	ab090108 	adds	x8, x8, x9
    402015b8:	a90223ec 	stp	x12, x8, [sp, #32]
    402015bc:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    402015c0:	37003a2a 	tbnz	w10, #0, 40201d04 <jnox_kernel::ordinary_reservations::irq+0xa3c>
    402015c4:	35003a08 	cbnz	w8, 40201d04 <jnox_kernel::ordinary_reservations::irq+0xa3c>
    402015c8:	aa1f03f6 	mov	x22, xzr
    402015cc:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402015d0:	39424beb 	ldrb	w11, [sp, #146]
    402015d4:	9100c3e9 	add	x9, sp, #0x30
    402015d8:	9100613d 	add	x29, x9, #0x18
    402015dc:	b94033fc 	ldr	w28, [sp, #48]
    402015e0:	9100e137 	add	x23, x9, #0x38
    402015e4:	91004138 	add	x24, x9, #0x10
    402015e8:	f9401ff5 	ldr	x21, [sp, #56]
    402015ec:	9100056a 	add	x10, x11, #0x1
    402015f0:	71000d7f 	cmp	w11, #0x3
    402015f4:	f902ad13 	str	x19, [x8, #1368]
    402015f8:	91000568 	add	x8, x11, #0x1
    402015fc:	a9012fe8 	stp	x8, x11, [sp, #16]
    40201600:	1a8a03f9 	csel	w25, wzr, w10, eq  // eq = none
    40201604:	91016134 	add	x20, x9, #0x58
    40201608:	9101813a 	add	x26, x9, #0x60
    4020160c:	52800028 	mov	w8, #0x1                   	// #1
    40201610:	8b1613a9 	add	x9, x29, x22, lsl #4
    40201614:	8b1612ea 	add	x10, x23, x22, lsl #4
    40201618:	d5033fdf 	isb
    4020161c:	d53be021 	mrs	x1, cntpct_el0
    40201620:	2a0803fb 	mov	w27, w8
    40201624:	a9402528 	ldp	x8, x9, [x9]
    40201628:	a909a7e8 	stp	x8, x9, [sp, #152]
    4020162c:	a9402548 	ldp	x8, x9, [x10]
    40201630:	a90aa7e8 	stp	x8, x9, [sp, #168]
    40201634:	910263e4 	add	x4, sp, #0x98
    40201638:	528000a0 	mov	w0, #0x5                   	// #5
    4020163c:	aa1303e2 	mov	x2, x19
    40201640:	aa1603e3 	mov	x3, x22
    40201644:	940003b5 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40201648:	d5033fdf 	isb
    4020164c:	d53be021 	mrs	x1, cntpct_el0
    40201650:	b8767b08 	ldr	w8, [x24, x22, lsl #2]
    40201654:	eb1502df 	cmp	x22, x21
    40201658:	b8767a89 	ldr	w9, [x20, x22, lsl #2]
    4020165c:	38766b4a 	ldrb	w10, [x26, x22]
    40201660:	1a9f17eb 	cset	w11, eq  // eq = none
    40201664:	a909a7e8 	stp	x8, x9, [sp, #152]
    40201668:	6a0b039f 	tst	w28, w11
    4020166c:	9a9f1328 	csel	x8, x25, xzr, ne  // ne = any
    40201670:	a90aa3ea 	stp	x10, x8, [sp, #168]
    40201674:	910263e4 	add	x4, sp, #0x98
    40201678:	528000c0 	mov	w0, #0x6                   	// #6
    4020167c:	aa1303e2 	mov	x2, x19
    40201680:	aa1603e3 	mov	x3, x22
    40201684:	940003a5 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40201688:	2a1f03e8 	mov	w8, wzr
    4020168c:	52800036 	mov	w22, #0x1                   	// #1
    40201690:	3707fc1b 	tbnz	w27, #0, 40201610 <jnox_kernel::ordinary_reservations::irq+0x348>
    40201694:	3400287c 	cbz	w28, 40201ba0 <jnox_kernel::ordinary_reservations::irq+0x8d8>
    40201698:	f9400fed 	ldr	x13, [sp, #24]
    4020169c:	71000dbf 	cmp	w13, #0x3
    402016a0:	540014a0 	b.eq	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.none
    402016a4:	f1000abf 	cmp	x21, #0x2
    402016a8:	54003922 	b.cs	40201dcc <jnox_kernel::ordinary_reservations::irq+0xb04>  // b.hs, b.nlast
    402016ac:	d503201f 	nop
    402016b0:	1002ea88 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402016b4:	8b150d0b 	add	x11, x8, x21, lsl #3
    402016b8:	f940e168 	ldr	x8, [x11, #448]
    402016bc:	f940e969 	ldr	x9, [x11, #464]
    402016c0:	f940c96c 	ldr	x12, [x11, #400]
    402016c4:	9100c3ea 	add	x10, sp, #0x30
    402016c8:	8b15114a 	add	x10, x10, x21, lsl #4
    402016cc:	f940214a 	ldr	x10, [x10, #64]
    402016d0:	eb0a019f 	cmp	x12, x10
    402016d4:	54000060 	b.eq	402016e0 <jnox_kernel::ordinary_reservations::irq+0x418>  // b.none
    402016d8:	f900c96a 	str	x10, [x11, #400]
    402016dc:	f900d17f 	str	xzr, [x11, #416]
    402016e0:	d000010b 	adrp	x11, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520+0xb8e0>
    402016e4:	f943f56b 	ldr	x11, [x11, #2024]
    402016e8:	d000002c 	adrp	x12, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402016ec:	9114018c 	add	x12, x12, #0x500
    402016f0:	a9004d95 	stp	x21, x19, [x12]
    402016f4:	a901218b 	stp	x11, x8, [x12, #16]
    402016f8:	a9022989 	stp	x9, x10, [x12, #32]
    402016fc:	3900c18d 	strb	w13, [x12, #48]
    40201700:	f94017f4 	ldr	x20, [sp, #40]
    40201704:	3400286d 	cbz	w13, 40201c10 <jnox_kernel::ordinary_reservations::irq+0x948>
    40201708:	b104011f 	cmn	x8, #0x100
    4020170c:	540036a2 	b.cs	40201de0 <jnox_kernel::ordinary_reservations::irq+0xb18>  // b.hs, b.nlast
    40201710:	91040108 	add	x8, x8, #0x100
    40201714:	14000140 	b	40201c14 <jnox_kernel::ordinary_reservations::irq+0x94c>
    40201718:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020171c:	f942f129 	ldr	x9, [x9, #1504]
    40201720:	f100093f 	cmp	x9, #0x2
    40201724:	54001080 	b.eq	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.none
    40201728:	b5001068 	cbnz	x8, 40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>
    4020172c:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201730:	f942ad08 	ldr	x8, [x8, #1368]
    40201734:	b100051f 	cmn	x8, #0x1
    40201738:	54000fe1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    4020173c:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201740:	f9432d08 	ldr	x8, [x8, #1624]
    40201744:	eb0800bf 	cmp	x5, x8
    40201748:	54000f61 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    4020174c:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201750:	f9429d29 	ldr	x9, [x9, #1336]
    40201754:	eb08013f 	cmp	x9, x8
    40201758:	54000ee1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    4020175c:	d0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520+0xb8e0>
    40201760:	f943f508 	ldr	x8, [x8, #2024]
    40201764:	f100051f 	cmp	x8, #0x1
    40201768:	54000e61 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    4020176c:	d503201f 	nop
    40201770:	10110388 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    40201774:	c8dffd09 	ldar	x9, [x8]
    40201778:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020177c:	f942354a 	ldr	x10, [x10, #1128]
    40201780:	aa0a0129 	orr	x9, x9, x10
    40201784:	b5000d89 	cbnz	x9, 40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>
    40201788:	aa1f03eb 	mov	x11, xzr
    4020178c:	5280002a 	mov	w10, #0x1                   	// #1
    40201790:	d503201f 	nop
    40201794:	1002e377 	adr	x23, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40201798:	8b0b02e9 	add	x9, x23, x11
    4020179c:	3941e129 	ldrb	w9, [x9, #120]
    402017a0:	3600008a 	tbz	w10, #0, 402017b0 <jnox_kernel::ordinary_reservations::irq+0x4e8>
    402017a4:	2a1f03ea 	mov	w10, wzr
    402017a8:	5280002b 	mov	w11, #0x1                   	// #1
    402017ac:	34ffff69 	cbz	w9, 40201798 <jnox_kernel::ordinary_reservations::irq+0x4d0>
    402017b0:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402017b4:	9111814a 	add	x10, x10, #0x460
    402017b8:	3940014b 	ldrb	w11, [x10]
    402017bc:	f940094a 	ldr	x10, [x10, #16]
    402017c0:	7100013f 	cmp	w9, #0x0
    402017c4:	7a430960 	ccmp	w11, #0x3, #0x0, eq  // eq = none
    402017c8:	fa400940 	ccmp	x10, #0x0, #0x0, eq  // eq = none
    402017cc:	54000b41 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402017d0:	d000010b 	adrp	x11, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520+0xb8e0>
    402017d4:	911fc16b 	add	x11, x11, #0x7f0
    402017d8:	f9400969 	ldr	x9, [x11, #16]
    402017dc:	f940056a 	ldr	x10, [x11, #8]
    402017e0:	f940016b 	ldr	x11, [x11]
    402017e4:	d000010c 	adrp	x12, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520+0xb8e0>
    402017e8:	910f818c 	add	x12, x12, #0x3e0
    402017ec:	eb0c017f 	cmp	x11, x12
    402017f0:	54000a21 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402017f4:	d503201f 	nop
    402017f8:	1000492b 	adr	x11, 4020211c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520>
    402017fc:	eb0b015f 	cmp	x10, x11
    40201800:	540009a1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201804:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201808:	f943254a 	ldr	x10, [x10, #1608]
    4020180c:	eb0a013f 	cmp	x9, x10
    40201810:	54000928 	b.hi	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.pmore
    40201814:	aa1f03e9 	mov	x9, xzr
    40201818:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020181c:	911aa14a 	add	x10, x10, #0x6a8
    40201820:	d503201f 	nop
    40201824:	1002f63a 	adr	x26, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40201828:	d503201f 	nop
    4020182c:	10112e3b 	adr	x27, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40201830:	d503201f 	nop
    40201834:	1002f63d 	adr	x29, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40201838:	d503201f 	nop
    4020183c:	10112e3c 	adr	x28, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40201840:	d10d032b 	sub	x11, x25, #0x340
    40201844:	d503201f 	nop
    40201848:	10112e4c 	adr	x12, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    4020184c:	f100413f 	cmp	x9, #0x10
    40201850:	54000740 	b.eq	40201938 <jnox_kernel::ordinary_reservations::irq+0x670>  // b.none
    40201854:	8b0902ed 	add	x13, x23, x9
    40201858:	f940b5ad 	ldr	x13, [x13, #360]
    4020185c:	f85d014e 	ldur	x14, [x10, #-48]
    40201860:	eb0d01df 	cmp	x14, x13
    40201864:	9140116b 	add	x11, x11, #0x4, lsl #12
    40201868:	fa4d0160 	ccmp	x11, x13, #0x0, eq  // eq = none
    4020186c:	54000641 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201870:	f9407dae 	ldr	x14, [x13, #248]
    40201874:	f85d814f 	ldur	x15, [x10, #-40]
    40201878:	eb0f01df 	cmp	x14, x15
    4020187c:	540005c1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201880:	f94081ae 	ldr	x14, [x13, #256]
    40201884:	f85e014f 	ldur	x15, [x10, #-32]
    40201888:	eb0f01df 	cmp	x14, x15
    4020188c:	54000541 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201890:	f9404dae 	ldr	x14, [x13, #152]
    40201894:	f85e814f 	ldur	x15, [x10, #-24]
    40201898:	eb0f01df 	cmp	x14, x15
    4020189c:	540004c1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402018a0:	f9408dad 	ldr	x13, [x13, #280]
    402018a4:	f85f014e 	ldur	x14, [x10, #-16]
    402018a8:	eb0e01bf 	cmp	x13, x14
    402018ac:	54000441 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402018b0:	8b09034d 	add	x13, x26, x9
    402018b4:	c8dffdad 	ldar	x13, [x13]
    402018b8:	b10005bf 	cmn	x13, #0x1
    402018bc:	540003c1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402018c0:	8b09036d 	add	x13, x27, x9
    402018c4:	c8dffdad 	ldar	x13, [x13]
    402018c8:	b500036d 	cbnz	x13, 40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>
    402018cc:	8b0903ad 	add	x13, x29, x9
    402018d0:	c8dffdad 	ldar	x13, [x13]
    402018d4:	b10005bf 	cmn	x13, #0x1
    402018d8:	540002e1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402018dc:	8b09038d 	add	x13, x28, x9
    402018e0:	c8dffdad 	ldar	x13, [x13]
    402018e4:	b500028d 	cbnz	x13, 40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>
    402018e8:	8b09018d 	add	x13, x12, x9
    402018ec:	c8dffdad 	ldar	x13, [x13]
    402018f0:	b500022d 	cbnz	x13, 40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>
    402018f4:	8b0902ed 	add	x13, x23, x9
    402018f8:	f940e1ae 	ldr	x14, [x13, #448]
    402018fc:	f85f814f 	ldur	x15, [x10, #-8]
    40201900:	eb0f01df 	cmp	x14, x15
    40201904:	54000181 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201908:	f940e9ad 	ldr	x13, [x13, #464]
    4020190c:	f843854e 	ldr	x14, [x10], #56
    40201910:	eb0e01bf 	cmp	x13, x14
    40201914:	54000101 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201918:	8b0902ed 	add	x13, x23, x9
    4020191c:	f940c9ae 	ldr	x14, [x13, #400]
    40201920:	b10005df 	cmn	x14, #0x1
    40201924:	54000081 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201928:	91002129 	add	x9, x9, #0x8
    4020192c:	f940d1ad 	ldr	x13, [x13, #416]
    40201930:	b4fff8ed 	cbz	x13, 4020184c <jnox_kernel::ordinary_reservations::irq+0x584>
    40201934:	97fffe5d 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40201938:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020193c:	f942412a 	ldr	x10, [x9, #1152]
    40201940:	f100095f 	cmp	x10, #0x2
    40201944:	54ffff80 	b.eq	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.none
    40201948:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020194c:	91136129 	add	x9, x9, #0x4d8
    40201950:	39402138 	ldrb	w24, [x9, #8]
    40201954:	71000f1f 	cmp	w24, #0x3
    40201958:	54fffee0 	b.eq	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.none
    4020195c:	3941eaeb 	ldrb	w11, [x23, #122]
    40201960:	3943eaec 	ldrb	w12, [x23, #250]
    40201964:	6b0c017f 	cmp	w11, w12
    40201968:	54fffe61 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    4020196c:	f94002eb 	ldr	x11, [x23]
    40201970:	eb0a017f 	cmp	x11, x10
    40201974:	54fffe01 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201978:	d503201f 	nop
    4020197c:	1002e334 	adr	x20, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    40201980:	f940028a 	ldr	x10, [x20]
    40201984:	b4fffd8a 	cbz	x10, 40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>
    40201988:	f9400133 	ldr	x19, [x9]
    4020198c:	f9400689 	ldr	x9, [x20, #8]
    40201990:	eb13013f 	cmp	x9, x19
    40201994:	54fffd01 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201998:	39418a89 	ldrb	w9, [x20, #98]
    4020199c:	6b09031f 	cmp	w24, w9
    402019a0:	54fffca1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402019a4:	f90017e5 	str	x5, [sp, #40]
    402019a8:	d0000119 	adrp	x25, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520+0xb8e0>
    402019ac:	911cc339 	add	x25, x25, #0x730
    402019b0:	d5033fdf 	isb
    402019b4:	d53be036 	mrs	x22, cntpct_el0
    402019b8:	f9001f36 	str	x22, [x25, #56]
    402019bc:	f9400329 	ldr	x9, [x25]
    402019c0:	b27f0129 	orr	x9, x9, #0x2
    402019c4:	f9000329 	str	x9, [x25]
    402019c8:	eb1502df 	cmp	x22, x21
    402019cc:	54001c43 	b.cc	40201d54 <jnox_kernel::ordinary_reservations::irq+0xa8c>  // b.lo, b.ul, b.last
    402019d0:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402019d4:	9114e14a 	add	x10, x10, #0x538
    402019d8:	f9400149 	ldr	x9, [x10]
    402019dc:	eb0902c9 	subs	x9, x22, x9
    402019e0:	54001ba3 	b.cc	40201d54 <jnox_kernel::ordinary_reservations::irq+0xa8c>  // b.lo, b.ul, b.last
    402019e4:	f940094a 	ldr	x10, [x10, #16]
    402019e8:	eb0a013f 	cmp	x9, x10
    402019ec:	54001b48 	b.hi	40201d54 <jnox_kernel::ordinary_reservations::irq+0xa8c>  // b.pmore
    402019f0:	52800069 	mov	w9, #0x3                   	// #3
    402019f4:	c89ffd09 	stlr	x9, [x8]
    402019f8:	c8dffd15 	ldar	x21, [x8]
    402019fc:	940005e6 	bl	40203194 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    40201a00:	f9402c08 	ldr	x8, [x0, #88]
    40201a04:	39418009 	ldrb	w9, [x0, #96]
    40201a08:	d5033fdf 	isb
    40201a0c:	d53be024 	mrs	x4, cntpct_el0
    40201a10:	f940032a 	ldr	x10, [x25]
    40201a14:	a9045724 	stp	x4, x21, [x25, #64]
    40201a18:	71000d3f 	cmp	w9, #0x3
    40201a1c:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40201a20:	f9002b28 	str	x8, [x25, #80]
    40201a24:	b27e0149 	orr	x9, x10, #0x4
    40201a28:	f9000329 	str	x9, [x25]
    40201a2c:	f1000ebf 	cmp	x21, #0x3
    40201a30:	54fff821 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201a34:	eb13011f 	cmp	x8, x19
    40201a38:	54fff7e1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201a3c:	eb16009f 	cmp	x4, x22
    40201a40:	d000002e 	adrp	x14, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201a44:	9114e1ce 	add	x14, x14, #0x538
    40201a48:	54001703 	b.cc	40201d28 <jnox_kernel::ordinary_reservations::irq+0xa60>  // b.lo, b.ul, b.last
    40201a4c:	f94001c8 	ldr	x8, [x14]
    40201a50:	eb080088 	subs	x8, x4, x8
    40201a54:	540016a3 	b.cc	40201d28 <jnox_kernel::ordinary_reservations::irq+0xa60>  // b.lo, b.ul, b.last
    40201a58:	f94009c9 	ldr	x9, [x14, #16]
    40201a5c:	eb09011f 	cmp	x8, x9
    40201a60:	54001648 	b.hi	40201d28 <jnox_kernel::ordinary_reservations::irq+0xa60>  // b.pmore
    40201a64:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201a68:	f902ad1f 	str	xzr, [x8, #1368]
    40201a6c:	f100067f 	cmp	x19, #0x1
    40201a70:	54001a68 	b.hi	40201dbc <jnox_kernel::ordinary_reservations::irq+0xaf4>  // b.pmore
    40201a74:	8b131288 	add	x8, x20, x19, lsl #4
    40201a78:	f9402108 	ldr	x8, [x8, #64]
    40201a7c:	8b130ee9 	add	x9, x23, x19, lsl #3
    40201a80:	f900c928 	str	x8, [x9, #400]
    40201a84:	f940e12a 	ldr	x10, [x9, #448]
    40201a88:	f940e92b 	ldr	x11, [x9, #464]
    40201a8c:	a9107ef3 	stp	x19, xzr, [x23, #256]
    40201a90:	5280002c 	mov	w12, #0x1                   	// #1
    40201a94:	a9112aec 	stp	x12, x10, [x23, #272]
    40201a98:	a91222eb 	stp	x11, x8, [x23, #288]
    40201a9c:	3904c2f8 	strb	w24, [x23, #304]
    40201aa0:	8b130fa8 	add	x8, x29, x19, lsl #3
    40201aa4:	a948aa8b 	ldp	x11, x10, [x20, #136]
    40201aa8:	c89ffd0a 	stlr	x10, [x8]
    40201aac:	91000708 	add	x8, x24, #0x1
    40201ab0:	f8337b68 	str	x8, [x27, x19, lsl #3]
    40201ab4:	f8337b9f 	str	xzr, [x28, x19, lsl #3]
    40201ab8:	8b130f48 	add	x8, x26, x19, lsl #3
    40201abc:	c89ffd1f 	stlr	xzr, [x8]
    40201ac0:	a91832eb 	stp	x11, x12, [x23, #384]
    40201ac4:	d51be24b 	msr	cntp_cval_el0, x11
    40201ac8:	d51be22c 	msr	cntp_ctl_el0, x12
    40201acc:	d5033fdf 	isb
    40201ad0:	d53be24d 	mrs	x13, cntp_cval_el0
    40201ad4:	d53be228 	mrs	x8, cntp_ctl_el0
    40201ad8:	d5033fdf 	isb
    40201adc:	d53be02a 	mrs	x10, cntpct_el0
    40201ae0:	a906a32d 	stp	x13, x8, [x25, #104]
    40201ae4:	a905af2a 	stp	x10, x11, [x25, #88]
    40201ae8:	f940032c 	ldr	x12, [x25]
    40201aec:	b27d018c 	orr	x12, x12, #0x8
    40201af0:	f900032c 	str	x12, [x25]
    40201af4:	eb0b01bf 	cmp	x13, x11
    40201af8:	54fff1e1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201afc:	92400508 	and	x8, x8, #0x3
    40201b00:	f100051f 	cmp	x8, #0x1
    40201b04:	54fff181 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201b08:	d5033fdf 	isb
    40201b0c:	d53be028 	mrs	x8, cntpct_el0
    40201b10:	eb04015f 	cmp	x10, x4
    40201b14:	540012c3 	b.cc	40201d6c <jnox_kernel::ordinary_reservations::irq+0xaa4>  // b.lo, b.ul, b.last
    40201b18:	eb0a011f 	cmp	x8, x10
    40201b1c:	54001283 	b.cc	40201d6c <jnox_kernel::ordinary_reservations::irq+0xaa4>  // b.lo, b.ul, b.last
    40201b20:	f94001ca 	ldr	x10, [x14]
    40201b24:	eb0a010a 	subs	x10, x8, x10
    40201b28:	54001223 	b.cc	40201d6c <jnox_kernel::ordinary_reservations::irq+0xaa4>  // b.lo, b.ul, b.last
    40201b2c:	f94009cb 	ldr	x11, [x14, #16]
    40201b30:	eb0b015f 	cmp	x10, x11
    40201b34:	540011c8 	b.hi	40201d6c <jnox_kernel::ordinary_reservations::irq+0xaa4>  // b.pmore
    40201b38:	f940b536 	ldr	x22, [x9, #360]
    40201b3c:	d5033fdf 	isb
    40201b40:	d53be024 	mrs	x4, cntpct_el0
    40201b44:	f9409ee8 	ldr	x8, [x23, #312]
    40201b48:	eb080088 	subs	x8, x4, x8
    40201b4c:	54000ee3 	b.cc	40201d28 <jnox_kernel::ordinary_reservations::irq+0xa60>  // b.lo, b.ul, b.last
    40201b50:	f940a6ea 	ldr	x10, [x23, #328]
    40201b54:	eb0a011f 	cmp	x8, x10
    40201b58:	54000e88 	b.hi	40201d28 <jnox_kernel::ordinary_reservations::irq+0xa60>  // b.pmore
    40201b5c:	f900b53f 	str	xzr, [x9, #360]
    40201b60:	f900b2f3 	str	x19, [x23, #352]
    40201b64:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201b68:	91004108 	add	x8, x8, #0x10
    40201b6c:	f9407ec9 	ldr	x9, [x22, #248]
    40201b70:	a907db24 	stp	x4, x22, [x25, #120]
    40201b74:	5280002a 	mov	w10, #0x1                   	// #1
    40201b78:	a9004d1f 	stp	xzr, x19, [x8]
    40201b7c:	f9408ec8 	ldr	x8, [x22, #280]
    40201b80:	f9004729 	str	x9, [x25, #136]
    40201b84:	f9404ec9 	ldr	x9, [x22, #152]
    40201b88:	a909ab28 	stp	x8, x10, [x25, #152]
    40201b8c:	f9004b29 	str	x9, [x25, #144]
    40201b90:	f9400328 	ldr	x8, [x25]
    40201b94:	b27c0108 	orr	x8, x8, #0x10
    40201b98:	f9000328 	str	x8, [x25]
    40201b9c:	14000051 	b	40201ce0 <jnox_kernel::ordinary_reservations::irq+0xa18>
    40201ba0:	aa1303e0 	mov	x0, x19
    40201ba4:	aa1f03e1 	mov	x1, xzr
    40201ba8:	f94017f4 	ldr	x20, [sp, #40]
    40201bac:	aa1403e2 	mov	x2, x20
    40201bb0:	94000430 	bl	40202c70 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201bb4:	52800055 	mov	w21, #0x2                   	// #2
    40201bb8:	1400003b 	b	40201ca4 <jnox_kernel::ordinary_reservations::irq+0x9dc>
    40201bbc:	d000010a 	adrp	x10, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520+0xb8e0>
    40201bc0:	911cc14a 	add	x10, x10, #0x730
    40201bc4:	d53be248 	mrs	x8, cntp_cval_el0
    40201bc8:	d5033fdf 	isb
    40201bcc:	d53be029 	mrs	x9, cntpct_el0
    40201bd0:	a9022157 	stp	x23, x8, [x10, #32]
    40201bd4:	a9015949 	stp	x9, x22, [x10, #16]
    40201bd8:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201bdc:	9114e129 	add	x9, x9, #0x538
    40201be0:	f940252b 	ldr	x11, [x9, #72]
    40201be4:	f900194b 	str	x11, [x10, #48]
    40201be8:	f940014c 	ldr	x12, [x10]
    40201bec:	b240018c 	orr	x12, x12, #0x1
    40201bf0:	a900554c 	stp	x12, x21, [x10]
    40201bf4:	eb0b011f 	cmp	x8, x11
    40201bf8:	54ffe9e1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201bfc:	f9400129 	ldr	x9, [x9]
    40201c00:	eb09011f 	cmp	x8, x9
    40201c04:	54ffe981 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201c08:	aa1f03f3 	mov	x19, xzr
    40201c0c:	17fffde7 	b	402013a8 <jnox_kernel::ordinary_reservations::irq+0xe0>
    40201c10:	92800008 	mov	x8, #0xffffffffffffffff    	// #-1
    40201c14:	d503201f 	nop
    40201c18:	1002d709 	adr	x9, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40201c1c:	d503201f 	nop
    40201c20:	10110e8a 	adr	x10, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40201c24:	d503201f 	nop
    40201c28:	1002d60b 	adr	x11, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40201c2c:	d503201f 	nop
    40201c30:	10110e8c 	adr	x12, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40201c34:	8b150d29 	add	x9, x9, x21, lsl #3
    40201c38:	c89ffd28 	stlr	x8, [x9]
    40201c3c:	f9400be8 	ldr	x8, [sp, #16]
    40201c40:	f8357948 	str	x8, [x10, x21, lsl #3]
    40201c44:	f835799f 	str	xzr, [x12, x21, lsl #3]
    40201c48:	8b150d68 	add	x8, x11, x21, lsl #3
    40201c4c:	c89ffd13 	stlr	x19, [x8]
    40201c50:	b100067f 	cmn	x19, #0x1
    40201c54:	54000580 	b.eq	40201d04 <jnox_kernel::ordinary_reservations::irq+0xa3c>  // b.none
    40201c58:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201c5c:	9114e129 	add	x9, x9, #0x538
    40201c60:	a9402129 	ldp	x9, x8, [x9]
    40201c64:	9100066b 	add	x11, x19, #0x1
    40201c68:	9bc87d6a 	umulh	x10, x11, x8
    40201c6c:	eb0a03ff 	cmp	xzr, x10
    40201c70:	1a9f07ea 	cset	w10, ne  // ne = any
    40201c74:	9b087d68 	mul	x8, x11, x8
    40201c78:	ab090108 	adds	x8, x8, x9
    40201c7c:	1a9f37e9 	cset	w9, cs  // cs = hs, nlast
    40201c80:	3700042a 	tbnz	w10, #0, 40201d04 <jnox_kernel::ordinary_reservations::irq+0xa3c>
    40201c84:	37000409 	tbnz	w9, #0, 40201d04 <jnox_kernel::ordinary_reservations::irq+0xa3c>
    40201c88:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201c8c:	f942a529 	ldr	x9, [x9, #1352]
    40201c90:	eb090102 	subs	x2, x8, x9
    40201c94:	54000383 	b.cc	40201d04 <jnox_kernel::ordinary_reservations::irq+0xa3c>  // b.lo, b.ul, b.last
    40201c98:	aa1303e0 	mov	x0, x19
    40201c9c:	52800021 	mov	w1, #0x1                   	// #1
    40201ca0:	940003f4 	bl	40202c70 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201ca4:	aa1303e0 	mov	x0, x19
    40201ca8:	aa1503e1 	mov	x1, x21
    40201cac:	9400054b 	bl	402031d8 <jnox_kernel::ordinary_reservations::Runtime::select>
    40201cb0:	aa0003f6 	mov	x22, x0
    40201cb4:	d5033fdf 	isb
    40201cb8:	d53be021 	mrs	x1, cntpct_el0
    40201cbc:	f9407c08 	ldr	x8, [x0, #248]
    40201cc0:	f94013e9 	ldr	x9, [sp, #32]
    40201cc4:	a909d3e9 	stp	x9, x20, [sp, #152]
    40201cc8:	a90aa3e0 	stp	x0, x8, [sp, #168]
    40201ccc:	910263e4 	add	x4, sp, #0x98
    40201cd0:	528000e0 	mov	w0, #0x7                   	// #7
    40201cd4:	aa1303e2 	mov	x2, x19
    40201cd8:	aa1503e3 	mov	x3, x21
    40201cdc:	9400020f 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40201ce0:	aa1603e0 	mov	x0, x22
    40201ce4:	a9554ff4 	ldp	x20, x19, [sp, #336]
    40201ce8:	a95457f6 	ldp	x22, x21, [sp, #320]
    40201cec:	a9535ff8 	ldp	x24, x23, [sp, #304]
    40201cf0:	a95267fa 	ldp	x26, x25, [sp, #288]
    40201cf4:	a9516ffc 	ldp	x28, x27, [sp, #272]
    40201cf8:	a9507bfd 	ldp	x29, x30, [sp, #256]
    40201cfc:	910583ff 	add	sp, sp, #0x160
    40201d00:	d65f03c0 	ret
    40201d04:	52800060 	mov	w0, #0x3                   	// #3
    40201d08:	94000568 	bl	402032a8 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    40201d0c:	f942b303 	ldr	x3, [x24, #1376]
    40201d10:	52800060 	mov	w0, #0x3                   	// #3
    40201d14:	52800081 	mov	w1, #0x4                   	// #4
    40201d18:	aa1303e2 	mov	x2, x19
    40201d1c:	aa1603e4 	mov	x4, x22
    40201d20:	aa1703e5 	mov	x5, x23
    40201d24:	94000254 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>
    40201d28:	52800040 	mov	w0, #0x2                   	// #2
    40201d2c:	528000a1 	mov	w1, #0x5                   	// #5
    40201d30:	aa1f03e2 	mov	x2, xzr
    40201d34:	52800043 	mov	w3, #0x2                   	// #2
    40201d38:	14000012 	b	40201d80 <jnox_kernel::ordinary_reservations::irq+0xab8>
    40201d3c:	52800040 	mov	w0, #0x2                   	// #2
    40201d40:	528000a1 	mov	w1, #0x5                   	// #5
    40201d44:	aa1303e2 	mov	x2, x19
    40201d48:	52800043 	mov	w3, #0x2                   	// #2
    40201d4c:	aa1503e4 	mov	x4, x21
    40201d50:	94000249 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>
    40201d54:	52800040 	mov	w0, #0x2                   	// #2
    40201d58:	528000a1 	mov	w1, #0x5                   	// #5
    40201d5c:	aa1f03e2 	mov	x2, xzr
    40201d60:	52800043 	mov	w3, #0x2                   	// #2
    40201d64:	aa1603e4 	mov	x4, x22
    40201d68:	14000006 	b	40201d80 <jnox_kernel::ordinary_reservations::irq+0xab8>
    40201d6c:	52800040 	mov	w0, #0x2                   	// #2
    40201d70:	528000a1 	mov	w1, #0x5                   	// #5
    40201d74:	aa1f03e2 	mov	x2, xzr
    40201d78:	52800043 	mov	w3, #0x2                   	// #2
    40201d7c:	aa0803e4 	mov	x4, x8
    40201d80:	f94017e5 	ldr	x5, [sp, #40]
    40201d84:	9400023c 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>
    40201d88:	aa1f03e0 	mov	x0, xzr
    40201d8c:	aa1f03e1 	mov	x1, xzr
    40201d90:	aa1303e2 	mov	x2, x19
    40201d94:	52800043 	mov	w3, #0x2                   	// #2
    40201d98:	aa1f03e4 	mov	x4, xzr
    40201d9c:	14000006 	b	40201db4 <jnox_kernel::ordinary_reservations::irq+0xaec>
    40201da0:	394283e4 	ldrb	w4, [sp, #160]
    40201da4:	52800060 	mov	w0, #0x3                   	// #3
    40201da8:	52800041 	mov	w1, #0x2                   	// #2
    40201dac:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201db0:	52800043 	mov	w3, #0x2                   	// #2
    40201db4:	aa1f03e5 	mov	x5, xzr
    40201db8:	9400022f 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>
    40201dbc:	d503201f 	nop
    40201dc0:	10020182 	adr	x2, 40205df0 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.3.llvm.16183259764102968520+0x30>
    40201dc4:	aa1303e0 	mov	x0, x19
    40201dc8:	14000004 	b	40201dd8 <jnox_kernel::ordinary_reservations::irq+0xb10>
    40201dcc:	d503201f 	nop
    40201dd0:	10020282 	adr	x2, 40205e20 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.3.llvm.16183259764102968520+0x60>
    40201dd4:	aa1503e0 	mov	x0, x21
    40201dd8:	52800041 	mov	w1, #0x2                   	// #2
    40201ddc:	94000b96 	bl	40204c34 <core::panicking::panic_bounds_check>
    40201de0:	94000093 	bl	4020202c <jnox_kernel::ordinary_reservations::run::{{closure}}>

0000000040201de4 <jnox_kernel::ordinary_reservations::run>:
    40201de4:	d105c3ff 	sub	sp, sp, #0x170
    40201de8:	a9127bfd 	stp	x29, x30, [sp, #288]
    40201dec:	a91367fa 	stp	x26, x25, [sp, #304]
    40201df0:	a9145ff8 	stp	x24, x23, [sp, #320]
    40201df4:	a91557f6 	stp	x22, x21, [sp, #336]
    40201df8:	a9164ff4 	stp	x20, x19, [sp, #352]
    40201dfc:	d5033fdf 	isb
    40201e00:	d53be038 	mrs	x24, cntpct_el0
    40201e04:	d53be014 	mrs	x20, cntfrq_el0
    40201e08:	d5033fdf 	isb
    40201e0c:	d53be028 	mrs	x8, cntpct_el0
    40201e10:	b202e7e9 	mov	x9, #0xcccccccccccccccc    	// #-3689348814741910324
    40201e14:	f29999a9 	movk	x9, #0xcccd
    40201e18:	9bc97e89 	umulh	x9, x20, x9
    40201e1c:	ab491113 	adds	x19, x8, x9, lsr #4
    40201e20:	54000043 	b.cc	40201e28 <jnox_kernel::ordinary_reservations::run+0x44>  // b.lo, b.ul, b.last
    40201e24:	94000082 	bl	4020202c <jnox_kernel::ordinary_reservations::run::{{closure}}>
    40201e28:	910223e8 	add	x8, sp, #0x88
    40201e2c:	aa1303e0 	mov	x0, x19
    40201e30:	aa1403e1 	mov	x1, x20
    40201e34:	52800022 	mov	w2, #0x1                   	// #1
    40201e38:	940007f8 	bl	40203e18 <jnox_kernel::reservation_jobs::Clock::new>
    40201e3c:	394223e8 	ldrb	w8, [sp, #136]
    40201e40:	7100051f 	cmp	w8, #0x1
    40201e44:	54000061 	b.ne	40201e50 <jnox_kernel::ordinary_reservations::run+0x6c>  // b.any
    40201e48:	394227e4 	ldrb	w4, [sp, #137]
    40201e4c:	14000015 	b	40201ea0 <jnox_kernel::ordinary_reservations::run+0xbc>
    40201e50:	a9495bf7 	ldp	x23, x22, [sp, #144]
    40201e54:	f94053f5 	ldr	x21, [sp, #160]
    40201e58:	d5033fdf 	isb
    40201e5c:	d53be021 	mrs	x1, cntpct_el0
    40201e60:	a908dbf4 	stp	x20, x22, [sp, #136]
    40201e64:	52800028 	mov	w8, #0x1                   	// #1
    40201e68:	a909a3e8 	stp	x8, x8, [sp, #152]
    40201e6c:	910223e4 	add	x4, sp, #0x88
    40201e70:	52800020 	mov	w0, #0x1                   	// #1
    40201e74:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201e78:	52800043 	mov	w3, #0x2                   	// #2
    40201e7c:	940001a7 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40201e80:	910223e8 	add	x8, sp, #0x88
    40201e84:	52800020 	mov	w0, #0x1                   	// #1
    40201e88:	52800021 	mov	w1, #0x1                   	// #1
    40201e8c:	940005fb 	bl	40203678 <jnox_kernel::reservation_jobs::Jobs::new>
    40201e90:	f94047e8 	ldr	x8, [sp, #136]
    40201e94:	f100091f 	cmp	x8, #0x2
    40201e98:	54000101 	b.ne	40201eb8 <jnox_kernel::ordinary_reservations::run+0xd4>  // b.any
    40201e9c:	394243e4 	ldrb	w4, [sp, #144]
    40201ea0:	52800060 	mov	w0, #0x3                   	// #3
    40201ea4:	52800041 	mov	w1, #0x2                   	// #2
    40201ea8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201eac:	52800043 	mov	w3, #0x2                   	// #2
    40201eb0:	aa1f03e5 	mov	x5, xzr
    40201eb4:	940001f0 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>
    40201eb8:	910023e0 	add	x0, sp, #0x8
    40201ebc:	910223e1 	add	x1, sp, #0x88
    40201ec0:	52801002 	mov	w2, #0x80                  	// #128
    40201ec4:	94000eac 	bl	40205974 <memcpy>
    40201ec8:	d5033fdf 	isb
    40201ecc:	d53be021 	mrs	x1, cntpct_el0
    40201ed0:	a908cff8 	stp	x24, x19, [sp, #136]
    40201ed4:	a909ffff 	stp	xzr, xzr, [sp, #152]
    40201ed8:	910223e4 	add	x4, sp, #0x88
    40201edc:	52800300 	mov	w0, #0x18                  	// #24
    40201ee0:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201ee4:	52800043 	mov	w3, #0x2                   	// #2
    40201ee8:	9400018c 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40201eec:	94000a0f 	bl	40204728 <jnox_kernel::context::init_timer_irq>
    40201ef0:	aa1f03f4 	mov	x20, xzr
    40201ef4:	910423f8 	add	x24, sp, #0x108
    40201ef8:	aa1403e0 	mov	x0, x20
    40201efc:	940001a8 	bl	4020259c <jnox_kernel::ordinary_reservations::fresh>
    40201f00:	f8347b00 	str	x0, [x24, x20, lsl #3]
    40201f04:	91000694 	add	x20, x20, #0x1
    40201f08:	f1000e9f 	cmp	x20, #0x3
    40201f0c:	54ffff61 	b.ne	40201ef8 <jnox_kernel::ordinary_reservations::run+0x114>  // b.any
    40201f10:	aa1f03f4 	mov	x20, xzr
    40201f14:	d503201f 	nop
    40201f18:	100ac048 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520>
    40201f1c:	52800318 	mov	w24, #0x18                  	// #24
    40201f20:	d503201f 	nop
    40201f24:	1001f3b9 	adr	x25, 40205d98 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.1.llvm.16183259764102968520>
    40201f28:	d5033fdf 	isb
    40201f2c:	d53be021 	mrs	x1, cntpct_el0
    40201f30:	f1000a9f 	cmp	x20, #0x2
    40201f34:	54000062 	b.cs	40201f40 <jnox_kernel::ordinary_reservations::run+0x15c>  // b.hs, b.nlast
    40201f38:	f8747b29 	ldr	x9, [x25, x20, lsl #3]
    40201f3c:	14000002 	b	40201f44 <jnox_kernel::ordinary_reservations::run+0x160>
    40201f40:	52818329 	mov	w9, #0xc19                 	// #3097
    40201f44:	9140111a 	add	x26, x8, #0x4, lsl #12
    40201f48:	a908ebe8 	stp	x8, x26, [sp, #136]
    40201f4c:	a909ffe9 	stp	x9, xzr, [sp, #152]
    40201f50:	910223e4 	add	x4, sp, #0x88
    40201f54:	52800220 	mov	w0, #0x11                  	// #17
    40201f58:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201f5c:	aa1403e3 	mov	x3, x20
    40201f60:	9400016e 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40201f64:	f1002318 	subs	x24, x24, #0x8
    40201f68:	91000694 	add	x20, x20, #0x1
    40201f6c:	aa1a03e8 	mov	x8, x26
    40201f70:	54fffdc1 	b.ne	40201f28 <jnox_kernel::ordinary_reservations::run+0x144>  // b.any
    40201f74:	d503201f 	nop
    40201f78:	1002a454 	adr	x20, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40201f7c:	910023e1 	add	x1, sp, #0x8
    40201f80:	aa1403e0 	mov	x0, x20
    40201f84:	52801002 	mov	w2, #0x80                  	// #128
    40201f88:	94000e7b 	bl	40205974 <memcpy>
    40201f8c:	52800048 	mov	w8, #0x2                   	// #2
    40201f90:	f9004288 	str	x8, [x20, #128]
    40201f94:	52800069 	mov	w9, #0x3                   	// #3
    40201f98:	3904c289 	strb	w9, [x20, #304]
    40201f9c:	a913da97 	stp	x23, x22, [x20, #312]
    40201fa0:	52800149 	mov	w9, #0xa                   	// #10
    40201fa4:	a914a695 	stp	x21, x9, [x20, #328]
    40201fa8:	9280000a 	mov	x10, #0xffffffffffffffff    	// #-1
    40201fac:	a915a28a 	stp	x10, x8, [x20, #344]
    40201fb0:	a950afe8 	ldp	x8, x11, [sp, #264]
    40201fb4:	a916ae88 	stp	x8, x11, [x20, #360]
    40201fb8:	f9408fe8 	ldr	x8, [sp, #280]
    40201fbc:	a917fe88 	stp	x8, xzr, [x20, #376]
    40201fc0:	a918aa9f 	stp	xzr, x10, [x20, #392]
    40201fc4:	a919fe8a 	stp	x10, xzr, [x20, #408]
    40201fc8:	52800028 	mov	w8, #0x1                   	// #1
    40201fcc:	a91aa29f 	stp	xzr, x8, [x20, #424]
    40201fd0:	a91bfe88 	stp	x8, xzr, [x20, #440]
    40201fd4:	52814328 	mov	w8, #0xa19                 	// #2585
    40201fd8:	a91ca29f 	stp	xzr, x8, [x20, #456]
    40201fdc:	52816328 	mov	w8, #0xb19                 	// #2841
    40201fe0:	f900ee88 	str	x8, [x20, #472]
    40201fe4:	d5033fdf 	isb
    40201fe8:	d53be021 	mrs	x1, cntpct_el0
    40201fec:	a908a7f3 	stp	x19, x9, [sp, #136]
    40201ff0:	a909ffff 	stp	xzr, xzr, [sp, #152]
    40201ff4:	910223e4 	add	x4, sp, #0x88
    40201ff8:	52800040 	mov	w0, #0x2                   	// #2
    40201ffc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40202000:	52800043 	mov	w3, #0x2                   	// #2
    40202004:	94000145 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202008:	94000194 	bl	40202658 <jnox_kernel::ordinary_reservations::state>
    4020200c:	aa1f03e0 	mov	x0, xzr
    40202010:	aa1f03e1 	mov	x1, xzr
    40202014:	aa1303e2 	mov	x2, x19
    40202018:	94000316 	bl	40202c70 <jnox_kernel::ordinary_reservations::Runtime::arm>
    4020201c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    40202020:	52800041 	mov	w1, #0x2                   	// #2
    40202024:	9400046d 	bl	402031d8 <jnox_kernel::ordinary_reservations::Runtime::select>
    40202028:	97fffc61 	bl	402011ac <sched_start_frame>

000000004020202c <jnox_kernel::ordinary_reservations::run::{{closure}}>:
    4020202c:	f81f0ffe 	str	x30, [sp, #-16]!
    40202030:	97fffc9e 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

0000000040202034 <jnox_kernel::ordinary_reservations::svc>:
    40202034:	f81f0ffe 	str	x30, [sp, #-16]!
    40202038:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020203c:	f9420108 	ldr	x8, [x8, #1024]
    40202040:	f100091f 	cmp	x8, #0x2
    40202044:	54000660 	b.eq	40202110 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.none
    40202048:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020204c:	f942b108 	ldr	x8, [x8, #1376]
    40202050:	d503201f 	nop
    40202054:	100ab669 	adr	x9, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520>
    40202058:	f100091f 	cmp	x8, #0x2
    4020205c:	8b08392a 	add	x10, x9, x8, lsl #14
    40202060:	fa401142 	ccmp	x10, x0, #0x2, ne  // ne = any
    40202064:	54000568 	b.hi	40202110 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    40202068:	b10d041f 	cmn	x0, #0x341
    4020206c:	54000528 	b.hi	40202110 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    40202070:	d372c508 	lsl	x8, x8, #14
    40202074:	8b080128 	add	x8, x9, x8
    40202078:	91401108 	add	x8, x8, #0x4, lsl #12
    4020207c:	910d0009 	add	x9, x0, #0x340
    40202080:	eb08013f 	cmp	x9, x8
    40202084:	54000468 	b.hi	40202110 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    40202088:	f9409c01 	ldr	x1, [x0, #312]
    4020208c:	d5385203 	mrs	x3, esr_el1
    40202090:	d35afc68 	lsr	x8, x3, #26
    40202094:	f100551f 	cmp	x8, #0x15
    40202098:	540003c1 	b.ne	40202110 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.any
    4020209c:	12003c68 	and	w8, w3, #0xffff
    402020a0:	7100051f 	cmp	w8, #0x1
    402020a4:	540000a0 	b.eq	402020b8 <jnox_kernel::ordinary_reservations::svc+0x84>  // b.none
    402020a8:	7100091f 	cmp	w8, #0x2
    402020ac:	54000321 	b.ne	40202110 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.any
    402020b0:	52800042 	mov	w2, #0x2                   	// #2
    402020b4:	14000002 	b	402020bc <jnox_kernel::ordinary_reservations::svc+0x88>
    402020b8:	52800022 	mov	w2, #0x1                   	// #1
    402020bc:	9400030e 	bl	40202cf4 <jnox_kernel::ordinary_reservations::Runtime::close>
    402020c0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402020c4:	9114e108 	add	x8, x8, #0x538
    402020c8:	f9401100 	ldr	x0, [x8, #32]
    402020cc:	91000409 	add	x9, x0, #0x1
    402020d0:	a9402908 	ldp	x8, x10, [x8]
    402020d4:	9bca7d2b 	umulh	x11, x9, x10
    402020d8:	eb0b03ff 	cmp	xzr, x11
    402020dc:	1a9f07eb 	cset	w11, ne  // ne = any
    402020e0:	9b0a7d29 	mul	x9, x9, x10
    402020e4:	ab080122 	adds	x2, x9, x8
    402020e8:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    402020ec:	3700014b 	tbnz	w11, #0, 40202114 <jnox_kernel::ordinary_reservations::svc+0xe0>
    402020f0:	35000128 	cbnz	w8, 40202114 <jnox_kernel::ordinary_reservations::svc+0xe0>
    402020f4:	aa1f03e1 	mov	x1, xzr
    402020f8:	940002de 	bl	40202c70 <jnox_kernel::ordinary_reservations::Runtime::arm>
    402020fc:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202100:	f942ad00 	ldr	x0, [x8, #1368]
    40202104:	52800041 	mov	w1, #0x2                   	// #2
    40202108:	f84107fe 	ldr	x30, [sp], #16
    4020210c:	14000433 	b	402031d8 <jnox_kernel::ordinary_reservations::Runtime::select>
    40202110:	97fffc66 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40202114:	52800060 	mov	w0, #0x3                   	// #3
    40202118:	94000464 	bl	402032a8 <jnox_kernel::ordinary_reservations::checked::{{closure}}>

000000004020211c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520>:
    4020211c:	d10743ff 	sub	sp, sp, #0x1d0
    40202120:	a9177bfd 	stp	x29, x30, [sp, #368]
    40202124:	a9186ffc 	stp	x28, x27, [sp, #384]
    40202128:	a91967fa 	stp	x26, x25, [sp, #400]
    4020212c:	a91a5ff8 	stp	x24, x23, [sp, #416]
    40202130:	a91b57f6 	stp	x22, x21, [sp, #432]
    40202134:	a91c4ff4 	stp	x20, x19, [sp, #448]
    40202138:	d50342df 	msr	daifset, #0x2
    4020213c:	d5033fdf 	isb
    40202140:	d5033fdf 	isb
    40202144:	d53be036 	mrs	x22, cntpct_el0
    40202148:	b0000035 	adrp	x21, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020214c:	f94202a8 	ldr	x8, [x21, #1024]
    40202150:	f100091f 	cmp	x8, #0x2
    40202154:	54001ac0 	b.eq	402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>  // b.none
    40202158:	d5033fdf 	isb
    4020215c:	d53be038 	mrs	x24, cntpct_el0
    40202160:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202164:	f942f108 	ldr	x8, [x8, #1504]
    40202168:	f100091f 	cmp	x8, #0x2
    4020216c:	54001a01 	b.ne	402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>  // b.any
    40202170:	b0000037 	adrp	x23, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202174:	f9429ef3 	ldr	x19, [x23, #1336]
    40202178:	d503201f 	nop
    4020217c:	1010b328 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    40202180:	c8dffd08 	ldar	x8, [x8]
    40202184:	b5001948 	cbnz	x8, 402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>
    40202188:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020218c:	91156108 	add	x8, x8, #0x558
    40202190:	f9400109 	ldr	x9, [x8]
    40202194:	b100053f 	cmn	x9, #0x1
    40202198:	540018a1 	b.ne	402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>  // b.any
    4020219c:	f9400508 	ldr	x8, [x8, #8]
    402021a0:	f100091f 	cmp	x8, #0x2
    402021a4:	54001841 	b.ne	402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>  // b.any
    402021a8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021ac:	9114c108 	add	x8, x8, #0x530
    402021b0:	39400109 	ldrb	w9, [x8]
    402021b4:	71000d3f 	cmp	w9, #0x3
    402021b8:	540017a1 	b.ne	402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>  // b.any
    402021bc:	f9402d09 	ldr	x9, [x8, #88]
    402021c0:	b5001769 	cbnz	x9, 402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>
    402021c4:	f9402908 	ldr	x8, [x8, #80]
    402021c8:	eb13011f 	cmp	x8, x19
    402021cc:	54001701 	b.ne	402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>  // b.any
    402021d0:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520+0xb8e0>
    402021d4:	f943f508 	ldr	x8, [x8, #2024]
    402021d8:	f100051f 	cmp	x8, #0x1
    402021dc:	54001681 	b.ne	402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>  // b.any
    402021e0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021e4:	f9423508 	ldr	x8, [x8, #1128]
    402021e8:	b5001628 	cbnz	x8, 402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>
    402021ec:	5280002a 	mov	w10, #0x1                   	// #1
    402021f0:	d503201f 	nop
    402021f4:	10029079 	adr	x25, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402021f8:	8b080328 	add	x8, x25, x8
    402021fc:	3941e109 	ldrb	w9, [x8, #120]
    40202200:	3600008a 	tbz	w10, #0, 40202210 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0xf4>
    40202204:	2a1f03ea 	mov	w10, wzr
    40202208:	52800028 	mov	w8, #0x1                   	// #1
    4020220c:	34ffff69 	cbz	w9, 402021f8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0xdc>
    40202210:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202214:	39518108 	ldrb	w8, [x8, #1120]
    40202218:	7100013f 	cmp	w9, #0x0
    4020221c:	7a430900 	ccmp	w8, #0x3, #0x0, eq  // eq = none
    40202220:	54001461 	b.ne	402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>  // b.any
    40202224:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202228:	9111c108 	add	x8, x8, #0x470
    4020222c:	f9400109 	ldr	x9, [x8]
    40202230:	b50013e9 	cbnz	x9, 402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>
    40202234:	f9400908 	ldr	x8, [x8, #16]
    40202238:	f100091f 	cmp	x8, #0x2
    4020223c:	54001381 	b.ne	402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>  // b.any
    40202240:	f94202a8 	ldr	x8, [x21, #1024]
    40202244:	f100051f 	cmp	x8, #0x1
    40202248:	54000121 	b.ne	4020226c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x150>  // b.any
    4020224c:	b0000021 	adrp	x1, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202250:	91102021 	add	x1, x1, #0x408
    40202254:	f940183a 	ldr	x26, [x1, #48]
    40202258:	910243e0 	add	x0, sp, #0x90
    4020225c:	52800602 	mov	w2, #0x30                  	// #48
    40202260:	94000dc5 	bl	40205974 <memcpy>
    40202264:	52800028 	mov	w8, #0x1                   	// #1
    40202268:	14000017 	b	402022c4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x1a8>
    4020226c:	910303e0 	add	x0, sp, #0xc0
    40202270:	9100a014 	add	x20, x0, #0x28
    40202274:	52800028 	mov	w8, #0x1                   	// #1
    40202278:	b0000021 	adrp	x1, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020227c:	91102021 	add	x1, x1, #0x408
    40202280:	2a0803fa 	mov	w26, w8
    40202284:	9100a03b 	add	x27, x1, #0x28
    40202288:	52800502 	mov	w2, #0x28                  	// #40
    4020228c:	94000dba 	bl	40205974 <memcpy>
    40202290:	2a1f03e8 	mov	w8, wzr
    40202294:	aa1b03e1 	mov	x1, x27
    40202298:	aa1403e0 	mov	x0, x20
    4020229c:	3707ff3a 	tbnz	w26, #0, 40202280 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x164>
    402022a0:	910243e0 	add	x0, sp, #0x90
    402022a4:	910303e1 	add	x1, sp, #0xc0
    402022a8:	52800602 	mov	w2, #0x30                  	// #48
    402022ac:	94000db2 	bl	40205974 <memcpy>
    402022b0:	aa1f03e8 	mov	x8, xzr
    402022b4:	a94f27fa 	ldp	x26, x9, [sp, #240]
    402022b8:	a9502fea 	ldp	x10, x11, [sp, #256]
    402022bc:	a907abe9 	stp	x9, x10, [sp, #120]
    402022c0:	f90047eb 	str	x11, [sp, #136]
    402022c4:	b000003b 	adrp	x27, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402022c8:	9111e37b 	add	x27, x27, #0x478
    402022cc:	39400b7c 	ldrb	w28, [x27, #2]
    402022d0:	7940037d 	ldrh	w29, [x27]
    402022d4:	aa1b03f4 	mov	x20, x27
    402022d8:	f8008e88 	str	x8, [x20, #8]!
    402022dc:	91004360 	add	x0, x27, #0x10
    402022e0:	910243e1 	add	x1, sp, #0x90
    402022e4:	52800602 	mov	w2, #0x30                  	// #48
    402022e8:	94000da3 	bl	40205974 <memcpy>
    402022ec:	52800068 	mov	w8, #0x3                   	// #3
    402022f0:	3901a368 	strb	w8, [x27, #104]
    402022f4:	a947a7e8 	ldp	x8, x9, [sp, #120]
    402022f8:	a904237a 	stp	x26, x8, [x27, #64]
    402022fc:	f94047e8 	ldr	x8, [sp, #136]
    40202300:	a9052369 	stp	x9, x8, [x27, #80]
    40202304:	a9077f7f 	stp	xzr, xzr, [x27, #112]
    40202308:	7901037d 	strh	w29, [x27, #128]
    4020230c:	39020b7c 	strb	w28, [x27, #130]
    40202310:	910303e8 	add	x8, sp, #0xc0
    40202314:	aa1403e0 	mov	x0, x20
    40202318:	94000467 	bl	402034b4 <jnox_kernel::reservation_jobs::Jobs::prepare_destination>
    4020231c:	f94063e8 	ldr	x8, [sp, #192]
    40202320:	f100091f 	cmp	x8, #0x2
    40202324:	54000cc0 	b.eq	402024bc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x3a0>  // b.none
    40202328:	910043e0 	add	x0, sp, #0x10
    4020232c:	910303e1 	add	x1, sp, #0xc0
    40202330:	52800d02 	mov	w2, #0x68                  	// #104
    40202334:	94000d90 	bl	40205974 <memcpy>
    40202338:	b0000020 	adrp	x0, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020233c:	91120000 	add	x0, x0, #0x480
    40202340:	910043e1 	add	x1, sp, #0x10
    40202344:	94000473 	bl	40203510 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision>
    40202348:	36000b20 	tbz	w0, #0, 402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>
    4020234c:	b94013e8 	ldr	w8, [sp, #16]
    40202350:	36000b48 	tbz	w8, #0, 402024b8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x39c>
    40202354:	3941cbe8 	ldrb	w8, [sp, #114]
    40202358:	34000188 	cbz	w8, 40202388 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x26c>
    4020235c:	71000d1f 	cmp	w8, #0x3
    40202360:	54000a60 	b.eq	402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>  // b.none
    40202364:	f9400fe0 	ldr	x0, [sp, #24]
    40202368:	f100041f 	cmp	x0, #0x1
    4020236c:	54000ce8 	b.hi	40202508 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x3ec>  // b.pmore
    40202370:	8b000f28 	add	x8, x25, x0, lsl #3
    40202374:	f940e108 	ldr	x8, [x8, #448]
    40202378:	b104011f 	cmn	x8, #0x100
    4020237c:	540009e2 	b.cs	402024b8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x39c>  // b.hs, b.nlast
    40202380:	9104011a 	add	x26, x8, #0x100
    40202384:	14000002 	b	4020238c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x270>
    40202388:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4020238c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202390:	9114e108 	add	x8, x8, #0x538
    40202394:	a9402508 	ldp	x8, x9, [x8]
    40202398:	ab09011b 	adds	x27, x8, x9
    4020239c:	540008a2 	b.cs	402024b0 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x394>  // b.hs, b.nlast
    402023a0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402023a4:	f942a508 	ldr	x8, [x8, #1352]
    402023a8:	eb08037c 	subs	x28, x27, x8
    402023ac:	54000823 	b.cc	402024b0 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x394>  // b.lo, b.ul, b.last
    402023b0:	f9009bf9 	str	x25, [sp, #304]
    402023b4:	910303f4 	add	x20, sp, #0xc0
    402023b8:	9104e3e8 	add	x8, sp, #0x138
    402023bc:	9104c3e0 	add	x0, sp, #0x130
    402023c0:	aa1f03e1 	mov	x1, xzr
    402023c4:	94000702 	bl	40203fcc <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    402023c8:	910303e0 	add	x0, sp, #0xc0
    402023cc:	9104e3e1 	add	x1, sp, #0x138
    402023d0:	52800702 	mov	w2, #0x38                  	// #56
    402023d4:	94000d68 	bl	40205974 <memcpy>
    402023d8:	9104e3e8 	add	x8, sp, #0x138
    402023dc:	9104c3e0 	add	x0, sp, #0x130
    402023e0:	52800021 	mov	w1, #0x1                   	// #1
    402023e4:	940006fa 	bl	40203fcc <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    402023e8:	9100e280 	add	x0, x20, #0x38
    402023ec:	9104e3e1 	add	x1, sp, #0x138
    402023f0:	52800702 	mov	w2, #0x38                  	// #56
    402023f4:	94000d60 	bl	40205974 <memcpy>
    402023f8:	d503201f 	nop
    402023fc:	10028f34 	adr	x20, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    40202400:	910043e1 	add	x1, sp, #0x10
    40202404:	aa1403e0 	mov	x0, x20
    40202408:	52800d02 	mov	w2, #0x68                  	// #104
    4020240c:	94000d5a 	bl	40205974 <memcpy>
    40202410:	52800088 	mov	w8, #0x4                   	// #4
    40202414:	a906a298 	stp	x24, x8, [x20, #104]
    40202418:	a907ee93 	stp	x19, x27, [x20, #120]
    4020241c:	a908ea9c 	stp	x28, x26, [x20, #136]
    40202420:	91026280 	add	x0, x20, #0x98
    40202424:	910303e1 	add	x1, sp, #0xc0
    40202428:	52800e02 	mov	w2, #0x70                  	// #112
    4020242c:	94000d52 	bl	40205974 <memcpy>
    40202430:	d5033fdf 	isb
    40202434:	d53be034 	mrs	x20, cntpct_el0
    40202438:	eb140268 	subs	x8, x19, x20
    4020243c:	9a8833e8 	csel	x8, xzr, x8, cc  // cc = lo, ul, last
    40202440:	a913cff8 	stp	x24, x19, [sp, #312]
    40202444:	a914ffe8 	stp	x8, xzr, [sp, #328]
    40202448:	9104e3e4 	add	x4, sp, #0x138
    4020244c:	528002c0 	mov	w0, #0x16                  	// #22
    40202450:	aa1403e1 	mov	x1, x20
    40202454:	aa1f03e2 	mov	x2, xzr
    40202458:	52800043 	mov	w3, #0x2                   	// #2
    4020245c:	9400002f 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202460:	eb18029f 	cmp	x20, x24
    40202464:	540003a3 	b.cc	402024d8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x3bc>  // b.lo, b.ul, b.last
    40202468:	eb13029f 	cmp	x20, x19
    4020246c:	54000362 	b.cs	402024d8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x3bc>  // b.hs, b.nlast
    40202470:	d5033fdf 	isb
    40202474:	d53be024 	mrs	x4, cntpct_el0
    40202478:	d503201f 	nop
    4020247c:	10109528 	adr	x8, 40223720 <jnox_kernel::ordinary_reservations::RECEIPT>
    40202480:	a9001116 	stp	x22, x4, [x8]
    40202484:	f94202a8 	ldr	x8, [x21, #1024]
    40202488:	f100091f 	cmp	x8, #0x2
    4020248c:	54000100 	b.eq	402024ac <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x390>  // b.none
    40202490:	f9429ee5 	ldr	x5, [x23, #1336]
    40202494:	eb05009f 	cmp	x4, x5
    40202498:	540002e2 	b.cs	402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x3d8>  // b.hs, b.nlast
    4020249c:	d50342ff 	msr	daifclr, #0x2
    402024a0:	d5033fdf 	isb
    402024a4:	d503207f 	wfi
    402024a8:	17ffffff 	b	402024a4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520+0x388>
    402024ac:	97fffb7f 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402024b0:	52800060 	mov	w0, #0x3                   	// #3
    402024b4:	9400037d 	bl	402032a8 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    402024b8:	97fffedd 	bl	4020202c <jnox_kernel::ordinary_reservations::run::{{closure}}>
    402024bc:	394323e4 	ldrb	w4, [sp, #200]
    402024c0:	52800060 	mov	w0, #0x3                   	// #3
    402024c4:	52800041 	mov	w1, #0x2                   	// #2
    402024c8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    402024cc:	52800043 	mov	w3, #0x2                   	// #2
    402024d0:	aa1f03e5 	mov	x5, xzr
    402024d4:	94000068 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>
    402024d8:	52800040 	mov	w0, #0x2                   	// #2
    402024dc:	52800121 	mov	w1, #0x9                   	// #9
    402024e0:	aa1f03e2 	mov	x2, xzr
    402024e4:	52800043 	mov	w3, #0x2                   	// #2
    402024e8:	aa1403e4 	mov	x4, x20
    402024ec:	aa1303e5 	mov	x5, x19
    402024f0:	94000061 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>
    402024f4:	52800040 	mov	w0, #0x2                   	// #2
    402024f8:	52800161 	mov	w1, #0xb                   	// #11
    402024fc:	aa1f03e2 	mov	x2, xzr
    40202500:	52800043 	mov	w3, #0x2                   	// #2
    40202504:	9400005c 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>
    40202508:	d503201f 	nop
    4020250c:	1001c7e2 	adr	x2, 40205e08 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.3.llvm.16183259764102968520+0x48>
    40202510:	52800041 	mov	w1, #0x2                   	// #2
    40202514:	940009c8 	bl	40204c34 <core::panicking::panic_bounds_check>

0000000040202518 <jnox_kernel::ordinary_reservations::event>:
    40202518:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020251c:	f9438909 	ldr	x9, [x8, #1808]
    40202520:	f110013f 	cmp	x9, #0x400
    40202524:	54000241 	b.ne	4020256c <jnox_kernel::ordinary_reservations::event+0x54>  // b.any
    40202528:	aa1f03e8 	mov	x8, xzr
    4020252c:	52800309 	mov	w9, #0x18                  	// #24
    40202530:	72a12009 	movk	w9, #0x900, lsl #16
    40202534:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    40202538:	d503201f 	nop
    4020253c:	1001c36b 	adr	x11, 40205da8 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.1.llvm.16183259764102968520+0x10>
    40202540:	3868696c 	ldrb	w12, [x11, x8]
    40202544:	b940012d 	ldr	w13, [x9]
    40202548:	3628006d 	tbz	w13, #5, 40202554 <jnox_kernel::ordinary_reservations::event+0x3c>
    4020254c:	d5033fdf 	isb
    40202550:	17fffffd 	b	40202544 <jnox_kernel::ordinary_reservations::event+0x2c>
    40202554:	91000508 	add	x8, x8, #0x1
    40202558:	b900014c 	str	w12, [x10]
    4020255c:	f100511f 	cmp	x8, #0x14
    40202560:	54ffff01 	b.ne	40202540 <jnox_kernel::ordinary_reservations::event+0x28>  // b.any
    40202564:	d503205f 	wfe
    40202568:	17ffffff 	b	40202564 <jnox_kernel::ordinary_reservations::event+0x4c>
    4020256c:	d503201f 	nop
    40202570:	10028d4a 	adr	x10, 40207718 <jnox_kernel::ordinary_reservations::TRACE>
    40202574:	8b09194a 	add	x10, x10, x9, lsl #6
    40202578:	a9000540 	stp	x0, x1, [x10]
    4020257c:	a940308b 	ldp	x11, x12, [x4]
    40202580:	a9010d42 	stp	x2, x3, [x10, #16]
    40202584:	a941388d 	ldp	x13, x14, [x4, #16]
    40202588:	a902314b 	stp	x11, x12, [x10, #32]
    4020258c:	a903394d 	stp	x13, x14, [x10, #48]
    40202590:	91000529 	add	x9, x9, #0x1
    40202594:	f9038909 	str	x9, [x8, #1808]
    40202598:	d65f03c0 	ret

000000004020259c <jnox_kernel::ordinary_reservations::fresh>:
    4020259c:	d10143ff 	sub	sp, sp, #0x50
    402025a0:	a90357f6 	stp	x22, x21, [sp, #48]
    402025a4:	a9044ff4 	stp	x20, x19, [sp, #64]
    402025a8:	aa0003f3 	mov	x19, x0
    402025ac:	d503201f 	nop
    402025b0:	10007768 	adr	x8, 4020349c <reservation_worker_a>
    402025b4:	d503201f 	nop
    402025b8:	10007789 	adr	x9, 402034a8 <reservation_worker_b>
    402025bc:	d503201f 	nop
    402025c0:	10ffdaea 	adr	x10, 4020211c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.16183259764102968520>
    402025c4:	a900a7e8 	stp	x8, x9, [sp, #8]
    402025c8:	a901fbea 	stp	x10, x30, [sp, #24]
    402025cc:	f100081f 	cmp	x0, #0x2
    402025d0:	540003a8 	b.hi	40202644 <jnox_kernel::ordinary_reservations::fresh+0xa8>  // b.pmore
    402025d4:	910023e8 	add	x8, sp, #0x8
    402025d8:	f8737915 	ldr	x21, [x8, x19, lsl #3]
    402025dc:	d503201f 	nop
    402025e0:	100a8a08 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520>
    402025e4:	8b133916 	add	x22, x8, x19, lsl #14
    402025e8:	52879808 	mov	w8, #0x3cc0                	// #15552
    402025ec:	8b0802d4 	add	x20, x22, x8
    402025f0:	aa1403e0 	mov	x0, x20
    402025f4:	2a1f03e1 	mov	w1, wzr
    402025f8:	52806802 	mov	w2, #0x340                 	// #832
    402025fc:	94000d6a 	bl	40205ba4 <memset>
    40202600:	f91eded5 	str	x21, [x22, #15800]
    40202604:	528068a8 	mov	w8, #0x345                 	// #837
    40202608:	f91ee2c8 	str	x8, [x22, #15808]
    4020260c:	f1000a7f 	cmp	x19, #0x2
    40202610:	54000061 	b.ne	4020261c <jnox_kernel::ordinary_reservations::fresh+0x80>  // b.any
    40202614:	52818328 	mov	w8, #0xc19                 	// #3097
    40202618:	14000004 	b	40202628 <jnox_kernel::ordinary_reservations::fresh+0x8c>
    4020261c:	d503201f 	nop
    40202620:	1001bbc8 	adr	x8, 40205d98 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.1.llvm.16183259764102968520>
    40202624:	f8737908 	ldr	x8, [x8, x19, lsl #3]
    40202628:	f9008e88 	str	x8, [x20, #280]
    4020262c:	aa1403e0 	mov	x0, x20
    40202630:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40202634:	a94357f6 	ldp	x22, x21, [sp, #48]
    40202638:	f94013fe 	ldr	x30, [sp, #32]
    4020263c:	910143ff 	add	sp, sp, #0x50
    40202640:	d65f03c0 	ret
    40202644:	d503201f 	nop
    40202648:	1001bbc2 	adr	x2, 40205dc0 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.3.llvm.16183259764102968520>
    4020264c:	aa1303e0 	mov	x0, x19
    40202650:	52800061 	mov	w1, #0x3                   	// #3
    40202654:	94000978 	bl	40204c34 <core::panicking::panic_bounds_check>

0000000040202658 <jnox_kernel::ordinary_reservations::state>:
    40202658:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020265c:	f9420108 	ldr	x8, [x8, #1024]
    40202660:	f100091f 	cmp	x8, #0x2
    40202664:	54000040 	b.eq	4020266c <jnox_kernel::ordinary_reservations::state+0x14>  // b.none
    40202668:	d65f03c0 	ret
    4020266c:	f81f0ffe 	str	x30, [sp, #-16]!
    40202670:	97fffb0e 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

0000000040202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>:
    40202674:	d10603ff 	sub	sp, sp, #0x180
    40202678:	a9127bfd 	stp	x29, x30, [sp, #288]
    4020267c:	a9136ffc 	stp	x28, x27, [sp, #304]
    40202680:	a91467fa 	stp	x26, x25, [sp, #320]
    40202684:	a9155ff8 	stp	x24, x23, [sp, #336]
    40202688:	a91657f6 	stp	x22, x21, [sp, #352]
    4020268c:	a9174ff4 	stp	x20, x19, [sp, #368]
    40202690:	d5034fdf 	msr	daifset, #0xf
    40202694:	d51be23f 	msr	cntp_ctl_el0, xzr
    40202698:	d5033fdf 	isb
    4020269c:	b0000109 	adrp	x9, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520+0xb8e0>
    402026a0:	395f6128 	ldrb	w8, [x9, #2008]
    402026a4:	7100051f 	cmp	w8, #0x1
    402026a8:	54000061 	b.ne	402026b4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x40>  // b.any
    402026ac:	d503205f 	wfe
    402026b0:	17ffffff 	b	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x38>
    402026b4:	aa0103ec 	mov	x12, x1
    402026b8:	d503201f 	nop
    402026bc:	1010832a 	adr	x10, 40223720 <jnox_kernel::ordinary_reservations::RECEIPT>
    402026c0:	5280002b 	mov	w11, #0x1                   	// #1
    402026c4:	a9400548 	ldp	x8, x1, [x10]
    402026c8:	391f612b 	strb	w11, [x9, #2008]
    402026cc:	a9415558 	ldp	x24, x21, [x10, #16]
    402026d0:	a9424d54 	ldp	x20, x19, [x10, #32]
    402026d4:	a943694b 	ldp	x11, x26, [x10, #48]
    402026d8:	a9447149 	ldp	x9, x28, [x10, #64]
    402026dc:	a9012fe9 	stp	x9, x11, [sp, #16]
    402026e0:	a945755b 	ldp	x27, x29, [x10, #80]
    402026e4:	a9464549 	ldp	x9, x17, [x10, #96]
    402026e8:	f9005be9 	str	x9, [sp, #176]
    402026ec:	a9474946 	ldp	x6, x18, [x10, #112]
    402026f0:	a9482d47 	ldp	x7, x11, [x10, #128]
    402026f4:	a949394d 	ldp	x13, x14, [x10, #144]
    402026f8:	a94a414f 	ldp	x15, x16, [x10, #160]
    402026fc:	f940594a 	ldr	x10, [x10, #176]
    40202700:	d5033fdf 	isb
    40202704:	d53be039 	mrs	x25, cntpct_el0
    40202708:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020270c:	d503201f 	nop
    40202710:	10027696 	adr	x22, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    40202714:	f942f137 	ldr	x23, [x9, #1504]
    40202718:	a90a0fe2 	stp	x2, x3, [sp, #160]
    4020271c:	a90917e4 	stp	x4, x5, [sp, #144]
    40202720:	a90833e0 	stp	x0, x12, [sp, #128]
    40202724:	a9072fea 	stp	x10, x11, [sp, #112]
    40202728:	a90637ee 	stp	x14, x13, [sp, #96]
    4020272c:	a9053ff0 	stp	x16, x15, [sp, #80]
    40202730:	a90447f2 	stp	x18, x17, [sp, #64]
    40202734:	a9031be7 	stp	x7, x6, [sp, #48]
    40202738:	a9026ffc 	stp	x28, x27, [sp, #32]
    4020273c:	b40001a1 	cbz	x1, 40202770 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0xfc>
    40202740:	f9403ec9 	ldr	x9, [x22, #120]
    40202744:	f1000aff 	cmp	x23, #0x2
    40202748:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    4020274c:	a90b87e8 	stp	x8, x1, [sp, #184]
    40202750:	a90cffe9 	stp	x9, xzr, [sp, #200]
    40202754:	9102e3e4 	add	x4, sp, #0xb8
    40202758:	52800480 	mov	w0, #0x24                  	// #36
    4020275c:	aa1f03e2 	mov	x2, xzr
    40202760:	52800043 	mov	w3, #0x2                   	// #2
    40202764:	97ffff6d 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202768:	f94002c8 	ldr	x8, [x22]
    4020276c:	14000002 	b	40202774 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x100>
    40202770:	aa1703e8 	mov	x8, x23
    40202774:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202778:	9117a129 	add	x9, x9, #0x5e8
    4020277c:	f940012a 	ldr	x10, [x9]
    40202780:	7200011f 	tst	w8, #0x1
    40202784:	52800048 	mov	w8, #0x2                   	// #2
    40202788:	f9403529 	ldr	x9, [x9, #104]
    4020278c:	9a881148 	csel	x8, x10, x8, ne  // ne = any
    40202790:	f1000aff 	cmp	x23, #0x2
    40202794:	da9f113b 	csinv	x27, x9, xzr, ne  // ne = any
    40202798:	9a8802fc 	csel	x28, x23, x8, eq  // eq = none
    4020279c:	d503201f 	nop
    402027a0:	10108208 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    402027a4:	c8dffd08 	ldar	x8, [x8]
    402027a8:	a90be3fb 	stp	x27, x24, [sp, #184]
    402027ac:	f27e031f 	tst	x24, #0x4
    402027b0:	f9405be9 	ldr	x9, [sp, #176]
    402027b4:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    402027b8:	a90ca7e8 	stp	x8, x9, [sp, #200]
    402027bc:	9102e3e4 	add	x4, sp, #0xb8
    402027c0:	52800300 	mov	w0, #0x18                  	// #24
    402027c4:	aa1903e1 	mov	x1, x25
    402027c8:	aa1f03e2 	mov	x2, xzr
    402027cc:	aa1c03e3 	mov	x3, x28
    402027d0:	97ffff52 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    402027d4:	37001d78 	tbnz	w24, #0, 40202b80 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x50c>
    402027d8:	37081f98 	tbnz	w24, #1, 40202bc8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x554>
    402027dc:	37102118 	tbnz	w24, #2, 40202bfc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x588>
    402027e0:	37182278 	tbnz	w24, #3, 40202c2c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x5b8>
    402027e4:	36200378 	tbz	w24, #4, 40202850 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x1dc>
    402027e8:	a94627e8 	ldp	x8, x9, [sp, #96]
    402027ec:	a90ba3e9 	stp	x9, x8, [sp, #184]
    402027f0:	a94527e8 	ldp	x8, x9, [sp, #80]
    402027f4:	a90ca3e9 	stp	x9, x8, [sp, #200]
    402027f8:	9102e3e4 	add	x4, sp, #0xb8
    402027fc:	528003a0 	mov	w0, #0x1d                  	// #29
    40202800:	f9403ff3 	ldr	x19, [sp, #120]
    40202804:	aa1303e1 	mov	x1, x19
    40202808:	aa1f03e2 	mov	x2, xzr
    4020280c:	aa1c03e3 	mov	x3, x28
    40202810:	97ffff42 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202814:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202818:	91196108 	add	x8, x8, #0x658
    4020281c:	a9402109 	ldp	x9, x8, [x8]
    40202820:	f1000aff 	cmp	x23, #0x2
    40202824:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    40202828:	f9403bea 	ldr	x10, [sp, #112]
    4020282c:	a90ba7ea 	stp	x10, x9, [sp, #184]
    40202830:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40202834:	a90cefe8 	stp	x8, x27, [sp, #200]
    40202838:	9102e3e4 	add	x4, sp, #0xb8
    4020283c:	528003c0 	mov	w0, #0x1e                  	// #30
    40202840:	aa1303e1 	mov	x1, x19
    40202844:	aa1f03e2 	mov	x2, xzr
    40202848:	aa1c03e3 	mov	x3, x28
    4020284c:	97ffff33 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202850:	f1000aff 	cmp	x23, #0x2
    40202854:	54000800 	b.eq	40202954 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x2e0>  // b.none
    40202858:	aa1f03f3 	mov	x19, xzr
    4020285c:	52800028 	mov	w8, #0x1                   	// #1
    40202860:	52800714 	mov	w20, #0x38                  	// #56
    40202864:	9b145a77 	madd	x23, x19, x20, x22
    40202868:	2a0803f5 	mov	w21, w8
    4020286c:	a949a6e8 	ldp	x8, x9, [x23, #152]
    40202870:	f94056ea 	ldr	x10, [x23, #168]
    40202874:	a90ba7e8 	stp	x8, x9, [sp, #184]
    40202878:	f9405ee8 	ldr	x8, [x23, #184]
    4020287c:	a90ca3ea 	stp	x10, x8, [sp, #200]
    40202880:	9102e3e4 	add	x4, sp, #0xb8
    40202884:	52800440 	mov	w0, #0x22                  	// #34
    40202888:	aa1903e1 	mov	x1, x25
    4020288c:	aa1f03e2 	mov	x2, xzr
    40202890:	aa1303e3 	mov	x3, x19
    40202894:	97ffff21 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202898:	f9405ae8 	ldr	x8, [x23, #176]
    4020289c:	a94c2ae9 	ldp	x9, x10, [x23, #192]
    402028a0:	a90ba7e8 	stp	x8, x9, [sp, #184]
    402028a4:	f9404ac8 	ldr	x8, [x22, #144]
    402028a8:	a90ca3ea 	stp	x10, x8, [sp, #200]
    402028ac:	9102e3e4 	add	x4, sp, #0xb8
    402028b0:	52800460 	mov	w0, #0x23                  	// #35
    402028b4:	aa1903e1 	mov	x1, x25
    402028b8:	aa1f03e2 	mov	x2, xzr
    402028bc:	aa1303e3 	mov	x3, x19
    402028c0:	97ffff16 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    402028c4:	8b1312c8 	add	x8, x22, x19, lsl #4
    402028c8:	a941a909 	ldp	x9, x10, [x8, #24]
    402028cc:	a90babe9 	stp	x9, x10, [sp, #184]
    402028d0:	a943a109 	ldp	x9, x8, [x8, #56]
    402028d4:	a90ca3e9 	stp	x9, x8, [sp, #200]
    402028d8:	9102e3e4 	add	x4, sp, #0xb8
    402028dc:	528003e0 	mov	w0, #0x1f                  	// #31
    402028e0:	aa1903e1 	mov	x1, x25
    402028e4:	aa1f03e2 	mov	x2, xzr
    402028e8:	aa1303e3 	mov	x3, x19
    402028ec:	97ffff0b 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    402028f0:	8b130ac8 	add	x8, x22, x19, lsl #2
    402028f4:	b9401109 	ldr	w9, [x8, #16]
    402028f8:	b9405908 	ldr	w8, [x8, #88]
    402028fc:	8b1302ca 	add	x10, x22, x19
    40202900:	3941814a 	ldrb	w10, [x10, #96]
    40202904:	b94002cb 	ldr	w11, [x22]
    40202908:	f94006cc 	ldr	x12, [x22, #8]
    4020290c:	eb13019f 	cmp	x12, x19
    40202910:	1a9f17ec 	cset	w12, eq  // eq = none
    40202914:	39418acd 	ldrb	w13, [x22, #98]
    40202918:	71000dbf 	cmp	w13, #0x3
    4020291c:	1a8d07ed 	csinc	w13, wzr, w13, eq  // eq = none
    40202920:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202924:	6a0c017f 	tst	w11, w12
    40202928:	9a9f11a8 	csel	x8, x13, xzr, ne  // ne = any
    4020292c:	a90ca3ea 	stp	x10, x8, [sp, #200]
    40202930:	9102e3e4 	add	x4, sp, #0xb8
    40202934:	52800400 	mov	w0, #0x20                  	// #32
    40202938:	aa1903e1 	mov	x1, x25
    4020293c:	aa1f03e2 	mov	x2, xzr
    40202940:	aa1303e3 	mov	x3, x19
    40202944:	97fffef5 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202948:	2a1f03e8 	mov	w8, wzr
    4020294c:	52800033 	mov	w19, #0x1                   	// #1
    40202950:	3707f8b5 	tbnz	w21, #0, 40202864 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x1f0>
    40202954:	52801008 	mov	w8, #0x80                  	// #128
    40202958:	52802109 	mov	w9, #0x108                 	// #264
    4020295c:	a90ba3e8 	stp	x8, x8, [sp, #184]
    40202960:	52801708 	mov	w8, #0xb8                  	// #184
    40202964:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202968:	9102e3e4 	add	x4, sp, #0xb8
    4020296c:	52800420 	mov	w0, #0x21                  	// #33
    40202970:	aa1903e1 	mov	x1, x25
    40202974:	aa1f03e2 	mov	x2, xzr
    40202978:	52800043 	mov	w3, #0x2                   	// #2
    4020297c:	97fffee7 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202980:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520+0xb8e0>
    40202984:	f943f508 	ldr	x8, [x8, #2024]
    40202988:	f101011f 	cmp	x8, #0x40
    4020298c:	52800809 	mov	w9, #0x40                  	// #64
    40202990:	9a893113 	csel	x19, x8, x9, cc  // cc = lo, ul, last
    40202994:	a94a5ff8 	ldp	x24, x23, [sp, #160]
    40202998:	a94967fa 	ldp	x26, x25, [sp, #144]
    4020299c:	f94047fb 	ldr	x27, [sp, #136]
    402029a0:	b4000288 	cbz	x8, 402029f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x37c>
    402029a4:	aa1f03f4 	mov	x20, xzr
    402029a8:	b0000035 	adrp	x21, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402029ac:	910022b5 	add	x21, x21, #0x8
    402029b0:	b0000116 	adrp	x22, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520+0xb8e0>
    402029b4:	911fc2d6 	add	x22, x22, #0x7f0
    402029b8:	f9400ac1 	ldr	x1, [x22, #16]
    402029bc:	f94006c8 	ldr	x8, [x22, #8]
    402029c0:	f84186c9 	ldr	x9, [x22], #24
    402029c4:	aa1403ea 	mov	x10, x20
    402029c8:	91000694 	add	x20, x20, #0x1
    402029cc:	a90ba3e9 	stp	x9, x8, [sp, #184]
    402029d0:	a97f8ea2 	ldp	x2, x3, [x21, #-8]
    402029d4:	a90cffea 	stp	x10, xzr, [sp, #200]
    402029d8:	9102e3e4 	add	x4, sp, #0xb8
    402029dc:	52800180 	mov	w0, #0xc                   	// #12
    402029e0:	97fffece 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    402029e4:	910042b5 	add	x21, x21, #0x10
    402029e8:	eb14027f 	cmp	x19, x20
    402029ec:	54fffe61 	b.ne	402029b8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x344>  // b.any
    402029f0:	52800314 	mov	w20, #0x18                  	// #24
    402029f4:	72a12014 	movk	w20, #0x900, lsl #16
    402029f8:	d5033fdf 	isb
    402029fc:	d53be021 	mrs	x1, cntpct_el0
    40202a00:	f94043e8 	ldr	x8, [sp, #128]
    40202a04:	a90befe8 	stp	x8, x27, [sp, #184]
    40202a08:	a90ce7fa 	stp	x26, x25, [sp, #200]
    40202a0c:	9102e3e4 	add	x4, sp, #0xb8
    40202a10:	528001a0 	mov	w0, #0xd                   	// #13
    40202a14:	aa1803e2 	mov	x2, x24
    40202a18:	aa1703e3 	mov	x3, x23
    40202a1c:	97fffebf 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202a20:	aa1f03e8 	mov	x8, xzr
    40202a24:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202a28:	d503201f 	nop
    40202a2c:	10019d6a 	adr	x10, 40205dd8 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.3.llvm.16183259764102968520+0x18>
    40202a30:	3868694b 	ldrb	w11, [x10, x8]
    40202a34:	b940028c 	ldr	w12, [x20]
    40202a38:	3628006c 	tbz	w12, #5, 40202a44 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x3d0>
    40202a3c:	d5033fdf 	isb
    40202a40:	17fffffd 	b	40202a34 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x3c0>
    40202a44:	91000508 	add	x8, x8, #0x1
    40202a48:	b900012b 	str	w11, [x9]
    40202a4c:	f1002d1f 	cmp	x8, #0xb
    40202a50:	54ffff01 	b.ne	40202a30 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x3bc>  // b.any
    40202a54:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202a58:	f9438915 	ldr	x21, [x8, #1808]
    40202a5c:	b4000755 	cbz	x21, 40202b44 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x4d0>
    40202a60:	aa1f03f6 	mov	x22, xzr
    40202a64:	9102e3e8 	add	x8, sp, #0xb8
    40202a68:	b202e7f7 	mov	x23, #0xcccccccccccccccc    	// #-3689348814741910324
    40202a6c:	f29999b7 	movk	x23, #0xcccd
    40202a70:	91004113 	add	x19, x8, #0x10
    40202a74:	52800158 	mov	w24, #0xa                   	// #10
    40202a78:	910423f9 	add	x25, sp, #0x108
    40202a7c:	52a1201a 	mov	w26, #0x9000000             	// #150994944
    40202a80:	5280041b 	mov	w27, #0x20                  	// #32
    40202a84:	d503201f 	nop
    40202a88:	1002649c 	adr	x28, 40207718 <jnox_kernel::ordinary_reservations::TRACE>
    40202a8c:	8b161b81 	add	x1, x28, x22, lsl #6
    40202a90:	910006d6 	add	x22, x22, #0x1
    40202a94:	aa1303e0 	mov	x0, x19
    40202a98:	52800802 	mov	w2, #0x40                  	// #64
    40202a9c:	94000bb6 	bl	40205974 <memcpy>
    40202aa0:	aa1f03e8 	mov	x8, xzr
    40202aa4:	b9011bff 	str	wzr, [sp, #280]
    40202aa8:	f8687a69 	ldr	x9, [x19, x8, lsl #3]
    40202aac:	91000508 	add	x8, x8, #0x1
    40202ab0:	5280026a 	mov	w10, #0x13                  	// #19
    40202ab4:	a910ffff 	stp	xzr, xzr, [sp, #264]
    40202ab8:	f1004d5f 	cmp	x10, #0x13
    40202abc:	54000d08 	b.hi	40202c5c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x5e8>  // b.pmore
    40202ac0:	9bd77d2b 	umulh	x11, x9, x23
    40202ac4:	d343fd6b 	lsr	x11, x11, #3
    40202ac8:	1b18a56c 	msub	w12, w11, w24, w9
    40202acc:	321c058c 	orr	w12, w12, #0x30
    40202ad0:	382a6b2c 	strb	w12, [x25, x10]
    40202ad4:	d100054a 	sub	x10, x10, #0x1
    40202ad8:	f100293f 	cmp	x9, #0xa
    40202adc:	aa0b03e9 	mov	x9, x11
    40202ae0:	54fffec2 	b.cs	40202ab8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x444>  // b.hs, b.nlast
    40202ae4:	91000549 	add	x9, x10, #0x1
    40202ae8:	38696b2a 	ldrb	w10, [x25, x9]
    40202aec:	b940028b 	ldr	w11, [x20]
    40202af0:	3628006b 	tbz	w11, #5, 40202afc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x488>
    40202af4:	d5033fdf 	isb
    40202af8:	17fffffd 	b	40202aec <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x478>
    40202afc:	91000529 	add	x9, x9, #0x1
    40202b00:	b900034a 	str	w10, [x26]
    40202b04:	f100513f 	cmp	x9, #0x14
    40202b08:	54ffff01 	b.ne	40202ae8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x474>  // b.any
    40202b0c:	14000002 	b	40202b14 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x4a0>
    40202b10:	d5033fdf 	isb
    40202b14:	b9400289 	ldr	w9, [x20]
    40202b18:	372fffc9 	tbnz	w9, #5, 40202b10 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x49c>
    40202b1c:	b900035b 	str	w27, [x26]
    40202b20:	f100211f 	cmp	x8, #0x8
    40202b24:	54fffc01 	b.ne	40202aa4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x430>  // b.any
    40202b28:	14000002 	b	40202b30 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x4bc>
    40202b2c:	d5033fdf 	isb
    40202b30:	b9400288 	ldr	w8, [x20]
    40202b34:	372fffc8 	tbnz	w8, #5, 40202b2c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x4b8>
    40202b38:	b9000358 	str	w24, [x26]
    40202b3c:	eb1502df 	cmp	x22, x21
    40202b40:	54fffa61 	b.ne	40202a8c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x418>  // b.any
    40202b44:	aa1f03e8 	mov	x8, xzr
    40202b48:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202b4c:	d503201f 	nop
    40202b50:	7001948a 	adr	x10, 40205de3 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.3.llvm.16183259764102968520+0x23>
    40202b54:	3868694b 	ldrb	w11, [x10, x8]
    40202b58:	b940028c 	ldr	w12, [x20]
    40202b5c:	3628006c 	tbz	w12, #5, 40202b68 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x4f4>
    40202b60:	d5033fdf 	isb
    40202b64:	17fffffd 	b	40202b58 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x4e4>
    40202b68:	91000508 	add	x8, x8, #0x1
    40202b6c:	b900012b 	str	w11, [x9]
    40202b70:	f100251f 	cmp	x8, #0x9
    40202b74:	54ffff01 	b.ne	40202b54 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x4e0>  // b.any
    40202b78:	d503205f 	wfe
    40202b7c:	17ffffff 	b	40202b78 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x504>
    40202b80:	a94127e8 	ldp	x8, x9, [sp, #16]
    40202b84:	a90ba7f3 	stp	x19, x9, [sp, #184]
    40202b88:	a90ca3fa 	stp	x26, x8, [sp, #200]
    40202b8c:	9102e3e4 	add	x4, sp, #0xb8
    40202b90:	52800320 	mov	w0, #0x19                  	// #25
    40202b94:	aa1503e1 	mov	x1, x21
    40202b98:	aa1f03e2 	mov	x2, xzr
    40202b9c:	52800043 	mov	w3, #0x2                   	// #2
    40202ba0:	97fffe5e 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202ba4:	a90bd3f5 	stp	x21, x20, [sp, #184]
    40202ba8:	a90ccffa 	stp	x26, x19, [sp, #200]
    40202bac:	9102e3e4 	add	x4, sp, #0xb8
    40202bb0:	528004a0 	mov	w0, #0x25                  	// #37
    40202bb4:	aa1403e1 	mov	x1, x20
    40202bb8:	aa1f03e2 	mov	x2, xzr
    40202bbc:	52800043 	mov	w3, #0x2                   	// #2
    40202bc0:	97fffe56 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202bc4:	360fe0d8 	tbz	w24, #1, 402027dc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x168>
    40202bc8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202bcc:	f9432d08 	ldr	x8, [x8, #1624]
    40202bd0:	f1000aff 	cmp	x23, #0x2
    40202bd4:	a90bfffb 	stp	x27, xzr, [sp, #184]
    40202bd8:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40202bdc:	a90cffe8 	stp	x8, xzr, [sp, #200]
    40202be0:	9102e3e4 	add	x4, sp, #0xb8
    40202be4:	52800340 	mov	w0, #0x1a                  	// #26
    40202be8:	f94013e1 	ldr	x1, [sp, #32]
    40202bec:	aa1f03e2 	mov	x2, xzr
    40202bf0:	52800043 	mov	w3, #0x2                   	// #2
    40202bf4:	97fffe49 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202bf8:	3617df58 	tbz	w24, #2, 402027e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x16c>
    40202bfc:	924003a8 	and	x8, x29, #0x1
    40202c00:	d341ffa9 	lsr	x9, x29, #1
    40202c04:	a90ba3fd 	stp	x29, x8, [sp, #184]
    40202c08:	f9405be8 	ldr	x8, [sp, #176]
    40202c0c:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202c10:	9102e3e4 	add	x4, sp, #0xb8
    40202c14:	52800360 	mov	w0, #0x1b                  	// #27
    40202c18:	f94017e1 	ldr	x1, [sp, #40]
    40202c1c:	aa1f03e2 	mov	x2, xzr
    40202c20:	aa1c03e3 	mov	x3, x28
    40202c24:	97fffe3d 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202c28:	361fddf8 	tbz	w24, #3, 402027e4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x170>
    40202c2c:	a94327e8 	ldp	x8, x9, [sp, #48]
    40202c30:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202c34:	52800028 	mov	w8, #0x1                   	// #1
    40202c38:	a94407e9 	ldp	x9, x1, [sp, #64]
    40202c3c:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202c40:	9102e3e4 	add	x4, sp, #0xb8
    40202c44:	52800380 	mov	w0, #0x1c                  	// #28
    40202c48:	aa1f03e2 	mov	x2, xzr
    40202c4c:	aa1c03e3 	mov	x3, x28
    40202c50:	97fffe32 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202c54:	3727dcb8 	tbnz	w24, #4, 402027e8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x174>
    40202c58:	17fffefe 	b	40202850 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520+0x1dc>
    40202c5c:	d503201f 	nop
    40202c60:	10018f82 	adr	x2, 40205e50 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.3.llvm.16183259764102968520+0x90>
    40202c64:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    40202c68:	52800281 	mov	w1, #0x14                  	// #20
    40202c6c:	940007f2 	bl	40204c34 <core::panicking::panic_bounds_check>

0000000040202c70 <jnox_kernel::ordinary_reservations::Runtime::arm>:
    40202c70:	d10103ff 	sub	sp, sp, #0x40
    40202c74:	a90257fe 	stp	x30, x21, [sp, #32]
    40202c78:	a9034ff4 	stp	x20, x19, [sp, #48]
    40202c7c:	aa0203f3 	mov	x19, x2
    40202c80:	aa0003e2 	mov	x2, x0
    40202c84:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202c88:	91158129 	add	x9, x9, #0x560
    40202c8c:	a9020533 	stp	x19, x1, [x9, #32]
    40202c90:	52800028 	mov	w8, #0x1                   	// #1
    40202c94:	d51be253 	msr	cntp_cval_el0, x19
    40202c98:	d51be228 	msr	cntp_ctl_el0, x8
    40202c9c:	d5033fdf 	isb
    40202ca0:	d53be255 	mrs	x21, cntp_cval_el0
    40202ca4:	d53be234 	mrs	x20, cntp_ctl_el0
    40202ca8:	d5033fdf 	isb
    40202cac:	d53be028 	mrs	x8, cntpct_el0
    40202cb0:	a90053f3 	stp	x19, x20, [sp]
    40202cb4:	f9400123 	ldr	x3, [x9]
    40202cb8:	a90107f5 	stp	x21, x1, [sp, #16]
    40202cbc:	910003e4 	mov	x4, sp
    40202cc0:	52800060 	mov	w0, #0x3                   	// #3
    40202cc4:	aa0803e1 	mov	x1, x8
    40202cc8:	97fffe14 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202ccc:	eb1302bf 	cmp	x21, x19
    40202cd0:	54000101 	b.ne	40202cf0 <jnox_kernel::ordinary_reservations::Runtime::arm+0x80>  // b.any
    40202cd4:	92400688 	and	x8, x20, #0x3
    40202cd8:	f100051f 	cmp	x8, #0x1
    40202cdc:	540000a1 	b.ne	40202cf0 <jnox_kernel::ordinary_reservations::Runtime::arm+0x80>  // b.any
    40202ce0:	a9434ff4 	ldp	x20, x19, [sp, #48]
    40202ce4:	a94257fe 	ldp	x30, x21, [sp, #32]
    40202ce8:	910103ff 	add	sp, sp, #0x40
    40202cec:	d65f03c0 	ret
    40202cf0:	97fff96e 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

0000000040202cf4 <jnox_kernel::ordinary_reservations::Runtime::close>:
    40202cf4:	d103c3ff 	sub	sp, sp, #0xf0
    40202cf8:	a9097bfd 	stp	x29, x30, [sp, #144]
    40202cfc:	a90a6ffc 	stp	x28, x27, [sp, #160]
    40202d00:	a90b67fa 	stp	x26, x25, [sp, #176]
    40202d04:	a90c5ff8 	stp	x24, x23, [sp, #192]
    40202d08:	a90d57f6 	stp	x22, x21, [sp, #208]
    40202d0c:	a90e4ff4 	stp	x20, x19, [sp, #224]
    40202d10:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202d14:	91140108 	add	x8, x8, #0x500
    40202d18:	a9405113 	ldp	x19, x20, [x8]
    40202d1c:	a9412518 	ldp	x24, x9, [x8, #16]
    40202d20:	f90037e9 	str	x9, [sp, #104]
    40202d24:	a942691d 	ldp	x29, x26, [x8, #32]
    40202d28:	3940c119 	ldrb	w25, [x8, #48]
    40202d2c:	52800069 	mov	w9, #0x3                   	// #3
    40202d30:	3900c109 	strb	w9, [x8, #48]
    40202d34:	71000f3f 	cmp	w25, #0x3
    40202d38:	54001d20 	b.eq	402030dc <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.none
    40202d3c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202d40:	f942b108 	ldr	x8, [x8, #1376]
    40202d44:	eb13011f 	cmp	x8, x19
    40202d48:	54001ca1 	b.ne	402030dc <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.any
    40202d4c:	aa0003f5 	mov	x21, x0
    40202d50:	d503201f 	nop
    40202d54:	100a4e68 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520>
    40202d58:	8b133909 	add	x9, x8, x19, lsl #14
    40202d5c:	eb00013f 	cmp	x9, x0
    40202d60:	54001be8 	b.hi	402030dc <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202d64:	b10d06bf 	cmn	x21, #0x341
    40202d68:	54001ba8 	b.hi	402030dc <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202d6c:	d372c669 	lsl	x9, x19, #14
    40202d70:	8b090108 	add	x8, x8, x9
    40202d74:	91401108 	add	x8, x8, #0x4, lsl #12
    40202d78:	910d02a9 	add	x9, x21, #0x340
    40202d7c:	eb08013f 	cmp	x9, x8
    40202d80:	54001ae8 	b.hi	402030dc <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202d84:	aa0303fc 	mov	x28, x3
    40202d88:	2a0203f7 	mov	w23, w2
    40202d8c:	aa0103f6 	mov	x22, x1
    40202d90:	9101c3e8 	add	x8, sp, #0x70
    40202d94:	aa1303e0 	mov	x0, x19
    40202d98:	9400014c 	bl	402032c8 <jnox_kernel::ordinary_reservations::snapshot>
    40202d9c:	f1000a7f 	cmp	x19, #0x2
    40202da0:	54001d62 	b.cs	4020314c <jnox_kernel::ordinary_reservations::Runtime::close+0x458>  // b.hs, b.nlast
    40202da4:	a94733fb 	ldp	x27, x12, [sp, #112]
    40202da8:	f94043ef 	ldr	x15, [sp, #128]
    40202dac:	d503201f 	nop
    40202db0:	10108288 	adr	x8, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40202db4:	8b130d08 	add	x8, x8, x19, lsl #3
    40202db8:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202dbc:	9114e129 	add	x9, x9, #0x538
    40202dc0:	c8dffd0e 	ldar	x14, [x8]
    40202dc4:	a9402129 	ldp	x9, x8, [x9]
    40202dc8:	9bc87e8a 	umulh	x10, x20, x8
    40202dcc:	eb0a03ff 	cmp	xzr, x10
    40202dd0:	1a9f07eb 	cset	w11, ne  // ne = any
    40202dd4:	9b087e8a 	mul	x10, x20, x8
    40202dd8:	ab09014d 	adds	x13, x10, x9
    40202ddc:	1a9f37ea 	cset	w10, cs  // cs = hs, nlast
    40202de0:	3700180b 	tbnz	w11, #0, 402030e0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202de4:	350017ea 	cbnz	w10, 402030e0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202de8:	9100068a 	add	x10, x20, #0x1
    40202dec:	9bc87d4b 	umulh	x11, x10, x8
    40202df0:	eb0b03ff 	cmp	xzr, x11
    40202df4:	1a9f07eb 	cset	w11, ne  // ne = any
    40202df8:	9b087d48 	mul	x8, x10, x8
    40202dfc:	ab090109 	adds	x9, x8, x9
    40202e00:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40202e04:	370016eb 	tbnz	w11, #0, 402030e0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202e08:	350016c8 	cbnz	w8, 402030e0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202e0c:	b100069f 	cmn	x20, #0x1
    40202e10:	54001680 	b.eq	402030e0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.none
    40202e14:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202e18:	f942a508 	ldr	x8, [x8, #1352]
    40202e1c:	eb08012a 	subs	x10, x9, x8
    40202e20:	54001603 	b.cc	402030e0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.lo, b.ul, b.last
    40202e24:	a9056bfc 	stp	x28, x26, [sp, #80]
    40202e28:	f9000fe9 	str	x9, [sp, #24]
    40202e2c:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520+0xb8e0>
    40202e30:	f943f508 	ldr	x8, [x8, #2024]
    40202e34:	91000709 	add	x9, x24, #0x1
    40202e38:	eb09011f 	cmp	x8, x9
    40202e3c:	54001501 	b.ne	402030dc <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.any
    40202e40:	b9004ff9 	str	w25, [sp, #76]
    40202e44:	d503201f 	nop
    40202e48:	10104d08 	adr	x8, 402237e8 <jnox_ap_returns>
    40202e4c:	52800309 	mov	w9, #0x18                  	// #24
    40202e50:	9b092308 	madd	x8, x24, x9, x8
    40202e54:	f9400509 	ldr	x9, [x8, #8]
    40202e58:	f940090b 	ldr	x11, [x8, #16]
    40202e5c:	f9400d1c 	ldr	x28, [x8, #24]
    40202e60:	eb1c02da 	subs	x26, x22, x28
    40202e64:	540017e3 	b.cc	40203160 <jnox_kernel::ordinary_reservations::Runtime::close+0x46c>  // b.lo, b.ul, b.last
    40202e68:	a902a7eb 	stp	x11, x9, [sp, #40]
    40202e6c:	a903b7ef 	stp	x15, x13, [sp, #56]
    40202e70:	f90033ee 	str	x14, [sp, #96]
    40202e74:	f9000bea 	str	x10, [sp, #16]
    40202e78:	d503201f 	nop
    40202e7c:	10022c28 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40202e80:	8b130d18 	add	x24, x8, x19, lsl #3
    40202e84:	f940d308 	ldr	x8, [x24, #416]
    40202e88:	ab1a0119 	adds	x25, x8, x26
    40202e8c:	540012a2 	b.cs	402030e0 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.hs, b.nlast
    40202e90:	f900d319 	str	x25, [x24, #416]
    40202e94:	f94037e8 	ldr	x8, [sp, #104]
    40202e98:	a9076fe8 	stp	x8, x27, [sp, #112]
    40202e9c:	a90833fd 	stp	x29, x12, [sp, #128]
    40202ea0:	f90013fb 	str	x27, [sp, #32]
    40202ea4:	9101c3e4 	add	x4, sp, #0x70
    40202ea8:	52800100 	mov	w0, #0x8                   	// #8
    40202eac:	aa1603e1 	mov	x1, x22
    40202eb0:	aa1403e2 	mov	x2, x20
    40202eb4:	aa1303e3 	mov	x3, x19
    40202eb8:	aa0c03fb 	mov	x27, x12
    40202ebc:	97fffd97 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202ec0:	f9407ea8 	ldr	x8, [x21, #248]
    40202ec4:	f9404ea9 	ldr	x9, [x21, #152]
    40202ec8:	a90723f5 	stp	x21, x8, [sp, #112]
    40202ecc:	f9408ea8 	ldr	x8, [x21, #280]
    40202ed0:	a90823e9 	stp	x9, x8, [sp, #128]
    40202ed4:	9101c3e4 	add	x4, sp, #0x70
    40202ed8:	52800120 	mov	w0, #0x9                   	// #9
    40202edc:	aa1603e1 	mov	x1, x22
    40202ee0:	aa1403e2 	mov	x2, x20
    40202ee4:	aa1303e3 	mov	x3, x19
    40202ee8:	97fffd8c 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202eec:	f94033e8 	ldr	x8, [sp, #96]
    40202ef0:	a90723fc 	stp	x28, x8, [sp, #112]
    40202ef4:	a9086bf6 	stp	x22, x26, [sp, #128]
    40202ef8:	f90007fa 	str	x26, [sp, #8]
    40202efc:	9101c3e4 	add	x4, sp, #0x70
    40202f00:	52800140 	mov	w0, #0xa                   	// #10
    40202f04:	aa1603e1 	mov	x1, x22
    40202f08:	aa1403e2 	mov	x2, x20
    40202f0c:	aa1303e3 	mov	x3, x19
    40202f10:	97fffd82 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202f14:	110006e8 	add	w8, w23, #0x1
    40202f18:	92401d09 	and	x9, x8, #0xff
    40202f1c:	f9402be8 	ldr	x8, [sp, #80]
    40202f20:	a90723e9 	stp	x9, x8, [sp, #112]
    40202f24:	f9401fe9 	ldr	x9, [sp, #56]
    40202f28:	910d02a8 	add	x8, x21, #0x340
    40202f2c:	a90823e9 	stp	x9, x8, [sp, #128]
    40202f30:	9101c3e4 	add	x4, sp, #0x70
    40202f34:	52800160 	mov	w0, #0xb                   	// #11
    40202f38:	aa1603e1 	mov	x1, x22
    40202f3c:	aa1403e2 	mov	x2, x20
    40202f40:	aa1303e3 	mov	x3, x19
    40202f44:	97fffd75 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202f48:	f9402fe8 	ldr	x8, [sp, #88]
    40202f4c:	a90767e8 	stp	x8, x25, [sp, #112]
    40202f50:	aa1903fa 	mov	x26, x25
    40202f54:	a942a7e8 	ldp	x8, x9, [sp, #40]
    40202f58:	a90823e9 	stp	x9, x8, [sp, #128]
    40202f5c:	9101c3e4 	add	x4, sp, #0x70
    40202f60:	52800260 	mov	w0, #0x13                  	// #19
    40202f64:	aa1603e1 	mov	x1, x22
    40202f68:	aa1403e2 	mov	x2, x20
    40202f6c:	aa1303e3 	mov	x3, x19
    40202f70:	97fffd6a 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40202f74:	f94013e4 	ldr	x4, [sp, #32]
    40202f78:	b9404fe8 	ldr	w8, [sp, #76]
    40202f7c:	6b37011f 	cmp	w8, w23, uxtb
    40202f80:	f94023e5 	ldr	x5, [sp, #64]
    40202f84:	54000b21 	b.ne	402030e8 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40202f88:	f94037e8 	ldr	x8, [sp, #104]
    40202f8c:	eb080088 	subs	x8, x4, x8
    40202f90:	54000ac9 	b.ls	402030e8 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.plast
    40202f94:	f9408ea9 	ldr	x9, [x21, #280]
    40202f98:	d503201f 	nop
    40202f9c:	10016fea 	adr	x10, 40205d98 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.1.llvm.16183259764102968520>
    40202fa0:	f873794a 	ldr	x10, [x10, x19, lsl #3]
    40202fa4:	eb0a013f 	cmp	x9, x10
    40202fa8:	54000a01 	b.ne	402030e8 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40202fac:	f94082a9 	ldr	x9, [x21, #256]
    40202fb0:	528011ea 	mov	w10, #0x8f                  	// #143
    40202fb4:	8a0a0129 	and	x9, x9, x10
    40202fb8:	f100153f 	cmp	x9, #0x5
    40202fbc:	54000961 	b.ne	402030e8 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40202fc0:	52800029 	mov	w9, #0x1                   	// #1
    40202fc4:	5280006a 	mov	w10, #0x3                   	// #3
    40202fc8:	aa0803eb 	mov	x11, x8
    40202fcc:	9b1d254c 	madd	x12, x10, x29, x9
    40202fd0:	f240017f 	tst	x11, #0x1
    40202fd4:	9a8c03bd 	csel	x29, x29, x12, eq  // eq = none
    40202fd8:	9b0a2529 	madd	x9, x9, x10, x9
    40202fdc:	9b0a7d4a 	mul	x10, x10, x10
    40202fe0:	d341fd6b 	lsr	x11, x11, #1
    40202fe4:	b5ffff4b 	cbnz	x11, 40202fcc <jnox_kernel::ordinary_reservations::Runtime::close+0x2d8>
    40202fe8:	eb1b03bf 	cmp	x29, x27
    40202fec:	540007e1 	b.ne	402030e8 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40202ff0:	72001eff 	tst	w23, #0xff
    40202ff4:	54000060 	b.eq	40203000 <jnox_kernel::ordinary_reservations::Runtime::close+0x30c>  // b.none
    40202ff8:	f104011f 	cmp	x8, #0x100
    40202ffc:	54000761 	b.ne	402030e8 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203000:	f94033ea 	ldr	x10, [sp, #96]
    40203004:	eb16015f 	cmp	x10, x22
    40203008:	540007c8 	b.hi	40203100 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.pmore
    4020300c:	eb05039f 	cmp	x28, x5
    40203010:	54000783 	b.cc	40203100 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.lo, b.ul, b.last
    40203014:	eb1c015f 	cmp	x10, x28
    40203018:	54000743 	b.cc	40203100 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.lo, b.ul, b.last
    4020301c:	cb050149 	sub	x9, x10, x5
    40203020:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203024:	f942a508 	ldr	x8, [x8, #1352]
    40203028:	eb08013f 	cmp	x9, x8
    4020302c:	540006a8 	b.hi	40203100 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.pmore
    40203030:	a9412fe5 	ldp	x5, x11, [sp, #16]
    40203034:	eb0b02df 	cmp	x22, x11
    40203038:	54000708 	b.hi	40203118 <jnox_kernel::ordinary_reservations::Runtime::close+0x424>  // b.pmore
    4020303c:	12001eea 	and	w10, w23, #0xff
    40203040:	eb0502c9 	subs	x9, x22, x5
    40203044:	9a8933e9 	csel	x9, xzr, x9, cc  // cc = lo, ul, last
    40203048:	3500006a 	cbnz	w10, 40203054 <jnox_kernel::ordinary_reservations::Runtime::close+0x360>
    4020304c:	eb08013f 	cmp	x9, x8
    40203050:	54000648 	b.hi	40203118 <jnox_kernel::ordinary_reservations::Runtime::close+0x424>  // b.pmore
    40203054:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203058:	f942a108 	ldr	x8, [x8, #1344]
    4020305c:	f94007ea 	ldr	x10, [sp, #8]
    40203060:	eb08015f 	cmp	x10, x8
    40203064:	aa1a03eb 	mov	x11, x26
    40203068:	54000648 	b.hi	40203130 <jnox_kernel::ordinary_reservations::Runtime::close+0x43c>  // b.pmore
    4020306c:	f940db09 	ldr	x9, [x24, #432]
    40203070:	9b087d28 	mul	x8, x9, x8
    40203074:	eb08017f 	cmp	x11, x8
    40203078:	540005c8 	b.hi	40203130 <jnox_kernel::ordinary_reservations::Runtime::close+0x43c>  // b.pmore
    4020307c:	72001eff 	tst	w23, #0xff
    40203080:	54000060 	b.eq	4020308c <jnox_kernel::ordinary_reservations::Runtime::close+0x398>  // b.none
    40203084:	eb0502df 	cmp	x22, x5
    40203088:	540006e2 	b.cs	40203164 <jnox_kernel::ordinary_reservations::Runtime::close+0x470>  // b.hs, b.nlast
    4020308c:	f900e304 	str	x4, [x24, #448]
    40203090:	f900eb1b 	str	x27, [x24, #464]
    40203094:	94000040 	bl	40203194 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    40203098:	aa1303e1 	mov	x1, x19
    4020309c:	2a1703e2 	mov	w2, w23
    402030a0:	94000240 	bl	402039a0 <jnox_kernel::reservation_jobs::Jobs::trap>
    402030a4:	72001c04 	ands	w4, w0, #0xff
    402030a8:	540006a1 	b.ne	4020317c <jnox_kernel::ordinary_reservations::Runtime::close+0x488>  // b.any
    402030ac:	12001ee8 	and	w8, w23, #0xff
    402030b0:	7100091f 	cmp	w8, #0x2
    402030b4:	54000040 	b.eq	402030bc <jnox_kernel::ordinary_reservations::Runtime::close+0x3c8>  // b.none
    402030b8:	f900b715 	str	x21, [x24, #360]
    402030bc:	a94e4ff4 	ldp	x20, x19, [sp, #224]
    402030c0:	a94d57f6 	ldp	x22, x21, [sp, #208]
    402030c4:	a94c5ff8 	ldp	x24, x23, [sp, #192]
    402030c8:	a94b67fa 	ldp	x26, x25, [sp, #176]
    402030cc:	a94a6ffc 	ldp	x28, x27, [sp, #160]
    402030d0:	a9497bfd 	ldp	x29, x30, [sp, #144]
    402030d4:	9103c3ff 	add	sp, sp, #0xf0
    402030d8:	d65f03c0 	ret
    402030dc:	97fff873 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402030e0:	52800060 	mov	w0, #0x3                   	// #3
    402030e4:	94000071 	bl	402032a8 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    402030e8:	52800060 	mov	w0, #0x3                   	// #3
    402030ec:	52800061 	mov	w1, #0x3                   	// #3
    402030f0:	aa1403e2 	mov	x2, x20
    402030f4:	aa1303e3 	mov	x3, x19
    402030f8:	f94037e5 	ldr	x5, [sp, #104]
    402030fc:	97fffd5e 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>
    40203100:	52800040 	mov	w0, #0x2                   	// #2
    40203104:	52800041 	mov	w1, #0x2                   	// #2
    40203108:	aa1403e2 	mov	x2, x20
    4020310c:	aa1303e3 	mov	x3, x19
    40203110:	aa0a03e4 	mov	x4, x10
    40203114:	97fffd58 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>
    40203118:	52800040 	mov	w0, #0x2                   	// #2
    4020311c:	52800021 	mov	w1, #0x1                   	// #1
    40203120:	aa1403e2 	mov	x2, x20
    40203124:	aa1303e3 	mov	x3, x19
    40203128:	aa1603e4 	mov	x4, x22
    4020312c:	14000006 	b	40203144 <jnox_kernel::ordinary_reservations::Runtime::close+0x450>
    40203130:	52800040 	mov	w0, #0x2                   	// #2
    40203134:	528000e1 	mov	w1, #0x7                   	// #7
    40203138:	aa1403e2 	mov	x2, x20
    4020313c:	aa1303e3 	mov	x3, x19
    40203140:	aa0a03e4 	mov	x4, x10
    40203144:	aa0b03e5 	mov	x5, x11
    40203148:	97fffd4b 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>
    4020314c:	d503201f 	nop
    40203150:	10016742 	adr	x2, 40205e38 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.3.llvm.16183259764102968520+0x78>
    40203154:	aa1303e0 	mov	x0, x19
    40203158:	52800041 	mov	w1, #0x2                   	// #2
    4020315c:	940006b6 	bl	40204c34 <core::panicking::panic_bounds_check>
    40203160:	97fffbb3 	bl	4020202c <jnox_kernel::ordinary_reservations::run::{{closure}}>
    40203164:	52800040 	mov	w0, #0x2                   	// #2
    40203168:	52800121 	mov	w1, #0x9                   	// #9
    4020316c:	aa1403e2 	mov	x2, x20
    40203170:	aa1303e3 	mov	x3, x19
    40203174:	aa1603e4 	mov	x4, x22
    40203178:	97fffd3f 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>
    4020317c:	52800060 	mov	w0, #0x3                   	// #3
    40203180:	52800041 	mov	w1, #0x2                   	// #2
    40203184:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40203188:	52800043 	mov	w3, #0x2                   	// #2
    4020318c:	aa1f03e5 	mov	x5, xzr
    40203190:	97fffd39 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>

0000000040203194 <jnox_kernel::ordinary_reservations::Runtime::ledger>:
    40203194:	f81f0ffe 	str	x30, [sp, #-16]!
    40203198:	d503201f 	nop
    4020319c:	10103228 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    402031a0:	c8dffd08 	ldar	x8, [x8]
    402031a4:	b4000128 	cbz	x8, 402031c8 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x34>
    402031a8:	f1000d1f 	cmp	x8, #0x3
    402031ac:	540000c1 	b.ne	402031c4 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x30>  // b.any
    402031b0:	90000020 	adrp	x0, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402031b4:	91120000 	add	x0, x0, #0x480
    402031b8:	f9400008 	ldr	x8, [x0]
    402031bc:	f100091f 	cmp	x8, #0x2
    402031c0:	54000081 	b.ne	402031d0 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x3c>  // b.any
    402031c4:	97fff839 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402031c8:	d503201f 	nop
    402031cc:	100211a0 	adr	x0, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402031d0:	f84107fe 	ldr	x30, [sp], #16
    402031d4:	d65f03c0 	ret

00000000402031d8 <jnox_kernel::ordinary_reservations::Runtime::select>:
    402031d8:	d10143ff 	sub	sp, sp, #0x50
    402031dc:	f90013fe 	str	x30, [sp, #32]
    402031e0:	a90357f6 	stp	x22, x21, [sp, #48]
    402031e4:	a9044ff4 	stp	x20, x19, [sp, #64]
    402031e8:	d503201f 	nop
    402031ec:	100210a8 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402031f0:	8b010d09 	add	x9, x8, x1, lsl #3
    402031f4:	f940b534 	ldr	x20, [x9, #360]
    402031f8:	d503201f 	nop
    402031fc:	100a2928 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520>
    40203200:	f900b53f 	str	xzr, [x9, #360]
    40203204:	8b013909 	add	x9, x8, x1, lsl #14
    40203208:	eb14013f 	cmp	x9, x20
    4020320c:	540004c8 	b.hi	402032a4 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    40203210:	aa0103f3 	mov	x19, x1
    40203214:	d372c429 	lsl	x9, x1, #14
    40203218:	8b090108 	add	x8, x8, x9
    4020321c:	91401108 	add	x8, x8, #0x4, lsl #12
    40203220:	910d0289 	add	x9, x20, #0x340
    40203224:	b10d069f 	cmn	x20, #0x341
    40203228:	fa489122 	ccmp	x9, x8, #0x2, ls  // ls = plast
    4020322c:	540003c8 	b.hi	402032a4 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    40203230:	90000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520+0xb8e0>
    40203234:	f943f516 	ldr	x22, [x8, #2024]
    40203238:	f100fedf 	cmp	x22, #0x3f
    4020323c:	54000348 	b.hi	402032a4 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    40203240:	aa0003f5 	mov	x21, x0
    40203244:	d5033fdf 	isb
    40203248:	d53be021 	mrs	x1, cntpct_el0
    4020324c:	f9407e88 	ldr	x8, [x20, #248]
    40203250:	f9404e89 	ldr	x9, [x20, #152]
    40203254:	a90023f4 	stp	x20, x8, [sp]
    40203258:	f9408e88 	ldr	x8, [x20, #280]
    4020325c:	a90123e9 	stp	x9, x8, [sp, #16]
    40203260:	910003e4 	mov	x4, sp
    40203264:	52800240 	mov	w0, #0x12                  	// #18
    40203268:	aa1503e2 	mov	x2, x21
    4020326c:	aa1303e3 	mov	x3, x19
    40203270:	97fffcaa 	bl	40202518 <jnox_kernel::ordinary_reservations::event>
    40203274:	d503201f 	nop
    40203278:	1001ec48 	adr	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020327c:	8b161108 	add	x8, x8, x22, lsl #4
    40203280:	a9004d15 	stp	x21, x19, [x8]
    40203284:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203288:	f902b113 	str	x19, [x8, #1376]
    4020328c:	aa1403e0 	mov	x0, x20
    40203290:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40203294:	a94357f6 	ldp	x22, x21, [sp, #48]
    40203298:	f94013fe 	ldr	x30, [sp, #32]
    4020329c:	910143ff 	add	sp, sp, #0x50
    402032a0:	d65f03c0 	ret
    402032a4:	97fff801 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

00000000402032a8 <jnox_kernel::ordinary_reservations::checked::{{closure}}>:
    402032a8:	f81f0ffe 	str	x30, [sp, #-16]!
    402032ac:	92401c04 	and	x4, x0, #0xff
    402032b0:	52800060 	mov	w0, #0x3                   	// #3
    402032b4:	52800041 	mov	w1, #0x2                   	// #2
    402032b8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    402032bc:	52800043 	mov	w3, #0x2                   	// #2
    402032c0:	aa1f03e5 	mov	x5, xzr
    402032c4:	97fffcec 	bl	40202674 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.16183259764102968520>

00000000402032c8 <jnox_kernel::ordinary_reservations::snapshot>:
    402032c8:	f81f0ffe 	str	x30, [sp, #-16]!
    402032cc:	f100041f 	cmp	x0, #0x1
    402032d0:	54000488 	b.hi	40203360 <jnox_kernel::ordinary_reservations::snapshot+0x98>  // b.pmore
    402032d4:	d503201f 	nop
    402032d8:	101059c9 	adr	x9, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    402032dc:	8b000d29 	add	x9, x9, x0, lsl #3
    402032e0:	c8dffd29 	ldar	x9, [x9]
    402032e4:	b40002c9 	cbz	x9, 4020333c <jnox_kernel::ordinary_reservations::snapshot+0x74>
    402032e8:	d503201f 	nop
    402032ec:	100a21aa 	adr	x10, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520>
    402032f0:	8b00394b 	add	x11, x10, x0, lsl #14
    402032f4:	eb09017f 	cmp	x11, x9
    402032f8:	54000328 	b.hi	4020335c <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    402032fc:	b100a53f 	cmn	x9, #0x29
    40203300:	540002e8 	b.hi	4020335c <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    40203304:	d372c40b 	lsl	x11, x0, #14
    40203308:	8b0b014a 	add	x10, x10, x11
    4020330c:	9140114a 	add	x10, x10, #0x4, lsl #12
    40203310:	9100a12b 	add	x11, x9, #0x28
    40203314:	eb0a017f 	cmp	x11, x10
    40203318:	54000228 	b.hi	4020335c <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    4020331c:	9100812a 	add	x10, x9, #0x20
    40203320:	c8dffd40 	ldar	x0, [x10]
    40203324:	f100041f 	cmp	x0, #0x1
    40203328:	54000228 	b.hi	4020336c <jnox_kernel::ordinary_reservations::snapshot+0xa4>  // b.pmore
    4020332c:	8b00112b 	add	x11, x9, x0, lsl #4
    40203330:	f940016a 	ldr	x10, [x11]
    40203334:	f940056b 	ldr	x11, [x11, #8]
    40203338:	14000005 	b	4020334c <jnox_kernel::ordinary_reservations::snapshot+0x84>
    4020333c:	aa1f03ea 	mov	x10, xzr
    40203340:	d503201f 	nop
    40203344:	100152ab 	adr	x11, 40205d98 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.1.llvm.16183259764102968520>
    40203348:	f860796b 	ldr	x11, [x11, x0, lsl #3]
    4020334c:	a9002d0a 	stp	x10, x11, [x8]
    40203350:	f9000909 	str	x9, [x8, #16]
    40203354:	f84107fe 	ldr	x30, [sp], #16
    40203358:	d65f03c0 	ret
    4020335c:	97fff7d3 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40203360:	d503201f 	nop
    40203364:	10015822 	adr	x2, 40205e68 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.3.llvm.16183259764102968520+0xa8>
    40203368:	14000003 	b	40203374 <jnox_kernel::ordinary_reservations::snapshot+0xac>
    4020336c:	d503201f 	nop
    40203370:	10015882 	adr	x2, 40205e80 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.3.llvm.16183259764102968520+0xc0>
    40203374:	52800041 	mov	w1, #0x2                   	// #2
    40203378:	9400062f 	bl	40204c34 <core::panicking::panic_bounds_check>

000000004020337c <reservation_rust_work>:
    4020337c:	d10103ff 	sub	sp, sp, #0x40
    40203380:	f9001bfe 	str	x30, [sp, #48]
    40203384:	f100041f 	cmp	x0, #0x1
    40203388:	54000768 	b.hi	40203474 <reservation_rust_work+0xf8>  // b.pmore
    4020338c:	aa1f03e9 	mov	x9, xzr
    40203390:	d503201f 	nop
    40203394:	10015028 	adr	x8, 40205d98 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.1.llvm.16183259764102968520>
    40203398:	910023ea 	add	x10, sp, #0x8
    4020339c:	9280000b 	mov	x11, #0xffffffffffffffff    	// #-1
    402033a0:	f860790d 	ldr	x13, [x8, x0, lsl #3]
    402033a4:	9100e3ec 	add	x12, sp, #0x38
    402033a8:	d503201f 	nop
    402033ac:	10105328 	adr	x8, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    402033b0:	5280002e 	mov	w14, #0x1                   	// #1
    402033b4:	d503201f 	nop
    402033b8:	1002198f 	adr	x15, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    402033bc:	8b000d08 	add	x8, x8, x0, lsl #3
    402033c0:	8b000def 	add	x15, x15, x0, lsl #3
    402033c4:	a900b7ff 	stp	xzr, x13, [sp, #8]
    402033c8:	f9000fff 	str	xzr, [sp, #24]
    402033cc:	a9027fed 	stp	x13, xzr, [sp, #32]
    402033d0:	c89ffd0a 	stlr	x10, [x8]
    402033d4:	d503201f 	nop
    402033d8:	10021908 	adr	x8, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    402033dc:	8b000d10 	add	x16, x8, x0, lsl #3
    402033e0:	d503201f 	nop
    402033e4:	10105071 	adr	x17, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    402033e8:	d503201f 	nop
    402033ec:	101050a8 	adr	x8, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    402033f0:	8b000d12 	add	x18, x8, x0, lsl #3
    402033f4:	c8dffde8 	ldar	x8, [x15]
    402033f8:	eb0b011f 	cmp	x8, x11
    402033fc:	540000a0 	b.eq	40203410 <reservation_rust_work+0x94>  // b.none
    40203400:	d5033fdf 	isb
    40203404:	d53be02b 	mrs	x11, cntpct_el0
    40203408:	c89ffe4b 	stlr	x11, [x18]
    4020340c:	aa0803eb 	mov	x11, x8
    40203410:	52800208 	mov	w8, #0x10                  	// #16
    40203414:	8b0d05ad 	add	x13, x13, x13, lsl #1
    40203418:	910005ad 	add	x13, x13, #0x1
    4020341c:	f9001fed 	str	x13, [sp, #56]
    40203420:	f9401fed 	ldr	x13, [sp, #56]
    40203424:	71000508 	subs	w8, w8, #0x1
    40203428:	54ffff61 	b.ne	40203414 <reservation_rust_work+0x98>  // b.any
    4020342c:	f94017e8 	ldr	x8, [sp, #40]
    40203430:	cb0801c8 	sub	x8, x14, x8
    40203434:	f100051f 	cmp	x8, #0x1
    40203438:	54000248 	b.hi	40203480 <reservation_rust_work+0x104>  // b.pmore
    4020343c:	91004129 	add	x9, x9, #0x10
    40203440:	8b081141 	add	x1, x10, x8, lsl #4
    40203444:	f9000029 	str	x9, [x1]
    40203448:	f900042d 	str	x13, [x1, #8]
    4020344c:	91008141 	add	x1, x10, #0x20
    40203450:	c89ffc28 	stlr	x8, [x1]
    40203454:	c8dffe08 	ldar	x8, [x16]
    40203458:	eb08013f 	cmp	x9, x8
    4020345c:	54fffcc1 	b.ne	402033f4 <reservation_rust_work+0x78>  // b.any
    40203460:	f8607a28 	ldr	x8, [x17, x0, lsl #3]
    40203464:	f100091f 	cmp	x8, #0x2
    40203468:	54000161 	b.ne	40203494 <reservation_rust_work+0x118>  // b.any
    4020346c:	d4000021 	svc	#0x1
    40203470:	17ffffe1 	b	402033f4 <reservation_rust_work+0x78>
    40203474:	d503201f 	nop
    40203478:	10015102 	adr	x2, 40205e98 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.3.llvm.16183259764102968520+0xd8>
    4020347c:	14000004 	b	4020348c <reservation_rust_work+0x110>
    40203480:	d503201f 	nop
    40203484:	10015162 	adr	x2, 40205eb0 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.3.llvm.16183259764102968520+0xf0>
    40203488:	aa0803e0 	mov	x0, x8
    4020348c:	52800041 	mov	w1, #0x2                   	// #2
    40203490:	940005e9 	bl	40204c34 <core::panicking::panic_bounds_check>
    40203494:	d4000041 	svc	#0x2
    40203498:	d4200020 	brk	#0x1

000000004020349c <reservation_worker_a>:
    4020349c:	f81f0ffe 	str	x30, [sp, #-16]!
    402034a0:	aa1f03e0 	mov	x0, xzr
    402034a4:	97ffffb6 	bl	4020337c <reservation_rust_work>

00000000402034a8 <reservation_worker_b>:
    402034a8:	f81f0ffe 	str	x30, [sp, #-16]!
    402034ac:	52800020 	mov	w0, #0x1                   	// #1
    402034b0:	97ffffb3 	bl	4020337c <reservation_rust_work>

00000000402034b4 <jnox_kernel::reservation_jobs::Jobs::prepare_destination>:
    402034b4:	f9403409 	ldr	x9, [x0, #104]
    402034b8:	b40000c9 	cbz	x9, 402034d0 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x1c>
    402034bc:	52800089 	mov	w9, #0x4                   	// #4
    402034c0:	39002109 	strb	w9, [x8, #8]
    402034c4:	52800049 	mov	w9, #0x2                   	// #2
    402034c8:	f9000109 	str	x9, [x8]
    402034cc:	d65f03c0 	ret
    402034d0:	aa1f03ea 	mov	x10, xzr
    402034d4:	9101e009 	add	x9, x0, #0x78
    402034d8:	5280002b 	mov	w11, #0x1                   	// #1
    402034dc:	386a692c 	ldrb	w12, [x9, x10]
    402034e0:	3600008b 	tbz	w11, #0, 402034f0 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x3c>
    402034e4:	2a1f03eb 	mov	w11, wzr
    402034e8:	5280002a 	mov	w10, #0x1                   	// #1
    402034ec:	34ffff8c 	cbz	w12, 402034dc <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x28>
    402034f0:	35fffe6c 	cbnz	w12, 402034bc <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>
    402034f4:	39418009 	ldrb	w9, [x0, #96]
    402034f8:	71000d3f 	cmp	w9, #0x3
    402034fc:	54fffe01 	b.ne	402034bc <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>  // b.any
    40203500:	f9403809 	ldr	x9, [x0, #112]
    40203504:	b5fffdc9 	cbnz	x9, 402034bc <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>
    40203508:	aa1f03e1 	mov	x1, xzr
    4020350c:	14000141 	b	40203a10 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>

0000000040203510 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision>:
    40203510:	f9403408 	ldr	x8, [x0, #104]
    40203514:	f100051f 	cmp	x8, #0x1
    40203518:	54000321 	b.ne	4020357c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x6c>  // b.any
    4020351c:	d10143ff 	sub	sp, sp, #0x50
    40203520:	a9025ffe 	stp	x30, x23, [sp, #32]
    40203524:	a90357f6 	stp	x22, x21, [sp, #48]
    40203528:	a9044ff4 	stp	x20, x19, [sp, #64]
    4020352c:	aa0003f3 	mov	x19, x0
    40203530:	b9400028 	ldr	w8, [x1]
    40203534:	39418829 	ldrb	w9, [x1, #98]
    40203538:	7100011f 	cmp	w8, #0x0
    4020353c:	52800068 	mov	w8, #0x3                   	// #3
    40203540:	1a881128 	csel	w8, w9, w8, ne  // ne = any
    40203544:	39418009 	ldrb	w9, [x0, #96]
    40203548:	71000d3f 	cmp	w9, #0x3
    4020354c:	540001c0 	b.eq	40203584 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x74>  // b.none
    40203550:	71000d1f 	cmp	w8, #0x3
    40203554:	54000180 	b.eq	40203584 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x74>  // b.none
    40203558:	2a1f03e0 	mov	w0, wzr
    4020355c:	f940042a 	ldr	x10, [x1, #8]
    40203560:	f9402e6b 	ldr	x11, [x19, #88]
    40203564:	eb0b015f 	cmp	x10, x11
    40203568:	1a9f17ea 	cset	w10, eq  // eq = none
    4020356c:	6b08013f 	cmp	w9, w8
    40203570:	540007a1 	b.ne	40203664 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    40203574:	3700012a 	tbnz	w10, #0, 40203598 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x88>
    40203578:	1400003b 	b	40203664 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>
    4020357c:	2a1f03e0 	mov	w0, wzr
    40203580:	d65f03c0 	ret
    40203584:	2a1f03e0 	mov	w0, wzr
    40203588:	71000d3f 	cmp	w9, #0x3
    4020358c:	540006c1 	b.ne	40203664 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    40203590:	71000d1f 	cmp	w8, #0x3
    40203594:	54000681 	b.ne	40203664 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    40203598:	aa1f03eb 	mov	x11, xzr
    4020359c:	9101e268 	add	x8, x19, #0x78
    402035a0:	91018029 	add	x9, x1, #0x60
    402035a4:	5280002a 	mov	w10, #0x1                   	// #1
    402035a8:	386b690c 	ldrb	w12, [x8, x11]
    402035ac:	386b692d 	ldrb	w13, [x9, x11]
    402035b0:	360000aa 	tbz	w10, #0, 402035c4 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xb4>
    402035b4:	2a1f03ea 	mov	w10, wzr
    402035b8:	6b0d019f 	cmp	w12, w13
    402035bc:	5280002b 	mov	w11, #0x1                   	// #1
    402035c0:	54ffff40 	b.eq	402035a8 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x98>  // b.none
    402035c4:	6b0d019f 	cmp	w12, w13
    402035c8:	540004c1 	b.ne	40203660 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x150>  // b.any
    402035cc:	f9403a68 	ldr	x8, [x19, #112]
    402035d0:	f9402c29 	ldr	x9, [x1, #88]
    402035d4:	eb09011f 	cmp	x8, x9
    402035d8:	54000441 	b.ne	40203660 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x150>  // b.any
    402035dc:	aa1f03e8 	mov	x8, xzr
    402035e0:	91002274 	add	x20, x19, #0x8
    402035e4:	b8418675 	ldr	w21, [x19], #24
    402035e8:	91010037 	add	x23, x1, #0x40
    402035ec:	aa0803f6 	mov	x22, x8
    402035f0:	f100091f 	cmp	x8, #0x2
    402035f4:	54000300 	b.eq	40203654 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.none
    402035f8:	360000b5 	tbz	w21, #0, 4020360c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xfc>
    402035fc:	b9400268 	ldr	w8, [x19]
    40203600:	f85f0269 	ldur	x9, [x19, #-16]
    40203604:	a90127e8 	stp	x8, x9, [sp, #16]
    40203608:	14000009 	b	4020362c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x11c>
    4020360c:	910023e8 	add	x8, sp, #0x8
    40203610:	aa1403e0 	mov	x0, x20
    40203614:	aa1f03e1 	mov	x1, xzr
    40203618:	940002e7 	bl	402041b4 <jnox_kernel::service_policy::PeriodicReservation::allocation_at>
    4020361c:	f94007e8 	ldr	x8, [sp, #8]
    40203620:	f100051f 	cmp	x8, #0x1
    40203624:	54000181 	b.ne	40203654 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.any
    40203628:	f9400be8 	ldr	x8, [sp, #16]
    4020362c:	f85f82e9 	ldur	x9, [x23, #-8]
    40203630:	eb09011f 	cmp	x8, x9
    40203634:	54000101 	b.ne	40203654 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.any
    40203638:	f84106e9 	ldr	x9, [x23], #16
    4020363c:	91006273 	add	x19, x19, #0x18
    40203640:	f9400fea 	ldr	x10, [sp, #24]
    40203644:	9100a294 	add	x20, x20, #0x28
    40203648:	910006c8 	add	x8, x22, #0x1
    4020364c:	eb09015f 	cmp	x10, x9
    40203650:	54fffce0 	b.eq	402035ec <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xdc>  // b.none
    40203654:	f10006df 	cmp	x22, #0x1
    40203658:	1a9f97e0 	cset	w0, hi  // hi = pmore
    4020365c:	14000002 	b	40203664 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>
    40203660:	2a1f03e0 	mov	w0, wzr
    40203664:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40203668:	a94357f6 	ldp	x22, x21, [sp, #48]
    4020366c:	a9425ffe 	ldp	x30, x23, [sp, #32]
    40203670:	910143ff 	add	sp, sp, #0x50
    40203674:	d65f03c0 	ret

0000000040203678 <jnox_kernel::reservation_jobs::Jobs::new>:
    40203678:	d10203ff 	sub	sp, sp, #0x80
    4020367c:	a90657fe 	stp	x30, x21, [sp, #96]
    40203680:	a9074ff4 	stp	x20, x19, [sp, #112]
    40203684:	2a0103f4 	mov	w20, w1
    40203688:	2a0003f5 	mov	w21, w0
    4020368c:	aa0803f3 	mov	x19, x8
    40203690:	72001c3f 	tst	w1, #0xff
    40203694:	540002c0 	b.eq	402036ec <jnox_kernel::reservation_jobs::Jobs::new+0x74>  // b.none
    40203698:	52800028 	mov	w8, #0x1                   	// #1
    4020369c:	52800049 	mov	w9, #0x2                   	// #2
    402036a0:	290027e8 	stp	w8, w9, [sp]
    402036a4:	12001e8a 	and	w10, w20, #0xff
    402036a8:	7100095f 	cmp	w10, #0x2
    402036ac:	290127e8 	stp	w8, w9, [sp, #8]
    402036b0:	540002a1 	b.ne	40203704 <jnox_kernel::reservation_jobs::Jobs::new+0x8c>  // b.any
    402036b4:	29402be9 	ldp	w9, w10, [sp]
    402036b8:	29022be9 	stp	w9, w10, [sp, #16]
    402036bc:	29412be9 	ldp	w9, w10, [sp, #8]
    402036c0:	29032be9 	stp	w9, w10, [sp, #24]
    402036c4:	52800109 	mov	w9, #0x8                   	// #8
    402036c8:	290427e8 	stp	w8, w9, [sp, #32]
    402036cc:	910043e0 	add	x0, sp, #0x10
    402036d0:	52800061 	mov	w1, #0x3                   	// #3
    402036d4:	940003c7 	bl	402045f0 <jnox_kernel::temporal_policy::admit_reservations>
    402036d8:	12001c08 	and	w8, w0, #0xff
    402036dc:	71000d1f 	cmp	w8, #0x3
    402036e0:	54000401 	b.ne	40203760 <jnox_kernel::reservation_jobs::Jobs::new+0xe8>  // b.any
    402036e4:	52800088 	mov	w8, #0x4                   	// #4
    402036e8:	1400003b 	b	402037d4 <jnox_kernel::reservation_jobs::Jobs::new+0x15c>
    402036ec:	52800048 	mov	w8, #0x2                   	// #2
    402036f0:	52800109 	mov	w9, #0x8                   	// #8
    402036f4:	5280002a 	mov	w10, #0x1                   	// #1
    402036f8:	290027e8 	stp	w8, w9, [sp]
    402036fc:	52800088 	mov	w8, #0x4                   	// #4
    40203700:	290123ea 	stp	w10, w8, [sp, #8]
    40203704:	910003e0 	mov	x0, sp
    40203708:	52800041 	mov	w1, #0x2                   	// #2
    4020370c:	940003b9 	bl	402045f0 <jnox_kernel::temporal_policy::admit_reservations>
    40203710:	12001c08 	and	w8, w0, #0xff
    40203714:	71000d1f 	cmp	w8, #0x3
    40203718:	54000241 	b.ne	40203760 <jnox_kernel::reservation_jobs::Jobs::new+0xe8>  // b.any
    4020371c:	34000275 	cbz	w21, 40203768 <jnox_kernel::reservation_jobs::Jobs::new+0xf0>
    40203720:	294027e8 	ldp	w8, w9, [sp]
    40203724:	290a27e8 	stp	w8, w9, [sp, #80]
    40203728:	294127e8 	ldp	w8, w9, [sp, #8]
    4020372c:	290b27e8 	stp	w8, w9, [sp, #88]
    40203730:	910043e8 	add	x8, sp, #0x10
    40203734:	910143e1 	add	x1, sp, #0x50
    40203738:	aa1f03e0 	mov	x0, xzr
    4020373c:	940002df 	bl	402042b8 <jnox_kernel::temporal_policy::HardCbs<_>::new>
    40203740:	b94013e8 	ldr	w8, [sp, #16]
    40203744:	36000468 	tbz	w8, #0, 402037d0 <jnox_kernel::reservation_jobs::Jobs::new+0x158>
    40203748:	a941a7ee 	ldp	x14, x9, [sp, #24]
    4020374c:	a942a3eb 	ldp	x11, x8, [sp, #40]
    40203750:	a943abec 	ldp	x12, x10, [sp, #56]
    40203754:	5280002f 	mov	w15, #0x1                   	// #1
    40203758:	f94027ed 	ldr	x13, [sp, #72]
    4020375c:	14000011 	b	402037a0 <jnox_kernel::reservation_jobs::Jobs::new+0x128>
    40203760:	11000508 	add	w8, w8, #0x1
    40203764:	1400001c 	b	402037d4 <jnox_kernel::reservation_jobs::Jobs::new+0x15c>
    40203768:	294027e8 	ldp	w8, w9, [sp]
    4020376c:	d100050a 	sub	x10, x8, #0x1
    40203770:	eb09015f 	cmp	x10, x9
    40203774:	540002e2 	b.cs	402037d0 <jnox_kernel::reservation_jobs::Jobs::new+0x158>  // b.hs, b.nlast
    40203778:	294137ea 	ldp	w10, w13, [sp, #8]
    4020377c:	d100054b 	sub	x11, x10, #0x1
    40203780:	eb0d017f 	cmp	x11, x13
    40203784:	54000262 	b.cs	402037d0 <jnox_kernel::reservation_jobs::Jobs::new+0x158>  // b.hs, b.nlast
    40203788:	aa1f03ec 	mov	x12, xzr
    4020378c:	aa1f03eb 	mov	x11, xzr
    40203790:	aa1f03ef 	mov	x15, xzr
    40203794:	72001e9f 	tst	w20, #0xff
    40203798:	1a9f17f0 	cset	w16, eq  // eq = none
    4020379c:	aa0803ee 	mov	x14, x8
    402037a0:	a9003a6f 	stp	x15, x14, [x19]
    402037a4:	a9012e69 	stp	x9, x11, [x19, #16]
    402037a8:	a9023268 	stp	x8, x12, [x19, #32]
    402037ac:	a903366a 	stp	x10, x13, [x19, #48]
    402037b0:	a9042a70 	stp	x16, x10, [x19, #64]
    402037b4:	f9002a70 	str	x16, [x19, #80]
    402037b8:	52800068 	mov	w8, #0x3                   	// #3
    402037bc:	39018268 	strb	w8, [x19, #96]
    402037c0:	a906fe7f 	stp	xzr, xzr, [x19, #104]
    402037c4:	7900f27f 	strh	wzr, [x19, #120]
    402037c8:	3901ea74 	strb	w20, [x19, #122]
    402037cc:	14000005 	b	402037e0 <jnox_kernel::reservation_jobs::Jobs::new+0x168>
    402037d0:	52800028 	mov	w8, #0x1                   	// #1
    402037d4:	39002268 	strb	w8, [x19, #8]
    402037d8:	52800048 	mov	w8, #0x2                   	// #2
    402037dc:	f9000268 	str	x8, [x19]
    402037e0:	a9474ff4 	ldp	x20, x19, [sp, #112]
    402037e4:	a94657fe 	ldp	x30, x21, [sp, #96]
    402037e8:	910203ff 	add	sp, sp, #0x80
    402037ec:	d65f03c0 	ret

00000000402037f0 <jnox_kernel::reservation_jobs::Jobs::open>:
    402037f0:	d10783ff 	sub	sp, sp, #0x1e0
    402037f4:	a9197bfd 	stp	x29, x30, [sp, #400]
    402037f8:	a91a67fa 	stp	x26, x25, [sp, #416]
    402037fc:	a91b5ff8 	stp	x24, x23, [sp, #432]
    40203800:	a91c57f6 	stp	x22, x21, [sp, #448]
    40203804:	a91d4ff4 	stp	x20, x19, [sp, #464]
    40203808:	aa0803f3 	mov	x19, x8
    4020380c:	f9403408 	ldr	x8, [x0, #104]
    40203810:	eb08003f 	cmp	x1, x8
    40203814:	540002e1 	b.ne	40203870 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.any
    40203818:	aa0103f5 	mov	x21, x1
    4020381c:	aa0003f4 	mov	x20, x0
    40203820:	3941e816 	ldrb	w22, [x0, #122]
    40203824:	710002df 	cmp	w22, #0x0
    40203828:	52800148 	mov	w8, #0xa                   	// #10
    4020382c:	52800449 	mov	w9, #0x22                  	// #34
    40203830:	9a880128 	csel	x8, x9, x8, eq  // eq = none
    40203834:	eb08003f 	cmp	x1, x8
    40203838:	540001c2 	b.cs	40203870 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.hs, b.nlast
    4020383c:	39418288 	ldrb	w8, [x20, #96]
    40203840:	71000d1f 	cmp	w8, #0x3
    40203844:	54000161 	b.ne	40203870 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.any
    40203848:	aa1403e1 	mov	x1, x20
    4020384c:	f8408428 	ldr	x8, [x1], #8
    40203850:	f100051f 	cmp	x8, #0x1
    40203854:	54000241 	b.ne	4020389c <jnox_kernel::reservation_jobs::Jobs::open+0xac>  // b.any
    40203858:	f9401e97 	ldr	x23, [x20, #56]
    4020385c:	910583e0 	add	x0, sp, #0x160
    40203860:	52800602 	mov	w2, #0x30                  	// #48
    40203864:	94000844 	bl	40205974 <memcpy>
    40203868:	52800028 	mov	w8, #0x1                   	// #1
    4020386c:	14000021 	b	402038f0 <jnox_kernel::reservation_jobs::Jobs::open+0x100>
    40203870:	52800088 	mov	w8, #0x4                   	// #4
    40203874:	39002268 	strb	w8, [x19, #8]
    40203878:	52800048 	mov	w8, #0x2                   	// #2
    4020387c:	f9000268 	str	x8, [x19]
    40203880:	a95d4ff4 	ldp	x20, x19, [sp, #464]
    40203884:	a95c57f6 	ldp	x22, x21, [sp, #448]
    40203888:	a95b5ff8 	ldp	x24, x23, [sp, #432]
    4020388c:	a95a67fa 	ldp	x26, x25, [sp, #416]
    40203890:	a9597bfd 	ldp	x29, x30, [sp, #400]
    40203894:	910783ff 	add	sp, sp, #0x1e0
    40203898:	d65f03c0 	ret
    4020389c:	910203e0 	add	x0, sp, #0x80
    402038a0:	9100a017 	add	x23, x0, #0x28
    402038a4:	52800028 	mov	w8, #0x1                   	// #1
    402038a8:	2a0803f8 	mov	w24, w8
    402038ac:	9100a039 	add	x25, x1, #0x28
    402038b0:	52800502 	mov	w2, #0x28                  	// #40
    402038b4:	94000830 	bl	40205974 <memcpy>
    402038b8:	2a1f03e8 	mov	w8, wzr
    402038bc:	aa1903e1 	mov	x1, x25
    402038c0:	aa1703e0 	mov	x0, x23
    402038c4:	3707ff38 	tbnz	w24, #0, 402038a8 <jnox_kernel::reservation_jobs::Jobs::open+0xb8>
    402038c8:	910583e0 	add	x0, sp, #0x160
    402038cc:	910203e1 	add	x1, sp, #0x80
    402038d0:	52800602 	mov	w2, #0x30                  	// #48
    402038d4:	94000828 	bl	40205974 <memcpy>
    402038d8:	aa1f03e8 	mov	x8, xzr
    402038dc:	a94b27f7 	ldp	x23, x9, [sp, #176]
    402038e0:	a94c2fea 	ldp	x10, x11, [sp, #192]
    402038e4:	a914abe9 	stp	x9, x10, [sp, #328]
    402038e8:	f900afeb 	str	x11, [sp, #344]
    402038ec:	f9402e98 	ldr	x24, [x20, #88]
    402038f0:	f9403a99 	ldr	x25, [x20, #112]
    402038f4:	f90003e8 	str	x8, [sp]
    402038f8:	910003e8 	mov	x8, sp
    402038fc:	7940f29a 	ldrh	w26, [x20, #120]
    40203900:	91002100 	add	x0, x8, #0x8
    40203904:	910583e1 	add	x1, sp, #0x160
    40203908:	52800602 	mov	w2, #0x30                  	// #48
    4020390c:	9400081a 	bl	40205974 <memcpy>
    40203910:	3901ebf6 	strb	w22, [sp, #122]
    40203914:	a954a7e8 	ldp	x8, x9, [sp, #328]
    40203918:	a903a3f7 	stp	x23, x8, [sp, #56]
    4020391c:	f940afe8 	ldr	x8, [sp, #344]
    40203920:	a904a3e9 	stp	x9, x8, [sp, #72]
    40203924:	a906e7f5 	stp	x21, x25, [sp, #104]
    40203928:	7900f3fa 	strh	w26, [sp, #120]
    4020392c:	f9002ff8 	str	x24, [sp, #88]
    40203930:	52800068 	mov	w8, #0x3                   	// #3
    40203934:	390183e8 	strb	w8, [sp, #96]
    40203938:	910203f7 	add	x23, sp, #0x80
    4020393c:	910203e8 	add	x8, sp, #0x80
    40203940:	910003e0 	mov	x0, sp
    40203944:	aa1503e1 	mov	x1, x21
    40203948:	94000032 	bl	40203a10 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>
    4020394c:	f94043f6 	ldr	x22, [sp, #128]
    40203950:	394223f5 	ldrb	w21, [sp, #136]
    40203954:	f1000adf 	cmp	x22, #0x2
    40203958:	54000061 	b.ne	40203964 <jnox_kernel::reservation_jobs::Jobs::open+0x174>  // b.any
    4020395c:	39002275 	strb	w21, [x19, #8]
    40203960:	17ffffc6 	b	40203878 <jnox_kernel::reservation_jobs::Jobs::open+0x88>
    40203964:	9103a3e0 	add	x0, sp, #0xe8
    40203968:	910026e1 	add	x1, x23, #0x9
    4020396c:	52800be2 	mov	w2, #0x5f                  	// #95
    40203970:	94000801 	bl	40205974 <memcpy>
    40203974:	910003e1 	mov	x1, sp
    40203978:	aa1403e0 	mov	x0, x20
    4020397c:	52801002 	mov	w2, #0x80                  	// #128
    40203980:	940007fd 	bl	40205974 <memcpy>
    40203984:	f9000276 	str	x22, [x19]
    40203988:	39002275 	strb	w21, [x19, #8]
    4020398c:	91002660 	add	x0, x19, #0x9
    40203990:	9103a3e1 	add	x1, sp, #0xe8
    40203994:	52800be2 	mov	w2, #0x5f                  	// #95
    40203998:	940007f7 	bl	40205974 <memcpy>
    4020399c:	17ffffb9 	b	40203880 <jnox_kernel::reservation_jobs::Jobs::open+0x90>

00000000402039a0 <jnox_kernel::reservation_jobs::Jobs::trap>:
    402039a0:	3941800a 	ldrb	w10, [x0, #96]
    402039a4:	71000d5f 	cmp	w10, #0x3
    402039a8:	54000061 	b.ne	402039b4 <jnox_kernel::reservation_jobs::Jobs::trap+0x14>  // b.any
    402039ac:	52800080 	mov	w0, #0x4                   	// #4
    402039b0:	d65f03c0 	ret
    402039b4:	aa0003e8 	mov	x8, x0
    402039b8:	12001c49 	and	w9, w2, #0xff
    402039bc:	52800080 	mov	w0, #0x4                   	// #4
    402039c0:	6b09015f 	cmp	w10, w9
    402039c4:	54000181 	b.ne	402039f4 <jnox_kernel::reservation_jobs::Jobs::trap+0x54>  // b.any
    402039c8:	f9402d0a 	ldr	x10, [x8, #88]
    402039cc:	eb01015f 	cmp	x10, x1
    402039d0:	54000121 	b.ne	402039f4 <jnox_kernel::reservation_jobs::Jobs::trap+0x54>  // b.any
    402039d4:	f100043f 	cmp	x1, #0x1
    402039d8:	54000108 	b.hi	402039f8 <jnox_kernel::reservation_jobs::Jobs::trap+0x58>  // b.pmore
    402039dc:	2a1f03e0 	mov	w0, wzr
    402039e0:	11000929 	add	w9, w9, #0x2
    402039e4:	8b01010a 	add	x10, x8, x1
    402039e8:	3901e149 	strb	w9, [x10, #120]
    402039ec:	52800069 	mov	w9, #0x3                   	// #3
    402039f0:	39018109 	strb	w9, [x8, #96]
    402039f4:	d65f03c0 	ret
    402039f8:	f81f0ffe 	str	x30, [sp, #-16]!
    402039fc:	d503201f 	nop
    40203a00:	10012642 	adr	x2, 40205ec8 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236>
    40203a04:	aa0103e0 	mov	x0, x1
    40203a08:	52800041 	mov	w1, #0x2                   	// #2
    40203a0c:	9400048a 	bl	40204c34 <core::panicking::panic_bounds_check>

0000000040203a10 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>:
    40203a10:	d10483ff 	sub	sp, sp, #0x120
    40203a14:	a90c7bfd 	stp	x29, x30, [sp, #192]
    40203a18:	a90d6ffc 	stp	x28, x27, [sp, #208]
    40203a1c:	a90e67fa 	stp	x26, x25, [sp, #224]
    40203a20:	a90f5ff8 	stp	x24, x23, [sp, #240]
    40203a24:	a91057f6 	stp	x22, x21, [sp, #256]
    40203a28:	a9114ff4 	stp	x20, x19, [sp, #272]
    40203a2c:	aa0103f5 	mov	x21, x1
    40203a30:	aa0003f4 	mov	x20, x0
    40203a34:	aa0803f3 	mov	x19, x8
    40203a38:	3941e808 	ldrb	w8, [x0, #122]
    40203a3c:	910083e9 	add	x9, sp, #0x20
    40203a40:	9100413b 	add	x27, x9, #0x10
    40203a44:	340000e8 	cbz	w8, 40203a60 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x50>
    40203a48:	f10002bf 	cmp	x21, #0x0
    40203a4c:	b21e03e9 	mov	x9, #0x400000004           	// #17179869188
    40203a50:	9a9f0129 	csel	x9, x9, xzr, eq  // eq = none
    40203a54:	7100051f 	cmp	w8, #0x1
    40203a58:	9a9f012a 	csel	x10, x9, xzr, eq  // eq = none
    40203a5c:	1400000b 	b	40203a88 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203a60:	aa1f03ea 	mov	x10, xzr
    40203a64:	f1005ebf 	cmp	x21, #0x17
    40203a68:	54000108 	b.hi	40203a88 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>  // b.pmore
    40203a6c:	52800028 	mov	w8, #0x1                   	// #1
    40203a70:	9ad52108 	lsl	x8, x8, x21
    40203a74:	52840629 	mov	w9, #0x2031                	// #8241
    40203a78:	72a00809 	movk	w9, #0x40, lsl #16
    40203a7c:	ea09011f 	tst	x8, x9
    40203a80:	54000da0 	b.eq	40203c34 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x224>  // b.none
    40203a84:	5280002a 	mov	w10, #0x1                   	// #1
    40203a88:	aa1f03f6 	mov	x22, xzr
    40203a8c:	a9012bea 	stp	x10, x10, [sp, #16]
    40203a90:	5280011d 	mov	w29, #0x8                   	// #8
    40203a94:	910063fa 	add	x26, sp, #0x18
    40203a98:	5280003c 	mov	w28, #0x1                   	// #1
    40203a9c:	b8767b57 	ldr	w23, [x26, x22, lsl #2]
    40203aa0:	34000297 	cbz	w23, 40203af0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0xe0>
    40203aa4:	8b160298 	add	x24, x20, x22
    40203aa8:	3941e308 	ldrb	w8, [x24, #120]
    40203aac:	71000d1f 	cmp	w8, #0x3
    40203ab0:	7a401904 	ccmp	w8, #0x0, #0x4, ne  // ne = any
    40203ab4:	540014a1 	b.ne	40203d48 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.any
    40203ab8:	8b160a99 	add	x25, x20, x22, lsl #2
    40203abc:	b9407328 	ldr	w8, [x25, #112]
    40203ac0:	35001448 	cbnz	w8, 40203d48 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203ac4:	f9400288 	ldr	x8, [x20]
    40203ac8:	f100051f 	cmp	x8, #0x1
    40203acc:	540000e1 	b.ne	40203ae8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0xd8>  // b.any
    40203ad0:	91002280 	add	x0, x20, #0x8
    40203ad4:	aa1603e1 	mov	x1, x22
    40203ad8:	2a1703e2 	mov	w2, w23
    40203adc:	94000279 	bl	402044c0 <jnox_kernel::temporal_policy::HardCbs<_>::release>
    40203ae0:	f100141f 	cmp	x0, #0x5
    40203ae4:	54000a01 	b.ne	40203c24 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x214>  // b.any
    40203ae8:	b9007337 	str	w23, [x25, #112]
    40203aec:	3901e31c 	strb	w28, [x24, #120]
    40203af0:	f10013bd 	subs	x29, x29, #0x4
    40203af4:	910006d6 	add	x22, x22, #0x1
    40203af8:	54fffd21 	b.ne	40203a9c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x8c>  // b.any
    40203afc:	6f00e400 	movi	v0.2d, #0x0
    40203b00:	ad0103e0 	stp	q0, q0, [sp, #32]
    40203b04:	f9400288 	ldr	x8, [x20]
    40203b08:	f100051f 	cmp	x8, #0x1
    40203b0c:	54000421 	b.ne	40203b90 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x180>  // b.any
    40203b10:	aa1f03f5 	mov	x21, xzr
    40203b14:	aa1f03fb 	mov	x27, xzr
    40203b18:	91006296 	add	x22, x20, #0x18
    40203b1c:	910083f7 	add	x23, sp, #0x20
    40203b20:	910203e8 	add	x8, sp, #0x80
    40203b24:	91002280 	add	x0, x20, #0x8
    40203b28:	aa1503e1 	mov	x1, x21
    40203b2c:	9400028b 	bl	40204558 <jnox_kernel::temporal_policy::HardCbs<_>::available>
    40203b30:	a94823e9 	ldp	x9, x8, [sp, #128]
    40203b34:	f100093f 	cmp	x9, #0x2
    40203b38:	54000280 	b.eq	40203b88 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x178>  // b.none
    40203b3c:	36000069 	tbz	w9, #0, 40203b48 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x138>
    40203b40:	f9404be9 	ldr	x9, [sp, #144]
    40203b44:	14000003 	b	40203b50 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x140>
    40203b48:	b94002c8 	ldr	w8, [x22]
    40203b4c:	f85f02c9 	ldur	x9, [x22, #-16]
    40203b50:	8b1b02ea 	add	x10, x23, x27
    40203b54:	9100437b 	add	x27, x27, #0x10
    40203b58:	2a0803e8 	mov	w8, w8
    40203b5c:	a9002548 	stp	x8, x9, [x10]
    40203b60:	910062d6 	add	x22, x22, #0x18
    40203b64:	910006b5 	add	x21, x21, #0x1
    40203b68:	f100837f 	cmp	x27, #0x20
    40203b6c:	54fffda1 	b.ne	40203b20 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x110>  // b.any
    40203b70:	910203e8 	add	x8, sp, #0x80
    40203b74:	91002280 	add	x0, x20, #0x8
    40203b78:	940001f4 	bl	40204348 <jnox_kernel::temporal_policy::HardCbs<_>::tick>
    40203b7c:	a94823e9 	ldp	x9, x8, [sp, #128]
    40203b80:	f100053f 	cmp	x9, #0x1
    40203b84:	54000641 	b.ne	40203c4c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x23c>  // b.any
    40203b88:	f100111f 	cmp	x8, #0x4
    40203b8c:	14000027 	b	40203c28 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x218>
    40203b90:	910083e8 	add	x8, sp, #0x20
    40203b94:	b27d0117 	orr	x23, x8, #0x8
    40203b98:	52800a1a 	mov	w26, #0x50                  	// #80
    40203b9c:	91002296 	add	x22, x20, #0x8
    40203ba0:	910203e8 	add	x8, sp, #0x80
    40203ba4:	aa1603e0 	mov	x0, x22
    40203ba8:	aa1503e1 	mov	x1, x21
    40203bac:	94000182 	bl	402041b4 <jnox_kernel::service_policy::PeriodicReservation::allocation_at>
    40203bb0:	b94083e8 	ldr	w8, [sp, #128]
    40203bb4:	36001108 	tbz	w8, #0, 40203dd4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c4>
    40203bb8:	a948a7e8 	ldp	x8, x9, [sp, #136]
    40203bbc:	f100a35a 	subs	x26, x26, #0x28
    40203bc0:	a93fa6e8 	stp	x8, x9, [x23, #-8]
    40203bc4:	9100a2d6 	add	x22, x22, #0x28
    40203bc8:	910042f7 	add	x23, x23, #0x10
    40203bcc:	54fffea1 	b.ne	40203ba0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x190>  // b.any
    40203bd0:	aa1f03e8 	mov	x8, xzr
    40203bd4:	910083e9 	add	x9, sp, #0x20
    40203bd8:	9101c28c 	add	x12, x20, #0x70
    40203bdc:	a90827ec 	stp	x12, x9, [sp, #128]
    40203be0:	5280004a 	mov	w10, #0x2                   	// #2
    40203be4:	a909a7ea 	stp	x10, x9, [sp, #152]
    40203be8:	f9400bf7 	ldr	x23, [sp, #16]
    40203bec:	9100050a 	add	x10, x8, #0x1
    40203bf0:	b868798b 	ldr	w11, [x12, x8, lsl #2]
    40203bf4:	3400006b 	cbz	w11, 40203c00 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x1f0>
    40203bf8:	f940012b 	ldr	x11, [x9]
    40203bfc:	b50003cb 	cbnz	x11, 40203c74 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x264>
    40203c00:	f100095f 	cmp	x10, #0x2
    40203c04:	aa1b03e9 	mov	x9, x27
    40203c08:	52800028 	mov	w8, #0x1                   	// #1
    40203c0c:	54ffff01 	b.ne	40203bec <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x1dc>  // b.any
    40203c10:	aa1f03e9 	mov	x9, xzr
    40203c14:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203c18:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203c1c:	52800068 	mov	w8, #0x3                   	// #3
    40203c20:	14000059 	b	40203d84 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x374>
    40203c24:	f100101f 	cmp	x0, #0x4
    40203c28:	52800068 	mov	w8, #0x3                   	// #3
    40203c2c:	1a880508 	cinc	w8, w8, ne  // ne = any
    40203c30:	1400006a 	b	40203dd8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c8>
    40203c34:	f10006bf 	cmp	x21, #0x1
    40203c38:	540008c0 	b.eq	40203d50 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x340>  // b.none
    40203c3c:	f1005ebf 	cmp	x21, #0x17
    40203c40:	54fff241 	b.ne	40203a88 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>  // b.any
    40203c44:	52800c8a 	mov	w10, #0x64                  	// #100
    40203c48:	17ffff90 	b	40203a88 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203c4c:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203c50:	f9404bf6 	ldr	x22, [sp, #144]
    40203c54:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203c58:	36000808 	tbz	w8, #0, 40203d58 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x348>
    40203c5c:	f10006df 	cmp	x22, #0x1
    40203c60:	f9400bf7 	ldr	x23, [sp, #16]
    40203c64:	54000369 	b.ls	40203cd0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x2c0>  // b.plast
    40203c68:	d503201f 	nop
    40203c6c:	10011462 	adr	x2, 40205ef8 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x30>
    40203c70:	14000067 	b	40203e0c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3fc>
    40203c74:	f9004bea 	str	x10, [sp, #144]
    40203c78:	f9400529 	ldr	x9, [x9, #8]
    40203c7c:	a90aa3e9 	stp	x9, x8, [sp, #168]
    40203c80:	f9005fe8 	str	x8, [sp, #184]
    40203c84:	910183e8 	add	x8, sp, #0x60
    40203c88:	91002108 	add	x8, x8, #0x8
    40203c8c:	910203e0 	add	x0, sp, #0x80
    40203c90:	9102a3e1 	add	x1, sp, #0xa8
    40203c94:	94000098 	bl	40203ef4 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold>
    40203c98:	f9403ff6 	ldr	x22, [sp, #120]
    40203c9c:	f1000adf 	cmp	x22, #0x2
    40203ca0:	54000b22 	b.cs	40203e04 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3f4>  // b.hs, b.nlast
    40203ca4:	52800508 	mov	w8, #0x28                  	// #40
    40203ca8:	91002289 	add	x9, x20, #0x8
    40203cac:	9b0826c0 	madd	x0, x22, x8, x9
    40203cb0:	aa1503e1 	mov	x1, x21
    40203cb4:	52800022 	mov	w2, #0x1                   	// #1
    40203cb8:	9400015a 	bl	40204220 <jnox_kernel::service_policy::PeriodicReservation::grant_at>
    40203cbc:	f100041f 	cmp	x0, #0x1
    40203cc0:	fa410820 	ccmp	x1, #0x1, #0x0, eq  // eq = none
    40203cc4:	54000421 	b.ne	40203d48 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.any
    40203cc8:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203ccc:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203cd0:	9101e288 	add	x8, x20, #0x78
    40203cd4:	38766908 	ldrb	w8, [x8, x22]
    40203cd8:	51000508 	sub	w8, w8, #0x1
    40203cdc:	7100091f 	cmp	w8, #0x2
    40203ce0:	54000342 	b.cs	40203d48 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.hs, b.nlast
    40203ce4:	9101c28a 	add	x10, x20, #0x70
    40203ce8:	b8767948 	ldr	w8, [x10, x22, lsl #2]
    40203cec:	51000509 	sub	w9, w8, #0x1
    40203cf0:	d3607d29 	lsl	x9, x9, #32
    40203cf4:	7100011f 	cmp	w8, #0x0
    40203cf8:	52808028 	mov	w8, #0x401                 	// #1025
    40203cfc:	9a890108 	csel	x8, x8, x9, eq  // eq = none
    40203d00:	37000248 	tbnz	w8, #0, 40203d48 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203d04:	d360fd08 	lsr	x8, x8, #32
    40203d08:	b8367948 	str	w8, [x10, x22, lsl #2]
    40203d0c:	910103e9 	add	x9, sp, #0x40
    40203d10:	8b161129 	add	x9, x9, x22, lsl #4
    40203d14:	f940012a 	ldr	x10, [x9]
    40203d18:	b400018a 	cbz	x10, 40203d48 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203d1c:	d100054a 	sub	x10, x10, #0x1
    40203d20:	f900012a 	str	x10, [x9]
    40203d24:	3941ea89 	ldrb	w9, [x20, #122]
    40203d28:	7100093f 	cmp	w9, #0x2
    40203d2c:	540001e0 	b.eq	40203d68 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x358>  // b.none
    40203d30:	7100053f 	cmp	w9, #0x1
    40203d34:	540001e1 	b.ne	40203d70 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x360>  // b.any
    40203d38:	f100011f 	cmp	x8, #0x0
    40203d3c:	52800048 	mov	w8, #0x2                   	// #2
    40203d40:	1a9f0108 	csel	w8, w8, wzr, eq  // eq = none
    40203d44:	1400000d 	b	40203d78 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x368>
    40203d48:	52800088 	mov	w8, #0x4                   	// #4
    40203d4c:	14000023 	b	40203dd8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c8>
    40203d50:	d2c00c8a 	mov	x10, #0x6400000000          	// #429496729600
    40203d54:	17ffff4d 	b	40203a88 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203d58:	aa1f03e9 	mov	x9, xzr
    40203d5c:	52800068 	mov	w8, #0x3                   	// #3
    40203d60:	f9400bf7 	ldr	x23, [sp, #16]
    40203d64:	14000008 	b	40203d84 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x374>
    40203d68:	2a1f03e8 	mov	w8, wzr
    40203d6c:	14000003 	b	40203d78 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x368>
    40203d70:	f100011f 	cmp	x8, #0x0
    40203d74:	1a9f17e8 	cset	w8, eq  // eq = none
    40203d78:	f9002e96 	str	x22, [x20, #88]
    40203d7c:	52800029 	mov	w9, #0x1                   	// #1
    40203d80:	39018288 	strb	w8, [x20, #96]
    40203d84:	f940368a 	ldr	x10, [x20, #104]
    40203d88:	b100055f 	cmn	x10, #0x1
    40203d8c:	54000240 	b.eq	40203dd4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c4>  // b.none
    40203d90:	9100054a 	add	x10, x10, #0x1
    40203d94:	f900368a 	str	x10, [x20, #104]
    40203d98:	a9422fea 	ldp	x10, x11, [sp, #32]
    40203d9c:	a94337ec 	ldp	x12, x13, [sp, #48]
    40203da0:	a902326b 	stp	x11, x12, [x19, #32]
    40203da4:	a94433eb 	ldp	x11, x12, [sp, #64]
    40203da8:	a9032e6d 	stp	x13, x11, [x19, #48]
    40203dac:	a9452fed 	ldp	x13, x11, [sp, #80]
    40203db0:	a904366c 	stp	x12, x13, [x19, #64]
    40203db4:	a9005a69 	stp	x9, x22, [x19]
    40203db8:	7940f289 	ldrh	w9, [x20, #120]
    40203dbc:	f9403a8c 	ldr	x12, [x20, #112]
    40203dc0:	a9012a77 	stp	x23, x10, [x19, #16]
    40203dc4:	a905326b 	stp	x11, x12, [x19, #80]
    40203dc8:	7900c269 	strh	w9, [x19, #96]
    40203dcc:	39018a68 	strb	w8, [x19, #98]
    40203dd0:	14000005 	b	40203de4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3d4>
    40203dd4:	52800068 	mov	w8, #0x3                   	// #3
    40203dd8:	39002268 	strb	w8, [x19, #8]
    40203ddc:	52800048 	mov	w8, #0x2                   	// #2
    40203de0:	f9000268 	str	x8, [x19]
    40203de4:	a9514ff4 	ldp	x20, x19, [sp, #272]
    40203de8:	a95057f6 	ldp	x22, x21, [sp, #256]
    40203dec:	a94f5ff8 	ldp	x24, x23, [sp, #240]
    40203df0:	a94e67fa 	ldp	x26, x25, [sp, #224]
    40203df4:	a94d6ffc 	ldp	x28, x27, [sp, #208]
    40203df8:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    40203dfc:	910483ff 	add	sp, sp, #0x120
    40203e00:	d65f03c0 	ret
    40203e04:	d503201f 	nop
    40203e08:	100106c2 	adr	x2, 40205ee0 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x18>
    40203e0c:	aa1603e0 	mov	x0, x22
    40203e10:	52800041 	mov	w1, #0x2                   	// #2
    40203e14:	94000388 	bl	40204c34 <core::panicking::panic_bounds_check>

0000000040203e18 <jnox_kernel::reservation_jobs::Clock::new>:
    40203e18:	b40005a1 	cbz	x1, 40203ecc <jnox_kernel::reservation_jobs::Clock::new+0xb4>
    40203e1c:	d343fc29 	lsr	x9, x1, #3
    40203e20:	d29ef9ea 	mov	x10, #0xf7cf                	// #63439
    40203e24:	f2bc6a6a 	movk	x10, #0xe353, lsl #16
    40203e28:	f2d374aa 	movk	x10, #0x9ba5, lsl #32
    40203e2c:	f2e4188a 	movk	x10, #0x20c4, lsl #48
    40203e30:	9bca7d29 	umulh	x9, x9, x10
    40203e34:	d344fd29 	lsr	x9, x9, #4
    40203e38:	52807d0a 	mov	w10, #0x3e8                 	// #1000
    40203e3c:	9b0a852a 	msub	x10, x9, x10, x1
    40203e40:	b500046a 	cbnz	x10, 40203ecc <jnox_kernel::reservation_jobs::Clock::new+0xb4>
    40203e44:	b202e7ea 	mov	x10, #0xcccccccccccccccc    	// #-3689348814741910324
    40203e48:	f29999aa 	movk	x10, #0xcccd
    40203e4c:	9bca7c2a 	umulh	x10, x1, x10
    40203e50:	d344fd4a 	lsr	x10, x10, #4
    40203e54:	72001c5f 	tst	w2, #0xff
    40203e58:	5280014b 	mov	w11, #0xa                   	// #10
    40203e5c:	5280050c 	mov	w12, #0x28                  	// #40
    40203e60:	9a8b018b 	csel	x11, x12, x11, eq  // eq = none
    40203e64:	9bca7d6c 	umulh	x12, x11, x10
    40203e68:	eb0c03ff 	cmp	xzr, x12
    40203e6c:	1a9f07ec 	cset	w12, ne  // ne = any
    40203e70:	9b0a7d6b 	mul	x11, x11, x10
    40203e74:	ab0b001f 	cmn	x0, x11
    40203e78:	1a9f37eb 	cset	w11, cs  // cs = hs, nlast
    40203e7c:	3700020c 	tbnz	w12, #0, 40203ebc <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203e80:	350001eb 	cbnz	w11, 40203ebc <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203e84:	72001c5f 	tst	w2, #0xff
    40203e88:	5280014b 	mov	w11, #0xa                   	// #10
    40203e8c:	5280044c 	mov	w12, #0x22                  	// #34
    40203e90:	9a8b018b 	csel	x11, x12, x11, eq  // eq = none
    40203e94:	9bca7d6c 	umulh	x12, x11, x10
    40203e98:	eb0c03ff 	cmp	xzr, x12
    40203e9c:	1a9f07ed 	cset	w13, ne  // ne = any
    40203ea0:	9b0a7d6b 	mul	x11, x11, x10
    40203ea4:	ab00016b 	adds	x11, x11, x0
    40203ea8:	1a9f37ec 	cset	w12, cs  // cs = hs, nlast
    40203eac:	3700008d 	tbnz	w13, #0, 40203ebc <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203eb0:	3500006c 	cbnz	w12, 40203ebc <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203eb4:	ab09057f 	cmn	x11, x9, lsl #1
    40203eb8:	54000123 	b.cc	40203edc <jnox_kernel::reservation_jobs::Clock::new+0xc4>  // b.lo, b.ul, b.last
    40203ebc:	52800069 	mov	w9, #0x3                   	// #3
    40203ec0:	39000509 	strb	w9, [x8, #1]
    40203ec4:	5280002b 	mov	w11, #0x1                   	// #1
    40203ec8:	14000003 	b	40203ed4 <jnox_kernel::reservation_jobs::Clock::new+0xbc>
    40203ecc:	5280002b 	mov	w11, #0x1                   	// #1
    40203ed0:	3900050b 	strb	w11, [x8, #1]
    40203ed4:	3900010b 	strb	w11, [x8]
    40203ed8:	d65f03c0 	ret
    40203edc:	2a1f03eb 	mov	w11, wzr
    40203ee0:	a900a900 	stp	x0, x10, [x8, #8]
    40203ee4:	f9000d09 	str	x9, [x8, #24]
    40203ee8:	17fffffb 	b	40203ed4 <jnox_kernel::reservation_jobs::Clock::new+0xbc>

0000000040203eec <__rustc::rust_begin_unwind>:
    40203eec:	d503205f 	wfe
    40203ef0:	17ffffff 	b	40203eec <__rustc::rust_begin_unwind>

0000000040203ef4 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold>:
    40203ef4:	d10103ff 	sub	sp, sp, #0x40
    40203ef8:	f9001bfe 	str	x30, [sp, #48]
    40203efc:	a9412809 	ldp	x9, x10, [x0, #16]
    40203f00:	eb0a013f 	cmp	x9, x10
    40203f04:	540004e2 	b.cs	40203fa0 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0xac>  // b.hs, b.nlast
    40203f08:	f940100e 	ldr	x14, [x0, #32]
    40203f0c:	a940340b 	ldp	x11, x13, [x0]
    40203f10:	910003ec 	mov	x12, sp
    40203f14:	9100618c 	add	x12, x12, #0x18
    40203f18:	f100093f 	cmp	x9, #0x2
    40203f1c:	5280004f 	mov	w15, #0x2                   	// #2
    40203f20:	9a8f8120 	csel	x0, x9, x15, hi  // hi = pmore
    40203f24:	8b0911ad 	add	x13, x13, x9, lsl #4
    40203f28:	8b0911ce 	add	x14, x14, x9, lsl #4
    40203f2c:	910021ce 	add	x14, x14, #0x8
    40203f30:	eb09001f 	cmp	x0, x9
    40203f34:	54000440 	b.eq	40203fbc <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0xc8>  // b.none
    40203f38:	b869796f 	ldr	w15, [x11, x9, lsl #2]
    40203f3c:	3400028f 	cbz	w15, 40203f8c <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x98>
    40203f40:	f94001af 	ldr	x15, [x13]
    40203f44:	b400024f 	cbz	x15, 40203f8c <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x98>
    40203f48:	f94001cf 	ldr	x15, [x14]
    40203f4c:	a9404430 	ldp	x16, x17, [x1]
    40203f50:	a90047f0 	stp	x16, x17, [sp]
    40203f54:	f9400831 	ldr	x17, [x1, #16]
    40203f58:	a9013ff1 	stp	x17, x15, [sp, #16]
    40203f5c:	eb0f021f 	cmp	x16, x15
    40203f60:	a90227e9 	stp	x9, x9, [sp, #32]
    40203f64:	54000061 	b.ne	40203f70 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x7c>  // b.any
    40203f68:	f94007ef 	ldr	x15, [sp, #8]
    40203f6c:	eb0901ff 	cmp	x15, x9
    40203f70:	aa0c03ef 	mov	x15, x12
    40203f74:	54000048 	b.hi	40203f7c <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x88>  // b.pmore
    40203f78:	910003ef 	mov	x15, sp
    40203f7c:	a94045f0 	ldp	x16, x17, [x15]
    40203f80:	a9004430 	stp	x16, x17, [x1]
    40203f84:	f94009ef 	ldr	x15, [x15, #16]
    40203f88:	f900082f 	str	x15, [x1, #16]
    40203f8c:	91000529 	add	x9, x9, #0x1
    40203f90:	910041ad 	add	x13, x13, #0x10
    40203f94:	910041ce 	add	x14, x14, #0x10
    40203f98:	eb09015f 	cmp	x10, x9
    40203f9c:	54fffca1 	b.ne	40203f30 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x3c>  // b.any
    40203fa0:	a9402829 	ldp	x9, x10, [x1]
    40203fa4:	a9002909 	stp	x9, x10, [x8]
    40203fa8:	f9400829 	ldr	x9, [x1, #16]
    40203fac:	f9000909 	str	x9, [x8, #16]
    40203fb0:	f9401bfe 	ldr	x30, [sp, #48]
    40203fb4:	910103ff 	add	sp, sp, #0x40
    40203fb8:	d65f03c0 	ret
    40203fbc:	d503201f 	nop
    40203fc0:	1000fe82 	adr	x2, 40205f90 <anon.e5cf9e378689f0b52d762c1b402a78cc.8.llvm.13402452413823366170>
    40203fc4:	52800041 	mov	w1, #0x2                   	// #2
    40203fc8:	9400031b 	bl	40204c34 <core::panicking::panic_bounds_check>

0000000040203fcc <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>:
    40203fcc:	d10083ff 	sub	sp, sp, #0x20
    40203fd0:	d503201f 	nop
    40203fd4:	10ffa649 	adr	x9, 4020349c <reservation_worker_a>
    40203fd8:	d503201f 	nop
    40203fdc:	10ffa66a 	adr	x10, 402034a8 <reservation_worker_b>
    40203fe0:	f90003e9 	str	x9, [sp]
    40203fe4:	a900fbea 	stp	x10, x30, [sp, #8]
    40203fe8:	f100043f 	cmp	x1, #0x1
    40203fec:	54000928 	b.hi	40204110 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x144>  // b.pmore
    40203ff0:	d503201f 	nop
    40203ff4:	1009b969 	adr	x9, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520>
    40203ff8:	8b013929 	add	x9, x9, x1, lsl #14
    40203ffc:	5287980a 	mov	w10, #0x3cc0                	// #15552
    40204000:	8b0a0129 	add	x9, x9, x10
    40204004:	f940000a 	ldr	x10, [x0]
    40204008:	8b010d4b 	add	x11, x10, x1, lsl #3
    4020400c:	f940b56d 	ldr	x13, [x11, #360]
    40204010:	eb0d013f 	cmp	x9, x13
    40204014:	540007c1 	b.ne	4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    40204018:	910003ea 	mov	x10, sp
    4020401c:	f861794a 	ldr	x10, [x10, x1, lsl #3]
    40204020:	f9407dac 	ldr	x12, [x13, #248]
    40204024:	eb0a019f 	cmp	x12, x10
    40204028:	54000721 	b.ne	4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    4020402c:	f94081ac 	ldr	x12, [x13, #256]
    40204030:	f10d159f 	cmp	x12, #0x345
    40204034:	540006c1 	b.ne	4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    40204038:	f9404dac 	ldr	x12, [x13, #152]
    4020403c:	b500068c 	cbnz	x12, 4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    40204040:	d503201f 	nop
    40204044:	1000eaac 	adr	x12, 40205d98 <anon.c8296473e0d3a4c3a5dc9ce93dbbd230.1.llvm.16183259764102968520>
    40204048:	f861798c 	ldr	x12, [x12, x1, lsl #3]
    4020404c:	f9408dad 	ldr	x13, [x13, #280]
    40204050:	eb0c01bf 	cmp	x13, x12
    40204054:	540005c1 	b.ne	4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    40204058:	d503201f 	nop
    4020405c:	1001b46d 	adr	x13, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40204060:	8b010dad 	add	x13, x13, x1, lsl #3
    40204064:	c8dffdad 	ldar	x13, [x13]
    40204068:	b10005bf 	cmn	x13, #0x1
    4020406c:	54000501 	b.ne	4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    40204070:	d503201f 	nop
    40204074:	100febed 	adr	x13, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40204078:	8b010dad 	add	x13, x13, x1, lsl #3
    4020407c:	c8dffdad 	ldar	x13, [x13]
    40204080:	b500046d 	cbnz	x13, 4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    40204084:	d503201f 	nop
    40204088:	1001b38d 	adr	x13, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    4020408c:	8b010dad 	add	x13, x13, x1, lsl #3
    40204090:	c8dffdad 	ldar	x13, [x13]
    40204094:	b10005bf 	cmn	x13, #0x1
    40204098:	540003a1 	b.ne	4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    4020409c:	d503201f 	nop
    402040a0:	100feb0d 	adr	x13, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    402040a4:	8b010dad 	add	x13, x13, x1, lsl #3
    402040a8:	c8dffdad 	ldar	x13, [x13]
    402040ac:	b500030d 	cbnz	x13, 4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    402040b0:	d503201f 	nop
    402040b4:	100feaed 	adr	x13, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    402040b8:	8b010dad 	add	x13, x13, x1, lsl #3
    402040bc:	c8dffdad 	ldar	x13, [x13]
    402040c0:	b500026d 	cbnz	x13, 4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    402040c4:	f940e16d 	ldr	x13, [x11, #448]
    402040c8:	b500022d 	cbnz	x13, 4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    402040cc:	f940e96d 	ldr	x13, [x11, #464]
    402040d0:	eb0c01bf 	cmp	x13, x12
    402040d4:	540001c1 	b.ne	4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    402040d8:	f940c96d 	ldr	x13, [x11, #400]
    402040dc:	b10005bf 	cmn	x13, #0x1
    402040e0:	54000161 	b.ne	4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    402040e4:	f940d16b 	ldr	x11, [x11, #416]
    402040e8:	b500012b 	cbnz	x11, 4020410c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    402040ec:	a9002909 	stp	x9, x10, [x8]
    402040f0:	528068a9 	mov	w9, #0x345                 	// #837
    402040f4:	a9017d09 	stp	x9, xzr, [x8, #16]
    402040f8:	a9027d0c 	stp	x12, xzr, [x8, #32]
    402040fc:	f900190c 	str	x12, [x8, #48]
    40204100:	f9400bfe 	ldr	x30, [sp, #16]
    40204104:	910083ff 	add	sp, sp, #0x20
    40204108:	d65f03c0 	ret
    4020410c:	97fff467 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40204110:	d503201f 	nop
    40204114:	1000f4a2 	adr	x2, 40205fa8 <anon.e5cf9e378689f0b52d762c1b402a78cc.8.llvm.13402452413823366170+0x18>
    40204118:	aa0103e0 	mov	x0, x1
    4020411c:	52800041 	mov	w1, #0x2                   	// #2
    40204120:	940002c5 	bl	40204c34 <core::panicking::panic_bounds_check>

0000000040204124 <jnox_kernel::uart_write>:
    40204124:	b40001a1 	cbz	x1, 40204158 <jnox_kernel::uart_write+0x34>
    40204128:	8b010008 	add	x8, x0, x1
    4020412c:	52800309 	mov	w9, #0x18                  	// #24
    40204130:	72a12009 	movk	w9, #0x900, lsl #16
    40204134:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    40204138:	3840140b 	ldrb	w11, [x0], #1
    4020413c:	b940012c 	ldr	w12, [x9]
    40204140:	3628006c 	tbz	w12, #5, 4020414c <jnox_kernel::uart_write+0x28>
    40204144:	d5033fdf 	isb
    40204148:	17fffffd 	b	4020413c <jnox_kernel::uart_write+0x18>
    4020414c:	b900014b 	str	w11, [x10]
    40204150:	eb08001f 	cmp	x0, x8
    40204154:	54ffff21 	b.ne	40204138 <jnox_kernel::uart_write+0x14>  // b.any
    40204158:	d65f03c0 	ret

000000004020415c <jnox_kernel::kernel_main>:
    4020415c:	f00000e8 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.16183259764102968520+0xb8e0>
    40204160:	f9471108 	ldr	x8, [x8, #3616]
    40204164:	b4000068 	cbz	x8, 40204170 <jnox_kernel::kernel_main+0x14>
    40204168:	d503205f 	wfe
    4020416c:	17ffffff 	b	40204168 <jnox_kernel::kernel_main+0xc>
    40204170:	f81f0ffe 	str	x30, [sp, #-16]!
    40204174:	52800608 	mov	w8, #0x30                  	// #48
    40204178:	72a12008 	movk	w8, #0x900, lsl #16
    4020417c:	b900011f 	str	wzr, [x8]
    40204180:	528001a9 	mov	w9, #0xd                   	// #13
    40204184:	5280002a 	mov	w10, #0x1                   	// #1
    40204188:	b81f4109 	stur	w9, [x8, #-12]
    4020418c:	b81f810a 	stur	w10, [x8, #-8]
    40204190:	52800c09 	mov	w9, #0x60                  	// #96
    40204194:	b81fc109 	stur	w9, [x8, #-4]
    40204198:	52802029 	mov	w9, #0x101                 	// #257
    4020419c:	b9000109 	str	w9, [x8]
    402041a0:	d503201f 	nop
    402041a4:	1000eb60 	adr	x0, 40205f10 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x48>
    402041a8:	52800361 	mov	w1, #0x1b                  	// #27
    402041ac:	97ffffde 	bl	40204124 <jnox_kernel::uart_write>
    402041b0:	97fff70d 	bl	40201de4 <jnox_kernel::ordinary_reservations::run>

00000000402041b4 <jnox_kernel::service_policy::PeriodicReservation::allocation_at>:
    402041b4:	f9400809 	ldr	x9, [x0, #16]
    402041b8:	eb09002a 	subs	x10, x1, x9
    402041bc:	54000062 	b.cs	402041c8 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x14>  // b.hs, b.nlast
    402041c0:	aa1f03ea 	mov	x10, xzr
    402041c4:	1400000f 	b	40204200 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x4c>
    402041c8:	f940040b 	ldr	x11, [x0, #8]
    402041cc:	b400022b 	cbz	x11, 40204210 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x5c>
    402041d0:	9acb0949 	udiv	x9, x10, x11
    402041d4:	cb0a03ec 	neg	x12, x10
    402041d8:	9b0b3129 	madd	x9, x9, x11, x12
    402041dc:	8b090029 	add	x9, x1, x9
    402041e0:	ab0b0129 	adds	x9, x9, x11
    402041e4:	54000063 	b.cc	402041f0 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x3c>  // b.lo, b.ul, b.last
    402041e8:	aa1f03eb 	mov	x11, xzr
    402041ec:	14000007 	b	40204208 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x54>
    402041f0:	eb0b015f 	cmp	x10, x11
    402041f4:	5280030a 	mov	w10, #0x18                  	// #24
    402041f8:	9a9f314a 	csel	x10, x10, xzr, cc  // cc = lo, ul, last
    402041fc:	f86a680a 	ldr	x10, [x0, x10]
    40204200:	5280002b 	mov	w11, #0x1                   	// #1
    40204204:	a900a50a 	stp	x10, x9, [x8, #8]
    40204208:	f900010b 	str	x11, [x8]
    4020420c:	d65f03c0 	ret
    40204210:	f81f0ffe 	str	x30, [sp, #-16]!
    40204214:	d503201f 	nop
    40204218:	1000e8c0 	adr	x0, 40205f30 <anon.e5cf9e378689f0b52d762c1b402a78cc.2.llvm.13402452413823366170>
    4020421c:	9400048c 	bl	4020544c <core::panicking::panic_const::panic_const_rem_by_zero>

0000000040204220 <jnox_kernel::service_policy::PeriodicReservation::grant_at>:
    40204220:	f9401008 	ldr	x8, [x0, #32]
    40204224:	eb08003f 	cmp	x1, x8
    40204228:	54000062 	b.cs	40204234 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x14>  // b.hs, b.nlast
    4020422c:	aa1f03e0 	mov	x0, xzr
    40204230:	1400001c 	b	402042a0 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x80>
    40204234:	f9400408 	ldr	x8, [x0, #8]
    40204238:	b4000388 	cbz	x8, 402042a8 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x88>
    4020423c:	f9400809 	ldr	x9, [x0, #16]
    40204240:	cb09002a 	sub	x10, x1, x9
    40204244:	9ac80949 	udiv	x9, x10, x8
    40204248:	9b08a929 	msub	x9, x9, x8, x10
    4020424c:	eb08015f 	cmp	x10, x8
    40204250:	54000062 	b.cs	4020425c <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x3c>  // b.hs, b.nlast
    40204254:	9100600a 	add	x10, x0, #0x18
    40204258:	14000004 	b	40204268 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x48>
    4020425c:	cb09002a 	sub	x10, x1, x9
    40204260:	f900080a 	str	x10, [x0, #16]
    40204264:	aa0003ea 	mov	x10, x0
    40204268:	f940014a 	ldr	x10, [x10]
    4020426c:	eb02015f 	cmp	x10, x2
    40204270:	9a82314b 	csel	x11, x10, x2, cc  // cc = lo, ul, last
    40204274:	cb090108 	sub	x8, x8, x9
    40204278:	eb0b011f 	cmp	x8, x11
    4020427c:	9a8b3109 	csel	x9, x8, x11, cc  // cc = lo, ul, last
    40204280:	aa2103e8 	mvn	x8, x1
    40204284:	eb09011f 	cmp	x8, x9
    40204288:	da812128 	csinv	x8, x9, x1, cs  // cs = hs, nlast
    4020428c:	cb08014a 	sub	x10, x10, x8
    40204290:	ab010129 	adds	x9, x9, x1
    40204294:	da9f3129 	csinv	x9, x9, xzr, cc  // cc = lo, ul, last
    40204298:	a901a40a 	stp	x10, x9, [x0, #24]
    4020429c:	52800020 	mov	w0, #0x1                   	// #1
    402042a0:	aa0803e1 	mov	x1, x8
    402042a4:	d65f03c0 	ret
    402042a8:	f81f0ffe 	str	x30, [sp, #-16]!
    402042ac:	d503201f 	nop
    402042b0:	1000e4c0 	adr	x0, 40205f48 <anon.e5cf9e378689f0b52d762c1b402a78cc.3.llvm.13402452413823366170>
    402042b4:	94000466 	bl	4020544c <core::panicking::panic_const::panic_const_rem_by_zero>

00000000402042b8 <jnox_kernel::temporal_policy::HardCbs<_>::new>:
    402042b8:	d10143ff 	sub	sp, sp, #0x50
    402042bc:	a90357fe 	stp	x30, x21, [sp, #48]
    402042c0:	a9044ff4 	stp	x20, x19, [sp, #64]
    402042c4:	aa0103f5 	mov	x21, x1
    402042c8:	aa0003f4 	mov	x20, x0
    402042cc:	aa0803f3 	mov	x19, x8
    402042d0:	aa0103e0 	mov	x0, x1
    402042d4:	52800041 	mov	w1, #0x2                   	// #2
    402042d8:	940000c6 	bl	402045f0 <jnox_kernel::temporal_policy::admit_reservations>
    402042dc:	12001c08 	and	w8, w0, #0xff
    402042e0:	71000d1f 	cmp	w8, #0x3
    402042e4:	54000261 	b.ne	40204330 <jnox_kernel::temporal_policy::HardCbs<_>::new+0x78>  // b.any
    402042e8:	910003e9 	mov	x9, sp
    402042ec:	91006128 	add	x8, x9, #0x18
    402042f0:	5280002a 	mov	w10, #0x1                   	// #1
    402042f4:	f9000134 	str	x20, [x9]
    402042f8:	28c132ab 	ldp	w11, w12, [x21], #8
    402042fc:	2a0a03ed 	mov	w13, w10
    40204300:	2901312b 	stp	w11, w12, [x9, #8]
    40204304:	f900093f 	str	xzr, [x9, #16]
    40204308:	aa0803e9 	mov	x9, x8
    4020430c:	2a1f03ea 	mov	w10, wzr
    40204310:	3707ff2d 	tbnz	w13, #0, 402042f4 <jnox_kernel::temporal_policy::HardCbs<_>::new+0x3c>
    40204314:	91002260 	add	x0, x19, #0x8
    40204318:	910003e1 	mov	x1, sp
    4020431c:	52800602 	mov	w2, #0x30                  	// #48
    40204320:	94000595 	bl	40205974 <memcpy>
    40204324:	f9001e74 	str	x20, [x19, #56]
    40204328:	52800028 	mov	w8, #0x1                   	// #1
    4020432c:	14000002 	b	40204334 <jnox_kernel::temporal_policy::HardCbs<_>::new+0x7c>
    40204330:	aa1f03e8 	mov	x8, xzr
    40204334:	f9000268 	str	x8, [x19]
    40204338:	a9444ff4 	ldp	x20, x19, [sp, #64]
    4020433c:	a94357fe 	ldp	x30, x21, [sp, #48]
    40204340:	910143ff 	add	sp, sp, #0x50
    40204344:	d65f03c0 	ret

0000000040204348 <jnox_kernel::temporal_policy::HardCbs<_>::tick>:
    40204348:	d10203ff 	sub	sp, sp, #0x80
    4020434c:	a9027bfd 	stp	x29, x30, [sp, #32]
    40204350:	a9036ffc 	stp	x28, x27, [sp, #48]
    40204354:	a90467fa 	stp	x26, x25, [sp, #64]
    40204358:	a9055ff8 	stp	x24, x23, [sp, #80]
    4020435c:	a90657f6 	stp	x22, x21, [sp, #96]
    40204360:	a9074ff4 	stp	x20, x19, [sp, #112]
    40204364:	aa0803f3 	mov	x19, x8
    40204368:	f940181b 	ldr	x27, [x0, #48]
    4020436c:	b100077a 	adds	x26, x27, #0x1
    40204370:	540000a3 	b.cc	40204384 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x3c>  // b.lo, b.ul, b.last
    40204374:	aa1f03f4 	mov	x20, xzr
    40204378:	52800037 	mov	w23, #0x1                   	// #1
    4020437c:	52800089 	mov	w9, #0x4                   	// #4
    40204380:	1400003e 	b	40204478 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    40204384:	aa0003f5 	mov	x21, x0
    40204388:	2a1f03fc 	mov	w28, wzr
    4020438c:	aa1f03e8 	mov	x8, xzr
    40204390:	aa1f03fd 	mov	x29, xzr
    40204394:	91005018 	add	x24, x0, #0x14
    40204398:	52800037 	mov	w23, #0x1                   	// #1
    4020439c:	910063bd 	add	x29, x29, #0x18
    402043a0:	aa0803f6 	mov	x22, x8
    402043a4:	8b1d0308 	add	x8, x24, x29
    402043a8:	b85e8108 	ldur	w8, [x8, #-24]
    402043ac:	340000e8 	cbz	w8, 402043c8 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x80>
    402043b0:	910023e8 	add	x8, sp, #0x8
    402043b4:	aa1503e0 	mov	x0, x21
    402043b8:	aa1603e1 	mov	x1, x22
    402043bc:	94000067 	bl	40204558 <jnox_kernel::temporal_policy::HardCbs<_>::available>
    402043c0:	f94007e8 	ldr	x8, [sp, #8]
    402043c4:	b50000c8 	cbnz	x8, 402043dc <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x94>
    402043c8:	910063bd 	add	x29, x29, #0x18
    402043cc:	910006d6 	add	x22, x22, #0x1
    402043d0:	f10123bf 	cmp	x29, #0x48
    402043d4:	54fffe81 	b.ne	402043a4 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x5c>  // b.any
    402043d8:	14000014 	b	40204428 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0xe0>
    402043dc:	f100091f 	cmp	x8, #0x2
    402043e0:	a9412be9 	ldp	x9, x10, [sp, #16]
    402043e4:	54000400 	b.eq	40204464 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x11c>  // b.none
    402043e8:	eb1b015f 	cmp	x10, x27
    402043ec:	540005a9 	b.ls	402044a0 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x158>  // b.plast
    402043f0:	910006c8 	add	x8, x22, #0x1
    402043f4:	eb19015f 	cmp	x10, x25
    402043f8:	1a9f37eb 	cset	w11, cs  // cs = hs, nlast
    402043fc:	6a0b039f 	tst	w28, w11
    40204400:	9a961294 	csel	x20, x20, x22, ne  // ne = any
    40204404:	9a8a1339 	csel	x25, x25, x10, ne  // ne = any
    40204408:	b94007ea 	ldr	w10, [sp, #4]
    4020440c:	1a89114a 	csel	w10, w10, w9, ne  // ne = any
    40204410:	b90007ea 	str	w10, [sp, #4]
    40204414:	5280003c 	mov	w28, #0x1                   	// #1
    40204418:	f100c3bf 	cmp	x29, #0x30
    4020441c:	54fffc01 	b.ne	4020439c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x54>  // b.any
    40204420:	f9001aba 	str	x26, [x21, #48]
    40204424:	14000003 	b	40204430 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0xe8>
    40204428:	f9001aba 	str	x26, [x21, #48]
    4020442c:	3600023c 	tbz	w28, #0, 40204470 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x128>
    40204430:	f1000a9f 	cmp	x20, #0x2
    40204434:	540003c2 	b.cs	402044ac <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x164>  // b.hs, b.nlast
    40204438:	aa1f03f7 	mov	x23, xzr
    4020443c:	52800308 	mov	w8, #0x18                  	// #24
    40204440:	9b085688 	madd	x8, x20, x8, x21
    40204444:	f9000119 	str	x25, [x8]
    40204448:	b94007e9 	ldr	w9, [sp, #4]
    4020444c:	51000529 	sub	w9, w9, #0x1
    40204450:	b940150a 	ldr	w10, [x8, #20]
    40204454:	5100054a 	sub	w10, w10, #0x1
    40204458:	29022909 	stp	w9, w10, [x8, #16]
    4020445c:	52800029 	mov	w9, #0x1                   	// #1
    40204460:	14000006 	b	40204478 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    40204464:	52800037 	mov	w23, #0x1                   	// #1
    40204468:	aa0a03f4 	mov	x20, x10
    4020446c:	14000003 	b	40204478 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    40204470:	aa1f03e9 	mov	x9, xzr
    40204474:	aa1f03f7 	mov	x23, xzr
    40204478:	a900d269 	stp	x9, x20, [x19, #8]
    4020447c:	f9000277 	str	x23, [x19]
    40204480:	a9474ff4 	ldp	x20, x19, [sp, #112]
    40204484:	a94657f6 	ldp	x22, x21, [sp, #96]
    40204488:	a9455ff8 	ldp	x24, x23, [sp, #80]
    4020448c:	a94467fa 	ldp	x26, x25, [sp, #64]
    40204490:	a9436ffc 	ldp	x28, x27, [sp, #48]
    40204494:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40204498:	910203ff 	add	sp, sp, #0x80
    4020449c:	d65f03c0 	ret
    402044a0:	52800069 	mov	w9, #0x3                   	// #3
    402044a4:	aa1603f4 	mov	x20, x22
    402044a8:	17fffff4 	b	40204478 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    402044ac:	d503201f 	nop
    402044b0:	1000d582 	adr	x2, 40205f60 <anon.e5cf9e378689f0b52d762c1b402a78cc.5.llvm.13402452413823366170>
    402044b4:	aa1403e0 	mov	x0, x20
    402044b8:	52800041 	mov	w1, #0x2                   	// #2
    402044bc:	940001de 	bl	40204c34 <core::panicking::panic_bounds_check>

00000000402044c0 <jnox_kernel::temporal_policy::HardCbs<_>::release>:
    402044c0:	f100043f 	cmp	x1, #0x1
    402044c4:	54000089 	b.ls	402044d4 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x14>  // b.plast
    402044c8:	aa1f03e1 	mov	x1, xzr
    402044cc:	aa1f03e0 	mov	x0, xzr
    402044d0:	d65f03c0 	ret
    402044d4:	340000e2 	cbz	w2, 402044f0 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x30>
    402044d8:	52800308 	mov	w8, #0x18                  	// #24
    402044dc:	9b080028 	madd	x8, x1, x8, x0
    402044e0:	b9401509 	ldr	w9, [x8, #20]
    402044e4:	340000a9 	cbz	w9, 402044f8 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x38>
    402044e8:	52800040 	mov	w0, #0x2                   	// #2
    402044ec:	d65f03c0 	ret
    402044f0:	52800020 	mov	w0, #0x1                   	// #1
    402044f4:	d65f03c0 	ret
    402044f8:	f940010a 	ldr	x10, [x8]
    402044fc:	f9401809 	ldr	x9, [x0, #48]
    40204500:	eb09014b 	subs	x11, x10, x9
    40204504:	54000149 	b.ls	4020452c <jnox_kernel::temporal_policy::HardCbs<_>::release+0x6c>  // b.plast
    40204508:	2941b10a 	ldp	w10, w12, [x8, #12]
    4020450c:	b940090d 	ldr	w13, [x8, #8]
    40204510:	9bac7d4c 	umull	x12, w10, w12
    40204514:	9bcb7dae 	umulh	x14, x13, x11
    40204518:	9b0b7dab 	mul	x11, x13, x11
    4020451c:	eb0c017f 	cmp	x11, x12
    40204520:	fa1f01df 	sbcs	xzr, x14, xzr
    40204524:	54000063 	b.cc	40204530 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x70>  // b.lo, b.ul, b.last
    40204528:	14000009 	b	4020454c <jnox_kernel::temporal_policy::HardCbs<_>::release+0x8c>
    4020452c:	b9400d0a 	ldr	w10, [x8, #12]
    40204530:	ab2a4121 	adds	x1, x9, w10, uxtw
    40204534:	54000063 	b.cc	40204540 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x80>  // b.lo, b.ul, b.last
    40204538:	52800080 	mov	w0, #0x4                   	// #4
    4020453c:	d65f03c0 	ret
    40204540:	f9000101 	str	x1, [x8]
    40204544:	b9400909 	ldr	w9, [x8, #8]
    40204548:	b9001109 	str	w9, [x8, #16]
    4020454c:	b9001502 	str	w2, [x8, #20]
    40204550:	528000a0 	mov	w0, #0x5                   	// #5
    40204554:	d65f03c0 	ret

0000000040204558 <jnox_kernel::temporal_policy::HardCbs<_>::available>:
    40204558:	f100083f 	cmp	x1, #0x2
    4020455c:	540000a3 	b.cc	40204570 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x18>  // b.lo, b.ul, b.last
    40204560:	a900fd1f 	stp	xzr, xzr, [x8, #8]
    40204564:	52800049 	mov	w9, #0x2                   	// #2
    40204568:	f9000109 	str	x9, [x8]
    4020456c:	d65f03c0 	ret
    40204570:	52800309 	mov	w9, #0x18                  	// #24
    40204574:	9b090029 	madd	x9, x1, x9, x0
    40204578:	b940152a 	ldr	w10, [x9, #20]
    4020457c:	340001aa 	cbz	w10, 402045b0 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x58>
    40204580:	b940112a 	ldr	w10, [x9, #16]
    40204584:	340000ea 	cbz	w10, 402045a0 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x48>
    40204588:	5280002b 	mov	w11, #0x1                   	// #1
    4020458c:	f900010b 	str	x11, [x8]
    40204590:	f9400129 	ldr	x9, [x9]
    40204594:	b900090a 	str	w10, [x8, #8]
    40204598:	f9000909 	str	x9, [x8, #16]
    4020459c:	d65f03c0 	ret
    402045a0:	f940180b 	ldr	x11, [x0, #48]
    402045a4:	f940012a 	ldr	x10, [x9]
    402045a8:	eb0a017f 	cmp	x11, x10
    402045ac:	54000062 	b.cs	402045b8 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x60>  // b.hs, b.nlast
    402045b0:	f900011f 	str	xzr, [x8]
    402045b4:	d65f03c0 	ret
    402045b8:	b9400d2b 	ldr	w11, [x9, #12]
    402045bc:	ab0b014a 	adds	x10, x10, x11
    402045c0:	540000c3 	b.cc	402045d8 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x80>  // b.lo, b.ul, b.last
    402045c4:	52800089 	mov	w9, #0x4                   	// #4
    402045c8:	a900a909 	stp	x9, x10, [x8, #8]
    402045cc:	5280004a 	mov	w10, #0x2                   	// #2
    402045d0:	f900010a 	str	x10, [x8]
    402045d4:	d65f03c0 	ret
    402045d8:	5280002b 	mov	w11, #0x1                   	// #1
    402045dc:	f900010b 	str	x11, [x8]
    402045e0:	b9400929 	ldr	w9, [x9, #8]
    402045e4:	b9000909 	str	w9, [x8, #8]
    402045e8:	f900090a 	str	x10, [x8, #16]
    402045ec:	d65f03c0 	ret

00000000402045f0 <jnox_kernel::temporal_policy::admit_reservations>:
    402045f0:	f81b0ffe 	str	x30, [sp, #-80]!
    402045f4:	a90167fa 	stp	x26, x25, [sp, #16]
    402045f8:	a9025ff8 	stp	x24, x23, [sp, #32]
    402045fc:	a90357f6 	stp	x22, x21, [sp, #48]
    40204600:	a9044ff4 	stp	x20, x19, [sp, #64]
    40204604:	b4000721 	cbz	x1, 402046e8 <jnox_kernel::temporal_policy::admit_reservations+0xf8>
    40204608:	aa0003f3 	mov	x19, x0
    4020460c:	aa1f03f6 	mov	x22, xzr
    40204610:	8b010c1a 	add	x26, x0, x1, lsl #3
    40204614:	52800020 	mov	w0, #0x1                   	// #1
    40204618:	29402269 	ldp	w9, w8, [x19]
    4020461c:	5100052a 	sub	w10, w9, #0x1
    40204620:	6b08015f 	cmp	w10, w8
    40204624:	540006a2 	b.cs	402046f8 <jnox_kernel::temporal_policy::admit_reservations+0x108>  // b.hs, b.nlast
    40204628:	9bd67d0a 	umulh	x10, x8, x22
    4020462c:	9b167d0b 	mul	x11, x8, x22
    40204630:	9bc07d2c 	umulh	x12, x9, x0
    40204634:	9b007d29 	mul	x9, x9, x0
    40204638:	ab090176 	adds	x22, x11, x9
    4020463c:	9a0c0157 	adc	x23, x10, x12
    40204640:	9bc07d14 	umulh	x20, x8, x0
    40204644:	9b007d15 	mul	x21, x8, x0
    40204648:	eb1602bf 	cmp	x21, x22
    4020464c:	fa17029f 	sbcs	xzr, x20, x23
    40204650:	54000583 	b.cc	40204700 <jnox_kernel::temporal_policy::admit_reservations+0x110>  // b.lo, b.ul, b.last
    40204654:	b4000220 	cbz	x0, 40204698 <jnox_kernel::temporal_policy::admit_reservations+0xa8>
    40204658:	aa1603e0 	mov	x0, x22
    4020465c:	aa1703e1 	mov	x1, x23
    40204660:	aa1503e8 	mov	x8, x21
    40204664:	aa1403e9 	mov	x9, x20
    40204668:	aa0903f8 	mov	x24, x9
    4020466c:	aa0803f9 	mov	x25, x8
    40204670:	aa0803e2 	mov	x2, x8
    40204674:	aa0903e3 	mov	x3, x9
    40204678:	94000542 	bl	40205b80 <__umodti3>
    4020467c:	aa0003e8 	mov	x8, x0
    40204680:	aa0103e9 	mov	x9, x1
    40204684:	aa01000a 	orr	x10, x0, x1
    40204688:	aa1903e0 	mov	x0, x25
    4020468c:	aa1803e1 	mov	x1, x24
    40204690:	b5fffeca 	cbnz	x10, 40204668 <jnox_kernel::temporal_policy::admit_reservations+0x78>
    40204694:	14000005 	b	402046a8 <jnox_kernel::temporal_policy::admit_reservations+0xb8>
    40204698:	aa1702c8 	orr	x8, x22, x23
    4020469c:	aa1603f9 	mov	x25, x22
    402046a0:	aa1703f8 	mov	x24, x23
    402046a4:	b40003c8 	cbz	x8, 4020471c <jnox_kernel::temporal_policy::admit_reservations+0x12c>
    402046a8:	aa1603e0 	mov	x0, x22
    402046ac:	aa1703e1 	mov	x1, x23
    402046b0:	aa1903e2 	mov	x2, x25
    402046b4:	aa1803e3 	mov	x3, x24
    402046b8:	940003e3 	bl	40205644 <__udivti3>
    402046bc:	b50001a1 	cbnz	x1, 402046f0 <jnox_kernel::temporal_policy::admit_reservations+0x100>
    402046c0:	aa0003f6 	mov	x22, x0
    402046c4:	aa1503e0 	mov	x0, x21
    402046c8:	aa1403e1 	mov	x1, x20
    402046cc:	aa1903e2 	mov	x2, x25
    402046d0:	aa1803e3 	mov	x3, x24
    402046d4:	940003dc 	bl	40205644 <__udivti3>
    402046d8:	b50000c1 	cbnz	x1, 402046f0 <jnox_kernel::temporal_policy::admit_reservations+0x100>
    402046dc:	91002273 	add	x19, x19, #0x8
    402046e0:	eb1a027f 	cmp	x19, x26
    402046e4:	54fff9a1 	b.ne	40204618 <jnox_kernel::temporal_policy::admit_reservations+0x28>  // b.any
    402046e8:	52800060 	mov	w0, #0x3                   	// #3
    402046ec:	14000006 	b	40204704 <jnox_kernel::temporal_policy::admit_reservations+0x114>
    402046f0:	52800040 	mov	w0, #0x2                   	// #2
    402046f4:	14000004 	b	40204704 <jnox_kernel::temporal_policy::admit_reservations+0x114>
    402046f8:	2a1f03e0 	mov	w0, wzr
    402046fc:	14000002 	b	40204704 <jnox_kernel::temporal_policy::admit_reservations+0x114>
    40204700:	52800020 	mov	w0, #0x1                   	// #1
    40204704:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40204708:	a94357f6 	ldp	x22, x21, [sp, #48]
    4020470c:	a9425ff8 	ldp	x24, x23, [sp, #32]
    40204710:	a94167fa 	ldp	x26, x25, [sp, #16]
    40204714:	f84507fe 	ldr	x30, [sp], #80
    40204718:	d65f03c0 	ret
    4020471c:	d503201f 	nop
    40204720:	1000c2c0 	adr	x0, 40205f78 <anon.e5cf9e378689f0b52d762c1b402a78cc.6.llvm.13402452413823366170>
    40204724:	94000343 	bl	40205430 <core::panicking::panic_const::panic_const_div_by_zero>

0000000040204728 <jnox_kernel::context::init_timer_irq>:
    40204728:	d503201f 	nop
    4020472c:	10fe06a8 	adr	x8, 40200800 <sched_vectors>
    40204730:	d518c008 	msr	vbar_el1, x8
    40204734:	d51be23f 	msr	cntp_ctl_el0, xzr
    40204738:	d5033fdf 	isb
    4020473c:	52a10008 	mov	w8, #0x8000000             	// #134217728
    40204740:	b900011f 	str	wzr, [x8]
    40204744:	52a10029 	mov	w9, #0x8010000             	// #134283264
    40204748:	b900013f 	str	wzr, [x9]
    4020474c:	5280100a 	mov	w10, #0x80                  	// #128
    40204750:	72a1000a 	movk	w10, #0x800, lsl #16
    40204754:	b940014b 	ldr	w11, [x10]
    40204758:	1201796b 	and	w11, w11, #0xbfffffff
    4020475c:	b900014b 	str	w11, [x10]
    40204760:	5280100b 	mov	w11, #0x80                  	// #128
    40204764:	390e794b 	strb	w11, [x10, #926]
    40204768:	52a8000b 	mov	w11, #0x40000000            	// #1073741824
    4020476c:	b902014b 	str	w11, [x10, #512]
    40204770:	b900814b 	str	w11, [x10, #128]
    40204774:	5280008a 	mov	w10, #0x4                   	// #4
    40204778:	72a1002a 	movk	w10, #0x801, lsl #16
    4020477c:	52801feb 	mov	w11, #0xff                  	// #255
    40204780:	b900014b 	str	w11, [x10]
    40204784:	5280002a 	mov	w10, #0x1                   	// #1
    40204788:	b900010a 	str	w10, [x8]
    4020478c:	b900012a 	str	w10, [x9]
    40204790:	d5033f9f 	dsb	sy
    40204794:	d5033fdf 	isb
    40204798:	d65f03c0 	ret

000000004020479c <<core::fmt::Formatter>::pad_integral>:
    4020479c:	d101c3ff 	sub	sp, sp, #0x70
    402047a0:	a9017bfd 	stp	x29, x30, [sp, #16]
    402047a4:	a9026ffc 	stp	x28, x27, [sp, #32]
    402047a8:	a90367fa 	stp	x26, x25, [sp, #48]
    402047ac:	a9045ff8 	stp	x24, x23, [sp, #64]
    402047b0:	a90557f6 	stp	x22, x21, [sp, #80]
    402047b4:	a9064ff4 	stp	x20, x19, [sp, #96]
    402047b8:	910043fd 	add	x29, sp, #0x10
    402047bc:	b940101a 	ldr	w26, [x0, #16]
    402047c0:	52a00229 	mov	w9, #0x110000              	// #1114112
    402047c4:	aa0503f3 	mov	x19, x5
    402047c8:	aa0403fc 	mov	x28, x4
    402047cc:	aa0303f6 	mov	x22, x3
    402047d0:	aa0003f5 	mov	x21, x0
    402047d4:	926b0348 	and	x8, x26, #0x200000
    402047d8:	d355574a 	ubfx	x10, x26, #21, #1
    402047dc:	7100011f 	cmp	w8, #0x0
    402047e0:	52800568 	mov	w8, #0x2b                  	// #43
    402047e4:	1a880128 	csel	w8, w9, w8, eq  // eq = none
    402047e8:	7100003f 	cmp	w1, #0x0
    402047ec:	528005a9 	mov	w9, #0x2d                  	// #45
    402047f0:	9a9f154a 	csinc	x10, x10, xzr, ne  // ne = any
    402047f4:	1a891118 	csel	w24, w8, w9, ne  // ne = any
    402047f8:	8b05015b 	add	x27, x10, x5
    402047fc:	37b8033a 	tbnz	w26, #23, 40204860 <<core::fmt::Formatter>::pad_integral+0xc4>
    40204800:	aa1f03f7 	mov	x23, xzr
    40204804:	79402ab4 	ldrh	w20, [x21, #20]
    40204808:	eb14037f 	cmp	x27, x20
    4020480c:	54001503 	b.cc	40204aac <<core::fmt::Formatter>::pad_integral+0x310>  // b.lo, b.ul, b.last
    40204810:	a94056b9 	ldp	x25, x21, [x21]
    40204814:	2a1803e2 	mov	w2, w24
    40204818:	aa1703e3 	mov	x3, x23
    4020481c:	aa1603e4 	mov	x4, x22
    40204820:	aa1903e0 	mov	x0, x25
    40204824:	aa1503e1 	mov	x1, x21
    40204828:	94000310 	bl	40205468 <<core::fmt::Formatter>::pad_integral::write_prefix>
    4020482c:	37001d60 	tbnz	w0, #0, 40204bd8 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204830:	f9400ea3 	ldr	x3, [x21, #24]
    40204834:	aa1903e0 	mov	x0, x25
    40204838:	aa1c03e1 	mov	x1, x28
    4020483c:	aa1303e2 	mov	x2, x19
    40204840:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40204844:	a94557f6 	ldp	x22, x21, [sp, #80]
    40204848:	a9445ff8 	ldp	x24, x23, [sp, #64]
    4020484c:	a94367fa 	ldp	x26, x25, [sp, #48]
    40204850:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40204854:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40204858:	9101c3ff 	add	sp, sp, #0x70
    4020485c:	d61f0060 	br	x3
    40204860:	aa0203f7 	mov	x23, x2
    40204864:	f10082df 	cmp	x22, #0x20
    40204868:	540000e2 	b.cs	40204884 <<core::fmt::Formatter>::pad_integral+0xe8>  // b.hs, b.nlast
    4020486c:	b4000156 	cbz	x22, 40204894 <<core::fmt::Formatter>::pad_integral+0xf8>
    40204870:	f10022df 	cmp	x22, #0x8
    40204874:	54000142 	b.cs	4020489c <<core::fmt::Formatter>::pad_integral+0x100>  // b.hs, b.nlast
    40204878:	aa1f03e8 	mov	x8, xzr
    4020487c:	aa1f03e0 	mov	x0, xzr
    40204880:	14000080 	b	40204a80 <<core::fmt::Formatter>::pad_integral+0x2e4>
    40204884:	aa1703e0 	mov	x0, x23
    40204888:	aa1603e1 	mov	x1, x22
    4020488c:	94000102 	bl	40204c94 <core::str::count::do_count_chars>
    40204890:	14000083 	b	40204a9c <<core::fmt::Formatter>::pad_integral+0x300>
    40204894:	aa1f03e0 	mov	x0, xzr
    40204898:	14000081 	b	40204a9c <<core::fmt::Formatter>::pad_integral+0x300>
    4020489c:	aa1703ea 	mov	x10, x23
    402048a0:	39400ae9 	ldrb	w9, [x23, #2]
    402048a4:	394006e8 	ldrb	w8, [x23, #1]
    402048a8:	38404d4b 	ldrb	w11, [x10, #4]!
    402048ac:	3940094c 	ldrb	w12, [x10, #2]
    402048b0:	394002ed 	ldrb	w13, [x23]
    402048b4:	39400eee 	ldrb	w14, [x23, #3]
    402048b8:	d370bd29 	lsl	x9, x9, #16
    402048bc:	394016ef 	ldrb	w15, [x23, #5]
    402048c0:	39400d4a 	ldrb	w10, [x10, #3]
    402048c4:	53103d8c 	lsl	w12, w12, #16
    402048c8:	aa0821a8 	orr	x8, x13, x8, lsl #8
    402048cc:	aa0e6129 	orr	x9, x9, x14, lsl #24
    402048d0:	0f05e7e4 	movi	v4.8b, #0xbf
    402048d4:	2a0f216b 	orr	w11, w11, w15, lsl #8
    402048d8:	2a0a618a 	orr	w10, w12, w10, lsl #24
    402048dc:	aa080128 	orr	x8, x9, x8
    402048e0:	2a0b0149 	orr	w9, w10, w11
    402048e4:	aa098108 	orr	x8, x8, x9, lsl #32
    402048e8:	9e670100 	fmov	d0, x8
    402048ec:	52800028 	mov	w8, #0x1                   	// #1
    402048f0:	4e080d03 	dup	v3.2d, x8
    402048f4:	927d06c8 	and	x8, x22, #0x18
    402048f8:	f100211f 	cmp	x8, #0x8
    402048fc:	0e243400 	cmgt	v0.8b, v0.8b, v4.8b
    40204900:	2f08a400 	uxtl	v0.8h, v0.8b
    40204904:	6f10a401 	uxtl2	v1.4s, v0.8h
    40204908:	2f10a400 	uxtl	v0.4s, v0.4h
    4020490c:	6f20a422 	uxtl2	v2.2d, v1.4s
    40204910:	2f20a421 	uxtl	v1.2d, v1.2s
    40204914:	6f20a405 	uxtl2	v5.2d, v0.4s
    40204918:	2f20a406 	uxtl	v6.2d, v0.2s
    4020491c:	4e231c40 	and	v0.16b, v2.16b, v3.16b
    40204920:	4e231c22 	and	v2.16b, v1.16b, v3.16b
    40204924:	4e231ca1 	and	v1.16b, v5.16b, v3.16b
    40204928:	4e231cc3 	and	v3.16b, v6.16b, v3.16b
    4020492c:	540009c0 	b.eq	40204a64 <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    40204930:	aa1703e9 	mov	x9, x23
    40204934:	f100411f 	cmp	x8, #0x10
    40204938:	38408d2a 	ldrb	w10, [x9, #8]!
    4020493c:	3940052b 	ldrb	w11, [x9, #1]
    40204940:	39400d2c 	ldrb	w12, [x9, #3]
    40204944:	3940092d 	ldrb	w13, [x9, #2]
    40204948:	3940152e 	ldrb	w14, [x9, #5]
    4020494c:	38404d2f 	ldrb	w15, [x9, #4]!
    40204950:	39400930 	ldrb	w16, [x9, #2]
    40204954:	39400d29 	ldrb	w9, [x9, #3]
    40204958:	d370bdad 	lsl	x13, x13, #16
    4020495c:	aa0b214a 	orr	x10, x10, x11, lsl #8
    40204960:	53103e10 	lsl	w16, w16, #16
    40204964:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40204968:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    4020496c:	2a096209 	orr	w9, w16, w9, lsl #24
    40204970:	aa0a018a 	orr	x10, x12, x10
    40204974:	2a0b0129 	orr	w9, w9, w11
    40204978:	aa098149 	orr	x9, x10, x9, lsl #32
    4020497c:	9e670125 	fmov	d5, x9
    40204980:	52800029 	mov	w9, #0x1                   	// #1
    40204984:	4e080d26 	dup	v6.2d, x9
    40204988:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    4020498c:	2f08a484 	uxtl	v4.8h, v4.8b
    40204990:	6f10a485 	uxtl2	v5.4s, v4.8h
    40204994:	2f10a484 	uxtl	v4.4s, v4.4h
    40204998:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    4020499c:	2f20a490 	uxtl	v16.2d, v4.2s
    402049a0:	6f20a484 	uxtl2	v4.2d, v4.4s
    402049a4:	2f20a4a5 	uxtl	v5.2d, v5.2s
    402049a8:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    402049ac:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    402049b0:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    402049b4:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    402049b8:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    402049bc:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    402049c0:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    402049c4:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    402049c8:	540004e0 	b.eq	40204a64 <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    402049cc:	aa1703e9 	mov	x9, x23
    402049d0:	0f05e7e4 	movi	v4.8b, #0xbf
    402049d4:	38410d2a 	ldrb	w10, [x9, #16]!
    402049d8:	3940052b 	ldrb	w11, [x9, #1]
    402049dc:	39400d2c 	ldrb	w12, [x9, #3]
    402049e0:	3940092d 	ldrb	w13, [x9, #2]
    402049e4:	3940152e 	ldrb	w14, [x9, #5]
    402049e8:	38404d2f 	ldrb	w15, [x9, #4]!
    402049ec:	39400930 	ldrb	w16, [x9, #2]
    402049f0:	39400d29 	ldrb	w9, [x9, #3]
    402049f4:	d370bdad 	lsl	x13, x13, #16
    402049f8:	aa0b214a 	orr	x10, x10, x11, lsl #8
    402049fc:	53103e10 	lsl	w16, w16, #16
    40204a00:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40204a04:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40204a08:	2a096209 	orr	w9, w16, w9, lsl #24
    40204a0c:	aa0a018a 	orr	x10, x12, x10
    40204a10:	2a0b0129 	orr	w9, w9, w11
    40204a14:	aa098149 	orr	x9, x10, x9, lsl #32
    40204a18:	9e670125 	fmov	d5, x9
    40204a1c:	52800029 	mov	w9, #0x1                   	// #1
    40204a20:	4e080d26 	dup	v6.2d, x9
    40204a24:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40204a28:	2f08a484 	uxtl	v4.8h, v4.8b
    40204a2c:	6f10a485 	uxtl2	v5.4s, v4.8h
    40204a30:	2f10a484 	uxtl	v4.4s, v4.4h
    40204a34:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40204a38:	2f20a490 	uxtl	v16.2d, v4.2s
    40204a3c:	6f20a484 	uxtl2	v4.2d, v4.4s
    40204a40:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40204a44:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40204a48:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40204a4c:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40204a50:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40204a54:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40204a58:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40204a5c:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40204a60:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40204a64:	4ee28462 	add	v2.2d, v3.2d, v2.2d
    40204a68:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    40204a6c:	eb0802df 	cmp	x22, x8
    40204a70:	4ee08440 	add	v0.2d, v2.2d, v0.2d
    40204a74:	5ef1b800 	addp	d0, v0.2d
    40204a78:	9e660000 	fmov	x0, d0
    40204a7c:	54000100 	b.eq	40204a9c <<core::fmt::Formatter>::pad_integral+0x300>  // b.none
    40204a80:	cb0802c9 	sub	x9, x22, x8
    40204a84:	8b0802e8 	add	x8, x23, x8
    40204a88:	38c0150a 	ldrsb	w10, [x8], #1
    40204a8c:	3101055f 	cmn	w10, #0x41
    40204a90:	9a80d400 	cinc	x0, x0, gt
    40204a94:	f1000529 	subs	x9, x9, #0x1
    40204a98:	54ffff81 	b.ne	40204a88 <<core::fmt::Formatter>::pad_integral+0x2ec>  // b.any
    40204a9c:	8b1b001b 	add	x27, x0, x27
    40204aa0:	79402ab4 	ldrh	w20, [x21, #20]
    40204aa4:	eb14037f 	cmp	x27, x20
    40204aa8:	54ffeb42 	b.cs	40204810 <<core::fmt::Formatter>::pad_integral+0x74>  // b.hs, b.nlast
    40204aac:	f90007fc 	str	x28, [sp, #8]
    40204ab0:	37c0011a 	tbnz	w26, #24, 40204ad0 <<core::fmt::Formatter>::pad_integral+0x334>
    40204ab4:	531d7b48 	ubfx	w8, w26, #29, #2
    40204ab8:	4b1b029b 	sub	w27, w20, w27
    40204abc:	7100051f 	cmp	w8, #0x1
    40204ac0:	540003cc 	b.gt	40204b38 <<core::fmt::Formatter>::pad_integral+0x39c>
    40204ac4:	35000568 	cbnz	w8, 40204b70 <<core::fmt::Formatter>::pad_integral+0x3d4>
    40204ac8:	2a1f03fc 	mov	w28, wzr
    40204acc:	1400002a 	b	40204b74 <<core::fmt::Formatter>::pad_integral+0x3d8>
    40204ad0:	a940f2ba 	ldp	x26, x28, [x21, #8]
    40204ad4:	52b3fc08 	mov	w8, #0x9fe00000            	// #-1612709888
    40204ad8:	f94002b9 	ldr	x25, [x21]
    40204adc:	2a1803e2 	mov	w2, w24
    40204ae0:	aa1703e3 	mov	x3, x23
    40204ae4:	aa1603e4 	mov	x4, x22
    40204ae8:	0a080388 	and	w8, w28, w8
    40204aec:	aa1903e0 	mov	x0, x25
    40204af0:	aa1a03e1 	mov	x1, x26
    40204af4:	321c0508 	orr	w8, w8, #0x30
    40204af8:	32030108 	orr	w8, w8, #0x20000000
    40204afc:	b90012a8 	str	w8, [x21, #16]
    40204b00:	9400025a 	bl	40205468 <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204b04:	370006a0 	tbnz	w0, #0, 40204bd8 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204b08:	2a1f03f6 	mov	w22, wzr
    40204b0c:	4b1b0294 	sub	w20, w20, w27
    40204b10:	12003ec8 	and	w8, w22, #0xffff
    40204b14:	6b34211f 	cmp	w8, w20, uxth
    40204b18:	540001a2 	b.cs	40204b4c <<core::fmt::Formatter>::pad_integral+0x3b0>  // b.hs, b.nlast
    40204b1c:	f9401348 	ldr	x8, [x26, #32]
    40204b20:	aa1903e0 	mov	x0, x25
    40204b24:	52800601 	mov	w1, #0x30                  	// #48
    40204b28:	110006d6 	add	w22, w22, #0x1
    40204b2c:	d63f0100 	blr	x8
    40204b30:	3607ff00 	tbz	w0, #0, 40204b10 <<core::fmt::Formatter>::pad_integral+0x374>
    40204b34:	14000029 	b	40204bd8 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204b38:	7100091f 	cmp	w8, #0x2
    40204b3c:	2a1b03fc 	mov	w28, w27
    40204b40:	540001a1 	b.ne	40204b74 <<core::fmt::Formatter>::pad_integral+0x3d8>  // b.any
    40204b44:	53013f7c 	ubfx	w28, w27, #1, #15
    40204b48:	1400000b 	b	40204b74 <<core::fmt::Formatter>::pad_integral+0x3d8>
    40204b4c:	f9400f48 	ldr	x8, [x26, #24]
    40204b50:	f94007e1 	ldr	x1, [sp, #8]
    40204b54:	aa1903e0 	mov	x0, x25
    40204b58:	aa1303e2 	mov	x2, x19
    40204b5c:	d63f0100 	blr	x8
    40204b60:	370003c0 	tbnz	w0, #0, 40204bd8 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204b64:	2a1f03f3 	mov	w19, wzr
    40204b68:	f9000abc 	str	x28, [x21, #16]
    40204b6c:	1400001c 	b	40204bdc <<core::fmt::Formatter>::pad_integral+0x440>
    40204b70:	2a1b03fc 	mov	w28, w27
    40204b74:	a94056b9 	ldp	x25, x21, [x21]
    40204b78:	2a1f03f4 	mov	w20, wzr
    40204b7c:	12003e88 	and	w8, w20, #0xffff
    40204b80:	6b3c211f 	cmp	w8, w28, uxth
    40204b84:	54000102 	b.cs	40204ba4 <<core::fmt::Formatter>::pad_integral+0x408>  // b.hs, b.nlast
    40204b88:	f94012a8 	ldr	x8, [x21, #32]
    40204b8c:	12005341 	and	w1, w26, #0x1fffff
    40204b90:	aa1903e0 	mov	x0, x25
    40204b94:	11000694 	add	w20, w20, #0x1
    40204b98:	d63f0100 	blr	x8
    40204b9c:	3607ff00 	tbz	w0, #0, 40204b7c <<core::fmt::Formatter>::pad_integral+0x3e0>
    40204ba0:	1400000e 	b	40204bd8 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204ba4:	aa1903e0 	mov	x0, x25
    40204ba8:	aa1503e1 	mov	x1, x21
    40204bac:	2a1803e2 	mov	w2, w24
    40204bb0:	aa1703e3 	mov	x3, x23
    40204bb4:	aa1603e4 	mov	x4, x22
    40204bb8:	9400022c 	bl	40205468 <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204bbc:	370000e0 	tbnz	w0, #0, 40204bd8 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204bc0:	f9400ea8 	ldr	x8, [x21, #24]
    40204bc4:	f94007e1 	ldr	x1, [sp, #8]
    40204bc8:	aa1903e0 	mov	x0, x25
    40204bcc:	aa1303e2 	mov	x2, x19
    40204bd0:	d63f0100 	blr	x8
    40204bd4:	36000160 	tbz	w0, #0, 40204c00 <<core::fmt::Formatter>::pad_integral+0x464>
    40204bd8:	52800033 	mov	w19, #0x1                   	// #1
    40204bdc:	2a1303e0 	mov	w0, w19
    40204be0:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40204be4:	a94557f6 	ldp	x22, x21, [sp, #80]
    40204be8:	a9445ff8 	ldp	x24, x23, [sp, #64]
    40204bec:	a94367fa 	ldp	x26, x25, [sp, #48]
    40204bf0:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40204bf4:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40204bf8:	9101c3ff 	add	sp, sp, #0x70
    40204bfc:	d65f03c0 	ret
    40204c00:	2a1f03f4 	mov	w20, wzr
    40204c04:	4b1c0376 	sub	w22, w27, w28
    40204c08:	12003e88 	and	w8, w20, #0xffff
    40204c0c:	6b36211f 	cmp	w8, w22, uxth
    40204c10:	1a9f27f3 	cset	w19, cc  // cc = lo, ul, last
    40204c14:	54fffe42 	b.cs	40204bdc <<core::fmt::Formatter>::pad_integral+0x440>  // b.hs, b.nlast
    40204c18:	f94012a8 	ldr	x8, [x21, #32]
    40204c1c:	12005341 	and	w1, w26, #0x1fffff
    40204c20:	aa1903e0 	mov	x0, x25
    40204c24:	11000694 	add	w20, w20, #0x1
    40204c28:	d63f0100 	blr	x8
    40204c2c:	3607fee0 	tbz	w0, #0, 40204c08 <<core::fmt::Formatter>::pad_integral+0x46c>
    40204c30:	17ffffeb 	b	40204bdc <<core::fmt::Formatter>::pad_integral+0x440>

0000000040204c34 <core::panicking::panic_bounds_check>:
    40204c34:	d10103ff 	sub	sp, sp, #0x40
    40204c38:	a9037bfd 	stp	x29, x30, [sp, #48]
    40204c3c:	9100c3fd 	add	x29, sp, #0x30
    40204c40:	910023e8 	add	x8, sp, #0x8
    40204c44:	d503201f 	nop
    40204c48:	10004549 	adr	x9, 402054f0 <<u64 as core::fmt::Display>::fmt>
    40204c4c:	a90007e0 	stp	x0, x1, [sp]
    40204c50:	b0000000 	adrp	x0, 40205000 <core::str::count::do_count_chars+0x36c>
    40204c54:	91349400 	add	x0, x0, #0xd25
    40204c58:	a90127e8 	stp	x8, x9, [sp, #16]
    40204c5c:	910003e8 	mov	x8, sp
    40204c60:	910043e1 	add	x1, sp, #0x10
    40204c64:	a90227e8 	stp	x8, x9, [sp, #32]
    40204c68:	94000001 	bl	40204c6c <core::panicking::panic_fmt>

0000000040204c6c <core::panicking::panic_fmt>:
    40204c6c:	d10103ff 	sub	sp, sp, #0x40
    40204c70:	a9037bfd 	stp	x29, x30, [sp, #48]
    40204c74:	9100c3fd 	add	x29, sp, #0x30
    40204c78:	910023e8 	add	x8, sp, #0x8
    40204c7c:	a90087e0 	stp	x0, x1, [sp, #8]
    40204c80:	910063e0 	add	x0, sp, #0x18
    40204c84:	a9018be8 	stp	x8, x2, [sp, #24]
    40204c88:	52800028 	mov	w8, #0x1                   	// #1
    40204c8c:	790053e8 	strh	w8, [sp, #40]
    40204c90:	97fffc97 	bl	40203eec <__rustc::rust_begin_unwind>

0000000040204c94 <core::str::count::do_count_chars>:
    40204c94:	d10183ff 	sub	sp, sp, #0x60
    40204c98:	fd0023ea 	str	d10, [sp, #64]
    40204c9c:	6d0523e9 	stp	d9, d8, [sp, #80]
    40204ca0:	91001c08 	add	x8, x0, #0x7
    40204ca4:	927df10d 	and	x13, x8, #0xfffffffffffffff8
    40204ca8:	cb0001ac 	sub	x12, x13, x0
    40204cac:	eb0c002b 	subs	x11, x1, x12
    40204cb0:	540000e2 	b.cs	40204ccc <core::str::count::do_count_chars+0x38>  // b.hs, b.nlast
    40204cb4:	b4000721 	cbz	x1, 40204d98 <core::str::count::do_count_chars+0x104>
    40204cb8:	f100203f 	cmp	x1, #0x8
    40204cbc:	54001b82 	b.cs	4020502c <core::str::count::do_count_chars+0x398>  // b.hs, b.nlast
    40204cc0:	aa1f03e9 	mov	x9, xzr
    40204cc4:	aa1f03e8 	mov	x8, xzr
    40204cc8:	140001d2 	b	40205410 <core::str::count::do_count_chars+0x77c>
    40204ccc:	d343fd69 	lsr	x9, x11, #3
    40204cd0:	b4ffff29 	cbz	x9, 40204cb4 <core::str::count::do_count_chars+0x20>
    40204cd4:	eb0001bf 	cmp	x13, x0
    40204cd8:	9240096a 	and	x10, x11, #0x7
    40204cdc:	aa1f03e8 	mov	x8, xzr
    40204ce0:	54000100 	b.eq	40204d00 <core::str::count::do_count_chars+0x6c>  // b.none
    40204ce4:	cb0d000d 	sub	x13, x0, x13
    40204ce8:	aa0003ee 	mov	x14, x0
    40204cec:	38c015cf 	ldrsb	w15, [x14], #1
    40204cf0:	310105ff 	cmn	w15, #0x41
    40204cf4:	9a88d508 	cinc	x8, x8, gt
    40204cf8:	b10005ad 	adds	x13, x13, #0x1
    40204cfc:	54ffff83 	b.cc	40204cec <core::str::count::do_count_chars+0x58>  // b.lo, b.ul, b.last
    40204d00:	8b0c000e 	add	x14, x0, x12
    40204d04:	b400056a 	cbz	x10, 40204db0 <core::str::count::do_count_chars+0x11c>
    40204d08:	927ded6b 	and	x11, x11, #0x7ffffffffffffff8
    40204d0c:	8b0b01cc 	add	x12, x14, x11
    40204d10:	39c0018b 	ldrsb	w11, [x12]
    40204d14:	3101057f 	cmn	w11, #0x41
    40204d18:	1a9fd7eb 	cset	w11, gt
    40204d1c:	f100055f 	cmp	x10, #0x1
    40204d20:	540004a0 	b.eq	40204db4 <core::str::count::do_count_chars+0x120>  // b.none
    40204d24:	39c0058d 	ldrsb	w13, [x12, #1]
    40204d28:	310105bf 	cmn	w13, #0x41
    40204d2c:	9a8bd56b 	cinc	x11, x11, gt
    40204d30:	f100095f 	cmp	x10, #0x2
    40204d34:	54000400 	b.eq	40204db4 <core::str::count::do_count_chars+0x120>  // b.none
    40204d38:	39c0098d 	ldrsb	w13, [x12, #2]
    40204d3c:	310105bf 	cmn	w13, #0x41
    40204d40:	9a8bd56b 	cinc	x11, x11, gt
    40204d44:	f1000d5f 	cmp	x10, #0x3
    40204d48:	54000360 	b.eq	40204db4 <core::str::count::do_count_chars+0x120>  // b.none
    40204d4c:	39c00d8d 	ldrsb	w13, [x12, #3]
    40204d50:	310105bf 	cmn	w13, #0x41
    40204d54:	9a8bd56b 	cinc	x11, x11, gt
    40204d58:	f100115f 	cmp	x10, #0x4
    40204d5c:	540002c0 	b.eq	40204db4 <core::str::count::do_count_chars+0x120>  // b.none
    40204d60:	39c0118d 	ldrsb	w13, [x12, #4]
    40204d64:	310105bf 	cmn	w13, #0x41
    40204d68:	9a8bd56b 	cinc	x11, x11, gt
    40204d6c:	f100155f 	cmp	x10, #0x5
    40204d70:	54000220 	b.eq	40204db4 <core::str::count::do_count_chars+0x120>  // b.none
    40204d74:	39c0158d 	ldrsb	w13, [x12, #5]
    40204d78:	310105bf 	cmn	w13, #0x41
    40204d7c:	9a8bd56b 	cinc	x11, x11, gt
    40204d80:	f100195f 	cmp	x10, #0x6
    40204d84:	54000180 	b.eq	40204db4 <core::str::count::do_count_chars+0x120>  // b.none
    40204d88:	39c0198a 	ldrsb	w10, [x12, #6]
    40204d8c:	3101055f 	cmn	w10, #0x41
    40204d90:	9a8bd56b 	cinc	x11, x11, gt
    40204d94:	14000008 	b	40204db4 <core::str::count::do_count_chars+0x120>
    40204d98:	aa1f03e8 	mov	x8, xzr
    40204d9c:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40204da0:	aa0803e0 	mov	x0, x8
    40204da4:	fd4023ea 	ldr	d10, [sp, #64]
    40204da8:	910183ff 	add	sp, sp, #0x60
    40204dac:	d65f03c0 	ret
    40204db0:	aa1f03eb 	mov	x11, xzr
    40204db4:	4f00e420 	movi	v0.16b, #0x1
    40204db8:	8b080168 	add	x8, x11, x8
    40204dbc:	5280180a 	mov	w10, #0xc0                  	// #192
    40204dc0:	b20083eb 	mov	x11, #0x1000100010001       	// #281479271743489
    40204dc4:	1400000c 	b	40204df4 <core::str::count::do_count_chars+0x160>
    40204dc8:	aa1f03f1 	mov	x17, xzr
    40204dcc:	d348fe2f 	lsr	x15, x17, #8
    40204dd0:	92009e30 	and	x16, x17, #0xff00ff00ff00ff
    40204dd4:	8b0e018e 	add	x14, x12, x14
    40204dd8:	cb0d0129 	sub	x9, x9, x13
    40204ddc:	92009def 	and	x15, x15, #0xff00ff00ff00ff
    40204de0:	8b1001ef 	add	x15, x15, x16
    40204de4:	9b0b7df0 	mul	x16, x15, x11
    40204de8:	924005af 	and	x15, x13, #0x3
    40204dec:	8b50c108 	add	x8, x8, x16, lsr #48
    40204df0:	b5000d8f 	cbnz	x15, 40204fa0 <core::str::count::do_count_chars+0x30c>
    40204df4:	b4fffd49 	cbz	x9, 40204d9c <core::str::count::do_count_chars+0x108>
    40204df8:	f103013f 	cmp	x9, #0xc0
    40204dfc:	aa0e03ec 	mov	x12, x14
    40204e00:	9a8a312d 	csel	x13, x9, x10, cc  // cc = lo, ul, last
    40204e04:	d37df1ae 	lsl	x14, x13, #3
    40204e08:	f27b15d0 	ands	x16, x14, #0x7e0
    40204e0c:	54fffde0 	b.eq	40204dc8 <core::str::count::do_count_chars+0x134>  // b.none
    40204e10:	d10081cf 	sub	x15, x14, #0x20
    40204e14:	f10181ff 	cmp	x15, #0x60
    40204e18:	54000082 	b.cs	40204e28 <core::str::count::do_count_chars+0x194>  // b.hs, b.nlast
    40204e1c:	aa1f03f1 	mov	x17, xzr
    40204e20:	aa0c03ef 	mov	x15, x12
    40204e24:	14000044 	b	40204f34 <core::str::count::do_count_chars+0x2a0>
    40204e28:	d345fdef 	lsr	x15, x15, #5
    40204e2c:	6f00e401 	movi	v1.2d, #0x0
    40204e30:	6f00e402 	movi	v2.2d, #0x0
    40204e34:	91010180 	add	x0, x12, #0x40
    40204e38:	910005f1 	add	x17, x15, #0x1
    40204e3c:	927ee632 	and	x18, x17, #0xffffffffffffffc
    40204e40:	927ee621 	and	x1, x17, #0xffffffffffffffc
    40204e44:	8b12158f 	add	x15, x12, x18, lsl #5
    40204e48:	d1010002 	sub	x2, x0, #0x40
    40204e4c:	4c400c10 	ld4	{v16.2d-v19.2d}, [x0]
    40204e50:	f1001021 	subs	x1, x1, #0x4
    40204e54:	91020000 	add	x0, x0, #0x80
    40204e58:	4c400c43 	ld4	{v3.2d-v6.2d}, [x2]
    40204e5c:	6e205a07 	mvn	v7.16b, v16.16b
    40204e60:	6e205a35 	mvn	v21.16b, v17.16b
    40204e64:	6e205a5a 	mvn	v26.16b, v18.16b
    40204e68:	6e205876 	mvn	v22.16b, v3.16b
    40204e6c:	6e205897 	mvn	v23.16b, v4.16b
    40204e70:	6e2058b8 	mvn	v24.16b, v5.16b
    40204e74:	6f7a0614 	ushr	v20.2d, v16.2d, #6
    40204e78:	6f7a0639 	ushr	v25.2d, v17.2d, #6
    40204e7c:	6f7a065b 	ushr	v27.2d, v18.2d, #6
    40204e80:	6f7a047c 	ushr	v28.2d, v3.2d, #6
    40204e84:	6f7a049d 	ushr	v29.2d, v4.2d, #6
    40204e88:	6f7a04be 	ushr	v30.2d, v5.2d, #6
    40204e8c:	6f7906d6 	ushr	v22.2d, v22.2d, #7
    40204e90:	6f7906f7 	ushr	v23.2d, v23.2d, #7
    40204e94:	6f790718 	ushr	v24.2d, v24.2d, #7
    40204e98:	6f7904e7 	ushr	v7.2d, v7.2d, #7
    40204e9c:	6f7906b5 	ushr	v21.2d, v21.2d, #7
    40204ea0:	6f79075a 	ushr	v26.2d, v26.2d, #7
    40204ea4:	6e205a7f 	mvn	v31.16b, v19.16b
    40204ea8:	6f7a0670 	ushr	v16.2d, v19.2d, #6
    40204eac:	6e2058d1 	mvn	v17.16b, v6.16b
    40204eb0:	4ebc1ed2 	orr	v18.16b, v22.16b, v28.16b
    40204eb4:	4ebd1ef3 	orr	v19.16b, v23.16b, v29.16b
    40204eb8:	4ebe1f16 	orr	v22.16b, v24.16b, v30.16b
    40204ebc:	4eb41ce7 	orr	v7.16b, v7.16b, v20.16b
    40204ec0:	4eb91eb4 	orr	v20.16b, v21.16b, v25.16b
    40204ec4:	4ebb1f55 	orr	v21.16b, v26.16b, v27.16b
    40204ec8:	6f7a04c3 	ushr	v3.2d, v6.2d, #6
    40204ecc:	6f7907e4 	ushr	v4.2d, v31.2d, #7
    40204ed0:	6f790625 	ushr	v5.2d, v17.2d, #7
    40204ed4:	4e201e46 	and	v6.16b, v18.16b, v0.16b
    40204ed8:	4e201e71 	and	v17.16b, v19.16b, v0.16b
    40204edc:	4e201ed2 	and	v18.16b, v22.16b, v0.16b
    40204ee0:	4e201ce7 	and	v7.16b, v7.16b, v0.16b
    40204ee4:	4e201e93 	and	v19.16b, v20.16b, v0.16b
    40204ee8:	4e201eb4 	and	v20.16b, v21.16b, v0.16b
    40204eec:	4eb01c84 	orr	v4.16b, v4.16b, v16.16b
    40204ef0:	4ea31ca3 	orr	v3.16b, v5.16b, v3.16b
    40204ef4:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40204ef8:	4ef18646 	add	v6.2d, v18.2d, v17.2d
    40204efc:	4ee284e2 	add	v2.2d, v7.2d, v2.2d
    40204f00:	4ef38685 	add	v5.2d, v20.2d, v19.2d
    40204f04:	4e201c63 	and	v3.16b, v3.16b, v0.16b
    40204f08:	4e201c84 	and	v4.16b, v4.16b, v0.16b
    40204f0c:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40204f10:	4ee284a2 	add	v2.2d, v5.2d, v2.2d
    40204f14:	4ee18461 	add	v1.2d, v3.2d, v1.2d
    40204f18:	4ee28482 	add	v2.2d, v4.2d, v2.2d
    40204f1c:	54fff961 	b.ne	40204e48 <core::str::count::do_count_chars+0x1b4>  // b.any
    40204f20:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40204f24:	eb12023f 	cmp	x17, x18
    40204f28:	5ef1b821 	addp	d1, v1.2d
    40204f2c:	9e660031 	fmov	x17, d1
    40204f30:	54fff4e0 	b.eq	40204dcc <core::str::count::do_count_chars+0x138>  // b.none
    40204f34:	8b100190 	add	x16, x12, x16
    40204f38:	f9400df2 	ldr	x18, [x15, #24]
    40204f3c:	f9001ff2 	str	x18, [sp, #56]
    40204f40:	f94009f2 	ldr	x18, [x15, #16]
    40204f44:	f9001bf2 	str	x18, [sp, #48]
    40204f48:	f94005f2 	ldr	x18, [x15, #8]
    40204f4c:	f90017f2 	str	x18, [sp, #40]
    40204f50:	f84205f2 	ldr	x18, [x15], #32
    40204f54:	eb1001ff 	cmp	x15, x16
    40204f58:	f90013f2 	str	x18, [sp, #32]
    40204f5c:	ad4107e2 	ldp	q2, q1, [sp, #32]
    40204f60:	6e205823 	mvn	v3.16b, v1.16b
    40204f64:	6e205844 	mvn	v4.16b, v2.16b
    40204f68:	6f7a0421 	ushr	v1.2d, v1.2d, #6
    40204f6c:	6f7a0442 	ushr	v2.2d, v2.2d, #6
    40204f70:	6f790463 	ushr	v3.2d, v3.2d, #7
    40204f74:	6f790484 	ushr	v4.2d, v4.2d, #7
    40204f78:	4ea21c82 	orr	v2.16b, v4.16b, v2.16b
    40204f7c:	4ea11c61 	orr	v1.16b, v3.16b, v1.16b
    40204f80:	4e201c21 	and	v1.16b, v1.16b, v0.16b
    40204f84:	4e201c42 	and	v2.16b, v2.16b, v0.16b
    40204f88:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40204f8c:	5ef1b821 	addp	d1, v1.2d
    40204f90:	9e660032 	fmov	x18, d1
    40204f94:	8b110251 	add	x17, x18, x17
    40204f98:	54fffd01 	b.ne	40204f38 <core::str::count::do_count_chars+0x2a4>  // b.any
    40204f9c:	17ffff8c 	b	40204dcc <core::str::count::do_count_chars+0x138>
    40204fa0:	927e15a9 	and	x9, x13, #0xfc
    40204fa4:	f10005ff 	cmp	x15, #0x1
    40204fa8:	8b090d8a 	add	x10, x12, x9, lsl #3
    40204fac:	f9400149 	ldr	x9, [x10]
    40204fb0:	aa2903eb 	mvn	x11, x9
    40204fb4:	d347fd6b 	lsr	x11, x11, #7
    40204fb8:	aa491969 	orr	x9, x11, x9, lsr #6
    40204fbc:	9200c129 	and	x9, x9, #0x101010101010101
    40204fc0:	540001e0 	b.eq	40204ffc <core::str::count::do_count_chars+0x368>  // b.none
    40204fc4:	f940054b 	ldr	x11, [x10, #8]
    40204fc8:	f10009ff 	cmp	x15, #0x2
    40204fcc:	aa2b03ec 	mvn	x12, x11
    40204fd0:	d347fd8c 	lsr	x12, x12, #7
    40204fd4:	aa4b198b 	orr	x11, x12, x11, lsr #6
    40204fd8:	9200c16b 	and	x11, x11, #0x101010101010101
    40204fdc:	8b090169 	add	x9, x11, x9
    40204fe0:	540000e0 	b.eq	40204ffc <core::str::count::do_count_chars+0x368>  // b.none
    40204fe4:	f940094a 	ldr	x10, [x10, #16]
    40204fe8:	aa2a03eb 	mvn	x11, x10
    40204fec:	d347fd6b 	lsr	x11, x11, #7
    40204ff0:	aa4a196a 	orr	x10, x11, x10, lsr #6
    40204ff4:	9200c14a 	and	x10, x10, #0x101010101010101
    40204ff8:	8b090149 	add	x9, x10, x9
    40204ffc:	d348fd2a 	lsr	x10, x9, #8
    40205000:	92009d29 	and	x9, x9, #0xff00ff00ff00ff
    40205004:	92009d4a 	and	x10, x10, #0xff00ff00ff00ff
    40205008:	8b090149 	add	x9, x10, x9
    4020500c:	b20083ea 	mov	x10, #0x1000100010001       	// #281479271743489
    40205010:	9b0a7d29 	mul	x9, x9, x10
    40205014:	8b49c108 	add	x8, x8, x9, lsr #48
    40205018:	6d4523e9 	ldp	d9, d8, [sp, #80]
    4020501c:	aa0803e0 	mov	x0, x8
    40205020:	fd4023ea 	ldr	d10, [sp, #64]
    40205024:	910183ff 	add	sp, sp, #0x60
    40205028:	d65f03c0 	ret
    4020502c:	f100803f 	cmp	x1, #0x20
    40205030:	54000082 	b.cs	40205040 <core::str::count::do_count_chars+0x3ac>  // b.hs, b.nlast
    40205034:	aa1f03e9 	mov	x9, xzr
    40205038:	aa1f03e8 	mov	x8, xzr
    4020503c:	140000bc 	b	4020532c <core::str::count::do_count_chars+0x698>
    40205040:	6f00e400 	movi	v0.2d, #0x0
    40205044:	4f05e7e3 	movi	v3.16b, #0xbf
    40205048:	52800028 	mov	w8, #0x1                   	// #1
    4020504c:	6f00e402 	movi	v2.2d, #0x0
    40205050:	6f00e407 	movi	v7.2d, #0x0
    40205054:	927d042a 	and	x10, x1, #0x18
    40205058:	6f00e401 	movi	v1.2d, #0x0
    4020505c:	6f00e412 	movi	v18.2d, #0x0
    40205060:	927be829 	and	x9, x1, #0xffffffffffffffe0
    40205064:	6f00e405 	movi	v5.2d, #0x0
    40205068:	6f00e406 	movi	v6.2d, #0x0
    4020506c:	927be82b 	and	x11, x1, #0xffffffffffffffe0
    40205070:	6f00e404 	movi	v4.2d, #0x0
    40205074:	6f00e416 	movi	v22.2d, #0x0
    40205078:	6f00e411 	movi	v17.2d, #0x0
    4020507c:	6f00e410 	movi	v16.2d, #0x0
    40205080:	6f00e417 	movi	v23.2d, #0x0
    40205084:	6f00e414 	movi	v20.2d, #0x0
    40205088:	6f00e415 	movi	v21.2d, #0x0
    4020508c:	6f00e413 	movi	v19.2d, #0x0
    40205090:	6f00e418 	movi	v24.2d, #0x0
    40205094:	4e080d19 	dup	v25.2d, x8
    40205098:	91004008 	add	x8, x0, #0x10
    4020509c:	aa0803ec 	mov	x12, x8
    402050a0:	385f1112 	ldurb	w18, [x8, #-15]
    402050a4:	385f5102 	ldurb	w2, [x8, #-11]
    402050a8:	385f0d8d 	ldrb	w13, [x12, #-16]!
    402050ac:	aa0c03ef 	mov	x15, x12
    402050b0:	3940098e 	ldrb	w14, [x12, #2]
    402050b4:	38404df0 	ldrb	w16, [x15, #4]!
    402050b8:	394009f1 	ldrb	w17, [x15, #2]
    402050bc:	39400d83 	ldrb	w3, [x12, #3]
    402050c0:	39400def 	ldrb	w15, [x15, #3]
    402050c4:	d370bdce 	lsl	x14, x14, #16
    402050c8:	aa1221ad 	orr	x13, x13, x18, lsl #8
    402050cc:	2a022210 	orr	w16, w16, w2, lsl #8
    402050d0:	53103e31 	lsl	w17, w17, #16
    402050d4:	f100816b 	subs	x11, x11, #0x20
    402050d8:	aa0361ce 	orr	x14, x14, x3, lsl #24
    402050dc:	2a0f622f 	orr	w15, w17, w15, lsl #24
    402050e0:	aa0d01cd 	orr	x13, x14, x13
    402050e4:	2a1001ee 	orr	w14, w15, w16
    402050e8:	aa0e81ad 	orr	x13, x13, x14, lsl #32
    402050ec:	f9000bed 	str	x13, [sp, #16]
    402050f0:	aa0c03ed 	mov	x13, x12
    402050f4:	38408dae 	ldrb	w14, [x13, #8]!
    402050f8:	39400daf 	ldrb	w15, [x13, #3]
    402050fc:	394009b0 	ldrb	w16, [x13, #2]
    40205100:	38404db1 	ldrb	w17, [x13, #4]!
    40205104:	394009b2 	ldrb	w18, [x13, #2]
    40205108:	39402582 	ldrb	w2, [x12, #9]
    4020510c:	3940358c 	ldrb	w12, [x12, #13]
    40205110:	39400dad 	ldrb	w13, [x13, #3]
    40205114:	d370be10 	lsl	x16, x16, #16
    40205118:	53103e52 	lsl	w18, w18, #16
    4020511c:	aa0221ce 	orr	x14, x14, x2, lsl #8
    40205120:	2a0c222c 	orr	w12, w17, w12, lsl #8
    40205124:	aa0f620f 	orr	x15, x16, x15, lsl #24
    40205128:	2a0d624d 	orr	w13, w18, w13, lsl #24
    4020512c:	aa0e01ee 	orr	x14, x15, x14
    40205130:	2a0c01ac 	orr	w12, w13, w12
    40205134:	aa0c81cc 	orr	x12, x14, x12, lsl #32
    40205138:	f9000fec 	str	x12, [sp, #24]
    4020513c:	aa0803ec 	mov	x12, x8
    40205140:	3940090e 	ldrb	w14, [x8, #2]
    40205144:	38404d8f 	ldrb	w15, [x12, #4]!
    40205148:	39400990 	ldrb	w16, [x12, #2]
    4020514c:	3940050d 	ldrb	w13, [x8, #1]
    40205150:	39400111 	ldrb	w17, [x8]
    40205154:	39400d12 	ldrb	w18, [x8, #3]
    40205158:	39401502 	ldrb	w2, [x8, #5]
    4020515c:	39400d8c 	ldrb	w12, [x12, #3]
    40205160:	d370bdce 	lsl	x14, x14, #16
    40205164:	53103e10 	lsl	w16, w16, #16
    40205168:	aa0d222d 	orr	x13, x17, x13, lsl #8
    4020516c:	2a0221ef 	orr	w15, w15, w2, lsl #8
    40205170:	3dc007fa 	ldr	q26, [sp, #16]
    40205174:	aa1261ce 	orr	x14, x14, x18, lsl #24
    40205178:	2a0c620c 	orr	w12, w16, w12, lsl #24
    4020517c:	4e23375a 	cmgt	v26.16b, v26.16b, v3.16b
    40205180:	aa0d01cd 	orr	x13, x14, x13
    40205184:	2a0f018c 	orr	w12, w12, w15
    40205188:	aa0c81ac 	orr	x12, x13, x12, lsl #32
    4020518c:	aa0803ed 	mov	x13, x8
    40205190:	6f08a75b 	uxtl2	v27.8h, v26.16b
    40205194:	2f08a75a 	uxtl	v26.8h, v26.8b
    40205198:	f90003ec 	str	x12, [sp]
    4020519c:	38408dac 	ldrb	w12, [x13, #8]!
    402051a0:	39400dae 	ldrb	w14, [x13, #3]
    402051a4:	394009af 	ldrb	w15, [x13, #2]
    402051a8:	38404db0 	ldrb	w16, [x13, #4]!
    402051ac:	394009b1 	ldrb	w17, [x13, #2]
    402051b0:	39402512 	ldrb	w18, [x8, #9]
    402051b4:	39403502 	ldrb	w2, [x8, #13]
    402051b8:	39400dad 	ldrb	w13, [x13, #3]
    402051bc:	d370bdef 	lsl	x15, x15, #16
    402051c0:	6f10a77c 	uxtl2	v28.4s, v27.8h
    402051c4:	53103e31 	lsl	w17, w17, #16
    402051c8:	aa12218c 	orr	x12, x12, x18, lsl #8
    402051cc:	2a022210 	orr	w16, w16, w2, lsl #8
    402051d0:	aa0e61ee 	orr	x14, x15, x14, lsl #24
    402051d4:	2f10a77b 	uxtl	v27.4s, v27.4h
    402051d8:	2f10a75e 	uxtl	v30.4s, v26.4h
    402051dc:	2a0d622d 	orr	w13, w17, w13, lsl #24
    402051e0:	6f20a79d 	uxtl2	v29.2d, v28.4s
    402051e4:	6f10a75a 	uxtl2	v26.4s, v26.8h
    402051e8:	aa0c01cc 	orr	x12, x14, x12
    402051ec:	2f20a79c 	uxtl	v28.2d, v28.2s
    402051f0:	91008108 	add	x8, x8, #0x20
    402051f4:	2a1001ad 	orr	w13, w13, w16
    402051f8:	6f20a768 	uxtl2	v8.2d, v27.4s
    402051fc:	6f20a7c9 	uxtl2	v9.2d, v30.4s
    40205200:	aa0d818c 	orr	x12, x12, x13, lsl #32
    40205204:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    40205208:	6f20a74a 	uxtl2	v10.2d, v26.4s
    4020520c:	2f20a75a 	uxtl	v26.2d, v26.2s
    40205210:	2f20a77b 	uxtl	v27.2d, v27.2s
    40205214:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    40205218:	f90007ec 	str	x12, [sp, #8]
    4020521c:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    40205220:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    40205224:	3dc003ff 	ldr	q31, [sp]
    40205228:	4efd86d6 	add	v22.2d, v22.2d, v29.2d
    4020522c:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40205230:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    40205234:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    40205238:	4efc8484 	add	v4.2d, v4.2d, v28.2d
    4020523c:	4e2337ff 	cmgt	v31.16b, v31.16b, v3.16b
    40205240:	4ee884c6 	add	v6.2d, v6.2d, v8.2d
    40205244:	2f20a7de 	uxtl	v30.2d, v30.2s
    40205248:	4eea8652 	add	v18.2d, v18.2d, v10.2d
    4020524c:	4ee984e7 	add	v7.2d, v7.2d, v9.2d
    40205250:	4efa8421 	add	v1.2d, v1.2d, v26.2d
    40205254:	4efb84a5 	add	v5.2d, v5.2d, v27.2d
    40205258:	6f08a7fd 	uxtl2	v29.8h, v31.16b
    4020525c:	2f08a7ff 	uxtl	v31.8h, v31.8b
    40205260:	4e391fde 	and	v30.16b, v30.16b, v25.16b
    40205264:	6f10a7bc 	uxtl2	v28.4s, v29.8h
    40205268:	6f10a7e8 	uxtl2	v8.4s, v31.8h
    4020526c:	2f10a7bd 	uxtl	v29.4s, v29.4h
    40205270:	2f10a7fa 	uxtl	v26.4s, v31.4h
    40205274:	4efe8442 	add	v2.2d, v2.2d, v30.2d
    40205278:	2f20a79b 	uxtl	v27.2d, v28.2s
    4020527c:	6f20a79c 	uxtl2	v28.2d, v28.4s
    40205280:	2f20a7bf 	uxtl	v31.2d, v29.2s
    40205284:	6f20a509 	uxtl2	v9.2d, v8.4s
    40205288:	6f20a7bd 	uxtl2	v29.2d, v29.4s
    4020528c:	2f20a74a 	uxtl	v10.2d, v26.2s
    40205290:	6f20a75a 	uxtl2	v26.2d, v26.4s
    40205294:	2f20a508 	uxtl	v8.2d, v8.2s
    40205298:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    4020529c:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    402052a0:	4e391fff 	and	v31.16b, v31.16b, v25.16b
    402052a4:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    402052a8:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    402052ac:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    402052b0:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    402052b4:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    402052b8:	4efc8718 	add	v24.2d, v24.2d, v28.2d
    402052bc:	4efb8673 	add	v19.2d, v19.2d, v27.2d
    402052c0:	4eff8694 	add	v20.2d, v20.2d, v31.2d
    402052c4:	4efd86b5 	add	v21.2d, v21.2d, v29.2d
    402052c8:	4ee986f7 	add	v23.2d, v23.2d, v9.2d
    402052cc:	4eea8631 	add	v17.2d, v17.2d, v10.2d
    402052d0:	4ee88610 	add	v16.2d, v16.2d, v8.2d
    402052d4:	4efa8400 	add	v0.2d, v0.2d, v26.2d
    402052d8:	54ffee21 	b.ne	4020509c <core::str::count::do_count_chars+0x408>  // b.any
    402052dc:	4ef286e3 	add	v3.2d, v23.2d, v18.2d
    402052e0:	4ef68712 	add	v18.2d, v24.2d, v22.2d
    402052e4:	eb09003f 	cmp	x1, x9
    402052e8:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    402052ec:	4ee28622 	add	v2.2d, v17.2d, v2.2d
    402052f0:	4ee58685 	add	v5.2d, v20.2d, v5.2d
    402052f4:	4ee686a6 	add	v6.2d, v21.2d, v6.2d
    402052f8:	4ee18601 	add	v1.2d, v16.2d, v1.2d
    402052fc:	4ee48664 	add	v4.2d, v19.2d, v4.2d
    40205300:	4ef28463 	add	v3.2d, v3.2d, v18.2d
    40205304:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40205308:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    4020530c:	4ee68400 	add	v0.2d, v0.2d, v6.2d
    40205310:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40205314:	4ee38400 	add	v0.2d, v0.2d, v3.2d
    40205318:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    4020531c:	5ef1b800 	addp	d0, v0.2d
    40205320:	9e660008 	fmov	x8, d0
    40205324:	54ffd3c0 	b.eq	40204d9c <core::str::count::do_count_chars+0x108>  // b.none
    40205328:	b400074a 	cbz	x10, 40205410 <core::str::count::do_count_chars+0x77c>
    4020532c:	6f00e400 	movi	v0.2d, #0x0
    40205330:	6f00e401 	movi	v1.2d, #0x0
    40205334:	aa0903ea 	mov	x10, x9
    40205338:	0f05e7e2 	movi	v2.8b, #0xbf
    4020533c:	6f00e403 	movi	v3.2d, #0x0
    40205340:	927df029 	and	x9, x1, #0xfffffffffffffff8
    40205344:	6f00e404 	movi	v4.2d, #0x0
    40205348:	4e081d00 	mov	v0.d[0], x8
    4020534c:	52800028 	mov	w8, #0x1                   	// #1
    40205350:	4e080d05 	dup	v5.2d, x8
    40205354:	cb090148 	sub	x8, x10, x9
    40205358:	8b0a000a 	add	x10, x0, x10
    4020535c:	aa0a03ed 	mov	x13, x10
    40205360:	3940094c 	ldrb	w12, [x10, #2]
    40205364:	3940054b 	ldrb	w11, [x10, #1]
    40205368:	38404dae 	ldrb	w14, [x13, #4]!
    4020536c:	394009af 	ldrb	w15, [x13, #2]
    40205370:	39400150 	ldrb	w16, [x10]
    40205374:	39400d51 	ldrb	w17, [x10, #3]
    40205378:	d370bd8c 	lsl	x12, x12, #16
    4020537c:	39401552 	ldrb	w18, [x10, #5]
    40205380:	39400dad 	ldrb	w13, [x13, #3]
    40205384:	53103def 	lsl	w15, w15, #16
    40205388:	aa0b220b 	orr	x11, x16, x11, lsl #8
    4020538c:	aa11618c 	orr	x12, x12, x17, lsl #24
    40205390:	b1002108 	adds	x8, x8, #0x8
    40205394:	2a1221ce 	orr	w14, w14, w18, lsl #8
    40205398:	2a0d61ed 	orr	w13, w15, w13, lsl #24
    4020539c:	9100214a 	add	x10, x10, #0x8
    402053a0:	aa0b018b 	orr	x11, x12, x11
    402053a4:	2a0e01ac 	orr	w12, w13, w14
    402053a8:	aa0c816b 	orr	x11, x11, x12, lsl #32
    402053ac:	9e670166 	fmov	d6, x11
    402053b0:	0e2234c6 	cmgt	v6.8b, v6.8b, v2.8b
    402053b4:	2f08a4c6 	uxtl	v6.8h, v6.8b
    402053b8:	6f10a4c7 	uxtl2	v7.4s, v6.8h
    402053bc:	2f10a4c6 	uxtl	v6.4s, v6.4h
    402053c0:	6f20a4f0 	uxtl2	v16.2d, v7.4s
    402053c4:	2f20a4d1 	uxtl	v17.2d, v6.2s
    402053c8:	6f20a4c6 	uxtl2	v6.2d, v6.4s
    402053cc:	2f20a4e7 	uxtl	v7.2d, v7.2s
    402053d0:	4e251e10 	and	v16.16b, v16.16b, v5.16b
    402053d4:	4e251e31 	and	v17.16b, v17.16b, v5.16b
    402053d8:	4e251cc6 	and	v6.16b, v6.16b, v5.16b
    402053dc:	4e251ce7 	and	v7.16b, v7.16b, v5.16b
    402053e0:	4ef08484 	add	v4.2d, v4.2d, v16.2d
    402053e4:	4ee68463 	add	v3.2d, v3.2d, v6.2d
    402053e8:	4ef18400 	add	v0.2d, v0.2d, v17.2d
    402053ec:	4ee78421 	add	v1.2d, v1.2d, v7.2d
    402053f0:	54fffb61 	b.ne	4020535c <core::str::count::do_count_chars+0x6c8>  // b.any
    402053f4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    402053f8:	4ee48461 	add	v1.2d, v3.2d, v4.2d
    402053fc:	eb09003f 	cmp	x1, x9
    40205400:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    40205404:	5ef1b800 	addp	d0, v0.2d
    40205408:	9e660008 	fmov	x8, d0
    4020540c:	54ffcc80 	b.eq	40204d9c <core::str::count::do_count_chars+0x108>  // b.none
    40205410:	cb09002a 	sub	x10, x1, x9
    40205414:	8b090009 	add	x9, x0, x9
    40205418:	38c0152b 	ldrsb	w11, [x9], #1
    4020541c:	3101057f 	cmn	w11, #0x41
    40205420:	9a88d508 	cinc	x8, x8, gt
    40205424:	f100054a 	subs	x10, x10, #0x1
    40205428:	54ffff81 	b.ne	40205418 <core::str::count::do_count_chars+0x784>  // b.any
    4020542c:	17fffe5c 	b	40204d9c <core::str::count::do_count_chars+0x108>

0000000040205430 <core::panicking::panic_const::panic_const_div_by_zero>:
    40205430:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    40205434:	910003fd 	mov	x29, sp
    40205438:	aa0003e2 	mov	x2, x0
    4020543c:	d503201f 	nop
    40205440:	10006240 	adr	x0, 40206088 <anon.e5cf9e378689f0b52d762c1b402a78cc.8.llvm.13402452413823366170+0xf8>
    40205444:	52800661 	mov	w1, #0x33                  	// #51
    40205448:	97fffe09 	bl	40204c6c <core::panicking::panic_fmt>

000000004020544c <core::panicking::panic_const::panic_const_rem_by_zero>:
    4020544c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    40205450:	910003fd 	mov	x29, sp
    40205454:	aa0003e2 	mov	x2, x0
    40205458:	d503201f 	nop
    4020545c:	30006220 	adr	x0, 402060a1 <anon.e5cf9e378689f0b52d762c1b402a78cc.8.llvm.13402452413823366170+0x111>
    40205460:	52800e61 	mov	w1, #0x73                  	// #115
    40205464:	97fffe02 	bl	40204c6c <core::panicking::panic_fmt>

0000000040205468 <<core::fmt::Formatter>::pad_integral::write_prefix>:
    40205468:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4020546c:	a90157f6 	stp	x22, x21, [sp, #16]
    40205470:	a9024ff4 	stp	x20, x19, [sp, #32]
    40205474:	910003fd 	mov	x29, sp
    40205478:	aa0403f3 	mov	x19, x4
    4020547c:	aa0303f4 	mov	x20, x3
    40205480:	aa0103f5 	mov	x21, x1
    40205484:	7144405f 	cmp	w2, #0x110, lsl #12
    40205488:	540001a0 	b.eq	402054bc <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>  // b.none
    4020548c:	f94012a8 	ldr	x8, [x21, #32]
    40205490:	2a0203e1 	mov	w1, w2
    40205494:	aa0003f6 	mov	x22, x0
    40205498:	d63f0100 	blr	x8
    4020549c:	2a0003e8 	mov	w8, w0
    402054a0:	aa1603e0 	mov	x0, x22
    402054a4:	360000c8 	tbz	w8, #0, 402054bc <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>
    402054a8:	52800020 	mov	w0, #0x1                   	// #1
    402054ac:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402054b0:	a94157f6 	ldp	x22, x21, [sp, #16]
    402054b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402054b8:	d65f03c0 	ret
    402054bc:	b4000114 	cbz	x20, 402054dc <<core::fmt::Formatter>::pad_integral::write_prefix+0x74>
    402054c0:	f9400ea3 	ldr	x3, [x21, #24]
    402054c4:	aa1403e1 	mov	x1, x20
    402054c8:	aa1303e2 	mov	x2, x19
    402054cc:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402054d0:	a94157f6 	ldp	x22, x21, [sp, #16]
    402054d4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402054d8:	d61f0060 	br	x3
    402054dc:	2a1f03e0 	mov	w0, wzr
    402054e0:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402054e4:	a94157f6 	ldp	x22, x21, [sp, #16]
    402054e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402054ec:	d65f03c0 	ret

00000000402054f0 <<u64 as core::fmt::Display>::fmt>:
    402054f0:	d100c3ff 	sub	sp, sp, #0x30
    402054f4:	a9027bfd 	stp	x29, x30, [sp, #32]
    402054f8:	910083fd 	add	x29, sp, #0x20
    402054fc:	f9400009 	ldr	x9, [x0]
    40205500:	d503201f 	nop
    40205504:	100055e8 	adr	x8, 40205fc0 <anon.e5cf9e378689f0b52d762c1b402a78cc.8.llvm.13402452413823366170+0x30>
    40205508:	f10fa13f 	cmp	x9, #0x3e8
    4020550c:	540004e3 	b.cc	402055a8 <<u64 as core::fmt::Display>::fmt+0xb8>  // b.lo, b.ul, b.last
    40205510:	d28b296c 	mov	x12, #0x594b                	// #22859
    40205514:	910033ea 	add	x10, sp, #0xc
    40205518:	5292cff1 	mov	w17, #0x967f                	// #38527
    4020551c:	f2a710cc 	movk	x12, #0x3886, lsl #16
    40205520:	9280026b 	mov	x11, #0xffffffffffffffec    	// #-20
    40205524:	5284e20d 	mov	w13, #0x2710                	// #10000
    40205528:	f2d8bacc 	movk	x12, #0xc5d6, lsl #32
    4020552c:	52828f6e 	mov	w14, #0x147b                	// #5243
    40205530:	91004d4f 	add	x15, x10, #0x13
    40205534:	f2e68dac 	movk	x12, #0x346d, lsl #48
    40205538:	52800c90 	mov	w16, #0x64                  	// #100
    4020553c:	72a01311 	movk	w17, #0x98, lsl #16
    40205540:	aa0903ea 	mov	x10, x9
    40205544:	aa0a03f2 	mov	x18, x10
    40205548:	9bcc7d4a 	umulh	x10, x10, x12
    4020554c:	9100116b 	add	x11, x11, #0x4
    40205550:	eb11025f 	cmp	x18, x17
    40205554:	d34bfd4a 	lsr	x10, x10, #11
    40205558:	1b0dc940 	msub	w0, w10, w13, w18
    4020555c:	53023c02 	ubfx	w2, w0, #2, #14
    40205560:	1b0e7c42 	mul	w2, w2, w14
    40205564:	53117c42 	lsr	w2, w2, #17
    40205568:	1b108040 	msub	w0, w2, w16, w0
    4020556c:	8b224502 	add	x2, x8, w2, uxtw #1
    40205570:	39400043 	ldrb	w3, [x2]
    40205574:	39400442 	ldrb	w2, [x2, #1]
    40205578:	8b202500 	add	x0, x8, w0, uxth #1
    4020557c:	381fd1e3 	sturb	w3, [x15, #-3]
    40205580:	39400003 	ldrb	w3, [x0]
    40205584:	39400400 	ldrb	w0, [x0, #1]
    40205588:	381fe1e2 	sturb	w2, [x15, #-2]
    4020558c:	381ff1e3 	sturb	w3, [x15, #-1]
    40205590:	381fc5e0 	strb	w0, [x15], #-4
    40205594:	54fffd88 	b.hi	40205544 <<u64 as core::fmt::Display>::fmt+0x54>  // b.pmore
    40205598:	cb0b03eb 	neg	x11, x11
    4020559c:	f100255f 	cmp	x10, #0x9
    402055a0:	540000c8 	b.hi	402055b8 <<u64 as core::fmt::Display>::fmt+0xc8>  // b.pmore
    402055a4:	14000015 	b	402055f8 <<u64 as core::fmt::Display>::fmt+0x108>
    402055a8:	5280028b 	mov	w11, #0x14                  	// #20
    402055ac:	aa0903ea 	mov	x10, x9
    402055b0:	f100253f 	cmp	x9, #0x9
    402055b4:	54000229 	b.ls	402055f8 <<u64 as core::fmt::Display>::fmt+0x108>  // b.plast
    402055b8:	53023d4c 	ubfx	w12, w10, #2, #14
    402055bc:	52828f6d 	mov	w13, #0x147b                	// #5243
    402055c0:	910033ef 	add	x15, sp, #0xc
    402055c4:	1b0d7d8c 	mul	w12, w12, w13
    402055c8:	52800c8d 	mov	w13, #0x64                  	// #100
    402055cc:	53117d8c 	lsr	w12, w12, #17
    402055d0:	1b0da98a 	msub	w10, w12, w13, w10
    402055d4:	d100096d 	sub	x13, x11, #0x2
    402055d8:	8b0b01eb 	add	x11, x15, x11
    402055dc:	8b2a250a 	add	x10, x8, w10, uxth #1
    402055e0:	3940014e 	ldrb	w14, [x10]
    402055e4:	3940054a 	ldrb	w10, [x10, #1]
    402055e8:	382d69ee 	strb	w14, [x15, x13]
    402055ec:	381ff16a 	sturb	w10, [x11, #-1]
    402055f0:	aa0c03ea 	mov	x10, x12
    402055f4:	aa0d03eb 	mov	x11, x13
    402055f8:	b4000049 	cbz	x9, 40205600 <<u64 as core::fmt::Display>::fmt+0x110>
    402055fc:	b40000ca 	cbz	x10, 40205614 <<u64 as core::fmt::Display>::fmt+0x124>
    40205600:	8b0a0508 	add	x8, x8, x10, lsl #1
    40205604:	d100056b 	sub	x11, x11, #0x1
    40205608:	910033e9 	add	x9, sp, #0xc
    4020560c:	39400508 	ldrb	w8, [x8, #1]
    40205610:	382b6928 	strb	w8, [x9, x11]
    40205614:	52800288 	mov	w8, #0x14                  	// #20
    40205618:	aa0103e0 	mov	x0, x1
    4020561c:	52800021 	mov	w1, #0x1                   	// #1
    40205620:	cb0b0105 	sub	x5, x8, x11
    40205624:	910033e8 	add	x8, sp, #0xc
    40205628:	52800022 	mov	w2, #0x1                   	// #1
    4020562c:	8b0b0104 	add	x4, x8, x11
    40205630:	aa1f03e3 	mov	x3, xzr
    40205634:	97fffc5a 	bl	4020479c <<core::fmt::Formatter>::pad_integral>
    40205638:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4020563c:	9100c3ff 	add	sp, sp, #0x30
    40205640:	d65f03c0 	ret

0000000040205644 <__udivti3>:
    40205644:	d100c3ff 	sub	sp, sp, #0x30
    40205648:	a9027bfd 	stp	x29, x30, [sp, #32]
    4020564c:	910083fd 	add	x29, sp, #0x20
    40205650:	910003e8 	mov	x8, sp
    40205654:	94000005 	bl	40205668 <compiler_builtins::int::specialized_div_rem::u128_div_rem>
    40205658:	a94007e0 	ldp	x0, x1, [sp]
    4020565c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40205660:	9100c3ff 	add	sp, sp, #0x30
    40205664:	d65f03c0 	ret

0000000040205668 <compiler_builtins::int::specialized_div_rem::u128_div_rem>:
    40205668:	dac01049 	clz	x9, x2
    4020566c:	dac0106a 	clz	x10, x3
    40205670:	f100007f 	cmp	x3, #0x0
    40205674:	11010129 	add	w9, w9, #0x40
    40205678:	dac0100c 	clz	x12, x0
    4020567c:	1a89114b 	csel	w11, w10, w9, ne  // ne = any
    40205680:	dac01029 	clz	x9, x1
    40205684:	1101018a 	add	w10, w12, #0x40
    40205688:	f100003f 	cmp	x1, #0x0
    4020568c:	1a8a112f 	csel	w15, w9, w10, ne  // ne = any
    40205690:	6b0f0169 	subs	w9, w11, w15
    40205694:	54000149 	b.ls	402056bc <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x54>  // b.plast
    40205698:	7100fdff 	cmp	w15, #0x3f
    4020569c:	540001c9 	b.ls	402056d4 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x6c>  // b.plast
    402056a0:	9ac20809 	udiv	x9, x0, x2
    402056a4:	aa1f03ea 	mov	x10, xzr
    402056a8:	aa1f03e1 	mov	x1, xzr
    402056ac:	9b028120 	msub	x0, x9, x2, x0
    402056b0:	a9002909 	stp	x9, x10, [x8]
    402056b4:	a9010500 	stp	x0, x1, [x8, #16]
    402056b8:	d65f03c0 	ret
    402056bc:	eb02001f 	cmp	x0, x2
    402056c0:	fa03003f 	sbcs	xzr, x1, x3
    402056c4:	54000282 	b.cs	40205714 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0xac>  // b.hs, b.nlast
    402056c8:	a9007d1f 	stp	xzr, xzr, [x8]
    402056cc:	a9010500 	stp	x0, x1, [x8, #16]
    402056d0:	d65f03c0 	ret
    402056d4:	71017d7f 	cmp	w11, #0x5f
    402056d8:	540002a9 	b.ls	4020572c <compiler_builtins::int::specialized_div_rem::u128_div_rem+0xc4>  // b.plast
    402056dc:	2a0203e9 	mov	w9, w2
    402056e0:	9ac9082a 	udiv	x10, x1, x9
    402056e4:	1b02854b 	msub	w11, w10, w2, w1
    402056e8:	93c0816b 	extr	x11, x11, x0, #32
    402056ec:	9ac9096c 	udiv	x12, x11, x9
    402056f0:	1b02ad8b 	msub	w11, w12, w2, w11
    402056f4:	aa4c814a 	orr	x10, x10, x12, lsr #32
    402056f8:	b3607d60 	bfi	x0, x11, #32, #32
    402056fc:	9ac9080b 	udiv	x11, x0, x9
    40205700:	9b098160 	msub	x0, x11, x9, x0
    40205704:	aa0c8169 	orr	x9, x11, x12, lsl #32
    40205708:	a9002909 	stp	x9, x10, [x8]
    4020570c:	a9017d00 	stp	x0, xzr, [x8, #16]
    40205710:	d65f03c0 	ret
    40205714:	eb020000 	subs	x0, x0, x2
    40205718:	52800029 	mov	w9, #0x1                   	// #1
    4020571c:	da030021 	sbc	x1, x1, x3
    40205720:	a9007d09 	stp	x9, xzr, [x8]
    40205724:	a9010500 	stp	x0, x1, [x8, #16]
    40205728:	d65f03c0 	ret
    4020572c:	7100813f 	cmp	w9, #0x20
    40205730:	54000422 	b.cs	402057b4 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x14c>  // b.hs, b.nlast
    40205734:	d37ff829 	lsl	x9, x1, #1
    40205738:	5280080a 	mov	w10, #0x40                  	// #64
    4020573c:	d37ff86c 	lsl	x12, x3, #1
    40205740:	510005eb 	sub	w11, w15, #0x1
    40205744:	4b0f014a 	sub	w10, w10, w15
    40205748:	9acb2129 	lsl	x9, x9, x11
    4020574c:	9aca240d 	lsr	x13, x0, x10
    40205750:	9acb218b 	lsl	x11, x12, x11
    40205754:	9aca244c 	lsr	x12, x2, x10
    40205758:	9aca242e 	lsr	x14, x1, x10
    4020575c:	9aca246f 	lsr	x15, x3, x10
    40205760:	f27a015f 	tst	x10, #0x40
    40205764:	aa0d0129 	orr	x9, x9, x13
    40205768:	aa0c016a 	orr	x10, x11, x12
    4020576c:	9a8911c9 	csel	x9, x14, x9, ne  // ne = any
    40205770:	9a8a11ea 	csel	x10, x15, x10, ne  // ne = any
    40205774:	9aca0929 	udiv	x9, x9, x10
    40205778:	9bc97c4a 	umulh	x10, x2, x9
    4020577c:	9b097c6b 	mul	x11, x3, x9
    40205780:	9bc97c6d 	umulh	x13, x3, x9
    40205784:	9b097c4c 	mul	x12, x2, x9
    40205788:	ab0b014b 	adds	x11, x10, x11
    4020578c:	9a8d35aa 	cinc	x10, x13, cs  // cs = hs, nlast
    40205790:	b500090a 	cbnz	x10, 402058b0 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x248>
    40205794:	eb0c001f 	cmp	x0, x12
    40205798:	fa0b003f 	sbcs	xzr, x1, x11
    4020579c:	540008a3 	b.cc	402058b0 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x248>  // b.lo, b.ul, b.last
    402057a0:	eb0c0000 	subs	x0, x0, x12
    402057a4:	da0b0021 	sbc	x1, x1, x11
    402057a8:	a9007d09 	stp	x9, xzr, [x8]
    402057ac:	a9010500 	stp	x0, x1, [x8, #16]
    402057b0:	d65f03c0 	ret
    402057b4:	52800c0d 	mov	w13, #0x60                  	// #96
    402057b8:	d37ff86c 	lsl	x12, x3, #1
    402057bc:	5101856e 	sub	w14, w11, #0x61
    402057c0:	4b0b01ad 	sub	w13, w13, w11
    402057c4:	aa1f03e9 	mov	x9, xzr
    402057c8:	aa1f03ea 	mov	x10, xzr
    402057cc:	9ace218e 	lsl	x14, x12, x14
    402057d0:	9acd2450 	lsr	x16, x2, x13
    402057d4:	9acd2471 	lsr	x17, x3, x13
    402057d8:	f27a01bf 	tst	x13, #0x40
    402057dc:	aa1001ce 	orr	x14, x14, x16
    402057e0:	52800810 	mov	w16, #0x40                  	// #64
    402057e4:	9a8e122e 	csel	x14, x17, x14, ne  // ne = any
    402057e8:	2a0e03ee 	mov	w14, w14
    402057ec:	910005ce 	add	x14, x14, #0x1
    402057f0:	d37ff832 	lsl	x18, x1, #1
    402057f4:	4b0f0211 	sub	w17, w16, w15
    402057f8:	510005ef 	sub	w15, w15, #0x1
    402057fc:	9ad12424 	lsr	x4, x1, x17
    40205800:	f27a023f 	tst	x17, #0x40
    40205804:	9acf224f 	lsl	x15, x18, x15
    40205808:	9ad12412 	lsr	x18, x0, x17
    4020580c:	aa1201ef 	orr	x15, x15, x18
    40205810:	9a8f1092 	csel	x18, x4, x15, ne  // ne = any
    40205814:	6b0d022f 	subs	w15, w17, w13
    40205818:	540005c3 	b.cc	402058d0 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x268>  // b.lo, b.ul, b.last
    4020581c:	9ace0a51 	udiv	x17, x18, x14
    40205820:	2a2f03e6 	mvn	w6, w15
    40205824:	f27a01ff 	tst	x15, #0x40
    40205828:	9bd17c52 	umulh	x18, x2, x17
    4020582c:	d341fe25 	lsr	x5, x17, #1
    40205830:	9b117c44 	mul	x4, x2, x17
    40205834:	9ac624a5 	lsr	x5, x5, x6
    40205838:	9b114872 	madd	x18, x3, x17, x18
    4020583c:	9acf2231 	lsl	x17, x17, x15
    40205840:	d341fc87 	lsr	x7, x4, #1
    40205844:	9ac624e6 	lsr	x6, x7, x6
    40205848:	9acf2252 	lsl	x18, x18, x15
    4020584c:	9acf208f 	lsl	x15, x4, x15
    40205850:	9a851224 	csel	x4, x17, x5, ne  // ne = any
    40205854:	9a9113f1 	csel	x17, xzr, x17, ne  // ne = any
    40205858:	aa060252 	orr	x18, x18, x6
    4020585c:	9a9211f2 	csel	x18, x15, x18, ne  // ne = any
    40205860:	9a8f13ef 	csel	x15, xzr, x15, ne  // ne = any
    40205864:	ab090229 	adds	x9, x17, x9
    40205868:	9a0a008a 	adc	x10, x4, x10
    4020586c:	eb0f0000 	subs	x0, x0, x15
    40205870:	fa120021 	sbcs	x1, x1, x18
    40205874:	dac0100f 	clz	x15, x0
    40205878:	dac01031 	clz	x17, x1
    4020587c:	110101ef 	add	w15, w15, #0x40
    40205880:	1a8f122f 	csel	w15, w17, w15, ne  // ne = any
    40205884:	6b0f017f 	cmp	w11, w15
    40205888:	54000549 	b.ls	40205930 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x2c8>  // b.plast
    4020588c:	7100fdff 	cmp	w15, #0x3f
    40205890:	54fffb09 	b.ls	402057f0 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x188>  // b.plast
    40205894:	9ac2080b 	udiv	x11, x0, x2
    40205898:	9b028160 	msub	x0, x11, x2, x0
    4020589c:	ab0b0129 	adds	x9, x9, x11
    402058a0:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    402058a4:	a9002909 	stp	x9, x10, [x8]
    402058a8:	a9017d00 	stp	x0, xzr, [x8, #16]
    402058ac:	d65f03c0 	ret
    402058b0:	ab00004d 	adds	x13, x2, x0
    402058b4:	d1000529 	sub	x9, x9, #0x1
    402058b8:	9a01006e 	adc	x14, x3, x1
    402058bc:	eb0c01a0 	subs	x0, x13, x12
    402058c0:	da0b01c1 	sbc	x1, x14, x11
    402058c4:	a9007d09 	stp	x9, xzr, [x8]
    402058c8:	a9010500 	stp	x0, x1, [x8, #16]
    402058cc:	d65f03c0 	ret
    402058d0:	2a3103eb 	mvn	w11, w17
    402058d4:	9ad1244d 	lsr	x13, x2, x17
    402058d8:	f27a023f 	tst	x17, #0x40
    402058dc:	9acb218b 	lsl	x11, x12, x11
    402058e0:	9ad1246c 	lsr	x12, x3, x17
    402058e4:	aa0d016b 	orr	x11, x11, x13
    402058e8:	9a8b118b 	csel	x11, x12, x11, ne  // ne = any
    402058ec:	9acb0a4d 	udiv	x13, x18, x11
    402058f0:	9bcd7c4b 	umulh	x11, x2, x13
    402058f4:	9b0d7c4c 	mul	x12, x2, x13
    402058f8:	9b0d2c6b 	madd	x11, x3, x13, x11
    402058fc:	eb0c001f 	cmp	x0, x12
    40205900:	fa0b003f 	sbcs	xzr, x1, x11
    40205904:	540002a2 	b.cs	40205958 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x2f0>  // b.hs, b.nlast
    40205908:	d10005ad 	sub	x13, x13, #0x1
    4020590c:	ab0d0129 	adds	x9, x9, x13
    40205910:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40205914:	ab02000d 	adds	x13, x0, x2
    40205918:	9a03002e 	adc	x14, x1, x3
    4020591c:	eb0c01a0 	subs	x0, x13, x12
    40205920:	da0b01c1 	sbc	x1, x14, x11
    40205924:	a9002909 	stp	x9, x10, [x8]
    40205928:	a9010500 	stp	x0, x1, [x8, #16]
    4020592c:	d65f03c0 	ret
    40205930:	eb02001f 	cmp	x0, x2
    40205934:	fa03003f 	sbcs	xzr, x1, x3
    40205938:	54ffebc3 	b.cc	402056b0 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x48>  // b.lo, b.ul, b.last
    4020593c:	b1000529 	adds	x9, x9, #0x1
    40205940:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40205944:	eb020000 	subs	x0, x0, x2
    40205948:	da030021 	sbc	x1, x1, x3
    4020594c:	a9002909 	stp	x9, x10, [x8]
    40205950:	a9010500 	stp	x0, x1, [x8, #16]
    40205954:	d65f03c0 	ret
    40205958:	ab0d0129 	adds	x9, x9, x13
    4020595c:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40205960:	eb0c0000 	subs	x0, x0, x12
    40205964:	da0b0021 	sbc	x1, x1, x11
    40205968:	a9002909 	stp	x9, x10, [x8]
    4020596c:	a9010500 	stp	x0, x1, [x8, #16]
    40205970:	d65f03c0 	ret

0000000040205974 <memcpy>:
    40205974:	f100405f 	cmp	x2, #0x10
    40205978:	54000723 	b.cc	40205a5c <memcpy+0xe8>  // b.lo, b.ul, b.last
    4020597c:	cb0003ec 	neg	x12, x0
    40205980:	92400988 	and	x8, x12, #0x7
    40205984:	8b080009 	add	x9, x0, x8
    40205988:	eb09001f 	cmp	x0, x9
    4020598c:	54000422 	b.cs	40205a10 <memcpy+0x9c>  // b.hs, b.nlast
    40205990:	f100111f 	cmp	x8, #0x4
    40205994:	aa0003ea 	mov	x10, x0
    40205998:	aa0103eb 	mov	x11, x1
    4020599c:	54000323 	b.cc	40205a00 <memcpy+0x8c>  // b.lo, b.ul, b.last
    402059a0:	cb01000a 	sub	x10, x0, x1
    402059a4:	aa0103eb 	mov	x11, x1
    402059a8:	f100815f 	cmp	x10, #0x20
    402059ac:	aa0003ea 	mov	x10, x0
    402059b0:	54000283 	b.cc	40205a00 <memcpy+0x8c>  // b.lo, b.ul, b.last
    402059b4:	927e018c 	and	x12, x12, #0x4
    402059b8:	aa0003ed 	mov	x13, x0
    402059bc:	aa0103ee 	mov	x14, x1
    402059c0:	8b0c000a 	add	x10, x0, x12
    402059c4:	8b0c002b 	add	x11, x1, x12
    402059c8:	aa0c03ef 	mov	x15, x12
    402059cc:	39400dd0 	ldrb	w16, [x14, #3]
    402059d0:	394009d1 	ldrb	w17, [x14, #2]
    402059d4:	f10011ef 	subs	x15, x15, #0x4
    402059d8:	394001d2 	ldrb	w18, [x14]
    402059dc:	394005c3 	ldrb	w3, [x14, #1]
    402059e0:	910011ce 	add	x14, x14, #0x4
    402059e4:	39000db0 	strb	w16, [x13, #3]
    402059e8:	390009b1 	strb	w17, [x13, #2]
    402059ec:	390005a3 	strb	w3, [x13, #1]
    402059f0:	380045b2 	strb	w18, [x13], #4
    402059f4:	54fffec1 	b.ne	402059cc <memcpy+0x58>  // b.any
    402059f8:	eb0c011f 	cmp	x8, x12
    402059fc:	540000a0 	b.eq	40205a10 <memcpy+0x9c>  // b.none
    40205a00:	3840156c 	ldrb	w12, [x11], #1
    40205a04:	3800154c 	strb	w12, [x10], #1
    40205a08:	eb09015f 	cmp	x10, x9
    40205a0c:	54ffffa1 	b.ne	40205a00 <memcpy+0x8c>  // b.any
    40205a10:	cb08004b 	sub	x11, x2, x8
    40205a14:	8b08002a 	add	x10, x1, x8
    40205a18:	927df16c 	and	x12, x11, #0xfffffffffffffff8
    40205a1c:	f240095f 	tst	x10, #0x7
    40205a20:	8b0c0128 	add	x8, x9, x12
    40205a24:	540007a1 	b.ne	40205b18 <memcpy+0x1a4>  // b.any
    40205a28:	eb08013f 	cmp	x9, x8
    40205a2c:	540000c2 	b.cs	40205a44 <memcpy+0xd0>  // b.hs, b.nlast
    40205a30:	aa0a03ed 	mov	x13, x10
    40205a34:	f84085ae 	ldr	x14, [x13], #8
    40205a38:	f800852e 	str	x14, [x9], #8
    40205a3c:	eb08013f 	cmp	x9, x8
    40205a40:	54ffffa3 	b.cc	40205a34 <memcpy+0xc0>  // b.lo, b.ul, b.last
    40205a44:	8b0c0141 	add	x1, x10, x12
    40205a48:	92400962 	and	x2, x11, #0x7
    40205a4c:	8b020109 	add	x9, x8, x2
    40205a50:	eb09011f 	cmp	x8, x9
    40205a54:	540000c3 	b.cc	40205a6c <memcpy+0xf8>  // b.lo, b.ul, b.last
    40205a58:	1400002f 	b	40205b14 <memcpy+0x1a0>
    40205a5c:	aa0003e8 	mov	x8, x0
    40205a60:	8b020009 	add	x9, x0, x2
    40205a64:	eb09001f 	cmp	x0, x9
    40205a68:	54000562 	b.cs	40205b14 <memcpy+0x1a0>  // b.hs, b.nlast
    40205a6c:	f100105f 	cmp	x2, #0x4
    40205a70:	540004a3 	b.cc	40205b04 <memcpy+0x190>  // b.lo, b.ul, b.last
    40205a74:	cb01010a 	sub	x10, x8, x1
    40205a78:	f100815f 	cmp	x10, #0x20
    40205a7c:	54000443 	b.cc	40205b04 <memcpy+0x190>  // b.lo, b.ul, b.last
    40205a80:	39400c2a 	ldrb	w10, [x1, #3]
    40205a84:	3940082b 	ldrb	w11, [x1, #2]
    40205a88:	3940002c 	ldrb	w12, [x1]
    40205a8c:	3940042d 	ldrb	w13, [x1, #1]
    40205a90:	39000d0a 	strb	w10, [x8, #3]
    40205a94:	927e044a 	and	x10, x2, #0xc
    40205a98:	f100115f 	cmp	x10, #0x4
    40205a9c:	3900090b 	strb	w11, [x8, #2]
    40205aa0:	3900050d 	strb	w13, [x8, #1]
    40205aa4:	3900010c 	strb	w12, [x8]
    40205aa8:	54000260 	b.eq	40205af4 <memcpy+0x180>  // b.none
    40205aac:	39401c2b 	ldrb	w11, [x1, #7]
    40205ab0:	3940182c 	ldrb	w12, [x1, #6]
    40205ab4:	f100215f 	cmp	x10, #0x8
    40205ab8:	3940102d 	ldrb	w13, [x1, #4]
    40205abc:	3940142e 	ldrb	w14, [x1, #5]
    40205ac0:	39001d0b 	strb	w11, [x8, #7]
    40205ac4:	3900190c 	strb	w12, [x8, #6]
    40205ac8:	3900150e 	strb	w14, [x8, #5]
    40205acc:	3900110d 	strb	w13, [x8, #4]
    40205ad0:	54000120 	b.eq	40205af4 <memcpy+0x180>  // b.none
    40205ad4:	39402c2b 	ldrb	w11, [x1, #11]
    40205ad8:	3940282c 	ldrb	w12, [x1, #10]
    40205adc:	3940202d 	ldrb	w13, [x1, #8]
    40205ae0:	3940242e 	ldrb	w14, [x1, #9]
    40205ae4:	39002d0b 	strb	w11, [x8, #11]
    40205ae8:	3900290c 	strb	w12, [x8, #10]
    40205aec:	3900250e 	strb	w14, [x8, #9]
    40205af0:	3900210d 	strb	w13, [x8, #8]
    40205af4:	eb0a005f 	cmp	x2, x10
    40205af8:	540000e0 	b.eq	40205b14 <memcpy+0x1a0>  // b.none
    40205afc:	8b0a0108 	add	x8, x8, x10
    40205b00:	8b0a0021 	add	x1, x1, x10
    40205b04:	3840142a 	ldrb	w10, [x1], #1
    40205b08:	3800150a 	strb	w10, [x8], #1
    40205b0c:	eb09011f 	cmp	x8, x9
    40205b10:	54ffffa1 	b.ne	40205b04 <memcpy+0x190>  // b.any
    40205b14:	d65f03c0 	ret
    40205b18:	eb08013f 	cmp	x9, x8
    40205b1c:	54fff942 	b.cs	40205a44 <memcpy+0xd0>  // b.hs, b.nlast
    40205b20:	aa0a03ed 	mov	x13, x10
    40205b24:	aa0d03f0 	mov	x16, x13
    40205b28:	394009af 	ldrb	w15, [x13, #2]
    40205b2c:	394005ae 	ldrb	w14, [x13, #1]
    40205b30:	38404e11 	ldrb	w17, [x16, #4]!
    40205b34:	39400a12 	ldrb	w18, [x16, #2]
    40205b38:	394001a1 	ldrb	w1, [x13]
    40205b3c:	39400da2 	ldrb	w2, [x13, #3]
    40205b40:	d370bdef 	lsl	x15, x15, #16
    40205b44:	394015a3 	ldrb	w3, [x13, #5]
    40205b48:	39400e10 	ldrb	w16, [x16, #3]
    40205b4c:	53103e52 	lsl	w18, w18, #16
    40205b50:	aa0e202e 	orr	x14, x1, x14, lsl #8
    40205b54:	aa0261ef 	orr	x15, x15, x2, lsl #24
    40205b58:	910021ad 	add	x13, x13, #0x8
    40205b5c:	2a032231 	orr	w17, w17, w3, lsl #8
    40205b60:	2a106250 	orr	w16, w18, w16, lsl #24
    40205b64:	aa0e01ee 	orr	x14, x15, x14
    40205b68:	2a11020f 	orr	w15, w16, w17
    40205b6c:	aa0f81ce 	orr	x14, x14, x15, lsl #32
    40205b70:	f800852e 	str	x14, [x9], #8
    40205b74:	eb08013f 	cmp	x9, x8
    40205b78:	54fffd63 	b.cc	40205b24 <memcpy+0x1b0>  // b.lo, b.ul, b.last
    40205b7c:	17ffffb2 	b	40205a44 <memcpy+0xd0>

0000000040205b80 <__umodti3>:
    40205b80:	d100c3ff 	sub	sp, sp, #0x30
    40205b84:	a9027bfd 	stp	x29, x30, [sp, #32]
    40205b88:	910083fd 	add	x29, sp, #0x20
    40205b8c:	910003e8 	mov	x8, sp
    40205b90:	97fffeb6 	bl	40205668 <compiler_builtins::int::specialized_div_rem::u128_div_rem>
    40205b94:	a94107e0 	ldp	x0, x1, [sp, #16]
    40205b98:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40205b9c:	9100c3ff 	add	sp, sp, #0x30
    40205ba0:	d65f03c0 	ret

0000000040205ba4 <memset>:
    40205ba4:	f100405f 	cmp	x2, #0x10
    40205ba8:	540009e3 	b.cc	40205ce4 <memset+0x140>  // b.lo, b.ul, b.last
    40205bac:	cb0003eb 	neg	x11, x0
    40205bb0:	92400968 	and	x8, x11, #0x7
    40205bb4:	8b080009 	add	x9, x0, x8
    40205bb8:	eb09001f 	cmp	x0, x9
    40205bbc:	54000302 	b.cs	40205c1c <memset+0x78>  // b.hs, b.nlast
    40205bc0:	f100111f 	cmp	x8, #0x4
    40205bc4:	aa0003ea 	mov	x10, x0
    40205bc8:	54000243 	b.cc	40205c10 <memset+0x6c>  // b.lo, b.ul, b.last
    40205bcc:	0e020c20 	dup	v0.4h, w1
    40205bd0:	927e016b 	and	x11, x11, #0x4
    40205bd4:	aa0003ec 	mov	x12, x0
    40205bd8:	8b0b000a 	add	x10, x0, x11
    40205bdc:	aa0b03ed 	mov	x13, x11
    40205be0:	5e0e0401 	mov	h1, v0.h[3]
    40205be4:	5e0a0402 	mov	h2, v0.h[2]
    40205be8:	5e060403 	mov	h3, v0.h[1]
    40205bec:	3d000180 	str	b0, [x12]
    40205bf0:	f10011ad 	subs	x13, x13, #0x4
    40205bf4:	3c003181 	stur	b1, [x12, #3]
    40205bf8:	3c002182 	stur	b2, [x12, #2]
    40205bfc:	3c001183 	stur	b3, [x12, #1]
    40205c00:	9100118c 	add	x12, x12, #0x4
    40205c04:	54ffff41 	b.ne	40205bec <memset+0x48>  // b.any
    40205c08:	eb0b011f 	cmp	x8, x11
    40205c0c:	54000080 	b.eq	40205c1c <memset+0x78>  // b.none
    40205c10:	38001541 	strb	w1, [x10], #1
    40205c14:	eb09015f 	cmp	x10, x9
    40205c18:	54ffffc1 	b.ne	40205c10 <memset+0x6c>  // b.any
    40205c1c:	cb08004a 	sub	x10, x2, x8
    40205c20:	927df148 	and	x8, x10, #0xfffffffffffffff8
    40205c24:	8b080128 	add	x8, x9, x8
    40205c28:	eb08013f 	cmp	x9, x8
    40205c2c:	54000102 	b.cs	40205c4c <memset+0xa8>  // b.hs, b.nlast
    40205c30:	12001c2b 	and	w11, w1, #0xff
    40205c34:	3200c3ec 	mov	w12, #0x1010101             	// #16843009
    40205c38:	1b0c7d6b 	mul	w11, w11, w12
    40205c3c:	aa0b816b 	orr	x11, x11, x11, lsl #32
    40205c40:	f800852b 	str	x11, [x9], #8
    40205c44:	eb08013f 	cmp	x9, x8
    40205c48:	54ffffc3 	b.cc	40205c40 <memset+0x9c>  // b.lo, b.ul, b.last
    40205c4c:	92400942 	and	x2, x10, #0x7
    40205c50:	8b020109 	add	x9, x8, x2
    40205c54:	eb09011f 	cmp	x8, x9
    40205c58:	54000442 	b.cs	40205ce0 <memset+0x13c>  // b.hs, b.nlast
    40205c5c:	f100105f 	cmp	x2, #0x4
    40205c60:	540003a3 	b.cc	40205cd4 <memset+0x130>  // b.lo, b.ul, b.last
    40205c64:	927e044a 	and	x10, x2, #0xc
    40205c68:	39000d01 	strb	w1, [x8, #3]
    40205c6c:	f100115f 	cmp	x10, #0x4
    40205c70:	8b0a010b 	add	x11, x8, x10
    40205c74:	39000901 	strb	w1, [x8, #2]
    40205c78:	39000501 	strb	w1, [x8, #1]
    40205c7c:	39000101 	strb	w1, [x8]
    40205c80:	54000240 	b.eq	40205cc8 <memset+0x124>  // b.none
    40205c84:	0e020c20 	dup	v0.4h, w1
    40205c88:	f100215f 	cmp	x10, #0x8
    40205c8c:	5e0e0401 	mov	h1, v0.h[3]
    40205c90:	5e0a0402 	mov	h2, v0.h[2]
    40205c94:	5e060403 	mov	h3, v0.h[1]
    40205c98:	3c004100 	stur	b0, [x8, #4]
    40205c9c:	3c007101 	stur	b1, [x8, #7]
    40205ca0:	3c006102 	stur	b2, [x8, #6]
    40205ca4:	3c005103 	stur	b3, [x8, #5]
    40205ca8:	54000100 	b.eq	40205cc8 <memset+0x124>  // b.none
    40205cac:	5e0e0401 	mov	h1, v0.h[3]
    40205cb0:	5e0a0402 	mov	h2, v0.h[2]
    40205cb4:	3c008100 	stur	b0, [x8, #8]
    40205cb8:	5e060403 	mov	h3, v0.h[1]
    40205cbc:	3c00b101 	stur	b1, [x8, #11]
    40205cc0:	3c00a102 	stur	b2, [x8, #10]
    40205cc4:	3c009103 	stur	b3, [x8, #9]
    40205cc8:	eb0a005f 	cmp	x2, x10
    40205ccc:	aa0b03e8 	mov	x8, x11
    40205cd0:	54000080 	b.eq	40205ce0 <memset+0x13c>  // b.none
    40205cd4:	38001501 	strb	w1, [x8], #1
    40205cd8:	eb09011f 	cmp	x8, x9
    40205cdc:	54ffffc1 	b.ne	40205cd4 <memset+0x130>  // b.any
    40205ce0:	d65f03c0 	ret
    40205ce4:	aa0003e8 	mov	x8, x0
    40205ce8:	8b020009 	add	x9, x0, x2
    40205cec:	eb09001f 	cmp	x0, x9
    40205cf0:	54fffb63 	b.cc	40205c5c <memset+0xb8>  // b.lo, b.ul, b.last
    40205cf4:	17fffffb 	b	40205ce0 <memset+0x13c>
