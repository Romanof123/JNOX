
source-WF.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000040200000 <_start>:
    40200000:	d5034fdf 	msr	daifset, #0xf
    40200004:	d5384240 	mrs	x0, currentel
    40200008:	f100101f 	cmp	x0, #0x4
    4020000c:	54000241 	b.ne	40200054 <_start+0x54>  // b.any
    40200010:	d50041bf 	msr	spsel, #0x1
    40200014:	58000260 	ldr	x0, 40200060 <_start+0x60>
    40200018:	9100001f 	mov	sp, x0
    4020001c:	d5381040 	mrs	x0, cpacr_el1
    40200020:	b26c0400 	orr	x0, x0, #0x300000
    40200024:	d5181040 	msr	cpacr_el1, x0
    40200028:	d5033fdf 	isb
    4020002c:	580001e0 	ldr	x0, 40200068 <_start+0x68>
    40200030:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    40200034:	f9000001 	str	x1, [x0]
    40200038:	580001c0 	ldr	x0, 40200070 <_start+0x70>
    4020003c:	580001e1 	ldr	x1, 40200078 <_start+0x78>
    40200040:	eb01001f 	cmp	x0, x1
    40200044:	54000062 	b.cs	40200050 <_start+0x50>  // b.hs, b.nlast
    40200048:	f800841f 	str	xzr, [x0], #8
    4020004c:	17fffffd 	b	40200040 <_start+0x40>
    40200050:	14001066 	b	402041e8 <jnox_kernel::kernel_main>
    40200054:	d503205f 	wfe
    40200058:	17ffffff 	b	40200054 <_start+0x54>
    4020005c:	00000000 	udf	#0
    40200060:	40227e40 	.word	0x40227e40
    40200064:	00000000 	.word	0x00000000
    40200068:	40223e20 	.word	0x40223e20
    4020006c:	00000000 	.word	0x00000000
    40200070:	40207710 	.word	0x40207710
    40200074:	00000000 	.word	0x00000000
    40200078:	40223e40 	.word	0x40223e40
	...

0000000040200800 <sched_vectors>:
    40200800:	14000200 00000000 00000000 00000000     ................
	...
    40200880:	140001e0 00000000 00000000 00000000     ................
	...
    40200900:	140001c0 00000000 00000000 00000000     ................
	...
    40200980:	140001a0 00000000 00000000 00000000     ................
	...
    40200a00:	140001b6 00000000 00000000 00000000     ................
	...
    40200a80:	14000161 00000000 00000000 00000000     a...............
	...
    40200b00:	14000140 00000000 00000000 00000000     @...............
	...
    40200b80:	14000120 00000000 00000000 00000000      ...............
	...
    40200c00:	14000100 00000000 00000000 00000000     ................
	...
    40200c80:	140000e0 00000000 00000000 00000000     ................
	...
    40200d00:	140000c0 00000000 00000000 00000000     ................
	...
    40200d80:	140000a0 00000000 00000000 00000000     ................
	...
    40200e00:	14000080 00000000 00000000 00000000     ................
	...
    40200e80:	14000060 00000000 00000000 00000000     `...............
	...
    40200f00:	14000040 00000000 00000000 00000000     @...............
	...
    40200f80:	14000020 00000000 00000000 00000000      ...............
	...
    40201000:	140000aa d10d03ff f90027e9 d5033fdf     .........'...?..
    40201010:	d53be029 f9009fe9 f94027e9 a90007e0     ).;......'@.....
    40201020:	a9010fe2 a90217e4 a9031fe6 a90427e8     .............'..
    40201030:	a9052fea a90637ec a9073fee a90847f0     ./...7...?...G..
    40201040:	a9094ff2 a90a57f4 a90b5ff6 a90c67f8     .O...W..._...g..
    40201050:	a90d6ffa a90e77fc f9007bfe ad0a07e0     .o...w...{......
    40201060:	ad0b0fe2 ad0c17e4 ad0d1fe6 ad0e27e8     .............'..
    40201070:	ad0f2fea ad1037ec ad113fee ad1247f0     ./...7...?...G..
    40201080:	ad134ff2 ad1457f4 ad155ff6 ad1667f8     .O...W..._...g..
    40201090:	ad176ffa ad1877fc ad197ffe d5384029     .o...w......)@8.
    402010a0:	d538400a a90fabe9 d53b4409 d53b442a     .@8......D;.*D;.
    402010b0:	a910abe9 d538d089 d538410a a911abe9     ......8..A8.....
    402010c0:	d53bd049 d53bd06a a912abe9 910003e0     I.;.j.;.........
    402010d0:	9400007e 14000036 d10d03ff f90027e9     ~...6........'..
    402010e0:	d5033fdf d53be029 f9009fe9 f94027e9     .?..).;......'@.
    402010f0:	a90007e0 a9010fe2 a90217e4 a9031fe6     ................
    40201100:	a90427e8 a9052fea a90637ec a9073fee     .'.../...7...?..
    40201110:	a90847f0 a9094ff2 a90a57f4 a90b5ff6     .G...O...W..._..
    40201120:	a90c67f8 a90d6ffa a90e77fc f9007bfe     .g...o...w...{..
    40201130:	ad0a07e0 ad0b0fe2 ad0c17e4 ad0d1fe6     ................
    40201140:	ad0e27e8 ad0f2fea ad1037ec ad113fee     .'.../...7...?..
    40201150:	ad1247f0 ad134ff2 ad1457f4 ad155ff6     .G...O...W..._..
    40201160:	ad1667f8 ad176ffa ad1877fc ad197ffe     .g...o...w......
    40201170:	d5384029 d538400a a90fabe9 d53b4409     )@8..@8......D;.
    40201180:	d53b442a a910abe9 d538d089 d538410a     *D;.......8..A8.
    40201190:	a911abe9 d53bd049 d53bd06a a912abe9     ....I.;.j.;.....
    402011a0:	910003e0 940003b2 14000001              ............

00000000402011ac <sched_start_frame>:
    402011ac:	9100001f 	mov	sp, x0
    402011b0:	a94fabe9 	ldp	x9, x10, [sp, #248]
    402011b4:	d5184029 	msr	elr_el1, x9
    402011b8:	d518400a 	msr	spsr_el1, x10
    402011bc:	a950abe9 	ldp	x9, x10, [sp, #264]
    402011c0:	d51b4409 	msr	fpcr, x9
    402011c4:	d51b442a 	msr	fpsr, x10
    402011c8:	a951abe9 	ldp	x9, x10, [sp, #280]
    402011cc:	d518d089 	msr	tpidr_el1, x9
    402011d0:	d518410a 	msr	sp_el0, x10
    402011d4:	a952abe9 	ldp	x9, x10, [sp, #296]
    402011d8:	d51bd049 	msr	tpidr_el0, x9
    402011dc:	d51bd06a 	msr	tpidrro_el0, x10
    402011e0:	ad4a07e0 	ldp	q0, q1, [sp, #320]
    402011e4:	ad4b0fe2 	ldp	q2, q3, [sp, #352]
    402011e8:	ad4c17e4 	ldp	q4, q5, [sp, #384]
    402011ec:	ad4d1fe6 	ldp	q6, q7, [sp, #416]
    402011f0:	ad4e27e8 	ldp	q8, q9, [sp, #448]
    402011f4:	ad4f2fea 	ldp	q10, q11, [sp, #480]
    402011f8:	ad5037ec 	ldp	q12, q13, [sp, #512]
    402011fc:	ad513fee 	ldp	q14, q15, [sp, #544]
    40201200:	ad5247f0 	ldp	q16, q17, [sp, #576]
    40201204:	ad534ff2 	ldp	q18, q19, [sp, #608]
    40201208:	ad5457f4 	ldp	q20, q21, [sp, #640]
    4020120c:	ad555ff6 	ldp	q22, q23, [sp, #672]
    40201210:	ad5667f8 	ldp	q24, q25, [sp, #704]
    40201214:	ad576ffa 	ldp	q26, q27, [sp, #736]
    40201218:	ad5877fc 	ldp	q28, q29, [sp, #768]
    4020121c:	ad597ffe 	ldp	q30, q31, [sp, #800]
    40201220:	d503201f 	nop
    40201224:	10112e29 	adr	x9, 402237e8 <jnox_ap_returns>
    40201228:	f940012a 	ldr	x10, [x9]
    4020122c:	f101015f 	cmp	x10, #0x40
    40201230:	54ffee82 	b.cs	40201000 <sched_vectors+0x800>  // b.hs, b.nlast
    40201234:	9100054b 	add	x11, x10, #0x1
    40201238:	f800852b 	str	x11, [x9], #8
    4020123c:	d280030b 	mov	x11, #0x18                  	// #24
    40201240:	9b0b2549 	madd	x9, x10, x11, x9
    40201244:	910003ea 	mov	x10, sp
    40201248:	d538402b 	mrs	x11, elr_el1
    4020124c:	a9002d2a 	stp	x10, x11, [x9]
    40201250:	d5033fdf 	isb
    40201254:	d53be02a 	mrs	x10, cntpct_el0
    40201258:	f900092a 	str	x10, [x9, #16]
    4020125c:	a94007e0 	ldp	x0, x1, [sp]
    40201260:	a9410fe2 	ldp	x2, x3, [sp, #16]
    40201264:	a94217e4 	ldp	x4, x5, [sp, #32]
    40201268:	a9431fe6 	ldp	x6, x7, [sp, #48]
    4020126c:	a94427e8 	ldp	x8, x9, [sp, #64]
    40201270:	a9452fea 	ldp	x10, x11, [sp, #80]
    40201274:	a94637ec 	ldp	x12, x13, [sp, #96]
    40201278:	a9473fee 	ldp	x14, x15, [sp, #112]
    4020127c:	a94847f0 	ldp	x16, x17, [sp, #128]
    40201280:	a9494ff2 	ldp	x18, x19, [sp, #144]
    40201284:	a94a57f4 	ldp	x20, x21, [sp, #160]
    40201288:	a94b5ff6 	ldp	x22, x23, [sp, #176]
    4020128c:	a94c67f8 	ldp	x24, x25, [sp, #192]
    40201290:	a94d6ffa 	ldp	x26, x27, [sp, #208]
    40201294:	a94e77fc 	ldp	x28, x29, [sp, #224]
    40201298:	f9407bfe 	ldr	x30, [sp, #240]
    4020129c:	910d03ff 	add	sp, sp, #0x340
    402012a0:	d5033f5f 	clrex
    402012a4:	d69f03e0 	eret

00000000402012a8 <jnox_kernel::ordinary_reservations::unexpected>:
    402012a8:	f81f0ffe 	str	x30, [sp, #-16]!
    402012ac:	52800060 	mov	w0, #0x3                   	// #3
    402012b0:	52800021 	mov	w1, #0x1                   	// #1
    402012b4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    402012b8:	52800043 	mov	w3, #0x2                   	// #2
    402012bc:	aa1f03e4 	mov	x4, xzr
    402012c0:	aa1f03e5 	mov	x5, xzr
    402012c4:	940004fa 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>

00000000402012c8 <jnox_kernel::ordinary_reservations::irq>:
    402012c8:	d10583ff 	sub	sp, sp, #0x160
    402012cc:	a9107bfd 	stp	x29, x30, [sp, #256]
    402012d0:	a9116ffc 	stp	x28, x27, [sp, #272]
    402012d4:	a91267fa 	stp	x26, x25, [sp, #288]
    402012d8:	a9135ff8 	stp	x24, x23, [sp, #304]
    402012dc:	a91457f6 	stp	x22, x21, [sp, #320]
    402012e0:	a9154ff4 	stp	x20, x19, [sp, #336]
    402012e4:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402012e8:	f9420108 	ldr	x8, [x8, #1024]
    402012ec:	f100091f 	cmp	x8, #0x2
    402012f0:	54003220 	b.eq	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.none
    402012f4:	aa0003f4 	mov	x20, x0
    402012f8:	d0000038 	adrp	x24, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402012fc:	d503201f 	nop
    40201300:	100b2119 	adr	x25, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766>
    40201304:	f942b308 	ldr	x8, [x24, #1376]
    40201308:	8b083b29 	add	x9, x25, x8, lsl #14
    4020130c:	eb00013f 	cmp	x9, x0
    40201310:	54003128 	b.hi	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.pmore
    40201314:	b10d069f 	cmn	x20, #0x341
    40201318:	540030e8 	b.hi	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.pmore
    4020131c:	d372c508 	lsl	x8, x8, #14
    40201320:	8b080328 	add	x8, x25, x8
    40201324:	91401108 	add	x8, x8, #0x4, lsl #12
    40201328:	910d0289 	add	x9, x20, #0x340
    4020132c:	eb08013f 	cmp	x9, x8
    40201330:	54003028 	b.hi	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.pmore
    40201334:	5280019a 	mov	w26, #0xc                   	// #12
    40201338:	72a1003a 	movk	w26, #0x801, lsl #16
    4020133c:	f9409e95 	ldr	x21, [x20, #312]
    40201340:	b9400356 	ldr	w22, [x26]
    40201344:	d53be237 	mrs	x23, cntp_ctl_el0
    40201348:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020134c:	91156129 	add	x9, x9, #0x558
    40201350:	f9401928 	ldr	x8, [x9, #48]
    40201354:	f9400133 	ldr	x19, [x9]
    40201358:	f100051f 	cmp	x8, #0x1
    4020135c:	540000e0 	b.eq	40201378 <jnox_kernel::ordinary_reservations::irq+0xb0>  // b.none
    40201360:	b100067f 	cmn	x19, #0x1
    40201364:	54000060 	b.eq	40201370 <jnox_kernel::ordinary_reservations::irq+0xa8>  // b.none
    40201368:	91000673 	add	x19, x19, #0x1
    4020136c:	14000003 	b	40201378 <jnox_kernel::ordinary_reservations::irq+0xb0>
    40201370:	b4004448 	cbz	x8, 40201bf8 <jnox_kernel::ordinary_reservations::irq+0x930>
    40201374:	aa1f03f3 	mov	x19, xzr
    40201378:	d000003b 	adrp	x27, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020137c:	9115837b 	add	x27, x27, #0x560
    40201380:	f9401369 	ldr	x9, [x27, #32]
    40201384:	a90923e9 	stp	x9, x8, [sp, #144]
    40201388:	f9400363 	ldr	x3, [x27]
    4020138c:	a90a5ff6 	stp	x22, x23, [sp, #160]
    40201390:	910243e4 	add	x4, sp, #0x90
    40201394:	52800080 	mov	w0, #0x4                   	// #4
    40201398:	aa1503e1 	mov	x1, x21
    4020139c:	aa1303e2 	mov	x2, x19
    402013a0:	9400046c 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    402013a4:	f9401368 	ldr	x8, [x27, #32]
    402013a8:	120026c9 	and	w9, w22, #0x3ff
    402013ac:	7100793f 	cmp	w9, #0x1e
    402013b0:	54004cc1 	b.ne	40201d48 <jnox_kernel::ordinary_reservations::irq+0xa80>  // b.any
    402013b4:	92400ae9 	and	x9, x23, #0x7
    402013b8:	f100153f 	cmp	x9, #0x5
    402013bc:	54004c61 	b.ne	40201d48 <jnox_kernel::ordinary_reservations::irq+0xa80>  // b.any
    402013c0:	eb0802bf 	cmp	x21, x8
    402013c4:	54004c23 	b.cc	40201d48 <jnox_kernel::ordinary_reservations::irq+0xa80>  // b.lo, b.ul, b.last
    402013c8:	d51be23f 	msr	cntp_ctl_el0, xzr
    402013cc:	d5033fdf 	isb
    402013d0:	d5033f9f 	dsb	sy
    402013d4:	b9000756 	str	w22, [x26, #4]
    402013d8:	d5033f9f 	dsb	sy
    402013dc:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402013e0:	f942c508 	ldr	x8, [x8, #1416]
    402013e4:	f100051f 	cmp	x8, #0x1
    402013e8:	540003e1 	b.ne	40201464 <jnox_kernel::ordinary_reservations::irq+0x19c>  // b.any
    402013ec:	aa1403e0 	mov	x0, x20
    402013f0:	aa1503e1 	mov	x1, x21
    402013f4:	2a1f03e2 	mov	w2, wzr
    402013f8:	aa1f03e3 	mov	x3, xzr
    402013fc:	94000661 	bl	40202d80 <jnox_kernel::ordinary_reservations::Runtime::close>
    40201400:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201404:	9114e108 	add	x8, x8, #0x538
    40201408:	91000669 	add	x9, x19, #0x1
    4020140c:	a9402908 	ldp	x8, x10, [x8]
    40201410:	9bca7d2b 	umulh	x11, x9, x10
    40201414:	eb0b03ff 	cmp	xzr, x11
    40201418:	1a9f07eb 	cset	w11, ne  // ne = any
    4020141c:	9b0a7d29 	mul	x9, x9, x10
    40201420:	ab080122 	adds	x2, x9, x8
    40201424:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40201428:	370048cb 	tbnz	w11, #0, 40201d40 <jnox_kernel::ordinary_reservations::irq+0xa78>
    4020142c:	350048a8 	cbnz	w8, 40201d40 <jnox_kernel::ordinary_reservations::irq+0xa78>
    40201430:	aa1303e0 	mov	x0, x19
    40201434:	aa1f03e1 	mov	x1, xzr
    40201438:	94000631 	bl	40202cfc <jnox_kernel::ordinary_reservations::Runtime::arm>
    4020143c:	aa1303e0 	mov	x0, x19
    40201440:	52800041 	mov	w1, #0x2                   	// #2
    40201444:	a9554ff4 	ldp	x20, x19, [sp, #336]
    40201448:	a95457f6 	ldp	x22, x21, [sp, #320]
    4020144c:	a9535ff8 	ldp	x24, x23, [sp, #304]
    40201450:	a95267fa 	ldp	x26, x25, [sp, #288]
    40201454:	a9516ffc 	ldp	x28, x27, [sp, #272]
    40201458:	a9507bfd 	ldp	x29, x30, [sp, #256]
    4020145c:	910583ff 	add	sp, sp, #0x160
    40201460:	14000781 	b	40203264 <jnox_kernel::ordinary_reservations::Runtime::select>
    40201464:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201468:	9114c129 	add	x9, x9, #0x530
    4020146c:	f940192a 	ldr	x10, [x9, #48]
    40201470:	f100095f 	cmp	x10, #0x2
    40201474:	54002601 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201478:	39400129 	ldrb	w9, [x9]
    4020147c:	71000d3f 	cmp	w9, #0x3
    40201480:	540025a1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201484:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201488:	91152129 	add	x9, x9, #0x548
    4020148c:	f9001934 	str	x20, [x9, #48]
    40201490:	f9401d25 	ldr	x5, [x9, #56]
    40201494:	cb0502aa 	sub	x10, x21, x5
    40201498:	f9400129 	ldr	x9, [x9]
    4020149c:	eb09015f 	cmp	x10, x9
    402014a0:	540046c8 	b.hi	40201d78 <jnox_kernel::ordinary_reservations::irq+0xab0>  // b.pmore
    402014a4:	b40013b3 	cbz	x19, 40201718 <jnox_kernel::ordinary_reservations::irq+0x450>
    402014a8:	92800028 	mov	x8, #0xfffffffffffffffe    	// #-2
    402014ac:	d0000037 	adrp	x23, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014b0:	d0000038 	adrp	x24, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014b4:	91174318 	add	x24, x24, #0x5d0
    402014b8:	b4000428 	cbz	x8, 4020153c <jnox_kernel::ordinary_reservations::irq+0x274>
    402014bc:	aa0803f6 	mov	x22, x8
    402014c0:	910243e8 	add	x8, sp, #0x90
    402014c4:	91000ac0 	add	x0, x22, #0x2
    402014c8:	940007a3 	bl	40203354 <jnox_kernel::ordinary_reservations::snapshot>
    402014cc:	a94957f4 	ldp	x20, x21, [sp, #144]
    402014d0:	f942aae8 	ldr	x8, [x23, #1360]
    402014d4:	eb08027f 	cmp	x19, x8
    402014d8:	54000161 	b.ne	40201504 <jnox_kernel::ordinary_reservations::irq+0x23c>  // b.any
    402014dc:	f94053e8 	ldr	x8, [sp, #160]
    402014e0:	d5033fdf 	isb
    402014e4:	d53be021 	mrs	x1, cntpct_el0
    402014e8:	a90957f4 	stp	x20, x21, [sp, #144]
    402014ec:	a90a7fe8 	stp	x8, xzr, [sp, #160]
    402014f0:	91000ac3 	add	x3, x22, #0x2
    402014f4:	910243e4 	add	x4, sp, #0x90
    402014f8:	528002a0 	mov	w0, #0x15                  	// #21
    402014fc:	aa1303e2 	mov	x2, x19
    40201500:	94000414 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40201504:	f85f0308 	ldur	x8, [x24, #-16]
    40201508:	eb08029f 	cmp	x20, x8
    4020150c:	540000a1 	b.ne	40201520 <jnox_kernel::ordinary_reservations::irq+0x258>  // b.any
    40201510:	f8408709 	ldr	x9, [x24], #8
    40201514:	910006c8 	add	x8, x22, #0x1
    40201518:	eb0902bf 	cmp	x21, x9
    4020151c:	54fffce0 	b.eq	402014b8 <jnox_kernel::ordinary_reservations::irq+0x1f0>  // b.none
    40201520:	91000ac3 	add	x3, x22, #0x2
    40201524:	52800060 	mov	w0, #0x3                   	// #3
    40201528:	52800101 	mov	w1, #0x8                   	// #8
    4020152c:	aa1303e2 	mov	x2, x19
    40201530:	aa1403e4 	mov	x4, x20
    40201534:	aa1503e5 	mov	x5, x21
    40201538:	9400045d 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>
    4020153c:	f942aae8 	ldr	x8, [x23, #1360]
    40201540:	eb08027f 	cmp	x19, x8
    40201544:	54004400 	b.eq	40201dc4 <jnox_kernel::ordinary_reservations::irq+0xafc>  // b.none
    40201548:	94000736 	bl	40203220 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    4020154c:	910243e8 	add	x8, sp, #0x90
    40201550:	aa1303e1 	mov	x1, x19
    40201554:	940008ca 	bl	4020387c <jnox_kernel::reservation_jobs::Jobs::open>
    40201558:	f9404be8 	ldr	x8, [sp, #144]
    4020155c:	f100091f 	cmp	x8, #0x2
    40201560:	540043e0 	b.eq	40201ddc <jnox_kernel::ordinary_reservations::irq+0xb14>  // b.none
    40201564:	9100a3e0 	add	x0, sp, #0x28
    40201568:	910243e1 	add	x1, sp, #0x90
    4020156c:	52800d02 	mov	w2, #0x68                  	// #104
    40201570:	94001124 	bl	40205a00 <memcpy>
    40201574:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201578:	9114e129 	add	x9, x9, #0x538
    4020157c:	a9402129 	ldp	x9, x8, [x9]
    40201580:	9bc87e6a 	umulh	x10, x19, x8
    40201584:	eb0a03ff 	cmp	xzr, x10
    40201588:	1a9f07eb 	cset	w11, ne  // ne = any
    4020158c:	9b087e6a 	mul	x10, x19, x8
    40201590:	ab09014c 	adds	x12, x10, x9
    40201594:	1a9f37ea 	cset	w10, cs  // cs = hs, nlast
    40201598:	37003d4b 	tbnz	w11, #0, 40201d40 <jnox_kernel::ordinary_reservations::irq+0xa78>
    4020159c:	35003d2a 	cbnz	w10, 40201d40 <jnox_kernel::ordinary_reservations::irq+0xa78>
    402015a0:	9100066b 	add	x11, x19, #0x1
    402015a4:	9bc87d6a 	umulh	x10, x11, x8
    402015a8:	eb0a03ff 	cmp	xzr, x10
    402015ac:	1a9f07ea 	cset	w10, ne  // ne = any
    402015b0:	9b087d68 	mul	x8, x11, x8
    402015b4:	ab090108 	adds	x8, x8, x9
    402015b8:	a901a3ec 	stp	x12, x8, [sp, #24]
    402015bc:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    402015c0:	37003c0a 	tbnz	w10, #0, 40201d40 <jnox_kernel::ordinary_reservations::irq+0xa78>
    402015c4:	35003be8 	cbnz	w8, 40201d40 <jnox_kernel::ordinary_reservations::irq+0xa78>
    402015c8:	aa1f03f6 	mov	x22, xzr
    402015cc:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402015d0:	39422beb 	ldrb	w11, [sp, #138]
    402015d4:	9100a3e9 	add	x9, sp, #0x28
    402015d8:	9100613d 	add	x29, x9, #0x18
    402015dc:	b9402bfc 	ldr	w28, [sp, #40]
    402015e0:	9100e137 	add	x23, x9, #0x38
    402015e4:	91004138 	add	x24, x9, #0x10
    402015e8:	f9401bf5 	ldr	x21, [sp, #48]
    402015ec:	9100056a 	add	x10, x11, #0x1
    402015f0:	71000d7f 	cmp	w11, #0x3
    402015f4:	f902ad13 	str	x19, [x8, #1368]
    402015f8:	91000568 	add	x8, x11, #0x1
    402015fc:	a900afe8 	stp	x8, x11, [sp, #8]
    40201600:	1a8a03f9 	csel	w25, wzr, w10, eq  // eq = none
    40201604:	91016134 	add	x20, x9, #0x58
    40201608:	9101813a 	add	x26, x9, #0x60
    4020160c:	52800028 	mov	w8, #0x1                   	// #1
    40201610:	8b1613a9 	add	x9, x29, x22, lsl #4
    40201614:	8b1612ea 	add	x10, x23, x22, lsl #4
    40201618:	d5033fdf 	isb
    4020161c:	d53be021 	mrs	x1, cntpct_el0
    40201620:	2a0803fb 	mov	w27, w8
    40201624:	a9402528 	ldp	x8, x9, [x9]
    40201628:	a90927e8 	stp	x8, x9, [sp, #144]
    4020162c:	a9402548 	ldp	x8, x9, [x10]
    40201630:	a90a27e8 	stp	x8, x9, [sp, #160]
    40201634:	910243e4 	add	x4, sp, #0x90
    40201638:	528000a0 	mov	w0, #0x5                   	// #5
    4020163c:	aa1303e2 	mov	x2, x19
    40201640:	aa1603e3 	mov	x3, x22
    40201644:	940003c3 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40201648:	d5033fdf 	isb
    4020164c:	d53be021 	mrs	x1, cntpct_el0
    40201650:	b8767b08 	ldr	w8, [x24, x22, lsl #2]
    40201654:	eb1502df 	cmp	x22, x21
    40201658:	b8767a89 	ldr	w9, [x20, x22, lsl #2]
    4020165c:	38766b4a 	ldrb	w10, [x26, x22]
    40201660:	1a9f17eb 	cset	w11, eq  // eq = none
    40201664:	a90927e8 	stp	x8, x9, [sp, #144]
    40201668:	6a0b039f 	tst	w28, w11
    4020166c:	9a9f1328 	csel	x8, x25, xzr, ne  // ne = any
    40201670:	a90a23ea 	stp	x10, x8, [sp, #160]
    40201674:	910243e4 	add	x4, sp, #0x90
    40201678:	528000c0 	mov	w0, #0x6                   	// #6
    4020167c:	aa1303e2 	mov	x2, x19
    40201680:	aa1603e3 	mov	x3, x22
    40201684:	940003b3 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40201688:	2a1f03e8 	mov	w8, wzr
    4020168c:	52800036 	mov	w22, #0x1                   	// #1
    40201690:	3707fc1b 	tbnz	w27, #0, 40201610 <jnox_kernel::ordinary_reservations::irq+0x348>
    40201694:	34002a5c 	cbz	w28, 40201bdc <jnox_kernel::ordinary_reservations::irq+0x914>
    40201698:	f9400bed 	ldr	x13, [sp, #16]
    4020169c:	71000dbf 	cmp	w13, #0x3
    402016a0:	540014a0 	b.eq	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.none
    402016a4:	f1000abf 	cmp	x21, #0x2
    402016a8:	54003b02 	b.cs	40201e08 <jnox_kernel::ordinary_reservations::irq+0xb40>  // b.hs, b.nlast
    402016ac:	d503201f 	nop
    402016b0:	1002ea88 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402016b4:	8b150d0b 	add	x11, x8, x21, lsl #3
    402016b8:	f940e168 	ldr	x8, [x11, #448]
    402016bc:	f940e969 	ldr	x9, [x11, #464]
    402016c0:	f940c96c 	ldr	x12, [x11, #400]
    402016c4:	9100a3ea 	add	x10, sp, #0x28
    402016c8:	8b15114a 	add	x10, x10, x21, lsl #4
    402016cc:	f940214a 	ldr	x10, [x10, #64]
    402016d0:	eb0a019f 	cmp	x12, x10
    402016d4:	54000060 	b.eq	402016e0 <jnox_kernel::ordinary_reservations::irq+0x418>  // b.none
    402016d8:	f900c96a 	str	x10, [x11, #400]
    402016dc:	f900d17f 	str	xzr, [x11, #416]
    402016e0:	d000010b 	adrp	x11, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766+0xb8e0>
    402016e4:	f943f56b 	ldr	x11, [x11, #2024]
    402016e8:	d000002c 	adrp	x12, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402016ec:	9114018c 	add	x12, x12, #0x500
    402016f0:	a9004d95 	stp	x21, x19, [x12]
    402016f4:	a901218b 	stp	x11, x8, [x12, #16]
    402016f8:	a9022989 	stp	x9, x10, [x12, #32]
    402016fc:	3900c18d 	strb	w13, [x12, #48]
    40201700:	f94013f4 	ldr	x20, [sp, #32]
    40201704:	34002a4d 	cbz	w13, 40201c4c <jnox_kernel::ordinary_reservations::irq+0x984>
    40201708:	b104011f 	cmn	x8, #0x100
    4020170c:	54003882 	b.cs	40201e1c <jnox_kernel::ordinary_reservations::irq+0xb54>  // b.hs, b.nlast
    40201710:	91040108 	add	x8, x8, #0x100
    40201714:	1400014f 	b	40201c50 <jnox_kernel::ordinary_reservations::irq+0x988>
    40201718:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020171c:	f942f129 	ldr	x9, [x9, #1504]
    40201720:	f100093f 	cmp	x9, #0x2
    40201724:	54001080 	b.eq	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.none
    40201728:	b5001068 	cbnz	x8, 40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>
    4020172c:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201730:	f942ad08 	ldr	x8, [x8, #1368]
    40201734:	b100051f 	cmn	x8, #0x1
    40201738:	54000fe1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    4020173c:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201740:	f9432d08 	ldr	x8, [x8, #1624]
    40201744:	eb0800bf 	cmp	x5, x8
    40201748:	54000f61 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    4020174c:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201750:	f9429d29 	ldr	x9, [x9, #1336]
    40201754:	eb08013f 	cmp	x9, x8
    40201758:	54000ee1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    4020175c:	d0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766+0xb8e0>
    40201760:	f943f508 	ldr	x8, [x8, #2024]
    40201764:	f100051f 	cmp	x8, #0x1
    40201768:	54000e61 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    4020176c:	d503201f 	nop
    40201770:	10110388 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    40201774:	c8dffd09 	ldar	x9, [x8]
    40201778:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020177c:	f942354a 	ldr	x10, [x10, #1128]
    40201780:	aa0a0129 	orr	x9, x9, x10
    40201784:	b5000d89 	cbnz	x9, 40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>
    40201788:	aa1f03eb 	mov	x11, xzr
    4020178c:	5280002a 	mov	w10, #0x1                   	// #1
    40201790:	d503201f 	nop
    40201794:	1002e377 	adr	x23, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40201798:	8b0b02e9 	add	x9, x23, x11
    4020179c:	3941e129 	ldrb	w9, [x9, #120]
    402017a0:	3600008a 	tbz	w10, #0, 402017b0 <jnox_kernel::ordinary_reservations::irq+0x4e8>
    402017a4:	2a1f03ea 	mov	w10, wzr
    402017a8:	5280002b 	mov	w11, #0x1                   	// #1
    402017ac:	34ffff69 	cbz	w9, 40201798 <jnox_kernel::ordinary_reservations::irq+0x4d0>
    402017b0:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402017b4:	9111814a 	add	x10, x10, #0x460
    402017b8:	3940014b 	ldrb	w11, [x10]
    402017bc:	f940094a 	ldr	x10, [x10, #16]
    402017c0:	7100013f 	cmp	w9, #0x0
    402017c4:	7a430960 	ccmp	w11, #0x3, #0x0, eq  // eq = none
    402017c8:	fa400940 	ccmp	x10, #0x0, #0x0, eq  // eq = none
    402017cc:	54000b41 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402017d0:	d000010b 	adrp	x11, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766+0xb8e0>
    402017d4:	911fc16b 	add	x11, x11, #0x7f0
    402017d8:	f9400969 	ldr	x9, [x11, #16]
    402017dc:	f940056a 	ldr	x10, [x11, #8]
    402017e0:	f940016b 	ldr	x11, [x11]
    402017e4:	d000010c 	adrp	x12, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766+0xb8e0>
    402017e8:	910f818c 	add	x12, x12, #0x3e0
    402017ec:	eb0c017f 	cmp	x11, x12
    402017f0:	54000a21 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402017f4:	d503201f 	nop
    402017f8:	10004aeb 	adr	x11, 40202154 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766>
    402017fc:	eb0b015f 	cmp	x10, x11
    40201800:	540009a1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201804:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201808:	f943254a 	ldr	x10, [x10, #1608]
    4020180c:	eb0a013f 	cmp	x9, x10
    40201810:	54000928 	b.hi	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.pmore
    40201814:	aa1f03e9 	mov	x9, xzr
    40201818:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020181c:	911aa14a 	add	x10, x10, #0x6a8
    40201820:	d503201f 	nop
    40201824:	1002f63a 	adr	x26, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40201828:	d503201f 	nop
    4020182c:	10112e3b 	adr	x27, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40201830:	d503201f 	nop
    40201834:	1002f63d 	adr	x29, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40201838:	d503201f 	nop
    4020183c:	10112e3c 	adr	x28, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40201840:	d10d032b 	sub	x11, x25, #0x340
    40201844:	d503201f 	nop
    40201848:	10112e4c 	adr	x12, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    4020184c:	f100413f 	cmp	x9, #0x10
    40201850:	54000740 	b.eq	40201938 <jnox_kernel::ordinary_reservations::irq+0x670>  // b.none
    40201854:	8b0902ed 	add	x13, x23, x9
    40201858:	f940b5ad 	ldr	x13, [x13, #360]
    4020185c:	f85d014e 	ldur	x14, [x10, #-48]
    40201860:	eb0d01df 	cmp	x14, x13
    40201864:	9140116b 	add	x11, x11, #0x4, lsl #12
    40201868:	fa4d0160 	ccmp	x11, x13, #0x0, eq  // eq = none
    4020186c:	54000641 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201870:	f9407dae 	ldr	x14, [x13, #248]
    40201874:	f85d814f 	ldur	x15, [x10, #-40]
    40201878:	eb0f01df 	cmp	x14, x15
    4020187c:	540005c1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201880:	f94081ae 	ldr	x14, [x13, #256]
    40201884:	f85e014f 	ldur	x15, [x10, #-32]
    40201888:	eb0f01df 	cmp	x14, x15
    4020188c:	54000541 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201890:	f9404dae 	ldr	x14, [x13, #152]
    40201894:	f85e814f 	ldur	x15, [x10, #-24]
    40201898:	eb0f01df 	cmp	x14, x15
    4020189c:	540004c1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402018a0:	f9408dad 	ldr	x13, [x13, #280]
    402018a4:	f85f014e 	ldur	x14, [x10, #-16]
    402018a8:	eb0e01bf 	cmp	x13, x14
    402018ac:	54000441 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402018b0:	8b09034d 	add	x13, x26, x9
    402018b4:	c8dffdad 	ldar	x13, [x13]
    402018b8:	b10005bf 	cmn	x13, #0x1
    402018bc:	540003c1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402018c0:	8b09036d 	add	x13, x27, x9
    402018c4:	c8dffdad 	ldar	x13, [x13]
    402018c8:	b500036d 	cbnz	x13, 40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>
    402018cc:	8b0903ad 	add	x13, x29, x9
    402018d0:	c8dffdad 	ldar	x13, [x13]
    402018d4:	b10005bf 	cmn	x13, #0x1
    402018d8:	540002e1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402018dc:	8b09038d 	add	x13, x28, x9
    402018e0:	c8dffdad 	ldar	x13, [x13]
    402018e4:	b500028d 	cbnz	x13, 40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>
    402018e8:	8b09018d 	add	x13, x12, x9
    402018ec:	c8dffdad 	ldar	x13, [x13]
    402018f0:	b500022d 	cbnz	x13, 40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>
    402018f4:	8b0902ed 	add	x13, x23, x9
    402018f8:	f940e1ae 	ldr	x14, [x13, #448]
    402018fc:	f85f814f 	ldur	x15, [x10, #-8]
    40201900:	eb0f01df 	cmp	x14, x15
    40201904:	54000181 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201908:	f940e9ad 	ldr	x13, [x13, #464]
    4020190c:	f843854e 	ldr	x14, [x10], #56
    40201910:	eb0e01bf 	cmp	x13, x14
    40201914:	54000101 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201918:	8b0902ed 	add	x13, x23, x9
    4020191c:	f940c9ae 	ldr	x14, [x13, #400]
    40201920:	b10005df 	cmn	x14, #0x1
    40201924:	54000081 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201928:	91002129 	add	x9, x9, #0x8
    4020192c:	f940d1ad 	ldr	x13, [x13, #416]
    40201930:	b4fff8ed 	cbz	x13, 4020184c <jnox_kernel::ordinary_reservations::irq+0x584>
    40201934:	97fffe5d 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40201938:	d5033fdf 	isb
    4020193c:	d53be029 	mrs	x9, cntpct_el0
    40201940:	10ffffea 	adr	x10, 4020193c <jnox_kernel::ordinary_reservations::irq+0x674>
    40201944:	f90017e9 	str	x9, [sp, #40]
    40201948:	f9007fea 	str	x10, [sp, #248]
    4020194c:	52800029 	mov	w9, #0x1                   	// #1
    40201950:	f9004be9 	str	x9, [sp, #144]
    40201954:	d503201f 	nop
    40201958:	10112689 	adr	x9, 40223e28 <jnox_kernel::ordinary_reservations::stage_hooks::stage_probe::OBSERVATION>
    4020195c:	f9404bea 	ldr	x10, [sp, #144]
    40201960:	f900012a 	str	x10, [x9]
    40201964:	f94017ea 	ldr	x10, [sp, #40]
    40201968:	f900052a 	str	x10, [x9, #8]
    4020196c:	f9407fea 	ldr	x10, [sp, #248]
    40201970:	f900092a 	str	x10, [x9, #16]
    40201974:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201978:	f942412a 	ldr	x10, [x9, #1152]
    4020197c:	f100095f 	cmp	x10, #0x2
    40201980:	54fffda0 	b.eq	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.none
    40201984:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201988:	91136129 	add	x9, x9, #0x4d8
    4020198c:	39402138 	ldrb	w24, [x9, #8]
    40201990:	71000f1f 	cmp	w24, #0x3
    40201994:	54fffd00 	b.eq	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.none
    40201998:	3941eaeb 	ldrb	w11, [x23, #122]
    4020199c:	3943eaec 	ldrb	w12, [x23, #250]
    402019a0:	6b0c017f 	cmp	w11, w12
    402019a4:	54fffc81 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402019a8:	f94002eb 	ldr	x11, [x23]
    402019ac:	eb0a017f 	cmp	x11, x10
    402019b0:	54fffc21 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402019b4:	d503201f 	nop
    402019b8:	1002e154 	adr	x20, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    402019bc:	f940028a 	ldr	x10, [x20]
    402019c0:	b4fffbaa 	cbz	x10, 40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>
    402019c4:	f9400133 	ldr	x19, [x9]
    402019c8:	f9400689 	ldr	x9, [x20, #8]
    402019cc:	eb13013f 	cmp	x9, x19
    402019d0:	54fffb21 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402019d4:	39418a89 	ldrb	w9, [x20, #98]
    402019d8:	6b09031f 	cmp	w24, w9
    402019dc:	54fffac1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    402019e0:	f90013e5 	str	x5, [sp, #32]
    402019e4:	d0000119 	adrp	x25, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766+0xb8e0>
    402019e8:	911cc339 	add	x25, x25, #0x730
    402019ec:	d5033fdf 	isb
    402019f0:	d53be036 	mrs	x22, cntpct_el0
    402019f4:	f9001f36 	str	x22, [x25, #56]
    402019f8:	f9400329 	ldr	x9, [x25]
    402019fc:	b27f0129 	orr	x9, x9, #0x2
    40201a00:	f9000329 	str	x9, [x25]
    40201a04:	eb1502df 	cmp	x22, x21
    40201a08:	54001c43 	b.cc	40201d90 <jnox_kernel::ordinary_reservations::irq+0xac8>  // b.lo, b.ul, b.last
    40201a0c:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201a10:	9114e14a 	add	x10, x10, #0x538
    40201a14:	f9400149 	ldr	x9, [x10]
    40201a18:	eb0902c9 	subs	x9, x22, x9
    40201a1c:	54001ba3 	b.cc	40201d90 <jnox_kernel::ordinary_reservations::irq+0xac8>  // b.lo, b.ul, b.last
    40201a20:	f940094a 	ldr	x10, [x10, #16]
    40201a24:	eb0a013f 	cmp	x9, x10
    40201a28:	54001b48 	b.hi	40201d90 <jnox_kernel::ordinary_reservations::irq+0xac8>  // b.pmore
    40201a2c:	52800069 	mov	w9, #0x3                   	// #3
    40201a30:	c89ffd09 	stlr	x9, [x8]
    40201a34:	c8dffd15 	ldar	x21, [x8]
    40201a38:	940005fa 	bl	40203220 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    40201a3c:	f9402c08 	ldr	x8, [x0, #88]
    40201a40:	39418009 	ldrb	w9, [x0, #96]
    40201a44:	d5033fdf 	isb
    40201a48:	d53be024 	mrs	x4, cntpct_el0
    40201a4c:	f940032a 	ldr	x10, [x25]
    40201a50:	a9045724 	stp	x4, x21, [x25, #64]
    40201a54:	71000d3f 	cmp	w9, #0x3
    40201a58:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40201a5c:	f9002b28 	str	x8, [x25, #80]
    40201a60:	b27e0149 	orr	x9, x10, #0x4
    40201a64:	f9000329 	str	x9, [x25]
    40201a68:	f1000ebf 	cmp	x21, #0x3
    40201a6c:	54fff641 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201a70:	eb13011f 	cmp	x8, x19
    40201a74:	54fff601 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201a78:	eb16009f 	cmp	x4, x22
    40201a7c:	d000002e 	adrp	x14, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201a80:	9114e1ce 	add	x14, x14, #0x538
    40201a84:	54001703 	b.cc	40201d64 <jnox_kernel::ordinary_reservations::irq+0xa9c>  // b.lo, b.ul, b.last
    40201a88:	f94001c8 	ldr	x8, [x14]
    40201a8c:	eb080088 	subs	x8, x4, x8
    40201a90:	540016a3 	b.cc	40201d64 <jnox_kernel::ordinary_reservations::irq+0xa9c>  // b.lo, b.ul, b.last
    40201a94:	f94009c9 	ldr	x9, [x14, #16]
    40201a98:	eb09011f 	cmp	x8, x9
    40201a9c:	54001648 	b.hi	40201d64 <jnox_kernel::ordinary_reservations::irq+0xa9c>  // b.pmore
    40201aa0:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201aa4:	f902ad1f 	str	xzr, [x8, #1368]
    40201aa8:	f100067f 	cmp	x19, #0x1
    40201aac:	54001a68 	b.hi	40201df8 <jnox_kernel::ordinary_reservations::irq+0xb30>  // b.pmore
    40201ab0:	8b131288 	add	x8, x20, x19, lsl #4
    40201ab4:	f9402108 	ldr	x8, [x8, #64]
    40201ab8:	8b130ee9 	add	x9, x23, x19, lsl #3
    40201abc:	f900c928 	str	x8, [x9, #400]
    40201ac0:	f940e12a 	ldr	x10, [x9, #448]
    40201ac4:	f940e92b 	ldr	x11, [x9, #464]
    40201ac8:	a9107ef3 	stp	x19, xzr, [x23, #256]
    40201acc:	5280002c 	mov	w12, #0x1                   	// #1
    40201ad0:	a9112aec 	stp	x12, x10, [x23, #272]
    40201ad4:	a91222eb 	stp	x11, x8, [x23, #288]
    40201ad8:	3904c2f8 	strb	w24, [x23, #304]
    40201adc:	8b130fa8 	add	x8, x29, x19, lsl #3
    40201ae0:	a948aa8b 	ldp	x11, x10, [x20, #136]
    40201ae4:	c89ffd0a 	stlr	x10, [x8]
    40201ae8:	91000708 	add	x8, x24, #0x1
    40201aec:	f8337b68 	str	x8, [x27, x19, lsl #3]
    40201af0:	f8337b9f 	str	xzr, [x28, x19, lsl #3]
    40201af4:	8b130f48 	add	x8, x26, x19, lsl #3
    40201af8:	c89ffd1f 	stlr	xzr, [x8]
    40201afc:	a91832eb 	stp	x11, x12, [x23, #384]
    40201b00:	d51be24b 	msr	cntp_cval_el0, x11
    40201b04:	d51be22c 	msr	cntp_ctl_el0, x12
    40201b08:	d5033fdf 	isb
    40201b0c:	d53be24d 	mrs	x13, cntp_cval_el0
    40201b10:	d53be228 	mrs	x8, cntp_ctl_el0
    40201b14:	d5033fdf 	isb
    40201b18:	d53be02a 	mrs	x10, cntpct_el0
    40201b1c:	a906a32d 	stp	x13, x8, [x25, #104]
    40201b20:	a905af2a 	stp	x10, x11, [x25, #88]
    40201b24:	f940032c 	ldr	x12, [x25]
    40201b28:	b27d018c 	orr	x12, x12, #0x8
    40201b2c:	f900032c 	str	x12, [x25]
    40201b30:	eb0b01bf 	cmp	x13, x11
    40201b34:	54fff001 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201b38:	92400508 	and	x8, x8, #0x3
    40201b3c:	f100051f 	cmp	x8, #0x1
    40201b40:	54ffefa1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201b44:	d5033fdf 	isb
    40201b48:	d53be028 	mrs	x8, cntpct_el0
    40201b4c:	eb04015f 	cmp	x10, x4
    40201b50:	540012c3 	b.cc	40201da8 <jnox_kernel::ordinary_reservations::irq+0xae0>  // b.lo, b.ul, b.last
    40201b54:	eb0a011f 	cmp	x8, x10
    40201b58:	54001283 	b.cc	40201da8 <jnox_kernel::ordinary_reservations::irq+0xae0>  // b.lo, b.ul, b.last
    40201b5c:	f94001ca 	ldr	x10, [x14]
    40201b60:	eb0a010a 	subs	x10, x8, x10
    40201b64:	54001223 	b.cc	40201da8 <jnox_kernel::ordinary_reservations::irq+0xae0>  // b.lo, b.ul, b.last
    40201b68:	f94009cb 	ldr	x11, [x14, #16]
    40201b6c:	eb0b015f 	cmp	x10, x11
    40201b70:	540011c8 	b.hi	40201da8 <jnox_kernel::ordinary_reservations::irq+0xae0>  // b.pmore
    40201b74:	f940b536 	ldr	x22, [x9, #360]
    40201b78:	d5033fdf 	isb
    40201b7c:	d53be024 	mrs	x4, cntpct_el0
    40201b80:	f9409ee8 	ldr	x8, [x23, #312]
    40201b84:	eb080088 	subs	x8, x4, x8
    40201b88:	54000ee3 	b.cc	40201d64 <jnox_kernel::ordinary_reservations::irq+0xa9c>  // b.lo, b.ul, b.last
    40201b8c:	f940a6ea 	ldr	x10, [x23, #328]
    40201b90:	eb0a011f 	cmp	x8, x10
    40201b94:	54000e88 	b.hi	40201d64 <jnox_kernel::ordinary_reservations::irq+0xa9c>  // b.pmore
    40201b98:	f900b53f 	str	xzr, [x9, #360]
    40201b9c:	f900b2f3 	str	x19, [x23, #352]
    40201ba0:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201ba4:	91004108 	add	x8, x8, #0x10
    40201ba8:	f9407ec9 	ldr	x9, [x22, #248]
    40201bac:	a907db24 	stp	x4, x22, [x25, #120]
    40201bb0:	5280002a 	mov	w10, #0x1                   	// #1
    40201bb4:	a9004d1f 	stp	xzr, x19, [x8]
    40201bb8:	f9408ec8 	ldr	x8, [x22, #280]
    40201bbc:	f9004729 	str	x9, [x25, #136]
    40201bc0:	f9404ec9 	ldr	x9, [x22, #152]
    40201bc4:	a909ab28 	stp	x8, x10, [x25, #152]
    40201bc8:	f9004b29 	str	x9, [x25, #144]
    40201bcc:	f9400328 	ldr	x8, [x25]
    40201bd0:	b27c0108 	orr	x8, x8, #0x10
    40201bd4:	f9000328 	str	x8, [x25]
    40201bd8:	14000051 	b	40201d1c <jnox_kernel::ordinary_reservations::irq+0xa54>
    40201bdc:	aa1303e0 	mov	x0, x19
    40201be0:	aa1f03e1 	mov	x1, xzr
    40201be4:	f94013f4 	ldr	x20, [sp, #32]
    40201be8:	aa1403e2 	mov	x2, x20
    40201bec:	94000444 	bl	40202cfc <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201bf0:	52800055 	mov	w21, #0x2                   	// #2
    40201bf4:	1400003b 	b	40201ce0 <jnox_kernel::ordinary_reservations::irq+0xa18>
    40201bf8:	d000010a 	adrp	x10, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766+0xb8e0>
    40201bfc:	911cc14a 	add	x10, x10, #0x730
    40201c00:	d53be248 	mrs	x8, cntp_cval_el0
    40201c04:	d5033fdf 	isb
    40201c08:	d53be029 	mrs	x9, cntpct_el0
    40201c0c:	a9022157 	stp	x23, x8, [x10, #32]
    40201c10:	a9015949 	stp	x9, x22, [x10, #16]
    40201c14:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201c18:	9114e129 	add	x9, x9, #0x538
    40201c1c:	f940252b 	ldr	x11, [x9, #72]
    40201c20:	f900194b 	str	x11, [x10, #48]
    40201c24:	f940014c 	ldr	x12, [x10]
    40201c28:	b240018c 	orr	x12, x12, #0x1
    40201c2c:	a900554c 	stp	x12, x21, [x10]
    40201c30:	eb0b011f 	cmp	x8, x11
    40201c34:	54ffe801 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201c38:	f9400129 	ldr	x9, [x9]
    40201c3c:	eb09011f 	cmp	x8, x9
    40201c40:	54ffe7a1 	b.ne	40201934 <jnox_kernel::ordinary_reservations::irq+0x66c>  // b.any
    40201c44:	aa1f03f3 	mov	x19, xzr
    40201c48:	17fffdd8 	b	402013a8 <jnox_kernel::ordinary_reservations::irq+0xe0>
    40201c4c:	92800008 	mov	x8, #0xffffffffffffffff    	// #-1
    40201c50:	d503201f 	nop
    40201c54:	1002d529 	adr	x9, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40201c58:	d503201f 	nop
    40201c5c:	10110caa 	adr	x10, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40201c60:	d503201f 	nop
    40201c64:	1002d42b 	adr	x11, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40201c68:	d503201f 	nop
    40201c6c:	10110cac 	adr	x12, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40201c70:	8b150d29 	add	x9, x9, x21, lsl #3
    40201c74:	c89ffd28 	stlr	x8, [x9]
    40201c78:	f94007e8 	ldr	x8, [sp, #8]
    40201c7c:	f8357948 	str	x8, [x10, x21, lsl #3]
    40201c80:	f835799f 	str	xzr, [x12, x21, lsl #3]
    40201c84:	8b150d68 	add	x8, x11, x21, lsl #3
    40201c88:	c89ffd13 	stlr	x19, [x8]
    40201c8c:	b100067f 	cmn	x19, #0x1
    40201c90:	54000580 	b.eq	40201d40 <jnox_kernel::ordinary_reservations::irq+0xa78>  // b.none
    40201c94:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201c98:	9114e129 	add	x9, x9, #0x538
    40201c9c:	a9402129 	ldp	x9, x8, [x9]
    40201ca0:	9100066b 	add	x11, x19, #0x1
    40201ca4:	9bc87d6a 	umulh	x10, x11, x8
    40201ca8:	eb0a03ff 	cmp	xzr, x10
    40201cac:	1a9f07ea 	cset	w10, ne  // ne = any
    40201cb0:	9b087d68 	mul	x8, x11, x8
    40201cb4:	ab090108 	adds	x8, x8, x9
    40201cb8:	1a9f37e9 	cset	w9, cs  // cs = hs, nlast
    40201cbc:	3700042a 	tbnz	w10, #0, 40201d40 <jnox_kernel::ordinary_reservations::irq+0xa78>
    40201cc0:	37000409 	tbnz	w9, #0, 40201d40 <jnox_kernel::ordinary_reservations::irq+0xa78>
    40201cc4:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201cc8:	f942a529 	ldr	x9, [x9, #1352]
    40201ccc:	eb090102 	subs	x2, x8, x9
    40201cd0:	54000383 	b.cc	40201d40 <jnox_kernel::ordinary_reservations::irq+0xa78>  // b.lo, b.ul, b.last
    40201cd4:	aa1303e0 	mov	x0, x19
    40201cd8:	52800021 	mov	w1, #0x1                   	// #1
    40201cdc:	94000408 	bl	40202cfc <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201ce0:	aa1303e0 	mov	x0, x19
    40201ce4:	aa1503e1 	mov	x1, x21
    40201ce8:	9400055f 	bl	40203264 <jnox_kernel::ordinary_reservations::Runtime::select>
    40201cec:	aa0003f6 	mov	x22, x0
    40201cf0:	d5033fdf 	isb
    40201cf4:	d53be021 	mrs	x1, cntpct_el0
    40201cf8:	f9407c08 	ldr	x8, [x0, #248]
    40201cfc:	f9400fe9 	ldr	x9, [sp, #24]
    40201d00:	a90953e9 	stp	x9, x20, [sp, #144]
    40201d04:	a90a23e0 	stp	x0, x8, [sp, #160]
    40201d08:	910243e4 	add	x4, sp, #0x90
    40201d0c:	528000e0 	mov	w0, #0x7                   	// #7
    40201d10:	aa1303e2 	mov	x2, x19
    40201d14:	aa1503e3 	mov	x3, x21
    40201d18:	9400020e 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40201d1c:	aa1603e0 	mov	x0, x22
    40201d20:	a9554ff4 	ldp	x20, x19, [sp, #336]
    40201d24:	a95457f6 	ldp	x22, x21, [sp, #320]
    40201d28:	a9535ff8 	ldp	x24, x23, [sp, #304]
    40201d2c:	a95267fa 	ldp	x26, x25, [sp, #288]
    40201d30:	a9516ffc 	ldp	x28, x27, [sp, #272]
    40201d34:	a9507bfd 	ldp	x29, x30, [sp, #256]
    40201d38:	910583ff 	add	sp, sp, #0x160
    40201d3c:	d65f03c0 	ret
    40201d40:	52800060 	mov	w0, #0x3                   	// #3
    40201d44:	9400057c 	bl	40203334 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    40201d48:	f942b303 	ldr	x3, [x24, #1376]
    40201d4c:	52800060 	mov	w0, #0x3                   	// #3
    40201d50:	52800081 	mov	w1, #0x4                   	// #4
    40201d54:	aa1303e2 	mov	x2, x19
    40201d58:	aa1603e4 	mov	x4, x22
    40201d5c:	aa1703e5 	mov	x5, x23
    40201d60:	94000253 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>
    40201d64:	52800040 	mov	w0, #0x2                   	// #2
    40201d68:	528000a1 	mov	w1, #0x5                   	// #5
    40201d6c:	aa1f03e2 	mov	x2, xzr
    40201d70:	52800043 	mov	w3, #0x2                   	// #2
    40201d74:	14000012 	b	40201dbc <jnox_kernel::ordinary_reservations::irq+0xaf4>
    40201d78:	52800040 	mov	w0, #0x2                   	// #2
    40201d7c:	528000a1 	mov	w1, #0x5                   	// #5
    40201d80:	aa1303e2 	mov	x2, x19
    40201d84:	52800043 	mov	w3, #0x2                   	// #2
    40201d88:	aa1503e4 	mov	x4, x21
    40201d8c:	94000248 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>
    40201d90:	52800040 	mov	w0, #0x2                   	// #2
    40201d94:	528000a1 	mov	w1, #0x5                   	// #5
    40201d98:	aa1f03e2 	mov	x2, xzr
    40201d9c:	52800043 	mov	w3, #0x2                   	// #2
    40201da0:	aa1603e4 	mov	x4, x22
    40201da4:	14000006 	b	40201dbc <jnox_kernel::ordinary_reservations::irq+0xaf4>
    40201da8:	52800040 	mov	w0, #0x2                   	// #2
    40201dac:	528000a1 	mov	w1, #0x5                   	// #5
    40201db0:	aa1f03e2 	mov	x2, xzr
    40201db4:	52800043 	mov	w3, #0x2                   	// #2
    40201db8:	aa0803e4 	mov	x4, x8
    40201dbc:	f94013e5 	ldr	x5, [sp, #32]
    40201dc0:	9400023b 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>
    40201dc4:	aa1f03e0 	mov	x0, xzr
    40201dc8:	aa1f03e1 	mov	x1, xzr
    40201dcc:	aa1303e2 	mov	x2, x19
    40201dd0:	52800043 	mov	w3, #0x2                   	// #2
    40201dd4:	aa1f03e4 	mov	x4, xzr
    40201dd8:	14000006 	b	40201df0 <jnox_kernel::ordinary_reservations::irq+0xb28>
    40201ddc:	394263e4 	ldrb	w4, [sp, #152]
    40201de0:	52800060 	mov	w0, #0x3                   	// #3
    40201de4:	52800041 	mov	w1, #0x2                   	// #2
    40201de8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201dec:	52800043 	mov	w3, #0x2                   	// #2
    40201df0:	aa1f03e5 	mov	x5, xzr
    40201df4:	9400022e 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>
    40201df8:	d503201f 	nop
    40201dfc:	10020422 	adr	x2, 40205e80 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.2706286857142130766+0x30>
    40201e00:	aa1303e0 	mov	x0, x19
    40201e04:	14000004 	b	40201e14 <jnox_kernel::ordinary_reservations::irq+0xb4c>
    40201e08:	d503201f 	nop
    40201e0c:	10020522 	adr	x2, 40205eb0 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.2706286857142130766+0x60>
    40201e10:	aa1503e0 	mov	x0, x21
    40201e14:	52800041 	mov	w1, #0x2                   	// #2
    40201e18:	94000baa 	bl	40204cc0 <core::panicking::panic_bounds_check>
    40201e1c:	94000092 	bl	40202064 <jnox_kernel::ordinary_reservations::run::{{closure}}>

0000000040201e20 <jnox_kernel::ordinary_reservations::run>:
    40201e20:	d105c3ff 	sub	sp, sp, #0x170
    40201e24:	a9127bfd 	stp	x29, x30, [sp, #288]
    40201e28:	a91367fa 	stp	x26, x25, [sp, #304]
    40201e2c:	a9145ff8 	stp	x24, x23, [sp, #320]
    40201e30:	a91557f6 	stp	x22, x21, [sp, #336]
    40201e34:	a9164ff4 	stp	x20, x19, [sp, #352]
    40201e38:	d5033fdf 	isb
    40201e3c:	d53be038 	mrs	x24, cntpct_el0
    40201e40:	d53be014 	mrs	x20, cntfrq_el0
    40201e44:	d5033fdf 	isb
    40201e48:	d53be028 	mrs	x8, cntpct_el0
    40201e4c:	b202e7e9 	mov	x9, #0xcccccccccccccccc    	// #-3689348814741910324
    40201e50:	f29999a9 	movk	x9, #0xcccd
    40201e54:	9bc97e89 	umulh	x9, x20, x9
    40201e58:	ab491113 	adds	x19, x8, x9, lsr #4
    40201e5c:	54000043 	b.cc	40201e64 <jnox_kernel::ordinary_reservations::run+0x44>  // b.lo, b.ul, b.last
    40201e60:	94000081 	bl	40202064 <jnox_kernel::ordinary_reservations::run::{{closure}}>
    40201e64:	910223e8 	add	x8, sp, #0x88
    40201e68:	aa1303e0 	mov	x0, x19
    40201e6c:	aa1403e1 	mov	x1, x20
    40201e70:	2a1f03e2 	mov	w2, wzr
    40201e74:	9400080c 	bl	40203ea4 <jnox_kernel::reservation_jobs::Clock::new>
    40201e78:	394223e8 	ldrb	w8, [sp, #136]
    40201e7c:	7100051f 	cmp	w8, #0x1
    40201e80:	54000061 	b.ne	40201e8c <jnox_kernel::ordinary_reservations::run+0x6c>  // b.any
    40201e84:	394227e4 	ldrb	w4, [sp, #137]
    40201e88:	14000014 	b	40201ed8 <jnox_kernel::ordinary_reservations::run+0xb8>
    40201e8c:	a9495bf7 	ldp	x23, x22, [sp, #144]
    40201e90:	f94053f5 	ldr	x21, [sp, #160]
    40201e94:	d5033fdf 	isb
    40201e98:	d53be021 	mrs	x1, cntpct_el0
    40201e9c:	a908dbf4 	stp	x20, x22, [sp, #136]
    40201ea0:	a909ffff 	stp	xzr, xzr, [sp, #152]
    40201ea4:	910223e4 	add	x4, sp, #0x88
    40201ea8:	52800020 	mov	w0, #0x1                   	// #1
    40201eac:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201eb0:	52800043 	mov	w3, #0x2                   	// #2
    40201eb4:	940001a7 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40201eb8:	910223e8 	add	x8, sp, #0x88
    40201ebc:	2a1f03e0 	mov	w0, wzr
    40201ec0:	2a1f03e1 	mov	w1, wzr
    40201ec4:	94000610 	bl	40203704 <jnox_kernel::reservation_jobs::Jobs::new>
    40201ec8:	f94047e8 	ldr	x8, [sp, #136]
    40201ecc:	f100091f 	cmp	x8, #0x2
    40201ed0:	54000101 	b.ne	40201ef0 <jnox_kernel::ordinary_reservations::run+0xd0>  // b.any
    40201ed4:	394243e4 	ldrb	w4, [sp, #144]
    40201ed8:	52800060 	mov	w0, #0x3                   	// #3
    40201edc:	52800041 	mov	w1, #0x2                   	// #2
    40201ee0:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201ee4:	52800043 	mov	w3, #0x2                   	// #2
    40201ee8:	aa1f03e5 	mov	x5, xzr
    40201eec:	940001f0 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>
    40201ef0:	910023e0 	add	x0, sp, #0x8
    40201ef4:	910223e1 	add	x1, sp, #0x88
    40201ef8:	52801002 	mov	w2, #0x80                  	// #128
    40201efc:	94000ec1 	bl	40205a00 <memcpy>
    40201f00:	d5033fdf 	isb
    40201f04:	d53be021 	mrs	x1, cntpct_el0
    40201f08:	a908cff8 	stp	x24, x19, [sp, #136]
    40201f0c:	a909ffff 	stp	xzr, xzr, [sp, #152]
    40201f10:	910223e4 	add	x4, sp, #0x88
    40201f14:	52800300 	mov	w0, #0x18                  	// #24
    40201f18:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201f1c:	52800043 	mov	w3, #0x2                   	// #2
    40201f20:	9400018c 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40201f24:	94000a24 	bl	402047b4 <jnox_kernel::context::init_timer_irq>
    40201f28:	aa1f03f4 	mov	x20, xzr
    40201f2c:	910423f8 	add	x24, sp, #0x108
    40201f30:	aa1403e0 	mov	x0, x20
    40201f34:	940001a8 	bl	402025d4 <jnox_kernel::ordinary_reservations::fresh>
    40201f38:	f8347b00 	str	x0, [x24, x20, lsl #3]
    40201f3c:	91000694 	add	x20, x20, #0x1
    40201f40:	f1000e9f 	cmp	x20, #0x3
    40201f44:	54ffff61 	b.ne	40201f30 <jnox_kernel::ordinary_reservations::run+0x110>  // b.any
    40201f48:	aa1f03f4 	mov	x20, xzr
    40201f4c:	d503201f 	nop
    40201f50:	100abe88 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766>
    40201f54:	52800318 	mov	w24, #0x18                  	// #24
    40201f58:	d503201f 	nop
    40201f5c:	1001f679 	adr	x25, 40205e28 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.2706286857142130766>
    40201f60:	d5033fdf 	isb
    40201f64:	d53be021 	mrs	x1, cntpct_el0
    40201f68:	f1000a9f 	cmp	x20, #0x2
    40201f6c:	54000062 	b.cs	40201f78 <jnox_kernel::ordinary_reservations::run+0x158>  // b.hs, b.nlast
    40201f70:	f8747b29 	ldr	x9, [x25, x20, lsl #3]
    40201f74:	14000002 	b	40201f7c <jnox_kernel::ordinary_reservations::run+0x15c>
    40201f78:	52818329 	mov	w9, #0xc19                 	// #3097
    40201f7c:	9140111a 	add	x26, x8, #0x4, lsl #12
    40201f80:	a908ebe8 	stp	x8, x26, [sp, #136]
    40201f84:	a909ffe9 	stp	x9, xzr, [sp, #152]
    40201f88:	910223e4 	add	x4, sp, #0x88
    40201f8c:	52800220 	mov	w0, #0x11                  	// #17
    40201f90:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201f94:	aa1403e3 	mov	x3, x20
    40201f98:	9400016e 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40201f9c:	f1002318 	subs	x24, x24, #0x8
    40201fa0:	91000694 	add	x20, x20, #0x1
    40201fa4:	aa1a03e8 	mov	x8, x26
    40201fa8:	54fffdc1 	b.ne	40201f60 <jnox_kernel::ordinary_reservations::run+0x140>  // b.any
    40201fac:	d503201f 	nop
    40201fb0:	1002a294 	adr	x20, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40201fb4:	910023e1 	add	x1, sp, #0x8
    40201fb8:	aa1403e0 	mov	x0, x20
    40201fbc:	52801002 	mov	w2, #0x80                  	// #128
    40201fc0:	94000e90 	bl	40205a00 <memcpy>
    40201fc4:	52800048 	mov	w8, #0x2                   	// #2
    40201fc8:	f9004288 	str	x8, [x20, #128]
    40201fcc:	52800069 	mov	w9, #0x3                   	// #3
    40201fd0:	3904c289 	strb	w9, [x20, #304]
    40201fd4:	a913da97 	stp	x23, x22, [x20, #312]
    40201fd8:	52800449 	mov	w9, #0x22                  	// #34
    40201fdc:	a914a695 	stp	x21, x9, [x20, #328]
    40201fe0:	9280000a 	mov	x10, #0xffffffffffffffff    	// #-1
    40201fe4:	a915a28a 	stp	x10, x8, [x20, #344]
    40201fe8:	a950b3eb 	ldp	x11, x12, [sp, #264]
    40201fec:	a916b28b 	stp	x11, x12, [x20, #360]
    40201ff0:	f9408feb 	ldr	x11, [sp, #280]
    40201ff4:	a917fe8b 	stp	x11, xzr, [x20, #376]
    40201ff8:	a918aa9f 	stp	xzr, x10, [x20, #392]
    40201ffc:	a919fe8a 	stp	x10, xzr, [x20, #408]
    40202000:	a91aa29f 	stp	xzr, x8, [x20, #424]
    40202004:	52800028 	mov	w8, #0x1                   	// #1
    40202008:	a91bfe88 	stp	x8, xzr, [x20, #440]
    4020200c:	52814328 	mov	w8, #0xa19                 	// #2585
    40202010:	a91ca29f 	stp	xzr, x8, [x20, #456]
    40202014:	52816328 	mov	w8, #0xb19                 	// #2841
    40202018:	f900ee88 	str	x8, [x20, #472]
    4020201c:	d5033fdf 	isb
    40202020:	d53be021 	mrs	x1, cntpct_el0
    40202024:	a908a7f3 	stp	x19, x9, [sp, #136]
    40202028:	a909ffff 	stp	xzr, xzr, [sp, #152]
    4020202c:	910223e4 	add	x4, sp, #0x88
    40202030:	52800040 	mov	w0, #0x2                   	// #2
    40202034:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40202038:	52800043 	mov	w3, #0x2                   	// #2
    4020203c:	94000145 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202040:	94000194 	bl	40202690 <jnox_kernel::ordinary_reservations::state>
    40202044:	aa1f03e0 	mov	x0, xzr
    40202048:	aa1f03e1 	mov	x1, xzr
    4020204c:	aa1303e2 	mov	x2, x19
    40202050:	9400032b 	bl	40202cfc <jnox_kernel::ordinary_reservations::Runtime::arm>
    40202054:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    40202058:	52800041 	mov	w1, #0x2                   	// #2
    4020205c:	94000482 	bl	40203264 <jnox_kernel::ordinary_reservations::Runtime::select>
    40202060:	97fffc53 	bl	402011ac <sched_start_frame>

0000000040202064 <jnox_kernel::ordinary_reservations::run::{{closure}}>:
    40202064:	f81f0ffe 	str	x30, [sp, #-16]!
    40202068:	97fffc90 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

000000004020206c <jnox_kernel::ordinary_reservations::svc>:
    4020206c:	f81f0ffe 	str	x30, [sp, #-16]!
    40202070:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202074:	f9420108 	ldr	x8, [x8, #1024]
    40202078:	f100091f 	cmp	x8, #0x2
    4020207c:	54000660 	b.eq	40202148 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.none
    40202080:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202084:	f942b108 	ldr	x8, [x8, #1376]
    40202088:	d503201f 	nop
    4020208c:	100ab4a9 	adr	x9, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766>
    40202090:	f100091f 	cmp	x8, #0x2
    40202094:	8b08392a 	add	x10, x9, x8, lsl #14
    40202098:	fa401142 	ccmp	x10, x0, #0x2, ne  // ne = any
    4020209c:	54000568 	b.hi	40202148 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    402020a0:	b10d041f 	cmn	x0, #0x341
    402020a4:	54000528 	b.hi	40202148 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    402020a8:	d372c508 	lsl	x8, x8, #14
    402020ac:	8b080128 	add	x8, x9, x8
    402020b0:	91401108 	add	x8, x8, #0x4, lsl #12
    402020b4:	910d0009 	add	x9, x0, #0x340
    402020b8:	eb08013f 	cmp	x9, x8
    402020bc:	54000468 	b.hi	40202148 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    402020c0:	f9409c01 	ldr	x1, [x0, #312]
    402020c4:	d5385203 	mrs	x3, esr_el1
    402020c8:	d35afc68 	lsr	x8, x3, #26
    402020cc:	f100551f 	cmp	x8, #0x15
    402020d0:	540003c1 	b.ne	40202148 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.any
    402020d4:	12003c68 	and	w8, w3, #0xffff
    402020d8:	7100051f 	cmp	w8, #0x1
    402020dc:	540000a0 	b.eq	402020f0 <jnox_kernel::ordinary_reservations::svc+0x84>  // b.none
    402020e0:	7100091f 	cmp	w8, #0x2
    402020e4:	54000321 	b.ne	40202148 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.any
    402020e8:	52800042 	mov	w2, #0x2                   	// #2
    402020ec:	14000002 	b	402020f4 <jnox_kernel::ordinary_reservations::svc+0x88>
    402020f0:	52800022 	mov	w2, #0x1                   	// #1
    402020f4:	94000323 	bl	40202d80 <jnox_kernel::ordinary_reservations::Runtime::close>
    402020f8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402020fc:	9114e108 	add	x8, x8, #0x538
    40202100:	f9401100 	ldr	x0, [x8, #32]
    40202104:	91000409 	add	x9, x0, #0x1
    40202108:	a9402908 	ldp	x8, x10, [x8]
    4020210c:	9bca7d2b 	umulh	x11, x9, x10
    40202110:	eb0b03ff 	cmp	xzr, x11
    40202114:	1a9f07eb 	cset	w11, ne  // ne = any
    40202118:	9b0a7d29 	mul	x9, x9, x10
    4020211c:	ab080122 	adds	x2, x9, x8
    40202120:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40202124:	3700014b 	tbnz	w11, #0, 4020214c <jnox_kernel::ordinary_reservations::svc+0xe0>
    40202128:	35000128 	cbnz	w8, 4020214c <jnox_kernel::ordinary_reservations::svc+0xe0>
    4020212c:	aa1f03e1 	mov	x1, xzr
    40202130:	940002f3 	bl	40202cfc <jnox_kernel::ordinary_reservations::Runtime::arm>
    40202134:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202138:	f942ad00 	ldr	x0, [x8, #1368]
    4020213c:	52800041 	mov	w1, #0x2                   	// #2
    40202140:	f84107fe 	ldr	x30, [sp], #16
    40202144:	14000448 	b	40203264 <jnox_kernel::ordinary_reservations::Runtime::select>
    40202148:	97fffc58 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    4020214c:	52800060 	mov	w0, #0x3                   	// #3
    40202150:	94000479 	bl	40203334 <jnox_kernel::ordinary_reservations::checked::{{closure}}>

0000000040202154 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766>:
    40202154:	d10743ff 	sub	sp, sp, #0x1d0
    40202158:	a9177bfd 	stp	x29, x30, [sp, #368]
    4020215c:	a9186ffc 	stp	x28, x27, [sp, #384]
    40202160:	a91967fa 	stp	x26, x25, [sp, #400]
    40202164:	a91a5ff8 	stp	x24, x23, [sp, #416]
    40202168:	a91b57f6 	stp	x22, x21, [sp, #432]
    4020216c:	a91c4ff4 	stp	x20, x19, [sp, #448]
    40202170:	d50342df 	msr	daifset, #0x2
    40202174:	d5033fdf 	isb
    40202178:	d5033fdf 	isb
    4020217c:	d53be036 	mrs	x22, cntpct_el0
    40202180:	b0000035 	adrp	x21, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202184:	f94202a8 	ldr	x8, [x21, #1024]
    40202188:	f100091f 	cmp	x8, #0x2
    4020218c:	54001ac0 	b.eq	402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>  // b.none
    40202190:	d5033fdf 	isb
    40202194:	d53be038 	mrs	x24, cntpct_el0
    40202198:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020219c:	f942f108 	ldr	x8, [x8, #1504]
    402021a0:	f100091f 	cmp	x8, #0x2
    402021a4:	54001a01 	b.ne	402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>  // b.any
    402021a8:	b0000037 	adrp	x23, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021ac:	f9429ef3 	ldr	x19, [x23, #1336]
    402021b0:	d503201f 	nop
    402021b4:	1010b168 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    402021b8:	c8dffd08 	ldar	x8, [x8]
    402021bc:	b5001948 	cbnz	x8, 402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>
    402021c0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021c4:	91156108 	add	x8, x8, #0x558
    402021c8:	f9400109 	ldr	x9, [x8]
    402021cc:	b100053f 	cmn	x9, #0x1
    402021d0:	540018a1 	b.ne	402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>  // b.any
    402021d4:	f9400508 	ldr	x8, [x8, #8]
    402021d8:	f100091f 	cmp	x8, #0x2
    402021dc:	54001841 	b.ne	402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>  // b.any
    402021e0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021e4:	9114c108 	add	x8, x8, #0x530
    402021e8:	39400109 	ldrb	w9, [x8]
    402021ec:	71000d3f 	cmp	w9, #0x3
    402021f0:	540017a1 	b.ne	402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>  // b.any
    402021f4:	f9402d09 	ldr	x9, [x8, #88]
    402021f8:	b5001769 	cbnz	x9, 402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>
    402021fc:	f9402908 	ldr	x8, [x8, #80]
    40202200:	eb13011f 	cmp	x8, x19
    40202204:	54001701 	b.ne	402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>  // b.any
    40202208:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766+0xb8e0>
    4020220c:	f943f508 	ldr	x8, [x8, #2024]
    40202210:	f100051f 	cmp	x8, #0x1
    40202214:	54001681 	b.ne	402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>  // b.any
    40202218:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020221c:	f9423508 	ldr	x8, [x8, #1128]
    40202220:	b5001628 	cbnz	x8, 402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>
    40202224:	5280002a 	mov	w10, #0x1                   	// #1
    40202228:	d503201f 	nop
    4020222c:	10028eb9 	adr	x25, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40202230:	8b080328 	add	x8, x25, x8
    40202234:	3941e109 	ldrb	w9, [x8, #120]
    40202238:	3600008a 	tbz	w10, #0, 40202248 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0xf4>
    4020223c:	2a1f03ea 	mov	w10, wzr
    40202240:	52800028 	mov	w8, #0x1                   	// #1
    40202244:	34ffff69 	cbz	w9, 40202230 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0xdc>
    40202248:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020224c:	39518108 	ldrb	w8, [x8, #1120]
    40202250:	7100013f 	cmp	w9, #0x0
    40202254:	7a430900 	ccmp	w8, #0x3, #0x0, eq  // eq = none
    40202258:	54001461 	b.ne	402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>  // b.any
    4020225c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202260:	9111c108 	add	x8, x8, #0x470
    40202264:	f9400109 	ldr	x9, [x8]
    40202268:	b50013e9 	cbnz	x9, 402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>
    4020226c:	f9400908 	ldr	x8, [x8, #16]
    40202270:	f100091f 	cmp	x8, #0x2
    40202274:	54001381 	b.ne	402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>  // b.any
    40202278:	f94202a8 	ldr	x8, [x21, #1024]
    4020227c:	f100051f 	cmp	x8, #0x1
    40202280:	54000121 	b.ne	402022a4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x150>  // b.any
    40202284:	b0000021 	adrp	x1, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202288:	91102021 	add	x1, x1, #0x408
    4020228c:	f940183a 	ldr	x26, [x1, #48]
    40202290:	910243e0 	add	x0, sp, #0x90
    40202294:	52800602 	mov	w2, #0x30                  	// #48
    40202298:	94000dda 	bl	40205a00 <memcpy>
    4020229c:	52800028 	mov	w8, #0x1                   	// #1
    402022a0:	14000017 	b	402022fc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x1a8>
    402022a4:	910303e0 	add	x0, sp, #0xc0
    402022a8:	9100a014 	add	x20, x0, #0x28
    402022ac:	52800028 	mov	w8, #0x1                   	// #1
    402022b0:	b0000021 	adrp	x1, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402022b4:	91102021 	add	x1, x1, #0x408
    402022b8:	2a0803fa 	mov	w26, w8
    402022bc:	9100a03b 	add	x27, x1, #0x28
    402022c0:	52800502 	mov	w2, #0x28                  	// #40
    402022c4:	94000dcf 	bl	40205a00 <memcpy>
    402022c8:	2a1f03e8 	mov	w8, wzr
    402022cc:	aa1b03e1 	mov	x1, x27
    402022d0:	aa1403e0 	mov	x0, x20
    402022d4:	3707ff3a 	tbnz	w26, #0, 402022b8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x164>
    402022d8:	910243e0 	add	x0, sp, #0x90
    402022dc:	910303e1 	add	x1, sp, #0xc0
    402022e0:	52800602 	mov	w2, #0x30                  	// #48
    402022e4:	94000dc7 	bl	40205a00 <memcpy>
    402022e8:	aa1f03e8 	mov	x8, xzr
    402022ec:	a94f27fa 	ldp	x26, x9, [sp, #240]
    402022f0:	a9502fea 	ldp	x10, x11, [sp, #256]
    402022f4:	a907abe9 	stp	x9, x10, [sp, #120]
    402022f8:	f90047eb 	str	x11, [sp, #136]
    402022fc:	b000003b 	adrp	x27, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202300:	9111e37b 	add	x27, x27, #0x478
    40202304:	39400b7c 	ldrb	w28, [x27, #2]
    40202308:	7940037d 	ldrh	w29, [x27]
    4020230c:	aa1b03f4 	mov	x20, x27
    40202310:	f8008e88 	str	x8, [x20, #8]!
    40202314:	91004360 	add	x0, x27, #0x10
    40202318:	910243e1 	add	x1, sp, #0x90
    4020231c:	52800602 	mov	w2, #0x30                  	// #48
    40202320:	94000db8 	bl	40205a00 <memcpy>
    40202324:	52800068 	mov	w8, #0x3                   	// #3
    40202328:	3901a368 	strb	w8, [x27, #104]
    4020232c:	a947a7e8 	ldp	x8, x9, [sp, #120]
    40202330:	a904237a 	stp	x26, x8, [x27, #64]
    40202334:	f94047e8 	ldr	x8, [sp, #136]
    40202338:	a9052369 	stp	x9, x8, [x27, #80]
    4020233c:	a9077f7f 	stp	xzr, xzr, [x27, #112]
    40202340:	7901037d 	strh	w29, [x27, #128]
    40202344:	39020b7c 	strb	w28, [x27, #130]
    40202348:	910303e8 	add	x8, sp, #0xc0
    4020234c:	aa1403e0 	mov	x0, x20
    40202350:	9400047c 	bl	40203540 <jnox_kernel::reservation_jobs::Jobs::prepare_destination>
    40202354:	f94063e8 	ldr	x8, [sp, #192]
    40202358:	f100091f 	cmp	x8, #0x2
    4020235c:	54000cc0 	b.eq	402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x3a0>  // b.none
    40202360:	910043e0 	add	x0, sp, #0x10
    40202364:	910303e1 	add	x1, sp, #0xc0
    40202368:	52800d02 	mov	w2, #0x68                  	// #104
    4020236c:	94000da5 	bl	40205a00 <memcpy>
    40202370:	b0000020 	adrp	x0, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202374:	91120000 	add	x0, x0, #0x480
    40202378:	910043e1 	add	x1, sp, #0x10
    4020237c:	94000488 	bl	4020359c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision>
    40202380:	36000b20 	tbz	w0, #0, 402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>
    40202384:	b94013e8 	ldr	w8, [sp, #16]
    40202388:	36000b48 	tbz	w8, #0, 402024f0 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x39c>
    4020238c:	3941cbe8 	ldrb	w8, [sp, #114]
    40202390:	34000188 	cbz	w8, 402023c0 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x26c>
    40202394:	71000d1f 	cmp	w8, #0x3
    40202398:	54000a60 	b.eq	402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>  // b.none
    4020239c:	f9400fe0 	ldr	x0, [sp, #24]
    402023a0:	f100041f 	cmp	x0, #0x1
    402023a4:	54000ce8 	b.hi	40202540 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x3ec>  // b.pmore
    402023a8:	8b000f28 	add	x8, x25, x0, lsl #3
    402023ac:	f940e108 	ldr	x8, [x8, #448]
    402023b0:	b104011f 	cmn	x8, #0x100
    402023b4:	540009e2 	b.cs	402024f0 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x39c>  // b.hs, b.nlast
    402023b8:	9104011a 	add	x26, x8, #0x100
    402023bc:	14000002 	b	402023c4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x270>
    402023c0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    402023c4:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402023c8:	9114e108 	add	x8, x8, #0x538
    402023cc:	a9402508 	ldp	x8, x9, [x8]
    402023d0:	ab09011b 	adds	x27, x8, x9
    402023d4:	540008a2 	b.cs	402024e8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x394>  // b.hs, b.nlast
    402023d8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402023dc:	f942a508 	ldr	x8, [x8, #1352]
    402023e0:	eb08037c 	subs	x28, x27, x8
    402023e4:	54000823 	b.cc	402024e8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x394>  // b.lo, b.ul, b.last
    402023e8:	f9009bf9 	str	x25, [sp, #304]
    402023ec:	910303f4 	add	x20, sp, #0xc0
    402023f0:	9104e3e8 	add	x8, sp, #0x138
    402023f4:	9104c3e0 	add	x0, sp, #0x130
    402023f8:	aa1f03e1 	mov	x1, xzr
    402023fc:	94000717 	bl	40204058 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    40202400:	910303e0 	add	x0, sp, #0xc0
    40202404:	9104e3e1 	add	x1, sp, #0x138
    40202408:	52800702 	mov	w2, #0x38                  	// #56
    4020240c:	94000d7d 	bl	40205a00 <memcpy>
    40202410:	52800039 	mov	w25, #0x1                   	// #1
    40202414:	9104e3e8 	add	x8, sp, #0x138
    40202418:	9104c3e0 	add	x0, sp, #0x130
    4020241c:	52800021 	mov	w1, #0x1                   	// #1
    40202420:	9400070e 	bl	40204058 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    40202424:	9100e280 	add	x0, x20, #0x38
    40202428:	9104e3e1 	add	x1, sp, #0x138
    4020242c:	52800702 	mov	w2, #0x38                  	// #56
    40202430:	94000d74 	bl	40205a00 <memcpy>
    40202434:	d503201f 	nop
    40202438:	10028d54 	adr	x20, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    4020243c:	910043e1 	add	x1, sp, #0x10
    40202440:	aa1403e0 	mov	x0, x20
    40202444:	52800d02 	mov	w2, #0x68                  	// #104
    40202448:	94000d6e 	bl	40205a00 <memcpy>
    4020244c:	a906e698 	stp	x24, x25, [x20, #104]
    40202450:	a907ee93 	stp	x19, x27, [x20, #120]
    40202454:	a908ea9c 	stp	x28, x26, [x20, #136]
    40202458:	91026280 	add	x0, x20, #0x98
    4020245c:	910303e1 	add	x1, sp, #0xc0
    40202460:	52800e02 	mov	w2, #0x70                  	// #112
    40202464:	94000d67 	bl	40205a00 <memcpy>
    40202468:	d5033fdf 	isb
    4020246c:	d53be034 	mrs	x20, cntpct_el0
    40202470:	eb140268 	subs	x8, x19, x20
    40202474:	9a8833e8 	csel	x8, xzr, x8, cc  // cc = lo, ul, last
    40202478:	a913cff8 	stp	x24, x19, [sp, #312]
    4020247c:	a914ffe8 	stp	x8, xzr, [sp, #328]
    40202480:	9104e3e4 	add	x4, sp, #0x138
    40202484:	528002c0 	mov	w0, #0x16                  	// #22
    40202488:	aa1403e1 	mov	x1, x20
    4020248c:	aa1f03e2 	mov	x2, xzr
    40202490:	52800043 	mov	w3, #0x2                   	// #2
    40202494:	9400002f 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202498:	eb18029f 	cmp	x20, x24
    4020249c:	540003a3 	b.cc	40202510 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x3bc>  // b.lo, b.ul, b.last
    402024a0:	eb13029f 	cmp	x20, x19
    402024a4:	54000362 	b.cs	40202510 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x3bc>  // b.hs, b.nlast
    402024a8:	d5033fdf 	isb
    402024ac:	d53be024 	mrs	x4, cntpct_el0
    402024b0:	d503201f 	nop
    402024b4:	10109368 	adr	x8, 40223720 <jnox_kernel::ordinary_reservations::RECEIPT>
    402024b8:	a9001116 	stp	x22, x4, [x8]
    402024bc:	f94202a8 	ldr	x8, [x21, #1024]
    402024c0:	f100091f 	cmp	x8, #0x2
    402024c4:	54000100 	b.eq	402024e4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x390>  // b.none
    402024c8:	f9429ee5 	ldr	x5, [x23, #1336]
    402024cc:	eb05009f 	cmp	x4, x5
    402024d0:	540002e2 	b.cs	4020252c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x3d8>  // b.hs, b.nlast
    402024d4:	d50342ff 	msr	daifclr, #0x2
    402024d8:	d5033fdf 	isb
    402024dc:	d503207f 	wfi
    402024e0:	17ffffff 	b	402024dc <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766+0x388>
    402024e4:	97fffb71 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402024e8:	52800060 	mov	w0, #0x3                   	// #3
    402024ec:	94000392 	bl	40203334 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    402024f0:	97fffedd 	bl	40202064 <jnox_kernel::ordinary_reservations::run::{{closure}}>
    402024f4:	394323e4 	ldrb	w4, [sp, #200]
    402024f8:	52800060 	mov	w0, #0x3                   	// #3
    402024fc:	52800041 	mov	w1, #0x2                   	// #2
    40202500:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40202504:	52800043 	mov	w3, #0x2                   	// #2
    40202508:	aa1f03e5 	mov	x5, xzr
    4020250c:	94000068 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>
    40202510:	52800040 	mov	w0, #0x2                   	// #2
    40202514:	52800121 	mov	w1, #0x9                   	// #9
    40202518:	aa1f03e2 	mov	x2, xzr
    4020251c:	52800043 	mov	w3, #0x2                   	// #2
    40202520:	aa1403e4 	mov	x4, x20
    40202524:	aa1303e5 	mov	x5, x19
    40202528:	94000061 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>
    4020252c:	52800040 	mov	w0, #0x2                   	// #2
    40202530:	52800161 	mov	w1, #0xb                   	// #11
    40202534:	aa1f03e2 	mov	x2, xzr
    40202538:	52800043 	mov	w3, #0x2                   	// #2
    4020253c:	9400005c 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>
    40202540:	d503201f 	nop
    40202544:	1001caa2 	adr	x2, 40205e98 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.2706286857142130766+0x48>
    40202548:	52800041 	mov	w1, #0x2                   	// #2
    4020254c:	940009dd 	bl	40204cc0 <core::panicking::panic_bounds_check>

0000000040202550 <jnox_kernel::ordinary_reservations::event>:
    40202550:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202554:	f9438909 	ldr	x9, [x8, #1808]
    40202558:	f110013f 	cmp	x9, #0x400
    4020255c:	54000241 	b.ne	402025a4 <jnox_kernel::ordinary_reservations::event+0x54>  // b.any
    40202560:	aa1f03e8 	mov	x8, xzr
    40202564:	52800309 	mov	w9, #0x18                  	// #24
    40202568:	72a12009 	movk	w9, #0x900, lsl #16
    4020256c:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    40202570:	d503201f 	nop
    40202574:	1001c62b 	adr	x11, 40205e38 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.2706286857142130766+0x10>
    40202578:	3868696c 	ldrb	w12, [x11, x8]
    4020257c:	b940012d 	ldr	w13, [x9]
    40202580:	3628006d 	tbz	w13, #5, 4020258c <jnox_kernel::ordinary_reservations::event+0x3c>
    40202584:	d5033fdf 	isb
    40202588:	17fffffd 	b	4020257c <jnox_kernel::ordinary_reservations::event+0x2c>
    4020258c:	91000508 	add	x8, x8, #0x1
    40202590:	b900014c 	str	w12, [x10]
    40202594:	f100511f 	cmp	x8, #0x14
    40202598:	54ffff01 	b.ne	40202578 <jnox_kernel::ordinary_reservations::event+0x28>  // b.any
    4020259c:	d503205f 	wfe
    402025a0:	17ffffff 	b	4020259c <jnox_kernel::ordinary_reservations::event+0x4c>
    402025a4:	d503201f 	nop
    402025a8:	10028b8a 	adr	x10, 40207718 <jnox_kernel::ordinary_reservations::TRACE>
    402025ac:	8b09194a 	add	x10, x10, x9, lsl #6
    402025b0:	a9000540 	stp	x0, x1, [x10]
    402025b4:	a940308b 	ldp	x11, x12, [x4]
    402025b8:	a9010d42 	stp	x2, x3, [x10, #16]
    402025bc:	a941388d 	ldp	x13, x14, [x4, #16]
    402025c0:	a902314b 	stp	x11, x12, [x10, #32]
    402025c4:	a903394d 	stp	x13, x14, [x10, #48]
    402025c8:	91000529 	add	x9, x9, #0x1
    402025cc:	f9038909 	str	x9, [x8, #1808]
    402025d0:	d65f03c0 	ret

00000000402025d4 <jnox_kernel::ordinary_reservations::fresh>:
    402025d4:	d10143ff 	sub	sp, sp, #0x50
    402025d8:	a90357f6 	stp	x22, x21, [sp, #48]
    402025dc:	a9044ff4 	stp	x20, x19, [sp, #64]
    402025e0:	aa0003f3 	mov	x19, x0
    402025e4:	d503201f 	nop
    402025e8:	10007a08 	adr	x8, 40203528 <reservation_worker_a>
    402025ec:	d503201f 	nop
    402025f0:	10007a29 	adr	x9, 40203534 <reservation_worker_b>
    402025f4:	d503201f 	nop
    402025f8:	10ffdaea 	adr	x10, 40202154 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.2706286857142130766>
    402025fc:	a900a7e8 	stp	x8, x9, [sp, #8]
    40202600:	a901fbea 	stp	x10, x30, [sp, #24]
    40202604:	f100081f 	cmp	x0, #0x2
    40202608:	540003a8 	b.hi	4020267c <jnox_kernel::ordinary_reservations::fresh+0xa8>  // b.pmore
    4020260c:	910023e8 	add	x8, sp, #0x8
    40202610:	f8737915 	ldr	x21, [x8, x19, lsl #3]
    40202614:	d503201f 	nop
    40202618:	100a8848 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766>
    4020261c:	8b133916 	add	x22, x8, x19, lsl #14
    40202620:	52879808 	mov	w8, #0x3cc0                	// #15552
    40202624:	8b0802d4 	add	x20, x22, x8
    40202628:	aa1403e0 	mov	x0, x20
    4020262c:	2a1f03e1 	mov	w1, wzr
    40202630:	52806802 	mov	w2, #0x340                 	// #832
    40202634:	94000d7f 	bl	40205c30 <memset>
    40202638:	f91eded5 	str	x21, [x22, #15800]
    4020263c:	528068a8 	mov	w8, #0x345                 	// #837
    40202640:	f91ee2c8 	str	x8, [x22, #15808]
    40202644:	f1000a7f 	cmp	x19, #0x2
    40202648:	54000061 	b.ne	40202654 <jnox_kernel::ordinary_reservations::fresh+0x80>  // b.any
    4020264c:	52818328 	mov	w8, #0xc19                 	// #3097
    40202650:	14000004 	b	40202660 <jnox_kernel::ordinary_reservations::fresh+0x8c>
    40202654:	d503201f 	nop
    40202658:	1001be88 	adr	x8, 40205e28 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.2706286857142130766>
    4020265c:	f8737908 	ldr	x8, [x8, x19, lsl #3]
    40202660:	f9008e88 	str	x8, [x20, #280]
    40202664:	aa1403e0 	mov	x0, x20
    40202668:	a9444ff4 	ldp	x20, x19, [sp, #64]
    4020266c:	a94357f6 	ldp	x22, x21, [sp, #48]
    40202670:	f94013fe 	ldr	x30, [sp, #32]
    40202674:	910143ff 	add	sp, sp, #0x50
    40202678:	d65f03c0 	ret
    4020267c:	d503201f 	nop
    40202680:	1001be82 	adr	x2, 40205e50 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.2706286857142130766>
    40202684:	aa1303e0 	mov	x0, x19
    40202688:	52800061 	mov	w1, #0x3                   	// #3
    4020268c:	9400098d 	bl	40204cc0 <core::panicking::panic_bounds_check>

0000000040202690 <jnox_kernel::ordinary_reservations::state>:
    40202690:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202694:	f9420108 	ldr	x8, [x8, #1024]
    40202698:	f100091f 	cmp	x8, #0x2
    4020269c:	54000040 	b.eq	402026a4 <jnox_kernel::ordinary_reservations::state+0x14>  // b.none
    402026a0:	d65f03c0 	ret
    402026a4:	f81f0ffe 	str	x30, [sp, #-16]!
    402026a8:	97fffb00 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

00000000402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>:
    402026ac:	d10603ff 	sub	sp, sp, #0x180
    402026b0:	a9127bfd 	stp	x29, x30, [sp, #288]
    402026b4:	a9136ffc 	stp	x28, x27, [sp, #304]
    402026b8:	a91467fa 	stp	x26, x25, [sp, #320]
    402026bc:	a9155ff8 	stp	x24, x23, [sp, #336]
    402026c0:	a91657f6 	stp	x22, x21, [sp, #352]
    402026c4:	a9174ff4 	stp	x20, x19, [sp, #368]
    402026c8:	d5034fdf 	msr	daifset, #0xf
    402026cc:	d51be23f 	msr	cntp_ctl_el0, xzr
    402026d0:	d5033fdf 	isb
    402026d4:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766+0xb8e0>
    402026d8:	395f6109 	ldrb	w9, [x8, #2008]
    402026dc:	7100053f 	cmp	w9, #0x1
    402026e0:	54000061 	b.ne	402026ec <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x40>  // b.any
    402026e4:	d503205f 	wfe
    402026e8:	17ffffff 	b	402026e4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x38>
    402026ec:	aa0303fb 	mov	x27, x3
    402026f0:	aa0203fc 	mov	x28, x2
    402026f4:	a90807e0 	stp	x0, x1, [sp, #128]
    402026f8:	a90917e4 	stp	x4, x5, [sp, #144]
    402026fc:	52800029 	mov	w9, #0x1                   	// #1
    40202700:	391f6109 	strb	w9, [x8, #2008]
    40202704:	d503201f 	nop
    40202708:	1010b908 	adr	x8, 40223e28 <jnox_kernel::ordinary_reservations::stage_hooks::stage_probe::OBSERVATION>
    4020270c:	f940050a 	ldr	x10, [x8, #8]
    40202710:	f940090b 	ldr	x11, [x8, #16]
    40202714:	f9400108 	ldr	x8, [x8]
    40202718:	7200011f 	tst	w8, #0x1
    4020271c:	9a9f116b 	csel	x11, x11, xzr, ne  // ne = any
    40202720:	9a9f1141 	csel	x1, x10, xzr, ne  // ne = any
    40202724:	5280004a 	mov	w10, #0x2                   	// #2
    40202728:	a90ba7ea 	stp	x10, x9, [sp, #184]
    4020272c:	f100011f 	cmp	x8, #0x0
    40202730:	1a9f07e8 	cset	w8, ne  // ne = any
    40202734:	a90cafe8 	stp	x8, x11, [sp, #200]
    40202738:	9102e3e4 	add	x4, sp, #0xb8
    4020273c:	528004c0 	mov	w0, #0x26                  	// #38
    40202740:	aa1f03e2 	mov	x2, xzr
    40202744:	52800043 	mov	w3, #0x2                   	// #2
    40202748:	97ffff82 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    4020274c:	d503201f 	nop
    40202750:	10107e89 	adr	x9, 40223720 <jnox_kernel::ordinary_reservations::RECEIPT>
    40202754:	a9400528 	ldp	x8, x1, [x9]
    40202758:	a9415538 	ldp	x24, x21, [x9, #16]
    4020275c:	a9424d34 	ldp	x20, x19, [x9, #32]
    40202760:	a943692b 	ldp	x11, x26, [x9, #48]
    40202764:	f940212a 	ldr	x10, [x9, #64]
    40202768:	a9012fea 	stp	x10, x11, [sp, #16]
    4020276c:	a944a92b 	ldp	x11, x10, [x9, #72]
    40202770:	a9022beb 	stp	x11, x10, [sp, #32]
    40202774:	a945a93d 	ldp	x29, x10, [x9, #88]
    40202778:	f9005bea 	str	x10, [sp, #176]
    4020277c:	a946a92b 	ldp	x11, x10, [x9, #104]
    40202780:	f9001fea 	str	x10, [sp, #56]
    40202784:	f9403d2a 	ldr	x10, [x9, #120]
    40202788:	a9042fea 	stp	x10, x11, [sp, #64]
    4020278c:	a948292b 	ldp	x11, x10, [x9, #128]
    40202790:	f9001beb 	str	x11, [sp, #48]
    40202794:	f9003fea 	str	x10, [sp, #120]
    40202798:	a949292b 	ldp	x11, x10, [x9, #144]
    4020279c:	a9062fea 	stp	x10, x11, [sp, #96]
    402027a0:	a94a292b 	ldp	x11, x10, [x9, #160]
    402027a4:	a9052fea 	stp	x10, x11, [sp, #80]
    402027a8:	f9405929 	ldr	x9, [x9, #176]
    402027ac:	f9003be9 	str	x9, [sp, #112]
    402027b0:	d5033fdf 	isb
    402027b4:	d53be039 	mrs	x25, cntpct_el0
    402027b8:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402027bc:	d503201f 	nop
    402027c0:	10027116 	adr	x22, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    402027c4:	f942f137 	ldr	x23, [x9, #1504]
    402027c8:	a90a6ffc 	stp	x28, x27, [sp, #160]
    402027cc:	b40001a1 	cbz	x1, 40202800 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x154>
    402027d0:	f9403ec9 	ldr	x9, [x22, #120]
    402027d4:	f1000aff 	cmp	x23, #0x2
    402027d8:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    402027dc:	a90b87e8 	stp	x8, x1, [sp, #184]
    402027e0:	a90cffe9 	stp	x9, xzr, [sp, #200]
    402027e4:	9102e3e4 	add	x4, sp, #0xb8
    402027e8:	52800480 	mov	w0, #0x24                  	// #36
    402027ec:	aa1f03e2 	mov	x2, xzr
    402027f0:	52800043 	mov	w3, #0x2                   	// #2
    402027f4:	97ffff57 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    402027f8:	f94002c8 	ldr	x8, [x22]
    402027fc:	14000002 	b	40202804 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x158>
    40202800:	aa1703e8 	mov	x8, x23
    40202804:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202808:	9117a129 	add	x9, x9, #0x5e8
    4020280c:	f940012a 	ldr	x10, [x9]
    40202810:	7200011f 	tst	w8, #0x1
    40202814:	52800048 	mov	w8, #0x2                   	// #2
    40202818:	f9403529 	ldr	x9, [x9, #104]
    4020281c:	9a881148 	csel	x8, x10, x8, ne  // ne = any
    40202820:	f1000aff 	cmp	x23, #0x2
    40202824:	da9f113b 	csinv	x27, x9, xzr, ne  // ne = any
    40202828:	9a8802fc 	csel	x28, x23, x8, eq  // eq = none
    4020282c:	d503201f 	nop
    40202830:	10107d88 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    40202834:	c8dffd08 	ldar	x8, [x8]
    40202838:	a90be3fb 	stp	x27, x24, [sp, #184]
    4020283c:	f27e031f 	tst	x24, #0x4
    40202840:	f9405be9 	ldr	x9, [sp, #176]
    40202844:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    40202848:	a90ca7e8 	stp	x8, x9, [sp, #200]
    4020284c:	9102e3e4 	add	x4, sp, #0xb8
    40202850:	52800300 	mov	w0, #0x18                  	// #24
    40202854:	aa1903e1 	mov	x1, x25
    40202858:	aa1f03e2 	mov	x2, xzr
    4020285c:	aa1c03e3 	mov	x3, x28
    40202860:	97ffff3c 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202864:	37001d58 	tbnz	w24, #0, 40202c0c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x560>
    40202868:	37081f78 	tbnz	w24, #1, 40202c54 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x5a8>
    4020286c:	371020f8 	tbnz	w24, #2, 40202c88 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x5dc>
    40202870:	37182258 	tbnz	w24, #3, 40202cb8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x60c>
    40202874:	36200378 	tbz	w24, #4, 402028e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x234>
    40202878:	a94627e8 	ldp	x8, x9, [sp, #96]
    4020287c:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202880:	a94527e8 	ldp	x8, x9, [sp, #80]
    40202884:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202888:	9102e3e4 	add	x4, sp, #0xb8
    4020288c:	528003a0 	mov	w0, #0x1d                  	// #29
    40202890:	f9403ff3 	ldr	x19, [sp, #120]
    40202894:	aa1303e1 	mov	x1, x19
    40202898:	aa1f03e2 	mov	x2, xzr
    4020289c:	aa1c03e3 	mov	x3, x28
    402028a0:	97ffff2c 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    402028a4:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402028a8:	91196108 	add	x8, x8, #0x658
    402028ac:	a9402109 	ldp	x9, x8, [x8]
    402028b0:	f1000aff 	cmp	x23, #0x2
    402028b4:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    402028b8:	f9403bea 	ldr	x10, [sp, #112]
    402028bc:	a90ba7ea 	stp	x10, x9, [sp, #184]
    402028c0:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    402028c4:	a90cefe8 	stp	x8, x27, [sp, #200]
    402028c8:	9102e3e4 	add	x4, sp, #0xb8
    402028cc:	528003c0 	mov	w0, #0x1e                  	// #30
    402028d0:	aa1303e1 	mov	x1, x19
    402028d4:	aa1f03e2 	mov	x2, xzr
    402028d8:	aa1c03e3 	mov	x3, x28
    402028dc:	97ffff1d 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    402028e0:	f1000aff 	cmp	x23, #0x2
    402028e4:	54000800 	b.eq	402029e4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x338>  // b.none
    402028e8:	aa1f03f3 	mov	x19, xzr
    402028ec:	52800028 	mov	w8, #0x1                   	// #1
    402028f0:	52800714 	mov	w20, #0x38                  	// #56
    402028f4:	9b145a77 	madd	x23, x19, x20, x22
    402028f8:	2a0803f5 	mov	w21, w8
    402028fc:	a949a6e8 	ldp	x8, x9, [x23, #152]
    40202900:	f94056ea 	ldr	x10, [x23, #168]
    40202904:	a90ba7e8 	stp	x8, x9, [sp, #184]
    40202908:	f9405ee8 	ldr	x8, [x23, #184]
    4020290c:	a90ca3ea 	stp	x10, x8, [sp, #200]
    40202910:	9102e3e4 	add	x4, sp, #0xb8
    40202914:	52800440 	mov	w0, #0x22                  	// #34
    40202918:	aa1903e1 	mov	x1, x25
    4020291c:	aa1f03e2 	mov	x2, xzr
    40202920:	aa1303e3 	mov	x3, x19
    40202924:	97ffff0b 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202928:	f9405ae8 	ldr	x8, [x23, #176]
    4020292c:	a94c2ae9 	ldp	x9, x10, [x23, #192]
    40202930:	a90ba7e8 	stp	x8, x9, [sp, #184]
    40202934:	f9404ac8 	ldr	x8, [x22, #144]
    40202938:	a90ca3ea 	stp	x10, x8, [sp, #200]
    4020293c:	9102e3e4 	add	x4, sp, #0xb8
    40202940:	52800460 	mov	w0, #0x23                  	// #35
    40202944:	aa1903e1 	mov	x1, x25
    40202948:	aa1f03e2 	mov	x2, xzr
    4020294c:	aa1303e3 	mov	x3, x19
    40202950:	97ffff00 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202954:	8b1312c8 	add	x8, x22, x19, lsl #4
    40202958:	a941a909 	ldp	x9, x10, [x8, #24]
    4020295c:	a90babe9 	stp	x9, x10, [sp, #184]
    40202960:	a943a109 	ldp	x9, x8, [x8, #56]
    40202964:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202968:	9102e3e4 	add	x4, sp, #0xb8
    4020296c:	528003e0 	mov	w0, #0x1f                  	// #31
    40202970:	aa1903e1 	mov	x1, x25
    40202974:	aa1f03e2 	mov	x2, xzr
    40202978:	aa1303e3 	mov	x3, x19
    4020297c:	97fffef5 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202980:	8b130ac8 	add	x8, x22, x19, lsl #2
    40202984:	b9401109 	ldr	w9, [x8, #16]
    40202988:	b9405908 	ldr	w8, [x8, #88]
    4020298c:	8b1302ca 	add	x10, x22, x19
    40202990:	3941814a 	ldrb	w10, [x10, #96]
    40202994:	b94002cb 	ldr	w11, [x22]
    40202998:	f94006cc 	ldr	x12, [x22, #8]
    4020299c:	eb13019f 	cmp	x12, x19
    402029a0:	1a9f17ec 	cset	w12, eq  // eq = none
    402029a4:	39418acd 	ldrb	w13, [x22, #98]
    402029a8:	71000dbf 	cmp	w13, #0x3
    402029ac:	1a8d07ed 	csinc	w13, wzr, w13, eq  // eq = none
    402029b0:	a90ba3e9 	stp	x9, x8, [sp, #184]
    402029b4:	6a0c017f 	tst	w11, w12
    402029b8:	9a9f11a8 	csel	x8, x13, xzr, ne  // ne = any
    402029bc:	a90ca3ea 	stp	x10, x8, [sp, #200]
    402029c0:	9102e3e4 	add	x4, sp, #0xb8
    402029c4:	52800400 	mov	w0, #0x20                  	// #32
    402029c8:	aa1903e1 	mov	x1, x25
    402029cc:	aa1f03e2 	mov	x2, xzr
    402029d0:	aa1303e3 	mov	x3, x19
    402029d4:	97fffedf 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    402029d8:	2a1f03e8 	mov	w8, wzr
    402029dc:	52800033 	mov	w19, #0x1                   	// #1
    402029e0:	3707f8b5 	tbnz	w21, #0, 402028f4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x248>
    402029e4:	52801008 	mov	w8, #0x80                  	// #128
    402029e8:	52802109 	mov	w9, #0x108                 	// #264
    402029ec:	a90ba3e8 	stp	x8, x8, [sp, #184]
    402029f0:	52801708 	mov	w8, #0xb8                  	// #184
    402029f4:	a90ca3e9 	stp	x9, x8, [sp, #200]
    402029f8:	9102e3e4 	add	x4, sp, #0xb8
    402029fc:	52800420 	mov	w0, #0x21                  	// #33
    40202a00:	aa1903e1 	mov	x1, x25
    40202a04:	aa1f03e2 	mov	x2, xzr
    40202a08:	52800043 	mov	w3, #0x2                   	// #2
    40202a0c:	97fffed1 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202a10:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766+0xb8e0>
    40202a14:	f943f508 	ldr	x8, [x8, #2024]
    40202a18:	f101011f 	cmp	x8, #0x40
    40202a1c:	52800809 	mov	w9, #0x40                  	// #64
    40202a20:	9a893113 	csel	x19, x8, x9, cc  // cc = lo, ul, last
    40202a24:	a94a5ff8 	ldp	x24, x23, [sp, #160]
    40202a28:	b4000288 	cbz	x8, 40202a78 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x3cc>
    40202a2c:	aa1f03f4 	mov	x20, xzr
    40202a30:	b0000035 	adrp	x21, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202a34:	910022b5 	add	x21, x21, #0x8
    40202a38:	b0000116 	adrp	x22, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766+0xb8e0>
    40202a3c:	911fc2d6 	add	x22, x22, #0x7f0
    40202a40:	f9400ac1 	ldr	x1, [x22, #16]
    40202a44:	f94006c8 	ldr	x8, [x22, #8]
    40202a48:	f84186c9 	ldr	x9, [x22], #24
    40202a4c:	aa1403ea 	mov	x10, x20
    40202a50:	91000694 	add	x20, x20, #0x1
    40202a54:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202a58:	a97f8ea2 	ldp	x2, x3, [x21, #-8]
    40202a5c:	a90cffea 	stp	x10, xzr, [sp, #200]
    40202a60:	9102e3e4 	add	x4, sp, #0xb8
    40202a64:	52800180 	mov	w0, #0xc                   	// #12
    40202a68:	97fffeba 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202a6c:	910042b5 	add	x21, x21, #0x10
    40202a70:	eb14027f 	cmp	x19, x20
    40202a74:	54fffe61 	b.ne	40202a40 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x394>  // b.any
    40202a78:	52800314 	mov	w20, #0x18                  	// #24
    40202a7c:	72a12014 	movk	w20, #0x900, lsl #16
    40202a80:	d5033fdf 	isb
    40202a84:	d53be021 	mrs	x1, cntpct_el0
    40202a88:	a94823e9 	ldp	x9, x8, [sp, #128]
    40202a8c:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202a90:	a94923e9 	ldp	x9, x8, [sp, #144]
    40202a94:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202a98:	9102e3e4 	add	x4, sp, #0xb8
    40202a9c:	528001a0 	mov	w0, #0xd                   	// #13
    40202aa0:	aa1803e2 	mov	x2, x24
    40202aa4:	aa1703e3 	mov	x3, x23
    40202aa8:	97fffeaa 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202aac:	aa1f03e8 	mov	x8, xzr
    40202ab0:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202ab4:	d503201f 	nop
    40202ab8:	10019d8a 	adr	x10, 40205e68 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.2706286857142130766+0x18>
    40202abc:	3868694b 	ldrb	w11, [x10, x8]
    40202ac0:	b940028c 	ldr	w12, [x20]
    40202ac4:	3628006c 	tbz	w12, #5, 40202ad0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x424>
    40202ac8:	d5033fdf 	isb
    40202acc:	17fffffd 	b	40202ac0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x414>
    40202ad0:	91000508 	add	x8, x8, #0x1
    40202ad4:	b900012b 	str	w11, [x9]
    40202ad8:	f1002d1f 	cmp	x8, #0xb
    40202adc:	54ffff01 	b.ne	40202abc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x410>  // b.any
    40202ae0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202ae4:	f9438915 	ldr	x21, [x8, #1808]
    40202ae8:	b4000755 	cbz	x21, 40202bd0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x524>
    40202aec:	aa1f03f6 	mov	x22, xzr
    40202af0:	9102e3e8 	add	x8, sp, #0xb8
    40202af4:	b202e7f7 	mov	x23, #0xcccccccccccccccc    	// #-3689348814741910324
    40202af8:	f29999b7 	movk	x23, #0xcccd
    40202afc:	91004113 	add	x19, x8, #0x10
    40202b00:	52800158 	mov	w24, #0xa                   	// #10
    40202b04:	910423f9 	add	x25, sp, #0x108
    40202b08:	52a1201a 	mov	w26, #0x9000000             	// #150994944
    40202b0c:	5280041b 	mov	w27, #0x20                  	// #32
    40202b10:	d503201f 	nop
    40202b14:	1002603c 	adr	x28, 40207718 <jnox_kernel::ordinary_reservations::TRACE>
    40202b18:	8b161b81 	add	x1, x28, x22, lsl #6
    40202b1c:	910006d6 	add	x22, x22, #0x1
    40202b20:	aa1303e0 	mov	x0, x19
    40202b24:	52800802 	mov	w2, #0x40                  	// #64
    40202b28:	94000bb6 	bl	40205a00 <memcpy>
    40202b2c:	aa1f03e8 	mov	x8, xzr
    40202b30:	b9011bff 	str	wzr, [sp, #280]
    40202b34:	f8687a69 	ldr	x9, [x19, x8, lsl #3]
    40202b38:	91000508 	add	x8, x8, #0x1
    40202b3c:	5280026a 	mov	w10, #0x13                  	// #19
    40202b40:	a910ffff 	stp	xzr, xzr, [sp, #264]
    40202b44:	f1004d5f 	cmp	x10, #0x13
    40202b48:	54000d08 	b.hi	40202ce8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x63c>  // b.pmore
    40202b4c:	9bd77d2b 	umulh	x11, x9, x23
    40202b50:	d343fd6b 	lsr	x11, x11, #3
    40202b54:	1b18a56c 	msub	w12, w11, w24, w9
    40202b58:	321c058c 	orr	w12, w12, #0x30
    40202b5c:	382a6b2c 	strb	w12, [x25, x10]
    40202b60:	d100054a 	sub	x10, x10, #0x1
    40202b64:	f100293f 	cmp	x9, #0xa
    40202b68:	aa0b03e9 	mov	x9, x11
    40202b6c:	54fffec2 	b.cs	40202b44 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x498>  // b.hs, b.nlast
    40202b70:	91000549 	add	x9, x10, #0x1
    40202b74:	38696b2a 	ldrb	w10, [x25, x9]
    40202b78:	b940028b 	ldr	w11, [x20]
    40202b7c:	3628006b 	tbz	w11, #5, 40202b88 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x4dc>
    40202b80:	d5033fdf 	isb
    40202b84:	17fffffd 	b	40202b78 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x4cc>
    40202b88:	91000529 	add	x9, x9, #0x1
    40202b8c:	b900034a 	str	w10, [x26]
    40202b90:	f100513f 	cmp	x9, #0x14
    40202b94:	54ffff01 	b.ne	40202b74 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x4c8>  // b.any
    40202b98:	14000002 	b	40202ba0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x4f4>
    40202b9c:	d5033fdf 	isb
    40202ba0:	b9400289 	ldr	w9, [x20]
    40202ba4:	372fffc9 	tbnz	w9, #5, 40202b9c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x4f0>
    40202ba8:	b900035b 	str	w27, [x26]
    40202bac:	f100211f 	cmp	x8, #0x8
    40202bb0:	54fffc01 	b.ne	40202b30 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x484>  // b.any
    40202bb4:	14000002 	b	40202bbc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x510>
    40202bb8:	d5033fdf 	isb
    40202bbc:	b9400288 	ldr	w8, [x20]
    40202bc0:	372fffc8 	tbnz	w8, #5, 40202bb8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x50c>
    40202bc4:	b9000358 	str	w24, [x26]
    40202bc8:	eb1502df 	cmp	x22, x21
    40202bcc:	54fffa61 	b.ne	40202b18 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x46c>  // b.any
    40202bd0:	aa1f03e8 	mov	x8, xzr
    40202bd4:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202bd8:	d503201f 	nop
    40202bdc:	700194aa 	adr	x10, 40205e73 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.2706286857142130766+0x23>
    40202be0:	3868694b 	ldrb	w11, [x10, x8]
    40202be4:	b940028c 	ldr	w12, [x20]
    40202be8:	3628006c 	tbz	w12, #5, 40202bf4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x548>
    40202bec:	d5033fdf 	isb
    40202bf0:	17fffffd 	b	40202be4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x538>
    40202bf4:	91000508 	add	x8, x8, #0x1
    40202bf8:	b900012b 	str	w11, [x9]
    40202bfc:	f100251f 	cmp	x8, #0x9
    40202c00:	54ffff01 	b.ne	40202be0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x534>  // b.any
    40202c04:	d503205f 	wfe
    40202c08:	17ffffff 	b	40202c04 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x558>
    40202c0c:	a94127e8 	ldp	x8, x9, [sp, #16]
    40202c10:	a90ba7f3 	stp	x19, x9, [sp, #184]
    40202c14:	a90ca3fa 	stp	x26, x8, [sp, #200]
    40202c18:	9102e3e4 	add	x4, sp, #0xb8
    40202c1c:	52800320 	mov	w0, #0x19                  	// #25
    40202c20:	aa1503e1 	mov	x1, x21
    40202c24:	aa1f03e2 	mov	x2, xzr
    40202c28:	52800043 	mov	w3, #0x2                   	// #2
    40202c2c:	97fffe49 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202c30:	a90bd3f5 	stp	x21, x20, [sp, #184]
    40202c34:	a90ccffa 	stp	x26, x19, [sp, #200]
    40202c38:	9102e3e4 	add	x4, sp, #0xb8
    40202c3c:	528004a0 	mov	w0, #0x25                  	// #37
    40202c40:	aa1403e1 	mov	x1, x20
    40202c44:	aa1f03e2 	mov	x2, xzr
    40202c48:	52800043 	mov	w3, #0x2                   	// #2
    40202c4c:	97fffe41 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202c50:	360fe0f8 	tbz	w24, #1, 4020286c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x1c0>
    40202c54:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202c58:	f9432d08 	ldr	x8, [x8, #1624]
    40202c5c:	f1000aff 	cmp	x23, #0x2
    40202c60:	a90bfffb 	stp	x27, xzr, [sp, #184]
    40202c64:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40202c68:	a90cffe8 	stp	x8, xzr, [sp, #200]
    40202c6c:	9102e3e4 	add	x4, sp, #0xb8
    40202c70:	52800340 	mov	w0, #0x1a                  	// #26
    40202c74:	f94013e1 	ldr	x1, [sp, #32]
    40202c78:	aa1f03e2 	mov	x2, xzr
    40202c7c:	52800043 	mov	w3, #0x2                   	// #2
    40202c80:	97fffe34 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202c84:	3617df78 	tbz	w24, #2, 40202870 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x1c4>
    40202c88:	924003a8 	and	x8, x29, #0x1
    40202c8c:	d341ffa9 	lsr	x9, x29, #1
    40202c90:	a90ba3fd 	stp	x29, x8, [sp, #184]
    40202c94:	f9405be8 	ldr	x8, [sp, #176]
    40202c98:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202c9c:	9102e3e4 	add	x4, sp, #0xb8
    40202ca0:	52800360 	mov	w0, #0x1b                  	// #27
    40202ca4:	f94017e1 	ldr	x1, [sp, #40]
    40202ca8:	aa1f03e2 	mov	x2, xzr
    40202cac:	aa1c03e3 	mov	x3, x28
    40202cb0:	97fffe28 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202cb4:	361fde18 	tbz	w24, #3, 40202874 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x1c8>
    40202cb8:	a94327e8 	ldp	x8, x9, [sp, #48]
    40202cbc:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202cc0:	52800028 	mov	w8, #0x1                   	// #1
    40202cc4:	a94407e9 	ldp	x9, x1, [sp, #64]
    40202cc8:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202ccc:	9102e3e4 	add	x4, sp, #0xb8
    40202cd0:	52800380 	mov	w0, #0x1c                  	// #28
    40202cd4:	aa1f03e2 	mov	x2, xzr
    40202cd8:	aa1c03e3 	mov	x3, x28
    40202cdc:	97fffe1d 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202ce0:	3727dcd8 	tbnz	w24, #4, 40202878 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x1cc>
    40202ce4:	17fffeff 	b	402028e0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766+0x234>
    40202ce8:	d503201f 	nop
    40202cec:	10018fa2 	adr	x2, 40205ee0 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.2706286857142130766+0x90>
    40202cf0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    40202cf4:	52800281 	mov	w1, #0x14                  	// #20
    40202cf8:	940007f2 	bl	40204cc0 <core::panicking::panic_bounds_check>

0000000040202cfc <jnox_kernel::ordinary_reservations::Runtime::arm>:
    40202cfc:	d10103ff 	sub	sp, sp, #0x40
    40202d00:	a90257fe 	stp	x30, x21, [sp, #32]
    40202d04:	a9034ff4 	stp	x20, x19, [sp, #48]
    40202d08:	aa0203f3 	mov	x19, x2
    40202d0c:	aa0003e2 	mov	x2, x0
    40202d10:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202d14:	91158129 	add	x9, x9, #0x560
    40202d18:	a9020533 	stp	x19, x1, [x9, #32]
    40202d1c:	52800028 	mov	w8, #0x1                   	// #1
    40202d20:	d51be253 	msr	cntp_cval_el0, x19
    40202d24:	d51be228 	msr	cntp_ctl_el0, x8
    40202d28:	d5033fdf 	isb
    40202d2c:	d53be255 	mrs	x21, cntp_cval_el0
    40202d30:	d53be234 	mrs	x20, cntp_ctl_el0
    40202d34:	d5033fdf 	isb
    40202d38:	d53be028 	mrs	x8, cntpct_el0
    40202d3c:	a90053f3 	stp	x19, x20, [sp]
    40202d40:	f9400123 	ldr	x3, [x9]
    40202d44:	a90107f5 	stp	x21, x1, [sp, #16]
    40202d48:	910003e4 	mov	x4, sp
    40202d4c:	52800060 	mov	w0, #0x3                   	// #3
    40202d50:	aa0803e1 	mov	x1, x8
    40202d54:	97fffdff 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202d58:	eb1302bf 	cmp	x21, x19
    40202d5c:	54000101 	b.ne	40202d7c <jnox_kernel::ordinary_reservations::Runtime::arm+0x80>  // b.any
    40202d60:	92400688 	and	x8, x20, #0x3
    40202d64:	f100051f 	cmp	x8, #0x1
    40202d68:	540000a1 	b.ne	40202d7c <jnox_kernel::ordinary_reservations::Runtime::arm+0x80>  // b.any
    40202d6c:	a9434ff4 	ldp	x20, x19, [sp, #48]
    40202d70:	a94257fe 	ldp	x30, x21, [sp, #32]
    40202d74:	910103ff 	add	sp, sp, #0x40
    40202d78:	d65f03c0 	ret
    40202d7c:	97fff94b 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

0000000040202d80 <jnox_kernel::ordinary_reservations::Runtime::close>:
    40202d80:	d103c3ff 	sub	sp, sp, #0xf0
    40202d84:	a9097bfd 	stp	x29, x30, [sp, #144]
    40202d88:	a90a6ffc 	stp	x28, x27, [sp, #160]
    40202d8c:	a90b67fa 	stp	x26, x25, [sp, #176]
    40202d90:	a90c5ff8 	stp	x24, x23, [sp, #192]
    40202d94:	a90d57f6 	stp	x22, x21, [sp, #208]
    40202d98:	a90e4ff4 	stp	x20, x19, [sp, #224]
    40202d9c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202da0:	91140108 	add	x8, x8, #0x500
    40202da4:	a9405113 	ldp	x19, x20, [x8]
    40202da8:	a9412518 	ldp	x24, x9, [x8, #16]
    40202dac:	f90037e9 	str	x9, [sp, #104]
    40202db0:	a942691d 	ldp	x29, x26, [x8, #32]
    40202db4:	3940c119 	ldrb	w25, [x8, #48]
    40202db8:	52800069 	mov	w9, #0x3                   	// #3
    40202dbc:	3900c109 	strb	w9, [x8, #48]
    40202dc0:	71000f3f 	cmp	w25, #0x3
    40202dc4:	54001d20 	b.eq	40203168 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.none
    40202dc8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202dcc:	f942b108 	ldr	x8, [x8, #1376]
    40202dd0:	eb13011f 	cmp	x8, x19
    40202dd4:	54001ca1 	b.ne	40203168 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.any
    40202dd8:	aa0003f5 	mov	x21, x0
    40202ddc:	d503201f 	nop
    40202de0:	100a4a08 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766>
    40202de4:	8b133909 	add	x9, x8, x19, lsl #14
    40202de8:	eb00013f 	cmp	x9, x0
    40202dec:	54001be8 	b.hi	40203168 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202df0:	b10d06bf 	cmn	x21, #0x341
    40202df4:	54001ba8 	b.hi	40203168 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202df8:	d372c669 	lsl	x9, x19, #14
    40202dfc:	8b090108 	add	x8, x8, x9
    40202e00:	91401108 	add	x8, x8, #0x4, lsl #12
    40202e04:	910d02a9 	add	x9, x21, #0x340
    40202e08:	eb08013f 	cmp	x9, x8
    40202e0c:	54001ae8 	b.hi	40203168 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202e10:	aa0303fc 	mov	x28, x3
    40202e14:	2a0203f7 	mov	w23, w2
    40202e18:	aa0103f6 	mov	x22, x1
    40202e1c:	9101c3e8 	add	x8, sp, #0x70
    40202e20:	aa1303e0 	mov	x0, x19
    40202e24:	9400014c 	bl	40203354 <jnox_kernel::ordinary_reservations::snapshot>
    40202e28:	f1000a7f 	cmp	x19, #0x2
    40202e2c:	54001d62 	b.cs	402031d8 <jnox_kernel::ordinary_reservations::Runtime::close+0x458>  // b.hs, b.nlast
    40202e30:	a94733fb 	ldp	x27, x12, [sp, #112]
    40202e34:	f94043ef 	ldr	x15, [sp, #128]
    40202e38:	d503201f 	nop
    40202e3c:	10107e28 	adr	x8, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40202e40:	8b130d08 	add	x8, x8, x19, lsl #3
    40202e44:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202e48:	9114e129 	add	x9, x9, #0x538
    40202e4c:	c8dffd0e 	ldar	x14, [x8]
    40202e50:	a9402129 	ldp	x9, x8, [x9]
    40202e54:	9bc87e8a 	umulh	x10, x20, x8
    40202e58:	eb0a03ff 	cmp	xzr, x10
    40202e5c:	1a9f07eb 	cset	w11, ne  // ne = any
    40202e60:	9b087e8a 	mul	x10, x20, x8
    40202e64:	ab09014d 	adds	x13, x10, x9
    40202e68:	1a9f37ea 	cset	w10, cs  // cs = hs, nlast
    40202e6c:	3700180b 	tbnz	w11, #0, 4020316c <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202e70:	350017ea 	cbnz	w10, 4020316c <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202e74:	9100068a 	add	x10, x20, #0x1
    40202e78:	9bc87d4b 	umulh	x11, x10, x8
    40202e7c:	eb0b03ff 	cmp	xzr, x11
    40202e80:	1a9f07eb 	cset	w11, ne  // ne = any
    40202e84:	9b087d48 	mul	x8, x10, x8
    40202e88:	ab090109 	adds	x9, x8, x9
    40202e8c:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40202e90:	370016eb 	tbnz	w11, #0, 4020316c <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202e94:	350016c8 	cbnz	w8, 4020316c <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202e98:	b100069f 	cmn	x20, #0x1
    40202e9c:	54001680 	b.eq	4020316c <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.none
    40202ea0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202ea4:	f942a508 	ldr	x8, [x8, #1352]
    40202ea8:	eb08012a 	subs	x10, x9, x8
    40202eac:	54001603 	b.cc	4020316c <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.lo, b.ul, b.last
    40202eb0:	a9056bfc 	stp	x28, x26, [sp, #80]
    40202eb4:	f9000fe9 	str	x9, [sp, #24]
    40202eb8:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766+0xb8e0>
    40202ebc:	f943f508 	ldr	x8, [x8, #2024]
    40202ec0:	91000709 	add	x9, x24, #0x1
    40202ec4:	eb09011f 	cmp	x8, x9
    40202ec8:	54001501 	b.ne	40203168 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.any
    40202ecc:	b9004ff9 	str	w25, [sp, #76]
    40202ed0:	d503201f 	nop
    40202ed4:	101048a8 	adr	x8, 402237e8 <jnox_ap_returns>
    40202ed8:	52800309 	mov	w9, #0x18                  	// #24
    40202edc:	9b092308 	madd	x8, x24, x9, x8
    40202ee0:	f9400509 	ldr	x9, [x8, #8]
    40202ee4:	f940090b 	ldr	x11, [x8, #16]
    40202ee8:	f9400d1c 	ldr	x28, [x8, #24]
    40202eec:	eb1c02da 	subs	x26, x22, x28
    40202ef0:	540017e3 	b.cc	402031ec <jnox_kernel::ordinary_reservations::Runtime::close+0x46c>  // b.lo, b.ul, b.last
    40202ef4:	a902a7eb 	stp	x11, x9, [sp, #40]
    40202ef8:	a903b7ef 	stp	x15, x13, [sp, #56]
    40202efc:	f90033ee 	str	x14, [sp, #96]
    40202f00:	f9000bea 	str	x10, [sp, #16]
    40202f04:	d503201f 	nop
    40202f08:	100227c8 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40202f0c:	8b130d18 	add	x24, x8, x19, lsl #3
    40202f10:	f940d308 	ldr	x8, [x24, #416]
    40202f14:	ab1a0119 	adds	x25, x8, x26
    40202f18:	540012a2 	b.cs	4020316c <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.hs, b.nlast
    40202f1c:	f900d319 	str	x25, [x24, #416]
    40202f20:	f94037e8 	ldr	x8, [sp, #104]
    40202f24:	a9076fe8 	stp	x8, x27, [sp, #112]
    40202f28:	a90833fd 	stp	x29, x12, [sp, #128]
    40202f2c:	f90013fb 	str	x27, [sp, #32]
    40202f30:	9101c3e4 	add	x4, sp, #0x70
    40202f34:	52800100 	mov	w0, #0x8                   	// #8
    40202f38:	aa1603e1 	mov	x1, x22
    40202f3c:	aa1403e2 	mov	x2, x20
    40202f40:	aa1303e3 	mov	x3, x19
    40202f44:	aa0c03fb 	mov	x27, x12
    40202f48:	97fffd82 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202f4c:	f9407ea8 	ldr	x8, [x21, #248]
    40202f50:	f9404ea9 	ldr	x9, [x21, #152]
    40202f54:	a90723f5 	stp	x21, x8, [sp, #112]
    40202f58:	f9408ea8 	ldr	x8, [x21, #280]
    40202f5c:	a90823e9 	stp	x9, x8, [sp, #128]
    40202f60:	9101c3e4 	add	x4, sp, #0x70
    40202f64:	52800120 	mov	w0, #0x9                   	// #9
    40202f68:	aa1603e1 	mov	x1, x22
    40202f6c:	aa1403e2 	mov	x2, x20
    40202f70:	aa1303e3 	mov	x3, x19
    40202f74:	97fffd77 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202f78:	f94033e8 	ldr	x8, [sp, #96]
    40202f7c:	a90723fc 	stp	x28, x8, [sp, #112]
    40202f80:	a9086bf6 	stp	x22, x26, [sp, #128]
    40202f84:	f90007fa 	str	x26, [sp, #8]
    40202f88:	9101c3e4 	add	x4, sp, #0x70
    40202f8c:	52800140 	mov	w0, #0xa                   	// #10
    40202f90:	aa1603e1 	mov	x1, x22
    40202f94:	aa1403e2 	mov	x2, x20
    40202f98:	aa1303e3 	mov	x3, x19
    40202f9c:	97fffd6d 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202fa0:	110006e8 	add	w8, w23, #0x1
    40202fa4:	92401d09 	and	x9, x8, #0xff
    40202fa8:	f9402be8 	ldr	x8, [sp, #80]
    40202fac:	a90723e9 	stp	x9, x8, [sp, #112]
    40202fb0:	f9401fe9 	ldr	x9, [sp, #56]
    40202fb4:	910d02a8 	add	x8, x21, #0x340
    40202fb8:	a90823e9 	stp	x9, x8, [sp, #128]
    40202fbc:	9101c3e4 	add	x4, sp, #0x70
    40202fc0:	52800160 	mov	w0, #0xb                   	// #11
    40202fc4:	aa1603e1 	mov	x1, x22
    40202fc8:	aa1403e2 	mov	x2, x20
    40202fcc:	aa1303e3 	mov	x3, x19
    40202fd0:	97fffd60 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40202fd4:	f9402fe8 	ldr	x8, [sp, #88]
    40202fd8:	a90767e8 	stp	x8, x25, [sp, #112]
    40202fdc:	aa1903fa 	mov	x26, x25
    40202fe0:	a942a7e8 	ldp	x8, x9, [sp, #40]
    40202fe4:	a90823e9 	stp	x9, x8, [sp, #128]
    40202fe8:	9101c3e4 	add	x4, sp, #0x70
    40202fec:	52800260 	mov	w0, #0x13                  	// #19
    40202ff0:	aa1603e1 	mov	x1, x22
    40202ff4:	aa1403e2 	mov	x2, x20
    40202ff8:	aa1303e3 	mov	x3, x19
    40202ffc:	97fffd55 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40203000:	f94013e4 	ldr	x4, [sp, #32]
    40203004:	b9404fe8 	ldr	w8, [sp, #76]
    40203008:	6b37011f 	cmp	w8, w23, uxtb
    4020300c:	f94023e5 	ldr	x5, [sp, #64]
    40203010:	54000b21 	b.ne	40203174 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203014:	f94037e8 	ldr	x8, [sp, #104]
    40203018:	eb080088 	subs	x8, x4, x8
    4020301c:	54000ac9 	b.ls	40203174 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.plast
    40203020:	f9408ea9 	ldr	x9, [x21, #280]
    40203024:	d503201f 	nop
    40203028:	1001700a 	adr	x10, 40205e28 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.2706286857142130766>
    4020302c:	f873794a 	ldr	x10, [x10, x19, lsl #3]
    40203030:	eb0a013f 	cmp	x9, x10
    40203034:	54000a01 	b.ne	40203174 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203038:	f94082a9 	ldr	x9, [x21, #256]
    4020303c:	528011ea 	mov	w10, #0x8f                  	// #143
    40203040:	8a0a0129 	and	x9, x9, x10
    40203044:	f100153f 	cmp	x9, #0x5
    40203048:	54000961 	b.ne	40203174 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    4020304c:	52800029 	mov	w9, #0x1                   	// #1
    40203050:	5280006a 	mov	w10, #0x3                   	// #3
    40203054:	aa0803eb 	mov	x11, x8
    40203058:	9b1d254c 	madd	x12, x10, x29, x9
    4020305c:	f240017f 	tst	x11, #0x1
    40203060:	9a8c03bd 	csel	x29, x29, x12, eq  // eq = none
    40203064:	9b0a2529 	madd	x9, x9, x10, x9
    40203068:	9b0a7d4a 	mul	x10, x10, x10
    4020306c:	d341fd6b 	lsr	x11, x11, #1
    40203070:	b5ffff4b 	cbnz	x11, 40203058 <jnox_kernel::ordinary_reservations::Runtime::close+0x2d8>
    40203074:	eb1b03bf 	cmp	x29, x27
    40203078:	540007e1 	b.ne	40203174 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    4020307c:	72001eff 	tst	w23, #0xff
    40203080:	54000060 	b.eq	4020308c <jnox_kernel::ordinary_reservations::Runtime::close+0x30c>  // b.none
    40203084:	f104011f 	cmp	x8, #0x100
    40203088:	54000761 	b.ne	40203174 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    4020308c:	f94033ea 	ldr	x10, [sp, #96]
    40203090:	eb16015f 	cmp	x10, x22
    40203094:	540007c8 	b.hi	4020318c <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.pmore
    40203098:	eb05039f 	cmp	x28, x5
    4020309c:	54000783 	b.cc	4020318c <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.lo, b.ul, b.last
    402030a0:	eb1c015f 	cmp	x10, x28
    402030a4:	54000743 	b.cc	4020318c <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.lo, b.ul, b.last
    402030a8:	cb050149 	sub	x9, x10, x5
    402030ac:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402030b0:	f942a508 	ldr	x8, [x8, #1352]
    402030b4:	eb08013f 	cmp	x9, x8
    402030b8:	540006a8 	b.hi	4020318c <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.pmore
    402030bc:	a9412fe5 	ldp	x5, x11, [sp, #16]
    402030c0:	eb0b02df 	cmp	x22, x11
    402030c4:	54000708 	b.hi	402031a4 <jnox_kernel::ordinary_reservations::Runtime::close+0x424>  // b.pmore
    402030c8:	12001eea 	and	w10, w23, #0xff
    402030cc:	eb0502c9 	subs	x9, x22, x5
    402030d0:	9a8933e9 	csel	x9, xzr, x9, cc  // cc = lo, ul, last
    402030d4:	3500006a 	cbnz	w10, 402030e0 <jnox_kernel::ordinary_reservations::Runtime::close+0x360>
    402030d8:	eb08013f 	cmp	x9, x8
    402030dc:	54000648 	b.hi	402031a4 <jnox_kernel::ordinary_reservations::Runtime::close+0x424>  // b.pmore
    402030e0:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402030e4:	f942a108 	ldr	x8, [x8, #1344]
    402030e8:	f94007ea 	ldr	x10, [sp, #8]
    402030ec:	eb08015f 	cmp	x10, x8
    402030f0:	aa1a03eb 	mov	x11, x26
    402030f4:	54000648 	b.hi	402031bc <jnox_kernel::ordinary_reservations::Runtime::close+0x43c>  // b.pmore
    402030f8:	f940db09 	ldr	x9, [x24, #432]
    402030fc:	9b087d28 	mul	x8, x9, x8
    40203100:	eb08017f 	cmp	x11, x8
    40203104:	540005c8 	b.hi	402031bc <jnox_kernel::ordinary_reservations::Runtime::close+0x43c>  // b.pmore
    40203108:	72001eff 	tst	w23, #0xff
    4020310c:	54000060 	b.eq	40203118 <jnox_kernel::ordinary_reservations::Runtime::close+0x398>  // b.none
    40203110:	eb0502df 	cmp	x22, x5
    40203114:	540006e2 	b.cs	402031f0 <jnox_kernel::ordinary_reservations::Runtime::close+0x470>  // b.hs, b.nlast
    40203118:	f900e304 	str	x4, [x24, #448]
    4020311c:	f900eb1b 	str	x27, [x24, #464]
    40203120:	94000040 	bl	40203220 <jnox_kernel::ordinary_reservations::Runtime::ledger>
    40203124:	aa1303e1 	mov	x1, x19
    40203128:	2a1703e2 	mov	w2, w23
    4020312c:	94000240 	bl	40203a2c <jnox_kernel::reservation_jobs::Jobs::trap>
    40203130:	72001c04 	ands	w4, w0, #0xff
    40203134:	540006a1 	b.ne	40203208 <jnox_kernel::ordinary_reservations::Runtime::close+0x488>  // b.any
    40203138:	12001ee8 	and	w8, w23, #0xff
    4020313c:	7100091f 	cmp	w8, #0x2
    40203140:	54000040 	b.eq	40203148 <jnox_kernel::ordinary_reservations::Runtime::close+0x3c8>  // b.none
    40203144:	f900b715 	str	x21, [x24, #360]
    40203148:	a94e4ff4 	ldp	x20, x19, [sp, #224]
    4020314c:	a94d57f6 	ldp	x22, x21, [sp, #208]
    40203150:	a94c5ff8 	ldp	x24, x23, [sp, #192]
    40203154:	a94b67fa 	ldp	x26, x25, [sp, #176]
    40203158:	a94a6ffc 	ldp	x28, x27, [sp, #160]
    4020315c:	a9497bfd 	ldp	x29, x30, [sp, #144]
    40203160:	9103c3ff 	add	sp, sp, #0xf0
    40203164:	d65f03c0 	ret
    40203168:	97fff850 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    4020316c:	52800060 	mov	w0, #0x3                   	// #3
    40203170:	94000071 	bl	40203334 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    40203174:	52800060 	mov	w0, #0x3                   	// #3
    40203178:	52800061 	mov	w1, #0x3                   	// #3
    4020317c:	aa1403e2 	mov	x2, x20
    40203180:	aa1303e3 	mov	x3, x19
    40203184:	f94037e5 	ldr	x5, [sp, #104]
    40203188:	97fffd49 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>
    4020318c:	52800040 	mov	w0, #0x2                   	// #2
    40203190:	52800041 	mov	w1, #0x2                   	// #2
    40203194:	aa1403e2 	mov	x2, x20
    40203198:	aa1303e3 	mov	x3, x19
    4020319c:	aa0a03e4 	mov	x4, x10
    402031a0:	97fffd43 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>
    402031a4:	52800040 	mov	w0, #0x2                   	// #2
    402031a8:	52800021 	mov	w1, #0x1                   	// #1
    402031ac:	aa1403e2 	mov	x2, x20
    402031b0:	aa1303e3 	mov	x3, x19
    402031b4:	aa1603e4 	mov	x4, x22
    402031b8:	14000006 	b	402031d0 <jnox_kernel::ordinary_reservations::Runtime::close+0x450>
    402031bc:	52800040 	mov	w0, #0x2                   	// #2
    402031c0:	528000e1 	mov	w1, #0x7                   	// #7
    402031c4:	aa1403e2 	mov	x2, x20
    402031c8:	aa1303e3 	mov	x3, x19
    402031cc:	aa0a03e4 	mov	x4, x10
    402031d0:	aa0b03e5 	mov	x5, x11
    402031d4:	97fffd36 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>
    402031d8:	d503201f 	nop
    402031dc:	10016762 	adr	x2, 40205ec8 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.2706286857142130766+0x78>
    402031e0:	aa1303e0 	mov	x0, x19
    402031e4:	52800041 	mov	w1, #0x2                   	// #2
    402031e8:	940006b6 	bl	40204cc0 <core::panicking::panic_bounds_check>
    402031ec:	97fffb9e 	bl	40202064 <jnox_kernel::ordinary_reservations::run::{{closure}}>
    402031f0:	52800040 	mov	w0, #0x2                   	// #2
    402031f4:	52800121 	mov	w1, #0x9                   	// #9
    402031f8:	aa1403e2 	mov	x2, x20
    402031fc:	aa1303e3 	mov	x3, x19
    40203200:	aa1603e4 	mov	x4, x22
    40203204:	97fffd2a 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>
    40203208:	52800060 	mov	w0, #0x3                   	// #3
    4020320c:	52800041 	mov	w1, #0x2                   	// #2
    40203210:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40203214:	52800043 	mov	w3, #0x2                   	// #2
    40203218:	aa1f03e5 	mov	x5, xzr
    4020321c:	97fffd24 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>

0000000040203220 <jnox_kernel::ordinary_reservations::Runtime::ledger>:
    40203220:	f81f0ffe 	str	x30, [sp, #-16]!
    40203224:	d503201f 	nop
    40203228:	10102dc8 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    4020322c:	c8dffd08 	ldar	x8, [x8]
    40203230:	b4000128 	cbz	x8, 40203254 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x34>
    40203234:	f1000d1f 	cmp	x8, #0x3
    40203238:	540000c1 	b.ne	40203250 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x30>  // b.any
    4020323c:	90000020 	adrp	x0, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203240:	91120000 	add	x0, x0, #0x480
    40203244:	f9400008 	ldr	x8, [x0]
    40203248:	f100091f 	cmp	x8, #0x2
    4020324c:	54000081 	b.ne	4020325c <jnox_kernel::ordinary_reservations::Runtime::ledger+0x3c>  // b.any
    40203250:	97fff816 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40203254:	d503201f 	nop
    40203258:	10020d40 	adr	x0, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    4020325c:	f84107fe 	ldr	x30, [sp], #16
    40203260:	d65f03c0 	ret

0000000040203264 <jnox_kernel::ordinary_reservations::Runtime::select>:
    40203264:	d10143ff 	sub	sp, sp, #0x50
    40203268:	f90013fe 	str	x30, [sp, #32]
    4020326c:	a90357f6 	stp	x22, x21, [sp, #48]
    40203270:	a9044ff4 	stp	x20, x19, [sp, #64]
    40203274:	d503201f 	nop
    40203278:	10020c48 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    4020327c:	8b010d09 	add	x9, x8, x1, lsl #3
    40203280:	f940b534 	ldr	x20, [x9, #360]
    40203284:	d503201f 	nop
    40203288:	100a24c8 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766>
    4020328c:	f900b53f 	str	xzr, [x9, #360]
    40203290:	8b013909 	add	x9, x8, x1, lsl #14
    40203294:	eb14013f 	cmp	x9, x20
    40203298:	540004c8 	b.hi	40203330 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    4020329c:	aa0103f3 	mov	x19, x1
    402032a0:	d372c429 	lsl	x9, x1, #14
    402032a4:	8b090108 	add	x8, x8, x9
    402032a8:	91401108 	add	x8, x8, #0x4, lsl #12
    402032ac:	910d0289 	add	x9, x20, #0x340
    402032b0:	b10d069f 	cmn	x20, #0x341
    402032b4:	fa489122 	ccmp	x9, x8, #0x2, ls  // ls = plast
    402032b8:	540003c8 	b.hi	40203330 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    402032bc:	90000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766+0xb8e0>
    402032c0:	f943f516 	ldr	x22, [x8, #2024]
    402032c4:	f100fedf 	cmp	x22, #0x3f
    402032c8:	54000348 	b.hi	40203330 <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    402032cc:	aa0003f5 	mov	x21, x0
    402032d0:	d5033fdf 	isb
    402032d4:	d53be021 	mrs	x1, cntpct_el0
    402032d8:	f9407e88 	ldr	x8, [x20, #248]
    402032dc:	f9404e89 	ldr	x9, [x20, #152]
    402032e0:	a90023f4 	stp	x20, x8, [sp]
    402032e4:	f9408e88 	ldr	x8, [x20, #280]
    402032e8:	a90123e9 	stp	x9, x8, [sp, #16]
    402032ec:	910003e4 	mov	x4, sp
    402032f0:	52800240 	mov	w0, #0x12                  	// #18
    402032f4:	aa1503e2 	mov	x2, x21
    402032f8:	aa1303e3 	mov	x3, x19
    402032fc:	97fffc95 	bl	40202550 <jnox_kernel::ordinary_reservations::event>
    40203300:	d503201f 	nop
    40203304:	1001e7e8 	adr	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203308:	8b161108 	add	x8, x8, x22, lsl #4
    4020330c:	a9004d15 	stp	x21, x19, [x8]
    40203310:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203314:	f902b113 	str	x19, [x8, #1376]
    40203318:	aa1403e0 	mov	x0, x20
    4020331c:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40203320:	a94357f6 	ldp	x22, x21, [sp, #48]
    40203324:	f94013fe 	ldr	x30, [sp, #32]
    40203328:	910143ff 	add	sp, sp, #0x50
    4020332c:	d65f03c0 	ret
    40203330:	97fff7de 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

0000000040203334 <jnox_kernel::ordinary_reservations::checked::{{closure}}>:
    40203334:	f81f0ffe 	str	x30, [sp, #-16]!
    40203338:	92401c04 	and	x4, x0, #0xff
    4020333c:	52800060 	mov	w0, #0x3                   	// #3
    40203340:	52800041 	mov	w1, #0x2                   	// #2
    40203344:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40203348:	52800043 	mov	w3, #0x2                   	// #2
    4020334c:	aa1f03e5 	mov	x5, xzr
    40203350:	97fffcd7 	bl	402026ac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.2706286857142130766>

0000000040203354 <jnox_kernel::ordinary_reservations::snapshot>:
    40203354:	f81f0ffe 	str	x30, [sp, #-16]!
    40203358:	f100041f 	cmp	x0, #0x1
    4020335c:	54000488 	b.hi	402033ec <jnox_kernel::ordinary_reservations::snapshot+0x98>  // b.pmore
    40203360:	d503201f 	nop
    40203364:	10105569 	adr	x9, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    40203368:	8b000d29 	add	x9, x9, x0, lsl #3
    4020336c:	c8dffd29 	ldar	x9, [x9]
    40203370:	b40002c9 	cbz	x9, 402033c8 <jnox_kernel::ordinary_reservations::snapshot+0x74>
    40203374:	d503201f 	nop
    40203378:	100a1d4a 	adr	x10, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766>
    4020337c:	8b00394b 	add	x11, x10, x0, lsl #14
    40203380:	eb09017f 	cmp	x11, x9
    40203384:	54000328 	b.hi	402033e8 <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    40203388:	b100a53f 	cmn	x9, #0x29
    4020338c:	540002e8 	b.hi	402033e8 <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    40203390:	d372c40b 	lsl	x11, x0, #14
    40203394:	8b0b014a 	add	x10, x10, x11
    40203398:	9140114a 	add	x10, x10, #0x4, lsl #12
    4020339c:	9100a12b 	add	x11, x9, #0x28
    402033a0:	eb0a017f 	cmp	x11, x10
    402033a4:	54000228 	b.hi	402033e8 <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    402033a8:	9100812a 	add	x10, x9, #0x20
    402033ac:	c8dffd40 	ldar	x0, [x10]
    402033b0:	f100041f 	cmp	x0, #0x1
    402033b4:	54000228 	b.hi	402033f8 <jnox_kernel::ordinary_reservations::snapshot+0xa4>  // b.pmore
    402033b8:	8b00112b 	add	x11, x9, x0, lsl #4
    402033bc:	f940016a 	ldr	x10, [x11]
    402033c0:	f940056b 	ldr	x11, [x11, #8]
    402033c4:	14000005 	b	402033d8 <jnox_kernel::ordinary_reservations::snapshot+0x84>
    402033c8:	aa1f03ea 	mov	x10, xzr
    402033cc:	d503201f 	nop
    402033d0:	100152cb 	adr	x11, 40205e28 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.2706286857142130766>
    402033d4:	f860796b 	ldr	x11, [x11, x0, lsl #3]
    402033d8:	a9002d0a 	stp	x10, x11, [x8]
    402033dc:	f9000909 	str	x9, [x8, #16]
    402033e0:	f84107fe 	ldr	x30, [sp], #16
    402033e4:	d65f03c0 	ret
    402033e8:	97fff7b0 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402033ec:	d503201f 	nop
    402033f0:	10015842 	adr	x2, 40205ef8 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.2706286857142130766+0xa8>
    402033f4:	14000003 	b	40203400 <jnox_kernel::ordinary_reservations::snapshot+0xac>
    402033f8:	d503201f 	nop
    402033fc:	100158a2 	adr	x2, 40205f10 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.2706286857142130766+0xc0>
    40203400:	52800041 	mov	w1, #0x2                   	// #2
    40203404:	9400062f 	bl	40204cc0 <core::panicking::panic_bounds_check>

0000000040203408 <reservation_rust_work>:
    40203408:	d10103ff 	sub	sp, sp, #0x40
    4020340c:	f9001bfe 	str	x30, [sp, #48]
    40203410:	f100041f 	cmp	x0, #0x1
    40203414:	54000768 	b.hi	40203500 <reservation_rust_work+0xf8>  // b.pmore
    40203418:	aa1f03e9 	mov	x9, xzr
    4020341c:	d503201f 	nop
    40203420:	10015048 	adr	x8, 40205e28 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.2706286857142130766>
    40203424:	910023ea 	add	x10, sp, #0x8
    40203428:	9280000b 	mov	x11, #0xffffffffffffffff    	// #-1
    4020342c:	f860790d 	ldr	x13, [x8, x0, lsl #3]
    40203430:	9100e3ec 	add	x12, sp, #0x38
    40203434:	d503201f 	nop
    40203438:	10104ec8 	adr	x8, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    4020343c:	5280002e 	mov	w14, #0x1                   	// #1
    40203440:	d503201f 	nop
    40203444:	1002152f 	adr	x15, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40203448:	8b000d08 	add	x8, x8, x0, lsl #3
    4020344c:	8b000def 	add	x15, x15, x0, lsl #3
    40203450:	a900b7ff 	stp	xzr, x13, [sp, #8]
    40203454:	f9000fff 	str	xzr, [sp, #24]
    40203458:	a9027fed 	stp	x13, xzr, [sp, #32]
    4020345c:	c89ffd0a 	stlr	x10, [x8]
    40203460:	d503201f 	nop
    40203464:	100214a8 	adr	x8, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40203468:	8b000d10 	add	x16, x8, x0, lsl #3
    4020346c:	d503201f 	nop
    40203470:	10104c11 	adr	x17, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40203474:	d503201f 	nop
    40203478:	10104c48 	adr	x8, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    4020347c:	8b000d12 	add	x18, x8, x0, lsl #3
    40203480:	c8dffde8 	ldar	x8, [x15]
    40203484:	eb0b011f 	cmp	x8, x11
    40203488:	540000a0 	b.eq	4020349c <reservation_rust_work+0x94>  // b.none
    4020348c:	d5033fdf 	isb
    40203490:	d53be02b 	mrs	x11, cntpct_el0
    40203494:	c89ffe4b 	stlr	x11, [x18]
    40203498:	aa0803eb 	mov	x11, x8
    4020349c:	52800208 	mov	w8, #0x10                  	// #16
    402034a0:	8b0d05ad 	add	x13, x13, x13, lsl #1
    402034a4:	910005ad 	add	x13, x13, #0x1
    402034a8:	f9001fed 	str	x13, [sp, #56]
    402034ac:	f9401fed 	ldr	x13, [sp, #56]
    402034b0:	71000508 	subs	w8, w8, #0x1
    402034b4:	54ffff61 	b.ne	402034a0 <reservation_rust_work+0x98>  // b.any
    402034b8:	f94017e8 	ldr	x8, [sp, #40]
    402034bc:	cb0801c8 	sub	x8, x14, x8
    402034c0:	f100051f 	cmp	x8, #0x1
    402034c4:	54000248 	b.hi	4020350c <reservation_rust_work+0x104>  // b.pmore
    402034c8:	91004129 	add	x9, x9, #0x10
    402034cc:	8b081141 	add	x1, x10, x8, lsl #4
    402034d0:	f9000029 	str	x9, [x1]
    402034d4:	f900042d 	str	x13, [x1, #8]
    402034d8:	91008141 	add	x1, x10, #0x20
    402034dc:	c89ffc28 	stlr	x8, [x1]
    402034e0:	c8dffe08 	ldar	x8, [x16]
    402034e4:	eb08013f 	cmp	x9, x8
    402034e8:	54fffcc1 	b.ne	40203480 <reservation_rust_work+0x78>  // b.any
    402034ec:	f8607a28 	ldr	x8, [x17, x0, lsl #3]
    402034f0:	f100091f 	cmp	x8, #0x2
    402034f4:	54000161 	b.ne	40203520 <reservation_rust_work+0x118>  // b.any
    402034f8:	d4000021 	svc	#0x1
    402034fc:	17ffffe1 	b	40203480 <reservation_rust_work+0x78>
    40203500:	d503201f 	nop
    40203504:	10015122 	adr	x2, 40205f28 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.2706286857142130766+0xd8>
    40203508:	14000004 	b	40203518 <reservation_rust_work+0x110>
    4020350c:	d503201f 	nop
    40203510:	10015182 	adr	x2, 40205f40 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.2706286857142130766+0xf0>
    40203514:	aa0803e0 	mov	x0, x8
    40203518:	52800041 	mov	w1, #0x2                   	// #2
    4020351c:	940005e9 	bl	40204cc0 <core::panicking::panic_bounds_check>
    40203520:	d4000041 	svc	#0x2
    40203524:	d4200020 	brk	#0x1

0000000040203528 <reservation_worker_a>:
    40203528:	f81f0ffe 	str	x30, [sp, #-16]!
    4020352c:	aa1f03e0 	mov	x0, xzr
    40203530:	97ffffb6 	bl	40203408 <reservation_rust_work>

0000000040203534 <reservation_worker_b>:
    40203534:	f81f0ffe 	str	x30, [sp, #-16]!
    40203538:	52800020 	mov	w0, #0x1                   	// #1
    4020353c:	97ffffb3 	bl	40203408 <reservation_rust_work>

0000000040203540 <jnox_kernel::reservation_jobs::Jobs::prepare_destination>:
    40203540:	f9403409 	ldr	x9, [x0, #104]
    40203544:	b40000c9 	cbz	x9, 4020355c <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x1c>
    40203548:	52800089 	mov	w9, #0x4                   	// #4
    4020354c:	39002109 	strb	w9, [x8, #8]
    40203550:	52800049 	mov	w9, #0x2                   	// #2
    40203554:	f9000109 	str	x9, [x8]
    40203558:	d65f03c0 	ret
    4020355c:	aa1f03ea 	mov	x10, xzr
    40203560:	9101e009 	add	x9, x0, #0x78
    40203564:	5280002b 	mov	w11, #0x1                   	// #1
    40203568:	386a692c 	ldrb	w12, [x9, x10]
    4020356c:	3600008b 	tbz	w11, #0, 4020357c <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x3c>
    40203570:	2a1f03eb 	mov	w11, wzr
    40203574:	5280002a 	mov	w10, #0x1                   	// #1
    40203578:	34ffff8c 	cbz	w12, 40203568 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x28>
    4020357c:	35fffe6c 	cbnz	w12, 40203548 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>
    40203580:	39418009 	ldrb	w9, [x0, #96]
    40203584:	71000d3f 	cmp	w9, #0x3
    40203588:	54fffe01 	b.ne	40203548 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>  // b.any
    4020358c:	f9403809 	ldr	x9, [x0, #112]
    40203590:	b5fffdc9 	cbnz	x9, 40203548 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>
    40203594:	aa1f03e1 	mov	x1, xzr
    40203598:	14000141 	b	40203a9c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>

000000004020359c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision>:
    4020359c:	f9403408 	ldr	x8, [x0, #104]
    402035a0:	f100051f 	cmp	x8, #0x1
    402035a4:	54000321 	b.ne	40203608 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x6c>  // b.any
    402035a8:	d10143ff 	sub	sp, sp, #0x50
    402035ac:	a9025ffe 	stp	x30, x23, [sp, #32]
    402035b0:	a90357f6 	stp	x22, x21, [sp, #48]
    402035b4:	a9044ff4 	stp	x20, x19, [sp, #64]
    402035b8:	aa0003f3 	mov	x19, x0
    402035bc:	b9400028 	ldr	w8, [x1]
    402035c0:	39418829 	ldrb	w9, [x1, #98]
    402035c4:	7100011f 	cmp	w8, #0x0
    402035c8:	52800068 	mov	w8, #0x3                   	// #3
    402035cc:	1a881128 	csel	w8, w9, w8, ne  // ne = any
    402035d0:	39418009 	ldrb	w9, [x0, #96]
    402035d4:	71000d3f 	cmp	w9, #0x3
    402035d8:	540001c0 	b.eq	40203610 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x74>  // b.none
    402035dc:	71000d1f 	cmp	w8, #0x3
    402035e0:	54000180 	b.eq	40203610 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x74>  // b.none
    402035e4:	2a1f03e0 	mov	w0, wzr
    402035e8:	f940042a 	ldr	x10, [x1, #8]
    402035ec:	f9402e6b 	ldr	x11, [x19, #88]
    402035f0:	eb0b015f 	cmp	x10, x11
    402035f4:	1a9f17ea 	cset	w10, eq  // eq = none
    402035f8:	6b08013f 	cmp	w9, w8
    402035fc:	540007a1 	b.ne	402036f0 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    40203600:	3700012a 	tbnz	w10, #0, 40203624 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x88>
    40203604:	1400003b 	b	402036f0 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>
    40203608:	2a1f03e0 	mov	w0, wzr
    4020360c:	d65f03c0 	ret
    40203610:	2a1f03e0 	mov	w0, wzr
    40203614:	71000d3f 	cmp	w9, #0x3
    40203618:	540006c1 	b.ne	402036f0 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    4020361c:	71000d1f 	cmp	w8, #0x3
    40203620:	54000681 	b.ne	402036f0 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    40203624:	aa1f03eb 	mov	x11, xzr
    40203628:	9101e268 	add	x8, x19, #0x78
    4020362c:	91018029 	add	x9, x1, #0x60
    40203630:	5280002a 	mov	w10, #0x1                   	// #1
    40203634:	386b690c 	ldrb	w12, [x8, x11]
    40203638:	386b692d 	ldrb	w13, [x9, x11]
    4020363c:	360000aa 	tbz	w10, #0, 40203650 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xb4>
    40203640:	2a1f03ea 	mov	w10, wzr
    40203644:	6b0d019f 	cmp	w12, w13
    40203648:	5280002b 	mov	w11, #0x1                   	// #1
    4020364c:	54ffff40 	b.eq	40203634 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x98>  // b.none
    40203650:	6b0d019f 	cmp	w12, w13
    40203654:	540004c1 	b.ne	402036ec <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x150>  // b.any
    40203658:	f9403a68 	ldr	x8, [x19, #112]
    4020365c:	f9402c29 	ldr	x9, [x1, #88]
    40203660:	eb09011f 	cmp	x8, x9
    40203664:	54000441 	b.ne	402036ec <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x150>  // b.any
    40203668:	aa1f03e8 	mov	x8, xzr
    4020366c:	91002274 	add	x20, x19, #0x8
    40203670:	b8418675 	ldr	w21, [x19], #24
    40203674:	91010037 	add	x23, x1, #0x40
    40203678:	aa0803f6 	mov	x22, x8
    4020367c:	f100091f 	cmp	x8, #0x2
    40203680:	54000300 	b.eq	402036e0 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.none
    40203684:	360000b5 	tbz	w21, #0, 40203698 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xfc>
    40203688:	b9400268 	ldr	w8, [x19]
    4020368c:	f85f0269 	ldur	x9, [x19, #-16]
    40203690:	a90127e8 	stp	x8, x9, [sp, #16]
    40203694:	14000009 	b	402036b8 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x11c>
    40203698:	910023e8 	add	x8, sp, #0x8
    4020369c:	aa1403e0 	mov	x0, x20
    402036a0:	aa1f03e1 	mov	x1, xzr
    402036a4:	940002e7 	bl	40204240 <jnox_kernel::service_policy::PeriodicReservation::allocation_at>
    402036a8:	f94007e8 	ldr	x8, [sp, #8]
    402036ac:	f100051f 	cmp	x8, #0x1
    402036b0:	54000181 	b.ne	402036e0 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.any
    402036b4:	f9400be8 	ldr	x8, [sp, #16]
    402036b8:	f85f82e9 	ldur	x9, [x23, #-8]
    402036bc:	eb09011f 	cmp	x8, x9
    402036c0:	54000101 	b.ne	402036e0 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.any
    402036c4:	f84106e9 	ldr	x9, [x23], #16
    402036c8:	91006273 	add	x19, x19, #0x18
    402036cc:	f9400fea 	ldr	x10, [sp, #24]
    402036d0:	9100a294 	add	x20, x20, #0x28
    402036d4:	910006c8 	add	x8, x22, #0x1
    402036d8:	eb09015f 	cmp	x10, x9
    402036dc:	54fffce0 	b.eq	40203678 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xdc>  // b.none
    402036e0:	f10006df 	cmp	x22, #0x1
    402036e4:	1a9f97e0 	cset	w0, hi  // hi = pmore
    402036e8:	14000002 	b	402036f0 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>
    402036ec:	2a1f03e0 	mov	w0, wzr
    402036f0:	a9444ff4 	ldp	x20, x19, [sp, #64]
    402036f4:	a94357f6 	ldp	x22, x21, [sp, #48]
    402036f8:	a9425ffe 	ldp	x30, x23, [sp, #32]
    402036fc:	910143ff 	add	sp, sp, #0x50
    40203700:	d65f03c0 	ret

0000000040203704 <jnox_kernel::reservation_jobs::Jobs::new>:
    40203704:	d10203ff 	sub	sp, sp, #0x80
    40203708:	a90657fe 	stp	x30, x21, [sp, #96]
    4020370c:	a9074ff4 	stp	x20, x19, [sp, #112]
    40203710:	2a0103f4 	mov	w20, w1
    40203714:	2a0003f5 	mov	w21, w0
    40203718:	aa0803f3 	mov	x19, x8
    4020371c:	72001c3f 	tst	w1, #0xff
    40203720:	540002c0 	b.eq	40203778 <jnox_kernel::reservation_jobs::Jobs::new+0x74>  // b.none
    40203724:	52800028 	mov	w8, #0x1                   	// #1
    40203728:	52800049 	mov	w9, #0x2                   	// #2
    4020372c:	290027e8 	stp	w8, w9, [sp]
    40203730:	12001e8a 	and	w10, w20, #0xff
    40203734:	7100095f 	cmp	w10, #0x2
    40203738:	290127e8 	stp	w8, w9, [sp, #8]
    4020373c:	540002a1 	b.ne	40203790 <jnox_kernel::reservation_jobs::Jobs::new+0x8c>  // b.any
    40203740:	29402be9 	ldp	w9, w10, [sp]
    40203744:	29022be9 	stp	w9, w10, [sp, #16]
    40203748:	29412be9 	ldp	w9, w10, [sp, #8]
    4020374c:	29032be9 	stp	w9, w10, [sp, #24]
    40203750:	52800109 	mov	w9, #0x8                   	// #8
    40203754:	290427e8 	stp	w8, w9, [sp, #32]
    40203758:	910043e0 	add	x0, sp, #0x10
    4020375c:	52800061 	mov	w1, #0x3                   	// #3
    40203760:	940003c7 	bl	4020467c <jnox_kernel::temporal_policy::admit_reservations>
    40203764:	12001c08 	and	w8, w0, #0xff
    40203768:	71000d1f 	cmp	w8, #0x3
    4020376c:	54000401 	b.ne	402037ec <jnox_kernel::reservation_jobs::Jobs::new+0xe8>  // b.any
    40203770:	52800088 	mov	w8, #0x4                   	// #4
    40203774:	1400003b 	b	40203860 <jnox_kernel::reservation_jobs::Jobs::new+0x15c>
    40203778:	52800048 	mov	w8, #0x2                   	// #2
    4020377c:	52800109 	mov	w9, #0x8                   	// #8
    40203780:	5280002a 	mov	w10, #0x1                   	// #1
    40203784:	290027e8 	stp	w8, w9, [sp]
    40203788:	52800088 	mov	w8, #0x4                   	// #4
    4020378c:	290123ea 	stp	w10, w8, [sp, #8]
    40203790:	910003e0 	mov	x0, sp
    40203794:	52800041 	mov	w1, #0x2                   	// #2
    40203798:	940003b9 	bl	4020467c <jnox_kernel::temporal_policy::admit_reservations>
    4020379c:	12001c08 	and	w8, w0, #0xff
    402037a0:	71000d1f 	cmp	w8, #0x3
    402037a4:	54000241 	b.ne	402037ec <jnox_kernel::reservation_jobs::Jobs::new+0xe8>  // b.any
    402037a8:	34000275 	cbz	w21, 402037f4 <jnox_kernel::reservation_jobs::Jobs::new+0xf0>
    402037ac:	294027e8 	ldp	w8, w9, [sp]
    402037b0:	290a27e8 	stp	w8, w9, [sp, #80]
    402037b4:	294127e8 	ldp	w8, w9, [sp, #8]
    402037b8:	290b27e8 	stp	w8, w9, [sp, #88]
    402037bc:	910043e8 	add	x8, sp, #0x10
    402037c0:	910143e1 	add	x1, sp, #0x50
    402037c4:	aa1f03e0 	mov	x0, xzr
    402037c8:	940002df 	bl	40204344 <jnox_kernel::temporal_policy::HardCbs<_>::new>
    402037cc:	b94013e8 	ldr	w8, [sp, #16]
    402037d0:	36000468 	tbz	w8, #0, 4020385c <jnox_kernel::reservation_jobs::Jobs::new+0x158>
    402037d4:	a941a7ee 	ldp	x14, x9, [sp, #24]
    402037d8:	a942a3eb 	ldp	x11, x8, [sp, #40]
    402037dc:	a943abec 	ldp	x12, x10, [sp, #56]
    402037e0:	5280002f 	mov	w15, #0x1                   	// #1
    402037e4:	f94027ed 	ldr	x13, [sp, #72]
    402037e8:	14000011 	b	4020382c <jnox_kernel::reservation_jobs::Jobs::new+0x128>
    402037ec:	11000508 	add	w8, w8, #0x1
    402037f0:	1400001c 	b	40203860 <jnox_kernel::reservation_jobs::Jobs::new+0x15c>
    402037f4:	294027e8 	ldp	w8, w9, [sp]
    402037f8:	d100050a 	sub	x10, x8, #0x1
    402037fc:	eb09015f 	cmp	x10, x9
    40203800:	540002e2 	b.cs	4020385c <jnox_kernel::reservation_jobs::Jobs::new+0x158>  // b.hs, b.nlast
    40203804:	294137ea 	ldp	w10, w13, [sp, #8]
    40203808:	d100054b 	sub	x11, x10, #0x1
    4020380c:	eb0d017f 	cmp	x11, x13
    40203810:	54000262 	b.cs	4020385c <jnox_kernel::reservation_jobs::Jobs::new+0x158>  // b.hs, b.nlast
    40203814:	aa1f03ec 	mov	x12, xzr
    40203818:	aa1f03eb 	mov	x11, xzr
    4020381c:	aa1f03ef 	mov	x15, xzr
    40203820:	72001e9f 	tst	w20, #0xff
    40203824:	1a9f17f0 	cset	w16, eq  // eq = none
    40203828:	aa0803ee 	mov	x14, x8
    4020382c:	a9003a6f 	stp	x15, x14, [x19]
    40203830:	a9012e69 	stp	x9, x11, [x19, #16]
    40203834:	a9023268 	stp	x8, x12, [x19, #32]
    40203838:	a903366a 	stp	x10, x13, [x19, #48]
    4020383c:	a9042a70 	stp	x16, x10, [x19, #64]
    40203840:	f9002a70 	str	x16, [x19, #80]
    40203844:	52800068 	mov	w8, #0x3                   	// #3
    40203848:	39018268 	strb	w8, [x19, #96]
    4020384c:	a906fe7f 	stp	xzr, xzr, [x19, #104]
    40203850:	7900f27f 	strh	wzr, [x19, #120]
    40203854:	3901ea74 	strb	w20, [x19, #122]
    40203858:	14000005 	b	4020386c <jnox_kernel::reservation_jobs::Jobs::new+0x168>
    4020385c:	52800028 	mov	w8, #0x1                   	// #1
    40203860:	39002268 	strb	w8, [x19, #8]
    40203864:	52800048 	mov	w8, #0x2                   	// #2
    40203868:	f9000268 	str	x8, [x19]
    4020386c:	a9474ff4 	ldp	x20, x19, [sp, #112]
    40203870:	a94657fe 	ldp	x30, x21, [sp, #96]
    40203874:	910203ff 	add	sp, sp, #0x80
    40203878:	d65f03c0 	ret

000000004020387c <jnox_kernel::reservation_jobs::Jobs::open>:
    4020387c:	d10783ff 	sub	sp, sp, #0x1e0
    40203880:	a9197bfd 	stp	x29, x30, [sp, #400]
    40203884:	a91a67fa 	stp	x26, x25, [sp, #416]
    40203888:	a91b5ff8 	stp	x24, x23, [sp, #432]
    4020388c:	a91c57f6 	stp	x22, x21, [sp, #448]
    40203890:	a91d4ff4 	stp	x20, x19, [sp, #464]
    40203894:	aa0803f3 	mov	x19, x8
    40203898:	f9403408 	ldr	x8, [x0, #104]
    4020389c:	eb08003f 	cmp	x1, x8
    402038a0:	540002e1 	b.ne	402038fc <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.any
    402038a4:	aa0103f5 	mov	x21, x1
    402038a8:	aa0003f4 	mov	x20, x0
    402038ac:	3941e816 	ldrb	w22, [x0, #122]
    402038b0:	710002df 	cmp	w22, #0x0
    402038b4:	52800148 	mov	w8, #0xa                   	// #10
    402038b8:	52800449 	mov	w9, #0x22                  	// #34
    402038bc:	9a880128 	csel	x8, x9, x8, eq  // eq = none
    402038c0:	eb08003f 	cmp	x1, x8
    402038c4:	540001c2 	b.cs	402038fc <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.hs, b.nlast
    402038c8:	39418288 	ldrb	w8, [x20, #96]
    402038cc:	71000d1f 	cmp	w8, #0x3
    402038d0:	54000161 	b.ne	402038fc <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.any
    402038d4:	aa1403e1 	mov	x1, x20
    402038d8:	f8408428 	ldr	x8, [x1], #8
    402038dc:	f100051f 	cmp	x8, #0x1
    402038e0:	54000241 	b.ne	40203928 <jnox_kernel::reservation_jobs::Jobs::open+0xac>  // b.any
    402038e4:	f9401e97 	ldr	x23, [x20, #56]
    402038e8:	910583e0 	add	x0, sp, #0x160
    402038ec:	52800602 	mov	w2, #0x30                  	// #48
    402038f0:	94000844 	bl	40205a00 <memcpy>
    402038f4:	52800028 	mov	w8, #0x1                   	// #1
    402038f8:	14000021 	b	4020397c <jnox_kernel::reservation_jobs::Jobs::open+0x100>
    402038fc:	52800088 	mov	w8, #0x4                   	// #4
    40203900:	39002268 	strb	w8, [x19, #8]
    40203904:	52800048 	mov	w8, #0x2                   	// #2
    40203908:	f9000268 	str	x8, [x19]
    4020390c:	a95d4ff4 	ldp	x20, x19, [sp, #464]
    40203910:	a95c57f6 	ldp	x22, x21, [sp, #448]
    40203914:	a95b5ff8 	ldp	x24, x23, [sp, #432]
    40203918:	a95a67fa 	ldp	x26, x25, [sp, #416]
    4020391c:	a9597bfd 	ldp	x29, x30, [sp, #400]
    40203920:	910783ff 	add	sp, sp, #0x1e0
    40203924:	d65f03c0 	ret
    40203928:	910203e0 	add	x0, sp, #0x80
    4020392c:	9100a017 	add	x23, x0, #0x28
    40203930:	52800028 	mov	w8, #0x1                   	// #1
    40203934:	2a0803f8 	mov	w24, w8
    40203938:	9100a039 	add	x25, x1, #0x28
    4020393c:	52800502 	mov	w2, #0x28                  	// #40
    40203940:	94000830 	bl	40205a00 <memcpy>
    40203944:	2a1f03e8 	mov	w8, wzr
    40203948:	aa1903e1 	mov	x1, x25
    4020394c:	aa1703e0 	mov	x0, x23
    40203950:	3707ff38 	tbnz	w24, #0, 40203934 <jnox_kernel::reservation_jobs::Jobs::open+0xb8>
    40203954:	910583e0 	add	x0, sp, #0x160
    40203958:	910203e1 	add	x1, sp, #0x80
    4020395c:	52800602 	mov	w2, #0x30                  	// #48
    40203960:	94000828 	bl	40205a00 <memcpy>
    40203964:	aa1f03e8 	mov	x8, xzr
    40203968:	a94b27f7 	ldp	x23, x9, [sp, #176]
    4020396c:	a94c2fea 	ldp	x10, x11, [sp, #192]
    40203970:	a914abe9 	stp	x9, x10, [sp, #328]
    40203974:	f900afeb 	str	x11, [sp, #344]
    40203978:	f9402e98 	ldr	x24, [x20, #88]
    4020397c:	f9403a99 	ldr	x25, [x20, #112]
    40203980:	f90003e8 	str	x8, [sp]
    40203984:	910003e8 	mov	x8, sp
    40203988:	7940f29a 	ldrh	w26, [x20, #120]
    4020398c:	91002100 	add	x0, x8, #0x8
    40203990:	910583e1 	add	x1, sp, #0x160
    40203994:	52800602 	mov	w2, #0x30                  	// #48
    40203998:	9400081a 	bl	40205a00 <memcpy>
    4020399c:	3901ebf6 	strb	w22, [sp, #122]
    402039a0:	a954a7e8 	ldp	x8, x9, [sp, #328]
    402039a4:	a903a3f7 	stp	x23, x8, [sp, #56]
    402039a8:	f940afe8 	ldr	x8, [sp, #344]
    402039ac:	a904a3e9 	stp	x9, x8, [sp, #72]
    402039b0:	a906e7f5 	stp	x21, x25, [sp, #104]
    402039b4:	7900f3fa 	strh	w26, [sp, #120]
    402039b8:	f9002ff8 	str	x24, [sp, #88]
    402039bc:	52800068 	mov	w8, #0x3                   	// #3
    402039c0:	390183e8 	strb	w8, [sp, #96]
    402039c4:	910203f7 	add	x23, sp, #0x80
    402039c8:	910203e8 	add	x8, sp, #0x80
    402039cc:	910003e0 	mov	x0, sp
    402039d0:	aa1503e1 	mov	x1, x21
    402039d4:	94000032 	bl	40203a9c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>
    402039d8:	f94043f6 	ldr	x22, [sp, #128]
    402039dc:	394223f5 	ldrb	w21, [sp, #136]
    402039e0:	f1000adf 	cmp	x22, #0x2
    402039e4:	54000061 	b.ne	402039f0 <jnox_kernel::reservation_jobs::Jobs::open+0x174>  // b.any
    402039e8:	39002275 	strb	w21, [x19, #8]
    402039ec:	17ffffc6 	b	40203904 <jnox_kernel::reservation_jobs::Jobs::open+0x88>
    402039f0:	9103a3e0 	add	x0, sp, #0xe8
    402039f4:	910026e1 	add	x1, x23, #0x9
    402039f8:	52800be2 	mov	w2, #0x5f                  	// #95
    402039fc:	94000801 	bl	40205a00 <memcpy>
    40203a00:	910003e1 	mov	x1, sp
    40203a04:	aa1403e0 	mov	x0, x20
    40203a08:	52801002 	mov	w2, #0x80                  	// #128
    40203a0c:	940007fd 	bl	40205a00 <memcpy>
    40203a10:	f9000276 	str	x22, [x19]
    40203a14:	39002275 	strb	w21, [x19, #8]
    40203a18:	91002660 	add	x0, x19, #0x9
    40203a1c:	9103a3e1 	add	x1, sp, #0xe8
    40203a20:	52800be2 	mov	w2, #0x5f                  	// #95
    40203a24:	940007f7 	bl	40205a00 <memcpy>
    40203a28:	17ffffb9 	b	4020390c <jnox_kernel::reservation_jobs::Jobs::open+0x90>

0000000040203a2c <jnox_kernel::reservation_jobs::Jobs::trap>:
    40203a2c:	3941800a 	ldrb	w10, [x0, #96]
    40203a30:	71000d5f 	cmp	w10, #0x3
    40203a34:	54000061 	b.ne	40203a40 <jnox_kernel::reservation_jobs::Jobs::trap+0x14>  // b.any
    40203a38:	52800080 	mov	w0, #0x4                   	// #4
    40203a3c:	d65f03c0 	ret
    40203a40:	aa0003e8 	mov	x8, x0
    40203a44:	12001c49 	and	w9, w2, #0xff
    40203a48:	52800080 	mov	w0, #0x4                   	// #4
    40203a4c:	6b09015f 	cmp	w10, w9
    40203a50:	54000181 	b.ne	40203a80 <jnox_kernel::reservation_jobs::Jobs::trap+0x54>  // b.any
    40203a54:	f9402d0a 	ldr	x10, [x8, #88]
    40203a58:	eb01015f 	cmp	x10, x1
    40203a5c:	54000121 	b.ne	40203a80 <jnox_kernel::reservation_jobs::Jobs::trap+0x54>  // b.any
    40203a60:	f100043f 	cmp	x1, #0x1
    40203a64:	54000108 	b.hi	40203a84 <jnox_kernel::reservation_jobs::Jobs::trap+0x58>  // b.pmore
    40203a68:	2a1f03e0 	mov	w0, wzr
    40203a6c:	11000929 	add	w9, w9, #0x2
    40203a70:	8b01010a 	add	x10, x8, x1
    40203a74:	3901e149 	strb	w9, [x10, #120]
    40203a78:	52800069 	mov	w9, #0x3                   	// #3
    40203a7c:	39018109 	strb	w9, [x8, #96]
    40203a80:	d65f03c0 	ret
    40203a84:	f81f0ffe 	str	x30, [sp, #-16]!
    40203a88:	d503201f 	nop
    40203a8c:	10012662 	adr	x2, 40205f58 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236>
    40203a90:	aa0103e0 	mov	x0, x1
    40203a94:	52800041 	mov	w1, #0x2                   	// #2
    40203a98:	9400048a 	bl	40204cc0 <core::panicking::panic_bounds_check>

0000000040203a9c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>:
    40203a9c:	d10483ff 	sub	sp, sp, #0x120
    40203aa0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    40203aa4:	a90d6ffc 	stp	x28, x27, [sp, #208]
    40203aa8:	a90e67fa 	stp	x26, x25, [sp, #224]
    40203aac:	a90f5ff8 	stp	x24, x23, [sp, #240]
    40203ab0:	a91057f6 	stp	x22, x21, [sp, #256]
    40203ab4:	a9114ff4 	stp	x20, x19, [sp, #272]
    40203ab8:	aa0103f5 	mov	x21, x1
    40203abc:	aa0003f4 	mov	x20, x0
    40203ac0:	aa0803f3 	mov	x19, x8
    40203ac4:	3941e808 	ldrb	w8, [x0, #122]
    40203ac8:	910083e9 	add	x9, sp, #0x20
    40203acc:	9100413b 	add	x27, x9, #0x10
    40203ad0:	340000e8 	cbz	w8, 40203aec <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x50>
    40203ad4:	f10002bf 	cmp	x21, #0x0
    40203ad8:	b21e03e9 	mov	x9, #0x400000004           	// #17179869188
    40203adc:	9a9f0129 	csel	x9, x9, xzr, eq  // eq = none
    40203ae0:	7100051f 	cmp	w8, #0x1
    40203ae4:	9a9f012a 	csel	x10, x9, xzr, eq  // eq = none
    40203ae8:	1400000b 	b	40203b14 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203aec:	aa1f03ea 	mov	x10, xzr
    40203af0:	f1005ebf 	cmp	x21, #0x17
    40203af4:	54000108 	b.hi	40203b14 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>  // b.pmore
    40203af8:	52800028 	mov	w8, #0x1                   	// #1
    40203afc:	9ad52108 	lsl	x8, x8, x21
    40203b00:	52840629 	mov	w9, #0x2031                	// #8241
    40203b04:	72a00809 	movk	w9, #0x40, lsl #16
    40203b08:	ea09011f 	tst	x8, x9
    40203b0c:	54000da0 	b.eq	40203cc0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x224>  // b.none
    40203b10:	5280002a 	mov	w10, #0x1                   	// #1
    40203b14:	aa1f03f6 	mov	x22, xzr
    40203b18:	a9012bea 	stp	x10, x10, [sp, #16]
    40203b1c:	5280011d 	mov	w29, #0x8                   	// #8
    40203b20:	910063fa 	add	x26, sp, #0x18
    40203b24:	5280003c 	mov	w28, #0x1                   	// #1
    40203b28:	b8767b57 	ldr	w23, [x26, x22, lsl #2]
    40203b2c:	34000297 	cbz	w23, 40203b7c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0xe0>
    40203b30:	8b160298 	add	x24, x20, x22
    40203b34:	3941e308 	ldrb	w8, [x24, #120]
    40203b38:	71000d1f 	cmp	w8, #0x3
    40203b3c:	7a401904 	ccmp	w8, #0x0, #0x4, ne  // ne = any
    40203b40:	540014a1 	b.ne	40203dd4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.any
    40203b44:	8b160a99 	add	x25, x20, x22, lsl #2
    40203b48:	b9407328 	ldr	w8, [x25, #112]
    40203b4c:	35001448 	cbnz	w8, 40203dd4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203b50:	f9400288 	ldr	x8, [x20]
    40203b54:	f100051f 	cmp	x8, #0x1
    40203b58:	540000e1 	b.ne	40203b74 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0xd8>  // b.any
    40203b5c:	91002280 	add	x0, x20, #0x8
    40203b60:	aa1603e1 	mov	x1, x22
    40203b64:	2a1703e2 	mov	w2, w23
    40203b68:	94000279 	bl	4020454c <jnox_kernel::temporal_policy::HardCbs<_>::release>
    40203b6c:	f100141f 	cmp	x0, #0x5
    40203b70:	54000a01 	b.ne	40203cb0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x214>  // b.any
    40203b74:	b9007337 	str	w23, [x25, #112]
    40203b78:	3901e31c 	strb	w28, [x24, #120]
    40203b7c:	f10013bd 	subs	x29, x29, #0x4
    40203b80:	910006d6 	add	x22, x22, #0x1
    40203b84:	54fffd21 	b.ne	40203b28 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x8c>  // b.any
    40203b88:	6f00e400 	movi	v0.2d, #0x0
    40203b8c:	ad0103e0 	stp	q0, q0, [sp, #32]
    40203b90:	f9400288 	ldr	x8, [x20]
    40203b94:	f100051f 	cmp	x8, #0x1
    40203b98:	54000421 	b.ne	40203c1c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x180>  // b.any
    40203b9c:	aa1f03f5 	mov	x21, xzr
    40203ba0:	aa1f03fb 	mov	x27, xzr
    40203ba4:	91006296 	add	x22, x20, #0x18
    40203ba8:	910083f7 	add	x23, sp, #0x20
    40203bac:	910203e8 	add	x8, sp, #0x80
    40203bb0:	91002280 	add	x0, x20, #0x8
    40203bb4:	aa1503e1 	mov	x1, x21
    40203bb8:	9400028b 	bl	402045e4 <jnox_kernel::temporal_policy::HardCbs<_>::available>
    40203bbc:	a94823e9 	ldp	x9, x8, [sp, #128]
    40203bc0:	f100093f 	cmp	x9, #0x2
    40203bc4:	54000280 	b.eq	40203c14 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x178>  // b.none
    40203bc8:	36000069 	tbz	w9, #0, 40203bd4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x138>
    40203bcc:	f9404be9 	ldr	x9, [sp, #144]
    40203bd0:	14000003 	b	40203bdc <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x140>
    40203bd4:	b94002c8 	ldr	w8, [x22]
    40203bd8:	f85f02c9 	ldur	x9, [x22, #-16]
    40203bdc:	8b1b02ea 	add	x10, x23, x27
    40203be0:	9100437b 	add	x27, x27, #0x10
    40203be4:	2a0803e8 	mov	w8, w8
    40203be8:	a9002548 	stp	x8, x9, [x10]
    40203bec:	910062d6 	add	x22, x22, #0x18
    40203bf0:	910006b5 	add	x21, x21, #0x1
    40203bf4:	f100837f 	cmp	x27, #0x20
    40203bf8:	54fffda1 	b.ne	40203bac <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x110>  // b.any
    40203bfc:	910203e8 	add	x8, sp, #0x80
    40203c00:	91002280 	add	x0, x20, #0x8
    40203c04:	940001f4 	bl	402043d4 <jnox_kernel::temporal_policy::HardCbs<_>::tick>
    40203c08:	a94823e9 	ldp	x9, x8, [sp, #128]
    40203c0c:	f100053f 	cmp	x9, #0x1
    40203c10:	54000641 	b.ne	40203cd8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x23c>  // b.any
    40203c14:	f100111f 	cmp	x8, #0x4
    40203c18:	14000027 	b	40203cb4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x218>
    40203c1c:	910083e8 	add	x8, sp, #0x20
    40203c20:	b27d0117 	orr	x23, x8, #0x8
    40203c24:	52800a1a 	mov	w26, #0x50                  	// #80
    40203c28:	91002296 	add	x22, x20, #0x8
    40203c2c:	910203e8 	add	x8, sp, #0x80
    40203c30:	aa1603e0 	mov	x0, x22
    40203c34:	aa1503e1 	mov	x1, x21
    40203c38:	94000182 	bl	40204240 <jnox_kernel::service_policy::PeriodicReservation::allocation_at>
    40203c3c:	b94083e8 	ldr	w8, [sp, #128]
    40203c40:	36001108 	tbz	w8, #0, 40203e60 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c4>
    40203c44:	a948a7e8 	ldp	x8, x9, [sp, #136]
    40203c48:	f100a35a 	subs	x26, x26, #0x28
    40203c4c:	a93fa6e8 	stp	x8, x9, [x23, #-8]
    40203c50:	9100a2d6 	add	x22, x22, #0x28
    40203c54:	910042f7 	add	x23, x23, #0x10
    40203c58:	54fffea1 	b.ne	40203c2c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x190>  // b.any
    40203c5c:	aa1f03e8 	mov	x8, xzr
    40203c60:	910083e9 	add	x9, sp, #0x20
    40203c64:	9101c28c 	add	x12, x20, #0x70
    40203c68:	a90827ec 	stp	x12, x9, [sp, #128]
    40203c6c:	5280004a 	mov	w10, #0x2                   	// #2
    40203c70:	a909a7ea 	stp	x10, x9, [sp, #152]
    40203c74:	f9400bf7 	ldr	x23, [sp, #16]
    40203c78:	9100050a 	add	x10, x8, #0x1
    40203c7c:	b868798b 	ldr	w11, [x12, x8, lsl #2]
    40203c80:	3400006b 	cbz	w11, 40203c8c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x1f0>
    40203c84:	f940012b 	ldr	x11, [x9]
    40203c88:	b50003cb 	cbnz	x11, 40203d00 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x264>
    40203c8c:	f100095f 	cmp	x10, #0x2
    40203c90:	aa1b03e9 	mov	x9, x27
    40203c94:	52800028 	mov	w8, #0x1                   	// #1
    40203c98:	54ffff01 	b.ne	40203c78 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x1dc>  // b.any
    40203c9c:	aa1f03e9 	mov	x9, xzr
    40203ca0:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203ca4:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203ca8:	52800068 	mov	w8, #0x3                   	// #3
    40203cac:	14000059 	b	40203e10 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x374>
    40203cb0:	f100101f 	cmp	x0, #0x4
    40203cb4:	52800068 	mov	w8, #0x3                   	// #3
    40203cb8:	1a880508 	cinc	w8, w8, ne  // ne = any
    40203cbc:	1400006a 	b	40203e64 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c8>
    40203cc0:	f10006bf 	cmp	x21, #0x1
    40203cc4:	540008c0 	b.eq	40203ddc <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x340>  // b.none
    40203cc8:	f1005ebf 	cmp	x21, #0x17
    40203ccc:	54fff241 	b.ne	40203b14 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>  // b.any
    40203cd0:	52800c8a 	mov	w10, #0x64                  	// #100
    40203cd4:	17ffff90 	b	40203b14 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203cd8:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203cdc:	f9404bf6 	ldr	x22, [sp, #144]
    40203ce0:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203ce4:	36000808 	tbz	w8, #0, 40203de4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x348>
    40203ce8:	f10006df 	cmp	x22, #0x1
    40203cec:	f9400bf7 	ldr	x23, [sp, #16]
    40203cf0:	54000369 	b.ls	40203d5c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x2c0>  // b.plast
    40203cf4:	d503201f 	nop
    40203cf8:	10011482 	adr	x2, 40205f88 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x30>
    40203cfc:	14000067 	b	40203e98 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3fc>
    40203d00:	f9004bea 	str	x10, [sp, #144]
    40203d04:	f9400529 	ldr	x9, [x9, #8]
    40203d08:	a90aa3e9 	stp	x9, x8, [sp, #168]
    40203d0c:	f9005fe8 	str	x8, [sp, #184]
    40203d10:	910183e8 	add	x8, sp, #0x60
    40203d14:	91002108 	add	x8, x8, #0x8
    40203d18:	910203e0 	add	x0, sp, #0x80
    40203d1c:	9102a3e1 	add	x1, sp, #0xa8
    40203d20:	94000098 	bl	40203f80 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold>
    40203d24:	f9403ff6 	ldr	x22, [sp, #120]
    40203d28:	f1000adf 	cmp	x22, #0x2
    40203d2c:	54000b22 	b.cs	40203e90 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3f4>  // b.hs, b.nlast
    40203d30:	52800508 	mov	w8, #0x28                  	// #40
    40203d34:	91002289 	add	x9, x20, #0x8
    40203d38:	9b0826c0 	madd	x0, x22, x8, x9
    40203d3c:	aa1503e1 	mov	x1, x21
    40203d40:	52800022 	mov	w2, #0x1                   	// #1
    40203d44:	9400015a 	bl	402042ac <jnox_kernel::service_policy::PeriodicReservation::grant_at>
    40203d48:	f100041f 	cmp	x0, #0x1
    40203d4c:	fa410820 	ccmp	x1, #0x1, #0x0, eq  // eq = none
    40203d50:	54000421 	b.ne	40203dd4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.any
    40203d54:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203d58:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203d5c:	9101e288 	add	x8, x20, #0x78
    40203d60:	38766908 	ldrb	w8, [x8, x22]
    40203d64:	51000508 	sub	w8, w8, #0x1
    40203d68:	7100091f 	cmp	w8, #0x2
    40203d6c:	54000342 	b.cs	40203dd4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.hs, b.nlast
    40203d70:	9101c28a 	add	x10, x20, #0x70
    40203d74:	b8767948 	ldr	w8, [x10, x22, lsl #2]
    40203d78:	51000509 	sub	w9, w8, #0x1
    40203d7c:	d3607d29 	lsl	x9, x9, #32
    40203d80:	7100011f 	cmp	w8, #0x0
    40203d84:	52808028 	mov	w8, #0x401                 	// #1025
    40203d88:	9a890108 	csel	x8, x8, x9, eq  // eq = none
    40203d8c:	37000248 	tbnz	w8, #0, 40203dd4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203d90:	d360fd08 	lsr	x8, x8, #32
    40203d94:	b8367948 	str	w8, [x10, x22, lsl #2]
    40203d98:	910103e9 	add	x9, sp, #0x40
    40203d9c:	8b161129 	add	x9, x9, x22, lsl #4
    40203da0:	f940012a 	ldr	x10, [x9]
    40203da4:	b400018a 	cbz	x10, 40203dd4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203da8:	d100054a 	sub	x10, x10, #0x1
    40203dac:	f900012a 	str	x10, [x9]
    40203db0:	3941ea89 	ldrb	w9, [x20, #122]
    40203db4:	7100093f 	cmp	w9, #0x2
    40203db8:	540001e0 	b.eq	40203df4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x358>  // b.none
    40203dbc:	7100053f 	cmp	w9, #0x1
    40203dc0:	540001e1 	b.ne	40203dfc <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x360>  // b.any
    40203dc4:	f100011f 	cmp	x8, #0x0
    40203dc8:	52800048 	mov	w8, #0x2                   	// #2
    40203dcc:	1a9f0108 	csel	w8, w8, wzr, eq  // eq = none
    40203dd0:	1400000d 	b	40203e04 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x368>
    40203dd4:	52800088 	mov	w8, #0x4                   	// #4
    40203dd8:	14000023 	b	40203e64 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c8>
    40203ddc:	d2c00c8a 	mov	x10, #0x6400000000          	// #429496729600
    40203de0:	17ffff4d 	b	40203b14 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203de4:	aa1f03e9 	mov	x9, xzr
    40203de8:	52800068 	mov	w8, #0x3                   	// #3
    40203dec:	f9400bf7 	ldr	x23, [sp, #16]
    40203df0:	14000008 	b	40203e10 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x374>
    40203df4:	2a1f03e8 	mov	w8, wzr
    40203df8:	14000003 	b	40203e04 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x368>
    40203dfc:	f100011f 	cmp	x8, #0x0
    40203e00:	1a9f17e8 	cset	w8, eq  // eq = none
    40203e04:	f9002e96 	str	x22, [x20, #88]
    40203e08:	52800029 	mov	w9, #0x1                   	// #1
    40203e0c:	39018288 	strb	w8, [x20, #96]
    40203e10:	f940368a 	ldr	x10, [x20, #104]
    40203e14:	b100055f 	cmn	x10, #0x1
    40203e18:	54000240 	b.eq	40203e60 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c4>  // b.none
    40203e1c:	9100054a 	add	x10, x10, #0x1
    40203e20:	f900368a 	str	x10, [x20, #104]
    40203e24:	a9422fea 	ldp	x10, x11, [sp, #32]
    40203e28:	a94337ec 	ldp	x12, x13, [sp, #48]
    40203e2c:	a902326b 	stp	x11, x12, [x19, #32]
    40203e30:	a94433eb 	ldp	x11, x12, [sp, #64]
    40203e34:	a9032e6d 	stp	x13, x11, [x19, #48]
    40203e38:	a9452fed 	ldp	x13, x11, [sp, #80]
    40203e3c:	a904366c 	stp	x12, x13, [x19, #64]
    40203e40:	a9005a69 	stp	x9, x22, [x19]
    40203e44:	7940f289 	ldrh	w9, [x20, #120]
    40203e48:	f9403a8c 	ldr	x12, [x20, #112]
    40203e4c:	a9012a77 	stp	x23, x10, [x19, #16]
    40203e50:	a905326b 	stp	x11, x12, [x19, #80]
    40203e54:	7900c269 	strh	w9, [x19, #96]
    40203e58:	39018a68 	strb	w8, [x19, #98]
    40203e5c:	14000005 	b	40203e70 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3d4>
    40203e60:	52800068 	mov	w8, #0x3                   	// #3
    40203e64:	39002268 	strb	w8, [x19, #8]
    40203e68:	52800048 	mov	w8, #0x2                   	// #2
    40203e6c:	f9000268 	str	x8, [x19]
    40203e70:	a9514ff4 	ldp	x20, x19, [sp, #272]
    40203e74:	a95057f6 	ldp	x22, x21, [sp, #256]
    40203e78:	a94f5ff8 	ldp	x24, x23, [sp, #240]
    40203e7c:	a94e67fa 	ldp	x26, x25, [sp, #224]
    40203e80:	a94d6ffc 	ldp	x28, x27, [sp, #208]
    40203e84:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    40203e88:	910483ff 	add	sp, sp, #0x120
    40203e8c:	d65f03c0 	ret
    40203e90:	d503201f 	nop
    40203e94:	100106e2 	adr	x2, 40205f70 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x18>
    40203e98:	aa1603e0 	mov	x0, x22
    40203e9c:	52800041 	mov	w1, #0x2                   	// #2
    40203ea0:	94000388 	bl	40204cc0 <core::panicking::panic_bounds_check>

0000000040203ea4 <jnox_kernel::reservation_jobs::Clock::new>:
    40203ea4:	b40005a1 	cbz	x1, 40203f58 <jnox_kernel::reservation_jobs::Clock::new+0xb4>
    40203ea8:	d343fc29 	lsr	x9, x1, #3
    40203eac:	d29ef9ea 	mov	x10, #0xf7cf                	// #63439
    40203eb0:	f2bc6a6a 	movk	x10, #0xe353, lsl #16
    40203eb4:	f2d374aa 	movk	x10, #0x9ba5, lsl #32
    40203eb8:	f2e4188a 	movk	x10, #0x20c4, lsl #48
    40203ebc:	9bca7d29 	umulh	x9, x9, x10
    40203ec0:	d344fd29 	lsr	x9, x9, #4
    40203ec4:	52807d0a 	mov	w10, #0x3e8                 	// #1000
    40203ec8:	9b0a852a 	msub	x10, x9, x10, x1
    40203ecc:	b500046a 	cbnz	x10, 40203f58 <jnox_kernel::reservation_jobs::Clock::new+0xb4>
    40203ed0:	b202e7ea 	mov	x10, #0xcccccccccccccccc    	// #-3689348814741910324
    40203ed4:	f29999aa 	movk	x10, #0xcccd
    40203ed8:	9bca7c2a 	umulh	x10, x1, x10
    40203edc:	d344fd4a 	lsr	x10, x10, #4
    40203ee0:	72001c5f 	tst	w2, #0xff
    40203ee4:	5280014b 	mov	w11, #0xa                   	// #10
    40203ee8:	5280050c 	mov	w12, #0x28                  	// #40
    40203eec:	9a8b018b 	csel	x11, x12, x11, eq  // eq = none
    40203ef0:	9bca7d6c 	umulh	x12, x11, x10
    40203ef4:	eb0c03ff 	cmp	xzr, x12
    40203ef8:	1a9f07ec 	cset	w12, ne  // ne = any
    40203efc:	9b0a7d6b 	mul	x11, x11, x10
    40203f00:	ab0b001f 	cmn	x0, x11
    40203f04:	1a9f37eb 	cset	w11, cs  // cs = hs, nlast
    40203f08:	3700020c 	tbnz	w12, #0, 40203f48 <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f0c:	350001eb 	cbnz	w11, 40203f48 <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f10:	72001c5f 	tst	w2, #0xff
    40203f14:	5280014b 	mov	w11, #0xa                   	// #10
    40203f18:	5280044c 	mov	w12, #0x22                  	// #34
    40203f1c:	9a8b018b 	csel	x11, x12, x11, eq  // eq = none
    40203f20:	9bca7d6c 	umulh	x12, x11, x10
    40203f24:	eb0c03ff 	cmp	xzr, x12
    40203f28:	1a9f07ed 	cset	w13, ne  // ne = any
    40203f2c:	9b0a7d6b 	mul	x11, x11, x10
    40203f30:	ab00016b 	adds	x11, x11, x0
    40203f34:	1a9f37ec 	cset	w12, cs  // cs = hs, nlast
    40203f38:	3700008d 	tbnz	w13, #0, 40203f48 <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f3c:	3500006c 	cbnz	w12, 40203f48 <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f40:	ab09057f 	cmn	x11, x9, lsl #1
    40203f44:	54000123 	b.cc	40203f68 <jnox_kernel::reservation_jobs::Clock::new+0xc4>  // b.lo, b.ul, b.last
    40203f48:	52800069 	mov	w9, #0x3                   	// #3
    40203f4c:	39000509 	strb	w9, [x8, #1]
    40203f50:	5280002b 	mov	w11, #0x1                   	// #1
    40203f54:	14000003 	b	40203f60 <jnox_kernel::reservation_jobs::Clock::new+0xbc>
    40203f58:	5280002b 	mov	w11, #0x1                   	// #1
    40203f5c:	3900050b 	strb	w11, [x8, #1]
    40203f60:	3900010b 	strb	w11, [x8]
    40203f64:	d65f03c0 	ret
    40203f68:	2a1f03eb 	mov	w11, wzr
    40203f6c:	a900a900 	stp	x0, x10, [x8, #8]
    40203f70:	f9000d09 	str	x9, [x8, #24]
    40203f74:	17fffffb 	b	40203f60 <jnox_kernel::reservation_jobs::Clock::new+0xbc>

0000000040203f78 <__rustc::rust_begin_unwind>:
    40203f78:	d503205f 	wfe
    40203f7c:	17ffffff 	b	40203f78 <__rustc::rust_begin_unwind>

0000000040203f80 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold>:
    40203f80:	d10103ff 	sub	sp, sp, #0x40
    40203f84:	f9001bfe 	str	x30, [sp, #48]
    40203f88:	a9412809 	ldp	x9, x10, [x0, #16]
    40203f8c:	eb0a013f 	cmp	x9, x10
    40203f90:	540004e2 	b.cs	4020402c <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0xac>  // b.hs, b.nlast
    40203f94:	f940100e 	ldr	x14, [x0, #32]
    40203f98:	a940340b 	ldp	x11, x13, [x0]
    40203f9c:	910003ec 	mov	x12, sp
    40203fa0:	9100618c 	add	x12, x12, #0x18
    40203fa4:	f100093f 	cmp	x9, #0x2
    40203fa8:	5280004f 	mov	w15, #0x2                   	// #2
    40203fac:	9a8f8120 	csel	x0, x9, x15, hi  // hi = pmore
    40203fb0:	8b0911ad 	add	x13, x13, x9, lsl #4
    40203fb4:	8b0911ce 	add	x14, x14, x9, lsl #4
    40203fb8:	910021ce 	add	x14, x14, #0x8
    40203fbc:	eb09001f 	cmp	x0, x9
    40203fc0:	54000440 	b.eq	40204048 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0xc8>  // b.none
    40203fc4:	b869796f 	ldr	w15, [x11, x9, lsl #2]
    40203fc8:	3400028f 	cbz	w15, 40204018 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x98>
    40203fcc:	f94001af 	ldr	x15, [x13]
    40203fd0:	b400024f 	cbz	x15, 40204018 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x98>
    40203fd4:	f94001cf 	ldr	x15, [x14]
    40203fd8:	a9404430 	ldp	x16, x17, [x1]
    40203fdc:	a90047f0 	stp	x16, x17, [sp]
    40203fe0:	f9400831 	ldr	x17, [x1, #16]
    40203fe4:	a9013ff1 	stp	x17, x15, [sp, #16]
    40203fe8:	eb0f021f 	cmp	x16, x15
    40203fec:	a90227e9 	stp	x9, x9, [sp, #32]
    40203ff0:	54000061 	b.ne	40203ffc <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x7c>  // b.any
    40203ff4:	f94007ef 	ldr	x15, [sp, #8]
    40203ff8:	eb0901ff 	cmp	x15, x9
    40203ffc:	aa0c03ef 	mov	x15, x12
    40204000:	54000048 	b.hi	40204008 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x88>  // b.pmore
    40204004:	910003ef 	mov	x15, sp
    40204008:	a94045f0 	ldp	x16, x17, [x15]
    4020400c:	a9004430 	stp	x16, x17, [x1]
    40204010:	f94009ef 	ldr	x15, [x15, #16]
    40204014:	f900082f 	str	x15, [x1, #16]
    40204018:	91000529 	add	x9, x9, #0x1
    4020401c:	910041ad 	add	x13, x13, #0x10
    40204020:	910041ce 	add	x14, x14, #0x10
    40204024:	eb09015f 	cmp	x10, x9
    40204028:	54fffca1 	b.ne	40203fbc <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x3c>  // b.any
    4020402c:	a9402829 	ldp	x9, x10, [x1]
    40204030:	a9002909 	stp	x9, x10, [x8]
    40204034:	f9400829 	ldr	x9, [x1, #16]
    40204038:	f9000909 	str	x9, [x8, #16]
    4020403c:	f9401bfe 	ldr	x30, [sp, #48]
    40204040:	910103ff 	add	sp, sp, #0x40
    40204044:	d65f03c0 	ret
    40204048:	d503201f 	nop
    4020404c:	1000fea2 	adr	x2, 40206020 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.3164296782144938743>
    40204050:	52800041 	mov	w1, #0x2                   	// #2
    40204054:	9400031b 	bl	40204cc0 <core::panicking::panic_bounds_check>

0000000040204058 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>:
    40204058:	d10083ff 	sub	sp, sp, #0x20
    4020405c:	d503201f 	nop
    40204060:	10ffa649 	adr	x9, 40203528 <reservation_worker_a>
    40204064:	d503201f 	nop
    40204068:	10ffa66a 	adr	x10, 40203534 <reservation_worker_b>
    4020406c:	f90003e9 	str	x9, [sp]
    40204070:	a900fbea 	stp	x10, x30, [sp, #8]
    40204074:	f100043f 	cmp	x1, #0x1
    40204078:	54000928 	b.hi	4020419c <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x144>  // b.pmore
    4020407c:	d503201f 	nop
    40204080:	1009b509 	adr	x9, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766>
    40204084:	8b013929 	add	x9, x9, x1, lsl #14
    40204088:	5287980a 	mov	w10, #0x3cc0                	// #15552
    4020408c:	8b0a0129 	add	x9, x9, x10
    40204090:	f940000a 	ldr	x10, [x0]
    40204094:	8b010d4b 	add	x11, x10, x1, lsl #3
    40204098:	f940b56d 	ldr	x13, [x11, #360]
    4020409c:	eb0d013f 	cmp	x9, x13
    402040a0:	540007c1 	b.ne	40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    402040a4:	910003ea 	mov	x10, sp
    402040a8:	f861794a 	ldr	x10, [x10, x1, lsl #3]
    402040ac:	f9407dac 	ldr	x12, [x13, #248]
    402040b0:	eb0a019f 	cmp	x12, x10
    402040b4:	54000721 	b.ne	40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    402040b8:	f94081ac 	ldr	x12, [x13, #256]
    402040bc:	f10d159f 	cmp	x12, #0x345
    402040c0:	540006c1 	b.ne	40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    402040c4:	f9404dac 	ldr	x12, [x13, #152]
    402040c8:	b500068c 	cbnz	x12, 40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    402040cc:	d503201f 	nop
    402040d0:	1000eacc 	adr	x12, 40205e28 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.2706286857142130766>
    402040d4:	f861798c 	ldr	x12, [x12, x1, lsl #3]
    402040d8:	f9408dad 	ldr	x13, [x13, #280]
    402040dc:	eb0c01bf 	cmp	x13, x12
    402040e0:	540005c1 	b.ne	40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    402040e4:	d503201f 	nop
    402040e8:	1001b00d 	adr	x13, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    402040ec:	8b010dad 	add	x13, x13, x1, lsl #3
    402040f0:	c8dffdad 	ldar	x13, [x13]
    402040f4:	b10005bf 	cmn	x13, #0x1
    402040f8:	54000501 	b.ne	40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    402040fc:	d503201f 	nop
    40204100:	100fe78d 	adr	x13, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40204104:	8b010dad 	add	x13, x13, x1, lsl #3
    40204108:	c8dffdad 	ldar	x13, [x13]
    4020410c:	b500046d 	cbnz	x13, 40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    40204110:	d503201f 	nop
    40204114:	1001af2d 	adr	x13, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40204118:	8b010dad 	add	x13, x13, x1, lsl #3
    4020411c:	c8dffdad 	ldar	x13, [x13]
    40204120:	b10005bf 	cmn	x13, #0x1
    40204124:	540003a1 	b.ne	40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    40204128:	d503201f 	nop
    4020412c:	100fe6ad 	adr	x13, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40204130:	8b010dad 	add	x13, x13, x1, lsl #3
    40204134:	c8dffdad 	ldar	x13, [x13]
    40204138:	b500030d 	cbnz	x13, 40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    4020413c:	d503201f 	nop
    40204140:	100fe68d 	adr	x13, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    40204144:	8b010dad 	add	x13, x13, x1, lsl #3
    40204148:	c8dffdad 	ldar	x13, [x13]
    4020414c:	b500026d 	cbnz	x13, 40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    40204150:	f940e16d 	ldr	x13, [x11, #448]
    40204154:	b500022d 	cbnz	x13, 40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    40204158:	f940e96d 	ldr	x13, [x11, #464]
    4020415c:	eb0c01bf 	cmp	x13, x12
    40204160:	540001c1 	b.ne	40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    40204164:	f940c96d 	ldr	x13, [x11, #400]
    40204168:	b10005bf 	cmn	x13, #0x1
    4020416c:	54000161 	b.ne	40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    40204170:	f940d16b 	ldr	x11, [x11, #416]
    40204174:	b500012b 	cbnz	x11, 40204198 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    40204178:	a9002909 	stp	x9, x10, [x8]
    4020417c:	528068a9 	mov	w9, #0x345                 	// #837
    40204180:	a9017d09 	stp	x9, xzr, [x8, #16]
    40204184:	a9027d0c 	stp	x12, xzr, [x8, #32]
    40204188:	f900190c 	str	x12, [x8, #48]
    4020418c:	f9400bfe 	ldr	x30, [sp, #16]
    40204190:	910083ff 	add	sp, sp, #0x20
    40204194:	d65f03c0 	ret
    40204198:	97fff444 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    4020419c:	d503201f 	nop
    402041a0:	1000f4c2 	adr	x2, 40206038 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.3164296782144938743+0x18>
    402041a4:	aa0103e0 	mov	x0, x1
    402041a8:	52800041 	mov	w1, #0x2                   	// #2
    402041ac:	940002c5 	bl	40204cc0 <core::panicking::panic_bounds_check>

00000000402041b0 <jnox_kernel::uart_write>:
    402041b0:	b40001a1 	cbz	x1, 402041e4 <jnox_kernel::uart_write+0x34>
    402041b4:	8b010008 	add	x8, x0, x1
    402041b8:	52800309 	mov	w9, #0x18                  	// #24
    402041bc:	72a12009 	movk	w9, #0x900, lsl #16
    402041c0:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    402041c4:	3840140b 	ldrb	w11, [x0], #1
    402041c8:	b940012c 	ldr	w12, [x9]
    402041cc:	3628006c 	tbz	w12, #5, 402041d8 <jnox_kernel::uart_write+0x28>
    402041d0:	d5033fdf 	isb
    402041d4:	17fffffd 	b	402041c8 <jnox_kernel::uart_write+0x18>
    402041d8:	b900014b 	str	w11, [x10]
    402041dc:	eb08001f 	cmp	x0, x8
    402041e0:	54ffff21 	b.ne	402041c4 <jnox_kernel::uart_write+0x14>  // b.any
    402041e4:	d65f03c0 	ret

00000000402041e8 <jnox_kernel::kernel_main>:
    402041e8:	f00000e8 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.2706286857142130766+0xb8e0>
    402041ec:	f9471108 	ldr	x8, [x8, #3616]
    402041f0:	b4000068 	cbz	x8, 402041fc <jnox_kernel::kernel_main+0x14>
    402041f4:	d503205f 	wfe
    402041f8:	17ffffff 	b	402041f4 <jnox_kernel::kernel_main+0xc>
    402041fc:	f81f0ffe 	str	x30, [sp, #-16]!
    40204200:	52800608 	mov	w8, #0x30                  	// #48
    40204204:	72a12008 	movk	w8, #0x900, lsl #16
    40204208:	b900011f 	str	wzr, [x8]
    4020420c:	528001a9 	mov	w9, #0xd                   	// #13
    40204210:	5280002a 	mov	w10, #0x1                   	// #1
    40204214:	b81f4109 	stur	w9, [x8, #-12]
    40204218:	b81f810a 	stur	w10, [x8, #-8]
    4020421c:	52800c09 	mov	w9, #0x60                  	// #96
    40204220:	b81fc109 	stur	w9, [x8, #-4]
    40204224:	52802029 	mov	w9, #0x101                 	// #257
    40204228:	b9000109 	str	w9, [x8]
    4020422c:	d503201f 	nop
    40204230:	1000eb80 	adr	x0, 40205fa0 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x48>
    40204234:	52800361 	mov	w1, #0x1b                  	// #27
    40204238:	97ffffde 	bl	402041b0 <jnox_kernel::uart_write>
    4020423c:	97fff6f9 	bl	40201e20 <jnox_kernel::ordinary_reservations::run>

0000000040204240 <jnox_kernel::service_policy::PeriodicReservation::allocation_at>:
    40204240:	f9400809 	ldr	x9, [x0, #16]
    40204244:	eb09002a 	subs	x10, x1, x9
    40204248:	54000062 	b.cs	40204254 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x14>  // b.hs, b.nlast
    4020424c:	aa1f03ea 	mov	x10, xzr
    40204250:	1400000f 	b	4020428c <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x4c>
    40204254:	f940040b 	ldr	x11, [x0, #8]
    40204258:	b400022b 	cbz	x11, 4020429c <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x5c>
    4020425c:	9acb0949 	udiv	x9, x10, x11
    40204260:	cb0a03ec 	neg	x12, x10
    40204264:	9b0b3129 	madd	x9, x9, x11, x12
    40204268:	8b090029 	add	x9, x1, x9
    4020426c:	ab0b0129 	adds	x9, x9, x11
    40204270:	54000063 	b.cc	4020427c <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x3c>  // b.lo, b.ul, b.last
    40204274:	aa1f03eb 	mov	x11, xzr
    40204278:	14000007 	b	40204294 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x54>
    4020427c:	eb0b015f 	cmp	x10, x11
    40204280:	5280030a 	mov	w10, #0x18                  	// #24
    40204284:	9a9f314a 	csel	x10, x10, xzr, cc  // cc = lo, ul, last
    40204288:	f86a680a 	ldr	x10, [x0, x10]
    4020428c:	5280002b 	mov	w11, #0x1                   	// #1
    40204290:	a900a50a 	stp	x10, x9, [x8, #8]
    40204294:	f900010b 	str	x11, [x8]
    40204298:	d65f03c0 	ret
    4020429c:	f81f0ffe 	str	x30, [sp, #-16]!
    402042a0:	d503201f 	nop
    402042a4:	1000e8e0 	adr	x0, 40205fc0 <anon.2d5d436b87d2a0d6f444a14986a49844.2.llvm.3164296782144938743>
    402042a8:	9400048c 	bl	402054d8 <core::panicking::panic_const::panic_const_rem_by_zero>

00000000402042ac <jnox_kernel::service_policy::PeriodicReservation::grant_at>:
    402042ac:	f9401008 	ldr	x8, [x0, #32]
    402042b0:	eb08003f 	cmp	x1, x8
    402042b4:	54000062 	b.cs	402042c0 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x14>  // b.hs, b.nlast
    402042b8:	aa1f03e0 	mov	x0, xzr
    402042bc:	1400001c 	b	4020432c <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x80>
    402042c0:	f9400408 	ldr	x8, [x0, #8]
    402042c4:	b4000388 	cbz	x8, 40204334 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x88>
    402042c8:	f9400809 	ldr	x9, [x0, #16]
    402042cc:	cb09002a 	sub	x10, x1, x9
    402042d0:	9ac80949 	udiv	x9, x10, x8
    402042d4:	9b08a929 	msub	x9, x9, x8, x10
    402042d8:	eb08015f 	cmp	x10, x8
    402042dc:	54000062 	b.cs	402042e8 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x3c>  // b.hs, b.nlast
    402042e0:	9100600a 	add	x10, x0, #0x18
    402042e4:	14000004 	b	402042f4 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x48>
    402042e8:	cb09002a 	sub	x10, x1, x9
    402042ec:	f900080a 	str	x10, [x0, #16]
    402042f0:	aa0003ea 	mov	x10, x0
    402042f4:	f940014a 	ldr	x10, [x10]
    402042f8:	eb02015f 	cmp	x10, x2
    402042fc:	9a82314b 	csel	x11, x10, x2, cc  // cc = lo, ul, last
    40204300:	cb090108 	sub	x8, x8, x9
    40204304:	eb0b011f 	cmp	x8, x11
    40204308:	9a8b3109 	csel	x9, x8, x11, cc  // cc = lo, ul, last
    4020430c:	aa2103e8 	mvn	x8, x1
    40204310:	eb09011f 	cmp	x8, x9
    40204314:	da812128 	csinv	x8, x9, x1, cs  // cs = hs, nlast
    40204318:	cb08014a 	sub	x10, x10, x8
    4020431c:	ab010129 	adds	x9, x9, x1
    40204320:	da9f3129 	csinv	x9, x9, xzr, cc  // cc = lo, ul, last
    40204324:	a901a40a 	stp	x10, x9, [x0, #24]
    40204328:	52800020 	mov	w0, #0x1                   	// #1
    4020432c:	aa0803e1 	mov	x1, x8
    40204330:	d65f03c0 	ret
    40204334:	f81f0ffe 	str	x30, [sp, #-16]!
    40204338:	d503201f 	nop
    4020433c:	1000e4e0 	adr	x0, 40205fd8 <anon.2d5d436b87d2a0d6f444a14986a49844.3.llvm.3164296782144938743>
    40204340:	94000466 	bl	402054d8 <core::panicking::panic_const::panic_const_rem_by_zero>

0000000040204344 <jnox_kernel::temporal_policy::HardCbs<_>::new>:
    40204344:	d10143ff 	sub	sp, sp, #0x50
    40204348:	a90357fe 	stp	x30, x21, [sp, #48]
    4020434c:	a9044ff4 	stp	x20, x19, [sp, #64]
    40204350:	aa0103f5 	mov	x21, x1
    40204354:	aa0003f4 	mov	x20, x0
    40204358:	aa0803f3 	mov	x19, x8
    4020435c:	aa0103e0 	mov	x0, x1
    40204360:	52800041 	mov	w1, #0x2                   	// #2
    40204364:	940000c6 	bl	4020467c <jnox_kernel::temporal_policy::admit_reservations>
    40204368:	12001c08 	and	w8, w0, #0xff
    4020436c:	71000d1f 	cmp	w8, #0x3
    40204370:	54000261 	b.ne	402043bc <jnox_kernel::temporal_policy::HardCbs<_>::new+0x78>  // b.any
    40204374:	910003e9 	mov	x9, sp
    40204378:	91006128 	add	x8, x9, #0x18
    4020437c:	5280002a 	mov	w10, #0x1                   	// #1
    40204380:	f9000134 	str	x20, [x9]
    40204384:	28c132ab 	ldp	w11, w12, [x21], #8
    40204388:	2a0a03ed 	mov	w13, w10
    4020438c:	2901312b 	stp	w11, w12, [x9, #8]
    40204390:	f900093f 	str	xzr, [x9, #16]
    40204394:	aa0803e9 	mov	x9, x8
    40204398:	2a1f03ea 	mov	w10, wzr
    4020439c:	3707ff2d 	tbnz	w13, #0, 40204380 <jnox_kernel::temporal_policy::HardCbs<_>::new+0x3c>
    402043a0:	91002260 	add	x0, x19, #0x8
    402043a4:	910003e1 	mov	x1, sp
    402043a8:	52800602 	mov	w2, #0x30                  	// #48
    402043ac:	94000595 	bl	40205a00 <memcpy>
    402043b0:	f9001e74 	str	x20, [x19, #56]
    402043b4:	52800028 	mov	w8, #0x1                   	// #1
    402043b8:	14000002 	b	402043c0 <jnox_kernel::temporal_policy::HardCbs<_>::new+0x7c>
    402043bc:	aa1f03e8 	mov	x8, xzr
    402043c0:	f9000268 	str	x8, [x19]
    402043c4:	a9444ff4 	ldp	x20, x19, [sp, #64]
    402043c8:	a94357fe 	ldp	x30, x21, [sp, #48]
    402043cc:	910143ff 	add	sp, sp, #0x50
    402043d0:	d65f03c0 	ret

00000000402043d4 <jnox_kernel::temporal_policy::HardCbs<_>::tick>:
    402043d4:	d10203ff 	sub	sp, sp, #0x80
    402043d8:	a9027bfd 	stp	x29, x30, [sp, #32]
    402043dc:	a9036ffc 	stp	x28, x27, [sp, #48]
    402043e0:	a90467fa 	stp	x26, x25, [sp, #64]
    402043e4:	a9055ff8 	stp	x24, x23, [sp, #80]
    402043e8:	a90657f6 	stp	x22, x21, [sp, #96]
    402043ec:	a9074ff4 	stp	x20, x19, [sp, #112]
    402043f0:	aa0803f3 	mov	x19, x8
    402043f4:	f940181b 	ldr	x27, [x0, #48]
    402043f8:	b100077a 	adds	x26, x27, #0x1
    402043fc:	540000a3 	b.cc	40204410 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x3c>  // b.lo, b.ul, b.last
    40204400:	aa1f03f4 	mov	x20, xzr
    40204404:	52800037 	mov	w23, #0x1                   	// #1
    40204408:	52800089 	mov	w9, #0x4                   	// #4
    4020440c:	1400003e 	b	40204504 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    40204410:	aa0003f5 	mov	x21, x0
    40204414:	2a1f03fc 	mov	w28, wzr
    40204418:	aa1f03e8 	mov	x8, xzr
    4020441c:	aa1f03fd 	mov	x29, xzr
    40204420:	91005018 	add	x24, x0, #0x14
    40204424:	52800037 	mov	w23, #0x1                   	// #1
    40204428:	910063bd 	add	x29, x29, #0x18
    4020442c:	aa0803f6 	mov	x22, x8
    40204430:	8b1d0308 	add	x8, x24, x29
    40204434:	b85e8108 	ldur	w8, [x8, #-24]
    40204438:	340000e8 	cbz	w8, 40204454 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x80>
    4020443c:	910023e8 	add	x8, sp, #0x8
    40204440:	aa1503e0 	mov	x0, x21
    40204444:	aa1603e1 	mov	x1, x22
    40204448:	94000067 	bl	402045e4 <jnox_kernel::temporal_policy::HardCbs<_>::available>
    4020444c:	f94007e8 	ldr	x8, [sp, #8]
    40204450:	b50000c8 	cbnz	x8, 40204468 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x94>
    40204454:	910063bd 	add	x29, x29, #0x18
    40204458:	910006d6 	add	x22, x22, #0x1
    4020445c:	f10123bf 	cmp	x29, #0x48
    40204460:	54fffe81 	b.ne	40204430 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x5c>  // b.any
    40204464:	14000014 	b	402044b4 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0xe0>
    40204468:	f100091f 	cmp	x8, #0x2
    4020446c:	a9412be9 	ldp	x9, x10, [sp, #16]
    40204470:	54000400 	b.eq	402044f0 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x11c>  // b.none
    40204474:	eb1b015f 	cmp	x10, x27
    40204478:	540005a9 	b.ls	4020452c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x158>  // b.plast
    4020447c:	910006c8 	add	x8, x22, #0x1
    40204480:	eb19015f 	cmp	x10, x25
    40204484:	1a9f37eb 	cset	w11, cs  // cs = hs, nlast
    40204488:	6a0b039f 	tst	w28, w11
    4020448c:	9a961294 	csel	x20, x20, x22, ne  // ne = any
    40204490:	9a8a1339 	csel	x25, x25, x10, ne  // ne = any
    40204494:	b94007ea 	ldr	w10, [sp, #4]
    40204498:	1a89114a 	csel	w10, w10, w9, ne  // ne = any
    4020449c:	b90007ea 	str	w10, [sp, #4]
    402044a0:	5280003c 	mov	w28, #0x1                   	// #1
    402044a4:	f100c3bf 	cmp	x29, #0x30
    402044a8:	54fffc01 	b.ne	40204428 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x54>  // b.any
    402044ac:	f9001aba 	str	x26, [x21, #48]
    402044b0:	14000003 	b	402044bc <jnox_kernel::temporal_policy::HardCbs<_>::tick+0xe8>
    402044b4:	f9001aba 	str	x26, [x21, #48]
    402044b8:	3600023c 	tbz	w28, #0, 402044fc <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x128>
    402044bc:	f1000a9f 	cmp	x20, #0x2
    402044c0:	540003c2 	b.cs	40204538 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x164>  // b.hs, b.nlast
    402044c4:	aa1f03f7 	mov	x23, xzr
    402044c8:	52800308 	mov	w8, #0x18                  	// #24
    402044cc:	9b085688 	madd	x8, x20, x8, x21
    402044d0:	f9000119 	str	x25, [x8]
    402044d4:	b94007e9 	ldr	w9, [sp, #4]
    402044d8:	51000529 	sub	w9, w9, #0x1
    402044dc:	b940150a 	ldr	w10, [x8, #20]
    402044e0:	5100054a 	sub	w10, w10, #0x1
    402044e4:	29022909 	stp	w9, w10, [x8, #16]
    402044e8:	52800029 	mov	w9, #0x1                   	// #1
    402044ec:	14000006 	b	40204504 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    402044f0:	52800037 	mov	w23, #0x1                   	// #1
    402044f4:	aa0a03f4 	mov	x20, x10
    402044f8:	14000003 	b	40204504 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    402044fc:	aa1f03e9 	mov	x9, xzr
    40204500:	aa1f03f7 	mov	x23, xzr
    40204504:	a900d269 	stp	x9, x20, [x19, #8]
    40204508:	f9000277 	str	x23, [x19]
    4020450c:	a9474ff4 	ldp	x20, x19, [sp, #112]
    40204510:	a94657f6 	ldp	x22, x21, [sp, #96]
    40204514:	a9455ff8 	ldp	x24, x23, [sp, #80]
    40204518:	a94467fa 	ldp	x26, x25, [sp, #64]
    4020451c:	a9436ffc 	ldp	x28, x27, [sp, #48]
    40204520:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40204524:	910203ff 	add	sp, sp, #0x80
    40204528:	d65f03c0 	ret
    4020452c:	52800069 	mov	w9, #0x3                   	// #3
    40204530:	aa1603f4 	mov	x20, x22
    40204534:	17fffff4 	b	40204504 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    40204538:	d503201f 	nop
    4020453c:	1000d5a2 	adr	x2, 40205ff0 <anon.2d5d436b87d2a0d6f444a14986a49844.5.llvm.3164296782144938743>
    40204540:	aa1403e0 	mov	x0, x20
    40204544:	52800041 	mov	w1, #0x2                   	// #2
    40204548:	940001de 	bl	40204cc0 <core::panicking::panic_bounds_check>

000000004020454c <jnox_kernel::temporal_policy::HardCbs<_>::release>:
    4020454c:	f100043f 	cmp	x1, #0x1
    40204550:	54000089 	b.ls	40204560 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x14>  // b.plast
    40204554:	aa1f03e1 	mov	x1, xzr
    40204558:	aa1f03e0 	mov	x0, xzr
    4020455c:	d65f03c0 	ret
    40204560:	340000e2 	cbz	w2, 4020457c <jnox_kernel::temporal_policy::HardCbs<_>::release+0x30>
    40204564:	52800308 	mov	w8, #0x18                  	// #24
    40204568:	9b080028 	madd	x8, x1, x8, x0
    4020456c:	b9401509 	ldr	w9, [x8, #20]
    40204570:	340000a9 	cbz	w9, 40204584 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x38>
    40204574:	52800040 	mov	w0, #0x2                   	// #2
    40204578:	d65f03c0 	ret
    4020457c:	52800020 	mov	w0, #0x1                   	// #1
    40204580:	d65f03c0 	ret
    40204584:	f940010a 	ldr	x10, [x8]
    40204588:	f9401809 	ldr	x9, [x0, #48]
    4020458c:	eb09014b 	subs	x11, x10, x9
    40204590:	54000149 	b.ls	402045b8 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x6c>  // b.plast
    40204594:	2941b10a 	ldp	w10, w12, [x8, #12]
    40204598:	b940090d 	ldr	w13, [x8, #8]
    4020459c:	9bac7d4c 	umull	x12, w10, w12
    402045a0:	9bcb7dae 	umulh	x14, x13, x11
    402045a4:	9b0b7dab 	mul	x11, x13, x11
    402045a8:	eb0c017f 	cmp	x11, x12
    402045ac:	fa1f01df 	sbcs	xzr, x14, xzr
    402045b0:	54000063 	b.cc	402045bc <jnox_kernel::temporal_policy::HardCbs<_>::release+0x70>  // b.lo, b.ul, b.last
    402045b4:	14000009 	b	402045d8 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x8c>
    402045b8:	b9400d0a 	ldr	w10, [x8, #12]
    402045bc:	ab2a4121 	adds	x1, x9, w10, uxtw
    402045c0:	54000063 	b.cc	402045cc <jnox_kernel::temporal_policy::HardCbs<_>::release+0x80>  // b.lo, b.ul, b.last
    402045c4:	52800080 	mov	w0, #0x4                   	// #4
    402045c8:	d65f03c0 	ret
    402045cc:	f9000101 	str	x1, [x8]
    402045d0:	b9400909 	ldr	w9, [x8, #8]
    402045d4:	b9001109 	str	w9, [x8, #16]
    402045d8:	b9001502 	str	w2, [x8, #20]
    402045dc:	528000a0 	mov	w0, #0x5                   	// #5
    402045e0:	d65f03c0 	ret

00000000402045e4 <jnox_kernel::temporal_policy::HardCbs<_>::available>:
    402045e4:	f100083f 	cmp	x1, #0x2
    402045e8:	540000a3 	b.cc	402045fc <jnox_kernel::temporal_policy::HardCbs<_>::available+0x18>  // b.lo, b.ul, b.last
    402045ec:	a900fd1f 	stp	xzr, xzr, [x8, #8]
    402045f0:	52800049 	mov	w9, #0x2                   	// #2
    402045f4:	f9000109 	str	x9, [x8]
    402045f8:	d65f03c0 	ret
    402045fc:	52800309 	mov	w9, #0x18                  	// #24
    40204600:	9b090029 	madd	x9, x1, x9, x0
    40204604:	b940152a 	ldr	w10, [x9, #20]
    40204608:	340001aa 	cbz	w10, 4020463c <jnox_kernel::temporal_policy::HardCbs<_>::available+0x58>
    4020460c:	b940112a 	ldr	w10, [x9, #16]
    40204610:	340000ea 	cbz	w10, 4020462c <jnox_kernel::temporal_policy::HardCbs<_>::available+0x48>
    40204614:	5280002b 	mov	w11, #0x1                   	// #1
    40204618:	f900010b 	str	x11, [x8]
    4020461c:	f9400129 	ldr	x9, [x9]
    40204620:	b900090a 	str	w10, [x8, #8]
    40204624:	f9000909 	str	x9, [x8, #16]
    40204628:	d65f03c0 	ret
    4020462c:	f940180b 	ldr	x11, [x0, #48]
    40204630:	f940012a 	ldr	x10, [x9]
    40204634:	eb0a017f 	cmp	x11, x10
    40204638:	54000062 	b.cs	40204644 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x60>  // b.hs, b.nlast
    4020463c:	f900011f 	str	xzr, [x8]
    40204640:	d65f03c0 	ret
    40204644:	b9400d2b 	ldr	w11, [x9, #12]
    40204648:	ab0b014a 	adds	x10, x10, x11
    4020464c:	540000c3 	b.cc	40204664 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x80>  // b.lo, b.ul, b.last
    40204650:	52800089 	mov	w9, #0x4                   	// #4
    40204654:	a900a909 	stp	x9, x10, [x8, #8]
    40204658:	5280004a 	mov	w10, #0x2                   	// #2
    4020465c:	f900010a 	str	x10, [x8]
    40204660:	d65f03c0 	ret
    40204664:	5280002b 	mov	w11, #0x1                   	// #1
    40204668:	f900010b 	str	x11, [x8]
    4020466c:	b9400929 	ldr	w9, [x9, #8]
    40204670:	b9000909 	str	w9, [x8, #8]
    40204674:	f900090a 	str	x10, [x8, #16]
    40204678:	d65f03c0 	ret

000000004020467c <jnox_kernel::temporal_policy::admit_reservations>:
    4020467c:	f81b0ffe 	str	x30, [sp, #-80]!
    40204680:	a90167fa 	stp	x26, x25, [sp, #16]
    40204684:	a9025ff8 	stp	x24, x23, [sp, #32]
    40204688:	a90357f6 	stp	x22, x21, [sp, #48]
    4020468c:	a9044ff4 	stp	x20, x19, [sp, #64]
    40204690:	b4000721 	cbz	x1, 40204774 <jnox_kernel::temporal_policy::admit_reservations+0xf8>
    40204694:	aa0003f3 	mov	x19, x0
    40204698:	aa1f03f6 	mov	x22, xzr
    4020469c:	8b010c1a 	add	x26, x0, x1, lsl #3
    402046a0:	52800020 	mov	w0, #0x1                   	// #1
    402046a4:	29402269 	ldp	w9, w8, [x19]
    402046a8:	5100052a 	sub	w10, w9, #0x1
    402046ac:	6b08015f 	cmp	w10, w8
    402046b0:	540006a2 	b.cs	40204784 <jnox_kernel::temporal_policy::admit_reservations+0x108>  // b.hs, b.nlast
    402046b4:	9bd67d0a 	umulh	x10, x8, x22
    402046b8:	9b167d0b 	mul	x11, x8, x22
    402046bc:	9bc07d2c 	umulh	x12, x9, x0
    402046c0:	9b007d29 	mul	x9, x9, x0
    402046c4:	ab090176 	adds	x22, x11, x9
    402046c8:	9a0c0157 	adc	x23, x10, x12
    402046cc:	9bc07d14 	umulh	x20, x8, x0
    402046d0:	9b007d15 	mul	x21, x8, x0
    402046d4:	eb1602bf 	cmp	x21, x22
    402046d8:	fa17029f 	sbcs	xzr, x20, x23
    402046dc:	54000583 	b.cc	4020478c <jnox_kernel::temporal_policy::admit_reservations+0x110>  // b.lo, b.ul, b.last
    402046e0:	b4000220 	cbz	x0, 40204724 <jnox_kernel::temporal_policy::admit_reservations+0xa8>
    402046e4:	aa1603e0 	mov	x0, x22
    402046e8:	aa1703e1 	mov	x1, x23
    402046ec:	aa1503e8 	mov	x8, x21
    402046f0:	aa1403e9 	mov	x9, x20
    402046f4:	aa0903f8 	mov	x24, x9
    402046f8:	aa0803f9 	mov	x25, x8
    402046fc:	aa0803e2 	mov	x2, x8
    40204700:	aa0903e3 	mov	x3, x9
    40204704:	94000542 	bl	40205c0c <__umodti3>
    40204708:	aa0003e8 	mov	x8, x0
    4020470c:	aa0103e9 	mov	x9, x1
    40204710:	aa01000a 	orr	x10, x0, x1
    40204714:	aa1903e0 	mov	x0, x25
    40204718:	aa1803e1 	mov	x1, x24
    4020471c:	b5fffeca 	cbnz	x10, 402046f4 <jnox_kernel::temporal_policy::admit_reservations+0x78>
    40204720:	14000005 	b	40204734 <jnox_kernel::temporal_policy::admit_reservations+0xb8>
    40204724:	aa1702c8 	orr	x8, x22, x23
    40204728:	aa1603f9 	mov	x25, x22
    4020472c:	aa1703f8 	mov	x24, x23
    40204730:	b40003c8 	cbz	x8, 402047a8 <jnox_kernel::temporal_policy::admit_reservations+0x12c>
    40204734:	aa1603e0 	mov	x0, x22
    40204738:	aa1703e1 	mov	x1, x23
    4020473c:	aa1903e2 	mov	x2, x25
    40204740:	aa1803e3 	mov	x3, x24
    40204744:	940003e3 	bl	402056d0 <__udivti3>
    40204748:	b50001a1 	cbnz	x1, 4020477c <jnox_kernel::temporal_policy::admit_reservations+0x100>
    4020474c:	aa0003f6 	mov	x22, x0
    40204750:	aa1503e0 	mov	x0, x21
    40204754:	aa1403e1 	mov	x1, x20
    40204758:	aa1903e2 	mov	x2, x25
    4020475c:	aa1803e3 	mov	x3, x24
    40204760:	940003dc 	bl	402056d0 <__udivti3>
    40204764:	b50000c1 	cbnz	x1, 4020477c <jnox_kernel::temporal_policy::admit_reservations+0x100>
    40204768:	91002273 	add	x19, x19, #0x8
    4020476c:	eb1a027f 	cmp	x19, x26
    40204770:	54fff9a1 	b.ne	402046a4 <jnox_kernel::temporal_policy::admit_reservations+0x28>  // b.any
    40204774:	52800060 	mov	w0, #0x3                   	// #3
    40204778:	14000006 	b	40204790 <jnox_kernel::temporal_policy::admit_reservations+0x114>
    4020477c:	52800040 	mov	w0, #0x2                   	// #2
    40204780:	14000004 	b	40204790 <jnox_kernel::temporal_policy::admit_reservations+0x114>
    40204784:	2a1f03e0 	mov	w0, wzr
    40204788:	14000002 	b	40204790 <jnox_kernel::temporal_policy::admit_reservations+0x114>
    4020478c:	52800020 	mov	w0, #0x1                   	// #1
    40204790:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40204794:	a94357f6 	ldp	x22, x21, [sp, #48]
    40204798:	a9425ff8 	ldp	x24, x23, [sp, #32]
    4020479c:	a94167fa 	ldp	x26, x25, [sp, #16]
    402047a0:	f84507fe 	ldr	x30, [sp], #80
    402047a4:	d65f03c0 	ret
    402047a8:	d503201f 	nop
    402047ac:	1000c2e0 	adr	x0, 40206008 <anon.2d5d436b87d2a0d6f444a14986a49844.6.llvm.3164296782144938743>
    402047b0:	94000343 	bl	402054bc <core::panicking::panic_const::panic_const_div_by_zero>

00000000402047b4 <jnox_kernel::context::init_timer_irq>:
    402047b4:	d503201f 	nop
    402047b8:	10fe0248 	adr	x8, 40200800 <sched_vectors>
    402047bc:	d518c008 	msr	vbar_el1, x8
    402047c0:	d51be23f 	msr	cntp_ctl_el0, xzr
    402047c4:	d5033fdf 	isb
    402047c8:	52a10008 	mov	w8, #0x8000000             	// #134217728
    402047cc:	b900011f 	str	wzr, [x8]
    402047d0:	52a10029 	mov	w9, #0x8010000             	// #134283264
    402047d4:	b900013f 	str	wzr, [x9]
    402047d8:	5280100a 	mov	w10, #0x80                  	// #128
    402047dc:	72a1000a 	movk	w10, #0x800, lsl #16
    402047e0:	b940014b 	ldr	w11, [x10]
    402047e4:	1201796b 	and	w11, w11, #0xbfffffff
    402047e8:	b900014b 	str	w11, [x10]
    402047ec:	5280100b 	mov	w11, #0x80                  	// #128
    402047f0:	390e794b 	strb	w11, [x10, #926]
    402047f4:	52a8000b 	mov	w11, #0x40000000            	// #1073741824
    402047f8:	b902014b 	str	w11, [x10, #512]
    402047fc:	b900814b 	str	w11, [x10, #128]
    40204800:	5280008a 	mov	w10, #0x4                   	// #4
    40204804:	72a1002a 	movk	w10, #0x801, lsl #16
    40204808:	52801feb 	mov	w11, #0xff                  	// #255
    4020480c:	b900014b 	str	w11, [x10]
    40204810:	5280002a 	mov	w10, #0x1                   	// #1
    40204814:	b900010a 	str	w10, [x8]
    40204818:	b900012a 	str	w10, [x9]
    4020481c:	d5033f9f 	dsb	sy
    40204820:	d5033fdf 	isb
    40204824:	d65f03c0 	ret

0000000040204828 <<core::fmt::Formatter>::pad_integral>:
    40204828:	d101c3ff 	sub	sp, sp, #0x70
    4020482c:	a9017bfd 	stp	x29, x30, [sp, #16]
    40204830:	a9026ffc 	stp	x28, x27, [sp, #32]
    40204834:	a90367fa 	stp	x26, x25, [sp, #48]
    40204838:	a9045ff8 	stp	x24, x23, [sp, #64]
    4020483c:	a90557f6 	stp	x22, x21, [sp, #80]
    40204840:	a9064ff4 	stp	x20, x19, [sp, #96]
    40204844:	910043fd 	add	x29, sp, #0x10
    40204848:	b940101a 	ldr	w26, [x0, #16]
    4020484c:	52a00229 	mov	w9, #0x110000              	// #1114112
    40204850:	aa0503f3 	mov	x19, x5
    40204854:	aa0403fc 	mov	x28, x4
    40204858:	aa0303f6 	mov	x22, x3
    4020485c:	aa0003f5 	mov	x21, x0
    40204860:	926b0348 	and	x8, x26, #0x200000
    40204864:	d355574a 	ubfx	x10, x26, #21, #1
    40204868:	7100011f 	cmp	w8, #0x0
    4020486c:	52800568 	mov	w8, #0x2b                  	// #43
    40204870:	1a880128 	csel	w8, w9, w8, eq  // eq = none
    40204874:	7100003f 	cmp	w1, #0x0
    40204878:	528005a9 	mov	w9, #0x2d                  	// #45
    4020487c:	9a9f154a 	csinc	x10, x10, xzr, ne  // ne = any
    40204880:	1a891118 	csel	w24, w8, w9, ne  // ne = any
    40204884:	8b05015b 	add	x27, x10, x5
    40204888:	37b8033a 	tbnz	w26, #23, 402048ec <<core::fmt::Formatter>::pad_integral+0xc4>
    4020488c:	aa1f03f7 	mov	x23, xzr
    40204890:	79402ab4 	ldrh	w20, [x21, #20]
    40204894:	eb14037f 	cmp	x27, x20
    40204898:	54001503 	b.cc	40204b38 <<core::fmt::Formatter>::pad_integral+0x310>  // b.lo, b.ul, b.last
    4020489c:	a94056b9 	ldp	x25, x21, [x21]
    402048a0:	2a1803e2 	mov	w2, w24
    402048a4:	aa1703e3 	mov	x3, x23
    402048a8:	aa1603e4 	mov	x4, x22
    402048ac:	aa1903e0 	mov	x0, x25
    402048b0:	aa1503e1 	mov	x1, x21
    402048b4:	94000310 	bl	402054f4 <<core::fmt::Formatter>::pad_integral::write_prefix>
    402048b8:	37001d60 	tbnz	w0, #0, 40204c64 <<core::fmt::Formatter>::pad_integral+0x43c>
    402048bc:	f9400ea3 	ldr	x3, [x21, #24]
    402048c0:	aa1903e0 	mov	x0, x25
    402048c4:	aa1c03e1 	mov	x1, x28
    402048c8:	aa1303e2 	mov	x2, x19
    402048cc:	a9464ff4 	ldp	x20, x19, [sp, #96]
    402048d0:	a94557f6 	ldp	x22, x21, [sp, #80]
    402048d4:	a9445ff8 	ldp	x24, x23, [sp, #64]
    402048d8:	a94367fa 	ldp	x26, x25, [sp, #48]
    402048dc:	a9426ffc 	ldp	x28, x27, [sp, #32]
    402048e0:	a9417bfd 	ldp	x29, x30, [sp, #16]
    402048e4:	9101c3ff 	add	sp, sp, #0x70
    402048e8:	d61f0060 	br	x3
    402048ec:	aa0203f7 	mov	x23, x2
    402048f0:	f10082df 	cmp	x22, #0x20
    402048f4:	540000e2 	b.cs	40204910 <<core::fmt::Formatter>::pad_integral+0xe8>  // b.hs, b.nlast
    402048f8:	b4000156 	cbz	x22, 40204920 <<core::fmt::Formatter>::pad_integral+0xf8>
    402048fc:	f10022df 	cmp	x22, #0x8
    40204900:	54000142 	b.cs	40204928 <<core::fmt::Formatter>::pad_integral+0x100>  // b.hs, b.nlast
    40204904:	aa1f03e8 	mov	x8, xzr
    40204908:	aa1f03e0 	mov	x0, xzr
    4020490c:	14000080 	b	40204b0c <<core::fmt::Formatter>::pad_integral+0x2e4>
    40204910:	aa1703e0 	mov	x0, x23
    40204914:	aa1603e1 	mov	x1, x22
    40204918:	94000102 	bl	40204d20 <core::str::count::do_count_chars>
    4020491c:	14000083 	b	40204b28 <<core::fmt::Formatter>::pad_integral+0x300>
    40204920:	aa1f03e0 	mov	x0, xzr
    40204924:	14000081 	b	40204b28 <<core::fmt::Formatter>::pad_integral+0x300>
    40204928:	aa1703ea 	mov	x10, x23
    4020492c:	39400ae9 	ldrb	w9, [x23, #2]
    40204930:	394006e8 	ldrb	w8, [x23, #1]
    40204934:	38404d4b 	ldrb	w11, [x10, #4]!
    40204938:	3940094c 	ldrb	w12, [x10, #2]
    4020493c:	394002ed 	ldrb	w13, [x23]
    40204940:	39400eee 	ldrb	w14, [x23, #3]
    40204944:	d370bd29 	lsl	x9, x9, #16
    40204948:	394016ef 	ldrb	w15, [x23, #5]
    4020494c:	39400d4a 	ldrb	w10, [x10, #3]
    40204950:	53103d8c 	lsl	w12, w12, #16
    40204954:	aa0821a8 	orr	x8, x13, x8, lsl #8
    40204958:	aa0e6129 	orr	x9, x9, x14, lsl #24
    4020495c:	0f05e7e4 	movi	v4.8b, #0xbf
    40204960:	2a0f216b 	orr	w11, w11, w15, lsl #8
    40204964:	2a0a618a 	orr	w10, w12, w10, lsl #24
    40204968:	aa080128 	orr	x8, x9, x8
    4020496c:	2a0b0149 	orr	w9, w10, w11
    40204970:	aa098108 	orr	x8, x8, x9, lsl #32
    40204974:	9e670100 	fmov	d0, x8
    40204978:	52800028 	mov	w8, #0x1                   	// #1
    4020497c:	4e080d03 	dup	v3.2d, x8
    40204980:	927d06c8 	and	x8, x22, #0x18
    40204984:	f100211f 	cmp	x8, #0x8
    40204988:	0e243400 	cmgt	v0.8b, v0.8b, v4.8b
    4020498c:	2f08a400 	uxtl	v0.8h, v0.8b
    40204990:	6f10a401 	uxtl2	v1.4s, v0.8h
    40204994:	2f10a400 	uxtl	v0.4s, v0.4h
    40204998:	6f20a422 	uxtl2	v2.2d, v1.4s
    4020499c:	2f20a421 	uxtl	v1.2d, v1.2s
    402049a0:	6f20a405 	uxtl2	v5.2d, v0.4s
    402049a4:	2f20a406 	uxtl	v6.2d, v0.2s
    402049a8:	4e231c40 	and	v0.16b, v2.16b, v3.16b
    402049ac:	4e231c22 	and	v2.16b, v1.16b, v3.16b
    402049b0:	4e231ca1 	and	v1.16b, v5.16b, v3.16b
    402049b4:	4e231cc3 	and	v3.16b, v6.16b, v3.16b
    402049b8:	540009c0 	b.eq	40204af0 <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    402049bc:	aa1703e9 	mov	x9, x23
    402049c0:	f100411f 	cmp	x8, #0x10
    402049c4:	38408d2a 	ldrb	w10, [x9, #8]!
    402049c8:	3940052b 	ldrb	w11, [x9, #1]
    402049cc:	39400d2c 	ldrb	w12, [x9, #3]
    402049d0:	3940092d 	ldrb	w13, [x9, #2]
    402049d4:	3940152e 	ldrb	w14, [x9, #5]
    402049d8:	38404d2f 	ldrb	w15, [x9, #4]!
    402049dc:	39400930 	ldrb	w16, [x9, #2]
    402049e0:	39400d29 	ldrb	w9, [x9, #3]
    402049e4:	d370bdad 	lsl	x13, x13, #16
    402049e8:	aa0b214a 	orr	x10, x10, x11, lsl #8
    402049ec:	53103e10 	lsl	w16, w16, #16
    402049f0:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    402049f4:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    402049f8:	2a096209 	orr	w9, w16, w9, lsl #24
    402049fc:	aa0a018a 	orr	x10, x12, x10
    40204a00:	2a0b0129 	orr	w9, w9, w11
    40204a04:	aa098149 	orr	x9, x10, x9, lsl #32
    40204a08:	9e670125 	fmov	d5, x9
    40204a0c:	52800029 	mov	w9, #0x1                   	// #1
    40204a10:	4e080d26 	dup	v6.2d, x9
    40204a14:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40204a18:	2f08a484 	uxtl	v4.8h, v4.8b
    40204a1c:	6f10a485 	uxtl2	v5.4s, v4.8h
    40204a20:	2f10a484 	uxtl	v4.4s, v4.4h
    40204a24:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40204a28:	2f20a490 	uxtl	v16.2d, v4.2s
    40204a2c:	6f20a484 	uxtl2	v4.2d, v4.4s
    40204a30:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40204a34:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40204a38:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40204a3c:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40204a40:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40204a44:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40204a48:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40204a4c:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40204a50:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40204a54:	540004e0 	b.eq	40204af0 <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    40204a58:	aa1703e9 	mov	x9, x23
    40204a5c:	0f05e7e4 	movi	v4.8b, #0xbf
    40204a60:	38410d2a 	ldrb	w10, [x9, #16]!
    40204a64:	3940052b 	ldrb	w11, [x9, #1]
    40204a68:	39400d2c 	ldrb	w12, [x9, #3]
    40204a6c:	3940092d 	ldrb	w13, [x9, #2]
    40204a70:	3940152e 	ldrb	w14, [x9, #5]
    40204a74:	38404d2f 	ldrb	w15, [x9, #4]!
    40204a78:	39400930 	ldrb	w16, [x9, #2]
    40204a7c:	39400d29 	ldrb	w9, [x9, #3]
    40204a80:	d370bdad 	lsl	x13, x13, #16
    40204a84:	aa0b214a 	orr	x10, x10, x11, lsl #8
    40204a88:	53103e10 	lsl	w16, w16, #16
    40204a8c:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40204a90:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40204a94:	2a096209 	orr	w9, w16, w9, lsl #24
    40204a98:	aa0a018a 	orr	x10, x12, x10
    40204a9c:	2a0b0129 	orr	w9, w9, w11
    40204aa0:	aa098149 	orr	x9, x10, x9, lsl #32
    40204aa4:	9e670125 	fmov	d5, x9
    40204aa8:	52800029 	mov	w9, #0x1                   	// #1
    40204aac:	4e080d26 	dup	v6.2d, x9
    40204ab0:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40204ab4:	2f08a484 	uxtl	v4.8h, v4.8b
    40204ab8:	6f10a485 	uxtl2	v5.4s, v4.8h
    40204abc:	2f10a484 	uxtl	v4.4s, v4.4h
    40204ac0:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40204ac4:	2f20a490 	uxtl	v16.2d, v4.2s
    40204ac8:	6f20a484 	uxtl2	v4.2d, v4.4s
    40204acc:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40204ad0:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40204ad4:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40204ad8:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40204adc:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40204ae0:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40204ae4:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40204ae8:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40204aec:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40204af0:	4ee28462 	add	v2.2d, v3.2d, v2.2d
    40204af4:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    40204af8:	eb0802df 	cmp	x22, x8
    40204afc:	4ee08440 	add	v0.2d, v2.2d, v0.2d
    40204b00:	5ef1b800 	addp	d0, v0.2d
    40204b04:	9e660000 	fmov	x0, d0
    40204b08:	54000100 	b.eq	40204b28 <<core::fmt::Formatter>::pad_integral+0x300>  // b.none
    40204b0c:	cb0802c9 	sub	x9, x22, x8
    40204b10:	8b0802e8 	add	x8, x23, x8
    40204b14:	38c0150a 	ldrsb	w10, [x8], #1
    40204b18:	3101055f 	cmn	w10, #0x41
    40204b1c:	9a80d400 	cinc	x0, x0, gt
    40204b20:	f1000529 	subs	x9, x9, #0x1
    40204b24:	54ffff81 	b.ne	40204b14 <<core::fmt::Formatter>::pad_integral+0x2ec>  // b.any
    40204b28:	8b1b001b 	add	x27, x0, x27
    40204b2c:	79402ab4 	ldrh	w20, [x21, #20]
    40204b30:	eb14037f 	cmp	x27, x20
    40204b34:	54ffeb42 	b.cs	4020489c <<core::fmt::Formatter>::pad_integral+0x74>  // b.hs, b.nlast
    40204b38:	f90007fc 	str	x28, [sp, #8]
    40204b3c:	37c0011a 	tbnz	w26, #24, 40204b5c <<core::fmt::Formatter>::pad_integral+0x334>
    40204b40:	531d7b48 	ubfx	w8, w26, #29, #2
    40204b44:	4b1b029b 	sub	w27, w20, w27
    40204b48:	7100051f 	cmp	w8, #0x1
    40204b4c:	540003cc 	b.gt	40204bc4 <<core::fmt::Formatter>::pad_integral+0x39c>
    40204b50:	35000568 	cbnz	w8, 40204bfc <<core::fmt::Formatter>::pad_integral+0x3d4>
    40204b54:	2a1f03fc 	mov	w28, wzr
    40204b58:	1400002a 	b	40204c00 <<core::fmt::Formatter>::pad_integral+0x3d8>
    40204b5c:	a940f2ba 	ldp	x26, x28, [x21, #8]
    40204b60:	52b3fc08 	mov	w8, #0x9fe00000            	// #-1612709888
    40204b64:	f94002b9 	ldr	x25, [x21]
    40204b68:	2a1803e2 	mov	w2, w24
    40204b6c:	aa1703e3 	mov	x3, x23
    40204b70:	aa1603e4 	mov	x4, x22
    40204b74:	0a080388 	and	w8, w28, w8
    40204b78:	aa1903e0 	mov	x0, x25
    40204b7c:	aa1a03e1 	mov	x1, x26
    40204b80:	321c0508 	orr	w8, w8, #0x30
    40204b84:	32030108 	orr	w8, w8, #0x20000000
    40204b88:	b90012a8 	str	w8, [x21, #16]
    40204b8c:	9400025a 	bl	402054f4 <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204b90:	370006a0 	tbnz	w0, #0, 40204c64 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204b94:	2a1f03f6 	mov	w22, wzr
    40204b98:	4b1b0294 	sub	w20, w20, w27
    40204b9c:	12003ec8 	and	w8, w22, #0xffff
    40204ba0:	6b34211f 	cmp	w8, w20, uxth
    40204ba4:	540001a2 	b.cs	40204bd8 <<core::fmt::Formatter>::pad_integral+0x3b0>  // b.hs, b.nlast
    40204ba8:	f9401348 	ldr	x8, [x26, #32]
    40204bac:	aa1903e0 	mov	x0, x25
    40204bb0:	52800601 	mov	w1, #0x30                  	// #48
    40204bb4:	110006d6 	add	w22, w22, #0x1
    40204bb8:	d63f0100 	blr	x8
    40204bbc:	3607ff00 	tbz	w0, #0, 40204b9c <<core::fmt::Formatter>::pad_integral+0x374>
    40204bc0:	14000029 	b	40204c64 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204bc4:	7100091f 	cmp	w8, #0x2
    40204bc8:	2a1b03fc 	mov	w28, w27
    40204bcc:	540001a1 	b.ne	40204c00 <<core::fmt::Formatter>::pad_integral+0x3d8>  // b.any
    40204bd0:	53013f7c 	ubfx	w28, w27, #1, #15
    40204bd4:	1400000b 	b	40204c00 <<core::fmt::Formatter>::pad_integral+0x3d8>
    40204bd8:	f9400f48 	ldr	x8, [x26, #24]
    40204bdc:	f94007e1 	ldr	x1, [sp, #8]
    40204be0:	aa1903e0 	mov	x0, x25
    40204be4:	aa1303e2 	mov	x2, x19
    40204be8:	d63f0100 	blr	x8
    40204bec:	370003c0 	tbnz	w0, #0, 40204c64 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204bf0:	2a1f03f3 	mov	w19, wzr
    40204bf4:	f9000abc 	str	x28, [x21, #16]
    40204bf8:	1400001c 	b	40204c68 <<core::fmt::Formatter>::pad_integral+0x440>
    40204bfc:	2a1b03fc 	mov	w28, w27
    40204c00:	a94056b9 	ldp	x25, x21, [x21]
    40204c04:	2a1f03f4 	mov	w20, wzr
    40204c08:	12003e88 	and	w8, w20, #0xffff
    40204c0c:	6b3c211f 	cmp	w8, w28, uxth
    40204c10:	54000102 	b.cs	40204c30 <<core::fmt::Formatter>::pad_integral+0x408>  // b.hs, b.nlast
    40204c14:	f94012a8 	ldr	x8, [x21, #32]
    40204c18:	12005341 	and	w1, w26, #0x1fffff
    40204c1c:	aa1903e0 	mov	x0, x25
    40204c20:	11000694 	add	w20, w20, #0x1
    40204c24:	d63f0100 	blr	x8
    40204c28:	3607ff00 	tbz	w0, #0, 40204c08 <<core::fmt::Formatter>::pad_integral+0x3e0>
    40204c2c:	1400000e 	b	40204c64 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204c30:	aa1903e0 	mov	x0, x25
    40204c34:	aa1503e1 	mov	x1, x21
    40204c38:	2a1803e2 	mov	w2, w24
    40204c3c:	aa1703e3 	mov	x3, x23
    40204c40:	aa1603e4 	mov	x4, x22
    40204c44:	9400022c 	bl	402054f4 <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204c48:	370000e0 	tbnz	w0, #0, 40204c64 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204c4c:	f9400ea8 	ldr	x8, [x21, #24]
    40204c50:	f94007e1 	ldr	x1, [sp, #8]
    40204c54:	aa1903e0 	mov	x0, x25
    40204c58:	aa1303e2 	mov	x2, x19
    40204c5c:	d63f0100 	blr	x8
    40204c60:	36000160 	tbz	w0, #0, 40204c8c <<core::fmt::Formatter>::pad_integral+0x464>
    40204c64:	52800033 	mov	w19, #0x1                   	// #1
    40204c68:	2a1303e0 	mov	w0, w19
    40204c6c:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40204c70:	a94557f6 	ldp	x22, x21, [sp, #80]
    40204c74:	a9445ff8 	ldp	x24, x23, [sp, #64]
    40204c78:	a94367fa 	ldp	x26, x25, [sp, #48]
    40204c7c:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40204c80:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40204c84:	9101c3ff 	add	sp, sp, #0x70
    40204c88:	d65f03c0 	ret
    40204c8c:	2a1f03f4 	mov	w20, wzr
    40204c90:	4b1c0376 	sub	w22, w27, w28
    40204c94:	12003e88 	and	w8, w20, #0xffff
    40204c98:	6b36211f 	cmp	w8, w22, uxth
    40204c9c:	1a9f27f3 	cset	w19, cc  // cc = lo, ul, last
    40204ca0:	54fffe42 	b.cs	40204c68 <<core::fmt::Formatter>::pad_integral+0x440>  // b.hs, b.nlast
    40204ca4:	f94012a8 	ldr	x8, [x21, #32]
    40204ca8:	12005341 	and	w1, w26, #0x1fffff
    40204cac:	aa1903e0 	mov	x0, x25
    40204cb0:	11000694 	add	w20, w20, #0x1
    40204cb4:	d63f0100 	blr	x8
    40204cb8:	3607fee0 	tbz	w0, #0, 40204c94 <<core::fmt::Formatter>::pad_integral+0x46c>
    40204cbc:	17ffffeb 	b	40204c68 <<core::fmt::Formatter>::pad_integral+0x440>

0000000040204cc0 <core::panicking::panic_bounds_check>:
    40204cc0:	d10103ff 	sub	sp, sp, #0x40
    40204cc4:	a9037bfd 	stp	x29, x30, [sp, #48]
    40204cc8:	9100c3fd 	add	x29, sp, #0x30
    40204ccc:	910023e8 	add	x8, sp, #0x8
    40204cd0:	d503201f 	nop
    40204cd4:	10004549 	adr	x9, 4020557c <<u64 as core::fmt::Display>::fmt>
    40204cd8:	a90007e0 	stp	x0, x1, [sp]
    40204cdc:	b0000000 	adrp	x0, 40205000 <core::str::count::do_count_chars+0x2e0>
    40204ce0:	9136d400 	add	x0, x0, #0xdb5
    40204ce4:	a90127e8 	stp	x8, x9, [sp, #16]
    40204ce8:	910003e8 	mov	x8, sp
    40204cec:	910043e1 	add	x1, sp, #0x10
    40204cf0:	a90227e8 	stp	x8, x9, [sp, #32]
    40204cf4:	94000001 	bl	40204cf8 <core::panicking::panic_fmt>

0000000040204cf8 <core::panicking::panic_fmt>:
    40204cf8:	d10103ff 	sub	sp, sp, #0x40
    40204cfc:	a9037bfd 	stp	x29, x30, [sp, #48]
    40204d00:	9100c3fd 	add	x29, sp, #0x30
    40204d04:	910023e8 	add	x8, sp, #0x8
    40204d08:	a90087e0 	stp	x0, x1, [sp, #8]
    40204d0c:	910063e0 	add	x0, sp, #0x18
    40204d10:	a9018be8 	stp	x8, x2, [sp, #24]
    40204d14:	52800028 	mov	w8, #0x1                   	// #1
    40204d18:	790053e8 	strh	w8, [sp, #40]
    40204d1c:	97fffc97 	bl	40203f78 <__rustc::rust_begin_unwind>

0000000040204d20 <core::str::count::do_count_chars>:
    40204d20:	d10183ff 	sub	sp, sp, #0x60
    40204d24:	fd0023ea 	str	d10, [sp, #64]
    40204d28:	6d0523e9 	stp	d9, d8, [sp, #80]
    40204d2c:	91001c08 	add	x8, x0, #0x7
    40204d30:	927df10d 	and	x13, x8, #0xfffffffffffffff8
    40204d34:	cb0001ac 	sub	x12, x13, x0
    40204d38:	eb0c002b 	subs	x11, x1, x12
    40204d3c:	540000e2 	b.cs	40204d58 <core::str::count::do_count_chars+0x38>  // b.hs, b.nlast
    40204d40:	b4000721 	cbz	x1, 40204e24 <core::str::count::do_count_chars+0x104>
    40204d44:	f100203f 	cmp	x1, #0x8
    40204d48:	54001b82 	b.cs	402050b8 <core::str::count::do_count_chars+0x398>  // b.hs, b.nlast
    40204d4c:	aa1f03e9 	mov	x9, xzr
    40204d50:	aa1f03e8 	mov	x8, xzr
    40204d54:	140001d2 	b	4020549c <core::str::count::do_count_chars+0x77c>
    40204d58:	d343fd69 	lsr	x9, x11, #3
    40204d5c:	b4ffff29 	cbz	x9, 40204d40 <core::str::count::do_count_chars+0x20>
    40204d60:	eb0001bf 	cmp	x13, x0
    40204d64:	9240096a 	and	x10, x11, #0x7
    40204d68:	aa1f03e8 	mov	x8, xzr
    40204d6c:	54000100 	b.eq	40204d8c <core::str::count::do_count_chars+0x6c>  // b.none
    40204d70:	cb0d000d 	sub	x13, x0, x13
    40204d74:	aa0003ee 	mov	x14, x0
    40204d78:	38c015cf 	ldrsb	w15, [x14], #1
    40204d7c:	310105ff 	cmn	w15, #0x41
    40204d80:	9a88d508 	cinc	x8, x8, gt
    40204d84:	b10005ad 	adds	x13, x13, #0x1
    40204d88:	54ffff83 	b.cc	40204d78 <core::str::count::do_count_chars+0x58>  // b.lo, b.ul, b.last
    40204d8c:	8b0c000e 	add	x14, x0, x12
    40204d90:	b400056a 	cbz	x10, 40204e3c <core::str::count::do_count_chars+0x11c>
    40204d94:	927ded6b 	and	x11, x11, #0x7ffffffffffffff8
    40204d98:	8b0b01cc 	add	x12, x14, x11
    40204d9c:	39c0018b 	ldrsb	w11, [x12]
    40204da0:	3101057f 	cmn	w11, #0x41
    40204da4:	1a9fd7eb 	cset	w11, gt
    40204da8:	f100055f 	cmp	x10, #0x1
    40204dac:	540004a0 	b.eq	40204e40 <core::str::count::do_count_chars+0x120>  // b.none
    40204db0:	39c0058d 	ldrsb	w13, [x12, #1]
    40204db4:	310105bf 	cmn	w13, #0x41
    40204db8:	9a8bd56b 	cinc	x11, x11, gt
    40204dbc:	f100095f 	cmp	x10, #0x2
    40204dc0:	54000400 	b.eq	40204e40 <core::str::count::do_count_chars+0x120>  // b.none
    40204dc4:	39c0098d 	ldrsb	w13, [x12, #2]
    40204dc8:	310105bf 	cmn	w13, #0x41
    40204dcc:	9a8bd56b 	cinc	x11, x11, gt
    40204dd0:	f1000d5f 	cmp	x10, #0x3
    40204dd4:	54000360 	b.eq	40204e40 <core::str::count::do_count_chars+0x120>  // b.none
    40204dd8:	39c00d8d 	ldrsb	w13, [x12, #3]
    40204ddc:	310105bf 	cmn	w13, #0x41
    40204de0:	9a8bd56b 	cinc	x11, x11, gt
    40204de4:	f100115f 	cmp	x10, #0x4
    40204de8:	540002c0 	b.eq	40204e40 <core::str::count::do_count_chars+0x120>  // b.none
    40204dec:	39c0118d 	ldrsb	w13, [x12, #4]
    40204df0:	310105bf 	cmn	w13, #0x41
    40204df4:	9a8bd56b 	cinc	x11, x11, gt
    40204df8:	f100155f 	cmp	x10, #0x5
    40204dfc:	54000220 	b.eq	40204e40 <core::str::count::do_count_chars+0x120>  // b.none
    40204e00:	39c0158d 	ldrsb	w13, [x12, #5]
    40204e04:	310105bf 	cmn	w13, #0x41
    40204e08:	9a8bd56b 	cinc	x11, x11, gt
    40204e0c:	f100195f 	cmp	x10, #0x6
    40204e10:	54000180 	b.eq	40204e40 <core::str::count::do_count_chars+0x120>  // b.none
    40204e14:	39c0198a 	ldrsb	w10, [x12, #6]
    40204e18:	3101055f 	cmn	w10, #0x41
    40204e1c:	9a8bd56b 	cinc	x11, x11, gt
    40204e20:	14000008 	b	40204e40 <core::str::count::do_count_chars+0x120>
    40204e24:	aa1f03e8 	mov	x8, xzr
    40204e28:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40204e2c:	aa0803e0 	mov	x0, x8
    40204e30:	fd4023ea 	ldr	d10, [sp, #64]
    40204e34:	910183ff 	add	sp, sp, #0x60
    40204e38:	d65f03c0 	ret
    40204e3c:	aa1f03eb 	mov	x11, xzr
    40204e40:	4f00e420 	movi	v0.16b, #0x1
    40204e44:	8b080168 	add	x8, x11, x8
    40204e48:	5280180a 	mov	w10, #0xc0                  	// #192
    40204e4c:	b20083eb 	mov	x11, #0x1000100010001       	// #281479271743489
    40204e50:	1400000c 	b	40204e80 <core::str::count::do_count_chars+0x160>
    40204e54:	aa1f03f1 	mov	x17, xzr
    40204e58:	d348fe2f 	lsr	x15, x17, #8
    40204e5c:	92009e30 	and	x16, x17, #0xff00ff00ff00ff
    40204e60:	8b0e018e 	add	x14, x12, x14
    40204e64:	cb0d0129 	sub	x9, x9, x13
    40204e68:	92009def 	and	x15, x15, #0xff00ff00ff00ff
    40204e6c:	8b1001ef 	add	x15, x15, x16
    40204e70:	9b0b7df0 	mul	x16, x15, x11
    40204e74:	924005af 	and	x15, x13, #0x3
    40204e78:	8b50c108 	add	x8, x8, x16, lsr #48
    40204e7c:	b5000d8f 	cbnz	x15, 4020502c <core::str::count::do_count_chars+0x30c>
    40204e80:	b4fffd49 	cbz	x9, 40204e28 <core::str::count::do_count_chars+0x108>
    40204e84:	f103013f 	cmp	x9, #0xc0
    40204e88:	aa0e03ec 	mov	x12, x14
    40204e8c:	9a8a312d 	csel	x13, x9, x10, cc  // cc = lo, ul, last
    40204e90:	d37df1ae 	lsl	x14, x13, #3
    40204e94:	f27b15d0 	ands	x16, x14, #0x7e0
    40204e98:	54fffde0 	b.eq	40204e54 <core::str::count::do_count_chars+0x134>  // b.none
    40204e9c:	d10081cf 	sub	x15, x14, #0x20
    40204ea0:	f10181ff 	cmp	x15, #0x60
    40204ea4:	54000082 	b.cs	40204eb4 <core::str::count::do_count_chars+0x194>  // b.hs, b.nlast
    40204ea8:	aa1f03f1 	mov	x17, xzr
    40204eac:	aa0c03ef 	mov	x15, x12
    40204eb0:	14000044 	b	40204fc0 <core::str::count::do_count_chars+0x2a0>
    40204eb4:	d345fdef 	lsr	x15, x15, #5
    40204eb8:	6f00e401 	movi	v1.2d, #0x0
    40204ebc:	6f00e402 	movi	v2.2d, #0x0
    40204ec0:	91010180 	add	x0, x12, #0x40
    40204ec4:	910005f1 	add	x17, x15, #0x1
    40204ec8:	927ee632 	and	x18, x17, #0xffffffffffffffc
    40204ecc:	927ee621 	and	x1, x17, #0xffffffffffffffc
    40204ed0:	8b12158f 	add	x15, x12, x18, lsl #5
    40204ed4:	d1010002 	sub	x2, x0, #0x40
    40204ed8:	4c400c10 	ld4	{v16.2d-v19.2d}, [x0]
    40204edc:	f1001021 	subs	x1, x1, #0x4
    40204ee0:	91020000 	add	x0, x0, #0x80
    40204ee4:	4c400c43 	ld4	{v3.2d-v6.2d}, [x2]
    40204ee8:	6e205a07 	mvn	v7.16b, v16.16b
    40204eec:	6e205a35 	mvn	v21.16b, v17.16b
    40204ef0:	6e205a5a 	mvn	v26.16b, v18.16b
    40204ef4:	6e205876 	mvn	v22.16b, v3.16b
    40204ef8:	6e205897 	mvn	v23.16b, v4.16b
    40204efc:	6e2058b8 	mvn	v24.16b, v5.16b
    40204f00:	6f7a0614 	ushr	v20.2d, v16.2d, #6
    40204f04:	6f7a0639 	ushr	v25.2d, v17.2d, #6
    40204f08:	6f7a065b 	ushr	v27.2d, v18.2d, #6
    40204f0c:	6f7a047c 	ushr	v28.2d, v3.2d, #6
    40204f10:	6f7a049d 	ushr	v29.2d, v4.2d, #6
    40204f14:	6f7a04be 	ushr	v30.2d, v5.2d, #6
    40204f18:	6f7906d6 	ushr	v22.2d, v22.2d, #7
    40204f1c:	6f7906f7 	ushr	v23.2d, v23.2d, #7
    40204f20:	6f790718 	ushr	v24.2d, v24.2d, #7
    40204f24:	6f7904e7 	ushr	v7.2d, v7.2d, #7
    40204f28:	6f7906b5 	ushr	v21.2d, v21.2d, #7
    40204f2c:	6f79075a 	ushr	v26.2d, v26.2d, #7
    40204f30:	6e205a7f 	mvn	v31.16b, v19.16b
    40204f34:	6f7a0670 	ushr	v16.2d, v19.2d, #6
    40204f38:	6e2058d1 	mvn	v17.16b, v6.16b
    40204f3c:	4ebc1ed2 	orr	v18.16b, v22.16b, v28.16b
    40204f40:	4ebd1ef3 	orr	v19.16b, v23.16b, v29.16b
    40204f44:	4ebe1f16 	orr	v22.16b, v24.16b, v30.16b
    40204f48:	4eb41ce7 	orr	v7.16b, v7.16b, v20.16b
    40204f4c:	4eb91eb4 	orr	v20.16b, v21.16b, v25.16b
    40204f50:	4ebb1f55 	orr	v21.16b, v26.16b, v27.16b
    40204f54:	6f7a04c3 	ushr	v3.2d, v6.2d, #6
    40204f58:	6f7907e4 	ushr	v4.2d, v31.2d, #7
    40204f5c:	6f790625 	ushr	v5.2d, v17.2d, #7
    40204f60:	4e201e46 	and	v6.16b, v18.16b, v0.16b
    40204f64:	4e201e71 	and	v17.16b, v19.16b, v0.16b
    40204f68:	4e201ed2 	and	v18.16b, v22.16b, v0.16b
    40204f6c:	4e201ce7 	and	v7.16b, v7.16b, v0.16b
    40204f70:	4e201e93 	and	v19.16b, v20.16b, v0.16b
    40204f74:	4e201eb4 	and	v20.16b, v21.16b, v0.16b
    40204f78:	4eb01c84 	orr	v4.16b, v4.16b, v16.16b
    40204f7c:	4ea31ca3 	orr	v3.16b, v5.16b, v3.16b
    40204f80:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40204f84:	4ef18646 	add	v6.2d, v18.2d, v17.2d
    40204f88:	4ee284e2 	add	v2.2d, v7.2d, v2.2d
    40204f8c:	4ef38685 	add	v5.2d, v20.2d, v19.2d
    40204f90:	4e201c63 	and	v3.16b, v3.16b, v0.16b
    40204f94:	4e201c84 	and	v4.16b, v4.16b, v0.16b
    40204f98:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40204f9c:	4ee284a2 	add	v2.2d, v5.2d, v2.2d
    40204fa0:	4ee18461 	add	v1.2d, v3.2d, v1.2d
    40204fa4:	4ee28482 	add	v2.2d, v4.2d, v2.2d
    40204fa8:	54fff961 	b.ne	40204ed4 <core::str::count::do_count_chars+0x1b4>  // b.any
    40204fac:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40204fb0:	eb12023f 	cmp	x17, x18
    40204fb4:	5ef1b821 	addp	d1, v1.2d
    40204fb8:	9e660031 	fmov	x17, d1
    40204fbc:	54fff4e0 	b.eq	40204e58 <core::str::count::do_count_chars+0x138>  // b.none
    40204fc0:	8b100190 	add	x16, x12, x16
    40204fc4:	f9400df2 	ldr	x18, [x15, #24]
    40204fc8:	f9001ff2 	str	x18, [sp, #56]
    40204fcc:	f94009f2 	ldr	x18, [x15, #16]
    40204fd0:	f9001bf2 	str	x18, [sp, #48]
    40204fd4:	f94005f2 	ldr	x18, [x15, #8]
    40204fd8:	f90017f2 	str	x18, [sp, #40]
    40204fdc:	f84205f2 	ldr	x18, [x15], #32
    40204fe0:	eb1001ff 	cmp	x15, x16
    40204fe4:	f90013f2 	str	x18, [sp, #32]
    40204fe8:	ad4107e2 	ldp	q2, q1, [sp, #32]
    40204fec:	6e205823 	mvn	v3.16b, v1.16b
    40204ff0:	6e205844 	mvn	v4.16b, v2.16b
    40204ff4:	6f7a0421 	ushr	v1.2d, v1.2d, #6
    40204ff8:	6f7a0442 	ushr	v2.2d, v2.2d, #6
    40204ffc:	6f790463 	ushr	v3.2d, v3.2d, #7
    40205000:	6f790484 	ushr	v4.2d, v4.2d, #7
    40205004:	4ea21c82 	orr	v2.16b, v4.16b, v2.16b
    40205008:	4ea11c61 	orr	v1.16b, v3.16b, v1.16b
    4020500c:	4e201c21 	and	v1.16b, v1.16b, v0.16b
    40205010:	4e201c42 	and	v2.16b, v2.16b, v0.16b
    40205014:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40205018:	5ef1b821 	addp	d1, v1.2d
    4020501c:	9e660032 	fmov	x18, d1
    40205020:	8b110251 	add	x17, x18, x17
    40205024:	54fffd01 	b.ne	40204fc4 <core::str::count::do_count_chars+0x2a4>  // b.any
    40205028:	17ffff8c 	b	40204e58 <core::str::count::do_count_chars+0x138>
    4020502c:	927e15a9 	and	x9, x13, #0xfc
    40205030:	f10005ff 	cmp	x15, #0x1
    40205034:	8b090d8a 	add	x10, x12, x9, lsl #3
    40205038:	f9400149 	ldr	x9, [x10]
    4020503c:	aa2903eb 	mvn	x11, x9
    40205040:	d347fd6b 	lsr	x11, x11, #7
    40205044:	aa491969 	orr	x9, x11, x9, lsr #6
    40205048:	9200c129 	and	x9, x9, #0x101010101010101
    4020504c:	540001e0 	b.eq	40205088 <core::str::count::do_count_chars+0x368>  // b.none
    40205050:	f940054b 	ldr	x11, [x10, #8]
    40205054:	f10009ff 	cmp	x15, #0x2
    40205058:	aa2b03ec 	mvn	x12, x11
    4020505c:	d347fd8c 	lsr	x12, x12, #7
    40205060:	aa4b198b 	orr	x11, x12, x11, lsr #6
    40205064:	9200c16b 	and	x11, x11, #0x101010101010101
    40205068:	8b090169 	add	x9, x11, x9
    4020506c:	540000e0 	b.eq	40205088 <core::str::count::do_count_chars+0x368>  // b.none
    40205070:	f940094a 	ldr	x10, [x10, #16]
    40205074:	aa2a03eb 	mvn	x11, x10
    40205078:	d347fd6b 	lsr	x11, x11, #7
    4020507c:	aa4a196a 	orr	x10, x11, x10, lsr #6
    40205080:	9200c14a 	and	x10, x10, #0x101010101010101
    40205084:	8b090149 	add	x9, x10, x9
    40205088:	d348fd2a 	lsr	x10, x9, #8
    4020508c:	92009d29 	and	x9, x9, #0xff00ff00ff00ff
    40205090:	92009d4a 	and	x10, x10, #0xff00ff00ff00ff
    40205094:	8b090149 	add	x9, x10, x9
    40205098:	b20083ea 	mov	x10, #0x1000100010001       	// #281479271743489
    4020509c:	9b0a7d29 	mul	x9, x9, x10
    402050a0:	8b49c108 	add	x8, x8, x9, lsr #48
    402050a4:	6d4523e9 	ldp	d9, d8, [sp, #80]
    402050a8:	aa0803e0 	mov	x0, x8
    402050ac:	fd4023ea 	ldr	d10, [sp, #64]
    402050b0:	910183ff 	add	sp, sp, #0x60
    402050b4:	d65f03c0 	ret
    402050b8:	f100803f 	cmp	x1, #0x20
    402050bc:	54000082 	b.cs	402050cc <core::str::count::do_count_chars+0x3ac>  // b.hs, b.nlast
    402050c0:	aa1f03e9 	mov	x9, xzr
    402050c4:	aa1f03e8 	mov	x8, xzr
    402050c8:	140000bc 	b	402053b8 <core::str::count::do_count_chars+0x698>
    402050cc:	6f00e400 	movi	v0.2d, #0x0
    402050d0:	4f05e7e3 	movi	v3.16b, #0xbf
    402050d4:	52800028 	mov	w8, #0x1                   	// #1
    402050d8:	6f00e402 	movi	v2.2d, #0x0
    402050dc:	6f00e407 	movi	v7.2d, #0x0
    402050e0:	927d042a 	and	x10, x1, #0x18
    402050e4:	6f00e401 	movi	v1.2d, #0x0
    402050e8:	6f00e412 	movi	v18.2d, #0x0
    402050ec:	927be829 	and	x9, x1, #0xffffffffffffffe0
    402050f0:	6f00e405 	movi	v5.2d, #0x0
    402050f4:	6f00e406 	movi	v6.2d, #0x0
    402050f8:	927be82b 	and	x11, x1, #0xffffffffffffffe0
    402050fc:	6f00e404 	movi	v4.2d, #0x0
    40205100:	6f00e416 	movi	v22.2d, #0x0
    40205104:	6f00e411 	movi	v17.2d, #0x0
    40205108:	6f00e410 	movi	v16.2d, #0x0
    4020510c:	6f00e417 	movi	v23.2d, #0x0
    40205110:	6f00e414 	movi	v20.2d, #0x0
    40205114:	6f00e415 	movi	v21.2d, #0x0
    40205118:	6f00e413 	movi	v19.2d, #0x0
    4020511c:	6f00e418 	movi	v24.2d, #0x0
    40205120:	4e080d19 	dup	v25.2d, x8
    40205124:	91004008 	add	x8, x0, #0x10
    40205128:	aa0803ec 	mov	x12, x8
    4020512c:	385f1112 	ldurb	w18, [x8, #-15]
    40205130:	385f5102 	ldurb	w2, [x8, #-11]
    40205134:	385f0d8d 	ldrb	w13, [x12, #-16]!
    40205138:	aa0c03ef 	mov	x15, x12
    4020513c:	3940098e 	ldrb	w14, [x12, #2]
    40205140:	38404df0 	ldrb	w16, [x15, #4]!
    40205144:	394009f1 	ldrb	w17, [x15, #2]
    40205148:	39400d83 	ldrb	w3, [x12, #3]
    4020514c:	39400def 	ldrb	w15, [x15, #3]
    40205150:	d370bdce 	lsl	x14, x14, #16
    40205154:	aa1221ad 	orr	x13, x13, x18, lsl #8
    40205158:	2a022210 	orr	w16, w16, w2, lsl #8
    4020515c:	53103e31 	lsl	w17, w17, #16
    40205160:	f100816b 	subs	x11, x11, #0x20
    40205164:	aa0361ce 	orr	x14, x14, x3, lsl #24
    40205168:	2a0f622f 	orr	w15, w17, w15, lsl #24
    4020516c:	aa0d01cd 	orr	x13, x14, x13
    40205170:	2a1001ee 	orr	w14, w15, w16
    40205174:	aa0e81ad 	orr	x13, x13, x14, lsl #32
    40205178:	f9000bed 	str	x13, [sp, #16]
    4020517c:	aa0c03ed 	mov	x13, x12
    40205180:	38408dae 	ldrb	w14, [x13, #8]!
    40205184:	39400daf 	ldrb	w15, [x13, #3]
    40205188:	394009b0 	ldrb	w16, [x13, #2]
    4020518c:	38404db1 	ldrb	w17, [x13, #4]!
    40205190:	394009b2 	ldrb	w18, [x13, #2]
    40205194:	39402582 	ldrb	w2, [x12, #9]
    40205198:	3940358c 	ldrb	w12, [x12, #13]
    4020519c:	39400dad 	ldrb	w13, [x13, #3]
    402051a0:	d370be10 	lsl	x16, x16, #16
    402051a4:	53103e52 	lsl	w18, w18, #16
    402051a8:	aa0221ce 	orr	x14, x14, x2, lsl #8
    402051ac:	2a0c222c 	orr	w12, w17, w12, lsl #8
    402051b0:	aa0f620f 	orr	x15, x16, x15, lsl #24
    402051b4:	2a0d624d 	orr	w13, w18, w13, lsl #24
    402051b8:	aa0e01ee 	orr	x14, x15, x14
    402051bc:	2a0c01ac 	orr	w12, w13, w12
    402051c0:	aa0c81cc 	orr	x12, x14, x12, lsl #32
    402051c4:	f9000fec 	str	x12, [sp, #24]
    402051c8:	aa0803ec 	mov	x12, x8
    402051cc:	3940090e 	ldrb	w14, [x8, #2]
    402051d0:	38404d8f 	ldrb	w15, [x12, #4]!
    402051d4:	39400990 	ldrb	w16, [x12, #2]
    402051d8:	3940050d 	ldrb	w13, [x8, #1]
    402051dc:	39400111 	ldrb	w17, [x8]
    402051e0:	39400d12 	ldrb	w18, [x8, #3]
    402051e4:	39401502 	ldrb	w2, [x8, #5]
    402051e8:	39400d8c 	ldrb	w12, [x12, #3]
    402051ec:	d370bdce 	lsl	x14, x14, #16
    402051f0:	53103e10 	lsl	w16, w16, #16
    402051f4:	aa0d222d 	orr	x13, x17, x13, lsl #8
    402051f8:	2a0221ef 	orr	w15, w15, w2, lsl #8
    402051fc:	3dc007fa 	ldr	q26, [sp, #16]
    40205200:	aa1261ce 	orr	x14, x14, x18, lsl #24
    40205204:	2a0c620c 	orr	w12, w16, w12, lsl #24
    40205208:	4e23375a 	cmgt	v26.16b, v26.16b, v3.16b
    4020520c:	aa0d01cd 	orr	x13, x14, x13
    40205210:	2a0f018c 	orr	w12, w12, w15
    40205214:	aa0c81ac 	orr	x12, x13, x12, lsl #32
    40205218:	aa0803ed 	mov	x13, x8
    4020521c:	6f08a75b 	uxtl2	v27.8h, v26.16b
    40205220:	2f08a75a 	uxtl	v26.8h, v26.8b
    40205224:	f90003ec 	str	x12, [sp]
    40205228:	38408dac 	ldrb	w12, [x13, #8]!
    4020522c:	39400dae 	ldrb	w14, [x13, #3]
    40205230:	394009af 	ldrb	w15, [x13, #2]
    40205234:	38404db0 	ldrb	w16, [x13, #4]!
    40205238:	394009b1 	ldrb	w17, [x13, #2]
    4020523c:	39402512 	ldrb	w18, [x8, #9]
    40205240:	39403502 	ldrb	w2, [x8, #13]
    40205244:	39400dad 	ldrb	w13, [x13, #3]
    40205248:	d370bdef 	lsl	x15, x15, #16
    4020524c:	6f10a77c 	uxtl2	v28.4s, v27.8h
    40205250:	53103e31 	lsl	w17, w17, #16
    40205254:	aa12218c 	orr	x12, x12, x18, lsl #8
    40205258:	2a022210 	orr	w16, w16, w2, lsl #8
    4020525c:	aa0e61ee 	orr	x14, x15, x14, lsl #24
    40205260:	2f10a77b 	uxtl	v27.4s, v27.4h
    40205264:	2f10a75e 	uxtl	v30.4s, v26.4h
    40205268:	2a0d622d 	orr	w13, w17, w13, lsl #24
    4020526c:	6f20a79d 	uxtl2	v29.2d, v28.4s
    40205270:	6f10a75a 	uxtl2	v26.4s, v26.8h
    40205274:	aa0c01cc 	orr	x12, x14, x12
    40205278:	2f20a79c 	uxtl	v28.2d, v28.2s
    4020527c:	91008108 	add	x8, x8, #0x20
    40205280:	2a1001ad 	orr	w13, w13, w16
    40205284:	6f20a768 	uxtl2	v8.2d, v27.4s
    40205288:	6f20a7c9 	uxtl2	v9.2d, v30.4s
    4020528c:	aa0d818c 	orr	x12, x12, x13, lsl #32
    40205290:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    40205294:	6f20a74a 	uxtl2	v10.2d, v26.4s
    40205298:	2f20a75a 	uxtl	v26.2d, v26.2s
    4020529c:	2f20a77b 	uxtl	v27.2d, v27.2s
    402052a0:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    402052a4:	f90007ec 	str	x12, [sp, #8]
    402052a8:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    402052ac:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    402052b0:	3dc003ff 	ldr	q31, [sp]
    402052b4:	4efd86d6 	add	v22.2d, v22.2d, v29.2d
    402052b8:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    402052bc:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    402052c0:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    402052c4:	4efc8484 	add	v4.2d, v4.2d, v28.2d
    402052c8:	4e2337ff 	cmgt	v31.16b, v31.16b, v3.16b
    402052cc:	4ee884c6 	add	v6.2d, v6.2d, v8.2d
    402052d0:	2f20a7de 	uxtl	v30.2d, v30.2s
    402052d4:	4eea8652 	add	v18.2d, v18.2d, v10.2d
    402052d8:	4ee984e7 	add	v7.2d, v7.2d, v9.2d
    402052dc:	4efa8421 	add	v1.2d, v1.2d, v26.2d
    402052e0:	4efb84a5 	add	v5.2d, v5.2d, v27.2d
    402052e4:	6f08a7fd 	uxtl2	v29.8h, v31.16b
    402052e8:	2f08a7ff 	uxtl	v31.8h, v31.8b
    402052ec:	4e391fde 	and	v30.16b, v30.16b, v25.16b
    402052f0:	6f10a7bc 	uxtl2	v28.4s, v29.8h
    402052f4:	6f10a7e8 	uxtl2	v8.4s, v31.8h
    402052f8:	2f10a7bd 	uxtl	v29.4s, v29.4h
    402052fc:	2f10a7fa 	uxtl	v26.4s, v31.4h
    40205300:	4efe8442 	add	v2.2d, v2.2d, v30.2d
    40205304:	2f20a79b 	uxtl	v27.2d, v28.2s
    40205308:	6f20a79c 	uxtl2	v28.2d, v28.4s
    4020530c:	2f20a7bf 	uxtl	v31.2d, v29.2s
    40205310:	6f20a509 	uxtl2	v9.2d, v8.4s
    40205314:	6f20a7bd 	uxtl2	v29.2d, v29.4s
    40205318:	2f20a74a 	uxtl	v10.2d, v26.2s
    4020531c:	6f20a75a 	uxtl2	v26.2d, v26.4s
    40205320:	2f20a508 	uxtl	v8.2d, v8.2s
    40205324:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    40205328:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    4020532c:	4e391fff 	and	v31.16b, v31.16b, v25.16b
    40205330:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    40205334:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    40205338:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    4020533c:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    40205340:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    40205344:	4efc8718 	add	v24.2d, v24.2d, v28.2d
    40205348:	4efb8673 	add	v19.2d, v19.2d, v27.2d
    4020534c:	4eff8694 	add	v20.2d, v20.2d, v31.2d
    40205350:	4efd86b5 	add	v21.2d, v21.2d, v29.2d
    40205354:	4ee986f7 	add	v23.2d, v23.2d, v9.2d
    40205358:	4eea8631 	add	v17.2d, v17.2d, v10.2d
    4020535c:	4ee88610 	add	v16.2d, v16.2d, v8.2d
    40205360:	4efa8400 	add	v0.2d, v0.2d, v26.2d
    40205364:	54ffee21 	b.ne	40205128 <core::str::count::do_count_chars+0x408>  // b.any
    40205368:	4ef286e3 	add	v3.2d, v23.2d, v18.2d
    4020536c:	4ef68712 	add	v18.2d, v24.2d, v22.2d
    40205370:	eb09003f 	cmp	x1, x9
    40205374:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40205378:	4ee28622 	add	v2.2d, v17.2d, v2.2d
    4020537c:	4ee58685 	add	v5.2d, v20.2d, v5.2d
    40205380:	4ee686a6 	add	v6.2d, v21.2d, v6.2d
    40205384:	4ee18601 	add	v1.2d, v16.2d, v1.2d
    40205388:	4ee48664 	add	v4.2d, v19.2d, v4.2d
    4020538c:	4ef28463 	add	v3.2d, v3.2d, v18.2d
    40205390:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40205394:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40205398:	4ee68400 	add	v0.2d, v0.2d, v6.2d
    4020539c:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    402053a0:	4ee38400 	add	v0.2d, v0.2d, v3.2d
    402053a4:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    402053a8:	5ef1b800 	addp	d0, v0.2d
    402053ac:	9e660008 	fmov	x8, d0
    402053b0:	54ffd3c0 	b.eq	40204e28 <core::str::count::do_count_chars+0x108>  // b.none
    402053b4:	b400074a 	cbz	x10, 4020549c <core::str::count::do_count_chars+0x77c>
    402053b8:	6f00e400 	movi	v0.2d, #0x0
    402053bc:	6f00e401 	movi	v1.2d, #0x0
    402053c0:	aa0903ea 	mov	x10, x9
    402053c4:	0f05e7e2 	movi	v2.8b, #0xbf
    402053c8:	6f00e403 	movi	v3.2d, #0x0
    402053cc:	927df029 	and	x9, x1, #0xfffffffffffffff8
    402053d0:	6f00e404 	movi	v4.2d, #0x0
    402053d4:	4e081d00 	mov	v0.d[0], x8
    402053d8:	52800028 	mov	w8, #0x1                   	// #1
    402053dc:	4e080d05 	dup	v5.2d, x8
    402053e0:	cb090148 	sub	x8, x10, x9
    402053e4:	8b0a000a 	add	x10, x0, x10
    402053e8:	aa0a03ed 	mov	x13, x10
    402053ec:	3940094c 	ldrb	w12, [x10, #2]
    402053f0:	3940054b 	ldrb	w11, [x10, #1]
    402053f4:	38404dae 	ldrb	w14, [x13, #4]!
    402053f8:	394009af 	ldrb	w15, [x13, #2]
    402053fc:	39400150 	ldrb	w16, [x10]
    40205400:	39400d51 	ldrb	w17, [x10, #3]
    40205404:	d370bd8c 	lsl	x12, x12, #16
    40205408:	39401552 	ldrb	w18, [x10, #5]
    4020540c:	39400dad 	ldrb	w13, [x13, #3]
    40205410:	53103def 	lsl	w15, w15, #16
    40205414:	aa0b220b 	orr	x11, x16, x11, lsl #8
    40205418:	aa11618c 	orr	x12, x12, x17, lsl #24
    4020541c:	b1002108 	adds	x8, x8, #0x8
    40205420:	2a1221ce 	orr	w14, w14, w18, lsl #8
    40205424:	2a0d61ed 	orr	w13, w15, w13, lsl #24
    40205428:	9100214a 	add	x10, x10, #0x8
    4020542c:	aa0b018b 	orr	x11, x12, x11
    40205430:	2a0e01ac 	orr	w12, w13, w14
    40205434:	aa0c816b 	orr	x11, x11, x12, lsl #32
    40205438:	9e670166 	fmov	d6, x11
    4020543c:	0e2234c6 	cmgt	v6.8b, v6.8b, v2.8b
    40205440:	2f08a4c6 	uxtl	v6.8h, v6.8b
    40205444:	6f10a4c7 	uxtl2	v7.4s, v6.8h
    40205448:	2f10a4c6 	uxtl	v6.4s, v6.4h
    4020544c:	6f20a4f0 	uxtl2	v16.2d, v7.4s
    40205450:	2f20a4d1 	uxtl	v17.2d, v6.2s
    40205454:	6f20a4c6 	uxtl2	v6.2d, v6.4s
    40205458:	2f20a4e7 	uxtl	v7.2d, v7.2s
    4020545c:	4e251e10 	and	v16.16b, v16.16b, v5.16b
    40205460:	4e251e31 	and	v17.16b, v17.16b, v5.16b
    40205464:	4e251cc6 	and	v6.16b, v6.16b, v5.16b
    40205468:	4e251ce7 	and	v7.16b, v7.16b, v5.16b
    4020546c:	4ef08484 	add	v4.2d, v4.2d, v16.2d
    40205470:	4ee68463 	add	v3.2d, v3.2d, v6.2d
    40205474:	4ef18400 	add	v0.2d, v0.2d, v17.2d
    40205478:	4ee78421 	add	v1.2d, v1.2d, v7.2d
    4020547c:	54fffb61 	b.ne	402053e8 <core::str::count::do_count_chars+0x6c8>  // b.any
    40205480:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    40205484:	4ee48461 	add	v1.2d, v3.2d, v4.2d
    40205488:	eb09003f 	cmp	x1, x9
    4020548c:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    40205490:	5ef1b800 	addp	d0, v0.2d
    40205494:	9e660008 	fmov	x8, d0
    40205498:	54ffcc80 	b.eq	40204e28 <core::str::count::do_count_chars+0x108>  // b.none
    4020549c:	cb09002a 	sub	x10, x1, x9
    402054a0:	8b090009 	add	x9, x0, x9
    402054a4:	38c0152b 	ldrsb	w11, [x9], #1
    402054a8:	3101057f 	cmn	w11, #0x41
    402054ac:	9a88d508 	cinc	x8, x8, gt
    402054b0:	f100054a 	subs	x10, x10, #0x1
    402054b4:	54ffff81 	b.ne	402054a4 <core::str::count::do_count_chars+0x784>  // b.any
    402054b8:	17fffe5c 	b	40204e28 <core::str::count::do_count_chars+0x108>

00000000402054bc <core::panicking::panic_const::panic_const_div_by_zero>:
    402054bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    402054c0:	910003fd 	mov	x29, sp
    402054c4:	aa0003e2 	mov	x2, x0
    402054c8:	d503201f 	nop
    402054cc:	10006260 	adr	x0, 40206118 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.3164296782144938743+0xf8>
    402054d0:	52800661 	mov	w1, #0x33                  	// #51
    402054d4:	97fffe09 	bl	40204cf8 <core::panicking::panic_fmt>

00000000402054d8 <core::panicking::panic_const::panic_const_rem_by_zero>:
    402054d8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    402054dc:	910003fd 	mov	x29, sp
    402054e0:	aa0003e2 	mov	x2, x0
    402054e4:	d503201f 	nop
    402054e8:	30006240 	adr	x0, 40206131 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.3164296782144938743+0x111>
    402054ec:	52800e61 	mov	w1, #0x73                  	// #115
    402054f0:	97fffe02 	bl	40204cf8 <core::panicking::panic_fmt>

00000000402054f4 <<core::fmt::Formatter>::pad_integral::write_prefix>:
    402054f4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    402054f8:	a90157f6 	stp	x22, x21, [sp, #16]
    402054fc:	a9024ff4 	stp	x20, x19, [sp, #32]
    40205500:	910003fd 	mov	x29, sp
    40205504:	aa0403f3 	mov	x19, x4
    40205508:	aa0303f4 	mov	x20, x3
    4020550c:	aa0103f5 	mov	x21, x1
    40205510:	7144405f 	cmp	w2, #0x110, lsl #12
    40205514:	540001a0 	b.eq	40205548 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>  // b.none
    40205518:	f94012a8 	ldr	x8, [x21, #32]
    4020551c:	2a0203e1 	mov	w1, w2
    40205520:	aa0003f6 	mov	x22, x0
    40205524:	d63f0100 	blr	x8
    40205528:	2a0003e8 	mov	w8, w0
    4020552c:	aa1603e0 	mov	x0, x22
    40205530:	360000c8 	tbz	w8, #0, 40205548 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>
    40205534:	52800020 	mov	w0, #0x1                   	// #1
    40205538:	a9424ff4 	ldp	x20, x19, [sp, #32]
    4020553c:	a94157f6 	ldp	x22, x21, [sp, #16]
    40205540:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40205544:	d65f03c0 	ret
    40205548:	b4000114 	cbz	x20, 40205568 <<core::fmt::Formatter>::pad_integral::write_prefix+0x74>
    4020554c:	f9400ea3 	ldr	x3, [x21, #24]
    40205550:	aa1403e1 	mov	x1, x20
    40205554:	aa1303e2 	mov	x2, x19
    40205558:	a9424ff4 	ldp	x20, x19, [sp, #32]
    4020555c:	a94157f6 	ldp	x22, x21, [sp, #16]
    40205560:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40205564:	d61f0060 	br	x3
    40205568:	2a1f03e0 	mov	w0, wzr
    4020556c:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40205570:	a94157f6 	ldp	x22, x21, [sp, #16]
    40205574:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40205578:	d65f03c0 	ret

000000004020557c <<u64 as core::fmt::Display>::fmt>:
    4020557c:	d100c3ff 	sub	sp, sp, #0x30
    40205580:	a9027bfd 	stp	x29, x30, [sp, #32]
    40205584:	910083fd 	add	x29, sp, #0x20
    40205588:	f9400009 	ldr	x9, [x0]
    4020558c:	d503201f 	nop
    40205590:	10005608 	adr	x8, 40206050 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.3164296782144938743+0x30>
    40205594:	f10fa13f 	cmp	x9, #0x3e8
    40205598:	540004e3 	b.cc	40205634 <<u64 as core::fmt::Display>::fmt+0xb8>  // b.lo, b.ul, b.last
    4020559c:	d28b296c 	mov	x12, #0x594b                	// #22859
    402055a0:	910033ea 	add	x10, sp, #0xc
    402055a4:	5292cff1 	mov	w17, #0x967f                	// #38527
    402055a8:	f2a710cc 	movk	x12, #0x3886, lsl #16
    402055ac:	9280026b 	mov	x11, #0xffffffffffffffec    	// #-20
    402055b0:	5284e20d 	mov	w13, #0x2710                	// #10000
    402055b4:	f2d8bacc 	movk	x12, #0xc5d6, lsl #32
    402055b8:	52828f6e 	mov	w14, #0x147b                	// #5243
    402055bc:	91004d4f 	add	x15, x10, #0x13
    402055c0:	f2e68dac 	movk	x12, #0x346d, lsl #48
    402055c4:	52800c90 	mov	w16, #0x64                  	// #100
    402055c8:	72a01311 	movk	w17, #0x98, lsl #16
    402055cc:	aa0903ea 	mov	x10, x9
    402055d0:	aa0a03f2 	mov	x18, x10
    402055d4:	9bcc7d4a 	umulh	x10, x10, x12
    402055d8:	9100116b 	add	x11, x11, #0x4
    402055dc:	eb11025f 	cmp	x18, x17
    402055e0:	d34bfd4a 	lsr	x10, x10, #11
    402055e4:	1b0dc940 	msub	w0, w10, w13, w18
    402055e8:	53023c02 	ubfx	w2, w0, #2, #14
    402055ec:	1b0e7c42 	mul	w2, w2, w14
    402055f0:	53117c42 	lsr	w2, w2, #17
    402055f4:	1b108040 	msub	w0, w2, w16, w0
    402055f8:	8b224502 	add	x2, x8, w2, uxtw #1
    402055fc:	39400043 	ldrb	w3, [x2]
    40205600:	39400442 	ldrb	w2, [x2, #1]
    40205604:	8b202500 	add	x0, x8, w0, uxth #1
    40205608:	381fd1e3 	sturb	w3, [x15, #-3]
    4020560c:	39400003 	ldrb	w3, [x0]
    40205610:	39400400 	ldrb	w0, [x0, #1]
    40205614:	381fe1e2 	sturb	w2, [x15, #-2]
    40205618:	381ff1e3 	sturb	w3, [x15, #-1]
    4020561c:	381fc5e0 	strb	w0, [x15], #-4
    40205620:	54fffd88 	b.hi	402055d0 <<u64 as core::fmt::Display>::fmt+0x54>  // b.pmore
    40205624:	cb0b03eb 	neg	x11, x11
    40205628:	f100255f 	cmp	x10, #0x9
    4020562c:	540000c8 	b.hi	40205644 <<u64 as core::fmt::Display>::fmt+0xc8>  // b.pmore
    40205630:	14000015 	b	40205684 <<u64 as core::fmt::Display>::fmt+0x108>
    40205634:	5280028b 	mov	w11, #0x14                  	// #20
    40205638:	aa0903ea 	mov	x10, x9
    4020563c:	f100253f 	cmp	x9, #0x9
    40205640:	54000229 	b.ls	40205684 <<u64 as core::fmt::Display>::fmt+0x108>  // b.plast
    40205644:	53023d4c 	ubfx	w12, w10, #2, #14
    40205648:	52828f6d 	mov	w13, #0x147b                	// #5243
    4020564c:	910033ef 	add	x15, sp, #0xc
    40205650:	1b0d7d8c 	mul	w12, w12, w13
    40205654:	52800c8d 	mov	w13, #0x64                  	// #100
    40205658:	53117d8c 	lsr	w12, w12, #17
    4020565c:	1b0da98a 	msub	w10, w12, w13, w10
    40205660:	d100096d 	sub	x13, x11, #0x2
    40205664:	8b0b01eb 	add	x11, x15, x11
    40205668:	8b2a250a 	add	x10, x8, w10, uxth #1
    4020566c:	3940014e 	ldrb	w14, [x10]
    40205670:	3940054a 	ldrb	w10, [x10, #1]
    40205674:	382d69ee 	strb	w14, [x15, x13]
    40205678:	381ff16a 	sturb	w10, [x11, #-1]
    4020567c:	aa0c03ea 	mov	x10, x12
    40205680:	aa0d03eb 	mov	x11, x13
    40205684:	b4000049 	cbz	x9, 4020568c <<u64 as core::fmt::Display>::fmt+0x110>
    40205688:	b40000ca 	cbz	x10, 402056a0 <<u64 as core::fmt::Display>::fmt+0x124>
    4020568c:	8b0a0508 	add	x8, x8, x10, lsl #1
    40205690:	d100056b 	sub	x11, x11, #0x1
    40205694:	910033e9 	add	x9, sp, #0xc
    40205698:	39400508 	ldrb	w8, [x8, #1]
    4020569c:	382b6928 	strb	w8, [x9, x11]
    402056a0:	52800288 	mov	w8, #0x14                  	// #20
    402056a4:	aa0103e0 	mov	x0, x1
    402056a8:	52800021 	mov	w1, #0x1                   	// #1
    402056ac:	cb0b0105 	sub	x5, x8, x11
    402056b0:	910033e8 	add	x8, sp, #0xc
    402056b4:	52800022 	mov	w2, #0x1                   	// #1
    402056b8:	8b0b0104 	add	x4, x8, x11
    402056bc:	aa1f03e3 	mov	x3, xzr
    402056c0:	97fffc5a 	bl	40204828 <<core::fmt::Formatter>::pad_integral>
    402056c4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    402056c8:	9100c3ff 	add	sp, sp, #0x30
    402056cc:	d65f03c0 	ret

00000000402056d0 <__udivti3>:
    402056d0:	d100c3ff 	sub	sp, sp, #0x30
    402056d4:	a9027bfd 	stp	x29, x30, [sp, #32]
    402056d8:	910083fd 	add	x29, sp, #0x20
    402056dc:	910003e8 	mov	x8, sp
    402056e0:	94000005 	bl	402056f4 <compiler_builtins::int::specialized_div_rem::u128_div_rem>
    402056e4:	a94007e0 	ldp	x0, x1, [sp]
    402056e8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    402056ec:	9100c3ff 	add	sp, sp, #0x30
    402056f0:	d65f03c0 	ret

00000000402056f4 <compiler_builtins::int::specialized_div_rem::u128_div_rem>:
    402056f4:	dac01049 	clz	x9, x2
    402056f8:	dac0106a 	clz	x10, x3
    402056fc:	f100007f 	cmp	x3, #0x0
    40205700:	11010129 	add	w9, w9, #0x40
    40205704:	dac0100c 	clz	x12, x0
    40205708:	1a89114b 	csel	w11, w10, w9, ne  // ne = any
    4020570c:	dac01029 	clz	x9, x1
    40205710:	1101018a 	add	w10, w12, #0x40
    40205714:	f100003f 	cmp	x1, #0x0
    40205718:	1a8a112f 	csel	w15, w9, w10, ne  // ne = any
    4020571c:	6b0f0169 	subs	w9, w11, w15
    40205720:	54000149 	b.ls	40205748 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x54>  // b.plast
    40205724:	7100fdff 	cmp	w15, #0x3f
    40205728:	540001c9 	b.ls	40205760 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x6c>  // b.plast
    4020572c:	9ac20809 	udiv	x9, x0, x2
    40205730:	aa1f03ea 	mov	x10, xzr
    40205734:	aa1f03e1 	mov	x1, xzr
    40205738:	9b028120 	msub	x0, x9, x2, x0
    4020573c:	a9002909 	stp	x9, x10, [x8]
    40205740:	a9010500 	stp	x0, x1, [x8, #16]
    40205744:	d65f03c0 	ret
    40205748:	eb02001f 	cmp	x0, x2
    4020574c:	fa03003f 	sbcs	xzr, x1, x3
    40205750:	54000282 	b.cs	402057a0 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0xac>  // b.hs, b.nlast
    40205754:	a9007d1f 	stp	xzr, xzr, [x8]
    40205758:	a9010500 	stp	x0, x1, [x8, #16]
    4020575c:	d65f03c0 	ret
    40205760:	71017d7f 	cmp	w11, #0x5f
    40205764:	540002a9 	b.ls	402057b8 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0xc4>  // b.plast
    40205768:	2a0203e9 	mov	w9, w2
    4020576c:	9ac9082a 	udiv	x10, x1, x9
    40205770:	1b02854b 	msub	w11, w10, w2, w1
    40205774:	93c0816b 	extr	x11, x11, x0, #32
    40205778:	9ac9096c 	udiv	x12, x11, x9
    4020577c:	1b02ad8b 	msub	w11, w12, w2, w11
    40205780:	aa4c814a 	orr	x10, x10, x12, lsr #32
    40205784:	b3607d60 	bfi	x0, x11, #32, #32
    40205788:	9ac9080b 	udiv	x11, x0, x9
    4020578c:	9b098160 	msub	x0, x11, x9, x0
    40205790:	aa0c8169 	orr	x9, x11, x12, lsl #32
    40205794:	a9002909 	stp	x9, x10, [x8]
    40205798:	a9017d00 	stp	x0, xzr, [x8, #16]
    4020579c:	d65f03c0 	ret
    402057a0:	eb020000 	subs	x0, x0, x2
    402057a4:	52800029 	mov	w9, #0x1                   	// #1
    402057a8:	da030021 	sbc	x1, x1, x3
    402057ac:	a9007d09 	stp	x9, xzr, [x8]
    402057b0:	a9010500 	stp	x0, x1, [x8, #16]
    402057b4:	d65f03c0 	ret
    402057b8:	7100813f 	cmp	w9, #0x20
    402057bc:	54000422 	b.cs	40205840 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x14c>  // b.hs, b.nlast
    402057c0:	d37ff829 	lsl	x9, x1, #1
    402057c4:	5280080a 	mov	w10, #0x40                  	// #64
    402057c8:	d37ff86c 	lsl	x12, x3, #1
    402057cc:	510005eb 	sub	w11, w15, #0x1
    402057d0:	4b0f014a 	sub	w10, w10, w15
    402057d4:	9acb2129 	lsl	x9, x9, x11
    402057d8:	9aca240d 	lsr	x13, x0, x10
    402057dc:	9acb218b 	lsl	x11, x12, x11
    402057e0:	9aca244c 	lsr	x12, x2, x10
    402057e4:	9aca242e 	lsr	x14, x1, x10
    402057e8:	9aca246f 	lsr	x15, x3, x10
    402057ec:	f27a015f 	tst	x10, #0x40
    402057f0:	aa0d0129 	orr	x9, x9, x13
    402057f4:	aa0c016a 	orr	x10, x11, x12
    402057f8:	9a8911c9 	csel	x9, x14, x9, ne  // ne = any
    402057fc:	9a8a11ea 	csel	x10, x15, x10, ne  // ne = any
    40205800:	9aca0929 	udiv	x9, x9, x10
    40205804:	9bc97c4a 	umulh	x10, x2, x9
    40205808:	9b097c6b 	mul	x11, x3, x9
    4020580c:	9bc97c6d 	umulh	x13, x3, x9
    40205810:	9b097c4c 	mul	x12, x2, x9
    40205814:	ab0b014b 	adds	x11, x10, x11
    40205818:	9a8d35aa 	cinc	x10, x13, cs  // cs = hs, nlast
    4020581c:	b500090a 	cbnz	x10, 4020593c <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x248>
    40205820:	eb0c001f 	cmp	x0, x12
    40205824:	fa0b003f 	sbcs	xzr, x1, x11
    40205828:	540008a3 	b.cc	4020593c <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x248>  // b.lo, b.ul, b.last
    4020582c:	eb0c0000 	subs	x0, x0, x12
    40205830:	da0b0021 	sbc	x1, x1, x11
    40205834:	a9007d09 	stp	x9, xzr, [x8]
    40205838:	a9010500 	stp	x0, x1, [x8, #16]
    4020583c:	d65f03c0 	ret
    40205840:	52800c0d 	mov	w13, #0x60                  	// #96
    40205844:	d37ff86c 	lsl	x12, x3, #1
    40205848:	5101856e 	sub	w14, w11, #0x61
    4020584c:	4b0b01ad 	sub	w13, w13, w11
    40205850:	aa1f03e9 	mov	x9, xzr
    40205854:	aa1f03ea 	mov	x10, xzr
    40205858:	9ace218e 	lsl	x14, x12, x14
    4020585c:	9acd2450 	lsr	x16, x2, x13
    40205860:	9acd2471 	lsr	x17, x3, x13
    40205864:	f27a01bf 	tst	x13, #0x40
    40205868:	aa1001ce 	orr	x14, x14, x16
    4020586c:	52800810 	mov	w16, #0x40                  	// #64
    40205870:	9a8e122e 	csel	x14, x17, x14, ne  // ne = any
    40205874:	2a0e03ee 	mov	w14, w14
    40205878:	910005ce 	add	x14, x14, #0x1
    4020587c:	d37ff832 	lsl	x18, x1, #1
    40205880:	4b0f0211 	sub	w17, w16, w15
    40205884:	510005ef 	sub	w15, w15, #0x1
    40205888:	9ad12424 	lsr	x4, x1, x17
    4020588c:	f27a023f 	tst	x17, #0x40
    40205890:	9acf224f 	lsl	x15, x18, x15
    40205894:	9ad12412 	lsr	x18, x0, x17
    40205898:	aa1201ef 	orr	x15, x15, x18
    4020589c:	9a8f1092 	csel	x18, x4, x15, ne  // ne = any
    402058a0:	6b0d022f 	subs	w15, w17, w13
    402058a4:	540005c3 	b.cc	4020595c <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x268>  // b.lo, b.ul, b.last
    402058a8:	9ace0a51 	udiv	x17, x18, x14
    402058ac:	2a2f03e6 	mvn	w6, w15
    402058b0:	f27a01ff 	tst	x15, #0x40
    402058b4:	9bd17c52 	umulh	x18, x2, x17
    402058b8:	d341fe25 	lsr	x5, x17, #1
    402058bc:	9b117c44 	mul	x4, x2, x17
    402058c0:	9ac624a5 	lsr	x5, x5, x6
    402058c4:	9b114872 	madd	x18, x3, x17, x18
    402058c8:	9acf2231 	lsl	x17, x17, x15
    402058cc:	d341fc87 	lsr	x7, x4, #1
    402058d0:	9ac624e6 	lsr	x6, x7, x6
    402058d4:	9acf2252 	lsl	x18, x18, x15
    402058d8:	9acf208f 	lsl	x15, x4, x15
    402058dc:	9a851224 	csel	x4, x17, x5, ne  // ne = any
    402058e0:	9a9113f1 	csel	x17, xzr, x17, ne  // ne = any
    402058e4:	aa060252 	orr	x18, x18, x6
    402058e8:	9a9211f2 	csel	x18, x15, x18, ne  // ne = any
    402058ec:	9a8f13ef 	csel	x15, xzr, x15, ne  // ne = any
    402058f0:	ab090229 	adds	x9, x17, x9
    402058f4:	9a0a008a 	adc	x10, x4, x10
    402058f8:	eb0f0000 	subs	x0, x0, x15
    402058fc:	fa120021 	sbcs	x1, x1, x18
    40205900:	dac0100f 	clz	x15, x0
    40205904:	dac01031 	clz	x17, x1
    40205908:	110101ef 	add	w15, w15, #0x40
    4020590c:	1a8f122f 	csel	w15, w17, w15, ne  // ne = any
    40205910:	6b0f017f 	cmp	w11, w15
    40205914:	54000549 	b.ls	402059bc <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x2c8>  // b.plast
    40205918:	7100fdff 	cmp	w15, #0x3f
    4020591c:	54fffb09 	b.ls	4020587c <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x188>  // b.plast
    40205920:	9ac2080b 	udiv	x11, x0, x2
    40205924:	9b028160 	msub	x0, x11, x2, x0
    40205928:	ab0b0129 	adds	x9, x9, x11
    4020592c:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    40205930:	a9002909 	stp	x9, x10, [x8]
    40205934:	a9017d00 	stp	x0, xzr, [x8, #16]
    40205938:	d65f03c0 	ret
    4020593c:	ab00004d 	adds	x13, x2, x0
    40205940:	d1000529 	sub	x9, x9, #0x1
    40205944:	9a01006e 	adc	x14, x3, x1
    40205948:	eb0c01a0 	subs	x0, x13, x12
    4020594c:	da0b01c1 	sbc	x1, x14, x11
    40205950:	a9007d09 	stp	x9, xzr, [x8]
    40205954:	a9010500 	stp	x0, x1, [x8, #16]
    40205958:	d65f03c0 	ret
    4020595c:	2a3103eb 	mvn	w11, w17
    40205960:	9ad1244d 	lsr	x13, x2, x17
    40205964:	f27a023f 	tst	x17, #0x40
    40205968:	9acb218b 	lsl	x11, x12, x11
    4020596c:	9ad1246c 	lsr	x12, x3, x17
    40205970:	aa0d016b 	orr	x11, x11, x13
    40205974:	9a8b118b 	csel	x11, x12, x11, ne  // ne = any
    40205978:	9acb0a4d 	udiv	x13, x18, x11
    4020597c:	9bcd7c4b 	umulh	x11, x2, x13
    40205980:	9b0d7c4c 	mul	x12, x2, x13
    40205984:	9b0d2c6b 	madd	x11, x3, x13, x11
    40205988:	eb0c001f 	cmp	x0, x12
    4020598c:	fa0b003f 	sbcs	xzr, x1, x11
    40205990:	540002a2 	b.cs	402059e4 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x2f0>  // b.hs, b.nlast
    40205994:	d10005ad 	sub	x13, x13, #0x1
    40205998:	ab0d0129 	adds	x9, x9, x13
    4020599c:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    402059a0:	ab02000d 	adds	x13, x0, x2
    402059a4:	9a03002e 	adc	x14, x1, x3
    402059a8:	eb0c01a0 	subs	x0, x13, x12
    402059ac:	da0b01c1 	sbc	x1, x14, x11
    402059b0:	a9002909 	stp	x9, x10, [x8]
    402059b4:	a9010500 	stp	x0, x1, [x8, #16]
    402059b8:	d65f03c0 	ret
    402059bc:	eb02001f 	cmp	x0, x2
    402059c0:	fa03003f 	sbcs	xzr, x1, x3
    402059c4:	54ffebc3 	b.cc	4020573c <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x48>  // b.lo, b.ul, b.last
    402059c8:	b1000529 	adds	x9, x9, #0x1
    402059cc:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    402059d0:	eb020000 	subs	x0, x0, x2
    402059d4:	da030021 	sbc	x1, x1, x3
    402059d8:	a9002909 	stp	x9, x10, [x8]
    402059dc:	a9010500 	stp	x0, x1, [x8, #16]
    402059e0:	d65f03c0 	ret
    402059e4:	ab0d0129 	adds	x9, x9, x13
    402059e8:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    402059ec:	eb0c0000 	subs	x0, x0, x12
    402059f0:	da0b0021 	sbc	x1, x1, x11
    402059f4:	a9002909 	stp	x9, x10, [x8]
    402059f8:	a9010500 	stp	x0, x1, [x8, #16]
    402059fc:	d65f03c0 	ret

0000000040205a00 <memcpy>:
    40205a00:	f100405f 	cmp	x2, #0x10
    40205a04:	54000723 	b.cc	40205ae8 <memcpy+0xe8>  // b.lo, b.ul, b.last
    40205a08:	cb0003ec 	neg	x12, x0
    40205a0c:	92400988 	and	x8, x12, #0x7
    40205a10:	8b080009 	add	x9, x0, x8
    40205a14:	eb09001f 	cmp	x0, x9
    40205a18:	54000422 	b.cs	40205a9c <memcpy+0x9c>  // b.hs, b.nlast
    40205a1c:	f100111f 	cmp	x8, #0x4
    40205a20:	aa0003ea 	mov	x10, x0
    40205a24:	aa0103eb 	mov	x11, x1
    40205a28:	54000323 	b.cc	40205a8c <memcpy+0x8c>  // b.lo, b.ul, b.last
    40205a2c:	cb01000a 	sub	x10, x0, x1
    40205a30:	aa0103eb 	mov	x11, x1
    40205a34:	f100815f 	cmp	x10, #0x20
    40205a38:	aa0003ea 	mov	x10, x0
    40205a3c:	54000283 	b.cc	40205a8c <memcpy+0x8c>  // b.lo, b.ul, b.last
    40205a40:	927e018c 	and	x12, x12, #0x4
    40205a44:	aa0003ed 	mov	x13, x0
    40205a48:	aa0103ee 	mov	x14, x1
    40205a4c:	8b0c000a 	add	x10, x0, x12
    40205a50:	8b0c002b 	add	x11, x1, x12
    40205a54:	aa0c03ef 	mov	x15, x12
    40205a58:	39400dd0 	ldrb	w16, [x14, #3]
    40205a5c:	394009d1 	ldrb	w17, [x14, #2]
    40205a60:	f10011ef 	subs	x15, x15, #0x4
    40205a64:	394001d2 	ldrb	w18, [x14]
    40205a68:	394005c3 	ldrb	w3, [x14, #1]
    40205a6c:	910011ce 	add	x14, x14, #0x4
    40205a70:	39000db0 	strb	w16, [x13, #3]
    40205a74:	390009b1 	strb	w17, [x13, #2]
    40205a78:	390005a3 	strb	w3, [x13, #1]
    40205a7c:	380045b2 	strb	w18, [x13], #4
    40205a80:	54fffec1 	b.ne	40205a58 <memcpy+0x58>  // b.any
    40205a84:	eb0c011f 	cmp	x8, x12
    40205a88:	540000a0 	b.eq	40205a9c <memcpy+0x9c>  // b.none
    40205a8c:	3840156c 	ldrb	w12, [x11], #1
    40205a90:	3800154c 	strb	w12, [x10], #1
    40205a94:	eb09015f 	cmp	x10, x9
    40205a98:	54ffffa1 	b.ne	40205a8c <memcpy+0x8c>  // b.any
    40205a9c:	cb08004b 	sub	x11, x2, x8
    40205aa0:	8b08002a 	add	x10, x1, x8
    40205aa4:	927df16c 	and	x12, x11, #0xfffffffffffffff8
    40205aa8:	f240095f 	tst	x10, #0x7
    40205aac:	8b0c0128 	add	x8, x9, x12
    40205ab0:	540007a1 	b.ne	40205ba4 <memcpy+0x1a4>  // b.any
    40205ab4:	eb08013f 	cmp	x9, x8
    40205ab8:	540000c2 	b.cs	40205ad0 <memcpy+0xd0>  // b.hs, b.nlast
    40205abc:	aa0a03ed 	mov	x13, x10
    40205ac0:	f84085ae 	ldr	x14, [x13], #8
    40205ac4:	f800852e 	str	x14, [x9], #8
    40205ac8:	eb08013f 	cmp	x9, x8
    40205acc:	54ffffa3 	b.cc	40205ac0 <memcpy+0xc0>  // b.lo, b.ul, b.last
    40205ad0:	8b0c0141 	add	x1, x10, x12
    40205ad4:	92400962 	and	x2, x11, #0x7
    40205ad8:	8b020109 	add	x9, x8, x2
    40205adc:	eb09011f 	cmp	x8, x9
    40205ae0:	540000c3 	b.cc	40205af8 <memcpy+0xf8>  // b.lo, b.ul, b.last
    40205ae4:	1400002f 	b	40205ba0 <memcpy+0x1a0>
    40205ae8:	aa0003e8 	mov	x8, x0
    40205aec:	8b020009 	add	x9, x0, x2
    40205af0:	eb09001f 	cmp	x0, x9
    40205af4:	54000562 	b.cs	40205ba0 <memcpy+0x1a0>  // b.hs, b.nlast
    40205af8:	f100105f 	cmp	x2, #0x4
    40205afc:	540004a3 	b.cc	40205b90 <memcpy+0x190>  // b.lo, b.ul, b.last
    40205b00:	cb01010a 	sub	x10, x8, x1
    40205b04:	f100815f 	cmp	x10, #0x20
    40205b08:	54000443 	b.cc	40205b90 <memcpy+0x190>  // b.lo, b.ul, b.last
    40205b0c:	39400c2a 	ldrb	w10, [x1, #3]
    40205b10:	3940082b 	ldrb	w11, [x1, #2]
    40205b14:	3940002c 	ldrb	w12, [x1]
    40205b18:	3940042d 	ldrb	w13, [x1, #1]
    40205b1c:	39000d0a 	strb	w10, [x8, #3]
    40205b20:	927e044a 	and	x10, x2, #0xc
    40205b24:	f100115f 	cmp	x10, #0x4
    40205b28:	3900090b 	strb	w11, [x8, #2]
    40205b2c:	3900050d 	strb	w13, [x8, #1]
    40205b30:	3900010c 	strb	w12, [x8]
    40205b34:	54000260 	b.eq	40205b80 <memcpy+0x180>  // b.none
    40205b38:	39401c2b 	ldrb	w11, [x1, #7]
    40205b3c:	3940182c 	ldrb	w12, [x1, #6]
    40205b40:	f100215f 	cmp	x10, #0x8
    40205b44:	3940102d 	ldrb	w13, [x1, #4]
    40205b48:	3940142e 	ldrb	w14, [x1, #5]
    40205b4c:	39001d0b 	strb	w11, [x8, #7]
    40205b50:	3900190c 	strb	w12, [x8, #6]
    40205b54:	3900150e 	strb	w14, [x8, #5]
    40205b58:	3900110d 	strb	w13, [x8, #4]
    40205b5c:	54000120 	b.eq	40205b80 <memcpy+0x180>  // b.none
    40205b60:	39402c2b 	ldrb	w11, [x1, #11]
    40205b64:	3940282c 	ldrb	w12, [x1, #10]
    40205b68:	3940202d 	ldrb	w13, [x1, #8]
    40205b6c:	3940242e 	ldrb	w14, [x1, #9]
    40205b70:	39002d0b 	strb	w11, [x8, #11]
    40205b74:	3900290c 	strb	w12, [x8, #10]
    40205b78:	3900250e 	strb	w14, [x8, #9]
    40205b7c:	3900210d 	strb	w13, [x8, #8]
    40205b80:	eb0a005f 	cmp	x2, x10
    40205b84:	540000e0 	b.eq	40205ba0 <memcpy+0x1a0>  // b.none
    40205b88:	8b0a0108 	add	x8, x8, x10
    40205b8c:	8b0a0021 	add	x1, x1, x10
    40205b90:	3840142a 	ldrb	w10, [x1], #1
    40205b94:	3800150a 	strb	w10, [x8], #1
    40205b98:	eb09011f 	cmp	x8, x9
    40205b9c:	54ffffa1 	b.ne	40205b90 <memcpy+0x190>  // b.any
    40205ba0:	d65f03c0 	ret
    40205ba4:	eb08013f 	cmp	x9, x8
    40205ba8:	54fff942 	b.cs	40205ad0 <memcpy+0xd0>  // b.hs, b.nlast
    40205bac:	aa0a03ed 	mov	x13, x10
    40205bb0:	aa0d03f0 	mov	x16, x13
    40205bb4:	394009af 	ldrb	w15, [x13, #2]
    40205bb8:	394005ae 	ldrb	w14, [x13, #1]
    40205bbc:	38404e11 	ldrb	w17, [x16, #4]!
    40205bc0:	39400a12 	ldrb	w18, [x16, #2]
    40205bc4:	394001a1 	ldrb	w1, [x13]
    40205bc8:	39400da2 	ldrb	w2, [x13, #3]
    40205bcc:	d370bdef 	lsl	x15, x15, #16
    40205bd0:	394015a3 	ldrb	w3, [x13, #5]
    40205bd4:	39400e10 	ldrb	w16, [x16, #3]
    40205bd8:	53103e52 	lsl	w18, w18, #16
    40205bdc:	aa0e202e 	orr	x14, x1, x14, lsl #8
    40205be0:	aa0261ef 	orr	x15, x15, x2, lsl #24
    40205be4:	910021ad 	add	x13, x13, #0x8
    40205be8:	2a032231 	orr	w17, w17, w3, lsl #8
    40205bec:	2a106250 	orr	w16, w18, w16, lsl #24
    40205bf0:	aa0e01ee 	orr	x14, x15, x14
    40205bf4:	2a11020f 	orr	w15, w16, w17
    40205bf8:	aa0f81ce 	orr	x14, x14, x15, lsl #32
    40205bfc:	f800852e 	str	x14, [x9], #8
    40205c00:	eb08013f 	cmp	x9, x8
    40205c04:	54fffd63 	b.cc	40205bb0 <memcpy+0x1b0>  // b.lo, b.ul, b.last
    40205c08:	17ffffb2 	b	40205ad0 <memcpy+0xd0>

0000000040205c0c <__umodti3>:
    40205c0c:	d100c3ff 	sub	sp, sp, #0x30
    40205c10:	a9027bfd 	stp	x29, x30, [sp, #32]
    40205c14:	910083fd 	add	x29, sp, #0x20
    40205c18:	910003e8 	mov	x8, sp
    40205c1c:	97fffeb6 	bl	402056f4 <compiler_builtins::int::specialized_div_rem::u128_div_rem>
    40205c20:	a94107e0 	ldp	x0, x1, [sp, #16]
    40205c24:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40205c28:	9100c3ff 	add	sp, sp, #0x30
    40205c2c:	d65f03c0 	ret

0000000040205c30 <memset>:
    40205c30:	f100405f 	cmp	x2, #0x10
    40205c34:	540009e3 	b.cc	40205d70 <memset+0x140>  // b.lo, b.ul, b.last
    40205c38:	cb0003eb 	neg	x11, x0
    40205c3c:	92400968 	and	x8, x11, #0x7
    40205c40:	8b080009 	add	x9, x0, x8
    40205c44:	eb09001f 	cmp	x0, x9
    40205c48:	54000302 	b.cs	40205ca8 <memset+0x78>  // b.hs, b.nlast
    40205c4c:	f100111f 	cmp	x8, #0x4
    40205c50:	aa0003ea 	mov	x10, x0
    40205c54:	54000243 	b.cc	40205c9c <memset+0x6c>  // b.lo, b.ul, b.last
    40205c58:	0e020c20 	dup	v0.4h, w1
    40205c5c:	927e016b 	and	x11, x11, #0x4
    40205c60:	aa0003ec 	mov	x12, x0
    40205c64:	8b0b000a 	add	x10, x0, x11
    40205c68:	aa0b03ed 	mov	x13, x11
    40205c6c:	5e0e0401 	mov	h1, v0.h[3]
    40205c70:	5e0a0402 	mov	h2, v0.h[2]
    40205c74:	5e060403 	mov	h3, v0.h[1]
    40205c78:	3d000180 	str	b0, [x12]
    40205c7c:	f10011ad 	subs	x13, x13, #0x4
    40205c80:	3c003181 	stur	b1, [x12, #3]
    40205c84:	3c002182 	stur	b2, [x12, #2]
    40205c88:	3c001183 	stur	b3, [x12, #1]
    40205c8c:	9100118c 	add	x12, x12, #0x4
    40205c90:	54ffff41 	b.ne	40205c78 <memset+0x48>  // b.any
    40205c94:	eb0b011f 	cmp	x8, x11
    40205c98:	54000080 	b.eq	40205ca8 <memset+0x78>  // b.none
    40205c9c:	38001541 	strb	w1, [x10], #1
    40205ca0:	eb09015f 	cmp	x10, x9
    40205ca4:	54ffffc1 	b.ne	40205c9c <memset+0x6c>  // b.any
    40205ca8:	cb08004a 	sub	x10, x2, x8
    40205cac:	927df148 	and	x8, x10, #0xfffffffffffffff8
    40205cb0:	8b080128 	add	x8, x9, x8
    40205cb4:	eb08013f 	cmp	x9, x8
    40205cb8:	54000102 	b.cs	40205cd8 <memset+0xa8>  // b.hs, b.nlast
    40205cbc:	12001c2b 	and	w11, w1, #0xff
    40205cc0:	3200c3ec 	mov	w12, #0x1010101             	// #16843009
    40205cc4:	1b0c7d6b 	mul	w11, w11, w12
    40205cc8:	aa0b816b 	orr	x11, x11, x11, lsl #32
    40205ccc:	f800852b 	str	x11, [x9], #8
    40205cd0:	eb08013f 	cmp	x9, x8
    40205cd4:	54ffffc3 	b.cc	40205ccc <memset+0x9c>  // b.lo, b.ul, b.last
    40205cd8:	92400942 	and	x2, x10, #0x7
    40205cdc:	8b020109 	add	x9, x8, x2
    40205ce0:	eb09011f 	cmp	x8, x9
    40205ce4:	54000442 	b.cs	40205d6c <memset+0x13c>  // b.hs, b.nlast
    40205ce8:	f100105f 	cmp	x2, #0x4
    40205cec:	540003a3 	b.cc	40205d60 <memset+0x130>  // b.lo, b.ul, b.last
    40205cf0:	927e044a 	and	x10, x2, #0xc
    40205cf4:	39000d01 	strb	w1, [x8, #3]
    40205cf8:	f100115f 	cmp	x10, #0x4
    40205cfc:	8b0a010b 	add	x11, x8, x10
    40205d00:	39000901 	strb	w1, [x8, #2]
    40205d04:	39000501 	strb	w1, [x8, #1]
    40205d08:	39000101 	strb	w1, [x8]
    40205d0c:	54000240 	b.eq	40205d54 <memset+0x124>  // b.none
    40205d10:	0e020c20 	dup	v0.4h, w1
    40205d14:	f100215f 	cmp	x10, #0x8
    40205d18:	5e0e0401 	mov	h1, v0.h[3]
    40205d1c:	5e0a0402 	mov	h2, v0.h[2]
    40205d20:	5e060403 	mov	h3, v0.h[1]
    40205d24:	3c004100 	stur	b0, [x8, #4]
    40205d28:	3c007101 	stur	b1, [x8, #7]
    40205d2c:	3c006102 	stur	b2, [x8, #6]
    40205d30:	3c005103 	stur	b3, [x8, #5]
    40205d34:	54000100 	b.eq	40205d54 <memset+0x124>  // b.none
    40205d38:	5e0e0401 	mov	h1, v0.h[3]
    40205d3c:	5e0a0402 	mov	h2, v0.h[2]
    40205d40:	3c008100 	stur	b0, [x8, #8]
    40205d44:	5e060403 	mov	h3, v0.h[1]
    40205d48:	3c00b101 	stur	b1, [x8, #11]
    40205d4c:	3c00a102 	stur	b2, [x8, #10]
    40205d50:	3c009103 	stur	b3, [x8, #9]
    40205d54:	eb0a005f 	cmp	x2, x10
    40205d58:	aa0b03e8 	mov	x8, x11
    40205d5c:	54000080 	b.eq	40205d6c <memset+0x13c>  // b.none
    40205d60:	38001501 	strb	w1, [x8], #1
    40205d64:	eb09011f 	cmp	x8, x9
    40205d68:	54ffffc1 	b.ne	40205d60 <memset+0x130>  // b.any
    40205d6c:	d65f03c0 	ret
    40205d70:	aa0003e8 	mov	x8, x0
    40205d74:	8b020009 	add	x9, x0, x2
    40205d78:	eb09001f 	cmp	x0, x9
    40205d7c:	54fffb63 	b.cc	40205ce8 <memset+0xb8>  // b.lo, b.ul, b.last
    40205d80:	17fffffb 	b	40205d6c <memset+0x13c>
