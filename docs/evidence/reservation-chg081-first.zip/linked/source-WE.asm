
source-WE.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000040200000 <_start>:
    40200000:	d5034fdf 	msr	daifset, #0xf
    40200004:	d5384240 	mrs	x0, currentel
    40200008:	f100101f 	cmp	x0, #0x4
    4020000c:	54000241 	b.ne	40200054 <_start+0x54>  // b.any
    40200010:	d50041bf 	msr	spsel, #0x1
    40200014:	58000260 	ldr	x0, 40200060 <_start+0x60>
    40200018:	9100001f 	mov	sp, x0
    4020001c:	d5381040 	mrs	x0, cpacr_el1
    40200020:	b26c0400 	orr	x0, x0, #0x300000
    40200024:	d5181040 	msr	cpacr_el1, x0
    40200028:	d5033fdf 	isb
    4020002c:	580001e0 	ldr	x0, 40200068 <_start+0x68>
    40200030:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    40200034:	f9000001 	str	x1, [x0]
    40200038:	580001c0 	ldr	x0, 40200070 <_start+0x70>
    4020003c:	580001e1 	ldr	x1, 40200078 <_start+0x78>
    40200040:	eb01001f 	cmp	x0, x1
    40200044:	54000062 	b.cs	40200050 <_start+0x50>  // b.hs, b.nlast
    40200048:	f800841f 	str	xzr, [x0], #8
    4020004c:	17fffffd 	b	40200040 <_start+0x40>
    40200050:	14001069 	b	402041f4 <jnox_kernel::kernel_main>
    40200054:	d503205f 	wfe
    40200058:	17ffffff 	b	40200054 <_start+0x54>
    4020005c:	00000000 	udf	#0
    40200060:	40227e40 	.word	0x40227e40
    40200064:	00000000 	.word	0x00000000
    40200068:	40223e20 	.word	0x40223e20
    4020006c:	00000000 	.word	0x00000000
    40200070:	40207710 	.word	0x40207710
    40200074:	00000000 	.word	0x00000000
    40200078:	40223e40 	.word	0x40223e40
	...

0000000040200800 <sched_vectors>:
    40200800:	14000200 00000000 00000000 00000000     ................
	...
    40200880:	140001e0 00000000 00000000 00000000     ................
	...
    40200900:	140001c0 00000000 00000000 00000000     ................
	...
    40200980:	140001a0 00000000 00000000 00000000     ................
	...
    40200a00:	140001b6 00000000 00000000 00000000     ................
	...
    40200a80:	14000161 00000000 00000000 00000000     a...............
	...
    40200b00:	14000140 00000000 00000000 00000000     @...............
	...
    40200b80:	14000120 00000000 00000000 00000000      ...............
	...
    40200c00:	14000100 00000000 00000000 00000000     ................
	...
    40200c80:	140000e0 00000000 00000000 00000000     ................
	...
    40200d00:	140000c0 00000000 00000000 00000000     ................
	...
    40200d80:	140000a0 00000000 00000000 00000000     ................
	...
    40200e00:	14000080 00000000 00000000 00000000     ................
	...
    40200e80:	14000060 00000000 00000000 00000000     `...............
	...
    40200f00:	14000040 00000000 00000000 00000000     @...............
	...
    40200f80:	14000020 00000000 00000000 00000000      ...............
	...
    40201000:	140000aa d10d03ff f90027e9 d5033fdf     .........'...?..
    40201010:	d53be029 f9009fe9 f94027e9 a90007e0     ).;......'@.....
    40201020:	a9010fe2 a90217e4 a9031fe6 a90427e8     .............'..
    40201030:	a9052fea a90637ec a9073fee a90847f0     ./...7...?...G..
    40201040:	a9094ff2 a90a57f4 a90b5ff6 a90c67f8     .O...W..._...g..
    40201050:	a90d6ffa a90e77fc f9007bfe ad0a07e0     .o...w...{......
    40201060:	ad0b0fe2 ad0c17e4 ad0d1fe6 ad0e27e8     .............'..
    40201070:	ad0f2fea ad1037ec ad113fee ad1247f0     ./...7...?...G..
    40201080:	ad134ff2 ad1457f4 ad155ff6 ad1667f8     .O...W..._...g..
    40201090:	ad176ffa ad1877fc ad197ffe d5384029     .o...w......)@8.
    402010a0:	d538400a a90fabe9 d53b4409 d53b442a     .@8......D;.*D;.
    402010b0:	a910abe9 d538d089 d538410a a911abe9     ......8..A8.....
    402010c0:	d53bd049 d53bd06a a912abe9 910003e0     I.;.j.;.........
    402010d0:	9400007e 14000036 d10d03ff f90027e9     ~...6........'..
    402010e0:	d5033fdf d53be029 f9009fe9 f94027e9     .?..).;......'@.
    402010f0:	a90007e0 a9010fe2 a90217e4 a9031fe6     ................
    40201100:	a90427e8 a9052fea a90637ec a9073fee     .'.../...7...?..
    40201110:	a90847f0 a9094ff2 a90a57f4 a90b5ff6     .G...O...W..._..
    40201120:	a90c67f8 a90d6ffa a90e77fc f9007bfe     .g...o...w...{..
    40201130:	ad0a07e0 ad0b0fe2 ad0c17e4 ad0d1fe6     ................
    40201140:	ad0e27e8 ad0f2fea ad1037ec ad113fee     .'.../...7...?..
    40201150:	ad1247f0 ad134ff2 ad1457f4 ad155ff6     .G...O...W..._..
    40201160:	ad1667f8 ad176ffa ad1877fc ad197ffe     .g...o...w......
    40201170:	d5384029 d538400a a90fabe9 d53b4409     )@8..@8......D;.
    40201180:	d53b442a a910abe9 d538d089 d538410a     *D;.......8..A8.
    40201190:	a911abe9 d53bd049 d53bd06a a912abe9     ....I.;.j.;.....
    402011a0:	910003e0 940003b6 14000001              ............

00000000402011ac <sched_start_frame>:
    402011ac:	9100001f 	mov	sp, x0
    402011b0:	a94fabe9 	ldp	x9, x10, [sp, #248]
    402011b4:	d5184029 	msr	elr_el1, x9
    402011b8:	d518400a 	msr	spsr_el1, x10
    402011bc:	a950abe9 	ldp	x9, x10, [sp, #264]
    402011c0:	d51b4409 	msr	fpcr, x9
    402011c4:	d51b442a 	msr	fpsr, x10
    402011c8:	a951abe9 	ldp	x9, x10, [sp, #280]
    402011cc:	d518d089 	msr	tpidr_el1, x9
    402011d0:	d518410a 	msr	sp_el0, x10
    402011d4:	a952abe9 	ldp	x9, x10, [sp, #296]
    402011d8:	d51bd049 	msr	tpidr_el0, x9
    402011dc:	d51bd06a 	msr	tpidrro_el0, x10
    402011e0:	ad4a07e0 	ldp	q0, q1, [sp, #320]
    402011e4:	ad4b0fe2 	ldp	q2, q3, [sp, #352]
    402011e8:	ad4c17e4 	ldp	q4, q5, [sp, #384]
    402011ec:	ad4d1fe6 	ldp	q6, q7, [sp, #416]
    402011f0:	ad4e27e8 	ldp	q8, q9, [sp, #448]
    402011f4:	ad4f2fea 	ldp	q10, q11, [sp, #480]
    402011f8:	ad5037ec 	ldp	q12, q13, [sp, #512]
    402011fc:	ad513fee 	ldp	q14, q15, [sp, #544]
    40201200:	ad5247f0 	ldp	q16, q17, [sp, #576]
    40201204:	ad534ff2 	ldp	q18, q19, [sp, #608]
    40201208:	ad5457f4 	ldp	q20, q21, [sp, #640]
    4020120c:	ad555ff6 	ldp	q22, q23, [sp, #672]
    40201210:	ad5667f8 	ldp	q24, q25, [sp, #704]
    40201214:	ad576ffa 	ldp	q26, q27, [sp, #736]
    40201218:	ad5877fc 	ldp	q28, q29, [sp, #768]
    4020121c:	ad597ffe 	ldp	q30, q31, [sp, #800]
    40201220:	d503201f 	nop
    40201224:	10112e29 	adr	x9, 402237e8 <jnox_ap_returns>
    40201228:	f940012a 	ldr	x10, [x9]
    4020122c:	f101015f 	cmp	x10, #0x40
    40201230:	54ffee82 	b.cs	40201000 <sched_vectors+0x800>  // b.hs, b.nlast
    40201234:	9100054b 	add	x11, x10, #0x1
    40201238:	f800852b 	str	x11, [x9], #8
    4020123c:	d280030b 	mov	x11, #0x18                  	// #24
    40201240:	9b0b2549 	madd	x9, x10, x11, x9
    40201244:	910003ea 	mov	x10, sp
    40201248:	d538402b 	mrs	x11, elr_el1
    4020124c:	a9002d2a 	stp	x10, x11, [x9]
    40201250:	d5033fdf 	isb
    40201254:	d53be02a 	mrs	x10, cntpct_el0
    40201258:	f900092a 	str	x10, [x9, #16]
    4020125c:	a94007e0 	ldp	x0, x1, [sp]
    40201260:	a9410fe2 	ldp	x2, x3, [sp, #16]
    40201264:	a94217e4 	ldp	x4, x5, [sp, #32]
    40201268:	a9431fe6 	ldp	x6, x7, [sp, #48]
    4020126c:	a94427e8 	ldp	x8, x9, [sp, #64]
    40201270:	a9452fea 	ldp	x10, x11, [sp, #80]
    40201274:	a94637ec 	ldp	x12, x13, [sp, #96]
    40201278:	a9473fee 	ldp	x14, x15, [sp, #112]
    4020127c:	a94847f0 	ldp	x16, x17, [sp, #128]
    40201280:	a9494ff2 	ldp	x18, x19, [sp, #144]
    40201284:	a94a57f4 	ldp	x20, x21, [sp, #160]
    40201288:	a94b5ff6 	ldp	x22, x23, [sp, #176]
    4020128c:	a94c67f8 	ldp	x24, x25, [sp, #192]
    40201290:	a94d6ffa 	ldp	x26, x27, [sp, #208]
    40201294:	a94e77fc 	ldp	x28, x29, [sp, #224]
    40201298:	f9407bfe 	ldr	x30, [sp, #240]
    4020129c:	910d03ff 	add	sp, sp, #0x340
    402012a0:	d5033f5f 	clrex
    402012a4:	d69f03e0 	eret

00000000402012a8 <jnox_kernel::ordinary_reservations::unexpected>:
    402012a8:	f81f0ffe 	str	x30, [sp, #-16]!
    402012ac:	52800060 	mov	w0, #0x3                   	// #3
    402012b0:	52800021 	mov	w1, #0x1                   	// #1
    402012b4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    402012b8:	52800043 	mov	w3, #0x2                   	// #2
    402012bc:	aa1f03e4 	mov	x4, xzr
    402012c0:	aa1f03e5 	mov	x5, xzr
    402012c4:	940004fe 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>

00000000402012c8 <jnox_kernel::ordinary_reservations::irq>:
    402012c8:	d10583ff 	sub	sp, sp, #0x160
    402012cc:	a9107bfd 	stp	x29, x30, [sp, #256]
    402012d0:	a9116ffc 	stp	x28, x27, [sp, #272]
    402012d4:	a91267fa 	stp	x26, x25, [sp, #288]
    402012d8:	a9135ff8 	stp	x24, x23, [sp, #304]
    402012dc:	a91457f6 	stp	x22, x21, [sp, #320]
    402012e0:	a9154ff4 	stp	x20, x19, [sp, #336]
    402012e4:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402012e8:	f9420108 	ldr	x8, [x8, #1024]
    402012ec:	f100091f 	cmp	x8, #0x2
    402012f0:	54003480 	b.eq	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.none
    402012f4:	aa0003f4 	mov	x20, x0
    402012f8:	d0000038 	adrp	x24, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402012fc:	d503201f 	nop
    40201300:	100b2119 	adr	x25, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328>
    40201304:	f942b308 	ldr	x8, [x24, #1376]
    40201308:	8b083b29 	add	x9, x25, x8, lsl #14
    4020130c:	eb00013f 	cmp	x9, x0
    40201310:	54003388 	b.hi	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.pmore
    40201314:	b10d069f 	cmn	x20, #0x341
    40201318:	54003348 	b.hi	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.pmore
    4020131c:	d372c508 	lsl	x8, x8, #14
    40201320:	8b080328 	add	x8, x25, x8
    40201324:	91401108 	add	x8, x8, #0x4, lsl #12
    40201328:	910d0289 	add	x9, x20, #0x340
    4020132c:	eb08013f 	cmp	x9, x8
    40201330:	54003288 	b.hi	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.pmore
    40201334:	5280019a 	mov	w26, #0xc                   	// #12
    40201338:	72a1003a 	movk	w26, #0x801, lsl #16
    4020133c:	f9409e95 	ldr	x21, [x20, #312]
    40201340:	b9400356 	ldr	w22, [x26]
    40201344:	d53be237 	mrs	x23, cntp_ctl_el0
    40201348:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020134c:	91156129 	add	x9, x9, #0x558
    40201350:	f9401928 	ldr	x8, [x9, #48]
    40201354:	f9400133 	ldr	x19, [x9]
    40201358:	f100051f 	cmp	x8, #0x1
    4020135c:	540000e0 	b.eq	40201378 <jnox_kernel::ordinary_reservations::irq+0xb0>  // b.none
    40201360:	b100067f 	cmn	x19, #0x1
    40201364:	54000060 	b.eq	40201370 <jnox_kernel::ordinary_reservations::irq+0xa8>  // b.none
    40201368:	91000673 	add	x19, x19, #0x1
    4020136c:	14000003 	b	40201378 <jnox_kernel::ordinary_reservations::irq+0xb0>
    40201370:	b40044c8 	cbz	x8, 40201c08 <jnox_kernel::ordinary_reservations::irq+0x940>
    40201374:	aa1f03f3 	mov	x19, xzr
    40201378:	d000003b 	adrp	x27, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020137c:	9115837b 	add	x27, x27, #0x560
    40201380:	f9401369 	ldr	x9, [x27, #32]
    40201384:	a909a3e9 	stp	x9, x8, [sp, #152]
    40201388:	f9400363 	ldr	x3, [x27]
    4020138c:	a90adff6 	stp	x22, x23, [sp, #168]
    40201390:	910263e4 	add	x4, sp, #0x98
    40201394:	52800080 	mov	w0, #0x4                   	// #4
    40201398:	aa1503e1 	mov	x1, x21
    4020139c:	aa1303e2 	mov	x2, x19
    402013a0:	94000470 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    402013a4:	f9401368 	ldr	x8, [x27, #32]
    402013a8:	120026c9 	and	w9, w22, #0x3ff
    402013ac:	7100793f 	cmp	w9, #0x1e
    402013b0:	54004d41 	b.ne	40201d58 <jnox_kernel::ordinary_reservations::irq+0xa90>  // b.any
    402013b4:	92400ae9 	and	x9, x23, #0x7
    402013b8:	f100153f 	cmp	x9, #0x5
    402013bc:	54004ce1 	b.ne	40201d58 <jnox_kernel::ordinary_reservations::irq+0xa90>  // b.any
    402013c0:	eb0802bf 	cmp	x21, x8
    402013c4:	54004ca3 	b.cc	40201d58 <jnox_kernel::ordinary_reservations::irq+0xa90>  // b.lo, b.ul, b.last
    402013c8:	d51be23f 	msr	cntp_ctl_el0, xzr
    402013cc:	d5033fdf 	isb
    402013d0:	d5033f9f 	dsb	sy
    402013d4:	b9000756 	str	w22, [x26, #4]
    402013d8:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402013dc:	f942c509 	ldr	x9, [x8, #1416]
    402013e0:	aa090269 	orr	x9, x19, x9
    402013e4:	b5000229 	cbnz	x9, 40201428 <jnox_kernel::ordinary_reservations::irq+0x160>
    402013e8:	d5033f9f 	dsb	sy
    402013ec:	d5033fdf 	isb
    402013f0:	d53be029 	mrs	x9, cntpct_el0
    402013f4:	10ffffea 	adr	x10, 402013f0 <jnox_kernel::ordinary_reservations::irq+0x128>
    402013f8:	a902a7ea 	stp	x10, x9, [sp, #40]
    402013fc:	52800029 	mov	w9, #0x1                   	// #1
    40201400:	f9004fe9 	str	x9, [sp, #152]
    40201404:	d503201f 	nop
    40201408:	10115109 	adr	x9, 40223e28 <jnox_kernel::ordinary_reservations::stage_hooks::stage_probe::OBSERVATION>
    4020140c:	f9404fea 	ldr	x10, [sp, #152]
    40201410:	f900012a 	str	x10, [x9]
    40201414:	f9401bea 	ldr	x10, [sp, #48]
    40201418:	f900052a 	str	x10, [x9, #8]
    4020141c:	f94017ea 	ldr	x10, [sp, #40]
    40201420:	f900092a 	str	x10, [x9, #16]
    40201424:	14000002 	b	4020142c <jnox_kernel::ordinary_reservations::irq+0x164>
    40201428:	d5033f9f 	dsb	sy
    4020142c:	f942c508 	ldr	x8, [x8, #1416]
    40201430:	f100051f 	cmp	x8, #0x1
    40201434:	540003e1 	b.ne	402014b0 <jnox_kernel::ordinary_reservations::irq+0x1e8>  // b.any
    40201438:	aa1403e0 	mov	x0, x20
    4020143c:	aa1503e1 	mov	x1, x21
    40201440:	2a1f03e2 	mov	w2, wzr
    40201444:	aa1f03e3 	mov	x3, xzr
    40201448:	94000651 	bl	40202d8c <jnox_kernel::ordinary_reservations::Runtime::close>
    4020144c:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201450:	9114e108 	add	x8, x8, #0x538
    40201454:	91000669 	add	x9, x19, #0x1
    40201458:	a9402908 	ldp	x8, x10, [x8]
    4020145c:	9bca7d2b 	umulh	x11, x9, x10
    40201460:	eb0b03ff 	cmp	xzr, x11
    40201464:	1a9f07eb 	cset	w11, ne  // ne = any
    40201468:	9b0a7d29 	mul	x9, x9, x10
    4020146c:	ab080122 	adds	x2, x9, x8
    40201470:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40201474:	370046eb 	tbnz	w11, #0, 40201d50 <jnox_kernel::ordinary_reservations::irq+0xa88>
    40201478:	350046c8 	cbnz	w8, 40201d50 <jnox_kernel::ordinary_reservations::irq+0xa88>
    4020147c:	aa1303e0 	mov	x0, x19
    40201480:	aa1f03e1 	mov	x1, xzr
    40201484:	94000621 	bl	40202d08 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201488:	aa1303e0 	mov	x0, x19
    4020148c:	52800041 	mov	w1, #0x2                   	// #2
    40201490:	a9554ff4 	ldp	x20, x19, [sp, #336]
    40201494:	a95457f6 	ldp	x22, x21, [sp, #320]
    40201498:	a9535ff8 	ldp	x24, x23, [sp, #304]
    4020149c:	a95267fa 	ldp	x26, x25, [sp, #288]
    402014a0:	a9516ffc 	ldp	x28, x27, [sp, #272]
    402014a4:	a9507bfd 	ldp	x29, x30, [sp, #256]
    402014a8:	910583ff 	add	sp, sp, #0x160
    402014ac:	14000771 	b	40203270 <jnox_kernel::ordinary_reservations::Runtime::select>
    402014b0:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014b4:	9114c129 	add	x9, x9, #0x530
    402014b8:	f940192a 	ldr	x10, [x9, #48]
    402014bc:	f100095f 	cmp	x10, #0x2
    402014c0:	54002601 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    402014c4:	39400129 	ldrb	w9, [x9]
    402014c8:	71000d3f 	cmp	w9, #0x3
    402014cc:	540025a1 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    402014d0:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014d4:	91152129 	add	x9, x9, #0x548
    402014d8:	f9001934 	str	x20, [x9, #48]
    402014dc:	f9401d25 	ldr	x5, [x9, #56]
    402014e0:	cb0502aa 	sub	x10, x21, x5
    402014e4:	f9400129 	ldr	x9, [x9]
    402014e8:	eb09015f 	cmp	x10, x9
    402014ec:	540044e8 	b.hi	40201d88 <jnox_kernel::ordinary_reservations::irq+0xac0>  // b.pmore
    402014f0:	b40013b3 	cbz	x19, 40201764 <jnox_kernel::ordinary_reservations::irq+0x49c>
    402014f4:	92800028 	mov	x8, #0xfffffffffffffffe    	// #-2
    402014f8:	d0000037 	adrp	x23, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402014fc:	d0000038 	adrp	x24, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201500:	91174318 	add	x24, x24, #0x5d0
    40201504:	b4000428 	cbz	x8, 40201588 <jnox_kernel::ordinary_reservations::irq+0x2c0>
    40201508:	aa0803f6 	mov	x22, x8
    4020150c:	910263e8 	add	x8, sp, #0x98
    40201510:	91000ac0 	add	x0, x22, #0x2
    40201514:	94000793 	bl	40203360 <jnox_kernel::ordinary_reservations::snapshot>
    40201518:	a949d7f4 	ldp	x20, x21, [sp, #152]
    4020151c:	f942aae8 	ldr	x8, [x23, #1360]
    40201520:	eb08027f 	cmp	x19, x8
    40201524:	54000161 	b.ne	40201550 <jnox_kernel::ordinary_reservations::irq+0x288>  // b.any
    40201528:	f94057e8 	ldr	x8, [sp, #168]
    4020152c:	d5033fdf 	isb
    40201530:	d53be021 	mrs	x1, cntpct_el0
    40201534:	a909d7f4 	stp	x20, x21, [sp, #152]
    40201538:	a90affe8 	stp	x8, xzr, [sp, #168]
    4020153c:	91000ac3 	add	x3, x22, #0x2
    40201540:	910263e4 	add	x4, sp, #0x98
    40201544:	528002a0 	mov	w0, #0x15                  	// #21
    40201548:	aa1303e2 	mov	x2, x19
    4020154c:	94000405 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40201550:	f85f0308 	ldur	x8, [x24, #-16]
    40201554:	eb08029f 	cmp	x20, x8
    40201558:	540000a1 	b.ne	4020156c <jnox_kernel::ordinary_reservations::irq+0x2a4>  // b.any
    4020155c:	f8408709 	ldr	x9, [x24], #8
    40201560:	910006c8 	add	x8, x22, #0x1
    40201564:	eb0902bf 	cmp	x21, x9
    40201568:	54fffce0 	b.eq	40201504 <jnox_kernel::ordinary_reservations::irq+0x23c>  // b.none
    4020156c:	91000ac3 	add	x3, x22, #0x2
    40201570:	52800060 	mov	w0, #0x3                   	// #3
    40201574:	52800101 	mov	w1, #0x8                   	// #8
    40201578:	aa1303e2 	mov	x2, x19
    4020157c:	aa1403e4 	mov	x4, x20
    40201580:	aa1503e5 	mov	x5, x21
    40201584:	9400044e 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>
    40201588:	f942aae8 	ldr	x8, [x23, #1360]
    4020158c:	eb08027f 	cmp	x19, x8
    40201590:	54004220 	b.eq	40201dd4 <jnox_kernel::ordinary_reservations::irq+0xb0c>  // b.none
    40201594:	94000726 	bl	4020322c <jnox_kernel::ordinary_reservations::Runtime::ledger>
    40201598:	910263e8 	add	x8, sp, #0x98
    4020159c:	aa1303e1 	mov	x1, x19
    402015a0:	940008ba 	bl	40203888 <jnox_kernel::reservation_jobs::Jobs::open>
    402015a4:	f9404fe8 	ldr	x8, [sp, #152]
    402015a8:	f100091f 	cmp	x8, #0x2
    402015ac:	54004200 	b.eq	40201dec <jnox_kernel::ordinary_reservations::irq+0xb24>  // b.none
    402015b0:	9100c3e0 	add	x0, sp, #0x30
    402015b4:	910263e1 	add	x1, sp, #0x98
    402015b8:	52800d02 	mov	w2, #0x68                  	// #104
    402015bc:	94001114 	bl	40205a0c <memcpy>
    402015c0:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402015c4:	9114e129 	add	x9, x9, #0x538
    402015c8:	a9402129 	ldp	x9, x8, [x9]
    402015cc:	9bc87e6a 	umulh	x10, x19, x8
    402015d0:	eb0a03ff 	cmp	xzr, x10
    402015d4:	1a9f07eb 	cset	w11, ne  // ne = any
    402015d8:	9b087e6a 	mul	x10, x19, x8
    402015dc:	ab09014c 	adds	x12, x10, x9
    402015e0:	1a9f37ea 	cset	w10, cs  // cs = hs, nlast
    402015e4:	37003b6b 	tbnz	w11, #0, 40201d50 <jnox_kernel::ordinary_reservations::irq+0xa88>
    402015e8:	35003b4a 	cbnz	w10, 40201d50 <jnox_kernel::ordinary_reservations::irq+0xa88>
    402015ec:	9100066b 	add	x11, x19, #0x1
    402015f0:	9bc87d6a 	umulh	x10, x11, x8
    402015f4:	eb0a03ff 	cmp	xzr, x10
    402015f8:	1a9f07ea 	cset	w10, ne  // ne = any
    402015fc:	9b087d68 	mul	x8, x11, x8
    40201600:	ab090108 	adds	x8, x8, x9
    40201604:	a901a3ec 	stp	x12, x8, [sp, #24]
    40201608:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    4020160c:	37003a2a 	tbnz	w10, #0, 40201d50 <jnox_kernel::ordinary_reservations::irq+0xa88>
    40201610:	35003a08 	cbnz	w8, 40201d50 <jnox_kernel::ordinary_reservations::irq+0xa88>
    40201614:	aa1f03f6 	mov	x22, xzr
    40201618:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020161c:	39424beb 	ldrb	w11, [sp, #146]
    40201620:	9100c3e9 	add	x9, sp, #0x30
    40201624:	9100613d 	add	x29, x9, #0x18
    40201628:	b94033fc 	ldr	w28, [sp, #48]
    4020162c:	9100e137 	add	x23, x9, #0x38
    40201630:	91004138 	add	x24, x9, #0x10
    40201634:	f9401ff5 	ldr	x21, [sp, #56]
    40201638:	9100056a 	add	x10, x11, #0x1
    4020163c:	71000d7f 	cmp	w11, #0x3
    40201640:	f902ad13 	str	x19, [x8, #1368]
    40201644:	91000568 	add	x8, x11, #0x1
    40201648:	a900afe8 	stp	x8, x11, [sp, #8]
    4020164c:	1a8a03f9 	csel	w25, wzr, w10, eq  // eq = none
    40201650:	91016134 	add	x20, x9, #0x58
    40201654:	9101813a 	add	x26, x9, #0x60
    40201658:	52800028 	mov	w8, #0x1                   	// #1
    4020165c:	8b1613a9 	add	x9, x29, x22, lsl #4
    40201660:	8b1612ea 	add	x10, x23, x22, lsl #4
    40201664:	d5033fdf 	isb
    40201668:	d53be021 	mrs	x1, cntpct_el0
    4020166c:	2a0803fb 	mov	w27, w8
    40201670:	a9402528 	ldp	x8, x9, [x9]
    40201674:	a909a7e8 	stp	x8, x9, [sp, #152]
    40201678:	a9402548 	ldp	x8, x9, [x10]
    4020167c:	a90aa7e8 	stp	x8, x9, [sp, #168]
    40201680:	910263e4 	add	x4, sp, #0x98
    40201684:	528000a0 	mov	w0, #0x5                   	// #5
    40201688:	aa1303e2 	mov	x2, x19
    4020168c:	aa1603e3 	mov	x3, x22
    40201690:	940003b4 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40201694:	d5033fdf 	isb
    40201698:	d53be021 	mrs	x1, cntpct_el0
    4020169c:	b8767b08 	ldr	w8, [x24, x22, lsl #2]
    402016a0:	eb1502df 	cmp	x22, x21
    402016a4:	b8767a89 	ldr	w9, [x20, x22, lsl #2]
    402016a8:	38766b4a 	ldrb	w10, [x26, x22]
    402016ac:	1a9f17eb 	cset	w11, eq  // eq = none
    402016b0:	a909a7e8 	stp	x8, x9, [sp, #152]
    402016b4:	6a0b039f 	tst	w28, w11
    402016b8:	9a9f1328 	csel	x8, x25, xzr, ne  // ne = any
    402016bc:	a90aa3ea 	stp	x10, x8, [sp, #168]
    402016c0:	910263e4 	add	x4, sp, #0x98
    402016c4:	528000c0 	mov	w0, #0x6                   	// #6
    402016c8:	aa1303e2 	mov	x2, x19
    402016cc:	aa1603e3 	mov	x3, x22
    402016d0:	940003a4 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    402016d4:	2a1f03e8 	mov	w8, wzr
    402016d8:	52800036 	mov	w22, #0x1                   	// #1
    402016dc:	3707fc1b 	tbnz	w27, #0, 4020165c <jnox_kernel::ordinary_reservations::irq+0x394>
    402016e0:	3400287c 	cbz	w28, 40201bec <jnox_kernel::ordinary_reservations::irq+0x924>
    402016e4:	f9400bed 	ldr	x13, [sp, #16]
    402016e8:	71000dbf 	cmp	w13, #0x3
    402016ec:	540014a0 	b.eq	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.none
    402016f0:	f1000abf 	cmp	x21, #0x2
    402016f4:	54003922 	b.cs	40201e18 <jnox_kernel::ordinary_reservations::irq+0xb50>  // b.hs, b.nlast
    402016f8:	d503201f 	nop
    402016fc:	1002e828 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40201700:	8b150d0b 	add	x11, x8, x21, lsl #3
    40201704:	f940e168 	ldr	x8, [x11, #448]
    40201708:	f940e969 	ldr	x9, [x11, #464]
    4020170c:	f940c96c 	ldr	x12, [x11, #400]
    40201710:	9100c3ea 	add	x10, sp, #0x30
    40201714:	8b15114a 	add	x10, x10, x21, lsl #4
    40201718:	f940214a 	ldr	x10, [x10, #64]
    4020171c:	eb0a019f 	cmp	x12, x10
    40201720:	54000060 	b.eq	4020172c <jnox_kernel::ordinary_reservations::irq+0x464>  // b.none
    40201724:	f900c96a 	str	x10, [x11, #400]
    40201728:	f900d17f 	str	xzr, [x11, #416]
    4020172c:	d000010b 	adrp	x11, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328+0xb8e0>
    40201730:	f943f56b 	ldr	x11, [x11, #2024]
    40201734:	d000002c 	adrp	x12, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201738:	9114018c 	add	x12, x12, #0x500
    4020173c:	a9004d95 	stp	x21, x19, [x12]
    40201740:	a901218b 	stp	x11, x8, [x12, #16]
    40201744:	a9022989 	stp	x9, x10, [x12, #32]
    40201748:	3900c18d 	strb	w13, [x12, #48]
    4020174c:	f94013f4 	ldr	x20, [sp, #32]
    40201750:	3400286d 	cbz	w13, 40201c5c <jnox_kernel::ordinary_reservations::irq+0x994>
    40201754:	b104011f 	cmn	x8, #0x100
    40201758:	540036a2 	b.cs	40201e2c <jnox_kernel::ordinary_reservations::irq+0xb64>  // b.hs, b.nlast
    4020175c:	91040108 	add	x8, x8, #0x100
    40201760:	14000140 	b	40201c60 <jnox_kernel::ordinary_reservations::irq+0x998>
    40201764:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201768:	f942f129 	ldr	x9, [x9, #1504]
    4020176c:	f100093f 	cmp	x9, #0x2
    40201770:	54001080 	b.eq	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.none
    40201774:	b5001068 	cbnz	x8, 40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>
    40201778:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020177c:	f942ad08 	ldr	x8, [x8, #1368]
    40201780:	b100051f 	cmn	x8, #0x1
    40201784:	54000fe1 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201788:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020178c:	f9432d08 	ldr	x8, [x8, #1624]
    40201790:	eb0800bf 	cmp	x5, x8
    40201794:	54000f61 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201798:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020179c:	f9429d29 	ldr	x9, [x9, #1336]
    402017a0:	eb08013f 	cmp	x9, x8
    402017a4:	54000ee1 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    402017a8:	d0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328+0xb8e0>
    402017ac:	f943f508 	ldr	x8, [x8, #2024]
    402017b0:	f100051f 	cmp	x8, #0x1
    402017b4:	54000e61 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    402017b8:	d503201f 	nop
    402017bc:	10110128 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    402017c0:	c8dffd09 	ldar	x9, [x8]
    402017c4:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402017c8:	f942354a 	ldr	x10, [x10, #1128]
    402017cc:	aa0a0129 	orr	x9, x9, x10
    402017d0:	b5000d89 	cbnz	x9, 40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>
    402017d4:	aa1f03eb 	mov	x11, xzr
    402017d8:	5280002a 	mov	w10, #0x1                   	// #1
    402017dc:	d503201f 	nop
    402017e0:	1002e117 	adr	x23, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    402017e4:	8b0b02e9 	add	x9, x23, x11
    402017e8:	3941e129 	ldrb	w9, [x9, #120]
    402017ec:	3600008a 	tbz	w10, #0, 402017fc <jnox_kernel::ordinary_reservations::irq+0x534>
    402017f0:	2a1f03ea 	mov	w10, wzr
    402017f4:	5280002b 	mov	w11, #0x1                   	// #1
    402017f8:	34ffff69 	cbz	w9, 402017e4 <jnox_kernel::ordinary_reservations::irq+0x51c>
    402017fc:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201800:	9111814a 	add	x10, x10, #0x460
    40201804:	3940014b 	ldrb	w11, [x10]
    40201808:	f940094a 	ldr	x10, [x10, #16]
    4020180c:	7100013f 	cmp	w9, #0x0
    40201810:	7a430960 	ccmp	w11, #0x3, #0x0, eq  // eq = none
    40201814:	fa400940 	ccmp	x10, #0x0, #0x0, eq  // eq = none
    40201818:	54000b41 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    4020181c:	d000010b 	adrp	x11, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328+0xb8e0>
    40201820:	911fc16b 	add	x11, x11, #0x7f0
    40201824:	f9400969 	ldr	x9, [x11, #16]
    40201828:	f940056a 	ldr	x10, [x11, #8]
    4020182c:	f940016b 	ldr	x11, [x11]
    40201830:	d000010c 	adrp	x12, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328+0xb8e0>
    40201834:	910f818c 	add	x12, x12, #0x3e0
    40201838:	eb0c017f 	cmp	x11, x12
    4020183c:	54000a21 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201840:	d503201f 	nop
    40201844:	1000490b 	adr	x11, 40202164 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328>
    40201848:	eb0b015f 	cmp	x10, x11
    4020184c:	540009a1 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201850:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201854:	f943254a 	ldr	x10, [x10, #1608]
    40201858:	eb0a013f 	cmp	x9, x10
    4020185c:	54000928 	b.hi	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.pmore
    40201860:	aa1f03e9 	mov	x9, xzr
    40201864:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201868:	911aa14a 	add	x10, x10, #0x6a8
    4020186c:	d503201f 	nop
    40201870:	1002f3da 	adr	x26, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40201874:	d503201f 	nop
    40201878:	10112bdb 	adr	x27, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    4020187c:	d503201f 	nop
    40201880:	1002f3dd 	adr	x29, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40201884:	d503201f 	nop
    40201888:	10112bdc 	adr	x28, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    4020188c:	d10d032b 	sub	x11, x25, #0x340
    40201890:	d503201f 	nop
    40201894:	10112bec 	adr	x12, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    40201898:	f100413f 	cmp	x9, #0x10
    4020189c:	54000740 	b.eq	40201984 <jnox_kernel::ordinary_reservations::irq+0x6bc>  // b.none
    402018a0:	8b0902ed 	add	x13, x23, x9
    402018a4:	f940b5ad 	ldr	x13, [x13, #360]
    402018a8:	f85d014e 	ldur	x14, [x10, #-48]
    402018ac:	eb0d01df 	cmp	x14, x13
    402018b0:	9140116b 	add	x11, x11, #0x4, lsl #12
    402018b4:	fa4d0160 	ccmp	x11, x13, #0x0, eq  // eq = none
    402018b8:	54000641 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    402018bc:	f9407dae 	ldr	x14, [x13, #248]
    402018c0:	f85d814f 	ldur	x15, [x10, #-40]
    402018c4:	eb0f01df 	cmp	x14, x15
    402018c8:	540005c1 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    402018cc:	f94081ae 	ldr	x14, [x13, #256]
    402018d0:	f85e014f 	ldur	x15, [x10, #-32]
    402018d4:	eb0f01df 	cmp	x14, x15
    402018d8:	54000541 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    402018dc:	f9404dae 	ldr	x14, [x13, #152]
    402018e0:	f85e814f 	ldur	x15, [x10, #-24]
    402018e4:	eb0f01df 	cmp	x14, x15
    402018e8:	540004c1 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    402018ec:	f9408dad 	ldr	x13, [x13, #280]
    402018f0:	f85f014e 	ldur	x14, [x10, #-16]
    402018f4:	eb0e01bf 	cmp	x13, x14
    402018f8:	54000441 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    402018fc:	8b09034d 	add	x13, x26, x9
    40201900:	c8dffdad 	ldar	x13, [x13]
    40201904:	b10005bf 	cmn	x13, #0x1
    40201908:	540003c1 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    4020190c:	8b09036d 	add	x13, x27, x9
    40201910:	c8dffdad 	ldar	x13, [x13]
    40201914:	b500036d 	cbnz	x13, 40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>
    40201918:	8b0903ad 	add	x13, x29, x9
    4020191c:	c8dffdad 	ldar	x13, [x13]
    40201920:	b10005bf 	cmn	x13, #0x1
    40201924:	540002e1 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201928:	8b09038d 	add	x13, x28, x9
    4020192c:	c8dffdad 	ldar	x13, [x13]
    40201930:	b500028d 	cbnz	x13, 40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>
    40201934:	8b09018d 	add	x13, x12, x9
    40201938:	c8dffdad 	ldar	x13, [x13]
    4020193c:	b500022d 	cbnz	x13, 40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>
    40201940:	8b0902ed 	add	x13, x23, x9
    40201944:	f940e1ae 	ldr	x14, [x13, #448]
    40201948:	f85f814f 	ldur	x15, [x10, #-8]
    4020194c:	eb0f01df 	cmp	x14, x15
    40201950:	54000181 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201954:	f940e9ad 	ldr	x13, [x13, #464]
    40201958:	f843854e 	ldr	x14, [x10], #56
    4020195c:	eb0e01bf 	cmp	x13, x14
    40201960:	54000101 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201964:	8b0902ed 	add	x13, x23, x9
    40201968:	f940c9ae 	ldr	x14, [x13, #400]
    4020196c:	b10005df 	cmn	x14, #0x1
    40201970:	54000081 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201974:	91002129 	add	x9, x9, #0x8
    40201978:	f940d1ad 	ldr	x13, [x13, #416]
    4020197c:	b4fff8ed 	cbz	x13, 40201898 <jnox_kernel::ordinary_reservations::irq+0x5d0>
    40201980:	97fffe4a 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40201984:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201988:	f942412a 	ldr	x10, [x9, #1152]
    4020198c:	f100095f 	cmp	x10, #0x2
    40201990:	54ffff80 	b.eq	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.none
    40201994:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201998:	91136129 	add	x9, x9, #0x4d8
    4020199c:	39402138 	ldrb	w24, [x9, #8]
    402019a0:	71000f1f 	cmp	w24, #0x3
    402019a4:	54fffee0 	b.eq	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.none
    402019a8:	3941eaeb 	ldrb	w11, [x23, #122]
    402019ac:	3943eaec 	ldrb	w12, [x23, #250]
    402019b0:	6b0c017f 	cmp	w11, w12
    402019b4:	54fffe61 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    402019b8:	f94002eb 	ldr	x11, [x23]
    402019bc:	eb0a017f 	cmp	x11, x10
    402019c0:	54fffe01 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    402019c4:	d503201f 	nop
    402019c8:	1002e0d4 	adr	x20, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    402019cc:	f940028a 	ldr	x10, [x20]
    402019d0:	b4fffd8a 	cbz	x10, 40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>
    402019d4:	f9400133 	ldr	x19, [x9]
    402019d8:	f9400689 	ldr	x9, [x20, #8]
    402019dc:	eb13013f 	cmp	x9, x19
    402019e0:	54fffd01 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    402019e4:	39418a89 	ldrb	w9, [x20, #98]
    402019e8:	6b09031f 	cmp	w24, w9
    402019ec:	54fffca1 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    402019f0:	f90013e5 	str	x5, [sp, #32]
    402019f4:	d0000119 	adrp	x25, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328+0xb8e0>
    402019f8:	911cc339 	add	x25, x25, #0x730
    402019fc:	d5033fdf 	isb
    40201a00:	d53be036 	mrs	x22, cntpct_el0
    40201a04:	f9001f36 	str	x22, [x25, #56]
    40201a08:	f9400329 	ldr	x9, [x25]
    40201a0c:	b27f0129 	orr	x9, x9, #0x2
    40201a10:	f9000329 	str	x9, [x25]
    40201a14:	eb1502df 	cmp	x22, x21
    40201a18:	54001c43 	b.cc	40201da0 <jnox_kernel::ordinary_reservations::irq+0xad8>  // b.lo, b.ul, b.last
    40201a1c:	d000002a 	adrp	x10, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201a20:	9114e14a 	add	x10, x10, #0x538
    40201a24:	f9400149 	ldr	x9, [x10]
    40201a28:	eb0902c9 	subs	x9, x22, x9
    40201a2c:	54001ba3 	b.cc	40201da0 <jnox_kernel::ordinary_reservations::irq+0xad8>  // b.lo, b.ul, b.last
    40201a30:	f940094a 	ldr	x10, [x10, #16]
    40201a34:	eb0a013f 	cmp	x9, x10
    40201a38:	54001b48 	b.hi	40201da0 <jnox_kernel::ordinary_reservations::irq+0xad8>  // b.pmore
    40201a3c:	52800069 	mov	w9, #0x3                   	// #3
    40201a40:	c89ffd09 	stlr	x9, [x8]
    40201a44:	c8dffd15 	ldar	x21, [x8]
    40201a48:	940005f9 	bl	4020322c <jnox_kernel::ordinary_reservations::Runtime::ledger>
    40201a4c:	f9402c08 	ldr	x8, [x0, #88]
    40201a50:	39418009 	ldrb	w9, [x0, #96]
    40201a54:	d5033fdf 	isb
    40201a58:	d53be024 	mrs	x4, cntpct_el0
    40201a5c:	f940032a 	ldr	x10, [x25]
    40201a60:	a9045724 	stp	x4, x21, [x25, #64]
    40201a64:	71000d3f 	cmp	w9, #0x3
    40201a68:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40201a6c:	f9002b28 	str	x8, [x25, #80]
    40201a70:	b27e0149 	orr	x9, x10, #0x4
    40201a74:	f9000329 	str	x9, [x25]
    40201a78:	f1000ebf 	cmp	x21, #0x3
    40201a7c:	54fff821 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201a80:	eb13011f 	cmp	x8, x19
    40201a84:	54fff7e1 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201a88:	eb16009f 	cmp	x4, x22
    40201a8c:	d000002e 	adrp	x14, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201a90:	9114e1ce 	add	x14, x14, #0x538
    40201a94:	54001703 	b.cc	40201d74 <jnox_kernel::ordinary_reservations::irq+0xaac>  // b.lo, b.ul, b.last
    40201a98:	f94001c8 	ldr	x8, [x14]
    40201a9c:	eb080088 	subs	x8, x4, x8
    40201aa0:	540016a3 	b.cc	40201d74 <jnox_kernel::ordinary_reservations::irq+0xaac>  // b.lo, b.ul, b.last
    40201aa4:	f94009c9 	ldr	x9, [x14, #16]
    40201aa8:	eb09011f 	cmp	x8, x9
    40201aac:	54001648 	b.hi	40201d74 <jnox_kernel::ordinary_reservations::irq+0xaac>  // b.pmore
    40201ab0:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201ab4:	f902ad1f 	str	xzr, [x8, #1368]
    40201ab8:	f100067f 	cmp	x19, #0x1
    40201abc:	54001a68 	b.hi	40201e08 <jnox_kernel::ordinary_reservations::irq+0xb40>  // b.pmore
    40201ac0:	8b131288 	add	x8, x20, x19, lsl #4
    40201ac4:	f9402108 	ldr	x8, [x8, #64]
    40201ac8:	8b130ee9 	add	x9, x23, x19, lsl #3
    40201acc:	f900c928 	str	x8, [x9, #400]
    40201ad0:	f940e12a 	ldr	x10, [x9, #448]
    40201ad4:	f940e92b 	ldr	x11, [x9, #464]
    40201ad8:	a9107ef3 	stp	x19, xzr, [x23, #256]
    40201adc:	5280002c 	mov	w12, #0x1                   	// #1
    40201ae0:	a9112aec 	stp	x12, x10, [x23, #272]
    40201ae4:	a91222eb 	stp	x11, x8, [x23, #288]
    40201ae8:	3904c2f8 	strb	w24, [x23, #304]
    40201aec:	8b130fa8 	add	x8, x29, x19, lsl #3
    40201af0:	a948aa8b 	ldp	x11, x10, [x20, #136]
    40201af4:	c89ffd0a 	stlr	x10, [x8]
    40201af8:	91000708 	add	x8, x24, #0x1
    40201afc:	f8337b68 	str	x8, [x27, x19, lsl #3]
    40201b00:	f8337b9f 	str	xzr, [x28, x19, lsl #3]
    40201b04:	8b130f48 	add	x8, x26, x19, lsl #3
    40201b08:	c89ffd1f 	stlr	xzr, [x8]
    40201b0c:	a91832eb 	stp	x11, x12, [x23, #384]
    40201b10:	d51be24b 	msr	cntp_cval_el0, x11
    40201b14:	d51be22c 	msr	cntp_ctl_el0, x12
    40201b18:	d5033fdf 	isb
    40201b1c:	d53be24d 	mrs	x13, cntp_cval_el0
    40201b20:	d53be228 	mrs	x8, cntp_ctl_el0
    40201b24:	d5033fdf 	isb
    40201b28:	d53be02a 	mrs	x10, cntpct_el0
    40201b2c:	a906a32d 	stp	x13, x8, [x25, #104]
    40201b30:	a905af2a 	stp	x10, x11, [x25, #88]
    40201b34:	f940032c 	ldr	x12, [x25]
    40201b38:	b27d018c 	orr	x12, x12, #0x8
    40201b3c:	f900032c 	str	x12, [x25]
    40201b40:	eb0b01bf 	cmp	x13, x11
    40201b44:	54fff1e1 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201b48:	92400508 	and	x8, x8, #0x3
    40201b4c:	f100051f 	cmp	x8, #0x1
    40201b50:	54fff181 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201b54:	d5033fdf 	isb
    40201b58:	d53be028 	mrs	x8, cntpct_el0
    40201b5c:	eb04015f 	cmp	x10, x4
    40201b60:	540012c3 	b.cc	40201db8 <jnox_kernel::ordinary_reservations::irq+0xaf0>  // b.lo, b.ul, b.last
    40201b64:	eb0a011f 	cmp	x8, x10
    40201b68:	54001283 	b.cc	40201db8 <jnox_kernel::ordinary_reservations::irq+0xaf0>  // b.lo, b.ul, b.last
    40201b6c:	f94001ca 	ldr	x10, [x14]
    40201b70:	eb0a010a 	subs	x10, x8, x10
    40201b74:	54001223 	b.cc	40201db8 <jnox_kernel::ordinary_reservations::irq+0xaf0>  // b.lo, b.ul, b.last
    40201b78:	f94009cb 	ldr	x11, [x14, #16]
    40201b7c:	eb0b015f 	cmp	x10, x11
    40201b80:	540011c8 	b.hi	40201db8 <jnox_kernel::ordinary_reservations::irq+0xaf0>  // b.pmore
    40201b84:	f940b536 	ldr	x22, [x9, #360]
    40201b88:	d5033fdf 	isb
    40201b8c:	d53be024 	mrs	x4, cntpct_el0
    40201b90:	f9409ee8 	ldr	x8, [x23, #312]
    40201b94:	eb080088 	subs	x8, x4, x8
    40201b98:	54000ee3 	b.cc	40201d74 <jnox_kernel::ordinary_reservations::irq+0xaac>  // b.lo, b.ul, b.last
    40201b9c:	f940a6ea 	ldr	x10, [x23, #328]
    40201ba0:	eb0a011f 	cmp	x8, x10
    40201ba4:	54000e88 	b.hi	40201d74 <jnox_kernel::ordinary_reservations::irq+0xaac>  // b.pmore
    40201ba8:	f900b53f 	str	xzr, [x9, #360]
    40201bac:	f900b2f3 	str	x19, [x23, #352]
    40201bb0:	d0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201bb4:	91004108 	add	x8, x8, #0x10
    40201bb8:	f9407ec9 	ldr	x9, [x22, #248]
    40201bbc:	a907db24 	stp	x4, x22, [x25, #120]
    40201bc0:	5280002a 	mov	w10, #0x1                   	// #1
    40201bc4:	a9004d1f 	stp	xzr, x19, [x8]
    40201bc8:	f9408ec8 	ldr	x8, [x22, #280]
    40201bcc:	f9004729 	str	x9, [x25, #136]
    40201bd0:	f9404ec9 	ldr	x9, [x22, #152]
    40201bd4:	a909ab28 	stp	x8, x10, [x25, #152]
    40201bd8:	f9004b29 	str	x9, [x25, #144]
    40201bdc:	f9400328 	ldr	x8, [x25]
    40201be0:	b27c0108 	orr	x8, x8, #0x10
    40201be4:	f9000328 	str	x8, [x25]
    40201be8:	14000051 	b	40201d2c <jnox_kernel::ordinary_reservations::irq+0xa64>
    40201bec:	aa1303e0 	mov	x0, x19
    40201bf0:	aa1f03e1 	mov	x1, xzr
    40201bf4:	f94013f4 	ldr	x20, [sp, #32]
    40201bf8:	aa1403e2 	mov	x2, x20
    40201bfc:	94000443 	bl	40202d08 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201c00:	52800055 	mov	w21, #0x2                   	// #2
    40201c04:	1400003b 	b	40201cf0 <jnox_kernel::ordinary_reservations::irq+0xa28>
    40201c08:	d000010a 	adrp	x10, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328+0xb8e0>
    40201c0c:	911cc14a 	add	x10, x10, #0x730
    40201c10:	d53be248 	mrs	x8, cntp_cval_el0
    40201c14:	d5033fdf 	isb
    40201c18:	d53be029 	mrs	x9, cntpct_el0
    40201c1c:	a9022157 	stp	x23, x8, [x10, #32]
    40201c20:	a9015949 	stp	x9, x22, [x10, #16]
    40201c24:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201c28:	9114e129 	add	x9, x9, #0x538
    40201c2c:	f940252b 	ldr	x11, [x9, #72]
    40201c30:	f900194b 	str	x11, [x10, #48]
    40201c34:	f940014c 	ldr	x12, [x10]
    40201c38:	b240018c 	orr	x12, x12, #0x1
    40201c3c:	a900554c 	stp	x12, x21, [x10]
    40201c40:	eb0b011f 	cmp	x8, x11
    40201c44:	54ffe9e1 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201c48:	f9400129 	ldr	x9, [x9]
    40201c4c:	eb09011f 	cmp	x8, x9
    40201c50:	54ffe981 	b.ne	40201980 <jnox_kernel::ordinary_reservations::irq+0x6b8>  // b.any
    40201c54:	aa1f03f3 	mov	x19, xzr
    40201c58:	17fffdd4 	b	402013a8 <jnox_kernel::ordinary_reservations::irq+0xe0>
    40201c5c:	92800008 	mov	x8, #0xffffffffffffffff    	// #-1
    40201c60:	d503201f 	nop
    40201c64:	1002d4a9 	adr	x9, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40201c68:	d503201f 	nop
    40201c6c:	10110c2a 	adr	x10, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40201c70:	d503201f 	nop
    40201c74:	1002d3ab 	adr	x11, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40201c78:	d503201f 	nop
    40201c7c:	10110c2c 	adr	x12, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40201c80:	8b150d29 	add	x9, x9, x21, lsl #3
    40201c84:	c89ffd28 	stlr	x8, [x9]
    40201c88:	f94007e8 	ldr	x8, [sp, #8]
    40201c8c:	f8357948 	str	x8, [x10, x21, lsl #3]
    40201c90:	f835799f 	str	xzr, [x12, x21, lsl #3]
    40201c94:	8b150d68 	add	x8, x11, x21, lsl #3
    40201c98:	c89ffd13 	stlr	x19, [x8]
    40201c9c:	b100067f 	cmn	x19, #0x1
    40201ca0:	54000580 	b.eq	40201d50 <jnox_kernel::ordinary_reservations::irq+0xa88>  // b.none
    40201ca4:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201ca8:	9114e129 	add	x9, x9, #0x538
    40201cac:	a9402129 	ldp	x9, x8, [x9]
    40201cb0:	9100066b 	add	x11, x19, #0x1
    40201cb4:	9bc87d6a 	umulh	x10, x11, x8
    40201cb8:	eb0a03ff 	cmp	xzr, x10
    40201cbc:	1a9f07ea 	cset	w10, ne  // ne = any
    40201cc0:	9b087d68 	mul	x8, x11, x8
    40201cc4:	ab090108 	adds	x8, x8, x9
    40201cc8:	1a9f37e9 	cset	w9, cs  // cs = hs, nlast
    40201ccc:	3700042a 	tbnz	w10, #0, 40201d50 <jnox_kernel::ordinary_reservations::irq+0xa88>
    40201cd0:	37000409 	tbnz	w9, #0, 40201d50 <jnox_kernel::ordinary_reservations::irq+0xa88>
    40201cd4:	d0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40201cd8:	f942a529 	ldr	x9, [x9, #1352]
    40201cdc:	eb090102 	subs	x2, x8, x9
    40201ce0:	54000383 	b.cc	40201d50 <jnox_kernel::ordinary_reservations::irq+0xa88>  // b.lo, b.ul, b.last
    40201ce4:	aa1303e0 	mov	x0, x19
    40201ce8:	52800021 	mov	w1, #0x1                   	// #1
    40201cec:	94000407 	bl	40202d08 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40201cf0:	aa1303e0 	mov	x0, x19
    40201cf4:	aa1503e1 	mov	x1, x21
    40201cf8:	9400055e 	bl	40203270 <jnox_kernel::ordinary_reservations::Runtime::select>
    40201cfc:	aa0003f6 	mov	x22, x0
    40201d00:	d5033fdf 	isb
    40201d04:	d53be021 	mrs	x1, cntpct_el0
    40201d08:	f9407c08 	ldr	x8, [x0, #248]
    40201d0c:	f9400fe9 	ldr	x9, [sp, #24]
    40201d10:	a909d3e9 	stp	x9, x20, [sp, #152]
    40201d14:	a90aa3e0 	stp	x0, x8, [sp, #168]
    40201d18:	910263e4 	add	x4, sp, #0x98
    40201d1c:	528000e0 	mov	w0, #0x7                   	// #7
    40201d20:	aa1303e2 	mov	x2, x19
    40201d24:	aa1503e3 	mov	x3, x21
    40201d28:	9400020e 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40201d2c:	aa1603e0 	mov	x0, x22
    40201d30:	a9554ff4 	ldp	x20, x19, [sp, #336]
    40201d34:	a95457f6 	ldp	x22, x21, [sp, #320]
    40201d38:	a9535ff8 	ldp	x24, x23, [sp, #304]
    40201d3c:	a95267fa 	ldp	x26, x25, [sp, #288]
    40201d40:	a9516ffc 	ldp	x28, x27, [sp, #272]
    40201d44:	a9507bfd 	ldp	x29, x30, [sp, #256]
    40201d48:	910583ff 	add	sp, sp, #0x160
    40201d4c:	d65f03c0 	ret
    40201d50:	52800060 	mov	w0, #0x3                   	// #3
    40201d54:	9400057b 	bl	40203340 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    40201d58:	f942b303 	ldr	x3, [x24, #1376]
    40201d5c:	52800060 	mov	w0, #0x3                   	// #3
    40201d60:	52800081 	mov	w1, #0x4                   	// #4
    40201d64:	aa1303e2 	mov	x2, x19
    40201d68:	aa1603e4 	mov	x4, x22
    40201d6c:	aa1703e5 	mov	x5, x23
    40201d70:	94000253 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>
    40201d74:	52800040 	mov	w0, #0x2                   	// #2
    40201d78:	528000a1 	mov	w1, #0x5                   	// #5
    40201d7c:	aa1f03e2 	mov	x2, xzr
    40201d80:	52800043 	mov	w3, #0x2                   	// #2
    40201d84:	14000012 	b	40201dcc <jnox_kernel::ordinary_reservations::irq+0xb04>
    40201d88:	52800040 	mov	w0, #0x2                   	// #2
    40201d8c:	528000a1 	mov	w1, #0x5                   	// #5
    40201d90:	aa1303e2 	mov	x2, x19
    40201d94:	52800043 	mov	w3, #0x2                   	// #2
    40201d98:	aa1503e4 	mov	x4, x21
    40201d9c:	94000248 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>
    40201da0:	52800040 	mov	w0, #0x2                   	// #2
    40201da4:	528000a1 	mov	w1, #0x5                   	// #5
    40201da8:	aa1f03e2 	mov	x2, xzr
    40201dac:	52800043 	mov	w3, #0x2                   	// #2
    40201db0:	aa1603e4 	mov	x4, x22
    40201db4:	14000006 	b	40201dcc <jnox_kernel::ordinary_reservations::irq+0xb04>
    40201db8:	52800040 	mov	w0, #0x2                   	// #2
    40201dbc:	528000a1 	mov	w1, #0x5                   	// #5
    40201dc0:	aa1f03e2 	mov	x2, xzr
    40201dc4:	52800043 	mov	w3, #0x2                   	// #2
    40201dc8:	aa0803e4 	mov	x4, x8
    40201dcc:	f94013e5 	ldr	x5, [sp, #32]
    40201dd0:	9400023b 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>
    40201dd4:	aa1f03e0 	mov	x0, xzr
    40201dd8:	aa1f03e1 	mov	x1, xzr
    40201ddc:	aa1303e2 	mov	x2, x19
    40201de0:	52800043 	mov	w3, #0x2                   	// #2
    40201de4:	aa1f03e4 	mov	x4, xzr
    40201de8:	14000006 	b	40201e00 <jnox_kernel::ordinary_reservations::irq+0xb38>
    40201dec:	394283e4 	ldrb	w4, [sp, #160]
    40201df0:	52800060 	mov	w0, #0x3                   	// #3
    40201df4:	52800041 	mov	w1, #0x2                   	// #2
    40201df8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201dfc:	52800043 	mov	w3, #0x2                   	// #2
    40201e00:	aa1f03e5 	mov	x5, xzr
    40201e04:	9400022e 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>
    40201e08:	d503201f 	nop
    40201e0c:	100203e2 	adr	x2, 40205e88 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.12015700318350904328+0x30>
    40201e10:	aa1303e0 	mov	x0, x19
    40201e14:	14000004 	b	40201e24 <jnox_kernel::ordinary_reservations::irq+0xb5c>
    40201e18:	d503201f 	nop
    40201e1c:	100204e2 	adr	x2, 40205eb8 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.12015700318350904328+0x60>
    40201e20:	aa1503e0 	mov	x0, x21
    40201e24:	52800041 	mov	w1, #0x2                   	// #2
    40201e28:	94000ba9 	bl	40204ccc <core::panicking::panic_bounds_check>
    40201e2c:	94000092 	bl	40202074 <jnox_kernel::ordinary_reservations::run::{{closure}}>

0000000040201e30 <jnox_kernel::ordinary_reservations::run>:
    40201e30:	d105c3ff 	sub	sp, sp, #0x170
    40201e34:	a9127bfd 	stp	x29, x30, [sp, #288]
    40201e38:	a91367fa 	stp	x26, x25, [sp, #304]
    40201e3c:	a9145ff8 	stp	x24, x23, [sp, #320]
    40201e40:	a91557f6 	stp	x22, x21, [sp, #336]
    40201e44:	a9164ff4 	stp	x20, x19, [sp, #352]
    40201e48:	d5033fdf 	isb
    40201e4c:	d53be038 	mrs	x24, cntpct_el0
    40201e50:	d53be014 	mrs	x20, cntfrq_el0
    40201e54:	d5033fdf 	isb
    40201e58:	d53be028 	mrs	x8, cntpct_el0
    40201e5c:	b202e7e9 	mov	x9, #0xcccccccccccccccc    	// #-3689348814741910324
    40201e60:	f29999a9 	movk	x9, #0xcccd
    40201e64:	9bc97e89 	umulh	x9, x20, x9
    40201e68:	ab491113 	adds	x19, x8, x9, lsr #4
    40201e6c:	54000043 	b.cc	40201e74 <jnox_kernel::ordinary_reservations::run+0x44>  // b.lo, b.ul, b.last
    40201e70:	94000081 	bl	40202074 <jnox_kernel::ordinary_reservations::run::{{closure}}>
    40201e74:	910223e8 	add	x8, sp, #0x88
    40201e78:	aa1303e0 	mov	x0, x19
    40201e7c:	aa1403e1 	mov	x1, x20
    40201e80:	2a1f03e2 	mov	w2, wzr
    40201e84:	9400080b 	bl	40203eb0 <jnox_kernel::reservation_jobs::Clock::new>
    40201e88:	394223e8 	ldrb	w8, [sp, #136]
    40201e8c:	7100051f 	cmp	w8, #0x1
    40201e90:	54000061 	b.ne	40201e9c <jnox_kernel::ordinary_reservations::run+0x6c>  // b.any
    40201e94:	394227e4 	ldrb	w4, [sp, #137]
    40201e98:	14000014 	b	40201ee8 <jnox_kernel::ordinary_reservations::run+0xb8>
    40201e9c:	a9495bf7 	ldp	x23, x22, [sp, #144]
    40201ea0:	f94053f5 	ldr	x21, [sp, #160]
    40201ea4:	d5033fdf 	isb
    40201ea8:	d53be021 	mrs	x1, cntpct_el0
    40201eac:	a908dbf4 	stp	x20, x22, [sp, #136]
    40201eb0:	a909ffff 	stp	xzr, xzr, [sp, #152]
    40201eb4:	910223e4 	add	x4, sp, #0x88
    40201eb8:	52800020 	mov	w0, #0x1                   	// #1
    40201ebc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201ec0:	52800043 	mov	w3, #0x2                   	// #2
    40201ec4:	940001a7 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40201ec8:	910223e8 	add	x8, sp, #0x88
    40201ecc:	2a1f03e0 	mov	w0, wzr
    40201ed0:	2a1f03e1 	mov	w1, wzr
    40201ed4:	9400060f 	bl	40203710 <jnox_kernel::reservation_jobs::Jobs::new>
    40201ed8:	f94047e8 	ldr	x8, [sp, #136]
    40201edc:	f100091f 	cmp	x8, #0x2
    40201ee0:	54000101 	b.ne	40201f00 <jnox_kernel::ordinary_reservations::run+0xd0>  // b.any
    40201ee4:	394243e4 	ldrb	w4, [sp, #144]
    40201ee8:	52800060 	mov	w0, #0x3                   	// #3
    40201eec:	52800041 	mov	w1, #0x2                   	// #2
    40201ef0:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201ef4:	52800043 	mov	w3, #0x2                   	// #2
    40201ef8:	aa1f03e5 	mov	x5, xzr
    40201efc:	940001f0 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>
    40201f00:	910023e0 	add	x0, sp, #0x8
    40201f04:	910223e1 	add	x1, sp, #0x88
    40201f08:	52801002 	mov	w2, #0x80                  	// #128
    40201f0c:	94000ec0 	bl	40205a0c <memcpy>
    40201f10:	d5033fdf 	isb
    40201f14:	d53be021 	mrs	x1, cntpct_el0
    40201f18:	a908cff8 	stp	x24, x19, [sp, #136]
    40201f1c:	a909ffff 	stp	xzr, xzr, [sp, #152]
    40201f20:	910223e4 	add	x4, sp, #0x88
    40201f24:	52800300 	mov	w0, #0x18                  	// #24
    40201f28:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201f2c:	52800043 	mov	w3, #0x2                   	// #2
    40201f30:	9400018c 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40201f34:	94000a23 	bl	402047c0 <jnox_kernel::context::init_timer_irq>
    40201f38:	aa1f03f4 	mov	x20, xzr
    40201f3c:	910423f8 	add	x24, sp, #0x108
    40201f40:	aa1403e0 	mov	x0, x20
    40201f44:	940001a8 	bl	402025e4 <jnox_kernel::ordinary_reservations::fresh>
    40201f48:	f8347b00 	str	x0, [x24, x20, lsl #3]
    40201f4c:	91000694 	add	x20, x20, #0x1
    40201f50:	f1000e9f 	cmp	x20, #0x3
    40201f54:	54ffff61 	b.ne	40201f40 <jnox_kernel::ordinary_reservations::run+0x110>  // b.any
    40201f58:	aa1f03f4 	mov	x20, xzr
    40201f5c:	d503201f 	nop
    40201f60:	100abe08 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328>
    40201f64:	52800318 	mov	w24, #0x18                  	// #24
    40201f68:	d503201f 	nop
    40201f6c:	1001f639 	adr	x25, 40205e30 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.12015700318350904328>
    40201f70:	d5033fdf 	isb
    40201f74:	d53be021 	mrs	x1, cntpct_el0
    40201f78:	f1000a9f 	cmp	x20, #0x2
    40201f7c:	54000062 	b.cs	40201f88 <jnox_kernel::ordinary_reservations::run+0x158>  // b.hs, b.nlast
    40201f80:	f8747b29 	ldr	x9, [x25, x20, lsl #3]
    40201f84:	14000002 	b	40201f8c <jnox_kernel::ordinary_reservations::run+0x15c>
    40201f88:	52818329 	mov	w9, #0xc19                 	// #3097
    40201f8c:	9140111a 	add	x26, x8, #0x4, lsl #12
    40201f90:	a908ebe8 	stp	x8, x26, [sp, #136]
    40201f94:	a909ffe9 	stp	x9, xzr, [sp, #152]
    40201f98:	910223e4 	add	x4, sp, #0x88
    40201f9c:	52800220 	mov	w0, #0x11                  	// #17
    40201fa0:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40201fa4:	aa1403e3 	mov	x3, x20
    40201fa8:	9400016e 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40201fac:	f1002318 	subs	x24, x24, #0x8
    40201fb0:	91000694 	add	x20, x20, #0x1
    40201fb4:	aa1a03e8 	mov	x8, x26
    40201fb8:	54fffdc1 	b.ne	40201f70 <jnox_kernel::ordinary_reservations::run+0x140>  // b.any
    40201fbc:	d503201f 	nop
    40201fc0:	1002a214 	adr	x20, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40201fc4:	910023e1 	add	x1, sp, #0x8
    40201fc8:	aa1403e0 	mov	x0, x20
    40201fcc:	52801002 	mov	w2, #0x80                  	// #128
    40201fd0:	94000e8f 	bl	40205a0c <memcpy>
    40201fd4:	52800048 	mov	w8, #0x2                   	// #2
    40201fd8:	f9004288 	str	x8, [x20, #128]
    40201fdc:	52800069 	mov	w9, #0x3                   	// #3
    40201fe0:	3904c289 	strb	w9, [x20, #304]
    40201fe4:	a913da97 	stp	x23, x22, [x20, #312]
    40201fe8:	52800449 	mov	w9, #0x22                  	// #34
    40201fec:	a914a695 	stp	x21, x9, [x20, #328]
    40201ff0:	9280000a 	mov	x10, #0xffffffffffffffff    	// #-1
    40201ff4:	a915a28a 	stp	x10, x8, [x20, #344]
    40201ff8:	a950b3eb 	ldp	x11, x12, [sp, #264]
    40201ffc:	a916b28b 	stp	x11, x12, [x20, #360]
    40202000:	f9408feb 	ldr	x11, [sp, #280]
    40202004:	a917fe8b 	stp	x11, xzr, [x20, #376]
    40202008:	a918aa9f 	stp	xzr, x10, [x20, #392]
    4020200c:	a919fe8a 	stp	x10, xzr, [x20, #408]
    40202010:	a91aa29f 	stp	xzr, x8, [x20, #424]
    40202014:	52800028 	mov	w8, #0x1                   	// #1
    40202018:	a91bfe88 	stp	x8, xzr, [x20, #440]
    4020201c:	52814328 	mov	w8, #0xa19                 	// #2585
    40202020:	a91ca29f 	stp	xzr, x8, [x20, #456]
    40202024:	52816328 	mov	w8, #0xb19                 	// #2841
    40202028:	f900ee88 	str	x8, [x20, #472]
    4020202c:	d5033fdf 	isb
    40202030:	d53be021 	mrs	x1, cntpct_el0
    40202034:	a908a7f3 	stp	x19, x9, [sp, #136]
    40202038:	a909ffff 	stp	xzr, xzr, [sp, #152]
    4020203c:	910223e4 	add	x4, sp, #0x88
    40202040:	52800040 	mov	w0, #0x2                   	// #2
    40202044:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40202048:	52800043 	mov	w3, #0x2                   	// #2
    4020204c:	94000145 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202050:	94000194 	bl	402026a0 <jnox_kernel::ordinary_reservations::state>
    40202054:	aa1f03e0 	mov	x0, xzr
    40202058:	aa1f03e1 	mov	x1, xzr
    4020205c:	aa1303e2 	mov	x2, x19
    40202060:	9400032a 	bl	40202d08 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40202064:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    40202068:	52800041 	mov	w1, #0x2                   	// #2
    4020206c:	94000481 	bl	40203270 <jnox_kernel::ordinary_reservations::Runtime::select>
    40202070:	97fffc4f 	bl	402011ac <sched_start_frame>

0000000040202074 <jnox_kernel::ordinary_reservations::run::{{closure}}>:
    40202074:	f81f0ffe 	str	x30, [sp, #-16]!
    40202078:	97fffc8c 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

000000004020207c <jnox_kernel::ordinary_reservations::svc>:
    4020207c:	f81f0ffe 	str	x30, [sp, #-16]!
    40202080:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202084:	f9420108 	ldr	x8, [x8, #1024]
    40202088:	f100091f 	cmp	x8, #0x2
    4020208c:	54000660 	b.eq	40202158 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.none
    40202090:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202094:	f942b108 	ldr	x8, [x8, #1376]
    40202098:	d503201f 	nop
    4020209c:	100ab429 	adr	x9, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328>
    402020a0:	f100091f 	cmp	x8, #0x2
    402020a4:	8b08392a 	add	x10, x9, x8, lsl #14
    402020a8:	fa401142 	ccmp	x10, x0, #0x2, ne  // ne = any
    402020ac:	54000568 	b.hi	40202158 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    402020b0:	b10d041f 	cmn	x0, #0x341
    402020b4:	54000528 	b.hi	40202158 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    402020b8:	d372c508 	lsl	x8, x8, #14
    402020bc:	8b080128 	add	x8, x9, x8
    402020c0:	91401108 	add	x8, x8, #0x4, lsl #12
    402020c4:	910d0009 	add	x9, x0, #0x340
    402020c8:	eb08013f 	cmp	x9, x8
    402020cc:	54000468 	b.hi	40202158 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.pmore
    402020d0:	f9409c01 	ldr	x1, [x0, #312]
    402020d4:	d5385203 	mrs	x3, esr_el1
    402020d8:	d35afc68 	lsr	x8, x3, #26
    402020dc:	f100551f 	cmp	x8, #0x15
    402020e0:	540003c1 	b.ne	40202158 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.any
    402020e4:	12003c68 	and	w8, w3, #0xffff
    402020e8:	7100051f 	cmp	w8, #0x1
    402020ec:	540000a0 	b.eq	40202100 <jnox_kernel::ordinary_reservations::svc+0x84>  // b.none
    402020f0:	7100091f 	cmp	w8, #0x2
    402020f4:	54000321 	b.ne	40202158 <jnox_kernel::ordinary_reservations::svc+0xdc>  // b.any
    402020f8:	52800042 	mov	w2, #0x2                   	// #2
    402020fc:	14000002 	b	40202104 <jnox_kernel::ordinary_reservations::svc+0x88>
    40202100:	52800022 	mov	w2, #0x1                   	// #1
    40202104:	94000322 	bl	40202d8c <jnox_kernel::ordinary_reservations::Runtime::close>
    40202108:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020210c:	9114e108 	add	x8, x8, #0x538
    40202110:	f9401100 	ldr	x0, [x8, #32]
    40202114:	91000409 	add	x9, x0, #0x1
    40202118:	a9402908 	ldp	x8, x10, [x8]
    4020211c:	9bca7d2b 	umulh	x11, x9, x10
    40202120:	eb0b03ff 	cmp	xzr, x11
    40202124:	1a9f07eb 	cset	w11, ne  // ne = any
    40202128:	9b0a7d29 	mul	x9, x9, x10
    4020212c:	ab080122 	adds	x2, x9, x8
    40202130:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40202134:	3700014b 	tbnz	w11, #0, 4020215c <jnox_kernel::ordinary_reservations::svc+0xe0>
    40202138:	35000128 	cbnz	w8, 4020215c <jnox_kernel::ordinary_reservations::svc+0xe0>
    4020213c:	aa1f03e1 	mov	x1, xzr
    40202140:	940002f2 	bl	40202d08 <jnox_kernel::ordinary_reservations::Runtime::arm>
    40202144:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202148:	f942ad00 	ldr	x0, [x8, #1368]
    4020214c:	52800041 	mov	w1, #0x2                   	// #2
    40202150:	f84107fe 	ldr	x30, [sp], #16
    40202154:	14000447 	b	40203270 <jnox_kernel::ordinary_reservations::Runtime::select>
    40202158:	97fffc54 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    4020215c:	52800060 	mov	w0, #0x3                   	// #3
    40202160:	94000478 	bl	40203340 <jnox_kernel::ordinary_reservations::checked::{{closure}}>

0000000040202164 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328>:
    40202164:	d10743ff 	sub	sp, sp, #0x1d0
    40202168:	a9177bfd 	stp	x29, x30, [sp, #368]
    4020216c:	a9186ffc 	stp	x28, x27, [sp, #384]
    40202170:	a91967fa 	stp	x26, x25, [sp, #400]
    40202174:	a91a5ff8 	stp	x24, x23, [sp, #416]
    40202178:	a91b57f6 	stp	x22, x21, [sp, #432]
    4020217c:	a91c4ff4 	stp	x20, x19, [sp, #448]
    40202180:	d50342df 	msr	daifset, #0x2
    40202184:	d5033fdf 	isb
    40202188:	d5033fdf 	isb
    4020218c:	d53be036 	mrs	x22, cntpct_el0
    40202190:	b0000035 	adrp	x21, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202194:	f94202a8 	ldr	x8, [x21, #1024]
    40202198:	f100091f 	cmp	x8, #0x2
    4020219c:	54001ac0 	b.eq	402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>  // b.none
    402021a0:	d5033fdf 	isb
    402021a4:	d53be038 	mrs	x24, cntpct_el0
    402021a8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021ac:	f942f108 	ldr	x8, [x8, #1504]
    402021b0:	f100091f 	cmp	x8, #0x2
    402021b4:	54001a01 	b.ne	402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>  // b.any
    402021b8:	b0000037 	adrp	x23, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021bc:	f9429ef3 	ldr	x19, [x23, #1336]
    402021c0:	d503201f 	nop
    402021c4:	1010b0e8 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    402021c8:	c8dffd08 	ldar	x8, [x8]
    402021cc:	b5001948 	cbnz	x8, 402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>
    402021d0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021d4:	91156108 	add	x8, x8, #0x558
    402021d8:	f9400109 	ldr	x9, [x8]
    402021dc:	b100053f 	cmn	x9, #0x1
    402021e0:	540018a1 	b.ne	402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>  // b.any
    402021e4:	f9400508 	ldr	x8, [x8, #8]
    402021e8:	f100091f 	cmp	x8, #0x2
    402021ec:	54001841 	b.ne	402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>  // b.any
    402021f0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402021f4:	9114c108 	add	x8, x8, #0x530
    402021f8:	39400109 	ldrb	w9, [x8]
    402021fc:	71000d3f 	cmp	w9, #0x3
    40202200:	540017a1 	b.ne	402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>  // b.any
    40202204:	f9402d09 	ldr	x9, [x8, #88]
    40202208:	b5001769 	cbnz	x9, 402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>
    4020220c:	f9402908 	ldr	x8, [x8, #80]
    40202210:	eb13011f 	cmp	x8, x19
    40202214:	54001701 	b.ne	402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>  // b.any
    40202218:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328+0xb8e0>
    4020221c:	f943f508 	ldr	x8, [x8, #2024]
    40202220:	f100051f 	cmp	x8, #0x1
    40202224:	54001681 	b.ne	402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>  // b.any
    40202228:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020222c:	f9423508 	ldr	x8, [x8, #1128]
    40202230:	b5001628 	cbnz	x8, 402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>
    40202234:	5280002a 	mov	w10, #0x1                   	// #1
    40202238:	d503201f 	nop
    4020223c:	10028e39 	adr	x25, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40202240:	8b080328 	add	x8, x25, x8
    40202244:	3941e109 	ldrb	w9, [x8, #120]
    40202248:	3600008a 	tbz	w10, #0, 40202258 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0xf4>
    4020224c:	2a1f03ea 	mov	w10, wzr
    40202250:	52800028 	mov	w8, #0x1                   	// #1
    40202254:	34ffff69 	cbz	w9, 40202240 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0xdc>
    40202258:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020225c:	39518108 	ldrb	w8, [x8, #1120]
    40202260:	7100013f 	cmp	w9, #0x0
    40202264:	7a430900 	ccmp	w8, #0x3, #0x0, eq  // eq = none
    40202268:	54001461 	b.ne	402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>  // b.any
    4020226c:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202270:	9111c108 	add	x8, x8, #0x470
    40202274:	f9400109 	ldr	x9, [x8]
    40202278:	b50013e9 	cbnz	x9, 402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>
    4020227c:	f9400908 	ldr	x8, [x8, #16]
    40202280:	f100091f 	cmp	x8, #0x2
    40202284:	54001381 	b.ne	402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>  // b.any
    40202288:	f94202a8 	ldr	x8, [x21, #1024]
    4020228c:	f100051f 	cmp	x8, #0x1
    40202290:	54000121 	b.ne	402022b4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x150>  // b.any
    40202294:	b0000021 	adrp	x1, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202298:	91102021 	add	x1, x1, #0x408
    4020229c:	f940183a 	ldr	x26, [x1, #48]
    402022a0:	910243e0 	add	x0, sp, #0x90
    402022a4:	52800602 	mov	w2, #0x30                  	// #48
    402022a8:	94000dd9 	bl	40205a0c <memcpy>
    402022ac:	52800028 	mov	w8, #0x1                   	// #1
    402022b0:	14000017 	b	4020230c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x1a8>
    402022b4:	910303e0 	add	x0, sp, #0xc0
    402022b8:	9100a014 	add	x20, x0, #0x28
    402022bc:	52800028 	mov	w8, #0x1                   	// #1
    402022c0:	b0000021 	adrp	x1, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402022c4:	91102021 	add	x1, x1, #0x408
    402022c8:	2a0803fa 	mov	w26, w8
    402022cc:	9100a03b 	add	x27, x1, #0x28
    402022d0:	52800502 	mov	w2, #0x28                  	// #40
    402022d4:	94000dce 	bl	40205a0c <memcpy>
    402022d8:	2a1f03e8 	mov	w8, wzr
    402022dc:	aa1b03e1 	mov	x1, x27
    402022e0:	aa1403e0 	mov	x0, x20
    402022e4:	3707ff3a 	tbnz	w26, #0, 402022c8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x164>
    402022e8:	910243e0 	add	x0, sp, #0x90
    402022ec:	910303e1 	add	x1, sp, #0xc0
    402022f0:	52800602 	mov	w2, #0x30                  	// #48
    402022f4:	94000dc6 	bl	40205a0c <memcpy>
    402022f8:	aa1f03e8 	mov	x8, xzr
    402022fc:	a94f27fa 	ldp	x26, x9, [sp, #240]
    40202300:	a9502fea 	ldp	x10, x11, [sp, #256]
    40202304:	a907abe9 	stp	x9, x10, [sp, #120]
    40202308:	f90047eb 	str	x11, [sp, #136]
    4020230c:	b000003b 	adrp	x27, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202310:	9111e37b 	add	x27, x27, #0x478
    40202314:	39400b7c 	ldrb	w28, [x27, #2]
    40202318:	7940037d 	ldrh	w29, [x27]
    4020231c:	aa1b03f4 	mov	x20, x27
    40202320:	f8008e88 	str	x8, [x20, #8]!
    40202324:	91004360 	add	x0, x27, #0x10
    40202328:	910243e1 	add	x1, sp, #0x90
    4020232c:	52800602 	mov	w2, #0x30                  	// #48
    40202330:	94000db7 	bl	40205a0c <memcpy>
    40202334:	52800068 	mov	w8, #0x3                   	// #3
    40202338:	3901a368 	strb	w8, [x27, #104]
    4020233c:	a947a7e8 	ldp	x8, x9, [sp, #120]
    40202340:	a904237a 	stp	x26, x8, [x27, #64]
    40202344:	f94047e8 	ldr	x8, [sp, #136]
    40202348:	a9052369 	stp	x9, x8, [x27, #80]
    4020234c:	a9077f7f 	stp	xzr, xzr, [x27, #112]
    40202350:	7901037d 	strh	w29, [x27, #128]
    40202354:	39020b7c 	strb	w28, [x27, #130]
    40202358:	910303e8 	add	x8, sp, #0xc0
    4020235c:	aa1403e0 	mov	x0, x20
    40202360:	9400047b 	bl	4020354c <jnox_kernel::reservation_jobs::Jobs::prepare_destination>
    40202364:	f94063e8 	ldr	x8, [sp, #192]
    40202368:	f100091f 	cmp	x8, #0x2
    4020236c:	54000cc0 	b.eq	40202504 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x3a0>  // b.none
    40202370:	910043e0 	add	x0, sp, #0x10
    40202374:	910303e1 	add	x1, sp, #0xc0
    40202378:	52800d02 	mov	w2, #0x68                  	// #104
    4020237c:	94000da4 	bl	40205a0c <memcpy>
    40202380:	b0000020 	adrp	x0, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202384:	91120000 	add	x0, x0, #0x480
    40202388:	910043e1 	add	x1, sp, #0x10
    4020238c:	94000487 	bl	402035a8 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision>
    40202390:	36000b20 	tbz	w0, #0, 402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>
    40202394:	b94013e8 	ldr	w8, [sp, #16]
    40202398:	36000b48 	tbz	w8, #0, 40202500 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x39c>
    4020239c:	3941cbe8 	ldrb	w8, [sp, #114]
    402023a0:	34000188 	cbz	w8, 402023d0 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x26c>
    402023a4:	71000d1f 	cmp	w8, #0x3
    402023a8:	54000a60 	b.eq	402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>  // b.none
    402023ac:	f9400fe0 	ldr	x0, [sp, #24]
    402023b0:	f100041f 	cmp	x0, #0x1
    402023b4:	54000ce8 	b.hi	40202550 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x3ec>  // b.pmore
    402023b8:	8b000f28 	add	x8, x25, x0, lsl #3
    402023bc:	f940e108 	ldr	x8, [x8, #448]
    402023c0:	b104011f 	cmn	x8, #0x100
    402023c4:	540009e2 	b.cs	40202500 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x39c>  // b.hs, b.nlast
    402023c8:	9104011a 	add	x26, x8, #0x100
    402023cc:	14000002 	b	402023d4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x270>
    402023d0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    402023d4:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402023d8:	9114e108 	add	x8, x8, #0x538
    402023dc:	a9402508 	ldp	x8, x9, [x8]
    402023e0:	ab09011b 	adds	x27, x8, x9
    402023e4:	540008a2 	b.cs	402024f8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x394>  // b.hs, b.nlast
    402023e8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402023ec:	f942a508 	ldr	x8, [x8, #1352]
    402023f0:	eb08037c 	subs	x28, x27, x8
    402023f4:	54000823 	b.cc	402024f8 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x394>  // b.lo, b.ul, b.last
    402023f8:	f9009bf9 	str	x25, [sp, #304]
    402023fc:	910303f4 	add	x20, sp, #0xc0
    40202400:	9104e3e8 	add	x8, sp, #0x138
    40202404:	9104c3e0 	add	x0, sp, #0x130
    40202408:	aa1f03e1 	mov	x1, xzr
    4020240c:	94000716 	bl	40204064 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    40202410:	910303e0 	add	x0, sp, #0xc0
    40202414:	9104e3e1 	add	x1, sp, #0x138
    40202418:	52800702 	mov	w2, #0x38                  	// #56
    4020241c:	94000d7c 	bl	40205a0c <memcpy>
    40202420:	52800039 	mov	w25, #0x1                   	// #1
    40202424:	9104e3e8 	add	x8, sp, #0x138
    40202428:	9104c3e0 	add	x0, sp, #0x130
    4020242c:	52800021 	mov	w1, #0x1                   	// #1
    40202430:	9400070d 	bl	40204064 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>
    40202434:	9100e280 	add	x0, x20, #0x38
    40202438:	9104e3e1 	add	x1, sp, #0x138
    4020243c:	52800702 	mov	w2, #0x38                  	// #56
    40202440:	94000d73 	bl	40205a0c <memcpy>
    40202444:	d503201f 	nop
    40202448:	10028cd4 	adr	x20, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    4020244c:	910043e1 	add	x1, sp, #0x10
    40202450:	aa1403e0 	mov	x0, x20
    40202454:	52800d02 	mov	w2, #0x68                  	// #104
    40202458:	94000d6d 	bl	40205a0c <memcpy>
    4020245c:	a906e698 	stp	x24, x25, [x20, #104]
    40202460:	a907ee93 	stp	x19, x27, [x20, #120]
    40202464:	a908ea9c 	stp	x28, x26, [x20, #136]
    40202468:	91026280 	add	x0, x20, #0x98
    4020246c:	910303e1 	add	x1, sp, #0xc0
    40202470:	52800e02 	mov	w2, #0x70                  	// #112
    40202474:	94000d66 	bl	40205a0c <memcpy>
    40202478:	d5033fdf 	isb
    4020247c:	d53be034 	mrs	x20, cntpct_el0
    40202480:	eb140268 	subs	x8, x19, x20
    40202484:	9a8833e8 	csel	x8, xzr, x8, cc  // cc = lo, ul, last
    40202488:	a913cff8 	stp	x24, x19, [sp, #312]
    4020248c:	a914ffe8 	stp	x8, xzr, [sp, #328]
    40202490:	9104e3e4 	add	x4, sp, #0x138
    40202494:	528002c0 	mov	w0, #0x16                  	// #22
    40202498:	aa1403e1 	mov	x1, x20
    4020249c:	aa1f03e2 	mov	x2, xzr
    402024a0:	52800043 	mov	w3, #0x2                   	// #2
    402024a4:	9400002f 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    402024a8:	eb18029f 	cmp	x20, x24
    402024ac:	540003a3 	b.cc	40202520 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x3bc>  // b.lo, b.ul, b.last
    402024b0:	eb13029f 	cmp	x20, x19
    402024b4:	54000362 	b.cs	40202520 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x3bc>  // b.hs, b.nlast
    402024b8:	d5033fdf 	isb
    402024bc:	d53be024 	mrs	x4, cntpct_el0
    402024c0:	d503201f 	nop
    402024c4:	101092e8 	adr	x8, 40223720 <jnox_kernel::ordinary_reservations::RECEIPT>
    402024c8:	a9001116 	stp	x22, x4, [x8]
    402024cc:	f94202a8 	ldr	x8, [x21, #1024]
    402024d0:	f100091f 	cmp	x8, #0x2
    402024d4:	54000100 	b.eq	402024f4 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x390>  // b.none
    402024d8:	f9429ee5 	ldr	x5, [x23, #1336]
    402024dc:	eb05009f 	cmp	x4, x5
    402024e0:	540002e2 	b.cs	4020253c <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x3d8>  // b.hs, b.nlast
    402024e4:	d50342ff 	msr	daifclr, #0x2
    402024e8:	d5033fdf 	isb
    402024ec:	d503207f 	wfi
    402024f0:	17ffffff 	b	402024ec <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328+0x388>
    402024f4:	97fffb6d 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402024f8:	52800060 	mov	w0, #0x3                   	// #3
    402024fc:	94000391 	bl	40203340 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    40202500:	97fffedd 	bl	40202074 <jnox_kernel::ordinary_reservations::run::{{closure}}>
    40202504:	394323e4 	ldrb	w4, [sp, #200]
    40202508:	52800060 	mov	w0, #0x3                   	// #3
    4020250c:	52800041 	mov	w1, #0x2                   	// #2
    40202510:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40202514:	52800043 	mov	w3, #0x2                   	// #2
    40202518:	aa1f03e5 	mov	x5, xzr
    4020251c:	94000068 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>
    40202520:	52800040 	mov	w0, #0x2                   	// #2
    40202524:	52800121 	mov	w1, #0x9                   	// #9
    40202528:	aa1f03e2 	mov	x2, xzr
    4020252c:	52800043 	mov	w3, #0x2                   	// #2
    40202530:	aa1403e4 	mov	x4, x20
    40202534:	aa1303e5 	mov	x5, x19
    40202538:	94000061 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>
    4020253c:	52800040 	mov	w0, #0x2                   	// #2
    40202540:	52800161 	mov	w1, #0xb                   	// #11
    40202544:	aa1f03e2 	mov	x2, xzr
    40202548:	52800043 	mov	w3, #0x2                   	// #2
    4020254c:	9400005c 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>
    40202550:	d503201f 	nop
    40202554:	1001ca62 	adr	x2, 40205ea0 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.12015700318350904328+0x48>
    40202558:	52800041 	mov	w1, #0x2                   	// #2
    4020255c:	940009dc 	bl	40204ccc <core::panicking::panic_bounds_check>

0000000040202560 <jnox_kernel::ordinary_reservations::event>:
    40202560:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202564:	f9438909 	ldr	x9, [x8, #1808]
    40202568:	f110013f 	cmp	x9, #0x400
    4020256c:	54000241 	b.ne	402025b4 <jnox_kernel::ordinary_reservations::event+0x54>  // b.any
    40202570:	aa1f03e8 	mov	x8, xzr
    40202574:	52800309 	mov	w9, #0x18                  	// #24
    40202578:	72a12009 	movk	w9, #0x900, lsl #16
    4020257c:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    40202580:	d503201f 	nop
    40202584:	1001c5eb 	adr	x11, 40205e40 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.12015700318350904328+0x10>
    40202588:	3868696c 	ldrb	w12, [x11, x8]
    4020258c:	b940012d 	ldr	w13, [x9]
    40202590:	3628006d 	tbz	w13, #5, 4020259c <jnox_kernel::ordinary_reservations::event+0x3c>
    40202594:	d5033fdf 	isb
    40202598:	17fffffd 	b	4020258c <jnox_kernel::ordinary_reservations::event+0x2c>
    4020259c:	91000508 	add	x8, x8, #0x1
    402025a0:	b900014c 	str	w12, [x10]
    402025a4:	f100511f 	cmp	x8, #0x14
    402025a8:	54ffff01 	b.ne	40202588 <jnox_kernel::ordinary_reservations::event+0x28>  // b.any
    402025ac:	d503205f 	wfe
    402025b0:	17ffffff 	b	402025ac <jnox_kernel::ordinary_reservations::event+0x4c>
    402025b4:	d503201f 	nop
    402025b8:	10028b0a 	adr	x10, 40207718 <jnox_kernel::ordinary_reservations::TRACE>
    402025bc:	8b09194a 	add	x10, x10, x9, lsl #6
    402025c0:	a9000540 	stp	x0, x1, [x10]
    402025c4:	a940308b 	ldp	x11, x12, [x4]
    402025c8:	a9010d42 	stp	x2, x3, [x10, #16]
    402025cc:	a941388d 	ldp	x13, x14, [x4, #16]
    402025d0:	a902314b 	stp	x11, x12, [x10, #32]
    402025d4:	a903394d 	stp	x13, x14, [x10, #48]
    402025d8:	91000529 	add	x9, x9, #0x1
    402025dc:	f9038909 	str	x9, [x8, #1808]
    402025e0:	d65f03c0 	ret

00000000402025e4 <jnox_kernel::ordinary_reservations::fresh>:
    402025e4:	d10143ff 	sub	sp, sp, #0x50
    402025e8:	a90357f6 	stp	x22, x21, [sp, #48]
    402025ec:	a9044ff4 	stp	x20, x19, [sp, #64]
    402025f0:	aa0003f3 	mov	x19, x0
    402025f4:	d503201f 	nop
    402025f8:	100079e8 	adr	x8, 40203534 <reservation_worker_a>
    402025fc:	d503201f 	nop
    40202600:	10007a09 	adr	x9, 40203540 <reservation_worker_b>
    40202604:	d503201f 	nop
    40202608:	10ffdaea 	adr	x10, 40202164 <_ZN11jnox_kernel21ordinary_reservations4idle17hc965054124715ef9E.llvm.12015700318350904328>
    4020260c:	a900a7e8 	stp	x8, x9, [sp, #8]
    40202610:	a901fbea 	stp	x10, x30, [sp, #24]
    40202614:	f100081f 	cmp	x0, #0x2
    40202618:	540003a8 	b.hi	4020268c <jnox_kernel::ordinary_reservations::fresh+0xa8>  // b.pmore
    4020261c:	910023e8 	add	x8, sp, #0x8
    40202620:	f8737915 	ldr	x21, [x8, x19, lsl #3]
    40202624:	d503201f 	nop
    40202628:	100a87c8 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328>
    4020262c:	8b133916 	add	x22, x8, x19, lsl #14
    40202630:	52879808 	mov	w8, #0x3cc0                	// #15552
    40202634:	8b0802d4 	add	x20, x22, x8
    40202638:	aa1403e0 	mov	x0, x20
    4020263c:	2a1f03e1 	mov	w1, wzr
    40202640:	52806802 	mov	w2, #0x340                 	// #832
    40202644:	94000d7e 	bl	40205c3c <memset>
    40202648:	f91eded5 	str	x21, [x22, #15800]
    4020264c:	528068a8 	mov	w8, #0x345                 	// #837
    40202650:	f91ee2c8 	str	x8, [x22, #15808]
    40202654:	f1000a7f 	cmp	x19, #0x2
    40202658:	54000061 	b.ne	40202664 <jnox_kernel::ordinary_reservations::fresh+0x80>  // b.any
    4020265c:	52818328 	mov	w8, #0xc19                 	// #3097
    40202660:	14000004 	b	40202670 <jnox_kernel::ordinary_reservations::fresh+0x8c>
    40202664:	d503201f 	nop
    40202668:	1001be48 	adr	x8, 40205e30 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.12015700318350904328>
    4020266c:	f8737908 	ldr	x8, [x8, x19, lsl #3]
    40202670:	f9008e88 	str	x8, [x20, #280]
    40202674:	aa1403e0 	mov	x0, x20
    40202678:	a9444ff4 	ldp	x20, x19, [sp, #64]
    4020267c:	a94357f6 	ldp	x22, x21, [sp, #48]
    40202680:	f94013fe 	ldr	x30, [sp, #32]
    40202684:	910143ff 	add	sp, sp, #0x50
    40202688:	d65f03c0 	ret
    4020268c:	d503201f 	nop
    40202690:	1001be42 	adr	x2, 40205e58 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.12015700318350904328>
    40202694:	aa1303e0 	mov	x0, x19
    40202698:	52800061 	mov	w1, #0x3                   	// #3
    4020269c:	9400098c 	bl	40204ccc <core::panicking::panic_bounds_check>

00000000402026a0 <jnox_kernel::ordinary_reservations::state>:
    402026a0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402026a4:	f9420108 	ldr	x8, [x8, #1024]
    402026a8:	f100091f 	cmp	x8, #0x2
    402026ac:	54000040 	b.eq	402026b4 <jnox_kernel::ordinary_reservations::state+0x14>  // b.none
    402026b0:	d65f03c0 	ret
    402026b4:	f81f0ffe 	str	x30, [sp, #-16]!
    402026b8:	97fffafc 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

00000000402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>:
    402026bc:	d10603ff 	sub	sp, sp, #0x180
    402026c0:	a9127bfd 	stp	x29, x30, [sp, #288]
    402026c4:	a9136ffc 	stp	x28, x27, [sp, #304]
    402026c8:	a91467fa 	stp	x26, x25, [sp, #320]
    402026cc:	a9155ff8 	stp	x24, x23, [sp, #336]
    402026d0:	a91657f6 	stp	x22, x21, [sp, #352]
    402026d4:	a9174ff4 	stp	x20, x19, [sp, #368]
    402026d8:	d5034fdf 	msr	daifset, #0xf
    402026dc:	d51be23f 	msr	cntp_ctl_el0, xzr
    402026e0:	d5033fdf 	isb
    402026e4:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328+0xb8e0>
    402026e8:	395f6109 	ldrb	w9, [x8, #2008]
    402026ec:	7100053f 	cmp	w9, #0x1
    402026f0:	54000061 	b.ne	402026fc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x40>  // b.any
    402026f4:	d503205f 	wfe
    402026f8:	17ffffff 	b	402026f4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x38>
    402026fc:	aa0303fb 	mov	x27, x3
    40202700:	aa0203fc 	mov	x28, x2
    40202704:	a90807e0 	stp	x0, x1, [sp, #128]
    40202708:	a90917e4 	stp	x4, x5, [sp, #144]
    4020270c:	52800029 	mov	w9, #0x1                   	// #1
    40202710:	391f6109 	strb	w9, [x8, #2008]
    40202714:	d503201f 	nop
    40202718:	1010b888 	adr	x8, 40223e28 <jnox_kernel::ordinary_reservations::stage_hooks::stage_probe::OBSERVATION>
    4020271c:	f940050a 	ldr	x10, [x8, #8]
    40202720:	f940090b 	ldr	x11, [x8, #16]
    40202724:	f9400108 	ldr	x8, [x8]
    40202728:	7200011f 	tst	w8, #0x1
    4020272c:	9a9f116b 	csel	x11, x11, xzr, ne  // ne = any
    40202730:	9a9f1141 	csel	x1, x10, xzr, ne  // ne = any
    40202734:	a90ba7e9 	stp	x9, x9, [sp, #184]
    40202738:	f100011f 	cmp	x8, #0x0
    4020273c:	1a9f07e8 	cset	w8, ne  // ne = any
    40202740:	a90cafe8 	stp	x8, x11, [sp, #200]
    40202744:	9102e3e4 	add	x4, sp, #0xb8
    40202748:	528004c0 	mov	w0, #0x26                  	// #38
    4020274c:	aa1f03e2 	mov	x2, xzr
    40202750:	52800043 	mov	w3, #0x2                   	// #2
    40202754:	97ffff83 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202758:	d503201f 	nop
    4020275c:	10107e29 	adr	x9, 40223720 <jnox_kernel::ordinary_reservations::RECEIPT>
    40202760:	a9400528 	ldp	x8, x1, [x9]
    40202764:	a9415538 	ldp	x24, x21, [x9, #16]
    40202768:	a9424d34 	ldp	x20, x19, [x9, #32]
    4020276c:	a943692b 	ldp	x11, x26, [x9, #48]
    40202770:	f940212a 	ldr	x10, [x9, #64]
    40202774:	a9012fea 	stp	x10, x11, [sp, #16]
    40202778:	a944a92b 	ldp	x11, x10, [x9, #72]
    4020277c:	a9022beb 	stp	x11, x10, [sp, #32]
    40202780:	a945a93d 	ldp	x29, x10, [x9, #88]
    40202784:	f9005bea 	str	x10, [sp, #176]
    40202788:	a946a92b 	ldp	x11, x10, [x9, #104]
    4020278c:	f9001fea 	str	x10, [sp, #56]
    40202790:	f9403d2a 	ldr	x10, [x9, #120]
    40202794:	a9042fea 	stp	x10, x11, [sp, #64]
    40202798:	a948292b 	ldp	x11, x10, [x9, #128]
    4020279c:	f9001beb 	str	x11, [sp, #48]
    402027a0:	f9003fea 	str	x10, [sp, #120]
    402027a4:	a949292b 	ldp	x11, x10, [x9, #144]
    402027a8:	a9062fea 	stp	x10, x11, [sp, #96]
    402027ac:	a94a292b 	ldp	x11, x10, [x9, #160]
    402027b0:	a9052fea 	stp	x10, x11, [sp, #80]
    402027b4:	f9405929 	ldr	x9, [x9, #176]
    402027b8:	f9003be9 	str	x9, [sp, #112]
    402027bc:	d5033fdf 	isb
    402027c0:	d53be039 	mrs	x25, cntpct_el0
    402027c4:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402027c8:	d503201f 	nop
    402027cc:	100270b6 	adr	x22, 402075e0 <jnox_kernel::ordinary_reservations::WITNESS>
    402027d0:	f942f137 	ldr	x23, [x9, #1504]
    402027d4:	a90a6ffc 	stp	x28, x27, [sp, #160]
    402027d8:	b40001a1 	cbz	x1, 4020280c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x150>
    402027dc:	f9403ec9 	ldr	x9, [x22, #120]
    402027e0:	f1000aff 	cmp	x23, #0x2
    402027e4:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    402027e8:	a90b87e8 	stp	x8, x1, [sp, #184]
    402027ec:	a90cffe9 	stp	x9, xzr, [sp, #200]
    402027f0:	9102e3e4 	add	x4, sp, #0xb8
    402027f4:	52800480 	mov	w0, #0x24                  	// #36
    402027f8:	aa1f03e2 	mov	x2, xzr
    402027fc:	52800043 	mov	w3, #0x2                   	// #2
    40202800:	97ffff58 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202804:	f94002c8 	ldr	x8, [x22]
    40202808:	14000002 	b	40202810 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x154>
    4020280c:	aa1703e8 	mov	x8, x23
    40202810:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202814:	9117a129 	add	x9, x9, #0x5e8
    40202818:	f940012a 	ldr	x10, [x9]
    4020281c:	7200011f 	tst	w8, #0x1
    40202820:	52800048 	mov	w8, #0x2                   	// #2
    40202824:	f9403529 	ldr	x9, [x9, #104]
    40202828:	9a881148 	csel	x8, x10, x8, ne  // ne = any
    4020282c:	f1000aff 	cmp	x23, #0x2
    40202830:	da9f113b 	csinv	x27, x9, xzr, ne  // ne = any
    40202834:	9a8802fc 	csel	x28, x23, x8, eq  // eq = none
    40202838:	d503201f 	nop
    4020283c:	10107d28 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    40202840:	c8dffd08 	ldar	x8, [x8]
    40202844:	a90be3fb 	stp	x27, x24, [sp, #184]
    40202848:	f27e031f 	tst	x24, #0x4
    4020284c:	f9405be9 	ldr	x9, [sp, #176]
    40202850:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    40202854:	a90ca7e8 	stp	x8, x9, [sp, #200]
    40202858:	9102e3e4 	add	x4, sp, #0xb8
    4020285c:	52800300 	mov	w0, #0x18                  	// #24
    40202860:	aa1903e1 	mov	x1, x25
    40202864:	aa1f03e2 	mov	x2, xzr
    40202868:	aa1c03e3 	mov	x3, x28
    4020286c:	97ffff3d 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202870:	37001d58 	tbnz	w24, #0, 40202c18 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x55c>
    40202874:	37081f78 	tbnz	w24, #1, 40202c60 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x5a4>
    40202878:	371020f8 	tbnz	w24, #2, 40202c94 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x5d8>
    4020287c:	37182258 	tbnz	w24, #3, 40202cc4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x608>
    40202880:	36200378 	tbz	w24, #4, 402028ec <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x230>
    40202884:	a94627e8 	ldp	x8, x9, [sp, #96]
    40202888:	a90ba3e9 	stp	x9, x8, [sp, #184]
    4020288c:	a94527e8 	ldp	x8, x9, [sp, #80]
    40202890:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202894:	9102e3e4 	add	x4, sp, #0xb8
    40202898:	528003a0 	mov	w0, #0x1d                  	// #29
    4020289c:	f9403ff3 	ldr	x19, [sp, #120]
    402028a0:	aa1303e1 	mov	x1, x19
    402028a4:	aa1f03e2 	mov	x2, xzr
    402028a8:	aa1c03e3 	mov	x3, x28
    402028ac:	97ffff2d 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    402028b0:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402028b4:	91196108 	add	x8, x8, #0x658
    402028b8:	a9402109 	ldp	x9, x8, [x8]
    402028bc:	f1000aff 	cmp	x23, #0x2
    402028c0:	da9f1129 	csinv	x9, x9, xzr, ne  // ne = any
    402028c4:	f9403bea 	ldr	x10, [sp, #112]
    402028c8:	a90ba7ea 	stp	x10, x9, [sp, #184]
    402028cc:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    402028d0:	a90cefe8 	stp	x8, x27, [sp, #200]
    402028d4:	9102e3e4 	add	x4, sp, #0xb8
    402028d8:	528003c0 	mov	w0, #0x1e                  	// #30
    402028dc:	aa1303e1 	mov	x1, x19
    402028e0:	aa1f03e2 	mov	x2, xzr
    402028e4:	aa1c03e3 	mov	x3, x28
    402028e8:	97ffff1e 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    402028ec:	f1000aff 	cmp	x23, #0x2
    402028f0:	54000800 	b.eq	402029f0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x334>  // b.none
    402028f4:	aa1f03f3 	mov	x19, xzr
    402028f8:	52800028 	mov	w8, #0x1                   	// #1
    402028fc:	52800714 	mov	w20, #0x38                  	// #56
    40202900:	9b145a77 	madd	x23, x19, x20, x22
    40202904:	2a0803f5 	mov	w21, w8
    40202908:	a949a6e8 	ldp	x8, x9, [x23, #152]
    4020290c:	f94056ea 	ldr	x10, [x23, #168]
    40202910:	a90ba7e8 	stp	x8, x9, [sp, #184]
    40202914:	f9405ee8 	ldr	x8, [x23, #184]
    40202918:	a90ca3ea 	stp	x10, x8, [sp, #200]
    4020291c:	9102e3e4 	add	x4, sp, #0xb8
    40202920:	52800440 	mov	w0, #0x22                  	// #34
    40202924:	aa1903e1 	mov	x1, x25
    40202928:	aa1f03e2 	mov	x2, xzr
    4020292c:	aa1303e3 	mov	x3, x19
    40202930:	97ffff0c 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202934:	f9405ae8 	ldr	x8, [x23, #176]
    40202938:	a94c2ae9 	ldp	x9, x10, [x23, #192]
    4020293c:	a90ba7e8 	stp	x8, x9, [sp, #184]
    40202940:	f9404ac8 	ldr	x8, [x22, #144]
    40202944:	a90ca3ea 	stp	x10, x8, [sp, #200]
    40202948:	9102e3e4 	add	x4, sp, #0xb8
    4020294c:	52800460 	mov	w0, #0x23                  	// #35
    40202950:	aa1903e1 	mov	x1, x25
    40202954:	aa1f03e2 	mov	x2, xzr
    40202958:	aa1303e3 	mov	x3, x19
    4020295c:	97ffff01 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202960:	8b1312c8 	add	x8, x22, x19, lsl #4
    40202964:	a941a909 	ldp	x9, x10, [x8, #24]
    40202968:	a90babe9 	stp	x9, x10, [sp, #184]
    4020296c:	a943a109 	ldp	x9, x8, [x8, #56]
    40202970:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202974:	9102e3e4 	add	x4, sp, #0xb8
    40202978:	528003e0 	mov	w0, #0x1f                  	// #31
    4020297c:	aa1903e1 	mov	x1, x25
    40202980:	aa1f03e2 	mov	x2, xzr
    40202984:	aa1303e3 	mov	x3, x19
    40202988:	97fffef6 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    4020298c:	8b130ac8 	add	x8, x22, x19, lsl #2
    40202990:	b9401109 	ldr	w9, [x8, #16]
    40202994:	b9405908 	ldr	w8, [x8, #88]
    40202998:	8b1302ca 	add	x10, x22, x19
    4020299c:	3941814a 	ldrb	w10, [x10, #96]
    402029a0:	b94002cb 	ldr	w11, [x22]
    402029a4:	f94006cc 	ldr	x12, [x22, #8]
    402029a8:	eb13019f 	cmp	x12, x19
    402029ac:	1a9f17ec 	cset	w12, eq  // eq = none
    402029b0:	39418acd 	ldrb	w13, [x22, #98]
    402029b4:	71000dbf 	cmp	w13, #0x3
    402029b8:	1a8d07ed 	csinc	w13, wzr, w13, eq  // eq = none
    402029bc:	a90ba3e9 	stp	x9, x8, [sp, #184]
    402029c0:	6a0c017f 	tst	w11, w12
    402029c4:	9a9f11a8 	csel	x8, x13, xzr, ne  // ne = any
    402029c8:	a90ca3ea 	stp	x10, x8, [sp, #200]
    402029cc:	9102e3e4 	add	x4, sp, #0xb8
    402029d0:	52800400 	mov	w0, #0x20                  	// #32
    402029d4:	aa1903e1 	mov	x1, x25
    402029d8:	aa1f03e2 	mov	x2, xzr
    402029dc:	aa1303e3 	mov	x3, x19
    402029e0:	97fffee0 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    402029e4:	2a1f03e8 	mov	w8, wzr
    402029e8:	52800033 	mov	w19, #0x1                   	// #1
    402029ec:	3707f8b5 	tbnz	w21, #0, 40202900 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x244>
    402029f0:	52801008 	mov	w8, #0x80                  	// #128
    402029f4:	52802109 	mov	w9, #0x108                 	// #264
    402029f8:	a90ba3e8 	stp	x8, x8, [sp, #184]
    402029fc:	52801708 	mov	w8, #0xb8                  	// #184
    40202a00:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202a04:	9102e3e4 	add	x4, sp, #0xb8
    40202a08:	52800420 	mov	w0, #0x21                  	// #33
    40202a0c:	aa1903e1 	mov	x1, x25
    40202a10:	aa1f03e2 	mov	x2, xzr
    40202a14:	52800043 	mov	w3, #0x2                   	// #2
    40202a18:	97fffed2 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202a1c:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328+0xb8e0>
    40202a20:	f943f508 	ldr	x8, [x8, #2024]
    40202a24:	f101011f 	cmp	x8, #0x40
    40202a28:	52800809 	mov	w9, #0x40                  	// #64
    40202a2c:	9a893113 	csel	x19, x8, x9, cc  // cc = lo, ul, last
    40202a30:	a94a5ff8 	ldp	x24, x23, [sp, #160]
    40202a34:	b4000288 	cbz	x8, 40202a84 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x3c8>
    40202a38:	aa1f03f4 	mov	x20, xzr
    40202a3c:	b0000035 	adrp	x21, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202a40:	910022b5 	add	x21, x21, #0x8
    40202a44:	b0000116 	adrp	x22, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328+0xb8e0>
    40202a48:	911fc2d6 	add	x22, x22, #0x7f0
    40202a4c:	f9400ac1 	ldr	x1, [x22, #16]
    40202a50:	f94006c8 	ldr	x8, [x22, #8]
    40202a54:	f84186c9 	ldr	x9, [x22], #24
    40202a58:	aa1403ea 	mov	x10, x20
    40202a5c:	91000694 	add	x20, x20, #0x1
    40202a60:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202a64:	a97f8ea2 	ldp	x2, x3, [x21, #-8]
    40202a68:	a90cffea 	stp	x10, xzr, [sp, #200]
    40202a6c:	9102e3e4 	add	x4, sp, #0xb8
    40202a70:	52800180 	mov	w0, #0xc                   	// #12
    40202a74:	97fffebb 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202a78:	910042b5 	add	x21, x21, #0x10
    40202a7c:	eb14027f 	cmp	x19, x20
    40202a80:	54fffe61 	b.ne	40202a4c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x390>  // b.any
    40202a84:	52800314 	mov	w20, #0x18                  	// #24
    40202a88:	72a12014 	movk	w20, #0x900, lsl #16
    40202a8c:	d5033fdf 	isb
    40202a90:	d53be021 	mrs	x1, cntpct_el0
    40202a94:	a94823e9 	ldp	x9, x8, [sp, #128]
    40202a98:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202a9c:	a94923e9 	ldp	x9, x8, [sp, #144]
    40202aa0:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202aa4:	9102e3e4 	add	x4, sp, #0xb8
    40202aa8:	528001a0 	mov	w0, #0xd                   	// #13
    40202aac:	aa1803e2 	mov	x2, x24
    40202ab0:	aa1703e3 	mov	x3, x23
    40202ab4:	97fffeab 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202ab8:	aa1f03e8 	mov	x8, xzr
    40202abc:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202ac0:	d503201f 	nop
    40202ac4:	10019d6a 	adr	x10, 40205e70 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.12015700318350904328+0x18>
    40202ac8:	3868694b 	ldrb	w11, [x10, x8]
    40202acc:	b940028c 	ldr	w12, [x20]
    40202ad0:	3628006c 	tbz	w12, #5, 40202adc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x420>
    40202ad4:	d5033fdf 	isb
    40202ad8:	17fffffd 	b	40202acc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x410>
    40202adc:	91000508 	add	x8, x8, #0x1
    40202ae0:	b900012b 	str	w11, [x9]
    40202ae4:	f1002d1f 	cmp	x8, #0xb
    40202ae8:	54ffff01 	b.ne	40202ac8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x40c>  // b.any
    40202aec:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202af0:	f9438915 	ldr	x21, [x8, #1808]
    40202af4:	b4000755 	cbz	x21, 40202bdc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x520>
    40202af8:	aa1f03f6 	mov	x22, xzr
    40202afc:	9102e3e8 	add	x8, sp, #0xb8
    40202b00:	b202e7f7 	mov	x23, #0xcccccccccccccccc    	// #-3689348814741910324
    40202b04:	f29999b7 	movk	x23, #0xcccd
    40202b08:	91004113 	add	x19, x8, #0x10
    40202b0c:	52800158 	mov	w24, #0xa                   	// #10
    40202b10:	910423f9 	add	x25, sp, #0x108
    40202b14:	52a1201a 	mov	w26, #0x9000000             	// #150994944
    40202b18:	5280041b 	mov	w27, #0x20                  	// #32
    40202b1c:	d503201f 	nop
    40202b20:	10025fdc 	adr	x28, 40207718 <jnox_kernel::ordinary_reservations::TRACE>
    40202b24:	8b161b81 	add	x1, x28, x22, lsl #6
    40202b28:	910006d6 	add	x22, x22, #0x1
    40202b2c:	aa1303e0 	mov	x0, x19
    40202b30:	52800802 	mov	w2, #0x40                  	// #64
    40202b34:	94000bb6 	bl	40205a0c <memcpy>
    40202b38:	aa1f03e8 	mov	x8, xzr
    40202b3c:	b9011bff 	str	wzr, [sp, #280]
    40202b40:	f8687a69 	ldr	x9, [x19, x8, lsl #3]
    40202b44:	91000508 	add	x8, x8, #0x1
    40202b48:	5280026a 	mov	w10, #0x13                  	// #19
    40202b4c:	a910ffff 	stp	xzr, xzr, [sp, #264]
    40202b50:	f1004d5f 	cmp	x10, #0x13
    40202b54:	54000d08 	b.hi	40202cf4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x638>  // b.pmore
    40202b58:	9bd77d2b 	umulh	x11, x9, x23
    40202b5c:	d343fd6b 	lsr	x11, x11, #3
    40202b60:	1b18a56c 	msub	w12, w11, w24, w9
    40202b64:	321c058c 	orr	w12, w12, #0x30
    40202b68:	382a6b2c 	strb	w12, [x25, x10]
    40202b6c:	d100054a 	sub	x10, x10, #0x1
    40202b70:	f100293f 	cmp	x9, #0xa
    40202b74:	aa0b03e9 	mov	x9, x11
    40202b78:	54fffec2 	b.cs	40202b50 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x494>  // b.hs, b.nlast
    40202b7c:	91000549 	add	x9, x10, #0x1
    40202b80:	38696b2a 	ldrb	w10, [x25, x9]
    40202b84:	b940028b 	ldr	w11, [x20]
    40202b88:	3628006b 	tbz	w11, #5, 40202b94 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x4d8>
    40202b8c:	d5033fdf 	isb
    40202b90:	17fffffd 	b	40202b84 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x4c8>
    40202b94:	91000529 	add	x9, x9, #0x1
    40202b98:	b900034a 	str	w10, [x26]
    40202b9c:	f100513f 	cmp	x9, #0x14
    40202ba0:	54ffff01 	b.ne	40202b80 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x4c4>  // b.any
    40202ba4:	14000002 	b	40202bac <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x4f0>
    40202ba8:	d5033fdf 	isb
    40202bac:	b9400289 	ldr	w9, [x20]
    40202bb0:	372fffc9 	tbnz	w9, #5, 40202ba8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x4ec>
    40202bb4:	b900035b 	str	w27, [x26]
    40202bb8:	f100211f 	cmp	x8, #0x8
    40202bbc:	54fffc01 	b.ne	40202b3c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x480>  // b.any
    40202bc0:	14000002 	b	40202bc8 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x50c>
    40202bc4:	d5033fdf 	isb
    40202bc8:	b9400288 	ldr	w8, [x20]
    40202bcc:	372fffc8 	tbnz	w8, #5, 40202bc4 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x508>
    40202bd0:	b9000358 	str	w24, [x26]
    40202bd4:	eb1502df 	cmp	x22, x21
    40202bd8:	54fffa61 	b.ne	40202b24 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x468>  // b.any
    40202bdc:	aa1f03e8 	mov	x8, xzr
    40202be0:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40202be4:	d503201f 	nop
    40202be8:	7001948a 	adr	x10, 40205e7b <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.12015700318350904328+0x23>
    40202bec:	3868694b 	ldrb	w11, [x10, x8]
    40202bf0:	b940028c 	ldr	w12, [x20]
    40202bf4:	3628006c 	tbz	w12, #5, 40202c00 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x544>
    40202bf8:	d5033fdf 	isb
    40202bfc:	17fffffd 	b	40202bf0 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x534>
    40202c00:	91000508 	add	x8, x8, #0x1
    40202c04:	b900012b 	str	w11, [x9]
    40202c08:	f100251f 	cmp	x8, #0x9
    40202c0c:	54ffff01 	b.ne	40202bec <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x530>  // b.any
    40202c10:	d503205f 	wfe
    40202c14:	17ffffff 	b	40202c10 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x554>
    40202c18:	a94127e8 	ldp	x8, x9, [sp, #16]
    40202c1c:	a90ba7f3 	stp	x19, x9, [sp, #184]
    40202c20:	a90ca3fa 	stp	x26, x8, [sp, #200]
    40202c24:	9102e3e4 	add	x4, sp, #0xb8
    40202c28:	52800320 	mov	w0, #0x19                  	// #25
    40202c2c:	aa1503e1 	mov	x1, x21
    40202c30:	aa1f03e2 	mov	x2, xzr
    40202c34:	52800043 	mov	w3, #0x2                   	// #2
    40202c38:	97fffe4a 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202c3c:	a90bd3f5 	stp	x21, x20, [sp, #184]
    40202c40:	a90ccffa 	stp	x26, x19, [sp, #200]
    40202c44:	9102e3e4 	add	x4, sp, #0xb8
    40202c48:	528004a0 	mov	w0, #0x25                  	// #37
    40202c4c:	aa1403e1 	mov	x1, x20
    40202c50:	aa1f03e2 	mov	x2, xzr
    40202c54:	52800043 	mov	w3, #0x2                   	// #2
    40202c58:	97fffe42 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202c5c:	360fe0f8 	tbz	w24, #1, 40202878 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x1bc>
    40202c60:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202c64:	f9432d08 	ldr	x8, [x8, #1624]
    40202c68:	f1000aff 	cmp	x23, #0x2
    40202c6c:	a90bfffb 	stp	x27, xzr, [sp, #184]
    40202c70:	da9f1108 	csinv	x8, x8, xzr, ne  // ne = any
    40202c74:	a90cffe8 	stp	x8, xzr, [sp, #200]
    40202c78:	9102e3e4 	add	x4, sp, #0xb8
    40202c7c:	52800340 	mov	w0, #0x1a                  	// #26
    40202c80:	f94013e1 	ldr	x1, [sp, #32]
    40202c84:	aa1f03e2 	mov	x2, xzr
    40202c88:	52800043 	mov	w3, #0x2                   	// #2
    40202c8c:	97fffe35 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202c90:	3617df78 	tbz	w24, #2, 4020287c <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x1c0>
    40202c94:	924003a8 	and	x8, x29, #0x1
    40202c98:	d341ffa9 	lsr	x9, x29, #1
    40202c9c:	a90ba3fd 	stp	x29, x8, [sp, #184]
    40202ca0:	f9405be8 	ldr	x8, [sp, #176]
    40202ca4:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202ca8:	9102e3e4 	add	x4, sp, #0xb8
    40202cac:	52800360 	mov	w0, #0x1b                  	// #27
    40202cb0:	f94017e1 	ldr	x1, [sp, #40]
    40202cb4:	aa1f03e2 	mov	x2, xzr
    40202cb8:	aa1c03e3 	mov	x3, x28
    40202cbc:	97fffe29 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202cc0:	361fde18 	tbz	w24, #3, 40202880 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x1c4>
    40202cc4:	a94327e8 	ldp	x8, x9, [sp, #48]
    40202cc8:	a90ba3e9 	stp	x9, x8, [sp, #184]
    40202ccc:	52800028 	mov	w8, #0x1                   	// #1
    40202cd0:	a94407e9 	ldp	x9, x1, [sp, #64]
    40202cd4:	a90ca3e9 	stp	x9, x8, [sp, #200]
    40202cd8:	9102e3e4 	add	x4, sp, #0xb8
    40202cdc:	52800380 	mov	w0, #0x1c                  	// #28
    40202ce0:	aa1f03e2 	mov	x2, xzr
    40202ce4:	aa1c03e3 	mov	x3, x28
    40202ce8:	97fffe1e 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202cec:	3727dcd8 	tbnz	w24, #4, 40202884 <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x1c8>
    40202cf0:	17fffeff 	b	402028ec <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328+0x230>
    40202cf4:	d503201f 	nop
    40202cf8:	10018f82 	adr	x2, 40205ee8 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.12015700318350904328+0x90>
    40202cfc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    40202d00:	52800281 	mov	w1, #0x14                  	// #20
    40202d04:	940007f2 	bl	40204ccc <core::panicking::panic_bounds_check>

0000000040202d08 <jnox_kernel::ordinary_reservations::Runtime::arm>:
    40202d08:	d10103ff 	sub	sp, sp, #0x40
    40202d0c:	a90257fe 	stp	x30, x21, [sp, #32]
    40202d10:	a9034ff4 	stp	x20, x19, [sp, #48]
    40202d14:	aa0203f3 	mov	x19, x2
    40202d18:	aa0003e2 	mov	x2, x0
    40202d1c:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202d20:	91158129 	add	x9, x9, #0x560
    40202d24:	a9020533 	stp	x19, x1, [x9, #32]
    40202d28:	52800028 	mov	w8, #0x1                   	// #1
    40202d2c:	d51be253 	msr	cntp_cval_el0, x19
    40202d30:	d51be228 	msr	cntp_ctl_el0, x8
    40202d34:	d5033fdf 	isb
    40202d38:	d53be255 	mrs	x21, cntp_cval_el0
    40202d3c:	d53be234 	mrs	x20, cntp_ctl_el0
    40202d40:	d5033fdf 	isb
    40202d44:	d53be028 	mrs	x8, cntpct_el0
    40202d48:	a90053f3 	stp	x19, x20, [sp]
    40202d4c:	f9400123 	ldr	x3, [x9]
    40202d50:	a90107f5 	stp	x21, x1, [sp, #16]
    40202d54:	910003e4 	mov	x4, sp
    40202d58:	52800060 	mov	w0, #0x3                   	// #3
    40202d5c:	aa0803e1 	mov	x1, x8
    40202d60:	97fffe00 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202d64:	eb1302bf 	cmp	x21, x19
    40202d68:	54000101 	b.ne	40202d88 <jnox_kernel::ordinary_reservations::Runtime::arm+0x80>  // b.any
    40202d6c:	92400688 	and	x8, x20, #0x3
    40202d70:	f100051f 	cmp	x8, #0x1
    40202d74:	540000a1 	b.ne	40202d88 <jnox_kernel::ordinary_reservations::Runtime::arm+0x80>  // b.any
    40202d78:	a9434ff4 	ldp	x20, x19, [sp, #48]
    40202d7c:	a94257fe 	ldp	x30, x21, [sp, #32]
    40202d80:	910103ff 	add	sp, sp, #0x40
    40202d84:	d65f03c0 	ret
    40202d88:	97fff948 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

0000000040202d8c <jnox_kernel::ordinary_reservations::Runtime::close>:
    40202d8c:	d103c3ff 	sub	sp, sp, #0xf0
    40202d90:	a9097bfd 	stp	x29, x30, [sp, #144]
    40202d94:	a90a6ffc 	stp	x28, x27, [sp, #160]
    40202d98:	a90b67fa 	stp	x26, x25, [sp, #176]
    40202d9c:	a90c5ff8 	stp	x24, x23, [sp, #192]
    40202da0:	a90d57f6 	stp	x22, x21, [sp, #208]
    40202da4:	a90e4ff4 	stp	x20, x19, [sp, #224]
    40202da8:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202dac:	91140108 	add	x8, x8, #0x500
    40202db0:	a9405113 	ldp	x19, x20, [x8]
    40202db4:	a9412518 	ldp	x24, x9, [x8, #16]
    40202db8:	f90037e9 	str	x9, [sp, #104]
    40202dbc:	a942691d 	ldp	x29, x26, [x8, #32]
    40202dc0:	3940c119 	ldrb	w25, [x8, #48]
    40202dc4:	52800069 	mov	w9, #0x3                   	// #3
    40202dc8:	3900c109 	strb	w9, [x8, #48]
    40202dcc:	71000f3f 	cmp	w25, #0x3
    40202dd0:	54001d20 	b.eq	40203174 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.none
    40202dd4:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202dd8:	f942b108 	ldr	x8, [x8, #1376]
    40202ddc:	eb13011f 	cmp	x8, x19
    40202de0:	54001ca1 	b.ne	40203174 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.any
    40202de4:	aa0003f5 	mov	x21, x0
    40202de8:	d503201f 	nop
    40202dec:	100a49a8 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328>
    40202df0:	8b133909 	add	x9, x8, x19, lsl #14
    40202df4:	eb00013f 	cmp	x9, x0
    40202df8:	54001be8 	b.hi	40203174 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202dfc:	b10d06bf 	cmn	x21, #0x341
    40202e00:	54001ba8 	b.hi	40203174 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202e04:	d372c669 	lsl	x9, x19, #14
    40202e08:	8b090108 	add	x8, x8, x9
    40202e0c:	91401108 	add	x8, x8, #0x4, lsl #12
    40202e10:	910d02a9 	add	x9, x21, #0x340
    40202e14:	eb08013f 	cmp	x9, x8
    40202e18:	54001ae8 	b.hi	40203174 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.pmore
    40202e1c:	aa0303fc 	mov	x28, x3
    40202e20:	2a0203f7 	mov	w23, w2
    40202e24:	aa0103f6 	mov	x22, x1
    40202e28:	9101c3e8 	add	x8, sp, #0x70
    40202e2c:	aa1303e0 	mov	x0, x19
    40202e30:	9400014c 	bl	40203360 <jnox_kernel::ordinary_reservations::snapshot>
    40202e34:	f1000a7f 	cmp	x19, #0x2
    40202e38:	54001d62 	b.cs	402031e4 <jnox_kernel::ordinary_reservations::Runtime::close+0x458>  // b.hs, b.nlast
    40202e3c:	a94733fb 	ldp	x27, x12, [sp, #112]
    40202e40:	f94043ef 	ldr	x15, [sp, #128]
    40202e44:	d503201f 	nop
    40202e48:	10107dc8 	adr	x8, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40202e4c:	8b130d08 	add	x8, x8, x19, lsl #3
    40202e50:	b0000029 	adrp	x9, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202e54:	9114e129 	add	x9, x9, #0x538
    40202e58:	c8dffd0e 	ldar	x14, [x8]
    40202e5c:	a9402129 	ldp	x9, x8, [x9]
    40202e60:	9bc87e8a 	umulh	x10, x20, x8
    40202e64:	eb0a03ff 	cmp	xzr, x10
    40202e68:	1a9f07eb 	cset	w11, ne  // ne = any
    40202e6c:	9b087e8a 	mul	x10, x20, x8
    40202e70:	ab09014d 	adds	x13, x10, x9
    40202e74:	1a9f37ea 	cset	w10, cs  // cs = hs, nlast
    40202e78:	3700180b 	tbnz	w11, #0, 40203178 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202e7c:	350017ea 	cbnz	w10, 40203178 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202e80:	9100068a 	add	x10, x20, #0x1
    40202e84:	9bc87d4b 	umulh	x11, x10, x8
    40202e88:	eb0b03ff 	cmp	xzr, x11
    40202e8c:	1a9f07eb 	cset	w11, ne  // ne = any
    40202e90:	9b087d48 	mul	x8, x10, x8
    40202e94:	ab090109 	adds	x9, x8, x9
    40202e98:	1a9f37e8 	cset	w8, cs  // cs = hs, nlast
    40202e9c:	370016eb 	tbnz	w11, #0, 40203178 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202ea0:	350016c8 	cbnz	w8, 40203178 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>
    40202ea4:	b100069f 	cmn	x20, #0x1
    40202ea8:	54001680 	b.eq	40203178 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.none
    40202eac:	b0000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40202eb0:	f942a508 	ldr	x8, [x8, #1352]
    40202eb4:	eb08012a 	subs	x10, x9, x8
    40202eb8:	54001603 	b.cc	40203178 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.lo, b.ul, b.last
    40202ebc:	a9056bfc 	stp	x28, x26, [sp, #80]
    40202ec0:	f9000fe9 	str	x9, [sp, #24]
    40202ec4:	b0000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328+0xb8e0>
    40202ec8:	f943f508 	ldr	x8, [x8, #2024]
    40202ecc:	91000709 	add	x9, x24, #0x1
    40202ed0:	eb09011f 	cmp	x8, x9
    40202ed4:	54001501 	b.ne	40203174 <jnox_kernel::ordinary_reservations::Runtime::close+0x3e8>  // b.any
    40202ed8:	b9004ff9 	str	w25, [sp, #76]
    40202edc:	d503201f 	nop
    40202ee0:	10104848 	adr	x8, 402237e8 <jnox_ap_returns>
    40202ee4:	52800309 	mov	w9, #0x18                  	// #24
    40202ee8:	9b092308 	madd	x8, x24, x9, x8
    40202eec:	f9400509 	ldr	x9, [x8, #8]
    40202ef0:	f940090b 	ldr	x11, [x8, #16]
    40202ef4:	f9400d1c 	ldr	x28, [x8, #24]
    40202ef8:	eb1c02da 	subs	x26, x22, x28
    40202efc:	540017e3 	b.cc	402031f8 <jnox_kernel::ordinary_reservations::Runtime::close+0x46c>  // b.lo, b.ul, b.last
    40202f00:	a902a7eb 	stp	x11, x9, [sp, #40]
    40202f04:	a903b7ef 	stp	x15, x13, [sp, #56]
    40202f08:	f90033ee 	str	x14, [sp, #96]
    40202f0c:	f9000bea 	str	x10, [sp, #16]
    40202f10:	d503201f 	nop
    40202f14:	10022768 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40202f18:	8b130d18 	add	x24, x8, x19, lsl #3
    40202f1c:	f940d308 	ldr	x8, [x24, #416]
    40202f20:	ab1a0119 	adds	x25, x8, x26
    40202f24:	540012a2 	b.cs	40203178 <jnox_kernel::ordinary_reservations::Runtime::close+0x3ec>  // b.hs, b.nlast
    40202f28:	f900d319 	str	x25, [x24, #416]
    40202f2c:	f94037e8 	ldr	x8, [sp, #104]
    40202f30:	a9076fe8 	stp	x8, x27, [sp, #112]
    40202f34:	a90833fd 	stp	x29, x12, [sp, #128]
    40202f38:	f90013fb 	str	x27, [sp, #32]
    40202f3c:	9101c3e4 	add	x4, sp, #0x70
    40202f40:	52800100 	mov	w0, #0x8                   	// #8
    40202f44:	aa1603e1 	mov	x1, x22
    40202f48:	aa1403e2 	mov	x2, x20
    40202f4c:	aa1303e3 	mov	x3, x19
    40202f50:	aa0c03fb 	mov	x27, x12
    40202f54:	97fffd83 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202f58:	f9407ea8 	ldr	x8, [x21, #248]
    40202f5c:	f9404ea9 	ldr	x9, [x21, #152]
    40202f60:	a90723f5 	stp	x21, x8, [sp, #112]
    40202f64:	f9408ea8 	ldr	x8, [x21, #280]
    40202f68:	a90823e9 	stp	x9, x8, [sp, #128]
    40202f6c:	9101c3e4 	add	x4, sp, #0x70
    40202f70:	52800120 	mov	w0, #0x9                   	// #9
    40202f74:	aa1603e1 	mov	x1, x22
    40202f78:	aa1403e2 	mov	x2, x20
    40202f7c:	aa1303e3 	mov	x3, x19
    40202f80:	97fffd78 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202f84:	f94033e8 	ldr	x8, [sp, #96]
    40202f88:	a90723fc 	stp	x28, x8, [sp, #112]
    40202f8c:	a9086bf6 	stp	x22, x26, [sp, #128]
    40202f90:	f90007fa 	str	x26, [sp, #8]
    40202f94:	9101c3e4 	add	x4, sp, #0x70
    40202f98:	52800140 	mov	w0, #0xa                   	// #10
    40202f9c:	aa1603e1 	mov	x1, x22
    40202fa0:	aa1403e2 	mov	x2, x20
    40202fa4:	aa1303e3 	mov	x3, x19
    40202fa8:	97fffd6e 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202fac:	110006e8 	add	w8, w23, #0x1
    40202fb0:	92401d09 	and	x9, x8, #0xff
    40202fb4:	f9402be8 	ldr	x8, [sp, #80]
    40202fb8:	a90723e9 	stp	x9, x8, [sp, #112]
    40202fbc:	f9401fe9 	ldr	x9, [sp, #56]
    40202fc0:	910d02a8 	add	x8, x21, #0x340
    40202fc4:	a90823e9 	stp	x9, x8, [sp, #128]
    40202fc8:	9101c3e4 	add	x4, sp, #0x70
    40202fcc:	52800160 	mov	w0, #0xb                   	// #11
    40202fd0:	aa1603e1 	mov	x1, x22
    40202fd4:	aa1403e2 	mov	x2, x20
    40202fd8:	aa1303e3 	mov	x3, x19
    40202fdc:	97fffd61 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    40202fe0:	f9402fe8 	ldr	x8, [sp, #88]
    40202fe4:	a90767e8 	stp	x8, x25, [sp, #112]
    40202fe8:	aa1903fa 	mov	x26, x25
    40202fec:	a942a7e8 	ldp	x8, x9, [sp, #40]
    40202ff0:	a90823e9 	stp	x9, x8, [sp, #128]
    40202ff4:	9101c3e4 	add	x4, sp, #0x70
    40202ff8:	52800260 	mov	w0, #0x13                  	// #19
    40202ffc:	aa1603e1 	mov	x1, x22
    40203000:	aa1403e2 	mov	x2, x20
    40203004:	aa1303e3 	mov	x3, x19
    40203008:	97fffd56 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    4020300c:	f94013e4 	ldr	x4, [sp, #32]
    40203010:	b9404fe8 	ldr	w8, [sp, #76]
    40203014:	6b37011f 	cmp	w8, w23, uxtb
    40203018:	f94023e5 	ldr	x5, [sp, #64]
    4020301c:	54000b21 	b.ne	40203180 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203020:	f94037e8 	ldr	x8, [sp, #104]
    40203024:	eb080088 	subs	x8, x4, x8
    40203028:	54000ac9 	b.ls	40203180 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.plast
    4020302c:	f9408ea9 	ldr	x9, [x21, #280]
    40203030:	d503201f 	nop
    40203034:	10016fea 	adr	x10, 40205e30 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.12015700318350904328>
    40203038:	f873794a 	ldr	x10, [x10, x19, lsl #3]
    4020303c:	eb0a013f 	cmp	x9, x10
    40203040:	54000a01 	b.ne	40203180 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203044:	f94082a9 	ldr	x9, [x21, #256]
    40203048:	528011ea 	mov	w10, #0x8f                  	// #143
    4020304c:	8a0a0129 	and	x9, x9, x10
    40203050:	f100153f 	cmp	x9, #0x5
    40203054:	54000961 	b.ne	40203180 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203058:	52800029 	mov	w9, #0x1                   	// #1
    4020305c:	5280006a 	mov	w10, #0x3                   	// #3
    40203060:	aa0803eb 	mov	x11, x8
    40203064:	9b1d254c 	madd	x12, x10, x29, x9
    40203068:	f240017f 	tst	x11, #0x1
    4020306c:	9a8c03bd 	csel	x29, x29, x12, eq  // eq = none
    40203070:	9b0a2529 	madd	x9, x9, x10, x9
    40203074:	9b0a7d4a 	mul	x10, x10, x10
    40203078:	d341fd6b 	lsr	x11, x11, #1
    4020307c:	b5ffff4b 	cbnz	x11, 40203064 <jnox_kernel::ordinary_reservations::Runtime::close+0x2d8>
    40203080:	eb1b03bf 	cmp	x29, x27
    40203084:	540007e1 	b.ne	40203180 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203088:	72001eff 	tst	w23, #0xff
    4020308c:	54000060 	b.eq	40203098 <jnox_kernel::ordinary_reservations::Runtime::close+0x30c>  // b.none
    40203090:	f104011f 	cmp	x8, #0x100
    40203094:	54000761 	b.ne	40203180 <jnox_kernel::ordinary_reservations::Runtime::close+0x3f4>  // b.any
    40203098:	f94033ea 	ldr	x10, [sp, #96]
    4020309c:	eb16015f 	cmp	x10, x22
    402030a0:	540007c8 	b.hi	40203198 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.pmore
    402030a4:	eb05039f 	cmp	x28, x5
    402030a8:	54000783 	b.cc	40203198 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.lo, b.ul, b.last
    402030ac:	eb1c015f 	cmp	x10, x28
    402030b0:	54000743 	b.cc	40203198 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.lo, b.ul, b.last
    402030b4:	cb050149 	sub	x9, x10, x5
    402030b8:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402030bc:	f942a508 	ldr	x8, [x8, #1352]
    402030c0:	eb08013f 	cmp	x9, x8
    402030c4:	540006a8 	b.hi	40203198 <jnox_kernel::ordinary_reservations::Runtime::close+0x40c>  // b.pmore
    402030c8:	a9412fe5 	ldp	x5, x11, [sp, #16]
    402030cc:	eb0b02df 	cmp	x22, x11
    402030d0:	54000708 	b.hi	402031b0 <jnox_kernel::ordinary_reservations::Runtime::close+0x424>  // b.pmore
    402030d4:	12001eea 	and	w10, w23, #0xff
    402030d8:	eb0502c9 	subs	x9, x22, x5
    402030dc:	9a8933e9 	csel	x9, xzr, x9, cc  // cc = lo, ul, last
    402030e0:	3500006a 	cbnz	w10, 402030ec <jnox_kernel::ordinary_reservations::Runtime::close+0x360>
    402030e4:	eb08013f 	cmp	x9, x8
    402030e8:	54000648 	b.hi	402031b0 <jnox_kernel::ordinary_reservations::Runtime::close+0x424>  // b.pmore
    402030ec:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    402030f0:	f942a108 	ldr	x8, [x8, #1344]
    402030f4:	f94007ea 	ldr	x10, [sp, #8]
    402030f8:	eb08015f 	cmp	x10, x8
    402030fc:	aa1a03eb 	mov	x11, x26
    40203100:	54000648 	b.hi	402031c8 <jnox_kernel::ordinary_reservations::Runtime::close+0x43c>  // b.pmore
    40203104:	f940db09 	ldr	x9, [x24, #432]
    40203108:	9b087d28 	mul	x8, x9, x8
    4020310c:	eb08017f 	cmp	x11, x8
    40203110:	540005c8 	b.hi	402031c8 <jnox_kernel::ordinary_reservations::Runtime::close+0x43c>  // b.pmore
    40203114:	72001eff 	tst	w23, #0xff
    40203118:	54000060 	b.eq	40203124 <jnox_kernel::ordinary_reservations::Runtime::close+0x398>  // b.none
    4020311c:	eb0502df 	cmp	x22, x5
    40203120:	540006e2 	b.cs	402031fc <jnox_kernel::ordinary_reservations::Runtime::close+0x470>  // b.hs, b.nlast
    40203124:	f900e304 	str	x4, [x24, #448]
    40203128:	f900eb1b 	str	x27, [x24, #464]
    4020312c:	94000040 	bl	4020322c <jnox_kernel::ordinary_reservations::Runtime::ledger>
    40203130:	aa1303e1 	mov	x1, x19
    40203134:	2a1703e2 	mov	w2, w23
    40203138:	94000240 	bl	40203a38 <jnox_kernel::reservation_jobs::Jobs::trap>
    4020313c:	72001c04 	ands	w4, w0, #0xff
    40203140:	540006a1 	b.ne	40203214 <jnox_kernel::ordinary_reservations::Runtime::close+0x488>  // b.any
    40203144:	12001ee8 	and	w8, w23, #0xff
    40203148:	7100091f 	cmp	w8, #0x2
    4020314c:	54000040 	b.eq	40203154 <jnox_kernel::ordinary_reservations::Runtime::close+0x3c8>  // b.none
    40203150:	f900b715 	str	x21, [x24, #360]
    40203154:	a94e4ff4 	ldp	x20, x19, [sp, #224]
    40203158:	a94d57f6 	ldp	x22, x21, [sp, #208]
    4020315c:	a94c5ff8 	ldp	x24, x23, [sp, #192]
    40203160:	a94b67fa 	ldp	x26, x25, [sp, #176]
    40203164:	a94a6ffc 	ldp	x28, x27, [sp, #160]
    40203168:	a9497bfd 	ldp	x29, x30, [sp, #144]
    4020316c:	9103c3ff 	add	sp, sp, #0xf0
    40203170:	d65f03c0 	ret
    40203174:	97fff84d 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40203178:	52800060 	mov	w0, #0x3                   	// #3
    4020317c:	94000071 	bl	40203340 <jnox_kernel::ordinary_reservations::checked::{{closure}}>
    40203180:	52800060 	mov	w0, #0x3                   	// #3
    40203184:	52800061 	mov	w1, #0x3                   	// #3
    40203188:	aa1403e2 	mov	x2, x20
    4020318c:	aa1303e3 	mov	x3, x19
    40203190:	f94037e5 	ldr	x5, [sp, #104]
    40203194:	97fffd4a 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>
    40203198:	52800040 	mov	w0, #0x2                   	// #2
    4020319c:	52800041 	mov	w1, #0x2                   	// #2
    402031a0:	aa1403e2 	mov	x2, x20
    402031a4:	aa1303e3 	mov	x3, x19
    402031a8:	aa0a03e4 	mov	x4, x10
    402031ac:	97fffd44 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>
    402031b0:	52800040 	mov	w0, #0x2                   	// #2
    402031b4:	52800021 	mov	w1, #0x1                   	// #1
    402031b8:	aa1403e2 	mov	x2, x20
    402031bc:	aa1303e3 	mov	x3, x19
    402031c0:	aa1603e4 	mov	x4, x22
    402031c4:	14000006 	b	402031dc <jnox_kernel::ordinary_reservations::Runtime::close+0x450>
    402031c8:	52800040 	mov	w0, #0x2                   	// #2
    402031cc:	528000e1 	mov	w1, #0x7                   	// #7
    402031d0:	aa1403e2 	mov	x2, x20
    402031d4:	aa1303e3 	mov	x3, x19
    402031d8:	aa0a03e4 	mov	x4, x10
    402031dc:	aa0b03e5 	mov	x5, x11
    402031e0:	97fffd37 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>
    402031e4:	d503201f 	nop
    402031e8:	10016742 	adr	x2, 40205ed0 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.12015700318350904328+0x78>
    402031ec:	aa1303e0 	mov	x0, x19
    402031f0:	52800041 	mov	w1, #0x2                   	// #2
    402031f4:	940006b6 	bl	40204ccc <core::panicking::panic_bounds_check>
    402031f8:	97fffb9f 	bl	40202074 <jnox_kernel::ordinary_reservations::run::{{closure}}>
    402031fc:	52800040 	mov	w0, #0x2                   	// #2
    40203200:	52800121 	mov	w1, #0x9                   	// #9
    40203204:	aa1403e2 	mov	x2, x20
    40203208:	aa1303e3 	mov	x3, x19
    4020320c:	aa1603e4 	mov	x4, x22
    40203210:	97fffd2b 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>
    40203214:	52800060 	mov	w0, #0x3                   	// #3
    40203218:	52800041 	mov	w1, #0x2                   	// #2
    4020321c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40203220:	52800043 	mov	w3, #0x2                   	// #2
    40203224:	aa1f03e5 	mov	x5, xzr
    40203228:	97fffd25 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>

000000004020322c <jnox_kernel::ordinary_reservations::Runtime::ledger>:
    4020322c:	f81f0ffe 	str	x30, [sp, #-16]!
    40203230:	d503201f 	nop
    40203234:	10102d68 	adr	x8, 402237e0 <_ZN11jnox_kernel21ordinary_reservations9AUTHORITY17h514bbc37eceee3e8E.0>
    40203238:	c8dffd08 	ldar	x8, [x8]
    4020323c:	b4000128 	cbz	x8, 40203260 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x34>
    40203240:	f1000d1f 	cmp	x8, #0x3
    40203244:	540000c1 	b.ne	4020325c <jnox_kernel::ordinary_reservations::Runtime::ledger+0x30>  // b.any
    40203248:	90000020 	adrp	x0, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    4020324c:	91120000 	add	x0, x0, #0x480
    40203250:	f9400008 	ldr	x8, [x0]
    40203254:	f100091f 	cmp	x8, #0x2
    40203258:	54000081 	b.ne	40203268 <jnox_kernel::ordinary_reservations::Runtime::ledger+0x3c>  // b.any
    4020325c:	97fff813 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    40203260:	d503201f 	nop
    40203264:	10020ce0 	adr	x0, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40203268:	f84107fe 	ldr	x30, [sp], #16
    4020326c:	d65f03c0 	ret

0000000040203270 <jnox_kernel::ordinary_reservations::Runtime::select>:
    40203270:	d10143ff 	sub	sp, sp, #0x50
    40203274:	f90013fe 	str	x30, [sp, #32]
    40203278:	a90357f6 	stp	x22, x21, [sp, #48]
    4020327c:	a9044ff4 	stp	x20, x19, [sp, #64]
    40203280:	d503201f 	nop
    40203284:	10020be8 	adr	x8, 40207400 <jnox_kernel::ordinary_reservations::RUNTIME>
    40203288:	8b010d09 	add	x9, x8, x1, lsl #3
    4020328c:	f940b534 	ldr	x20, [x9, #360]
    40203290:	d503201f 	nop
    40203294:	100a2468 	adr	x8, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328>
    40203298:	f900b53f 	str	xzr, [x9, #360]
    4020329c:	8b013909 	add	x9, x8, x1, lsl #14
    402032a0:	eb14013f 	cmp	x9, x20
    402032a4:	540004c8 	b.hi	4020333c <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    402032a8:	aa0103f3 	mov	x19, x1
    402032ac:	d372c429 	lsl	x9, x1, #14
    402032b0:	8b090108 	add	x8, x8, x9
    402032b4:	91401108 	add	x8, x8, #0x4, lsl #12
    402032b8:	910d0289 	add	x9, x20, #0x340
    402032bc:	b10d069f 	cmn	x20, #0x341
    402032c0:	fa489122 	ccmp	x9, x8, #0x2, ls  // ls = plast
    402032c4:	540003c8 	b.hi	4020333c <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    402032c8:	90000108 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328+0xb8e0>
    402032cc:	f943f516 	ldr	x22, [x8, #2024]
    402032d0:	f100fedf 	cmp	x22, #0x3f
    402032d4:	54000348 	b.hi	4020333c <jnox_kernel::ordinary_reservations::Runtime::select+0xcc>  // b.pmore
    402032d8:	aa0003f5 	mov	x21, x0
    402032dc:	d5033fdf 	isb
    402032e0:	d53be021 	mrs	x1, cntpct_el0
    402032e4:	f9407e88 	ldr	x8, [x20, #248]
    402032e8:	f9404e89 	ldr	x9, [x20, #152]
    402032ec:	a90023f4 	stp	x20, x8, [sp]
    402032f0:	f9408e88 	ldr	x8, [x20, #280]
    402032f4:	a90123e9 	stp	x9, x8, [sp, #16]
    402032f8:	910003e4 	mov	x4, sp
    402032fc:	52800240 	mov	w0, #0x12                  	// #18
    40203300:	aa1503e2 	mov	x2, x21
    40203304:	aa1303e3 	mov	x3, x19
    40203308:	97fffc96 	bl	40202560 <jnox_kernel::ordinary_reservations::event>
    4020330c:	d503201f 	nop
    40203310:	1001e788 	adr	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203314:	8b161108 	add	x8, x8, x22, lsl #4
    40203318:	a9004d15 	stp	x21, x19, [x8]
    4020331c:	90000028 	adrp	x8, 40207000 <jnox_kernel::ordinary_reservations::PLANS>
    40203320:	f902b113 	str	x19, [x8, #1376]
    40203324:	aa1403e0 	mov	x0, x20
    40203328:	a9444ff4 	ldp	x20, x19, [sp, #64]
    4020332c:	a94357f6 	ldp	x22, x21, [sp, #48]
    40203330:	f94013fe 	ldr	x30, [sp, #32]
    40203334:	910143ff 	add	sp, sp, #0x50
    40203338:	d65f03c0 	ret
    4020333c:	97fff7db 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>

0000000040203340 <jnox_kernel::ordinary_reservations::checked::{{closure}}>:
    40203340:	f81f0ffe 	str	x30, [sp, #-16]!
    40203344:	92401c04 	and	x4, x0, #0xff
    40203348:	52800060 	mov	w0, #0x3                   	// #3
    4020334c:	52800041 	mov	w1, #0x2                   	// #2
    40203350:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    40203354:	52800043 	mov	w3, #0x2                   	// #2
    40203358:	aa1f03e5 	mov	x5, xzr
    4020335c:	97fffcd8 	bl	402026bc <_ZN11jnox_kernel21ordinary_reservations6finish17h86090a47046c2e3aE.llvm.12015700318350904328>

0000000040203360 <jnox_kernel::ordinary_reservations::snapshot>:
    40203360:	f81f0ffe 	str	x30, [sp, #-16]!
    40203364:	f100041f 	cmp	x0, #0x1
    40203368:	54000488 	b.hi	402033f8 <jnox_kernel::ordinary_reservations::snapshot+0x98>  // b.pmore
    4020336c:	d503201f 	nop
    40203370:	10105509 	adr	x9, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    40203374:	8b000d29 	add	x9, x9, x0, lsl #3
    40203378:	c8dffd29 	ldar	x9, [x9]
    4020337c:	b40002c9 	cbz	x9, 402033d4 <jnox_kernel::ordinary_reservations::snapshot+0x74>
    40203380:	d503201f 	nop
    40203384:	100a1cea 	adr	x10, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328>
    40203388:	8b00394b 	add	x11, x10, x0, lsl #14
    4020338c:	eb09017f 	cmp	x11, x9
    40203390:	54000328 	b.hi	402033f4 <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    40203394:	b100a53f 	cmn	x9, #0x29
    40203398:	540002e8 	b.hi	402033f4 <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    4020339c:	d372c40b 	lsl	x11, x0, #14
    402033a0:	8b0b014a 	add	x10, x10, x11
    402033a4:	9140114a 	add	x10, x10, #0x4, lsl #12
    402033a8:	9100a12b 	add	x11, x9, #0x28
    402033ac:	eb0a017f 	cmp	x11, x10
    402033b0:	54000228 	b.hi	402033f4 <jnox_kernel::ordinary_reservations::snapshot+0x94>  // b.pmore
    402033b4:	9100812a 	add	x10, x9, #0x20
    402033b8:	c8dffd40 	ldar	x0, [x10]
    402033bc:	f100041f 	cmp	x0, #0x1
    402033c0:	54000228 	b.hi	40203404 <jnox_kernel::ordinary_reservations::snapshot+0xa4>  // b.pmore
    402033c4:	8b00112b 	add	x11, x9, x0, lsl #4
    402033c8:	f940016a 	ldr	x10, [x11]
    402033cc:	f940056b 	ldr	x11, [x11, #8]
    402033d0:	14000005 	b	402033e4 <jnox_kernel::ordinary_reservations::snapshot+0x84>
    402033d4:	aa1f03ea 	mov	x10, xzr
    402033d8:	d503201f 	nop
    402033dc:	100152ab 	adr	x11, 40205e30 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.12015700318350904328>
    402033e0:	f860796b 	ldr	x11, [x11, x0, lsl #3]
    402033e4:	a9002d0a 	stp	x10, x11, [x8]
    402033e8:	f9000909 	str	x9, [x8, #16]
    402033ec:	f84107fe 	ldr	x30, [sp], #16
    402033f0:	d65f03c0 	ret
    402033f4:	97fff7ad 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402033f8:	d503201f 	nop
    402033fc:	10015822 	adr	x2, 40205f00 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.12015700318350904328+0xa8>
    40203400:	14000003 	b	4020340c <jnox_kernel::ordinary_reservations::snapshot+0xac>
    40203404:	d503201f 	nop
    40203408:	10015882 	adr	x2, 40205f18 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.12015700318350904328+0xc0>
    4020340c:	52800041 	mov	w1, #0x2                   	// #2
    40203410:	9400062f 	bl	40204ccc <core::panicking::panic_bounds_check>

0000000040203414 <reservation_rust_work>:
    40203414:	d10103ff 	sub	sp, sp, #0x40
    40203418:	f9001bfe 	str	x30, [sp, #48]
    4020341c:	f100041f 	cmp	x0, #0x1
    40203420:	54000768 	b.hi	4020350c <reservation_rust_work+0xf8>  // b.pmore
    40203424:	aa1f03e9 	mov	x9, xzr
    40203428:	d503201f 	nop
    4020342c:	10015028 	adr	x8, 40205e30 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.12015700318350904328>
    40203430:	910023ea 	add	x10, sp, #0x8
    40203434:	9280000b 	mov	x11, #0xffffffffffffffff    	// #-1
    40203438:	f860790d 	ldr	x13, [x8, x0, lsl #3]
    4020343c:	9100e3ec 	add	x12, sp, #0x38
    40203440:	d503201f 	nop
    40203444:	10104e68 	adr	x8, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    40203448:	5280002e 	mov	w14, #0x1                   	// #1
    4020344c:	d503201f 	nop
    40203450:	100214cf 	adr	x15, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    40203454:	8b000d08 	add	x8, x8, x0, lsl #3
    40203458:	8b000def 	add	x15, x15, x0, lsl #3
    4020345c:	a900b7ff 	stp	xzr, x13, [sp, #8]
    40203460:	f9000fff 	str	xzr, [sp, #24]
    40203464:	a9027fed 	stp	x13, xzr, [sp, #32]
    40203468:	c89ffd0a 	stlr	x10, [x8]
    4020346c:	d503201f 	nop
    40203470:	10021448 	adr	x8, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40203474:	8b000d10 	add	x16, x8, x0, lsl #3
    40203478:	d503201f 	nop
    4020347c:	10104bb1 	adr	x17, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40203480:	d503201f 	nop
    40203484:	10104be8 	adr	x8, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    40203488:	8b000d12 	add	x18, x8, x0, lsl #3
    4020348c:	c8dffde8 	ldar	x8, [x15]
    40203490:	eb0b011f 	cmp	x8, x11
    40203494:	540000a0 	b.eq	402034a8 <reservation_rust_work+0x94>  // b.none
    40203498:	d5033fdf 	isb
    4020349c:	d53be02b 	mrs	x11, cntpct_el0
    402034a0:	c89ffe4b 	stlr	x11, [x18]
    402034a4:	aa0803eb 	mov	x11, x8
    402034a8:	52800208 	mov	w8, #0x10                  	// #16
    402034ac:	8b0d05ad 	add	x13, x13, x13, lsl #1
    402034b0:	910005ad 	add	x13, x13, #0x1
    402034b4:	f9001fed 	str	x13, [sp, #56]
    402034b8:	f9401fed 	ldr	x13, [sp, #56]
    402034bc:	71000508 	subs	w8, w8, #0x1
    402034c0:	54ffff61 	b.ne	402034ac <reservation_rust_work+0x98>  // b.any
    402034c4:	f94017e8 	ldr	x8, [sp, #40]
    402034c8:	cb0801c8 	sub	x8, x14, x8
    402034cc:	f100051f 	cmp	x8, #0x1
    402034d0:	54000248 	b.hi	40203518 <reservation_rust_work+0x104>  // b.pmore
    402034d4:	91004129 	add	x9, x9, #0x10
    402034d8:	8b081141 	add	x1, x10, x8, lsl #4
    402034dc:	f9000029 	str	x9, [x1]
    402034e0:	f900042d 	str	x13, [x1, #8]
    402034e4:	91008141 	add	x1, x10, #0x20
    402034e8:	c89ffc28 	stlr	x8, [x1]
    402034ec:	c8dffe08 	ldar	x8, [x16]
    402034f0:	eb08013f 	cmp	x9, x8
    402034f4:	54fffcc1 	b.ne	4020348c <reservation_rust_work+0x78>  // b.any
    402034f8:	f8607a28 	ldr	x8, [x17, x0, lsl #3]
    402034fc:	f100091f 	cmp	x8, #0x2
    40203500:	54000161 	b.ne	4020352c <reservation_rust_work+0x118>  // b.any
    40203504:	d4000021 	svc	#0x1
    40203508:	17ffffe1 	b	4020348c <reservation_rust_work+0x78>
    4020350c:	d503201f 	nop
    40203510:	10015102 	adr	x2, 40205f30 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.12015700318350904328+0xd8>
    40203514:	14000004 	b	40203524 <reservation_rust_work+0x110>
    40203518:	d503201f 	nop
    4020351c:	10015162 	adr	x2, 40205f48 <anon.f4139c418240cf1e99d30121eb57c0ff.3.llvm.12015700318350904328+0xf0>
    40203520:	aa0803e0 	mov	x0, x8
    40203524:	52800041 	mov	w1, #0x2                   	// #2
    40203528:	940005e9 	bl	40204ccc <core::panicking::panic_bounds_check>
    4020352c:	d4000041 	svc	#0x2
    40203530:	d4200020 	brk	#0x1

0000000040203534 <reservation_worker_a>:
    40203534:	f81f0ffe 	str	x30, [sp, #-16]!
    40203538:	aa1f03e0 	mov	x0, xzr
    4020353c:	97ffffb6 	bl	40203414 <reservation_rust_work>

0000000040203540 <reservation_worker_b>:
    40203540:	f81f0ffe 	str	x30, [sp, #-16]!
    40203544:	52800020 	mov	w0, #0x1                   	// #1
    40203548:	97ffffb3 	bl	40203414 <reservation_rust_work>

000000004020354c <jnox_kernel::reservation_jobs::Jobs::prepare_destination>:
    4020354c:	f9403409 	ldr	x9, [x0, #104]
    40203550:	b40000c9 	cbz	x9, 40203568 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x1c>
    40203554:	52800089 	mov	w9, #0x4                   	// #4
    40203558:	39002109 	strb	w9, [x8, #8]
    4020355c:	52800049 	mov	w9, #0x2                   	// #2
    40203560:	f9000109 	str	x9, [x8]
    40203564:	d65f03c0 	ret
    40203568:	aa1f03ea 	mov	x10, xzr
    4020356c:	9101e009 	add	x9, x0, #0x78
    40203570:	5280002b 	mov	w11, #0x1                   	// #1
    40203574:	386a692c 	ldrb	w12, [x9, x10]
    40203578:	3600008b 	tbz	w11, #0, 40203588 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x3c>
    4020357c:	2a1f03eb 	mov	w11, wzr
    40203580:	5280002a 	mov	w10, #0x1                   	// #1
    40203584:	34ffff8c 	cbz	w12, 40203574 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x28>
    40203588:	35fffe6c 	cbnz	w12, 40203554 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>
    4020358c:	39418009 	ldrb	w9, [x0, #96]
    40203590:	71000d3f 	cmp	w9, #0x3
    40203594:	54fffe01 	b.ne	40203554 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>  // b.any
    40203598:	f9403809 	ldr	x9, [x0, #112]
    4020359c:	b5fffdc9 	cbnz	x9, 40203554 <jnox_kernel::reservation_jobs::Jobs::prepare_destination+0x8>
    402035a0:	aa1f03e1 	mov	x1, xzr
    402035a4:	14000141 	b	40203aa8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>

00000000402035a8 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision>:
    402035a8:	f9403408 	ldr	x8, [x0, #104]
    402035ac:	f100051f 	cmp	x8, #0x1
    402035b0:	54000321 	b.ne	40203614 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x6c>  // b.any
    402035b4:	d10143ff 	sub	sp, sp, #0x50
    402035b8:	a9025ffe 	stp	x30, x23, [sp, #32]
    402035bc:	a90357f6 	stp	x22, x21, [sp, #48]
    402035c0:	a9044ff4 	stp	x20, x19, [sp, #64]
    402035c4:	aa0003f3 	mov	x19, x0
    402035c8:	b9400028 	ldr	w8, [x1]
    402035cc:	39418829 	ldrb	w9, [x1, #98]
    402035d0:	7100011f 	cmp	w8, #0x0
    402035d4:	52800068 	mov	w8, #0x3                   	// #3
    402035d8:	1a881128 	csel	w8, w9, w8, ne  // ne = any
    402035dc:	39418009 	ldrb	w9, [x0, #96]
    402035e0:	71000d3f 	cmp	w9, #0x3
    402035e4:	540001c0 	b.eq	4020361c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x74>  // b.none
    402035e8:	71000d1f 	cmp	w8, #0x3
    402035ec:	54000180 	b.eq	4020361c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x74>  // b.none
    402035f0:	2a1f03e0 	mov	w0, wzr
    402035f4:	f940042a 	ldr	x10, [x1, #8]
    402035f8:	f9402e6b 	ldr	x11, [x19, #88]
    402035fc:	eb0b015f 	cmp	x10, x11
    40203600:	1a9f17ea 	cset	w10, eq  // eq = none
    40203604:	6b08013f 	cmp	w9, w8
    40203608:	540007a1 	b.ne	402036fc <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    4020360c:	3700012a 	tbnz	w10, #0, 40203630 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x88>
    40203610:	1400003b 	b	402036fc <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>
    40203614:	2a1f03e0 	mov	w0, wzr
    40203618:	d65f03c0 	ret
    4020361c:	2a1f03e0 	mov	w0, wzr
    40203620:	71000d3f 	cmp	w9, #0x3
    40203624:	540006c1 	b.ne	402036fc <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    40203628:	71000d1f 	cmp	w8, #0x3
    4020362c:	54000681 	b.ne	402036fc <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>  // b.any
    40203630:	aa1f03eb 	mov	x11, xzr
    40203634:	9101e268 	add	x8, x19, #0x78
    40203638:	91018029 	add	x9, x1, #0x60
    4020363c:	5280002a 	mov	w10, #0x1                   	// #1
    40203640:	386b690c 	ldrb	w12, [x8, x11]
    40203644:	386b692d 	ldrb	w13, [x9, x11]
    40203648:	360000aa 	tbz	w10, #0, 4020365c <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xb4>
    4020364c:	2a1f03ea 	mov	w10, wzr
    40203650:	6b0d019f 	cmp	w12, w13
    40203654:	5280002b 	mov	w11, #0x1                   	// #1
    40203658:	54ffff40 	b.eq	40203640 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x98>  // b.none
    4020365c:	6b0d019f 	cmp	w12, w13
    40203660:	540004c1 	b.ne	402036f8 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x150>  // b.any
    40203664:	f9403a68 	ldr	x8, [x19, #112]
    40203668:	f9402c29 	ldr	x9, [x1, #88]
    4020366c:	eb09011f 	cmp	x8, x9
    40203670:	54000441 	b.ne	402036f8 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x150>  // b.any
    40203674:	aa1f03e8 	mov	x8, xzr
    40203678:	91002274 	add	x20, x19, #0x8
    4020367c:	b8418675 	ldr	w21, [x19], #24
    40203680:	91010037 	add	x23, x1, #0x40
    40203684:	aa0803f6 	mov	x22, x8
    40203688:	f100091f 	cmp	x8, #0x2
    4020368c:	54000300 	b.eq	402036ec <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.none
    40203690:	360000b5 	tbz	w21, #0, 402036a4 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xfc>
    40203694:	b9400268 	ldr	w8, [x19]
    40203698:	f85f0269 	ldur	x9, [x19, #-16]
    4020369c:	a90127e8 	stp	x8, x9, [sp, #16]
    402036a0:	14000009 	b	402036c4 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x11c>
    402036a4:	910023e8 	add	x8, sp, #0x8
    402036a8:	aa1403e0 	mov	x0, x20
    402036ac:	aa1f03e1 	mov	x1, xzr
    402036b0:	940002e7 	bl	4020424c <jnox_kernel::service_policy::PeriodicReservation::allocation_at>
    402036b4:	f94007e8 	ldr	x8, [sp, #8]
    402036b8:	f100051f 	cmp	x8, #0x1
    402036bc:	54000181 	b.ne	402036ec <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.any
    402036c0:	f9400be8 	ldr	x8, [sp, #16]
    402036c4:	f85f82e9 	ldur	x9, [x23, #-8]
    402036c8:	eb09011f 	cmp	x8, x9
    402036cc:	54000101 	b.ne	402036ec <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x144>  // b.any
    402036d0:	f84106e9 	ldr	x9, [x23], #16
    402036d4:	91006273 	add	x19, x19, #0x18
    402036d8:	f9400fea 	ldr	x10, [sp, #24]
    402036dc:	9100a294 	add	x20, x20, #0x28
    402036e0:	910006c8 	add	x8, x22, #0x1
    402036e4:	eb09015f 	cmp	x10, x9
    402036e8:	54fffce0 	b.eq	40203684 <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0xdc>  // b.none
    402036ec:	f10006df 	cmp	x22, #0x1
    402036f0:	1a9f97e0 	cset	w0, hi  // hi = pmore
    402036f4:	14000002 	b	402036fc <jnox_kernel::reservation_jobs::Jobs::matches_first_decision+0x154>
    402036f8:	2a1f03e0 	mov	w0, wzr
    402036fc:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40203700:	a94357f6 	ldp	x22, x21, [sp, #48]
    40203704:	a9425ffe 	ldp	x30, x23, [sp, #32]
    40203708:	910143ff 	add	sp, sp, #0x50
    4020370c:	d65f03c0 	ret

0000000040203710 <jnox_kernel::reservation_jobs::Jobs::new>:
    40203710:	d10203ff 	sub	sp, sp, #0x80
    40203714:	a90657fe 	stp	x30, x21, [sp, #96]
    40203718:	a9074ff4 	stp	x20, x19, [sp, #112]
    4020371c:	2a0103f4 	mov	w20, w1
    40203720:	2a0003f5 	mov	w21, w0
    40203724:	aa0803f3 	mov	x19, x8
    40203728:	72001c3f 	tst	w1, #0xff
    4020372c:	540002c0 	b.eq	40203784 <jnox_kernel::reservation_jobs::Jobs::new+0x74>  // b.none
    40203730:	52800028 	mov	w8, #0x1                   	// #1
    40203734:	52800049 	mov	w9, #0x2                   	// #2
    40203738:	290027e8 	stp	w8, w9, [sp]
    4020373c:	12001e8a 	and	w10, w20, #0xff
    40203740:	7100095f 	cmp	w10, #0x2
    40203744:	290127e8 	stp	w8, w9, [sp, #8]
    40203748:	540002a1 	b.ne	4020379c <jnox_kernel::reservation_jobs::Jobs::new+0x8c>  // b.any
    4020374c:	29402be9 	ldp	w9, w10, [sp]
    40203750:	29022be9 	stp	w9, w10, [sp, #16]
    40203754:	29412be9 	ldp	w9, w10, [sp, #8]
    40203758:	29032be9 	stp	w9, w10, [sp, #24]
    4020375c:	52800109 	mov	w9, #0x8                   	// #8
    40203760:	290427e8 	stp	w8, w9, [sp, #32]
    40203764:	910043e0 	add	x0, sp, #0x10
    40203768:	52800061 	mov	w1, #0x3                   	// #3
    4020376c:	940003c7 	bl	40204688 <jnox_kernel::temporal_policy::admit_reservations>
    40203770:	12001c08 	and	w8, w0, #0xff
    40203774:	71000d1f 	cmp	w8, #0x3
    40203778:	54000401 	b.ne	402037f8 <jnox_kernel::reservation_jobs::Jobs::new+0xe8>  // b.any
    4020377c:	52800088 	mov	w8, #0x4                   	// #4
    40203780:	1400003b 	b	4020386c <jnox_kernel::reservation_jobs::Jobs::new+0x15c>
    40203784:	52800048 	mov	w8, #0x2                   	// #2
    40203788:	52800109 	mov	w9, #0x8                   	// #8
    4020378c:	5280002a 	mov	w10, #0x1                   	// #1
    40203790:	290027e8 	stp	w8, w9, [sp]
    40203794:	52800088 	mov	w8, #0x4                   	// #4
    40203798:	290123ea 	stp	w10, w8, [sp, #8]
    4020379c:	910003e0 	mov	x0, sp
    402037a0:	52800041 	mov	w1, #0x2                   	// #2
    402037a4:	940003b9 	bl	40204688 <jnox_kernel::temporal_policy::admit_reservations>
    402037a8:	12001c08 	and	w8, w0, #0xff
    402037ac:	71000d1f 	cmp	w8, #0x3
    402037b0:	54000241 	b.ne	402037f8 <jnox_kernel::reservation_jobs::Jobs::new+0xe8>  // b.any
    402037b4:	34000275 	cbz	w21, 40203800 <jnox_kernel::reservation_jobs::Jobs::new+0xf0>
    402037b8:	294027e8 	ldp	w8, w9, [sp]
    402037bc:	290a27e8 	stp	w8, w9, [sp, #80]
    402037c0:	294127e8 	ldp	w8, w9, [sp, #8]
    402037c4:	290b27e8 	stp	w8, w9, [sp, #88]
    402037c8:	910043e8 	add	x8, sp, #0x10
    402037cc:	910143e1 	add	x1, sp, #0x50
    402037d0:	aa1f03e0 	mov	x0, xzr
    402037d4:	940002df 	bl	40204350 <jnox_kernel::temporal_policy::HardCbs<_>::new>
    402037d8:	b94013e8 	ldr	w8, [sp, #16]
    402037dc:	36000468 	tbz	w8, #0, 40203868 <jnox_kernel::reservation_jobs::Jobs::new+0x158>
    402037e0:	a941a7ee 	ldp	x14, x9, [sp, #24]
    402037e4:	a942a3eb 	ldp	x11, x8, [sp, #40]
    402037e8:	a943abec 	ldp	x12, x10, [sp, #56]
    402037ec:	5280002f 	mov	w15, #0x1                   	// #1
    402037f0:	f94027ed 	ldr	x13, [sp, #72]
    402037f4:	14000011 	b	40203838 <jnox_kernel::reservation_jobs::Jobs::new+0x128>
    402037f8:	11000508 	add	w8, w8, #0x1
    402037fc:	1400001c 	b	4020386c <jnox_kernel::reservation_jobs::Jobs::new+0x15c>
    40203800:	294027e8 	ldp	w8, w9, [sp]
    40203804:	d100050a 	sub	x10, x8, #0x1
    40203808:	eb09015f 	cmp	x10, x9
    4020380c:	540002e2 	b.cs	40203868 <jnox_kernel::reservation_jobs::Jobs::new+0x158>  // b.hs, b.nlast
    40203810:	294137ea 	ldp	w10, w13, [sp, #8]
    40203814:	d100054b 	sub	x11, x10, #0x1
    40203818:	eb0d017f 	cmp	x11, x13
    4020381c:	54000262 	b.cs	40203868 <jnox_kernel::reservation_jobs::Jobs::new+0x158>  // b.hs, b.nlast
    40203820:	aa1f03ec 	mov	x12, xzr
    40203824:	aa1f03eb 	mov	x11, xzr
    40203828:	aa1f03ef 	mov	x15, xzr
    4020382c:	72001e9f 	tst	w20, #0xff
    40203830:	1a9f17f0 	cset	w16, eq  // eq = none
    40203834:	aa0803ee 	mov	x14, x8
    40203838:	a9003a6f 	stp	x15, x14, [x19]
    4020383c:	a9012e69 	stp	x9, x11, [x19, #16]
    40203840:	a9023268 	stp	x8, x12, [x19, #32]
    40203844:	a903366a 	stp	x10, x13, [x19, #48]
    40203848:	a9042a70 	stp	x16, x10, [x19, #64]
    4020384c:	f9002a70 	str	x16, [x19, #80]
    40203850:	52800068 	mov	w8, #0x3                   	// #3
    40203854:	39018268 	strb	w8, [x19, #96]
    40203858:	a906fe7f 	stp	xzr, xzr, [x19, #104]
    4020385c:	7900f27f 	strh	wzr, [x19, #120]
    40203860:	3901ea74 	strb	w20, [x19, #122]
    40203864:	14000005 	b	40203878 <jnox_kernel::reservation_jobs::Jobs::new+0x168>
    40203868:	52800028 	mov	w8, #0x1                   	// #1
    4020386c:	39002268 	strb	w8, [x19, #8]
    40203870:	52800048 	mov	w8, #0x2                   	// #2
    40203874:	f9000268 	str	x8, [x19]
    40203878:	a9474ff4 	ldp	x20, x19, [sp, #112]
    4020387c:	a94657fe 	ldp	x30, x21, [sp, #96]
    40203880:	910203ff 	add	sp, sp, #0x80
    40203884:	d65f03c0 	ret

0000000040203888 <jnox_kernel::reservation_jobs::Jobs::open>:
    40203888:	d10783ff 	sub	sp, sp, #0x1e0
    4020388c:	a9197bfd 	stp	x29, x30, [sp, #400]
    40203890:	a91a67fa 	stp	x26, x25, [sp, #416]
    40203894:	a91b5ff8 	stp	x24, x23, [sp, #432]
    40203898:	a91c57f6 	stp	x22, x21, [sp, #448]
    4020389c:	a91d4ff4 	stp	x20, x19, [sp, #464]
    402038a0:	aa0803f3 	mov	x19, x8
    402038a4:	f9403408 	ldr	x8, [x0, #104]
    402038a8:	eb08003f 	cmp	x1, x8
    402038ac:	540002e1 	b.ne	40203908 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.any
    402038b0:	aa0103f5 	mov	x21, x1
    402038b4:	aa0003f4 	mov	x20, x0
    402038b8:	3941e816 	ldrb	w22, [x0, #122]
    402038bc:	710002df 	cmp	w22, #0x0
    402038c0:	52800148 	mov	w8, #0xa                   	// #10
    402038c4:	52800449 	mov	w9, #0x22                  	// #34
    402038c8:	9a880128 	csel	x8, x9, x8, eq  // eq = none
    402038cc:	eb08003f 	cmp	x1, x8
    402038d0:	540001c2 	b.cs	40203908 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.hs, b.nlast
    402038d4:	39418288 	ldrb	w8, [x20, #96]
    402038d8:	71000d1f 	cmp	w8, #0x3
    402038dc:	54000161 	b.ne	40203908 <jnox_kernel::reservation_jobs::Jobs::open+0x80>  // b.any
    402038e0:	aa1403e1 	mov	x1, x20
    402038e4:	f8408428 	ldr	x8, [x1], #8
    402038e8:	f100051f 	cmp	x8, #0x1
    402038ec:	54000241 	b.ne	40203934 <jnox_kernel::reservation_jobs::Jobs::open+0xac>  // b.any
    402038f0:	f9401e97 	ldr	x23, [x20, #56]
    402038f4:	910583e0 	add	x0, sp, #0x160
    402038f8:	52800602 	mov	w2, #0x30                  	// #48
    402038fc:	94000844 	bl	40205a0c <memcpy>
    40203900:	52800028 	mov	w8, #0x1                   	// #1
    40203904:	14000021 	b	40203988 <jnox_kernel::reservation_jobs::Jobs::open+0x100>
    40203908:	52800088 	mov	w8, #0x4                   	// #4
    4020390c:	39002268 	strb	w8, [x19, #8]
    40203910:	52800048 	mov	w8, #0x2                   	// #2
    40203914:	f9000268 	str	x8, [x19]
    40203918:	a95d4ff4 	ldp	x20, x19, [sp, #464]
    4020391c:	a95c57f6 	ldp	x22, x21, [sp, #448]
    40203920:	a95b5ff8 	ldp	x24, x23, [sp, #432]
    40203924:	a95a67fa 	ldp	x26, x25, [sp, #416]
    40203928:	a9597bfd 	ldp	x29, x30, [sp, #400]
    4020392c:	910783ff 	add	sp, sp, #0x1e0
    40203930:	d65f03c0 	ret
    40203934:	910203e0 	add	x0, sp, #0x80
    40203938:	9100a017 	add	x23, x0, #0x28
    4020393c:	52800028 	mov	w8, #0x1                   	// #1
    40203940:	2a0803f8 	mov	w24, w8
    40203944:	9100a039 	add	x25, x1, #0x28
    40203948:	52800502 	mov	w2, #0x28                  	// #40
    4020394c:	94000830 	bl	40205a0c <memcpy>
    40203950:	2a1f03e8 	mov	w8, wzr
    40203954:	aa1903e1 	mov	x1, x25
    40203958:	aa1703e0 	mov	x0, x23
    4020395c:	3707ff38 	tbnz	w24, #0, 40203940 <jnox_kernel::reservation_jobs::Jobs::open+0xb8>
    40203960:	910583e0 	add	x0, sp, #0x160
    40203964:	910203e1 	add	x1, sp, #0x80
    40203968:	52800602 	mov	w2, #0x30                  	// #48
    4020396c:	94000828 	bl	40205a0c <memcpy>
    40203970:	aa1f03e8 	mov	x8, xzr
    40203974:	a94b27f7 	ldp	x23, x9, [sp, #176]
    40203978:	a94c2fea 	ldp	x10, x11, [sp, #192]
    4020397c:	a914abe9 	stp	x9, x10, [sp, #328]
    40203980:	f900afeb 	str	x11, [sp, #344]
    40203984:	f9402e98 	ldr	x24, [x20, #88]
    40203988:	f9403a99 	ldr	x25, [x20, #112]
    4020398c:	f90003e8 	str	x8, [sp]
    40203990:	910003e8 	mov	x8, sp
    40203994:	7940f29a 	ldrh	w26, [x20, #120]
    40203998:	91002100 	add	x0, x8, #0x8
    4020399c:	910583e1 	add	x1, sp, #0x160
    402039a0:	52800602 	mov	w2, #0x30                  	// #48
    402039a4:	9400081a 	bl	40205a0c <memcpy>
    402039a8:	3901ebf6 	strb	w22, [sp, #122]
    402039ac:	a954a7e8 	ldp	x8, x9, [sp, #328]
    402039b0:	a903a3f7 	stp	x23, x8, [sp, #56]
    402039b4:	f940afe8 	ldr	x8, [sp, #344]
    402039b8:	a904a3e9 	stp	x9, x8, [sp, #72]
    402039bc:	a906e7f5 	stp	x21, x25, [sp, #104]
    402039c0:	7900f3fa 	strh	w26, [sp, #120]
    402039c4:	f9002ff8 	str	x24, [sp, #88]
    402039c8:	52800068 	mov	w8, #0x3                   	// #3
    402039cc:	390183e8 	strb	w8, [sp, #96]
    402039d0:	910203f7 	add	x23, sp, #0x80
    402039d4:	910203e8 	add	x8, sp, #0x80
    402039d8:	910003e0 	mov	x0, sp
    402039dc:	aa1503e1 	mov	x1, x21
    402039e0:	94000032 	bl	40203aa8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>
    402039e4:	f94043f6 	ldr	x22, [sp, #128]
    402039e8:	394223f5 	ldrb	w21, [sp, #136]
    402039ec:	f1000adf 	cmp	x22, #0x2
    402039f0:	54000061 	b.ne	402039fc <jnox_kernel::reservation_jobs::Jobs::open+0x174>  // b.any
    402039f4:	39002275 	strb	w21, [x19, #8]
    402039f8:	17ffffc6 	b	40203910 <jnox_kernel::reservation_jobs::Jobs::open+0x88>
    402039fc:	9103a3e0 	add	x0, sp, #0xe8
    40203a00:	910026e1 	add	x1, x23, #0x9
    40203a04:	52800be2 	mov	w2, #0x5f                  	// #95
    40203a08:	94000801 	bl	40205a0c <memcpy>
    40203a0c:	910003e1 	mov	x1, sp
    40203a10:	aa1403e0 	mov	x0, x20
    40203a14:	52801002 	mov	w2, #0x80                  	// #128
    40203a18:	940007fd 	bl	40205a0c <memcpy>
    40203a1c:	f9000276 	str	x22, [x19]
    40203a20:	39002275 	strb	w21, [x19, #8]
    40203a24:	91002660 	add	x0, x19, #0x9
    40203a28:	9103a3e1 	add	x1, sp, #0xe8
    40203a2c:	52800be2 	mov	w2, #0x5f                  	// #95
    40203a30:	940007f7 	bl	40205a0c <memcpy>
    40203a34:	17ffffb9 	b	40203918 <jnox_kernel::reservation_jobs::Jobs::open+0x90>

0000000040203a38 <jnox_kernel::reservation_jobs::Jobs::trap>:
    40203a38:	3941800a 	ldrb	w10, [x0, #96]
    40203a3c:	71000d5f 	cmp	w10, #0x3
    40203a40:	54000061 	b.ne	40203a4c <jnox_kernel::reservation_jobs::Jobs::trap+0x14>  // b.any
    40203a44:	52800080 	mov	w0, #0x4                   	// #4
    40203a48:	d65f03c0 	ret
    40203a4c:	aa0003e8 	mov	x8, x0
    40203a50:	12001c49 	and	w9, w2, #0xff
    40203a54:	52800080 	mov	w0, #0x4                   	// #4
    40203a58:	6b09015f 	cmp	w10, w9
    40203a5c:	54000181 	b.ne	40203a8c <jnox_kernel::reservation_jobs::Jobs::trap+0x54>  // b.any
    40203a60:	f9402d0a 	ldr	x10, [x8, #88]
    40203a64:	eb01015f 	cmp	x10, x1
    40203a68:	54000121 	b.ne	40203a8c <jnox_kernel::reservation_jobs::Jobs::trap+0x54>  // b.any
    40203a6c:	f100043f 	cmp	x1, #0x1
    40203a70:	54000108 	b.hi	40203a90 <jnox_kernel::reservation_jobs::Jobs::trap+0x58>  // b.pmore
    40203a74:	2a1f03e0 	mov	w0, wzr
    40203a78:	11000929 	add	w9, w9, #0x2
    40203a7c:	8b01010a 	add	x10, x8, x1
    40203a80:	3901e149 	strb	w9, [x10, #120]
    40203a84:	52800069 	mov	w9, #0x3                   	// #3
    40203a88:	39018109 	strb	w9, [x8, #96]
    40203a8c:	d65f03c0 	ret
    40203a90:	f81f0ffe 	str	x30, [sp, #-16]!
    40203a94:	d503201f 	nop
    40203a98:	10012642 	adr	x2, 40205f60 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236>
    40203a9c:	aa0103e0 	mov	x0, x1
    40203aa0:	52800041 	mov	w1, #0x2                   	// #2
    40203aa4:	9400048a 	bl	40204ccc <core::panicking::panic_bounds_check>

0000000040203aa8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236>:
    40203aa8:	d10483ff 	sub	sp, sp, #0x120
    40203aac:	a90c7bfd 	stp	x29, x30, [sp, #192]
    40203ab0:	a90d6ffc 	stp	x28, x27, [sp, #208]
    40203ab4:	a90e67fa 	stp	x26, x25, [sp, #224]
    40203ab8:	a90f5ff8 	stp	x24, x23, [sp, #240]
    40203abc:	a91057f6 	stp	x22, x21, [sp, #256]
    40203ac0:	a9114ff4 	stp	x20, x19, [sp, #272]
    40203ac4:	aa0103f5 	mov	x21, x1
    40203ac8:	aa0003f4 	mov	x20, x0
    40203acc:	aa0803f3 	mov	x19, x8
    40203ad0:	3941e808 	ldrb	w8, [x0, #122]
    40203ad4:	910083e9 	add	x9, sp, #0x20
    40203ad8:	9100413b 	add	x27, x9, #0x10
    40203adc:	340000e8 	cbz	w8, 40203af8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x50>
    40203ae0:	f10002bf 	cmp	x21, #0x0
    40203ae4:	b21e03e9 	mov	x9, #0x400000004           	// #17179869188
    40203ae8:	9a9f0129 	csel	x9, x9, xzr, eq  // eq = none
    40203aec:	7100051f 	cmp	w8, #0x1
    40203af0:	9a9f012a 	csel	x10, x9, xzr, eq  // eq = none
    40203af4:	1400000b 	b	40203b20 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203af8:	aa1f03ea 	mov	x10, xzr
    40203afc:	f1005ebf 	cmp	x21, #0x17
    40203b00:	54000108 	b.hi	40203b20 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>  // b.pmore
    40203b04:	52800028 	mov	w8, #0x1                   	// #1
    40203b08:	9ad52108 	lsl	x8, x8, x21
    40203b0c:	52840629 	mov	w9, #0x2031                	// #8241
    40203b10:	72a00809 	movk	w9, #0x40, lsl #16
    40203b14:	ea09011f 	tst	x8, x9
    40203b18:	54000da0 	b.eq	40203ccc <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x224>  // b.none
    40203b1c:	5280002a 	mov	w10, #0x1                   	// #1
    40203b20:	aa1f03f6 	mov	x22, xzr
    40203b24:	a9012bea 	stp	x10, x10, [sp, #16]
    40203b28:	5280011d 	mov	w29, #0x8                   	// #8
    40203b2c:	910063fa 	add	x26, sp, #0x18
    40203b30:	5280003c 	mov	w28, #0x1                   	// #1
    40203b34:	b8767b57 	ldr	w23, [x26, x22, lsl #2]
    40203b38:	34000297 	cbz	w23, 40203b88 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0xe0>
    40203b3c:	8b160298 	add	x24, x20, x22
    40203b40:	3941e308 	ldrb	w8, [x24, #120]
    40203b44:	71000d1f 	cmp	w8, #0x3
    40203b48:	7a401904 	ccmp	w8, #0x0, #0x4, ne  // ne = any
    40203b4c:	540014a1 	b.ne	40203de0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.any
    40203b50:	8b160a99 	add	x25, x20, x22, lsl #2
    40203b54:	b9407328 	ldr	w8, [x25, #112]
    40203b58:	35001448 	cbnz	w8, 40203de0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203b5c:	f9400288 	ldr	x8, [x20]
    40203b60:	f100051f 	cmp	x8, #0x1
    40203b64:	540000e1 	b.ne	40203b80 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0xd8>  // b.any
    40203b68:	91002280 	add	x0, x20, #0x8
    40203b6c:	aa1603e1 	mov	x1, x22
    40203b70:	2a1703e2 	mov	w2, w23
    40203b74:	94000279 	bl	40204558 <jnox_kernel::temporal_policy::HardCbs<_>::release>
    40203b78:	f100141f 	cmp	x0, #0x5
    40203b7c:	54000a01 	b.ne	40203cbc <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x214>  // b.any
    40203b80:	b9007337 	str	w23, [x25, #112]
    40203b84:	3901e31c 	strb	w28, [x24, #120]
    40203b88:	f10013bd 	subs	x29, x29, #0x4
    40203b8c:	910006d6 	add	x22, x22, #0x1
    40203b90:	54fffd21 	b.ne	40203b34 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x8c>  // b.any
    40203b94:	6f00e400 	movi	v0.2d, #0x0
    40203b98:	ad0103e0 	stp	q0, q0, [sp, #32]
    40203b9c:	f9400288 	ldr	x8, [x20]
    40203ba0:	f100051f 	cmp	x8, #0x1
    40203ba4:	54000421 	b.ne	40203c28 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x180>  // b.any
    40203ba8:	aa1f03f5 	mov	x21, xzr
    40203bac:	aa1f03fb 	mov	x27, xzr
    40203bb0:	91006296 	add	x22, x20, #0x18
    40203bb4:	910083f7 	add	x23, sp, #0x20
    40203bb8:	910203e8 	add	x8, sp, #0x80
    40203bbc:	91002280 	add	x0, x20, #0x8
    40203bc0:	aa1503e1 	mov	x1, x21
    40203bc4:	9400028b 	bl	402045f0 <jnox_kernel::temporal_policy::HardCbs<_>::available>
    40203bc8:	a94823e9 	ldp	x9, x8, [sp, #128]
    40203bcc:	f100093f 	cmp	x9, #0x2
    40203bd0:	54000280 	b.eq	40203c20 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x178>  // b.none
    40203bd4:	36000069 	tbz	w9, #0, 40203be0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x138>
    40203bd8:	f9404be9 	ldr	x9, [sp, #144]
    40203bdc:	14000003 	b	40203be8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x140>
    40203be0:	b94002c8 	ldr	w8, [x22]
    40203be4:	f85f02c9 	ldur	x9, [x22, #-16]
    40203be8:	8b1b02ea 	add	x10, x23, x27
    40203bec:	9100437b 	add	x27, x27, #0x10
    40203bf0:	2a0803e8 	mov	w8, w8
    40203bf4:	a9002548 	stp	x8, x9, [x10]
    40203bf8:	910062d6 	add	x22, x22, #0x18
    40203bfc:	910006b5 	add	x21, x21, #0x1
    40203c00:	f100837f 	cmp	x27, #0x20
    40203c04:	54fffda1 	b.ne	40203bb8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x110>  // b.any
    40203c08:	910203e8 	add	x8, sp, #0x80
    40203c0c:	91002280 	add	x0, x20, #0x8
    40203c10:	940001f4 	bl	402043e0 <jnox_kernel::temporal_policy::HardCbs<_>::tick>
    40203c14:	a94823e9 	ldp	x9, x8, [sp, #128]
    40203c18:	f100053f 	cmp	x9, #0x1
    40203c1c:	54000641 	b.ne	40203ce4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x23c>  // b.any
    40203c20:	f100111f 	cmp	x8, #0x4
    40203c24:	14000027 	b	40203cc0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x218>
    40203c28:	910083e8 	add	x8, sp, #0x20
    40203c2c:	b27d0117 	orr	x23, x8, #0x8
    40203c30:	52800a1a 	mov	w26, #0x50                  	// #80
    40203c34:	91002296 	add	x22, x20, #0x8
    40203c38:	910203e8 	add	x8, sp, #0x80
    40203c3c:	aa1603e0 	mov	x0, x22
    40203c40:	aa1503e1 	mov	x1, x21
    40203c44:	94000182 	bl	4020424c <jnox_kernel::service_policy::PeriodicReservation::allocation_at>
    40203c48:	b94083e8 	ldr	w8, [sp, #128]
    40203c4c:	36001108 	tbz	w8, #0, 40203e6c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c4>
    40203c50:	a948a7e8 	ldp	x8, x9, [sp, #136]
    40203c54:	f100a35a 	subs	x26, x26, #0x28
    40203c58:	a93fa6e8 	stp	x8, x9, [x23, #-8]
    40203c5c:	9100a2d6 	add	x22, x22, #0x28
    40203c60:	910042f7 	add	x23, x23, #0x10
    40203c64:	54fffea1 	b.ne	40203c38 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x190>  // b.any
    40203c68:	aa1f03e8 	mov	x8, xzr
    40203c6c:	910083e9 	add	x9, sp, #0x20
    40203c70:	9101c28c 	add	x12, x20, #0x70
    40203c74:	a90827ec 	stp	x12, x9, [sp, #128]
    40203c78:	5280004a 	mov	w10, #0x2                   	// #2
    40203c7c:	a909a7ea 	stp	x10, x9, [sp, #152]
    40203c80:	f9400bf7 	ldr	x23, [sp, #16]
    40203c84:	9100050a 	add	x10, x8, #0x1
    40203c88:	b868798b 	ldr	w11, [x12, x8, lsl #2]
    40203c8c:	3400006b 	cbz	w11, 40203c98 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x1f0>
    40203c90:	f940012b 	ldr	x11, [x9]
    40203c94:	b50003cb 	cbnz	x11, 40203d0c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x264>
    40203c98:	f100095f 	cmp	x10, #0x2
    40203c9c:	aa1b03e9 	mov	x9, x27
    40203ca0:	52800028 	mov	w8, #0x1                   	// #1
    40203ca4:	54ffff01 	b.ne	40203c84 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x1dc>  // b.any
    40203ca8:	aa1f03e9 	mov	x9, xzr
    40203cac:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203cb0:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203cb4:	52800068 	mov	w8, #0x3                   	// #3
    40203cb8:	14000059 	b	40203e1c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x374>
    40203cbc:	f100101f 	cmp	x0, #0x4
    40203cc0:	52800068 	mov	w8, #0x3                   	// #3
    40203cc4:	1a880508 	cinc	w8, w8, ne  // ne = any
    40203cc8:	1400006a 	b	40203e70 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c8>
    40203ccc:	f10006bf 	cmp	x21, #0x1
    40203cd0:	540008c0 	b.eq	40203de8 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x340>  // b.none
    40203cd4:	f1005ebf 	cmp	x21, #0x17
    40203cd8:	54fff241 	b.ne	40203b20 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>  // b.any
    40203cdc:	52800c8a 	mov	w10, #0x64                  	// #100
    40203ce0:	17ffff90 	b	40203b20 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203ce4:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203ce8:	f9404bf6 	ldr	x22, [sp, #144]
    40203cec:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203cf0:	36000808 	tbz	w8, #0, 40203df0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x348>
    40203cf4:	f10006df 	cmp	x22, #0x1
    40203cf8:	f9400bf7 	ldr	x23, [sp, #16]
    40203cfc:	54000369 	b.ls	40203d68 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x2c0>  // b.plast
    40203d00:	d503201f 	nop
    40203d04:	10011462 	adr	x2, 40205f90 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x30>
    40203d08:	14000067 	b	40203ea4 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3fc>
    40203d0c:	f9004bea 	str	x10, [sp, #144]
    40203d10:	f9400529 	ldr	x9, [x9, #8]
    40203d14:	a90aa3e9 	stp	x9, x8, [sp, #168]
    40203d18:	f9005fe8 	str	x8, [sp, #184]
    40203d1c:	910183e8 	add	x8, sp, #0x60
    40203d20:	91002108 	add	x8, x8, #0x8
    40203d24:	910203e0 	add	x0, sp, #0x80
    40203d28:	9102a3e1 	add	x1, sp, #0xa8
    40203d2c:	94000098 	bl	40203f8c <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold>
    40203d30:	f9403ff6 	ldr	x22, [sp, #120]
    40203d34:	f1000adf 	cmp	x22, #0x2
    40203d38:	54000b22 	b.cs	40203e9c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3f4>  // b.hs, b.nlast
    40203d3c:	52800508 	mov	w8, #0x28                  	// #40
    40203d40:	91002289 	add	x9, x20, #0x8
    40203d44:	9b0826c0 	madd	x0, x22, x8, x9
    40203d48:	aa1503e1 	mov	x1, x21
    40203d4c:	52800022 	mov	w2, #0x1                   	// #1
    40203d50:	9400015a 	bl	402042b8 <jnox_kernel::service_policy::PeriodicReservation::grant_at>
    40203d54:	f100041f 	cmp	x0, #0x1
    40203d58:	fa410820 	ccmp	x1, #0x1, #0x0, eq  // eq = none
    40203d5c:	54000421 	b.ne	40203de0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.any
    40203d60:	ad4107e0 	ldp	q0, q1, [sp, #32]
    40203d64:	ad0207e0 	stp	q0, q1, [sp, #64]
    40203d68:	9101e288 	add	x8, x20, #0x78
    40203d6c:	38766908 	ldrb	w8, [x8, x22]
    40203d70:	51000508 	sub	w8, w8, #0x1
    40203d74:	7100091f 	cmp	w8, #0x2
    40203d78:	54000342 	b.cs	40203de0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>  // b.hs, b.nlast
    40203d7c:	9101c28a 	add	x10, x20, #0x70
    40203d80:	b8767948 	ldr	w8, [x10, x22, lsl #2]
    40203d84:	51000509 	sub	w9, w8, #0x1
    40203d88:	d3607d29 	lsl	x9, x9, #32
    40203d8c:	7100011f 	cmp	w8, #0x0
    40203d90:	52808028 	mov	w8, #0x401                 	// #1025
    40203d94:	9a890108 	csel	x8, x8, x9, eq  // eq = none
    40203d98:	37000248 	tbnz	w8, #0, 40203de0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203d9c:	d360fd08 	lsr	x8, x8, #32
    40203da0:	b8367948 	str	w8, [x10, x22, lsl #2]
    40203da4:	910103e9 	add	x9, sp, #0x40
    40203da8:	8b161129 	add	x9, x9, x22, lsl #4
    40203dac:	f940012a 	ldr	x10, [x9]
    40203db0:	b400018a 	cbz	x10, 40203de0 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x338>
    40203db4:	d100054a 	sub	x10, x10, #0x1
    40203db8:	f900012a 	str	x10, [x9]
    40203dbc:	3941ea89 	ldrb	w9, [x20, #122]
    40203dc0:	7100093f 	cmp	w9, #0x2
    40203dc4:	540001e0 	b.eq	40203e00 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x358>  // b.none
    40203dc8:	7100053f 	cmp	w9, #0x1
    40203dcc:	540001e1 	b.ne	40203e08 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x360>  // b.any
    40203dd0:	f100011f 	cmp	x8, #0x0
    40203dd4:	52800048 	mov	w8, #0x2                   	// #2
    40203dd8:	1a9f0108 	csel	w8, w8, wzr, eq  // eq = none
    40203ddc:	1400000d 	b	40203e10 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x368>
    40203de0:	52800088 	mov	w8, #0x4                   	// #4
    40203de4:	14000023 	b	40203e70 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c8>
    40203de8:	d2c00c8a 	mov	x10, #0x6400000000          	// #429496729600
    40203dec:	17ffff4d 	b	40203b20 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x78>
    40203df0:	aa1f03e9 	mov	x9, xzr
    40203df4:	52800068 	mov	w8, #0x3                   	// #3
    40203df8:	f9400bf7 	ldr	x23, [sp, #16]
    40203dfc:	14000008 	b	40203e1c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x374>
    40203e00:	2a1f03e8 	mov	w8, wzr
    40203e04:	14000003 	b	40203e10 <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x368>
    40203e08:	f100011f 	cmp	x8, #0x0
    40203e0c:	1a9f17e8 	cset	w8, eq  // eq = none
    40203e10:	f9002e96 	str	x22, [x20, #88]
    40203e14:	52800029 	mov	w9, #0x1                   	// #1
    40203e18:	39018288 	strb	w8, [x20, #96]
    40203e1c:	f940368a 	ldr	x10, [x20, #104]
    40203e20:	b100055f 	cmn	x10, #0x1
    40203e24:	54000240 	b.eq	40203e6c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3c4>  // b.none
    40203e28:	9100054a 	add	x10, x10, #0x1
    40203e2c:	f900368a 	str	x10, [x20, #104]
    40203e30:	a9422fea 	ldp	x10, x11, [sp, #32]
    40203e34:	a94337ec 	ldp	x12, x13, [sp, #48]
    40203e38:	a902326b 	stp	x11, x12, [x19, #32]
    40203e3c:	a94433eb 	ldp	x11, x12, [sp, #64]
    40203e40:	a9032e6d 	stp	x13, x11, [x19, #48]
    40203e44:	a9452fed 	ldp	x13, x11, [sp, #80]
    40203e48:	a904366c 	stp	x12, x13, [x19, #64]
    40203e4c:	a9005a69 	stp	x9, x22, [x19]
    40203e50:	7940f289 	ldrh	w9, [x20, #120]
    40203e54:	f9403a8c 	ldr	x12, [x20, #112]
    40203e58:	a9012a77 	stp	x23, x10, [x19, #16]
    40203e5c:	a905326b 	stp	x11, x12, [x19, #80]
    40203e60:	7900c269 	strh	w9, [x19, #96]
    40203e64:	39018a68 	strb	w8, [x19, #98]
    40203e68:	14000005 	b	40203e7c <_ZN11jnox_kernel16reservation_jobs4Jobs6decide17heff9b39ef4b14322E.llvm.17356852037749283236+0x3d4>
    40203e6c:	52800068 	mov	w8, #0x3                   	// #3
    40203e70:	39002268 	strb	w8, [x19, #8]
    40203e74:	52800048 	mov	w8, #0x2                   	// #2
    40203e78:	f9000268 	str	x8, [x19]
    40203e7c:	a9514ff4 	ldp	x20, x19, [sp, #272]
    40203e80:	a95057f6 	ldp	x22, x21, [sp, #256]
    40203e84:	a94f5ff8 	ldp	x24, x23, [sp, #240]
    40203e88:	a94e67fa 	ldp	x26, x25, [sp, #224]
    40203e8c:	a94d6ffc 	ldp	x28, x27, [sp, #208]
    40203e90:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    40203e94:	910483ff 	add	sp, sp, #0x120
    40203e98:	d65f03c0 	ret
    40203e9c:	d503201f 	nop
    40203ea0:	100106c2 	adr	x2, 40205f78 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x18>
    40203ea4:	aa1603e0 	mov	x0, x22
    40203ea8:	52800041 	mov	w1, #0x2                   	// #2
    40203eac:	94000388 	bl	40204ccc <core::panicking::panic_bounds_check>

0000000040203eb0 <jnox_kernel::reservation_jobs::Clock::new>:
    40203eb0:	b40005a1 	cbz	x1, 40203f64 <jnox_kernel::reservation_jobs::Clock::new+0xb4>
    40203eb4:	d343fc29 	lsr	x9, x1, #3
    40203eb8:	d29ef9ea 	mov	x10, #0xf7cf                	// #63439
    40203ebc:	f2bc6a6a 	movk	x10, #0xe353, lsl #16
    40203ec0:	f2d374aa 	movk	x10, #0x9ba5, lsl #32
    40203ec4:	f2e4188a 	movk	x10, #0x20c4, lsl #48
    40203ec8:	9bca7d29 	umulh	x9, x9, x10
    40203ecc:	d344fd29 	lsr	x9, x9, #4
    40203ed0:	52807d0a 	mov	w10, #0x3e8                 	// #1000
    40203ed4:	9b0a852a 	msub	x10, x9, x10, x1
    40203ed8:	b500046a 	cbnz	x10, 40203f64 <jnox_kernel::reservation_jobs::Clock::new+0xb4>
    40203edc:	b202e7ea 	mov	x10, #0xcccccccccccccccc    	// #-3689348814741910324
    40203ee0:	f29999aa 	movk	x10, #0xcccd
    40203ee4:	9bca7c2a 	umulh	x10, x1, x10
    40203ee8:	d344fd4a 	lsr	x10, x10, #4
    40203eec:	72001c5f 	tst	w2, #0xff
    40203ef0:	5280014b 	mov	w11, #0xa                   	// #10
    40203ef4:	5280050c 	mov	w12, #0x28                  	// #40
    40203ef8:	9a8b018b 	csel	x11, x12, x11, eq  // eq = none
    40203efc:	9bca7d6c 	umulh	x12, x11, x10
    40203f00:	eb0c03ff 	cmp	xzr, x12
    40203f04:	1a9f07ec 	cset	w12, ne  // ne = any
    40203f08:	9b0a7d6b 	mul	x11, x11, x10
    40203f0c:	ab0b001f 	cmn	x0, x11
    40203f10:	1a9f37eb 	cset	w11, cs  // cs = hs, nlast
    40203f14:	3700020c 	tbnz	w12, #0, 40203f54 <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f18:	350001eb 	cbnz	w11, 40203f54 <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f1c:	72001c5f 	tst	w2, #0xff
    40203f20:	5280014b 	mov	w11, #0xa                   	// #10
    40203f24:	5280044c 	mov	w12, #0x22                  	// #34
    40203f28:	9a8b018b 	csel	x11, x12, x11, eq  // eq = none
    40203f2c:	9bca7d6c 	umulh	x12, x11, x10
    40203f30:	eb0c03ff 	cmp	xzr, x12
    40203f34:	1a9f07ed 	cset	w13, ne  // ne = any
    40203f38:	9b0a7d6b 	mul	x11, x11, x10
    40203f3c:	ab00016b 	adds	x11, x11, x0
    40203f40:	1a9f37ec 	cset	w12, cs  // cs = hs, nlast
    40203f44:	3700008d 	tbnz	w13, #0, 40203f54 <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f48:	3500006c 	cbnz	w12, 40203f54 <jnox_kernel::reservation_jobs::Clock::new+0xa4>
    40203f4c:	ab09057f 	cmn	x11, x9, lsl #1
    40203f50:	54000123 	b.cc	40203f74 <jnox_kernel::reservation_jobs::Clock::new+0xc4>  // b.lo, b.ul, b.last
    40203f54:	52800069 	mov	w9, #0x3                   	// #3
    40203f58:	39000509 	strb	w9, [x8, #1]
    40203f5c:	5280002b 	mov	w11, #0x1                   	// #1
    40203f60:	14000003 	b	40203f6c <jnox_kernel::reservation_jobs::Clock::new+0xbc>
    40203f64:	5280002b 	mov	w11, #0x1                   	// #1
    40203f68:	3900050b 	strb	w11, [x8, #1]
    40203f6c:	3900010b 	strb	w11, [x8]
    40203f70:	d65f03c0 	ret
    40203f74:	2a1f03eb 	mov	w11, wzr
    40203f78:	a900a900 	stp	x0, x10, [x8, #8]
    40203f7c:	f9000d09 	str	x9, [x8, #24]
    40203f80:	17fffffb 	b	40203f6c <jnox_kernel::reservation_jobs::Clock::new+0xbc>

0000000040203f84 <__rustc::rust_begin_unwind>:
    40203f84:	d503205f 	wfe
    40203f88:	17ffffff 	b	40203f84 <__rustc::rust_begin_unwind>

0000000040203f8c <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold>:
    40203f8c:	d10103ff 	sub	sp, sp, #0x40
    40203f90:	f9001bfe 	str	x30, [sp, #48]
    40203f94:	a9412809 	ldp	x9, x10, [x0, #16]
    40203f98:	eb0a013f 	cmp	x9, x10
    40203f9c:	540004e2 	b.cs	40204038 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0xac>  // b.hs, b.nlast
    40203fa0:	f940100e 	ldr	x14, [x0, #32]
    40203fa4:	a940340b 	ldp	x11, x13, [x0]
    40203fa8:	910003ec 	mov	x12, sp
    40203fac:	9100618c 	add	x12, x12, #0x18
    40203fb0:	f100093f 	cmp	x9, #0x2
    40203fb4:	5280004f 	mov	w15, #0x2                   	// #2
    40203fb8:	9a8f8120 	csel	x0, x9, x15, hi  // hi = pmore
    40203fbc:	8b0911ad 	add	x13, x13, x9, lsl #4
    40203fc0:	8b0911ce 	add	x14, x14, x9, lsl #4
    40203fc4:	910021ce 	add	x14, x14, #0x8
    40203fc8:	eb09001f 	cmp	x0, x9
    40203fcc:	54000440 	b.eq	40204054 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0xc8>  // b.none
    40203fd0:	b869796f 	ldr	w15, [x11, x9, lsl #2]
    40203fd4:	3400028f 	cbz	w15, 40204024 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x98>
    40203fd8:	f94001af 	ldr	x15, [x13]
    40203fdc:	b400024f 	cbz	x15, 40204024 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x98>
    40203fe0:	f94001cf 	ldr	x15, [x14]
    40203fe4:	a9404430 	ldp	x16, x17, [x1]
    40203fe8:	a90047f0 	stp	x16, x17, [sp]
    40203fec:	f9400831 	ldr	x17, [x1, #16]
    40203ff0:	a9013ff1 	stp	x17, x15, [sp, #16]
    40203ff4:	eb0f021f 	cmp	x16, x15
    40203ff8:	a90227e9 	stp	x9, x9, [sp, #32]
    40203ffc:	54000061 	b.ne	40204008 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x7c>  // b.any
    40204000:	f94007ef 	ldr	x15, [sp, #8]
    40204004:	eb0901ff 	cmp	x15, x9
    40204008:	aa0c03ef 	mov	x15, x12
    4020400c:	54000048 	b.hi	40204014 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x88>  // b.pmore
    40204010:	910003ef 	mov	x15, sp
    40204014:	a94045f0 	ldp	x16, x17, [x15]
    40204018:	a9004430 	stp	x16, x17, [x1]
    4020401c:	f94009ef 	ldr	x15, [x15, #16]
    40204020:	f900082f 	str	x15, [x1, #16]
    40204024:	91000529 	add	x9, x9, #0x1
    40204028:	910041ad 	add	x13, x13, #0x10
    4020402c:	910041ce 	add	x14, x14, #0x10
    40204030:	eb09015f 	cmp	x10, x9
    40204034:	54fffca1 	b.ne	40203fc8 <<core::iter::adapters::map::Map<I,F> as core::iter::traits::iterator::Iterator>::fold+0x3c>  // b.any
    40204038:	a9402829 	ldp	x9, x10, [x1]
    4020403c:	a9002909 	stp	x9, x10, [x8]
    40204040:	f9400829 	ldr	x9, [x1, #16]
    40204044:	f9000909 	str	x9, [x8, #16]
    40204048:	f9401bfe 	ldr	x30, [sp, #48]
    4020404c:	910103ff 	add	sp, sp, #0x40
    40204050:	d65f03c0 	ret
    40204054:	d503201f 	nop
    40204058:	1000fe82 	adr	x2, 40206028 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.17586484101796375430>
    4020405c:	52800041 	mov	w1, #0x2                   	// #2
    40204060:	9400031b 	bl	40204ccc <core::panicking::panic_bounds_check>

0000000040204064 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut>:
    40204064:	d10083ff 	sub	sp, sp, #0x20
    40204068:	d503201f 	nop
    4020406c:	10ffa649 	adr	x9, 40203534 <reservation_worker_a>
    40204070:	d503201f 	nop
    40204074:	10ffa66a 	adr	x10, 40203540 <reservation_worker_b>
    40204078:	f90003e9 	str	x9, [sp]
    4020407c:	a900fbea 	stp	x10, x30, [sp, #8]
    40204080:	f100043f 	cmp	x1, #0x1
    40204084:	54000928 	b.hi	402041a8 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x144>  // b.pmore
    40204088:	d503201f 	nop
    4020408c:	1009b4a9 	adr	x9, 40217720 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328>
    40204090:	8b013929 	add	x9, x9, x1, lsl #14
    40204094:	5287980a 	mov	w10, #0x3cc0                	// #15552
    40204098:	8b0a0129 	add	x9, x9, x10
    4020409c:	f940000a 	ldr	x10, [x0]
    402040a0:	8b010d4b 	add	x11, x10, x1, lsl #3
    402040a4:	f940b56d 	ldr	x13, [x11, #360]
    402040a8:	eb0d013f 	cmp	x9, x13
    402040ac:	540007c1 	b.ne	402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    402040b0:	910003ea 	mov	x10, sp
    402040b4:	f861794a 	ldr	x10, [x10, x1, lsl #3]
    402040b8:	f9407dac 	ldr	x12, [x13, #248]
    402040bc:	eb0a019f 	cmp	x12, x10
    402040c0:	54000721 	b.ne	402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    402040c4:	f94081ac 	ldr	x12, [x13, #256]
    402040c8:	f10d159f 	cmp	x12, #0x345
    402040cc:	540006c1 	b.ne	402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    402040d0:	f9404dac 	ldr	x12, [x13, #152]
    402040d4:	b500068c 	cbnz	x12, 402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    402040d8:	d503201f 	nop
    402040dc:	1000eaac 	adr	x12, 40205e30 <anon.f4139c418240cf1e99d30121eb57c0ff.1.llvm.12015700318350904328>
    402040e0:	f861798c 	ldr	x12, [x12, x1, lsl #3]
    402040e4:	f9408dad 	ldr	x13, [x13, #280]
    402040e8:	eb0c01bf 	cmp	x13, x12
    402040ec:	540005c1 	b.ne	402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    402040f0:	d503201f 	nop
    402040f4:	1001afad 	adr	x13, 402076e8 <jnox_kernel::ordinary_reservations::GENERATION>
    402040f8:	8b010dad 	add	x13, x13, x1, lsl #3
    402040fc:	c8dffdad 	ldar	x13, [x13]
    40204100:	b10005bf 	cmn	x13, #0x1
    40204104:	54000501 	b.ne	402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    40204108:	d503201f 	nop
    4020410c:	100fe72d 	adr	x13, 40223df0 <jnox_kernel::ordinary_reservations::ACTION>
    40204110:	8b010dad 	add	x13, x13, x1, lsl #3
    40204114:	c8dffdad 	ldar	x13, [x13]
    40204118:	b500046d 	cbnz	x13, 402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    4020411c:	d503201f 	nop
    40204120:	1001aecd 	adr	x13, 402076f8 <jnox_kernel::ordinary_reservations::GOAL>
    40204124:	8b010dad 	add	x13, x13, x1, lsl #3
    40204128:	c8dffdad 	ldar	x13, [x13]
    4020412c:	b10005bf 	cmn	x13, #0x1
    40204130:	540003a1 	b.ne	402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    40204134:	d503201f 	nop
    40204138:	100fe64d 	adr	x13, 40223e00 <jnox_kernel::ordinary_reservations::FIRST>
    4020413c:	8b010dad 	add	x13, x13, x1, lsl #3
    40204140:	c8dffdad 	ldar	x13, [x13]
    40204144:	b500030d 	cbnz	x13, 402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    40204148:	d503201f 	nop
    4020414c:	100fe62d 	adr	x13, 40223e10 <jnox_kernel::ordinary_reservations::POINTER>
    40204150:	8b010dad 	add	x13, x13, x1, lsl #3
    40204154:	c8dffdad 	ldar	x13, [x13]
    40204158:	b500026d 	cbnz	x13, 402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    4020415c:	f940e16d 	ldr	x13, [x11, #448]
    40204160:	b500022d 	cbnz	x13, 402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    40204164:	f940e96d 	ldr	x13, [x11, #464]
    40204168:	eb0c01bf 	cmp	x13, x12
    4020416c:	540001c1 	b.ne	402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    40204170:	f940c96d 	ldr	x13, [x11, #400]
    40204174:	b10005bf 	cmn	x13, #0x1
    40204178:	54000161 	b.ne	402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>  // b.any
    4020417c:	f940d16b 	ldr	x11, [x11, #416]
    40204180:	b500012b 	cbnz	x11, 402041a4 <<core::ops::try_trait::Wrapped<T,A,F> as core::ops::function::FnMut<(A,)>>::call_mut+0x140>
    40204184:	a9002909 	stp	x9, x10, [x8]
    40204188:	528068a9 	mov	w9, #0x345                 	// #837
    4020418c:	a9017d09 	stp	x9, xzr, [x8, #16]
    40204190:	a9027d0c 	stp	x12, xzr, [x8, #32]
    40204194:	f900190c 	str	x12, [x8, #48]
    40204198:	f9400bfe 	ldr	x30, [sp, #16]
    4020419c:	910083ff 	add	sp, sp, #0x20
    402041a0:	d65f03c0 	ret
    402041a4:	97fff441 	bl	402012a8 <jnox_kernel::ordinary_reservations::unexpected>
    402041a8:	d503201f 	nop
    402041ac:	1000f4a2 	adr	x2, 40206040 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.17586484101796375430+0x18>
    402041b0:	aa0103e0 	mov	x0, x1
    402041b4:	52800041 	mov	w1, #0x2                   	// #2
    402041b8:	940002c5 	bl	40204ccc <core::panicking::panic_bounds_check>

00000000402041bc <jnox_kernel::uart_write>:
    402041bc:	b40001a1 	cbz	x1, 402041f0 <jnox_kernel::uart_write+0x34>
    402041c0:	8b010008 	add	x8, x0, x1
    402041c4:	52800309 	mov	w9, #0x18                  	// #24
    402041c8:	72a12009 	movk	w9, #0x900, lsl #16
    402041cc:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    402041d0:	3840140b 	ldrb	w11, [x0], #1
    402041d4:	b940012c 	ldr	w12, [x9]
    402041d8:	3628006c 	tbz	w12, #5, 402041e4 <jnox_kernel::uart_write+0x28>
    402041dc:	d5033fdf 	isb
    402041e0:	17fffffd 	b	402041d4 <jnox_kernel::uart_write+0x18>
    402041e4:	b900014b 	str	w11, [x10]
    402041e8:	eb08001f 	cmp	x0, x8
    402041ec:	54ffff21 	b.ne	402041d0 <jnox_kernel::uart_write+0x14>  // b.any
    402041f0:	d65f03c0 	ret

00000000402041f4 <jnox_kernel::kernel_main>:
    402041f4:	f00000e8 	adrp	x8, 40223000 <_ZN11jnox_kernel21ordinary_reservations6STACKS17h49f8dec9f92853efE.llvm.12015700318350904328+0xb8e0>
    402041f8:	f9471108 	ldr	x8, [x8, #3616]
    402041fc:	b4000068 	cbz	x8, 40204208 <jnox_kernel::kernel_main+0x14>
    40204200:	d503205f 	wfe
    40204204:	17ffffff 	b	40204200 <jnox_kernel::kernel_main+0xc>
    40204208:	f81f0ffe 	str	x30, [sp, #-16]!
    4020420c:	52800608 	mov	w8, #0x30                  	// #48
    40204210:	72a12008 	movk	w8, #0x900, lsl #16
    40204214:	b900011f 	str	wzr, [x8]
    40204218:	528001a9 	mov	w9, #0xd                   	// #13
    4020421c:	5280002a 	mov	w10, #0x1                   	// #1
    40204220:	b81f4109 	stur	w9, [x8, #-12]
    40204224:	b81f810a 	stur	w10, [x8, #-8]
    40204228:	52800c09 	mov	w9, #0x60                  	// #96
    4020422c:	b81fc109 	stur	w9, [x8, #-4]
    40204230:	52802029 	mov	w9, #0x101                 	// #257
    40204234:	b9000109 	str	w9, [x8]
    40204238:	d503201f 	nop
    4020423c:	1000eb60 	adr	x0, 40205fa8 <anon.ea87e2b2cc9f7d58a9d94b6887b82322.1.llvm.17356852037749283236+0x48>
    40204240:	52800361 	mov	w1, #0x1b                  	// #27
    40204244:	97ffffde 	bl	402041bc <jnox_kernel::uart_write>
    40204248:	97fff6fa 	bl	40201e30 <jnox_kernel::ordinary_reservations::run>

000000004020424c <jnox_kernel::service_policy::PeriodicReservation::allocation_at>:
    4020424c:	f9400809 	ldr	x9, [x0, #16]
    40204250:	eb09002a 	subs	x10, x1, x9
    40204254:	54000062 	b.cs	40204260 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x14>  // b.hs, b.nlast
    40204258:	aa1f03ea 	mov	x10, xzr
    4020425c:	1400000f 	b	40204298 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x4c>
    40204260:	f940040b 	ldr	x11, [x0, #8]
    40204264:	b400022b 	cbz	x11, 402042a8 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x5c>
    40204268:	9acb0949 	udiv	x9, x10, x11
    4020426c:	cb0a03ec 	neg	x12, x10
    40204270:	9b0b3129 	madd	x9, x9, x11, x12
    40204274:	8b090029 	add	x9, x1, x9
    40204278:	ab0b0129 	adds	x9, x9, x11
    4020427c:	54000063 	b.cc	40204288 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x3c>  // b.lo, b.ul, b.last
    40204280:	aa1f03eb 	mov	x11, xzr
    40204284:	14000007 	b	402042a0 <jnox_kernel::service_policy::PeriodicReservation::allocation_at+0x54>
    40204288:	eb0b015f 	cmp	x10, x11
    4020428c:	5280030a 	mov	w10, #0x18                  	// #24
    40204290:	9a9f314a 	csel	x10, x10, xzr, cc  // cc = lo, ul, last
    40204294:	f86a680a 	ldr	x10, [x0, x10]
    40204298:	5280002b 	mov	w11, #0x1                   	// #1
    4020429c:	a900a50a 	stp	x10, x9, [x8, #8]
    402042a0:	f900010b 	str	x11, [x8]
    402042a4:	d65f03c0 	ret
    402042a8:	f81f0ffe 	str	x30, [sp, #-16]!
    402042ac:	d503201f 	nop
    402042b0:	1000e8c0 	adr	x0, 40205fc8 <anon.2d5d436b87d2a0d6f444a14986a49844.2.llvm.17586484101796375430>
    402042b4:	9400048c 	bl	402054e4 <core::panicking::panic_const::panic_const_rem_by_zero>

00000000402042b8 <jnox_kernel::service_policy::PeriodicReservation::grant_at>:
    402042b8:	f9401008 	ldr	x8, [x0, #32]
    402042bc:	eb08003f 	cmp	x1, x8
    402042c0:	54000062 	b.cs	402042cc <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x14>  // b.hs, b.nlast
    402042c4:	aa1f03e0 	mov	x0, xzr
    402042c8:	1400001c 	b	40204338 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x80>
    402042cc:	f9400408 	ldr	x8, [x0, #8]
    402042d0:	b4000388 	cbz	x8, 40204340 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x88>
    402042d4:	f9400809 	ldr	x9, [x0, #16]
    402042d8:	cb09002a 	sub	x10, x1, x9
    402042dc:	9ac80949 	udiv	x9, x10, x8
    402042e0:	9b08a929 	msub	x9, x9, x8, x10
    402042e4:	eb08015f 	cmp	x10, x8
    402042e8:	54000062 	b.cs	402042f4 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x3c>  // b.hs, b.nlast
    402042ec:	9100600a 	add	x10, x0, #0x18
    402042f0:	14000004 	b	40204300 <jnox_kernel::service_policy::PeriodicReservation::grant_at+0x48>
    402042f4:	cb09002a 	sub	x10, x1, x9
    402042f8:	f900080a 	str	x10, [x0, #16]
    402042fc:	aa0003ea 	mov	x10, x0
    40204300:	f940014a 	ldr	x10, [x10]
    40204304:	eb02015f 	cmp	x10, x2
    40204308:	9a82314b 	csel	x11, x10, x2, cc  // cc = lo, ul, last
    4020430c:	cb090108 	sub	x8, x8, x9
    40204310:	eb0b011f 	cmp	x8, x11
    40204314:	9a8b3109 	csel	x9, x8, x11, cc  // cc = lo, ul, last
    40204318:	aa2103e8 	mvn	x8, x1
    4020431c:	eb09011f 	cmp	x8, x9
    40204320:	da812128 	csinv	x8, x9, x1, cs  // cs = hs, nlast
    40204324:	cb08014a 	sub	x10, x10, x8
    40204328:	ab010129 	adds	x9, x9, x1
    4020432c:	da9f3129 	csinv	x9, x9, xzr, cc  // cc = lo, ul, last
    40204330:	a901a40a 	stp	x10, x9, [x0, #24]
    40204334:	52800020 	mov	w0, #0x1                   	// #1
    40204338:	aa0803e1 	mov	x1, x8
    4020433c:	d65f03c0 	ret
    40204340:	f81f0ffe 	str	x30, [sp, #-16]!
    40204344:	d503201f 	nop
    40204348:	1000e4c0 	adr	x0, 40205fe0 <anon.2d5d436b87d2a0d6f444a14986a49844.3.llvm.17586484101796375430>
    4020434c:	94000466 	bl	402054e4 <core::panicking::panic_const::panic_const_rem_by_zero>

0000000040204350 <jnox_kernel::temporal_policy::HardCbs<_>::new>:
    40204350:	d10143ff 	sub	sp, sp, #0x50
    40204354:	a90357fe 	stp	x30, x21, [sp, #48]
    40204358:	a9044ff4 	stp	x20, x19, [sp, #64]
    4020435c:	aa0103f5 	mov	x21, x1
    40204360:	aa0003f4 	mov	x20, x0
    40204364:	aa0803f3 	mov	x19, x8
    40204368:	aa0103e0 	mov	x0, x1
    4020436c:	52800041 	mov	w1, #0x2                   	// #2
    40204370:	940000c6 	bl	40204688 <jnox_kernel::temporal_policy::admit_reservations>
    40204374:	12001c08 	and	w8, w0, #0xff
    40204378:	71000d1f 	cmp	w8, #0x3
    4020437c:	54000261 	b.ne	402043c8 <jnox_kernel::temporal_policy::HardCbs<_>::new+0x78>  // b.any
    40204380:	910003e9 	mov	x9, sp
    40204384:	91006128 	add	x8, x9, #0x18
    40204388:	5280002a 	mov	w10, #0x1                   	// #1
    4020438c:	f9000134 	str	x20, [x9]
    40204390:	28c132ab 	ldp	w11, w12, [x21], #8
    40204394:	2a0a03ed 	mov	w13, w10
    40204398:	2901312b 	stp	w11, w12, [x9, #8]
    4020439c:	f900093f 	str	xzr, [x9, #16]
    402043a0:	aa0803e9 	mov	x9, x8
    402043a4:	2a1f03ea 	mov	w10, wzr
    402043a8:	3707ff2d 	tbnz	w13, #0, 4020438c <jnox_kernel::temporal_policy::HardCbs<_>::new+0x3c>
    402043ac:	91002260 	add	x0, x19, #0x8
    402043b0:	910003e1 	mov	x1, sp
    402043b4:	52800602 	mov	w2, #0x30                  	// #48
    402043b8:	94000595 	bl	40205a0c <memcpy>
    402043bc:	f9001e74 	str	x20, [x19, #56]
    402043c0:	52800028 	mov	w8, #0x1                   	// #1
    402043c4:	14000002 	b	402043cc <jnox_kernel::temporal_policy::HardCbs<_>::new+0x7c>
    402043c8:	aa1f03e8 	mov	x8, xzr
    402043cc:	f9000268 	str	x8, [x19]
    402043d0:	a9444ff4 	ldp	x20, x19, [sp, #64]
    402043d4:	a94357fe 	ldp	x30, x21, [sp, #48]
    402043d8:	910143ff 	add	sp, sp, #0x50
    402043dc:	d65f03c0 	ret

00000000402043e0 <jnox_kernel::temporal_policy::HardCbs<_>::tick>:
    402043e0:	d10203ff 	sub	sp, sp, #0x80
    402043e4:	a9027bfd 	stp	x29, x30, [sp, #32]
    402043e8:	a9036ffc 	stp	x28, x27, [sp, #48]
    402043ec:	a90467fa 	stp	x26, x25, [sp, #64]
    402043f0:	a9055ff8 	stp	x24, x23, [sp, #80]
    402043f4:	a90657f6 	stp	x22, x21, [sp, #96]
    402043f8:	a9074ff4 	stp	x20, x19, [sp, #112]
    402043fc:	aa0803f3 	mov	x19, x8
    40204400:	f940181b 	ldr	x27, [x0, #48]
    40204404:	b100077a 	adds	x26, x27, #0x1
    40204408:	540000a3 	b.cc	4020441c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x3c>  // b.lo, b.ul, b.last
    4020440c:	aa1f03f4 	mov	x20, xzr
    40204410:	52800037 	mov	w23, #0x1                   	// #1
    40204414:	52800089 	mov	w9, #0x4                   	// #4
    40204418:	1400003e 	b	40204510 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    4020441c:	aa0003f5 	mov	x21, x0
    40204420:	2a1f03fc 	mov	w28, wzr
    40204424:	aa1f03e8 	mov	x8, xzr
    40204428:	aa1f03fd 	mov	x29, xzr
    4020442c:	91005018 	add	x24, x0, #0x14
    40204430:	52800037 	mov	w23, #0x1                   	// #1
    40204434:	910063bd 	add	x29, x29, #0x18
    40204438:	aa0803f6 	mov	x22, x8
    4020443c:	8b1d0308 	add	x8, x24, x29
    40204440:	b85e8108 	ldur	w8, [x8, #-24]
    40204444:	340000e8 	cbz	w8, 40204460 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x80>
    40204448:	910023e8 	add	x8, sp, #0x8
    4020444c:	aa1503e0 	mov	x0, x21
    40204450:	aa1603e1 	mov	x1, x22
    40204454:	94000067 	bl	402045f0 <jnox_kernel::temporal_policy::HardCbs<_>::available>
    40204458:	f94007e8 	ldr	x8, [sp, #8]
    4020445c:	b50000c8 	cbnz	x8, 40204474 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x94>
    40204460:	910063bd 	add	x29, x29, #0x18
    40204464:	910006d6 	add	x22, x22, #0x1
    40204468:	f10123bf 	cmp	x29, #0x48
    4020446c:	54fffe81 	b.ne	4020443c <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x5c>  // b.any
    40204470:	14000014 	b	402044c0 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0xe0>
    40204474:	f100091f 	cmp	x8, #0x2
    40204478:	a9412be9 	ldp	x9, x10, [sp, #16]
    4020447c:	54000400 	b.eq	402044fc <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x11c>  // b.none
    40204480:	eb1b015f 	cmp	x10, x27
    40204484:	540005a9 	b.ls	40204538 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x158>  // b.plast
    40204488:	910006c8 	add	x8, x22, #0x1
    4020448c:	eb19015f 	cmp	x10, x25
    40204490:	1a9f37eb 	cset	w11, cs  // cs = hs, nlast
    40204494:	6a0b039f 	tst	w28, w11
    40204498:	9a961294 	csel	x20, x20, x22, ne  // ne = any
    4020449c:	9a8a1339 	csel	x25, x25, x10, ne  // ne = any
    402044a0:	b94007ea 	ldr	w10, [sp, #4]
    402044a4:	1a89114a 	csel	w10, w10, w9, ne  // ne = any
    402044a8:	b90007ea 	str	w10, [sp, #4]
    402044ac:	5280003c 	mov	w28, #0x1                   	// #1
    402044b0:	f100c3bf 	cmp	x29, #0x30
    402044b4:	54fffc01 	b.ne	40204434 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x54>  // b.any
    402044b8:	f9001aba 	str	x26, [x21, #48]
    402044bc:	14000003 	b	402044c8 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0xe8>
    402044c0:	f9001aba 	str	x26, [x21, #48]
    402044c4:	3600023c 	tbz	w28, #0, 40204508 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x128>
    402044c8:	f1000a9f 	cmp	x20, #0x2
    402044cc:	540003c2 	b.cs	40204544 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x164>  // b.hs, b.nlast
    402044d0:	aa1f03f7 	mov	x23, xzr
    402044d4:	52800308 	mov	w8, #0x18                  	// #24
    402044d8:	9b085688 	madd	x8, x20, x8, x21
    402044dc:	f9000119 	str	x25, [x8]
    402044e0:	b94007e9 	ldr	w9, [sp, #4]
    402044e4:	51000529 	sub	w9, w9, #0x1
    402044e8:	b940150a 	ldr	w10, [x8, #20]
    402044ec:	5100054a 	sub	w10, w10, #0x1
    402044f0:	29022909 	stp	w9, w10, [x8, #16]
    402044f4:	52800029 	mov	w9, #0x1                   	// #1
    402044f8:	14000006 	b	40204510 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    402044fc:	52800037 	mov	w23, #0x1                   	// #1
    40204500:	aa0a03f4 	mov	x20, x10
    40204504:	14000003 	b	40204510 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    40204508:	aa1f03e9 	mov	x9, xzr
    4020450c:	aa1f03f7 	mov	x23, xzr
    40204510:	a900d269 	stp	x9, x20, [x19, #8]
    40204514:	f9000277 	str	x23, [x19]
    40204518:	a9474ff4 	ldp	x20, x19, [sp, #112]
    4020451c:	a94657f6 	ldp	x22, x21, [sp, #96]
    40204520:	a9455ff8 	ldp	x24, x23, [sp, #80]
    40204524:	a94467fa 	ldp	x26, x25, [sp, #64]
    40204528:	a9436ffc 	ldp	x28, x27, [sp, #48]
    4020452c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40204530:	910203ff 	add	sp, sp, #0x80
    40204534:	d65f03c0 	ret
    40204538:	52800069 	mov	w9, #0x3                   	// #3
    4020453c:	aa1603f4 	mov	x20, x22
    40204540:	17fffff4 	b	40204510 <jnox_kernel::temporal_policy::HardCbs<_>::tick+0x130>
    40204544:	d503201f 	nop
    40204548:	1000d582 	adr	x2, 40205ff8 <anon.2d5d436b87d2a0d6f444a14986a49844.5.llvm.17586484101796375430>
    4020454c:	aa1403e0 	mov	x0, x20
    40204550:	52800041 	mov	w1, #0x2                   	// #2
    40204554:	940001de 	bl	40204ccc <core::panicking::panic_bounds_check>

0000000040204558 <jnox_kernel::temporal_policy::HardCbs<_>::release>:
    40204558:	f100043f 	cmp	x1, #0x1
    4020455c:	54000089 	b.ls	4020456c <jnox_kernel::temporal_policy::HardCbs<_>::release+0x14>  // b.plast
    40204560:	aa1f03e1 	mov	x1, xzr
    40204564:	aa1f03e0 	mov	x0, xzr
    40204568:	d65f03c0 	ret
    4020456c:	340000e2 	cbz	w2, 40204588 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x30>
    40204570:	52800308 	mov	w8, #0x18                  	// #24
    40204574:	9b080028 	madd	x8, x1, x8, x0
    40204578:	b9401509 	ldr	w9, [x8, #20]
    4020457c:	340000a9 	cbz	w9, 40204590 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x38>
    40204580:	52800040 	mov	w0, #0x2                   	// #2
    40204584:	d65f03c0 	ret
    40204588:	52800020 	mov	w0, #0x1                   	// #1
    4020458c:	d65f03c0 	ret
    40204590:	f940010a 	ldr	x10, [x8]
    40204594:	f9401809 	ldr	x9, [x0, #48]
    40204598:	eb09014b 	subs	x11, x10, x9
    4020459c:	54000149 	b.ls	402045c4 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x6c>  // b.plast
    402045a0:	2941b10a 	ldp	w10, w12, [x8, #12]
    402045a4:	b940090d 	ldr	w13, [x8, #8]
    402045a8:	9bac7d4c 	umull	x12, w10, w12
    402045ac:	9bcb7dae 	umulh	x14, x13, x11
    402045b0:	9b0b7dab 	mul	x11, x13, x11
    402045b4:	eb0c017f 	cmp	x11, x12
    402045b8:	fa1f01df 	sbcs	xzr, x14, xzr
    402045bc:	54000063 	b.cc	402045c8 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x70>  // b.lo, b.ul, b.last
    402045c0:	14000009 	b	402045e4 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x8c>
    402045c4:	b9400d0a 	ldr	w10, [x8, #12]
    402045c8:	ab2a4121 	adds	x1, x9, w10, uxtw
    402045cc:	54000063 	b.cc	402045d8 <jnox_kernel::temporal_policy::HardCbs<_>::release+0x80>  // b.lo, b.ul, b.last
    402045d0:	52800080 	mov	w0, #0x4                   	// #4
    402045d4:	d65f03c0 	ret
    402045d8:	f9000101 	str	x1, [x8]
    402045dc:	b9400909 	ldr	w9, [x8, #8]
    402045e0:	b9001109 	str	w9, [x8, #16]
    402045e4:	b9001502 	str	w2, [x8, #20]
    402045e8:	528000a0 	mov	w0, #0x5                   	// #5
    402045ec:	d65f03c0 	ret

00000000402045f0 <jnox_kernel::temporal_policy::HardCbs<_>::available>:
    402045f0:	f100083f 	cmp	x1, #0x2
    402045f4:	540000a3 	b.cc	40204608 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x18>  // b.lo, b.ul, b.last
    402045f8:	a900fd1f 	stp	xzr, xzr, [x8, #8]
    402045fc:	52800049 	mov	w9, #0x2                   	// #2
    40204600:	f9000109 	str	x9, [x8]
    40204604:	d65f03c0 	ret
    40204608:	52800309 	mov	w9, #0x18                  	// #24
    4020460c:	9b090029 	madd	x9, x1, x9, x0
    40204610:	b940152a 	ldr	w10, [x9, #20]
    40204614:	340001aa 	cbz	w10, 40204648 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x58>
    40204618:	b940112a 	ldr	w10, [x9, #16]
    4020461c:	340000ea 	cbz	w10, 40204638 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x48>
    40204620:	5280002b 	mov	w11, #0x1                   	// #1
    40204624:	f900010b 	str	x11, [x8]
    40204628:	f9400129 	ldr	x9, [x9]
    4020462c:	b900090a 	str	w10, [x8, #8]
    40204630:	f9000909 	str	x9, [x8, #16]
    40204634:	d65f03c0 	ret
    40204638:	f940180b 	ldr	x11, [x0, #48]
    4020463c:	f940012a 	ldr	x10, [x9]
    40204640:	eb0a017f 	cmp	x11, x10
    40204644:	54000062 	b.cs	40204650 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x60>  // b.hs, b.nlast
    40204648:	f900011f 	str	xzr, [x8]
    4020464c:	d65f03c0 	ret
    40204650:	b9400d2b 	ldr	w11, [x9, #12]
    40204654:	ab0b014a 	adds	x10, x10, x11
    40204658:	540000c3 	b.cc	40204670 <jnox_kernel::temporal_policy::HardCbs<_>::available+0x80>  // b.lo, b.ul, b.last
    4020465c:	52800089 	mov	w9, #0x4                   	// #4
    40204660:	a900a909 	stp	x9, x10, [x8, #8]
    40204664:	5280004a 	mov	w10, #0x2                   	// #2
    40204668:	f900010a 	str	x10, [x8]
    4020466c:	d65f03c0 	ret
    40204670:	5280002b 	mov	w11, #0x1                   	// #1
    40204674:	f900010b 	str	x11, [x8]
    40204678:	b9400929 	ldr	w9, [x9, #8]
    4020467c:	b9000909 	str	w9, [x8, #8]
    40204680:	f900090a 	str	x10, [x8, #16]
    40204684:	d65f03c0 	ret

0000000040204688 <jnox_kernel::temporal_policy::admit_reservations>:
    40204688:	f81b0ffe 	str	x30, [sp, #-80]!
    4020468c:	a90167fa 	stp	x26, x25, [sp, #16]
    40204690:	a9025ff8 	stp	x24, x23, [sp, #32]
    40204694:	a90357f6 	stp	x22, x21, [sp, #48]
    40204698:	a9044ff4 	stp	x20, x19, [sp, #64]
    4020469c:	b4000721 	cbz	x1, 40204780 <jnox_kernel::temporal_policy::admit_reservations+0xf8>
    402046a0:	aa0003f3 	mov	x19, x0
    402046a4:	aa1f03f6 	mov	x22, xzr
    402046a8:	8b010c1a 	add	x26, x0, x1, lsl #3
    402046ac:	52800020 	mov	w0, #0x1                   	// #1
    402046b0:	29402269 	ldp	w9, w8, [x19]
    402046b4:	5100052a 	sub	w10, w9, #0x1
    402046b8:	6b08015f 	cmp	w10, w8
    402046bc:	540006a2 	b.cs	40204790 <jnox_kernel::temporal_policy::admit_reservations+0x108>  // b.hs, b.nlast
    402046c0:	9bd67d0a 	umulh	x10, x8, x22
    402046c4:	9b167d0b 	mul	x11, x8, x22
    402046c8:	9bc07d2c 	umulh	x12, x9, x0
    402046cc:	9b007d29 	mul	x9, x9, x0
    402046d0:	ab090176 	adds	x22, x11, x9
    402046d4:	9a0c0157 	adc	x23, x10, x12
    402046d8:	9bc07d14 	umulh	x20, x8, x0
    402046dc:	9b007d15 	mul	x21, x8, x0
    402046e0:	eb1602bf 	cmp	x21, x22
    402046e4:	fa17029f 	sbcs	xzr, x20, x23
    402046e8:	54000583 	b.cc	40204798 <jnox_kernel::temporal_policy::admit_reservations+0x110>  // b.lo, b.ul, b.last
    402046ec:	b4000220 	cbz	x0, 40204730 <jnox_kernel::temporal_policy::admit_reservations+0xa8>
    402046f0:	aa1603e0 	mov	x0, x22
    402046f4:	aa1703e1 	mov	x1, x23
    402046f8:	aa1503e8 	mov	x8, x21
    402046fc:	aa1403e9 	mov	x9, x20
    40204700:	aa0903f8 	mov	x24, x9
    40204704:	aa0803f9 	mov	x25, x8
    40204708:	aa0803e2 	mov	x2, x8
    4020470c:	aa0903e3 	mov	x3, x9
    40204710:	94000542 	bl	40205c18 <__umodti3>
    40204714:	aa0003e8 	mov	x8, x0
    40204718:	aa0103e9 	mov	x9, x1
    4020471c:	aa01000a 	orr	x10, x0, x1
    40204720:	aa1903e0 	mov	x0, x25
    40204724:	aa1803e1 	mov	x1, x24
    40204728:	b5fffeca 	cbnz	x10, 40204700 <jnox_kernel::temporal_policy::admit_reservations+0x78>
    4020472c:	14000005 	b	40204740 <jnox_kernel::temporal_policy::admit_reservations+0xb8>
    40204730:	aa1702c8 	orr	x8, x22, x23
    40204734:	aa1603f9 	mov	x25, x22
    40204738:	aa1703f8 	mov	x24, x23
    4020473c:	b40003c8 	cbz	x8, 402047b4 <jnox_kernel::temporal_policy::admit_reservations+0x12c>
    40204740:	aa1603e0 	mov	x0, x22
    40204744:	aa1703e1 	mov	x1, x23
    40204748:	aa1903e2 	mov	x2, x25
    4020474c:	aa1803e3 	mov	x3, x24
    40204750:	940003e3 	bl	402056dc <__udivti3>
    40204754:	b50001a1 	cbnz	x1, 40204788 <jnox_kernel::temporal_policy::admit_reservations+0x100>
    40204758:	aa0003f6 	mov	x22, x0
    4020475c:	aa1503e0 	mov	x0, x21
    40204760:	aa1403e1 	mov	x1, x20
    40204764:	aa1903e2 	mov	x2, x25
    40204768:	aa1803e3 	mov	x3, x24
    4020476c:	940003dc 	bl	402056dc <__udivti3>
    40204770:	b50000c1 	cbnz	x1, 40204788 <jnox_kernel::temporal_policy::admit_reservations+0x100>
    40204774:	91002273 	add	x19, x19, #0x8
    40204778:	eb1a027f 	cmp	x19, x26
    4020477c:	54fff9a1 	b.ne	402046b0 <jnox_kernel::temporal_policy::admit_reservations+0x28>  // b.any
    40204780:	52800060 	mov	w0, #0x3                   	// #3
    40204784:	14000006 	b	4020479c <jnox_kernel::temporal_policy::admit_reservations+0x114>
    40204788:	52800040 	mov	w0, #0x2                   	// #2
    4020478c:	14000004 	b	4020479c <jnox_kernel::temporal_policy::admit_reservations+0x114>
    40204790:	2a1f03e0 	mov	w0, wzr
    40204794:	14000002 	b	4020479c <jnox_kernel::temporal_policy::admit_reservations+0x114>
    40204798:	52800020 	mov	w0, #0x1                   	// #1
    4020479c:	a9444ff4 	ldp	x20, x19, [sp, #64]
    402047a0:	a94357f6 	ldp	x22, x21, [sp, #48]
    402047a4:	a9425ff8 	ldp	x24, x23, [sp, #32]
    402047a8:	a94167fa 	ldp	x26, x25, [sp, #16]
    402047ac:	f84507fe 	ldr	x30, [sp], #80
    402047b0:	d65f03c0 	ret
    402047b4:	d503201f 	nop
    402047b8:	1000c2c0 	adr	x0, 40206010 <anon.2d5d436b87d2a0d6f444a14986a49844.6.llvm.17586484101796375430>
    402047bc:	94000343 	bl	402054c8 <core::panicking::panic_const::panic_const_div_by_zero>

00000000402047c0 <jnox_kernel::context::init_timer_irq>:
    402047c0:	d503201f 	nop
    402047c4:	10fe01e8 	adr	x8, 40200800 <sched_vectors>
    402047c8:	d518c008 	msr	vbar_el1, x8
    402047cc:	d51be23f 	msr	cntp_ctl_el0, xzr
    402047d0:	d5033fdf 	isb
    402047d4:	52a10008 	mov	w8, #0x8000000             	// #134217728
    402047d8:	b900011f 	str	wzr, [x8]
    402047dc:	52a10029 	mov	w9, #0x8010000             	// #134283264
    402047e0:	b900013f 	str	wzr, [x9]
    402047e4:	5280100a 	mov	w10, #0x80                  	// #128
    402047e8:	72a1000a 	movk	w10, #0x800, lsl #16
    402047ec:	b940014b 	ldr	w11, [x10]
    402047f0:	1201796b 	and	w11, w11, #0xbfffffff
    402047f4:	b900014b 	str	w11, [x10]
    402047f8:	5280100b 	mov	w11, #0x80                  	// #128
    402047fc:	390e794b 	strb	w11, [x10, #926]
    40204800:	52a8000b 	mov	w11, #0x40000000            	// #1073741824
    40204804:	b902014b 	str	w11, [x10, #512]
    40204808:	b900814b 	str	w11, [x10, #128]
    4020480c:	5280008a 	mov	w10, #0x4                   	// #4
    40204810:	72a1002a 	movk	w10, #0x801, lsl #16
    40204814:	52801feb 	mov	w11, #0xff                  	// #255
    40204818:	b900014b 	str	w11, [x10]
    4020481c:	5280002a 	mov	w10, #0x1                   	// #1
    40204820:	b900010a 	str	w10, [x8]
    40204824:	b900012a 	str	w10, [x9]
    40204828:	d5033f9f 	dsb	sy
    4020482c:	d5033fdf 	isb
    40204830:	d65f03c0 	ret

0000000040204834 <<core::fmt::Formatter>::pad_integral>:
    40204834:	d101c3ff 	sub	sp, sp, #0x70
    40204838:	a9017bfd 	stp	x29, x30, [sp, #16]
    4020483c:	a9026ffc 	stp	x28, x27, [sp, #32]
    40204840:	a90367fa 	stp	x26, x25, [sp, #48]
    40204844:	a9045ff8 	stp	x24, x23, [sp, #64]
    40204848:	a90557f6 	stp	x22, x21, [sp, #80]
    4020484c:	a9064ff4 	stp	x20, x19, [sp, #96]
    40204850:	910043fd 	add	x29, sp, #0x10
    40204854:	b940101a 	ldr	w26, [x0, #16]
    40204858:	52a00229 	mov	w9, #0x110000              	// #1114112
    4020485c:	aa0503f3 	mov	x19, x5
    40204860:	aa0403fc 	mov	x28, x4
    40204864:	aa0303f6 	mov	x22, x3
    40204868:	aa0003f5 	mov	x21, x0
    4020486c:	926b0348 	and	x8, x26, #0x200000
    40204870:	d355574a 	ubfx	x10, x26, #21, #1
    40204874:	7100011f 	cmp	w8, #0x0
    40204878:	52800568 	mov	w8, #0x2b                  	// #43
    4020487c:	1a880128 	csel	w8, w9, w8, eq  // eq = none
    40204880:	7100003f 	cmp	w1, #0x0
    40204884:	528005a9 	mov	w9, #0x2d                  	// #45
    40204888:	9a9f154a 	csinc	x10, x10, xzr, ne  // ne = any
    4020488c:	1a891118 	csel	w24, w8, w9, ne  // ne = any
    40204890:	8b05015b 	add	x27, x10, x5
    40204894:	37b8033a 	tbnz	w26, #23, 402048f8 <<core::fmt::Formatter>::pad_integral+0xc4>
    40204898:	aa1f03f7 	mov	x23, xzr
    4020489c:	79402ab4 	ldrh	w20, [x21, #20]
    402048a0:	eb14037f 	cmp	x27, x20
    402048a4:	54001503 	b.cc	40204b44 <<core::fmt::Formatter>::pad_integral+0x310>  // b.lo, b.ul, b.last
    402048a8:	a94056b9 	ldp	x25, x21, [x21]
    402048ac:	2a1803e2 	mov	w2, w24
    402048b0:	aa1703e3 	mov	x3, x23
    402048b4:	aa1603e4 	mov	x4, x22
    402048b8:	aa1903e0 	mov	x0, x25
    402048bc:	aa1503e1 	mov	x1, x21
    402048c0:	94000310 	bl	40205500 <<core::fmt::Formatter>::pad_integral::write_prefix>
    402048c4:	37001d60 	tbnz	w0, #0, 40204c70 <<core::fmt::Formatter>::pad_integral+0x43c>
    402048c8:	f9400ea3 	ldr	x3, [x21, #24]
    402048cc:	aa1903e0 	mov	x0, x25
    402048d0:	aa1c03e1 	mov	x1, x28
    402048d4:	aa1303e2 	mov	x2, x19
    402048d8:	a9464ff4 	ldp	x20, x19, [sp, #96]
    402048dc:	a94557f6 	ldp	x22, x21, [sp, #80]
    402048e0:	a9445ff8 	ldp	x24, x23, [sp, #64]
    402048e4:	a94367fa 	ldp	x26, x25, [sp, #48]
    402048e8:	a9426ffc 	ldp	x28, x27, [sp, #32]
    402048ec:	a9417bfd 	ldp	x29, x30, [sp, #16]
    402048f0:	9101c3ff 	add	sp, sp, #0x70
    402048f4:	d61f0060 	br	x3
    402048f8:	aa0203f7 	mov	x23, x2
    402048fc:	f10082df 	cmp	x22, #0x20
    40204900:	540000e2 	b.cs	4020491c <<core::fmt::Formatter>::pad_integral+0xe8>  // b.hs, b.nlast
    40204904:	b4000156 	cbz	x22, 4020492c <<core::fmt::Formatter>::pad_integral+0xf8>
    40204908:	f10022df 	cmp	x22, #0x8
    4020490c:	54000142 	b.cs	40204934 <<core::fmt::Formatter>::pad_integral+0x100>  // b.hs, b.nlast
    40204910:	aa1f03e8 	mov	x8, xzr
    40204914:	aa1f03e0 	mov	x0, xzr
    40204918:	14000080 	b	40204b18 <<core::fmt::Formatter>::pad_integral+0x2e4>
    4020491c:	aa1703e0 	mov	x0, x23
    40204920:	aa1603e1 	mov	x1, x22
    40204924:	94000102 	bl	40204d2c <core::str::count::do_count_chars>
    40204928:	14000083 	b	40204b34 <<core::fmt::Formatter>::pad_integral+0x300>
    4020492c:	aa1f03e0 	mov	x0, xzr
    40204930:	14000081 	b	40204b34 <<core::fmt::Formatter>::pad_integral+0x300>
    40204934:	aa1703ea 	mov	x10, x23
    40204938:	39400ae9 	ldrb	w9, [x23, #2]
    4020493c:	394006e8 	ldrb	w8, [x23, #1]
    40204940:	38404d4b 	ldrb	w11, [x10, #4]!
    40204944:	3940094c 	ldrb	w12, [x10, #2]
    40204948:	394002ed 	ldrb	w13, [x23]
    4020494c:	39400eee 	ldrb	w14, [x23, #3]
    40204950:	d370bd29 	lsl	x9, x9, #16
    40204954:	394016ef 	ldrb	w15, [x23, #5]
    40204958:	39400d4a 	ldrb	w10, [x10, #3]
    4020495c:	53103d8c 	lsl	w12, w12, #16
    40204960:	aa0821a8 	orr	x8, x13, x8, lsl #8
    40204964:	aa0e6129 	orr	x9, x9, x14, lsl #24
    40204968:	0f05e7e4 	movi	v4.8b, #0xbf
    4020496c:	2a0f216b 	orr	w11, w11, w15, lsl #8
    40204970:	2a0a618a 	orr	w10, w12, w10, lsl #24
    40204974:	aa080128 	orr	x8, x9, x8
    40204978:	2a0b0149 	orr	w9, w10, w11
    4020497c:	aa098108 	orr	x8, x8, x9, lsl #32
    40204980:	9e670100 	fmov	d0, x8
    40204984:	52800028 	mov	w8, #0x1                   	// #1
    40204988:	4e080d03 	dup	v3.2d, x8
    4020498c:	927d06c8 	and	x8, x22, #0x18
    40204990:	f100211f 	cmp	x8, #0x8
    40204994:	0e243400 	cmgt	v0.8b, v0.8b, v4.8b
    40204998:	2f08a400 	uxtl	v0.8h, v0.8b
    4020499c:	6f10a401 	uxtl2	v1.4s, v0.8h
    402049a0:	2f10a400 	uxtl	v0.4s, v0.4h
    402049a4:	6f20a422 	uxtl2	v2.2d, v1.4s
    402049a8:	2f20a421 	uxtl	v1.2d, v1.2s
    402049ac:	6f20a405 	uxtl2	v5.2d, v0.4s
    402049b0:	2f20a406 	uxtl	v6.2d, v0.2s
    402049b4:	4e231c40 	and	v0.16b, v2.16b, v3.16b
    402049b8:	4e231c22 	and	v2.16b, v1.16b, v3.16b
    402049bc:	4e231ca1 	and	v1.16b, v5.16b, v3.16b
    402049c0:	4e231cc3 	and	v3.16b, v6.16b, v3.16b
    402049c4:	540009c0 	b.eq	40204afc <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    402049c8:	aa1703e9 	mov	x9, x23
    402049cc:	f100411f 	cmp	x8, #0x10
    402049d0:	38408d2a 	ldrb	w10, [x9, #8]!
    402049d4:	3940052b 	ldrb	w11, [x9, #1]
    402049d8:	39400d2c 	ldrb	w12, [x9, #3]
    402049dc:	3940092d 	ldrb	w13, [x9, #2]
    402049e0:	3940152e 	ldrb	w14, [x9, #5]
    402049e4:	38404d2f 	ldrb	w15, [x9, #4]!
    402049e8:	39400930 	ldrb	w16, [x9, #2]
    402049ec:	39400d29 	ldrb	w9, [x9, #3]
    402049f0:	d370bdad 	lsl	x13, x13, #16
    402049f4:	aa0b214a 	orr	x10, x10, x11, lsl #8
    402049f8:	53103e10 	lsl	w16, w16, #16
    402049fc:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40204a00:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40204a04:	2a096209 	orr	w9, w16, w9, lsl #24
    40204a08:	aa0a018a 	orr	x10, x12, x10
    40204a0c:	2a0b0129 	orr	w9, w9, w11
    40204a10:	aa098149 	orr	x9, x10, x9, lsl #32
    40204a14:	9e670125 	fmov	d5, x9
    40204a18:	52800029 	mov	w9, #0x1                   	// #1
    40204a1c:	4e080d26 	dup	v6.2d, x9
    40204a20:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40204a24:	2f08a484 	uxtl	v4.8h, v4.8b
    40204a28:	6f10a485 	uxtl2	v5.4s, v4.8h
    40204a2c:	2f10a484 	uxtl	v4.4s, v4.4h
    40204a30:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40204a34:	2f20a490 	uxtl	v16.2d, v4.2s
    40204a38:	6f20a484 	uxtl2	v4.2d, v4.4s
    40204a3c:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40204a40:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40204a44:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40204a48:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40204a4c:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40204a50:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40204a54:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40204a58:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40204a5c:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40204a60:	540004e0 	b.eq	40204afc <<core::fmt::Formatter>::pad_integral+0x2c8>  // b.none
    40204a64:	aa1703e9 	mov	x9, x23
    40204a68:	0f05e7e4 	movi	v4.8b, #0xbf
    40204a6c:	38410d2a 	ldrb	w10, [x9, #16]!
    40204a70:	3940052b 	ldrb	w11, [x9, #1]
    40204a74:	39400d2c 	ldrb	w12, [x9, #3]
    40204a78:	3940092d 	ldrb	w13, [x9, #2]
    40204a7c:	3940152e 	ldrb	w14, [x9, #5]
    40204a80:	38404d2f 	ldrb	w15, [x9, #4]!
    40204a84:	39400930 	ldrb	w16, [x9, #2]
    40204a88:	39400d29 	ldrb	w9, [x9, #3]
    40204a8c:	d370bdad 	lsl	x13, x13, #16
    40204a90:	aa0b214a 	orr	x10, x10, x11, lsl #8
    40204a94:	53103e10 	lsl	w16, w16, #16
    40204a98:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40204a9c:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40204aa0:	2a096209 	orr	w9, w16, w9, lsl #24
    40204aa4:	aa0a018a 	orr	x10, x12, x10
    40204aa8:	2a0b0129 	orr	w9, w9, w11
    40204aac:	aa098149 	orr	x9, x10, x9, lsl #32
    40204ab0:	9e670125 	fmov	d5, x9
    40204ab4:	52800029 	mov	w9, #0x1                   	// #1
    40204ab8:	4e080d26 	dup	v6.2d, x9
    40204abc:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40204ac0:	2f08a484 	uxtl	v4.8h, v4.8b
    40204ac4:	6f10a485 	uxtl2	v5.4s, v4.8h
    40204ac8:	2f10a484 	uxtl	v4.4s, v4.4h
    40204acc:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40204ad0:	2f20a490 	uxtl	v16.2d, v4.2s
    40204ad4:	6f20a484 	uxtl2	v4.2d, v4.4s
    40204ad8:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40204adc:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40204ae0:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40204ae4:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40204ae8:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40204aec:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40204af0:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40204af4:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40204af8:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40204afc:	4ee28462 	add	v2.2d, v3.2d, v2.2d
    40204b00:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    40204b04:	eb0802df 	cmp	x22, x8
    40204b08:	4ee08440 	add	v0.2d, v2.2d, v0.2d
    40204b0c:	5ef1b800 	addp	d0, v0.2d
    40204b10:	9e660000 	fmov	x0, d0
    40204b14:	54000100 	b.eq	40204b34 <<core::fmt::Formatter>::pad_integral+0x300>  // b.none
    40204b18:	cb0802c9 	sub	x9, x22, x8
    40204b1c:	8b0802e8 	add	x8, x23, x8
    40204b20:	38c0150a 	ldrsb	w10, [x8], #1
    40204b24:	3101055f 	cmn	w10, #0x41
    40204b28:	9a80d400 	cinc	x0, x0, gt
    40204b2c:	f1000529 	subs	x9, x9, #0x1
    40204b30:	54ffff81 	b.ne	40204b20 <<core::fmt::Formatter>::pad_integral+0x2ec>  // b.any
    40204b34:	8b1b001b 	add	x27, x0, x27
    40204b38:	79402ab4 	ldrh	w20, [x21, #20]
    40204b3c:	eb14037f 	cmp	x27, x20
    40204b40:	54ffeb42 	b.cs	402048a8 <<core::fmt::Formatter>::pad_integral+0x74>  // b.hs, b.nlast
    40204b44:	f90007fc 	str	x28, [sp, #8]
    40204b48:	37c0011a 	tbnz	w26, #24, 40204b68 <<core::fmt::Formatter>::pad_integral+0x334>
    40204b4c:	531d7b48 	ubfx	w8, w26, #29, #2
    40204b50:	4b1b029b 	sub	w27, w20, w27
    40204b54:	7100051f 	cmp	w8, #0x1
    40204b58:	540003cc 	b.gt	40204bd0 <<core::fmt::Formatter>::pad_integral+0x39c>
    40204b5c:	35000568 	cbnz	w8, 40204c08 <<core::fmt::Formatter>::pad_integral+0x3d4>
    40204b60:	2a1f03fc 	mov	w28, wzr
    40204b64:	1400002a 	b	40204c0c <<core::fmt::Formatter>::pad_integral+0x3d8>
    40204b68:	a940f2ba 	ldp	x26, x28, [x21, #8]
    40204b6c:	52b3fc08 	mov	w8, #0x9fe00000            	// #-1612709888
    40204b70:	f94002b9 	ldr	x25, [x21]
    40204b74:	2a1803e2 	mov	w2, w24
    40204b78:	aa1703e3 	mov	x3, x23
    40204b7c:	aa1603e4 	mov	x4, x22
    40204b80:	0a080388 	and	w8, w28, w8
    40204b84:	aa1903e0 	mov	x0, x25
    40204b88:	aa1a03e1 	mov	x1, x26
    40204b8c:	321c0508 	orr	w8, w8, #0x30
    40204b90:	32030108 	orr	w8, w8, #0x20000000
    40204b94:	b90012a8 	str	w8, [x21, #16]
    40204b98:	9400025a 	bl	40205500 <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204b9c:	370006a0 	tbnz	w0, #0, 40204c70 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204ba0:	2a1f03f6 	mov	w22, wzr
    40204ba4:	4b1b0294 	sub	w20, w20, w27
    40204ba8:	12003ec8 	and	w8, w22, #0xffff
    40204bac:	6b34211f 	cmp	w8, w20, uxth
    40204bb0:	540001a2 	b.cs	40204be4 <<core::fmt::Formatter>::pad_integral+0x3b0>  // b.hs, b.nlast
    40204bb4:	f9401348 	ldr	x8, [x26, #32]
    40204bb8:	aa1903e0 	mov	x0, x25
    40204bbc:	52800601 	mov	w1, #0x30                  	// #48
    40204bc0:	110006d6 	add	w22, w22, #0x1
    40204bc4:	d63f0100 	blr	x8
    40204bc8:	3607ff00 	tbz	w0, #0, 40204ba8 <<core::fmt::Formatter>::pad_integral+0x374>
    40204bcc:	14000029 	b	40204c70 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204bd0:	7100091f 	cmp	w8, #0x2
    40204bd4:	2a1b03fc 	mov	w28, w27
    40204bd8:	540001a1 	b.ne	40204c0c <<core::fmt::Formatter>::pad_integral+0x3d8>  // b.any
    40204bdc:	53013f7c 	ubfx	w28, w27, #1, #15
    40204be0:	1400000b 	b	40204c0c <<core::fmt::Formatter>::pad_integral+0x3d8>
    40204be4:	f9400f48 	ldr	x8, [x26, #24]
    40204be8:	f94007e1 	ldr	x1, [sp, #8]
    40204bec:	aa1903e0 	mov	x0, x25
    40204bf0:	aa1303e2 	mov	x2, x19
    40204bf4:	d63f0100 	blr	x8
    40204bf8:	370003c0 	tbnz	w0, #0, 40204c70 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204bfc:	2a1f03f3 	mov	w19, wzr
    40204c00:	f9000abc 	str	x28, [x21, #16]
    40204c04:	1400001c 	b	40204c74 <<core::fmt::Formatter>::pad_integral+0x440>
    40204c08:	2a1b03fc 	mov	w28, w27
    40204c0c:	a94056b9 	ldp	x25, x21, [x21]
    40204c10:	2a1f03f4 	mov	w20, wzr
    40204c14:	12003e88 	and	w8, w20, #0xffff
    40204c18:	6b3c211f 	cmp	w8, w28, uxth
    40204c1c:	54000102 	b.cs	40204c3c <<core::fmt::Formatter>::pad_integral+0x408>  // b.hs, b.nlast
    40204c20:	f94012a8 	ldr	x8, [x21, #32]
    40204c24:	12005341 	and	w1, w26, #0x1fffff
    40204c28:	aa1903e0 	mov	x0, x25
    40204c2c:	11000694 	add	w20, w20, #0x1
    40204c30:	d63f0100 	blr	x8
    40204c34:	3607ff00 	tbz	w0, #0, 40204c14 <<core::fmt::Formatter>::pad_integral+0x3e0>
    40204c38:	1400000e 	b	40204c70 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204c3c:	aa1903e0 	mov	x0, x25
    40204c40:	aa1503e1 	mov	x1, x21
    40204c44:	2a1803e2 	mov	w2, w24
    40204c48:	aa1703e3 	mov	x3, x23
    40204c4c:	aa1603e4 	mov	x4, x22
    40204c50:	9400022c 	bl	40205500 <<core::fmt::Formatter>::pad_integral::write_prefix>
    40204c54:	370000e0 	tbnz	w0, #0, 40204c70 <<core::fmt::Formatter>::pad_integral+0x43c>
    40204c58:	f9400ea8 	ldr	x8, [x21, #24]
    40204c5c:	f94007e1 	ldr	x1, [sp, #8]
    40204c60:	aa1903e0 	mov	x0, x25
    40204c64:	aa1303e2 	mov	x2, x19
    40204c68:	d63f0100 	blr	x8
    40204c6c:	36000160 	tbz	w0, #0, 40204c98 <<core::fmt::Formatter>::pad_integral+0x464>
    40204c70:	52800033 	mov	w19, #0x1                   	// #1
    40204c74:	2a1303e0 	mov	w0, w19
    40204c78:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40204c7c:	a94557f6 	ldp	x22, x21, [sp, #80]
    40204c80:	a9445ff8 	ldp	x24, x23, [sp, #64]
    40204c84:	a94367fa 	ldp	x26, x25, [sp, #48]
    40204c88:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40204c8c:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40204c90:	9101c3ff 	add	sp, sp, #0x70
    40204c94:	d65f03c0 	ret
    40204c98:	2a1f03f4 	mov	w20, wzr
    40204c9c:	4b1c0376 	sub	w22, w27, w28
    40204ca0:	12003e88 	and	w8, w20, #0xffff
    40204ca4:	6b36211f 	cmp	w8, w22, uxth
    40204ca8:	1a9f27f3 	cset	w19, cc  // cc = lo, ul, last
    40204cac:	54fffe42 	b.cs	40204c74 <<core::fmt::Formatter>::pad_integral+0x440>  // b.hs, b.nlast
    40204cb0:	f94012a8 	ldr	x8, [x21, #32]
    40204cb4:	12005341 	and	w1, w26, #0x1fffff
    40204cb8:	aa1903e0 	mov	x0, x25
    40204cbc:	11000694 	add	w20, w20, #0x1
    40204cc0:	d63f0100 	blr	x8
    40204cc4:	3607fee0 	tbz	w0, #0, 40204ca0 <<core::fmt::Formatter>::pad_integral+0x46c>
    40204cc8:	17ffffeb 	b	40204c74 <<core::fmt::Formatter>::pad_integral+0x440>

0000000040204ccc <core::panicking::panic_bounds_check>:
    40204ccc:	d10103ff 	sub	sp, sp, #0x40
    40204cd0:	a9037bfd 	stp	x29, x30, [sp, #48]
    40204cd4:	9100c3fd 	add	x29, sp, #0x30
    40204cd8:	910023e8 	add	x8, sp, #0x8
    40204cdc:	d503201f 	nop
    40204ce0:	10004549 	adr	x9, 40205588 <<u64 as core::fmt::Display>::fmt>
    40204ce4:	a90007e0 	stp	x0, x1, [sp]
    40204ce8:	b0000000 	adrp	x0, 40205000 <core::str::count::do_count_chars+0x2d4>
    40204cec:	9136f400 	add	x0, x0, #0xdbd
    40204cf0:	a90127e8 	stp	x8, x9, [sp, #16]
    40204cf4:	910003e8 	mov	x8, sp
    40204cf8:	910043e1 	add	x1, sp, #0x10
    40204cfc:	a90227e8 	stp	x8, x9, [sp, #32]
    40204d00:	94000001 	bl	40204d04 <core::panicking::panic_fmt>

0000000040204d04 <core::panicking::panic_fmt>:
    40204d04:	d10103ff 	sub	sp, sp, #0x40
    40204d08:	a9037bfd 	stp	x29, x30, [sp, #48]
    40204d0c:	9100c3fd 	add	x29, sp, #0x30
    40204d10:	910023e8 	add	x8, sp, #0x8
    40204d14:	a90087e0 	stp	x0, x1, [sp, #8]
    40204d18:	910063e0 	add	x0, sp, #0x18
    40204d1c:	a9018be8 	stp	x8, x2, [sp, #24]
    40204d20:	52800028 	mov	w8, #0x1                   	// #1
    40204d24:	790053e8 	strh	w8, [sp, #40]
    40204d28:	97fffc97 	bl	40203f84 <__rustc::rust_begin_unwind>

0000000040204d2c <core::str::count::do_count_chars>:
    40204d2c:	d10183ff 	sub	sp, sp, #0x60
    40204d30:	fd0023ea 	str	d10, [sp, #64]
    40204d34:	6d0523e9 	stp	d9, d8, [sp, #80]
    40204d38:	91001c08 	add	x8, x0, #0x7
    40204d3c:	927df10d 	and	x13, x8, #0xfffffffffffffff8
    40204d40:	cb0001ac 	sub	x12, x13, x0
    40204d44:	eb0c002b 	subs	x11, x1, x12
    40204d48:	540000e2 	b.cs	40204d64 <core::str::count::do_count_chars+0x38>  // b.hs, b.nlast
    40204d4c:	b4000721 	cbz	x1, 40204e30 <core::str::count::do_count_chars+0x104>
    40204d50:	f100203f 	cmp	x1, #0x8
    40204d54:	54001b82 	b.cs	402050c4 <core::str::count::do_count_chars+0x398>  // b.hs, b.nlast
    40204d58:	aa1f03e9 	mov	x9, xzr
    40204d5c:	aa1f03e8 	mov	x8, xzr
    40204d60:	140001d2 	b	402054a8 <core::str::count::do_count_chars+0x77c>
    40204d64:	d343fd69 	lsr	x9, x11, #3
    40204d68:	b4ffff29 	cbz	x9, 40204d4c <core::str::count::do_count_chars+0x20>
    40204d6c:	eb0001bf 	cmp	x13, x0
    40204d70:	9240096a 	and	x10, x11, #0x7
    40204d74:	aa1f03e8 	mov	x8, xzr
    40204d78:	54000100 	b.eq	40204d98 <core::str::count::do_count_chars+0x6c>  // b.none
    40204d7c:	cb0d000d 	sub	x13, x0, x13
    40204d80:	aa0003ee 	mov	x14, x0
    40204d84:	38c015cf 	ldrsb	w15, [x14], #1
    40204d88:	310105ff 	cmn	w15, #0x41
    40204d8c:	9a88d508 	cinc	x8, x8, gt
    40204d90:	b10005ad 	adds	x13, x13, #0x1
    40204d94:	54ffff83 	b.cc	40204d84 <core::str::count::do_count_chars+0x58>  // b.lo, b.ul, b.last
    40204d98:	8b0c000e 	add	x14, x0, x12
    40204d9c:	b400056a 	cbz	x10, 40204e48 <core::str::count::do_count_chars+0x11c>
    40204da0:	927ded6b 	and	x11, x11, #0x7ffffffffffffff8
    40204da4:	8b0b01cc 	add	x12, x14, x11
    40204da8:	39c0018b 	ldrsb	w11, [x12]
    40204dac:	3101057f 	cmn	w11, #0x41
    40204db0:	1a9fd7eb 	cset	w11, gt
    40204db4:	f100055f 	cmp	x10, #0x1
    40204db8:	540004a0 	b.eq	40204e4c <core::str::count::do_count_chars+0x120>  // b.none
    40204dbc:	39c0058d 	ldrsb	w13, [x12, #1]
    40204dc0:	310105bf 	cmn	w13, #0x41
    40204dc4:	9a8bd56b 	cinc	x11, x11, gt
    40204dc8:	f100095f 	cmp	x10, #0x2
    40204dcc:	54000400 	b.eq	40204e4c <core::str::count::do_count_chars+0x120>  // b.none
    40204dd0:	39c0098d 	ldrsb	w13, [x12, #2]
    40204dd4:	310105bf 	cmn	w13, #0x41
    40204dd8:	9a8bd56b 	cinc	x11, x11, gt
    40204ddc:	f1000d5f 	cmp	x10, #0x3
    40204de0:	54000360 	b.eq	40204e4c <core::str::count::do_count_chars+0x120>  // b.none
    40204de4:	39c00d8d 	ldrsb	w13, [x12, #3]
    40204de8:	310105bf 	cmn	w13, #0x41
    40204dec:	9a8bd56b 	cinc	x11, x11, gt
    40204df0:	f100115f 	cmp	x10, #0x4
    40204df4:	540002c0 	b.eq	40204e4c <core::str::count::do_count_chars+0x120>  // b.none
    40204df8:	39c0118d 	ldrsb	w13, [x12, #4]
    40204dfc:	310105bf 	cmn	w13, #0x41
    40204e00:	9a8bd56b 	cinc	x11, x11, gt
    40204e04:	f100155f 	cmp	x10, #0x5
    40204e08:	54000220 	b.eq	40204e4c <core::str::count::do_count_chars+0x120>  // b.none
    40204e0c:	39c0158d 	ldrsb	w13, [x12, #5]
    40204e10:	310105bf 	cmn	w13, #0x41
    40204e14:	9a8bd56b 	cinc	x11, x11, gt
    40204e18:	f100195f 	cmp	x10, #0x6
    40204e1c:	54000180 	b.eq	40204e4c <core::str::count::do_count_chars+0x120>  // b.none
    40204e20:	39c0198a 	ldrsb	w10, [x12, #6]
    40204e24:	3101055f 	cmn	w10, #0x41
    40204e28:	9a8bd56b 	cinc	x11, x11, gt
    40204e2c:	14000008 	b	40204e4c <core::str::count::do_count_chars+0x120>
    40204e30:	aa1f03e8 	mov	x8, xzr
    40204e34:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40204e38:	aa0803e0 	mov	x0, x8
    40204e3c:	fd4023ea 	ldr	d10, [sp, #64]
    40204e40:	910183ff 	add	sp, sp, #0x60
    40204e44:	d65f03c0 	ret
    40204e48:	aa1f03eb 	mov	x11, xzr
    40204e4c:	4f00e420 	movi	v0.16b, #0x1
    40204e50:	8b080168 	add	x8, x11, x8
    40204e54:	5280180a 	mov	w10, #0xc0                  	// #192
    40204e58:	b20083eb 	mov	x11, #0x1000100010001       	// #281479271743489
    40204e5c:	1400000c 	b	40204e8c <core::str::count::do_count_chars+0x160>
    40204e60:	aa1f03f1 	mov	x17, xzr
    40204e64:	d348fe2f 	lsr	x15, x17, #8
    40204e68:	92009e30 	and	x16, x17, #0xff00ff00ff00ff
    40204e6c:	8b0e018e 	add	x14, x12, x14
    40204e70:	cb0d0129 	sub	x9, x9, x13
    40204e74:	92009def 	and	x15, x15, #0xff00ff00ff00ff
    40204e78:	8b1001ef 	add	x15, x15, x16
    40204e7c:	9b0b7df0 	mul	x16, x15, x11
    40204e80:	924005af 	and	x15, x13, #0x3
    40204e84:	8b50c108 	add	x8, x8, x16, lsr #48
    40204e88:	b5000d8f 	cbnz	x15, 40205038 <core::str::count::do_count_chars+0x30c>
    40204e8c:	b4fffd49 	cbz	x9, 40204e34 <core::str::count::do_count_chars+0x108>
    40204e90:	f103013f 	cmp	x9, #0xc0
    40204e94:	aa0e03ec 	mov	x12, x14
    40204e98:	9a8a312d 	csel	x13, x9, x10, cc  // cc = lo, ul, last
    40204e9c:	d37df1ae 	lsl	x14, x13, #3
    40204ea0:	f27b15d0 	ands	x16, x14, #0x7e0
    40204ea4:	54fffde0 	b.eq	40204e60 <core::str::count::do_count_chars+0x134>  // b.none
    40204ea8:	d10081cf 	sub	x15, x14, #0x20
    40204eac:	f10181ff 	cmp	x15, #0x60
    40204eb0:	54000082 	b.cs	40204ec0 <core::str::count::do_count_chars+0x194>  // b.hs, b.nlast
    40204eb4:	aa1f03f1 	mov	x17, xzr
    40204eb8:	aa0c03ef 	mov	x15, x12
    40204ebc:	14000044 	b	40204fcc <core::str::count::do_count_chars+0x2a0>
    40204ec0:	d345fdef 	lsr	x15, x15, #5
    40204ec4:	6f00e401 	movi	v1.2d, #0x0
    40204ec8:	6f00e402 	movi	v2.2d, #0x0
    40204ecc:	91010180 	add	x0, x12, #0x40
    40204ed0:	910005f1 	add	x17, x15, #0x1
    40204ed4:	927ee632 	and	x18, x17, #0xffffffffffffffc
    40204ed8:	927ee621 	and	x1, x17, #0xffffffffffffffc
    40204edc:	8b12158f 	add	x15, x12, x18, lsl #5
    40204ee0:	d1010002 	sub	x2, x0, #0x40
    40204ee4:	4c400c10 	ld4	{v16.2d-v19.2d}, [x0]
    40204ee8:	f1001021 	subs	x1, x1, #0x4
    40204eec:	91020000 	add	x0, x0, #0x80
    40204ef0:	4c400c43 	ld4	{v3.2d-v6.2d}, [x2]
    40204ef4:	6e205a07 	mvn	v7.16b, v16.16b
    40204ef8:	6e205a35 	mvn	v21.16b, v17.16b
    40204efc:	6e205a5a 	mvn	v26.16b, v18.16b
    40204f00:	6e205876 	mvn	v22.16b, v3.16b
    40204f04:	6e205897 	mvn	v23.16b, v4.16b
    40204f08:	6e2058b8 	mvn	v24.16b, v5.16b
    40204f0c:	6f7a0614 	ushr	v20.2d, v16.2d, #6
    40204f10:	6f7a0639 	ushr	v25.2d, v17.2d, #6
    40204f14:	6f7a065b 	ushr	v27.2d, v18.2d, #6
    40204f18:	6f7a047c 	ushr	v28.2d, v3.2d, #6
    40204f1c:	6f7a049d 	ushr	v29.2d, v4.2d, #6
    40204f20:	6f7a04be 	ushr	v30.2d, v5.2d, #6
    40204f24:	6f7906d6 	ushr	v22.2d, v22.2d, #7
    40204f28:	6f7906f7 	ushr	v23.2d, v23.2d, #7
    40204f2c:	6f790718 	ushr	v24.2d, v24.2d, #7
    40204f30:	6f7904e7 	ushr	v7.2d, v7.2d, #7
    40204f34:	6f7906b5 	ushr	v21.2d, v21.2d, #7
    40204f38:	6f79075a 	ushr	v26.2d, v26.2d, #7
    40204f3c:	6e205a7f 	mvn	v31.16b, v19.16b
    40204f40:	6f7a0670 	ushr	v16.2d, v19.2d, #6
    40204f44:	6e2058d1 	mvn	v17.16b, v6.16b
    40204f48:	4ebc1ed2 	orr	v18.16b, v22.16b, v28.16b
    40204f4c:	4ebd1ef3 	orr	v19.16b, v23.16b, v29.16b
    40204f50:	4ebe1f16 	orr	v22.16b, v24.16b, v30.16b
    40204f54:	4eb41ce7 	orr	v7.16b, v7.16b, v20.16b
    40204f58:	4eb91eb4 	orr	v20.16b, v21.16b, v25.16b
    40204f5c:	4ebb1f55 	orr	v21.16b, v26.16b, v27.16b
    40204f60:	6f7a04c3 	ushr	v3.2d, v6.2d, #6
    40204f64:	6f7907e4 	ushr	v4.2d, v31.2d, #7
    40204f68:	6f790625 	ushr	v5.2d, v17.2d, #7
    40204f6c:	4e201e46 	and	v6.16b, v18.16b, v0.16b
    40204f70:	4e201e71 	and	v17.16b, v19.16b, v0.16b
    40204f74:	4e201ed2 	and	v18.16b, v22.16b, v0.16b
    40204f78:	4e201ce7 	and	v7.16b, v7.16b, v0.16b
    40204f7c:	4e201e93 	and	v19.16b, v20.16b, v0.16b
    40204f80:	4e201eb4 	and	v20.16b, v21.16b, v0.16b
    40204f84:	4eb01c84 	orr	v4.16b, v4.16b, v16.16b
    40204f88:	4ea31ca3 	orr	v3.16b, v5.16b, v3.16b
    40204f8c:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40204f90:	4ef18646 	add	v6.2d, v18.2d, v17.2d
    40204f94:	4ee284e2 	add	v2.2d, v7.2d, v2.2d
    40204f98:	4ef38685 	add	v5.2d, v20.2d, v19.2d
    40204f9c:	4e201c63 	and	v3.16b, v3.16b, v0.16b
    40204fa0:	4e201c84 	and	v4.16b, v4.16b, v0.16b
    40204fa4:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40204fa8:	4ee284a2 	add	v2.2d, v5.2d, v2.2d
    40204fac:	4ee18461 	add	v1.2d, v3.2d, v1.2d
    40204fb0:	4ee28482 	add	v2.2d, v4.2d, v2.2d
    40204fb4:	54fff961 	b.ne	40204ee0 <core::str::count::do_count_chars+0x1b4>  // b.any
    40204fb8:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40204fbc:	eb12023f 	cmp	x17, x18
    40204fc0:	5ef1b821 	addp	d1, v1.2d
    40204fc4:	9e660031 	fmov	x17, d1
    40204fc8:	54fff4e0 	b.eq	40204e64 <core::str::count::do_count_chars+0x138>  // b.none
    40204fcc:	8b100190 	add	x16, x12, x16
    40204fd0:	f9400df2 	ldr	x18, [x15, #24]
    40204fd4:	f9001ff2 	str	x18, [sp, #56]
    40204fd8:	f94009f2 	ldr	x18, [x15, #16]
    40204fdc:	f9001bf2 	str	x18, [sp, #48]
    40204fe0:	f94005f2 	ldr	x18, [x15, #8]
    40204fe4:	f90017f2 	str	x18, [sp, #40]
    40204fe8:	f84205f2 	ldr	x18, [x15], #32
    40204fec:	eb1001ff 	cmp	x15, x16
    40204ff0:	f90013f2 	str	x18, [sp, #32]
    40204ff4:	ad4107e2 	ldp	q2, q1, [sp, #32]
    40204ff8:	6e205823 	mvn	v3.16b, v1.16b
    40204ffc:	6e205844 	mvn	v4.16b, v2.16b
    40205000:	6f7a0421 	ushr	v1.2d, v1.2d, #6
    40205004:	6f7a0442 	ushr	v2.2d, v2.2d, #6
    40205008:	6f790463 	ushr	v3.2d, v3.2d, #7
    4020500c:	6f790484 	ushr	v4.2d, v4.2d, #7
    40205010:	4ea21c82 	orr	v2.16b, v4.16b, v2.16b
    40205014:	4ea11c61 	orr	v1.16b, v3.16b, v1.16b
    40205018:	4e201c21 	and	v1.16b, v1.16b, v0.16b
    4020501c:	4e201c42 	and	v2.16b, v2.16b, v0.16b
    40205020:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40205024:	5ef1b821 	addp	d1, v1.2d
    40205028:	9e660032 	fmov	x18, d1
    4020502c:	8b110251 	add	x17, x18, x17
    40205030:	54fffd01 	b.ne	40204fd0 <core::str::count::do_count_chars+0x2a4>  // b.any
    40205034:	17ffff8c 	b	40204e64 <core::str::count::do_count_chars+0x138>
    40205038:	927e15a9 	and	x9, x13, #0xfc
    4020503c:	f10005ff 	cmp	x15, #0x1
    40205040:	8b090d8a 	add	x10, x12, x9, lsl #3
    40205044:	f9400149 	ldr	x9, [x10]
    40205048:	aa2903eb 	mvn	x11, x9
    4020504c:	d347fd6b 	lsr	x11, x11, #7
    40205050:	aa491969 	orr	x9, x11, x9, lsr #6
    40205054:	9200c129 	and	x9, x9, #0x101010101010101
    40205058:	540001e0 	b.eq	40205094 <core::str::count::do_count_chars+0x368>  // b.none
    4020505c:	f940054b 	ldr	x11, [x10, #8]
    40205060:	f10009ff 	cmp	x15, #0x2
    40205064:	aa2b03ec 	mvn	x12, x11
    40205068:	d347fd8c 	lsr	x12, x12, #7
    4020506c:	aa4b198b 	orr	x11, x12, x11, lsr #6
    40205070:	9200c16b 	and	x11, x11, #0x101010101010101
    40205074:	8b090169 	add	x9, x11, x9
    40205078:	540000e0 	b.eq	40205094 <core::str::count::do_count_chars+0x368>  // b.none
    4020507c:	f940094a 	ldr	x10, [x10, #16]
    40205080:	aa2a03eb 	mvn	x11, x10
    40205084:	d347fd6b 	lsr	x11, x11, #7
    40205088:	aa4a196a 	orr	x10, x11, x10, lsr #6
    4020508c:	9200c14a 	and	x10, x10, #0x101010101010101
    40205090:	8b090149 	add	x9, x10, x9
    40205094:	d348fd2a 	lsr	x10, x9, #8
    40205098:	92009d29 	and	x9, x9, #0xff00ff00ff00ff
    4020509c:	92009d4a 	and	x10, x10, #0xff00ff00ff00ff
    402050a0:	8b090149 	add	x9, x10, x9
    402050a4:	b20083ea 	mov	x10, #0x1000100010001       	// #281479271743489
    402050a8:	9b0a7d29 	mul	x9, x9, x10
    402050ac:	8b49c108 	add	x8, x8, x9, lsr #48
    402050b0:	6d4523e9 	ldp	d9, d8, [sp, #80]
    402050b4:	aa0803e0 	mov	x0, x8
    402050b8:	fd4023ea 	ldr	d10, [sp, #64]
    402050bc:	910183ff 	add	sp, sp, #0x60
    402050c0:	d65f03c0 	ret
    402050c4:	f100803f 	cmp	x1, #0x20
    402050c8:	54000082 	b.cs	402050d8 <core::str::count::do_count_chars+0x3ac>  // b.hs, b.nlast
    402050cc:	aa1f03e9 	mov	x9, xzr
    402050d0:	aa1f03e8 	mov	x8, xzr
    402050d4:	140000bc 	b	402053c4 <core::str::count::do_count_chars+0x698>
    402050d8:	6f00e400 	movi	v0.2d, #0x0
    402050dc:	4f05e7e3 	movi	v3.16b, #0xbf
    402050e0:	52800028 	mov	w8, #0x1                   	// #1
    402050e4:	6f00e402 	movi	v2.2d, #0x0
    402050e8:	6f00e407 	movi	v7.2d, #0x0
    402050ec:	927d042a 	and	x10, x1, #0x18
    402050f0:	6f00e401 	movi	v1.2d, #0x0
    402050f4:	6f00e412 	movi	v18.2d, #0x0
    402050f8:	927be829 	and	x9, x1, #0xffffffffffffffe0
    402050fc:	6f00e405 	movi	v5.2d, #0x0
    40205100:	6f00e406 	movi	v6.2d, #0x0
    40205104:	927be82b 	and	x11, x1, #0xffffffffffffffe0
    40205108:	6f00e404 	movi	v4.2d, #0x0
    4020510c:	6f00e416 	movi	v22.2d, #0x0
    40205110:	6f00e411 	movi	v17.2d, #0x0
    40205114:	6f00e410 	movi	v16.2d, #0x0
    40205118:	6f00e417 	movi	v23.2d, #0x0
    4020511c:	6f00e414 	movi	v20.2d, #0x0
    40205120:	6f00e415 	movi	v21.2d, #0x0
    40205124:	6f00e413 	movi	v19.2d, #0x0
    40205128:	6f00e418 	movi	v24.2d, #0x0
    4020512c:	4e080d19 	dup	v25.2d, x8
    40205130:	91004008 	add	x8, x0, #0x10
    40205134:	aa0803ec 	mov	x12, x8
    40205138:	385f1112 	ldurb	w18, [x8, #-15]
    4020513c:	385f5102 	ldurb	w2, [x8, #-11]
    40205140:	385f0d8d 	ldrb	w13, [x12, #-16]!
    40205144:	aa0c03ef 	mov	x15, x12
    40205148:	3940098e 	ldrb	w14, [x12, #2]
    4020514c:	38404df0 	ldrb	w16, [x15, #4]!
    40205150:	394009f1 	ldrb	w17, [x15, #2]
    40205154:	39400d83 	ldrb	w3, [x12, #3]
    40205158:	39400def 	ldrb	w15, [x15, #3]
    4020515c:	d370bdce 	lsl	x14, x14, #16
    40205160:	aa1221ad 	orr	x13, x13, x18, lsl #8
    40205164:	2a022210 	orr	w16, w16, w2, lsl #8
    40205168:	53103e31 	lsl	w17, w17, #16
    4020516c:	f100816b 	subs	x11, x11, #0x20
    40205170:	aa0361ce 	orr	x14, x14, x3, lsl #24
    40205174:	2a0f622f 	orr	w15, w17, w15, lsl #24
    40205178:	aa0d01cd 	orr	x13, x14, x13
    4020517c:	2a1001ee 	orr	w14, w15, w16
    40205180:	aa0e81ad 	orr	x13, x13, x14, lsl #32
    40205184:	f9000bed 	str	x13, [sp, #16]
    40205188:	aa0c03ed 	mov	x13, x12
    4020518c:	38408dae 	ldrb	w14, [x13, #8]!
    40205190:	39400daf 	ldrb	w15, [x13, #3]
    40205194:	394009b0 	ldrb	w16, [x13, #2]
    40205198:	38404db1 	ldrb	w17, [x13, #4]!
    4020519c:	394009b2 	ldrb	w18, [x13, #2]
    402051a0:	39402582 	ldrb	w2, [x12, #9]
    402051a4:	3940358c 	ldrb	w12, [x12, #13]
    402051a8:	39400dad 	ldrb	w13, [x13, #3]
    402051ac:	d370be10 	lsl	x16, x16, #16
    402051b0:	53103e52 	lsl	w18, w18, #16
    402051b4:	aa0221ce 	orr	x14, x14, x2, lsl #8
    402051b8:	2a0c222c 	orr	w12, w17, w12, lsl #8
    402051bc:	aa0f620f 	orr	x15, x16, x15, lsl #24
    402051c0:	2a0d624d 	orr	w13, w18, w13, lsl #24
    402051c4:	aa0e01ee 	orr	x14, x15, x14
    402051c8:	2a0c01ac 	orr	w12, w13, w12
    402051cc:	aa0c81cc 	orr	x12, x14, x12, lsl #32
    402051d0:	f9000fec 	str	x12, [sp, #24]
    402051d4:	aa0803ec 	mov	x12, x8
    402051d8:	3940090e 	ldrb	w14, [x8, #2]
    402051dc:	38404d8f 	ldrb	w15, [x12, #4]!
    402051e0:	39400990 	ldrb	w16, [x12, #2]
    402051e4:	3940050d 	ldrb	w13, [x8, #1]
    402051e8:	39400111 	ldrb	w17, [x8]
    402051ec:	39400d12 	ldrb	w18, [x8, #3]
    402051f0:	39401502 	ldrb	w2, [x8, #5]
    402051f4:	39400d8c 	ldrb	w12, [x12, #3]
    402051f8:	d370bdce 	lsl	x14, x14, #16
    402051fc:	53103e10 	lsl	w16, w16, #16
    40205200:	aa0d222d 	orr	x13, x17, x13, lsl #8
    40205204:	2a0221ef 	orr	w15, w15, w2, lsl #8
    40205208:	3dc007fa 	ldr	q26, [sp, #16]
    4020520c:	aa1261ce 	orr	x14, x14, x18, lsl #24
    40205210:	2a0c620c 	orr	w12, w16, w12, lsl #24
    40205214:	4e23375a 	cmgt	v26.16b, v26.16b, v3.16b
    40205218:	aa0d01cd 	orr	x13, x14, x13
    4020521c:	2a0f018c 	orr	w12, w12, w15
    40205220:	aa0c81ac 	orr	x12, x13, x12, lsl #32
    40205224:	aa0803ed 	mov	x13, x8
    40205228:	6f08a75b 	uxtl2	v27.8h, v26.16b
    4020522c:	2f08a75a 	uxtl	v26.8h, v26.8b
    40205230:	f90003ec 	str	x12, [sp]
    40205234:	38408dac 	ldrb	w12, [x13, #8]!
    40205238:	39400dae 	ldrb	w14, [x13, #3]
    4020523c:	394009af 	ldrb	w15, [x13, #2]
    40205240:	38404db0 	ldrb	w16, [x13, #4]!
    40205244:	394009b1 	ldrb	w17, [x13, #2]
    40205248:	39402512 	ldrb	w18, [x8, #9]
    4020524c:	39403502 	ldrb	w2, [x8, #13]
    40205250:	39400dad 	ldrb	w13, [x13, #3]
    40205254:	d370bdef 	lsl	x15, x15, #16
    40205258:	6f10a77c 	uxtl2	v28.4s, v27.8h
    4020525c:	53103e31 	lsl	w17, w17, #16
    40205260:	aa12218c 	orr	x12, x12, x18, lsl #8
    40205264:	2a022210 	orr	w16, w16, w2, lsl #8
    40205268:	aa0e61ee 	orr	x14, x15, x14, lsl #24
    4020526c:	2f10a77b 	uxtl	v27.4s, v27.4h
    40205270:	2f10a75e 	uxtl	v30.4s, v26.4h
    40205274:	2a0d622d 	orr	w13, w17, w13, lsl #24
    40205278:	6f20a79d 	uxtl2	v29.2d, v28.4s
    4020527c:	6f10a75a 	uxtl2	v26.4s, v26.8h
    40205280:	aa0c01cc 	orr	x12, x14, x12
    40205284:	2f20a79c 	uxtl	v28.2d, v28.2s
    40205288:	91008108 	add	x8, x8, #0x20
    4020528c:	2a1001ad 	orr	w13, w13, w16
    40205290:	6f20a768 	uxtl2	v8.2d, v27.4s
    40205294:	6f20a7c9 	uxtl2	v9.2d, v30.4s
    40205298:	aa0d818c 	orr	x12, x12, x13, lsl #32
    4020529c:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    402052a0:	6f20a74a 	uxtl2	v10.2d, v26.4s
    402052a4:	2f20a75a 	uxtl	v26.2d, v26.2s
    402052a8:	2f20a77b 	uxtl	v27.2d, v27.2s
    402052ac:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    402052b0:	f90007ec 	str	x12, [sp, #8]
    402052b4:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    402052b8:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    402052bc:	3dc003ff 	ldr	q31, [sp]
    402052c0:	4efd86d6 	add	v22.2d, v22.2d, v29.2d
    402052c4:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    402052c8:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    402052cc:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    402052d0:	4efc8484 	add	v4.2d, v4.2d, v28.2d
    402052d4:	4e2337ff 	cmgt	v31.16b, v31.16b, v3.16b
    402052d8:	4ee884c6 	add	v6.2d, v6.2d, v8.2d
    402052dc:	2f20a7de 	uxtl	v30.2d, v30.2s
    402052e0:	4eea8652 	add	v18.2d, v18.2d, v10.2d
    402052e4:	4ee984e7 	add	v7.2d, v7.2d, v9.2d
    402052e8:	4efa8421 	add	v1.2d, v1.2d, v26.2d
    402052ec:	4efb84a5 	add	v5.2d, v5.2d, v27.2d
    402052f0:	6f08a7fd 	uxtl2	v29.8h, v31.16b
    402052f4:	2f08a7ff 	uxtl	v31.8h, v31.8b
    402052f8:	4e391fde 	and	v30.16b, v30.16b, v25.16b
    402052fc:	6f10a7bc 	uxtl2	v28.4s, v29.8h
    40205300:	6f10a7e8 	uxtl2	v8.4s, v31.8h
    40205304:	2f10a7bd 	uxtl	v29.4s, v29.4h
    40205308:	2f10a7fa 	uxtl	v26.4s, v31.4h
    4020530c:	4efe8442 	add	v2.2d, v2.2d, v30.2d
    40205310:	2f20a79b 	uxtl	v27.2d, v28.2s
    40205314:	6f20a79c 	uxtl2	v28.2d, v28.4s
    40205318:	2f20a7bf 	uxtl	v31.2d, v29.2s
    4020531c:	6f20a509 	uxtl2	v9.2d, v8.4s
    40205320:	6f20a7bd 	uxtl2	v29.2d, v29.4s
    40205324:	2f20a74a 	uxtl	v10.2d, v26.2s
    40205328:	6f20a75a 	uxtl2	v26.2d, v26.4s
    4020532c:	2f20a508 	uxtl	v8.2d, v8.2s
    40205330:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    40205334:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    40205338:	4e391fff 	and	v31.16b, v31.16b, v25.16b
    4020533c:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    40205340:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    40205344:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40205348:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    4020534c:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    40205350:	4efc8718 	add	v24.2d, v24.2d, v28.2d
    40205354:	4efb8673 	add	v19.2d, v19.2d, v27.2d
    40205358:	4eff8694 	add	v20.2d, v20.2d, v31.2d
    4020535c:	4efd86b5 	add	v21.2d, v21.2d, v29.2d
    40205360:	4ee986f7 	add	v23.2d, v23.2d, v9.2d
    40205364:	4eea8631 	add	v17.2d, v17.2d, v10.2d
    40205368:	4ee88610 	add	v16.2d, v16.2d, v8.2d
    4020536c:	4efa8400 	add	v0.2d, v0.2d, v26.2d
    40205370:	54ffee21 	b.ne	40205134 <core::str::count::do_count_chars+0x408>  // b.any
    40205374:	4ef286e3 	add	v3.2d, v23.2d, v18.2d
    40205378:	4ef68712 	add	v18.2d, v24.2d, v22.2d
    4020537c:	eb09003f 	cmp	x1, x9
    40205380:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40205384:	4ee28622 	add	v2.2d, v17.2d, v2.2d
    40205388:	4ee58685 	add	v5.2d, v20.2d, v5.2d
    4020538c:	4ee686a6 	add	v6.2d, v21.2d, v6.2d
    40205390:	4ee18601 	add	v1.2d, v16.2d, v1.2d
    40205394:	4ee48664 	add	v4.2d, v19.2d, v4.2d
    40205398:	4ef28463 	add	v3.2d, v3.2d, v18.2d
    4020539c:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    402053a0:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    402053a4:	4ee68400 	add	v0.2d, v0.2d, v6.2d
    402053a8:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    402053ac:	4ee38400 	add	v0.2d, v0.2d, v3.2d
    402053b0:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    402053b4:	5ef1b800 	addp	d0, v0.2d
    402053b8:	9e660008 	fmov	x8, d0
    402053bc:	54ffd3c0 	b.eq	40204e34 <core::str::count::do_count_chars+0x108>  // b.none
    402053c0:	b400074a 	cbz	x10, 402054a8 <core::str::count::do_count_chars+0x77c>
    402053c4:	6f00e400 	movi	v0.2d, #0x0
    402053c8:	6f00e401 	movi	v1.2d, #0x0
    402053cc:	aa0903ea 	mov	x10, x9
    402053d0:	0f05e7e2 	movi	v2.8b, #0xbf
    402053d4:	6f00e403 	movi	v3.2d, #0x0
    402053d8:	927df029 	and	x9, x1, #0xfffffffffffffff8
    402053dc:	6f00e404 	movi	v4.2d, #0x0
    402053e0:	4e081d00 	mov	v0.d[0], x8
    402053e4:	52800028 	mov	w8, #0x1                   	// #1
    402053e8:	4e080d05 	dup	v5.2d, x8
    402053ec:	cb090148 	sub	x8, x10, x9
    402053f0:	8b0a000a 	add	x10, x0, x10
    402053f4:	aa0a03ed 	mov	x13, x10
    402053f8:	3940094c 	ldrb	w12, [x10, #2]
    402053fc:	3940054b 	ldrb	w11, [x10, #1]
    40205400:	38404dae 	ldrb	w14, [x13, #4]!
    40205404:	394009af 	ldrb	w15, [x13, #2]
    40205408:	39400150 	ldrb	w16, [x10]
    4020540c:	39400d51 	ldrb	w17, [x10, #3]
    40205410:	d370bd8c 	lsl	x12, x12, #16
    40205414:	39401552 	ldrb	w18, [x10, #5]
    40205418:	39400dad 	ldrb	w13, [x13, #3]
    4020541c:	53103def 	lsl	w15, w15, #16
    40205420:	aa0b220b 	orr	x11, x16, x11, lsl #8
    40205424:	aa11618c 	orr	x12, x12, x17, lsl #24
    40205428:	b1002108 	adds	x8, x8, #0x8
    4020542c:	2a1221ce 	orr	w14, w14, w18, lsl #8
    40205430:	2a0d61ed 	orr	w13, w15, w13, lsl #24
    40205434:	9100214a 	add	x10, x10, #0x8
    40205438:	aa0b018b 	orr	x11, x12, x11
    4020543c:	2a0e01ac 	orr	w12, w13, w14
    40205440:	aa0c816b 	orr	x11, x11, x12, lsl #32
    40205444:	9e670166 	fmov	d6, x11
    40205448:	0e2234c6 	cmgt	v6.8b, v6.8b, v2.8b
    4020544c:	2f08a4c6 	uxtl	v6.8h, v6.8b
    40205450:	6f10a4c7 	uxtl2	v7.4s, v6.8h
    40205454:	2f10a4c6 	uxtl	v6.4s, v6.4h
    40205458:	6f20a4f0 	uxtl2	v16.2d, v7.4s
    4020545c:	2f20a4d1 	uxtl	v17.2d, v6.2s
    40205460:	6f20a4c6 	uxtl2	v6.2d, v6.4s
    40205464:	2f20a4e7 	uxtl	v7.2d, v7.2s
    40205468:	4e251e10 	and	v16.16b, v16.16b, v5.16b
    4020546c:	4e251e31 	and	v17.16b, v17.16b, v5.16b
    40205470:	4e251cc6 	and	v6.16b, v6.16b, v5.16b
    40205474:	4e251ce7 	and	v7.16b, v7.16b, v5.16b
    40205478:	4ef08484 	add	v4.2d, v4.2d, v16.2d
    4020547c:	4ee68463 	add	v3.2d, v3.2d, v6.2d
    40205480:	4ef18400 	add	v0.2d, v0.2d, v17.2d
    40205484:	4ee78421 	add	v1.2d, v1.2d, v7.2d
    40205488:	54fffb61 	b.ne	402053f4 <core::str::count::do_count_chars+0x6c8>  // b.any
    4020548c:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    40205490:	4ee48461 	add	v1.2d, v3.2d, v4.2d
    40205494:	eb09003f 	cmp	x1, x9
    40205498:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    4020549c:	5ef1b800 	addp	d0, v0.2d
    402054a0:	9e660008 	fmov	x8, d0
    402054a4:	54ffcc80 	b.eq	40204e34 <core::str::count::do_count_chars+0x108>  // b.none
    402054a8:	cb09002a 	sub	x10, x1, x9
    402054ac:	8b090009 	add	x9, x0, x9
    402054b0:	38c0152b 	ldrsb	w11, [x9], #1
    402054b4:	3101057f 	cmn	w11, #0x41
    402054b8:	9a88d508 	cinc	x8, x8, gt
    402054bc:	f100054a 	subs	x10, x10, #0x1
    402054c0:	54ffff81 	b.ne	402054b0 <core::str::count::do_count_chars+0x784>  // b.any
    402054c4:	17fffe5c 	b	40204e34 <core::str::count::do_count_chars+0x108>

00000000402054c8 <core::panicking::panic_const::panic_const_div_by_zero>:
    402054c8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    402054cc:	910003fd 	mov	x29, sp
    402054d0:	aa0003e2 	mov	x2, x0
    402054d4:	d503201f 	nop
    402054d8:	10006240 	adr	x0, 40206120 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.17586484101796375430+0xf8>
    402054dc:	52800661 	mov	w1, #0x33                  	// #51
    402054e0:	97fffe09 	bl	40204d04 <core::panicking::panic_fmt>

00000000402054e4 <core::panicking::panic_const::panic_const_rem_by_zero>:
    402054e4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    402054e8:	910003fd 	mov	x29, sp
    402054ec:	aa0003e2 	mov	x2, x0
    402054f0:	d503201f 	nop
    402054f4:	30006220 	adr	x0, 40206139 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.17586484101796375430+0x111>
    402054f8:	52800e61 	mov	w1, #0x73                  	// #115
    402054fc:	97fffe02 	bl	40204d04 <core::panicking::panic_fmt>

0000000040205500 <<core::fmt::Formatter>::pad_integral::write_prefix>:
    40205500:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40205504:	a90157f6 	stp	x22, x21, [sp, #16]
    40205508:	a9024ff4 	stp	x20, x19, [sp, #32]
    4020550c:	910003fd 	mov	x29, sp
    40205510:	aa0403f3 	mov	x19, x4
    40205514:	aa0303f4 	mov	x20, x3
    40205518:	aa0103f5 	mov	x21, x1
    4020551c:	7144405f 	cmp	w2, #0x110, lsl #12
    40205520:	540001a0 	b.eq	40205554 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>  // b.none
    40205524:	f94012a8 	ldr	x8, [x21, #32]
    40205528:	2a0203e1 	mov	w1, w2
    4020552c:	aa0003f6 	mov	x22, x0
    40205530:	d63f0100 	blr	x8
    40205534:	2a0003e8 	mov	w8, w0
    40205538:	aa1603e0 	mov	x0, x22
    4020553c:	360000c8 	tbz	w8, #0, 40205554 <<core::fmt::Formatter>::pad_integral::write_prefix+0x54>
    40205540:	52800020 	mov	w0, #0x1                   	// #1
    40205544:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40205548:	a94157f6 	ldp	x22, x21, [sp, #16]
    4020554c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40205550:	d65f03c0 	ret
    40205554:	b4000114 	cbz	x20, 40205574 <<core::fmt::Formatter>::pad_integral::write_prefix+0x74>
    40205558:	f9400ea3 	ldr	x3, [x21, #24]
    4020555c:	aa1403e1 	mov	x1, x20
    40205560:	aa1303e2 	mov	x2, x19
    40205564:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40205568:	a94157f6 	ldp	x22, x21, [sp, #16]
    4020556c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40205570:	d61f0060 	br	x3
    40205574:	2a1f03e0 	mov	w0, wzr
    40205578:	a9424ff4 	ldp	x20, x19, [sp, #32]
    4020557c:	a94157f6 	ldp	x22, x21, [sp, #16]
    40205580:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40205584:	d65f03c0 	ret

0000000040205588 <<u64 as core::fmt::Display>::fmt>:
    40205588:	d100c3ff 	sub	sp, sp, #0x30
    4020558c:	a9027bfd 	stp	x29, x30, [sp, #32]
    40205590:	910083fd 	add	x29, sp, #0x20
    40205594:	f9400009 	ldr	x9, [x0]
    40205598:	d503201f 	nop
    4020559c:	100055e8 	adr	x8, 40206058 <anon.2d5d436b87d2a0d6f444a14986a49844.8.llvm.17586484101796375430+0x30>
    402055a0:	f10fa13f 	cmp	x9, #0x3e8
    402055a4:	540004e3 	b.cc	40205640 <<u64 as core::fmt::Display>::fmt+0xb8>  // b.lo, b.ul, b.last
    402055a8:	d28b296c 	mov	x12, #0x594b                	// #22859
    402055ac:	910033ea 	add	x10, sp, #0xc
    402055b0:	5292cff1 	mov	w17, #0x967f                	// #38527
    402055b4:	f2a710cc 	movk	x12, #0x3886, lsl #16
    402055b8:	9280026b 	mov	x11, #0xffffffffffffffec    	// #-20
    402055bc:	5284e20d 	mov	w13, #0x2710                	// #10000
    402055c0:	f2d8bacc 	movk	x12, #0xc5d6, lsl #32
    402055c4:	52828f6e 	mov	w14, #0x147b                	// #5243
    402055c8:	91004d4f 	add	x15, x10, #0x13
    402055cc:	f2e68dac 	movk	x12, #0x346d, lsl #48
    402055d0:	52800c90 	mov	w16, #0x64                  	// #100
    402055d4:	72a01311 	movk	w17, #0x98, lsl #16
    402055d8:	aa0903ea 	mov	x10, x9
    402055dc:	aa0a03f2 	mov	x18, x10
    402055e0:	9bcc7d4a 	umulh	x10, x10, x12
    402055e4:	9100116b 	add	x11, x11, #0x4
    402055e8:	eb11025f 	cmp	x18, x17
    402055ec:	d34bfd4a 	lsr	x10, x10, #11
    402055f0:	1b0dc940 	msub	w0, w10, w13, w18
    402055f4:	53023c02 	ubfx	w2, w0, #2, #14
    402055f8:	1b0e7c42 	mul	w2, w2, w14
    402055fc:	53117c42 	lsr	w2, w2, #17
    40205600:	1b108040 	msub	w0, w2, w16, w0
    40205604:	8b224502 	add	x2, x8, w2, uxtw #1
    40205608:	39400043 	ldrb	w3, [x2]
    4020560c:	39400442 	ldrb	w2, [x2, #1]
    40205610:	8b202500 	add	x0, x8, w0, uxth #1
    40205614:	381fd1e3 	sturb	w3, [x15, #-3]
    40205618:	39400003 	ldrb	w3, [x0]
    4020561c:	39400400 	ldrb	w0, [x0, #1]
    40205620:	381fe1e2 	sturb	w2, [x15, #-2]
    40205624:	381ff1e3 	sturb	w3, [x15, #-1]
    40205628:	381fc5e0 	strb	w0, [x15], #-4
    4020562c:	54fffd88 	b.hi	402055dc <<u64 as core::fmt::Display>::fmt+0x54>  // b.pmore
    40205630:	cb0b03eb 	neg	x11, x11
    40205634:	f100255f 	cmp	x10, #0x9
    40205638:	540000c8 	b.hi	40205650 <<u64 as core::fmt::Display>::fmt+0xc8>  // b.pmore
    4020563c:	14000015 	b	40205690 <<u64 as core::fmt::Display>::fmt+0x108>
    40205640:	5280028b 	mov	w11, #0x14                  	// #20
    40205644:	aa0903ea 	mov	x10, x9
    40205648:	f100253f 	cmp	x9, #0x9
    4020564c:	54000229 	b.ls	40205690 <<u64 as core::fmt::Display>::fmt+0x108>  // b.plast
    40205650:	53023d4c 	ubfx	w12, w10, #2, #14
    40205654:	52828f6d 	mov	w13, #0x147b                	// #5243
    40205658:	910033ef 	add	x15, sp, #0xc
    4020565c:	1b0d7d8c 	mul	w12, w12, w13
    40205660:	52800c8d 	mov	w13, #0x64                  	// #100
    40205664:	53117d8c 	lsr	w12, w12, #17
    40205668:	1b0da98a 	msub	w10, w12, w13, w10
    4020566c:	d100096d 	sub	x13, x11, #0x2
    40205670:	8b0b01eb 	add	x11, x15, x11
    40205674:	8b2a250a 	add	x10, x8, w10, uxth #1
    40205678:	3940014e 	ldrb	w14, [x10]
    4020567c:	3940054a 	ldrb	w10, [x10, #1]
    40205680:	382d69ee 	strb	w14, [x15, x13]
    40205684:	381ff16a 	sturb	w10, [x11, #-1]
    40205688:	aa0c03ea 	mov	x10, x12
    4020568c:	aa0d03eb 	mov	x11, x13
    40205690:	b4000049 	cbz	x9, 40205698 <<u64 as core::fmt::Display>::fmt+0x110>
    40205694:	b40000ca 	cbz	x10, 402056ac <<u64 as core::fmt::Display>::fmt+0x124>
    40205698:	8b0a0508 	add	x8, x8, x10, lsl #1
    4020569c:	d100056b 	sub	x11, x11, #0x1
    402056a0:	910033e9 	add	x9, sp, #0xc
    402056a4:	39400508 	ldrb	w8, [x8, #1]
    402056a8:	382b6928 	strb	w8, [x9, x11]
    402056ac:	52800288 	mov	w8, #0x14                  	// #20
    402056b0:	aa0103e0 	mov	x0, x1
    402056b4:	52800021 	mov	w1, #0x1                   	// #1
    402056b8:	cb0b0105 	sub	x5, x8, x11
    402056bc:	910033e8 	add	x8, sp, #0xc
    402056c0:	52800022 	mov	w2, #0x1                   	// #1
    402056c4:	8b0b0104 	add	x4, x8, x11
    402056c8:	aa1f03e3 	mov	x3, xzr
    402056cc:	97fffc5a 	bl	40204834 <<core::fmt::Formatter>::pad_integral>
    402056d0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    402056d4:	9100c3ff 	add	sp, sp, #0x30
    402056d8:	d65f03c0 	ret

00000000402056dc <__udivti3>:
    402056dc:	d100c3ff 	sub	sp, sp, #0x30
    402056e0:	a9027bfd 	stp	x29, x30, [sp, #32]
    402056e4:	910083fd 	add	x29, sp, #0x20
    402056e8:	910003e8 	mov	x8, sp
    402056ec:	94000005 	bl	40205700 <compiler_builtins::int::specialized_div_rem::u128_div_rem>
    402056f0:	a94007e0 	ldp	x0, x1, [sp]
    402056f4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    402056f8:	9100c3ff 	add	sp, sp, #0x30
    402056fc:	d65f03c0 	ret

0000000040205700 <compiler_builtins::int::specialized_div_rem::u128_div_rem>:
    40205700:	dac01049 	clz	x9, x2
    40205704:	dac0106a 	clz	x10, x3
    40205708:	f100007f 	cmp	x3, #0x0
    4020570c:	11010129 	add	w9, w9, #0x40
    40205710:	dac0100c 	clz	x12, x0
    40205714:	1a89114b 	csel	w11, w10, w9, ne  // ne = any
    40205718:	dac01029 	clz	x9, x1
    4020571c:	1101018a 	add	w10, w12, #0x40
    40205720:	f100003f 	cmp	x1, #0x0
    40205724:	1a8a112f 	csel	w15, w9, w10, ne  // ne = any
    40205728:	6b0f0169 	subs	w9, w11, w15
    4020572c:	54000149 	b.ls	40205754 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x54>  // b.plast
    40205730:	7100fdff 	cmp	w15, #0x3f
    40205734:	540001c9 	b.ls	4020576c <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x6c>  // b.plast
    40205738:	9ac20809 	udiv	x9, x0, x2
    4020573c:	aa1f03ea 	mov	x10, xzr
    40205740:	aa1f03e1 	mov	x1, xzr
    40205744:	9b028120 	msub	x0, x9, x2, x0
    40205748:	a9002909 	stp	x9, x10, [x8]
    4020574c:	a9010500 	stp	x0, x1, [x8, #16]
    40205750:	d65f03c0 	ret
    40205754:	eb02001f 	cmp	x0, x2
    40205758:	fa03003f 	sbcs	xzr, x1, x3
    4020575c:	54000282 	b.cs	402057ac <compiler_builtins::int::specialized_div_rem::u128_div_rem+0xac>  // b.hs, b.nlast
    40205760:	a9007d1f 	stp	xzr, xzr, [x8]
    40205764:	a9010500 	stp	x0, x1, [x8, #16]
    40205768:	d65f03c0 	ret
    4020576c:	71017d7f 	cmp	w11, #0x5f
    40205770:	540002a9 	b.ls	402057c4 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0xc4>  // b.plast
    40205774:	2a0203e9 	mov	w9, w2
    40205778:	9ac9082a 	udiv	x10, x1, x9
    4020577c:	1b02854b 	msub	w11, w10, w2, w1
    40205780:	93c0816b 	extr	x11, x11, x0, #32
    40205784:	9ac9096c 	udiv	x12, x11, x9
    40205788:	1b02ad8b 	msub	w11, w12, w2, w11
    4020578c:	aa4c814a 	orr	x10, x10, x12, lsr #32
    40205790:	b3607d60 	bfi	x0, x11, #32, #32
    40205794:	9ac9080b 	udiv	x11, x0, x9
    40205798:	9b098160 	msub	x0, x11, x9, x0
    4020579c:	aa0c8169 	orr	x9, x11, x12, lsl #32
    402057a0:	a9002909 	stp	x9, x10, [x8]
    402057a4:	a9017d00 	stp	x0, xzr, [x8, #16]
    402057a8:	d65f03c0 	ret
    402057ac:	eb020000 	subs	x0, x0, x2
    402057b0:	52800029 	mov	w9, #0x1                   	// #1
    402057b4:	da030021 	sbc	x1, x1, x3
    402057b8:	a9007d09 	stp	x9, xzr, [x8]
    402057bc:	a9010500 	stp	x0, x1, [x8, #16]
    402057c0:	d65f03c0 	ret
    402057c4:	7100813f 	cmp	w9, #0x20
    402057c8:	54000422 	b.cs	4020584c <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x14c>  // b.hs, b.nlast
    402057cc:	d37ff829 	lsl	x9, x1, #1
    402057d0:	5280080a 	mov	w10, #0x40                  	// #64
    402057d4:	d37ff86c 	lsl	x12, x3, #1
    402057d8:	510005eb 	sub	w11, w15, #0x1
    402057dc:	4b0f014a 	sub	w10, w10, w15
    402057e0:	9acb2129 	lsl	x9, x9, x11
    402057e4:	9aca240d 	lsr	x13, x0, x10
    402057e8:	9acb218b 	lsl	x11, x12, x11
    402057ec:	9aca244c 	lsr	x12, x2, x10
    402057f0:	9aca242e 	lsr	x14, x1, x10
    402057f4:	9aca246f 	lsr	x15, x3, x10
    402057f8:	f27a015f 	tst	x10, #0x40
    402057fc:	aa0d0129 	orr	x9, x9, x13
    40205800:	aa0c016a 	orr	x10, x11, x12
    40205804:	9a8911c9 	csel	x9, x14, x9, ne  // ne = any
    40205808:	9a8a11ea 	csel	x10, x15, x10, ne  // ne = any
    4020580c:	9aca0929 	udiv	x9, x9, x10
    40205810:	9bc97c4a 	umulh	x10, x2, x9
    40205814:	9b097c6b 	mul	x11, x3, x9
    40205818:	9bc97c6d 	umulh	x13, x3, x9
    4020581c:	9b097c4c 	mul	x12, x2, x9
    40205820:	ab0b014b 	adds	x11, x10, x11
    40205824:	9a8d35aa 	cinc	x10, x13, cs  // cs = hs, nlast
    40205828:	b500090a 	cbnz	x10, 40205948 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x248>
    4020582c:	eb0c001f 	cmp	x0, x12
    40205830:	fa0b003f 	sbcs	xzr, x1, x11
    40205834:	540008a3 	b.cc	40205948 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x248>  // b.lo, b.ul, b.last
    40205838:	eb0c0000 	subs	x0, x0, x12
    4020583c:	da0b0021 	sbc	x1, x1, x11
    40205840:	a9007d09 	stp	x9, xzr, [x8]
    40205844:	a9010500 	stp	x0, x1, [x8, #16]
    40205848:	d65f03c0 	ret
    4020584c:	52800c0d 	mov	w13, #0x60                  	// #96
    40205850:	d37ff86c 	lsl	x12, x3, #1
    40205854:	5101856e 	sub	w14, w11, #0x61
    40205858:	4b0b01ad 	sub	w13, w13, w11
    4020585c:	aa1f03e9 	mov	x9, xzr
    40205860:	aa1f03ea 	mov	x10, xzr
    40205864:	9ace218e 	lsl	x14, x12, x14
    40205868:	9acd2450 	lsr	x16, x2, x13
    4020586c:	9acd2471 	lsr	x17, x3, x13
    40205870:	f27a01bf 	tst	x13, #0x40
    40205874:	aa1001ce 	orr	x14, x14, x16
    40205878:	52800810 	mov	w16, #0x40                  	// #64
    4020587c:	9a8e122e 	csel	x14, x17, x14, ne  // ne = any
    40205880:	2a0e03ee 	mov	w14, w14
    40205884:	910005ce 	add	x14, x14, #0x1
    40205888:	d37ff832 	lsl	x18, x1, #1
    4020588c:	4b0f0211 	sub	w17, w16, w15
    40205890:	510005ef 	sub	w15, w15, #0x1
    40205894:	9ad12424 	lsr	x4, x1, x17
    40205898:	f27a023f 	tst	x17, #0x40
    4020589c:	9acf224f 	lsl	x15, x18, x15
    402058a0:	9ad12412 	lsr	x18, x0, x17
    402058a4:	aa1201ef 	orr	x15, x15, x18
    402058a8:	9a8f1092 	csel	x18, x4, x15, ne  // ne = any
    402058ac:	6b0d022f 	subs	w15, w17, w13
    402058b0:	540005c3 	b.cc	40205968 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x268>  // b.lo, b.ul, b.last
    402058b4:	9ace0a51 	udiv	x17, x18, x14
    402058b8:	2a2f03e6 	mvn	w6, w15
    402058bc:	f27a01ff 	tst	x15, #0x40
    402058c0:	9bd17c52 	umulh	x18, x2, x17
    402058c4:	d341fe25 	lsr	x5, x17, #1
    402058c8:	9b117c44 	mul	x4, x2, x17
    402058cc:	9ac624a5 	lsr	x5, x5, x6
    402058d0:	9b114872 	madd	x18, x3, x17, x18
    402058d4:	9acf2231 	lsl	x17, x17, x15
    402058d8:	d341fc87 	lsr	x7, x4, #1
    402058dc:	9ac624e6 	lsr	x6, x7, x6
    402058e0:	9acf2252 	lsl	x18, x18, x15
    402058e4:	9acf208f 	lsl	x15, x4, x15
    402058e8:	9a851224 	csel	x4, x17, x5, ne  // ne = any
    402058ec:	9a9113f1 	csel	x17, xzr, x17, ne  // ne = any
    402058f0:	aa060252 	orr	x18, x18, x6
    402058f4:	9a9211f2 	csel	x18, x15, x18, ne  // ne = any
    402058f8:	9a8f13ef 	csel	x15, xzr, x15, ne  // ne = any
    402058fc:	ab090229 	adds	x9, x17, x9
    40205900:	9a0a008a 	adc	x10, x4, x10
    40205904:	eb0f0000 	subs	x0, x0, x15
    40205908:	fa120021 	sbcs	x1, x1, x18
    4020590c:	dac0100f 	clz	x15, x0
    40205910:	dac01031 	clz	x17, x1
    40205914:	110101ef 	add	w15, w15, #0x40
    40205918:	1a8f122f 	csel	w15, w17, w15, ne  // ne = any
    4020591c:	6b0f017f 	cmp	w11, w15
    40205920:	54000549 	b.ls	402059c8 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x2c8>  // b.plast
    40205924:	7100fdff 	cmp	w15, #0x3f
    40205928:	54fffb09 	b.ls	40205888 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x188>  // b.plast
    4020592c:	9ac2080b 	udiv	x11, x0, x2
    40205930:	9b028160 	msub	x0, x11, x2, x0
    40205934:	ab0b0129 	adds	x9, x9, x11
    40205938:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    4020593c:	a9002909 	stp	x9, x10, [x8]
    40205940:	a9017d00 	stp	x0, xzr, [x8, #16]
    40205944:	d65f03c0 	ret
    40205948:	ab00004d 	adds	x13, x2, x0
    4020594c:	d1000529 	sub	x9, x9, #0x1
    40205950:	9a01006e 	adc	x14, x3, x1
    40205954:	eb0c01a0 	subs	x0, x13, x12
    40205958:	da0b01c1 	sbc	x1, x14, x11
    4020595c:	a9007d09 	stp	x9, xzr, [x8]
    40205960:	a9010500 	stp	x0, x1, [x8, #16]
    40205964:	d65f03c0 	ret
    40205968:	2a3103eb 	mvn	w11, w17
    4020596c:	9ad1244d 	lsr	x13, x2, x17
    40205970:	f27a023f 	tst	x17, #0x40
    40205974:	9acb218b 	lsl	x11, x12, x11
    40205978:	9ad1246c 	lsr	x12, x3, x17
    4020597c:	aa0d016b 	orr	x11, x11, x13
    40205980:	9a8b118b 	csel	x11, x12, x11, ne  // ne = any
    40205984:	9acb0a4d 	udiv	x13, x18, x11
    40205988:	9bcd7c4b 	umulh	x11, x2, x13
    4020598c:	9b0d7c4c 	mul	x12, x2, x13
    40205990:	9b0d2c6b 	madd	x11, x3, x13, x11
    40205994:	eb0c001f 	cmp	x0, x12
    40205998:	fa0b003f 	sbcs	xzr, x1, x11
    4020599c:	540002a2 	b.cs	402059f0 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x2f0>  // b.hs, b.nlast
    402059a0:	d10005ad 	sub	x13, x13, #0x1
    402059a4:	ab0d0129 	adds	x9, x9, x13
    402059a8:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    402059ac:	ab02000d 	adds	x13, x0, x2
    402059b0:	9a03002e 	adc	x14, x1, x3
    402059b4:	eb0c01a0 	subs	x0, x13, x12
    402059b8:	da0b01c1 	sbc	x1, x14, x11
    402059bc:	a9002909 	stp	x9, x10, [x8]
    402059c0:	a9010500 	stp	x0, x1, [x8, #16]
    402059c4:	d65f03c0 	ret
    402059c8:	eb02001f 	cmp	x0, x2
    402059cc:	fa03003f 	sbcs	xzr, x1, x3
    402059d0:	54ffebc3 	b.cc	40205748 <compiler_builtins::int::specialized_div_rem::u128_div_rem+0x48>  // b.lo, b.ul, b.last
    402059d4:	b1000529 	adds	x9, x9, #0x1
    402059d8:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    402059dc:	eb020000 	subs	x0, x0, x2
    402059e0:	da030021 	sbc	x1, x1, x3
    402059e4:	a9002909 	stp	x9, x10, [x8]
    402059e8:	a9010500 	stp	x0, x1, [x8, #16]
    402059ec:	d65f03c0 	ret
    402059f0:	ab0d0129 	adds	x9, x9, x13
    402059f4:	9a8a354a 	cinc	x10, x10, cs  // cs = hs, nlast
    402059f8:	eb0c0000 	subs	x0, x0, x12
    402059fc:	da0b0021 	sbc	x1, x1, x11
    40205a00:	a9002909 	stp	x9, x10, [x8]
    40205a04:	a9010500 	stp	x0, x1, [x8, #16]
    40205a08:	d65f03c0 	ret

0000000040205a0c <memcpy>:
    40205a0c:	f100405f 	cmp	x2, #0x10
    40205a10:	54000723 	b.cc	40205af4 <memcpy+0xe8>  // b.lo, b.ul, b.last
    40205a14:	cb0003ec 	neg	x12, x0
    40205a18:	92400988 	and	x8, x12, #0x7
    40205a1c:	8b080009 	add	x9, x0, x8
    40205a20:	eb09001f 	cmp	x0, x9
    40205a24:	54000422 	b.cs	40205aa8 <memcpy+0x9c>  // b.hs, b.nlast
    40205a28:	f100111f 	cmp	x8, #0x4
    40205a2c:	aa0003ea 	mov	x10, x0
    40205a30:	aa0103eb 	mov	x11, x1
    40205a34:	54000323 	b.cc	40205a98 <memcpy+0x8c>  // b.lo, b.ul, b.last
    40205a38:	cb01000a 	sub	x10, x0, x1
    40205a3c:	aa0103eb 	mov	x11, x1
    40205a40:	f100815f 	cmp	x10, #0x20
    40205a44:	aa0003ea 	mov	x10, x0
    40205a48:	54000283 	b.cc	40205a98 <memcpy+0x8c>  // b.lo, b.ul, b.last
    40205a4c:	927e018c 	and	x12, x12, #0x4
    40205a50:	aa0003ed 	mov	x13, x0
    40205a54:	aa0103ee 	mov	x14, x1
    40205a58:	8b0c000a 	add	x10, x0, x12
    40205a5c:	8b0c002b 	add	x11, x1, x12
    40205a60:	aa0c03ef 	mov	x15, x12
    40205a64:	39400dd0 	ldrb	w16, [x14, #3]
    40205a68:	394009d1 	ldrb	w17, [x14, #2]
    40205a6c:	f10011ef 	subs	x15, x15, #0x4
    40205a70:	394001d2 	ldrb	w18, [x14]
    40205a74:	394005c3 	ldrb	w3, [x14, #1]
    40205a78:	910011ce 	add	x14, x14, #0x4
    40205a7c:	39000db0 	strb	w16, [x13, #3]
    40205a80:	390009b1 	strb	w17, [x13, #2]
    40205a84:	390005a3 	strb	w3, [x13, #1]
    40205a88:	380045b2 	strb	w18, [x13], #4
    40205a8c:	54fffec1 	b.ne	40205a64 <memcpy+0x58>  // b.any
    40205a90:	eb0c011f 	cmp	x8, x12
    40205a94:	540000a0 	b.eq	40205aa8 <memcpy+0x9c>  // b.none
    40205a98:	3840156c 	ldrb	w12, [x11], #1
    40205a9c:	3800154c 	strb	w12, [x10], #1
    40205aa0:	eb09015f 	cmp	x10, x9
    40205aa4:	54ffffa1 	b.ne	40205a98 <memcpy+0x8c>  // b.any
    40205aa8:	cb08004b 	sub	x11, x2, x8
    40205aac:	8b08002a 	add	x10, x1, x8
    40205ab0:	927df16c 	and	x12, x11, #0xfffffffffffffff8
    40205ab4:	f240095f 	tst	x10, #0x7
    40205ab8:	8b0c0128 	add	x8, x9, x12
    40205abc:	540007a1 	b.ne	40205bb0 <memcpy+0x1a4>  // b.any
    40205ac0:	eb08013f 	cmp	x9, x8
    40205ac4:	540000c2 	b.cs	40205adc <memcpy+0xd0>  // b.hs, b.nlast
    40205ac8:	aa0a03ed 	mov	x13, x10
    40205acc:	f84085ae 	ldr	x14, [x13], #8
    40205ad0:	f800852e 	str	x14, [x9], #8
    40205ad4:	eb08013f 	cmp	x9, x8
    40205ad8:	54ffffa3 	b.cc	40205acc <memcpy+0xc0>  // b.lo, b.ul, b.last
    40205adc:	8b0c0141 	add	x1, x10, x12
    40205ae0:	92400962 	and	x2, x11, #0x7
    40205ae4:	8b020109 	add	x9, x8, x2
    40205ae8:	eb09011f 	cmp	x8, x9
    40205aec:	540000c3 	b.cc	40205b04 <memcpy+0xf8>  // b.lo, b.ul, b.last
    40205af0:	1400002f 	b	40205bac <memcpy+0x1a0>
    40205af4:	aa0003e8 	mov	x8, x0
    40205af8:	8b020009 	add	x9, x0, x2
    40205afc:	eb09001f 	cmp	x0, x9
    40205b00:	54000562 	b.cs	40205bac <memcpy+0x1a0>  // b.hs, b.nlast
    40205b04:	f100105f 	cmp	x2, #0x4
    40205b08:	540004a3 	b.cc	40205b9c <memcpy+0x190>  // b.lo, b.ul, b.last
    40205b0c:	cb01010a 	sub	x10, x8, x1
    40205b10:	f100815f 	cmp	x10, #0x20
    40205b14:	54000443 	b.cc	40205b9c <memcpy+0x190>  // b.lo, b.ul, b.last
    40205b18:	39400c2a 	ldrb	w10, [x1, #3]
    40205b1c:	3940082b 	ldrb	w11, [x1, #2]
    40205b20:	3940002c 	ldrb	w12, [x1]
    40205b24:	3940042d 	ldrb	w13, [x1, #1]
    40205b28:	39000d0a 	strb	w10, [x8, #3]
    40205b2c:	927e044a 	and	x10, x2, #0xc
    40205b30:	f100115f 	cmp	x10, #0x4
    40205b34:	3900090b 	strb	w11, [x8, #2]
    40205b38:	3900050d 	strb	w13, [x8, #1]
    40205b3c:	3900010c 	strb	w12, [x8]
    40205b40:	54000260 	b.eq	40205b8c <memcpy+0x180>  // b.none
    40205b44:	39401c2b 	ldrb	w11, [x1, #7]
    40205b48:	3940182c 	ldrb	w12, [x1, #6]
    40205b4c:	f100215f 	cmp	x10, #0x8
    40205b50:	3940102d 	ldrb	w13, [x1, #4]
    40205b54:	3940142e 	ldrb	w14, [x1, #5]
    40205b58:	39001d0b 	strb	w11, [x8, #7]
    40205b5c:	3900190c 	strb	w12, [x8, #6]
    40205b60:	3900150e 	strb	w14, [x8, #5]
    40205b64:	3900110d 	strb	w13, [x8, #4]
    40205b68:	54000120 	b.eq	40205b8c <memcpy+0x180>  // b.none
    40205b6c:	39402c2b 	ldrb	w11, [x1, #11]
    40205b70:	3940282c 	ldrb	w12, [x1, #10]
    40205b74:	3940202d 	ldrb	w13, [x1, #8]
    40205b78:	3940242e 	ldrb	w14, [x1, #9]
    40205b7c:	39002d0b 	strb	w11, [x8, #11]
    40205b80:	3900290c 	strb	w12, [x8, #10]
    40205b84:	3900250e 	strb	w14, [x8, #9]
    40205b88:	3900210d 	strb	w13, [x8, #8]
    40205b8c:	eb0a005f 	cmp	x2, x10
    40205b90:	540000e0 	b.eq	40205bac <memcpy+0x1a0>  // b.none
    40205b94:	8b0a0108 	add	x8, x8, x10
    40205b98:	8b0a0021 	add	x1, x1, x10
    40205b9c:	3840142a 	ldrb	w10, [x1], #1
    40205ba0:	3800150a 	strb	w10, [x8], #1
    40205ba4:	eb09011f 	cmp	x8, x9
    40205ba8:	54ffffa1 	b.ne	40205b9c <memcpy+0x190>  // b.any
    40205bac:	d65f03c0 	ret
    40205bb0:	eb08013f 	cmp	x9, x8
    40205bb4:	54fff942 	b.cs	40205adc <memcpy+0xd0>  // b.hs, b.nlast
    40205bb8:	aa0a03ed 	mov	x13, x10
    40205bbc:	aa0d03f0 	mov	x16, x13
    40205bc0:	394009af 	ldrb	w15, [x13, #2]
    40205bc4:	394005ae 	ldrb	w14, [x13, #1]
    40205bc8:	38404e11 	ldrb	w17, [x16, #4]!
    40205bcc:	39400a12 	ldrb	w18, [x16, #2]
    40205bd0:	394001a1 	ldrb	w1, [x13]
    40205bd4:	39400da2 	ldrb	w2, [x13, #3]
    40205bd8:	d370bdef 	lsl	x15, x15, #16
    40205bdc:	394015a3 	ldrb	w3, [x13, #5]
    40205be0:	39400e10 	ldrb	w16, [x16, #3]
    40205be4:	53103e52 	lsl	w18, w18, #16
    40205be8:	aa0e202e 	orr	x14, x1, x14, lsl #8
    40205bec:	aa0261ef 	orr	x15, x15, x2, lsl #24
    40205bf0:	910021ad 	add	x13, x13, #0x8
    40205bf4:	2a032231 	orr	w17, w17, w3, lsl #8
    40205bf8:	2a106250 	orr	w16, w18, w16, lsl #24
    40205bfc:	aa0e01ee 	orr	x14, x15, x14
    40205c00:	2a11020f 	orr	w15, w16, w17
    40205c04:	aa0f81ce 	orr	x14, x14, x15, lsl #32
    40205c08:	f800852e 	str	x14, [x9], #8
    40205c0c:	eb08013f 	cmp	x9, x8
    40205c10:	54fffd63 	b.cc	40205bbc <memcpy+0x1b0>  // b.lo, b.ul, b.last
    40205c14:	17ffffb2 	b	40205adc <memcpy+0xd0>

0000000040205c18 <__umodti3>:
    40205c18:	d100c3ff 	sub	sp, sp, #0x30
    40205c1c:	a9027bfd 	stp	x29, x30, [sp, #32]
    40205c20:	910083fd 	add	x29, sp, #0x20
    40205c24:	910003e8 	mov	x8, sp
    40205c28:	97fffeb6 	bl	40205700 <compiler_builtins::int::specialized_div_rem::u128_div_rem>
    40205c2c:	a94107e0 	ldp	x0, x1, [sp, #16]
    40205c30:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40205c34:	9100c3ff 	add	sp, sp, #0x30
    40205c38:	d65f03c0 	ret

0000000040205c3c <memset>:
    40205c3c:	f100405f 	cmp	x2, #0x10
    40205c40:	540009e3 	b.cc	40205d7c <memset+0x140>  // b.lo, b.ul, b.last
    40205c44:	cb0003eb 	neg	x11, x0
    40205c48:	92400968 	and	x8, x11, #0x7
    40205c4c:	8b080009 	add	x9, x0, x8
    40205c50:	eb09001f 	cmp	x0, x9
    40205c54:	54000302 	b.cs	40205cb4 <memset+0x78>  // b.hs, b.nlast
    40205c58:	f100111f 	cmp	x8, #0x4
    40205c5c:	aa0003ea 	mov	x10, x0
    40205c60:	54000243 	b.cc	40205ca8 <memset+0x6c>  // b.lo, b.ul, b.last
    40205c64:	0e020c20 	dup	v0.4h, w1
    40205c68:	927e016b 	and	x11, x11, #0x4
    40205c6c:	aa0003ec 	mov	x12, x0
    40205c70:	8b0b000a 	add	x10, x0, x11
    40205c74:	aa0b03ed 	mov	x13, x11
    40205c78:	5e0e0401 	mov	h1, v0.h[3]
    40205c7c:	5e0a0402 	mov	h2, v0.h[2]
    40205c80:	5e060403 	mov	h3, v0.h[1]
    40205c84:	3d000180 	str	b0, [x12]
    40205c88:	f10011ad 	subs	x13, x13, #0x4
    40205c8c:	3c003181 	stur	b1, [x12, #3]
    40205c90:	3c002182 	stur	b2, [x12, #2]
    40205c94:	3c001183 	stur	b3, [x12, #1]
    40205c98:	9100118c 	add	x12, x12, #0x4
    40205c9c:	54ffff41 	b.ne	40205c84 <memset+0x48>  // b.any
    40205ca0:	eb0b011f 	cmp	x8, x11
    40205ca4:	54000080 	b.eq	40205cb4 <memset+0x78>  // b.none
    40205ca8:	38001541 	strb	w1, [x10], #1
    40205cac:	eb09015f 	cmp	x10, x9
    40205cb0:	54ffffc1 	b.ne	40205ca8 <memset+0x6c>  // b.any
    40205cb4:	cb08004a 	sub	x10, x2, x8
    40205cb8:	927df148 	and	x8, x10, #0xfffffffffffffff8
    40205cbc:	8b080128 	add	x8, x9, x8
    40205cc0:	eb08013f 	cmp	x9, x8
    40205cc4:	54000102 	b.cs	40205ce4 <memset+0xa8>  // b.hs, b.nlast
    40205cc8:	12001c2b 	and	w11, w1, #0xff
    40205ccc:	3200c3ec 	mov	w12, #0x1010101             	// #16843009
    40205cd0:	1b0c7d6b 	mul	w11, w11, w12
    40205cd4:	aa0b816b 	orr	x11, x11, x11, lsl #32
    40205cd8:	f800852b 	str	x11, [x9], #8
    40205cdc:	eb08013f 	cmp	x9, x8
    40205ce0:	54ffffc3 	b.cc	40205cd8 <memset+0x9c>  // b.lo, b.ul, b.last
    40205ce4:	92400942 	and	x2, x10, #0x7
    40205ce8:	8b020109 	add	x9, x8, x2
    40205cec:	eb09011f 	cmp	x8, x9
    40205cf0:	54000442 	b.cs	40205d78 <memset+0x13c>  // b.hs, b.nlast
    40205cf4:	f100105f 	cmp	x2, #0x4
    40205cf8:	540003a3 	b.cc	40205d6c <memset+0x130>  // b.lo, b.ul, b.last
    40205cfc:	927e044a 	and	x10, x2, #0xc
    40205d00:	39000d01 	strb	w1, [x8, #3]
    40205d04:	f100115f 	cmp	x10, #0x4
    40205d08:	8b0a010b 	add	x11, x8, x10
    40205d0c:	39000901 	strb	w1, [x8, #2]
    40205d10:	39000501 	strb	w1, [x8, #1]
    40205d14:	39000101 	strb	w1, [x8]
    40205d18:	54000240 	b.eq	40205d60 <memset+0x124>  // b.none
    40205d1c:	0e020c20 	dup	v0.4h, w1
    40205d20:	f100215f 	cmp	x10, #0x8
    40205d24:	5e0e0401 	mov	h1, v0.h[3]
    40205d28:	5e0a0402 	mov	h2, v0.h[2]
    40205d2c:	5e060403 	mov	h3, v0.h[1]
    40205d30:	3c004100 	stur	b0, [x8, #4]
    40205d34:	3c007101 	stur	b1, [x8, #7]
    40205d38:	3c006102 	stur	b2, [x8, #6]
    40205d3c:	3c005103 	stur	b3, [x8, #5]
    40205d40:	54000100 	b.eq	40205d60 <memset+0x124>  // b.none
    40205d44:	5e0e0401 	mov	h1, v0.h[3]
    40205d48:	5e0a0402 	mov	h2, v0.h[2]
    40205d4c:	3c008100 	stur	b0, [x8, #8]
    40205d50:	5e060403 	mov	h3, v0.h[1]
    40205d54:	3c00b101 	stur	b1, [x8, #11]
    40205d58:	3c00a102 	stur	b2, [x8, #10]
    40205d5c:	3c009103 	stur	b3, [x8, #9]
    40205d60:	eb0a005f 	cmp	x2, x10
    40205d64:	aa0b03e8 	mov	x8, x11
    40205d68:	54000080 	b.eq	40205d78 <memset+0x13c>  // b.none
    40205d6c:	38001501 	strb	w1, [x8], #1
    40205d70:	eb09011f 	cmp	x8, x9
    40205d74:	54ffffc1 	b.ne	40205d6c <memset+0x130>  // b.any
    40205d78:	d65f03c0 	ret
    40205d7c:	aa0003e8 	mov	x8, x0
    40205d80:	8b020009 	add	x9, x0, x2
    40205d84:	eb09001f 	cmp	x0, x9
    40205d88:	54fffb63 	b.cc	40205cf4 <memset+0xb8>  // b.lo, b.ul, b.last
    40205d8c:	17fffffb 	b	40205d78 <memset+0x13c>
