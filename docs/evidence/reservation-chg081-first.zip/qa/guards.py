from pathlib import Path
import json,collections
H=Path('/tmp')/('jnox-chg081-efabd263-first-'+__import__('sys').argv[1])
for p in sorted(H.glob('[0-9]*')):
 r=json.loads((p/'audit.json').read_text());z=r['terminal'];mask=r['mask'];a=r['independent']
 gs={'source IRQ and timer identity':'passed' if mask&1 else 'unobserved','live idle/worker frames, ledger eligibility and destination configuration':'passed' if mask&2 else 'unobserved','precommit time bound':'passed' if mask&4 else ('failed' if mask==3 and z[4:6]==[2,5] else 'unobserved'),'authority write/readback and observed owner':'passed' if mask&4 else 'unobserved','postcommit time bound':'passed' if mask&8 else ('failed' if mask==7 and z[4:6]==[2,5] else 'unobserved'),'cutoff CVAL and CTL readback':'passed' if mask&8 else 'unobserved','planned/selected time bound':'passed' if mask&16 else ('failed; identical terminal format for planned or selection sample; exact subguard unobserved' if mask==15 and z[4:6]==[2,5] else 'unobserved'),'first actual worker return':'observed' if r['actual_return'] else 'unobserved','first worker opening bound':'passed' if r['first_service'] and a['first_offset']<=62500 else ('failed' if r['first_service'] else 'unobserved')}
 r['guard_evidence']=gs;(p/'audit.json').write_text(json.dumps(r,indent=2))
