from pathlib import Path
import sys,tarfile,subprocess as sp,os,shutil
d=Path(__file__).resolve().parent
for tree,rev in [('parent','aacdbebe958feca152b358ce8cf36033cd7d6749'),('source','efabd263c24a8ad8bd71c614ccfd2f437020ff81')]:
 s=d/tree
 if not s.exists():
  sp.run(['git','-C','D:/codex/.jnox-work/next-fixed/reservation-stage-v3-first/pins','archive','--output',str(d/(tree+'.tar')),rev,'kernel','tools'],check=True)
  s.mkdir(); sp.run(['tar','-xf',str(d/(tree+'.tar')),'-C',str(s)],check=True)
 for case,app in [('W','aligned-wake'),('S','cbs-saturated')]:
  for stage in sys.argv[1]:

   label=tree+'-'+case+stage
   target=d/('target-'+label)
   env={k:v for k,v in os.environ.items() if not k.startswith(('JNOX_','RUST','CARGO_'))}
   env.update(JNOX_BOARD='virt',JNOX_PROFILE='reservation',JNOX_APP=app,CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR=str(target))
   if stage!='B':env['JNOX_RESERVATION_STAGE']={'E':'eoi','F':'frames'}[stage]
   with open(d/(label+'.log'),'xb') as log:sp.run(['cargo','+1.95.0','build','--locked','--release','-j1','-vv'],cwd=s/'kernel',env=env,stdout=log,stderr=sp.STDOUT,check=True)
   shutil.copyfile(target/'aarch64-unknown-none/release/jnox-kernel',d/(label+'.elf'))



