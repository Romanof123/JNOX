from pathlib import Path
import hashlib,json,sys,shutil,traceback
D=Path(__file__).parent;H=Path('/tmp')/('jnox-chg081-efabd263-first-'+__import__('sys').argv[1])
sys.path.insert(0,str(D/'source/tools'))
from reservation_stage import replay as stage,Launch
from audit import compact,oracle
def run(p):
 m=json.loads((p/'meta.json').read_text());l=Launch(**m['launch'])
 raw=(p/'uart').read_bytes(); result=stage(raw,(p/'kernel.elf').read_bytes(),l)
 proj=H/'derived'/p.name;proj.mkdir(parents=True,exist_ok=True)
 lines=raw.splitlines(); parsed=[list(map(int,x.split())) for x in lines[3:-1]];rr=[r for r in parsed if r[0]!=38]
 (proj/'uart').write_bytes(b'\n'.join([*lines[:2],b'RSRV RAW 3',*(x for x,r in zip(lines[3:-1],parsed) if r[0]!=38),lines[-1]])+b'\n')
 for name in ['kernel.elf','exceptions.log']:
  if (p/name).exists() and not (proj/name).exists():(proj/name).symlink_to(p/name)
 aud=compact(proj,l.selector,rr)
 result['independent']=aud
 result['period_service']={}
 for g in aud['grants']:
  i=g['owner'];key=f"{i}-{oracle(l.selector)[g['slot']]['alloc'][i][3]}"
  result['period_service'].setdefault(key,[]).append([g['slot'],g['upper'],g['allocation_upper']])
 return result
for p in sorted(H.glob('[0-9]*')):
 if not (p/'meta.json').exists():continue
 try:r=run(p)
 except Exception:r={'error':traceback.format_exc()}
 (p/'audit.json').write_text(json.dumps(r,indent=2))
 print(p.name, r.get('error',r.get('terminal')),r.get('whole'),r.get('prefix'),r.get('suffix'))
