import os,json,subprocess as sp,shutil,time
from pathlib import Path
import hashlib
d=Path.cwd(); base=Path('/tmp/jnox-chg081-controls-efabd263');base.mkdir()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((d/'control-elfs.json').read_text())
for app,digest in frozen.items():
 folder=base/app;folder.mkdir();elf=folder/'kernel.elf';shutil.copy2(d/('control-'+app+'.elf'),elf);assert h(elf)==digest
 args=['timeout','15s','/usr/bin/qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','stdio','-kernel',str(elf)]
 if not app.endswith('refused'): args+=['-d','int','-D',str(folder/'exceptions.log')]
 meta=dict(argv=args,elf_sha256=digest,utc=time.time(),load=os.getloadavg())
 with (folder/'uart').open('xb') as out,(folder/'stderr').open('xb') as err:meta['returncode']=sp.run(args,stdout=out,stderr=err).returncode
 meta['hashes']={p.name:h(p) for p in folder.iterdir()};(folder/'metadata.json').write_text(json.dumps(meta,indent=2));shutil.copytree(folder,d/'controls'/app)
 print(app,(folder/'uart').read_bytes()[-110:],flush=True)
