import json,collections
from pathlib import Path
j=lambda p:json.loads(Path(p).read_bytes())
out={}
for role in ['parent','source']:
 out[role]={}
 for stratum in 'WS':
  records={s:[j(p/'audit.json') for p in sorted(Path('raw-'+role).glob('*'+stratum+s))] for s in 'BEF'}
  def disp(a):return (a['terminal'][4:6],a['mask'])
  def ran(rs):return [min(rs),max(rs)] if rs else None
  for site in 'EF':
   data=records[site];assert len(data)==2
   base=records['B'];ticks=[a['whole'] for a in data if a['whole'] is not None];bticks=[a['whole'] for a in base if a['whole'] is not None]
   pred=(len(ticks)==2 and all(a['prefix']*2>a['whole'] for a in data));suf=(len(ticks)==2 and all(a['suffix']*2>a['whole'] for a in data))
   # Both the distribution and reached stage must match before applying an observed split to the baseline.
   consistent=len({str(disp(a)) for a in data+base})==1
   overlap=bool(ticks and bticks and max(ticks)>=min(bticks) and max(bticks)>=min(ticks))
   out[role][stratum+site]=dict(prefixes=[a['prefix'] for a in data],suffixes=[a['suffix'] for a in data],wholes=ticks,baseline_wholes=bticks,local_majority='prefix' if pred else 'suffix' if suf else None,range_overlap=overlap,all_reached_same_stage=consistent,baseline_attribution='unresolved' if not (consistent and overlap and len(ticks)==len(bticks)==2) else 'only a follow-up hypothesis')
print(json.dumps(out,indent=2))
