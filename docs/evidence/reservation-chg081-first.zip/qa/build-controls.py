from pathlib import Path
import shutil,subprocess as sp,os,json,hashlib
d=Path.cwd(); cases='aligned-refused cbs-refused aligned-late cbs-late aligned-saturated cbs-wake'.split()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
out={}
for case in cases:
 target=d/('target-control-'+case);env={k:v for k,v in os.environ.items() if not k.startswith(('JNOX_','RUST','CARGO_'))}
 env.update(JNOX_BOARD='virt',JNOX_PROFILE='reservation',JNOX_APP=case,CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR=str(target))
 with (d/('control-'+case+'.log')).open('xb') as log:sp.run(['cargo','+1.95.0','build','--locked','--release','-j1','-vv'],cwd=d/'source/kernel',env=env,stdout=log,stderr=sp.STDOUT,check=True)
 p=d/('control-'+case+'.elf');shutil.copyfile(target/'aarch64-unknown-none/release/jnox-kernel',p);out[case]=h(p)
(d/'control-elfs.json').write_text(json.dumps(out,indent=2))
