from pathlib import Path
import sys,hashlib,json
from dataclasses import replace
sys.path.insert(0,'source/tools')
from reservation_stage import replay,Launch
p=Path('raw-source/02-WE');raw=(p/'uart').read_bytes();elf=(p/'kernel.elf').read_bytes();l=Launch(**json.loads((p/'launch.json').read_text()));h=lambda b:hashlib.sha256(b).hexdigest()
probe=next(x for x in raw.splitlines(keepends=True) if x.startswith(b'38 '));modified=raw.replace(probe,b'').replace(b'RSRV END',probe+b'RSRV END')
out={}
for key,data,desc in [('elf-digest',raw,replace(l,elf_sha256='0'*64)),('uart-digest',raw,replace(l,uart_sha256='0'*64)),('duplicate',raw.replace(probe,probe*2),None),('missing',raw.replace(probe,b''),None),('misordered',modified,None),('wrong-site',raw,replace(l,counter_pc=l.counter_pc-4))]:
 try:replay(data,elf,desc or replace(l,uart_sha256=h(data)))
 except ValueError as e:out[key]=str(e)
 else:raise AssertionError(key)
print(json.dumps(out,indent=2))
