from pathlib import Path
import json
from audit import compact
from ledger import analyze
out={}
for d in sorted(Path('controls').iterdir()):
 app=d.name;raw=(d/'uart').read_text().splitlines()
 assert raw[-1]=='RSRV END';rows=[list(map(int,l.split())) for l in raw[3:-1]];z=rows[-1]
 if 'refused' in app:
  a=analyze(d,app); assert z[4:]==[1,2,9,8] and not a['grants'];verdict='expected admission refusal'
 elif 'late' in app:
  a=analyze(d,app);o=a.get('overrun');verdict='late enforcement demonstrated' if o and o['fixture_valid'] and z[4:6]==[2,1] else 'first stop before qualifying late-enforcement verdict'
 else:
  a=compact(d,app,rows);verdict='horizon completed' if z[4:6]==[0,0] else 'first timing stop'
 out[app]=dict(terminal=z,verdict=verdict,grants=a['grants'],return_count=a['returns'],overrun=a.get('overrun'),traces=a['traces'])
print(json.dumps(out,indent=2))
