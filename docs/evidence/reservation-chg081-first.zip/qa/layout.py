from pathlib import Path
import re,json
r={}
for a in Path('.').glob('*-??.asm'):
 if not a.stem.startswith(('parent-','source-')):continue
 base=a.with_suffix('.map').read_text(); asm=a.read_text(); measures={}
 for m in re.finditer(r'(?m)^\s*(\w+) <jnox_kernel::ordinary_reservations::([^>]+)>:\n(.*?)(?=\n\n|\Z)',asm,re.S):
  fun=m[2]
  if fun not in ['irq','svc','Runtime::open','Runtime::prepare_first','Runtime::retire','snapshot']:continue
  ops=re.findall(r'(?m)^\s*[0-9a-f]+:\s+[0-9a-f]{8}\s+(\S+)',m[3])
  measures[fun]=dict(start=m[1],instructions=len(ops),load_instructions=sum(op.startswith('ld') for op in ops),branches=sum(op in ('b','bl','blr','br','ret','eret') or op.startswith(('b.','cb','tb')) for op in ops))
 r[a.stem]=dict(sections={m[1]:int(m[2],16) for m in re.finditer(r'\[\s*\d+\]\s+\.(text|rodata|bss|data|stack)\s+\S+\s+\w+\s+\w+\s+(\w+)',base)},functions=measures)
print(json.dumps(r,indent=2))
