from pathlib import Path
import json,hashlib
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for role in ['parent','source']:
 n=Path('/tmp')/('jnox-chg081-efabd263-first-'+role)
 for p in sorted(n.glob('[0-9]*')):
  cp=Path('raw-'+role)/p.name
  for k in ('kernel.elf','uart','stderr','launch.json','meta.json','audit.json','exceptions.log'):
   if (p/k).exists():assert H(p/k)==H(cp/k);rows.append((role,p.name,k,H(p/k)))
for p in sorted(Path('/tmp/jnox-chg081-controls-efabd263').iterdir()):
 for f in p.iterdir():assert H(f)==H(Path('controls')/p.name/f.name);rows.append(('control',p.name,f.name,H(f)))
print(json.dumps(rows,indent=2))
