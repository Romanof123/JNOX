from pathlib import Path
import re,hashlib,json,struct,collections
def loads(p):
 b=p.read_bytes();o=struct.unpack_from('<Q',b,32)[0];size,n=struct.unpack_from('<HH',b,54);out=[]
 for i in range(n):
  h=struct.unpack_from('<IIQQQQQQ',b,o+i*size)
  if h[0]==1:out.append((h,b[h[2]:h[2]+h[5]]))
 return out
v=Path('../reservation-stage-v3-first')
r={}
for a in 'WS':
 for s in 'BEF':
  tag=a+s;p=Path('parent-'+tag+'.elf');c=Path('source-'+tag+'.elf')
  assert loads(p)==loads(v/('candidate-'+tag+'.elf')),tag
  if s=='B':assert loads(p)==loads(v/('reference-'+a+'.elf')),tag
  for role in ['source','parent']:
   prefix=role+'-'+tag
   asm=Path(prefix+'.asm').read_text()
   ops=re.findall(r'^\s*[a-f0-9]+:\s+[a-f0-9]{8}\s+(\S+)',asm,re.M)
   mrs=asm.count('cntpct_el0')
   assert mrs==(26 if s=='B' else 27)
   if s=='E':
    assert all(re.search('^\s*'+addr+':.*'+pat,asm,re.M) for addr,pat in [('402013d4','str'),('402013e4','cbnz.*40201428'),('402013e8','dsb'),('402013ec','isb'),('402013f0','mrs.*cntpct'),('402013f4','adr.*402013f0'),('40201428','dsb')])
   if s=='F':
    isb='40201938' if role=='source' else '40201968';pc=int(isb,16)+4
    assert re.search(r'b.eq\s+'+isb,asm) and re.search(isb+':.*isb',asm) and re.search(f'{pc:x}:.*mrs.*cntpct',asm) and re.search(f'{pc+4:x}:.*adr.*{pc:x}',asm)
   r[prefix]=dict(elf=hashlib.sha256(Path(prefix+'.elf').read_bytes()).hexdigest(),segments=[list(h) for h,b in loads(Path(prefix+'.elf'))],loads=sum(o.startswith(('ldr','ldp','ldur','ldar','ldrb','ldrh','ldax','ldxr')) for o in ops),branches=sum(o=='b' or o.startswith(('b.','cb','tb','bl','br','ret')) for o in ops),counter_sites=mrs)
print(json.dumps(r,indent=2))
