from pathlib import Path
import re
D=Path(__file__).resolve().parent
for line in (D/'cases').read_text().splitlines():
 name,*spec=line.split()
 if name=='excess':continue
 params=[tuple(map(int,s.split(':')[1].split(','))) for s in spec]
 for mode in ('plain','traced'):
  text=(D/'runs'/(name+'-'+mode)/'uart.log').read_text()
  rows=[list(map(int,s.split())) for s in re.findall(r'^NATIVE CBS EVENT ([0-9 ]+)$',text,re.M)]
  allocations=[list(x) for x in params]; active=[True]*len(spec); exited=set(); opens={b[2]:b for b in rows if b[0]==0}; stops={b[2]:b for b in rows if 1<=b[0]<=4}; wakes={b[2]:b for b in rows if b[0]==6}
  for t in range(max(opens)+1):
   if t in wakes:
    i=wakes[t][3];q,d=allocations[i];Q,P=params[i]
    if t>=d or q*P>Q*(d-t): allocations[i]=[Q,t+P]
    active[i]=True
   for i,(q,d) in enumerate(allocations):
    if active[i] and q==0 and t==d:allocations[i]=[params[i][0],d+params[i][1]]
   candidates=[(d,i) for i,(q,d) in enumerate(allocations) if active[i] and q>0 and i not in exited]
   if not candidates:
    assert t not in opens;continue
   _,i=min(candidates);assert opens[t][3]==i
   allocations[i][0]-=1
   assert all(opens[t][23+2*j:25+2*j]==allocation for j,allocation in enumerate(allocations))
   kind=stops[t][0]
   if kind in (2,3):active[i]=False
   if kind==3:exited.add(i)
  print(name,mode,len(opens),'ordered owners/debits and all skipped openings match')