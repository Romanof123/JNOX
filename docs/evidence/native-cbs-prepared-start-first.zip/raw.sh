set -eu
cd ~/jnox303-correct-evidence
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
cp /mnt/d/codex/jnox303-start-independent/raw.py .
python3 raw.py > raw-controls.txt
D=$PWD
cd ~/jnox303-correct-src
python3 tools/build_native_el0.py --out "$HOME/jnox303-correct-pkgs/arithmetic" --policy cbs --elf "$D/elf/crc.elf" --reservation 1,4294967295 --peer-elf "$D/elf/histogram.elf" --peer-reservation 1,4294967294 --peer-elf "$D/elf/energy.elf" --peer-reservation 1,4294967292 > "$D/controls/arithmetic-build.log"
cd "$D"
mkdir -p supplemental/elf/arithmetic supplemental/runs
cp "$HOME"/jnox303-correct-pkgs/arithmetic/{kernel.elf,manifest.json,build.log} supplemental/elf/arithmetic/
cp elf/*.elf.sym supplemental/elf/
cp capture.py supplemental/
echo 'arithmetic crc:1,4294967295 histogram:1,4294967294 energy:1,4294967292' > supplemental/cases
python3 supplemental/capture.py > supplemental/capture.log