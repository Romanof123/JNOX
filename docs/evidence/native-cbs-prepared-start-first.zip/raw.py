from pathlib import Path
import subprocess as sp,os,hashlib,json
d=Path.home()/'jnox303-correct-evidence'; src=Path.home()/'jnox303-correct-src'; elf=d/'elf/crc.elf'
env=dict(os.environ,JNOX_BOARD='virt',JNOX_PROFILE='native',JNOX_APP='process',JNOX_NATIVE_ELF=str(elf),JNOX_NATIVE_ELF_SHA256=hashlib.sha256(elf.read_bytes()).hexdigest(),JNOX_NATIVE_POLICY='cbs',CARGO_TARGET_DIR=str(Path.home()/'jnox303-raw-controls'))
out=d/'controls';out.mkdir(exist_ok=True)
checks=[('valid','1,4',{},None),('missing',None,{},'CBS requires reservations'),('extra','1,4;1,4',{},'supply one CBS reservation per slot'),('zero','0,4',{},'CBS requires'),('above','5,4',{},'CBS requires'),('malformed','x,4',{},'invalid CBS number'),('oversize','1,4294967296',{},'CBS number exceeds u32'),('wrong-policy','1,4',{'JNOX_NATIVE_POLICY':'fifo'},'reservations require CBS'),('priority','1,4',{'JNOX_NATIVE_PRIORITIES':'1'},'priorit'),('quantum','1,4',{'JNOX_NATIVE_QUANTUM_TICKS':'1'},'quantum'),('weight','1,4',{'JNOX_NATIVE_WEIGHTS':'1'},'weights require'),('edf','1,4',{'JNOX_NATIVE_EDF_JOBS':'1,2,1'},'job tuples require EDF'),('periodic','1,4',{'JNOX_NATIVE_PERIODIC':'0,20,20'},'periodic tuples require')]
for name,tuples,more,why in checks:
 e=dict(env,**more)
 if tuples:e['JNOX_NATIVE_RESERVATIONS']=tuples
 c=sp.run(['cargo','build','--release','--target','aarch64-unknown-none'],cwd=src/'kernel',env=e,capture_output=True,text=True); log=c.stdout+c.stderr;(out/(name+'.log')).write_text(log)
 print(name,c.returncode, ('PASS' if (c.returncode==0 if why is None else c.returncode!=0 and why.lower() in log.lower()) else 'CHECK'),flush=True)
for name,args in [('missing',[]),('duplicate',['--reservation','1,4','--reservation','1,4']),('extra',['--reservation','1,4','--peer-reservation','1,4']),('conflict',['--reservation','1,4','--weight','1'])]:
 c=sp.run(['python3','tools/build_native_el0.py','--out',str(out/('cli-'+name)),'--policy','cbs','--elf',str(elf)]+args,cwd=src,capture_output=True,text=True);(out/('cli-'+name+'.log')).write_text(c.stdout+c.stderr);print('cli',name,c.returncode,flush=True)