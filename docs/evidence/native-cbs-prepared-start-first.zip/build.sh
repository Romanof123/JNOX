set -euo pipefail
D=$HOME/jnox303-correct-evidence
cd ~/jnox303-correct-src
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1


mkdir -p "$D/elf" "$D/runs" ~/jnox303-correct-pkgs
gzip -c /mnt/d/codex/jnox303-start-independent/source.tar > "$D/input-source.tar.gz"
{ date -u; echo 547fef88cf4144707c9f474bc4e9c3144667a1da; clang --version; rustc -Vv; cargo -V; qemu-system-aarch64 --version; } > "$D/toolchain.txt"
for app in crc energy short_report block_yield; do sh sdk/native-aarch64/build.sh examples/native-cbs/"$app".c "$D/elf/$app.elf"; done
sh sdk/native-aarch64/build-rust.sh examples/native-cbs-rust/Cargo.toml "$D/elf/histogram.elf"
for app in "$D"/elf/*.elf; do aarch64-linux-gnu-nm -nS "$app" > "$app.sym"; aarch64-linux-gnu-objdump -d "$app" > "$app.dis"; done
while read -r name specs; do
 args=(--policy cbs); pre=--; mkdir -p "$D/elf/$name"
 for s in $specs; do args+=("${pre}elf" "$D/elf/${s%:*}.elf" "${pre}reservation" "${s#*:}"); pre=--peer-; done
 python3 tools/build_native_el0.py --out "$HOME/jnox303-correct-pkgs/$name" "${args[@]}" > "$D/elf/$name/package.log" 2>&1 || { if [[ "$name" == excess ]]; then continue; fi; cat "$D/elf/$name/package.log"; cat "$HOME/jnox303-correct-pkgs/$name/build.log" | tail -60; exit 1; }
 cp "$HOME/jnox303-correct-pkgs/$name/"{kernel.elf,manifest.json,build.log} "$D/elf/$name/"
done < "$D/cases"
sha256sum "$D/input-source.tar.gz" "$D"/elf/*.elf "$D"/elf/*/kernel.elf "$D"/{cases,prospective-budget.txt,capture.py,build.sh} > "$D/prelaunch.sha256"
