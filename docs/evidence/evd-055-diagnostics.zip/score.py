"""Independent CHG-057 first-launch scorer. Python 3.9+, standard library."""
import argparse
import hashlib
import json
import re
import struct
from pathlib import Path

MASK = 2**64-1
W = (1,2,4)
CASES = ("lottery1","lottery2","stride","lottery-miss","stride-delay")
SPEC = "jnox.chg057.independent/1"
COLUMNS = ("slot","owner","mask","start","compare","stop","whole","remainder","progress")


def split(state):
    state = (state + 0x9e3779b97f4a7c15) & MASK
    x = state
    for shift, factor in ((30,0xbf58476d1ce4e5b9),(27,0x94d049bb133111eb)):
        x = ((x ^ (x >> shift))*factor) & MASK
    return state, x ^ (x >> 31)


def ticket(weights, mask, value):
    if mask >> len(weights):
        raise ValueError("mask")
    low = 0
    for client, weight in enumerate(weights):
        if mask & (1<<client):
            if low <= value < low + weight:
                return client,low,low+weight
            low += weight
    raise ValueError("ticket outside active interval")


def draw(state,mask):
    total = sum(w for i,w in enumerate(W) if mask & (1<<i))
    if total == 0:
        return state,[],None
    cutoff = 2**64 % total
    words = []
    for _ in range(cutoff+1):
        state, x = split(state)
        words.append(x)
        if x >= cutoff:
            return state,words,x%total
    raise ValueError("unreachable rejection exhaustion")


def advance(x,count):
    # 2*x(n)+1 == 3**n*(2*x(0)+1) modulo 2**65.
    return (((2*x+1)*pow(3,count,2**65)-1) % 2**65)//2


def parse(raw):
    rows,errors,footer=[],[],None
    opened=False
    for n,line in enumerate(raw.splitlines(),1):
        line=line.strip()
        if line=="PROP RAW 1":
            if opened:
                errors.append([n,"duplicate header"])
            opened=True
        elif line.startswith("PROP END "):
            fields=line.split()[2:]
            if not opened or footer is not None or len(fields)!=5 or not all(re.fullmatch("[0-9]+",x) for x in fields):
                errors.append([n,"invalid footer"])
            else:
                footer=tuple(map(int,fields))
                if max(footer)>MASK:
                    errors.append([n,"footer overflow"])
        elif opened and line:
            fields=line.split()
            if footer is not None or len(fields)!=7 or not all(re.fullmatch("[0-9]+",x) for x in fields):
                errors.append([n,"invalid raw row"])
            else:
                row=tuple(map(int,fields))
                rows.append(row)
                if max(row)>MASK or row[0] not in range(1,15):
                    errors.append([n,"unsupported field"])
        elif "PROP OVERFLOW" in line:
            errors.append([n,"overflow"])
    if not opened or footer is None:
        errors.append([0,"incomplete transcript"])
    return rows,footer,errors


def elf_functions(file):
    raw=file.read_bytes()
    if raw[:6]!=b"\x7fELF\x02\x01" or struct.unpack_from("<H",raw,18)[0]!=183:
        raise ValueError("expected little-endian AArch64 ELF64")
    table=struct.unpack_from("<Q",raw,40)[0]
    size,count=struct.unpack_from("<HH",raw,58)
    sections=[struct.unpack_from("<IIQQQQIIQQ",raw,table+i*size) for i in range(count)]
    funcs=[]
    for sec in sections:
        if sec[1]!=2:
            continue
        strings=sections[sec[6]]
        names=raw[strings[4]:strings[4]+strings[5]]
        for at in range(sec[4],sec[4]+sec[5],sec[9]):
            name,info,_,sh,addr,length=struct.unpack_from("<IBBHQQ",raw,at)
            if sh and info&15==2 and length:
                funcs.append((addr,addr+length,names[name:].split(b"\0",1)[0].decode(errors="replace")))
    return funcs


def external(path):
    """Retain event order, including return vs entry; skip startup non-IRQ/SVC ELRs."""
    events=[]
    pending=None
    for line in path.read_text(errors="replace").splitlines():
        m=re.search(r"Taking exception \d+ \[([^]]+)\]",line)
        if m:
            pending=m[1]
        m=re.search(r"with ELR (0x[0-9a-fA-F]+)",line)
        if m and pending:
            if pending in ("IRQ","SVC"):
                events.append((pending,int(m[1],16)))
            pending=None
        m=re.search(r"Exception return .* PC (0x[0-9a-fA-F]+)",line)
        if m:
            events.append(("return",int(m[1],16)))
    return events


def inputs(paths):
    return {k:dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
            for k,p in paths.items() if p}


def order_issues(rows):
    # The UART writer preserves append order. The return witness is copied at the stop.
    phase_rows = [r for r in rows if r[0] not in (1,2)]
    mode = next((r[1] for r in rows if r[0]==1),None)
    if not phase_rows:
        return ["no mechanism rows"]
    expected = [(14,0,3),(7,0,3),(13,MASK,None),(14,0,3),(8,0,3)]
    for n in range((32,32,16,1,1)[mode] if mode in range(5) else 0):
        stride=mode in (2,4)
        mask_tags=[5,6] if stride else [3,4]
        if mode==2 and n==8:
            mask_tags=[11]+mask_tags
        pick=next((r[2] for r in rows if r[0]==7 and r[1]==n and r[2]!=3),None)
        expected.extend((tag,n,None) for tag in mask_tags)
        expected.extend([(14,n,pick),(7,n,pick)])
        if mode!=2 or pick!=0:
            expected.append((13,n,None))
        expected.extend([(14,n,pick),(8,n,pick),(9,n,pick),(10,n,None)])
        expected.extend((12,n,i) for i in range(3))
    mismatches=[]
    for n,(r,(tag,slot,who)) in enumerate(zip(phase_rows,expected)):
        if r[:2]!=(tag,slot) or (who is not None and r[2]!=who):
            mismatches.append([n,r[:3],[tag,slot,who]])
            break
        if tag==14 and (r[3]==0)!=(n+1<len(expected) and expected[n+1][0]==7):
            mismatches.append([n,"wrong selection/stop order"])
            break
    if len(phase_rows)>len(expected):
        mismatches.append(["extra raw events",len(phase_rows)-len(expected)])
    return mismatches


class Invalid(Exception):
    pass


def score(case,uart,elf,exceptions):
    mode=CASES.index(case)
    stride=mode in (2,4)
    seed=(1,2,0,1,0)[mode]
    limit=(32,32,16,1,1)[mode]
    rows,end,errors=parse(uart.read_text(errors="replace"))
    findings=[]
    def require(ok,why):
        if not ok:
            raise Invalid(why)
    def one(tag, condition=lambda d:True):
        group=[row[1:] for row in rows if row[0]==tag and condition(row[1:])]
        require(len(group)==1,f"tag {tag} multiplicity {len(group)}")
        return group[0]
    slots=[]
    words_by_slot=[]
    counts=[0]*3
    service=[0]*3
    observations=[]
    pc_events=[]
    funds=[0]*3
    prior=[(0,i+1,0,0) for i in range(3)]
    saved={}
    grants=[]
    frames={}
    funcs=[]
    if elf:
        try:
            funcs=elf_functions(elf)
        except (ValueError,struct.error,IndexError) as exc:
            errors.append([0,f"ELF: {exc}"])
    def symbols(pc):
        return [name for lo,hi,name in funcs if lo<=pc<hi]
    timing_miss=None
    late_charge=False
    phase="header"
    try:
        cfg,record_seed,freq,tick,packed,res=one(1)
        require((cfg,record_seed,packed,res)==(mode,seed,0x040201,0),"configuration")
        require(freq>0 and freq%100==0 and tick==freq//(25 if stride else 100),"frequency")
        for i in range(4):
            d=one(2,lambda a:a[0]==i)
            _,lo,hi,pc,tpid,zero=d
            require(lo<hi and pc and tpid==i+1 and not zero and all(hi<=p[0] or lo>=p[1] for p in frames.values()),"stack overlap or range")
            frames[i]=(lo,hi,pc)
            if funcs:
                require(bool(symbols(pc)),"unmapped entry")
                if i<3:
                    require("prop_rust_"+"abc"[i] in symbols(pc),"incorrect worker entry")
        require(len([r for r in rows if r[0]==2])==4,"extra stack record")
        state=seed
        def by_slot(tag,n,owner=None):
            return one(tag,lambda d:d[0]==n and (owner is None or d[1]==owner))
        def common(n,i,idle=False):
            sel=by_slot(7,n,i)
            ret=by_slot(8,n,i)
            _,_,start,compare,frame,pc=sel
            _,_,rf,rpc,pre,stop=ret
            a=one(14,lambda d:d[:3]==(n,i,0))
            b=one(14,lambda d:d[:3]==(n,i,1))
            lo,hi,entry=frames[i]
            require((frame,pc)==(rf,rpc)==a[3:5] and lo<=frame<hi and lo<=b[3]<hi
                    and all(f%16==0 for f in (frame,b[3])) and start<=pre<=stop,"frame/bracket")
            if i in saved:
                require(a[3:]==saved[i],"continuation frame/PC/fingerprint")
            else:
                require(pc==entry,"first entry")
            saved[i]=b[3:]
            if funcs:
                require(bool(set(symbols(entry)) & set(symbols(b[4]))),"interrupted PC outside entry function; independent call-path attribution needed")
            irq=idle or not stride or mode==4 or i!=0
            pc_events.extend([("return",pc),("IRQ" if irq else "SVC",b[4])])
            if irq:
                ack=one(13,lambda d:d[0]==(MASK if idle else n))
                require(ack[1]&1023==30 and ack[2]&7==5 and ack[3:]==(0,0,0),"PPI30 asserted")
            return start,compare,stop,pre,b,irq
        idle=one(7,lambda d:d[1]==3)
        phase="idle"
        istart,icomp,istop,_,_,_=common(idle[0],3,True)
        require(icomp-istart==tick and icomp<=istop,"idle release")
        require(draw(state,0)==(seed,[],None),"empty-ready model state")
        for n in range(limit):
            phase=f"slot {n}"
            mask=1 if mode==4 else 3 if stride and n<8 else 7
            if stride:
                if n==8:
                    require(by_slot(11,n)==(n,*funds,3,7),"late join incumbent")
                    funds[2]=min(funds[:2])
                ready=[i for i in range(3) if mask&(1<<i)]
                floor=min(funds[i] for i in ready)
                i=min(ready,key=lambda j:(funds[j],j))
                require(by_slot(5,n)==(n,mask,*funds,floor),"pre-normalization pass/floor")
                funds=[max(0,x-floor) for x in funds]
                require(by_slot(6,n)==(n,i,*funds,0),"normalization/order")
                expected=0 if mode==4 else (n%2 if n<8 else (0,1,2,2)[n%4])
                require(i==expected,"frozen stride order")
            else:
                before=state
                state,words,t=draw(state,mask)
                words_by_slot.append(words)
                i,lo,hi=ticket(W,mask,t)
                require(by_slot(3,n)==(n,before,state,len(words),words[-1],t),"autonomous draw")
                require(by_slot(4,n)==(n,mask,7,lo,hi,i),"eligible interval")
            start,compare,stop,pre,b,irq=common(n,i)
            require(compare-start==tick*(2 if stride or mode==3 else 1),"scheduled grant")
            _,owner,kind,ipc,s,reported=by_slot(9,n)
            whole,rem=divmod(stop-start,tick)
            require((owner,kind,ipc,s,reported)==(i,int(irq),b[4],stop,whole),"stop/whole/PC")
            require(not irq or stop>=compare,"early IRQ")
            if stride:
                funds[i]+=whole*(720720//W[i])
            require(max(funds)<=MASK,"charge overflow")
            post=by_slot(10,n)
            require(post==(n,*funds,rem,b[3]),"post-charge/remainder")
            counts[i]+=1
            service[i]+=whole
            for j in range(3):
                snap=by_slot(12,n,j)[2:]
                count,x,when,ptr=snap
                old=prior[j]
                if j==i:
                    low,high,_=frames[i]
                    require(count>old[0] and count%16==0 and advance(old[1],count-old[0])==x
                            and pre<=when<=stop and low<=ptr<high and (not old[3] or ptr==old[3]),"active progress")
                else:
                    require(snap==old,"inactive progress")
                prior[j]=snap
            grants.append([n,i,mask,start,compare,stop,whole,rem,prior[i][0]])
            slots.append(n)
            want=2 if stride and i else 1
            if mode==4:
                late_charge=whole>=3
                if not late_charge:
                    timing_miss=(n,whole,3)
            elif whole!=want:
                timing_miss=(n,whole,want)
            if timing_miss:
                break
        if mode in (0,1) and not timing_miss:
            require(counts==([10,8,14] if seed==1 else [5,11,16]) and
                    all(abs(7*v-32*w)<=56 for v,w in zip(counts,W)),"seed window")
        if mode==2 and not timing_miss:
            require(service==[6,12,8],"service totals")
        if mode==3:
            require(timing_miss is not None,"negative control failed to perturb")
    except (Invalid,ValueError) as exc:
        findings.append([phase,str(exc)])
    if end and end[0]==0 and end!=(0,0,0,0,0):
        findings.append(["uncommitted footer has nonzero payload",end])
    if end is None or end[0]!=0:
        findings.append(["guest-first-failure",end])
    if end and end[0] and timing_miss and end[1:]!=(mode,*timing_miss):
        findings.append(["first predicate requires exact source/operand attribution",end])
    if not elf or not exceptions:
        findings.append(["mechanism","missing ELF or ordered external trace"])
    if exceptions:
        actual=external(exceptions)
        # A startup ERET can precede entry to the idle context.
        at=next((n for n,e in enumerate(actual) if pc_events and e==pc_events[0]),None)
        if at is None or actual[at:]!=pc_events:
            findings.append(["mechanism","ordered external ERET/IRQ/SVC/ELR mismatch"])
    observed_rows={t:sum(r[0]==t for r in rows) for t in range(1,15)}
    expected_rows={1:1,2:4,3:0 if stride else limit,4:0 if stride else limit,
        5:limit if stride else 0,6:limit if stride else 0,7:limit+1,8:limit+1,
        9:limit,10:limit,11:int(mode==2),12:limit*3,
        13:limit+1-(6 if mode==2 else 0),14:2*(limit+1)}
    if observed_rows!=expected_rows:
        findings.append(["schema coverage",{"expected":expected_rows,"actual":observed_rows}])
    if timing_miss:
        findings.append(["first observed residency deviation",timing_miss])
    chronology=order_issues(rows)
    if chronology:
        findings.append(["raw event order",chronology])
    return dict(schema=SPEC,case=case,inputs=inputs(dict(uart=uart,elf=elf,exceptions=exceptions)),
        complete_arithmetic_and_mechanism_observation=not errors and not findings and len(slots)==limit,
        parser_errors=errors,findings=findings,first_guest_record=end,raw_rows=rows,
        columns=COLUMNS,grants=grants,counts=counts,whole_service=service,raw_rng_words=words_by_slot,
        late_charge_observed=late_charge,controlled_pending_irq_source="unavailable",
        scope="finite frozen regular or diagnostic transcript; no delayed-source inference")


def calendar():
    windows=[]
    for initial in range(1,9):
        state=initial
        counts=[0]*3
        for _ in range(4096):
            state,_,t=draw(state,7)
            counts[ticket(W,7,t)[0]]+=1
        within=all(100*abs(7*c-4096*w)<=3*4096*7 for c,w in zip(counts,W))
        windows.append(dict(seed=initial,counts=counts,within_three_points=within))
    return dict(schema=SPEC,scope="host only",windows=windows)


def checks():
    def expect_invalid(f):
        try:
            f()
        except ValueError:
            return
        raise AssertionError("unexpected acceptance")
    assert [(v,v>=2**64%7) for v in (0,1,2)]==[(0,False),(1,False),(2,True)]
    assert [ticket(W,7,t)[0] for t in range(7)]==[0,1,1,2,2,2,2]
    expect_invalid(lambda:ticket(W,7,7))
    expect_invalid(lambda:ticket(W,0,0))
    assert ticket(W,5,1)==(2,1,5)
    assert draw(8,0)==(8,[],None)
    assert advance(1,2)==13
    assert parse("PROP RAW 1\n1 0 1 10 1 2 0 0 0\nPROP END 0 0 0 0 0")[2]
    assert parse("PROP RAW 1\n1 0 1 10 1 2 0")[2]
    assert parse("PROP RAW 1\nPROP END 12 0 0 2 1\nPROP END 0 0 0 0 0")[2]
    return {"schema":SPEC,"scope":"synthetic source/reduction and UART controls","status":"completed"}


def perturb(raw,mutation):
    """Create intentionally invalid transcript from separately retained complete seed-1 capture."""
    rows,end,errors=parse(raw)
    if errors or not end or end[0] or len([r for r in rows if r[0]==9])!=32:
        raise ValueError("requires complete unmodified lottery1 parent")
    rows=list(rows)
    idx=next(i for i,r in enumerate(rows) if r[0]==1)
    if rows[idx][1]!=0:
        raise ValueError("requires lottery1")
    tag,col={"rng-word":(3,5),"ticket-owner":(4,6),"counter-stop":(9,5),
             "resume-pc":(8,4),"frozen-client":(12,3)}[mutation]
    idx=next(i for i,r in enumerate(rows) if r[0]==tag and r[1]==0
             and (tag!=8 or r[2]!=3) and (tag!=12 or r[2]!=next(x[6] for x in rows if x[0]==4)))
    edit=list(rows[idx])
    edit[col]^=1
    rows[idx]=tuple(edit)
    return "PROP RAW 1\n"+"".join(" ".join(map(str,r))+"\n" for r in rows)+"PROP END "+" ".join(map(str,end))+"\n"


if __name__=="__main__":
    cli=argparse.ArgumentParser()
    sub=cli.add_subparsers(dest="command",required=True)
    for name in ("order","calendar","controls"):
        sub.add_parser(name)
    run=sub.add_parser("score")
    run.add_argument("case",choices=CASES)
    run.add_argument("uart",type=Path)
    run.add_argument("--elf",type=Path)
    run.add_argument("--exceptions",type=Path)
    mock=sub.add_parser("mutate")
    mock.add_argument("uart",type=Path)
    mock.add_argument("mutation",choices=("rng-word","ticket-owner","counter-stop","resume-pc","frozen-client"))
    args=cli.parse_args()
    if args.command=="mutate":
        print(perturb(args.uart.read_text(errors="replace"),args.mutation),end="")
    else:
        if args.command=="score":
            output=score(args.case,args.uart,args.elf,args.exceptions)
        elif args.command=="calendar":
            output=calendar()
        elif args.command=="controls":
            output=checks()
        else:
            output={"schema":SPEC,"positions":[{"ordinal":n,"case":case} for n,case in enumerate(CASES,1)]}
        print(json.dumps(output,indent=2))


