import pathlib,subprocess,time,socket,struct,hashlib,shutil
p=pathlib.Path.home()/'jnox253-combined-ver/e/ram1'
p.mkdir(exist_ok=True)
elf=p.parent/'coop-bounded-plain/guest.elf'
addr=next(int(x.split()[0],16) for x in subprocess.check_output(['nm',elf],text=True).splitlines() if x.endswith(' coop_bounded_observations'))
mon=p/'monitor.sock'
cmd=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-m','128M','-display','none','-monitor',f'unix:{mon},server,nowait','-serial',f'file:{p}/uart','-nic','none','-kernel',str(elf)]
(p/'command').write_text(repr(cmd))
with (p/'stderr').open('wb') as err:
 q=subprocess.Popen(cmd,stderr=err)
 try:
  for _ in range(200):
   if (p/'uart').exists() and b'COOP DONE' in (p/'uart').read_bytes(): break
   time.sleep(.05)
  with socket.socket(socket.AF_UNIX) as s:
   s.connect(str(mon)); s.recv(4096); s.sendall(f'stop\npmemsave {addr:#x} 632 "{p}/ram.bin"\n'.encode())
   for _ in range(100):
    if (p/'ram.bin').exists() and (p/'ram.bin').stat().st_size==632:break
    time.sleep(.02)
   s.sendall(b'quit\n')
 finally:
  try:q.wait(timeout=2)
  except subprocess.TimeoutExpired:q.terminate();q.wait()
 (p/'exit').write_text(str(q.returncode))
w=struct.unpack('<79Q',(p/'ram.bin').read_bytes())
(p/'words').write_text('\n'.join(f'{i:02} {x:20} {x:#x}' for i,x in enumerate(w)))
print((p/'words').read_text())
