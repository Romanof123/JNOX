from pathlib import Path
import struct, json
root=Path.home()/'jnox253-combined-ver'; e=root/'e'
w=struct.unpack('<79Q',(e/'ram1/ram.bin').read_bytes())
for i,row in enumerate([[3,1,4,1],[5,9,2,6],[5,3,5,8]]):
 assert (sum(row),sum(k*x for k,x in enumerate(row,1)))==w[63+i*6:65+i*6]
for d in e.glob('ordinary-*-supply-*'):
 if not d.is_dir() or 'refuse' in d.name:continue
 t=d.joinpath('uart').read_text().splitlines()
 get=lambda tag:[list(map(int,l.split()[1:])) for l in t if l.startswith(tag+' ')]
 a,b=get('RESULT')[0][2:]; assert get('RESULT')[0][0]==sum(i*i for i in range(1,65)); cfg=get('CONFIG')[0]
 if d.name.endswith('trace'):
  ds=get('D'); js=get('J')[-3:]; jobs=get('JOB')
  for k,product in enumerate([a,b]):
   count=js[k][-1]*64; modulus=32*(1<<64); power=pow(33,count,modulus)
   v=((k+1)*power+(power-1)//32) % (1<<64); assert product==v
   row=[x for x in ds if x[0]==2 and x[9]==k];assert len(row)==1 and row[0][7]<=cfg[1]+jobs[k][2]*cfg[2]
 print(d.name,'sum',sum(i*i for i in range(1,65)),'products',a,b)
for d in sorted(e.glob('ordinary-*-trace')):
 if 'supply' in d.name:continue
 t=d.joinpath('uart').read_text().splitlines()
 ds=[list(map(int,l.split()[1:])) for l in t if l.startswith('D ')]
 assert ds and all(x[18]==0 for x in ds)
 print(d.name,'rows',len(ds),'exhaust',sum(bool(x[17]) for x in ds),'live misses',sum(bool(x[18]) for x in ds))
