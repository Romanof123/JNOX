import pathlib, struct
from collections import deque
e=pathlib.Path(__file__).parent/'e'
w=struct.unpack('<79Q',(e/'ram1/ram.bin').read_bytes())
assert w[:9]==(1,3,12500000,6250000,0,20,2,5,3)
posts=[w[i:i+10] for i in range(9,59,10)]
done=[w[i:i+6] for i in range(59,77,6)]
q=deque(); cost=w[2:4]; active=None
for now,worker,block,deadline,reason,db,cb,da,ca,remaining in posts:
 if done[0][2]<=now and active is None: active=q.popleft()
 assert db==len(q) and cb==sum(cost[i] for i,b in q)
 assert remaining==(max(0,cost[active[0]]-(now-done[0][2])) if active else 0)
 fit=now+remaining+cb+cost[worker]<=deadline
 assert reason==(0 if fit else 3)
 if fit:q.append((worker,block))
 assert da==len(q) and ca==sum(cost[i] for i,b in q)
expect=[active]+list(q)
assert expect==[(x[0],x[1]) for x in done]
assert all(start<=end and end-start<=cost[worker] for worker,b,start,end,*_ in done)
assert all(x[3]<=y[2] for x,y in zip(done,done[1:]))
assert [sum(x[i] for x in done) for i in (4,5)]==list(w[77:])==[52,132]
for f in sorted(e.glob('*/uart')):
 t=f.read_text(); app=f.parent.name
 def rows(k):return [list(map(int,l.split()[1:])) for l in t.splitlines() if l.startswith(k+' ')]
 if 'supply' in app:
  cfg,=rows('CONFIG'); assert cfg[0]==62500000
  if 'refuse' in app:
   assert cfg[5]==(8 if 'edf' in app else 9) and 'REFUSED BEFORE LAUNCH' in t and not rows('D') and not rows('JOB')
  else:
   assert rows('RESULT')[0][0]==89440 and rows('A_STOP')[0][0]==cfg[1]+cfg[0]//4
   a,p,b=rows('A_PROGRESS')[0];assert 0<a==p<b
   assert 'FINISHED' in t and len(rows('JOB'))==2
   if 'trace' in app:
    d=rows('D'); assert d[1][1:3]==[1,1] and d[2][1:3]==[2,2] and d[1][9:11]==[0,4] and d[2][9:11]==[4,0] and d[1][11:13]==d[2][13:15]
    assert all(x[7]<=cfg[1]+j[2]*cfg[2] for x,j in zip(d[-2:],rows('JOB')))
 elif 'coop' in app or 'ram' in app: assert 'COOP DONE' in t
 else:assert 'FINISHED' in t
 print(app,'PASS')
print('PASS independently reconstructed RAM, finite UART, trace deadlines and resume. Refusal plain has no dispatch counter. Legacy baseline and host cases pending.')
