from pathlib import Path
import subprocess,struct,hashlib,json,re
root=Path.home()/'jnox253-combined-ver'; e=root/'e'; result={}
def measure(p):
 b=p.read_bytes(); ph=struct.unpack_from('<Q',b,32)[0]; stride,count=struct.unpack_from('<HH',b,54); seg=[]
 for n in range(count):
  typ,fl,off,va,pa,fs,ms,align=struct.unpack_from('<II6Q',b,ph+n*stride)
  if typ==1:seg.append(b[off:off+fs])
 txt=subprocess.check_output(['aarch64-linux-gnu-objcopy','-O','binary','--only-section=.text',str(p),'/dev/stdout'])
 h=lambda x:hashlib.sha256(x).hexdigest()
 return [len(b),sum(map(len,seg)),h(b''.join(seg)),len(txt),h(txt),h(b)]
for p in sorted((root/'baseline').glob('*/kernel.elf')):
 a=measure(p); b=measure(e/p.parent.name/'guest.elf'); result[p.parent.name]={'base':a,'tested':b}
 print(p.parent.name,'size delta',b[0]-a[0],'load delta',b[1]-a[1],'load_equal',a[2]==b[2],'text_equal',a[4]==b[4])
(e/'legacy.json').write_text(json.dumps(result,indent=2))
for num in ['095','097']:
 d=root/'indexed/docs/evidence'
 for suf in ['.en.md','.md']:
  p=d/('evd-'+num+suf); t=p.read_text()
  for link in re.findall(r'\]\(([^)]+)\)',t):
   if '://' in link:continue
   f=p.parent/link;assert f.is_file(), f
   if link.endswith('first.zip'):assert hashlib.sha256(f.read_bytes()).hexdigest() in t
  assert 'first.en-ko.md' in t and 'first.zip' in t
 matrix=json.loads((e/'matrix.json').read_text())
 assert ('EVD-'+num) in matrix['evidence']
 print('EVD-'+num,'EN/KO, first report, archive hash and matrix membership PASS')
