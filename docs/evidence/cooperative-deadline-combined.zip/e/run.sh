set -eu
cd ~/jnox253-combined-ver/src
export RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo
export PATH=$CARGO_HOME/bin:$PATH RUSTUP_TOOLCHAIN=1.95.0 CARGO_BUILD_JOBS=1 JNOX_BOARD=virt
dest=/mnt/d/codex/jnox253-combined-ver
rustc -vV > ../e/env
qemu-system-aarch64 --version >> ../e/env
env | grep -E '^(RUST|CARGO|JNOX)' >> ../e/env
for app in ordinary-edf-supply-refuse ordinary-llf-supply-refuse ordinary-edf-supply ordinary-llf-supply coop-bounded ordinary-edf ordinary-llf ordinary-llf-overload ordinary-edf-overrun coop-events coop-single; do
 export JNOX_APP=$app JNOX_PROFILE=deadline
 modes="trace plain"
 case $app in coop*) export JNOX_PROFILE=fixed; modes=plain;; esac
 for mode in $modes; do
  unset JNOX_DEADLINE_TRACE
  if [ $mode = trace ]; then export JNOX_DEADLINE_TRACE=1; fi
  d=../e/$app-$mode
  mkdir -p "$d"
  if python3 tools/build_kernel.py > "$d/build" 2>&1; then
   cp kernel/target/aarch64-unknown-none/release/jnox-kernel "$d/guest.elf"
   q=(qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -m 128M -nographic -monitor none -serial stdio -nic none -kernel "$d/guest.elf")
   printf '%q ' "${q[@]}" > "$d/command"
   rc=0; timeout 2 "${q[@]}" > "$d/uart" 2>"$d/stderr" || rc=$?
   echo "$rc" > "$d/exit"
  fi
  cp -r "$d" "$dest/"
  (cd "$d"; sha256sum *) | (cd "$dest/$app-$mode"; sha256sum -c -) >/dev/null
 done
done
