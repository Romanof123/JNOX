#![allow(dead_code)]
#[path="../src/kernel/src/event_loop.rs"] mod event_loop;
#[path="../src/kernel/src/coop_bounded.rs"] mod coop_bounded;
#[path="../src/kernel/src/deadline_jobs.rs"] mod deadline_jobs;
#[path="../src/kernel/src/deadline_policy.rs"] mod deadline_policy;
#[path="../src/kernel/src/ready_queue.rs"] mod ready_queue;
mod ordinary_deadline {pub fn counter()->u64{unreachable!()}}
use coop_bounded::{Decision::*,Handler,Service,Request,Post};
fn req(block:u64, deadline:u64)->Request {Request{handler:0,block,deadline}}
#[test] fn busy_observation_order(){
 fn handler(_: &mut (), r:Request, p:&mut Post<'_>){
  if r.block==7 {
   let refused=p(req(9,61),60);
   assert_eq!((refused.decision,refused.before,refused.after,refused.remaining),(Deadline,(1,30),(1,30),20));
   assert_eq!(p(req(9,999),59).decision,InvalidInterval);
  }
 }
 let mut s=Service::<(),4,1>::new([Handler{cost:30,call:handler}]);
 assert_eq!(s.post(req(7,500),11).decision,Accepted);
 let refused=s.post(req(9,30),20);
 assert_eq!((refused.decision,refused.before,refused.after),(Deadline,(1,30),(1,30)));
 assert_eq!(s.post(req(8,500),19).decision,InvalidInterval);
 assert_eq!(s.post(req(8,500),20).decision,Accepted);
 let mut samples=[50u64,58].into_iter();
 assert_eq!(s.turn(&mut (),||samples.next().unwrap()).unwrap().0.block,7);
 assert_eq!(s.post(req(9,999),70).decision,InvalidInterval);
 assert_eq!(s.turn(&mut (),||80).unwrap().0.block,8);
 assert_eq!(s.post(req(1,30),0).decision,Accepted);
}
#[test] fn independent_demand_overflow(){
 use deadline_jobs::*; use deadline_policy::*;
 let mut jobs=SUPPLIED; jobs[0].release=0; jobs[1].release=0; jobs[0].cost=u64::MAX-1; jobs[1].cost=3;
 jobs[0].deadline=3; jobs[1].deadline=4;
 assert_eq!(admit_with_supply(DeadlinePolicy::Edf,&jobs,1000,0,RESERVED),Err(Refusal::Demand));
 jobs[1].deadline=3;
 assert_eq!(admit_with_supply(DeadlinePolicy::Edf,&jobs,1000,0,RESERVED),Err(Refusal::Overflow));
}
