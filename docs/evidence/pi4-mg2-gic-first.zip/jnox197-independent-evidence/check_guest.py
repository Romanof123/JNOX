import json,re
from pathlib import Path
from pi4_mg2_terminal import observations,rows_and_frames
p=Path(__file__).resolve().parent
f=json.loads((p/'freeze.json').read_text())
for n in (1,2):
 d=p/f'first-{n}'
 ram=rows_and_frames((d/'terminal-ram.bin').read_bytes(),f['ram'])
 o=observations(d,json.loads((d/'session.json').read_text()),f,ram)
 out=dict(ram=ram,observations=o,stopped_pcs=[re.search(r'PC=(\w+)',(d/f'cpu-{i}-registers.txt').read_text())[1] for i in range(4)])
 (p/f'guest-{n}.json').write_text(json.dumps(out,indent=2))
 print(n,out['stopped_pcs'],ram['m_opening_svc_frames'],o['completed_summaries'])
