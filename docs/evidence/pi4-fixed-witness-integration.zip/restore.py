from pathlib import Path
import hashlib,json,zipfile,sys
z=zipfile.ZipFile(sys.argv[1])
out=Path(sys.argv[2]);out.mkdir()
for name,row in json.loads(z.read('index.json')).items():
    p=out/name;p.resolve().relative_to(out.resolve())
    b=z.read('objects/'+row['sha256']);assert hashlib.sha256(b).hexdigest()==row['sha256'] and len(b)==row['bytes']
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
