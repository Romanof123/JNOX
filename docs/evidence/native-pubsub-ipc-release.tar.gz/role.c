#include <jnox/ipc.h>
volatile long role_results[9];
int main(int argc, char **argv) {
    int role = argc == 3 ? 3 : argv[1][0] - '0';
    if (role < 2) {
        role_results[0] = jnox_ipc_trap(37,0,0,0).status;
        role_results[1] = jnox_ipc_trap(52,0,0,0).status;
        if (role_results[0] != -13 || role_results[1] != -13) return 101;
        if (role == 1) return 91;
        for (unsigned server=2; server<=3; ++server) {
            jnox_ipc_response r=jnox_ipc_call(server, 0xca00+server, UINT64_MAX);
            role_results[2*server]=r.status;
            role_results[2*server+1]=r.word;
            if (r.status || r.word!=0xda00+server) return 102;
        }
    } else {
        role_results[0]=jnox_ipc_trap(role==2 ? 52 : 37,0,0,0).status;
        if (role_results[0]!=-13) return 103;
        for (;;) {
            jnox_ipc_registers r=jnox_ipc_trap(role==2 ? 37 : 52,0,0,0);
            if(r.status) return 104;
            if(!r.x1) continue;
            role_results[1]=r.status; role_results[2]=r.x1; role_results[3]=r.x2;
            if(r.x2 != 0xca00u+(unsigned)role) return 105;
            role_results[4]=jnox_ipc_reply(r.x1,0xda00+role);
            if(role_results[4]) return 106;
            break;
        }
    }
    return 90+role;
}
