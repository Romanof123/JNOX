import hashlib, json, re, struct, sys
from pathlib import Path
base=Path(sys.argv[1]).resolve()
src=Path(sys.argv[2]).resolve()
sys.path.insert(0,str(src/'tools'))
from native_amc_roots import linked_roots
from native_el0_replay import Snapshot, elf_file, permissions, symbol, vread
records={}
for policy in ('fifo','rr'):
 for kind in ('socket','shell','role'):
    case=kind+'-'+policy
    package=base/case
    cap=base/('cap-'+case)
    manifest=json.loads((package/'manifest.json').read_text())
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    assert sha(package/'kernel.elf')==manifest['kernel_elf_sha256']==json.loads((cap/'launch.json').read_text())['kernel']
    slots=manifest['slots']
    roots=linked_roots(package/'kernel.elf',len(slots))
    mem=Snapshot(0x40200000,(cap/'ram.bin').read_bytes())
    def field(slot,name,t):
        item=slots[slot]
        path=package/item['elf']
        assert sha(path)==item['elf_sha256']
        va,size=symbol(elf_file(path.read_bytes()),name)
        permissions(mem,roots[slot],va,'user rw')
        return list(struct.unpack('<'+t*(size//struct.calcsize(t)),vread(mem,roots[slot],va,size)))
    expected={'socket':[73,74,0],'shell':[0,0,0],'role':[90,91,92,93]}[kind]
    uart=(cap/'uart.bin').read_text()
    exits=sorted((int(i),int(x)) for i,x in re.findall(r'NATIVE EL0 EXIT PID (\d+) (-?\d+)',uart))
    assert [x for i,x in exits]==expected,(case,exits)
    rec={'exits':exits}
    if kind=='shell':
        rec['result']=field(0,'shell_result','i')
        assert rec['result']==[1,1,1,2,1,2,0,0]
        assert 'NATIVE SHELL CONSOLE 0 2 1 2 50 10' in uart
        rec['stdout_hex']='320a'
    if kind=='socket':
        rec['server']=field(0,'socket_server_result','q')
        rec['client']=field(1,'socket_client_result','q')
        assert rec['server']==[1,1,2080,64,3,16,45,0,0,32,1,0]
        assert rec['client']==[1,7,57,0,0,-11,32,0,1,0,0,0]
    if kind=='role':
        rec['private']=[field(i,'role_results','q') for i in range(4)]
        a,b,c,d=rec['private']
        assert a==[-13,-13,0,0,0,0xda02,0,0xda03,0] and b[:2]==[-13,-13]
        assert c[:2]==d[:2]==[-13,0] and c[2]>0 and d[2]>0 and c[3:5]==[0xca02,0] and d[3:5]==[0xca03,0]
        assert manifest['pubsub_service']['slot']==3 and manifest['socket_service']['slot']==2
    records[case]=rec
print(json.dumps(records,indent=2))
