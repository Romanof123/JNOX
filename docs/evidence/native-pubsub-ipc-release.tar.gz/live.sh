set -euxo pipefail
base=$HOME/release384-6fc32
src=$base/checkout
raw=$base/live
export SRC=$src RAW=$raw
source ~/.cargo/env
export PYTHONPATH=$HOME/jnox-169-first-e203caa/deps CARGO_TARGET_DIR=$raw/app-target CARGO_NET_OFFLINE=true
cd "$src"
bash "$raw/run.sh" first
for p in fifo rr; do python3 "$raw/capture.py" . "$raw/$p" "$raw/cap-$p"; done
bash "$raw/extra.sh"
d=$raw
for a in shell cat wc; do sh sdk/native-aarch64/build.sh --pipes --native-shell examples/native-shell-pipeline/$a.c $d/$a.elf; done
printf 'zero\none\nlast' > $d/input.txt
sh sdk/native-aarch64/build.sh --local-socket examples/native-local-sockets/server.c $d/server.elf
sh sdk/native-aarch64/build-rust.sh --local-socket examples/native-local-sockets/client/Cargo.toml $d/client.elf
sh sdk/native-aarch64/build-rust.sh services/socket/Cargo.toml $d/socket.elf
sh sdk/native-aarch64/build.sh --local-socket examples/native-inet-sockets/tcp.c $d/tcp.elf
sh sdk/native-aarch64/build-rust.sh --local-socket examples/native-inet-sockets/udp/Cargo.toml $d/udp.elf
sh sdk/native-aarch64/build-rust.sh services/inet/Cargo.toml $d/inet.elf
for p in fifo rr; do
 flags=(); if [[ $p == rr ]]; then flags=(--quantum-ticks 625000); fi
 build() { python3 tools/build_native_el0.py --policy $p "${flags[@]}" "$@"; }
 build --out $d/shell-$p --pipes --elf $d/shell.elf --priority 7 --arg 'cat sample.txt | wc -l' --peer-elf $d/cat.elf --peer-priority 4 --exec-child 1:cat --peer-elf $d/wc.elf --peer-priority 4 --exec-child 2:wc --rom-file sample.txt=$d/input.txt
 python3 $d/capture.py . $d/shell-$p $d/cap-shell-$p
 build --out $d/socket-$p --elf $d/server.elf --arg stream --priority 7 --peer-elf $d/client.elf --peer-arg stream --peer-priority 4 --peer-elf $d/socket.elf --peer2-arg 3 --peer-priority 1 --socket-service 2 --ipc-route 0:2 --ipc-route 1:2
 python3 $d/capture.py . $d/socket-$p $d/cap-socket-$p
 build --out $d/inet-$p --elf $d/tcp.elf --priority 4 --peer-elf $d/udp.elf --peer-priority 4 --peer-elf $d/inet.elf --peer-priority 7 --peer2-arg 3 --ipc-route 0:2 --ipc-route 1:2 --socket-service 2 --net-service 2
done
