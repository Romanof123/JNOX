set -euxo pipefail
cd ~/release384-6fc32/checkout
d=$HOME/release384-6fc32/live
source ~/.cargo/env
export CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true
sh sdk/native-aarch64/build.sh $d/role.c $d/role.elf
for p in fifo rr; do
 flags=(); if [[ $p == rr ]]; then flags=(--quantum-ticks 625000); fi
 python3 tools/build_native_el0.py --policy $p "${flags[@]}" --out $d/role-$p --elf $d/role.elf --priority 4 --arg 0 --peer-elf $d/role.elf --peer-priority 4 --peer-arg 1 --peer-elf $d/role.elf --peer-priority 4 --peer2-arg 2 --peer-elf $d/role.elf --peer-priority 4 --pubsub-service 3 --pubsub-publish 0:1 --pubsub-subscribe 1:1 --socket-service 2 --ipc-route 0:2 --ipc-route 0:3 --ipc-route 1:3 --ipc-route 2:3
 python3 $d/capture.py . $d/role-$p $d/cap-role-$p
done
