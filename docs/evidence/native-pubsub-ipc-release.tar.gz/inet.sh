set -euxo pipefail
ns=ipc008release6fc32
ip netns add "$ns"
trap 'ip netns del "$ns"' EXIT
ip -n "$ns" link set lo up
ip netns exec "$ns" ip tuntap add dev jnx0 mode tap user ywcho
ip -n "$ns" addr add 10.0.2.2/24 dev jnx0
ip -n "$ns" link set jnx0 up
cd /home/ywcho/release384-6fc32
for p in fifo rr; do
 ip netns exec "$ns" python3 checkout/examples/native-inet-sockets/peer.py live/inet-$p live/tap-inet-$p --isolated-tap jnx0
 tar czf /mnt/d/codex/.jnox-work/ipc008-release-6fc32/tap-inet-$p.tar.gz -C live tap-inet-$p
done
