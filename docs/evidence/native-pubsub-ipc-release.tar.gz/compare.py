import hashlib,json,subprocess,sys
from pathlib import Path
base=Path(sys.argv[1]).resolve()
src=Path(sys.argv[2]).resolve()
first=Path(sys.argv[3]).resolve()
def git(*args):return subprocess.check_output(['git','-C',src,*args])
def digest(data):return hashlib.sha256(data).hexdigest()
x=json.loads((base/'decoded.json').read_text()); a=json.loads((first/'decoded.json').read_text())
sources=['examples/native-pubsub','services/pubsub','sdk/native-aarch64/pubsub.c','sdk/native-aarch64/include/jnox/pubsub.h','sdk/native-aarch64/rust/src/pubsub.rs']
assert not git('diff','--name-only','51a9ca0','6fc32ff','--',*sources)
report={'identical_source_paths':sources,'commit':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'cases':{}}
for case,r in x.items():
 delta={key:[a[case][key],r[key]] for key in r if a[case][key]!=r[key]}
 if case in ('fifo','rr'):assert set(delta)<= {'trace_dropped'}
 elif case.startswith('legacy'):assert set(delta)<={'addresses','observed_exit_ttbr0_el1'}
 else:
    assert set(delta)<={'trace_dropped','reader_result'}
    assert [v for i,v in enumerate(r['reader_result']) if i!=4]==[v for i,v in enumerate(a[case]['reader_result']) if i!=4]
 report['cases'][case]={'differences':delta}
 if case in ('fifo','rr'):
    apps={}
    for filename in ('user.elf','native_peer.elf','native_peer2.elf','native_peer3.elf','kernel.elf'):
        paths=[first/case/filename,base/case/filename]
        apps[filename]={'elf_sha256':[digest(p.read_bytes()) for p in paths],'text_sha256':[digest(subprocess.check_output(['aarch64-linux-gnu-objcopy','-O','binary','--only-section=.text',p,'/dev/stdout'])) for p in paths]}
    report['cases'][case]['images']=apps
print(json.dumps(report,indent=2))
