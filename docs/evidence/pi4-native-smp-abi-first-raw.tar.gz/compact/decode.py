import pathlib,json,re,struct,hashlib
D=pathlib.Path('seal'); F=json.loads((D/'seal.json').read_bytes());out={}
for pos in ('plain','traced'):
 p=D/pos;base=json.loads((p/'launch.json').read_bytes())['ram_base'];b=(p/'ram.bin').read_bytes();u=(p/'uart.bin').read_text();l=[]
 for cpu,addr,n,w,lost,fa,size in [list(map(int,x.split())) for x in re.findall('NATIVE SMP JOURNAL ([0-9 ]+)',u)]:
  for i in range(n):
   r=struct.unpack_from('<37Q',b,addr-base+296*i);fb=fa-base+1632*i;s=b[fb:fb+816];g=b[fb+816:fb+1632];f=struct.unpack('<102Q',s);start=F['apps'][cpu]['loop']
   if r[3]==30 and r[6]==cpu and start<=f[32]<F['apps'][cpu]['end']:
    done=f[4]-int(f[32]>=start+20)
    l.append(dict(cpu=cpu,row=i,pc=hex(f[32]),completed=done,x19=hex(f[19]),q16=f[70:72],tls=hex(f[34]),ro=f[35],fpcr=hex(f[36]),fpsr=hex(f[37]),saved=hashlib.sha256(s).hexdigest(),prepared=hashlib.sha256(g).hexdigest()))
 out[pos]=l
print(json.dumps(out,indent=2))
