#!/bin/bash
set -eu
d=$HOME/iv355-abir-data
cd ~/iv355-abir-src
export PATH=$HOME/.cargo/bin:$PATH PYTHONPATH=$HOME/jnox-169-first-e203caa/deps
q=$HOME/arm-speed-lab-tools/qemu-11.1.3/build/qemu-system-aarch64
call(){ name=$1; shift; printf '%q ' "$@" >>$d/commands; echo >>$d/commands; rc=0; "$@" > "$d/$name.log" 2>"$d/$name.err" || rc=$?; echo "$name $rc" >> "$d/status"; return $rc; }
call jobs sh examples/native-pi4-smp/abi/build.sh "$d/jobs"
call package python3 tools/build_native_el0.py --board pi4 --policy smp-partitioned --elf "$d/jobs/odd.elf" --peer-elf "$d/jobs/even.elf" --cpu-mask 1 --peer-cpu-mask 2 --priority 2 --peer-priority 2 --out "$d/package"
call seal python3 tools/pi4_native_smp_abi.py seal "$d/package" "$d/seal" --qemu "$q"
h=$(sha256sum "$d/seal/seal.json"|cut -d' ' -f1)
for mode in plain traced; do
 call cap-$mode python3 tools/pi4_native_smp_abi.py capture "$d/seal" "$h" "$mode" || :
 if test -f "$d/seal/$mode/session.json"; then call report-$mode python3 tools/pi4_native_smp_abi.py report "$d/seal" "$h" "$mode" "$(sha256sum "$d/seal/$mode/session.json"|cut -d' ' -f1)" || :; fi
done
