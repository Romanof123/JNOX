from pathlib import Path
import hashlib,json,subprocess as sp,shutil,zipfile,sys
root=Path.home()/'baseline259260';raw=root/'raw';dst=Path('/mnt/d/codex/jnox259260-baseline')
def digest(f):return hashlib.sha256(f.read_bytes()).hexdigest()
rows=json.loads((raw/'matrix.json').read_text());assert len(rows)==28
for r in rows:
 d=raw/(r['app']+'-'+r['mode']);assert digest(d/'kernel.elf')==r['elf_sha256'];assert len(r['segments'])==2 and len(r['sections'])==4
 for i,s in enumerate(r['segments']):assert digest(d/f'load{i}.bin')==s['sha256']
toolbin=Path.home()/'jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin'
cmds=[['git','rev-parse','HEAD'],['git','diff','HEAD','--stat'],['df','-T','.'],[str(toolbin/'rustc'),'-Vv'],[str(toolbin/'cargo'),'-V'],['qemu-system-aarch64','--version'],['uname','-a']]
(raw/'environment.txt').write_text(''.join('$ '+' '.join(cmd)+'\n'+sp.check_output(cmd,cwd=root/'tree',text=True)+'\n' for cmd in cmds))
for f in ['build.py','guests.py']:shutil.copyfile(root/f,raw/f)
for f in ['kernel/build.rs','kernel/link.ld','docs/ordinary-multilevel.en.md','docs/deadline-supply-plan.md','tools/qemu_boot.py','tools/qemu_capture.py','tools/ordinary_multilevel_capture.py','tools/ordinary_multilevel_replay.py','tools/deadline_supply_replay.py']:
 out=raw/'source'/f;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/'tree'/f,out)
report=['# Ordinary scheduling baseline / 일반 스케줄러 기준 측정','', 'Pinned source / 기준 커밋 '+sp.check_output(['git','rev-parse','HEAD'],cwd=root/'tree',text=True).strip(),'', '28 release ELF originals, one Cargo job, six diagnostic guest acquisitions. Kernel build.rs selects 6 multilevel apps and 8 deadline apps. Each app uses an unset trace variable for plain and 1 for trace. Each row below lists section bytes. Stack symbols inside .bss are already included in its size. The .stack column contains only the separate linker reservation. matrix.json retains full ELF, both file-backed PT_LOAD segment and section digests, virtual addresses, segment file/memory sizes, and stack symbols. NOBITS has no file payload. readelf.txt retains the full linked tables.', '', '일반 빌드는 추적 변수를 설정하지 않았고 진단 빌드는 1로 설정했다. .bss에 포함된 작업 스택과 링커가 별도 확보한 .stack을 구별했다. 각 이미지 원본·로드 세그먼트 원본·해시·링크 심볼은 개별 폴더 및 matrix.json에 있다. 각 build.json과 guest.json은 명령과 실행 시각(Unix 초)을 기록한다.', '', '|App|Mode|ELF|.text|.rodata|.bss|.stack|','|---|---|---:|---:|---:|---:|---:|']
for r in rows:report.append('| '+' | '.join(map(str,[r['app'],r['mode'],r['elf_size']]+[r['sections'][k]['size'] for k in ['.text','.rodata','.bss','.stack']]))+' |')
report+=['','## Guest references / 게스트 기준 실행','','Each capture used the public acquisition recipe retained under source/. Each timing value is from one QEMU TCG guest on this host. 거부 게스트에는 작업 실행 시간이 없으며, 허용 게스트의 관측값은 해당 단일 실행에 한정된다.','']
for d in sorted(raw.glob('*-trace')):
 if not (d/'guest.json').exists():continue
 g=json.loads((d/'guest.json').read_text());re=json.loads((d/'replay.json').read_text());assert g['rc']==(0 if d.name.startswith('ml') else 124)
 report+=['- '+d.name+' · host rc '+str(g['rc'])+' · replay rc '+str(re['rc'])+' · '+ ' '.join((d/'replay.stdout').read_text().split())]
(raw/'report.en-ko.md').write_text('\n'.join(report)+'\n')
files=sorted(f for f in raw.rglob('*') if f.is_file() and f.name!='SHA256SUMS')
(raw/'SHA256SUMS').write_text(''.join(digest(f)+'  '+f.relative_to(raw).as_posix()+'\n' for f in files))
shutil.copytree(raw,dst,dirs_exist_ok=True)
for _ in range(2):
 for f in files:assert digest(dst/f.relative_to(raw))==digest(f)
z=dst.parent/(dst.name+'.zip')
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as zz:
 for f in files+[raw/'SHA256SUMS']:zz.write(dst/f.relative_to(raw),f.relative_to(raw))
with zipfile.ZipFile(z) as zz:
 assert zz.testzip() is None
 for f in files:assert hashlib.sha256(zz.read(f.relative_to(raw).as_posix())).hexdigest()==digest(f)
h=digest(z);assert digest(z)==h;Path(str(z)+'.sha256').write_text(h+'  '+z.name+'\n');print(h,len(files),flush=True)
