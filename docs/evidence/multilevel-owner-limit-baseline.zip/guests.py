from pathlib import Path
import subprocess as sp, time, json, os
b=Path.home()/'baseline259260';raw=b/'raw';tree=b/'tree'
def run(d,name,args,extra={}):
 env=dict(os.environ,**extra);s=time.time()
 with (d/(name+'.stdout')).open('wb') as out,(d/(name+'.stderr')).open('wb') as err:
  rc=sp.run(args,cwd=tree,env=env,stdin=sp.DEVNULL,stdout=out,stderr=err).returncode
 (d/(name+'.json')).write_text(json.dumps(dict(cmd=args,start_epoch=s,end_epoch=time.time(),rc=rc,extra=extra),indent=2));print(name,d.name,rc,flush=True)
for app in ['mlq','mlfq','ordinary-edf-supply','ordinary-llf-supply','ordinary-edf-supply-refuse','ordinary-llf-supply-refuse']:
 d=raw/(app+'-trace');elf=str(d/'kernel.elf')
 if app in ['mlq','mlfq']:
  run(d,'guest',['python3','tools/qemu_boot.py','--profile',app,'--runs','1','--qemu','tools/ordinary_multilevel_capture.py','--kernel',elf],dict(ORDINARY_MULTILEVEL_CAPTURE_DIR=str(d/'capture')))
  run(d,'replay',['python3','tools/ordinary_multilevel_replay.py',app,str(d/'capture/audit.bin')])
 else:
  run(d,'guest',['timeout','10s','qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-accel','tcg','-smp','1','-m','128M','-nographic','-nic','none','-monitor','none','-serial','stdio','-d','int','-D',str(d/'exceptions.log'),'-kernel',elf])
  run(d,'replay',['python3','tools/deadline_supply_replay.py',app,str(d/'guest.stdout')])
