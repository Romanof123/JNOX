from pathlib import Path
import subprocess as sp, json, re, hashlib, os, time, shutil, sys
b=Path.home()/'baseline259260'; t=b/'tree'; raw=b/'raw'
sha=lambda x:hashlib.sha256(x).hexdigest()
env=dict(os.environ,PATH=str(Path.home()/'jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')+':/usr/bin:/bin',CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR=str(b/'target'))
def run(cmd,d,name,cwd=t,env=env):
 s=time.time(); o=sp.run(cmd,cwd=cwd,env=env,capture_output=True);(d/(name+'.stdout')).write_bytes(o.stdout);(d/(name+'.stderr')).write_bytes(o.stderr);(d/(name+'.json')).write_text(json.dumps(dict(cmd=cmd,cwd=str(cwd),start_epoch=s,end_epoch=time.time(),rc=o.returncode,settings={k:v for k,v in env.items() if k.startswith(('CARGO','JNOX','ORDINARY'))}),indent=2));return o
rows=[]
for profile in ['multilevel','deadline']:
 src=(t/'kernel/build.rs').read_text().split('Some("'+profile+'") => {')[1].split('Some(name @ (')[1].split('))')[0]
 for app in re.findall(r'"([^"]+)"',src):
  for mode in ['plain','trace']:
   d=raw/(app+'-'+mode);d.mkdir(exist_ok=True);e=dict(env,JNOX_PROFILE=profile,JNOX_APP=app)
   if mode=='trace':e['JNOX_'+profile.upper()+'_TRACE']='1'
   cmd=['cargo','build','--release','--locked','--target','aarch64-unknown-none','-j','1']; r=run(cmd,d,'build',t/'kernel',e);assert r.returncode==0,r.stderr
   f=d/'kernel.elf';shutil.copyfile(b/'target/aarch64-unknown-none/release/jnox-kernel',f);data=f.read_bytes()
   def read(*args):return sp.check_output(['readelf','-W',*args,str(f)],text=True)
   sec=read('-S');segs=read('-l');syms=read('-s');(d/'readelf.txt').write_text(sec+segs+syms)
   row=dict(profile=profile,app=app,mode=mode,elf_size=len(data),elf_sha256=sha(data),segments=[],sections={},stack_symbols=[x.strip() for x in syms.splitlines() if 'stack' in x.lower()])
   for i,m in enumerate(re.finditer(r'^  LOAD\s+(0x\w+)\s+(0x\w+)\s+(0x\w+)\s+(0x\w+)\s+(0x\w+)',segs,re.M)):
    off,va,pa,fs,ms=[int(x,16) for x in m.groups()];part=data[off:off+fs];(d/f'load{i}.bin').write_bytes(part);row['segments'].append(dict(offset=off,va=va,pa=pa,filesz=fs,memsz=ms,sha256=sha(part)))
   for n,typ,addr,off,size in re.findall(r'\[\s*\d+\]\s+(\.\S+)\s+(\S+)\s+(\w+)\s+(\w+)\s+(\w+)',sec):
    if n in ['.text','.rodata','.bss','.stack']:
     off,size=int(off,16),int(size,16);row['sections'][n]=dict(addr=int(addr,16),size=size,sha256=None if typ=='NOBITS' else sha(data[off:off+size]))
   rows.append(row);print(app,mode,flush=True)
(raw/'matrix.json').write_text(json.dumps(rows,indent=2))
