"""Pack frozen evidence into a portable content-addressed ZIP or restore and verify it."""
import argparse
import gzip
import hashlib
import json
import os
import stat
import tempfile
import zipfile
from pathlib import Path, PurePosixPath


BLOCK = 1024 * 1024


def relative(name):
    path = PurePosixPath(name)
    if not path.parts or path.is_absolute() or ".." in path.parts or "\\" in name or ":" in name:
        raise ValueError(f"unsafe portable path {name!r}")
    return path


def decoded_ram(path):
    checksum = hashlib.sha256()
    size = 0
    with gzip.open(path, "rb") as stream:
        while block := stream.read(BLOCK):
            checksum.update(block)
            size += len(block)
    return {"size": size, "sha256": checksum.hexdigest()}


def add_file(archive, seen, src):
    digest = hashlib.sha256()
    chunks = []
    size = 0
    with src.open("rb") as stream:
        while block := stream.read(BLOCK):
            size += len(block)
            digest.update(block)
            if block.count(0) == len(block):
                chunks.append(None)
                continue
            key = hashlib.sha256(block).hexdigest()
            if key not in seen:
                archive.writestr("objects/" + key, block)
                seen.add(key)
            chunks.append(key)
    result = {"size": size, "sha256": digest.hexdigest(), "chunks": chunks}
    if src.name.endswith(".ram.gz"):
        result["full_memory"] = decoded_ram(src)
    return result


def store(inventory, output):
    roots = json.loads(inventory.read_text(encoding="utf-8"))
    files = {}
    seen = set()
    if output.exists():
        raise FileExistsError(output)
    temporary = tempfile.NamedTemporaryFile(dir=output.parent, delete=False)
    temporary.close()
    stage = Path(temporary.name)
    try:
        with zipfile.ZipFile(stage, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for spec in roots:
                root = Path(spec["source"]).absolute()
                label = relative(spec["name"])
                if output.resolve().is_relative_to(root.resolve()):
                    raise ValueError("output inside frozen input")
                if not root.exists() or root.is_symlink():
                    raise ValueError(f"missing or symlinked source {root}")
                paths = [root]
                if root.is_dir():
                    excluded = set(spec.get("exclude_directories", []))
                    for folder, folders, filenames in os.walk(root):
                        folders[:] = sorted(name for name in folders if name not in excluded)
                        paths.extend(Path(folder, name) for name in folders)
                        paths.extend(Path(folder, name) for name in sorted(filenames))
                for path in paths:
                    name = str(label / path.relative_to(root).as_posix())
                    before = path.lstat()
                    if name in files:
                        raise ValueError(f"duplicate member {name}")
                    entry = {"mode": stat.S_IMODE(before.st_mode), "mtime_ns": before.st_mtime_ns}
                    if stat.S_ISREG(before.st_mode):
                        entry.update(type="file", **add_file(archive, seen, path))
                    elif stat.S_ISDIR(before.st_mode):
                        entry["type"] = "directory"
                    else:
                        raise ValueError(f"unsupported nonregular input {path}")
                    after = path.lstat()
                    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                        raise RuntimeError(f"input changed while packing {path}")
                    files[name] = entry
            manifest = {"format": 1, "block_bytes": BLOCK, "roots": [
                {k: v for k, v in spec.items() if k != "source"} for spec in roots
            ], "entries": files}
            archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2))
        # Publish without replacing an existing release.
        os.link(stage, output)
    finally:
        stage.unlink(missing_ok=True)


def restore(source, out):
    out.mkdir()
    directories = []
    with zipfile.ZipFile(source) as archive:
        manifest = json.loads(archive.read("manifest.json"))
        if manifest["format"] != 1 or manifest["block_bytes"] != BLOCK:
            raise ValueError("unsupported archive format")
        for name, entry in manifest["entries"].items():
            dest = out.joinpath(*relative(name).parts)
            dest.parent.mkdir(parents=True, exist_ok=True)
            if entry["type"] == "directory":
                dest.mkdir(exist_ok=True)
                directories.append((dest, entry))
                continue
            if entry["type"] != "file":
                raise ValueError(f"unsupported type {name}")
            digest = hashlib.sha256()
            remaining = entry["size"]
            with dest.open("xb") as stream:
                for key in entry["chunks"]:
                    size = min(BLOCK, remaining)
                    if size <= 0:
                        raise ValueError(f"extra chunk in {name}")
                    if key is None:
                        block = bytes(size)
                        stream.seek(size, 1)
                    else:
                        block = archive.read("objects/" + key)
                        if len(block) != size or hashlib.sha256(block).hexdigest() != key:
                            raise ValueError(f"bad chunk {name}")
                        stream.write(block)
                    remaining -= size
                    digest.update(block)
                stream.truncate(entry["size"])
            if remaining or digest.hexdigest() != entry["sha256"]:
                raise ValueError(f"bad restored file {name}")
            if "full_memory" in entry and decoded_ram(dest) != entry["full_memory"]:
                raise ValueError(f"decoded RAM mismatch {name}")
            set_meta(dest, entry)
    for dest, entry in reversed(directories):
        set_meta(dest, entry)


def set_meta(dest, entry):
    dest.chmod(entry["mode"])
    os.utime(dest, ns=(entry["mtime_ns"], entry["mtime_ns"]))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    for action in ("pack", "restore"):
        command = sub.add_parser(action)
        command.add_argument("input", type=Path)
        command.add_argument("output", type=Path)
    args = parser.parse_args()
    (store if args.action == "pack" else restore)(args.input, args.output)
