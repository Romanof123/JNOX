"""Offline legacy window, headless, and four complete timing-array checks."""
import csv
import gzip
import hashlib
import json
import struct
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root / "independent"))
from memory import RAM, MASK, one, symbols

base = root / "449-build-02"
window = base / "regress-01/window"
record = json.loads((window / "result.json").read_bytes())
def sha(data):
    return hashlib.sha256(data).hexdigest()

assert record["pass"]
for name, expected in record["hashes"].items():
    assert sha((window / name).read_bytes()) == expected, name
for name, info in record["frames"].items():
    page = (window / (name + ".ppm")).read_bytes()
    assert page == (window / (name + "-repeat.ppm")).read_bytes()
    header = b"P6\n320 240\n255\n"
    assert page.startswith(header) and len(page) == len(header) + 320*240*3
    assert sha(page[len(header):]) == info["rgb_sha256"] and info["matched_pixels"] == 76800
assert len(record["frames"]) == 4
headless = base / "regress-01/headless"
h = json.loads((headless / "result.json").read_bytes())
uart = (headless / "uart.bin").read_bytes()
assert h["passed"] and h["uart_sha256"] == sha(uart)
assert b"NATIVE EL0 EXIT 74" in uart.splitlines()
counts = {}
for case in ("headless", "restart-quit", "primary-exit", "spare-fault"):
    single = case == "headless"
    pkg = base / ("headless-package" if single else "package")
    ramfile = (headless if single else base / "guest-01" / case / "boot") / "terminal.ram.gz"
    manifest = json.loads((pkg / "manifest.json").read_bytes())
    slots = manifest["slots"]
    assert len(slots) == (1 if single else 5)
    kernel = pkg / "kernel.elf"
    assert sha(kernel.read_bytes()) == manifest["kernel_elf_sha256"]
    address, size = one(symbols(kernel), lambda name: "native_el0_mmu" in name and "6SPACES" in name)
    stride, remainder = divmod(size, len(slots))
    assert not remainder and stride >= 4096 and stride % 4096 == address % 4096 == 0
    idx = 0 if single else 4
    pgtable = address + idx * stride
    slot = slots[idx]
    if "expected_ttbr0_el1" in slot:
        assert pgtable == (slot["expected_ttbr0_el1"] & MASK)
    elf = pkg / slot["elf"]
    assert sha(elf.read_bytes()) == slot["elf_sha256"]
    table = symbols(elf)
    with gzip.open(ramfile, "rb") as f:
        memory = RAM(f.read())
    def values(field):
        addr, length = one(table, lambda name: name == "restart_control_" + field)
        return struct.unpack(f"<{length//8}Q", memory.user(pgtable, addr, length))
    count, = values("count")
    deadlines, wake = values("deadline"), values("wake")
    with (base / "all-samples" / (case + ".csv")).open() as f:
        rows = list(csv.DictReader(f))
    assert count == len(deadlines) == len(wake) == len(rows) == 4096
    for i, row in enumerate(rows):
        assert (int(row["index"]), int(row["deadline_ns"]), int(row["wake_ns"])) == (i, deadlines[i], wake[i])
        assert row["inter_completion_ns"] == (str(wake[i] - wake[i-1]) if i else "")
        assert int(row["lateness_ns"]) == wake[i] - deadlines[i]
    counts[case] = count
print(json.dumps({"ordinary_window_pixel_pairs": 4, "pixels_each": 76800,
                  "headless_exit": 74, "ram_to_csv_samples": counts}, indent=2))
