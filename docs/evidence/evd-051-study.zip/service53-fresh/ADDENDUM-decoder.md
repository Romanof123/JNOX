# Independent verifier correction to CHG-053 REPORT.md

I retract my statement that the frozen decoder reverses the decision interval or assigns a timestamp as the phase. The decoder at 188faa91e5e0655f56cf6aca97001a4e61fa75c4, tools/control_service_markers.py, SHA-256 c0e6cb0466724cb0616d314955d12ce864589106c7172869969e57338850addc, uses (t,a) for actual_check and b for phase. My independent verifier uses the same mapping.

In boot 02, marker record n=9 is (kind=8,t=273778,a=275568,b=0). The corresponding UART record is (21,275568,0,273778). The decoder correctly gives phase 0, first phase class and 1790 check ticks. I have no contradictory tuple or revision. The claim that the four captured decoder outputs have invalid phase labels or cost attribution is withdrawn.

A separate validation issue is visible in the source: the slice checks establish that t and a lie inside the slice but do not explicitly require t <= a for kind 8. A reversed pair mirrored in UART could therefore evade these checks when both endpoints lie in the same slice. That is a hypothetical malformed input. The independent verifier explicitly required start <= end <= completion for all 624 actual UART phases and checked the four RAM joins.

The raw hashes, guest run outcomes, joined marker observations and independently recomputed timing results stand. This addendum supersedes the disputed decoder sentences in REPORT.md. Original evidence and checksums are preserved.

Signed by control_service_independent, independent CHG-053 verifier, 2026-11-24.
