import hashlib,json,tarfile,struct,re
from pathlib import Path
from collections import defaultdict
out=Path(__file__).resolve().parent
src=out.parent/'service53-corrected-builds'/'captures'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def save(p,obj): (out/p).write_text(json.dumps(obj,indent=2)+'\n')
index=load(src/'index.json')
assert len(index)==24 and sha((src/'index.json').read_bytes())==(src/'index.sha256').read_text().split()[0]
runs=[]
for it in index:
    path=src/it['archive']
    assert sha(path.read_bytes())==it['archive_sha256']
    with tarfile.open(path) as archive:
        files={Path(f.name).name:archive.extractfile(f).read() for f in archive if f.isfile()}
    hashes=json.loads(files['files.json'])
    assert set(hashes)==set(files)-{'files.json'} and all(sha(files[k])==v for k,v in hashes.items())
    lines=files['uart'].decode().splitlines()
    rows=[list(map(int,l.split())) for l in lines[lines.index('CONTROL RAW v1')+1:lines.index('CONTROL END')]]
    ev=lambda k:[r[1:] for r in rows if r[0]==k]
    epoch,hz,_=ev(1)[0]; step=hz//400
    phases=[]
    for i,((irq,idx,ac),(end,j,start),(fin,k,target)) in enumerate(zip(ev(3),ev(21),ev(10))):
        assert i==idx==ac==j==k and target==epoch+i*step and start<=end<=fin
        phases.append(dict(i=i,irq=irq-target,decision=end-target,check=end-start,completion=fin-target,service=sum(d for t,a,d in ev(8) if a==0 and fin<=t<(ev(10)[i+1][0] if i+1<len(ev(10)) else 2**64))))
    assert len(phases)==26
    fault=ev(15)[0][0] if ev(15) else None; latch=ev(13)[0][0] if ev(13) else None
    run=dict(ordinal=it['ordinal'],**it['case'],archive=path.name,archive_sha256=it['archive_sha256'],hashes_verified=len(hashes),phases=phases,
             longest_mask=ev(33)[0],irq_handlers=ev(34),svc_handlers=ev(35),jobs=[t-rel for t,a,rel in ev(9) if a==0],decision_gaps=[y[0]-x[0] for x,y in zip(ev(21),ev(21)[1:])],issue_gaps=[y[0]-x[0] for x,y in zip(ev(11),ev(11)[1:])],first_fault=next(iter(ev(15)),[None,None,None]),fault_to_latch=latch-fault if fault and latch else None,actions=ev(28),device=ev(18),edges=ev(14),deliveries=ev(12),commands=ev(17),rearms=ev(20),issue=ev(11),outputs=ev(19),rejects=ev(24),release_setup=[t-rel for t,a,rel in ev(4) if a==0],qualified=it['healthy_verdict'])
    if 'markers.bin' in files:
        data=files['markers.bin']; used,ov,sealed=struct.unpack_from('<3Q',data);assert not ov and sealed==1
        marks=[struct.unpack_from('<7Q',data,24+56*n) for n in range(used)]
        assert all(n+1==r[-1] and r[4]<=r[5] for n,r in enumerate(marks))
        erets=[int(x,16) for x in re.findall(rb'Exception return[^\n]+ PC (0x\w+)',files['exceptions'])]
        vectors=[(k.decode(),int(x,16)) for k,x in re.findall(rb'Taking exception \d+ \[(IRQ|SVC)\].*?with ELR (0x\w+)',files['exceptions'],re.S)]
        assert len(erets)==1+sum(r[0]==4 for r in marks) and len(vectors)==sum(r[0] in (2,3) for r in marks); assert [r[3] for r in marks if r[0]==4]==erets[:sum(r[0]==4 for r in marks)] and [('IRQ' if r[0]==2 else 'SVC',r[2]) for r in marks if r[0] in (2,3)]==vectors[:sum(r[0] in (2,3) for r in marks)]
        assert [[r[2],r[3],r[1]] for r in marks if r[0]==8]==ev(21)
        slices=[]; s=None;balance=[0,0]
        for k,t,a,b,ws,we,n in marks:
            if k==1:s=(t,a,b)
            if k==4:restore=(t,a,b)
            if k in (2,3) and s and s[1]<2:
                st,task,pc=s;assert st<=restore[0]<=restore[1]<=t and pc==restore[2]
                slices.append([t,task,t-st])
        assert slices==ev(6)
        for k,t,a,b in rows:
            if k==4:balance[a]=0
            if k==6:balance[a]+=b
            if k==8:assert balance[a]==b;balance[a]=0
        attr=[]
        for p,(e,idx,begin) in zip(phases,ev(21)):
            end,_,debit=next(r for r in slices if r[1]==0 and r[0]>=e)
            start=end-debit
            rr=next(r for r in marks if r[0]==4 and start<=r[1]<=end)
            samples=[r for r in marks if r[0] in (5,10) and start<=r[1]<=end]
            intervals=[(start,rr[1],'selection'),(rr[1],rr[2],'restore'),(begin,e,'check')]
            if samples:intervals.append((rr[2],samples[0][1],'tail_to_worker'))
            intervals.extend((r[4],r[5],'write') for r in marks if start<=r[4]<=r[5]<=end)
            boundaries=sorted({start,end,*(x for lo,hi,k in intervals for x in (lo,hi))}); parts=defaultdict(int)
            for lo,hi in zip(boundaries,boundaries[1:]):
                tags=[k for a,b,k in intervals if a<=lo and hi<=b]
                parts['write' if 'write' in tags else tags[0] if tags else 'remainder']+=hi-lo
            masks=[r for r in marks if r[0] in (6,7) and start<=r[1]<=end]
            inner=outer=0
            for enter,leave in zip(masks[::2],masks[1::2]):
                assert enter[0]==6 and leave[0]==7 and enter[1]<=enter[2]<=leave[1]<=leave[2]
                inner+=leave[1]-enter[2];outer+=leave[2]-enter[1]
            assert sum(parts.values())==debit
            attr.append(dict(i=idx,debit=debit,parts=dict(parts),mask_inner=inner,mask_outer=outer))
        run.update(attribution=attr,erets=len(erets),vectors=len(vectors),committed=used)
    runs.append(run)
save('observations.json',runs)
for r in runs:
    p=r['phases'][0]
    print(r['ordinal'],r['arm'],p['service'],p['decision'],p['irq'],p['check'],r['issue_gaps'][0],r['first_fault'][1],r['fault_to_latch'],max(r['jobs']),max(r['decision_gaps']))




