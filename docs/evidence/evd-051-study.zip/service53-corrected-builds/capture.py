"""Run only in the assigned serial slot. Every measured runtime path is on native Linux /tmp."""
from pathlib import Path
import argparse, hashlib, json, os, re, shutil, socket, struct, subprocess as sp, sys, tarfile, tempfile, time, traceback

def save(path,data):
    path.write_text(json.dumps(data,indent=2)+"\n")
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def loads(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def loads_image(path):
    data=path.read_bytes()
    ph=struct.unpack_from("<Q",data,32)[0]
    stride,n=struct.unpack_from("<HH",data,54)
    result=[]
    for i in range(n):
        kind,flags,off,va,pa,fsize,memsize,align=struct.unpack_from("<II6Q",data,ph+i*stride)
        if kind==1:
            result.append([flags,va,pa,fsize,memsize,align,hashlib.sha256(data[off:off+fsize]).hexdigest()])
    return result
def cmdrecord(directory,tag,argv):
    res=sp.run(argv,stdout=sp.PIPE,stderr=sp.PIPE)
    (directory/(tag+".stdout")).write_bytes(res.stdout)
    (directory/(tag+".stderr")).write_bytes(res.stderr)
    save(directory/(tag+".command.json"),dict(argv=list(map(str,argv)),exit=res.returncode))
    return res
def snapshot(qpath,d,marker,request):
    with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as conn:
        conn.settimeout(3)
        conn.connect(str(qpath))
        with conn.makefile("rwb",buffering=0) as stream:
            assert "QMP" in json.loads(stream.readline())
            request(stream,"qmp_capabilities")
            pre=request(stream,"query-status")
            cpus=request(stream,"query-cpus-fast")
            assert pre["running"] and len(cpus)==1
            request(stream,"stop")
            post=request(stream,"query-status")
            assert not post["running"]
            save(d/"qmp.json",{"before":pre,"after":post,"cpus":cpus})
            if marker:
                addr,size=marker
                request(stream,"pmemsave",val=addr,size=size,filename=str(d/"markers.bin"))
                assert (d/"markers.bin").stat().st_size==size==57368
def metrics(d):
    txt=(d/"uart").read_text(errors="replace").splitlines()
    start=txt.index("CONTROL RAW v1");end=txt.index("CONTROL END",start)
    rows=[list(map(int,line.split())) for line in txt[start+1:end]]
    assert all(len(r)==4 for r in rows)
    ev=lambda n:[r[1:] for r in rows if r[0]==n]
    epoch,hz,_=ev(1)[0]
    debits=[r for r in ev(8) if r[1]==0]
    decisions=ev(21)
    return dict(epoch=epoch,frequency=hz,phase_quantum=hz//400,charged_control_ticks=[r[2] for r in debits],
        first_overspend=next((r for r in debits if r[2]*1000000>250*hz),None),
        irq_lateness=[[r[1],r[0]-epoch-r[1]*(hz//400)] for r in ev(3)],
        decision_spacing=[y[0]-x[0] for x,y in zip(decisions,decisions[1:])],
        phase_decision=[[i,e,s,e-epoch-i*(hz//400)] for e,i,s in decisions],
        control_job_finish=[[r[2],r[0]-r[2]] for r in ev(9) if r[1]==0],
        actual_issue_gaps=[y[0]-x[0] for x,y in zip(ev(11),ev(11)[1:])],
        events_in_original_order=rows)
def main():
    parser=argparse.ArgumentParser();parser.add_argument("build_directory",type=Path);args=parser.parse_args()
    out=args.build_directory.resolve()
    dest=out/"captures";dest.mkdir(exist_ok=False)
    root=Path(tempfile.mkdtemp(prefix="s53-",dir="/tmp"))
    os.environ.update(TMPDIR=str(root),PYTHONDONTWRITEBYTECODE="1")
    os.chdir(root)
    cfg=loads(out/"protocol.json");idx=loads(out/"build-index.json");order=loads(out/"order.json")
    assert len(order)==24 and len(idx["images"])==8 and sha(out/"build-index.json")== (out/"build-index.sha256").read_text().split()[0]
    q=Path(cfg["qemu"]);assert sha(q)==cfg["qemu_sha256"]
    tools=root/"tools";tools.mkdir()
    for name,arm in [("qemu_capture.py","baseline"),("control_observations.py","baseline"),("control_service_markers.py","marker")]:
        shutil.copy2(out/"sources"/arm/"tools"/name,tools/name)
    sys.path.insert(0,str(tools))
    from qemu_capture import request
    save(dest/"host.json",dict(native_dir=str(root),boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
         fs=sp.check_output(["df","-T",root],text=True),qemu_version=sp.check_output([q,"--version"],text=True),
         qemu_sha256=sha(q),tools={f.name:sha(f) for f in tools.glob("*.py")},independent_score_command="python3 -B control_observations.py healthy uart"))
    built={}
    for name,meta in idx["images"].items():
        assert meta["exit"]==0
        img=root/"images"/name;img.mkdir(parents=True);elf=img/"kernel.elf"
        shutil.copy2(out/meta["file"],elf);assert sha(elf)==meta["sha256"]
        for tag,cmd in [("symbols",["aarch64-linux-gnu-nm","-nS"]),("disassembly",["aarch64-linux-gnu-objdump","-dC"]),("sections",["aarch64-linux-gnu-size","-A"]),("segments",["aarch64-linux-gnu-readelf","-lW"])]:
            assert cmdrecord(img,tag,[*cmd,elf]).returncode==0
        sym=re.findall(r"^([0-9a-f]+) ([0-9a-f]+) \w control_marker_journal$", (img/"symbols.stdout").read_text(),re.M)
        assert len(sym)==int(meta["arm"]=="marker")
        marker=tuple(int(x,16) for x in sym[0]) if sym else None
        if marker: assert marker[1]==57368
        provenance=dict(elf_sha256=sha(elf),load_segments=loads_image(elf),marker=marker)
        if meta["arm"]=="baseline":
            ref=out/"images"/name/"archived-v2.elf"
            assert sha(ref)==meta["archived_v2_sha256"]
            provenance.update(archived_v2_sha256=sha(ref),archived_v2_load_identical=loads_image(ref)==loads_image(elf))
        save(img/"provenance.json",provenance)
        shutil.copytree(img,dest/"images"/name)
        built[name]=elf,marker
    summary=[]
    for n,case in enumerate(order,1):
        key=f"{n:02d}-{case['comparison']}-{case['policy']}-p{case['pair']}-{case['arm']}"
        d=root/key;d.mkdir()
        elf,marker=built[case["policy"]+"-"+case["arm"]]
        uart=d/"uart";trace=d/"exceptions";sock=d/"q"
        argv=[str(q),*cfg["qemu_options"],"-serial","file:"+str(uart),"-d","int","-D",str(trace),"-qmp","unix:"+str(sock)+",server=on,wait=off","-kernel",str(elf)]
        meta=dict(case=case,ordinal=n,elf_sha256=sha(elf),argv=argv,clock="default",terminal=False,prelaunch_loadavg=Path("/proc/loadavg").read_text())
        save(d/"execution.json",meta);proc=None
        try:
            with (d/"stderr").open("wb") as err,(d/"stdout").open("wb") as stdout:
                t=time.monotonic_ns();meta["launch_monotonic_ns"]=t
                proc=sp.Popen(argv,stdout=stdout,stderr=err)
                meta["pid"]=proc.pid
                while proc.poll() is None and time.monotonic_ns()-t < cfg["guest_deadline_seconds"]*10**9:
                    if uart.is_file() and uart.read_bytes().endswith(b"CONTROL END\n"):
                        meta["terminal"]=True;meta["terminal_monotonic_ns"]=time.monotonic_ns();break
                    time.sleep(.001)
                if meta["terminal"]:snapshot(sock,d,marker,request)
        except Exception:
            meta["capture_error"]=traceback.format_exc()
        finally:
            if proc is not None:
                if proc.poll() is None:proc.terminate()
                try:proc.wait(3)
                except sp.TimeoutExpired:proc.kill();proc.wait()
                meta["exit"]=proc.returncode
            if sock.exists():sock.unlink()
        try:
            score=cmdrecord(d,"healthy_score",[sys.executable,"-B",tools/"control_observations.py","healthy",uart])
            meta["healthy_verdict"]=json.loads(score.stdout)["verdict"]
            meta["score_exit"]=score.returncode
            if meta["terminal"]:
                save(d/"metrics.json",metrics(d))
            if marker:
                dec=cmdrecord(d,"marker_decode",[sys.executable,"-B",tools/"control_service_markers.py",d/"markers.bin",uart])
                meta["marker_decode_exit"]=dec.returncode
            if trace.is_file():
                events=[line for line in trace.read_text(errors="replace").splitlines() if line.startswith(("Taking exception","...with ESR","...with ELR","...to EL","Exception return"))]
                (d/"exception-events.txt").write_text("\n".join(events)+"\n")
                meta["exception_count"]=sum(x.startswith("Taking exception") for x in events)
                meta["eret_count"]=sum(x.startswith("Exception return") for x in events)
        except Exception:
            meta["scoring_error"]=traceback.format_exc()
        save(d/"execution.json",meta);save(d/"files.json",{f.name:sha(f) for f in d.iterdir() if f.is_file() and f.name!="files.json"})
        archive=dest/(key+".tar.gz")
        with tarfile.open(archive,"x:gz") as a:a.add(d,arcname=key)
        summary.append(dict(**meta,archive=archive.name,archive_sha256=sha(archive)))
        save(dest/"index.json",summary);print(n,key,meta["terminal"],meta.get("healthy_verdict"),flush=True)
    (dest/"index.sha256").write_text(sha(dest/"index.json")+"  index.json\n")
if __name__=="__main__":
    main()
