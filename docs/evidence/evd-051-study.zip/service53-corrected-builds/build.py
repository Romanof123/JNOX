"""Windows preparation for a single future authorized build/run. Never overwrites a run."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess as sp, zipfile

here = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
def git(repo, *args):
    return sp.check_output(["git", "-C", str(repo), *args], text=True).strip()
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    config = json.loads((here/"protocol.json").read_text(encoding="utf-8-sig"))
    repo = here.parent/config["source_repository"]
    for item in ["protocol.json","capture.py","build.py","order.json"]:
        shutil.copy2(here/item,out/item)
    ref = here.parent/config["baseline_reference"]
    assert sha(ref) == config["reference_index_sha256"]
    refs = json.loads(ref.read_bytes())["images"]
    sources = {}
    for name, commit in config["sources"].items():
        archive = out/(name+".zip")
        sp.run(["git","-C",str(repo),"archive","--format=zip","-o",str(archive),commit],check=True)
        source = out/"sources"/name
        with zipfile.ZipFile(archive) as z:
            z.extractall(source)
        sources[name] = {"commit":commit,"tree":git(repo,"rev-parse",commit+"^{tree}"),"archive_sha256":sha(archive)}
    rust = sp.check_output(["rustc","+1.95.0","-vV"],text=True)
    assert "host: x86_64-pc-windows-msvc" in rust and "59807616e" in rust
    meta = {"sources":sources,"rust":rust,"cargo":sp.check_output(["cargo","+1.95.0","--version"],text=True).strip(),"images":{}}
    for policy in config["policies"]:
        for arm,(source,opt,selectors) in config["arms"].items():
            name = policy+"-"+arm
            d = out/"images"/name
            d.mkdir(parents=True)
            env = {k:v for k,v in os.environ.items() if not k.startswith(("JNOX_","CARGO_PROFILE_RELEASE_","CARGO_TARGET_AARCH64_")) and k not in ("RUSTFLAGS","CARGO_ENCODED_RUSTFLAGS","RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","RUSTC")}
            overrides = dict(config["common_selectors"],JNOX_APP="control-"+policy,CARGO_BUILD_JOBS="1",CARGO_TARGET_DIR=str(out/"targets"/name),TMP=str(d),TEMP=str(d),**selectors)
            if opt == "3":
                overrides["CARGO_PROFILE_RELEASE_OPT_LEVEL"]="3"
            env.update(overrides)
            src = out/"sources"/source/"kernel"
            assert 'opt-level = "s"' in (src/"Cargo.toml").read_text()
            with (d/"build.log").open("wb") as log:
                rc=sp.run(config["build"],cwd=src,env=env,stdout=log,stderr=sp.STDOUT).returncode
            row={"arm":arm,"policy":policy,"source":source,"opt":opt,"cwd":str(src),"argv":config["build"],"env":{k:v for k,v in env.items() if k.startswith(("CARGO_","JNOX_","RUST")) and not any(s in k for s in ["TOKEN","PASSWORD","SECRET"])}, "exit":rc,"build_log_sha256":sha(d/"build.log")}
            if rc==0:
                elf=d/"kernel.elf"
                shutil.copy2(Path(overrides["CARGO_TARGET_DIR"])/config["target"]/"release/jnox-kernel",elf)
                row.update(sha256=sha(elf),file=str(elf.relative_to(out).as_posix()))
                if arm=="baseline":
                    reference=refs[policy+"-healthy"]
                    refelf=ref.parent/reference["path"]
                    assert sha(refelf)==reference["sha256"]
                    row.update(archived_v2_sha256=reference["sha256"],whole_elf_equal_to_v2=sha(elf)==reference["sha256"])
                    shutil.copy2(refelf,d/"archived-v2.elf")
            meta["images"][name]=row
            save(out/"build-index.json",meta)
            print(name,rc,row.get("sha256"),flush=True)
    (out/"build-index.sha256").write_text(sha(out/"build-index.json")+"  build-index.json\n")
    if any(x["exit"] for x in meta["images"].values()):
        raise SystemExit("Build failures retained; cohort has not launched.")
if __name__=="__main__":
    main()
