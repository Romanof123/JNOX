from pathlib import Path
import os,shutil,json,hashlib,zipfile,subprocess as sp
p=Path(__file__).resolve().parent;root=p.parent;old=root/'service53-builds';repo=root/'control-markers-repaired'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def save(path,obj):path.write_bytes((json.dumps(obj,indent=2)+'\n').encode())
base=(root/'partition-parent-builds/batches.py').read_text(encoding='utf-8-sig')
exec(base[base.index('def elf('):base.index('def batch(')],globals())
import struct
h=lambda b:hashlib.sha256(b).hexdigest()
rev='188faa91e5e0655f56cf6aca97001a4e61fa75c4'
assert sp.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==rev and not sp.check_output(['git','status','--porcelain'],cwd=repo)
assert sha(old/'build-index.json')=='70a9bedb3035daca62ff60cfec9f45ce6df4070237398401facd403e42f52d27'
idx=json.loads((old/'build-index.json').read_bytes())
idx['first_batch_sha256']=sha(old/'build-index.json');idx['first_batch_location']='../service53-builds'
idx['controls']={k:v for k,v in idx['controls'].items() if 'descriptor' in k}
for f in ['build.py','capture.py','order.json']:shutil.copy2(old/f,p/f)
cfg=json.loads((old/'protocol.json').read_text(encoding='utf-8-sig'));cfg['sources']['marker']=rev;save(p/'protocol.json',cfg)
for branch in idx['sources']:
 z=p/(branch+'.zip')
 if branch=='marker':sp.run(['git','archive','--format=zip','-o',str(z),rev],cwd=repo,check=True);idx['sources'][branch]=dict(commit=rev,tree=sp.check_output(['git','rev-parse','HEAD^{tree}'],cwd=repo,text=True).strip(),archive_sha256=sha(z))
 else:shutil.copy2(old/z.name,z);assert sha(z)==idx['sources'][branch]['archive_sha256']
 with zipfile.ZipFile(z) as f:f.extractall(p/'sources'/branch)
for k,v in idx['images'].items():
 if v['arm']!='marker':
  shutil.copytree(old/'images'/k,p/'images'/k)
  assert sha(p/v['file'])==v['sha256'];v['origin']='retained original build'
def build(name,policy,selectors,dest,ref):
 dest.mkdir(parents=True);src=p/'sources/marker/kernel'
 env={k:v for k,v in os.environ.items() if not k.startswith(('JNOX_','CARGO_PROFILE_RELEASE_','CARGO_TARGET_AARCH64_')) and k not in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTC')}
 over=dict(cfg['common_selectors'],JNOX_APP='control-'+policy,CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR=str(p/'targets'/name),TMP=str(dest),TEMP=str(dest),**selectors);env.update(over)
 with (dest/'build.log').open('wb') as f:r=sp.run(cfg['build'],cwd=src,env=env,stdout=f,stderr=sp.STDOUT)
 row=dict(source='marker',policy=policy,arm='marker' if name.endswith('-marker') else name,opt='s',origin='repaired marker snapshot',exit=r.returncode,argv=cfg['build'],cwd=str(src),env=over,build_log_sha256=sha(dest/'build.log'))
 if r.returncode==0:
  elf=dest/'kernel.elf';shutil.copyfile(Path(over['CARGO_TARGET_DIR'])/cfg['target']/'release/jnox-kernel',elf)
  row.update(file=elf.relative_to(p).as_posix(),sha256=sha(elf),prior_comparison=compare(elf,ref))
  nm=sp.check_output(['wsl','-d','Ubuntu','--exec','aarch64-linux-gnu-nm','-nS','/mnt/d/'+elf.as_posix().split(':/',1)[1]])
  (dest/'symbols.txt').write_bytes(nm);records=[line.decode().split() for line in nm.splitlines() if line.endswith(b' control_marker_journal')]
  row.update(marker_symbol=records,symbols_sha256=h(nm))
  assert len(records)==int(name.endswith('-marker'))
  if records:assert records==idx['images'][name]['marker_symbol'] and int(records[0][1],16)==57368
 else:row['rejection_identified']=b'JNOX_CONTROL_MARKERS and JNOX_CONTROL_DESCRIPTOR require separate builds' in (dest/'build.log').read_bytes()
 print(name,r.returncode,row.get('prior_comparison',{}).get('identical'),row.get('rejection_identified'),flush=True)
 return row
for pol in ['rm','dm']:
 name=pol+'-marker';idx['images'][name]=build(name,pol,{'JNOX_CONTROL_MARKERS':'1'},p/'images'/name,old/'images'/name/'kernel.elf')
 name=pol+'-marker-unset';idx['controls'][name]=build(name,pol,{},p/'controls'/name,old/'controls'/name/'kernel.elf')
 name=pol+'-marker-mixed';idx['controls'][name]=build(name,pol,{'JNOX_CONTROL_MARKERS':'1','JNOX_CONTROL_DESCRIPTOR':'1'},p/'controls'/name,None)
idx['scope']='Six unchanged cohort images retained byte-for-byte from first batch; two corrected markers rebuilt. Unset controls compare to first marker-unset builds. Mixed selectors rejected on both corrected policies. First-batch marker-only branch accepted mixed selectors; its immutable raw record is retained separately.'
for k,v in idx['images'].items():assert v['exit']==0 and sha(p/v['file'])==v['sha256']
save(p/'build-index.json',idx);(p/'build-index.sha256').write_text(sha(p/'build-index.json')+'  build-index.json\n')
checks={}
for key,src,script,args in [('partition-pycompat','partition-pycompat','test_ordinary_partition_account.py',[]),('partition-current-main','partition-current-main','scheduling_evidence.py',[]),('reservations-plan-current','reservations-plan-current','scheduling_evidence.py',[])]:
 dir=root/src;cmd=[os.sys.executable,'-B','tools/'+script,*args];r=sp.run(cmd,cwd=dir,stdout=sp.PIPE,stderr=sp.PIPE)
 (p/(key+'.stdout')).write_bytes(r.stdout);(p/(key+'.stderr')).write_bytes(r.stderr)
 rec=dict(argv=cmd,cwd=str(dir),head=sp.check_output(['git','rev-parse','HEAD'],cwd=dir,text=True).strip(),tree=sp.check_output(['git','write-tree'],cwd=dir,text=True).strip(),exit=r.returncode,stdout_sha256=h(r.stdout),stderr_sha256=h(r.stderr))
 if script=='scheduling_evidence.py':
  data=json.loads(r.stdout);rec.update(policies=len(data['policies']),evidence=len(data['evidence']),findings=data['findings'])
 else:rec['output']=(r.stdout+r.stderr).decode(errors='replace')
 checks[key]=rec;print(key,rec,flush=True)
save(p/'host-checks.json',checks)
print('INDEX',sha(p/'build-index.json'),'DRIVER',sha(p/'capture.py'))
