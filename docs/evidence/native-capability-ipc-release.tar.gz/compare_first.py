"""Compare complete application rows and kernel-state samples to original replay JSON."""
import sys,json
from pathlib import Path
orig,new=[json.loads(Path(p).read_text()) for p in sys.argv[1:]]
cases=[f"{case}-{policy}" for case in ("transfer","before","pending","active","target","mailbox") for policy in ("fifo","rr")]
for name in cases:
    assert new[name]["data"]==orig[name]["data"] and new[name]["states"]==orig[name]["states"],name
print("12 matched complete private datasets and boot/terminal state tables")
