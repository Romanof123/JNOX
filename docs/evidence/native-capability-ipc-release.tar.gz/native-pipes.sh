set -eux
src="$PWD"
rev=$(git rev-parse HEAD)
cd "/home/ywcho/cap387new/src/evidence"
dir="$src"/examples/native-pipes
sh "$src"/sdk/native-aarch64/build.sh --pipes "$dir/writer.c" writer.elf
sh "$src"/sdk/native-aarch64/build-rust.sh --pipes "$dir/writer-rust/Cargo.toml" rust-writer.elf
sh "$src"/sdk/native-aarch64/build.sh --pipes "$dir/reader.c" reader.elf
sh "$src"/sdk/native-aarch64/build.sh --pipes "$dir/anon-writer.c" anon-writer.elf
sh "$src"/sdk/native-aarch64/build.sh --pipes "$dir/anon-reader.c" anon-reader.elf
package() {
    policy=$1
    shift
    python3 "$src"/tools/build_native_el0.py --pipes --policy "$policy" "$@" --out "pipe-named-$policy" \
        --elf writer.elf --priority 3 --peer-elf rust-writer.elf --peer-priority 3 \
        --peer-elf reader.elf --peer-priority 3 --fifo-grant 0:4:3 \
        --pipe-link 0:3:1:3 --pipe-link 0:4:2:3 --pipe-link 1:4:0:5
    python3 "$src"/tools/build_native_el0.py --pipes --policy "$policy" "$@" --out "pipe-anon-$policy" \
        --elf anon-writer.elf --priority 3 --peer-elf anon-reader.elf --peer-priority 3 \
        --pipe-link 0:1:1:0 --pipe-link 1:4:0:4
}
package fifo
package rr --quantum-ticks 625000

for pol in fifo rr; do p=pipe-named-$pol; python3 "$src"/tools/native_el0_capture.py run-$p "$p/kernel.elf" writer.elf "$dir/writer.c" "$rev" --plain --manifest "$p/manifest.json" --expect-exit 61 --timeout 20; done

for pol in fifo rr; do p=pipe-anon-$pol; python3 "$src"/tools/native_el0_capture.py run-$p "$p/kernel.elf" anon-writer.elf "$dir/anon-writer.c" "$rev" --plain --manifest "$p/manifest.json" --expect-exit 64 --timeout 20; done
