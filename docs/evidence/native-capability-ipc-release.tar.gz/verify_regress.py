"""Replay integrated profile captures from ELF symbols, per-slot page tables and packet bytes."""
from pathlib import Path
import json,struct,subprocess,hashlib,zlib,re
P=Path(__file__).resolve().parent
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def sym(path):
    return {s[3]:(int(s[0],16),int(s[1],16)) for line in subprocess.check_output(["nm","-S",path],text=True).splitlines() if len(s:=line.split())==4}
def verify(name,apps,exits):
    inet=name.startswith('inet')
    pkg=P/name
    cap=P/(name+"-first" if inet else "run-"+name)
    manifest=json.loads((pkg/"manifest.json").read_text())
    assert manifest["commit"]=="1d017b042e3490ea63436b4604836257397310fd" and not manifest["tracked_changes"]
    uart=(cap/("uart" if inet else "uart.bin")).read_text()
    assert [int(x) for x in re.findall(r"NATIVE EL0 EXIT PID \d+ (\d+)",uart)]==exits
    assert [s["elf_sha256"] for s in manifest["slots"]]==[digest(P/(app+".elf")) for app in apps]
    assert digest(pkg/"kernel.elf")==manifest["kernel_elf_sha256"]
    launch=json.loads((cap/"launch.json").read_text())
    if inet: assert launch["kernel_sha256"]==manifest["kernel_elf_sha256"]
    else:
        assert digest(cap/"kernel.elf")==manifest["kernel_elf_sha256"]
        assert all(digest(cap/f)==h for f,h in json.loads((cap/"session.json").read_text())["hashes"].items())
    base=0x40000000 if inet else launch["ram_base"]
    ram=(cap/"ram.bin").read_bytes()
    space,size=next(v for k,v in sym(pkg/"kernel.elf").items() if "native_el0_mmu6SPACES" in k)
    maps=[sym(P/(app+".elf")) for app in apps]
    def read(i,key,fmt="B"):
        va,n=maps[i][key]
        buf=b""
        while n:
            pa=space+i*(size//len(apps))
            for shift in (30,21,12):
                desc=struct.unpack_from("<Q",ram,pa-base+8*((va>>shift)&511))[0]
                assert desc&3==3
                pa=desc&0xfffffffff000
            offset=va%4096
            m=min(n,4096-offset)
            buf+=ram[pa-base+offset:pa-base+offset+m];va+=m;n-=m
        return list(v[0] for v in struct.iter_unpack("<"+fmt,buf))
    if name.startswith("telemetry"):
        lengths=[0,1,7,32,11,3,19,6]
        for i,ids,ik,sk,dk in [(0,list(range(1,9)),"published_ids","published_sizes","published_bytes"),(1,list(range(1,9)),"active_ids","active_sizes","active_data"),(2,[1,2,3,4,8],"stalled_ids","stalled_sizes","stalled_data")]:
            assert read(i,ik,"Q")==ids and read(i,sk)==[lengths[s-1] for s in ids]
            raw=read(i,dk)
            for j,s in enumerate(ids):assert raw[32*j:32*j+lengths[s-1]]==[(43*s+19*k+k//2)%256 for k in range(lengths[s-1])]
        assert read(1,"active_observations","Q")==sum(([1,1,0,s] for s in range(1,9)),[])
        assert read(2,"queue_before","Q")==[4,4,2,1]
        assert [read(i,k,"q")[0] for i,k in [(0,"publisher_subscribe_status"),(1,"active_terminal_wait"),(2,"stale_status"),(2,"empty_status"),(2,"wrong_publish")]]==[-13,-32,-116,-11,-13]
        r=read(3,"pubsub_report","Q");assert r[1:4]==[0,0,0] and r[12]==0
        return dict(report=r)
    if name.startswith("pipe-anon"):
        assert bytes(read(1,"anon_data"))==b"rainfall"
        assert [read(1,k,"i")[0] for k in ["anon_eof","anon_epipe_rc","anon_epipe_errno","anon_done"]]==[0,-1,32,1]
        assert read(0,"anon_writer_steps","i")==[2]
        return {"bytes":"rainfall"}
    if name.startswith("pipe-named"):
        raw=bytes(read(2,"pipe_received")); seen=[0,0]
        for i in range(0,len(raw),512):
            block=raw[i:i+512];o,s=block[:2];assert s==seen[o];seen[o]+=1
            assert block[2:508]==bytes((97*o+31*s+17*k+k//8)%256 for k in range(2,508))
            crc=zlib.crc32(block[:508]);assert int.from_bytes(block[508:],"little")==crc==read(o,["c_writer_crc","rust_writer_crc"][o],"I")[s]
        assert seen==[8,8] and read(2,"pipe_eof","I")==[1]
        assert read(0,"c_full_rc","i")==[-1] and read(0,"c_full_errno","i")==[11]
        chunks=read(2,"pipe_read_sizes","H")[:read(2,"pipe_reads","I")[0]]; assert chunks[-1]==0 and sum(chunks)==8192 and all(0<x<=137 for x in chunks[:-1])
        return dict(received_sha256=hashlib.sha256(raw).hexdigest(),records=seen)
    tcp=read(0,"inet_tcp_result","q");udp=read(1,"inet_udp_result","q")
    assert tcp[:3]==[4,9,13] and 1<=tcp[3]<=3 and tcp[4:]==[0,12,14,0,4,-1,104,1]
    assert udp[:10]==[3,3,3,3,1,4,3,0,0x0a000202,43004] and udp[10]>0 and udp[11:]==[1,0,0,0,0]
    logs=[json.loads(l) for l in (cap/"peer.jsonl").read_text().splitlines()]
    def words(kind):return [e["data"] for e in logs if e["kind"]==kind]
    assert words("udp_before_relay")==["55010a","550214","55031e","550428"] and words("udp_after_relay")==["52010a","520428","52031e","520000"]
    wire=(cap/"wire.pcap").read_bytes(); pos=24; reset=False; udp_wire=[]
    while pos<len(wire):
        n=struct.unpack_from("<I",wire,pos+8)[0]; frame=wire[pos+16:pos+16+n];pos+=16+n
        if frame[12:14]!=b'\x08\x00':continue
        ip=frame[14:];start=(ip[0]&15)*4;end=int.from_bytes(ip[2:4],"big");seg=ip[start:end]
        if ip[9]==6 and int.from_bytes(seg[:2],"big")==43002 and seg[13]&4: reset=True
        if ip[9]==17:udp_wire.append(seg[8:].hex())
    assert reset and [x for x in udp_wire if x.startswith("52")]==words("udp_after_relay") and [x for x in udp_wire if x.startswith("55")]==words("udp_before_relay")
    return dict(tcp=tcp,udp=udp,wire_reset=reset)
out={}
for policy in ["fifo","rr"]:
    for profile,apps,exits in [("telemetry",["publisher","active","stalled","pubsub-broker"],[71,72,73,0]),("pipe-named",["writer","rust-writer","reader"],[61,62,63]),("pipe-anon",["anon-writer","anon-reader"],[64,65]),("inet",["inet-tcp","inet-udp","inet-service"],[75,76,0])]:
        name=profile+"-"+policy;out[name]=verify(name,apps,exits)
print(json.dumps(out,indent=2))
