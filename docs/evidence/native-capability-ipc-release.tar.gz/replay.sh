set -eu
out="$PWD/evidence"
app=examples/native-capability-ipc
sh sdk/native-aarch64/build.sh "$app/origin.c" "$out/origin.elf"
sh sdk/native-aarch64/build-rust.sh "$app/receiver/Cargo.toml" "$out/receiver.elf"
sh sdk/native-aarch64/build.sh "$app/target.c" "$out/target.elf"
rev=1d017b042e3490ea63436b4604836257397310fd
for policy in fifo rr; do
  quantum=()
  if [ "$policy" = rr ]; then quantum=(--quantum-ticks 625000); fi
  for scenario in transfer before pending active target mailbox; do
    pkg="$out/$scenario-$policy"
    python3 tools/build_native_el0.py --out "$pkg" \
      --elf "$out/origin.elf" --peer-elf "$out/receiver.elf" --peer-elf "$out/target.elf" \
      --arg "$scenario" --policy "$policy" "${quantum[@]}" \
      --priority 7 --peer-priority 4 --peer-priority 2 \
      --ipc-route 0:1 --ipc-route 0:2 \
      --cap-grant 0:2:3 --cap-route 0:1 --cap-route 1:0
    python3 tools/native_el0_capture.py "$out/cap-$scenario-$policy" "$pkg/kernel.elf" \
      "$out/origin.elf" "$app/origin.c" "$rev" --plain --manifest "$pkg/manifest.json" \
      --expect-exit 71 --timeout 20
  done
done
