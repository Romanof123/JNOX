#include <jnox/capability.h>
#include <jnox/ipc.h>
#include <time.h>
volatile long times_result[9];
int main(void) {
  jnox_cap_handle h;
  if(jnox_cap_initial(0,&h)) return 81;
  for(unsigned n=0;n<4;n++) if(jnox_cap_send(h,101+n,0)) return 82;
  struct timespec t;
  if(clock_gettime(CLOCK_MONOTONIC,&t)) return 83;
  unsigned long now=t.tv_sec*1000000000UL+t.tv_nsec;
  times_result[0]=now;
  times_result[1]=jnox_cap_send(h,501,0);
  times_result[2]=jnox_cap_send(h,502,1);
  times_result[3]=jnox_cap_send(h,503,now+100000000UL);
  if(clock_gettime(CLOCK_MONOTONIC,&t)) return 84;
  times_result[4]=t.tv_sec*1000000000UL+t.tv_nsec;
  if(times_result[1]!=-11 || times_result[2]!=-110 || times_result[3]!=-110 || times_result[4]<now+100000000UL) return 85;
  if(jnox_ipc_call(1,200,UINT64_MAX).status) return 86;
  times_result[5]=jnox_cap_send(h,105,UINT64_MAX);
  return times_result[5]?87:71;
}
