#include <jnox/ipc.h>
#include <jnox/mailbox.h>
volatile unsigned long time_words[5];
int main(void) {
  jnox_ipc_request r=jnox_ipc_receive();
  if(r.status || r.word!=200 || jnox_ipc_reply(r.token,200)) return 88;
  for(unsigned n=0;n<5;n++){jnox_mailbox_result v=jnox_mailbox_receive(0); time_words[n]=v.word;if(v.status || v.word!=101+n) return 89;}
  return jnox_mailbox_receive(0).status==-11?72:90;
}
