set -eux
src="$PWD"
rev=$(git rev-parse HEAD)
cd "/home/ywcho/cap387new/src/evidence"
app="$src"/examples/native-inet-sockets
sh "$src"/sdk/native-aarch64/build.sh --local-socket "$app/tcp.c" inet-tcp.elf
sh "$src"/sdk/native-aarch64/build-rust.sh --local-socket "$app/udp/Cargo.toml" inet-udp.elf
sh "$src"/sdk/native-aarch64/build-rust.sh "$src"/services/inet/Cargo.toml inet-service.elf
package() {
    policy=$1
    shift
    python3 "$src"/tools/build_native_el0.py --out "inet-$policy" --policy "$policy" --elf inet-tcp.elf --priority 4 --peer-elf inet-udp.elf --peer-priority 4 --peer-elf inet-service.elf --peer-priority 7 --peer2-arg 3 --ipc-route 0:2 --ipc-route 1:2 --socket-service 2 --net-service 2 "$@"
}
package fifo
package rr --quantum-ticks 625000
python3 "$app/peer.py" inet-fifo inet-fifo-first
python3 "$app/private_results.py" inet-fifo inet-fifo-first inet-tcp.elf inet-udp.elf
python3 "$app/peer.py" inet-rr inet-rr-first
python3 "$app/private_results.py" inet-rr inet-rr-first inet-tcp.elf inet-udp.elf
