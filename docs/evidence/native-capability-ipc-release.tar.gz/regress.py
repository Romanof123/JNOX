from pathlib import Path
import subprocess,os
e=Path("evidence").resolve()
for module in ("native-pubsub","native-pipes","native-inet-sockets"):
    app=Path("examples")/module
    sh=(app/"README.md").read_text().split("~~~sh\n")[1].split("~~~")[0]
    sh=sh.replace("dir=examples/",'dir="$src"/examples/').replace("app=examples/",'app="$src"/examples/').replace("sh sdk/",'sh "$src"/sdk/').replace("python3 tools/",'python3 "$src"/tools/').replace(" services/",' "$src"/services/')
    if module!="native-inet-sockets":
        cases=[("telemetry",71,"publisher","publisher")] if module=="native-pubsub" else [("pipe-named",61,"writer","writer"),("pipe-anon",64,"anon-writer","anon-writer")]
        for pkg,code,elf,c in cases:
            sh+=f'\nfor pol in fifo rr; do p={pkg}-$pol; python3 "$src"/tools/native_el0_capture.py run-$p "$p/kernel.elf" {elf}.elf "$dir/{c}.c" "$rev" --plain --manifest "$p/manifest.json" --expect-exit {code} --timeout 20; done\n'
    prefix=f'set -eux\nsrc="$PWD"\nrev=$(git rev-parse HEAD)\ncd "{e}"\n'
    script=e/(module+".sh");script.write_text(prefix+sh)
    with (e/(module+".log")).open("w") as f:
        proc=subprocess.run(["bash",script],stdout=f,stderr=subprocess.STDOUT)
    print(module,proc.returncode,flush=True)
