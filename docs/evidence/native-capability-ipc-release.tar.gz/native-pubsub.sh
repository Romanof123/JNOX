set -eux
src="$PWD"
rev=$(git rev-parse HEAD)
cd "/home/ywcho/cap387new/src/evidence"
dir="$src"/examples/native-pubsub
sh "$src"/sdk/native-aarch64/build.sh --pubsub "$dir/publisher.c" publisher.elf
sh "$src"/sdk/native-aarch64/build-rust.sh --pubsub "$dir/active/Cargo.toml" active.elf
sh "$src"/sdk/native-aarch64/build.sh --pubsub "$dir/stalled.c" stalled.elf
sh "$src"/sdk/native-aarch64/build-rust.sh "$src"/services/pubsub/Cargo.toml pubsub-broker.elf
package() {
    policy=$1
    shift
    python3 "$src"/tools/build_native_el0.py --board virt --policy "$policy" "$@" --out "telemetry-$policy" \
        --elf publisher.elf --priority 4 \
        --peer-elf active.elf --peer-priority 4 \
        --peer-elf stalled.elf --peer-priority 4 \
        --peer-elf pubsub-broker.elf --peer-priority 2 \
        --pubsub-service 3 --pubsub-publish 0:1 --pubsub-subscribe 1:1 --pubsub-subscribe 2:1 \
        --ipc-route 0:1 --ipc-route 0:2 --ipc-route 0:3 --ipc-route 1:3 --ipc-route 2:3
}
package fifo
package rr --quantum-ticks 625000

for pol in fifo rr; do p=telemetry-$pol; python3 "$src"/tools/native_el0_capture.py run-$p "$p/kernel.elf" publisher.elf "$dir/publisher.c" "$rev" --plain --manifest "$p/manifest.json" --expect-exit 71 --timeout 20; done
