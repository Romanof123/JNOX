#include <jnox/capability.h>
int main(void){for(unsigned op=53;op<=58;op++) if(jnox_cap_trap(op,0,0,0,0,0).status!=-38)return op;return 71;}
