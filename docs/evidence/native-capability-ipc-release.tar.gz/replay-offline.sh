set -eu
cd "$(dirname "$0")"
sha256sum --quiet -c SHA256SUMS
d=$(mktemp -d)
trap 'rm -f "$d/cap.json" "$d/regress.json"; rmdir "$d"' EXIT
python3 verify.py > "$d/cap.json"
cmp "$d/cap.json" observations.json
python3 verify_regress.py > "$d/regress.json"
cmp "$d/regress.json" regression-observations.json
echo '23 captures verified'
