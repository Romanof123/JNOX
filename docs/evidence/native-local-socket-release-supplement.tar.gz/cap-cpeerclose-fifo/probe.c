#include <errno.h>
#include <jnox/ipc.h>
#include <sys/un.h>

volatile long readings[96];
volatile unsigned nreadings;
static const struct sockaddr_un station = {AF_UNIX,"/station"};
static const struct sockaddr_un origin = {AF_UNIX,"/origin"};
static const struct sockaddr_un gate = {AF_UNIX,"/gate"};
static const struct sockaddr_un aux = {AF_UNIX,"/aux"};
#define ADDR(v) (const struct sockaddr *)&(v), sizeof(v)
static long noted(long value) {
    long status = value < 0 ? -errno : value;
    readings[nreadings++] = status;
    return status;
}
#define EXPECT(op, expected) do { if (noted(op) != (expected)) return 99; } while (0)
static int receive_record(int fd, unsigned cap, int flags, long expected,
                          unsigned byte, unsigned changed, int short_addr) {
    struct sockaddr_un source = {0};
    socklen_t len = short_addr ? 3 : sizeof(source);
    unsigned char buf[33];
    for (unsigned i = 0; i < sizeof(buf); ++i) buf[i] = 0x77;
    EXPECT(recvfrom(fd,cap ? buf : 0,cap,flags,(struct sockaddr *)&source,&len),expected);
    EXPECT(len,10);
    EXPECT(source.sun_family,AF_UNIX);
    for (unsigned i=0; i<(short_addr ? 1 : 8); ++i)
        if (source.sun_path[i] != origin.sun_path[i]) return 99;
    for (unsigned i=0; i<sizeof(buf); ++i)
        if (buf[i] != (i < changed ? byte : 0x77)) return 99;
    return 0;
}
int main(int argc, char **argv) {
    if (argc != 2) return 98;
    char mode = argv[1][0];
    EXPECT(jnox_socket_broker(2),0);
    if (mode == 'g') {
        EXPECT(socket(AF_UNIX,SOCK_DGRAM,0),-EACCES);
        readings[nreadings++] = jnox_ipc_trap(37,0,0,0).status;
        return readings[nreadings-1] == -EACCES ? 51 : 99;
    }
    int kind = mode == 's' || mode == 'q' ? SOCK_SEQPACKET :
               mode == 't' ? SOCK_STREAM : SOCK_DGRAM;
    int a = socket(AF_UNIX,SOCK_DGRAM,0), b = socket(AF_UNIX,kind,0);
    EXPECT(a,64); EXPECT(b,65);
    EXPECT(bind(a,ADDR(gate)),0); EXPECT(bind(b,ADDR(station)),0);
    if (kind != SOCK_DGRAM) EXPECT(listen(b,2),0);
    unsigned char v = 0;
    EXPECT(read(a,&v,1),1); EXPECT(v,1);
    int fd = b;
    if (kind != SOCK_DGRAM) {
        struct sockaddr_un output = {0};
        socklen_t capacity = sizeof(output);
        EXPECT(accept(b,(struct sockaddr *)&output,&capacity),-ENOTSUP);
        fd = accept(b,0,0);
        EXPECT(fd,66);
    }
    if (mode == 's' || mode == 'd') {
        if (receive_record(fd,5,0,0,0,0,0) ||
            receive_record(fd,0,MSG_TRUNC,4,0,0,1) ||
            receive_record(fd,0,0,0,0,0,0) ||
            receive_record(fd,32,0,32,0x55,32,0)) return 99;
        EXPECT(recv(fd,&v,1,MSG_DONTWAIT),-EAGAIN);
        if (kind == SOCK_DGRAM) EXPECT(connect(fd,ADDR(origin)),0);
        EXPECT(write(fd,0,0),0);
        EXPECT(send(fd,"abcd",4,0),4);
        EXPECT(send(fd,"z",1,0),1);
        EXPECT(send(fd,"xy",2,0),2);
    } else {
        if (kind == SOCK_DGRAM) EXPECT(connect(fd,ADDR(origin)),0);
        EXPECT(recv(fd,&v,1,MSG_DONTWAIT),-EAGAIN);
        if (mode == 'q') {
            for (unsigned i=0; i<4; ++i) EXPECT(write(fd,"x",1),1);
            EXPECT(send(fd,"f",1,MSG_DONTWAIT),-EAGAIN);
        }
        EXPECT(sendto(a,"y",1,0,ADDR(aux)),1);
        if (mode == 'q') EXPECT(write(fd,"X",1),-EPIPE);
        else EXPECT(read(fd,&v,1),kind == SOCK_STREAM ? 0 : -ECONNREFUSED);
        EXPECT(read(a,&v,1),1); EXPECT(v,2);
        EXPECT(write(fd,"x",1),-EPIPE);
        if (kind == SOCK_DGRAM) {
            EXPECT(connect(fd,ADDR(origin)),0);
            EXPECT(write(fd,"R",1),1);
        }
    }
    EXPECT(close(fd),0); EXPECT(read(fd,&v,1),-EBADF);
    if (fd != b) EXPECT(close(b),0);
    EXPECT(close(a),0);
    return 51;
}
