#!/usr/bin/env bash
set -euo pipefail
prep=$(cd "$(dirname "$0")" && pwd)
release=$(dirname "$prep")
base=$(dirname "$release")
for pair in first:e7d3ded corrected:70f2ab8; do
    which=${pair%%:*}
    short=${pair#*:}
    dir="$base/376-$which-independent"
    file="376-$which-$short.tar.gz"
    (cd "$dir" && sha256sum -c "$file.sha256")
    dest=$(mktemp -d)
    tar -xzf "$dir/$file" -C "$dest"
    (cd "$dest" && sha256sum -c --quiet SHA256SUMS && PYTHONDONTWRITEBYTECODE=1 python3 verify.py . > "$release/history-$which.json")
    cmp "$dest/results.json" "$release/history-$which.json"
    echo "$which archive, member digests and decoded RAM results matched"
done
