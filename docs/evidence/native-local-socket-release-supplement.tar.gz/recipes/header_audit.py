"""Identify standard errno symbols needed for error numbers returned by the socket service."""
import json
import re
import sys
from pathlib import Path

header,engine=map(Path,sys.argv[1:3])
text=header.read_text()
source=engine.read_text()
symbols={name:int(val) for name,val in re.findall(r"^#define (E[A-Z0-9]+) (\d+)$",text,re.M)}
cases={"ENOENT":(2,".ok_or(-2)"),"ENFILE":(23,".ok_or(-23)"),
       "EPROTOTYPE":(91,"Err(-91)"),"EDESTADDRREQ":(89,"{ -89 }")}
for name,(value,pattern) in cases.items():
    assert pattern in source and name not in symbols,(name,value)
print(json.dumps({n:v for n,(v,_) in cases.items()},indent=2))
