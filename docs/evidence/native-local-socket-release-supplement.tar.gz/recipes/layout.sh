#!/usr/bin/env bash
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
cd "$src"
# Independent unbooted type-layout witnesses, used only to interpret the exact
# original release ELF and captured RAM. Keep all artifacts outside the source.
export RUSTFLAGS="-C debuginfo=2"
run broker-layout sh sdk/native-aarch64/build-rust.sh services/socket/Cargo.toml "$raw/layout-broker.elf"
sed -e '1,3d' kernel/src/sync_ipc.rs > "$raw/endpoint-types.rs"
cat > "$raw/layout-kernel.rs" <<'EOF'
#![no_std]
include!("endpoint-types.rs");
#[no_mangle]
pub static LAYOUT: SyncIpc<3> = SyncIpc::with_broker([4,4,0],2);
EOF
run endpoint-layout rustc --edition 2021 -C opt-level=3 -C debuginfo=2 --target aarch64-unknown-none-softfloat --crate-name wire_layout --crate-type lib --emit=obj "$raw/layout-kernel.rs" -o "$raw/layout-kernel.o"
