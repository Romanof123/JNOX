"""Audit 24 clean-build guests and eight broker register captures on this exact candidate."""
import argparse
import json
import re
import struct
import subprocess
from pathlib import Path
import verify as v

EXTRA = ("dgramzero","seqzero","treadclose","qwriteclose","cpeerclose","grants")
CLOSE = {"treadclose":(7,0),"qwriteclose":(6,-32),"cpeerclose":(7,-111)}

def expected(mode):
    # Every value in the ordinary application result vector, including signed errno.
    if mode == "grants":
        return [[0,-13,-13],[1]]
    connected = mode in ("seqzero","treadclose","qwriteclose")
    server = [0,64,65,0,0] + ([0] if connected else []) + [1,1]
    if connected:
        server += [-95,66]
    if mode in ("seqzero","dgramzero"):
        for ret in (0,4,0,32):
            server += [ret,10,1]
        server += [-11] + ([] if connected else [0]) + [0,4,1,2]
        peer = [-90,0,4,1,32,-11,1,0,1,4,1,0,1,2,1,1]
        if connected:
            peer += [0]
    else:
        if not connected:
            server += [0]
        server += [-11]
        if mode == "qwriteclose":
            server += [1,1,1,1,-11]
        server += [1,CLOSE[mode][1],1,2,-32]
        peer = [1,1,1,1,1]
        if not connected:
            server += [0,1]
            peer += [1,1]
    server += [0,-9] + ([0] if connected else []) + [0]
    return [server,peer]

def extra(pkg,cap,mode,policy,layout):
    m = v.readj(pkg/"manifest.json")
    launch = v.readj(cap/"launch.json")
    session = v.checksums(cap)
    base = launch["ram_base"]
    ram = (cap/"ram.bin").read_bytes()
    assert len(ram) == launch["ram_bytes"]
    assert launch["argument_package"] == m and not m["tracked_changes"]
    assert launch["revision"] == m["commit"] == v.REV
    assert (m["board"],m["policy"],m["quantum_ticks"]) == ("virt",policy,625000 if policy == "rr" else None)
    allow = [1] if mode == "grants" else [0,1]
    assert m["socket_service"] == {"slot":2,"authorized_clients":allow}
    assert m["ipc_routes"] == [{"caller":i,"server":2} for i in allow]
    args = launch["argv"]
    for k,val in (("-cpu","cortex-a72"),("-smp","1"),("-accel","tcg")):
        assert args[args.index(k)+1] == val
    assert v.digest(pkg/"kernel.elf") == v.digest(cap/"kernel.elf") == m["kernel_elf_sha256"]
    uart = (cap/"uart.bin").read_text()
    exits = sorted([int(a),int(b)] for a,b in re.findall(r"^NATIVE EL0 EXIT PID (\d+) (-?\d+)$",uart,re.M))
    assert exits == [[0,51],[1,52],[2,0]] and "FAULT" not in uart and session["marker"]=="EXIT 51"
    kt = v.syms(pkg/"kernel.elf")
    start, sz = v.unique(kt,"6SPACES")
    assert sz%3 == 0
    private_frames = [set() for _ in range(3)]
    vectors = []
    auth_mask = str(sum(1 << i for i in allow))
    for i,s in enumerate(m["slots"]):
        image = pkg/s["elf"]
        assert s["elf_sha256"] == v.digest(image) and s["elf_sha256"] in uart
        assert s["priority"] == [7,4,1][i] and s["argv"][1:] == [[mode],[mode],[auth_mask]][i]
        sym = v.syms(image)
        def fetch(symbol):
            va,n = sym[symbol]
            buf,frames = v.private(ram,base,start+i*sz//3,va,n)
            private_frames[i].update(frames)
            return buf
        if i < 2:
            n, = struct.unpack("<I",fetch("nreadings"))
            assert n <= 96
            vectors.append(list(struct.unpack("<96q",fetch("readings"))[:n]))
        else:
            address,length = v.unique(kt,"9ENDPOINTS")
            service, = [name for name in sym if "7SERVICE" in name]
            clients, = [name for name in sym if "12CLIENT_STATE" in name]
            last = v.cleanup(fetch(service),fetch(clients),ram[address-base:address-base+length],layout,
                             routes=[4 if j in allow else 0 for j in range(3)])
    assert not any(private_frames[i]&private_frames[j] for i,j in ((0,1),(0,2),(1,2)))
    assert vectors == expected(mode),(mode, vectors,expected(mode))
    return dict(kernel=m["kernel_elf_sha256"],exits=exits,slot_results=vectors,last_token=last,
                grant_to_broker=allow,terminal_empty=True,
                uart_dropped=int(re.search(r"NATIVE FIXED DROPPED (\d+)",uart)[1]))

def observed_replies(pkg,cap,mode,last):
    asm = subprocess.check_output(["aarch64-linux-gnu-objdump","-d",pkg/"native_peer2.elf"],text=True)
    sites = [int(s,16) for s in re.findall(r"^\s*([0-9a-f]+):\s+d4094021\s+svc",
                                           asm.split("<main>:",1)[1],re.M)]
    assert len(sites)==5
    allowed = [1] if mode=="grants" else [0,1]
    calls,replies,op,dead,ordered = {},{},{},[],[]
    for line in (cap/"registers.log").read_text().split(" PC=")[1:]:
        pc = int(line.split()[0],16)
        reg = {int(n):int(data,16) for n,data in re.findall(r"X(\d+)=(\w+)",line)}
        if pc == sites[0]+4 and reg[8] == 37:
            assert reg[0] == 0 and reg[3] in allowed and "EL0t" in line
            token,who,word = reg[1],reg[3],reg[2]
            if not token:
                assert word == 0 and who not in dead
                dead.append(who)
                ordered.append(("exit",0,who,0,0))
                continue
            assert who not in dead and token not in calls
            tag = word>>56
            if tag==0x11:
                op[who]=(word>>48)&255
            calls[token] = (who,tag,op.get(who),len(ordered))
            ordered.append(("receive",token,who,tag,op.get(who)))
        elif pc in sites[1:] and reg[8]==23:
            token,result = reg[0],reg[1]
            assert token in calls and token not in replies and "EL0t" in line
            who,tag,operation,_ = calls[token]
            value = result if result < 2**63 else result-2**64
            replies[token]=(value,len(ordered))
            ordered.append(("reply",token,who,tag,operation))
    assert sorted(dead)==allowed and set(calls)==set(replies)==set(range(1,last+1))
    data = dict(replied_once=last,authenticated_exit_slots=dead)
    if mode in CLOSE:
        operation,val=CLOSE[mode]
        witnesses=[]
        for token,(who,tag,opid,a) in calls.items():
            result,b=replies[token]
            if (who,tag,opid,result)!=(0,0x13,operation,val):
                continue
            for k,entry in enumerate(ordered[a+1:b],a+1):
                if entry[0]=="receive" and entry[2:]==(1,0x13,9):
                    close_token=entry[1]
                    assert replies[close_token][0]==0
                    assert not any(x[0]=="exit" for x in ordered[a+1:b])
                    witnesses.append(dict(wait_token=token,close_token=close_token,reply=result,
                                          wait_arrival=a,close_commit=k,wait_reply=b))
        assert len(witnesses)==1,(mode,witnesses)
        data["explicit_close"]=witnesses[0]
    return data

def audit(root):
    layout=v.readj(root/"layout.json")
    report={}
    for mode in (*v.MODES,*EXTRA):
        for policy in ("fifo","rr"):
            case=mode+"-"+policy
            pkg=root/("pkg-"+case)
            cap=root/("cap-"+case)
            if mode in v.MODES:
                report[case]=v.capture(pkg,cap,mode,layout)
            else:
                plain=extra(pkg,cap,mode,policy,layout)
                report[case]=plain
                if mode in CLOSE or mode=="grants":
                    traced=root/("trace-"+case)
                    other=extra(pkg,traced,mode,policy,layout)
                    assert other["slot_results"]==plain["slot_results"] and other["last_token"]==plain["last_token"]
                    plain["register_replay"]=observed_replies(pkg,traced,mode,other["last_token"])
    return report

if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("root",type=Path)
    print(json.dumps(audit(p.parse_args().root),indent=2))
