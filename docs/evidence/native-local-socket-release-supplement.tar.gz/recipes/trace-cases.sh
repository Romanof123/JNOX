#!/usr/bin/env bash
set -euo pipefail
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
export SRC="$src" RAW="$raw"
bash "$prep/layout.sh"
bash "$prep/offline-types.sh"
cd "$src"
run trace-close python3 "$prep/trace.py" "$src" "$raw" treadclose-fifo treadclose-rr qwriteclose-fifo qwriteclose-rr cpeerclose-fifo cpeerclose-rr grants-fifo grants-rr
