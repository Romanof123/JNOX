#![no_std]
#![no_main]

use core::{panic::PanicInfo, ptr::write_volatile};
use jnox_native::{exit, local_socket as s};

#[no_mangle]
static mut readings: [i64; 96] = [0; 96];
#[no_mangle]
static mut nreadings: u32 = 0;
fn note(v: i64) {
    unsafe {
        write_volatile(&raw mut readings[nreadings as usize], v);
        write_volatile(&raw mut nreadings, nreadings + 1);
    }
}
#[panic_handler]
fn panic(_: &PanicInfo<'_>) -> ! { exit(97) }

fn count(actual: Result<usize, i32>, target: i64) -> Result<(), i32> {
    let value = actual.map_or_else(i64::from, |n| n as i64);
    note(value);
    if value == target { Ok(()) } else { Err(-700) }
}
fn same(value: bool) -> Result<(), i32> {
    note(i64::from(value));
    if value { Ok(()) } else { Err(-701) }
}
fn run(m: u8) -> Result<(), i32> {
    s::set_broker(2)?;
    if m == b'g' {
        let fd = s::socket(s::SOCK_DGRAM,false)?;
        same(fd == 64)?;
        return s::close(fd);
    }
    let kind = match m { b's' | b'q' => s::SOCK_SEQPACKET, b't' => s::SOCK_STREAM, _ => s::SOCK_DGRAM };
    let fd = s::socket(kind,false)?;
    let aux = s::socket(s::SOCK_DGRAM,false)?;
    s::bind(fd,b"/origin")?;
    s::bind(aux,b"/aux")?;
    s::connect(fd,b"/station")?;
    if m == b's' || m == b'd' {
        count(s::send(fd,&[0;33],0),-90)?;
        count(s::send(fd,&[],0),0)?;
        count(s::send(fd,&[1,2,3,4],0),4)?;
        count(s::send(fd,&[0xa1],0),1)?;
        count(s::send(fd,&[0x55;32],0),32)?;
        count(s::send(fd,&[],s::MSG_DONTWAIT),-11)?;
        count(s::send_to(aux,&[1],0,b"/gate"),1)?;
        let mut guard = [0x88;3];
        for (cap,flags,expected) in [(1,0,0), (0,s::MSG_TRUNC,4), (0,0,0), (1,s::MSG_TRUNC,2)] {
            let (len,peer) = s::recv_from(fd,&mut guard[..cap],flags)?;
            count(Ok(len),expected)?;
            same(peer.as_bytes() == b"/station")?;
        }
        same(guard == [b'x',0x88,0x88])?;
        if kind == s::SOCK_SEQPACKET {
            count(s::recv(fd,&mut guard,0),0)?;
        }
        s::close(fd)?;
    } else {
        count(s::send_to(aux,&[1],0,b"/gate"),1)?;
        let mut byte = [0];
        count(s::recv(aux,&mut byte,0),1)?;
        same(byte == [b'y'])?;
        s::close(fd)?;
        let next = s::socket(kind,false)?;
        same(next == fd)?;
        s::bind(next,b"/origin")?;
        count(s::send_to(aux,&[2],0,b"/gate"),1)?;
        if kind == s::SOCK_DGRAM {
            count(s::recv(next,&mut byte,0),1)?;
            same(byte == [b'R'])?;
        }
        s::close(next)?;
    }
    s::close(aux)
}
#[no_mangle]
pub unsafe extern "C" fn main(argc: i32, argv: *const *const u8) -> i32 {
    if argc != 2 { return 98; }
    match run(**argv.add(1)) { Ok(()) => 52, Err(e) => {note(i64::from(e)); 99} }
}
