#!/usr/bin/env bash
set -euo pipefail
prep=$(cd "$(dirname "$0")" && pwd)
dest=$(dirname "$prep")
raw=${RAW:-$HOME/v376-release-raw}
src=${SRC:-$HOME/v376-release-src}
packet=$(mktemp -d "$HOME/v376-release-packet.XXXXXXXX")
cp -R "$prep" "$packet/recipes"
cp "$dest"/history-{first,corrected}.json "$packet/"
cp "$dest"/native-local-socket-release.en-ko.md "$packet/REPORT.en-ko.md"
cp "$dest"/../issue-376-verifier-snapshot.md "$packet/issue-376.md"
cp "$raw"/{revision.txt,status.txt,commands.sh,contract.md,platform.txt,layout.json,broker-types.o,layout-kernel.o,results.json} "$packet/"
cp "$raw"/*.log "$packet/"
mkdir -p "$packet/observer/tools"
cp "$src"/tools/{ordinary_amc_capture,native_el0_capture,qemu_capture}.py "$packet/observer/tools/"
mkdir "$packet/api-audit"
cp "$src/sdk/native-aarch64/include/errno.h" "$src/services/socket/src/local.rs" "$packet/api-audit/"
python3 "$prep/header_audit.py" "$packet/api-audit/errno.h" "$packet/api-audit/local.rs" > "$packet/api-audit/missing-errno-symbols.json"
git -C "$src" rev-parse HEAD 'HEAD^' 'HEAD^{tree}' > "$packet/commit-parent-tree.txt"
git -C "$src" status --porcelain > "$packet/source-status-after-build.txt"
git -C "$src" diff --exit-code HEAD -- > "$packet/tracked.diff"
for f in "$raw"/pkg-*; do
    if [[ -d $f ]]; then
        name=$(basename "$f")
        mkdir "$packet/$name"
        cp "$f"/*.elf "$f/manifest.json" "$f/build.log" "$packet/$name"
    fi
done
for d in "$raw"/cap-* "$raw"/trace-*; do
    if [[ -d $d ]]; then cp -R "$d" "$packet/"; fi
done
cd "$packet"
export PYTHONDONTWRITEBYTECODE=1
python3 recipes/audit.py . > "$raw/release-recheck.json"
cmp results.json "$raw/release-recheck.json"
find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
sha256sum -c --quiet SHA256SUMS
file=376-release-70f2ab8.tar.gz
tar -czf "$dest/$file" .
cd "$dest"
sha256sum "$file" > "$file.sha256"
sha256sum -c "$file.sha256"
echo "$packet"
