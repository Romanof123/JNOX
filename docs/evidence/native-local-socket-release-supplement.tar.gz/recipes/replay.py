"""Reboot one or all archived guest kernels; output must be a new directory."""
import argparse
import json
import subprocess
import sys
from pathlib import Path
import audit
import verify as v

p=argparse.ArgumentParser(description=__doc__)
p.add_argument("packet", type=Path)
p.add_argument("output", type=Path)
p.add_argument("--case", help="e.g. qwriteclose-rr; by default reboot all 24")
args=p.parse_args()
packet=args.packet.resolve()
out=args.output.resolve()
original=v.readj(packet/"results.json")
layout=v.readj(packet/"layout.json")
keys=[args.case] if args.case else list(original)
if any(key not in original for key in keys):
    p.error("unknown case")
out.mkdir()
for key in keys:
    mode,policy=key.rsplit("-",1)
    pkg=packet/("pkg-"+key)
    cap=out/("cap-"+key)
    before=packet/("cap-"+key)
    expected=v.EXITS[mode][0] if mode in v.EXITS else 51
    subprocess.run([sys.executable,packet/"observer/tools/native_el0_capture.py",cap,
                    pkg/"kernel.elf",pkg/"user.elf",before/"probe.c",v.REV,"--plain",
                    "--manifest",pkg/"manifest.json","--expect-exit",str(expected),"--timeout","25"],check=True)
    got=(v.capture(pkg,cap,mode,layout) if mode in v.MODES else audit.extra(pkg,cap,mode,policy,layout))
    for field in ("exits","kernel","slot_results","last_token"):
        assert got[field]==original[key][field],(key,field,got[field],original[key][field])
    if "register_replay" in original[key]:
        (out/pkg.name).symlink_to(pkg,target_is_directory=True)
        subprocess.run([sys.executable,packet/"recipes/trace.py",packet/"observer",out,key],check=True)
        trace=out/("trace-"+key)
        traced=audit.extra(pkg,trace,mode,policy,layout)
        assert traced["slot_results"]==got["slot_results"]
        witness=audit.observed_replies(pkg,trace,mode,traced["last_token"])
        assert witness["replied_once"]==original[key]["register_replay"]["replied_once"]
        assert witness.get("explicit_close",{}).get("reply")==original[key]["register_replay"].get("explicit_close",{}).get("reply")
    print(key,"matched",flush=True)
