"""Export DWARF structure member offsets and enum variant selectors used to decode release RAM."""
import json
import sys
from pathlib import Path
from elftools.elf.elffile import ELFFile

def layouts(path, names):
    result = {}
    with path.open("rb") as f:
        dw = ELFFile(f).get_dwarf_info()
        for cu in dw.iter_CUs():
            for d in cu.iter_DIEs():
                size = d.attributes.get("DW_AT_byte_size")
                name = d.attributes.get("DW_AT_name")
                if size is None or name is None:
                    continue
                name = name.value.decode()
                if name not in names or name in result: continue
                fields = {}
                for c in d.iter_children():
                    if c.tag == "DW_TAG_member":
                        fields[c.attributes["DW_AT_name"].value.decode()] = c.attributes["DW_AT_data_member_location"].value
                    if c.tag == "DW_TAG_variant_part":
                        disc = c.get_DIE_from_attribute("DW_AT_discr")
                        fields["discriminant"] = disc.attributes["DW_AT_data_member_location"].value
                        fields["disc_size"] = disc.get_DIE_from_attribute("DW_AT_type").attributes["DW_AT_byte_size"].value
                        for var in c.iter_children():
                            if var.tag != "DW_TAG_variant": continue
                            val = var.attributes.get("DW_AT_discr_value")
                            vname = next(var.iter_children()).attributes["DW_AT_name"].value.decode()
                            fields[vname] = val.value if val else None
                result[name] = dict(size=size.value,fields=fields)
    assert set(result)==set(names), (set(names)-set(result))
    return result

if __name__ == "__main__":
    root = Path(sys.argv[1])
    b = layouts(root/"broker-types.o",["Local","Socket","Client","Option<usize>","Option<u64>",
        "Option<jnox_local_socket::Request>","Option<jnox_local_socket::Response>"])
    k = layouts(root/"layout-kernel.o",["SyncIpc<3>","Slot","Option<wire_layout::ReceiveMode>",
        "Option<wire_layout::Request>","Option<(wire_layout::Completion, core::option::Option<usize>)>"])
    print(json.dumps(dict(broker=b,kernel=k),indent=2))
