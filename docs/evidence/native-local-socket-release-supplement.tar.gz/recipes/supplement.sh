#!/usr/bin/env bash
set -euo pipefail
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
cd "$src"
mkdir -p "$raw/release-rust/src"
cp "$prep/rust/src/main.rs" "$raw/release-rust/src"
sed "s@../../../sdk/native-aarch64/rust@$src/sdk/native-aarch64/rust@" examples/native-local-sockets/client/Cargo.toml > "$raw/release-rust/Cargo.toml"
run cc-release sh sdk/native-aarch64/build.sh --local-socket "$prep/server.c" "$raw/release-server.elf"
run rust-release sh sdk/native-aarch64/build-rust.sh --local-socket "$raw/release-rust/Cargo.toml" "$raw/release-client.elf"
for pol in fifo rr; do
    for mode in dgramzero seqzero treadclose qwriteclose cpeerclose grants; do
        grants=(--peer2-arg 3 --peer-priority 1 --socket-service 2 --ipc-route 0:2 --ipc-route 1:2)
        if [[ $mode == grants ]]; then grants=(--peer2-arg 2 --peer-priority 1 --socket-service 2 --ipc-route 1:2); fi
        guest "$mode-$pol" "$pol" 51 "$raw/release-server.elf" "$prep/server.c" --arg "$mode" --priority 7 --peer-elf "$raw/release-client.elf" --peer-arg "$mode" --peer-priority 4 --peer-elf "$raw/broker.elf" "${grants[@]}" || true
    done
done
