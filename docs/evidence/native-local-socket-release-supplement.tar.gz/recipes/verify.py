"""Recompute independent socket results from ELF symbols, page tables, RAM, UART and broker registers."""
import collections
import hashlib
import json
import re
import struct
import subprocess
import sys
from pathlib import Path

REV = "70f2ab812d1d0a444da04c0f8ecdf1f568d533d7"
MODES = ("stream","dgram","seq","bounds","death","cancel")
EXITS = {"stream":[73,74,0],"dgram":[73,74,0],"seq":[73,74,0],
         "bounds":[60,61,0],"death":[62,63,0],"cancel":[64,65,0]}
ORACLES = {
    "stream": [[1,1,sum(range(1,65)),64,3,16,45,0,0,32,1,0], [1,7,57,0,0,-11,32,0,1,0,0,0]],
    "dgram": [[2,2,10+11+12+20+21,5,5,2,0,0,10,74,1,0], [2,5,2,0,0,0,74,10,1,0,0,0]],
    "seq": [[5,5,sum(i+j for i in range(1,5) for j in (0,10,20)),12,3,3,3,3,0,150,1,0], [5,3,3,3,3,-11,150,0,1,0,0,0]],
    "bounds": [[64,65,0,0,0,41,-23,66,51,0,66,0,1,66,52,0,66,53],[-13,0,-9,64,0,65,66,67,-24,0,0,-11,1,1,1,42,0,1]],
    "death": [[64,0,0,65,1,1,1,1,-11,1,-32,0,66,0],[64,0,0,1,65,0,0,-16]],
    "cancel": [[64,0,0,0,-110,0,1,72,-11],[64,0,1,1,1,1,81,82,83,84,71,1]],
}
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def readj(path): return json.loads(path.read_text())
def syms(path):
    obj = subprocess.check_output(["aarch64-linux-gnu-nm","-nS",path],text=True)
    return {s[3]:(int(s[0],16),int(s[1],16)) for ln in obj.splitlines() if len(s:=ln.split())==4}
def unique(table, text):
    (value,) = [v for n,v in table.items() if text in n]
    return value
def integer(b, i, n): return int.from_bytes(b[i:i+n],"little")
def checksums(cap):
    session=readj(cap/"session.json")
    for fname,sha in session["hashes"].items(): assert digest(cap/fname)==sha, (cap,fname)
    return session
def private(ram, base, root, va, size):
    data=bytearray()
    physical=[]
    while size:
        frame=root
        for shift in (30,21,12):
            off=frame-base+((va>>shift)&511)*8
            assert 0<=off<=len(ram)-8
            ent=integer(ram,off,8)
            assert ent&3==3
            frame=ent&0x0000fffffffff000
        assert ent&0xc0==0x40 # EL0 read/write mapped page
        count=min(size,4096-(va%4096))
        off=frame-base+va%4096
        assert 0<=off<=len(ram)-count
        data.extend(ram[off:off+count])
        physical.append(frame)
        size-=count
        va+=count
    return bytes(data),physical
def not_some(buf, layout, typ, off):
    f=layout[typ]["fields"]
    return integer(buf,off+f["discriminant"],f["disc_size"])==f["None"]
def cleanup(s,cs,ep,layout,routes=(4,4,0)):
    b,k=layout["broker"],layout["kernel"]
    def fields(src,key): return src[key]["fields"]
    assert len(s)==b["Local"]["size"] and len(cs)==3*b["Client"]["size"] and len(ep)==k["SyncIpc<3>"]["size"]
    obj,cli,local=fields(b,"Socket"),fields(b,"Client"),fields(b,"Local")
    qs=[]
    for i in range(8):
        off=local["objects"]+i*b["Socket"]["size"]
        qs.append([integer(s,off+obj[n],size) for n,size in (("kind",1),("npending",8),("nbytes",8),("nrecords",8))])
    assert qs==[[0,0,0,0]]*8
    assert all(not_some(s,b,"Option<usize>",local["fds"]+i*b["Option<usize>"]["size"]) for i in range(12))
    for i in range(3):
        off=i*b["Client"]["size"]
        for f,t in (("request","Option<jnox_local_socket::Request>"),("response","Option<jnox_local_socket::Response>"),("pending","Option<u64>")):
            assert not_some(cs,b,t,off+cli[f])
    sync,slot=fields(k,"SyncIpc<3>"),fields(k,"Slot")
    assert list(ep[sync["routes"]:sync["routes"]+3])==list(routes) and ep[sync["pending_exits"]]==0
    for i in range(3):
        off=sync["slots"]+i*k["Slot"]["size"]
        assert ep[off+slot["alive"]]==0
        for f,t in (("request","Option<wire_layout::Request>"),("receiving","Option<wire_layout::ReceiveMode>"),("completion","Option<(wire_layout::Completion, core::option::Option<usize>)>")):
            assert not_some(ep,k,t,off+slot[f])
    return integer(ep,sync["last_token"],8)
def capture(pkg, cap, mode, layout):
    session=checksums(cap)
    launch=readj(cap/"launch.json")
    man=readj(pkg/"manifest.json")
    assert launch["argument_package"]==man and launch["revision"]==man["commit"]==REV and not man["tracked_changes"]
    assert man["policy"] in ("fifo","rr") and man["board"]=="virt" and man["quantum_ticks"]==(625000 if man["policy"]=="rr" else None)
    assert man["socket_service"]=={"slot":2,"authorized_clients":[0,1]} and man["ipc_routes"]==[{"caller":i,"server":2} for i in (0,1)]
    args=launch["argv"]
    for opt,v in (("-smp","1"),("-cpu","cortex-a72"),("-accel","tcg")): assert args[args.index(opt)+1]==v
    uart=(cap/"uart.bin").read_text()
    assert "FAULT" not in uart and session["marker"]==f"EXIT {EXITS[mode][0]}"
    exits=sorted(tuple(map(int,x)) for x in re.findall(r"^NATIVE EL0 EXIT PID (\d+) (-?\d+)$",uart,re.M))
    assert exits==list(enumerate(EXITS[mode]))
    assert digest(cap/"kernel.elf")==digest(pkg/"kernel.elf")==man["kernel_elf_sha256"]
    slots=man["slots"]
    argvs=[[mode],[mode],["3"]] if mode in MODES[:3] else [["0"+mode[0]],["1"+mode[0]],["3"]]
    assert [ss["argv"][1:] for ss in slots]==argvs and [ss["priority"] for ss in slots]==[7,4,1]
    ram=(cap/"ram.bin").read_bytes()
    base=launch["ram_base"]
    assert len(ram)==launch["ram_bytes"]
    kt=syms(pkg/"kernel.elf")
    start,size=unique(kt,"6SPACES")
    assert size%3==0
    roots=[start+i*size//3 for i in range(3)]
    physical=[set() for _ in range(3)]
    sets=[]
    for i,slot in enumerate(slots):
        elf=pkg/slot["elf"]
        assert slot["elf_sha256"]==digest(elf) and slot["elf_sha256"] in uart
        headers=subprocess.check_output(["aarch64-linux-gnu-readelf","-lW",elf],text=True)
        assert [ln.split()[6:-1] for ln in headers.splitlines() if ln.lstrip().startswith("LOAD")]==[["R","E"],["R"],["RW"]]
        sets.append(syms(elf))
    def fetch(i,name):
        va,n=unique(sets[i],name)
        value,frames=private(ram,base,roots[i],va,n)
        physical[i].update(frames)
        return value
    arrays=[]
    for i in range(2):
        if mode in MODES[:3]:
            arrays.append(list(struct.unpack("<12q",fetch(i,["socket_server_result","socket_client_result"][i]))))
        else:
            n=integer(fetch(i,"observed_count"),0,4)
            va,length=sets[i]["observed"]
            vals,frames=private(ram,base,roots[i],va,length)
            physical[i].update(frames)
            arrays.append(list(struct.unpack("<64q",vals))[:n])
    assert arrays==ORACLES[mode],(mode,arrays)
    addr,length=unique(kt,"9ENDPOINTS")
    token=cleanup(fetch(2,"7SERVICE"),fetch(2,"12CLIENT_STATE"),ram[addr-base:addr-base+length],layout)
    assert not (physical[0]&physical[1] or physical[1]&physical[2] or physical[2]&physical[0])
    rows=[list(map(int,l.split()[3:])) for l in uart.splitlines() if l.startswith("NATIVE FIXED EVENT ")]
    drops=int(re.search(r"NATIVE FIXED DROPPED (\d+)",uart)[1])
    assert all(any(r[1]==21 and r[3]==i for r in rows) for i in (0,1))
    assert all(any(r[1]==op and r[3]==2 for r in rows) for op in (23,37))
    return dict(kernel=man["kernel_elf_sha256"],exits=[list(a) for a in exits],slot_results=arrays,last_token=token,
        roots=roots,captured_writable_frames=[sorted(v) for v in physical],uart_rows=len(rows),uart_dropped=drops,
        terminal=dict(open_descriptors=0,occupied_objects=0,queued_connections=0,stream_bytes=0,queued_records=0,
            broker_requests=0,broker_responses=0,held_tokens=0,live_kernel_slots=0,kernel_pending_exits=0,kernel_pending_completions=0))
def trace(cap,mode,last):
    text=(cap/"registers.log").read_text()
    req={}
    replies={}
    events=[]
    for record in text.split(" PC=")[1:]:
        x={int(n):int(val,16) for n,val in re.findall(r"X(\d+)=(\w+)",record)}
        pc=int(record.split()[0],16)
        if pc==0x401e18 and x[8]==37:
            assert x[0]==0 and x[3] in (0,1) and "EL0t" in record
            if x[1]:
                assert x[1] not in req
                req[x[1]]=(x[3],x[2])
                events.append(("receive",x[1],x[3],x[2]))
            else:
                assert x[2]==0
                events.append(("exit",0,x[3],0))
        elif pc in (0x402154,0x4021bc,0x402230,0x40228c) and x[8]==23:
            assert x[0] in req and x[0] not in replies and "EL0t" in record
            result=x[1] if x[1]<2**63 else x[1]-2**64
            replies[x[0]]=result
            events.append(("reply",x[0],req[x[0]][0],result))
    assert len(req)==last and sorted(req)==list(range(1,last+1))
    assert sorted(e[2] for e in events if e[0]=="exit")==[0,1]
    missing=set(req)-set(replies)
    if mode=="cancel":
        assert len(missing)==1 and req[next(iter(missing))]==(0,0x13<<56)
    else: assert not missing
    stages={}
    waits=[]
    pending={}
    categories=collections.Counter()
    deaths=set()
    detail=[]
    for i,(kind,token,who,v) in enumerate(events):
        if kind=="receive":
            assert who not in deaths
            tag=v>>56
            if tag==0x11:
                op=(v>>48)&255
                if token in replies and replies[token]==0: stages[who]=op
            else: op=stages.get(who)
            if tag==0x13: pending[token]=(i,who,op)
            categories[(who,tag)]+=1
        if kind=="exit": deaths.add(who)
        if kind=="reply" and token in pending:
            a,_,op=pending.pop(token)
            if any(row[0] in ("receive","exit") and row[2]!=who for row in events[a+1:i]):
                waits.append(dict(caller=who,operation=op,token=token,result=v,peer_exit_between=any(row[0]=="exit" for row in events[a+1:i])))
        detail.append([kind,token,who,v])
    assert all(e[0]!="receive" or (e[3]>>56) in range(0x11,0x17) for e in events)
    if mode=="death":
        assert any(w["caller"]==0 and w["operation"]==6 and w["result"]==1 for w in waits)
        assert any(w["caller"]==0 and w["operation"]==6 and w["result"]==-32 and w["peer_exit_between"] for w in waits)
    staged={}
    commits=[]
    outputs={}
    decoded=[]
    partial_exits=[]
    for token,(who,w) in req.items():
        octets=w.to_bytes(8,"little")
        tag=octets[7]
        result=replies.get(token)
        if tag==0x11:
            if who in staged:
                assert result==-16
                continue
            assert result==0
            staged[who]=(octets[6],octets[5],octets[4],octets[3],octets[2],bytearray())
        if tag==0x12:
            assert result==0
            _,_,_,p,n,buf=staged[who]
            assert octets[6]==len(buf)
            used=min(6,p+n-len(buf))
            assert used>0 and octets[used:6]==bytes(6-used)
            buf.extend(octets[:used])
        if tag==0x13:
            op,fd,arg,p,n,buf=staged.pop(who)
            assert len(buf)==p+n
            commits.append((who,op,fd,arg,bytes(buf[:p]),bytes(buf[p:]),result))
        if tag==0x14:
            copied,full,path=result&255,(result>>8)&255,result>>16
            assert copied<=full and copied<=64 and path<=31
            outputs[who]=dict(copied=copied,full=full,path=path,data=bytearray())
        if tag==0x15:
            d=outputs[who]
            assert octets[6]==len(d["data"])
            left=d["copied"]+d["path"]-octets[6]
            assert left>0 and 0<=result<1<<48
            d["data"].extend(result.to_bytes(6,"little")[:left])
            if len(d["data"])==d["copied"]+d["path"]:
                decoded.append((who,d["full"],bytes(d["data"][:d["copied"]]),bytes(d["data"][d["copied"]:])))
        if tag==0x16: staged.pop(who,None)
    partial_exits=sorted(staged)
    assert partial_exits==([1] if mode=="death" else [])
    if mode=="stream":
        writes=[(c[5],c[6]) for c in commits if c[0]==1 and c[1]==6 and c[2]==0]
        assert writes==[(bytes(range(1,8)),7),(bytes(range(8,72)),57),(bytes([250]),-11)]
        assert [(d[1],d[2]) for d in decoded if d[0]==0 and len(d[2])>1]==[(3,bytes(range(1,4))),(16,bytes(range(4,20))),(45,bytes(range(20,65)))]
    if mode=="dgram":
        assert [(d[1],d[2],d[3]) for d in decoded if d[0]==0 and d[3]]==[(5,bytes((10,11,12)),b"/origin"),(2,bytes((20,21)),b"/origin")]
        assert (1,1,b"J",b"/telemetry") in decoded
    if mode=="seq":
        assert [d[2] for d in decoded if d[0]==0 and d[1]==3]==[bytes((i,i+10,i+20)) for i in range(1,5)]
    return dict(calls=last,reply_attempts=len(replies),caller_counts=[sum(v for (c,_),v in categories.items() if c==i) for i in (0,1)],
        verified_wire_commits=len(commits),decoded_nonempty_reads=len(decoded),owners_exiting_with_partial_input=partial_exits,
        authenticated_exit_order=[e[2] for e in events if e[0]=="exit"],unanswered_timed_out=sorted(missing),deferred=waits),detail

if __name__=="__main__":
    raw=Path(sys.argv[1])
    layout=readj(raw/"layout.json")
    report={}
    for mode in MODES:
        for policy in ("fifo","rr"):
            case=mode+"-"+policy
            pkg=raw/("pkg-"+case)
            first=capture(pkg,raw/("cap-"+case),mode,layout)
            rep=capture(pkg,raw/("trace-"+case),mode,layout)
            assert first["slot_results"]==rep["slot_results"] and first["last_token"]==rep["last_token"]
            first["register_replay"],_ = trace(raw/("trace-"+case),mode,rep["last_token"])
            report[case]=first
    print(json.dumps(report,indent=2))
