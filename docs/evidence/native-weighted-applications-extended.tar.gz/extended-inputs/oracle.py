#!/usr/bin/env python3
"""Compute all full-result oracles without building or running a guest."""
from math import comb
import json
import zlib

def uint(value, width):
    if not 0 <= value < 1 << width:
        raise ValueError(f"{value} does not fit u{width}")
    return value

crc_bytes = uint(128 * 1024**2, 32)
chunk = bytes(range(256)) * 4096
crc = 0
for _ in range(crc_bytes // len(chunk)):
    crc = zlib.crc32(chunk, crc)
crc = uint(crc, 32)

hist_blocks = 2**21
hist = [uint(comb(8, ones) * hist_blocks, 32) for ones in range(9)]
score = uint(sum((index + 1)**2 * count for index, count in enumerate(hist)), 64)

energy_blocks = 2**22
energy = uint(sum(sample * sample for sample in range(-128, 128)) * energy_blocks, 64)
expected = {
    "checksum": [crc_bytes, crc, crc % 251],
    "histogram": [uint(hist_blocks * 256, 32), hist, score % 251],
    "continuous_reporter": [uint(energy_blocks * 256, 32), energy, energy % 251],
    "reporter": [3, 7, 7],
}
print(json.dumps({"expected": expected}, indent=2))
