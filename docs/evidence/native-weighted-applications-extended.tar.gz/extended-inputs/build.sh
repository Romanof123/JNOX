#!/bin/sh
# Usage: sh build.sh /path/to/pinned/JNOX /new/output/directory
set -eu
[ "$#" -eq 2 ] || { echo "usage: sh build.sh SDK_CHECKOUT NEW_OUTPUT" >&2; exit 2; }
inputs=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
repo=$(CDPATH= cd -- "$1" && pwd)
test "$(git -C "$repo" rev-parse HEAD)" = 100d32e1b6e49277c9801723b8cc5b0dd3ad801f
(cd "$inputs" && sha256sum -c SHA256SUMS)
mkdir "$2"
out=$(CDPATH= cd -- "$2" && pwd)
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT
cp -R "$inputs/examples" "$stage/examples"
mkdir "$stage/sdk"
ln -s "$repo/sdk/native-aarch64" "$stage/sdk/native-aarch64"
export CARGO_TARGET_DIR="$stage/target"
for app in checksum continuous_reporter reporter; do
    sh "$stage/sdk/native-aarch64/build.sh" "$stage/examples/native-weighted/$app.c" "$out/$app.elf"
done
sh "$stage/sdk/native-aarch64/build-rust.sh" "$stage/examples/native-weighted-rust/Cargo.toml" "$out/histogram.elf"
(cd "$out" && sha256sum *.elf > elf.sha256)
