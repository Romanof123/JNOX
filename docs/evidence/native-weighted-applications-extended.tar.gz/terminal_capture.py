import pathlib,sys,json,re,struct,subprocess as sp,time,math,zlib,os,fcntl
D=pathlib.Path(__file__).resolve().parent
bins=[262144*sum(i.bit_count()==k for i in range(256)) for k in range(9)]
crc=zlib.crc32(bytes(range(256))*65536)
energy=524288*sum(i*i for i in range(-128,128))
expected={'checksum':(16777216,crc,crc%251),'histogram':(67108864,bins,sum((k+1)**2*v for k,v in enumerate(bins))%251),'continuous_reporter':(134217728,energy,energy%251),'reporter':(3,7,7),'boundary':(3,17,17),'boundary_peer':(2,19,19)}
cases={'share':['checksum','histogram'],'wake':['checksum','reporter'],'swap':['checksum','histogram'],'triple':['checksum','histogram','continuous_reporter'],'mixed':['checksum','histogram','reporter'],'solo':['boundary'],'boundary':['boundary','boundary_peer']}
order=['share-default','share-icount','wake-default','wake-icount','swap-default','triple-default','solo-default','boundary-default','mixed-default']
def argv(kernel,r,mode):
 return ['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(r/'uart.log')]+(['-icount','shift=3,align=off,sleep=off'] if mode=='icount' else [])+['-kernel',str(kernel)]
def launch(label):
 case,mode=label.split('-'); r=D/'supplemental-icount'/label; r.mkdir()
 apps=cases[case]; kernel=D/'elf'/case/'kernel.elf'
 syms=sp.check_output(['aarch64-linux-gnu-nm','-S',kernel],text=True)
 base,size=map(lambda x:int(x,16),next(l for l in syms.splitlines() if '6SPACES' in l).split()[:2])
 stride=0x415000; assert size==stride*len(apps)
 fields=[]
 for slot,app in enumerate(apps):
  items={}
  for l in (D/'elf'/(app+'.elf.sym')).read_text().splitlines():
   s=l.split()
   if len(s)==4 and s[-1] in ('private_progress','private_result','report_deadline_ns','report_observed_ns','boundary_deadline_ns'):
    items[s[-1]]=(base+stride*slot+5*4096+int(s[0],16)-0x400000,int(s[1],16))
  fields.append(items)
 args=argv(kernel,r,mode)
 (r/'command.json').write_text(json.dumps(dict(argv=args,apps=apps,fields=fields)))
 with (r/'qemu.stderr').open('w') as err,(r/'progress.jsonl').open('w') as obs,sp.Popen(args,stdin=sp.PIPE,stdout=sp.PIPE,text=True,stderr=err) as p:
  try:
   def read():
    while True:
     data=json.loads(p.stdout.readline())
     if 'event' not in data:return data
   def cmd(name,**kwargs):
    p.stdin.write(json.dumps({'execute':name,'arguments':kwargs})+'\n');p.stdin.flush()
    return read()['return']
   def mem(address,width):
    out=cmd('human-monitor-command',**{'command-line':f'xp /{width}bx {address:#x}'})
    return bytes(int(b,16) for l in out.splitlines() for b in re.findall(r'0x([0-9a-fA-F]{2})\b',l.split(':',1)[1]))
   read();cmd('qmp_capabilities'); start=time.monotonic()
   while True:
    ps=[int.from_bytes(mem(*s['private_progress']),'little') for s in fields]
    print(json.dumps([time.monotonic_ns(),ps]),file=obs,flush=True)
    uart=(r/'uart.log').read_text(errors='replace')
    if 'NATIVE WEIGHTED EVENT' in uart:
     symbols={}
     for key in ['11EXIT_STATUS','8weighted4ROWS','8weighted4USED','8weighted4LOST']:
      symbols[key]=int(next(l for l in syms.splitlines() if key in l).split()[0],16)
     used=int.from_bytes(mem(symbols['8weighted4USED'],8),'little')
     lost=int.from_bytes(mem(symbols['8weighted4LOST'],8),'little')
     statuses=list(struct.unpack('<ii',mem(symbols['11EXIT_STATUS'],8)))
     reply=cmd('pmemsave',val=symbols['8weighted4ROWS'],size=used*39*8,filename=str(r/'rows.bin'))
     if reply:raise ValueError(reply)
     rows=list(struct.iter_unpack('<39Q',(r/'rows.bin').read_bytes()))
     assert len(rows)==used and rows[-1][0]==3 and rows[-1][3]==2**64-1
     (r/'terminal.json').write_text(json.dumps(dict(used=used,lost=lost,statuses=statuses,symbols=symbols)))
     # Render a separate derived view solely for the existing text replay.
     rendered=['NATIVE WEIGHTED EVENT '+' '.join(map(str,row)) for row in rows]+[f'NATIVE WEIGHTED DROPPED {lost}']+[f'NATIVE EL0 EXIT PID {i} {status}' for i,status in enumerate(statuses)]
     (r/'ram-derived.txt').write_text(chr(10).join(rendered)+chr(10))
     break
    if time.monotonic()-start>180:raise TimeoutError('terminal state not reached')
    time.sleep(.012)
   raw=[{k:mem(*v).hex() for k,v in s.items()} for s in fields]; (r/'ram.json').write_text(json.dumps(raw))
   cmd('quit');p.wait(4)
  finally:
   if p.poll() is None:p.kill();p.wait()
   (r/'qemu.status').write_text(str(p.returncode))
if __name__=='__main__':
 lock=(D/'lane.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 label='share-icount'
 (D/'supplemental-icount'/'prelaunch.json').write_text(json.dumps(dict(case=label,expected=expected,watchdog_s=180,clock='shift=3',image_sha256='546e3ece41c17f042dd3730d51196ea504aa236afac65718a547c7162be07659',Q=625000,H=781250,G=156250,terminal='read full physical journal, both private images and EXIT_STATUS once post-final-exit UART dump begins'),indent=2))
 assert not sp.run(['pgrep','-f','^qemu-system-aarch64'],capture_output=True).stdout
 launch(label)