from capture import D,cases,expected,order
import json,math,re,struct
from fractions import Fraction as F
Q=625000; H=781250; G=156250; NONE=2**64-1
def score(label):
 case=label.split('-')[0]; apps=cases[case]; n=len(apps)
 w={'swap':[2,1],'solo':[1]}.get(case,list(range(1,n+1)))
 r=D/'supplemental-icount'/label; uart=(r/'ram-derived.txt').read_text()
 rows=[list(map(int,l.split()[3:])) for l in uart.splitlines() if l.startswith('NATIVE WEIGHTED EVENT') and len(l.split())==42]
 clocks=[list(map(int,l.split()[3:])) for l in uart.splitlines() if l.startswith('NATIVE WEIGHTED CLOCK')]
 ram=json.loads((r/'ram.json').read_text()); product=[]; exits=[]
 for i,app in enumerate(apps):
  fields=ram[i]; dec=lambda k:int.from_bytes(bytes.fromhex(fields[k]),'little')
  result=list(struct.unpack('<9I',bytes.fromhex(fields['private_result']))) if app=='histogram' else dec('private_result')
  match=re.search('NATIVE EL0 EXIT '+(f'PID {i} ' if n>1 else '')+r'(-?\d+)',uart);status=int(match[1]) if match else None
  product.append([dec('private_progress'),result]==list(expected[app][:2]));exits.append(status)
 vr=[F(0)]*n; srv=[0]*n; ready=set(range(n)); sleeping={}; floor=F(0); old=NONE; seq=0; prev=None; errors=[]; timing=[]; window=0; window_service=[]; wake=[]; blocked={}
 def check(ok,what):
  if not ok:errors.append([idx,what])
 def advance():
  return max(floor,min((vr[k] for k in ready),default=floor))
 target=36 if case in ('share','swap') else 60 if case=='triple' else 0
 for idx,b in enumerate(rows):
  reason,now,prior,nxt=b[:4]; check(prior==old,'previous')
  if old!=NONE:
   elapsed=now-prev[15];check(b[4]==prev[14] and b[5]==prev[15] and b[6]==elapsed and b[8]==prev[16],'lease/elapsed/compare')
   srv[old]+=elapsed;vr[old]+=F(elapsed,w[old]);floor=advance()
   if reason in (2,3):
    ready.remove(old);floor=advance()
    if reason==2:sleeping[old]=b[7];blocked[old]=(idx,b[7],srv[:])
  due=sorted((t,i) for i,t in sleeping.items() if t<=now)
  for _,i in due:
   del sleeping[i];vr[i]=max(vr[i],F(math.ceil(floor*w[i]),w[i]));ready.add(i);floor=advance()
  if nxt!=NONE:seq+=1
  check(nxt==min(ready,key=lambda i:(vr[i],i),default=NONE),'minimum')
  check(b[14]==(seq if nxt!=NONE else 0) and b[11]==sum(1<<i for i in ready),'sequence/ready')
  check(b[12]==sum(1<<i for _,i in due) and b[36]==sum((i+1)*16**k for k,(_,i) in enumerate(reversed(due))),'admission order')
  check(b[24:24+n]==srv and F(b[21])+F(b[22],b[23])==floor,'service/floor')
  for i in range(n):
   a=27+3*i;check(F(b[a])+F(b[a+1],b[a+2])==vr[i],'runtime')
  arms=list(sleeping.values())+([b[15]+Q] if len(ready)>1 else [])
  check(b[16]==min(arms,default=0),'next compare')
  if target and 1<=idx<=target:
   if reason==4 and prev[11]==(1<<n)-1 and b[11]==prev[11] and window==idx-1:
    window+=1;window_service=srv[:]
    if not Q<=b[6]<=H:timing.append([idx,'full interval',b[6]])
    if b[15]-now>G:timing.append([idx,'gap',b[15]-now])
    if n==2:
     a,c=(srv if w[0]==1 else srv[::-1]);delta=2*a-c
     if not -H<=delta<=2*H:timing.append([idx,'prefix',delta])
     if idx==36 and (sum(srv)<36*Q or abs(delta)*36*Q>2*H*sum(srv)):timing.append([idx,'terminal inequality',delta])
    elif max(vr)-min(vr)>H:timing.append([idx,'spread',str(max(vr)-min(vr))])
  if case in ('wake','mixed') and any(apps[i]=='reporter' for _,i in due):
   i=apps.index('reporter');sl,D0,ss=blocked[i];ret=next((k for k in range(idx,len(rows)) if rows[k][3]==i),None)
   rr=rows[ret];start=rr[15];cl=next(c for c in clocks if c[0]==i and c[1]>=start)
   # R lies after the return hook and before restored EL0's next clock syscall.
   I,W,L,U=now,b[13],cl[1],cl[2]
   bounds=[I-D0,W-I,L-W,U-start,U-D0]
   saved=rows[sl][17];restored=rr[19];clock_pc=cl[4]
   blocks=[t for t in rows[sl+1:idx+1] if t[2]==0]
   entrypc=int(next(x for x in (D/'elf'/'checksum.elf.sym').read_text().splitlines() if x.endswith(' checksum_stream')).split()[0],16)
   user=restored==saved and clock_pc!=0 and all((D/'elf'/'reporter.elf.dis').read_text().find(f'{v:x}:')>=0 for v in [restored,clock_pc-4])
   wake.append(dict(target=D0,irq=I,admission=W,ret_lower=start,L=L,U=U,conservative_bounds=bounds,latency_pass=D0<=I<=W<=start<=L<=U and all(v<=m for v,m in zip(bounds,[G,G,H+2*G,G,H+5*G])),peer_service=srv[0]-ss[0],reporter_charge=srv[i]-ss[i],peer_pc=[t[17] for t in blocks],restore_pc=restored,clock_pc=clock_pc,user=user))
  old=nxt; prev=b
 active=[b for b in rows[1:] if b[2]!=NONE and b[0]==4 and b[9] and b[8]==b[9]]
 return dict(rows=len(rows),exit=exits,products=product,window_service=window_service,dropped=(int(re.search(r'DROPPED (\d+)',uart)[1]) if 'DROPPED' in uart else None),selection_errors=errors[:8],required_window=target,observed_window=window,timing_errors=timing[:8],wake=wake,contended_full_excess=[(b[4],b[6]-H) for b in active if b[6]>H][:8],idle=sum(b[3]==NONE and b[16]!=0 for b in rows),coadmission=[b[36] for b in rows if b[12].bit_count()>1],solo_yield=sum(b[0]==1 and b[11].bit_count()==1 for b in rows))
if __name__=='__main__':
 (D/'supplemental-icount'/'score.json').write_text(json.dumps(score('share-icount'),indent=2))