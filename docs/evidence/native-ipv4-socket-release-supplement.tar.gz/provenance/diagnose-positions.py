from pathlib import Path
import runpy, difflib, collections
m=runpy.run_path(str(Path(__file__).with_name('release-replay.py')))
root=Path('/home/ywcho/v383-ipv4-release/release-evidence')
for name in ('standard-fifo-first','standard-rr-first','record-fifo-first','record-rr-first'):
    peer=m['packets'](root/(name+'-host')/'peer.pcap',(0,))[0]
    dev=m['packets'](root/name/'wire.pcap',(10,12))[0]
    a=[str(r[:-1]) for r in dev]; b=[str(r[:-1]) for r in peer]
    print(name,len(a),len(b),collections.Counter(a)==collections.Counter(b))
    print('\n'.join(difflib.unified_diff(a,b,n=0)))

