"""Offline verification from two independent pcap positions, exact ELFs and post-stop RAM.

Use normal Python 3 with GNU aarch64-linux-gnu-nm available.
"""
import collections
import hashlib
import json
import mmap
from pathlib import Path
import re
import socket
import struct
import subprocess
import sys

root = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
G = "10.0.2.15"
A = "10.0.2.2"
B = "10.0.2.3"
rev = "874720752f02d52788ecc03696209332045731af"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def sym(path, test):
    output = subprocess.check_output(["aarch64-linux-gnu-nm","--defined-only","-S",path],text=True)
    found = [line.split() for line in output.splitlines() if len(line.split())==4 and test(line.split()[-1])]
    assert len(found)==1, (path, found)
    return int(found[0][0],16), int(found[0][1],16)

def private(kernel, slots, ram, names):
    base, length = sym(kernel, lambda n: 'native_el0_mmu' in n and '6SPACES' in n)
    assert base%4096 == 0 and length%12288 == 0
    stride = length//3
    result = []
    frames = set()
    for i,(path,name) in enumerate(zip(slots,names)):
        va, size = sym(path, lambda n: n==name)
        assert size%8==0 and va//4096==(va+size-1)//4096
        table = base + i*stride
        for shift in (30,21,12):
            at = table+8*((va>>shift)&511)-0x40000000
            assert 0<=at<=len(ram)-8
            entry=struct.unpack_from('<Q',ram,at)[0]
            assert entry&3==3
            table=entry&0x0000fffffffff000
            if shift!=12:
                assert entry==(table|3)
        assert (entry>>6&3,entry>>53&3,entry>>10&1,entry>>2&7)==(1,3,1,0)
        assert table not in frames
        frames.add(table)
        at=table+(va%4096)-0x40000000
        assert 0<=at<=len(ram)-size
        result.append(list(struct.unpack_from('<'+'q'*(size//8),ram,at)))
    return result

def packets(path, prefixes):
    raw=path.read_bytes()
    assert raw[:4]==bytes.fromhex('d4c3b2a1') and struct.unpack_from('<I',raw,20)[0]==1
    pos=24
    rows=[]
    offsets=collections.Counter()
    while pos<len(raw):
        n,orig=struct.unpack_from('<II',raw,pos+8)
        frame=raw[pos+16:pos+16+n]
        assert len(frame)==orig==n
        pos+=16+n
        possible=[p for p in prefixes if frame[p+12:p+14] in (b'\x08\x00',b'\x08\x06',b'\x86\xdd')]
        assert len(possible)==1
        pre=possible[0]
        offsets[pre]+=1
        eth=frame[pre:]
        if eth[12:14]!=b'\x08\x00': continue
        ip=eth[14:]
        ihl=(ip[0]&15)*4
        end=int.from_bytes(ip[2:4],'big')
        assert ip[0]>>4==4 and 20<=ihl<=end<=len(ip)
        src, dst = socket.inet_ntoa(ip[12:16]),socket.inet_ntoa(ip[16:20])
        assert G in (src,dst) and {src,dst}<={G,A,B}
        segment=ip[ihl:end]
        proto=ip[9]
        assert proto in (6,17)
        sport,dport=struct.unpack_from('!HH',segment)
        if proto==17:
            assert struct.unpack_from('!H',segment,4)[0]==len(segment)
            flags=0
            payload=segment[8:]
        else:
            h=(segment[12]>>4)*4
            assert 20<=h<=len(segment)
            flags=segment[13]
            payload=segment[h:]
        rows.append((proto,src,sport,dst,dport,flags,payload,eth))
    assert pos==len(raw)
    return rows,dict(offsets)

def check_tcp(rows):
    flows=collections.defaultdict(list)
    for proto,src,sp,dst,dp,flags,data,_ in rows:
        if proto==6:
            assert {src,dst}=={G,A}
            outbound=src==G
            flows[(sp,dp) if outbound else (dp,sp)].append((outbound,flags,data))
    assert len(flows)==3
    proof={}
    for ports,flow in flows.items():
        guest=b''.join(data for out,flags,data in flow if out)
        host=b''.join(data for out,flags,data in flow if not out)
        typ={b'GUEST/out':'outbound',b'GUEST/accepted':'accepted',b'ARM!':'reset'}[guest]
        assert host=={'outbound':b'HOST/outbound','accepted':b'HOST/inbound','reset':b''}[typ]
        assert (ports[0]==43001 if typ=='accepted' else ports[1]==43002)
        initiator=typ!='accepted'
        assert flow[0][0]==initiator and flow[0][1]&0x12==2
        assert any(out!=initiator and flags&0x12==0x12 for out,flags,_ in flow)
        fins=[out for out,flags,_ in flow if flags&1]
        resets=[out for out,flags,_ in flow if flags&4]
        if typ=='reset':
            arm=next(i for i,(_,_,data) in enumerate(flow) if data==b'ARM!')
            assert not fins and resets==[False] and any(not out and flags&4 for out,flags,_ in flow[arm+1:])
        else:
            assert sorted(fins)==[False,True] and not resets
        proof[typ]={'ports':ports,'app_bytes':[guest.decode(),host.decode()],'FIN':fins,'RST':resets}
    assert set(proof)=={'accepted','outbound','reset'}
    return proof

def check_namespace(text):
    assert 'default' not in text
    assert set(re.findall(r'^(\S+)\s+(?:UP|DOWN|UNKNOWN)\s', text,re.M))=={'lo','jnx0'}
    assert '10.0.2.0/24 dev jnx0' in text

def udp(rows):
    return [(src,sp,dst,dp,data) for proto,src,sp,dst,dp,_,data,_ in rows if proto==17]

def compact_udp(rows):
    return [[s,p,d,q,b.hex()] for s,p,d,q,b in rows]

def normal_udp(prelink=False):
    a=[(G,43003,A,43004,bytes([85,n,10*n])) for n in (1,2,3,4)]
    b=[(A,43004,G,43003,bytes([82,n,10*n])) for n in ((1,2,3,4,0) if prelink else (1,4,3,0))]
    return a+b+[(G,43003,A,43004,b'DONE')]

def record_udp():
    return [(G,43003,A,43004,b''),(A,43004,G,43003,b''),(G,43003,A,43004,b'NEXT1'),
            (B,43005,G,43003,b'abcdefgh'),(G,43003,A,43004,b'NEXT2'),
            (A,43004,G,43003,b'UVWXYZ'),(G,43003,A,43004,b'DONE')]

def check_fresh(kind,pol):
    name=f'{kind}-{pol}-first'
    run=root/name
    side=root/(name+'-host')
    pkg=root/(pol if kind=='standard' else 'record-'+pol)
    manifest=json.loads((pkg/'manifest.json').read_text())
    launch=json.loads((run/'launch.json').read_text())
    assert manifest['policy']==pol and manifest['commit']==rev and not manifest['tracked_changes']
    assert manifest['quantum_ticks']==(625000 if pol=='rr' else None)
    assert manifest['socket_service']=={'slot':2,'authorized_clients':[0,1]}
    assert manifest['net_service']['slot']==2 and manifest['net_service']['transport']=='virtio-net-mmio-modern'
    kernel=pkg/'kernel.elf'
    assert sha(kernel)==manifest['kernel_elf_sha256']==launch['kernel_sha256']
    argv=launch['argv']
    assert argv[argv.index('-netdev')+1]=='tap,id=lan,ifname=jnx0,script=no,downscript=no'
    for flag,value in [('-cpu','cortex-a72'),('-smp','1'),('-accel','tcg')]: assert argv[argv.index(flag)+1]==value
    uart=(run/'uart').read_text()
    assert 'NATIVE EL0 FAULT' not in uart
    slots=[pkg/s['elf'] for s in manifest['slots']]
    hashes=[sha(s) for s in slots]
    assert len(set(hashes))==3
    assert hashes==[s['elf_sha256'] for s in manifest['slots']]==re.findall(r'^NATIVE EL0 (?:PEER2? )?ELF ([0-9a-f]{64})$',uart,re.M)
    for slot in slots:
        elf=slot.read_bytes()
        assert elf[:7]==b'\x7fELF\x02\x01\x01' and struct.unpack_from('<HH',elf,16)==(2,183)
    exits=[[int(n),int(code)] for n,code in re.findall(r'NATIVE EL0 EXIT PID (\d+) (\d+)',uart)]
    assert exits==[[0,75],[1,76],[2,0]]
    assert json.loads((run/'status.json').read_text())=={'tcp':'complete','udp':'complete','guest_exits':exits}
    names=['inet_tcp_result','inet_udp_result' if kind=='standard' else 'ipv4_record_results','inet_activity']
    with (run/'ram.bin').open('rb') as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as ram:
        assert len(ram)==128<<20
        tcp,app,broker=private(kernel,slots,ram,names)
    assert tcp[:3]==[4,9,13] and 0<tcp[3]<=3 and tcp[4:]==[0,12,14,0,4,-1,104,1]
    assert broker[1]>0 and broker[2]==2 and broker[3]>0
    logs=[json.loads(l) for l in (run/'peer.jsonl').read_text().splitlines()]
    assert [x['data'] for x in logs if x['kind']=='tcp_out_rx']==[b'GUEST/out'.hex()]
    assert [x['data'] for x in logs if x['kind']=='tcp_in_rx']==[b'GUEST/accepted'.hex()]
    assert [x['received'] for x in logs if x['kind']=='tcp_abortive_close']==[b'ARM!'.hex()]
    check_namespace((side/'namespace.txt').read_text())
    assert '0 packets dropped by kernel' in (side/'capture.log').read_text()
    dev,offsets=packets(run/'wire.pcap',(10,12))
    peer,_=packets(side/'peer.pcap',(0,))
    # Independent host/guest directions can interleave differently at the two taps.
    assert collections.Counter(x[:-1] for x in dev)==collections.Counter(x[:-1] for x in peer)
    assert udp(dev)==udp(peer)
    def tcp_sequences(rows):
        flows=collections.defaultdict(list)
        for proto,src,sp,dst,dp,flags,data,frame in rows:
            if proto==6:
                offset=14+(frame[14]&15)*4
                seq,ack=struct.unpack_from('!II',frame,offset+4)
                ports=(sp,dp) if src==G else (dp,sp)
                flows[ports].append((src,flags,seq,ack,data))
        return flows
    assert tcp_sequences(dev)==tcp_sequences(peer)
    tcp_wire=check_tcp(dev)
    assert tcp_wire==check_tcp(peer)
    datagrams=udp(dev)
    if kind=='standard':
        assert datagrams==normal_udp()
        assert app[:10]==[3,3,3,3,1,4,3,0,0x0a000202,43004] and app[10]>0 and app[11:]==[1,0,0,0,0]
    else:
        assert datagrams==record_udp()
        expected=[1,0,0,0x0a000202,43004,0xa5a5a5,5,3,0x0a000203,43005,0x616263,
                  5,6,0x0a000202,43004,0x555657,-11,4,1]+[0]*5
        assert app==expected
        observed=[]
        for entry in logs:
            if entry['kind']=='udp_receive':
                observed.append((*entry['peer'],*entry['local'],bytes.fromhex(entry['data'])))
            if entry['kind']=='udp_transmit':
                data=bytes.fromhex(entry['data'])
                assert entry['count']==len(data)
                observed.append((*entry['local'],*entry['peer'],data))
        assert observed==datagrams
    device=list(map(int,re.search(r'^NATIVE NET DEVICE (.+)$',uart,re.M)[1].split()))
    assert device[2]>0 and device[3]==device[4]>0 and device[-1]==0
    return dict(slot_sha256=hashes,kernel=sha(kernel),exits=exits,tcp_private=tcp,udp_private=app,
                broker_private=broker,device=device,pcap_prefix_counts=offsets,transport_packets=len(dev),
                tcp=tcp_wire,udp=compact_udp(datagrams))

def historical(pol):
    folder=root/'original-wire'/pol
    before,_=packets(folder/'peer.pcap',(0,))
    after,_=packets(folder/'wire.pcap',(0,))
    assert udp(before)==normal_udp(True) and udp(after)==normal_udp()
    assert check_tcp(before)==check_tcp(after)
    check_namespace((folder/'namespace.txt').read_text())
    assert '0 packets dropped by kernel' in (folder/'tcpdump.log').read_text()
    events=[json.loads(line) for line in (folder/'link.jsonl').read_text().splitlines()]
    original=[row[-1] for row in before if row[0]==17 and row[1]==A]
    kept=[row[-1] for row in after if row[0]==17 and row[1]==A]
    assert [(e['id'],e['action']) for e in events]==[(1,'pass'),(2,'drop'),(3,'hold'),(4,'pass-and-release'),(0,'pass')]
    assert [bytes.fromhex(e['frame']) for e in events]==original
    assert kept==[original[i] for i in (0,3,2,4)]
    return dict(peer_ids=[r[6][1] for r in before if r[0]==17 and r[1]==A],
                device_ids=[r[6][1] for r in after if r[0]==17 and r[1]==A],
                discarded_frame_sha256=hashlib.sha256(original[1]).hexdigest())

if __name__=='__main__':
    report={f'{kind}-{p}':check_fresh(kind,p) for kind in ('standard','record') for p in ('fifo','rr')}
    report.update({f'archived-link-{p}':historical(p) for p in ('fifo','rr')})
    print(json.dumps(report,indent=2,sort_keys=True))
