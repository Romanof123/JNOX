#!/usr/bin/env bash
set -eu
wr=/home/ywcho/v383-ipv4-release
mkdir -p "$wr"
mkdir "$wr/previous" "$wr/corrected"
for spec in 'previous /mnt/d/codex/.jnox-work/376-ipv4-first-906fdd0 376-ipv4-first-906fdd0' 'corrected /mnt/d/codex/.jnox-work/next-fixed/376-inet-05b26e7-receipt 376-ipv4-corrected-05b26e7'; do
    read -r sub folder prefix <<< "$spec"
    (cd "$folder" && sha256sum -c "$prefix.tar.gz.sha256") > "$wr/$sub-outer.txt"
    tar -xzf "$folder/$prefix.tar.gz" -C "$wr/$sub"
    (cd "$wr/$sub" && sha256sum -c SHA256SUMS) > "$wr/$sub-inner.txt"
    (cd "$wr/$sub" && PYTHONPATH=/home/ywcho/jnox-169-first-e203caa/deps python3 replay.py) > "$wr/$sub-replay.json"
    cmp "$wr/$sub-replay.json" "$wr/$sub/replay.json"
done
