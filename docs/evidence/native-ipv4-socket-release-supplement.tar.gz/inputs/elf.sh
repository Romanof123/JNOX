#!/usr/bin/env bash
set -euo pipefail
raw=/home/ywcho/v383-ipv4-release/run
for file in tcp udp broker; do
    aarch64-linux-gnu-readelf -Whl "$raw/$file.elf" > "$raw/$file.readelf"
    aarch64-linux-gnu-nm --defined-only "$raw/$file.elf" | grep -E 'inet_(tcp_result|udp_result|activity)$| recvfrom$| sendto$| recv$| connect$| accept$' > "$raw/$file.symbols"
done
