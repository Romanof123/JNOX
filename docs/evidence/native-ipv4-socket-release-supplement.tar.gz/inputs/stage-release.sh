#!/usr/bin/env bash
set -euo pipefail
base=$(cd "$(dirname "$0")" && pwd)
wr=/home/ywcho/v383-ipv4-release
raw=$wr/run
pkg=$wr/release-evidence
mkdir "$pkg"
mkdir -p "$pkg"/{inputs,provenance,original-wire}
cp "$base"/{record.rs,build-record.sh,record-peer.py,tap-release.sh,build.sh,extract.sh,elf.sh} "$pkg/inputs/"
cp "$base/release-replay.py" "$pkg/"
cp "$raw"/{build-status.txt,boot-status.txt,revision.txt,status-after.txt,status-after-record.txt,commands.sh,platform.txt,*.readelf,*.symbols,*.log} "$pkg/provenance/"
cp "$wr/record-app"/{Cargo.toml,Cargo.lock} "$pkg/inputs/"
cp "$wr/public-source/examples/native-inet-sockets"/{tcp.c,peer.py} "$pkg/inputs/"
cp "$wr/public-source/examples/native-inet-sockets/udp/src/main.rs" "$pkg/inputs/published-udp.rs"
cp "$wr"/{previous,corrected}-{inner.txt,outer.txt,replay.json} "$pkg/provenance/"
for p in fifo rr; do
    for name in "$p" record-"$p"; do
        mkdir "$pkg/$name"
        cp "$raw/$name"/{*.elf,manifest.json,build.log} "$pkg/$name/"
    done
    for name in standard-"$p"-first record-"$p"-first; do
        cp -a "$raw/$name" "$raw/$name-host" "$pkg/"
    done
    mkdir "$pkg/original-wire/$p"
    cp "$wr/corrected/$p-wire-first"/{wire.pcap,private.json,peer.jsonl} "$pkg/original-wire/$p/"
    cp "$wr/corrected/$p-wire-first-host"/{peer.pcap,link.jsonl,namespace.txt,tcpdump.log} "$pkg/original-wire/$p/"
done
git -C "$base/public-objects" ls-tree -l pr383 docs/evidence/native-ipv4-socket-corrected.tar.gz docs/evidence/native-ipv4-socket-first.tar.gz > "$pkg/provenance/public-evidence-blobs.txt"
for f in /mnt/d/codex/.jnox-work/376-ipv4-first-906fdd0/*tar.gz /mnt/d/codex/.jnox-work/next-fixed/376-inet-05b26e7-receipt/*tar.gz; do
    basename "$f"
    git hash-object "$f"
    sha256sum "$f"
done > "$pkg/provenance/verified-input-archives.txt"
git -C "$base/public-objects" log -3 --format='%H %s' pr383 > "$pkg/provenance/public-revisions.txt"
git -C "$base/public-objects" diff --name-status 8747207 pr383 > "$pkg/provenance/evidence-only-head-diff.txt"
python3 "$pkg/release-replay.py" "$pkg" > "$pkg/replay.json"

