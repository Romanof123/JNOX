#!/usr/bin/env bash
set -euo pipefail
base=$(cd "$(dirname "$0")" && pwd)
wr=/home/ywcho/v383-ipv4-release
pkg=$wr/release-evidence
export GIT_ALTERNATE_OBJECT_DIRECTORIES=/mnt/d/codex/j-nox/.git/objects
git -C "$base/public-objects" diff --name-status 05b26e7407f1901e9213280846f295b12d681024 874720752f02d52788ecc03696209332045731af -- arch boards examples kernel sdk services tools trace > "$pkg/provenance/guest-source-diff.txt"
git -C "$base/public-objects" diff 05b26e7407f1901e9213280846f295b12d681024 874720752f02d52788ecc03696209332045731af -- sdk/native-aarch64/include/errno.h > "$pkg/provenance/sdk-header-diff.patch"
cat "$pkg/provenance/guest-source-diff.txt"
# Preserve the local first verifier's overly strict cross-flow comparison.
cp "$base/diagnose-positions.py" "$pkg/provenance/"
python3 "$base/diagnose-positions.py" > "$pkg/provenance/capture-interleaving.txt"
cp "$base/stage-release.sh" "$pkg/inputs/"
cp "$base/inputs-and-compare.sh" "$pkg/inputs/"

