#!/usr/bin/env bash
set -euo pipefail
base=$(cd "$(dirname "$0")" && pwd)
wr=/home/ywcho/v383-ipv4-release
raw=$wr/run
src=$wr/public-source
cd "$src"
source "$HOME/.cargo/env"
export CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$raw/app-target" CARGO_NET_OFFLINE=true
app=$wr/record-app
mkdir "$app" "$app/src"
sed -e "s|../../../sdk/native-aarch64/rust|$src/sdk/native-aarch64/rust|" -e 's/native-inet-udp/release-record-udp/' examples/native-inet-sockets/udp/Cargo.toml > "$app/Cargo.toml"
cp "$base/record.rs" "$app/src/main.rs"
sh sdk/native-aarch64/build-rust.sh --local-socket "$app/Cargo.toml" "$raw/record.elf" > "$raw/build-record.log" 2>&1
for p in fifo rr; do
    opt=()
    if [[ $p == rr ]]; then opt=(--quantum-ticks 625000); fi
    python3 tools/build_native_el0.py --out "$raw/record-$p" --policy "$p" --elf "$raw/tcp.elf" --priority 4 --peer-elf "$raw/record.elf" --peer-priority 4 --peer-elf "$raw/broker.elf" --peer-priority 7 --peer2-arg 3 --ipc-route 0:2 --ipc-route 1:2 --socket-service 2 --net-service 2 "${opt[@]}" > "$raw/pkg-record-$p.log" 2>&1
done
git status --porcelain --untracked-files=no > "$raw/status-after-record.txt"
test ! -s "$raw/status-after-record.txt"
