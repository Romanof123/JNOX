#!/usr/bin/env bash
set -euo pipefail
base=$(cd "$(dirname "$0")" && pwd)
wr=/home/ywcho/v383-ipv4-release
rev=874720752f02d52788ecc03696209332045731af
src=$wr/public-source
raw=$wr/run
mkdir -p "$wr"
mkdir "$src" "$raw"
git -C "$src" init -q
echo "$base/public-objects/.git/objects" > "$src/.git/objects/info/alternates"
cd "$src"
git sparse-checkout init --cone
git sparse-checkout set arch boards examples kernel sdk services tools trace verification
git -c advice.detachedHead=false checkout -q --detach "$rev"
git rev-parse HEAD 'HEAD^{tree}' > "$raw/revision.txt"
test -z "$(git status --porcelain --untracked-files=no)"
source "$HOME/.cargo/env"
export CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$raw/app-target" CARGO_NET_OFFLINE=true
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
(date -u; uname -a; rustc -Vv; cargo -V; qemu-system-aarch64 --version; clang --version; python3 -V; tcpdump --version; ip -V) > "$raw/platform.txt"
run() {
    local tag=$1 status=0
    shift
    printf '%q ' "$@" >> "$raw/commands.sh"
    echo >> "$raw/commands.sh"
    "$@" > "$raw/$tag.log" 2>&1 || status=$?
    echo "$tag $status" | tee -a "$raw/build-status.txt"
    if ((status)); then tail -45 "$raw/$tag.log"; fi
    return "$status"
}
app=examples/native-inet-sockets
run cc sh sdk/native-aarch64/build.sh --local-socket "$app/tcp.c" "$raw/tcp.elf"
run rust sh sdk/native-aarch64/build-rust.sh --local-socket "$app/udp/Cargo.toml" "$raw/udp.elf"
run broker sh sdk/native-aarch64/build-rust.sh services/inet/Cargo.toml "$raw/broker.elf"
for pol in fifo rr; do
    args=()
    if [[ $pol == rr ]]; then args=(--quantum-ticks 625000); fi
    run "pkg-$pol" python3 tools/build_native_el0.py --out "$raw/$pol" --policy "$pol" --elf "$raw/tcp.elf" --priority 4 --peer-elf "$raw/udp.elf" --peer-priority 4 --peer-elf "$raw/broker.elf" --peer-priority 7 --peer2-arg 3 --ipc-route 0:2 --ipc-route 1:2 --socket-service 2 --net-service 2 "${args[@]}"
done
git status --porcelain --untracked-files=no > "$raw/status-after.txt"
test ! -s "$raw/status-after.txt"
for file in tcp udp broker; do
    aarch64-linux-gnu-readelf -Whl "$raw/$file.elf" > "$raw/$file.readelf"
    aarch64-linux-gnu-nm --defined-only "$raw/$file.elf" | rg -e 'inet_(tcp_result|udp_result|activity)$| TCP| recvfrom$| sendto$| recv$| connect$| accept$' > "$raw/$file.symbols"
done
