"""Reuse the public cold-boot/TCP fixture; run two normal IPv4 UDP sockets."""
import sys
from pathlib import Path
sys.path.insert(0, '/home/ywcho/v383-ipv4-release/public-source/examples/native-inet-sockets')
import peer

def record_udp(s, log):
    with peer.sock(peer.socket.SOCK_DGRAM, "10.0.2.3", 43005, 20) as alternate:
        guest = ("10.0.2.15", 43003)
        for trigger, reply, source in (
            (b"", b"", s),
            (b"NEXT1", b"abcdefgh", alternate),
            (b"NEXT2", b"UVWXYZ", s),
        ):
            payload, addr = s.recvfrom(64)
            log("udp_receive", peer=addr, data=payload.hex(), local=s.getsockname())
            peer.require((payload,addr)==(trigger,guest), "wrong request or sender")
            n = source.sendto(reply, addr)
            log("udp_transmit", peer=addr, local=source.getsockname(), data=reply.hex(), count=n)
            peer.require(n==len(reply), "wrong reply size")
        data, addr = s.recvfrom(64)
        log("udp_receive", peer=addr, data=data.hex(), local=s.getsockname())
        peer.require((data,addr)==(b"DONE",guest), "final receipt")

peer.udp_peer = record_udp
if __name__ == '__main__':
    raise SystemExit(peer.main())
