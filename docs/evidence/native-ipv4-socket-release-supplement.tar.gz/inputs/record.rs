#![no_std]
#![no_main]

use core::{panic::PanicInfo, ptr::write_volatile};
use jnox_native::{exit, local_socket as s};

#[no_mangle]
static mut ipv4_record_results: [i64; 24] = [0; 24];

fn put(i: usize, n: i64) {
    unsafe { write_volatile(&raw mut ipv4_record_results[i], n) }
}

#[panic_handler]
fn panic(_: &PanicInfo<'_>) -> ! { exit(121) }

fn expect_count(fd: i32, data: &[u8], dest: s::Ipv4Endpoint, result: usize) -> Result<(), i32> {
    let n = s::send_to4(fd, data, 0, dest)?;
    put(result, n as i64);
    if n != data.len() { return Err(-1001); }
    Ok(())
}

fn receive(fd: i32, flags: i32, count: usize, prefix: &[u8],
           expected: s::Ipv4Endpoint, result: usize) -> Result<(), i32> {
    let mut buf = [0xa5u8; 5];
    let (n, source) = s::recv_from4(fd, &mut buf[1..4], flags)?;
    let peer = source.ok_or(-1002)?;
    put(result, n as i64);
    put(result+1, u32::from_be_bytes(peer.address).into());
    put(result+2, peer.port.into());
    put(result+3, u32::from_be_bytes([0,buf[1],buf[2],buf[3]]).into());
    if n != count || peer != expected || buf[0] != 0xa5 || buf[4] != 0xa5
        || &buf[1..1+prefix.len()] != prefix || buf[1+prefix.len()..4].iter().any(|x| *x != 0xa5) {
        return Err(-1003);
    }
    Ok(())
}

fn run() -> Result<(), i32> {
    let a = s::Ipv4Endpoint {address: [10,0,2,2], port: 43004};
    let b = s::Ipv4Endpoint {address: [10,0,2,3], port: 43005};
    s::set_broker(2)?;
    let fd=s::socket4(s::SOCK_DGRAM, false)?;
    s::bind4(fd, s::Ipv4Endpoint {address: [10,0,2,15], port: 43003})?;
    put(0, 1);
    expect_count(fd, b"", a, 1)?;
    receive(fd, 0, 0, b"", a, 2)?;
    expect_count(fd, b"NEXT1", a, 6)?;
    receive(fd, 0, 3, b"abc", b, 7)?;
    expect_count(fd, b"NEXT2", a, 11)?;
    receive(fd, s::MSG_TRUNC, 6, b"UVW", a, 12)?;
    let mut tail = [0;3];
    let error = s::recv_from4(fd, &mut tail, s::MSG_DONTWAIT).err().ok_or(-1004)?;
    put(16, i64::from(error));
    if error != -11 { return Err(-1005); }
    expect_count(fd, b"DONE", a, 17)?;
    s::close(fd)?;
    put(18, 1);
    Ok(())
}

#[no_mangle]
pub extern "C" fn main() -> i32 {
    match run() {
        Ok(()) => 76,
        Err(e) => { put(23, i64::from(e)); 123 }
    }
}
