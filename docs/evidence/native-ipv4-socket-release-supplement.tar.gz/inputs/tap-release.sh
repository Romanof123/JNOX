#!/usr/bin/env bash
set -euo pipefail
base=$(cd "$(dirname "$0")" && pwd)
wr=/home/ywcho/v383-ipv4-release
src=$wr/public-source
raw=$wr/run
kind=${1:?standard or record}
case "$kind" in standard|record) ;; *) exit 2;; esac
ns=jnx383release-$kind
ip netns add "$ns"
trap 'ip netns del "$ns"' EXIT
ip -n "$ns" link set lo up
ip netns exec "$ns" ip tuntap add dev jnx0 mode tap
ip -n "$ns" addr add 10.0.2.2/24 dev jnx0
if [[ "$kind" == record ]]; then ip -n "$ns" addr add 10.0.2.3/24 dev jnx0; fi
ip -n "$ns" link set jnx0 up
test -z "$(ip -n "$ns" route show default)"
test "$(ip -n "$ns" link | awk '/^[0-9]+:/ {print $2}' | xargs)" = "lo: jnx0:"
for p in fifo rr; do
    label=$kind-$p-first
    side=$raw/$label-host
    run=$raw/$label
    mkdir "$side"
    (ip -n "$ns" -br addr; ip -n "$ns" route; ip -n "$ns" -6 route) > "$side/namespace.txt"
    ip netns exec "$ns" tcpdump -ni jnx0 -s 0 -U -w "$side/peer.pcap" > "$side/capture.log" 2>&1 &
    cap=$!
    until grep -q 'listening on' "$side/capture.log"; do kill -0 "$cap"; sleep .05; done
    fixture=$src/examples/native-inet-sockets/peer.py
    pkg=$p
    if [[ "$kind" == record ]]; then fixture=$base/record-peer.py; pkg=record-$p; fi
    ret=0
    ip netns exec "$ns" python3 "$fixture" "$raw/$pkg" "$run" --isolated-tap jnx0 --timeout 20 > "$side/fixture.log" 2>&1 || ret=$?
    sleep 1.1
    kill -INT "$cap"; wait "$cap"
    echo "$label peer exit $ret" | tee -a "$raw/boot-status.txt"
    cat "$run/status.json"
done
