import csv,sys,subprocess,json,re,tempfile,shutil,zipfile,hashlib,os
from pathlib import Path
r=Path(sys.argv[1]).resolve()
out=Path(sys.argv[2]).resolve();out.mkdir(exist_ok=True)
pin='9ad9917d620fed9ae25ec4a38764e71828478002'
def git(*args):return subprocess.check_output(['git','-C',str(r),*args])
assert git('rev-parse','HEAD').decode().strip()==pin
def lines(file):return (r/file).read_text(encoding='utf8').splitlines()
def dump(name,obj):(out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=1),encoding='utf8')
rel=dict(OBJ='derives',THR='derives',HAZ='derives',ASM='constrains',DES='implemented-by-design',VER='verified-by')
def edge(req,x):return (req,rel[x[:3]],x) if x[:3] in ('DES','VER') else (x,rel[x[:3]],req)
decl={}; prescribed={}
for suffix in ['.en.md','.md']:
 loc={}; wanted=set()
 for book,types in [('requirements','REQ'),('product-plan','OBJ'),('safety-security-concept','HAZ THR ASM'),('verification-plan','VER'),('architecture','DES')]:
  file='docs/'+book+suffix
  for n,l in enumerate(lines(file),1):
   m=re.match(r'^## (DES-\d{3})\b' if types=='DES' else r'^\|\s*`([A-Z]{3}-\d{3})`',l)
   if not m or m[1][:3] not in types.split():continue
   id=m[1]; assert id not in loc;loc[id]=f'{file}:{n}'
   if types=='REQ':
    cells=l.split('|')
    for x in re.findall(r'\b(?:OBJ|HAZ|THR|ASM|DES|VER)-\d{3}\b',cells[2]+' '+cells[4]):wanted.add(edge(id,x))
 decl[suffix]=loc;prescribed[suffix]=wanted
en,ko=decl.values();assert en.keys()==ko.keys()
w1,w2=prescribed.values();assert w1==w2
file='trace/links.csv';rows=lines(file)
old=git('show','a106db7:'+file).decode().splitlines()
dels=[(n,old.index(l)+1,l) for n,l in enumerate(old,1) if old.index(l)<n-1]
assert {l for _,_,l in dels}=={'CHG-075,affects,REQ-'+i for i in ('002','005','008','023')} and len(dels)==4
assert rows==[l for n,l in enumerate(old,1) if n not in {v[0] for v in dels}]
dump('delta.json',dels)
actual={tuple(a):n for n,a in enumerate(csv.reader(rows[1:]),2)};assert w1<=actual.keys()
reqs=sorted(x for x in en if x.startswith('REQ-'))
edges={}
for req in reqs:
 es=[]
 for e,n in actual.items():
  a,b,c=e
  if req not in (a,c):continue
  x=c if a==req else a
  if x[:3] not in rel:continue
  assert e==edge(req,x);es.append((e,n,x))
 edges[req]=sorted(es)
dump('oracle.json',dict(declarations=decl,listed=sorted(w1),edges=edges))
def expected(q):
 ls=[]
 for req in reqs:
  selected=[(e,n,x) for e,n,x in edges[req] if q in ('',req,x)]
  if not selected and q not in ('',req):continue
  ls.append('  '.join((req,en[req],ko[req])))
  for e,n,x in selected:ls.append('  '+'  '.join((' '.join(e),file+':'+str(n),en[x],ko[x])))
 return ls
def run(root,q):
 p=subprocess.run([sys.executable,str(root/'tools/requirement_graph.py'),*([q] if q else [])],capture_output=True,text=True)
 return [p.returncode,p.stdout,p.stderr]
queries={}
for q in ['',*sorted(en)]:
 rc,stdout,stderr=queries[q]=run(r,q);assert (rc,stdout.splitlines(),stderr)==(0,expected(q),''),q
dump('queries.json',queries)
cases={}
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);shutil.copytree(r/'docs',p/'docs');(p/'tools').mkdir();shutil.copy(r/'tools/requirement_graph.py',p/'tools');(p/'trace').mkdir()
 csvp=p/file;clean='\n'.join(rows)+'\n';csvp.write_text(clean,encoding='utf8')
 def probe(name,path,content,rc,*phrases):
  before=path.read_bytes();path.write_text(content,encoding='utf8')
  try:
   got=cases[name]=run(p,'VER-011');assert got[0]==rc and all(t in got[2] for t in phrases) and got[1]==queries['VER-011'][1],(name,got)
  finally:path.write_bytes(before)
 for kind in rel:
  e=edge('REQ-001',kind+'-001');a,b,c=e
  for label,bad in [('reverse',(c,b,a)),('relation',(a,'affects',c))]:
   probe(kind+' '+label,csvp,clean+','.join(bad)+'\n',1,f'{file}:{len(rows)+1}',' '.join(bad),'expected '+' '.join(e))
 probe('REQ pair',csvp,clean+'REQ-001,derives,REQ-002\n',1,'no REQ-to-REQ allocation')
 for e in ['CHG-998,affects,REQ-001','VER-001,has-partial-evidence,EVD-998','OBJ-008,derives,HAZ-001','OBJ-008,derives,THR-001','OBJ-008,derives,ASM-001']:
  assert e not in rows;probe(e,csvp,clean+e+'\n',0)
 for kind in ['upstream','DES','VER']:
  remove={','.join(e) for e,n,x in edges['REQ-001'] if (x[:3] if x[:3] in ('DES','VER') else 'upstream')==kind}
  probe('orphan '+kind,csvp,'\n'.join('CHG-998,affects,EVD-'+str(i) if l in remove else l for i,l in enumerate(rows))+'\n',1,'REQ-001 missing '+kind+' coverage')
 for suff in decl:
  path=p/('docs/requirements'+suff);t=path.read_text(encoding='utf8');line=next(l for l in t.splitlines() if l.startswith('| `REQ-001`'))
  probe('missing '+suff,path,t.replace(line,''),1,'edition mismatch REQ-001')
  probe('allocation '+suff,path,t.replace(line,line.replace('HAZ-002','HAZ-001')),1,'REQ-001 edition allocation mismatch','missing declared edge HAZ-001 derives REQ-001')
 for name,l,msg in [('undefined','CHG-998,affects,DES-999','undefined endpoint DES-999'),('malformed','HAZ-001,derives,REQ-001,unexpected','malformed CSV'),('duplicate',rows[1],'duplicate edge')]:
  probe(name,csvp,clean+l+'\n',1,msg)
 csvp.write_text('\n'.join(old)+'\n',encoding='utf8');archive=run(p,'');assert archive[0]==1 and archive[2].count('duplicate edge')==4
 with zipfile.ZipFile(r/'docs/evidence/requirement-graph-first.zip') as z:
  archived=json.loads(z.read('queries.json'))[''];assert archive==[archived[k] for k in ('rc','stdout','stderr')]
  dump('archived-replay.json',archive)
dump('controls.json',cases)
print(len(en),len(reqs),len(w1),sum(map(len,edges.values())),len(queries),len(cases),dels)

