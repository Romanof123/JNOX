set -eu
out=/mnt/d/codex/.jnox-work/next-fixed/integration215-record
r=$(mktemp -d "$HOME/int215.XXXXXX")
echo "$r" > "$out/root.txt"
mkdir "$r/src" "$r/ev"
tar xf "$out/source.tar" -C "$r/src"
export PATH="$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH" CARGO_HOME="$HOME/jnox-169-first-e203caa/cargo" CARGO_BUILD_JOBS=1 JNOX_BOARD=virt
cd "$r/src/kernel"
for spec in 'telemetry batch batch-sjf telemetry' 'recurring groups ordinary-groups-recurring none' 'legacy-batch batch batch-sjf none' 'legacy-groups groups ordinary-groups none' 'reject groups ordinary-groups-recurring telemetry'; do
 set -- $spec
 d="$r/ev/$1"
 mkdir "$d"
 export CARGO_TARGET_DIR="$r/b-$1" JNOX_PROFILE="$2" JNOX_APP="$3"
 unset JNOX_BATCH_WORKLOAD
 if [ "$4" = telemetry ]; then export JNOX_BATCH_WORKLOAD=telemetry; fi
 if cargo build --release --locked > "$d/build" 2>&1; then rc=0; else rc=$?; fi
 echo "$rc" > "$d/build.exit"
 if [ "$rc" = 0 ] && [ "$1" != reject ]; then
 cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" "$d/kernel.elf"
 (cd "$d"; rc=0; timeout 4s qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -accel tcg -smp 1 -m 128M -nographic -nic none -monitor none -serial file:uart.log -d int -D irq.log -kernel kernel.elf >host 2>&1 || rc=$?; echo "$rc" > exit)
 fi
 cp -r "$d" "$out/"
done
