"""Capture the fixed public GitHub namespace, retaining source-page hashes and read times."""
import datetime
import hashlib
import json
import re
import urllib.request
from pathlib import Path

ROOT = 'https://api.github.com/repos/Romanof123/JNOX'
CUTOFF = 274


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')


def collect():
    pages = []
    def fetch(url):
        request = urllib.request.Request(url, headers={'User-Agent': 'JNOX-PM-records'})
        with urllib.request.urlopen(request, timeout=60) as response:
            raw = response.read()
            pages.append(dict(url=url, read_at=now(), sha256=hashlib.sha256(raw).hexdigest()))
            return json.loads(raw)

    def inventory(kind):
        rows = []
        page = 1
        while True:
            data = fetch(f'{ROOT}/{kind}?state=all&sort=created&direction=asc&per_page=100&page={page}')
            rows.extend(row for row in data if row['number'] <= CUTOFF)
            if len(data) < 100 or any(row['number'] > CUTOFF for row in data):
                return rows
            page += 1

    started = now()
    main = fetch(f'{ROOT}/commits/main')['sha']
    issues = inventory('issues')
    pulls = {p['number']: p for p in inventory('pulls')}
    rows = []
    for issue in issues:
        n = issue['number']
        body = issue['body'] or ''
        row = {k: issue[k] for k in ('number', 'title', 'html_url', 'state', 'updated_at', 'closed_at')}
        row.update(teams=[x['name'] for x in issue['labels'] if x['name'].startswith('team:')],
                   refs=sorted({int(m) for m in re.findall(r'(?:#|https://github\.com/Romanof123/JNOX/(?:pull|issues)/)(\d+)\b', body)}))
        if n >= 266:
            row['body'] = body
        if 'pull_request' in issue:
            p = pulls[n]
            assert p['state'] == row['state']
            row.update(head=p['head']['sha'], merged_at=p['merged_at'],
                       merge=p['merge_commit_sha'] if p['merged_at'] else None)
        rows.append(row)
    # Check an independent open-only request and re-read the main tip to catch a changing freeze.
    opened = fetch(f'{ROOT}/issues?state=open&per_page=100')
    assert len(opened) < 100
    open_inventory = {x['number']: x['updated_at'] for x in opened if x['number'] <= CUTOFF}
    assert open_inventory == {x['number']: x['updated_at'] for x in rows if x['state']=='open'}
    assert main == fetch(f'{ROOT}/commits/main')['sha']
    return dict(started=started, ended=now(), main=main, pages=pages, open_check=open_inventory, rows=rows)


if __name__ == '__main__':
    Path('input.json').write_text(json.dumps(collect(), ensure_ascii=False, indent=1), encoding='utf-8')
