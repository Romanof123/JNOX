# Open work and document handoffs / 열린 작업과 문서 인계

2026-11-25 05:32:16 KST (2026-11-24 20:32:16 UTC). PM followed the open GitHub issues endpoint through its last page and reconciled 37 issues and 20 pull requests. Every item has one next-action team and a direct baseline document. All 20 PRs and their primary issues reference each other in body prose. The nominated primary is recorded below.

The check resolved all 185 distinct explicit GitHub blob locations with a main or hexadecimal revision to a Git object, pinning main to [8609aab7](https://github.com/Romanof123/JNOX/commit/8609aab7eeb509b7aa032fcf6cafe124770ab751). The attached index maps each item and commit/path to its blob. Document existence and ticket ownership are administrative findings. Safety authority, product approvals and test verdicts are recorded on their own evidence paths.

열린 이슈 37건과 PR 20건의 다음 담당, 직접 문서 링크, PR과 주 이슈의 양방향 참조를 점검했다. 공개 저장소의 고정 리비전 또는 main을 가리킨 서로 다른 문서 위치 185개에서 실제 파일을 확인했다. 아래 표와 원본의 시점 이후 진행 사항은 [PM 이슈](https://github.com/Romanof123/JNOX/issues/6)에서 확인할 수 있다.

## Findings and disposition / 발견 사항과 조치

- [#162](https://github.com/Romanof123/JNOX/issues/162) now links the decision worksheet, time, storage and window plans in both languages. The product owner and safety authority still own the outstanding choices. 시각·저장·화면의 제품 결정 항목을 양 언어 기획에 연결했다.
- [#126](https://github.com/Romanof123/JNOX/pull/126), [#133](https://github.com/Romanof123/JNOX/pull/133), [#135](https://github.com/Romanof123/JNOX/pull/135), [#138](https://github.com/Romanof123/JNOX/pull/138), [#153](https://github.com/Romanof123/JNOX/pull/153) now link the scoped design or evidence pinned to their own heads. The change supplies five missing direct handoffs. 각 PR의 기존 판정을 유지하고 해당 소스의 설계·근거 문서로 연결했다.
- [#248](https://github.com/Romanof123/JNOX/issues/248) / [#252](https://github.com/Romanof123/JNOX/pull/252) carries the first independent EDF/LLF failure through [#254](https://github.com/Romanof123/JNOX/issues/254). [#250](https://github.com/Romanof123/JNOX/issues/250) / [#253](https://github.com/Romanof123/JNOX/pull/253) carries the cooperative counter regression through [#255](https://github.com/Romanof123/JNOX/issues/255). [#249](https://github.com/Romanof123/JNOX/issues/249) / [#251](https://github.com/Romanof123/JNOX/pull/251) is held against its 1 ms criterion. 최초 근거와 수정 후보를 구분해 보관한다.
- [#21](https://github.com/Romanof123/JNOX/issues/21) records 0/18 scheduling families at release. [#24](https://github.com/Romanof123/JNOX/issues/24) records 0/10 IPC families. Item/workload, safe state and deadline authority, and physical board evidence are open in [#1](https://github.com/Romanof123/JNOX/issues/1), [#10](https://github.com/Romanof123/JNOX/issues/10) and [#34](https://github.com/Romanof123/JNOX/issues/34).

| Item / 작업 | Primary issue / 주 이슈 | Next owner / 다음 담당 | Pinned or main document locations / 문서 위치 수 |
| --- | --- | --- | --- |
| [#1](https://github.com/Romanof123/JNOX/issues/1) | · | team:systems | 8 |
| [#2](https://github.com/Romanof123/JNOX/issues/2) | · | team:systems | 4 |
| [#3](https://github.com/Romanof123/JNOX/issues/3) | · | team:integration | 2 |
| [#5](https://github.com/Romanof123/JNOX/issues/5) | · | team:systems | 2 |
| [#6](https://github.com/Romanof123/JNOX/issues/6) | · | team:pm | 37 |
| [#7](https://github.com/Romanof123/JNOX/issues/7) | · | team:systems | 2 |
| [#8](https://github.com/Romanof123/JNOX/issues/8) | · | team:systems | 4 |
| [#9](https://github.com/Romanof123/JNOX/issues/9) | · | team:verification | 2 |
| [#10](https://github.com/Romanof123/JNOX/issues/10) | · | team:functional-safety | 1 |
| [#11](https://github.com/Romanof123/JNOX/issues/11) | · | team:systems | 2 |
| [#12](https://github.com/Romanof123/JNOX/issues/12) | · | team:integration | 7 |
| [#21](https://github.com/Romanof123/JNOX/issues/21) | · | team:integration | 86 |
| [#24](https://github.com/Romanof123/JNOX/issues/24) | · | team:pm | 2 |
| [#34](https://github.com/Romanof123/JNOX/issues/34) | · | team:integration | 8 |
| [#41](https://github.com/Romanof123/JNOX/issues/41) | · | team:verification | 2 |
| [#47](https://github.com/Romanof123/JNOX/issues/47) | · | team:development | 15 |
| [#49](https://github.com/Romanof123/JNOX/issues/49) | · | team:systems | 9 |
| [#79](https://github.com/Romanof123/JNOX/issues/79) | · | team:functional-safety | 3 |
| [#94](https://github.com/Romanof123/JNOX/issues/94) | · | team:development | 2 |
| [#99](https://github.com/Romanof123/JNOX/issues/99) | · | team:development | 5 |
| [#101](https://github.com/Romanof123/JNOX/issues/101) | · | team:systems | 2 |
| [#110](https://github.com/Romanof123/JNOX/issues/110) | · | team:functional-safety | 4 |
| [#123](https://github.com/Romanof123/JNOX/issues/123) | · | team:development | 8 |
| [#126](https://github.com/Romanof123/JNOX/pull/126) | [#123](https://github.com/Romanof123/JNOX/issues/123) | team:integration | 3 |
| [#133](https://github.com/Romanof123/JNOX/pull/133) | [#99](https://github.com/Romanof123/JNOX/issues/99) | team:integration | 3 |
| [#135](https://github.com/Romanof123/JNOX/pull/135) | [#99](https://github.com/Romanof123/JNOX/issues/99) | team:systems | 3 |
| [#137](https://github.com/Romanof123/JNOX/issues/137) | · | team:systems | 2 |
| [#138](https://github.com/Romanof123/JNOX/pull/138) | [#123](https://github.com/Romanof123/JNOX/issues/123) | team:integration | 3 |
| [#153](https://github.com/Romanof123/JNOX/pull/153) | [#123](https://github.com/Romanof123/JNOX/issues/123) | team:integration | 3 |
| [#162](https://github.com/Romanof123/JNOX/issues/162) | · | team:systems | 8 |
| [#172](https://github.com/Romanof123/JNOX/pull/172) | [#123](https://github.com/Romanof123/JNOX/issues/123) | team:integration | 7 |
| [#177](https://github.com/Romanof123/JNOX/issues/177) | · | team:development | 8 |
| [#178](https://github.com/Romanof123/JNOX/pull/178) | [#177](https://github.com/Romanof123/JNOX/issues/177) | team:development | 9 |
| [#184](https://github.com/Romanof123/JNOX/issues/184) | · | team:development | 10 |
| [#192](https://github.com/Romanof123/JNOX/pull/192) | [#123](https://github.com/Romanof123/JNOX/issues/123) | team:development | 4 |
| [#201](https://github.com/Romanof123/JNOX/pull/201) | [#123](https://github.com/Romanof123/JNOX/issues/123) | team:development | 3 |
| [#204](https://github.com/Romanof123/JNOX/pull/204) | [#47](https://github.com/Romanof123/JNOX/issues/47) | team:development | 3 |
| [#207](https://github.com/Romanof123/JNOX/pull/207) | [#49](https://github.com/Romanof123/JNOX/issues/49) | team:development | 1 |
| [#213](https://github.com/Romanof123/JNOX/pull/213) | [#94](https://github.com/Romanof123/JNOX/issues/94) | team:development | 1 |
| [#216](https://github.com/Romanof123/JNOX/issues/216) | · | team:systems | 16 |
| [#217](https://github.com/Romanof123/JNOX/issues/217) | · | team:systems | 1 |
| [#218](https://github.com/Romanof123/JNOX/pull/218) | [#217](https://github.com/Romanof123/JNOX/issues/217) | team:systems | 1 |
| [#219](https://github.com/Romanof123/JNOX/pull/219) | [#216](https://github.com/Romanof123/JNOX/issues/216) | team:systems | 8 |
| [#230](https://github.com/Romanof123/JNOX/issues/230) | · | team:systems | 2 |
| [#231](https://github.com/Romanof123/JNOX/pull/231) | [#230](https://github.com/Romanof123/JNOX/issues/230) | team:systems | 2 |
| [#232](https://github.com/Romanof123/JNOX/issues/232) | · | team:systems | 7 |
| [#233](https://github.com/Romanof123/JNOX/issues/233) | · | team:systems | 5 |
| [#236](https://github.com/Romanof123/JNOX/pull/236) | [#232](https://github.com/Romanof123/JNOX/issues/232) | team:systems | 4 |
| [#238](https://github.com/Romanof123/JNOX/pull/238) | [#233](https://github.com/Romanof123/JNOX/issues/233) | team:systems | 5 |
| [#248](https://github.com/Romanof123/JNOX/issues/248) | · | team:verification | 5 |
| [#249](https://github.com/Romanof123/JNOX/issues/249) | · | team:systems | 3 |
| [#250](https://github.com/Romanof123/JNOX/issues/250) | · | team:verification | 4 |
| [#251](https://github.com/Romanof123/JNOX/pull/251) | [#249](https://github.com/Romanof123/JNOX/issues/249) | team:systems | 3 |
| [#252](https://github.com/Romanof123/JNOX/pull/252) | [#248](https://github.com/Romanof123/JNOX/issues/248) | team:verification | 4 |
| [#253](https://github.com/Romanof123/JNOX/pull/253) | [#250](https://github.com/Romanof123/JNOX/issues/250) | team:verification | 3 |
| [#254](https://github.com/Romanof123/JNOX/issues/254) | · | team:verification | 3 |
| [#255](https://github.com/Romanof123/JNOX/issues/255) | · | team:verification | 2 |

## Reproduction / 재현

[Original REST inventory, checker output and immutable object index](pm-tracking-20261124T203216Z.zip). Extract and run the repository command below from the stated main baseline. 조회 시점의 공개 API 원본, 검사 출력과 문서별 Git 객체를 동봉했다.

```sh
python tools/open_tracking.py open-inventory.json
```

Inventory SHA-256 `bc763639ed1228b113bfdff463b22e5dc47acf37bb63d1163a5a6d137c61d8dc`. Archive SHA-256 `0b722afeb433e57f605c72ded6cb14ec01fc5a6d6b9a6c4c1b670ad9709cb9f3`.
