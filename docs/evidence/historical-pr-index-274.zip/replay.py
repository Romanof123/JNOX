# coding: utf-8
"""Replay the fixed-cutoff public records and regenerate the bilingual report offline."""
import hashlib
import json
import re
from pathlib import Path

ROOT = 'https://github.com/Romanof123/JNOX'
NAME = 'historical-pr-index-274.en-ko.md'
D = json.loads(Path('input.json').read_text(encoding='utf-8'))
rows = {r['number']: r for r in D['rows']}
assert len(rows) == len(D['rows']) == 274 and set(rows) == set(range(1,275))
open_rows = [r for r in rows.values() if r['state'] == 'open']
assert {str(r['number']):r['updated_at'] for r in open_rows} == D['open_check']
old = Path('owners.md').read_text(encoding='utf-8')
primary = {int(n):int(i) for n,i in re.findall(r'/pull/(\d+)\) \| \[#(\d+)\]', old)}
primary.update({258:257,265:264,267:266,270:269,271:268,274:273})
neighbors = {266:[267],267:[266],268:[271,272],269:[270],270:[269],271:[268,272],272:[268,271],273:[274],274:[273]}
for n, links in neighbors.items():
    for i in links:
        assert i in rows[n]['refs'] and n in rows[i]['refs']
for r in open_rows:
    assert len(r['teams']) == 1
    if 'head' in r:
        n = r['number']
        i = primary[n]
        assert i in r['refs'] and n in rows[i]['refs']
prs = [r for r in rows.values() if 'head' in r]
assert all(bool(p['merged_at']) == bool(p['merge']) for p in prs)
assert all(rows[n]['state']=='closed' for n in range(266,275)) and rows[274]['merge']
previous = Path('previous.md').read_text(encoding='utf-8')
assert all(f'#{n}' in previous for n in [73,92,98,155,168])

def link(n):
    return f"[#{n}]({rows[n]['html_url']})"

def doc(sha,path,label):
    return f'[{label}]({ROOT}/blob/{sha}/docs/{path})'

def commit(sha):
    return f'[{sha[:10]}]({ROOT}/commit/{sha})'

def evidence(pr,path,label):
    return doc(rows[pr]['merge'],'evidence/'+path,label)

base = evidence(267,'historical-pr-index-265.en-ko.md','Historical index / 과거 색인')
first = evidence(271,'sched-app-trace-joint-first.en-ko.md','First cohort / 최초 35개 구성')
fix = commit('0174fe3b67a26f75e5c44a02a992d28297707219')
typed = evidence(271,'sched-app-trace-typed-first.en-ko.md','Typed replay / 형식 검증')
halt = evidence(271,'sched-app-trace-halt-corrected.en-ko.md','Post-stop evidence / 정지 확인')
amend = doc('7f27c12294ac5bf6c76cc254a494861e1c4ed96e','scheduling-app-trace-v1.en-ko.md','Prospective correction / 사전 수정안')
scope = {
267: '160 PRs, 105 issues, 491 pairs reproduced / PR 160건·이슈 105건·관계 491건 재현. '+base,
270: 'Two seeded 48-grant admissions, 25 windows each, one prelaunch refusal / 두 시드의 48회 배정·각 25개 창과 기동 전 거부 1건. '+evidence(270,'lottery-window-first.en-ko.md','First runs / 최초 실행'),
271: '35 configurations, 24 distinct trace sessions across three cohorts / 35개 구성·세 차수 추적 세션 24건. '+first+' · '+halt+' · '+typed,
274: '12 first positions, 24 rebuilt controls, two distinct service results and two restores per normal run / 최초 12개·기존 대조 24개·정상 실행별 서비스 결과 및 복원 각 2회. '+evidence(274,'deadline-recurring-first.en-ko.md','Independent runs / 독립 실행')}
plan = {
267: doc('eb3d00e4d70738ba37099275575a94bceb03b04b','lifecycle.en.md','Lifecycle / 추적 절차'),
270: doc('6636241ba7186e3fdd7fc38fb5075abbc5b829ae','lottery-window-plan.en-ko.md','Plan / 설계'),
271: doc('c550ec7ddd3425830203e6ee3e1fd9a4c33968e0','scheduling-app-trace-v1.en-ko.md','Plan / 설계'),
274: doc('74276211dcb87792a07f49f31d944048d74cd2fe','deadline-recurring-plan.en-ko.md','Plan / 설계')}
source = {267:'ffa2ad2e631defabb2372609943fa7c3bc32781e',270:'602b1896286b9eb25b956ca1d658732441e1b719',271:'33d8fbfedededb5147d5de93bef044822810c846',274:'4ecce4b0f3afdd1a676bcffb81fae33acf4b1d6d'}
issue_scope={266:267,268:271,269:270,272:271,273:274}
oi=sum('head' not in r for r in open_rows)
op=len(open_rows)-oi
m=sum(bool(p['merge']) for p in prs)
latest=max(r['updated_at'] for r in rows.values())
out=['# Public work register through #274 / #274까지의 공개 작업 색인','',
f"Read in UTC / UTC 조회 {D['started']} – {D['ended']}. Main / 본선 {commit(D['main'])}. Latest item update / 최신 항목 변경 {latest}.",
'',f"{len(rows)-len(prs)} issues / 이슈 ({oi} open / 열림), {len(prs)} PRs ({m} merged / 병합, {len(prs)-m-op} closed unmerged / 미병합 종료, {op} open / 열림).",
'',base+' covers every item through #265. The originating issue remains unknown for '+', '.join(link(n) for n in (73,92,98,155,168))+'. / #265까지의 개별 이력과 근거는 선행 색인에 있다. 위 다섯 PR의 최초 이슈는 미확정이다.',
'',f"The former open pair {link(264)} / {link(265)} closed with merge {commit(rows[265]['merge'])}. The subsequent publication PR belongs to {link(6)} outside this fixed cutoff. / 선행 색인의 열린 #264와 #265는 병합 후 종결됐다. 이번 기록을 게시하는 후속 PR의 주 이슈는 #6이며 집계는 #274에서 마감한다.",
'','## New records / 추가 기록','','Source shows the measured input or reviewed records commit. Merge links identify the actual accepted result. / 소스는 측정 입력 또는 검토 문서 커밋이며 병합 링크는 실제 본선 결과다.','','| Item / 작업 | Disposition / 상태 | Reciprocal records / 상호 참조 | Plan, source, verified scope / 설계·소스·검증 범위 |','|---|---|---|---|']
for n in range(266,275):
    r=rows[n]
    pr=issue_scope.get(n,n)
    status='Merged / 병합 '+commit(r['merge']) if 'head' in r else 'Closed / 종료'
    detail=plan[pr]+' · '+commit(source[pr])+' · '+scope[pr]
    if n==272:
        detail='Missing post-stop status / 정지 후 상태 누락. '+amend+' · '+fix+' · '+halt+' · '+typed
    related = [('Primary / 주 ' if primary.get(n)==i else '')+link(i) for i in neighbors[n]]
    out.append(f"| {link(n)} {r['title']} | {status} | {', '.join(related)} | {detail} |")
out+=['','## Trace from a requirement or an issue / 요구사항·이슈에서 판정까지','',
f"Start with REQ-009 in {link(268)} or its {plan[271]}. Follow {link(271)} to the {first}. All eight public decodes rejected the missing post-stop status. {link(272)} records the {amend} and {fix}. The {halt} and {typed} preserve the fresh independent runs alongside the original failures. The finite CPU0 trusted workload closed. Broader tracing stays open in {link(137)} and the scheduling release decision is held in {link(21)}.",
'',f"REQ-009 또는 {link(268)}의 고정 설계에서 {link(271)}의 최초 독립 보고서로 이동한다. 8개 실행 모두 정지 후 상태 기록 누락으로 공개 복호화가 거부됐다. {link(272)}의 사전 수정안과 수정 커밋을 거쳐 실제 정지 응답 및 새 형식의 독립 재생 자료를 확인한다. CPU0의 한정된 작업만 종결됐고 전체 추적 계약은 {link(137)}, 스케줄링 제품 승인 판단은 {link(21)}에 남아 있다.",
'','## Open assignments / 열린 작업 담당','',f'{oi} issues and {op} PRs / 이슈 {oi}건·PR {op}건. Each team comes from the single current team label. PR primaries are from the historical inventory and reciprocal bodies. / 현행 팀 라벨 하나를 다음 담당으로 표시하고 PR 주 이슈는 고정 이력과 양측 본문에서 대조했다.',
'','| Open item / 열린 작업 | Next action / 다음 담당 | PR primary / 주 이슈 |','|---|---|---|']
for r in open_rows:
    n=r['number']
    out.append(f"| {link(n)} {r['title']} | {r['teams'][0]} | {link(primary[n]) if 'head' in r else '·'} |")
out+=['','[Offline records and replay / 오프라인 자료와 재현](historical-pr-index-274.zip). Extract and run `python replay.py` to reproduce this report with Python 3 and the standard library. The source-page URLs, read times and SHA-256 digests are in input.json. This is a PM records audit. / 압축을 풀고 위 명령을 실행하면 정규화한 공개 입력에서 보고서를 재생한다. 수집 주소·조회 시각·해시는 input.json에 있다. 기술 판정은 링크한 독립 보고서에서 확인한다.']
Path(NAME).write_bytes(('\n'.join(out)+'\n').encode('utf-8'))
print(f'{len(rows)} items, {len(prs)} PRs, {m} merged, {oi} open issues, {op} open PRs')
