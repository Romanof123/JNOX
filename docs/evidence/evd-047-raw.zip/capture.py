from pathlib import Path
import json,subprocess as s,time,hashlib,tempfile,shutil,re
root=Path('/mnt/d/codex/.jnox-work/next-fixed')
dest=root/'partition-select-fresh'
tmp=Path(tempfile.mkdtemp(prefix='jnox-selector-'))
print(tmp,flush=True)
for issue,case in [('104','ordinary-partition-p'),('104','ordinary-partition-q'),('112','partition-bench'),('112','partition-legacy-diag'),('112','partition-legacy-diag-negative')]:
 name=issue+'-'+case; d=tmp/name;d.mkdir()
 b=root/'selector-integration-builds'/issue;i=json.loads((b/'index.json').read_text());row=i['images'][case];elf=d/'kernel.elf';shutil.copyfile(b/row['path'],elf);assert hashlib.sha256(elf.read_bytes()).hexdigest()==row['sha256']
 cmd=['/usr/bin/qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-nic','none','-display','none','-monitor','none','-serial','file:'+str(d/'uart'),'-d','int','-D',str(d/'exceptions.log'),'-no-reboot','-kernel',str(elf)]
 with (d/'stderr').open('wb') as err,(d/'stdout').open('wb') as out:
  start=time.monotonic();p=s.Popen(cmd,stderr=err,stdout=out,cwd=d);done=False
  while time.monotonic()-start<12 and p.poll() is None:
   if (d/'uart').exists() and re.search(rb'(?:OP STOP [^\n]+|PART (?:PASS|FAIL))\r?\n$',(d/'uart').read_bytes()):done=True;break
   time.sleep(.03)
  stable=(d/'uart').read_bytes();time.sleep(.15);unchanged=stable==(d/'uart').read_bytes()
  if p.poll() is None:p.terminate()
  rc=p.wait()
 (d/'execution.json').write_text(json.dumps(dict(cmd=cmd,terminal=done,uart_stable=unchanged,rc=rc,seconds=time.monotonic()-start,elf_sha256=row['sha256'],source=i['source'],version=s.check_output([cmd[0],'--version']).decode()),indent=2))
 (d/'disassembly').write_bytes(s.check_output(['aarch64-linux-gnu-objdump','-d',elf]))
 shutil.copytree(d,dest/name)
 print(name,done,stable.splitlines()[-1:],flush=True)
