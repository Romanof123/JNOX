from pathlib import Path
import hashlib,subprocess as s,json,re,shutil
o=Path(__file__).resolve().parent;r=o.parent;out=o/'replays';src=r/'partition-select-src/tools'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
summary={'guest':{},'legacy':{},'synthetic':{},'original_verdicts':json.loads((r/'partition-fresh/summary.json').read_text()),'live_delay':'No guest selector. Controlled near and long are synthetic only.'}
for table in 'PQ':
 for label in ['first','prior']:
  j=json.loads((out/(label+table+'.stdout')).read_text());edges=j['edges'];metrics={k:v for k,v in j.items() if k not in ('edges','intervals')};metrics.update(edges=len(edges),elapsed_ticks=sum(j['ticks'].values()),max_latency_ticks=max(x['latency'] for x in edges),first_excess=next((x for x in edges if not x['within_bound']),None),over=sum(not x['within_bound'] for x in edges));assert metrics['elapsed_ticks']==j['intervals'][-1]['end']-j['epoch'];summary['guest'][label+table]=metrics
 for kind in ['healthy','near','long']:
  name='current-'+table+'-'+kind;f=out/(name+'.uart');f.write_bytes(s.check_output(['python3',src/'test_ordinary_partition_account.py','--emit',table,kind]));p=s.run(['python3',src/'ordinary_partition_account.py',f,'--table',table,'--case',kind,'--origin','synthetic'],capture_output=True);assert p.returncode==0;(out/(name+'.json')).write_bytes(p.stdout);j=json.loads(p.stdout);summary['synthetic'][name]={k:j[k] for k in ('timing_envelope_met','first_a_close','missed','measured_service_loss_ticks')}
p=s.run(['python3',src/'test_ordinary_partition_account.py'],capture_output=True);(out/'current-suite.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
for case in ['partition-bench','partition-legacy-diag','partition-legacy-diag-negative']:
 d=o/('112-'+case);elf=d/'kernel.elf';same=elf.read_bytes()==(r/'legacy-diag-builds'/case/'kernel.elf').read_bytes();assert same
 uart=(d/'uart').read_text().splitlines();events=(d/'exceptions.log').read_text();assert json.loads((d/'execution.json').read_text())['uart_stable'];nm=s.check_output(['aarch64-linux-gnu-nm',elf],text=True);diag='partition_diag_stop' in nm
 assert diag==(case!='partition-bench')
 irq=events.count('Taking exception 5 [IRQ]');returns=events.count('Exception return from AArch64 EL1 to AArch64 EL1');target='...to EL1 PC 0x40200a80'
 assert events.count('Taking exception')==irq==events.count(target)
 rec=[line for line in uart if line.startswith('PART DIAG1 ')]
 if case.endswith('negative'):
  assert irq==0 and returns==1 and len(rec)==1 and uart[-1]=='PART FAIL'
  fields=[int(v,16) for v in rec[0].split()[2:]];assert fields[:7]==[99,0,1,2**64-1,0,0,2] and fields[7]>0 and fields[8]==0
 else:
  assert irq==returns==6 and not rec and uart==['JNOX M1 BOOT','JNOX M1 READY','PART A FIRST','PART IDLE FIRST','PART B READY','PART A RESUMED','PART B FIRST','PART IDLE RESUMED','PART STOP','PART PASS'];fields=None
 ref=r/'partition-builds/partition-bench/kernel.elf'
 def section(p):return s.check_output(['aarch64-linux-gnu-objcopy','--dump-section','.text=/dev/stdout',p,'/dev/null'])
 text_hash=hashlib.sha256(section(elf)).hexdigest();orig_text_hash=hashlib.sha256(section(ref)).hexdigest()
 summary['legacy'][case]=dict(uart=uart,elf_matches_preselector=True,elf_sha256=sha(elf),text_sha256=text_hash,original_legacy_text_sha256=orig_text_hash,original_legacy_text_identical=text_hash==orig_text_hash,diag_stop_symbol=diag,irq_count=irq,return_count=returns,irq_vector='0x40200a80',ppi_identity='PPI 30 checked by runtime guard 28 on all six IRQs; QEMU trace records IRQ exception class and vector only.' if irq else 'Negative terminates at first worker marker before IRQ.',first_failure=fields,stable_after_terminal=True)
summary['previous_fixture_compatibility']='Six older emitted synthetic streams are rejected (legacy accumulator/initial frame format). Current six emitted streams pass. Old bad first-PC input already fails on its invalid accumulator; fresh aligned one-word PC mutation isolates PC check.'
summary['run_id']='Wire format has no run ID; expected table, generation, ELF digest and independent IRQ/return sequence are checked.'
save(o/'summary.json',summary)
shutil.copyfile(r/'partition-fresh/summary.json',o/'original-summary.json')
for issue in ['104','112']:shutil.copyfile(r/'selector-integration-builds'/issue/'index.json',o/('build-'+issue+'.json'))
(o/'manifest.sha256').write_text(''.join(sha(f)+'  '+f.relative_to(o).as_posix()+'\n' for f in sorted(o.rglob('*')) if f.is_file() and f.name!='manifest.sha256'))
