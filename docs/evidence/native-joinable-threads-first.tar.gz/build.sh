set -eux
cd ~/jnox314-3d53da8/src
D=$HOME/jnox314-3d53da8/evidence
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
git rev-parse HEAD > "$D/revision"
python3 tools/build_native_el0.py --out "$D/c" --threads 2 --source examples/native-threads/sensor.c
sh sdk/native-aarch64/build-rust.sh examples/native-threads-rust/Cargo.toml "$D/energy.elf"
python3 tools/build_native_el0.py --out "$D/rust" --threads 2 --elf "$D/energy.elf"
find "$D" -name '*.elf' -exec sha256sum {} + > "$D/hashes"
git ls-files sdk/native-aarch64 examples/native-threads examples/native-threads-rust | xargs sha256sum > "$D/source-hashes"
find "$D" -name '*.elf' -exec sh -c 'for f do aarch64-linux-gnu-nm -nS "$f" > "$f.sym"; done' sh {} +

