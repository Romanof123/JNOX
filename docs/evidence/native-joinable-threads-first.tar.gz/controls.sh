set -eu
cd ~/jnox314-3d53da8/src
D=$HOME/jnox314-3d53da8/evidence
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
sh sdk/native-aarch64/build.sh "$D/control.c" "$D/control.elf"
for mode in z s u n m e o; do
 extra=(--threads 2); if test "$mode" = o; then extra=(); fi
 python3 tools/build_native_el0.py --out "$D/$mode" "${extra[@]}" --elf "$D/control.elf" --arg "$mode"
done
cp ~/jnox312-424a/packet/elf/batch.elf "$D/old-batch.elf"
python3 tools/build_native_el0.py --out "$D/old" --elf "$D/old-batch.elf" --arg=--blocks --arg 1
python3 tools/build_native_el0.py --out "$D/probe"
python3 "$D/capture.py" "$D" z-plain s-plain u-plain n-plain m-plain e-plain old-plain o-plain probe-plain

