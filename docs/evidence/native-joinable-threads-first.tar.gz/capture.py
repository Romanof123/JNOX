import pathlib,sys,time,subprocess as sp,json,re
D=pathlib.Path(sys.argv[1]).resolve()
for case in sys.argv[2:]:
 name,mode=case.rsplit('-',1)
 k=D/name/'kernel.elf'
 r=D/'runs'/case;r.mkdir(parents=True)
 symbols=sp.check_output(['aarch64-linux-gnu-nm','-nS',str(k)],text=True)
 base=next((int(l.split()[0],16) for l in symbols.splitlines() if '6SPACES' in l),None)
 args=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-no-reboot','-qmp','stdio','-serial','file:'+str(r/'uart.log')]
 if mode=='traced':args+=['-d','int','-trace','enable=gic_acknowledge_irq','-D',str(r/'exceptions.log')]
 args+=['-kernel',str(k)]
 (r/'command.json').write_text(json.dumps(args))
 with (r/'stderr').open('w') as err,sp.Popen(args,stdin=sp.PIPE,stdout=sp.PIPE,text=True,stderr=err) as p:
  def read():
   while True:
    x=json.loads(p.stdout.readline())
    if 'event' not in x:return x
  def cmd(command,**kw):
   p.stdin.write(json.dumps(dict(execute=command,arguments=kw))+'\n');p.stdin.flush()
   x=read();assert 'return' in x,x;return x['return']
  try:
   read();cmd('qmp_capabilities');start=time.monotonic()
   while time.monotonic()-start<12:
    uart=(r/'uart.log').read_bytes()
    if re.search(rb'NATIVE EL0 (?:EXIT -?\d+|FAIL[^\r\n]*|FAULT[^\r\n]*)\r?\n',uart):break
    time.sleep(.02)
   cmd('stop')
   if base is not None:cmd('pmemsave',val=base,size=0x415000,filename=str(r/'space.raw'))
   (r/'registers').write_text(cmd('human-monitor-command',**{'command-line':'info registers'}))
   cmd('quit');p.wait(5)
  finally:
   if p.poll() is None:p.kill();p.wait()
 print(case,(r/'uart.log').read_text()[-160:],flush=True)

