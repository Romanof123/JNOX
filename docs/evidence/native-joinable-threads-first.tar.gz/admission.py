import os,pathlib as P, subprocess as s,hashlib,json
D=P.Path(__file__).parent
os.chdir(D.parent/'src')
target=D/'admission';target.mkdir()
elf=D/'control.elf';digest=hashlib.sha256(elf.read_bytes()).hexdigest()
cases={'count':['--threads','3','--elf',str(elf)],'duplicate':['--threads','2','--threads','2','--elf',str(elf)],'probe':['--threads','2'],'peer':['--threads','2','--elf',str(elf),'--peer-elf',str(elf)],'policy':['--threads','2','--elf',str(elf),'--policy','fifo'],'priority':['--threads','2','--elf',str(elf),'--priority','1']}
res={}
for n,args in cases.items():
 cmd=['python3','tools/build_native_el0.py','--out',str(target/n),*args]
 r=s.run(cmd,capture_output=True);(target/(n+'.log')).write_bytes(r.stderr+r.stdout);res[n]=r.returncode;assert r.returncode==2
env=dict(os.environ,JNOX_BOARD='virt',JNOX_PROFILE='native',JNOX_APP='process',JNOX_NATIVE_ELF=str(elf),JNOX_NATIVE_ELF_SHA256=digest,JNOX_NATIVE_THREADS='2',CARGO_TARGET_DIR=str(target/'target'))
for n,ov in {'count':{'JNOX_NATIVE_THREADS':'3'},'probe':{'JNOX_APP':'startup-probe'},'peer':{'JNOX_NATIVE_PEER_ELF':str(elf),'JNOX_NATIVE_PEER_ELF_SHA256':digest},'policy':{'JNOX_NATIVE_POLICY':'fifo'},'priority':{'JNOX_NATIVE_PRIORITIES':'1'}}.items():
 r=s.run(['python3','tools/build_kernel.py','--arch','aarch64'],env={**env,**ov},capture_output=True)
 (target/('raw-'+n+'.log')).write_bytes(r.stderr+r.stdout);res['raw-'+n]=r.returncode;assert r.returncode!=0
print(res)

