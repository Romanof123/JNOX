#include <pthread.h>
#include <errno.h>
#include <sched.h>
#include <stdint.h>
static pthread_t handle;
static int marker;
static _Atomic int observed;
static void *worker(void *mode) {
 if (*(char*)mode == 's') observed = pthread_join(handle, 0);
 else observed = 1;
 return &marker;
}
int main(int argc,char **argv) {
 if(argc!=2) return 90;
 char *mode=argv[1]; void *out=&marker; pthread_t other=123;
 errno=22;
 if(*mode=='u'){
  pthread_attr_t attr={0};
  if(pthread_create(0,0,worker,mode)!=EINVAL || pthread_create(&other,0,0,mode)!=EINVAL ||
     pthread_create(&other,&attr,worker,mode)!=ENOTSUP || other!=123 || errno!=22) return 91;
  return 32;
 }
 if(*mode=='o') {
  register uint64_t op __asm__("x8"); register long res __asm__("x0");
  for(int n=10;n<=12;n++){op=n;res=0;__asm__ volatile("svc #0x4a01":"+r"(res):"r"(op):"x1","memory");if(res!=-95)return 92;}
  return errno==22 ? 37:93;
 }
 if(pthread_create(&handle,0,worker,mode))return 94;
 if(*mode=='e')return 36;
 if(*mode=='m')pthread_exit(0);
 if(*mode=='z' && (pthread_create(&other,0,worker,mode)!=EAGAIN || other!=123))return 95;
 if(sched_yield())return 96;
 if(*mode=='z' && (pthread_create(&other,0,worker,mode)!=EAGAIN || other!=123))return 97;
 if(pthread_join(handle,*mode=='n'?0:&out) || errno!=22)return 98;
 if(pthread_join(handle,&out)!=ESRCH || out!=&marker)return 99;
 return *mode=='z' && observed==1 ? 30 : *mode=='s' && observed==EDEADLK ? 31 : *mode=='n' && observed==1 ? 33 : 100;
}

