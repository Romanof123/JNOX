import pathlib as P, subprocess as sp,struct,re,json
D=P.Path(__file__).parent
summary={}
for name in ('c','rust'):
 for mode in ('plain','traced'):
  r=D/'runs'/(name+'-'+mode)
  rows=[list(map(int,l.split()[3:])) for l in (r/'uart.log').read_text().splitlines() if l.startswith('NATIVE THREAD EVENT')]
  mem=(r/'space.raw').read_bytes()
  def vals(fmt,off):return struct.unpack_from('<'+fmt,mem,off)
  def app(addr):return addr-0x400000+0x5000
  root=rows[0][26]&0xfffff000
  sym=(D/name/'kernel.elf.sym').read_text()
  assert root==int(next(l.split()[0] for l in sym.splitlines() if '6SPACES' in l),16)
  def walk(va):
   page=0
   for shift in (30,21,12):
    desc=vals('Q',page+8*((va>>shift)&511))[0]
    if desc&3!=3:return None
    page=(desc&0xfffff000)-root
   return page+(va&4095)
  assert walk(0x402000)==app(0x402000)
  assert walk(0x1001000)==0x405000 and walk(0x1002000)==walk(0x1009000)==None
  for x in rows:
   assert x[26]&0xfffff000==root
   for tid,pc,sp_,errno in [(x[2],x[10],x[11],x[12]),(x[3],x[13],x[14],x[15])]:
    if pc:
     lo,hi=[(0x100a000,0x1011000),(0x1003000,0x1009000)][tid]
     assert lo<=sp_<=hi and sp_%16==0 and errno==0x1001000+4*tid
  out={'events':len(rows),'ttbr':hex(rows[0][26]),'entry_sp':[hex(rows[0][14]),hex(next(x[14] for x in rows if x[3]==1))]}
  if name=='c':
   assert vals('256I',app(0x402850))==tuple(range(256))
   for g in (1,2):
    off=app(0x402000+(g-1)*1056)
    assert vals('I',off)==(g,) and vals('256I',off+4)==tuple(i+g for i in range(256))
    assert vals('I Q ii II',off+1028)==(32640+256*g,0x1001004,0,38,4,1)
   assert vals('Q',app(0x402848))==(0x1001000,)
   assert vals('II',0x405000)==(22,38)
   assert vals('QQI',app(0x402c50))==(3,5,32640)
   assert vals('QQI',app(0x402c68))==(0x402000,0x402420,3)
   due,wake=vals('QQ',app(0x402c80));assert wake>=due
   joins=[x for x in rows if x[4]==11]
   assert [(x[5],x[19]) for x in joins]==[(3,4),(5,1),(3,1)] and joins[1][9]==0x402420
   sleeper=next(x for x in rows if x[4]==7);irq=next(x for x in rows if x[1]==3)
   assert sleeper[19:21]==[4,3] and irq[24]==sleeper[25]>sleeper[0] and irq[0]>=irq[24] and irq[3]==1
   assert next(x for x in rows if x[4]==12)[17]==0x402000
   out.update(deadline_ns=due,wake_ns=wake,compare=sleeper[25],irq=irq[0])
  else:
   assert vals('II',app(0x402000))==(32640,5559680)
   assert vals('256I',app(0x402008))==tuple(range(256)) and vals('256I',app(0x402408))==tuple(i*i for i in range(256))
   assert next(x for x in rows if x[4]==12)[17]==0x402004
  if mode=='traced':
   log=(r/'exceptions.log').read_text()
   svc=list(map(lambda s:int(s,16),re.findall(r'Taking exception 2 \[SVC\]\n\.\.\.from EL0 to EL1\n[^\n]*\n\.\.\.with ELR (0x[0-9a-f]+)',log)))
   eret=[int(s,16) for s in re.findall(r'EL1 to AArch64 EL0 PC (0x[0-9a-f]+)',log)]
   assert svc==[x[10] for x in rows if x[1]==1] and eret==[x[13] for x in rows if x[13]]
   if name=='c':assert 'gic_acknowledge_irq cpu 0 acknowledged irq 30' in log
   out.update(svc=len(svc),eret=len(eret))
  summary[r.name]=out
print(json.dumps(summary,indent=2))

