from pathlib import Path
import re,json,zlib,struct
D=Path(__file__).resolve().parent
ramp=bytes(range(256))*16
for case in (D/'cases').read_text().splitlines():
 name,*spec=case.split(); apps=[s.split(':')[0] for s in spec]
 for mode in ('plain',):
  r=D/'runs'/(name+'-'+mode); log=(r/'uart.log').read_text()
  events=[[int(x) for x in s.split()] for s in re.findall(r'^NATIVE CBS EVENT ([0-9 ]+)$',log,re.M)]
  starts=[(row[2],row[3]) for row in events if row[0]==0]
  stops=[row for row in events if row[0] in (1,2,3,4)]
  guard=62500
  print(r.name, 'open',starts, 'launch pass/indeterminate/miss',sum(0<b[10]<=b[4]+guard for b in stops),sum(b[9]<=b[4]+guard and (not b[10] or b[10]>b[4]+guard) for b in stops),sum(b[9]>b[4]+guard for b in stops))
  print('owner bounds',[(b[2],b[3],b[9]-b[4],b[10]-b[4],b[12]-b[6] if b[0]==4 else None,b[12]-b[5],b[13]) for b in stops])
  print('exits',re.findall(r'^NATIVE EL0 EXIT PID.*$',log,re.M),'inhibit',re.findall(r'^NATIVE CBS INHIBIT.*$',log,re.M),'refusal',re.findall(r'^NATIVE CBS REFUSED.*$',log,re.M))
  if not (r/'ram.json').exists(): continue
  for a,rec in zip(apps,json.loads((r/'ram.json').read_text())):
   val=lambda k:int.from_bytes(bytes.fromhex(rec[k]),'little')
   n=val('private_blocks'); raw=bytes.fromhex(rec['private_result']); expected=0
   if a=='crc':
    for _ in range(n):expected=zlib.crc32(ramp,expected)
   elif a=='histogram':expected=int.from_bytes(struct.pack('<16Q',*([256*n]*16)),'little')
   elif a=='energy':expected=22370304*n
   elif a=='short_report':expected=256*n
   else:expected=522240*n
   print(a,n,'bytes_ok',val('private_bytes')==4096*n,'product_ok',int.from_bytes(raw,'little')==expected)
