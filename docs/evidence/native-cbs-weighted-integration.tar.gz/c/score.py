from pathlib import Path
from collections import Counter
import re,json,struct,zlib,itertools,zipfile,hashlib
d=Path(__file__).resolve().parent
score=[]
for line in (d/'cases').read_text().splitlines():
 name,*specs=line.split()
 for mode in ['plain']:
  r=d/'runs'/(name+'-'+mode); log=(r/'uart.log').read_text()
  rows=[[int(x) for x in s.split()] for s in re.findall(r'^NATIVE CBS EVENT ([0-9 ]+)$',log,re.M)]
  status=[int(x) for x in re.findall(r'^NATIVE EL0 EXIT PID \d+ (-?\d+)$',log,re.M)]
  ram=json.loads((r/'ram.json').read_text()); ns=[int.from_bytes(bytes.fromhex(a['private_blocks']),'little') for a in ram]
  if not rows:
   assert not any(ns) and 'REFUSED 2' in log;continue
  caps=[int(s.split(':')[1].split(',')[0]) for s in specs]
  e,h,span,g=map(int,re.search(r'CONFIG (.*)',log).group(1).split())
  prep,f,arm,check,seen=map(int,re.search(r'STARTUP (.*)',log).group(1).split())
  stops=[b for b in rows if 1<=b[0]<=4]; starts=[b for b in rows if b[0]==0]
  assert len(starts)==len(stops) and e==f+h//10000 and prep<=stops[0][8]<=f<=arm and check>=e and seen==1
  walls=Counter(); prev={}; irqs=[]; restored=0; late=[]; seen_exit=set()
  trace=(r/'exceptions.log').read_text() if mode=='traced' else ''
  for a,b in zip(starts,stops):
   _,_,t,i=b[:4];assert a[2:4]==b[2:4] and i not in seen_exit
   assert b[4]==e+t*span and b[6]==b[5]-g and b[4]<=b[9]<=b[10]<=b[4]+g and b[12]<=b[5] and b[13]<=span
   walls[i,b[24+2*i]]+=b[13]; assert walls[i,b[24+2*i]]<=caps[i]*span
   if i in prev:
    assert (a[32],a[33],a[20])==prev[i];restored+=1
   prev[i]=b[18],b[19],b[20]
   if b[0]==4:
    late.append(b[12]-b[6]);assert 0<=late[-1]<=g
    if trace:
     assert ('ELR '+hex(b[18])) in trace and ('to AArch64 EL0 PC '+hex(b[18])) in trace
   if b[0]==3:seen_exit.add(i)
  assert len(seen_exit)==len(specs) and 'DROPPED 0' in log
  blocks=[obs[1] for obs in map(json.loads,(r/'progress.jsonl').read_text().splitlines())]
  delta=[[b[i]-a[i] for i in range(len(specs))] for a,b in zip(blocks,blocks[1:])]
  # Groups of positive changes separated by a stationary interval for each private counter.
  groups=[sum(k for k,seq in itertools.groupby(row[i]>0 for row in delta)) for i in range(len(specs))]
  out=dict(case=name,mode=mode,owners=[b[3] for b in starts],slots=[b[2] for b in starts],grants=len(stops),first_L=check-e,first_U=stops[0][10]-e,max_U=max(b[10]-b[4] for b in stops),max_cutoff=max(late,default=None),restores=restored,irq=len(late),blocks=ns,status=status,positive_sample_groups=groups,per_pid_grants=[sum(b[3]==i for b in starts) for i in range(len(specs))],wake=[(b[2],b[3],b[23+2*b[3]],b[24+2*b[3]]) for b in rows if b[0]==6])
  score.append(out)
(d/'scores.json').write_text(json.dumps(score,indent=2))
for s in score:print(s['case'],s['mode'],s['grants'],s['first_L'],s['first_U'],s['max_U'],s['max_cutoff'],s['restores'],s['blocks'],s['positive_sample_groups'],s['wake'])