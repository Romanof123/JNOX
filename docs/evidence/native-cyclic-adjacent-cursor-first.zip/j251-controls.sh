set -eu
cd /tmp/j251-new
r=/home/ywcho/j251first
export CARGO_BUILD_JOBS=1 PYTHONPATH=$HOME/jnox-169-first-e203caa/deps PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH
mkdir "$r/controls"
for a in weighted-share weighted-wake startup-probe; do
b="$r/build-$a"; rc=0; python3 tools/build_native_el0.py --app "$a" --out "$b" >"$b.log" 2>&1 || rc=$?; echo "$rc" >"$b.rc"; if ((rc)); then continue; fi
for c in default icount3; do t=native_weighted; args=("${a#weighted-}" "$c"); p=native_weighted_monitor; if [[ $a == startup-probe ]]; then [[ $c == default ]] || continue; t=native_el0; args=(); p=native_startup_probe; fi
d="$r/controls/$a-$c"; rc=0; python3 tools/${t}_capture.py "${args[@]}" "$d" "$b/kernel.elf" "$b/user.elf" "examples/portability/$p.c" "$(git rev-parse HEAD)" >"$d.log" 2>&1 || rc=$?; echo "$rc" >"$d.capture"; if [[ -f "$d/session.json" ]]; then rc=0; python3 tools/${t}_replay.py "$d" "$(sha256sum "$d/session.json" |cut -d' ' -f1)" >"$d.json" 2>"$d.err" || rc=$?; echo "$rc" >"$d.rc"; fi
done; done
rustc --edition 2024 --test tools/scheduling_tests.rs -o /tmp/j251-host >"$r/controls/compile.txt" 2>&1
/tmp/j251-host --test-threads=1 >"$r/controls/rust-tests.txt"
python3 tools/test_build_native_partition_phase.py >"$r/controls/package.txt" 2>&1
for a in p q; do
b="$r/build-phase-$a"; python3 tools/build_native_el0.py --app partition-$a --partition-phase irq-v1 --out "$b" >"$b.log" 2>&1
for c in default icount3; do
d="$r/controls/phase-$a-$c"; rc=0
python3 tools/native_weighted_capture.py partition-$a "$c" "$d" "$b/kernel.elf" "$b/user.elf" examples/portability/native_partition_monitor.c "$(git rev-parse HEAD)" >"$d.log" 2>&1 || rc=$?
echo "$rc" >"$d.capture"
f=$(find "$r/evidence" -maxdepth 1 -type d -name "*-$a-$c-new" |sort|head -1)
rc=0; python3 tools/native_partition_phase.py "$f" "$(cat "$f.digest")" "$d" "$(sha256sum "$d/session.json"|cut -d' ' -f1)" >"$d.json" 2>"$d.err" || rc=$?; echo "$rc" >"$d.rc"
done; done
