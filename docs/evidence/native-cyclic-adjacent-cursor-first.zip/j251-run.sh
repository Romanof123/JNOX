set -eu
r=$HOME/j251first
mkdir "$r"
mkdir "$r/evidence"
export CARGO_BUILD_JOBS=1 RUST_TEST_THREADS=1 PYTHONPATH=$HOME/jnox-169-first-e203caa/deps PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH
rustc -Vv >"$r/rust.txt"
for v in old new; do cd /tmp/j251-$v; for a in p q; do
b="$r/build-$a-$v"
python3 tools/build_native_el0.py --app partition-$a --out "$b" >"$b.log" 2>&1
aarch64-linux-gnu-objdump -dC "$b/kernel.elf" >"$b.dis"
done; done
for a in p q; do cmp "$r/build-$a-old/user.elf" "$r/build-$a-new/user.elf"; done
i=0
for a in p q; do for c in default icount3; do for v in old new new old old new new old old new; do
cd /tmp/j251-$v
i=$((i+1)); d="$r/evidence/$(printf %02d $i)-$a-$c-$v"; b="$r/build-$a-$v"; rc=0
python3 tools/native_weighted_capture.py partition-$a "$c" "$d" "$b/kernel.elf" "$b/user.elf" examples/portability/native_partition_monitor.c "$(git rev-parse HEAD)" >"$d.log" 2>&1 || rc=$?
echo "$rc" >"$d.capture"
if test -f "$d/session.json"; then h=$(sha256sum "$d/session.json"|cut -d' ' -f1); echo "$h" >"$d.digest"; rc=0; python3 tools/native_partition_replay.py "$d" "$h" >"$d.json" 2>"$d.err" || rc=$?; echo "$rc" >"$d.rc"; fi
done; done; done
