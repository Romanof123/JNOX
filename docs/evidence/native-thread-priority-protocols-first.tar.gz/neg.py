import subprocess,os,json,pathlib,hashlib
e=pathlib.Path.home()/'iv336-383/evidence'; src=e.parent/'src'
app=str(e/'priority.elf'); digest=hashlib.sha256(open(app,'rb').read()).hexdigest()
out={}
for n,role,extra,override in [
 ('missing',None,[],{}),('short','1,2,3',[],{}),('extra','1,2,3,4,5',[],{}),('zero','0,2,3,4',[],{}),('high','1,2,3,32',[],{}),('conflict','1,2,3,4',['--weights','1,2'],{'JNOX_NATIVE_WEIGHTS':'1,2'}),('peer','1,2,3,4',['--peer-elf',app],{'JNOX_NATIVE_PEER_ELF':app,'JNOX_NATIVE_PEER_ELF_SHA256':digest}),('board','1,2,3,4',['--board','pi4'],{'JNOX_BOARD':'pi4'}),('count','1,2,3,4',[],{'JNOX_NATIVE_THREADS':'3'})]:
 env=dict(os.environ,JNOX_APP='process',JNOX_PROFILE='native',JNOX_BOARD='virt',JNOX_NATIVE_THREADS='4',JNOX_NATIVE_POLICY='fifo',JNOX_NATIVE_ELF=app,JNOX_NATIVE_ELF_SHA256=digest,CARGO_TARGET_DIR=str(e.parent/'neg-target'),CARGO_BUILD_JOBS='1')
 env.update(override)
 if role:env['JNOX_NATIVE_THREAD_PRIORITIES']=role
 args=['python3','tools/build_native_el0.py','--out',str(e.parent/('neg-'+n)),'--elf',app,'--threads',env['JNOX_NATIVE_THREADS'],'--policy','fifo']+(['--thread-priorities',role] if role else [])+extra
 for k,cmd,penv in [('package',args,os.environ),('raw',['python3','tools/build_kernel.py','--arch','aarch64'],env)]:
  p=subprocess.run(cmd,cwd=src,env=penv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True); (e/f'neg-{n}-{k}.log').write_text(p.stdout);out[n+'-'+k]=p.returncode
print(out);(e/'negative-status.json').write_text(json.dumps(out,indent=2))
