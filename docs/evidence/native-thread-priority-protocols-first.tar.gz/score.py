from pathlib import Path
import json,struct,re,subprocess
E=Path.home()/'iv336-383/evidence'
N=2**64-1
def syms(path):
 return {f[-1]:int(f[0],16) for l in subprocess.check_output(['aarch64-linux-gnu-nm','-n',path],text=True).splitlines() if len(f:=l.split())==3}
report={}
for path in sorted(E.glob('*-trace'))+sorted(E.glob('*-plain')):
 c=path.name.split('-')[0]; u=syms(path/'user.elf'); k=syms(path/'kernel.elf'); ram=(path/'ram.bin').read_bytes()
 def read(name,fmt):
  space=next(v for n,v in k.items() if '6SPACES17' in n)
  return list(struct.unpack_from('<'+fmt,ram,space-0x40200000+5*4096+u[name]-0x400000))
 uart=(path/'uart.bin').read_text(); r=report[path.name]={'exit':int(re.search(r'EL0 EXIT (-?\d+)',uart)[1])}
 if c.startswith('legacy'):
  r['sensor']=read('sensor_total','3Q'); r['join']=read('joined_aggregate','Q')[0]==u['sensor_total']; continue
 if c=='singleton':continue
 def rows(tag):return [list(map(int,l.split()[3:])) for l in uart.splitlines() if l.startswith('NATIVE PRIORITY '+tag+' ')]
 ev=rows('EVENT'); tasks=rows('TASK'); locks=rows('LOCK'); r['drops']=rows('DROPPED')[0][0]
 data=read('products','12Q'); ns={'chain':[524288,8,524288,8],'timeout':[524288,8,524288,8],'cycle':[8,8,0,0],'protect':[8,0,8,0],'rank':[8,8,8,0],'fifo12':[8,8,8,0],'fifo21':[8,8,8,0],'rr':[0,524288,524288,8],'fifo':[0,524288,524288,8]}[c]
 r['products']=data; r['products_ok']=all(data[3*i:3*i+3]==[n,n*32640,n*5559680] for i,n in enumerate(ns))
 r['joins']=read('joined','4Q'); r['joins_ok']=all(r['joins'][i]==u['products']+24*i for i in range(1,4) if ns[i]); r['stage']=read('stages','4I'); r['transcript']=read('transcript','16I')[:read('transcript_count','I')[0]]; r['errors']=dict((n,read(n,'i')[0]) for n in ['failure_line','timeout_result','cycle_result','busy_result','wrong_user_result','stale_result','stale_mutex_result'])
 out=[]
 for i,e in enumerate(ev):
  t=tasks[4*i:4*i+4]; l=locks[4*i:4*i+4]
  out.append([i,e[1],e[4] if e[4]!=N else '-',e[5] if e[5]!=N else '-',e[6], [a[4] for a in t],[a[7] for a in t],[a[6] for a in t], [a[4] if a[4]!=N else '-' for a in l],hex(e[13]),hex(e[16]),e[12] if e[12]<2**63 else e[12]-2**64])
 (E/(path.name+'-rows.json')).write_text(json.dumps(out))
 if (path/'exceptions.log').exists():
  trace=(path/'exceptions.log').read_text(); actual=[int(p,16) for p in re.findall(r'Exception return from AArch64 EL1 to AArch64 EL0 PC (0x[0-9a-f]+)',trace)]
  wanted=[e[16] for e in ev if e[5]!=N and e[24]]
  r['eret']=[len(wanted),len(actual),wanted==actual]; r['irq_elr']=[hex(e[13]) for e in ev if e[1]==2]
 print(path.name,r['products_ok'],r['joins_ok'],r['stage'],r['transcript'],r.get('eret'))
(E/'scores.json').write_text(json.dumps(report,indent=2))
