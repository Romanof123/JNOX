set -eu
source ~/.cargo/env
cd ~/iv336-383/src
e=$HOME/iv336-383/evidence
rev=383f1d40b10798af89d5f3ddf44c456accb96b0b
export CARGO_BUILD_JOBS=1
aarch64-linux-gnu-objdump -d "$e/priority.elf" > "$e/priority.dis"
cp ~/iv318-f0/raw/sensor.elf "$e/sensor.elf"
cp ~/iv318-f0/raw/outside/user.elf "$e/single.elf"
for c in chain timeout protect rank fifo12 fifo21 cycle rr fifo legacycoop legacyrr singleton; do
 p=1,2,3,4; case $c in fifo12|fifo21|rr|fifo) p=1,2,2,4;; esac
 a=(--elf "$e/priority.elf" --arg "$c" --threads 4 --policy fifo --thread-priorities "$p")
 case $c in rr) a=(--elf "$e/priority.elf" --arg rr --threads 4 --policy rr --thread-priorities "$p" --quantum-ticks 625000);; legacycoop) a=(--elf "$e/sensor.elf" --threads 2);; legacyrr) a=(--elf "$e/sensor.elf" --threads 2 --policy rr --quantum-ticks 625000);; singleton) a=(--elf "$e/single.elf");; esac
 python3 tools/build_native_el0.py --out "$e/pkg-$c" "${a[@]}" > "$e/build-$c.log" 2>&1 || echo BUILD-FAIL-$c
done
sha256sum "$e"/*.elf "$e"/priority.dis "$e"/pkg-*/manifest.json "$e"/pkg-*/kernel.elf > "$e/preboot.sha256"
for c in chain timeout protect rank fifo12 fifo21 cycle rr fifo legacycoop legacyrr singleton; do
 modes=trace; case $c in chain|timeout|protect) modes='plain trace';; esac
 for mode in $modes; do
 f=priority; pr=examples/native-priority-mutex/priority.c; exitcode=0; case $c in legacy*) f=sensor; pr=examples/native-thread-mutex/sensor.c;; singleton) f=single; pr=/home/ywcho/iv318-f0/raw/outside.c; exitcode=0;; esac
 opts=(); if [[ $mode == plain ]]; then opts+=(--plain); fi
 python3 tools/native_el0_capture.py "$e/$c-$mode" "$e/pkg-$c/kernel.elf" "$e/$f.elf" "$pr" "$rev" --expect-exit "$exitcode" "${opts[@]}" > "$e/run-$c-$mode.log" 2>&1 || echo CAPTURE-FAIL-$c-$mode
 done
done
