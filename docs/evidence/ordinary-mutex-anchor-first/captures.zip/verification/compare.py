from pathlib import Path
import shutil, hashlib, struct
d=Path('/mnt/d/codex/.jnox-work/next-fixed/mutex-anchor-first')
out=Path.home()/'jnox-mutex-anchor-first-da80055'
out.mkdir(exist_ok=True)
for name in ['independent-freeze.txt','default-pi.build.txt']:
 shutil.copy2(d/name,out/name)
r=Path.home()/'jnox-149-first-47ea890/01-ordinary-pi-plain/kernel.elf'
c=d/'build/default-pi/aarch64-unknown-none/release/jnox-kernel'
s=[]
for name,source in [('reference',r),('candidate',c)]:
 b=source.read_bytes()
 shutil.copy2(source,out/(name+'.elf'))
 h=lambda buf:hashlib.sha256(buf).hexdigest()
 s.append(name+' ELF '+h(b))
 ph,sh=struct.unpack_from('<QQ',b,32)
 ps,pn,ss,sn,si=struct.unpack_from('<5H',b,54)
 for i in range(pn):
  t,flags,off,va,pa,size,ms,al=struct.unpack_from('<II6Q',b,ph+i*ps)
  if t==1:s.append(f'LOAD {va:x} {size:x} '+h(b[off:off+size]))
 names,ns=struct.unpack_from('<2Q',b,sh+si*ss+24)
 for i in range(sn):
  j=sh+i*ss
  start=names+struct.unpack_from('<I',b,j)[0]
  if b[start:start+6]==b'.text\0':
   off,size=struct.unpack_from('<2Q',b,j+24)
   s.append(f'.text {size:x} '+h(b[off:off+size]))
text='\n'.join(s)+'\n'
print(text)
for p in [out,d]: (p/'preflight.txt').write_text(text)
