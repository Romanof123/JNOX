from pathlib import Path
import subprocess as sp,os,json
d=Path(__file__).parent; k=d/'source/kernel'
def build(tag,mode=None,app=None,board='virt',profile='mutex',features=None,extra=None,bad=False):
 env={k:v for k,v in os.environ.items() if not k.startswith('JNOX_')}
 env.update(JNOX_BOARD=board,CARGO_TARGET_DIR=str(d/'build'/tag))
 for key,val in [('JNOX_MUTEX_ANCHOR',mode),('JNOX_PROFILE',profile),('JNOX_APP',app)]:
  if val:env[key]=val
 env.update(extra or {})
 cmd=['cargo','+1.95.0','build','--locked','--release','-j1']+(['--features',features] if features else [])
 with (d/(tag+'.log')).open('xb') as f:r=sp.run(cmd,cwd=k,env=env,stdout=f,stderr=sp.STDOUT)
 (d/(tag+'.json')).write_text(json.dumps(dict(cwd=str(k),args=cmd,selectors={a:b for a,b in env.items() if a.startswith('JNOX_') or a=='CARGO_TARGET_DIR'},status=r.returncode),indent=2))
 print(tag,r.returncode,flush=True)
 return (r.returncode!=0)==bad
for tag,kw in [('default-ceiling',dict(app='ordinary-ceiling')),('legacy',dict(profile=None,features='mutex-bench')),('reject-unknown',dict(mode='bad',app='ordinary-pi',bad=True)),('reject-pi4',dict(mode='selected-return',board='pi4',app='ordinary-pi',bad=True)),('reject-bench',dict(mode='rust-prepared',app='ordinary-pi',features='mutex-bench',bad=True)),('reject-trace',dict(mode='rust-stages',app='ordinary-pi',extra={'JNOX_FIXED_TRACE':'1'},bad=True)),('reject-case',dict(mode='selected-return',app='ordinary-pi',extra={'JNOX_CONTROL_CASE':'1'},bad=True)),('reject-app',dict(mode='rust-stages',bad=True))]:
 if not build(tag,**kw):raise SystemExit(tag)
for mode in ['rust-prepared','rust-stages','selected-return']:
 for app in ['ordinary-pi','ordinary-ceiling']:build(mode+'-'+app,mode,app)
