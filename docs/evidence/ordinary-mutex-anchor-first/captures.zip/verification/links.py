from pathlib import Path
import shutil,subprocess as s,hashlib,json,struct,re
D=Path(__file__).parent
H=Path.home()/'jnox-mutex-anchor-first-da80055'
elf=lambda tag:D/'build'/tag/'aarch64-unknown-none/release/jnox-kernel'
h=lambda b:hashlib.sha256(b).hexdigest()
for tag,ref in [('default-ceiling',Path.home()/'jnox-149-first-47ea890/03-ordinary-ceiling-plain/kernel.elf'),('legacy',D.parent/'ordinary-mutex-first/build/controls/aarch64-unknown-none/release/jnox-kernel')]:
 a,b=ref.read_bytes(),elf(tag).read_bytes()
 diff=[k for k,(x,y) in enumerate(zip(a,b)) if x!=y]
 s0=[tag,str(ref),h(a),h(b),str([len(a),len(b)]),str([(hex(i),a[i],b[i]) for i in diff[:20]])]
 def parts(blob):
  ph,sh=struct.unpack_from('<QQ',blob,32);ps,pn,ss,sn,si=struct.unpack_from('<5H',blob,54)
  names=struct.unpack_from('<Q',blob,sh+si*ss+24)[0]; result={}
  for i in range(pn):
   t,fl,off,va,pa,size,ms,al=struct.unpack_from('<II6Q',blob,ph+i*ps)
   if t==1:result[hex(va)]=h(blob[off:off+size])
  for i in range(sn):
   j=sh+i*ss; start=names+struct.unpack_from('<I',blob,j)[0]
   if blob[start:start+6]==b'.text\0':
    off,size=struct.unpack_from('<2Q',blob,j+24);result['text']=h(blob[off:off+size])
  return result
 s0.extend([str(parts(a)),str(parts(b))])
 if tag=='default-ceiling':
  for i in diff:
   for j in range(i-17,i-14):
    ptr,n,l,c=struct.unpack_from('<QQII',b,j)
    if n==21 and 0x40200000<=ptr<0x40208000 and b[ptr-0x401f0000:ptr-0x401f0000+21]==b'src\\ordinary_mutex.rs':
     s0.append(str([hex(i),struct.unpack_from('<I',a,j+16)[0],l,c]))
 (D/(tag+'.compare')).write_text('\n'.join(s0));print('\n'.join(s0))
 assert parts(a)['text']==parts(b)['text'] and (parts(a)==parts(b) if tag=='legacy' else len(a)==len(b) and len(diff)==len(s0)-8)
for mode in ['rust-prepared','rust-stages','selected-return']:
 for app in ['ordinary-pi','ordinary-ceiling']:
  tag=mode+'-'+app
  p=H/tag;p.mkdir();f=p/'kernel.elf';shutil.copy2(elf(tag),f)
  for name,cmd in [('disasm',['aarch64-linux-gnu-objdump','-dC']),('symbols',['aarch64-linux-gnu-nm','-nCS'])]:
   (p/name).write_bytes(s.check_output(cmd+[str(f)]))
  dis=(p/'disasm').read_text();lines=dis.splitlines()
  writers=[x for x in lines if re.search(r'msr\s+cntp_cval_el0',x)]
  assert len(writers)==1,writers
  ret=dis.split('<sched_start_frame>:\n')[1].split('\n\n')[0]
  assert ('msr\tcntp_cval_el0' in ret)==(mode=='selected-return')
  for word in ['clrex','eret','elr_el1','spsr_el1','tpidr_el1']: assert word in ret
  assert ret.count('cntpct_el0')=={'rust-prepared':1,'rust-stages':2,'selected-return':3}[mode]
  (p/'linked.txt').write_text('\n'.join(writers)+'\n'+ret)
  print(tag,h(f.read_bytes()),writers)

