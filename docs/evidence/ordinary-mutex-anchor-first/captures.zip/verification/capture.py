from pathlib import Path
import shutil,subprocess as s,json,time,hashlib,platform
H=Path.home()/'jnox-mutex-anchor-first-da80055'; D=Path(__file__).parent
items=[]
for mode in ['rust-prepared','rust-stages','selected-return']:
 for i,app in enumerate(['ordinary-pi','ordinary-pi','ordinary-ceiling','ordinary-ceiling']):
  img=H/(mode+'-'+app);p=H/mode/(f'{i+1:02}-'+app+('-traced' if i%2 else '-plain'));p.mkdir(parents=True)
  f=p/'kernel.elf';shutil.copy2(img/'kernel.elf',f)
  for n in ['symbols','disasm','linked.txt']:shutil.copy2(img/n,p/n)
  argv=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','stdio','-kernel',str(f)]
  if i%2:argv+=['-d','int','-D',str(p/'external.log')]
  m=dict(revision='da8005510e3d240660fc1f8f445161826852a291',mode=mode,app=app,argv=argv,sha256=hashlib.sha256(f.read_bytes()).hexdigest(),allowance=15,host=platform.uname()._asdict(),qemu=s.check_output(['qemu-system-aarch64','--version'],text=True).strip())
  (p/'attempt.json').write_text(json.dumps(m,indent=2));items.append((p,m))
for p,m in items:
 m['start']=time.time();begin=time.monotonic()
 with (p/'uart').open('xb') as u,(p/'stderr').open('xb') as err:
  q=s.Popen(m['argv'],stdin=s.DEVNULL,stdout=u,stderr=err);m['pid']=q.pid
  while q.poll() is None and time.monotonic()-begin<15:
   if b'MUTEX END' in (p/'uart').read_bytes():break
   time.sleep(.01)
  m['cause']='guest-process-exit' if q.poll() is not None else ('host-stop-after-footer' if b'MUTEX END' in (p/'uart').read_bytes() else 'host-timeout')
  if q.poll() is None:q.terminate()
  m.update(status=q.wait(),elapsed=time.monotonic()-begin)
 (p/'result.json').write_text(json.dumps(m,indent=2));shutil.copytree(p,D/'captures'/m['mode']/p.name)
 print(p,m['cause'],(p/'uart').read_text().splitlines()[3:4],flush=True)
