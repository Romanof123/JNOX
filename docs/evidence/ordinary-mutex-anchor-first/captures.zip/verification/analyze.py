from pathlib import Path
import subprocess as s,sys,json,re
D=Path(__file__).parent
ancestor=(D.parent/'ordinary-mutex-first/replay.py').read_text()
code=ancestor[ancestor.index('for p in sorted'):].replace("sorted(H.glob('0*'))","[position]")
for p in sorted((D/'captures').glob('*/*')):
 m=json.loads((p/'result.json').read_text()); mode,app=m['mode'],m['app']
 result=s.run([sys.executable,str(D/'source/tools/mutex_anchor_replay.py'),str(p/'uart'),'--app',app,'--anchor',mode],capture_output=True,text=True)
 rows=[line.split() for line in (p/'uart').read_text().splitlines()];ev=[[int(i,16) for i in row[1:]] for row in rows if row[0]=='E'];irq=next(x for x in ev if x[2]==5)
 ds=(p/'disasm').read_text();worker=ds.split('<mutex_batch_compute>:\n')[-1].split('\n\n')[0]
 pc=hex(irq[7])[2:];lines=worker.splitlines();idx=next((i for i,x in enumerate(lines) if x.strip().startswith(pc+':')),None)
 near=lines[max(0,idx-4):idx+5] if idx is not None else []
 with (p/'interpretation.txt').open('w') as f:
  from contextlib import redirect_stdout
  import collections
  with redirect_stdout(f):
   print('candidate decoder',result.returncode,result.stdout,result.stderr);print('IRQ PC',pc,'completed',irq[20],'in work',irq[21]);print('\n'.join(near))
   try:exec(code,dict(position=p,collections=collections,re=re,N=2**64-1))
   except Exception as exc:print('INDEPENDENT REPLAY ERROR',repr(exc));import traceback;traceback.print_exc(file=f)
 print(mode,p.name, result.returncode,pc,irq[20],str(idx),'replay error', 'REPLAY ERROR' in (p/'interpretation.txt').read_text())
