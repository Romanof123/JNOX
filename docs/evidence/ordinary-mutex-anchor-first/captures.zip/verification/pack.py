from pathlib import Path
import json,zipfile,collections,hashlib
d=Path(__file__).parent
dest=d.parent/'mutex-anchor-first-evidence/docs/evidence/ordinary-mutex-anchor-first'
dest.mkdir(exist_ok=True)
report=['# CHG-072 first optional cohorts / 선택형 이미지 최초 실행','',
'Source da8005510e3d240660fc1f8f445161826852a291. Native WSL2 QEMU virt/GICv2, single Cortex-A72, TCG, 128 MiB, default clock, 15 s allowance. Builds used Windows MSVC Rust 1.95.0 for aarch64-unknown-none. First launches only, one boot per position. Complete footer in all 12, raw argv/PID/time/status in capture archive. All compare intervals exactly 6,250 ticks at 62.5 MHz. Raw samples and ELF/disassembly are included per position. A traced ERET record gives the destination PC, its cycle remains unobserved.','','| Mode | Position | Guest reason | IRQ ELR | chunks | arm | CVAL | R | pre-ERET | vector |','|---|---|---:|---|---:|---:|---:|---:|---:|---:|']
for p in sorted((d/'captures').glob('*/*')):
 rows=collections.defaultdict(list)
 for line in (p/'uart').read_text().splitlines()[3:-1]:
  tag,*v=line.split();rows[tag].append([int(x,16) for x in v])
 h,t,ph=[rows[x][0] for x in ['H','T','P']];q=next(e for e in rows['E'] if e[2]==5)
 report.append(f'| {p.parent.name} | {p.name} | {h[1]} | 0x{q[7]:x} | {q[20]} | {t[1]} | {t[2]} | {ph[3]} | {ph[4] or "—"} | {q[0]} |')
report+=['','Rust-prepared and rust-stages each qualified 3/4 (PI 1/2, ceiling 2/2). Both traced PI failures ended with reason 16, IN_WORK zero and no completed chunks. Selected-return qualified 4/4 (PI 2/2, ceiling 2/2). The selected-return ceiling trace interrupted the instruction immediately after the input loop before publishing the first chunk. All qualifying boots completed the 256 chunk records, final count 65,536, sum 557,056 and MEDIUM sum 32,896. The independent replay checks ready membership, priorities, owners/waiters, handoffs, frames and registers, all restores and available external exception matches. Per-position interpretation contains actual interval and input-PC evidence.','',
'Each optional linked image contains exactly one CVAL writer. In selected-return both ELFs have CLREX at 0x40201aa0, arm sample at 0x40201b98, CVAL/CTL writes at 0x40201ba4/0x40201bac and readbacks at 0x40201bb4/0x40201bb8. Final sample at 0x40201bf4 precedes one store, NZCV restoration, a bounded 832-byte frame revisit for x9–x14, SP recovery, branch and ERET at 0x40201c58. The added static block covers 109 instructions, including fail paths, adds no register spills and uses a 160-byte witness. Each rust-stages capture includes original-anchor write-end/readback-end/restore-entry values in P.','',
'Default PI and ceiling both have equal executable text and seven bytes differing in six diagnostic source line numbers. Legacy mutex-bench has equal PT_LOAD segments and text, different full ELF. Separate hashes and reference paths are archived. All six invalid selector combinations exited 101. Offline host suites passed five decoder tests and two policy tests. Original RAW 1 remains a separate cohort. Results describe this virtual machine and observer.','',
'선택형 세 코호트는 각각 독립적으로 집계했다. Rust 준비형과 단계 계측형은 각각 3/4였고 두 경우 모두 PI 추적 실행이 보호 작업에 진입하기 전에 IRQ를 받아 사유 16으로 종료됐다. 선택 프레임 반환형은 4/4였다. 각 첫 실행의 ELF, UART, 명령행과 추적 로그를 보존했다. 물리 보드나 최악 실행 시간은 측정하지 않았다.']
(dest/'README.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
with zipfile.ZipFile(dest/'captures.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted((d/'captures').rglob('*')):
  if f.is_file():z.write(f,f.relative_to(d))
 for pattern in ['*.py','*.log','*.json','*.compare','host-*.txt']:
  for f in d.glob(pattern):z.write(f,'verification/'+f.name)
 for tag in ['default-ceiling','legacy']:z.write(d/'build'/tag/'aarch64-unknown-none/release/jnox-kernel','verification/'+tag+'.elf')
 z.write(d.parent/'ordinary-mutex-first/replay.py','verification/retained-replay.py')
print(dest)
