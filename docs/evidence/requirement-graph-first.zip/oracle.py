import sys,csv,json,re
from pathlib import Path
p=Path(sys.argv[1]); out=Path(sys.argv[2]); decl={}; alloc={}; errors=[]
for lang,suffix in [('EN','.en.md'),('KO','.md')]:
 d={}; a={}
 for base,kinds in [('product-plan',['OBJ']),('safety-security-concept',['HAZ','THR','ASM']),('requirements',['REQ']),('verification-plan',['VER']),('architecture',['DES'])]:
  f='docs/'+base+suffix
  for n,line in enumerate((p/f).read_text(encoding='utf8').splitlines(),1):
   m=re.match(r'^## (DES-\d{3})\b' if base=='architecture' else r'^\|\s*`([A-Z]+-\d{3})`',line)
   if not m or m[1][:3] not in kinds:continue
   x=m[1]
   if x in d: errors.append(('duplicate',lang,x))
   d[x]=[f,n]
   if x.startswith('REQ'):
    cells=line.split('|'); a[x]=[]
    for i in [2,4]:
     for y in re.findall(r'`([A-Z]+-\d{3})`',cells[i]):
      rel={'OBJ':'derives','HAZ':'derives','THR':'derives','ASM':'constrains','DES':'implemented-by-design','VER':'verified-by'}[y[:3]]
      a[x].append([y,rel,x] if i==2 else [x,rel,y])
 decl[lang]=d;alloc[lang]=a
rows=list(csv.reader((p/'trace/links.csv').read_text().splitlines()))[1:]
edges={x:[[i,*r] for i,r in enumerate(rows,2) if x in (r[0],r[2])] for x in alloc['EN']}
for x,v in alloc['EN'].items():
 for t in v:
  if t not in rows:errors.append(('missing',*t))
for i,r in enumerate(rows,2):
 for x in (r[0],r[2]):
  if x[:3] in ['OBJ','HAZ','THR','ASM','REQ','DES','VER'] and x not in decl['EN']: errors.append(('undefined',i,x))
assert set(decl['EN'])==set(decl['KO']) and alloc['EN']==alloc['KO']
(out/'frozen.json').write_text(json.dumps(dict(decl=decl,alloc=alloc,edges=edges,errors=errors),indent=1))
print(len(decl['EN']),len(edges),errors)
