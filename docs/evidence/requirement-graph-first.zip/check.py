from pathlib import Path
import subprocess as s,sys,json,csv,collections,tempfile,shutil
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();f=json.loads((out/'frozen.json').read_text()); kinds=dict(OBJ='derives',HAZ='derives',THR='derives',ASM='constrains',DES='implemented-by-design',VER='verified-by')
def run(p,q):
 r=s.run([sys.executable,str(p/'tools/requirement_graph.py'),*([q] if q else [])],capture_output=True,text=True)
 return dict(rc=r.returncode,stdout=r.stdout,stderr=r.stderr)
def loc(x):
 return '  '.join(':'.join(map(str,f['decl'][l][x])) for l in ('EN','KO'))
def expect(q):
 ls=[]
 for req,edges in sorted(f['edges'].items()):
  found=[]
  for n,a,b,c in edges:
   other=c if a==req else a;k=other[:3]
   if kinds.get(k)!=b or ((k in ['DES','VER'])!=(a==req)):continue
   if q and q not in (req,other):continue
   found.append(f'  {a} {b} {c}  trace/links.csv:{n}  {loc(other)}')
  if not q or req==q or found:ls += [req+'  '+loc(req),*found]
 return sorted(ls)
orig={}
for q in ['',*sorted(f['decl']['EN'])]:
 r=run(root,q);orig[q]=r
 assert sorted(r['stdout'].splitlines())==expect(q),(q,r)
assert orig['']==run(root,'')
(out/'queries.json').write_text(json.dumps(orig,indent=1))
rows=(root/'trace/links.csv').read_text().splitlines()
dups=[(n,rows.index(line)+1,line) for n,line in enumerate(rows,1) if rows.index(line)+1<n]
print('Independent CSV duplicates:',dups)
cases={}
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp)
 shutil.copytree(root/'tools',p/'tools');shutil.copytree(root/'docs',p/'docs');(p/'trace').mkdir()
 clean='\n'.join(dict.fromkeys(rows))+'\n'; csvp=p/'trace/links.csv'
 def probe(name,path,before,after,rc,phrase):
  path.write_text(after,encoding='utf8');r=run(p,'VER-011');cases[name]=r
  path.write_text(before,encoding='utf8');assert r['rc']==rc and phrase in r['stderr'],(name,r)
 csvp.write_text(clean);probe('clean',csvp,clean,clean,0,'')
 for name,extra,rc,phrase in [('malformed','HAZ-001,derives,REQ-001,unexpected',1,'malformed CSV'),('undefined nonincident','CHG-999,affects,DES-999',1,'undefined endpoint DES-999'),('duplicate',rows[1],1,'duplicate edge'),('wrong relation extra','REQ-001,verified-by,DES-001',0,''),('reversed extra','VER-001,verified-by,REQ-001',0,'')]:
  probe(name,csvp,clean,clean+extra+'\n',rc,phrase)
 probe('orphan upstream',csvp,clean,'\n'.join(x for x in clean.splitlines() if not(x.endswith(',REQ-001') and (',constrains,' in x or ',derives,' in x)))+'\n',1,'REQ-001 missing upstream coverage')
 for suffix in ['.en.md','.md']:
  path=p/('docs/requirements'+suffix);t=path.read_text(encoding='utf8');line=next(x for x in t.splitlines() if x.startswith('| `REQ-001`'))
  for n,repl,msg in [('missing', '', 'edition mismatch REQ-001'),('dup',line+'\n'+line,'duplicate'),('wrong allocation',line.replace('`HAZ-002`','`DES-001`'),'malformed allocation')]:
   probe(n+suffix,path,t,t.replace(line,repl),1,msg)
(out/'mutations.json').write_text(json.dumps(cases,indent=1))
print('all',len(orig),'queries matched; mutation controls',len(cases))
