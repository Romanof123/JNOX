from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent
for name,h in json.loads((root/'paths.json').read_bytes()).items():
 out=root/'restored'/name
 out.resolve().relative_to((root/'restored').resolve())
 out.parent.mkdir(parents=True,exist_ok=True)
 b=(root/'objects'/h).read_bytes()
 assert hashlib.sha256(b).hexdigest()==h
 with out.open('xb') as f:f.write(b)
 assert hashlib.sha256(out.read_bytes()).hexdigest()==h
