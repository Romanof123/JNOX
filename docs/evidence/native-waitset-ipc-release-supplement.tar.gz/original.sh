#!/usr/bin/env bash
set -euo pipefail
source "$HOME/.cargo/env"
rev=d33b49ee0d3daac51af70d90b4c4a2e4b5dc573c
tree=13778a42bb5d9f11072bcef5e9ec2d2336d17e25
rel=$HOME/rel373-d33b49e
src=$rel/source
raw=$rel/raw
mkdir "$rel"
mkdir "$src" "$raw"
git -C "$src" init -q
echo /mnt/d/codex/j-nox/.git/objects > "$src/.git/objects/info/alternates"
cd "$src"
git sparse-checkout init --cone
git sparse-checkout set arch boards kernel examples tools sdk
git -c advice.detachedHead=false checkout --detach "$rev"
test "$(git rev-parse 'HEAD^{tree}')" = "$tree"
test -z "$(git status --porcelain --untracked-files=no)"
git rev-parse HEAD 'HEAD^{tree}' > "$raw/revision"
export CARGO_TARGET_DIR="$rel/target" CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=1 PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
sh sdk/native-aarch64/build-rust.sh examples/native-waitset/receiver/Cargo.toml "$raw/receiver.elf"
sh sdk/native-aarch64/build.sh examples/native-waitset/sender.c "$raw/sender.elf"
rustc --edition 2021 --test kernel/src/waitset_ipc.rs -o "$rel/policy-test"
"$rel/policy-test" | tee "$raw/host.log"
for policy in fifo rr; do
    args=(--out "$rel/pkg-$policy" --policy "$policy" --elf "$raw/receiver.elf" --peer-elf "$raw/sender.elf" --priority 7 --peer-priority 1 --mailbox-route 1:0 --notify-route 1:0 --waitset)
    if [[ $policy = rr ]]; then args+=(--quantum-ticks 625000); fi
    python3 tools/build_native_el0.py "${args[@]}"
    sha256sum "$rel/pkg-$policy/kernel.elf" "$raw/receiver.elf" "$raw/sender.elf" | tee "$raw/$policy-preboot.sha256"
    cp "$rel/pkg-$policy/manifest.json" "$raw/$policy-manifest.json"
    python3 tools/native_el0_capture.py "$raw/$policy" "$rel/pkg-$policy/kernel.elf" "$raw/receiver.elf" examples/native-waitset/receiver/src/main.rs "$rev" --manifest "$rel/pkg-$policy/manifest.json" --expect-exit 71 --timeout 20 --plain
done
