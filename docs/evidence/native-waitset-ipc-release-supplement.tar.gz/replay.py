"""Check original IPC-004 captures using their own ELF symbols, page tables and journal."""
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def symbols(path):
    result = {}
    lines = subprocess.check_output(["aarch64-linux-gnu-nm", "-nS", path], text=True)
    for line in lines.splitlines():
        fields = line.split()
        if len(fields) == 4:
            address, size, _, name = fields
            result[name] = int(address, 16), int(size, 16)
    return result


def one(table, text):
    [match] = [value for key, value in table.items() if text in key]
    return match


def decode(capture, sender, policy):
    launch = json.loads((capture / "launch.json").read_text())
    session = json.loads((capture / "session.json").read_text())
    assert session["marker"] == "EXIT 71"
    for name, expected in session["hashes"].items():
        assert digest(capture / name) == expected, name
    manifest = launch["argument_package"]
    assert manifest["board"] == "virt" and manifest["policy"] == policy and manifest["waitset"]
    assert manifest["tracked_changes"] == "" and manifest["commit"] == launch["revision"] == "d33b49ee0d3daac51af70d90b4c4a2e4b5dc573c"
    assert manifest["kernel_elf_sha256"] == digest(capture / "kernel.elf")
    assert manifest["slots"][0]["elf_sha256"] == digest(capture / "user.elf")
    assert manifest["slots"][1]["elf_sha256"] == digest(sender)
    uart = (capture / "uart.bin").read_text()
    ram = (capture / "ram.bin").read_bytes()
    base = launch["ram_base"]
    kernel = symbols(capture / "kernel.elf")
    apps = [symbols(capture / "user.elf"), symbols(sender)]
    spaces, size = one(kernel, "6SPACES17")
    assert launch["ram_bytes"] == len(ram)
    assert "FAULT" not in uart and "NATIVE FIXED DROPPED 0\n" in uart
    assert re.findall(r"(?m)^NATIVE EL0 EXIT PID (\d+) (-?\d+)$", uart) == [("0", "71"), ("1", "72")]

    def read(address, count=1, signed=False):
        off = address - base
        assert 0 <= off <= len(ram) - count * 8
        return list(struct.unpack_from("<" + ("q" if signed else "Q") * count, ram, off))

    def local(pid, name, signed=False):
        va, length = apps[pid][name]
        table = spaces + pid * (size // 2)
        for shift in (30, 21, 12):
            [entry] = read(table + ((va >> shift) & 511) * 8)
            assert entry & 3 == 3
            table = entry & 0xfffff000
        assert entry & (1 << 6) and not entry & (1 << 7)  # EL0 RW
        return read(table + va % 4096, length // 8, signed)

    handles = local(0, "waitset_handles")
    a, b, _, old, new = handles
    assert len(set(handles)) == 5 and ((old ^ new) & 15) == 0
    assert local(0, "waitset_observations") == [a, 1, b, 1, b, 1, old, 1, new, 8]
    assert local(0, "waitset_errors", True) == [-13, -116, -11, -11, -110]
    assert local(0, "waitset_products") == [0x10000012c, 17, 0x200000200, 812]
    assert local(1, "waitset_sender_foreign", True) == [-13]
    assert local(1, "waitset_send_status", True) == [0] * 5
    rows = [list(map(int, s.split()[3:])) for s in uart.splitlines() if s.startswith("NATIVE FIXED EVENT ")]
    naddr, _ = one(kernel, "7RECORDS17")
    daddr, _ = one(kernel, "9DECISIONS17")
    assert read(naddr) == [len(rows)]
    assert all(read(daddr + i * 168, 21) == row for i, row in enumerate(rows))
    switches = [(i, r[1], r[3], r[4]) for i, r in enumerate(rows) if r[3] != r[4]]
    idle = 2**64 - 1
    assert [x[1:] for x in switches] == [(0,idle,0),(32,0,1),(28,1,0),(32,0,1),(28,1,0),
                                          (32,0,1),(3,1,idle),(4,idle,0),(3,0,idle)]
    assert [r[1] for r in rows[switches[1][0]+1:switches[2][0]+1]] == [30,24,26,28,28]
    block, wake = rows[switches[5][0]], rows[switches[7][0]]
    assert 0 < block[11] <= wake[0] and block[5:7] == wake[7:9]
    for (begin, end) in [(1,2),(3,4)]:
        assert rows[switches[begin][0]][5:7] == rows[switches[end][0]][7:9]
    return dict(policy=policy, journal=len(rows), handles=handles, transitions=switches,
                compare_tick=block[11], irq_tick=wake[0], exits=[71,72], dropped=0,
                kernel_sha256=digest(capture / "kernel.elf"), session_sha256=digest(capture / "session.json"))


if __name__ == "__main__":
    for item in sys.argv[1:]:
        root = Path(item)
        for policy in ("fifo", "rr"):
            cap = root / policy
            if not cap.is_dir():
                cap = root / ("cap-waitset-" + policy)
            print(json.dumps(decode(cap, root / "sender.elf", policy)))
