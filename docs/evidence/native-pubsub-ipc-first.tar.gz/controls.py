import json, subprocess,sys
from pathlib import Path
src,raw=map(Path,sys.argv[1:3])
original=json.loads((raw/"fifo/manifest.json").read_text())["package_argv"]
tests={}
def reject(name,sub,old=[],new=[],add=[]):
    args=original.copy()
    for flag,val in old:
        i=next(i for i in range(len(args)-1) if args[i:i+2]==[flag,val]); args[i:i+2]=[]
    for flag,val in new: args[args.index(flag)+1]=val
    args[args.index("--out")+1]=str(raw/("reject-"+name))
    p=subprocess.run([sys.executable,*args,*add],cwd=src,capture_output=True,text=True)
    assert p.returncode and sub in p.stderr and not (raw/("reject-"+name)/"kernel.elf").exists(),(name,p.stderr)
    tests[name]=dict(argv=args+add,exit=p.returncode,last=p.stderr.splitlines()[-1])
reject("route","explicit IPC routes",old=[("--ipc-route","1:3")])
reject("generated-args","four ordinary",add=["--peer3-arg","000"])
reject("three-process","four ordinary",old=[("--peer-elf",str(raw/"broker.elf"))])
reject("wrong-policy","four ordinary",new=[("--policy","edf")])
reject("wrong-board","four ordinary",new=[("--board","pi4")])
reject("duplicate","only once",add=["--pubsub-service","3"])
reject("grants-disabled","topic grants require",old=[("--pubsub-service","3")])
print(json.dumps(tests,indent=2))
