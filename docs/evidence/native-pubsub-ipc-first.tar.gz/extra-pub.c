#include <jnox/ipc.h>
#include <jnox/pubsub.h>
#include <time.h>
volatile long pub_result[6];
int main(int argc,char **argv) {
    if(argc!=2) return 100;
    if(argv[1][0]=='e') {
        struct timespec now;
        if(clock_gettime(1,&now)) return 101;
        now.tv_nsec+=550000000;
        if(now.tv_nsec>=1000000000) { now.tv_sec++; now.tv_nsec-=1000000000; }
        if(clock_nanosleep(1,TIMER_ABSTIME,&now,0)) return 102;
    }
    jnox_subscription h; uint64_t seq=0; const unsigned char b=0xa5;
    pub_result[0]=jnox_subscribe(3,0,&h);
    pub_result[1]=jnox_publish(3,0,&b,1,&seq); pub_result[2]=seq;
    jnox_ipc_response a=jnox_ipc_call(1,100,UINT64_MAX);
    pub_result[3]=a.status; pub_result[4]=a.word;
    jnox_ipc_response s=jnox_ipc_call(2,200,UINT64_MAX);
    pub_result[5]=s.status;
    return pub_result[0]==-13 && !pub_result[1] && seq==1 && !a.status && a.word==100 && !s.status && s.word==200 ? 81:103;
}
