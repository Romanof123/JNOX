"""Offline first-position replay. Python 3 and GNU nm (NM override) suffice."""
import hashlib, json, os, re, struct, subprocess, sys
from pathlib import Path

root=Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve()
MASK=(1<<64)-1
BASE=0x40200000
CASES=["fifo","rr","expire-fifo","ready-fifo","expire-rr","ready-rr","legacy-fifo","legacy-rr"]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def unpack(data,signed=False):
    return list(struct.unpack("<"+("q" if signed else "Q")*(len(data)//8),data))
def symbols(path):
    out=subprocess.check_output([os.environ.get("NM","aarch64-linux-gnu-nm"),"-nS",path],text=True)
    return {v[3]:(int(v[0],16),int(v[1],16)) for ln in out.splitlines() if len(v:=ln.split())==4}
def matching(s,name):
    vals=[item for label,item in s.items() if name in label]; assert len(vals)==1,(name,vals); return vals[0]
def vals(data,offset,n):
    return int.from_bytes(data[offset:offset+n],"little")
def check_trace(path,expired):
    text=path.read_text()
    seq=[]
    for block in text.split(" PC=")[1:]:
        pc=int(block[:16],16); reg={int(n):int(v,16) for n,v in re.findall(r"X(\d+)=([0-9a-f]+)",block)}
        if pc==0x400ecc and reg[8]==52 and reg[0]==0:
            assert "EL0t" in block
            seq.append(("event",reg[3],reg[1],reg[2]))
        for site in [0x400214,0x401394,0x4003f4]:
            if reg[8]==23 and pc in (site,site+4):
                seq.append(("reply" if pc==site else "return",site,reg[0],reg[1]))
    def one(pred,after=-1):
        return next((i,x) for i,x in enumerate(seq) if i>after and pred(x))
    def event(pid,frame,after=-1):
        return one(lambda e:e[0]=="event" and e[1]==pid and e[3]==frame,after)
    wait_begin=0x3100000001050010
    pub_begin=0x3100000000030001
    commit=0x3300000000000000
    i,_=event(1,wait_begin); i,w=event(1,commit,i)
    j,_=event(0,pub_begin,i); j,pub=event(0,commit,j)
    k,_=one(lambda e:e==("reply",0x401394,pub[2],8),j)
    k,_=one(lambda e:e[:3]==("return",0x401394,0),k)
    k,_=one(lambda e:e==("reply",0x400214,w[2],10),k)
    k,res=one(lambda e:e[:2]==("return",0x400214),k)
    assert res[2]==((-116 & MASK) if expired else 0)
    assert not any(e[0]=="event" and e[1]==1 for e in seq[i+1:k+1])
    j,_=event(1,wait_begin,k); j,last=event(1,commit,j)
    j,d=event(0,0,j); assert d[2]==0
    j,_=one(lambda e:e==("reply",0x4003f4,last[2],-32&MASK),j)
    one(lambda e:e[:3]==("return",0x4003f4,0),j)
    return dict(wait_token=w[2],publication_token=pub[2],delivery_reply_status=-116 if expired else 0,
        reader_broker_calls_during_held_wait=0,terminal_wait_token=last[2],terminal_reply=-32)
def replay(case,wrapper=False):
    pkg=root/case
    cap=root/(("wrapper-" if wrapper else "cap-")+case)
    m=json.loads((pkg/"manifest.json").read_text()); n=len(m["slots"])
    assert m["commit"]=="51a9ca0e80f1b5510bda6440680983b1eb72c433" and m["tracked_changes"]==""
    assert m["kernel_elf_sha256"]==sha(pkg/"kernel.elf")
    uart=(cap/"uart.bin").read_bytes()
    if wrapper:
        ss=json.loads((cap/"session.json").read_text()); assert ss["marker"]=="EXIT 71"
        assert ss["observed_slot_exits"]=={"0":71,"1":72,"2":73,"3":0}
        for name,d in ss["hashes"].items(): assert sha(cap/name)==d
    else:
        r=json.loads((cap/"result.json").read_text())
        assert r["uart_sha256"]==sha(cap/"uart.bin") and r["ram_sha256"]==sha(cap/"ram.bin")
        assert json.loads((cap/"halted.json").read_text())["status"]=="paused"
    ram=(cap/"ram.bin").read_bytes()
    def physical(pa,size):
        assert BASE<=pa and pa+size<=BASE+len(ram)
        return ram[pa-BASE:pa-BASE+size]
    ksyms=symbols(pkg/"kernel.elf")
    def ksym(key):
        a,z=matching(ksyms,key); return physical(a,z)
    sp,extent=matching(ksyms,"6SPACES17")
    assert extent%n==0
    step=extent//n
    def walk(i,va):
        pa=sp+step*i
        for sh in [30,21,12]:
            ent=unpack(physical(pa+8*((va>>sh)&511),8))[0]
            assert ent&3==3,(case,i,hex(va),sh)
            pa=ent & 0xfffff000
        assert ent&(1<<6) and ent&(1<<11)
        return pa+(va&4095)
    def private(i,va,size):
        buf=b""
        while size:
            l=min(4096-va%4096,size)
            buf+=physical(walk(i,va),l); va+=l; size-=l
        return buf
    hashes=re.findall(rb"(?m)^NATIVE EL0 (?:PEER\d? )?ELF ([a-f0-9]{64})\r?$",uart)
    appsyms=[]; address=[]; used=set()
    for i,slot in enumerate(m["slots"]):
        f=pkg/slot["elf"]; raw=f.read_bytes()
        assert slot["slot"]==i and slot["elf_sha256"]==sha(f)==hashes[i].decode()
        if n==4: assert slot["expected_ttbr0_el1"]==((i+1)<<48)|(sp+step*i)
        sy=symbols(f); appsyms.append(sy)
        pages=set(); entry=vals(raw,24,8)
        phoff=vals(raw,32,8); phsize=vals(raw,54,2)
        for j in range(vals(raw,56,2)):
            kind,flags,off,va,pa,sz,mem,align=struct.unpack_from("<IIQQQQQQ",raw,phoff+phsize*j)
            if kind!=1 or not mem: continue
            for a in range(va&~4095,va+mem,4096): pages.add(walk(i,a)&~4095)
            if flags&1: assert private(i,va,sz)==raw[off:off+sz]
        stack=[walk(i,a) for a in range(0x1001000,0x1011000,4096)]
        assert len(stack)==len(set(stack))==16 and pages.isdisjoint(stack)
        pages.update(stack)
        assert used.isdisjoint(pages); used.update(pages)
        address.append(dict(root_pa=hex(sp+step*i),entry_pa=hex(walk(i,entry)),stack_first_pa=hex(stack[0]),private_pages=len(pages)))
    def obj(i,name):
        va,size=appsyms[i][name]
        return private(i,va,size)
    rows=[list(map(int,x.split())) for x in re.findall(rb"(?m)^NATIVE FIXED EVENT ([0-9 ]+)\r?$",uart)]
    dr=int(re.search(rb"(?m)^NATIVE FIXED DROPPED (\d+)\r?$",uart)[1])
    assert dr==unpack(ksym("7DROPPED17"))[0] and len(rows)==unpack(ksym("7RECORDS17"))[0]
    w=12+3*n
    assert w in (21,24) and all(len(r)==w for r in rows)
    if n==4: assert m["fixed_event_layout"]==dict(fields=24,ready_start=12,service_start=16,remaining_start=20,slots_per_group=4)
    trace=ksym("9DECISIONS17"); assert len(trace)==128*w*8
    assert unpack(trace[:8*w*len(rows)])==[x for r in rows for x in r]
    for idx,r in enumerate(rows):
        ready=[v for v in r[12:12+n] if v!=MASK]
        assert all(0<=v<n for v in ready) and len(ready)==len(set(ready))
        if idx:
            prev=rows[idx-1]; owner=r[3]
            assert owner==prev[4]
            for slot in range(n):
                assert r[12+n+slot]-prev[12+n+slot]==((r[0]-prev[0]) if slot==owner else 0)
        remain=r[12+2*n:]
        assert max(remain)<= (0 if m["policy"]=="fifo" else m["quantum_ticks"])
    journal=unpack(ksym("jnox_native_el0_journal")); assert journal[1]==3 and journal[10]==1
    exits=[int(s) for _,s in sorted((int(i),int(s)) for i,s in re.findall(rb"(?m)^NATIVE EL0 EXIT PID (\d+) (-?\d+)\r?$",uart))]
    report=dict(exits=exits,addresses=address,trace_rows=len(rows),trace_fields=w,trace_dropped=dr)
    traps=[journal[16+i*16:32+i*16] for i in range(min(journal[8],8))]
    ttbrs=[((i+1)<<48)|(sp+step*i) for i in range(n)]
    recorded={r[14]:r[8] for r in traps if r[7]==1}
    assert recorded==dict(zip(ttbrs,exits))
    report["observed_exit_ttbr0_el1"]=[hex(t) for t in ttbrs]
    if n==3:
        assert exits==[84]*3 and dr==0 and all(unpack(obj(i,"disabled_svc"),True)==[-38] for i in range(3))
        return report
    assert m["pubsub_service"]==dict(slot=3,authorized_clients=[0,1,2],publish_masks="100",subscribe_masks="011") and m["slots"][3]["argv"]==["/bin/app","100","011"]
    endpoint=ksym("9ENDPOINTS17"); layout=json.loads((root/"endpoint-layout.json").read_text()); ep=layout["SyncIpc<4>"]["fields"]; sl=layout["Slot"]["fields"]
    assert len(endpoint)==layout["SyncIpc<4>"]["size"]
    route=tuple(endpoint[ep["routes"]:ep["routes"]+4]); assert route in [(14,8,8,0),(14,12,8,0)]
    assert endpoint[ep["brokers"]]==8 and endpoint[ep["pending_exits"]:ep["pending_exits"]+4]==bytes(4)
    for i in range(4):
        off=ep["slots"]+i*layout["Slot"]["size"]
        assert endpoint[off+sl["alive"]]==0
        for field,typ in [("request","Option<wire_layout::Request>"),("completion","Option<(wire_layout::Completion, core::option::Option<usize>)>"),("receiving","Option<wire_layout::ReceiveMode>")]:
            fmt=layout[typ]["fields"]
            assert vals(endpoint,off+sl[field]+fmt["discriminant"],fmt["disc_size"])==fmt["None"]
    report["terminal_endpoint"]=dict(live=0,waiting_receives=0,pending_calls=0,pending_completions=0,pending_deaths=0,last_token=vals(endpoint,ep["last_token"],8))
    rep=unpack(obj(3,"pubsub_report")); report["broker_report"]=rep
    assert rep[:4]==[0x4a4e505338,0,0,0] and rep[12]==0
    if case in ("fifo","rr"):
        assert rep[4:12]==[2,5,2,8,0,0,0,0] and rep[14]==26 and exits==[71,72,73,0]
        ids=[1,2,3,4,5,6,7,8]; sizes=[0,1,7,32,11,3,19,6]
        for i,keep,idsym,szsym,dtsym in [(0,ids,"published_ids","published_sizes","published_bytes"),(1,ids,"active_ids","active_sizes","active_data"),(2,[1,2,3,4,8],"stalled_ids","stalled_sizes","stalled_data")]:
            ss=unpack(obj(i,idsym)); sizes_i=list(obj(i,szsym)); data=obj(i,dtsym)
            assert ss==keep and sizes_i==[sizes[j-1] for j in keep]
            samples=[data[k*32:k*32+s].hex() for k,s in enumerate(sizes_i)]
            assert samples==[bytes((43*j+19*b+b//2)%256 for b in range(sizes[j-1])).hex() for j in keep]
            report[idsym]=ss; report[szsym]=sizes_i; report[dtsym]=samples
        obs=unpack(obj(1,"active_observations")); assert obs==[x for j in ids for x in (1,1,0,j)]
        report["active_observations"]=[obs[i:i+4] for i in range(0,len(obs),4)]
        for i,name,want in [(2,"queue_before",[4,4,2,1]),(2,"old_handle",[6,1]),(2,"new_handle",[6,2]),(2,"stale_status",[-116]),(2,"empty_status",[-11]),(2,"wrong_publish",[-13]),(0,"publisher_subscribe_status",[-13]),(1,"active_terminal_wait",[-32])]:
            got=unpack(obj(i,name),True); assert got==want; report[name]=got
    else:
        expired=case.startswith("expire"); assert exits==[81,82,83,0]
        assert rep[4:]==[2,2,0,1,0,0,0,int(expired),0,1,5]
        pub=unpack(obj(0,"pub_result"),True); slow=unpack(obj(2,"slow_result"),True); reader=unpack(obj(1,"reader_result"),True)
        assert pub==[-13,0,1,0,100,0] and slow==[6,1,1,1,0,1,-13,1,1,0,1,165]
        assert reader[:4]==[6,1,-1,-1] and reader[4]>0
        assert reader[5:17]==([-110,0,0,1,1,0,1,1,1,165,-11,-32] if expired else [10,1,0xa5010000,0,1,0,0,0,0,0,-11,-32])
        report.update(pub_result=pub,reader_result=reader,slow_result=slow,token_order=check_trace(cap/"registers.log",expired))
    return report
result={name:replay(name) for name in CASES}
result.update({f"wrapper-{p}":replay(p,True) for p in ("fifo","rr")})
print(json.dumps(result,indent=2))
