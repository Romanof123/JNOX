#include <jnox/ipc.h>
#include <jnox/pubsub.h>
#include <time.h>
volatile long reader_result[22];
static long frame(uint64_t word,uint64_t until) {
    jnox_ipc_response r=jnox_ipc_call(3,word,until);
    return r.status?r.status:(long)r.word;
}
int main(int argc,char **argv) {
    if(argc!=2) return 100;
    int expire=argv[1][0]=='e';
    jnox_subscription h; jnox_pubsub_sample s; jnox_pubsub_observation o;
    if(jnox_subscribe(3,0,&h)) return 101;
    jnox_ipc_response f=jnox_ipc_call(2,11,UINT64_MAX);
    if(f.status) return 102;
    jnox_subscription foreign={f.word&255,f.word>>8};
    reader_result[0]=foreign.slot; reader_result[1]=foreign.generation;
    reader_result[2]=jnox_observe(3,foreign,&o); reader_result[3]=jnox_unsubscribe(3,foreign);
    if(reader_result[2]!=-1||reader_result[3]!=-1) return 103;
    if(frame(0x3100000001050010ULL,UINT64_MAX)) return 104;
    unsigned char handle[16];
    for(unsigned i=0;i<8;i++){ handle[i]=(unsigned char)(h.slot>>(8*i)); handle[i+8]=(unsigned char)(h.generation>>(8*i)); }
    for(unsigned off=0;off<16;off+=6) {
        uint64_t chunk=0x3200000000000000ULL|((uint64_t)off<<48);
        for(unsigned j=0;j<6 && j+off<16;j++) chunk|=(uint64_t)handle[off+j]<<(8*j);
        if(frame(chunk,UINT64_MAX)) return 105;
    }
    struct timespec n; if(clock_gettime(1,&n)) return 106;
    uint64_t deadline=n.tv_sec*1000000000ULL+n.tv_nsec+(expire?200000000ULL:3000000000ULL);
    reader_result[4]=deadline; reader_result[5]=frame(0x3300000000000000ULL,deadline);
    if(reader_result[5]!=(expire?-110:10)) return 107;
    // An ordinary IPC rendezvous after publication prevents an expired client from touching the broker prematurely.
    jnox_ipc_request ready=jnox_ipc_receive();
    if(ready.status||ready.word!=100) return 108;
    if(!expire){
        reader_result[6]=frame(0x3400000000000000ULL,UINT64_MAX);
        reader_result[7]=frame(0x3406000000000000ULL,UINT64_MAX);
    }
    if(jnox_observe(3,h,&o)) return 109;
    reader_result[8]=o.queued; reader_result[9]=o.high_water; reader_result[10]=o.lost; reader_result[11]=o.front_sequence;
    if(expire){
        if(jnox_receive(3,h,0,&s)) return 110;
        reader_result[12]=s.sequence; reader_result[13]=s.length; reader_result[14]=s.data[0];
    }
    reader_result[15]=jnox_receive(3,h,0,&s);
    if(reader_result[15]!=-11||jnox_ipc_reply(ready.token,100)) return 111;
    reader_result[16]=jnox_receive(3,h,1,&s);
    if(jnox_unsubscribe(3,h)) return 112;
    return reader_result[16]==-32?82:113;
}
