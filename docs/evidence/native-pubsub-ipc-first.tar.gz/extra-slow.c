#include <jnox/ipc.h>
#include <jnox/pubsub.h>
volatile long slow_result[12];
int main(void) {
    jnox_subscription h; jnox_pubsub_observation o; uint64_t id=0; unsigned char b=7;
    if(jnox_subscribe(3,0,&h)) return 100;
    slow_result[0]=h.slot; slow_result[1]=h.generation;
    jnox_ipc_request a=jnox_ipc_receive();
    if(a.status||a.word!=11||jnox_ipc_reply(a.token,(h.generation<<8)|h.slot)) return 101;
    jnox_ipc_request s=jnox_ipc_receive();
    if(s.status||s.word!=200||jnox_observe(3,h,&o)) return 102;
    slow_result[2]=o.queued; slow_result[3]=o.high_water; slow_result[4]=o.lost; slow_result[5]=o.front_sequence;
    slow_result[6]=jnox_publish(3,0,&b,1,&id);
    if(jnox_observe(3,h,&o)) return 103;
    slow_result[7]=o.queued; slow_result[8]=o.high_water; slow_result[9]=o.lost; slow_result[10]=o.front_sequence;
    jnox_pubsub_sample peek;
    if(jnox_peek(3,h,&peek)) return 104;
    slow_result[11]=peek.data[0];
    if(jnox_ipc_reply(s.token,200)) return 105;
    return slow_result[6]==-13 && slow_result[2]==1 && o.queued==1 && peek.length==1 && peek.data[0]==0xa5?83:106;
}
