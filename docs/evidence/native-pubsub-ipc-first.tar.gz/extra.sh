#!/usr/bin/env bash
set -eu
extra=$(cd "$(dirname "$0")" && pwd)
source "$extra/run.sh"
run disabled-sdk sh sdk/native-aarch64/build.sh "$extra/disabled.c" "$raw/disabled.elf"
for who in pub reader slow; do run extra-$who sh sdk/native-aarch64/build.sh --pubsub "$extra/extra-$who.c" "$raw/$who.elf"; done
for p in fifo rr; do
    rr=()
    if [[ $p = rr ]]; then rr=(--quantum-ticks 625000); fi
    run pkg-legacy-$p python3 tools/build_native_el0.py --board virt --policy "$p" "${rr[@]}" --out "$raw/legacy-$p" --elf "$raw/disabled.elf" --priority 4 --peer-elf "$raw/disabled.elf" --peer-priority 4 --peer-elf "$raw/disabled.elf" --peer-priority 4
    run cap-legacy-$p python3 "$extra/capture.py" "$src" "$raw/legacy-$p" "$raw/cap-legacy-$p" || true
    for mode in expire ready; do
        n="$mode-$p"
        run pkg-$n python3 tools/build_native_el0.py --board virt --policy "$p" "${rr[@]}" --out "$raw/$n" --elf "$raw/pub.elf" --priority 4 --arg "$mode" --peer-elf "$raw/reader.elf" --peer-priority 5 --peer-arg "$mode" --peer-elf "$raw/slow.elf" --peer-priority 6 --peer-elf "$raw/broker.elf" --peer-priority 7 --pubsub-service 3 --pubsub-publish 0:1 --pubsub-subscribe 1:1 --pubsub-subscribe 2:1 --ipc-route 0:1 --ipc-route 0:2 --ipc-route 1:2 --ipc-route 0:3 --ipc-route 1:3 --ipc-route 2:3
        run cap-$n python3 "$extra/capture.py" "$src" "$raw/$n" "$raw/cap-$n" --trace || true
    done
done
