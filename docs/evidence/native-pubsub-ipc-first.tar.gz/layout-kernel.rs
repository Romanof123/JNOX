#![no_std]
include!("endpoint-types.rs");
#[no_mangle] pub static LAYOUT: SyncIpc<4> = SyncIpc::with_broker([14,8,8,0],3);
