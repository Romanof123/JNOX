#!/usr/bin/env bash
set -euo pipefail
source "$HOME/.cargo/env"
src=${SRC:-$HOME/v384-first-src-51a9ca0}
raw=${RAW:-$HOME/v384-first-51a9ca0}
export CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true CARGO_TARGET_DIR="$raw/app-target" PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
rev=51a9ca0e80f1b5510bda6440680983b1eb72c433
cd "$src"
run() {
  local label=$1; shift
  printf '%q ' "$@" >> "$raw/commands.sh"; echo >> "$raw/commands.sh"
  local rc=0; "$@" > "$raw/$label.log" 2>&1 || rc=$?
  echo "$label $rc" | tee -a "$raw/status.txt"
  if ((rc)); then tail -15 "$raw/$label.log"; fi
  return "$rc"
}
dir=examples/native-pubsub
package() {
 local p=$1; shift
 python3 tools/build_native_el0.py --board virt --policy "$p" "$@" --out "$raw/$p" --elf "$raw/publisher.elf" --priority 4 --peer-elf "$raw/active.elf" --peer-priority 4 --peer-elf "$raw/stalled.elf" --peer-priority 4 --peer-elf "$raw/broker.elf" --peer-priority 2 --pubsub-service 3 --pubsub-publish 0:1 --pubsub-subscribe 1:1 --pubsub-subscribe 2:1 --ipc-route 0:1 --ipc-route 0:2 --ipc-route 0:3 --ipc-route 1:3 --ipc-route 2:3
}
if [[ ${1:-} = first ]]; then
 run hostcompile rustc --edition=2021 --test services/pubsub/src/state.rs -o "$raw/state-test"
 run hoststate "$raw/state-test" --test-threads=1
 run publisher sh sdk/native-aarch64/build.sh --pubsub "$dir/publisher.c" "$raw/publisher.elf"
 run active sh sdk/native-aarch64/build-rust.sh --pubsub "$dir/active/Cargo.toml" "$raw/active.elf"
 run stalled sh sdk/native-aarch64/build.sh --pubsub "$dir/stalled.c" "$raw/stalled.elf"
 run broker sh sdk/native-aarch64/build-rust.sh services/pubsub/Cargo.toml "$raw/broker.elf"
 run pkg-fifo package fifo
 run stock-capture python3 tools/native_el0_capture.py "$raw/stock-fifo" "$raw/fifo/kernel.elf" "$raw/publisher.elf" "$dir/publisher.c" "$rev" --plain --manifest "$raw/fifo/manifest.json" --expect-exit 71 || true
 run pkg-rr package rr --quantum-ticks 625000
fi
