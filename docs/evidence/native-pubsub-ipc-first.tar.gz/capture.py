"""Capture cold QEMU UART and full linked RAM through QMP, including on failed guests."""
import argparse, hashlib, json, re, shutil, subprocess, sys, time
from pathlib import Path
src, pkg, out = (Path(x).resolve() for x in sys.argv[1:4])
sys.path.insert(0,str(src/"tools"))
from ordinary_amc_capture import FLAGS
from qemu_capture import request, capture_halt
out.mkdir()
sha=lambda x: hashlib.sha256(x.read_bytes()).hexdigest()
man=json.loads((pkg/"manifest.json").read_text())
kernel=pkg/"kernel.elf"
assert sha(kernel)==man["kernel_elf_sha256"]
for s in man["slots"]: assert sha(pkg/s["elf"])==s["elf_sha256"]
sym=subprocess.check_output(["aarch64-linux-gnu-nm","-n",kernel],text=True).splitlines()
def addr(name):
    return int(next(x for x in sym if x.split()[-1]==name).split()[0],16)
base,end=addr("_start"),addr("__stack_top")
q=shutil.which("qemu-system-aarch64")
cmd=[q,*FLAGS,"-serial","file:"+str(out/"uart.bin"),"-qmp","stdio","-kernel",str(kernel)]
if "--trace" in sys.argv[4:]:
    broker=pkg/man["slots"][3]["elf"]
    assembly=subprocess.check_output(["aarch64-linux-gnu-objdump","-dC",broker],text=True)
    points=set()
    for match in re.finditer(r"(?m)^\s*([0-9a-f]+):\s*[0-9a-f]+\s+svc\s+#0x4a01",assembly):
        pc=int(match[1],16)
        points.update((pc,pc+4))
    cmd+=["-singlestep","-d","cpu,nochain","-dfilter",",".join(f"0x{x:x}+4" for x in sorted(points)),"-D",str(out/"registers.log")]
count=len(man["slots"])
meta=dict(cmd=cmd,version=subprocess.check_output([q,"--version"],text=True),qemu_sha256=sha(Path(q)),base=base,end=end,kernel=sha(kernel),commit=man["commit"],start=time.time_ns())
(out/"launch.json").write_text(json.dumps(meta,indent=2))
with (out/"stderr").open("xb") as err:
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,bufsize=0)
    try:
        class Pipe:
            write=proc.stdin.write
            readline=proc.stdout.readline
        assert "QMP" in json.loads(proc.stdout.readline())
        request(Pipe,"qmp_capabilities")
        reason="timeout"
        for i in range(3000):
            if (out/"uart.bin").exists():
                uart=(out/"uart.bin").read_bytes()
                exits=re.findall(rb"^NATIVE EL0 EXIT PID (\d+) (-?\d+)\r?\n",uart,re.M)
                if len(exits)==count:
                    reason="all exits"; break
                if re.search(rb"^NATIVE EL0 FAULT .+?\r?\n",uart,re.M):
                    reason="guest fault"; break
            if proc.poll() is not None: raise ValueError("guest stopped")
            time.sleep(.005)
        capture_halt(Pipe,out)
        request(Pipe,"pmemsave",val=base,size=end-base,filename=str(out/"ram.bin"))
        assert (out/"ram.bin").stat().st_size==end-base
        print(reason,exits,flush=True)
        (out/"result.json").write_text(json.dumps(dict(reason=reason,exits=[[int(a),int(b)] for a,b in exits],ram_sha256=sha(out/"ram.bin"),uart_sha256=sha(out/"uart.bin")),indent=2))
    finally:
        proc.terminate(); proc.wait(timeout=5)
assert reason=="all exits", reason
