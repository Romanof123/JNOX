#include <jnox/ipc.h>
volatile long disabled_svc;
int main(void) { disabled_svc=jnox_ipc_trap(52,0,0,0).status; return disabled_svc==-38?84:101; }
