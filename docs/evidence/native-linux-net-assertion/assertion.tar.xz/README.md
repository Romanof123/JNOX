# Native NIC owner assertion containment

Extract into an empty Linux directory and run `python3 -B replay.py`. Replay needs Python 3.10+, GNU nm and aarch64-linux-gnu-nm. Pyelftools 0.32 and its license are bundled.

| Capture | Profile | Guest build | Frozen observer | MAC | MTU |
|---|---|---|---|---|---|
| cold-02 | owner BRK assertion | 3cc58b803faa379bcace521489421f22da802e67 | 9cf82b246f635635a65d925f49a33be3a29e1d35 | 52:54:00:19:26:41 | 1410 |
| cold-03 | owner BRK assertion | 3cc58b803faa379bcace521489421f22da802e67 | 9cf82b246f635635a65d925f49a33be3a29e1d35 | 52:54:00:19:26:52 | 1490 |
| full-01 | ordinary lifecycle regression | 3cc58b803faa379bcace521489421f22da802e67 | 9cf82b246f635635a65d925f49a33be3a29e1d35 | 52:54:00:19:26:41 | 1410 |

Each assertion cold boot retains its armed and final sparse physical RAM, QMP stop records, UART scheduler events, QEMU instruction/MMIO/IRQ traces, external nonce, ingress stream and Ethernet PCAP. The retained kernel ELF locates both the protected exception journal and the 96-byte post-retirement FIFO decision journal. The generic scheduler event prefix carries separate retained and dropped counts. Its reason-256 coverage is reported per boot. The fault PC is checked against the live owner mapping and the BRK #0x440 instruction in the linked driver ELF. The independent reader checks the survivor's received frame, timer progress, authority denials, signed process exits and both QueueReady readbacks. The case covers a deliberate EL0 breakpoint with a single virtual NIC and one emulated CPU.

The per-build source index maps every compiler dependency to archived bytes. The full 9,403-file header digest ledger binds the compiled subset to the pinned header tree. Each original result is compared with the frozen observer, including any recorded corruption controls. For each assertion, the independent reader is run separately and its complete JSON compared with the retained report. The ordinary regression retains eight checkpoints and runs its own frozen lifecycle observer across two device generations. The five recorded host reset-model tests are under reset-controls/. Default replay authenticates the model inputs and retained test output. To repeat those host tests, run from reset-controls/ with the recorded Rust toolchain:

```sh
rustc --edition=2021 --test kernel/src/native_virtio_reset_test.rs -o /tmp/jnox-native-reset-tests
/tmp/jnox-native-reset-tests --test-threads=1
```

Individual offline commands follow.

```sh
PYTHONPATH=vendor python3 -B observers/9cf82b246f635635a65d925f49a33be3a29e1d35/tools/verify_linux_source_net_assertion.py --replay --mutation-tests --package builds/aee9e0585338e63cac77d18465f16262b6cd8fbd7180b640b2487a34e7751c3c/native --driver-manifest builds/aee9e0585338e63cac77d18465f16262b6cd8fbd7180b640b2487a34e7751c3c/imported/import.json --out captures/cold-02 --mac 52:54:00:19:26:41 --mtu 1410
PYTHONPATH=vendor python3 -B qa/replay.py builds/aee9e0585338e63cac77d18465f16262b6cd8fbd7180b640b2487a34e7751c3c captures/cold-02 source/linux/4700e3adf3b24b39dd4929e9c6d62811ba3ccea8/drivers/net/virtio_net.c
PYTHONPATH=vendor python3 -B observers/9cf82b246f635635a65d925f49a33be3a29e1d35/tools/verify_linux_source_net_assertion.py --replay --mutation-tests --package builds/aee9e0585338e63cac77d18465f16262b6cd8fbd7180b640b2487a34e7751c3c/native --driver-manifest builds/aee9e0585338e63cac77d18465f16262b6cd8fbd7180b640b2487a34e7751c3c/imported/import.json --out captures/cold-03 --mac 52:54:00:19:26:52 --mtu 1490
PYTHONPATH=vendor python3 -B qa/replay.py builds/aee9e0585338e63cac77d18465f16262b6cd8fbd7180b640b2487a34e7751c3c captures/cold-03 source/linux/4700e3adf3b24b39dd4929e9c6d62811ba3ccea8/drivers/net/virtio_net.c
PYTHONPATH=vendor python3 -B observers/9cf82b246f635635a65d925f49a33be3a29e1d35/tools/verify_linux_source_net_lifecycle.py --replay --mutation-tests --package builds/3dd3ea0aae0268c19c0042d96de0ce432950f73a7c83b3ae4ba7e1d8646d8416/native --driver-manifest builds/3dd3ea0aae0268c19c0042d96de0ce432950f73a7c83b3ae4ba7e1d8646d8416/imported/import.json --out captures/full-01 --mac 52:54:00:19:26:41 --mtu 1410
```
