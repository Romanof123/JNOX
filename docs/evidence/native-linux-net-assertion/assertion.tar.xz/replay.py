#!/usr/bin/env python3
"""Recompute the cold-boot EL0 assertion-containment evidence on Linux."""
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys

sys.dont_write_bytecode = True
from evidence_io import checksums, read, regular, require, sha

VERIFIER = "tools/verify_linux_source_net_assertion.py"
REG_VERIFIER = "tools/verify_linux_source_net_lifecycle.py"
BOARD = "docs/evidence/native-linux-net-irq-board"
PROFILE = "drivers/linux-compat/profiles/virtio-net.json"
STAGES = ("armed", "final")
REG_STAGES = ("first-probed","first-open","first-ack","first-removed","second-probed","second-open","second-ack","final")
REG_CONTROLS = {"live original ndo_open pointer","registered netdevice identity","missing first original probe entry","second-generation private RX payload"}
CONTROLS = {"wrong ELR", "wrong TTBR ASID", "wrong syndrome", "peer falsely trapped",
            "terminal decision at wrong tick","ordinary scheduler reason","wrong surviving PID","false peer decision",
            "removed live DMA authority", "no survivor timer progress", "cooperative exit", "missing second QueueReady readback"}
RAW = {"net.events","host.bin","nonce.bin","wire.pcap","machine.log","uart.log","stderr.log","launch.json",
       "result.json","observer-commit.txt","observer.sha256"}
LINUX = "4700e3adf3b24b39dd4929e9c6d62811ba3ccea8"
LINUX_HASH = "05e676f7fc4f91783c961c860b930fae33462348064887eea95be3a440282a29"
HEADERS_HASH = "901bb6ced9321e225b59395161f80a66146e3beaa9252f94c6430f545c84806b"


def git_identity(file, kind, oid):
    data = file.read_bytes()
    require(hashlib.sha1(f"{kind} {len(data)}\0".encode() + data).hexdigest() == oid, f"Git {kind} identity {file}")


def build_evidence(root, name, regression=False):
    base = root / "builds" / name
    native, imported = base / "native", base / "imported"
    pkg, imp = read(native / "manifest.json"), read(imported / "import.json")
    rev = pkg["commit"]
    require(re.fullmatch("[0-9a-f]{40}", rev) and sha(native / "manifest.json") == name and
            (pkg["tracked_changes"], pkg["board"], pkg["app"], pkg["policy"]) == ("", "virt", "process", "fifo") and
            imp["mode"] == "lifecycle-service" and len(pkg["slots"]) == 2,
            "native lifecycle build")
    if regression:
        require("lifecycle_assert_test" not in imp, "ordinary regression intake")
    else:
        trap = imp["lifecycle_assert_test"]
        require(trap["immediate"] == 0x440 and trap["trap_symbol"]["name"] == "jnox_lifecycle_assert_trap",
                "deliberate assertion import fixture")
    sources = root / "source/jnox" / rev
    git_identity(sources / "commit.raw", "commit", rev)
    require(sha(native / "kernel.elf") == pkg["kernel_elf_sha256"] and
            sha(native / "build.log") == pkg["build_log_sha256"], "kernel digest or build log")
    kernel = (native / "kernel.elf").read_bytes()
    argv = pkg["package_argv"]
    require("--linux-source-net-lifecycle" in argv and
            [argv[i+1] for i,k in enumerate(argv) if k in ("--elf","--peer-elf")] ==
            [s["input"]["path"] for s in pkg["slots"]], "selected ELF arguments")
    roles = []
    peer = imp["irq_peer"]
    spec = importlib.util.spec_from_file_location("linked_native_roots", regular(sources, "tools/native_amc_roots.py"))
    roots_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(roots_module)
    roots = roots_module.linked_roots(native / "kernel.elf", len(pkg["slots"]))
    for slot, (s, role, src, elf, digest, map_hash) in enumerate(zip(pkg["slots"], ("driver","peer"),
            ("examples/linux-source-net-lifecycle/driver.c", peer["source"]), ("service.elf","peer.elf"),
            (imp["service"]["sha256"], peer["elf"]["sha256"]), (imp["link_map_sha256"],peer["link_map_sha256"]))):
        app = regular(native, s["elf"])
        obj = ("driver.o","irq_peer.o")[slot]
        require((s["slot"],s["argv"],s["priority"]) == (slot,["/bin/app"],8) and src in imp["input_sha256_by_object"][obj],
                f"{role} slot or source")
        require(sha(app) == sha(imported / elf) == s["input"]["sha256"] == s["elf_sha256"] == digest ==
                pkg["source_sha256"][s["input"]["path"]] and app.read_bytes() in kernel and
                sha(imported / Path(elf).with_suffix(".map")) == map_hash, f"{role} link or embedded ELF")
        require(s.get("expected_ttbr0_el1", roots[slot]) == roots[slot], f"{role} linked address-space root")
        roles.append({"role": role, "slot": slot, "sha256": digest, "source": src,
                      "linked_ttbr0_el1": hex(roots[slot]), "map_sha256": map_hash})
    require(roles[0]["linked_ttbr0_el1"] != roles[1]["linked_ttbr0_el1"], "two distinct slot roots")
    for filename, item in imp["objects"].items():
        require(sha(regular(imported, filename)) == item["sha256"], f"object {filename}")
    for key in ("driver_object", "callback_object"):
        item = imp[key]
        require(sha(regular(imported, item["filename"])) == item["sha256"], key)
    for name in imp["input_sha256_by_object"]:
        regular(imported, name)
    index = read(base / "source-index.json")
    files = index["compiler_inputs"]
    require(set(files) == set(imp["input_sha256"]) and sha(sources / PROFILE) == imp["profile_sha256"],
            "compiler file inventory or import profile")
    profile = read(sources / PROFILE)
    require(profile["upstream"] == imp["upstream"] and profile["headers"] == imp["header_profile"], "intake source profile")
    upstream = imp["upstream"]
    require(upstream["commit"] == LINUX and upstream["sha256"] == imp["source"]["sha256"] == LINUX_HASH and
            upstream["path"] == "drivers/net/virtio_net.c", "pinned original Linux source")
    git_identity(regular(root, files[upstream["path"]]), "blob", upstream["git_blob_sha1"])
    header_root = root / "source/linux-headers" / HEADERS_HASH
    ledger = read(header_root / "tree.json")
    whole = hashlib.sha256()
    for path, digest in sorted(ledger.items()):
        whole.update(path.encode() + b"\0" + bytes.fromhex(digest))
    require(len(ledger) == 9403 and whole.hexdigest() == imp["header_tree_sha256"] == HEADERS_HASH, "header tree identity")
    for path, digest in profile["headers"]["generated_sha256"].items():
        require(ledger[path] == digest == sha(regular(header_root / "files", path)), f"generated header {path}")
    for path, target in files.items():
        digest = imp["input_sha256"][path]
        require(sha(regular(root, target)) == digest, f"compiler input {path}")
        if path.startswith("headers/"):
            require(ledger[path[8:]] == digest, f"header provenance {path}")
    for path, digest in pkg["kernel_build"]["config_sha256"].items():
        require(sha(regular(sources, path)) == digest, f"kernel configuration {path}")
    return {"source_commit": rev, "linux_commit": LINUX, "linux_tu_sha256": LINUX_HASH,
            "header_tree_sha256": HEADERS_HASH, "compiler_input_count": len(files), "roles": roles,
            "import_sha256": sha(imported / "import.json"), "kernel_sha256": pkg["kernel_elf_sha256"],
            "objects": {n:sha(imported / n) for n in ("virtio_net.original.o","virtio_net.packet.o","virtio_net.callback.o")}}


def python(root, args, **opts):
    env = dict(os.environ, LC_ALL="C", PYTHONPATH=str(root / "vendor"),
               PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1")
    env.pop("PYTHONOPTIMIZE", None)
    return subprocess.check_output([sys.executable, "-B", *args], cwd=root, env=env, **opts)


def observer_args(case, launch):
    base = "builds/" + case["build"]
    verifier = REG_VERIFIER if case.get("regression") else VERIFIER
    return [f"observers/{case['observer_commit']}/{verifier}", "--replay","--mutation-tests",
            "--package",base+"/native","--driver-manifest",base+"/imported/import.json",
            "--out","captures/"+case["label"],"--mac",launch["mac"],"--mtu",str(launch["mtu"])]


def journal_evidence(kernel, capture):
    table = subprocess.check_output(["aarch64-linux-gnu-nm","-S","--defined-only",kernel],text=True)
    records = [read(capture/stage/"ram.json") for stage in STAGES]

    def retained(symbol, count):
        fields, = [line.split() for line in table.splitlines() if line.split()[-1:] == [symbol]]
        addr, size = int(fields[0],16), int(fields[1],16)
        require(size == count*8, f"protected journal extent {symbol}")
        observations = []
        for ram in records:
            cursor, left = addr, size
            data = bytearray()
            while left:
                length = min(left,4096-cursor%4096)
                chunk = bytes.fromhex(ram[f"{cursor:x}/{length}"])
                require(len(chunk) == length, "protected journal checkpoint length")
                data.extend(chunk)
                cursor += length
                left -= length
            observations.append(list(struct.unpack(f"<{count}Q",data)))
        return addr, observations[0], observations[1]

    addr, before, after = retained("jnox_linux_net_assertions",20)
    require(not any(before) and not any(after[10:]) and after[0] and after[1] == 0 and
            after[3] == 0x400 and after[4] == 0xf2000440 and after[6]&31 == 0, "protected EL0 BRK journal")
    decision, previous, terminal = retained("jnox_linux_net_assert_exit",12)
    require(not any(previous) and terminal == [after[0],256,0,1,(1<<64)-5,after[5]]+[0]*6,
            "protected post-retirement FIFO decision")
    return {"physical_address":hex(addr),"armed_words":before,"final_words":after,
            "assert_exit":{"physical_address":hex(decision),"armed_words":previous,"final_words":terminal},
            "ELR_EL1":hex(after[5]),"ESR_EL1":hex(after[4]),"TTBR0_EL1":hex(after[2]),"tick":after[0]}


def trap_evidence(base, pc):
    record = read(base/"imported/import.json")["lifecycle_assert_test"]["trap_symbol"]
    require(int(record["value"],16) == pc, "journal PC and linked assertion symbol")
    elf = (base / "native/user.elf").read_bytes()
    require(elf[:6]==b"\x7fELF\x02\x01" and struct.unpack_from("<H",elf,18)[0]==183, "AArch64 ELF64 executable")
    phoff = struct.unpack_from("<Q",elf,32)[0]
    entsize, count = struct.unpack_from("<HH",elf,54)
    offsets = []
    for i in range(count):
        kind,flags,offset,va,_,size,_,_ = struct.unpack_from("<IIQQQQQQ",elf,phoff+i*entsize)
        if kind == 1 and flags&1 and va <= pc <= va+size-4:
            offsets.append(offset+pc-va)
    offset, = offsets
    ins = elf[offset:offset+4]
    require(ins == bytes.fromhex("008820d4"), "captured PC must point to linked BRK #0x440")
    return {"symbol":record["name"],"pc":hex(pc),"elf_offset":hex(offset),"instruction_bytes":ins.hex(),"immediate":0x440}


def replay(root):
    members = checksums(root)
    cases, builds, nonces = {}, {}, set()
    for case in read(root / "bundle.json")["cases"]:
        label, bid, rev = (case[k] for k in ("label","build","observer_commit"))
        require(label not in cases and re.fullmatch(r"[A-Za-z0-9][\w.-]*",label) and
                re.fullmatch("[0-9a-f]{64}",bid) and re.fullmatch("[0-9a-f]{40}",rev), "case identity")
        regression = case.get("regression", False)
        if bid not in builds:
            builds[bid] = build_evidence(root,bid,regression)
        build = builds[bid]
        base = root / "builds" / bid
        cap = root / "captures" / label
        observer = root / "observers" / rev
        git_identity(observer / "commit.raw","commit",rev)
        require((cap / "observer-commit.txt").read_text().strip() == rev and case["build_commit"] == build["source_commit"],
                f"{label} frozen revisions")
        checks = {}
        for line in (cap / "observer.sha256").read_text().splitlines():
            digest, name = line.split("  ",1)
            require(name not in checks, "duplicate frozen module")
            checks[name] = digest
        for file in (observer / "tools").glob("*.py"):
            require(sha(file) == checks["tools/"+file.name], f"observer provenance {file.name}")
        launch = read(cap / "launch.json")
        board = read(observer / BOARD / "board.json")
        require(hashlib.sha256(gzip.decompress((observer / BOARD / "virt-net.dtb.gz").read_bytes())).hexdigest() == board["sha256"]
                and board["qemu_sha256"] == launch["qemu_sha256"] and build["kernel_sha256"] == launch["kernel_sha256"]
                and build["import_sha256"] == launch["import_sha256"] and build["roles"][0]["sha256"] == launch["driver_sha256"],
                "captured QEMU and binary identity")
        stages = REG_STAGES if regression else STAGES
        inventory = RAW - {"nonce.bin"} | {"nonces.bin"} if regression else RAW
        nonce = (cap / ("nonces.bin" if regression else "nonce.bin")).read_bytes()
        values = {nonce[:8],nonce[8:]} if regression else {nonce}
        require(len(nonce)==(16 if regression else 8) and len(values)==(2 if regression else 1) and
                all(any(n) for n in values) and not values & nonces,"unique external boot nonce")
        nonces.update(values)
        require({p.name for p in cap.iterdir()} == inventory | set(stages), "raw capture inventory")
        for stage in stages:
            require({p.name for p in (cap/stage).iterdir()} == {"qmp.json","halted.json","ram.json"},f"{stage} raw inventory")
        argv = observer_args(case,launch)
        output = json.loads(python(root,argv))
        controls = output.pop("rejected_mutations")
        historical = read(cap/"result.json")
        recorded = historical.pop("rejected_mutations",controls)
        required = REG_CONTROLS if regression else CONTROLS
        require(output == historical and controls == recorded and required <= set(controls) and len(controls)==len(set(controls)),
                f"{label} replayed result and corruption controls")
        if regression:
            require(output["checkpoints"] == list(REG_STAGES) and output["peer_frames"] == 83
                    and len(output["tokens"]) == 2 and output["tokens"][0] < output["tokens"][1], "two-generation lifecycle regression")
            cases[label] = {"profile":"ordinary lifecycle regression","build_commit":build["source_commit"],"observer_commit":rev,
                    "checkpoints":list(stages),"qemu_sha256":launch["qemu_sha256"],"board_dtb_sha256":board["sha256"],
                    "pcap_sha256":sha(cap/"wire.pcap"),"nonces_hex":nonce.hex(),"observer":output,
                    "rejected_mutations":controls,"observer_argv":["python3","-B",*argv]}
            continue
        journal = journal_evidence(base/"native/kernel.elf",cap)
        require(output["protected_fifo_decision"] == journal["assert_exit"]["final_words"][:6] and
                output["el1_handler_tick"] == journal["tick"], "frozen observer FIFO decision and handling tick")
        uart = (cap/"uart.log").read_bytes()
        rows = re.findall(rb"(?m)^NATIVE FIXED EVENT (\d+) (\d+) [^\n]+\r?$",uart)
        dropped, = re.findall(rb"(?m)^NATIVE FIXED DROPPED (\d+)\r?$",uart)
        scheduler = output["scheduler"]
        require(int(dropped) == scheduler["rows_dropped"] and len(rows)==scheduler["rows_retained"] and
                any(reason == b"256" for _,reason in rows)==scheduler["reason_256_observed"],
                "bounded scheduler prefix coverage")
        independent = json.loads(python(root,case["independent_argv"]))
        require(independent == read(root/"qa"/(label+".json")), f"{label} independent retained report")
        require(independent["protected_exit"] == dict(tick=journal["tick"],reason=256,old_pid=0,next_pid=1,
                    signed_exit=-5,trap_pc=journal["ELR_EL1"]) and independent["scheduler"]["dropped"] == int(dropped)
                and independent["scheduler"]["retained"] == len(rows), "independent terminal decision and scheduler coverage")
        require(independent["pc"] == output["elr"] == journal["ELR_EL1"] and
                independent["esr"] == output["esr"] == journal["ESR_EL1"] and
                independent["root"] == output["driver_ttbr"] == journal["TTBR0_EL1"] == build["roles"][0]["linked_ttbr0_el1"]
                and output["peer_ttbr"] == build["roles"][1]["linked_ttbr0_el1"] and
                independent["tick"] == output["tick"] == journal["tick"] and
                independent["peer_elapsed_ns"] == output["peer_elapsed_ns"] >= 100000000 and
                independent["token"] == output["token"] and independent["mac"] == launch["mac"] and
                independent["mtu"] == launch["mtu"] and len(independent["armed_descriptors"]) == output["posted"],
                "independent journal, trap, DMA, or survivor mismatch")
        cases[label] = {"build_commit":build["source_commit"],"observer_commit":rev,"checkpoints":list(STAGES),
            "qemu_sha256":launch["qemu_sha256"],"board_dtb_sha256":board["sha256"],
            "nonce_hex":nonce.hex(),"pcap_sha256":sha(cap/"wire.pcap"),"journal":journal,
            "linked_trap":trap_evidence(base,int(journal["ELR_EL1"],16)),"observer":output,
            "rejected_mutations":controls,"independent":independent,"observer_argv":["python3","-B",*argv],
            "independent_argv":["python3","-B",*case["independent_argv"]]}
    reset = read(root/"reset-controls/model.json")
    log = (root/"reset-controls/result.txt").read_text()
    require(log.splitlines()[0]==reset["commit"] and re.search(r"test result: ok\. 5 passed; 0 failed;",log),
            "host reset-control record")
    for path,digest in reset["inputs"].items():
        require(sha(regular(root/"reset-controls",path))==digest and f"{digest}  {path}" in log
                and all(sha(regular(root/"source/jnox"/b["source_commit"],path))==digest for b in builds.values()),
                f"recorded reset-control source {path}")
    return {"checksummed_members":members,"builds":builds,"captures":cases,"host_reset_controls":reset}


if __name__ == "__main__":
    print(json.dumps(replay(Path(__file__).resolve().parent),indent=2))
