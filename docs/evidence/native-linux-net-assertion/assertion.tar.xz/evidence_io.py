"""File inventory and safe archive I/O for offline lifecycle evidence."""
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def regular(root, relative):
    path = Path(relative)
    require(not path.is_absolute() and ".." not in path.parts, f"invalid relative path {relative}")
    file = root / path
    require(file.is_file() and not file.is_symlink() and file.resolve().is_relative_to(root.resolve()), str(file))
    return file


def checksums(root):
    ledger = {}
    for row in (root / "SHA256SUMS").read_text().splitlines():
        digest, name = row.split("  ", 1)
        require(re.fullmatch(r"[0-9a-f]{64}", digest) and name not in ledger, "invalid or duplicate checksum")
        require(sha(regular(root, name)) == digest, f"changed archive member {name}")
        ledger[name] = digest
    require(not any(p.is_symlink() for p in root.rglob("*")), "symlink in extracted bundle")
    members = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    require(members == set(ledger) | {"SHA256SUMS"}, "archive member inventory differs")
    return len(ledger)


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def copy(file, dest, digest=None):
    require(not file.is_symlink() and file.is_file(), f"missing or linked evidence file {file}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        require(sha(dest) == sha(file), f"conflicting inputs {dest}")
    else:
        shutil.copyfile(file, dest)
    if digest:
        require(sha(dest) == digest, f"source hash mismatch {file}")


def git(repo, *args):
    return subprocess.check_output(["git", "-c", f"safe.directory={repo.resolve().as_posix()}", "-C", repo, *args])


def export(repo, rev, paths, dest):
    require(re.fullmatch("[0-9a-f]{40}", rev), "invalid Git revision")
    for item in paths:
        p = Path(item)
        require(not p.is_absolute() and ".." not in p.parts, f"invalid git path {item}")
    data = git(repo, "archive", "--format=tar", rev, "--", *sorted(paths))
    with tarfile.open(fileobj=io.BytesIO(data)) as tar:
        for member in tar:
            if member.isdir():
                continue
            require(member.isfile() and not Path(member.name).is_absolute() and ".." not in Path(member.name).parts,
                    f"nonregular or external Git member {member.name}")
            target = dest / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(member) as src, target.open("wb") as out:
                shutil.copyfileobj(src, out)
    raw = git(repo, "cat-file", "commit", rev)
    require(hashlib.sha1(f"commit {len(raw)}\0".encode() + raw).hexdigest() == rev, "Git object identity")
    (dest / "commit.raw").write_bytes(raw)


def archive(stage, path):
    with tarfile.open(path, "x:xz", preset=4) as tar:
        for file in sorted(p for p in stage.rglob("*") if p.is_file()):
            rel = file.relative_to(stage).as_posix()
            regular(stage, rel)
            info = tarfile.TarInfo(rel)
            info.size = file.stat().st_size
            info.mode = 0o644
            with file.open("rb") as data:
                tar.addfile(info, data)


def extract(archive_path, dest):
    dest.mkdir()
    seen = set()
    with tarfile.open(archive_path, "r:xz") as tar:
        for member in tar:
            path = Path(member.name)
            require(member.isfile() and not path.is_absolute() and ".." not in path.parts and path not in seen,
                    f"unsafe or duplicate member {path}")
            seen.add(path)
            target = dest / path
            target.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(member) as data, target.open("xb") as stream:
                shutil.copyfileobj(data, stream)
