#!/bin/bash
set -euo pipefail
base="$HOME/jnox406-lab"
exec 9>"$base/run.lock"
flock 9
ref="$1"
out="$base/440-assert-02/reset-controls"
mkdir "$out"
git -C "$base/src" archive "$ref" kernel/src/native_virtio_reset.rs kernel/src/native_virtio_reset_test.rs | tar -C "$out" -xf -
cd "$out"
export PATH="$HOME/.cargo/bin:$PATH"
{
  echo "$ref"
  rustc --version --verbose
  sha256sum kernel/src/native_virtio_reset{,_test}.rs
  rustc --edition=2021 --test kernel/src/native_virtio_reset_test.rs -o reset-tests
  ./reset-tests --test-threads=1
} >result.txt 2>&1
cat result.txt
