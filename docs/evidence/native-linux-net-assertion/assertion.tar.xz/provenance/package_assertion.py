#!/usr/bin/env python3
"""Package existing JNOX native EL0 BRK-containment evidence for offline replay."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import stat
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
from evidence_io import archive, copy, export, extract, git, read, regular, require, sha, write
from replay import BOARD, HEADERS_HASH, LINUX, PROFILE, RAW, REG_STAGES, REG_VERIFIER, STAGES, VERIFIER, observer_args

PM = Path(__file__).resolve().parent
LAB = Path.home() / "jnox406-lab"
KNOWN_SOURCE = {"arch/aarch64", "kernel", "boards", "examples/linux-source-net-lifecycle", PROFILE}
BUILD_TOOLS = ["tools/build_linux_source_virtio_net.py", "tools/build_native_el0.py", "tools/build_kernel.py"]


def tool_closure(repo, rev, entrypoints):
    """Follow imports only among Python modules tracked under tools/ at this revision."""
    paths = {p for p in git(repo, "ls-tree", "-r", "--name-only", rev, "--", "tools").decode().splitlines()
             if re.fullmatch(r"tools/[A-Za-z_][A-Za-z_0-9]*\.py", p)}
    selected, pending = set(), list(entrypoints)
    while pending:
        path = pending.pop()
        if path in selected:
            continue
        require(path in paths, f"missing tracked Python tool {rev}:{path}")
        selected.add(path)
        code = git(repo, "show", f"{rev}:{path}")
        for node in ast.walk(ast.parse(code)):
            if isinstance(node, ast.Import):
                names = [n.name for n in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                names = [node.module]
            else:
                continue
            for name in names:
                dependency = "tools/" + name.split(".")[0] + ".py"
                if dependency in paths and dependency not in selected:
                    pending.append(dependency)
    return selected


def header_ledger(headers, dest):
    dest.mkdir(parents=True, exist_ok=True)
    if (dest / "tree.json").exists():
        return
    records = {}
    for root, dirs, files in os.walk(headers, followlinks=False):
        directory = Path(root)
        for name in dirs:
            require(stat.S_ISDIR((directory / name).lstat().st_mode), f"linked header directory {directory / name}")
        for name in files:
            file = directory / name
            require(stat.S_ISREG(file.lstat().st_mode), f"linked or irregular header {file}")
            records[file.relative_to(headers).as_posix()] = sha(file)
    whole = hashlib.sha256()
    for name, digest in sorted(records.items()):
        whole.update(name.encode() + b"\0" + bytes.fromhex(digest))
    require(len(records) == 9403 and whole.hexdigest() == HEADERS_HASH, "pinned compiler header tree differs")
    write(dest / "tree.json", records)


def add_build(stage, args, build, bid, regression):
    dest = stage / "builds" / bid
    m, imp = read(regular(build, "native/manifest.json")), read(regular(build, "imported/import.json"))
    require(m["tracked_changes"] == "" and imp["mode"] == "lifecycle-service" and
            ("lifecycle_assert_test" not in imp if regression else imp["lifecycle_assert_test"]["immediate"] == 0x440),
            "expected clean assertion or regression build")
    native = ["manifest.json", "kernel.elf", "user.elf", "native_peer.elf", "build.log"]
    for name in native:
        copy(regular(build, Path("native") / name), dest / "native" / name)
    copy(regular(build, "build.log"), dest / "build.log")
    objects = set(imp["input_sha256_by_object"]) | set(imp["objects"]) | {imp[k]["filename"] for k in ("callback_object","driver_object")}
    for name in objects | {"service.elf","peer.elf","service.map","peer.map","import.json"}:
        require(Path(name).name == name, f"unexpected intake filename {name}")
        copy(regular(build, Path("imported") / name), dest / "imported" / name)
    rev = m["commit"]
    require(re.fullmatch("[0-9a-f]{40}", rev) and imp["header_tree_sha256"] == HEADERS_HASH, "commit or header profile")
    headers = args.headers or Path(imp["header_root"])
    source = args.linux_source or Path(imp["source"]["path"])
    hdir = stage / "source/linux-headers" / HEADERS_HASH
    header_ledger(headers, hdir)
    for path, digest in imp["header_profile"]["generated_sha256"].items():
        copy(regular(headers, path), hdir / "files" / path, digest)
    tracked = KNOWN_SOURCE | tool_closure(args.repo, rev, BUILD_TOOLS)
    inputs = {}
    for name, digest in imp["input_sha256"].items():
        path = Path(name)
        require(".." not in path.parts, f"invalid compiler path {name}")
        if name.startswith("headers/"):
            rel = path.relative_to("headers")
            target = hdir / "files" / rel
            copy(regular(headers, rel), target, digest)
        elif name == imp["upstream"]["path"]:
            require(imp["upstream"]["commit"] == LINUX and name == "drivers/net/virtio_net.c", "upstream input")
            target = stage / "source/linux" / LINUX / name
            copy(source, target, digest)
        elif path.is_absolute():
            require(path.parent.name == "build" and path.suffix in (".h",".inc"), f"unrecognized generated input {name}")
            target = dest / "imported" / path.name
            copy(regular(build, Path("imported") / path.name), target, digest)
        else:
            tracked.add(name)
            target = stage / "source/jnox" / rev / path
        inputs[name] = target.relative_to(stage).as_posix()
    export(args.repo, rev, tracked, stage / "source/jnox" / rev)
    write(dest / "source-index.json", {"commit": rev, "compiler_inputs": inputs})
    return m


def package(stage,args):
    all_cases = [*args.case,args.regression]
    labels = {c[0] for c in all_cases}
    reports = {label:Path(file) for label,file in args.report}
    require(len(labels) == len(all_cases) and set(reports) <= {c[0] for c in args.case} and len(reports) == len(args.report),
            "duplicate or unrecognized report or capture label")
    reader = args.independent_reader or args.independent_dir / "replay.py"
    copy(reader,stage/"qa/replay.py")
    cases, rows, commands = [], [], []
    for item in all_cases:
        label, directory, commit, rev = item
        regression = item == args.regression
        require(re.fullmatch(r"[A-Za-z0-9][\w.-]*",label) and all(re.fullmatch("[0-9a-f]{40}",r) for r in (commit,rev)),
                "explicit label and full capture-time commit identities")
        build = Path(directory)
        bid = sha(regular(build,"native/manifest.json"))
        require(read(regular(build,"native/manifest.json"))["commit"] == commit,"guest build commit mismatch")
        if not (stage/"builds"/bid).exists():
            add_build(stage,args,build,bid,regression)
        cap = build/label
        require(cap.is_dir() and not cap.is_symlink() and not (cap/"failure.json").exists() and
                (regular(cap,"observer-commit.txt")).read_text().strip() == rev, f"{label} failed or observer mismatch")
        stages, verifier = (REG_STAGES,REG_VERIFIER) if regression else (STAGES,VERIFIER)
        require({p.name for p in cap.iterdir() if p.is_dir()} == set(stages), f"{label} checkpoint inventory")
        dest = stage/"captures"/label
        inventory = RAW - {"nonce.bin"} | {"nonces.bin"} if regression else RAW
        for name in sorted(inventory):
            copy(regular(cap,name),dest/name)
        for which in stages:
            for file in ("ram.json","qmp.json","halted.json"):
                copy(regular(cap,Path(which)/file),dest/which/file)
        obs = stage/"observers"/rev
        if not (obs/verifier).exists():
            files = tool_closure(args.repo,rev,[verifier]) | {BOARD+"/board.json",BOARD+"/virt-net.dtb.gz"}
            export(args.repo,rev,files,obs)
        case = {"label":label,"build":bid,"build_commit":commit,"observer_commit":rev,"regression":regression}
        cases.append(case)
        launch = read(dest/"launch.json")
        cmds = [observer_args(case,launch)]
        if not regression:
            report = reports.get(label,args.independent_dir/(label+".json"))
            copy(report,stage/"qa"/(label+".json"))
            case["independent_argv"] = ["qa/replay.py","builds/"+bid,"captures/"+label,"source/linux/"+LINUX+"/drivers/net/virtio_net.c"]
            cmds.append(case["independent_argv"])
        for cmd in cmds:
            commands.append("PYTHONPATH=vendor "+shlex.join(["python3","-B",*cmd]))
        role = "ordinary lifecycle regression" if regression else "owner BRK assertion"
        rows.append(f"| {label} | {role} | {commit} | {rev} | {launch['mac']} | {launch['mtu']} |")
    reset_src = args.reset_controls
    reset_files = ["kernel/src/native_virtio_reset.rs","kernel/src/native_virtio_reset_test.rs"]
    for file in [*reset_files,"result.txt"]:
        copy(regular(reset_src,file),stage/"reset-controls"/file)
    reset_log = (stage/"reset-controls/result.txt").read_text()
    reset_commit = reset_log.splitlines()[0]
    require(re.fullmatch("[a-f0-9]{40}",reset_commit) and reset_commit in {case["build_commit"] for case in cases},
            "reset control Git commit")
    write(stage/"reset-controls/model.json",{"commit":reset_commit,
          "inputs":{file:sha(stage/"reset-controls"/file) for file in reset_files},
          "host_toolchain":reset_log.splitlines()[1],"recorded_tests":re.findall(r"(?m)^test (\w+) \.\.\. ok$",reset_log)})
    copy(PM/"reset-controls.sh",stage/"provenance/reset-controls.sh")
    for path in (args.vendor/"elftools").rglob("*.py"):
        rel = path.relative_to(args.vendor)
        copy(regular(args.vendor,rel),stage/"vendor"/rel)
    regular(stage,"vendor/elftools/elf/elffile.py")
    for name in ("LICENSE","METADATA"):
        rel = Path("pyelftools-0.32.dist-info")/name
        copy(regular(args.vendor,rel),stage/"vendor"/rel)
    copy(args.license,stage/"source/GPL-2.0")
    for file in ("replay.py","evidence_io.py"):
        copy(PM/file,stage/file)
    copy(PM/"package_assertion.py",stage/"provenance/package_assertion.py")
    for name,file in (("build.sh",args.build_script),("capture.sh",args.capture_script)):
        copy(file,stage/"provenance"/name)
    for note in args.report_note:
        require(note.suffix.lower() in (".md",".txt"), "expected text QA report")
        copy(note,stage/"qa/notes"/note.name)
    write(stage/"bundle.json",{"format":1,"profile":"native Linux-source NIC assertion containment","cases":cases})
    (stage/"README.md").write_text(
        "# Native NIC owner assertion containment\n\nExtract into an empty Linux directory and run `python3 -B replay.py`. "
        "Replay needs Python 3.10+, GNU nm and aarch64-linux-gnu-nm. Pyelftools 0.32 and its license are bundled.\n\n"
        "| Capture | Profile | Guest build | Frozen observer | MAC | MTU |\n|---|---|---|---|---|---|\n"+"\n".join(rows)+
        "\n\nEach assertion cold boot retains its armed and final sparse physical RAM, QMP stop records, UART scheduler events, "
        "QEMU instruction/MMIO/IRQ traces, external nonce, ingress stream and Ethernet PCAP. The retained kernel ELF "
        "locates both the protected exception journal and the 96-byte post-retirement FIFO decision journal. The generic "
        "scheduler event prefix carries separate retained and dropped counts. Its reason-256 coverage is reported per boot. "
        "The fault PC is checked against the live owner mapping and the BRK #0x440 "
        "instruction in the linked driver ELF. The independent reader checks the survivor's received frame, timer progress, "
        "authority denials, signed process exits and both QueueReady readbacks. The case covers a deliberate EL0 breakpoint "
        "with a single virtual NIC and one emulated CPU.\n\nThe per-build source index maps every compiler dependency "
        "to archived bytes. The full 9,403-file header digest ledger binds the compiled subset to the pinned header tree. "
        "Each original result is compared with the frozen observer, including any recorded corruption controls. "
        "For each assertion, the independent reader is run separately and its complete JSON compared with the retained report. "
        "The ordinary regression retains eight checkpoints and runs its own frozen lifecycle observer across two device generations. "
        "The five recorded host reset-model tests are under reset-controls/. Default replay authenticates the model inputs and "
        "retained test output. To repeat those host tests, run from reset-controls/ with the recorded Rust toolchain:\n\n"
        "```sh\nrustc --edition=2021 --test kernel/src/native_virtio_reset_test.rs -o /tmp/jnox-native-reset-tests\n"
        "/tmp/jnox-native-reset-tests --test-threads=1\n```\n\n"
        "Individual offline commands follow.\n\n```sh\n"+"\n".join(commands)+"\n```\n",encoding="utf-8")
    members=sorted(p for p in stage.rglob("*") if p.is_file())
    (stage/"SHA256SUMS").write_text("".join(f"{sha(p)}  {p.relative_to(stage).as_posix()}\n" for p in members))


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--case",nargs=4,action="append",required=True,metavar=("LABEL","BUILD","BUILD_COMMIT","OBSERVER_COMMIT"))
    cli.add_argument("--regression",nargs=4,required=True,metavar=("LABEL","BUILD","BUILD_COMMIT","OBSERVER_COMMIT"))
    cli.add_argument("--reset-controls",type=Path,required=True)
    cli.add_argument("--output",type=Path,required=True,help="new release directory")
    cli.add_argument("--repo",type=Path,default=LAB/"src")
    cli.add_argument("--linux-source",type=Path,help="relocated upstream virtio_net.c")
    cli.add_argument("--headers",type=Path,help="relocated pinned AArch64 kernel headers")
    cli.add_argument("--license",type=Path,default=PM.parent/"jnox424-pm/GPL-2.0")
    cli.add_argument("--vendor",type=Path,default=PM.parent/"jnox332-release-deps")
    cli.add_argument("--independent-dir",type=Path,default=PM.parent/"jnox440-independent")
    cli.add_argument("--independent-reader",type=Path)
    cli.add_argument("--report",nargs=2,action="append",default=[],metavar=("LABEL","JSON"))
    cli.add_argument("--report-note",type=Path,action="append",default=[])
    cli.add_argument("--build-script",type=Path,default=PM.parent/"jnox426-lifecycle/build.sh")
    cli.add_argument("--capture-script",type=Path,default=PM.parent/"jnox426-lifecycle/capture.sh")
    args = cli.parse_args()
    output = args.output.absolute()
    require(not output.exists(),f"output already exists {output}")
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="jnox-assert-offline-") as tmp, tempfile.TemporaryDirectory(
            prefix=".jnox440-",dir=output.parent) as pubroot:
        work, pub = Path(tmp), Path(pubroot)/"release"
        stage = work/"bundle"
        stage.mkdir()
        pub.mkdir()
        package(stage,args)
        tar = pub/"assertion.tar.xz"
        archive(stage,tar)
        fresh = work/"extracted"
        extract(tar,fresh)
        result = json.loads(subprocess.check_output([sys.executable,"-B","replay.py"],cwd=fresh))
        write(pub/"result.json",result)
        copy(fresh/"README.md",pub/"README.md")
        digest = sha(tar)
        (pub/(tar.name+".sha256")).write_text(f"{digest}  {tar.name}\n")
        require(not output.exists(),f"output appeared during packaging {output}")
        pub.rename(output)
        print(f"{digest}  {output/tar.name}")


if __name__ == "__main__":
    main()
