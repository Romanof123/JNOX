"""Independent offline AArch64 split-ring / lifecycle reader, Python 3 and GNU nm."""
import argparse
import hashlib
import json
import re
import struct
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("build", type=Path)
parser.add_argument("capture", type=Path)
parser.add_argument("source", type=Path)

args = parser.parse_args()
raw = args.capture if args.capture.is_dir() else args.build / args.capture
native = args.build / "native" if (args.build / "native").is_dir() else args.build



def check(condition, label):
    if not condition:
        raise ValueError(label)

def syms(name):
    lines = subprocess.check_output(["nm", "-n", native / name], text=True).splitlines()
    return {p[2]: int(p[0],16) for line in lines if len(p := line.split()) == 3}

class Memory:
    def __init__(self, path):
        self.data = {}
        for key, encoded in json.loads(path.read_text()).items():
            addr, size = key.split("/")
            addr, block = int(addr,16), bytes.fromhex(encoded)
            check(len(block) == int(size), "RAM length " + key)
            for i, val in enumerate(block):
                check(self.data.setdefault(addr+i,val) == val, "inconsistent overlapping RAM")
    def read(self, addr, n):
        return bytes(self.data[addr+i] for i in range(n))
    def phys(self, root, va):
        table = root
        for shift in (30,21,12):
            entry = int.from_bytes(self.read(table + 8*((va >> shift) & 511),8),"little")
            if entry & 3 != 3:
                raise KeyError("table/page invalid")
            table = entry & 0xfffffffff000
        return table + (va & 4095)
    def user_pages(self, root):
        tables = {root}
        for shift in (30,21,12):
            next_tables = set()
            for table in tables:
                entries = struct.unpack("<512Q", self.read(table,4096))
                for entry in entries:
                    if entry & 1:
                        check(entry & 3 == 3, "unexpected block mapping")
                        if shift != 12 or entry & 64:
                            next_tables.add(entry & 0xfffffffff000)
            tables = next_tables
        return tables
    def user(self, root, va, n):
        buf = bytearray()
        while len(buf) < n:
            addr = va+len(buf)
            length = min(n-len(buf),4096-addr%4096)
            buf.extend(self.read(self.phys(root,addr),length))
        return bytes(buf)
    def words(self, root, va, n):
        return struct.unpack("<"+"Q"*n,self.user(root,va,n*8))


def elf_word(path, pc):
    data = path.read_bytes()
    check(data[:6] == b"\x7fELF\x02\x01" and struct.unpack_from("<H", data, 18)[0] == 183, "AArch64 ELF")
    start = struct.unpack_from("<Q", data, 32)[0]
    stride, count = struct.unpack_from("<HH", data, 54)
    for index in range(count):
        kind, flags, offset, address, _, length, _, _ = struct.unpack_from("<II6Q", data, start + index*stride)
        if kind == 1 and flags & 1 and address <= pc <= address+length-4:
            return data[offset+pc-address:offset+pc-address+4]
    raise ValueError("ELR outside executable file segments")

def sample(name):
    folder = raw / name
    q = json.loads((folder / "qmp.json").read_text())
    h = json.loads((folder / "halted.json").read_text())
    check([c["cpu-index"] for c in q["cpus"]] == [0] and q["status"]["running"] and q["stop_return"] == {} and h["status"] == "paused" and not h["running"], "single stopped CPU")
    return Memory(folder / "ram.json")

def words(mem, symbol, count):
    return struct.unpack("<" + "Q"*count, mem.read(kernel[symbol], count*8))

kernel = syms("kernel.elf")
driver = syms("user.elf")
peer = syms("native_peer.elf")
digest = hashlib.sha256(args.source.read_bytes()).hexdigest()
check(digest == "05e676f7fc4f91783c961c860b930fae33462348064887eea95be3a440282a29", "original Linux source")
objects = subprocess.check_output(["nm", "-S", native / "kernel.elf"], text=True)
[(base, size)] = re.findall(r"(?m)^([\da-fA-F]+)\s+([\da-fA-F]+)\s+[bB]\s+\S*native_el0_mmu\S*6SPACES\S*$", objects)
r0 = int(base, 16)
r1 = r0 + int(size, 16)//2
before, after = sample("armed"), sample("final")
host = (raw / "host.bin").read_bytes()
wire = host[4:]
check(len(wire) == int.from_bytes(host[:4],"big") == 60, "external socket frame")
pcap = (raw / "wire.pcap").read_bytes()
endian = {b"\xd4\xc3\xb2\xa1":"<", b"\xa1\xb2\xc3\xd4":">"}[pcap[:4]]
captured, original = struct.unpack_from(endian+"II",pcap,32)
check(len(pcap)==40+captured and captured==original and pcap[40:] in (wire,bytes(10)+wire,bytes(12)+wire), "exact single ingress packet")
launch = json.loads((raw / "launch.json").read_text())
check(wire[:6] == bytes.fromhex(launch["mac"].replace(":","")) and wire[22:30] == (raw / "nonce.bin").read_bytes(), "external MAC and nonce")
d = before.words(r0,driver["jnox_assert_driver"],8)
token, nonce, length, posted, status, rx, tx, armed = d
check(token and nonce == int.from_bytes(wire[22:30],"big") and length==60 and status==15 and armed==1, "driver checkpoint")
ring = before.read(kernel["jnox_linux_net_queue_pool"],4096)
pool = kernel["jnox_linux_net_packet_buffers"]
slots = before.words(r0,driver["jnox_assert_rx_slots"],32)
avail, used = (struct.unpack_from("<H",ring,n)[0] for n in (514,586))
ids = struct.unpack_from("<32H",ring,516)
live = {ids[i%32] for i in range(used,avail)}
check(used==1 and 0<posted==len(live)==avail-used<=32 and max(live)<32,"pending ring")
grants = words(before,"jnox_linux_net_lifecycle_grants",96)
used_id, used_size = struct.unpack_from("<II",ring,588)
check(used_id<32 and used_size==72 and before.read(pool+1536*used_id+12,60)==wire,"received DMA frame")
for i in range(32):
    epoch, va, length = grants[i*3:i*3+3]
    if i in live:
        check((epoch,va,length)==(token,slots[i],1530) and struct.unpack_from("<QIHH",ring,16*i)==(pool+1536*i,1530,2,0),"descriptor ownership")
        before.user(r0,va,length)
    else:
        check((epoch,va,length)==(0,0,0),"stale grant")
check(not any(words(after,"jnox_linux_net_lifecycle_grants",96)) and not any(after.read(pool,64*1536)), "retired DMA")
check(not any(words(before,"jnox_linux_net_assertions",20)), "pre-fault journal")
a = words(after,"jnox_linux_net_assertions",20)
tick, actor, table, vector, esr, pc, psr, far, sp, lr = a[:10]
instruction = elf_word(native/"user.elf",pc)
opcode = int.from_bytes(instruction,"little")
check(tick and actor==0 and table==(1<<48|r0) and vector==0x400 and psr&31==0 and not any(a[10:]), "fault actor, mode and address space")
check(opcode & 0xffe0001f == 0xd4200000 and (opcode>>5)&65535 == esr&65535 == 0x440 and esr>>16==0xf200 and pc==driver["jnox_lifecycle_assert_trap"] and after.user(r0,pc,4)==instruction, "linked and live breakpoint")
for key, name in (("kernel_sha256","kernel.elf"),("driver_sha256","user.elf")):
    check(hashlib.sha256((native/name).read_bytes()).hexdigest() == launch[key], "capture ELF digest")
check(words(before,"jnox_linux_net_irq_metrics",27)[26]==0 and words(after,"jnox_linux_net_irq_metrics",27)[26]==1, "owner IRQ retirement")
peer_va = peer["jnox_assert_peer_frame"]
for mem in (before,after):
    driver_pages, peer_pages = mem.user_pages(r0), mem.user_pages(r1)
    check((mem.phys(r1,peer_va) & ~4095) not in driver_pages and (mem.phys(r0,driver["jnox_assert_driver"]) & ~4095) not in peer_pages, "foreign access to private receipt")
    for name, length in (("jnox_linux_net_queue_pool",8192),("jnox_linux_net_packet_buffers",64*1536),("jnox_linux_net_lifecycle_grants",768),("jnox_linux_net_assertions",160),("jnox_linux_net_assert_exit",96)):
        start = kernel[name] & ~4095
        reserved = set(range(start,kernel[name]+length,4096))
        check(not reserved.intersection(driver_pages | peer_pages), "userspace access to protected pool or receipt")
    check(mem.phys(r0,driver["jnox_assert_driver"])//4096 != mem.phys(r1,peer_va)//4096 and mem.user(r1,peer_va,91)==wire+bytes(31), "peer private frame")
p0,p1 = [m.words(r1,peer["jnox_assert_peer"],12) for m in (before,after)]
check(p0[:5]==p1[:5]==(token,int.from_bytes(wire[:6],"big"),nonce,60,1) and not any(p0[5:]) and p1[5]==0 and p1[6]>0 and p1[7]-p1[6]>=100000000 and p1[8:]==((1<<64)-13,)*3+(100,), "peer EOF and subsequent timer")
uart = (raw/"uart.log").read_text()
rows = [list(map(int,s.split())) for s in re.findall(r"(?m)^NATIVE FIXED EVENT ([\d ]+)$",uart)]
decision = words(after,"jnox_linux_net_assert_exit",12)
check(not any(words(before,"jnox_linux_net_assert_exit",12)), "pre-fault dispatch record")
check(decision == (tick,256,actor,1,(1<<64)-5,pc)+(0,)*6, "protected terminal decision and successor")
[dropped] = map(int,re.findall(r"(?m)^NATIVE FIXED DROPPED (\d+)$",uart))
faults = [i for i,row in enumerate(rows) if row[1]==256]
check(rows and len(faults)<=1 and all(len(row)>=7 for row in rows), "scheduler record shape")
check(not any(row[1]==3 and row[3]==0 for row in rows),"unexpected cooperative owner exit")
if faults:
    row = rows[faults[0]]
    check(row[0]==tick and row[3:7]==[actor,1,pc,sp], "scheduler disagrees with protected decision")
else:
    check(dropped>0 and rows[-1][0]<tick,"missing fault within retained scheduler interval")
later = rows[faults[0]+1:] if faults else []
check(all(row[3]!=0 and row[4]!=0 for row in later), "retired owner rescheduled")
peer_sleep = any(row[3]==1 and row[1]==2 for row in later)
peer_exit = any(row[3]==1 and row[1]==3 for row in later)
check(dropped or (peer_sleep and peer_exit),"complete scheduler log missing survivor events")
scheduler = dict(retained=len(rows), dropped=dropped, last_retained_tick=rows[-1][0],
                 fault_retained=bool(faults), peer_sleep_retained=peer_sleep, peer_exit_retained=peer_exit)
check(re.findall(r"(?m)^NATIVE EL0 EXIT PID (\d+) (-?\d+)$",uart)==[("0","-5"),("1","0")], "signed exits")
events = []
with (raw/"machine.log").open("rb") as f:
    for line in f:
        match = re.search(rb"memory_region_ops_(read|write) cpu 0 mr \S+ addr (0x[0-9a-f]+) value (0x[0-9a-f]+) size 4", line)
        if match:
            events.append((match[1],int(match[2],16),int(match[3],16)))
[nic] = {a-8 for op,a,v in events if op==b"read" and a%512==8 and v==1 and 0xa000000<=a<0xa004000}
states = [(i,v) for i,(op,a,v) in enumerate(events) if (op,a)==(b"write",nic+112)]
check([v for _,v in states]==[0,1,3,11,15,0], "hardware status")
selected, ready, ack = None, [], False
for op,a,v in events[states[-1][0]+1:]:
    if (op,a)==(b"read",nic+112):
        check(v==0,"reset readback")
        ack=True
    if (op,a)==(b"write",nic+48):
        selected=v
    if (op,a)==(b"read",nic+68):
        check(ack and v==0,"queue readback")
        ready.append(selected)
check(ready==[0,1], "both queues reset")
print(json.dumps(dict(source_sha256=digest, mac=launch["mac"],mtu=launch["mtu"], scheduler=scheduler, protected_exit=dict(tick=tick,reason=decision[1],old_pid=actor,next_pid=decision[3],signed_exit=-5,trap_pc=hex(pc)), armed_descriptors=sorted(live), token=token, tick=tick, root=hex(table), pc=hex(pc), esr=hex(esr), peer_elapsed_ns=p1[7]-p1[6], limits="One deliberate EL0 BRK, one virtual NIC, single CPU QEMU. Physical DMA isolation and other exceptions unmeasured."),indent=2))



