set -eux
cd ~/v307/clean
export CARGO_HOME="$HOME/jnox-169-first-e203caa/cargo" RUSTUP_HOME="$HOME/jnox-169-first-e203caa/rustup" RUSTUP_TOOLCHAIN=1.95.0
export PATH="$CARGO_HOME/bin:$PATH"
e=$HOME/v307/ev
sh sdk/native-aarch64/build.sh examples/native-llf/checksum.c "$e/A.elf"
sh sdk/native-aarch64/build-rust.sh examples/native-llf-rust/Cargo.toml "$e/B.elf"
for p in llf edf; do python3 tools/build_native_el0.py --out "$e/$p" --policy "$p" --elf "$e/A.elf" --job 0,6,1 --peer-elf "$e/B.elf" --peer-job 0,7,3; done
for x in short negative reject; do case "$x" in short) t=0,4,1; a=A;; negative) t=0,1,1; a=B;; reject) t=0,1,2; a=A;; esac; python3 tools/build_native_el0.py --out "$e/$x" --policy llf --elf "$e/$a.elf" --job "$t"; done
for a in A B; do aarch64-linux-gnu-objdump -d "$e/$a.elf" > "$e/$a.dis"; aarch64-linux-gnu-nm -n "$e/$a.elf" > "$e/$a.symbols"; done
qemu-system-aarch64 --version
clang --version
rustc -vV
grep -inE 'capacity|const .*usize' kernel/src/native_edf.rs | head -30
sha256sum "$e"/*.elf "$e"/*/*.elf
cd "$e"
python3 ../run.py