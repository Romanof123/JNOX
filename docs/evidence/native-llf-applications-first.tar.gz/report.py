import pathlib,re,struct,json,math,hashlib,shutil
from collections import defaultdict
e=pathlib.Path(__file__).resolve().parent/'ev'
report=[]
def put(t=''):report.append(t)
put('# #307 independent first positions / 독립 최초 실행')
put('Source af022d69bf2ad5a62798e163ea72d2daa07be0a5. Plan 7c8925603c492da34f04959f38097cc291dd4d67106d66649f7247e737c581c1. One Cortex-A72, TCG virt GICv2, 128 MiB, 62,500,000 Hz, Q=6,250,000, journal 512, 120 s timeout. Ordered ordinary/traced captures used ext4. Host terminated QEMU after terminal UART and RAM observation. Single-job terminal spelling was corrected in the external observer while the short job remained parked. No guest restart or timeout.')
put('검증자는 공개 커밋에서 C와 Rust ELF를 독립 빌드했다. 원래 LLF 일반·추적, EDF 일반·추적 순서와 최초 결과를 보존했다. 원래 장기 작업의 마감 초과와 별도 배포의 마감 준수를 각각 판정했다.')
put('')
put('| Position / 실행 | S | exit counter / deadline (signed margin = deadline − exit) | raw service A,B |')
put('|---|---:|---|---|')
rowsout={};results={};N=2**64-1
names=['llf-plain','llf-traced','edf-plain','edf-traced','short-plain','negative-plain','practical-plain','practical-traced']
for name in names:
 p=name.split('-')[0]; pair=p in ('llf','edf','practical'); typ=['A','W' if p=='practical' else 'B'] if pair else ['B' if p=='negative' else 'A'];jobs=[(6,1),(7,3)] if pair else [(1,1) if p=='negative' else (4,1)]
 log=(e/(name+'.uart')).read_text(); assert 'DROPPED 0' in log
 S,Q,hz=map(int,re.search(r'CONFIG (.*)',log)[1].split())
 ranks=[l.split()[4:] for l in log.splitlines() if ' LAXITY ' in l]
 rows=[list(map(int,l.split()[3:])) for l in log.splitlines() if ' EVENT ' in l];last=0;owner=N;remaining=[j[1] for j in jobs];service=[0]*len(jobs);ready=list(range(len(jobs))); history=[]
 for i,r in enumerate(rows):
  reason,t,k,prior,next_id=r[:5];assert k==(t-S)//Q and prior==owner and r[19]==0 and r[12]==0
  assert r[11]==((1<<len(jobs))-1 if i==0 else 0)
  if reason==4:assert r[8]==S+k*Q
  if owner!=N:
   assert r[5]==rows[i-1][7] and r[6]==t-r[5];service[owner]+=r[6]
   remaining[owner]=max(1,remaining[owner]-(k-last))
   if reason==3: remaining[owner]=None
  keys=[(d-k-rem if p!='edf' else d) if rem is not None else None for (d,c),rem in zip(jobs,remaining)]
  options=[x for x in range(len(jobs)) if remaining[x] is not None]
  expected=min(options,key=lambda x:(keys[x],x!=owner,x)) if options else N
  assert r[27:27+len(jobs)]==[N if v is None else v for v in remaining] and next_id==expected and service==r[24:24+len(jobs)]
  if p!='edf':assert ranks[i]==['NA' if v is None else str(v) for v in keys]
  history.append(dict(k=k,reason=reason,sample=t,compare=r[8],running=next_id,ranks=keys,service=list(service),saved=r[20:22],restored=r[22:24],ready_code=r[33],skipped=r[19]))
  last=k;owner=next_id
 exposures=[]
 for i,app in enumerate(typ):
  buf=(e/f'{name}-private{i}.bin').read_bytes()
  if app=='A': val=struct.unpack_from('<Q',buf,8)[0];count=struct.unpack_from('<I',buf,16)[0];assert val==sum((17*j+3)%256 for j in range(4096))*16 and count==16;status=17
  elif app=='B':val=struct.unpack_from('<16Q',buf,8);count=struct.unpack_from('<I',buf)[0];assert val==(256*131072,)*16 and count==131072;status=29
  else:count,*val=struct.unpack_from('<10I',buf);assert val==[262144*math.comb(8,j) for j in range(9)] and count==67108864;status=sum((j+1)**2*v for j,v in enumerate(val))%251
  assert (f'EXIT PID {i} {status}' if pair else f'EL0 EXIT {status}') in log
  deadline=S+jobs[i][0]*Q;ex=rows[-1][30+i];exposures.append(f'{ex} / {deadline} ({deadline-ex:+})')
  results.setdefault(name,[]).append(dict(app=app,product=val,progress=count,status=status,exit=ex,deadline=deadline))
 if pair and p!='edf':
  assert [r[4] for r in rows[:4]]==[1,1,0,1] and rows[2][20:22]==rows[3][22:24] and rows[2][34]==rows[3][35]
 rowsout[name]=history
 put(f'| {name} | {S} | '+', '.join(exposures)+' | '+', '.join(map(str,service))+' |')
put('')
put('Original LLF selected B at k0, retained B on 4/4 at k1, and selected A at 3/4 at k2. Both ready at all three samples, no intervening syscall or release. Model finishes A3, B4. EDF entered A first on both originals. SHA-256 A 086de07c44bbd68540b9fb7149c3f32b5a360e1cc8a4514eb6500413e8bc873e, B e077a9b23513fda4d3f371dc21a9e5d6f36aabc98e31d9720e96a4ea83d3468c. Symbols/disassembly show volatile source-byte load and per-bin increment in B. QEMU traced EL0 IRQ saved 0x400040, kernel recorded SP 0x%x. Initial return entered A at 0x400000; A exit SVC returned to B at 0x400040 on the saved SP. First ordinary run retained terminal private RAM only.'%rowsout['llf-traced'][2]['saved'][1])
obs=json.loads((e/'llf-traced-observations.json').read_text())
for idx in (2,4):
 c=[s[2][1][1] for s in obs if s[1]==idx and len(s[2])==2]
 put(f'Traced B completed-block range with {idx} published journal rows: {min(c)}–{max(c)}.')
put('원래 두 정책 모두 모든 실제 제품을 확인했다. 호스트가 QEMU의 128 MiB 게스트 RAM에서 각 슬롯의 페이지 테이블을 순회한 후 사설 페이지를 읽었다. A는 16블록 합 8,355,840, B는 131,072블록 및 16개 빈 각각 33,554,432, 종료값은 각각 17과 29였다. 별도 실용 배포에서 같은 A와 기본 weighted Rust 앱은 일반 및 추적 모두 마감 이내 완료했다. Rust 앱은 67,108,864개 샘플을 집계했고 아홉 빈 전체와 종료값 197을 대조했다. 두 배포는 같은 커널 소스와 스케줄링 정책으로 각자 내장한 ELF가 다른 커널 이미지를 사용했다.')
put('Long solo B observed −1 at k1 and continued to the complete product. Short A finished within its deadline. Rejected (0,1,2) printed REFUSED 8 and FAULT 14 before EL0 entry. CLI and raw Cargo missing/extra tuple controls failed. Host suite passed 163 tests. Inherited historical linked EDF/LLF and external return witnesses retain their original scope. This run independently exercised native EDF in the matching pair. No board or integrated-load timing qualification.')
put('단독 장기 작업의 음수 여유시간과 실제 마감 초과 후 정상 완료를 확인했다. 과수요 패키지는 사용자 실행 전에 거부됐다. 외부 예외 추적은 실제 경로와 복귀 PC를 보여 주며, 커널 기록은 실행 프레임·SP·카운터를 제공한다. 실제 보드 또는 통합 부하의 시간 보장은 검증 범위 밖이다.')
(e/'reconstruction.json').write_text(json.dumps(rowsout,indent=1))
(e/'products.json').write_text(json.dumps(results,indent=1))
(e/'report.en-ko.md').write_text('\n\n'.join(report).replace('|\n\n|','|\n|')+'\n')