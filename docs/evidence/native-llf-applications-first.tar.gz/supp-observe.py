import os,struct,subprocess,pathlib,time,json,signal
e=pathlib.Path('/home/ywcho/v307/ev')
for name in ['practical-plain','practical-traced']:
 policy=name.split('-')[0]
 if (e/(name+'.json')).exists(): continue
 syms=subprocess.check_output(['aarch64-linux-gnu-nm','-S',e/policy/'kernel.elf'],text=True).splitlines()
 addr=lambda s:int(next(l.split()[0] for l in syms if s in l),16)
 spaces=addr('6SPACES'); used=addr('4USED'); stride=0x415000
 counts={'practical':2,'llf':2,'edf':2}.get(policy,1)
 samples=[]
 while not (e/(name+'.uart')).exists(): time.sleep(.005)
 pid=None
 while pid is None:
  for proc in pathlib.Path('/proc').glob('[0-9]*'):
   try: args=(proc/'cmdline').read_bytes().split(b'\0')
   except OSError: continue
   if args[0]==b'qemu-system-aarch64' and os.fsencode(e/policy/'kernel.elf') in args and (b'-d' in args)==name.endswith('traced'):
    pid=int(proc.name);break
  if not pid: time.sleep(.005)
 while True:
  maps=pathlib.Path(f'/proc/{pid}/maps').read_text().splitlines()
  bases=[int(l.split('-')[0],16) for l in maps if 'rw-p' in l and int(l.split()[0].split('-')[1],16)-int(l.split('-')[0],16)==128*1024**2]
  if bases: break
  time.sleep(.005)
 fd=os.open(f'/proc/{pid}/mem',os.O_RDONLY)
 def read(pa,n):return os.pread(fd,n,bases[0]+pa-0x40000000)
 def u64(pa):return struct.unpack('<Q',read(pa,8))[0]
 while True:
  cells=[]
  for i in range(counts):
   base=spaces+i*stride
   leaf=(u64(base)&0xfffff000)
   if not leaf:break
   table=u64(leaf+16)&0xfffff000
   if not table:break
   page=u64(table+(16 if i==1 else 24))&0xfffff000
   if not page:break
   block=0 if i or policy=='negative' else 16
   cells.append((page,struct.unpack('<I',read(page+block,4))[0]))
  if cells:samples.append([time.monotonic_ns(),u64(used),cells])
  uart=(e/(name+'.uart')).read_text(errors='replace')
  done=('EXIT PID 1 197' if counts==2 else ('REFUSED' if policy=='reject' else 'NATIVE EL0 EXIT ')) in uart
  if done:
   for i,(pa,count) in enumerate(cells):
    (e/f'{name}-private{i}.bin').write_bytes(read(pa,136))
   (e/(name+'-observations.json')).write_text(json.dumps(samples))
   os.close(fd)
   print(name,pid,cells,flush=True)
   os.kill(pid,signal.SIGTERM)
   break
  time.sleep(.005)