set -eux
cd ~/v307/clean
export CARGO_HOME="$HOME/jnox-169-first-e203caa/cargo" RUSTUP_HOME="$HOME/jnox-169-first-e203caa/rustup" RUSTUP_TOOLCHAIN=1.95.0
export PATH="$CARGO_HOME/bin:$PATH"
e=$HOME/v307/ev
sh sdk/native-aarch64/build-rust.sh examples/native-weighted-rust/Cargo.toml "$e/W.elf"
python3 tools/build_native_el0.py --out "$e/practical" --policy llf --elf "$e/A.elf" --job 0,6,1 --peer-elf "$e/W.elf" --peer-job 0,7,3
aarch64-linux-gnu-nm -n "$e/W.elf" > "$e/W.symbols"
aarch64-linux-gnu-objdump -d "$e/W.elf" > "$e/W.dis"
cat "$e/W.symbols"
sha256sum "$e/W.elf" "$e/practical/kernel.elf"
cd "$e"
python3 ../supp-run.py