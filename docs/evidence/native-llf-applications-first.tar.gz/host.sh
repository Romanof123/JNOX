set -eux
cd ~/v307/clean
export CARGO_HOME="$HOME/jnox-169-first-e203caa/cargo" RUSTUP_HOME="$HOME/jnox-169-first-e203caa/rustup" RUSTUP_TOOLCHAIN=1.95.0
export PATH="$CARGO_HOME/bin:$PATH"
e=$HOME/v307/ev
rustc --edition=2021 --test tools/scheduling_tests.rs -o "$HOME/v307/host-tests"
"$HOME/v307/host-tests" > "$e/host-tests.log"
for x in missing extra; do
 if [ "$x" = missing ]; then set -- --elf "$e/A.elf" --job 0,6,1 --peer-elf "$e/B.elf"; else set -- --elf "$e/A.elf" --job 0,6,1 --peer-job 0,7,3; fi
 if python3 tools/build_native_el0.py --out "$HOME/v307/bad-$x" --policy llf "$@" > "$e/cli-$x.log" 2>&1; then exit 91; fi
done
cd kernel
export JNOX_BOARD=virt JNOX_PROFILE=native JNOX_APP=process JNOX_NATIVE_POLICY=llf JNOX_NATIVE_ELF="$e/A.elf" JNOX_NATIVE_ELF_SHA256="$(sha256sum "$e/A.elf" | cut -d' ' -f1)" JNOX_NATIVE_PEER_ELF="$e/B.elf" JNOX_NATIVE_PEER_ELF_SHA256="$(sha256sum "$e/B.elf" | cut -d' ' -f1)" CARGO_TARGET_DIR="$HOME/v307/raw"
for x in missing extra; do
 if [ "$x" = missing ]; then export JNOX_NATIVE_EDF_JOBS=0,6,1; else export JNOX_NATIVE_EDF_JOBS='0,6,1;0,7,3;0,9,1'; fi
 if cargo build --release --target aarch64-unknown-none > "$e/raw-$x.log" 2>&1; then exit 92; fi
done