from pathlib import Path
import hashlib,tarfile,shutil,json,math
root=Path(__file__).resolve().parent
e=root/'ev'
seq=(5,5,6)
deadline=5
assert [(v>deadline) for v in (5,6)]==[False,True]
(e/'deadline-endpoints.json').write_text(json.dumps([dict(exit=v,deadline=deadline,miss=v>deadline) for v in (5,6)]))
with (e/'report.en-ko.md').open('a') as f:
 f.write('\nPhysical endpoint host controls classified equal counter as on time and +1 as late. Original plain LLF lacked pre-switch external progress samples. Traced LLF supplied both sides. The practical plain run also retained terminal RAM only. QEMU IRQ trace identifies IRQ exception class, with PPI30 attribution from the configured guest timer/GIC path.\n')
 f.write('\n실용 배포의 9개 빈은 순서대로 262144, 2097152, 7340032, 14680064, 18350080, 14680064, 7340032, 2097152, 262144였다. 최초 일반 LLF의 선점 전 외부 진행량은 미관측이며 최초 추적 실행에서 선점 전후 진행량을 확인했다.\n')
files=list(e.glob('*'))
files=[p for p in files if p.is_file()]+[p for d in e.iterdir() if d.is_dir() for p in d.iterdir() if p.is_file()]+[root/f for f in ['build.sh','run.py','observe.py','host.sh','supp.sh','supp-run.py','supp-observe.py','report.py','pack.py']]
out=root/'first307.tar.gz'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ids=root/'SHA256SUMS'
ids.write_text(''.join(f'{digest(p)}  {p.relative_to(root)}\n' for p in sorted(files)))
with tarfile.open(out,'w:gz') as t:
 for p in files+[ids]:t.add(p,arcname=p.relative_to(root))
dest=Path('/mnt/d/codex/.jnox-work/307-independent-af022d6')
dest.mkdir(exist_ok=True)
for p in (out,e/'report.en-ko.md',ids):shutil.copyfile(p,dest/p.name);assert digest(p)==digest(dest/p.name)
print(out.stat().st_size,digest(out),digest(e/'report.en-ko.md'))