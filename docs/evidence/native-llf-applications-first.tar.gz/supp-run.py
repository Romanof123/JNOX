import pathlib,subprocess,time,json
e=pathlib.Path.cwd()
for name in ['practical-plain','practical-traced']:
 p,trace=name.split('-')
 cmd=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-no-reboot','-serial','stdio','-kernel',str(e/p/'kernel.elf')]
 if trace=='traced': cmd+=['-d','int','-D',str(e/(name+'.trace'))]
 with open(name+'.uart','xb',buffering=0) as f:
  start=time.monotonic()
  try: rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=120).returncode
  except subprocess.TimeoutExpired: rc=124
 (e/(name+'.json')).write_text(json.dumps(dict(command=cmd,rc=rc,seconds=time.monotonic()-start)))
 print(name,rc,flush=True)