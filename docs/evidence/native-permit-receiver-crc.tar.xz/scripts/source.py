"""Authenticate the two Git commit records, build-input blobs and the equal public trial tree."""
import hashlib, os, tarfile, sys
from pathlib import Path
root=Path(sys.argv[1]); refs=root/'source-bundles'
old='52e4a8b23897801a418da23cac18fefca4cea35b'; measured=os.environ.get('MEASURED_CANDIDATE','4cc9254b0957b88bcaa1c5e5f7f54afa15a93764');public='94c54b7da88cb93eaf65c2c2d95c3d0687b500e2'
def obj(kind,data):return hashlib.sha1(kind+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()
def verify_commit(rev,expected):
    raw=(refs/(rev+'.commit')).read_bytes()
    assert obj(b'commit',raw)==rev and raw.startswith(b'tree '+expected.encode()+b'\n')
public_tree='63d603f00b0d6747574980e06f22c03cbdb9a57c'
verify_commit(old,'aa185fdf2ee73cd1633153ab4ce7ddd6577bf321');verify_commit(measured,public_tree)
if (refs/(public+'.commit')).exists():verify_commit(public,public_tree)
inputs={}
for rev in (old,measured):
    expected={v.split('\t',1)[1]:v.split()[2] for v in (refs/(rev+'.ls-tree')).read_text().splitlines()}
    actual={}
    with tarfile.open(refs/(rev+'.tar.gz')) as archive:
        for member in archive:
            if member.isfile():actual[member.name]=obj(b'blob',archive.extractfile(member).read())
            elif member.issym():actual[member.name]=obj(b'blob',member.linkname.encode())
    assert actual==expected
    inputs[rev]=actual
    print('source id',rev,'verified build-input blobs',len(actual),'privileged source',actual['kernel/src/native_safety_channel.rs'])
assert inputs[old].keys()==inputs[measured].keys()
assert [p for p in inputs[old] if inputs[old][p]!=inputs[measured][p]]==['sdk/native-safety-channel/src/lib.rs']

