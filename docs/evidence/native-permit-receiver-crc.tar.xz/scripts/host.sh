#!/usr/bin/env bash
set -euo pipefail
lab=${1:?evidence directory}
sdir=$(cd "$(dirname "$0")" && pwd)
lab=$(realpath "$lab")
export PATH="$HOME/.cargo/bin:$PATH" LC_ALL=C TZ=UTC
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
for rev in 52e4a8b23897801a418da23cac18fefca4cea35b ${MEASURED_CANDIDATE:-4cc9254b0957b88bcaa1c5e5f7f54afa15a93764}; do
  src="$tmp/$rev"; mkdir -p "$src"
  tar -xzf "$lab/source-bundles/$rev.tar.gz" -C "$src" sdk/native-safety-channel
  cargo test --offline --manifest-path "$src/sdk/native-safety-channel/Cargo.toml"
  rustc --edition=2021 --crate-type rlib --crate-name jnox_safety_channel -C opt-level=3 "$src/sdk/native-safety-channel/src/lib.rs" -o "$tmp/libjnox_safety_channel.rlib"
  rustc --edition=2021 -C opt-level=3 "$sdir/host.rs" --extern "jnox_safety_channel=$tmp/libjnox_safety_channel.rlib" -o "$tmp/test"
  echo "independent zlib and Rust state replay $rev"; "$tmp/test"
done
