#!/usr/bin/env bash
# Usage: bash scripts/reproduce.sh /absolute/path/to/JNOX /fresh/WSL/lab
set -eu
repo=$(realpath "${1:?local JNOX checkout containing the two public commits}")
export LAB_ROOT=${2:?new directory for captures}
test ! -e "$LAB_ROOT"
packet=$(cd "$(dirname "$0")/.." && pwd)
export MEASURED_CANDIDATE=94c54b7da88cb93eaf65c2c2d95c3d0687b500e2
test "$(git -C "$repo" rev-parse "$MEASURED_CANDIDATE^{tree}")" = 63d603f00b0d6747574980e06f22c03cbdb9a57c
test "$(git -C "$repo" rev-parse '52e4a8b23897801a418da23cac18fefca4cea35b^{tree}')" = aa185fdf2ee73cd1633153ab4ce7ddd6577bf321
export OBJECTS=$(git -C "$repo" rev-parse --path-format=absolute --git-path objects)
export FIXTURE_DIR="$packet/fixtures"
bash "$packet/scripts/campaign.sh"
bash "$packet/scripts/replay.sh" "$LAB_ROOT"
