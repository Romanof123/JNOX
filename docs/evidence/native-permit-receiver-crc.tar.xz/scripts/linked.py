import csv, os, difflib, hashlib, json, re, struct, subprocess, sys, zlib
from pathlib import Path
from score import sha, symtab
root=Path(sys.argv[1]).resolve()
out=root/'results'; site=out/'disassembly';site.mkdir(exist_ok=True)
def h(data):return hashlib.sha256(data).hexdigest()
def section(file,name):
    data=file.read_bytes(); first,=struct.unpack_from('<Q',data,40); size,count,stridx=struct.unpack_from('<HHH',data,58)
    sections=[struct.unpack_from('<IIQQQQIIQQ',data,first+i*size) for i in range(count)]; st=sections[stridx]
    names=data[st[4]:st[4]+st[5]]
    s,=[s for s in sections if names[s[0]:].split(b'\0')[0].decode()==name]
    return s[3],data[s[4]:s[4]+s[5]]
def field(file,name,sec):
    addr,n=symtab(file)[name]; st,data=section(file,sec);return data[addr-st:addr-st+n]
def disasm(file):
    text=subprocess.check_output(['aarch64-linux-gnu-objdump','-drC',file],text=True)
    return {int(m[1],16):m[2].rstrip() for line in text.splitlines() if (m:=re.match(r'^\s*([0-9a-f]+):\s+[a-f0-9]+\s+(.+)$',line))}
old='52e4a8b23897801a418da23cac18fefca4cea35b';new=os.environ.get('MEASURED_CANDIDATE','4cc9254b0957b88bcaa1c5e5f7f54afa15a93764')
func='jnox_kernel::native_el0::safety::Session::commit'
kernel=[]
for p in ('fifo','rr'):
 for c in ('healthy','overrun','invalid','live'):
    a,b=[root/'pkg'/f'{r[:9]}-fused-{p}-{c}'/'kernel.elf' for r in (old,new)]
    start,x=section(a,'.text');bstart,y=section(b,'.text')
    assert start==bstart and len(x)==len(y)
    off=[i for i in range(0,len(x),4) if x[i:i+4]!=y[i:i+4]]
    sa,sb=disasm(a),disasm(b)
    file=site/f'{p}-{c}.tsv'
    with file.open('w') as f:
        f.write('address\tbaseline\tcandidate\n')
        for i in off:f.write(f'0x{start+i:x}\t{sa.get(start+i,"?")}\t{sb.get(start+i,"?")}\n')
    fx,fy=[field(t,func,'.text') for t in (a,b)]
    kernel.append(dict(policy=p,case=c,old_elf=sha(a),new_elf=sha(b),old_text=h(x),new_text=h(y),text_4byte_words=len(x)//4,different_4byte_words=len(off),protected_commit_address=hex(symtab(a)[func][0]),protected_commit_bytes_match=fx==fy,old_commit_sha=h(fx),new_commit_sha=h(fy),old_rodata_bytes=len(section(a,'.rodata')[1]),new_rodata_bytes=len(section(b,'.rodata')[1]),old_data_sha=h(section(a,'.data')[1]),new_data_sha=h(section(b,'.data')[1])))
    print(file.name, len(off),'/',len(x)//4,'changed; same protected commit',fx==fy)
with (out/'linked-kernels.json').open('w') as f:json.dump(kernel,f,indent=2);f.write('\n')
for r in (old,new):
    app=root/'apps'/r/'controller.elf';symbol='jnox_safety_channel::CRC32_TABLE'
    assert (r==new)==(symbol in symtab(app))
    if r==new:
        table=b''.join(struct.pack('<I',zlib.crc32(bytes([i]),0xffffffff)^0xffffffff) for i in range(256))
        assert table==field(app,symbol,'.rodata') and symtab(app)[symbol][1]==1024
        print('CRC table matches 256 zlib-derived entries',h(table))
    ds=disasm(app)
    with (site/f'{r[:9]}-decode.txt').open('w') as f:
        for fn in ('jnox_safety_channel::decode','jnox_safety_channel::crc32'):
            if fn not in symtab(app):continue
            addr,n=symtab(app)[fn];f.write(f'{fn} 0x{addr:x} {n} bytes\n')
            for i in range(addr,addr+n,4):f.write(f'{i:#x} {ds.get(i,"?")}\n')
    print(r,app.stat().st_size,{name:len(section(app,name)[1]) for name in ('.text','.rodata')})

