#!/usr/bin/env bash
set -euo pipefail
lab=${LAB_ROOT:-$HOME/permit389-receiver-crc-first}
history=${HISTORY_ROOT:-$HOME/permit389-hotpath-independent}
objects=${OBJECTS:-/mnt/d/codex/.jnox-work/policy-v1/.git/objects}
export PATH="$HOME/.cargo/bin:$PATH" LC_ALL=C TZ=UTC CARGO_BUILD_JOBS=1 PYTHONDONTWRITEBYTECODE=1
unset RUSTFLAGS CARGO_TARGET_DIR PYTHONPATH
while read -r v; do unset "$v"; done < <(compgen -e | sed -n '/^JNOX_/p')
old=52e4a8b23897801a418da23cac18fefca4cea35b
new=${MEASURED_CANDIDATE:-4cc9254b0957b88bcaa1c5e5f7f54afa15a93764}
test ! -e "$lab"
mkdir -p "$lab"/{apps,logs,pkg,runs,source-bundles,build-input,tools,fixtures}
git init --quiet "$lab/src"
realpath "$objects" > "$lab/src/.git/objects/info/alternates"
cd "$lab/src"
git sparse-checkout init --cone
git sparse-checkout set arch boards examples kernel sdk services tools trace verification
for nm in sender supervisor; do cp "${FIXTURE_DIR:-$history/apps}/$nm.elf" "$lab/fixtures/$nm.elf"; done
echo "a126746f393b98c22c69fb92eb26d2883f228a90269633a8a40bdc4d47e33a48  $lab/fixtures/sender.elf
9267d8ae6f318b728522af79f5d1651d9c9fe5b47a6edd08291a087cbb12fa54  $lab/fixtures/supervisor.elf" | sha256sum -c -
{ date -u; uname -a; rustc -Vv; cargo -V; clang --version; qemu-system-aarch64 --version; sha256sum "$(command -v qemu-system-aarch64)"; git --version; python3 -V; lscpu; } > "$lab/logs/host.txt"
# Stock SDK requests exactly one mktemp -d. Give it an exclusive fresh
# directory at the same absolute path so its rustc link-arg strings match.
cat > "$lab/tools/mktemp" <<'SH'
#!/bin/sh
set -eu
[ "$#" = 1 ] && [ "$1" = -d ]
mkdir -m 700 "$FIXED_SDK_TMP"
printf '%s\n' "$FIXED_SDK_TMP"
SH
chmod +x "$lab/tools/mktemp"
buildapp(){
  local slot=$1
  CARGO_TARGET_DIR="$lab/app-target" FIXED_SDK_TMP="$lab/sdk-link" PATH="$lab/tools:$PATH" sh sdk/native-aarch64/build-rust.sh "examples/native-safety-admission/$slot/Cargo.toml" "$lab/build-input/$slot.elf"
}
package(){
  local ref=$1 mode=$2 p=$3 c=$4
  local q=()
  [ "$p" != rr ] || q=(--quantum-ticks 625000)
  local key="${ref:0:9}-$mode-$p-$c"
  (set -x; python3 tools/build_native_el0.py --out "$lab/package-out" --board virt --policy "$p" "${q[@]}" --elf "$lab/build-input/sender.elf" --peer-elf "$lab/build-input/controller.elf" --peer-elf "$lab/build-input/supervisor.elf" --arg "$c" --peer-arg "$c" --peer-arg fused-phase --peer2-arg "$c" --priority 6 --peer-priority 7 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel --safety-qualification) > "$lab/logs/$key.build.log" 2>&1
  mv "$lab/package-out" "$lab/pkg/$key"
  echo "packaged $key"
}
for rev in "$old" "$new"; do
  git checkout --quiet --detach "$rev"
  git cat-file -p "$rev" > "$lab/source-bundles/$rev.commit"
  git ls-tree -r "$rev" -- arch boards examples kernel sdk services tools trace verification > "$lab/source-bundles/$rev.ls-tree"
  git archive --format=tar.gz -o "$lab/source-bundles/$rev.tar.gz" "$rev" arch boards examples kernel sdk services tools trace verification
  git diff "$old" "$rev" -- arch boards examples kernel sdk services tools trace verification > "$lab/source-bundles/$rev.diff"
  mkdir -p "$lab/apps/$rev"
  cp "$lab/fixtures/"*.elf "$lab/build-input/"
  buildapp controller > "$lab/logs/$rev.controller.build.log" 2>&1
  mv "$lab/app-target" "$lab/target-$rev"
  cp "$lab/build-input/"*.elf "$lab/apps/$rev/"
  test -z "$(git status --short --untracked-files=no)"
  for p in fifo rr; do for c in healthy overrun invalid live; do package "$rev" fused "$p" "$c"; done; done
  if [ "$rev" = "$new" ]; then
    mkdir "$lab/apps/all-$rev"
    for slot in sender supervisor; do buildapp "$slot" > "$lab/logs/$rev.$slot.build.log" 2>&1; done
    cp "$lab/build-input/"*.elf "$lab/apps/all-$rev/"
    for p in fifo rr; do package "$rev" all "$p" healthy; done
  fi
done
n=0
boot(){
  local ref=$1 mode=$2 p=$3 c=$4
  n=$((n+1))
  local key="${ref:0:9}-$mode-$p-$c"
  local pkg="$lab/pkg/$key" dest="$lab/runs/$(printf %03d "$n")-$key"
  mkdir "$dest"
  date -u +%FT%T.%NZ > "$dest/start.utc"
  set +e
  (set -x; python3 tools/native_el0_capture.py "$dest/cap" "$pkg/kernel.elf" "$pkg/user.elf" examples/native-safety-admission/sender/src/main.rs "$ref" --manifest "$pkg/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608) > "$dest/capture.log" 2>&1
  local rc=$?
  set -e
  date -u +%FT%T.%NZ > "$dest/finish.utc"
  echo "$rc" > "$dest/status"
  echo "boot $n $key status=$rc"
  return "$rc"
}
for p in fifo rr; do for c in healthy overrun; do
  for rev in "$old" "$new" "$new" "$old" "$new" "$old" "$old" "$new"; do boot "$rev" fused "$p" "$c"; done
done; done
for p in fifo rr; do for c in invalid live; do for rev in "$new" "$old"; do boot "$rev" fused "$p" "$c"; done; done; done
for p in fifo rr; do boot "$new" all "$p" healthy; done
echo finished
