"""Regenerate phase, operation and provenance rows directly from the recorded boot and input ELFs."""
from pathlib import Path
from statistics import median
import csv, hashlib, json, struct, sys, zlib
from score import chunks, sha, signed, symtab
base=Path(sys.argv[1]).resolve()
out=base/'results'
boots=json.loads((out/'boots.json').read_text())
def save_csv(name,rows):
    with (out/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for row in rows for k in row)))
        w.writeheader();w.writerows(rows)
def rows(lines,tag):
    return [list(map(int,line[len(tag):].split())) for line in lines if line.startswith(tag+' ')]
def section_info(file):
    data=file.read_bytes()
    first,=struct.unpack_from('<Q',data,40); size,count,stridx=struct.unpack_from('<HHH',data,58)
    sections=[struct.unpack_from('<IIQQQQIIQQ',data,first+i*size) for i in range(count)]
    names=sections[stridx]
    st=data[names[4]:names[4]+names[5]]
    return {st[s[0]:].split(b'\0')[0].decode():(s[3],data[s[4]:s[4]+s[5]]) for s in sections if s[1]==1}
def field(x,name):
    va,n=symtab(x)[name]
    for base_addr,mem in section_info(x).values():
        if base_addr<=va and va+n<=base_addr+len(mem):return mem[va-base_addr:va-base_addr+n]
    raise AssertionError(name)
def hashed(data):return hashlib.sha256(data).hexdigest()
def label(p):return ('A','B')[p['phase']-1]+str(p['job'])
phases=[];frames=[];timings=[];bindings=[];agg=[]
for b in boots:
    run=base/'runs'/b['run']; cap=run/'cap'; pkg=base/'pkg'/run.name.split('-',1)[1]
    m=json.loads((pkg/'manifest.json').read_text())
    assert sha(pkg/'build.log')==m['build_log_sha256']
    assert all(sha(pkg/s['elf'])==s['elf_sha256'] for s in m['slots'])
    assert sha(pkg/'kernel.elf')==m['kernel_elf_sha256']
    assert [m[k] for k in ['board','app','profile']]==['virt','process','native']
    assert m['ipc_routes']==[{'caller':2,'server':0},{'caller':2,'server':1}]
    assert m['loan_route']=={'producer':0,'consumer':1}
    assert b['functional'] and not b['qual_loss'] and not b['safety_loss']
    assert len(b['controller'])==len(b['phases'])==32
    assert all(v['hi'] is not None and v['block'] is not None and v['lo']<=v['hi'] for v in b['phases'])
    assert b['pub']==b['pub_ok']==b['rx']==8
    lines=(cap/'uart.bin').read_text().splitlines(); q=rows(lines,'NATIVE QUAL ROW'); ev=rows(lines,'NATIVE SAFETY EVENT')
    privatestate=(0,0); seen=[]; acks=[]; empty=0; miss=len(b['misses'])
    for i,(p,ctl) in enumerate(zip(b['phases'],b['controller'])):
        n=label(p); start,stop=p['marks'][1:]; selected=q[start:stop+1]
        a=[v for v in selected if v[1:4]==[4,1,63]]; assert len(a)==2
        start_check,end_complete=a
        middle=[v for v in ev if start_check[7]<=v[1]<=end_complete[5]]
        recv,=[v for v in middle if v[0]==6 and v[2:4]==[1,35]]
        got=signed(recv[4]); assert got==signed(ctl[3]); assert ctl[0]==p['target']
        assert ctl[11:13]==ctl[13:15]
        release=[v for v in middle if v[0]==6 and v[2:4]==[1,36]]
        commit=[v for v in middle if v[0]==5 and v[2:5]==[1,60,2]]
        commit_svc=[v for v in selected if v[1:5]==[4,1,60,2]]
        raw=[v for v in middle if v[0]==7]
        check_ev,=[v for v in ev if v[0]==12 and v[3]==1 and start_check[5]<=v[2]<=v[1]<=start_check[7]]
        complete_ev,=[v for v in ev if v[0]==10 and end_complete[5]<=v[2]<=v[3]<=end_complete[7]]
        kind='empty' if got==-11 else ('accepted' if ctl[4]==0 else 'rejected')
        d=dict(run=b['run'],kind=kind,policy=b['policy'],case=b['case'],mode=b['role'],build='A' if b['rev'].startswith('52e') else 'B',phase=n,index=i,nominal=p['target'],phase_lo=p['lo'],phase_hi=p['hi'],prewake=p['prewake'],wait_row=p['wait'],ready_row=p['ready'],dispatch_row=p['dispatch'],stage1=p['marks'][0],stage2=start,stage3=stop,block_row=p['block'],check_row=start_check[0],complete_row=end_complete[0],protected_check=check_ev[2],protected_complete_lo=complete_ev[2],protected_complete_hi=complete_ev[3],receive=got,receive_journal=recv[1],private_sequence=ctl[13],private_issue=ctl[14],private_enabled=ctl[16],private_faulted=ctl[17],protected_flags=ctl[10],protected_sequence=ctl[11],protected_issue=ctl[12],crc_sample=ctl[6] or None)
        if got==-11:
            assert not release and not raw and not commit and not commit_svc and ctl[6]==0
            empty+=1
        else:
            assert got==0 and len(release)==len(raw)==1 and release[0][4]==0
            rr=release[0]; r=raw[0]
            assert r[2]==recv[7]==rr[6] and recv[8]==rr[8]==44
            wire=b''.join(x.to_bytes(8,'little') for x in r[4:])[:44]
            ix,=[k for k,s in enumerate(b['sender_rows']) if s[6]==r[2] and s[8]==0]
            assert wire==bytes.fromhex(b['sender_bytes'][ix]); sender=b['sender_rows'][ix]
            gen,seq,issue=struct.unpack_from('<QQQ',wire,8); stored,=struct.unpack_from('<I',wire,40)
            crc=zlib.crc32(wire[:40]); assert [seq,issue]==sender[4:6];assert gen==1
            assert wire[:8]==bytes([1,1,44,0,1,0,1,1]) and wire[32:36]==(20).to_bytes(4,'little') and wire[36] in (0,1) and wire[37:40]==bytes(3)
            accepted=ctl[4]==0; assert len(commit)==len(commit_svc)==int(accepted)
            assert rr[1]<=ctl[6]<=end_complete[5]
            if accepted:
                co=commit[0]; svc=commit_svc[0]
                assert ctl[5]==co[5]==0 and co[6:9]==[gen,seq,issue] and stored==crc
                assert ctl[6]<=svc[5]<=co[1]<=svc[7] and tuple(ctl[13:15])==(seq,issue)
                d.update(commit_svc_entry=svc[5],commit_journal=co[1],commit_service_ticks=svc[7]-svc[5],crc_sample_to_commit_entry=svc[5]-ctl[6],release_to_commit_journal=co[1]-rr[1])
                acks.append(seq)
            else:
                assert tuple(ctl[13:15])==privatestate and stored!=crc and ctl[4] in (2,17)
            d.update(handle=rr[6],wire_sequence=seq,release_journal=rr[1],release_to_crc_sample=ctl[6]-rr[1],local_status=ctl[4])
            frames.append(dict(run=b['run'],phase=n,source_index=ix,handle=r[2],generation=gen,sequence=seq,issue=issue,permit=wire[36],encoded_le_crc=f'{stored:08x}',zlib_crc=f'{crc:08x}',wire_sha256=hashed(wire),wire_hex=wire.hex(),local_status=ctl[4],commit=int(accepted)))
            seen.append(seq)
        privatestate=tuple(ctl[13:15]);phases.append(d)
    assert empty==24
    case=b['case']
    assert seen==([1,2,3,4,4,4,4,4] if case=='invalid' else list(range(1,9)))
    assert acks==([1,2,3] if case=='invalid' else list(range(1,9)))
    assert b['private_rejections']==([2,17,17,17,17] if case=='invalid' else [])
    assert b['first_pair']==625000 or case=='live'
    assert b['output']==([0,0] if case=='live' and b['first_pair']!=625000 else [1,1])
    if case=='overrun':
        s,e,num=b['overrun'];assert e-s>=68750 and 1<=num<=4096 and 8 in b['misses']
    if case=='invalid':assert all(p[13]==3 for p in b['controller'] if p[4] in (2,17)) and b['controller'][-1][17]==1
    if case=='live':assert b['first_pair']!=625000 and not any(p[16] for p in b['controller'])
    if case=='healthy':assert b['controller'][-1][16]==0 and b['controller'][-1][13]==8
    timings.append(dict(run=b['run'],case=case,policy=b['policy'],build='A' if b['rev'].startswith('52e') else 'B',mode=b['role'],empty=empty,accepted=len(acks),rejected=len(b['private_rejections']),first_pair=b['first_pair'],output18=b['output'][0],output37=b['output'][1],endpoint_misses=miss,unbounded=len(b['unbounded']),prewake=sum(p['prewake'] for p in b['phases']),max_phase=max(p['hi'] for p in b['phases']),max_job=max(156250+p['hi'] for p in b['phases'] if p['phase']==2),max_sender=max((p['hi'] or 0) for p in b['sender']),open_sender=sum(p['hi'] is None for p in b['sender']),max_check_gap=max(b['check_gap']),max_complete_gap=max(v[1] for v in b['complete_gap']),max_grid_irq=b['max_grid_irq'],fixed_dropped=b['fixed_loss'],spin_ticks=b['overrun'][1]-b['overrun'][0],phase_A0_lower=b['phases'][0]['lo']))
    bindings.append(dict(run=run.name,source_commit=b['rev'],kernel=m['kernel_elf_sha256'],sender=m['slots'][0]['elf_sha256'],controller=m['slots'][1]['elf_sha256'],supervisor=m['slots'][2]['elf_sha256'],stderr=sha(cap/'stderr'),session=sha(cap/'session.json'),ram=sha(cap/'ram.bin'),uart=sha(cap/'uart.bin'),launch=sha(cap/'launch.json')))
save_csv('phases.csv',phases);save_csv('frames.csv',frames);save_csv('bindings.csv',bindings);save_csv('per-boot.csv',timings)
for policy in ('fifo','rr'):
  for case in ('healthy','overrun'):
    for build in ('A','B'):
      group=[p for p in phases if p['mode']=='fused' and p['case']==case and p['policy']==policy and p['build']==build]
      first=[p for p in group if p.get('wire_sequence')==1]
      b0=[p for p in group if p['phase']=='B0'];a0=[p for p in group if p['phase']=='A0']
      non=[p for p in b0 if p['kind']=='accepted'];empty=[p for p in b0 if p['kind']=='empty']
      assert len(first)==len(b0)==len(a0)==4 and len(group)==128
      ops=[p for p in group if p['kind']=='accepted']
      f=lambda field,ls:[p[field] for p in ls]
      span=lambda col,ls:[min(f(col,ls)),median(f(col,ls)),max(f(col,ls))] if ls else []
      agg.append(dict(policy=policy,case=case,build=build,A0=span('phase_hi',a0),A0_min_lower=min(f('phase_lo',a0)),first_placement=f('phase',first),first_release_sample=span('release_to_crc_sample',first),B0_accepted=len(non),B0_frame_release_sample=span('release_to_crc_sample',non),B0_frame_full=span('phase_hi',non),B0_empty_full=span('phase_hi',empty),all_phase_misses=sum(p['phase_lo']>62500 for p in group),full_max=max(f('phase_hi',group)),all_release_sample=span('release_to_crc_sample',ops),warm_release_sample=span('release_to_crc_sample',[p for p in ops if p['wire_sequence']>=2])))
(out/'summary.json').write_text(json.dumps(agg,indent=2)+'\n')
print('phase records',len(phases),'frames',len(frames),'boots',len(timings))
for r in agg:print(r)
print('core/gaps/sender/irq', [(k,max(t[k] for t in timings)) for k in ('max_job','max_complete_gap','max_check_gap','max_sender','max_grid_irq')])
print('open endpoints, not prewoken, fixed losses:',sum(t['unbounded'] for t in timings),sum(32-t['prewake'] for t in timings),min(t['fixed_dropped'] for t in timings),max(t['fixed_dropped'] for t in timings))

