#!/usr/bin/env bash
set -euo pipefail
root=$HOME/permit389-receiver-crc-first
win=/mnt/d/codex/permit389-receiver-crc-first
packet="$root/packet"
mkdir "$packet"
mkdir -p "$packet"/{scripts,pkg,logs}
cp -al "$root"/{fixtures,apps,runs,results,source-bundles} "$packet/"
cp "$root/logs/"* "$packet/logs/"
cp "$win/campaign.log" "$packet/logs/"
cp "$win/REPORT.en-ko.md" "$packet/"
for f in campaign.sh reproduce.sh replay.sh reduce.py pairs.py linked.py host.sh host.rs score.py source.py seal.sh; do cp "$win/$f" "$packet/scripts/"; done
for pkg in "$root"/pkg/*; do
  dest="$packet/pkg/$(basename "$pkg")"
  mkdir "$dest"
  cp -al "$pkg/"*.elf "$pkg/build.log" "$pkg/manifest.json" "$dest/"
done
# Canonicalize duplicate binaries on the packet copy (hash-checked).
python3 - "$packet" <<'PY'
import hashlib,os,sys
from pathlib import Path
seen={}
for f in sorted(Path(sys.argv[1]).rglob('*.elf')):
    key=hashlib.sha256(f.read_bytes()).hexdigest()
    if key in seen and not os.path.samefile(seen[key],f):
        tmp=f.with_suffix('.same')
        os.link(seen[key],tmp);os.replace(tmp,f)
    else:seen[key]=f
PY
cd "$packet"
export LC_ALL=C TZ=UTC PYTHONDONTWRITEBYTECODE=1
bash scripts/replay.sh . > "$root/offline-replay.log" 2>&1
cp "$root/offline-replay.log" logs/
find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
sha256sum --quiet -c SHA256SUMS
archive=native-permit-controller-crc-first.tar.gz
tar -cf - --sort=name --owner=0 --group=0 --numeric-owner --mtime=@0 . | gzip -n -6 > "$win/$archive"
mkdir "$root/unpack-check"
cd "$root/unpack-check"
tar -xzf "$win/$archive"
sha256sum --quiet -c SHA256SUMS
bash scripts/replay.sh . > "$root/transport-replay.log" 2>&1
sha256sum --quiet -c SHA256SUMS
cd "$win"
sha256sum "$archive" > "$archive.sha256"
cat "$archive.sha256"
ls -lh "$archive"

