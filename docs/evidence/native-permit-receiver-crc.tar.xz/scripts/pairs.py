import csv, statistics, sys
from pathlib import Path
r=Path(sys.argv[1])/'results'
with (r/'phases.csv').open() as fd:
    first=[x for x in csv.DictReader(fd) if x['wire_sequence']=='1' and x['mode']=='fused' and x['case'] in ('healthy','overrun')]
pairs=[]
for a,b in zip(first[::2],first[1::2]):
    order=a['build']+b['build']; a,b=sorted((a,b),key=lambda v:v['build'])
    assert order in ('AB','BA') and a['case']==b['case'] and a['policy']==b['policy']
    ua,ub=[int(v['release_to_crc_sample']) for v in (a,b)]
    pairs.append(dict(policy=a['policy'],case=a['case'],order=order,baseline_run=a['run'],candidate_run=b['run'],baseline_phase=a['phase'],candidate_phase=b['phase'],same_phase=a['phase']==b['phase'],baseline_release_sample=ua,candidate_release_sample=ub,candidate_minus_baseline=ub-ua))
with (r/'first-frame-pairs.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
for cond in (True,False):print('same actual phase',cond,[v['candidate_minus_baseline'] for v in pairs if v['same_phase']==cond])

