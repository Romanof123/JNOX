#!/usr/bin/env bash
set -eu
export LC_ALL=C TZ=UTC PYTHONDONTWRITEBYTECODE=1
root=$(realpath "${1:-.}")
sdir=$(cd "$(dirname "$0")" && pwd)
python3 "$sdir/source.py" "$root"
python3 "$sdir/score.py" "$root"
python3 "$sdir/reduce.py" "$root"
python3 "$sdir/pairs.py" "$root"
python3 "$sdir/linked.py" "$root"
bash "$sdir/host.sh" "$root"

