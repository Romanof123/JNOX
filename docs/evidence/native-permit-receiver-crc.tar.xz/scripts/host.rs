extern crate jnox_safety_channel as sdk;
use sdk::{crc32, decode, encode, Error, Permit, Receiver};
use std::os::raw::{c_uint,c_ulong};
#[link(name="z")]
extern "C" { #[link_name="crc32"] fn z_crc32(init:c_ulong, p:*const u8, n:c_uint)->c_ulong; }
fn reference(bytes:&[u8])->u32 { unsafe { z_crc32(0,bytes.as_ptr(),bytes.len().try_into().unwrap()) as u32 } }
fn compare(bytes:&[u8]) { assert_eq!(crc32(bytes),reference(bytes),"{:x?}",bytes); }
fn main() {
    assert_eq!(crc32(&[]),0);
    assert_eq!(crc32(b"123456789"),0xcbf43926);
    compare(&[]); compare(b"123456789");
    for a in 0..=255u8 {
        compare(&[a]);
        for b in 0..=255u8 { compare(&[a,b]); }
    }
    let lengths=[3usize,4,7,8,9,15,16,31,39,40,41,43,44,45,63,64,127,128,255,256,257,1023,4096];
    for len in lengths {
        for seed in 0..8u32 {
            let mut x=seed.wrapping_add(17);
            let bytes:Vec<u8>=(0..len).map(|_| { x=x.wrapping_mul(1664525).wrapping_add(1013904223); (x >> 24) as u8 }).collect();
            compare(&bytes);
        }
    }
    let mut r=Receiver::new(1000).unwrap();
    r.begin_activation(0).unwrap(); r.open(2,1,0).unwrap();
    let make=|sequence,issue,permit| Permit{generation:1,sequence,issue,permit};
    let p=make(1,0,true); let first=encode(p).unwrap();
    assert_eq!(&first[40..],&[0x70,0x6e,0x56,0xe3]); assert_eq!(decode(&first),Ok(p));
    r.accept(&first,||0).unwrap();
    r.begin_activation(10).unwrap(); r.accept(&encode(make(2,10,true)).unwrap(),||10).unwrap();
    r.begin_activation(11).unwrap(); r.rearm(2,1,11).unwrap();
    r.begin_activation(12).unwrap(); let snap=r.snapshot();
    let next=make(3,12,false); let wire=encode(next).unwrap();
    assert_eq!(reference(&wire[..40]).to_le_bytes(),wire[40..]); assert!(snap.enabled);
    for bit in 0..352 {
        let mut bad=wire; bad[bit/8]^=1<<(bit%8);
        compare(&bad[..40]); assert_eq!(decode(&bad),Err(Error::Crc));
        let mut trial=r; assert_eq!(trial.accept(&bad,||12),Err(Error::Crc)); assert_eq!(trial.snapshot(),snap);
    }
    let mut trial=r;
    let mut wire_bad=wire; wire_bad[37]=2;
    let crc=reference(&wire_bad[..40]); wire_bad[40..].copy_from_slice(&crc.to_le_bytes());
    assert_eq!(trial.accept(&wire_bad,||12),Err(Error::Format)); assert_eq!(trial.snapshot(),snap);
    trial.accept(&wire,||12).unwrap(); assert_eq!(trial.snapshot().sequence,3); assert!(!trial.snapshot().enabled);
    let mut expired=r; let mut broken=wire; broken[0]^=1; assert_eq!(expired.accept(&broken,||30),Err(Error::Expired)); assert!(expired.snapshot().faulted); assert!(!expired.snapshot().enabled); assert_eq!(expired.snapshot().sequence,2);
    println!("zlib matched empty, 123456789=cbf43926, 256 single bytes, 65536 two-byte strings, {} deterministic multi-byte buffers. Golden 40-byte wire CRC e3566e70. Compared all 320 protected-data and 32 checksum flips with private decode and protected model snapshots. Matched semantic rejection, accepted withdrawal, and equality-expiry first.",lengths.len()*8);
}
