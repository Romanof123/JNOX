import subprocess,itertools
from verify import forecast
items=[]; expected=[]
for s,h,w,m,weight,f in itertools.product([0,1,2,2**64-1],[0,3,24,48,64,65],[0,1,3,24,48,65],[3,7,15],[(1,2,4),(0,2,4),(16,16,16),(1,17,1)],[(1,1,1),(5,3,11),(6,3,11),(0,2,4),(48,1,1)]):
 items.append(' '.join(map(str,[s,h,w,m,*weight,*f]))); v=forecast(s,h,w,m,weight,f)
 if v is None: expected.append('invalid');continue
 fail=v[3];expected.append(' '.join(map(str,[*v[2],*(fail[:3] if fail else (999,999,0))])))
out=subprocess.run(['./probe'],input='\n'.join(items),text=True,capture_output=True,check=True).stdout.splitlines()
assert out==expected
print(len(out),'actual policy comparisons,',sum(x!='invalid' for x in out),'valid')
