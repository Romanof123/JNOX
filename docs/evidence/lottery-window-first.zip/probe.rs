#[path="../first270-602b/kernel/src/feedback_policy.rs"] mod feedback_policy;
#[path="../first270-602b/kernel/src/proportional_policy.rs"] mod proportional_policy;
use proportional_policy::WindowInput;
fn main(){
 use std::io::{self,BufRead};
 for line in io::stdin().lock().lines(){let line=line.unwrap();let a:Vec<u64>=line.split_whitespace().map(|v|v.parse().unwrap()).collect();
 let x=WindowInput{seed:a[0],horizon:a[1] as usize,width:a[2] as usize,ready:a[3] as u32,weights:[a[4] as u8,a[5] as u8,a[6] as u8],floors:[a[7] as u8,a[8] as u8,a[9] as u8]};
 if let Some(r)=x.analyze(){let(s,i,n)=r.first_short.unwrap_or((999,999,0));println!("{} {} {} {} {} {}",r.minimum[0],r.minimum[1],r.minimum[2],s,i,n);}else{println!("invalid");}}
}
