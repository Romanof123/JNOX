import zipfile,hashlib,pathlib,json
p=pathlib.Path('/mnt/d/codex/jnox268-269-baseline.zip')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='5e21b68e1d7f0d6c897873ce459b44423370fbf640666e6a5f096b52cab2b61e'
z=zipfile.ZipFile(p); ds={}
for name in ['lottery1','lottery2','lottery-miss','stride','stride-delay','proportional-bench']:
 b=z.read('new/'+name+'/kernel.elf'); folder=pathlib.Path(name+('-feature' if name=='proportional-bench' else '')); c=(folder/'kernel.elf').read_bytes()
 print(name,b==c,(folder/'uart').read_text().splitlines()[-1]); score='new/'+name+'/score.json'
 ds[name]={'baseline_sha256':hashlib.sha256(b).hexdigest(),'candidate_sha256':hashlib.sha256(c).hexdigest(),'equal':b==c,'first_baseline':json.loads(z.read(score)) if score in z.namelist() else z.read('new/'+name+'/boot/run-1/uart').decode(),'candidate_terminal':(folder/'uart').read_text().splitlines()[-1]}
pathlib.Path('comparison.json').write_text(json.dumps(ds,indent=2))
