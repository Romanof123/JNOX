from pathlib import Path
import json,re,hashlib
M=2**64-1
def forecast(seed,h=48,w=24,mask=7,weights=(1,2,4),floors=(1,1,1)):
 if not(1<=h<=64 and 1<=w<=h and mask==7 and len(weights)==len(floors)==3 and all(1<=v<=16 for v in weights) and all(1<=v<=w for v in floors) and sum(floors)<=w):return None
 t=sum(weights); state=seed; ds=[]
 for slot in range(h):
  before=state; words=[]
  while True:
   state=(state+0x9e3779b97f4a7c15)&M; z=state
   z=((z^(z>>30))*0xbf58476d1ce4e5b9)&M; z=((z^(z>>27))*0x94d049bb133111eb)&M; z^=z>>31; words.append(z)
   if z>=2**64%t:break
  ticket=z%t; owner=next(i for i in range(3) if ticket<sum(weights[:i+1]))
  ds.append((before,state,words,ticket,owner))
 ids=[x[-1] for x in ds]; wins=[[ids[s:s+w].count(i) for i in range(3)] for s in range(h-w+1)]
 return ds,wins,[min(x[i] for x in wins) for i in range(3)],next(((s,i,x[i],floors[i]) for s,x in enumerate(wins) for i in range(3) if x[i]<floors[i]),None)
for bad in [dict(h=0),dict(h=65),dict(w=0),dict(w=49),dict(weights=(0,2,4)),dict(weights=(17,2,4)),dict(mask=3),dict(mask=15),dict(floors=(0,2,4)),dict(floors=(25,1,1)),dict(floors=(10,10,10)),dict(w=1),dict(weights=(1,2))]: assert forecast(1,**bad) is None
assert len(forecast(1,w=48)[1])==1
for mode,case,seed,floors in [(5,'lottery-window1',1,(5,3,11)),(6,'lottery-window2',2,(1,7,10)),(7,'lottery-window-tight',1,(6,3,11))]:
 d=Path(case); ds,windows,mins,fail=forecast(seed,floors=floors); lines=(d/'uart').read_text().splitlines()
 assert lines[:3]==['JNOX M1 BOOT','JNOX M1 READY','PROP RAW 1'] and lines[-1]=='PROP END 0 0 0 0 0'
 rows=[list(map(int,l.split())) for l in lines[3:-1]]
 def tag(t):return [r[1:] for r in rows if r[0]==t]
 assert tag(15)==[[mode,seed,48,24,7,262657]] and tag(16)==[[*floors,seed,seed,int(not fail)]] and tag(17)==[[*mins,0,0,0]]
 exc=(d/'exceptions').read_text(); receipts=[]; costs=[]
 if fail:
  assert fail==(24,0,5,6) and rows[-1]==[18,24,48,0,5,6,0] and len(rows)==4 and not exc
 else:
  assert len(tag(19))==48 and len(tag(12))==144 and len(tag(3))==len(tag(4))==48 and not tag(18)
  regs=tag(2); assert all(r[0]==i and r[2]-r[1]==16384 and r[4]==i+1 for i,r in enumerate(regs)) and all(a[2]<=b[1] for a,b in zip(regs,regs[1:]))
  freq,tick=tag(1)[0][2:4];assert freq==100*tick
  erets=[int(x,16) for x in re.findall('Exception return .* PC (0x[0-9a-f]+)',exc)]
  stops=[int(x,16) for x in re.findall('with ELR (0x[0-9a-f]+)',exc)]
  assert exc.count('Taking exception')==exc.count('Taking exception 5 [IRQ]')==len(erets)==len(stops)==49
  prior={}; counts=[0]*3; snapshots=[[0,i+1,0,0] for i in range(3)]
  for turn in range(49):
   k=max(0,turn-1); owner=ds[k][-1] if turn else 3
   ret,end=tag(14)[2*turn:2*turn+2]; start,cmp,ptr,pc=tag(7)[turn][2:]; fr,rpc,stamp,stop=tag(8)[turn][2:]
   assert ret[:5]==[k,owner,0,ptr,pc] and end[:3]==[k,owner,1] and regs[owner][1]<=end[3]<regs[owner][2] and regs[owner][1]<=ptr<regs[owner][2]
   assert tag(7)[turn][:2]==tag(8)[turn][:2]==[k,owner] and (fr,rpc)==(ptr,pc) and pc==erets[turn] and end[4]==stops[turn]
   assert (ret[3:]==prior[owner] if owner in prior else pc==regs[owner][3]); prior[owner]=end[3:]
   assert tag(13)[turn]==[k if turn else M,30,5,0,0,0] and cmp-start==tick and start<=stamp<=stop and cmp<=stop
   if not turn:continue
   before,after,words,ticket,who=ds[k];lo=(0,1,3)[who];hi=(1,3,7)[who]
   assert tag(3)[k]==[k,before,after,len(words),words[-1],ticket] and tag(4)[k]==[k,7,7,lo,hi,who]
   whole,rem=divmod(stop-start,tick);assert tag(9)[k]==[k,who,1,end[4],stop,whole] and tag(10)[k]==[k,0,0,0,rem,end[3]]
   n=counts[who]; block=[(37*who+11*n+j)%256 for j in range(16)]; val=[sum(block),sum(b%4==0 for b in block),max(block)][who]
   receipt=tag(19)[k];assert receipt[:4]==[k,who,n,val] and stamp<=receipt[4]<=stop and regs[who][1]<=receipt[5]<regs[who][2]
   counts[who]+=1;snapshots[who]=[n+1,val,*receipt[4:]]
   assert tag(12)[k*3:k*3+3]==[[k,i,*snapshots[i]] for i in range(3)]
   receipts.append([k,who,n,block,val,*receipt[4:]]); costs.append([start,cmp,stamp,stop,stop-start,whole,rem])
  assert counts==([11,14,23] if seed==1 else [8,17,23])
 (d/'independent.json').write_text(json.dumps(dict(draws=ds,windows=windows,minima=mins,first_failure=fail,receipts=receipts,counter_samples=costs)))
 print(case,'PASS',mins,fail)
