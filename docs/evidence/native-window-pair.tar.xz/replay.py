#!/usr/bin/env python3
"""Replay the retained #413 cold boot. Run python3 replay.py from the archive root."""
import hashlib
import json
from pathlib import Path
import sys


# The recorded result pins capture files. Its launch and source records pin the
# package, verifier, and working source bytes. Bind this replay to that run.
RESULT_SHA256 = "3101b29c7591b269b717b70ec386f4100dade3f4d36cc5fc2f98f48a1a930802"
PUBLIC_COMMIT = "95ab33dd5358fd58f4f59b70d4ed049aa8c0d397"
CAPTURE = Path("capture")
PACKAGE = CAPTURE / "package"
TOOLS = Path("tools")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify_hashes(directory, hashes):
    for name, digest in hashes.items():
        path = directory / name
        require(hashlib.sha256(path.read_bytes()).hexdigest() == digest, f"SHA-256 mismatch: {path}")


def record(path):
    return json.loads(path.read_bytes())


def commit_tree(name, expected):
    data = (Path("commits") / (name + ".txt")).read_bytes()
    header = f"commit {len(data)}\0".encode()
    require(hashlib.sha1(header + data).hexdigest() == expected, f"unexpected {name} Git commit")
    prefix, tree = data.splitlines()[0].split()
    require(prefix == b"tree" and len(tree) == 40, "malformed commit tree")
    return tree


def check_input(wire):
    require(wire == b"xnxq", "unexpected PL011 input sequence")


def check_ppm(data, expected, observer):
    header = observer.PPM.match(data)
    require(header and tuple(map(int, header.groups())) == (320, 240)
            and data[header.end():] == expected, "PPM pixels or geometry differ from fixture")


def must_reject(check, *args):
    try:
        check(*args)
    except ValueError:
        return
    raise ValueError(f"corruption accepted by {check.__name__}")


def main():
    verify_hashes(CAPTURE, {"result.json": RESULT_SHA256})
    result = record(CAPTURE / "result.json")
    verify_hashes(CAPTURE, result["hashes"])
    launch = record(CAPTURE / "launch.json")
    verify_hashes(PACKAGE, launch["package_sha256"])
    sources = record(CAPTURE / "sources.json")
    verify_hashes(Path("source"), sources["source_sha256"])
    verify_hashes(TOOLS, sources["observer_sha256"])

    # Load the original independent host oracle only after checking its bytes.
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(TOOLS.resolve()))
    import verify_native_display as display
    import verify_native_window_pair as pair

    manifest = record(PACKAGE / "manifest.json")
    require(not manifest["tracked_changes"] and manifest["commit"] == sources["commit"],
            "unclean or inconsistent source revision")
    require(commit_tree("local", manifest["commit"]) == commit_tree("public", PUBLIC_COMMIT),
            "captured and public revisions have different Git trees")
    frozen = launch["package_sha256"]
    require(frozen["kernel.elf"] == manifest["kernel_elf_sha256"]
            and frozen["build.log"] == manifest["build_log_sha256"], "package provenance mismatch")
    kernel = (PACKAGE / "kernel.elf").read_bytes()
    require(len(manifest["slots"]) == len(pair.SLOTS) == 4, "wrong process count")
    for pid, (slot, (name, args, priority, hash_key)) in enumerate(zip(manifest["slots"], pair.SLOTS)):
        require((slot["slot"], slot["elf"], slot["argv"], slot["priority"]) == (pid, name, ["/bin/app", *args], priority),
                f"unexpected role in slot {pid}")
        require(frozen[name] == manifest[hash_key] == slot["elf_sha256"] == slot["input"]["sha256"]
                == manifest["source_sha256"][slot["input"]["path"]] and (PACKAGE / name).read_bytes() in kernel,
                f"slot {pid} ELF differs from frozen input or embedded image")

    wire = (CAPTURE / "input.bin").read_bytes()
    check_input(wire)
    require(result["pass"] is True and result["qemu_status"] == 0 and len(result["input"]) == 4,
            "incomplete live capture")
    previous = 0
    for scene, sent in zip(pair.SCENES, result["input"]):
        name, focus, a_ink, b_ink, key = scene
        rgb = pair.expected_frame(focus, a_ink, b_ink)
        for suffix in (".ppm", "-repeat.ppm"):
            check_ppm((CAPTURE / (name + suffix)).read_bytes(), rgb, display)
        pair.check_png(CAPTURE / (name + ".png"), rgb)
        frame = result["frames"][name]
        require(frame["rgb_sha256"] == hashlib.sha256(rgb).hexdigest() and frame["matched_pixels"] == 320*240
                and (frame["focus"], frame["a_ink"], frame["b_ink"]) == (focus, a_ink, b_ink),
                f"incorrect recorded pixels or state for {name}")
        require((sent["after_frame"], sent["byte"]) == (name, key.decode())
                and display.STABLE_SECONDS <= frame["stable_seconds"] <= frame["captured_seconds"] - previous
                and frame["captured_seconds"] <= sent["seconds"] <= result["elapsed_seconds"],
                f"incorrect stable frame or input order at {name}")
        previous = sent["seconds"]

    raw = (CAPTURE / "uart.bin").read_bytes()
    prefix = pair.boot_prefix(manifest)
    terminal = pair.check_terminal(raw, prefix)
    require(terminal["native_exits"] == pair.EXITS == [tuple(row) for row in result["native_exits"]]
            and all(terminal[k] == result[k] for k in ("fixed_events", "dropped_fixed_events")),
            "terminal UART disagrees with capture report")

    # Exercise semantic checks on changed bytes without modifying the evidence.
    ppm = (CAPTURE / "b-ink-repeat.ppm").read_bytes()
    must_reject(check_ppm, ppm[:-1] + bytes([ppm[-1] ^ 1]), rgb, display)
    must_reject(pair.check_png, CAPTURE / "a-ink.png", rgb)
    must_reject(check_input, wire.replace(b"n", b"x"))
    must_reject(pair.check_terminal, raw.replace(b"PID 1 71", b"PID 1 0"), prefix)
    must_reject(pair.check_terminal, raw.removesuffix(b"NATIVE EL0 EXIT PID 3 0\n"), prefix)
    print(f"PASS {len(sources['source_sha256'])} source files, 4 slot ELFs, 8 PPMs, 4 PNGs, "
          "PL011 xnxq, exits 70/71/72/0, 5 corruption controls")


if __name__ == "__main__":
    try:
        main()
    except (OSError, KeyError, ValueError) as error:
        sys.exit(f"FAIL {error}")
