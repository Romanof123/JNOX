#!/bin/bash
set -euo pipefail
base="$HOME/jnox406-lab"
cd "$base/src"
export PATH="$HOME/.cargo/bin:$PATH" CARGO_BUILD_JOBS=1 LC_ALL=C CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1
exec 9>"$base/run.lock"
flock 9
test "$(git rev-parse HEAD)" = "$1"
b="$base/$2"
mkdir "$b"
exec > >(tee "$b/run.log") 2>&1
sh sdk/native-aarch64/build-rust.sh examples/native-display/Cargo.toml "$b/display.elf"
python3 tools/build_native_el0.py --board virt --policy fifo --elf "$b/display.elf" --priority 1 --peer-elf "$b/display.elf" --peer-priority 2 --peer-arg denied --display-service 0 --out "$b/display"
python3 tools/build_native_el0.py --board virt --policy fifo --elf "$b/display.elf" --priority 1 --out "$b/headless"
python3 -B tools/verify_native_display.py --package "$b/display" --headless-package "$b/headless" --out "$b/capture"
