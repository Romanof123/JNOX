#!/bin/bash
set -euo pipefail
base="$HOME/jnox406-lab"
cd "$base/src"
export PATH="$HOME/.cargo/bin:$PATH" CARGO_BUILD_JOBS=1 LC_ALL=C CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1
exec 9>"$base/run.lock"
flock 9
git checkout -q --detach "$1"
test -z "$(git status --porcelain --untracked-files=no)"
b="$base/$2"
mkdir "$b"
exec > >(tee "$b/run.log") 2>&1
python3 -B tools/test_native_service_slots.py
sh sdk/native-aarch64/build-rust.sh --local-socket examples/native-window-pair/Cargo.toml "$b/pair.elf"
sh sdk/native-aarch64/build-rust.sh services/socket/Cargo.toml "$b/broker.elf"
python3 -B tools/build_native_el0.py --board virt --policy fifo --elf "$b/pair.elf" --priority 7 --peer-elf "$b/pair.elf" --peer-priority 5 --peer-arg a --peer-elf "$b/pair.elf" --peer-priority 4 --peer2-arg b --peer-elf "$b/broker.elf" --peer-priority 1 --peer3-arg 7 --display-service 0 --socket-service 3 --ipc-route 0:3 --ipc-route 1:3 --ipc-route 2:3 --out "$b/pkg"
python3 -B tools/verify_native_window_pair.py --package "$b/pkg" --out "$b/capture" --timeout 45
