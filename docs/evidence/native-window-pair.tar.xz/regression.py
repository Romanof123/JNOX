"""Replay the three original display controls from the extracted evidence packet."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "tools"))
from ordinary_amc_capture import sha
from verify_native_display import expected_rgb, observed_exits, PPM
from verify_native_window_pair import check_png, require


def main():
    base = ROOT / "regression"
    cases = {
        "interaction": ("display-package", [(0, 0), (1, 61)]),
        "absent": ("display-package", [(0, 19), (1, 61)]),
        "headless": ("headless-package", [(None, 38)]),
    }
    for mode, (package, expected_exits) in cases.items():
        run = base / mode
        result = json.loads((run / "result.json").read_bytes())
        kernel = base / package / "kernel.elf"
        manifest = json.loads((kernel.parent / "manifest.json").read_bytes())
        require(result["pass"] and result["mode"] == mode and result["qemu_status"] == 0, mode)
        require(sha(kernel) == result["kernel_sha256"] == manifest["kernel_elf_sha256"], mode)
        require(all(sha(run / name) == digest for name, digest in result["hashes"].items()), mode)
        require(observed_exits((run / "uart.bin").read_bytes()) == expected_exits, mode)
    for name, changed in [("before", False), ("after", True)]:
        expected = expected_rgb(changed)
        for suffix in [".ppm", "-repeat.ppm"]:
            data = (base / "interaction" / (name + suffix)).read_bytes()
            match = PPM.match(data)
            require(match and match.groups() == (b"320", b"240") and data[match.end():] == expected, name)
        check_png(base / "interaction" / (name + ".png"), expected)
    print("PASS: display interaction, missing device and headless controls")


if __name__ == "__main__":
    main()
