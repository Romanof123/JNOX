"""Reassemble compositor-side Unix streams and decode using upstream protocol XML."""
from collections import defaultdict, deque
from pathlib import Path
import struct
from xml.etree import ElementTree as XML


def need(ok, why):
    if not ok:
        raise ValueError(why)


def interfaces():
    root = Path(__file__).parent
    return {i.get("name"):i for f in ("wayland.xml","xdg-shell.xml")
            for i in XML.parse(root/f).findall("interface")}


class Stream:
    def __init__(self):
        self.objects = {1:"wl_display"}
        self.versions = {1:1}
        self.partial = defaultdict(bytearray)
        self.fds = defaultdict(deque)
        self.messages = []
        self.globals = {}

    def feed(self, seq, direction, payload, fds, spec):
        buf = self.partial[direction]
        queue = self.fds[direction]
        queue.extend(fds)
        buf.extend(payload)
        while len(buf)>=8:
            obj, header = struct.unpack_from("<II",buf)
            size, opcode = header>>16, header&65535
            need(size>=8 and size%4==0, "invalid Wayland header")
            if len(buf)<size:
                break
            body = bytes(buf[8:size])
            del buf[:size]
            interface = self.objects[obj]
            kind = "request" if direction==1 else "event"
            msg = spec[interface].findall(kind)[opcode]
            need(int(msg.get("since","1"))<=self.versions[obj],"message exceeds negotiated version")
            name = msg.get("name")
            args = {}
            off = 0
            def uint():
                nonlocal off
                value, = struct.unpack_from("<I",body,off)
                off+=4
                return value
            def block():
                nonlocal off
                length = uint()
                data = body[off:off+length]
                need(len(data)==length,"short variable length field")
                off+=(length+3)&~3
                return data
            def string():
                data=block()
                if not data:
                    return None
                need(data[-1]==0,"unterminated Wayland string")
                return data[:-1].decode()
            for arg in msg.findall("arg"):
                key, t = arg.get("name"), arg.get("type")
                if t=="fd":
                    need(queue,"missing ancillary handle")
                    value=queue.popleft()
                elif t=="string":
                    value=string()
                elif t=="array":
                    value=block().hex()
                elif t=="new_id":
                    target=arg.get("interface")
                    if not target:
                        target=string()
                        args["interface"],args["version"]=target,uint()
                    value=uint()
                    need(value != 0 and value not in self.objects, "new_id already allocated or null")
                    self.objects[value]=target
                    self.versions[value]=min(args.get("version",self.versions[obj]),int(spec[target].get("version")))
                else:
                    value=uint()
                    if t in ("int","fixed") and value>=1<<31:
                        value-=1<<32
                if t=="object":
                    need((value==0 and arg.get("allow-null")=="true") or
                         (value in self.objects and (not arg.get("interface") or self.objects[value]==arg.get("interface"))),
                         "invalid object argument")
                args[key]=value
            need(off==len(body),"Wayland signature size mismatch")
            self.messages.append(dict(seq=seq,direction=direction,object=obj,interface=interface,
                                      name=name,args=args))
            if interface=="wl_registry" and name=="global":
                self.globals[args["name"]]=(args["interface"],args["version"])
            elif interface=="wl_registry" and name=="bind":
                advertised,version=self.globals[args["name"]]
                need(advertised==args["interface"] and 0<args["version"]<=version,"unadvertised bind/version")
            elif interface=="wl_display" and name=="delete_id":
                need(args["id"] in self.objects and args["id"]!=1,"delete_id for unknown object")
                del self.objects[args["id"]]


def decode(ram, root, head, records):
    total,lost=struct.unpack("<QQ",ram.user(root,head,16))
    need(total<=2048 and not lost,"wire journal overwritten")
    spec=interfaces()
    connections=[]
    sockets={}
    trace=[]
    for j in range(total):
        record=ram.user(root,records+j*120,120)
        seq,fd,dr,n,nd,*descriptors=struct.unpack_from("<QiIII8i",record)
        need(seq==j+1 and dr in (1,2,3,4) and n<=64 and nd<=8,"wire journal extent/sequence")
        need(fd >= 0 and all(x >= 0 for x in descriptors[:nd]), "negative transport descriptor")
        trace.append([seq,fd,dr,n,descriptors[:nd],record[56:56+n].hex()])
        if dr==3:
            need(fd not in sockets,"duplicate accept")
            sockets[fd]=Stream()
            connections.append((fd,sockets[fd]))
        elif dr==4:
            sockets.pop(fd)
        else:
            sockets[fd].feed(seq,dr,record[56:56+n],descriptors[:nd],spec)
    return dict(raw=trace, peers=[dict(fd=fd,messages=c.messages) for fd,c in connections])
