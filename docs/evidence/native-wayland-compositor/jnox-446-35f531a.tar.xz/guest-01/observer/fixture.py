"""Independent #446 RGB fixture. The action following each scene goes over PL011."""
SCENES = (
    ("initial", "BA", 0, 0, b"x"),
    ("a1", "BA", 1, 0, b"n"),
    ("b-front", "AB", 1, 0, b"x"),
    ("b1", "AB", 1, 1, b"k"),
    ("b-dead", "A", 1, 1, b"x"),
    ("a2", "A", 2, 1, b"q"),
)
GLYPHS = dict(P="1e11111e101010", U="1111111111110e", L="1010101010101f",
              S="0f10100e01011e", E="1f10101e10101f", T="1f040404040404",
              I="0e04040404040e")
WINDOWS = {
    "A": (16, 24, "PULSE", "d2ece8", ("276575", "398657", "445a90"), 12,
          (16, 48, 40, 40, 104, 0x448, 0xa44, 0xf244, 0x182, 0x102, 0x101, 0)),
    "B": (112, 80, "TILES", "f1d5bc", ("704567", "a25639", "73559b"), 69,
          (0x7e7e, 0x4242, 0x5a5a, 0x5a5a, 0x4242, 0x7e7e, 0, 0x3c3c, 0x2424, 0x2424, 0x3c3c, 0)),
}
def window(role, phase):
    _, _, title, ink, bodies, mx, motif = WINDOWS[role]
    pixels = bytearray(bytes.fromhex(ink) * (128 * 96))
    def rect(x, y, w, h, color):
        row = bytes.fromhex(color) * w
        for line in range(y, y+h):
            start = 3*(128*line+x)
            pixels[start:start+len(row)] = row
    def mask(x, y, w, rows, scale, color):
        for j, row in enumerate(rows):
            for i in range(w):
                if row & (1 << (w-i-1)):
                    rect(x+i*scale, y+j*scale, scale, scale, color)
    rect(2, 2, 124, 92, bodies[phase%3])
    rect(2, 2, 124, 18, "233541")
    for i, c in enumerate(title):
        mask(8+i*6, 7, 5, bytes.fromhex(GLYPHS[c]), 1, "e0eee9")
    mask(mx, 33, 16, motif, 3, ink)
    return bytes(pixels)

def frame(scene):
    _, layers, a, b, _ = scene
    canvas = bytearray(bytes.fromhex("18232d") * (320*240))
    for role in layers:
        pixels = window(role, a if role == "A" else b)
        x, y = WINDOWS[role][:2]
        for row in range(96):
            at = 3*(320*(y+row)+x)
            canvas[at:at+384] = pixels[row*384:(row+1)*384]
    return b"P6\n320 240\n255\n" + canvas
