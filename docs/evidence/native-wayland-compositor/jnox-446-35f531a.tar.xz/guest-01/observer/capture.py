"""Linux cold-boot recorder. Capture only after the integration gate is released."""
import argparse
import hashlib
import json
import mmap
import struct
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import threading
import time


FLAGS = ["-machine", "virt,gic-version=2", "-cpu", "cortex-a72", "-smp", "1",
         "-accel", "tcg", "-m", "128M", "-nodefaults", "-display", "none",
         "-monitor", "none", "-no-reboot"]
PACKAGE = ["manifest.json", "kernel.elf", "user.elf", "native_peer.elf",
           "native_peer2.elf", "native_peer3.elf"]


from fixture import SCENES, frame

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def boot(dest, kernel, emulator, fixtures, exits, timeout):
    dest.mkdir()
    with tempfile.TemporaryDirectory() as tmp, (dest / "uart.bin").open("xb", buffering=0) as uart, (dest / "stderr").open("xb") as err, (dest / "events.jsonl").open("x", buffering=1) as events:
        endpoint = str(Path(tmp) / "serial")
        cmd = [str(emulator), *FLAGS, "-S", "-qmp", "stdio", "-chardev",
               f"socket,id=pl011,path={endpoint},server=on,wait=off", "-serial",
               "chardev:pl011", "-device", "ramfb,id=screen", "-kernel", str(kernel)]
        def record(kind, data):
            events.write(json.dumps([time.monotonic_ns(), kind, data]) + "\n")
        record("launch", [cmd, digest(emulator), digest(kernel)])
        with subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err) as proc, socket.socket(socket.AF_UNIX) as serial:
            timer = threading.Timer(timeout, proc.kill)
            timer.start()
            try:
                running_hash = digest(Path("/proc")/str(proc.pid)/"exe")
                require(running_hash == digest(emulator), "launched executable differs from configured binary")
                record("running-executable", running_hash)
                record("greeting", json.loads(proc.stdout.readline())["QMP"])
                def request(name, **args):
                    record("command", [name, args])
                    proc.stdin.write(json.dumps(dict(execute=name, arguments=args)).encode() + b"\n")
                    proc.stdin.flush()
                    while True:
                        reply = json.loads(proc.stdout.readline())
                        record("reply", reply)
                        if "event" not in reply:
                            return reply["return"]
                request("qmp_capabilities")
                serial.connect(endpoint)
                serial.setblocking(False)
                data = bytearray()
                def drain():
                    while True:
                        try:
                            block = serial.recv(65536)
                        except BlockingIOError:
                            return
                        require(block, "serial disconnected")
                        uart.write(block)
                        data.extend(block)
                from replay import capture_memory
                request("cont")
                for scene in SCENES:
                    stage, key = scene[0], scene[-1]
                    path = dest / (stage + ".ppm")
                    while True:
                        drain()
                        try:
                            request("screendump", filename=str(path))
                        except KeyError:
                            if proc.poll() is not None:
                                raise
                        if path.exists() and path.read_bytes() == fixtures[stage].read_bytes():
                            time.sleep(.12)
                            request("stop")
                            request("screendump", filename=str(path))
                            if path.read_bytes() == fixtures[stage].read_bytes():
                                break
                            request("cont")
                        time.sleep(.05)
                    capture_memory(request, dest, kernel.parent, stage)
                    drain()
                    serial.sendall(key)
                    record("pl011", key.hex())
                    request("cont")
                while not all(line in data.splitlines() for line in exits):
                    drain()
                    require(proc.poll() is None, "premature QEMU exit")
                    time.sleep(.02)
                request("stop")
                capture_memory(request, dest, kernel.parent, "terminal")
                drain()
                request("quit")
                require(proc.wait(timeout=5) == 0, "QEMU exit status")
            finally:
                timer.cancel()
                if proc.poll() is None:
                    proc.kill()
                proc.wait()
                timer.join()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("package", "contract", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True, help="git source checkout containing the frozen commit")
    parser.add_argument("--qemu", default="qemu-system-aarch64")
    parser.add_argument("--timeout", type=int, default=90)
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True)
    pkg = out / "package"
    pkg.mkdir()
    observer = out/"observer"
    observer.mkdir()
    for name in ("capture.py","replay.py","fixture.py","controls.py","wire.py","wayland.xml","xdg-shell.xml"):
        shutil.copyfile(Path(__file__).resolve().with_name(name),observer/name)
    for name in PACKAGE:
        shutil.copyfile(args.package / name, pkg / name)
    manifest = json.loads((pkg/"manifest.json").read_bytes())
    revision = manifest["commit"]
    require(len(revision)==40 and all(c in "0123456789abcdef" for c in revision), "full git commit")
    cmd = ["git", "-C", str(args.source)]
    tree = subprocess.check_output([*cmd, "ls-tree", "-r", "-z", revision])
    (out/"source-tree.git").write_bytes(tree)
    provenance = dict(commit=revision, tree_sha256=digest(out/"source-tree.git"),
                      tree_object=subprocess.check_output([*cmd,"rev-parse",revision+"^{tree}"],text=True).strip())
    (out/"source.json").write_text(json.dumps(provenance,indent=2))
    shutil.copyfile(args.contract, out / "contract.json")
    contract = json.loads(args.contract.read_bytes())
    frames = {}
    for scene in SCENES:
        stage = scene[0]
        frames[stage] = out / (stage + ".expected.ppm")
        frames[stage].write_bytes(frame(scene))
    require(len(contract["exits"]) == 4, "four terminal exit codes required")
    exits = [f"NATIVE EL0 EXIT PID {i} {n}".encode() for i, n in enumerate(contract["exits"])]
    emulator = Path(shutil.which(args.qemu) or args.qemu).resolve(strict=True)
    errors = {}
    for number in (1, 2):
        try:
            boot(out / f"cold-{number}", pkg / "kernel.elf", emulator, frames, exits, args.timeout)
        except Exception as exc:
            errors[str(number)] = repr(exc)
            (out / f"cold-{number}" / "failure.txt").write_text(repr(exc))
    from replay import verify
    from controls import controls
    if not errors:
        verify(out)
        controls(out)
    hashes = {str(p.relative_to(out)): digest(p) for p in sorted(out.rglob("*")) if p.is_file()}
    (out / "sha256.json").write_text(json.dumps(hashes, indent=2))

    require(not errors, f"cold boot capture failures: {errors}")
