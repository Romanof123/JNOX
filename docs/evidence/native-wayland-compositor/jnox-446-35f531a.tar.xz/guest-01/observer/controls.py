"""Run each negative check on an isolated copy-on-write view of the archived evidence."""
import argparse
from pathlib import Path
import shutil
import struct
import tempfile

from fixture import SCENES
from replay import PageArchive, observe, package, validate, verify


def rejected(fn, description):
    try:
        fn()
    except (ValueError, KeyError, AssertionError):
        return
    raise RuntimeError("unexpected acceptance of "+description)


def controls(out):
    pkg = out/"package"
    roots,_,_,witness = package(pkg)
    dest = out/"cold-1"
    for stage in ("a1", "b1"):
        ram = PageArchive.load(dest/(stage+".pages.z"))
        role = 1 if stage=="a1" else 2
        word = witness[role-1][0]+14*8
        leaf = ram.walk(roots[role],word)
        phys = leaf[0]
        page = phys & ~4095
        changed = bytearray(ram.pages[page])
        struct.pack_into("<Q",changed,phys-page,0)
        ram.pages[page] = bytes(changed)
        rejected(lambda: validate(observe(ram,pkg,stage),stage),"cross-role input witness "+stage)
    with tempfile.TemporaryDirectory() as scratch:
        local = Path(scratch)
        for path in out.iterdir():
            if path.name!="cold-1":
                (local/path.name).symlink_to(path.resolve(),target_is_directory=path.is_dir())
        mirror=local/"cold-1"
        mirror.mkdir()
        for path in dest.iterdir():
            if path.name!="initial.ppm":
                (mirror/path.name).symlink_to(path.resolve())
        changed=bytearray((dest/"initial.ppm").read_bytes())
        changed[-1]^=1
        (mirror/"initial.ppm").write_bytes(changed)
        rejected(lambda: verify(local),"one external pixel")
    print("Corrupted client words and external pixel rejected")


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("evidence",type=Path)
    controls(parser.parse_args().evidence)
