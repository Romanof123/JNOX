"""Replay physical snapshots against the independently supplied application contract."""
import argparse
import json
import mmap
from pathlib import Path
import struct
import subprocess
from capture import FLAGS, PACKAGE, digest, require

PAGE = 4096
BASE = 0x40000000
MASK = (1 << 48) - PAGE
WINDOW = 0x02000000
STRIDE = 512 << 10
SIZE = 320 * 240 * 4


def symbols(path):
    output = subprocess.check_output(["nm", "-S", "--defined-only", path], text=True)
    return [(int(a, 16), int(n, 16), name) for row in output.splitlines()
            if len(parts := row.split()) == 4 for a, n, _, name in [parts]]


def one(entries, predicate):
    values = [entry for entry in entries if predicate(entry[2])]
    require(len(values) == 1, "missing or ambiguous linked symbol")
    return values[0][:2]


class RAM:
    def __init__(self, raw):
        self.raw = raw
        require(len(raw) == 128 << 20, "unexpected physical RAM size")

    def read(self, addr, size):
        offset = addr - BASE
        require(0 <= offset <= len(self.raw) - size, "physical extent outside virt RAM")
        return self.raw[offset:offset + size]

    def walk(self, root, va):
        table, user, write, xn = root, True, True, False
        require(0 <= va < 1 << 39, "VA outside 39-bit TTBR0")
        for shift in (30, 21, 12):
            desc = int.from_bytes(self.read(table + 8*((va >> shift) & 511), 8), "little")
            if not desc & 1:
                return None
            if shift != 12 and desc & 2:
                table = desc & MASK
                user &= not bool(desc & (1 << 61))
                write &= not bool(desc & (1 << 62))
                xn |= bool(desc & (1 << 60))
                continue
            require(shift != 12 or desc & 2, "reserved L3 descriptor")
            low = (1 << shift) - 1
            return ((desc & MASK & ~low) | (va & low),
                    user and bool(desc & 64), write and not bool(desc & 128),
                    xn or bool(desc & (1 << 54)), bool(desc & (1 << 10)))

    def user(self, root, va, size):
        data = bytearray()
        while len(data) < size:
            at = va + len(data)
            mapping = self.walk(root, at)
            require(mapping and mapping[1] and mapping[4], "unreadable EL0 VA")
            length = min(size-len(data), PAGE-at%PAGE)
            data.extend(self.read(mapping[0], length))
        return bytes(data)

    def surfaces(self, root):
        mapped = {}
        for slot in range(4):
            start = WINDOW + slot * STRIDE
            for offset in range(0, STRIDE, PAGE):
                leaf = self.walk(root, start+offset)
                if leaf and leaf[1]:
                    mapped[start+offset] = leaf
        return mapped

    def aliases(self, root, physical_start, size):
        """Enumerate EL0 aliases across TTBR0, including block mappings."""
        found = set()
        def visit(table, shift, va_base):
            for i,(desc,) in enumerate(struct.iter_unpack("<Q",self.read(table,PAGE))):
                if not desc & 1:
                    continue
                va = va_base + (i << shift)
                if shift > 12 and desc & 2:
                    if not desc & (1 << 61):
                        visit(desc & MASK,shift-9,va)
                elif desc & 64:
                    require(shift > 12 or desc & 2, "reserved EL0 descriptor")
                    pa = desc & MASK & ~((1<<shift)-1)
                    for addr in range(max(pa,physical_start), min(pa+(1<<shift),physical_start+size),PAGE):
                        found.add(va+addr-pa)
        visit(root,30,0)
        return found


def package(pkg):
    manifest = json.loads((pkg/"manifest.json").read_bytes())
    kernel = pkg / "kernel.elf"
    image = kernel.read_bytes()
    require(digest(kernel) == manifest["kernel_elf_sha256"], "kernel manifest hash")
    base, size = one(symbols(kernel), lambda n: "native_el0_mmu" in n and "6SPACES" in n)
    require(base % PAGE == 0 and size % (4*PAGE) == 0, "linked root extent")
    roots = [base + i*(size//4) for i in range(4)]
    require((manifest["profile"],manifest["app"],manifest["board"],manifest["policy"]) ==
            ("native","process","virt","fifo"), "ordinary virt native FIFO")
    require(manifest["display_service"]["slot"] == 0 and
            manifest["socket_service"] == {"slot":3,"authorized_clients":[0,1,2]},
            "display and AF_UNIX role ownership")
    identities = []
    entries = []
    require(len(manifest["slots"]) == 4, "four-slot manifest")
    for i, slot in enumerate(manifest["slots"]):
        elf = pkg / PACKAGE[2+i]
        data = elf.read_bytes()
        h = digest(elf)
        require(slot["elf_sha256"] == h and slot["slot"] == i and
                slot["expected_ttbr0_el1"] == ((i+1)<<48 | roots[i]), "manifest slot")
        require(data[:6] == b"\x7fELF\x02\x01" and data[18:20] == b"\xb7\0" and data in image,
                "embedded AArch64 identity")
        entry, ph = struct.unpack_from("<QQ", data, 24)
        step, count = struct.unpack_from("<HH", data, 54)
        code = []
        for j in range(count):
            typ, flags, off, va, _, length, _, _ = struct.unpack_from("<II6Q", data, ph+j*step)
            if typ == 1 and flags & 1 and va <= entry <= va+length-32:
                code.append(data[off+entry-va:off+entry-va+32])
        require(len(code) == 1, "executable entry")
        entries.append((entry, code[0]))
        identities.append(h)
    require(identities[0] != identities[3] and all(h not in (identities[0], identities[3]) for h in identities[1:3]), "role identities")
    witnesses = [one(symbols(pkg/PACKAGE[i+2]), lambda n: n == "wayland_client_witness") for i in (1,2)]
    require(all(n == 256 for _, n in witnesses), "client witness extents")
    return roots, entries, identities, witnesses

from fixture import SCENES, frame
import hashlib
import re
import tempfile
import zlib


class PageArchive(RAM):
    """Record only the physical pages consumed by a frozen observation."""
    def __init__(self, source=None, pages=None):
        self.source = source
        self.pages = {} if pages is None else pages

    def read(self, addr, size):
        result = bytearray()
        while len(result) < size:
            pos = addr+len(result)
            page = pos & ~(PAGE-1)
            if page not in self.pages:
                require(self.source is not None, f"missing archived physical page {page:#x}")
                self.pages[page] = self.source.read(page, PAGE)
            off = pos-page
            result.extend(self.pages[page][off:off+min(PAGE-off, size-len(result))])
        return bytes(result)

    def save(self, path):
        raw = b"".join(struct.pack("<Q", addr)+data for addr,data in sorted(self.pages.items()))
        path.write_bytes(zlib.compress(raw))

    @classmethod
    def load(cls, path):
        raw = zlib.decompress(path.read_bytes())
        pages = {}
        require(len(raw) % (PAGE+8) == 0, "partial archived page")
        for i in range(0,len(raw),PAGE+8):
            key, = struct.unpack_from("<Q", raw, i)
            require(key not in pages and key % PAGE == 0 and BASE <= key < BASE+(128<<20), "physical address")
            pages[key] = raw[i+8:i+8+PAGE]
        return cls(pages=pages)


def observe(ram, pkg, stage):
    roots, entries, ids, witness = package(pkg)
    words = {}
    for i, (entry, expected) in enumerate(entries):
        if stage != "terminal" and (i != 2 or stage not in ("b-dead", "a2")):
            require(ram.user(roots[i],entry,len(expected)) == expected, f"slot {i} live entry")
    for role,(va,_) in enumerate(witness,1):
        mapping = ram.walk(roots[role], va)
        if mapping and mapping[1] and mapping[4]:
            words[str(role)] = struct.unpack("<32Q",ram.user(roots[role],va,256))
    aliases = {}
    for role in (1,2):
        if str(role) not in words or stage == "terminal" or (role == 2 and stage in ("b-dead","a2")):
            continue
        va = words[str(role)][21]
        source = ram.walk(roots[role], va)
        if source and source[1] and source[4]:
            offsets = [ram.walk(roots[role], va + off) for off in range(0,128*96*4,PAGE)]
            shares = []
            for leaf in offsets:
                if not leaf:
                    continue
                phys = leaf[0] & ~(PAGE-1)
                ram.read(phys,PAGE)
                owners = []
                for root in roots:
                    vaddrs = sorted(ram.aliases(root,phys,PAGE))
                    owners.append([[addr,ram.walk(root,addr)[2]] for addr in vaddrs])
                shares.append([phys, owners])
            aliases[str(role)] = shares
    compositor=symbols(pkg/"user.elf")
    head,_=one(compositor,lambda n:n=="jnox_wayland_wire_head")
    journal,extent=one(compositor,lambda n:n=="jnox_wayland_wire")
    require(extent==2048*120,"wire journal extent")
    scene_va,scene_extent=one(compositor,lambda n:n=="jnox_wayland_scene")
    require(scene_extent==128,"scene extent")
    mapping=ram.walk(roots[0],head)
    wire=scene_words=None
    if mapping and mapping[1] and mapping[4]:
        from wire import decode
        wire=decode(ram,roots[0],head,journal)
        scene_words=struct.unpack("<16Q",ram.user(roots[0],scene_va,128))
    return dict(roots=roots, elf_sha256=ids, client=words, aliases=aliases, wire=wire, scene=scene_words)


def capture_memory(request, dest, pkg, stage):
    # Read small physical extents on demand through QMP while all vCPUs are stopped.
    with tempfile.TemporaryDirectory() as scratch:
        pagefile = Path(scratch)/"memory"
        class QMPMemory:
            def read(self, addr, size):
                request("pmemsave", val=addr, size=size, filename=str(pagefile))
                data = pagefile.read_bytes()
                require(len(data) == size, "short pmemsave")
                return data
        ram = PageArchive(QMPMemory())
        try:
            result = observe(ram, pkg, stage)
            (dest/(stage+".json")).write_text(json.dumps(result))
        finally:
            ram.save(dest/(stage+".pages.z"))


def protocol_stage(messages, slot, alive, focused):
    fd, surface_id, toplevel_id, mapped, width, height = slot
    roles = {}
    surfaces = {}
    configures = {}
    acknowledged = set()
    configured = set()
    entered = {}
    pools = {}
    buffers = {}
    submitted = set()
    reuse = 0
    down = set()
    pending = {}
    busy = set()
    commits = 0
    focused_keys = []
    for m in messages:
        iface, name, obj, a = m["interface"], m["name"], m["object"], m["args"]
        if (iface,name)==("xdg_wm_base","get_xdg_surface"):
            surfaces[a["id"]] = a["surface"]
        elif (iface,name)==("xdg_surface","get_toplevel"):
            roles[a["id"]] = obj
        elif (iface,name)==("xdg_toplevel","configure"):
            configured.add(roles[obj])
        elif (iface,name)==("xdg_surface","configure"):
            require(obj in configured,"missing toplevel configure")
            configures[obj,a["serial"]] = True
        elif (iface,name)==("xdg_surface","ack_configure"):
            require(configures.pop((obj,a["serial"]),False),"ack without matching configure")
            acknowledged.add(surfaces[obj])
        elif (iface,name)==("wl_shm","create_pool"):
            require(a["fd"]>=0 and a["size"]>0,"pool descriptor or extent")
            pools[a["id"]] = a["size"]
        elif (iface,name)==("wl_shm_pool","create_buffer"):
            require(a["format"] in (0,1) and a["stride"]>=4*a["width"] and a["offset"]>=0 and
                    a["offset"]+(a["height"]-1)*a["stride"]+4*a["width"]<=pools[obj],"SHM geometry or format")
            buffers[a["id"]] = (a["width"],a["height"])
        elif (iface,name)==("wl_surface","attach"):
            pending[obj] = a["buffer"]
        elif (iface,name)==("wl_surface","commit"):
            buffer = pending.pop(obj,None)
            if buffer:
                require(obj in acknowledged and buffer in buffers and buffer not in busy,
                        "unconfigured surface or unreleased buffer submission")
                require(buffers[buffer]==(128,96),"buffer dimensions")
                reuse += int(buffer in submitted)
                submitted.add(buffer)
                busy.add(buffer)
                commits += 1
        elif (iface,name)==("wl_buffer","release"):
            require(obj in busy,"release without outstanding submission")
            busy.remove(obj)
        elif (iface,name)==("wl_keyboard","keymap"):
            require(a["format"]==1 and a["fd"]>=0 and a["size"]>1,"missing XKB v1 keymap")
        elif (iface,name)==("wl_keyboard","enter"):
            entered[obj] = a["surface"]
        elif (iface,name)==("wl_keyboard","leave"):
            require(entered.pop(obj,None)==a["surface"],"keyboard leave target")
        elif (iface,name)==("wl_keyboard","key"):
            require(entered.get(obj) in acknowledged,"key delivered without surface focus")
            if a["state"]==1:
                require(a["key"] not in down,"repeated press without release")
                focused_keys.append(a["key"])
                down.add(a["key"])
            else:
                require(a["state"]==0 and a["key"] in down,"unexpected release")
                down.remove(a["key"])
    require(commits and not down,"missing configured buffer commit or key release")
    require(not focused_keys or reuse,"no reuse after key-driven update")
    if alive:
        require(mapped==1 and (width,height)==(128,96) and
                surfaces.get(roles.get(toplevel_id))==surface_id,"mapped scene identities")
        require((surface_id in entered.values())==focused,"keyboard focus versus scene")
    else:
        require(not mapped,"dead peer remains mapped")
    return focused_keys


def validate(memory, stage):
    if stage == "terminal":
        return
    idx = [s[0] for s in SCENES].index(stage)
    require(memory["wire"] and len(memory["wire"]["peers"])==2,"two compositor peers")
    scene = memory["scene"]
    focus_role = (1,1,2,2,1,1)[idx]
    require(scene and scene[0]>0 and scene[2] in (0,1),"compositor scene focus")
    routed = {}
    for peer in memory["wire"]["peers"]:
        msgs = peer["messages"]
        def select(interface,name):
            return [m for m in msgs if (m["interface"],m["name"])==(interface,name)]
        titles = select("xdg_toplevel","set_title")
        require(titles,"client title on wire")
        title = titles[-1]["args"]["title"].upper()
        role = next((i for i,word in ((1,"PULSE"),(2,"TILES")) if word in title),None)
        require(role and role not in routed,"distinct titled peers")
        routed[role]=msgs
        require(any(m["args"]["app_id"]==("org.jnox.Pulse" if role==1 else "org.jnox.Tiles") for m in select("xdg_toplevel","set_app_id")),"peer app identity")
        slots=[scene[4:10],scene[10:16]]
        slot=next((s for s in slots if s[0]==peer["fd"]),None)
        alive = role==1 or idx<4
        if alive:
            require(slot and (slots.index(slot)==scene[2])==(focus_role==role),"scene socket focus")
        else:
            require(slot is None,"terminated peer still connected")
            slot=next(s for s in slots if s[0]==(1<<64)-1)
        pressed = protocol_stage(msgs,slot,alive,focus_role==role)
        expected = (([],[45],[45],[45],[45],[45,45]) if role==1 else
                    ([],[],[],[45],[45,37],[45,37]))
        require(pressed==expected[idx],"peer key press sequence")
        require(any(m["args"]["interface"]=="wl_seat" and m["args"]["version"]==4 for m in select("wl_registry","global")) and
                any(m["args"]["interface"]=="wl_seat" and m["args"]["version"]==1 for m in select("wl_registry","bind")),"guest seat versions")
        require(select("wl_shm","create_pool") and select("wl_shm_pool","create_buffer"),"transferred pool")
        require(select("wl_keyboard","keymap") and select("xdg_surface","ack_configure"),"keymap fd and configure")
        require(select("wl_surface","attach") and select("wl_surface","commit"),"surface commit")
        require(not select("wl_display","error"),"wire error")
        if role == 2 and idx>=4:
            require(any(m["args"]["key"]==37 and m["args"]["state"]==1 for m in select("wl_keyboard","key")),"B abrupt key")
            continue
        w = memory["client"][str(role)]
        keyevents = select("wl_keyboard","key")
        require(sum(m["args"]["key"]==45 and m["args"]["state"]==1 for m in keyevents)==w[14],"wire X presses vs client")
        require(any(m["args"]["serial"]==w[10] for m in select("xdg_surface","ack_configure")),"configure serial")
        require(any(m["args"]["size"]==w[7] for m in select("wl_keyboard","keymap")),"keymap size")
        callbacks={m["args"]["callback"] for m in select("wl_surface","frame")}
        require(sum(m["object"] in callbacks for m in select("wl_callback","done"))>=w[19],"wire frame done count")
        require(len(select("wl_buffer","release"))>=w[18],"wire release count")
    for i in (1,2):
        if i == 2 and idx >= 4:
            continue
        w = memory["client"][str(i)]
        require(w[2] == w[4] == 0 and w[5] == 15 and w[7] and w[8] and w[9] and w[10],
                f"{stage} role {i} registry/keymap/configure")
        require(w[14] == ((0,1,1,1,1,2) if i==1 else (0,0,0,1,1,1))[idx], "key routing")
        require(w[28] == 3 and w[17] > 0, "device isolation or surface submission")
        shares = memory["aliases"][str(i)]
        require(len(shares)==12 and len({page for page,_ in shares})==12, "shared surface pages")
        for _, owners in shares:
            require(len(owners[i])==1 and owners[i][0][1], "missing client writer")
            require(len(owners[0])==1 and not owners[0][0][1], "missing compositor read-only alias")
            require(not owners[3-i] and not owners[3], "unexpected role maps surface")
        if idx and w[14]:
            require(w[18] and w[19], "no release/frame callback")


def verify(out):
    pkg = out/"package"
    provenance = json.loads((out/"source.json").read_bytes())
    tree = (out/"source-tree.git").read_bytes()
    require(provenance["tree_sha256"]==hashlib.sha256(tree).hexdigest(), "source tree hash")
    require(provenance["commit"]==json.loads((pkg/"manifest.json").read_bytes())["commit"], "source commit")
    for run in ("cold-1","cold-2"):
        dest = out/run
        timeline = [json.loads(l) for l in (dest/"events.jsonl").read_text().splitlines()]
        require(all(a[0]<=b[0] for a,b in zip(timeline,timeline[1:])), "timestamps")
        launch = next(data for _,kind,data in timeline if kind=="launch")
        require(launch[0][1:1+len(FLAGS)]==FLAGS and launch[2]==digest(pkg/"kernel.elf"), "launch")
        require(any(kind=="running-executable" and data==launch[1] for _,kind,data in timeline), "live QEMU")
        require([data for _,kind,data in timeline if kind=="pl011"]==[s[-1].hex() for s in SCENES], "input")
        for scene in SCENES:
            stage = scene[0]
            require((dest/(stage+".ppm")).read_bytes()==frame(scene), "pixels "+stage)
        for stage in [s[0] for s in SCENES]+["terminal"]:
            result = observe(PageArchive.load(dest/(stage+".pages.z")),pkg,stage)
            require(json.loads(json.dumps(result))==json.loads((dest/(stage+".json")).read_bytes()), "raw replay "+stage)
            validate(result,stage)
        codes = json.loads((out/"contract.json").read_bytes())["exits"]
        actual = re.findall(rb"(?m)^NATIVE EL0 EXIT PID (\d+) (\d+)\r?$",(dest/"uart.bin").read_bytes())
        require(sorted((int(i),int(code)) for i,code in actual)==list(enumerate(codes)), "guest exits")


if __name__=="__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("evidence",type=Path)
    args = parser.parse_args()
    verify(args.evidence)
    print("Both cold boots replayed")
