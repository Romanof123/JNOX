"""Offline integrity and semantic replay. Python 3.10+, Linux, GNU nm."""
from pathlib import Path
import hashlib
import json
import runpy
import struct
import subprocess
import sys
import zlib

ROOT = Path(__file__).resolve().parent
GUEST = ROOT / "guest-01"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(condition, item):
    if not condition:
        raise ValueError(str(item))


def png_pixels(path):
    data = path.read_bytes()
    check(data[:8] == b"\x89PNG\r\n\x1a\n", path)
    cursor = 8
    compressed = bytearray()
    while cursor < len(data):
        n, = struct.unpack_from(">I", data, cursor)
        kind = data[cursor+4:cursor+8]
        chunk = data[cursor+8:cursor+8+n]
        crc, = struct.unpack_from(">I", data, cursor+8+n)
        check(crc == zlib.crc32(kind + chunk), path)
        if kind == b"IHDR":
            check(struct.unpack(">IIBBBBB", chunk) == (320,240,8,2,0,0,0), path)
        if kind == b"IDAT":
            compressed.extend(chunk)
        cursor += n+12
    scan = zlib.decompress(compressed)
    check(len(scan) == 240*961 and not any(scan[::961]), path)
    return b"".join(scan[i+1:i+961] for i in range(0,len(scan),961))


def main():
    inventory = json.loads((ROOT / "files.json").read_bytes())
    for name, expected in inventory.items():
        check(digest(ROOT / name) == expected, name)
    for name, expected in json.loads((GUEST / "sha256.json").read_bytes()).items():
        check(digest(GUEST / name) == expected, name)
    for reader in (GUEST / "observer", ROOT / "review"):
        subprocess.run([sys.executable, "-B", reader/"replay.py", GUEST], check=True)
    subprocess.run([sys.executable, "-B", ROOT/"review/controls.py", GUEST], check=True)
    for ppm in sorted(GUEST.glob("cold-*/*.ppm")):
        png = ROOT / "screens" / ppm.parent.name / (ppm.stem+".png")
        check(ppm.read_bytes() == b"P6\n320 240\n255\n" + png_pixels(png), png)
    locate = runpy.run_path(str(ROOT/"source/verification/wayland/run-reference.py"))["locate"]
    for folder, origin in (("report",(16,24)), ("geometry",(13,22))):
        host = ROOT/"stock-01"/folder
        result = json.loads((host/"result.json").read_bytes())
        check(locate((host/"mapped.raw").read_bytes()) == origin, folder)
        check(result["frame"]["sha256"] == digest(host/"mapped.raw"), folder)
        for field, path in (("server_sha256",ROOT/"build/wayland-host"),
                            ("client_sha256",ROOT/"stock-01/build/reference-client"),
                            ("wire_sha256",host/"client.wire.log")):
            check(result[field] == digest(path), path)
        for lib, expected in result["libraries"].items():
            check(digest(next((ROOT/"upstream/libs").glob(lib+".so.*"))) == expected, lib)
    print("PASS inventory, two frozen readers, controls, 12 PNGs, both host origins and binaries")

if __name__ == "__main__":
    main()
