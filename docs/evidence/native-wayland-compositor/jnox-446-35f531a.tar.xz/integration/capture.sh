#!/usr/bin/env bash
set -euo pipefail
label=${1:?build label}; run=${2:?new capture label}
[[ $label =~ ^446-[a-z0-9-]+$ && $run =~ ^[a-z0-9-]+$ ]]
base="$HOME/jnox406-lab"; d="$base/$label"
exec 9>"$base/run.lock"; flock 9
test -f "$d/host-interop.pass"; test ! -e "$d/$run"
export PYTHONPATH=/mnt/d/codex/jnox332-release-deps PYTHONDONTWRITEBYTECODE=1 LC_ALL=C
qa="$d/$run.observer"; mkdir "$qa"
cp /mnt/d/codex/jnox446-independent/{*.py,*.xml} "$qa/"
cmp "$qa/wayland.xml" /mnt/d/codex/jnox446-upstream/sysroot/usr/share/wayland/wayland.xml
cmp "$qa/xdg-shell.xml" /mnt/d/codex/jnox446-upstream/sysroot/usr/share/wayland-protocols/stable/xdg-shell/xdg-shell.xml
printf '%s\n' '{"exits":[0,71,72,0]}' >"$qa/contract.json"
(cd "$qa" && sha256sum *.py *.xml contract.json) >"$d/$run.observer-sha256"
test "$(git -C "$base/src" rev-parse HEAD)" = "$(cat "$d/source-commit")"
qemu=$(readlink -f "$(command -v qemu-system-aarch64)")
identity(){ date -u -Ins; echo "$qemu"; sha256sum "$qemu"; "$qemu" --version; }
identity >"$d/$run.qemu-before"; trap 'identity >"$d/$run.qemu-after"' EXIT
python3 "$qa/capture.py" --source "$base/src" --package "$d/package" --contract "$qa/contract.json" --out "$d/$run" --timeout 100
python3 "$qa/replay.py" "$d/$run" | tee "$d/$run.replay.log"
