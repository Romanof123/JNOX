#!/usr/bin/env bash
set -euo pipefail
label=${1:?build label}; run=${2:?fresh host report label}
[[ $label =~ ^446-[a-z0-9-]+$ && $run =~ ^[a-z0-9-]+$ ]]
base="$HOME/jnox406-lab"; d="$base/$label"; cd "$base/src"
exec 9>"$base/run.lock"; flock 9
test "$(git rev-parse HEAD)" = "$(cat "$d/source-commit")"
out="$d/$run"; mkdir "$out"
exec > >(tee "$out/host.log") 2>&1
sysroot=/mnt/d/codex/jnox446-upstream/sysroot
export PYTHONDONTWRITEBYTECODE=1 LC_ALL=C
sh verification/wayland/build-reference.sh "$sysroot" "$out/build"
python3 verification/wayland/run-reference.py "$d/wayland-host" "$out/build/reference-client" "$sysroot" "$out/report"
python3 verification/wayland/run-reference.py --geometry "$d/wayland-host" "$out/build/reference-client" "$sysroot" "$out/geometry"
sha256sum "$d/wayland-host" "$out/build/reference-client" >"$out/images.sha256"
printf '%s\n' "$run" >"$d/host-interop.pass"
