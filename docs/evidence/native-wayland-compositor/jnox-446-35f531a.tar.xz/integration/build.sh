#!/usr/bin/env bash
set -euo pipefail
rev=${1:?frozen full git SHA}; label=${2:?new 446-build label}
[[ $rev =~ ^[0-9a-f]{40}$ && $label =~ ^446-[a-z0-9-]+$ ]]
base="$HOME/jnox406-lab"; cd "$base/src"
exec 9>"$base/run.lock"; flock 9
git checkout -q --detach "$rev"
git restore --ignore-skip-worktree-bits --source=HEAD -- arch boards kernel tools sdk services/socket services/wayland examples/native-wayland verification/wayland
test "$(git rev-parse HEAD)" = "$rev"
test -z "$(git status --porcelain --untracked-files=no)"
d="$base/$label"; mkdir "$d"; mkdir "$d/maps" "$d/metadata"
exec > >(tee "$d/build.log") 2>&1
export PATH="$HOME/.cargo/bin:$PATH" CARGO_TARGET_DIR="$d/target" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1 LC_ALL=C PYTHONPATH=/mnt/d/codex/jnox332-release-deps
printf '%s\n' "$rev" >"$d/source-commit"
git ls-tree -r HEAD -- services/{wayland,socket} sdk/native-aarch64 examples/native-wayland verification/wayland >"$d/metadata/source-tree.txt"
rustc -vV >"$d/metadata/rustc.txt"; clang --version >"$d/metadata/clang.txt"
for role in wayland socket; do
    manifest="services/$role/Cargo.toml"
    cargo metadata --offline --no-deps --format-version 1 --manifest-path "$manifest" >"$d/metadata/$role.json"
done
cargo test --offline --manifest-path services/wayland/Cargo.toml -- --nocapture | tee "$d/host-tests.log"
cargo rustc --offline --release --manifest-path services/wayland/Cargo.toml --bin jnox-wayland -- -C "link-arg=-Wl,-Map,$d/maps/wayland-host.map"
cp "$d/target/release/jnox-wayland" "$d/wayland-host"
readelf -W -h -l -d "$d/wayland-host" >"$d/metadata/wayland-host.readelf"
sdk=sdk/native-aarch64
for role in wayland socket; do
    opt=()
    if [[ $role == wayland ]]; then opt=(--local-socket); fi
    CARGO_TARGET_AARCH64_UNKNOWN_NONE_SOFTFLOAT_RUSTFLAGS="-C link-arg=-Map=$d/maps/$role.map" sh "$sdk/build-rust.sh" "${opt[@]}" "services/$role/Cargo.toml" "$d/$role.elf"
done
# SDK build.sh invokes clang once as the driver for this final C link.
mkdir "$d/client-tools"; real_clang=$(command -v clang)
cat >"$d/client-tools/clang" <<EOF
#!/bin/sh
exec "$real_clang" "-Wl,-Map,$d/maps/client.map" "\$@"
EOF
chmod +x "$d/client-tools/clang"
PATH="$d/client-tools:$PATH" sh "$sdk/build.sh" --local-socket examples/native-wayland/client.c "$d/client.elf"
for file in "$d"/*.elf; do readelf -W -h -l -d "$file" >"$d/metadata/$(basename "$file").readelf"; done
python3 /mnt/d/codex/jnox446-integration/elf_audit.py "$d"/*.elf
for role in wayland-host wayland client socket; do test -s "$d/maps/$role.map"; done
python3 -B tools/build_native_el0.py --board virt --policy fifo --display-service 0 --socket-service 3 --shared-fd --ipc-route 0:3 --ipc-route 1:3 --ipc-route 2:3 --elf "$d/wayland.elf" --priority 7 --peer-elf "$d/client.elf" --peer-arg a --peer-priority 5 --peer-elf "$d/client.elf" --peer2-arg b --peer-priority 4 --peer-elf "$d/socket.elf" --peer3-arg 7 --peer-priority 1 --out "$d/package"
sha256sum "$d"/{*.elf,wayland-host,maps/*.map,package/kernel.elf,package/manifest.json} >"$d/metadata/artifacts.sha256"
