"""Build the #446 evidence release from immutable capture directories under WSL."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tarfile
import tempfile
import zlib

HERE = Path(__file__).resolve().parent
BASE = Path.home() / "jnox406-lab"
BUILD = BASE / "446-build-03"
WORK = HERE.parent
REV = "35f531a0f2f088cbcf1baaa7150e18570641d0e8"
ARCHIVE = HERE / "jnox-446-35f531a.tar.xz"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True)+"\n")


def copy(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.is_dir():
        shutil.copytree(src, dst)
    else:
        shutil.copyfile(src, dst)


def chunk(tag, data):
    return struct.pack(">I",len(data))+tag+data+struct.pack(">I",zlib.crc32(tag+data))


def main(out):
    if (BUILD/"source-commit").read_text().strip() != REV:
        raise ValueError("build revision")
    for name in ("guest-01","stock-01"):
        copy(BUILD/name,out/name)
    for name in ("build.log","host-tests.log","source-commit","maps","metadata","socket.elf",
                 "client.elf","wayland.elf","wayland-host","guest-01.observer","guest-01.observer-sha256",
                 "guest-01.qemu-before","guest-01.qemu-after","guest-01.replay.log","package/build.log"):
        copy(BUILD/name,out/"build"/name)
    for label in ("446-build-01","446-build-02"):
        for name in ("source-commit","build.log"):
            copy(BASE/label/name,out/"history"/label/name)
    for filename in ("README.md","replay.py","extract.py","package-release.py"):
        copy(HERE/filename,out/filename)
    copy(WORK/"jnox446-independent/review-build03",out/"review")
    for script in (WORK/"jnox446-integration").glob("*"):
        if script.is_file():
            copy(script,out/"integration"/script.name)
    upstream = WORK/"jnox446-upstream"
    copy(upstream/"debs",out/"upstream/debs")
    for doc in (upstream/"sysroot/usr/share/doc").glob("*/copyright"):
        copy(doc,out/"upstream/licenses"/doc.parent.name/"copyright")
    for lib in ("libwayland-client.so.0.20.0","libxkbcommon.so.0.0.0"):
        copy(upstream/"sysroot/usr/lib/x86_64-linux-gnu"/lib,out/"upstream/libs"/lib)
    repo = BASE/"src"
    def git(*args):
        return subprocess.check_output(["git","-C",repo,*args])
    (out/"git-commit.raw").write_bytes(git("cat-file","commit",REV))
    paths = git("ls-tree","-r","-z",REV,"--","services/wayland","services/socket","verification/wayland","sdk/native-aarch64","examples/native-wayland").split(b"\0")
    for entry in filter(None,paths):
        metadata,name = entry.split(b"\t",1)
        target = out/"source"/name.decode()
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(git("cat-file","blob",metadata.split()[2].decode()))
    for ppm in (out/"guest-01").glob("cold-*/*.ppm"):
        header = b"P6\n320 240\n255\n"
        data = ppm.read_bytes()
        if not data.startswith(header) or len(data) != len(header)+230400:
            raise ValueError(ppm)
        rgb = data[len(header):]
        scan = b"".join(b"\0"+rgb[i:i+960] for i in range(0,len(rgb),960))
        png = out/"screens"/ppm.parent.name/(ppm.stem+".png")
        png.parent.mkdir(parents=True,exist_ok=True)
        png.write_bytes(b"\x89PNG\r\n\x1a\n"+chunk(b"IHDR",struct.pack(">IIBBBBB",320,240,8,2,0,0,0))+chunk(b"IDAT",zlib.compress(scan,9))+chunk(b"IEND",b""))
    summary = {"source":json.loads((out/"guest-01/source.json").read_bytes()),
               "host":{group:json.loads((out/"stock-01"/group/"result.json").read_bytes()) for group in ("report","geometry")},
               "guest":{}, "readers":{}, "build_history":{}}
    for name in ("cold-1","cold-2"):
        cold = out/"guest-01"/name
        uart = (cold/"uart.bin").read_bytes()
        summary["guest"][name]={"uart_sha256":sha(cold/"uart.bin"),
             "fixed_dropped":int(re.search(rb"NATIVE FIXED DROPPED (\d+)",uart)[1]),
             "exits":[[int(p),int(c)] for p,c in re.findall(rb"NATIVE EL0 EXIT PID (\d+) (\d+)",uart)],
             "frames":{f.stem:sha(f) for f in cold.glob("*.ppm")}}
    for label in ("guest-01/observer","review"):
        summary["readers"][label]={f.name:sha(f) for f in (out/label).iterdir() if f.is_file()}
    for path in (out/"history").iterdir():
        summary["build_history"][path.name]=(path/"source-commit").read_text().strip()
    dump(out/"summary.json",summary)
    copy(out/"summary.json",HERE/"summary.json")
    dump(out/"files.json",{str(f.relative_to(out)):sha(f) for f in sorted(out.rglob("*")) if f.is_file()})
    with tarfile.open(ARCHIVE,"w:xz",preset=6) as tar:
        for f in sorted(out.rglob("*")):
            if f.is_file():
                info=tar.gettarinfo(str(f),str(f.relative_to(out)))
                info.mtime=0
                info.uid=info.gid=0
                info.uname=info.gname=""
                info.mode=0o644
                with f.open("rb") as stream:
                    tar.addfile(info,stream)
    files=[ARCHIVE,HERE/"extract.py",HERE/"README.md",HERE/"summary.json"]
    if ARCHIVE.stat().st_size > 6*1024**2:
        with ARCHIVE.open("rb") as stream:
            while data:=stream.read(6*1024**2):
                f=Path(str(ARCHIVE)+f".part{len(files)-4:02}")
                f.write_bytes(data)
                files.append(f)
    (HERE/"SHA256SUMS").write_text("".join(f"{sha(f)}  {f.name}\n" for f in files))

if __name__=="__main__":
    with tempfile.TemporaryDirectory() as tmp:
        main(Path(tmp))
