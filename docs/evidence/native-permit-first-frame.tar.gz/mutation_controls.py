"""In-memory refusal controls on real 013/014 UART bytes. Never writes source inputs."""
def controls(infer, receipt, rejected_type, docs, pins, inputs):
    results = []

    def reject(name, layer, expected, call):
        try:
            call()
        except rejected_type as e:
            if expected not in str(e):
                raise RuntimeError(f"{name}: expected {expected!r}, got {e}") from e
            results.append(dict(control=name, layer=layer, outcome="refused", reason=str(e)))
        else:
            raise RuntimeError(f"{name}: invalid input accepted")

    empty, frame = inputs
    data, run, ref, independent, controller = frame
    path = f"runs/{run}/cap/uart.bin"
    reject("corrupt UART with original receipt", "receipt", "UART SHA-256 mismatch",
           lambda: receipt({**docs,path:data + b"X"}, run, pins[run]))
    reject("different boot UART with original receipt", "receipt", "UART SHA-256 mismatch",
           lambda: receipt({**docs,path:empty[0]},run,pins[run]))
    baseline = infer(*frame)

    def edit(original, tag, index, *, column=None, value=None, drop=False, duplicate=False):
        lines = original.splitlines(keepends=True)
        matches = [i for i,line in enumerate(lines) if line.startswith(tag+b" ")]
        pos = matches[index]
        if drop:
            del lines[pos]
        elif duplicate:
            lines.insert(pos, lines[pos])
        else:
            cells = lines[pos][len(tag):].split()
            cells[column] = str(value).encode("ascii")
            lines[pos] = tag + b" " + b" ".join(cells) + b"\n"
        return b"".join(lines)

    def semantic(name, payload, expected, source=frame):
        reject(name, "semantic replay after receipt check", expected, lambda: infer(payload,*source[1:]))

    semantic("truncated terminal record", data[:data.rfind(b"NATIVE EL0 EXIT PID")], "terminal exits")
    qr = b"NATIVE QUAL ROW"
    semantic("missing QUAL row", edit(data,qr,baseline["commit_row"],drop=True), "QUAL count or loss")
    semantic("nonzero SAFETY loss", edit(data,b"NATIVE SAFETY DROPPED",0,column=0,value=1), "SAFETY loss")
    begin = baseline["safety_first_index"]
    def event(offset, **kwargs):
        return edit(data,b"NATIVE SAFETY EVENT",begin+offset,**kwargs)

    semantic("duplicate receive",event(3,duplicate=True),"B0 receive")
    semantic("mismatched release handle",event(4,column=6,value=99),"frame handle/length")
    semantic("corrupt frame CRC",event(2,column=9,value=0),"snapshot wire CRC")
    semantic("missing post-CRC site",event(6,drop=True),"B0 safety event sequence")
    semantic("field-recheck site duplicated at post-CRC",event(6,column=3,value=514),"commit site order")
    semantic("late first-site operand",event(5,column=2,value=baseline["post_crc"]+1),"QUAL bracket")
    semantic("old state mismatch at recheck",event(7,column=5,value=3),"commit prior state")
    semantic("commit reports wrong sequence",event(8,column=7,value=9),"accepted commit state")
    semantic("commit qualifier after precedes journal",edit(data,qr,baseline["commit_row"],column=7,
             value=baseline["commit_status"]-1),"QUAL bracket")
    semantic("empty receive reports returned frame length",edit(empty[0],b"NATIVE SAFETY EVENT",
             infer(*empty)["safety_first_index"]+2,column=8,value=44),"empty receive registers",empty)
    reject("independent reference disagrees", "cross-check", "independent CSV: sequence",
           lambda: infer(data,run,ref,{**independent, "sequence":"2"},controller))
    bad_sample = controller.copy()
    bad_sample[6] = baseline["commit_entry"]+1
    reject("RAM post-decode INFO lies outside call", "semantic replay after receipt check",
           "RAM private decode INFO sample", lambda: infer(data,run,ref,independent,bad_sample))
    bad_state = controller.copy()
    bad_state[13] += 1
    reject("RAM private sequence disagrees", "semantic replay after receipt check",
           "RAM protected/private sequence and issue", lambda: infer(data,run,ref,independent,bad_state))
    return results
