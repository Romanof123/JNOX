"""Optional full-source replay of the recorded B0 controller RAM rows (GNU AArch64 nm)."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="restored original packet root with ELF/RAM files")
    root = parser.parse_args().source.resolve()
    scorer = root / "scripts/score.py"
    if hashlib.sha256(scorer.read_bytes()).hexdigest() != "48a855144cc7486290f4d773c3104e5474fd61c49ce72d18d5997e9b61ed5871":
        raise ValueError("wrong original scorer")
    spec = importlib.util.spec_from_file_location("source_score", scorer)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    grouped = json.loads((root / "results/boots.json").read_bytes())
    selected = [b for b in grouped if 13 <= int(b["run"][:3]) <= 44]
    if sorted(int(b["run"][:3]) for b in selected) != list(range(13,45)):
        raise ValueError("wrong run set")
    for boot in selected:
        decoded = module.analyze(root, root / "runs" / boot["run"])
        if decoded["controller"][1] != boot["controller"][1] or not decoded["functional"]:
            raise ValueError(f"RAM mismatch in {boot['run']}")
    print("32/32 authenticated RAM + ELF re-decodes matched all 18 B0 controller words")


if __name__ == "__main__":
    main()
