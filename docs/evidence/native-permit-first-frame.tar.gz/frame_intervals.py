"""Replay protected CNTPCT samples from first B0 in the frozen #389 comparison."""
import argparse
import csv
import hashlib
import io
import json
import statistics
import struct
import sys
import tarfile
import zlib
from collections import defaultdict
from pathlib import Path


DIRECTORY = Path(__file__).resolve().parent
REFERENCE_CSV = "results/b0-by-boot.csv"
REFERENCE_HASH = "81c89ea89ac30a06c887f818450aa3de2e4f064d3545f58fa3271ccd4391b67c"
BOOTS = "results/boots.json"
BOOTS_HASH = "a7aeb44360c319e3dcea992c7798b6e84c056c7ddea1575916fe8aca9252b8f8"
MASK = (1 << 64) - 1
FREQ = 62_500_000
COMMON_START = ["stage2_entry", "check_entry", "check_after"]
COMMON_END = ["complete_entry", "complete_after", "stage3_entry"]
FRAME = ["snapshot_audit", "recv_audit", "release_audit", "private_decode_info", "commit_entry",
         "precheck", "post_crc", "field_recheck", "commit_status", "commit_after"]
PATHS = {"valid44": COMMON_START + FRAME + COMMON_END,
         "empty": COMMON_START + ["recv_audit"] + COMMON_END}
TOTALS = {
    "stage2_to_stage3": ("stage2_entry", "stage3_entry"),
    "check_entry_to_complete_after": ("check_entry", "complete_after"),
    "check_after_to_complete_entry": ("check_after", "complete_entry"),
    "recv_to_commit_status": ("recv_audit", "commit_status"),
    "recv_to_commit_entry": ("recv_audit", "commit_entry"),
    "release_to_commit_status": ("release_audit", "commit_status"),
    "release_to_commit_entry": ("release_audit", "commit_entry"),
    "commit_entry_to_after": ("commit_entry", "commit_after"),
}


class Rejected(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Rejected(message)


def singleton(rows, label):
    require(len(rows) == 1, f"{label}: expected one, found {len(rows)}")
    return rows[0]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ordered(values, label):
    require(all(a <= b for a, b in zip(values, values[1:])), f"{label}: counter order")


def journal_rows(uart):
    """Parse full protected journal sections including row counts and final exit records."""
    specs = {"NATIVE QUAL ROW": 13, "NATIVE QUAL COUNTS": 4, "NATIVE SAFETY EVENT": 10,
             "NATIVE SAFETY DROPPED": 1, "NATIVE EL0 EXIT PID": 2, "NATIVE FIXED EVENT": 21}
    groups = defaultdict(list)
    for line in uart.decode("ascii").splitlines():
        for tag, width in specs.items():
            if line.startswith(tag):
                parts = line[len(tag):].split()
                require(len(parts) == width and all(p.isdecimal() for p in parts), f"{tag}: bad row")
                row = list(map(int, parts))
                require(max(row) <= MASK, f"{tag}: u64 overflow")
                groups[tag].append(row)
                break
    qual = groups["NATIVE QUAL ROW"]
    count = singleton(groups["NATIVE QUAL COUNTS"], "QUAL count")
    require(count == [FREQ, len(qual), len(qual), 0] and qual, "QUAL count or loss")
    require(all(row[0] == n for n, row in enumerate(qual)), "QUAL index gap or duplicate")
    require(groups["NATIVE SAFETY DROPPED"] == [[0]], "SAFETY loss")
    require(groups["NATIVE EL0 EXIT PID"] == [[0, 71], [1, 72], [2, 73]], "terminal exits")
    safety = groups["NATIVE SAFETY EVENT"]
    require(safety and safety[0][0] == 1 and safety[0][2] == FREQ, "SAFETY boot frequency")
    ordered([r[1] for r in safety], "SAFETY journal")
    return qual, safety, groups["NATIVE FIXED EVENT"]


def frame_identity(snapshot):
    # Event 7 packs six little-endian u64 chunks, including a zero-padded final u32 CRC.
    require(snapshot[-1] <= 0xffffffff, "snapshot padding")
    wire = struct.pack("<6Q", *snapshot[4:])[:44]
    require(zlib.crc32(wire[:40]) == int.from_bytes(wire[40:], "little"), "snapshot wire CRC")
    require(wire[:8] == bytes([1, 1, 44, 0, 1, 0, 1, 1])
            and wire[32:36] == (20).to_bytes(4, "little")
            and wire[36] in (0, 1) and wire[37:40] == bytes(3), "snapshot wire fields")
    generation, seq, issue = struct.unpack_from("<3Q", wire, 8)
    return generation, seq, issue, wire[36]


def verify_qual(decision, site, status):
    require(decision[8] == status[5] == 0, "QUAL/SAFETY service status")
    ordered([decision[5], decision[6], site[2], site[1], status[1], decision[7]], "QUAL bracket")


def check_reference(reference, derived):
    for key, value in derived.items():
        require(reference[key] == ("" if value is None else str(value)), f"independent CSV: {key}")


def infer(uart, run, ref, reference, controller):
    qual, safety, fixed = journal_rows(uart)
    # Indexed QUAL rows are [index, kind, pid, job, phase, stage, target, entry, now, pc, status, ...].
    marks = [r for r in qual if r[1:5] == [1, 1, 0, 2]]
    require([r[5] for r in marks] == [1, 2, 3], "B0 stage marks")
    arm, begin, end = marks
    require(len({r[6] for r in marks}) == 1 and all(r[10] == 0 for r in marks), "B0 mark identity/status")
    ordered([arm[7], arm[8], begin[7], begin[8], end[7], end[8]], "B0 marks")
    decisions = [r for r in qual[begin[0]+1:end[0]] if r[1] == 4]
    journal = [(i, r) for i, r in enumerate(safety) if begin[7] <= r[1] <= end[7]]
    rows = [r for _, r in journal]
    recv = singleton([r for r in rows if r[0] == 6 and r[2:4] == [1, 35]], "B0 receive")
    require(recv[4] in (0, MASK-10), "B0 receive status")
    valid = recv[4] == 0
    occupancy = "valid44" if valid else "empty"
    expected = [[1, 63, 1], [1, 60, 2], [1, 63, 3]] if valid else [[1, 63, 1], [1, 63, 3]]
    require([d[2:5] for d in decisions] == expected, "B0 qualified decision sequence")
    check, complete = decisions[0], decisions[-1]
    # Reject unexpected or duplicated protected events, including unrelated controller loans.
    middle = [7, 6, 6, 12, 12, 12, 5] if valid else [6]
    require([r[0] for r in rows] == [12, 5] + middle + [12, 5, 10], "B0 safety event sequence")
    check_site, check_status = rows[:2]
    complete_site, complete_status, final = rows[-3:]
    verify_qual(check, check_site, check_status)
    verify_qual(complete, complete_site, complete_status)
    require(check_status[2:5] == [1, 63, 1] and complete_status[2:5] == [1, 63, 3],
            "CHECK/COMPLETE identity")
    prior = check_status[6:9]  # generation, last accepted sequence, issue
    require(prior[0] > 0 and check_site[3:] == [1, *prior, 0, 0, 1], "CHECK state")
    require(recv[9] == prior[0] and recv[5] == 0, "receive generation/remaining occupancy")
    require(len(controller) == 18 and controller[0] == begin[6], "B0 RAM target/width")
    require(check_status[1] <= controller[1] <= check[7] and
            final[1] <= controller[2] <= complete[7], "B0 RAM fused samples")
    points = dict(stage2_entry=begin[7], check_entry=check[5], check_after=check[7],
                  recv_audit=recv[1], complete_entry=complete[5], complete_after=complete[7],
                  stage3_entry=end[7])
    run_position, _, _, policy, case = run.split("-")
    row = dict(run=run, position=int(run_position), ref=ref, policy=policy, case=case,
               join="closed", error="", hz=FREQ, occupancy=occupancy, recv_status=0 if valid else -11,
               remaining_queued=recv[5], stage2_row=begin[0], check_row=check[0],
               complete_row=complete[0], stage3_row=end[0], safety_first_index=journal[0][0],
               safety_last_index=journal[-1][0], prior_generation=prior[0], prior_seq=prior[1],
               prior_issue=prior[2], check_qual_before=check[6], complete_qual_before=complete[6],
               ram_check_readback=controller[1], ram_complete_readback=controller[2])
    accepted = prior
    if valid:
        snapshot, _, release, precheck, post_crc, recheck, status = rows[2:-3]
        commit = decisions[1]
        generation, seq, issue, permit = frame_identity(snapshot)
        accepted = [generation, seq, issue]
        require(snapshot[2] == recv[7] == release[6] and recv[8] == 44, "frame handle/length")
        require(release[2:5] == [1, 36, 0] and release[9] == generation, "release status/generation")
        require(snapshot[3] == prior[0] == generation and seq == prior[1]+1, "frame identity")
        require([r[3] for r in (precheck, post_crc, recheck)] == [2, 0x102, 0x202], "commit site order")
        for site in (precheck, post_crc, recheck):
            require(site[4:] == [*prior, 0, 0, 1], "commit prior state")
        require(status[2:9] == [1, 60, 2, 0, *accepted], "accepted commit state")
        require(final[8] == permit and status[9] == complete_status[9], "accepted permit/streak")
        require(controller[3:6] == [0,0,0], "RAM receive/accept/commit status")
        info = singleton([r for r in fixed if r[1] == 61 and r[3] == 1
                          and release[1] <= r[0] <= commit[5]], "release-to-COMMIT INFO call")
        ordered([release[1], info[0], controller[6], commit[5]], "RAM private decode INFO sample")
        verify_qual(commit, precheck, status)
        ordered([commit[6], precheck[2], precheck[1], post_crc[2], post_crc[1], recheck[2],
                 recheck[1], status[1], commit[7]], "commit sites")
        points.update(snapshot_audit=snapshot[1], release_audit=release[1], private_decode_info=controller[6],
                      commit_entry=commit[5],
                      precheck=precheck[2], post_crc=post_crc[2], field_recheck=recheck[2],
                      commit_status=status[1], commit_after=commit[7])
        row.update(frame_handle=snapshot[2], frame_length=recv[8], generation=generation,
                   sequence=seq, issue=issue, permit=permit, release_status=0, commit_status_code=0,
                   commit_row=commit[0], commit_qual_before=commit[6], info_call_before=info[0], precheck_audit=precheck[1],
                   post_crc_audit=post_crc[1], field_recheck_audit=recheck[1])
    else:
        require(recv[7:9] == [0, 0], "empty receive registers")
        require(check_status[9] == complete_status[9], "empty COMPLETE streak")
        require(controller[3:7] == [MASK-10,1<<63,1<<63,0], "RAM empty attempt/skip fields")
    require(controller[11:15] == [*accepted[1:], *accepted[1:]], "RAM protected/private sequence and issue")
    require(complete_site[3:] == [3, *accepted, 0, 0, 1]
            and complete_status[6:9] == accepted, "COMPLETE state")
    require(final[4:8] == [0, *accepted] and final[9] == complete_status[9], "completion record")
    ordered([complete[6], final[2], complete_site[2], complete_status[1], final[3], final[1],
             complete[7]], "completion record")
    ordered([points[k] for k in PATHS[occupancy]], "consecutive samples")
    row.update(points)
    path = PATHS[occupancy]
    intervals = {f"dt_{a}_to_{b}": points[b] - points[a] for a,b in zip(path, path[1:])}
    row.update(intervals)
    row.update({f"total_{name}": points[b]-points[a] for name,(a,b) in TOTALS.items()
                if a in points and b in points})
    require(sum(intervals.values()) == row["total_stage2_to_stage3"], "partition sum")
    last = points["commit_status"] if valid else recv[1]
    independent = dict(run=run, ref=ref, policy=policy, case=case, recv=row["recv_status"],
                       handle=row.get("frame_handle"), sequence=row.get("sequence"),
                       release_status=row.get("release_status"), commit_status=row.get("commit_status_code"),
                       qual_row_mark=begin[0], qual_row_check=check[0], qual_row_complete=complete[0])
    bands = dict(check_svc=[check[7]-check[5]]*2, complete_svc=[complete[7]-complete[5]]*2,
                 check_to_complete=[final[2]-check_site[1],final[3]-check_site[2]],
                 checked_to_recv_journal=[recv[1]-check_site[1],recv[1]-check_site[2]],
                 last_loan_or_commit_to_complete=[final[2]-last,final[3]-last],
                 recv_to_release_journal=[points["release_audit"]-recv[1]]*2 if valid else [None]*2,
                 release_to_commit_journal=[last-points["release_audit"]]*2 if valid else [None]*2)
    for key, (lo,hi) in bands.items():
        independent.update({key+"_lo":lo, key+"_hi":hi})
    check_reference(reference, independent)
    return row


def read_inputs(source, filenames):
    if source.is_dir():
        return {name:(source / name).read_bytes() for name in filenames if (source / name).is_file()}
    content = {}
    with tarfile.open(source, "r|*") as archive:
        for member in archive:
            name = member.name.removeprefix("./")
            if name in filenames:
                require(name not in content and member.isfile(), f"duplicate/nonregular member {name}")
                content[name] = archive.extractfile(member).read()
    return content


def receipt(documents, run, pinned_session):
    base = f"runs/{run}/cap/"
    session = documents[base + "session.json"]
    uart, launch = documents[base + "uart.bin"], documents[base + "launch.json"]
    require(sha(session) == pinned_session, "unrecognized session receipt")
    session = json.loads(session)
    require(session["marker"] == "EXIT 71", "receipt exit marker")
    require(sha(uart) == session["hashes"]["uart.bin"], "UART SHA-256 mismatch")
    require(sha(launch) == session["hashes"]["launch.json"], "launch SHA-256 mismatch")
    package = json.loads(launch)["argument_package"]
    require(package["commit"].startswith(run.split("-")[1]) and package["tracked_changes"] == "",
            "launch provenance")
    return uart, package["commit"]


def write_csv(path, rows, fields=None):
    if fields is None:
        fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def position_fields():
    identity = ("run position ref policy case join error hz uart_sha256 occupancy recv_status "
                "remaining_queued frame_handle frame_length generation sequence issue permit "
                "release_status commit_status_code prior_generation prior_seq prior_issue stage2_row "
                "check_row commit_row complete_row stage3_row safety_first_index safety_last_index").split()
    samples = ("stage2_entry check_entry check_qual_before ram_check_readback check_after snapshot_audit recv_audit "
               "release_audit info_call_before private_decode_info commit_entry commit_qual_before precheck precheck_audit post_crc "
               "post_crc_audit field_recheck field_recheck_audit commit_status commit_after "
               "complete_entry complete_qual_before ram_complete_readback complete_after stage3_entry").split()
    spans = list(dict.fromkeys(f"dt_{a}_to_{b}" for path in PATHS.values()
                               for a,b in zip(path,path[1:])))
    return identity + samples + spans + [f"total_{name}" for name in TOTALS]


def summary(rows):
    samples = defaultdict(list)
    for row in rows:
        for key,value in row.items():
            if key.startswith(("dt_", "total_")):
                samples[(row["ref"], row["occupancy"], key)].append(value)
    return [dict(ref=ref, occupancy=occ, metric=metric, count=len(vals), min_ticks=min(vals),
                 median_ticks=statistics.median(vals), max_ticks=max(vals))
            for (ref,occ,metric),vals in sorted(samples.items())]


def run_analysis(source, output):
    from mutation_controls import controls
    with (DIRECTORY / "input-sessions.csv").open() as f:
        pins = {r["run"]:r["session_sha256"] for r in csv.DictReader(f)}
    require([int(r[:3]) for r in pins] == list(range(13,45)), "sealed position set")
    needed = {f"runs/{r}/cap/{f}" for r in pins for f in ["session.json", "launch.json", "uart.bin"]}
    docs = read_inputs(source, needed | {REFERENCE_CSV, BOOTS})
    require(sha(docs[REFERENCE_CSV]) == REFERENCE_HASH, "independent CSV provenance")
    require(sha(docs[BOOTS]) == BOOTS_HASH, "RAM reduction provenance")
    selected = [b for b in json.loads(docs[BOOTS]) if b["run"] in pins]
    require(len(selected) == len(pins) and {b["run"] for b in selected} == set(pins), "RAM run set")
    boots = {b["run"]:b for b in selected}
    references = list(csv.DictReader(io.StringIO(docs[REFERENCE_CSV].decode("ascii"))))
    require(len(references) == len(pins) and {r["run"] for r in references} == set(pins), "independent run set")
    references = {r["run"]: r for r in references}
    rows, test_inputs = [], []
    for run, pin in pins.items():
        try:
            uart, ref = receipt(docs, run, pin)
            ram = boots[run]
            require(ram["rev"] == ref and ram["phases"][1]["job"] == 0 and ram["phases"][1]["phase"] == 2,
                    "RAM boot/phase identity")
            inputs = (uart, run, ref, references[run], ram["controller"][1])
            row = infer(*inputs)
            row["uart_sha256"] = sha(uart)
            if run[:3] in ("013", "014"):
                test_inputs.append(inputs)
        except (ValueError, KeyError, TypeError) as err:
            row = dict(run=run, position=int(run[:3]), join="open", error=str(err))
        rows.append(row)
    output.mkdir(parents=True, exist_ok=True)
    write_csv(output / "b0-frame-positions.csv", rows, position_fields())
    errors = [r for r in rows if r["join"] != "closed"]
    if errors:
        raise Rejected("; ".join(f'{r["run"]}: {r["error"]}' for r in errors))
    tests = controls(infer, receipt, Rejected, docs, pins, test_inputs)
    write_csv(output / "b0-frame-controls.csv", tests)
    write_csv(output / "b0-frame-summary.csv", summary(rows))
    print(f"{len(rows)} closed positions, 0 open, {sum(r['occupancy']=='valid44' for r in rows)} valid44, "
          f"{sum(r['occupancy']=='empty' for r in rows)} empty, {len(tests)} expected refusals")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="original full tar.gz or restored/extracted raw packet root")
    parser.add_argument("outdir", type=Path, help="new or empty directory for generated CSV files")
    args = parser.parse_args()
    try:
        require(not args.outdir.exists() or (args.outdir.is_dir() and not any(args.outdir.iterdir())),
                "select an empty output directory")
        run_analysis(args.source, args.outdir)
    except (OSError, ValueError, TypeError, KeyError, tarfile.TarError) as exc:
        sys.exit(f"rejected: {exc}")
