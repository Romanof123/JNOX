import json,re,pathlib,collections
r=pathlib.Path('.')
m=json.loads((r/'raw/metadata.json').read_bytes())
rows=json.loads((r/'raw/open-items.json').read_bytes())
doc=next((r/'head/docs/evidence').glob('*.md')).read_text(encoding='utf8')
table=[l.split(' | ') for l in doc.splitlines() if l.startswith('| [#')]
assert len(table)==len(rows)==49
for row in rows:
 n=row['number']; t=next(t for t in table if t[0].startswith('| [#'+str(n)+']'))
 assert [l['name'] for l in row['labels'] if l['name'].startswith('team:')]==[t[2].strip(' |')],(n,t)
 assert row['state']=='open' and row['updated_at']<=m['captured_utc'],n
 if row.get('pull_request'):
  assert int(re.search(r'#(\d+)',t[1])[1])==m['primary'][str(n)]
 else:
  assert row['title']==t[1] and sorted(map(int,re.findall(r'\[#(\d+)\]',t[3])))==sorted(int(k) for k,v in m['primary'].items() if v==n)
print('49 exact rows, titles, role and inverse lists passed')
