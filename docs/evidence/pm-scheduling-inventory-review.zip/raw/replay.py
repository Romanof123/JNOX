from pathlib import Path
import csv, hashlib, json, re, subprocess, sys
root=Path(sys.argv[1]).resolve(); here=Path(__file__).resolve().parent
meta=json.loads((here/'metadata.json').read_text(encoding='utf-8')); raw=(here/'open-items.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()==meta['raw_sha256']
rows=json.loads(raw); issues={x['number']:x for x in rows if not x.get('pull_request')}; prs={x['number']:x for x in rows if x.get('pull_request')}
assert len(issues)==meta['open_issues'] and len(prs)==meta['open_prs']
def call(tool,*args):
    return subprocess.check_output([sys.executable,'-B',str(root/'tools'/tool),*args],cwd=root,encoding='utf-8')
audit=call('open_tracking.py',str(here/'open-items.json')); assert audit.splitlines()==(here/'tracking.txt').read_text(encoding='utf-8').splitlines()
assert {int(k) for k in meta['primary']}==set(prs)
for p, i in meta['primary'].items():
    row=next(x for x in audit.splitlines() if x.startswith('PR #'+p+':'))
    assert '#'+str(i) in re.findall(r'#[0-9]+',row.split(':',1)[1]) and i in issues
graph=call('requirement_graph.py'); req=len(set(re.findall(r'^(REQ-[0-9]{3})\b',graph,re.M)))
sched=json.loads(call('scheduling_evidence.py')); assert sched['findings']==[]
with (root/'trace'/'links.csv').open(encoding='utf-8-sig', newline='') as f: edges=list(csv.reader(f))[1:]
assert len(set((r[0],r[1],r[2]) for r in edges))==len(edges)
counts=dict(requirements=req,policies=len(sched['policies']),numbered_evidence=len(sched['evidence']),unique_edges=len(edges),typed_nodes=len({n for a,_,b in edges for n in (a,b)}))
assert counts==meta['trace'],(counts,meta['trace'])
print(f"{len(issues)} issues, {len(prs)} PRs, {len(meta['primary'])} reciprocal primaries; checked {counts}")
