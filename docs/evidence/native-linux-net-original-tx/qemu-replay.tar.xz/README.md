# JNOX #430 native Linux transmit callback

Extract the archive to an empty directory on Linux. From inside that directory run `sh replay.sh`. The replay needs Python 3.10 or newer, GNU `sha256sum`, `nm` and `aarch64-linux-gnu-nm`. These commands are provided by coreutils, binutils and binutils-aarch64-linux-gnu on Debian/Ubuntu. It uses the bundled pyelftools 0.32, works offline and reads the recorded captures. The checksum file covers every payload file, including this guide and the replay script.

Both runs used the JNOX native driver service and an isolated peer, built at `07b209362c0b521f64942f6b22a7fadf333516a7`. Each original `capture-*/launch.json` identifies the QEMU executable, command, MAC, MTU, kernel, service and import manifest. Absolute paths in those original records describe the historical build. All offline inputs reside in this archive.

Each capture retains both length-prefixed Ethernet socket directions, the matching PCAP, the eight-byte test challenge, raw UART, QEMU execution and MMIO trace, and CPU-stop records with sparse physical-memory reads for ready, active and final phases. The offline verifier checks the pinned callback's linked instructions, execution count, queue registers, completion indexes, packet contents, and native service and peer receipts. Its mutation checks run on temporary copies.

The upstream driver is Linux stable v6.18.65, `drivers/net/virtio_net.c`, from commit `4700e3adf3b24b39dd4929e9c6d62811ba3ccea8`. The original translation unit, used headers, compiled objects, linker map and generated layout are included. The driver retains its GPL-2.0-or-later notice. See `source/GPL-2.0`, the header notices and `vendor/pyelftools-0.32.dist-info/LICENSE`. The package captures upstream `start_xmit` with native receive handling on QEMU virtio-net. Hardware qualification and upstream `virtnet_poll` execution require their own evidence.

`qa/` holds the independent analysis and its original report. `result.json` describes both capture configurations and associates the QA files with their SHA-256 values.
