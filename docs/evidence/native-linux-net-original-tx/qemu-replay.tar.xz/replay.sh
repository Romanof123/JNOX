#!/bin/sh
set -eu
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$PWD/vendor:$PWD/tools"
unset PYTHONOPTIMIZE
sha256sum --quiet -c SHA256SUMS
for run in capture-a capture-b; do
    echo "$run"
    python3 -B tools/verify_linux_source_net_packets.py --replay --mutation-tests \
        --package native --driver-manifest imported/import.json --out "$run"
done
python3 -B - <<'PY'
import json, subprocess, sys
from pathlib import Path
recorded = json.loads(Path("qa/result.json").read_bytes())
actual = json.loads(subprocess.check_output([sys.executable, "-B", "qa/read_wire.py", "."]))
if actual != recorded:
    sys.exit("independent replay differs from the retained report")
print("PASS independent raw socket, PCAP, callback entry, queue notifications and physical ring indices for both boots")
PY
