"""Offline reader for frozen issue 430 QEMU socket, PCAP, execution and DMA evidence."""
import hashlib
import json
import re
import struct
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])
def frames(data, pcap=False):
    pos = 24 if pcap else 0
    if pcap:
        assert struct.unpack_from("<IHH", data) == (0xa1b2c3d4, 2, 4)
        assert struct.unpack_from("<I", data, 20)[0] == 1
    result = []
    while pos < len(data):
        if pcap:
            _, _, length, original = struct.unpack_from("<IIII", data, pos)
            assert length == original
            pos += 16
        else:
            length, = struct.unpack_from(">I", data, pos)
            pos += 4
        assert 14 <= length <= len(data) - pos
        result.append(data[pos:pos+length])
        pos += length
    return result

def inspect(folder, entry):
    nonce = (folder / "nonce.bin").read_bytes()
    host_mac = bytes.fromhex("024a4e4f5801")
    guest_mac = bytes.fromhex("525400193041" if folder.name == "capture-a" else "525400193042")
    proto = bytes.fromhex("88b5")
    inbound = frames((folder / "host-to-guest.bin").read_bytes())
    outbound = frames((folder / "guest-to-host.bin").read_bytes())
    assert len(nonce) == 8
    assert inbound == [guest_mac + host_mac + proto + tag + nonce + bytes(30)
                       for tag in (b"JNOXCHAL", b"JNOXACK!")]
    assert len(outbound) == 80
    for seq, packet in enumerate(outbound):
        assert packet[:34] == host_mac + guest_mac + proto + b"JNOXDATA" + nonce + seq.to_bytes(4, "big")
        assert len(packet) == 60 + seq % 32
        assert packet[34:] == bytes((seq + n) % 256 for n in range(34, len(packet)))
    assert frames((folder / "wire.pcap").read_bytes(), True) == [inbound[0], *outbound, inbound[1]]
    trace = (folder / "machine.log").read_text()
    entries = len(re.findall(r"^Trace [^\n]*\[[^/]+/" + f"{entry:016x}" + "/", trace, re.M))
    assert entries == 80
    registers = {}
    notify = []
    for match in re.finditer(r"memory_region_ops_write .*?addr 0xa003e([0-9a-f]{2}) value (0x[0-9a-f]+) size 4 name 'virtio-mmio'", trace):
        reg, value = int(match[1],16), int(match[2],16)
        if reg == 0x30:
            queue = value
        if reg in (0x38,0x80,0x90,0xa0) and value:
            registers[queue,reg] = value
        if reg == 0x50:
            notify.append(value)
    assert notify.count(1) == 80
    ring = {}
    for stage in ("ready","active","final"):
        ram = json.loads((folder / stage / "ram.json").read_text())
        def idx(addr):
            base = addr & ~4095
            page = bytes.fromhex(ram[f"{base:x}/4096"])
            return struct.unpack_from("<H",page,addr-base+2)[0]
        ring[stage] = [[idx(registers[q,r]) for r in (0x90,0xa0)] for q in (0,1)]
    assert registers[1,0x38] == 32 and ring["ready"][1] == [0,0] and ring["active"][1] == [80,80]
    return dict(nonce=nonce.hex(), frame_bytes=sum(map(len,outbound)), lengths=[len(p) for p in outbound], entries=entries, notifications=[notify.count(0),notify.count(1)], rx_tx_avail_used=ring)

elf = root / "imported/service.elf"
symbols = subprocess.check_output(["nm","-S",elf],text=True)
entry = int(re.search(r"^(\w+) \w+ T start_xmit$",symbols,re.M)[1],16)
results = {name:inspect(root/name,entry) for name in ("capture-a","capture-b")}
assert results["capture-a"]["nonce"] != results["capture-b"]["nonce"]
print(json.dumps(dict(service_sha256=hashlib.sha256(elf.read_bytes()).hexdigest(),entry=hex(entry),boots=results), indent=2))

