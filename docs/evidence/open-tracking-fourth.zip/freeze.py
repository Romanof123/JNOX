import pathlib,json
p=pathlib.Path(__file__).parent
u='https://github.com/Romanof123/JNOX/issues/6'
f='https://else.invalid/path(a(#6))'
yes=['#6','(#6).','Romanof123/JNOX#6',u,'('+u+').','<'+u+'>','[#91]('+u+')',f+' #6','> <code>\n\nTracks #6','`<pre>`\n\n#6','~~~\n<pre>\n~~~\n\n#6','    <pre>\n\n#6']
no=[f,f+';',f+'?#6',f+',#6',u+'#frag(#6)',u+'?a=(#6)',u+'%28#6%29','other/JNOX#6','> #6','`#6`','    #6','<pre>#6</pre>','<!-- #6 -->','foo#6','https://else.invalid/guide(#6)','https://else.invalid/guide(<'+u+'>)','https://else.invalid/doc([link]('+u+'))']
roles='pm systems functional-safety development integration verification release'.split()
(p/'freeze.json').write_text(json.dumps(dict(body={**dict.fromkeys(yes,True),**dict.fromkeys(no,False)},role={**dict.fromkeys(roles,True),'owner':False,'release,pm':False}),indent=2))
