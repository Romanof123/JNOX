import json,pathlib,subprocess,sys
p=pathlib.Path(__file__).parent;q=p.parent/'qa-36eca-rawurl';src=json.loads((p/'old/first/valid.json').read_bytes())
cases={'https://[2001:db8::1]/guide(a)#6 #6':0,'https://[2001:db8::1]/guide(a)#6':1,'https://example.org/guide(a)#6 #6':0}
(p/'ipv6-freeze.json').write_text(json.dumps(cases))
out=[]
for i,(body,want) in enumerate(cases.items()):
 src[1]['body']=body;f=p/f'ipv6-{i}.json';f.write_text(json.dumps(src));r=subprocess.run([sys.executable,'-X','utf8',q/'tools/open_tracking.py',f],capture_output=True,encoding='utf8');out.append([body,want,r.returncode,r.stdout+r.stderr])
(p/'ipv6-results.json').write_text(json.dumps(out,indent=1));print(out)
