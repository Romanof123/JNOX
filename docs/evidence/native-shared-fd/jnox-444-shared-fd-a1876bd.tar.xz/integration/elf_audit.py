import sys
from pathlib import Path
from elftools.elf.elffile import ELFFile

for name in sys.argv[1:]:
    with Path(name).open('rb') as stream:
        image = ELFFile(stream)
        assert image.elfclass == 64 and image.little_endian
        assert image['e_type'] == 'ET_EXEC' and image['e_machine'] == 'EM_AARCH64'
        segments = list(image.iter_segments())
        assert not any(s['p_type'] in ('PT_INTERP', 'PT_DYNAMIC') for s in segments)
        loads = [s for s in segments if s['p_type'] == 'PT_LOAD']
        assert all((s['p_flags'] & 3) != 3 for s in loads), name
        assert any(s['p_flags'] & 1 and s['p_vaddr'] <= image['e_entry'] < s['p_vaddr'] + s['p_filesz'] for s in loads)
        assert all(s['p_type'] != 'PT_GNU_STACK' or not s['p_flags'] & 1 for s in segments)
        print(name, 'static AArch64 ELF, executable entry, W^X')
