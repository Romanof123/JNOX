#!/usr/bin/env bash
set -euo pipefail
base="$HOME/jnox406-lab"; label=${1:?build label}; run=${2:?new capture label}; mode=${3:?fd or window}
[[ $label =~ ^444-[a-z0-9-]+$ && $run =~ ^[a-z0-9-]+$ ]]
d="$base/$label"; dest="$d/$run"; test ! -e "$dest"
exec 9>"$base/run.lock"; flock 9
export PYTHONDONTWRITEBYTECODE=1 LC_ALL=C PYTHONPATH=/mnt/d/codex/jnox332-release-deps
test "$(git -C "$base/src" rev-parse HEAD)" = "$(cat "$d/source-commit")"
where=$(command -v qemu-system-aarch64); path=$(readlink -f "$where")
identity(){ date -u -Ins; echo "$where"; echo "$path"; sha256sum "$path"; "$path" --version; }
identity > "$d/$run.qemu-before"
trap 'identity > "$d/$run.qemu-after"' EXIT
case "$mode" in
 fd)
    qa=/mnt/d/codex/jnox444-independent
    sha256sum "$qa"/{capture.py,replay.py,contract.json} > "$d/$run.observer-sha256"
    python3 "$qa/capture.py" --package "$d/package" --out "$dest" --contract "$qa/contract.json"
    python3 "$qa/replay.py" "$dest" | tee "$d/$run.replay.log";;
 window)
    python3 "$base/src/tools/verify_native_window_pair.py" --package "$d/window-package" --out "$dest" | tee "$d/$run.window.log";;
 *) exit 2;;
esac
