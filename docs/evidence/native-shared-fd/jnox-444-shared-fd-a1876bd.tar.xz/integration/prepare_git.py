import json, pathlib, subprocess, sys
repo=pathlib.Path("D:/codex/.jnox-work/native-fd-transfer")
out=pathlib.Path("D:/codex/jnox444-integration/blobs")
out.mkdir(parents=True, exist_ok=True)
def git(*args):
    return subprocess.check_output(["git","-c","safe.directory="+repo.as_posix(),*args],cwd=repo)
base,head=sys.argv[1:]
changed=git("diff","--name-only","-z",base,head).decode().split("\0")[:-1]
assert changed
rows=[]
for name in changed:
    row=git("ls-tree",head,"--",name).decode().strip()
    mode,kind,sha=row.partition("\t")[0].split()
    assert kind=="blob"
    content=git("cat-file","blob",sha)
    (out/sha).write_bytes(content)
    rows.append(dict(path=name,mode=mode,type=kind,sha=sha,size=len(content)))
print(json.dumps(rows))
