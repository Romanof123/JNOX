#!/usr/bin/env bash
set -euo pipefail
rev=${1:?frozen full git sha}; label=${2:?new build label}
[[ $rev =~ ^[0-9a-f]{40}$ && $label =~ ^444-[a-z0-9-]+$ ]]
base="$HOME/jnox406-lab"; cd "$base/src"
exec 9>"$base/run.lock"; flock 9
git checkout -q --detach "$rev"
git restore --ignore-skip-worktree-bits --source=HEAD -- arch boards kernel tools sdk services/socket examples/native-fd-transfer examples/native-window-pair
test "$(git rev-parse HEAD)" = "$rev"
test -z "$(git status --porcelain --untracked-files=no)"
d="$base/$label"; mkdir "$d"
exec > >(tee "$d/build.log") 2>&1
export PATH="$HOME/.cargo/bin:$PATH" CARGO_TARGET_DIR="$d/target" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1 LC_ALL=C
export PYTHONPATH=/mnt/d/codex/jnox332-release-deps
printf '%s\n' "$rev" >"$d/source-commit"
python3 -B tools/test_native_service_slots.py
sdk=sdk/native-aarch64
sh "$sdk/build.sh" --local-socket examples/native-fd-transfer/main.c "$d/fd.elf"
sh "$sdk/build-rust.sh" services/socket/Cargo.toml "$d/socket.elf"
sh "$sdk/build-rust.sh" --local-socket examples/native-window-pair/Cargo.toml "$d/window.elf"
mkdir -p "$d/rust-api/src"
cat >"$d/rust-api/Cargo.toml" <<EOF
[package]
name="shared-api-link"
version="0.1.0"
edition="2021"
[dependencies]
jnox-native={path="$PWD/$sdk/rust",features=["local-socket"]}
[profile.release]
panic="abort"
EOF
cat >"$d/rust-api/src/main.rs" <<'RS'
#![no_std]
#![no_main]
use jnox_native::local_socket as s;
#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop { core::hint::spin_loop() } }
#[no_mangle]
pub extern "C" fn main(argc: i32, _: *const *const u8) -> i32 {
    let Ok(backing) = s::shm_create(4096) else {return 1};
    let mut buf = [0u8;1];
    if argc == 3 {
        let _ = s::shm_dup_readonly(backing);
        let _ = s::shm_size(backing);
        let _ = s::shm_map(backing,false).map(|v|v.unmap());
        let _ = s::sendmsg(argc,&buf,Some(backing),0);
        let _ = s::recvmsg(argc,&mut buf,true,0);
    }
    s::close(backing).map_or(2, |_|0)
}
RS
sh "$sdk/build-rust.sh" --local-socket "$d/rust-api/Cargo.toml" "$d/rust-api.elf"
for elf in "$d"/*.elf; do
    readelf -W -h -l -d "$elf" > "$elf.readelf"
done
python3 /mnt/d/codex/jnox444-integration/elf_audit.py "$d"/*.elf
common=(--board virt --policy fifo --priority 7 --peer-priority 5 --peer-priority 4 --peer-priority 1 --display-service 0 --peer3-arg 7 --ipc-route 0:3 --ipc-route 1:3 --ipc-route 2:3)
package(){
    local app=$1 arg1=$2 arg2=$3 out=$4; shift 4
    python3 -B tools/build_native_el0.py "${common[@]}" --elf "$app" --peer-elf "$app" --peer-arg "$arg1" --peer-elf "$app" --peer2-arg "$arg2" --peer-elf "$d/socket.elf" --out "$out" "$@"
}
package "$d/fd.elf" p a "$d/package" --socket-service 3 --shared-fd
package "$d/window.elf" a b "$d/window-package" --socket-service 3
for test in missing-broker duplicate; do
    opts=(--shared-fd)
    if [[ $test == duplicate ]]; then opts+=(--socket-service 3 --shared-fd); fi
    if package "$d/fd.elf" p a "$d/rejected-$test" "${opts[@]}" >"$d/rejected-$test.log" 2>&1; then echo "invalid package accepted: $test" >&2; exit 1; fi
    grep -F -- '--shared-fd requires' "$d/rejected-$test.log"
done
sha256sum "$d"/*.elf "$d"/{package,window-package}/{kernel.elf,manifest.json} > "$d/images.sha256"
