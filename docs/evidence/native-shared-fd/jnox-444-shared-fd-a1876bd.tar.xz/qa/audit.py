"""Independent evidence summary and rehashed negative controls using disposable copies."""
import json
import mmap
from pathlib import Path
import shutil
import struct
import sys
import tempfile
import replay as r


def audit(src):
    src = src.resolve()
    r.replay(src)
    roots, _, ids, witness = r.package(src/"package")
    syms = {n:a for a,_,n in r.symbols(src/"package"/"kernel.elf")}
    base = syms["jnox_native_shared_state"]
    maps = syms["jnox_native_shared_maps"]
    changes = []
    for cold in ("cold-1","cold-2"):
        for phase in ("pretimeout","queued","installed","before","after","terminal"):
            name = f"{cold}/{phase}.ram"
            with (src/name).open("rb") as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as m:
                ram = r.RAM(m)
                w = [struct.unpack("<32q",ram.user(root,witness,256)) for root in roots[:3]]
                desc = list(struct.iter_unpack("BB",ram.read(base+32,64)))
                queued = list(struct.iter_unpack("<QBB6x",ram.read(base+96,128)))
                active = list(struct.iter_unpack("<3Q",ram.read(maps,4*4*24)))
                print(json.dumps(dict(boot=cold,phase=phase,stages=[v[1] for v in w],fds=[
                    [i//8,i%8+96,n,wr] for i,(n,wr) in enumerate(desc) if n],
                    escrow=[q for q in queued if q[0]],maps=[[i//4,i%4,*row] for i,row in enumerate(active) if row[1]],
                    va=[hex(v[4]) for v in w],witness=w[0])))
                if cold!="cold-1":
                    continue
                def alter(title, pa, mask, reason):
                    changes.append((title,name,pa-r.BASE,mask,reason))
                if phase=="queued":
                    pos=next(i for i,q in enumerate(queued) if q[0])
                    alter("queued right write bit",base+96+16*pos+9,1,"queued SCM_RIGHTS reference")
                    alter("expired receive",ram.walk(roots[0],witness+29*8)[0],1,"witness 29")
                if phase=="installed":
                    alter("installed fd98 right",base+32+2*2+1,1,"local descriptor installation")
                if phase=="before":
                    va=w[0][4]
                    table=roots[0]
                    for shift in (30,21):
                        table=int.from_bytes(ram.read(table+8*((va>>shift)&511),8),"little") & r.MASK
                    addr=table+8*((va>>12)&511)
                    leaf=ram.walk(roots[0],va)
                    print(json.dumps(dict(roots=list(map(hex,roots)),elf=ids,firstPA=hex(leaf[0]),
                                          lastPA=hex(ram.walk(roots[0],va+r.SIZE-r.PAGE)[0]),
                                          firstPTE=hex(int.from_bytes(ram.read(addr,8),"little")))))
                    alter("read-only leaf",addr,128,"invalid page permission")
                    alter("physical framebuffer",leaf[0],1,"backing bytes differ")
                    alter("stale fd98",base+32+2*2,1,"receiver retained closed descriptor")
                if phase=="terminal":
                    alter("truncated control",ram.walk(roots[0],witness+16*8)[0],8,"witness 16")
                    alter("terminal descriptor",base+32,1,"retained protected state")
    changes.append(("raw QMP scanout","cold-1/after.ppm",len(b"P6\n320 240\n255\n"),1,"scanout"))
    with tempfile.TemporaryDirectory() as t:
        clone=Path(t)/"evidence"
        clone.mkdir()
        for original in src.rglob("*"):
            dest=clone/original.relative_to(src)
            if original.is_dir():
                dest.mkdir(parents=True,exist_ok=True)
            else:
                dest.symlink_to(original)
        (clone/"sha256.json").unlink()
        hashes=json.loads((src/"sha256.json").read_bytes())
        for title,name,offset,mask,reason in changes:
            dest=clone/name
            dest.unlink()
            shutil.copyfile(src/name,dest)
            with dest.open("r+b") as stream:
                stream.seek(offset)
                val=stream.read(1)[0]
                stream.seek(offset)
                stream.write(bytes([val^mask]))
            (clone/"sha256.json").write_text(json.dumps({**hashes,name:r.digest(dest)}))
            try:
                r.replay(clone)
            except ValueError as exc:
                r.require(reason in str(exc),f"{title}: wrong rejection {exc}")
                print(f"REJECTED {title}: {exc}",flush=True)
            else:
                raise ValueError(f"undetected mutation: {title}")
            dest.unlink()
            dest.symlink_to(src/name)
    r.replay(src)
    print(f"PASS two original captures and {len(changes)} rehashed mutation controls")


if __name__ == "__main__":
    audit(Path(sys.argv[1]))
