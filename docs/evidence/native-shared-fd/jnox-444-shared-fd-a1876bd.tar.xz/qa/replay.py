"""Replay physical snapshots against the independently supplied application contract."""
import argparse
import json
import mmap
from pathlib import Path
import struct
import subprocess
from capture import FLAGS, PACKAGE, digest, require, frame_fixture

PAGE = 4096
BASE = 0x40000000
MASK = (1 << 48) - PAGE
WINDOW = 0x02000000
STRIDE = 512 << 10
SIZE = 320 * 240 * 4


def symbols(path):
    output = subprocess.check_output(["nm", "-S", "--defined-only", path], text=True)
    return [(int(a, 16), int(n, 16), name) for row in output.splitlines()
            if len(parts := row.split()) == 4 for a, n, _, name in [parts]]


def one(entries, predicate):
    values = [entry for entry in entries if predicate(entry[2])]
    require(len(values) == 1, "missing or ambiguous linked symbol")
    return values[0][:2]


class RAM:
    def __init__(self, raw):
        self.raw = raw
        require(len(raw) == 128 << 20, "unexpected physical RAM size")

    def read(self, addr, size):
        offset = addr - BASE
        require(0 <= offset <= len(self.raw) - size, "physical extent outside virt RAM")
        return self.raw[offset:offset + size]

    def walk(self, root, va):
        table, user, write, xn = root, True, True, False
        require(0 <= va < 1 << 39, "VA outside 39-bit TTBR0")
        for shift in (30, 21, 12):
            desc = int.from_bytes(self.read(table + 8*((va >> shift) & 511), 8), "little")
            if not desc & 1:
                return None
            if shift != 12 and desc & 2:
                table = desc & MASK
                user &= not bool(desc & (1 << 61))
                write &= not bool(desc & (1 << 62))
                xn |= bool(desc & (1 << 60))
                continue
            require(shift != 12 or desc & 2, "reserved L3 descriptor")
            low = (1 << shift) - 1
            return ((desc & MASK & ~low) | (va & low),
                    user and bool(desc & 64), write and not bool(desc & 128),
                    xn or bool(desc & (1 << 54)), bool(desc & (1 << 10)))

    def user(self, root, va, size):
        data = bytearray()
        while len(data) < size:
            at = va + len(data)
            mapping = self.walk(root, at)
            require(mapping and mapping[1] and mapping[4], "unreadable EL0 VA")
            length = min(size-len(data), PAGE-at%PAGE)
            data.extend(self.read(mapping[0], length))
        return bytes(data)

    def surfaces(self, root):
        mapped = {}
        for slot in range(4):
            start = WINDOW + slot * STRIDE
            for offset in range(0, STRIDE, PAGE):
                leaf = self.walk(root, start+offset)
                if leaf and leaf[1]:
                    mapped[start+offset] = leaf
        return mapped

    def aliases(self, root, physical_start, size):
        """Enumerate EL0 aliases across TTBR0, including block mappings."""
        found = set()
        def visit(table, shift, va_base):
            for i,(desc,) in enumerate(struct.iter_unpack("<Q",self.read(table,PAGE))):
                if not desc & 1:
                    continue
                va = va_base + (i << shift)
                if shift > 12 and desc & 2:
                    if not desc & (1 << 61):
                        visit(desc & MASK,shift-9,va)
                elif desc & 64:
                    require(shift > 12 or desc & 2, "reserved EL0 descriptor")
                    pa = desc & MASK & ~((1<<shift)-1)
                    for addr in range(max(pa,physical_start), min(pa+(1<<shift),physical_start+size),PAGE):
                        found.add(va+addr-pa)
        visit(root,30,0)
        return found


def package(pkg):
    manifest = json.loads((pkg/"manifest.json").read_bytes())
    kernel = pkg / "kernel.elf"
    image = kernel.read_bytes()
    require(digest(kernel) == manifest["kernel_elf_sha256"], "kernel manifest hash")
    base, size = one(symbols(kernel), lambda n: "native_el0_mmu" in n and "6SPACES" in n)
    require(base % PAGE == 0 and size % (4*PAGE) == 0, "linked root extent")
    roots = [base + i*(size//4) for i in range(4)]
    identities = []
    entries = []
    require(len(manifest["slots"]) == 4, "four-slot manifest")
    for i, slot in enumerate(manifest["slots"]):
        elf = pkg / PACKAGE[2+i]
        data = elf.read_bytes()
        h = digest(elf)
        require(slot["elf_sha256"] == h and slot["slot"] == i and
                slot["expected_ttbr0_el1"] == ((i+1)<<48 | roots[i]), "manifest slot")
        require(data[:6] == b"\x7fELF\x02\x01" and data[18:20] == b"\xb7\0" and data in image,
                "embedded AArch64 identity")
        entry, ph = struct.unpack_from("<QQ", data, 24)
        step, count = struct.unpack_from("<HH", data, 54)
        code = []
        for j in range(count):
            typ, flags, off, va, _, length, _, _ = struct.unpack_from("<II6Q", data, ph+j*step)
            if typ == 1 and flags & 1 and va <= entry <= va+length-32:
                code.append(data[off+entry-va:off+entry-va+32])
        require(len(code) == 1, "executable entry")
        entries.append((entry, code[0]))
        identities.append(h)
    require(len(set(identities[:3])) == 1 and identities[3] != identities[0], "fixture identities")
    witness, extent = one(symbols(pkg/"user.elf"), lambda n: n == "fd_transfer_witness")
    require(extent == 32*8, "witness extent")
    return roots, entries, identities, witness


def scene(ram, roots, expected, words):
    maps = [ram.surfaces(root) for root in roots]
    pixels = expected.read_bytes()
    header = b"P6\n320 240\n255\n"
    require(pixels.startswith(header) and len(pixels) == len(header)+320*240*3, "canonical RGB PPM required")
    aliases = []
    for role in (0, 1):
        first = words[role][4]
        pages = sorted((va,leaf) for va,leaf in maps[role].items() if first <= va < first+STRIDE)
        require(len(pages) == SIZE//PAGE, "unexpected surface or guard page count")
        require((first-WINDOW)%STRIDE == 0, "mapping not at slot base")
        for i, (va, (_, user, write, xn, af)) in enumerate(pages):
            require(va == first+i*PAGE and user and write == bool(role) and xn and af, "invalid page permission")
        aliases.append([leaf[0] for _, leaf in pages])
    require(aliases[0] == aliases[1] and len(set(aliases[0])) == len(aliases[0]), "physical alias mismatch")
    target = set(aliases[0])
    for role, pages in enumerate(maps):
        exposed = [va for va,leaf in pages.items() if leaf[0] in target]
        require(len(exposed) == (SIZE//PAGE if role in (0,1) else 0), "unauthorized alias")
    raw = b"".join(ram.read(addr, PAGE) for addr in aliases[0])
    rgb = bytearray(3 * 320 * 240)
    rgb[0::3], rgb[1::3], rgb[2::3] = raw[2::4], raw[1::4], raw[0::4]
    require(rgb == pixels[len(header):], "XRGB8888 backing bytes differ from external scanout")
    return aliases[0]


def protected_state(ram, roots, symbols_by_name, aliases, stage):
    def region(name, size):
        addr, extent = symbols_by_name["jnox_native_shared_" + name]
        require(extent >= size, name + " extent")
        return ram.read(addr, size)
    state = region("state", 32+64+128)
    sizes = struct.unpack_from("<4Q", state)
    rows = list(struct.iter_unpack("<QQQ", region("maps", 4*4*24)))
    descriptors = list(struct.iter_unpack("BB", state[32:96]))
    escrow = list(struct.iter_unpack("<QBB6s", state[96:224]))
    require(all(0 <= obj <= 4 and wr <= 1 and (obj or not wr) for obj,wr in descriptors), "descriptor encoding")
    require(all(0 <= obj <= 4 and wr <= 1 and pad == bytes(6) and bool(tag)==bool(obj)
                for tag,obj,wr,pad in escrow), "escrow encoding")
    if stage == "terminal":
        require(not any(any(row) for row in rows+descriptors)
                and not any(tag or obj or wr for tag,obj,wr,_ in escrow), "retained protected state")
        require(not any(region("l3",4*512*8)), "terminal protected page table retains entries")
        backing, extent = symbols_by_name["jnox_native_shared_pages"]
        require(all(not ram.aliases(root,backing,extent) for root in roots),"EL0 backing still reachable")
        return
    backing, extent = symbols_by_name["jnox_native_shared_pages"]
    if aliases is None:
        active = [row for row in rows[4:8] if row[1] == SIZE]
        require(len(active)==1, "missing original producer map")
        start = backing+active[0][0]*SIZE
        aliases = list(range(start,start+SIZE,PAGE))
    obj, offset = divmod(aliases[0] - backing, SIZE)
    require(extent == 4*SIZE and 0 <= obj < 4 and offset == 0 and sizes[obj] == SIZE, "protected backing identity")
    require(aliases == list(range(backing+obj*SIZE, backing+(obj+1)*SIZE, PAGE)), "protected pages mismatch")
    for role,root in enumerate(roots):
        slot_pages = ram.surfaces(root)
        expected_aliases = {va for va,entry in slot_pages.items() if aliases[0] <= entry[0] < aliases[0]+SIZE}
        require(ram.aliases(root,aliases[0],SIZE) == expected_aliases, "unexpected alias outside shared window")
        require(role < 2 or not expected_aliases, "unrelated process can access original object")
        for slot in range(4):
            va = WINDOW+slot*STRIDE
            leaf = ram.walk(root, va)
            row = rows[role*4+slot]
            if leaf and leaf[1]:
                n,length,wr = row
                require(0 <= n < 4 and sizes[n] == length and 0 < length <= SIZE and wr <= 1,
                        "invalid protected map metadata")
                expected_count = (length+PAGE-1)//PAGE
                for i in range(STRIDE//PAGE):
                    entry = slot_pages.get(va+i*PAGE)
                    if i < expected_count:
                        require(entry == (backing+n*SIZE+i*PAGE,True,bool(wr),True,True), "protected map mismatch")
                    else:
                        require(entry is None, "guard mismatch")
                if n == obj:
                    require(row == (obj,SIZE,int(role==1)), "active surface permissions")
            else:
                require(row[1] == 0, "unexpected retained map")
                require(not any(va <= p < va+STRIDE for p in slot_pages), "stray authorized page")
    decoy, wr = descriptors[8]
    require(decoy and wr == 1 and decoy != obj+1 and sizes[decoy-1] == 4
            and descriptors[9] == (decoy,0), "reused producer fd96/97")
    require(not any(n for n,_ in descriptors[10:]), "unexpected nonreceiver descriptor")
    received = descriptors[:8]
    pending = [(n,wr) for _,n,wr,_ in escrow if n]
    require(pending == ([(obj+1,0)] if stage=="queued" else []), "queued SCM_RIGHTS reference")
    if stage == "installed":
        filler = received[0][0]
        require(filler not in (0,obj+1,decoy) and received ==
                [(filler,1),(filler,0),(obj+1,0)] + [(0,0)]*5, "local descriptor installation")
    elif stage == "queued":
        require(all(n != obj+1 for n,_ in received), "receiver prematurely installed descriptor")
    else:
        require(received == [(0,0)]*8, "receiver retained closed descriptor")
    require(sum(row[1] == SIZE and row[0]==obj for row in rows[:4]) ==
            int(stage!="queued"), "receiver mapping lifetime")
    require(ram.read(backing+(decoy-1)*SIZE,4) == bytes.fromhex("d4c3b2a1"), "decoy bytes")


def check_gates(events, boot):
    paused = True
    snapshots = []
    sent = 0
    gates = [("queued","72"),("installed","69"),("before","75"),("after","71")]
    for _, kind, value in events:
        if kind == "command":
            cmd, args = value
            if cmd == "cont":
                paused = False
                snapshots = []
            elif cmd == "stop":
                paused = True
            elif cmd == "pmemsave":
                require(paused and args["size"]==128<<20 and args["val"]==BASE, "unsafe snapshot")
                snapshots.append(Path(args["filename"]).name)
        if kind == "pl011":
            stage,key = gates[sent]
            require(paused and value==key and snapshots==[stage+".ram"], "input before matching paused snapshot")
            sent += 1
    require(sent==4 and snapshots==["terminal.ram"], "incomplete cold boot")


def replay(out):
    hashes = json.loads((out/"sha256.json").read_bytes())
    files = {str(p.relative_to(out)) for p in out.rglob("*") if p.is_file() and p != out/"sha256.json"
             and "__pycache__" not in p.parts}
    require(set(hashes) == files and all(digest(out/p) == hashes[p] for p in files), "capture hashes")
    roots, entries, identities, witness = package(out/"package")
    kernel_symbols = {n:(a,s) for a,s,n in symbols(out/"package"/"kernel.elf")}
    contract = json.loads((out/"contract.json").read_bytes())
    expected_exits = [f"NATIVE EL0 EXIT PID {i} {v}".encode() for i,v in enumerate(contract["exits"])]
    emulators = set()
    for boot in (out/"cold-1", out/"cold-2"):
        events = [json.loads(line) for line in (boot/"events.jsonl").read_text().splitlines()]
        argv, emulator_hash, kernel_hash = events[0][2]
        require(argv[1:1+len(FLAGS)] == FLAGS and kernel_hash == hashes[str(Path("package/kernel.elf"))], "launch")
        emulators.add(emulator_hash)
        require(events[1][1:] == ["running-executable",emulator_hash], "running QEMU binary identity")
        check_gates(events, boot)
        gates = [v for _, k, v in events if k=="pl011"]
        require(gates == ["72","69","75", "71"], "external operator input")
        uart = (boot/"uart.bin").read_bytes().splitlines()
        for label, h in zip(["ELF","PEER ELF","PEER2 ELF","PEER3 ELF"], identities):
            require(f"NATIVE EL0 {label} {h}".encode() in uart, "missing UART ELF identity")
        require(sorted(line for line in uart if line.startswith(b"NATIVE EL0 EXIT PID ")) == sorted(expected_exits), "terminal receipts")
        aliases = None
        if (boot/"pretimeout.ram").exists():
            with (boot/"pretimeout.ram").open("rb") as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as raw:
                words = struct.unpack("<32q",RAM(raw).user(roots[0],witness,256))
                require(words[0]==0 and words[1]==9, "wrong pre-deadline receiver phase")
        for stage in ("queued","installed","before", "after", "terminal"):
            with (boot/(stage+".ram")).open("rb") as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as raw:
                ram = RAM(raw)
                if stage == "terminal":
                    require(not any(ram.surfaces(root) for root in roots), "surface survives release/exit")
                    protected_state(ram, roots, kernel_symbols, None,stage)
                elif stage in ("queued","installed"):
                    protected_state(ram, roots, kernel_symbols, None,stage)
                else:
                    expected = out/(stage+".expected.ppm")
                    require(expected.read_bytes() == frame_fixture(int(stage=="after")) ==
                            (boot/(stage+".ppm")).read_bytes(), "scanout")
                    words = [struct.unpack("<32q", ram.user(r,witness,256)) for r in roots[:3]]
                    live = scene(ram, roots, expected, words)
                    protected_state(ram, roots, kernel_symbols, live,stage)
                    require(aliases is None or aliases == live, "backing replaced across external input")
                    aliases = live
                    private_pages = set()
                    for role, (root, (pc, code)) in enumerate(zip(roots, entries)):
                        leaf = ram.walk(root, pc)
                        require(leaf and leaf[1] and not leaf[3] and ram.user(root, pc, 32) == code, "entry identity")
                        if role < 3:
                            private_pages.add(ram.walk(root, witness)[0])
                    require(len(private_pages) == 3, "witness pages must be private")
                for role, fields in contract["witness"][stage].items():
                    words = struct.unpack("<32q", ram.user(roots[int(role)], witness, 256))
                    for index, value in fields.items():
                        require(words[int(index)] == value, f"{stage} role {role} witness {index}")
    require(len(emulators) == 1, "QEMU binary changed across boots")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    replay(parser.parse_args().capture)
    print("Verified captured framebuffer aliases, inputs, permissions, exit receipts and contract witness fields.")
