"""Linux cold-boot recorder. Capture only after the integration gate is released."""
import argparse
import hashlib
import json
import mmap
import struct
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import threading
import time


FLAGS = ["-machine", "virt,gic-version=2", "-cpu", "cortex-a72", "-smp", "1",
         "-accel", "tcg", "-m", "128M", "-nodefaults", "-display", "none",
         "-monitor", "none", "-no-reboot"]
PACKAGE = ["manifest.json", "kernel.elf", "user.elf", "native_peer.elf",
           "native_peer2.elf", "native_peer3.elf"]


def frame_fixture(stage):
    pixels = bytearray()
    for y in range(240):
        for x in range(320):
            pixels.extend(((x+(160 if stage else 32))&255, (y+(112 if stage else 64))&255,
                           216 if ((x>>4)^(y>>4)^stage)&1 else 56))
    return b"P6\n320 240\n255\n" + pixels


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def boot(dest, kernel, emulator, fixtures, exits, timeout):
    dest.mkdir()
    with tempfile.TemporaryDirectory() as tmp, (dest / "uart.bin").open("xb", buffering=0) as uart, (dest / "stderr").open("xb") as err, (dest / "events.jsonl").open("x", buffering=1) as events:
        endpoint = str(Path(tmp) / "serial")
        cmd = [str(emulator), *FLAGS, "-S", "-qmp", "stdio", "-chardev",
               f"socket,id=pl011,path={endpoint},server=on,wait=off", "-serial",
               "chardev:pl011", "-device", "ramfb,id=screen", "-kernel", str(kernel)]
        def record(kind, data):
            events.write(json.dumps([time.monotonic_ns(), kind, data]) + "\n")
        record("launch", [cmd, digest(emulator), digest(kernel)])
        with subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err) as proc, socket.socket(socket.AF_UNIX) as serial:
            timer = threading.Timer(timeout, proc.kill)
            timer.start()
            try:
                running_hash = digest(Path("/proc")/str(proc.pid)/"exe")
                require(running_hash == digest(emulator), "launched executable differs from configured binary")
                record("running-executable", running_hash)
                record("greeting", json.loads(proc.stdout.readline())["QMP"])
                def request(name, **args):
                    record("command", [name, args])
                    proc.stdin.write(json.dumps(dict(execute=name, arguments=args)).encode() + b"\n")
                    proc.stdin.flush()
                    while True:
                        reply = json.loads(proc.stdout.readline())
                        record("reply", reply)
                        if "event" not in reply:
                            return reply["return"]
                request("qmp_capabilities")
                serial.connect(endpoint)
                serial.setblocking(False)
                data = bytearray()
                def drain():
                    while True:
                        try:
                            block = serial.recv(65536)
                        except BlockingIOError:
                            return
                        require(block, "serial disconnected")
                        uart.write(block)
                        data.extend(block)
                def snapshot(stage):
                    request("pmemsave", val=0x40000000, size=128 << 20,
                            filename=str(dest / (stage + ".ram")))
                from replay import RAM, package
                roots, _, _, witness = package(kernel.parent)
                def stages(stage):
                    with (dest/(stage+".ram")).open("rb") as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as raw:
                        ram = RAM(raw)
                        return [struct.unpack("<q",ram.user(root,witness+8,8))[0] for root in roots[:3]]
                request("cont")
                for stage, state, key in [("queued",10,b"r"),("installed",11,b"i")]:
                    while True:
                        time.sleep(.12)
                        drain()
                        request("stop")
                        snapshot(stage)
                        try:
                            values = stages(stage)
                            ready = values == [state,0,1]
                            if stage=="queued" and values[0]==9 and not (dest/"pretimeout.ram").exists():
                                (dest/"queued.ram").rename(dest/"pretimeout.ram")
                                record("pretimeout",values)
                        except ValueError:
                            ready = False
                        if ready:
                            serial.sendall(key)
                            record("pl011",key.hex())
                            request("cont")
                            break
                        request("cont")
                for stage, key in [("before", b"u"), ("after", b"q")]:
                    frame = dest / (stage + ".ppm")
                    wanted = fixtures[stage].read_bytes()
                    while True:
                        drain()
                        try:
                            request("screendump", filename=str(frame))
                        except KeyError:
                            if proc.poll() is not None:
                                raise
                        if frame.exists() and frame.read_bytes() == wanted:
                            request("stop")
                            request("screendump", filename=str(frame))
                            if frame.read_bytes() == wanted:
                                snapshot(stage)
                                states = stages(stage)
                                if states == ([1,1,1] if stage=="before" else [2,2,1]):
                                    break
                            request("cont")
                        time.sleep(.05)
                    drain()
                    serial.sendall(key)
                    record("pl011", key.hex())
                    request("cont")
                while not all(line in data.splitlines() for line in exits):
                    drain()
                    require(proc.poll() is None, "premature QEMU exit")
                    time.sleep(.02)
                request("stop")
                snapshot("terminal")
                drain()
                request("quit")
                require(proc.wait(timeout=5) == 0, "QEMU exit status")
            finally:
                timer.cancel()
                if proc.poll() is None:
                    proc.kill()
                proc.wait()
                timer.join()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("package", "contract", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--qemu", default="qemu-system-aarch64")
    parser.add_argument("--timeout", type=int, default=90)
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True)
    pkg = out / "package"
    pkg.mkdir()
    observer = out/"observer"
    observer.mkdir()
    for name in ("capture.py","replay.py"):
        shutil.copyfile(Path(__file__).resolve().with_name(name),observer/name)
    for name in PACKAGE:
        shutil.copyfile(args.package / name, pkg / name)
    shutil.copyfile(args.contract, out / "contract.json")
    contract = json.loads(args.contract.read_bytes())
    frames = {}
    for stage in ("before", "after"):
        frames[stage] = out / (stage + ".expected.ppm")
        frames[stage].write_bytes(frame_fixture(int(stage=="after")))
    require(frames["before"].read_bytes() != frames["after"].read_bytes(), "identical fixtures")
    require(len(contract["exits"]) == 4, "four terminal exit codes required")
    exits = [f"NATIVE EL0 EXIT PID {i} {n}".encode() for i, n in enumerate(contract["exits"])]
    emulator = Path(shutil.which(args.qemu) or args.qemu).resolve(strict=True)
    for number in (1, 2):
        boot(out / f"cold-{number}", pkg / "kernel.elf", emulator, frames, exits, args.timeout)
    hashes = {str(p.relative_to(out)): digest(p) for p in sorted(out.rglob("*")) if p.is_file()}
    (out / "sha256.json").write_text(json.dumps(hashes, indent=2))
