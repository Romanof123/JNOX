#!/usr/bin/env python3
"""Authenticate and reconstruct the two complete cold boots, then run the frozen readers."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
sys.dont_write_bytecode=True
from evidence_io import checksums, read, regular, require, sha
from source_proof import git_id, tree_objects
from sparse_ram import BLOCK, portable, reconstruct
import window_check

ROOT=Path(__file__).resolve().parent
BUILD=ROOT/"build"
REV="a1876bd4dc51e292fe63b0785bc4ea586b367b97"

def command(argv,cwd):
    env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1","PYTHONNOUSERSITE":"1","LC_ALL":"C"}
    env.pop("PYTHONPATH",None)
    return subprocess.check_output([sys.executable,"-B",*argv],cwd=cwd,env=env)

def authenticate():
    members=checksums(ROOT)
    source=ROOT/"source"
    commit=(source/"commit.raw").read_bytes()
    require(git_id(b"commit",commit)==REV and (BUILD/"source-commit").read_text().strip()==REV,"Git provenance")
    for file in source.rglob("*"):
        if file.is_file() and file!=source/"commit.raw":
            tree_objects(commit,ROOT/"git-trees",file.relative_to(source),file.read_bytes())
    for row in (BUILD/"images.sha256").read_text().splitlines():
        digest,absolute=row.split("  ",1)
        rel=Path(absolute).relative_to("/home/ywcho/jnox406-lab/444-build-01")
        require(sha(regular(BUILD,rel))==digest,"changed input or boot image")
    for raw, packaged in [("fd-cold-01","package"),("window-cold-01","window-package")]:
        src=BUILD/raw/"package"
        pkg=BUILD/packaged
        m=read(pkg/"manifest.json")
        require(m["commit"]==REV and not m["tracked_changes"] and len(m["slots"])==4,"boot package source")
        require(sha(pkg/"kernel.elf")==m["kernel_elf_sha256"] and sha(pkg/"build.log")==m["build_log_sha256"], "kernel or build log")
        image=(pkg/"kernel.elf").read_bytes()
        for f in src.iterdir():
            require(f.read_bytes()==(pkg/f.name).read_bytes(), "different capture-time package "+f.name)
        for s in m["slots"]:
            code=(pkg/s["elf"]).read_bytes()
            require(hashlib.sha256(code).hexdigest()==s["elf_sha256"]==s["input"]["sha256"] and code in image
                    and code==(BUILD/Path(s["input"]["path"]).name).read_bytes(), "embedded ELF identity")
    qa=ROOT/"qa"
    for row in (BUILD/"fd-cold-01.observer-sha256").read_text().splitlines():
        digest,path=row.split("  ",1)
        name=Path(path).name
        observed=BUILD/"fd-cold-01"/("observer" if name.endswith(".py") else "")/name
        require(sha(qa/name)==sha(observed)==digest,"capture-time observer drift")
    qemu=sha(ROOT/"host/qemu-system-aarch64")
    for mode in ("fd","window"):
        for when in ("before","after"):
            lines=(BUILD/(mode+"-cold-01.qemu-"+when)).read_text().splitlines()
            require(lines[3].split()[0]==qemu,"host QEMU binary changed")
    for boot in ("cold-1","cold-2"):
        events=[json.loads(line) for line in (BUILD/"fd-cold-01"/boot/"events.jsonl").read_text().splitlines()]
        require(events[0][1]=="launch" and events[0][2][1]==qemu and events[1][1:] == ["running-executable",qemu],
                "running process digest")
    return members,qemu

def run(dest):
    members,qemu=authenticate()
    layout=read(ROOT/"ram-layout.json")
    cases=layout["files"]
    ledger=read(BUILD/"fd-cold-01/sha256.json")
    expected={f"cold-{n}/{p}.ram" for n in (1,2) for p in ("pretimeout","queued","installed","before","after","terminal")}
    require(layout["block_size"]==BLOCK and set(cases)==expected=={p for p in ledger if p.endswith(".ram")},"RAM stage inventory")
    blocks=ROOT/"ram-blocks"
    require({v[1] for rec in cases.values() for v in rec["blocks"]}=={p.name for p in blocks.iterdir()},"RAM block inventory")
    dest=dest.resolve()
    require(not dest.exists() and not dest.is_relative_to(ROOT),"restore path must be new and outside the archive")
    shutil.copytree(BUILD/"fd-cold-01",dest)
    for name,spec in cases.items():
        require(spec["sha256"]==ledger[name] and spec["size"]==134217728, "original RAM digest or length")
        reconstruct(spec,blocks,dest/portable(name))
    primary=command([dest/"observer/replay.py",dest],dest)
    require(primary==(BUILD/"fd-cold-01.replay.log").read_bytes(),"primary replay differs from capture-time stdout")
    audit=command([ROOT/"qa/audit.py",dest],dest)
    require(audit==(ROOT/"qa/accepted-audit.log").read_bytes(),"independent QA output differs")
    rejected=[r.decode() for r in audit.splitlines() if r.startswith(b"REJECTED ")]
    require(len(rejected)==9,"missing QA mutation results")
    window=window_check.run(ROOT,qemu,REV)
    drops={}
    exits={}
    for name in ("cold-1","cold-2"):
        uart=(dest/name/"uart.bin").read_text()
        drops[name]=int(re.search(r"^NATIVE FIXED DROPPED ([0-9]+)$",uart,re.M)[1])
        exits[name]=re.findall(r"^NATIVE EL0 EXIT PID ([0-9]+) ([0-9]+)$",uart,re.M)
    return {"pass":True,"source_commit":REV,"qemu_sha256":qemu,"verified_archive_members":members,
            "restored_ram_files":len(cases),"restored_ram_bytes":sum(r["size"] for r in cases.values()),
            "unique_ram_blocks":len(list(blocks.iterdir())),"block_size":BLOCK,
            "shared_fd_primary_stdout_equal":True,"shared_fd_qa_stdout_equal":True,
            "shared_fd_qa_two_complete_passes":True,"shared_fd_mutations":rejected,
            "shared_fd_uart_exits":exits,"shared_fd_dropped_fixed_events":drops,"window_regression":window}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--restore",type=Path,help="retain restored fd-cold-01 at this new path outside the extracted archive")
    args=p.parse_args()
    if args.restore:
        result=run(args.restore)
    else:
        with tempfile.TemporaryDirectory(prefix="jnox444-replay-") as d:
            result=run(Path(d)/"fd-cold-01")
    print(json.dumps(result,indent=2))

if __name__=="__main__":
    main()
