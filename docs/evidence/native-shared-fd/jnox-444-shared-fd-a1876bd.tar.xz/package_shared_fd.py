#!/usr/bin/env python3
"""Create the #444 portable evidence archive and verify it from an empty directory."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from evidence_io import archive, copy, export, extract, read, regular, require, sha, write
from source_proof import save_trees
from sparse_ram import BLOCK, encode

HERE = Path(__file__).resolve().parent
REV = "a1876bd4dc51e292fe63b0785bc4ea586b367b97"
FD = "fd-cold-01"

def subtree(src,dst):
    for p in src.rglob("*"):
        require(not p.is_symlink(),"linked capture input "+str(p))
        if p.is_file():
            copy(p,dst/p.relative_to(src))

def package(args,stage):
    b = args.build.resolve()
    qa = args.qa.resolve()
    require((b/"source-commit").read_text().strip()==REV, "wrong build revision")
    for p in b.iterdir():
        if p.is_file():
            copy(p,stage/"build"/p.name)
    for folder in ["package","window-package"]:
        for p in (b/folder).iterdir():
            if p.is_file():
                copy(p,stage/"build"/folder/p.name)
            else:
                require(p.name=="target" and not p.is_symlink(),"unknown package directory")
    allowed_dirs={FD,"package","window-package","rust-api","window-cold-01","target"}
    require({p.name for p in b.iterdir() if p.is_dir()}==allowed_dirs,"unknown build inputs")
    for name in ["rust-api","window-cold-01"]:
        subtree(b/name, stage/"build"/name)

    ledger=read(b/FD/"sha256.json")
    seen = {p.relative_to(b/FD).as_posix() for p in (b/FD).rglob("*") if p.is_file()}
    require(seen==set(ledger)|{"sha256.json"}, "raw file inventory differs")
    copy(b/FD/"sha256.json",stage/"build"/FD/"sha256.json")
    ram={}
    for name,check in ledger.items():
        p=regular(b/FD,name)
        if name.endswith(".ram"):
            spec=encode(p,stage/"ram-blocks")
            require(spec["sha256"]==check and spec["size"]==128<<20, "original RAM digest or size")
            ram[name]=spec
        else:
            copy(p,stage/"build"/FD/name,check)
    require(len(ram)==12,"missing raw RAM")
    write(stage/"ram-layout.json",{"block_size":BLOCK,"files":ram})
    for name in ["capture.py","replay.py"]:
        copy(qa/name,stage/"qa"/name,ledger["observer/"+name])
    copy(qa/"contract.json",stage/"qa/contract.json",ledger["contract.json"])
    for name in ["audit.py","accepted-audit.log"]:
        copy(qa/name,stage/"qa"/name)
    if (qa/"independent.log").exists():
        copy(qa/"independent.log",stage/"qa/earlier-incomplete-audit.log")

    qemu=Path("/usr/bin/qemu-system-aarch64").resolve()
    copy(qemu,stage/"host/qemu-system-aarch64",read(b/"window-cold-01/launch.json")["qemu_sha256"])
    copy(Path("/usr/share/doc/qemu-system-arm/copyright"),stage/"host/qemu-copyright")
    (stage/"host/package-version.txt").write_bytes(subprocess.check_output(["dpkg-query","-W","qemu-system-arm"]))
    for name in ["build.sh","capture.sh","elf_audit.py","prepare_git.py"]:
        copy(args.integration/name,stage/"integration"/name)
    sources=read(b/"window-cold-01/sources.json")
    dirs=["arch","boards","kernel","tools","sdk","services/socket","examples/native-fd-transfer","examples/native-window-pair"]
    export(args.repo.resolve(),REV,dirs,stage/"source")
    for name,check in sources["source_sha256"].items():
        require(sha(regular(stage/"source",name))==check, "source missing "+name)
    save_trees(args.repo.resolve(),REV,stage/"source",stage/"git-trees")
    for folder in ["elftools","pyelftools-0.32.dist-info"]:
        for p in (args.vendor/folder).rglob("*"):
            if p.is_file() and "__pycache__" not in p.parts and p.suffix!=".pyc":
                copy(p,stage/"vendor"/p.relative_to(args.vendor))
    for name in ["replay.py","sparse_ram.py","evidence_io.py","source_proof.py","window_check.py","README.md","package_shared_fd.py"]:
        copy(HERE/name,stage/name)
    files=sorted(p for p in stage.rglob("*") if p.is_file())
    (stage/"SHA256SUMS").write_text("".join(sha(p)+"  "+p.relative_to(stage).as_posix()+"\n" for p in files))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ["build","repo","qa","integration","vendor","out"]:
        p.add_argument("--"+name,required=True,type=Path)
    a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=True)
    name="jnox-444-shared-fd-a1876bd.tar.xz"
    final=a.out/name
    require(not final.exists(), "release archive already exists")
    with tempfile.TemporaryDirectory(prefix="jnox444-release-") as tmp:
        tmp=Path(tmp)
        stage=tmp/"stage"
        package(a,stage)
        candidate=tmp/name
        archive(stage,candidate)
        fresh=tmp/"fresh"
        extract(candidate,fresh)
        env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1","PYTHONNOUSERSITE":"1"}
        env.pop("PYTHONPATH",None)
        observed=subprocess.check_output([sys.executable,"-B",fresh/"replay.py"],cwd=fresh,env=env)
        result=__import__("json").loads(observed)
        result.update(archive=name,archive_sha256=sha(candidate),archive_bytes=candidate.stat().st_size)
        copy(candidate,final,result["archive_sha256"])
        (a.out/(name+".sha256")).write_text(result["archive_sha256"]+"  "+name+"\n")
        write(a.out/"fresh-replay.json",result)
        copy(HERE/"README.md",a.out/"README.md")
        print(__import__("json").dumps(result,indent=2))
if __name__=="__main__":
    main()
