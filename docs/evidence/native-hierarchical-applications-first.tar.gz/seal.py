from pathlib import Path
import hashlib,tarfile
p=Path(__file__).parent
def sha(data):return hashlib.sha256(data).hexdigest()
files=[]
for rd in ['raw','packages','controls']:
 files+=[f for f in (p/rd).rglob('*') if f.is_file()]
files += [p/f for f in ['contract.md','ordinary-groups.md','nested-group-recurring-service.en-ko.md','verification-plan.md','package.log','packages.sh','boots.py','boots.log','audit.py','summarize.py','controls.sh','trace-wrapper.py','plain-wrapper.py','metrics.json','single-frame-proof.json','first-report.en-ko.md','seal.py']]
files=sorted(files)
hashes={str(f.relative_to(p)):sha(f.read_bytes()) for f in files}
(p/'MEMBER-SHA256').write_text(''.join(h+'  '+n+'\n' for n,h in hashes.items()))
arc=p/'hierarchy-first-b276a2e.tar.gz'
with tarfile.open(arc,'x:gz',compresslevel=5) as tf:
 for f in files+[p/'MEMBER-SHA256']:tf.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(arc) as tf:
 for name,digest in hashes.items():assert sha(tf.extractfile(name).read())==digest
 assert tf.extractfile('MEMBER-SHA256').read()==(p/'MEMBER-SHA256').read_bytes()
dig=sha(arc.read_bytes());(p/'archive.sha256').write_text(dig+'  '+arc.name+'\n');print(dig,arc.stat().st_size,len(files))
