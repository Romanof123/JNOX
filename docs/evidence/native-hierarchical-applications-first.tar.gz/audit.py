from pathlib import Path
import sys,struct,re,subprocess,hashlib,json,collections
root=Path(__file__).parent; package=root/'packages'; reports={}
P=15625000
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def parse(s):return [int(x) for x in s.split()]
def q(b,i):return struct.unpack_from('<Q',b,i)[0]
def audit(d):
 case,mode=d.name.rsplit('-',1); p=package/case; m=json.loads((p/'manifest.json').read_text())
 elfids={'saturated':['crc','histogram','energy'],'swap':['energy','histogram','crc'],'child-leaf':['crc','histogram','energy'],'wake':['reporter','histogram','energy'],'single':['crc'],'default':['crc']}[case]
 n=len(elfids); mem=(d/'ram.bin').read_bytes(); base=0x40200000; symbols=(d/'symbols').read_text();u=(d/'uart').read_text()
 def sym(s):return int(next(l.split()[0] for l in symbols.splitlines() if s in l),16)
 space=sym('6SPACES');stride=0x415000
 def pa(a):return a-base
 def walk(rt,va):
  addr=rt&0xfffff000
  for shift in [30,21,12]:
   off=pa(addr)+8*((va>>shift)&511); desc=q(mem,off);assert desc&3==3;addr=desc&0xfffff000
  return addr+(va&4095)
 assert sha(p/'kernel.elf')==m['kernel_elf_sha256'] and m['commit']=='b276a2ed8e9715fc6ced057b84681d77ccead755' and not m['tracked_changes']
 products=[]
 for i,id in enumerate(elfids):
  f=package/(id+'.elf');assert sha(f)==m['slots'][i]['elf_sha256']==sha(p/m['slots'][i]['elf'])
  nm=subprocess.check_output(['nm','-Sn',f],text=True)
  def val(name,width):
   l=next(l.split() for l in nm.splitlines() if l.endswith(' '+name)); a,size=[int(x,16) for x in l[:2]];ofs=pa(walk(space+i*stride,a));return [int.from_bytes(mem[ofs+j:ofs+j+width],'little') for j in range(0,size,width)]
  actual=[val('private_progress',4)[0],val('private_result',8 if id=='energy' else 4)]
  expected={'crc':[134217728,[2124873618]],'histogram':[536870912,[2097152*k for k in (1,8,28,56,70,56,28,8,1)]],'energy':[1073741824,[5864240971776]],'reporter':[3,[7]]}[id]
  assert actual==expected,(actual,expected)
  code={'crc':237,'histogram':70,'energy':179,'reporter':7}[id]
  assert ('NATIVE EL0 EXIT '+('PID '+str(i)+' ' if n>1 else '')+str(code)+'\n') in u
  product=dict(id=id,sha=sha(f),result=actual,exit=code)
  if id=='reporter':
   a=val('report_deadline_ns',8); b=val('report_observed_ns',8);assert all(y>=x for x,y in zip(a,b));product.update(deadline=a,observed=b)
  products.append(product)
 result=dict(products=products)
 if case=='default':return result
 rows=[parse(l) for l in re.findall(r'^NATIVE HIERARCHY EVENT (.*)$',u,re.M)]
 assert 'NATIVE HIERARCHY DROPPED 0' in u and q(mem,pa(sym(' native_hierarchy_lost')))==0 and len(rows)==q(mem,pa(sym(' native_hierarchy_used')))
 begin=pa(sym(' native_hierarchy_rows'))
 assert all(r==list(struct.unpack_from('<47Q',mem,begin+47*8*i)) and r[0]==i for i,r in enumerate(rows))
 epoch=parse(re.search('NATIVE HIERARCHY CONFIG (.*)',u)[1])[1];cfg=m['hierarchy'];pc=cfg['parents'];cc=cfg['children'];lc=cfg['leaves'];caps=pc+[q for _,q in cc]+[q for _,q in lc];bal=caps.copy()
 paths=[[cc[c][0],len(pc)+c,len(pc)+len(cc)+i] for i,(c,_) in enumerate(lc)]
 prev=epoch;old=3;due=0;gr=0;end=0;exitmask=0;sl=[0]*n;pcs=[0x400000]*n;sps=[None]*n
 grants=[];idle=[];parents=[];children=[];leaf=[];sleeps=[];wakes=[];irq=[];cost=collections.defaultdict(list);errs=[];led=[]
 idlepc=sym(' native_sleep_idle');frames=sym('6FRAMES');stack=sym('4IDLE')+0x4000
 for i,r in enumerate(rows):
  _,kind,op,entry,t,settled,sel,chosen,src,target,ready,woke,ex,prior,due_next,gs,ge,charged,overrun,saved,sp,frame,rt,dest,dsp,df,arg,ret,res,*_=r
  assert src==old and prior==due and prev<=t and entry<=t<=settled<=sel<=chosen and (not i or rows[i-1][3]<=entry)
  if src<n:
   assert (gs,ge)==(prev,end) and charged==t-prev and overrun==max(0,t-end)
   assert rt&0xfffff000==space+src*stride and frame==frames+832*src
   pcs[src]=saved;sps[src]=sp
  else:
   assert charged==overrun==0
   if i:assert kind==1 and saved in (idlepc,idlepc+4) and sp==stack;idle.append([i,hex(saved),t-prev])
  cursor=prev
  while cursor<t:
   border=epoch+((cursor-epoch)//P+1)*P;stop=min(t,border)
   if src<n:
    for j in paths[src]:bal[j]-=stop-cursor
   if stop==border:bal=[min(q,b+q) for q,b in zip(caps,bal)]
   cursor=stop
  assert r[29:32]==([max(-bal[j],0) for j in paths[src]] if src<n else [0]*3)
  for a,path in enumerate(paths):assert r[35+3*a:38+3*a]==[max(bal[j],0) for j in path]
  if kind==2:
   if op==1:exitmask|=1<<src
   if op==7 and r[32+src]:sl[src]=r[32+src];sleeps.append([i,src,sl[src],saved])
  fired=[a for a in range(n) if 0<sl[a]<=t]
  for a in fired:sl[a]=0;wakes.append([i,a,t])
  assert woke==sum(1<<a for a in fired) and ex==exitmask and sl==r[32:32+n]
  mask=sum(1<<a for a in range(n) if not sl[a] and not exitmask>>a&1);assert ready==mask
  def elig(b):return [a for a in range(n) if mask>>a&1 and min(b[j] for j in paths[a])>0]
  expect=(elig(bal) or [4 if exitmask==(1<<n)-1 else 3])[0];assert expect==target
  border=epoch+((t-epoch)//P+1)*P
  if target<n:
   expected=min(border-t,min(bal[j] for j in paths[target]));assert res==expected
   assert dest==pcs[target] and (sps[target] is None or dsp==sps[target]);assert df==frames+832*target and r[44]&0xfffff000==space+target*stride
   end=t+res;next_due=end
  else:
   assert res==0
   if target==3:assert dsp==stack and dest==sym(' native_cyclic_idle_landing') and r[46]>=r[45]>0
   end=0;next_due=0
   if mask:
    shadow=bal.copy();next_due=border
    while True:
     shadow=[min(q,b+q) for q,b in zip(caps,shadow)]
     if elig(shadow):break
     next_due+=P
  assert min([x for x in [next_due]+sl if x] or [0])==due_next
  if kind==1:
   assert op==30
   lag=entry-prior;irq.append([i,src,lag])
   if not 0<=lag<=P//8:errs.append(['IRQ',i,lag])
   if src<n and prior==ge and prev+gr==ge and gr<=P and gr==min(led[-1]['balances'][j] for j in paths[src]):
    grants.append([i,charged-gr])
    if charged>gr+P//8:errs.append(['occupancy',i,charged-gr])
  if i and entry-rows[i-1][3]>8*P:errs.append(['spacing',i,entry-rows[i-1][3]])
  if kind and target!=4:
   assert r[45]>=chosen
   typ='same' if src==target else 'idle-enter' if target==3 else 'idle-recover' if src==3 else 'switch'
   duration=r[45]-entry;cost[str(kind)+'/'+typ].append([duration,duration/max(1,t-prev),settled-t,chosen-sel,r[45]-chosen])
  if n>1 and ready&3==3 and bal[0]<=0 and all(bal[j]>0 for j in [*paths[0][1:],*paths[1][1:]]):parents.append([i,(t-epoch)//P,target])
  if src<n and min(bal[j] for j in paths[src])<=0:
   b=[bal[j] for j in paths[src]]
   if b[0]>0 and b[1]<=0<b[2]:children.append([i,src,b])
   if min(b[:2])>0 and b[2]<=0:leaf.append([i,src,b])
  led.append(dict(row=i,src=src,target=target,kind=kind,op=op,balances=bal.copy(),ready=ready,pc=[saved,dest],physical_service=charged,entry=entry,settle=t,compare=due_next,return_tick=r[45]))
  prev=t;gr=res;due=due_next;old=target
 assert old==4
 if mode=='trace':
  tr=(d/'exceptions').read_text()
  entries=[(typ,int(el),int(pc,16)) for typ,el,pc in re.findall(r'Taking exception \d+ \[(IRQ|Synchronous Trap|SVC)\]\n\.\.\.from EL(\d) to EL1\n.*?with ELR 0x([a-f0-9]+)',tr,re.S)]
  assert len(entries)==len(rows)-1,(len(entries),len(rows))
  for r,(typ,el,pc) in zip(rows[1:],entries):assert (typ,el,pc)==('IRQ' if r[1]==1 else 'SVC',int(r[8]==3),r[19])
  actual=[int(pc,16) for pc in re.findall(r'Exception return from AArch64 EL1 to AArch64 EL0 PC 0x([a-f0-9]+)',tr)]
  assert actual==[r[23] for r in rows if r[9]<n]
  result.update(external_entries=len(entries),external_user_erets=len(actual))
 (d/'ledger.json').write_text(json.dumps(led))
 result.update(rows=len(rows),drops=0,errors=errs,irq=irq,grants=grants,positive_overruns=sum(max(0,v) for _,v in grants),max_spacing=max(b[3]-a[3] for a,b in zip(rows,rows[1:])),idle=idle,parent=parents,child=children,leaf=leaf,sleep=sleeps,wake=wakes,cost={k:dict(count=len(v),min=min(x[0] for x in v),max=max(x[0] for x in v),sum=sum(x[0] for x in v),max_sample_share=max(x[1] for x in v)) for k,v in cost.items()})
 return result
for d in sorted((root/'raw').iterdir()):
 if not (d/'outcome').exists():continue
 try:reports[d.name]=audit(d);print(d.name,'ok',reports[d.name].get('errors',[]))
 except Exception:
  import traceback;traceback.print_exc();print('FAIL',d,flush=True)
(root/'metrics.json').write_text(json.dumps(reports,indent=2))

