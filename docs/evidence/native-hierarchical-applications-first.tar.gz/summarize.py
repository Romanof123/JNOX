from pathlib import Path
import json,struct,re,subprocess,collections
h=Path(__file__).parent;m=json.loads((h/'metrics.json').read_text())
r=['# Native hierarchy first records / 네이티브 계층형 최초 검증','', 'Candidate b276a2ed8e9715fc6ced057b84681d77ccead755 against main 3906f6fcfe53f106b3f63c7080399a5fa4495dbf. Frozen ae7a0bddf8754e4fcb855ae04846015f6fe0c3e0. WSL ext4, single A72 TCG virt/GICv2 CPU, 62,500,000 Hz. All ten natural cold boots completed with original products and exits. Two plain firsts missed the frozen idle IRQ bound. Release timing verdict FAIL. No reruns or delayed IRQ injection.','', '열 번의 네이티브 최초 부팅에서 최종 산출물과 종료값은 모두 일치했다. 포화 및 교환 일반 부팅에서 실제 유휴 IRQ가 1,953,125틱 상한을 초과하여 전체 시간 판정은 실패다. 재실행 및 인위적인 지연 주입은 없었다.','', '|Position|Rows|Max IRQ lag|Max observation gap|Quota grants N|Positive overhead sum|True idle recoveries|Parent throttle windows|','|---|---:|---:|---:|---:|---:|---:|---:|']
supp={}
for c in ['saturated','swap','child-leaf','wake','single']:
 for mode in ['plain','trace']:
  name=c+'-'+mode; a=m[name];d=h/'raw'/name
  r+=['|'+ '|'.join(map(str,[name,a['rows'],max(i[2] for i in a['irq']),a['max_spacing'],len(a['grants']),a['positive_overruns'],len(a['idle']),len(set(p[1] for p in a['parent']))]))+'|']
  n=len(a['products']);b=(d/'samples').read_bytes();stride=8+960*n;samples=[]
  for pos in range(0,len(b),stride):
   snap=b[pos:pos+stride]; row=[]
   for i,v in enumerate(a['products']):
    frame=snap[8+n*128+i*832:];pc=struct.unpack_from('<Q',frame,264)[0];spsr=struct.unpack_from('<Q',frame,256)[0];sp=struct.unpack_from('<Q',frame,272)[0]
    x9=struct.unpack_from('<Q',frame,72)[0];off=8+128*i;field=int.from_bytes(snap[off:off+4],'little')
    row.append(dict(id=v['id'],frame_pc=pc,frame_sp=sp,spsr=spsr,ramp_counter=x9 if v['id'] in ('crc','energy') and 0x4004a0<=pc<=0x400554 else None,private_hist_bytes=field if v['id']=='histogram' else None))
   samples.append(row)
  (d/'sample-decode.json').write_text(json.dumps(samples))
  ledger=json.loads((d/'ledger.json').read_text())
  if c in ('saturated','swap','child-leaf','wake'):
   id=2 if c!='wake' else 1;fields=[s[id]['ramp_counter'] if c!='wake' else s[id]['private_hist_bytes'] for s in samples];vals=sorted(set(v for v in fields if v is not None and v>0));assert len(vals)>=2
  if c=='single':
   pcs={k['pc'][0] for k in ledger if k['kind']==1 and k['src']==0}
   valid=[s[0] for s in samples if s[0]['frame_pc'] in pcs]
   assert valid and all(v['spsr']&0x9f==0 for v in valid)
   assert len(set(v['ramp_counter'] for v in valid if v['ramp_counter']))>=2
   supp[name]=dict(samples=len(valid),first=valid[0],last=valid[-1],etries=a.get('external_entries'))
  if c=='wake':
   prod=a['products'][0];j=0
   for (k,slot,w,pc),(jrow,slot2,t) in zip(a['sleep'],a['wake']):
    assert slot==slot2==0 and t>=w
    nxt=next(v for v in ledger[k+1:] if v['target']==0)
    assert nxt['pc'][1]==pc and nxt['row']>=jrow
    assert any(v['src'] in (1,2) and v['physical_service']>0 for v in ledger[k+1:jrow+1])
    mem=(d/'ram.bin').read_bytes(); domain=[struct.unpack_from('<Q',mem,int(l.split()[0],16)-0x40200000)[0] for l in (d/'symbols').read_text().splitlines() if '12CLOCK_DOMAIN' in l]; epoch=next(v for v in domain if v!=62500000); assert w==epoch+(prod['deadline'][j]+15)//16; assert prod['deadline'][j]==(ledger[k-1]['entry']-epoch)*16+40000000
    j+=1
   assert j==3
  if c=='child-leaf':assert any(x[1]==0 for x in a['child']) and any(x[1]==1 and x[0]>a['child'][0][0] for x in a['leaf'])
  if c=='saturated':assert len(set(v[1] for v in a['parent']))>=3 and sum(x[1]>0 for x in a['grants'])>=2 and len(a['idle'])>=3
  if c=='swap':assert a['parent']
r+=['','Full per-row signed ledger, IRQ lags, counter brackets, cost categories, throttles, wake sequences and all first RAMs are supplied. N includes uninterrupted grant-end IRQs where the path minimum limited the reservation. An interval touching all three levels is counted once. All measured occupancy excesses fit N × 1,953,125; every decision gap ≤125,000,000.','', 'Idle misses / 유휴 지연 초과','', '|Case/row|Prior selection end|Prior pre-transfer|Idle landing|Compare|PPI30 entry|Settlement|Restored EL0 pre-ERET|','|---|---:|---:|---:|---:|---:|---:|---:|','|Saturated 60→61|316957749|316958876|316958880|328667725|332869281|332871606|332873364|','|Swap 82→83|582595401|582596499|582596503|594305368|600792436|600793949|600799106|','', 'Both misses were idle→histogram, true interrupted ELR 0x40201488 (native_sleep_idle+4), zero idle charge, ready 2 and exited 5. On entering idle, parent0 debts were 5349 and 6013. The assembly landing sample preceded compare by 11708845 and 11708865 ticks. Actual IRQ-entry counter exceeded compare by 4201556 and 6487068. Pre-ERET occurred 4205639 and 6493738 ticks after compare. Later histogram IRQs confirm execution. One compare-programming call per decision from implementation, bracketed by selection end and pre-transfer. The plain boots have no external IRQ/return stream, independent register write count, or timestamps at CVAL write, WFI, physical assertion, or actual ERET. QMP live reads and host scheduling are part of the environment. Attribution to a specific host or guest mechanism is unproven.','', '두 초과 모두 히스토그램만 준비된 상태에서 유휴 루프를 실제 중단했다. 두 착지 표본은 비교값보다 약 1171만 틱 빨랐다. IRQ 입력·실제 WFI·복귀 명령 그 자체의 타임스탬프와 호스트 스케줄링 기록은 없으며, 각 원인의 기여도는 분리할 수 없다.','', 'Payload and causality / 계산 결과와 인과관계','', 'Each ELF hash matched its manifest slot and mapped image. Independent TTBR-root page walks: CRC 134217728 bytes, CRC 2124873618, exit 237; Rust histogram 536870912 bytes, 2097152 × [1,8,28,56,70,56,28,8,1], exit 70; energy 1073741824 samples, 5864240971776, exit 179. Reporter recorded three deadlines, restored its post-SVC continuation each time and produced 3/mask 7/exit 7. Its deadlines agree with armed ticks and private observations are all due. Each block interval includes measured peer computation. Final RAM preserves complete private products. Periodic reads saw histogram private bytes and saved C-loop progress registers. The 128-byte sampled window omits CRC/energy progress words at offsets 264/272; their loop counters and full final RAM independently show progress.','', 'The tier-by-tier signed replay matches all reported debts and balances, early closures, service/idle intervals, owners, comparisons, identity and frames in all runs. External traces correlate every exception origin/ELR and every EL0 ERET in traced runs. Lower-limit cases show child0 depletion with funded ancestors/leaf, then independent leaf1 depletion with funded parent and child. Single CRC shows exclusive leaf debt, true zero-charge idle interrupted in WFI loop and timer-driven restoration of exact CRC PC, SP and page root. Initial user mode derives from the exact binary initialization/ERET path (0x340); live saved exception frames confirm EL0t/I-clear and continued ramp progress at resumed PCs. External QEMU int output records return level and PC, not an independent live SPSR sample precisely at ERET.','', '모든 최초 실행에 대해 사설 주소 변환 후 최종 결과를 계산했고, 추적 실행에서는 각 예외의 진입 EL·중단 PC와 전체 EL0 복귀 PC를 대조했다. 하위 예산 구성의 자식과 리프가 각기 독립적으로 소진됐다. 단일 CRC는 조상 잔액이 남은 채 리프가 소진되고 실제 유휴에서 타이머로 복귀했다. 복원된 프레임은 EL0t 및 I=0이며, 복귀 뒤 반복 횟수가 증가했다.','', 'Costs / 계측 비용','', 'Ticks from ordered entry to last transfer sample (probe overhead included); maximum share uses this handling duration divided by the physical interval between consecutive settlement samples. This sample-to-sample denominator can be short on adjacent SVCs; it does not isolate net workload overhead. Terminal has no ERET, launch has no exception. Unlisted category combinations have zero observations. Separate stage brackets are in the original 47-word rows.','', '|Case|Source/type|N|min|max|total|max share|','|---|---|---:|---:|---:|---:|---:|']
for name,a in m.items():
 for k,v in sorted(a.get('cost',{}).items()):
  cause,typ=k.split('/');r+=['|'+ '|'.join(map(str,[name,{'1':'IRQ','2':'SVC'}[cause]+'/'+typ,v['count'],v['min'],v['max'],v['sum'],format(v['max_sample_share'],'.6f')]))+'|']
r+=['','Historical controls / 기존 대조','', 'All four linked ordinary/recurring firsts passed. Original diagnostic has 8 rows, 1 true idle recovery, max IRQ lag 19309 ticks. Recurring has 14 rows, 3 true idle recoveries, max 20043, two peer quota expirations and parent-0 debts 18558/9505/9274 in successive windows. Receipts 33152,33408,33664; cumulative 100224. Both independent linked frame/PC/ledger replay and supplied readers accepted. Default native CRC package returned 237 with exact product. Seven maintained arithmetic tests, upstream reader fixtures and the historical independent 10162 query comparator passed. These linked controls concern EL1 jobs, scoped to each original workload.','', '가상 단일 CPU에서 연결된 기존 일반 작업은 진단 8행, 반복 작업은 14행으로 원래 기준을 만족했다. 독립 정수 모형 10,162개 대조도 통과했다. 실제 하드웨어 시간이나 제품 부하의 보장은 이 검증 범위 밖이다.']
(h/'single-frame-proof.json').write_text(json.dumps(supp,indent=2));(h/'first-report.en-ko.md').write_text('\n'.join(r)+'\n')
