set -eux
cd ~/iv333prep/src
out=$HOME/iv333prep/packages
mkdir -p "$out"
export PATH="$HOME/.cargo/bin:$PATH" RUSTUP_TOOLCHAIN=1.95.0
git status --porcelain
for t in cargo rustc clang ld.lld qemu-system-aarch64 aarch64-linux-gnu-nm; do "$t" --version | head -1; done
sh sdk/native-aarch64/build.sh examples/native-weighted-analytics/checksum.c "$out/crc.elf"
sh sdk/native-aarch64/build-rust.sh examples/native-weighted-analytics-rust/Cargo.toml "$out/histogram.elf"
sh sdk/native-aarch64/build.sh examples/native-weighted-analytics/energy.c "$out/energy.elf"
sh sdk/native-aarch64/build.sh examples/native-weighted/reporter.c "$out/reporter.elf"
sha256sum "$out"/*.elf
pkg() { python3 tools/build_native_el0.py --out "$out/$1" --policy hierarchy --hierarchy "examples/native-hierarchy/$2.json" --elf "$out/$3.elf" --peer-elf "$out/$4.elf" --peer-elf "$out/$5.elf"; }
pkg saturated baseline crc histogram energy
pkg swap baseline energy histogram crc
pkg child-leaf child-leaf crc histogram energy
pkg wake baseline reporter histogram energy
echo '{"period_ticks":15625000,"parents":[15625000],"children":[[0,15625000]],"leaves":[[0,3906250]]}' > "$out/single.json"
python3 tools/build_native_el0.py --out "$out/single" --policy hierarchy --hierarchy "$out/single.json" --elf "$out/crc.elf"
python3 tools/build_native_el0.py --out "$out/default" --elf "$out/crc.elf"
