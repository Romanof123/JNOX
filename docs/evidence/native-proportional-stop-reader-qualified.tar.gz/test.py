import pathlib, subprocess, hashlib,json,sys,struct,os
from pathlib import Path
b=Path(__file__).resolve().parent
os.chdir(b)
src=b/"src"
d=b.parent/"control/first"
env=dict(os.environ,PYTHONPATH="/home/ywcho/jnox-169-first-e203caa/deps",PYTHONDONTWRITEBYTECODE="1")
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
orig="0ca980217348561bddbe0f4738356248298604d510fb11b2c94e014a115a81b5"
def validate():
    assert h(d/"session.json")==orig
    for n,v in json.loads((d/"session.json").read_text())["hashes"].items():assert h(d/n)==v
def run(name, directory,digest,rc):
    args=[sys.executable,str(src/"tools/native_proportional_guard.py"),"replay",str(directory),digest]
    p=subprocess.run(args,capture_output=True,text=True,env=env)
    (b/(name+".log")).write_text(json.dumps(args)+"\n"+p.stdout+p.stderr+"\nexit="+str(p.returncode)+"\n")
    assert p.returncode==rc
validate()
run("positive",d,orig,0)
run("wrong-digest",d,"0"*64,1)
copy=b/"negative-copy"
copy.mkdir()
for f in d.iterdir():
    if f.name not in ("session.json","ram1.bin"):(copy/f.name).symlink_to(f)
ram=bytearray((d/"ram1.bin").read_bytes())
frame=0x40c25460-0x40200000
assert struct.unpack_from("<QQ",ram,frame+832)==(0,568164)
assert ram[frame:frame+848]==(d/"ram0.bin").read_bytes()[frame:frame+848]
ram[frame+840]^=1
(copy/"ram1.bin").write_bytes(ram)
m=json.loads((d/"session.json").read_text())
m["hashes"]["ram1.bin"]=h(copy/"ram1.bin")
(copy/"session.json").write_text(json.dumps(m,indent=2)+"\n")
run("wrong-entry",copy,h(copy/"session.json"),1)
validate()
print("Original session and all members rehashed before/after. Both 848-byte frames identical; x2=0 entry=568164.")
