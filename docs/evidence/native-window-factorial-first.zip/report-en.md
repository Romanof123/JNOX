# Ordinary P/Q first cohort

Fourteen of 920 windows exceeded 62,500 ticks (1 ms). All fourteen occurred at generation 2 under the default clock. Position 32 (P/D) took 77,022 ticks, 14,522 over budget. All 80 captures passed structural checks with 160 bounded exits (41 and 42 per boot).

0799f56557286d9caca8e1adec673a9b10da3a38 · Rust 1.95.0 · QEMU 6.2.0 TCG virt Cortex-A72 · 62.5 MHz · ABI v2/v3 · 1 vCPU

A/B copy frames and C/D retain frames. B/D use the cursor and A/C scan. Maxima below use ticks.

| Table | Clock | Cell | Windows | Misses | Maximum | Position | Gen 2 max | Gen 3+ max |
|---|---|---|---:|---:|---:|---:|---:|---:|
| p | default | A | 50 | 4 | 66497 | 31 | 66497 | 31593 |
| p | default | B | 50 | 3 | 72857 | 29 | 72857 | 23093 |
| p | default | C | 50 | 2 | 63220 | 55 | 63220 | 26615 |
| p | default | D | 50 | 4 | 77022 | 32 | 77022 | 25489 |
| p | icount3 | A | 50 | 0 | 1432 | 12 | 1424 | 1432 |
| p | icount3 | B | 50 | 0 | 1430 | 11 | 1426 | 1430 |
| p | icount3 | C | 50 | 0 | 737 | 9 | 727 | 737 |
| p | icount3 | D | 50 | 0 | 735 | 10 | 729 | 735 |
| q | default | A | 65 | 0 | 62005 | 46 | 62005 | 24152 |
| q | default | B | 65 | 0 | 60345 | 48 | 60345 | 24214 |
| q | default | C | 65 | 0 | 55638 | 47 | 55638 | 25757 |
| q | default | D | 65 | 1 | 72548 | 18 | 72548 | 28288 |
| q | icount3 | A | 65 | 0 | 1439 | 14 | 1429 | 1439 |
| q | icount3 | B | 65 | 0 | 1438 | 16 | 1432 | 1438 |
| q | icount3 | C | 65 | 0 | 742 | 15 | 732 | 742 |
| q | icount3 | D | 65 | 0 | 741 | 13 | 736 | 741 |

Median generation 2 effects in ticks, five matched rounds per row. contrasts.csv contains each operand and effect for every generation.

| Table | Clock | B−A | D−C | C−A | D−B | Interaction |
|---|---|---:|---:|---:|---:|---:|
| p | default | 792 | 2328 | -432 | 523 | 1536 |
| p | icount3 | 2 | 2 | -697 | -697 | 0 |
| q | default | -1660 | -21 | -3712 | -1801 | -452 |
| q | icount3 | 3 | 4 | -697 | -696 | 1 |

All 80 original stock replay invocations stopped at the missing pyelftools dependency. The archive retains every original log. A separately labeled offline replay supplied that dependency and agreed with the independent decoder on all 920 immutable window captures. Guest retries numbered zero. The fifth local block repeats the first order. Default-clock variation and five blocks limit inference about hardware, WCET, host causes and the overall release.

136 Rust tests and 11 Python selector/accounting tests passed. All eight user ELFs and probes had identical hashes. linked/ contains the ELF dispatch calls, restore vectors, symbols, cfg, section sizes and both parent diffs.

[80 boots](boots.csv) · [920 windows](windows.csv) · [14 misses](red-windows.csv) · [230 matched comparisons](contrasts.csv) · [Packages](packages.csv) · [Raw ZIP](jnox258-raw.zip)
