import os,sys,json,hashlib,subprocess as sp,shutil,pathlib,time
from pathlib import Path
root=Path.home()/'jnox258'
src=root/'src'
out=root/'raw'
os.chdir(src)
rev='0799f56557286d9caca8e1adec673a9b10da3a38'
assert sp.check_output(['git','rev-parse','HEAD'],text=True).strip()==rev
tools=Path.home()/'jnox-169-first-e203caa'
os.environ.update(PATH=str(tools/'rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')+':'+os.environ['PATH'],CARGO_BUILD_JOBS='1',RUSTUP_HOME=str(tools/'rustup'),CARGO_HOME=str(tools/'cargo'))
def dump(name,obj): (out/name).write_text(json.dumps(obj,indent=2)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd,log):
 with (out/log).open('xb') as f: return sp.run(cmd,stdout=f,stderr=sp.STDOUT).returncode
probe=next(src.rglob('native_partition_monitor.c'))
rows=[]; builds={}; packages=root/'packages';packages.mkdir(exist_ok=True)
for r in range(5):
 for b in range(4):
  s=(r+b)%4;t='pq'[s%2]; clock=('default','icount3')[s//2]
  for c in ['ABDC','BCAD','CDBA','DACB'][(r+s)%4]:
   i=len(rows)+1;k=t+c;p=packages/k
   cmd=['python3','tools/build_native_el0.py','--app','partition-'+t,'--out',str(p)]
   if c in 'BD':cmd+=['--partition-window','cursor-v1']
   if c in 'CD':cmd+=['--partition-frames','retained-v1']
   builds[k]=cmd
   rows.append(dict(i=i,r=r,b=b,t=t,c=c,clock=clock,k=k,cmd=['python3','tools/native_weighted_capture.py','partition-'+t,clock,str(out/f'boot{i:02}'),str(p/'kernel.elf'),str(p/'user.elf'),str(probe),rev]))
dump('matrix.json',rows);dump('builds.json',builds)
dump('environment.json',dict(rev=rev,environment={k:os.environ[k] for k in ['PATH','CARGO_BUILD_JOBS','CARGO_HOME','RUSTUP_HOME']},versions={x:sp.check_output(args,text=True) for x,args in dict(rust=['rustc','-vV'],cargo=['cargo','--version'],qemu=['qemu-system-aarch64','--version'],host=['uname','-a'],load=['cat','/proc/loadavg']).items()},scripts={p.name:sha(p) for p in [src/'tools'/n for n in ['build_native_el0.py','native_weighted_capture.py','native_el0_capture.py','native_partition_replay.py','qemu_capture.py']]+[Path(__file__)]},limit_s=20))
dest=Path('/mnt/d/codex/jnox258-independent')
for p in out.iterdir(): shutil.copy2(p,dest/p.name)
status={}
for k,cmd in builds.items():
 status[k]=run(cmd,'build-'+k+'.log');dump('build-status.json',status);print(k,status[k],flush=True)
result=[]
for row in rows:
 i=row['i'];k=row['k']; item=dict(i=i,status='blocked by package' if status[k] else 'launched')
 if not status[k]:
  item['rc']=run(row['cmd'],f'launch{i:02}.log')
  folder=out/f'boot{i:02}';item['hashes']={p.name:sha(p) for p in folder.iterdir() if p.is_file()} if folder.exists() else {}
 result.append(item);dump('capture-status.json',result)
for row,item in zip(rows,result):
 if item.get('hashes',{}).get('session.json'):
  i=row['i'];item['replay_rc']=run(['python3','tools/native_partition_replay.py',str(out/f'boot{i:02}'),item['hashes']['session.json']],f'replay{i:02}.json')
dump('replay-status.json',result)
