import subprocess as sp,json,csv,hashlib,shutil,sys,itertools,os
from pathlib import Path
root=Path.home()/'jnox258'; os.chdir(root/'src'); raw=root/'raw'; linked=raw/'linked';linked.mkdir(exist_ok=True); dest=Path('/mnt/d/codex/jnox258-independent')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cmd(args,p):
 with p.open('wb') as f:return sp.run(args,stdout=f,stderr=sp.STDOUT).returncode
def table(n,rows):
 with (raw/n).open('w') as f:
  w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
envbase=Path.home()/'jnox-169-first-e203caa';os.environ.update(PYTHONPATH=str(envbase/'deps'),PATH=str(envbase/'rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')+':'+os.environ['PATH'],CARGO_BUILD_JOBS='1')
rows=json.loads((raw/'independent.json').read_text());caps=json.loads((raw/'replay-status.json').read_text())
packages=[];paths=[]
for p in sorted((root/'packages').iterdir()):
 d=linked/p.name;d.mkdir(exist_ok=True); elf=p/'kernel.elf'; meta=json.loads((p/'manifest.json').read_text())
 for n in ['kernel.elf','user.elf','manifest.json','build.log']:shutil.copy2(p/n,d/n)
 for args,n in [(['aarch64-linux-gnu-nm','-nSC'],'symbols.txt'),(['aarch64-linux-gnu-objdump','-dC'],'disassembly.txt'),(['aarch64-linux-gnu-size','-A'],'sections.txt')]: assert cmd(args+[str(elf)],d/n)==0
 dis=(d/'disassembly.txt').read_text(); syms=(d/'symbols.txt').read_text()
 before,body=dis.split('::State::dispatch>:',1) if '::State::dispatch>:' in dis else ('','');body=body.split('\n\n',1)[0];assert body
 cursor='CyclicCursor' in body;retained='native_partition_traps_v1' in syms
 assert cursor==(p.name[1] in 'BD') and retained==(p.name[1] in 'CD')
 for f in p.glob('target/**/output'):
  if 'jnox' in str(f):shutil.copy2(f,d/('cfg-'+f.parent.name+'.txt'))
 packages.append(dict(package=p.name,cursor=cursor,retained=retained,kernel=sha(elf),user=sha(p/'user.elf'),probe=sha(Path('examples/portability/native_partition_monitor.c')),manifest=sha(p/'manifest.json')))
assert len({r['user'] for r in packages})==len({r['probe'] for r in packages})==1;table('packages.csv',packages)
for parent in ['d01fd1587fb0563e1e8dd3d4eaeac39b9346e072','55ce22d949095a90438586412710d094b6f03886']:
 assert cmd(['git','diff',parent,'HEAD','--','kernel/src','tools/build*','tools/scheduling_tests.rs','tools/native_partition_replay.py'],linked/(parent+'.patch'))==0
assert cmd(['rustc','--edition=2021','--test','tools/scheduling_tests.rs','-o',str(root/'tests')],raw/'rust-build.txt')==0
assert cmd([str(root/'tests'),'--test-threads=1'],raw/'rust-tests.txt')==0
assert cmd(['python3','-m','unittest','discover','-s','tools','-p','test_*partition*py'],raw/'selector-tests.txt')==0
windows=[];boots=[];idx={};summary=[]
for r,cap in zip(rows,caps):
 i=r['i']; f=raw/f'boot{i:02}'; assert all(sha(f/k)==v for k,v in cap['hashes'].items())
 rc=cmd(['python3','tools/native_partition_replay.py',str(f),cap['hashes']['session.json']],raw/f'offline{i:02}.json')
 rep=json.loads((raw/f'offline{i:02}.json').read_text());ws=r['windows']
 assert [w['latency'] for w in rep['windows']]==[w['y'] for w in ws] and rc==int(any(w['margin']<0 for w in ws))
 base={k:r[k] for k in ['i','r','t','clock','c']}
 for w in ws: windows.append(dict(**base,**w));idx[r['r'],r['t'],r['clock'],w['g'],r['c']]=w['y']
 boots.append(dict(**base,capture=cap['rc'],first_replay=cap['replay_rc'],offline_replay=rc,independent='valid',windows=len(ws),misses=sum(w['margin']<0 for w in ws),exits='41 42',session=cap['hashes']['session.json']))
table('boots.csv',boots);table('windows.csv',windows)
comparisons=[]
for rr,t,clock,g in sorted({k[:4] for k in idx}):
 a,b,c,d=(idx[rr,t,clock,g,v] for v in 'ABCD');comparisons.append(dict(round=rr,t=t,clock=clock,g=g,A=a,B=b,C=c,D=d,B_A=b-a,D_C=d-c,C_A=c-a,D_B=d-b,interaction=d-c-b+a))
table('contrasts.csv',comparisons)
for t,clock,c in sorted({(w['t'],w['clock'],w['c']) for w in windows}):
 ws=[w for w in windows if (w['t'],w['clock'],w['c'])==(t,clock,c)];mx=max(ws,key=lambda x:x['y']);summary.append(dict(t=t,clock=clock,c=c,scheduled=len(ws),captured=len(ws),valid=len(ws),missing=0,failed_boots=0,miss_boots=len({w['i'] for w in ws if w['margin']<0}),misses=sum(w['margin']<0 for w in ws),max=mx['y'],position=mx['i'],generation=mx['g'],gen2_max=max(w['y'] for w in ws if w['g']==2),later_max=max(w['y'] for w in ws if w['g']>2)))
table('summary.csv',summary);table('red-windows.csv',[w for w in windows if w['margin']<0])
print(summary,flush=True)
