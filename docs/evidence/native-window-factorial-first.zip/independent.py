from pathlib import Path
import hashlib,json,struct,csv,sys,collections
base=Path.home()/'jnox258'; raw=base/'raw';sys.path.insert(0,str(base/'src/tools'))
from elftools.elf.elffile import ELFFile
from native_weighted_trace import transitions
from native_el0_replay import Snapshot,vread,permissions,PA_MASK
def check(row):
 folder=raw/f"boot{row['i']:02}"
 load=lambda n:(folder/n).read_bytes()
 manifest=json.loads(load('session.json')); assert all(hashlib.sha256(load(n)).hexdigest()==v for n,v in manifest['hashes'].items())
 assert load('uart.bin')==b'JNOX M1 BOOT\nJNOX M1 READY\nNATIVE PARTITION END\n'
 launch=json.loads(load('launch.json')); mem=Snapshot(launch['ram_base'],load('ram.bin'))
 kernel=ELFFile((folder/'kernel.elf').open('rb')); user=ELFFile((folder/'user.elf').open('rb'))
 def sym(elf,n):return elf.get_section_by_name('.symtab').get_symbol_by_name(n)[0]['st_value']
 def words(a):return struct.unpack('<104Q',mem.read(a,832))
 addr=sym(kernel,'native_vruntime_journal'); header,*records=struct.iter_unpack('<16Q',mem.read(addr,513*128))
 v=header[0]; assert v==(3 if row['c'] in 'CD' else 2) and header[3:5]==(62500000,3125000)
 records=iter(records[:header[6]]); trace=iter(transitions(load('exceptions.log'))); vector=sym(kernel,'native_vruntime_vectors'); start=user['e_entry'];groups={'p':[(0,2),(1,1),(2,1)],'q':[(1,1),(2,1),(0,2),(1,1)]}[row['t']]; slots=len(groups)*3+1
 def take(tag,p):
  r=next(records);assert r[0]==tag and r[2]==p;return r
 maps=[];physical=set();controls=set();result_va=sym(user,'native_partition_result')
 for p in range(3):
  a=take(1,p);root=a[3]&PA_MASK;maps.append(root);assert a[3]>>48==p+1 and a[6]==start
  pages={j:'user rw' for j in range(0x1001000,0x1011000,4096)}
  for seg in user.iter_segments():
   if seg['p_type']=='PT_LOAD':
    for j in range(seg['p_vaddr'],seg['p_vaddr']+seg['p_memsz'],4096):pages[j]={4:'user r',5:'user rx',6:'user rw'}[seg['p_flags']]
  for j,perm in pages.items():
   permissions(mem,root,j,perm);pg=mem.leaf(root,j)&PA_MASK;assert pg not in physical;physical.add(pg)
  permissions(mem,root,0x1200000,'user r');controls.add(mem.leaf(root,0x1200000)&PA_MASK)
 assert len(controls)==1 and not controls&physical
 opening=header[5];prior=None;released=False;saved={};ptr={};progress=[0]*3;wins=[];exits=[];results={}
 for g in range(1,slots+3):
  drain=g>slots;owner,units=(g-slots-1,0) if drain else groups[(g-1)%len(groups)];released|=owner==2;p=2 if owner==1 and not released else owner
  d=take(21,p);select=d[1]; assert d[3:5]==(g,prior if drain else opening) and d[6:9]==(owner,3 if released else 1,int(drain)) and d[9]&PA_MASK==maps[p]
  if not drain:assert d[5]==opening+units*header[4]
  if p not in saved:
   initial=[0]*104;initial[32:36]=[0x340,start,0x1011000-80,4];initial[102]=0x1011000-96-16*p;saved[p]=tuple(initial);ptr[p]=d[14]
  assert d[14]==ptr[p]
  if v==2: restored=sum((take(24,p)[3:] for _ in range(8)),())
  else:
   witness=struct.unpack('<Q',mem.read(sym(kernel,'native_partition_restore_v1')+8*(g-1),8))[0];assert witness==ptr[p];restored=words(witness)
  assert restored==saved[p]
  e=next(trace);assert (e.kind,e.pc)==('eret',restored[33])
  irq=take(22,p);rr=take(23,p);results[p]=rr[4:10];entry=irq[1];ret=irq[4];assert irq[5]==d[5] and irq[3]==rr[3]==g and rr[1]==entry
  if v==2:saved[p]=sum((take(25,p)[3:] for _ in range(8)),())
  else:
   tp=sym(kernel,'native_partition_traps_v1')+832*(g-1);rp=sym(kernel,'native_partition_resume_v1')+832*(g-1);assert irq[15]==tp and mem.read(tp,832)==mem.read(rp,832);saved[p]=words(tp);ptr[p]=rp
  assert (saved[p][33],saved[p][34],saved[p][32],saved[p][102])==irq[9:13]
  e=next(trace);assert (e.kind,e.pc,e.vector)==('svc' if drain else 'irq',irq[9],vector+(0x400 if drain else 0x480))
  if drain:
   assert irq[14]==rr[9]==41+p and irq[13]==1 and entry<irq[5]<=select+header[4] and rr[7]>=progress[p]>0;exits.append(rr[9])
  else:
   first=rr[6];assert rr[5]==g and rr[4]==p+1 and rr[9]==0 and opening<=select<=ret<=first<d[5]<=entry and irq[7]==30
   assert (p==2 and rr[7]==rr[8]==0) or (p<2 and rr[7]>progress[p] and rr[8] in [(rr[7]-i)*(3+2*p) for i in [0,1]])
   progress[p]=rr[7];wins.append(dict(g=g,owner=owner,pid=p,opening=opening,prior=prior,select=select,ret=ret,first=first,irq=entry,y=first-opening,margin=62500-first+opening,irq_delay=None if prior is None else prior-opening,select_delay=None if prior is None else select-prior,return_delay=ret-select,user_delay=first-ret))
   opening=d[5]
  prior=entry
 assert next(records,None)==next(trace,None)==None and exits==[41,42]
 for p in saved:assert words(ptr[p])==saved[p] and struct.unpack('<6Q',vread(mem,maps[p],result_va,48))==results[p]
 return wins,exits
matrix=json.loads((raw/'matrix.json').read_text());results=[]
for row in matrix:
 try:w,e=check(row);results.append(dict(**row,windows=w,exits=e))
 except Exception as exc:
  import traceback
  results.append(dict(**row,error=traceback.format_exc()))
(raw/'independent.json').write_text(json.dumps(results,indent=2));print([(r['i'],r['error']) for r in results if 'error' in r][:2])
