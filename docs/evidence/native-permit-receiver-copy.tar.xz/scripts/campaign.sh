#!/usr/bin/env bash
set -euo pipefail
lab=${LAB_ROOT:-$HOME/permit389-private-copy-first}
history=${HISTORY_ROOT:-$HOME/permit389-hotpath-independent}
objects=${OBJECTS:-/mnt/d/codex/.jnox-work/policy-v1/.git/objects}
export PATH="$HOME/.cargo/bin:$PATH" LC_ALL=C TZ=UTC CARGO_BUILD_JOBS=1 PYTHONDONTWRITEBYTECODE=1
unset RUSTFLAGS CARGO_TARGET_DIR PYTHONPATH
while read -r v; do unset "$v"; done < <(compgen -e | sed -n '/^JNOX_/p')
refs=(52e4a8b23897801a418da23cac18fefca4cea35b 94c54b7da88cb93eaf65c2c2d95c3d0687b500e2 ca5e50add6bf79f0064eb4b372c3a0274cccd08b e007c569f21b1180f0d4b63b6696fa3da19cd4de)
test ! -e "$lab"
mkdir -p "$lab"/{apps,logs,pkg,runs,source-bundles,build-input,tools,fixtures,static,results,host-tests}
git init --quiet "$lab/src"
realpath "$objects" > "$lab/src/.git/objects/info/alternates"
cd "$lab/src"
git sparse-checkout init --cone
git sparse-checkout set arch boards examples kernel sdk services tools trace verification
for nm in sender supervisor; do cp "$history/apps/$nm.elf" "$lab/fixtures/$nm.elf"; done
echo "a126746f393b98c22c69fb92eb26d2883f228a90269633a8a40bdc4d47e33a48  $lab/fixtures/sender.elf
9267d8ae6f318b728522af79f5d1651d9c9fe5b47a6edd08291a087cbb12fa54  $lab/fixtures/supervisor.elf" | sha256sum -c -
{ date -u; uname -a; rustc -Vv; cargo -V; clang --version; qemu-system-aarch64 --version; sha256sum "$(command -v qemu-system-aarch64)"; git --version; python3 -V; lscpu; } > "$lab/logs/host.txt"
cat > "$lab/tools/mktemp" <<'SH'
#!/bin/sh
set -eu
[ "$#" = 1 ] && [ "$1" = -d ]
mkdir -m 700 "$FIXED_SDK_TMP"
printf '%s\n' "$FIXED_SDK_TMP"
SH
chmod +x "$lab/tools/mktemp"
package(){
  local ref=$1 role=$2 p=$3 c=$4
  local q=() args=()
  [ "$p" != rr ] || q=(--quantum-ticks 625000)
  local key="${ref:0:9}-$role-$p-$c"
  if [ "$role" = fused ]; then
    args=(--elf "$lab/build-input/sender.elf" --peer-elf "$lab/build-input/controller.elf" --peer-elf "$lab/build-input/supervisor.elf" --arg "$c" --peer-arg "$c" --peer-arg fused-phase --peer2-arg "$c" --priority 6 --peer-priority 7 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel --safety-qualification)
  else
    args=(--elf "$lab/build-input/producer.elf" --peer-elf "$lab/build-input/reader.elf" --priority 7 --peer-priority 1 --loan-route 0:1)
  fi
  (set -x; python3 tools/build_native_el0.py --out "$lab/package-out" --board virt --policy "$p" "${q[@]}" "${args[@]}") > "$lab/logs/$key.build.log" 2>&1
  mv "$lab/package-out" "$lab/pkg/$key"
  echo "packaged $key"
}
for rev in "${refs[@]}"; do
  git checkout --quiet --detach "$rev"
  git cat-file -p "$rev" > "$lab/source-bundles/$rev.commit"
  git ls-tree -r "$rev" -- arch boards examples kernel sdk services tools trace verification > "$lab/source-bundles/$rev.ls-tree"
  git archive --format=tar.gz -o "$lab/source-bundles/$rev.tar.gz" "$rev" arch boards examples kernel sdk services tools trace verification
  git diff "${refs[0]}" "$rev" -- arch boards examples kernel sdk services tools trace verification > "$lab/source-bundles/$rev.diff"
  mkdir -p "$lab/apps/$rev"
  cp "$lab/fixtures/"*.elf "$lab/build-input/"
  sh sdk/native-aarch64/build.sh examples/native-loan/producer.c "$lab/build-input/producer.elf" > "$lab/logs/$rev.producer.build.log" 2>&1
  for slot in controller reader; do
    pkg=examples/native-safety-admission/controller
    [ "$slot" != reader ] || pkg=examples/native-loan/reader
    CARGO_TARGET_DIR="$lab/app-target" FIXED_SDK_TMP="$lab/sdk-link" PATH="$lab/tools:$PATH" sh sdk/native-aarch64/build-rust.sh "$pkg/Cargo.toml" "$lab/build-input/$slot.elf" > "$lab/logs/$rev.$slot.build.log" 2>&1
    mv "$lab/app-target" "$lab/target-$rev-$slot"
  done
  cp "$lab/build-input/"*.elf "$lab/apps/$rev/"
  test -z "$(git status --short --untracked-files=no)"
  for p in fifo rr; do for c in healthy overrun invalid; do package "$rev" fused "$p" "$c"; done
    package "$rev" loan "$p" ordinary
  done
done
boot(){
  local idx=$1 role=$2 p=$3 c=$4
  local ref=${refs[idx]}
  n=$((n+1))
  local key="${ref:0:9}-$role-$p-$c"
  local pkg="$lab/pkg/$key" dest="$lab/runs/$(printf %03d "$n")-$key"
  local probe=examples/native-safety-admission/sender/src/main.rs marker=71
  if [ "$role" = loan ]; then probe=examples/native-loan/producer.c; marker=73; fi
  git checkout --quiet --detach "$ref"
  mkdir "$dest"
  date -u +%FT%T.%NZ > "$dest/start.utc"
  set +e
  (set -x; python3 tools/native_el0_capture.py "$dest/cap" "$pkg/kernel.elf" "$pkg/user.elf" "$probe" "$ref" --manifest "$pkg/manifest.json" --plain --expect-exit "$marker" --timeout 40 --uart-limit 8388608) > "$dest/capture.log" 2>&1
  local rc=$?
  set -e
  date -u +%FT%T.%NZ > "$dest/finish.utc"
  echo "$rc" > "$dest/status"
  echo "boot $n $key status=$rc"
}
n=0
for row in "0 1 3 2" "1 2 0 3" "2 3 1 0" "3 0 2 1"; do
  read -ra order <<<"$row"
  for idx in "${order[@]}"; do boot "$idx" fused fifo healthy; done
  for j in 3 2 1 0; do boot "${order[j]}" fused rr healthy; done
done
for p in fifo rr; do for idx in 0 2 1 3; do for c in overrun invalid; do boot "$idx" fused "$p" "$c"; done
  boot "$idx" loan "$p" ordinary
done; done
echo finished
