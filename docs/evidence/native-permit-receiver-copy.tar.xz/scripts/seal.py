"""Create a lossless packet from original logs, RAM, ELFs, build metadata and scripts."""
import hashlib,os,shutil,subprocess,sys
from pathlib import Path
root,external=map(Path,sys.argv[1:])
packet=root/'packet';packet.mkdir()
seen={}; sourcepaths=[]
for path in ('apps','fixtures','host-tests','logs','pkg','results','runs','source-bundles','static'):
    for p in sorted((root/path).rglob('*')):
        if p.is_file() and 'target' not in p.relative_to(root).parts:
            sourcepaths.append((p,packet/p.relative_to(root)))
for f in ('campaign.sh','provenance.sh','host.sh','static.py','score.py','reduce.py','stats.py','check.py','replay.sh','seal.py'):
    sourcepaths.append((external/f,packet/'scripts'/f))
sourcepaths.extend([(external/'campaign.log',packet/'logs/campaign.log'),(external/'REPORT.en-ko.md',packet/'REPORT.en-ko.md')])
manifest=[]
for p,t in sourcepaths:
    t.parent.mkdir(parents=True,exist_ok=True)
    h=hashlib.sha256(p.read_bytes()).hexdigest()
    if h in seen:os.link(seen[h],t)
    elif p.stat().st_dev==packet.stat().st_dev:os.link(p,t)
    else:shutil.copyfile(p,t)
    seen[h]=t
    manifest.append((str(t.relative_to(packet)),h))
(packet/'SHA256SUMS').write_text(''.join(h+'  '+n+'\n' for n,h in sorted(manifest)))
archive=external/'native-permit-private-copy-four-arm.tar.gz'
subprocess.run(['tar','--sparse','--hole-detection=raw','--sort=name','--format=posix','-czf',archive,'-C',packet,'.'],check=True)
receipt=hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n'
(external/'native-permit-private-copy-four-arm.sha256').write_text(receipt)
print(len(manifest),'hashes',archive.stat().st_size,'bytes',receipt,flush=True)
