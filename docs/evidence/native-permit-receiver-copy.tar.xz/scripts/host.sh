#!/usr/bin/env bash
set -euo pipefail
lab=$(realpath "$1")
export PATH="$HOME/.cargo/bin:$PATH" LC_ALL=C TZ=UTC CARGO_BUILD_JOBS=1
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
for path in "$lab"/source-bundles/*.tar.gz; do
  name=$(basename "$path" .tar.gz)
  src="$tmp/$name"; mkdir -p "$src"
  tar xzf "$path" -C "$src" kernel/src/loan_ipc.rs sdk/native-safety-channel
  echo "$name SDK"
  cargo test --offline --manifest-path "$src/sdk/native-safety-channel/Cargo.toml" -- --test-threads=1
  echo "$name loan core"
  rustc --edition 2024 --test "$src/kernel/src/loan_ipc.rs" -o "$src/loan-test"
  "$src/loan-test" --test-threads=1
done
