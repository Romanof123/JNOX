#!/usr/bin/env bash
set -euo pipefail
lab=$(realpath "${1:-.}")
export PYTHONDONTWRITEBYTECODE=1 LC_ALL=C
cd "$lab"
sha256sum --quiet -c SHA256SUMS
python3 scripts/score.py "$lab"
python3 scripts/reduce.py "$lab"
python3 scripts/stats.py "$lab"
python3 scripts/static.py "$lab"
python3 scripts/check.py "$lab"
sha256sum --quiet -c SHA256SUMS
printf 'Input and regenerated table hashes verified.\n'
