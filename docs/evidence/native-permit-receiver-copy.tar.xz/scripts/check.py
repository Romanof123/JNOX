import csv, json, sys, hashlib
from pathlib import Path
from collections import Counter
root=Path(sys.argv[1])
def csvs(n):
    with (root/'results'/n).open() as f:return list(csv.DictReader(f))
def object_id(kind,data):return hashlib.sha1((kind+' '+str(len(data))).encode()+b'\0'+data).hexdigest()
for line in (root/'logs/source-equivalence.log').read_text().splitlines():
    a,b,tree=line.split()
    for rev in [a,b]:
        commit=(root/'source-bundles'/(rev+'.commit')).read_bytes()
        assert object_id('commit',commit)==rev and commit.decode().splitlines()[0]=='tree '+tree
boots=json.loads((root/'results/boots.json').read_text());phase=csvs('phases.csv')
assert len(boots)==56 and len(phase)==1536 and len(csvs('frames.csv'))==384
assert all((root/'runs'/b['run']/'status').read_text().strip()=='0' for b in boots)
row_groups=[['BASE','CRC','BOTH','INLINE'],['CRC','INLINE','BASE','BOTH'],['INLINE','BOTH','CRC','BASE'],['BOTH','BASE','INLINE','CRC']]
healthy=csvs('healthy-blocks.csv')
for idx,wanted in enumerate(row_groups):
    group=healthy[idx*8:idx*8+8]
    assert [(r['policy'],r['arm']) for r in group]==[('fifo',k) for k in wanted]+[('rr',k) for k in reversed(wanted)]
for b in boots:
    if b['role']=='loan':continue
    pp=[x for x in phase if x['run']==b['run']]
    missed=[x for x in pp if int(x['phase_lo'])>62500]
    assert b['functional'] and not b['qual_loss'] and not b['safety_loss'] and all(v['prewake'] for v in b['phases'])
    assert not any(int(x['phase_lo'])<=62500<int(x['phase_hi']) for x in pp)
    assert b['output']==[1,1] and b['first_pair']==625000
    assert [(r[4],r[5]) for r in b['writes']]==[(0,1),(1,0)] and b['controller'][-1][16]==0
    if b['case']=='healthy':
        assert len(missed)==2 and missed[0]['phase']=='A0' and missed[0]['kind']=='empty' and missed[1]['wire_sequence']=='1' and missed[1]['kind']=='accepted'
    if b['case']=='overrun':assert len(missed)==3
print('56 genuine captures; no timeout/retry/exclusion; four-by-four cold order, terminal private state and deadline semantics validated.')
