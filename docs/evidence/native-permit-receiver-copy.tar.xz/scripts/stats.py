"""Group cold boots by Williams block, operation, sequence and policy."""
from collections import Counter
from pathlib import Path
from statistics import median
import csv,json,sys
root=Path(sys.argv[1]); dest=root/'results'
def read(name):
    with (dest/name).open() as f:return list(csv.DictReader(f))
def write(name,rows):
    with (dest/name).open('w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
def mid(ph,field):return median(int(v[field]) for v in ph)
boots=[b for b in read('per-boot.csv') if b['case']=='healthy'];phases=read('phases.csv')
groups=[];summary=[];paired=[]
for b in boots:
    pp=[v for v in phases if v['run']==b['run']]
    acc=[v for v in pp if v['kind']=='accepted'];emp=[v for v in pp if v['kind']=='empty']
    first,=[v for v in acc if v['wire_sequence']=='1'];warm=[v for v in acc if int(v['wire_sequence'])>=2]
    r=dict(run=b['run'],policy=b['policy'],arm=b['build'],block=(int(b['run'][:3])-1)//8+1,first_phase=first['phase'],b0_kind=pp[1]['kind'],misses=int(b['endpoint_misses']),unknown=sum(int(v['phase_lo'])<=62500<int(v['phase_hi']) for v in pp),A0_lo=int(pp[0]['phase_lo']),A0_hi=int(pp[0]['phase_hi']),B0_hi=int(pp[1]['phase_hi']),full_first_hi=int(first['phase_hi']),acc_hi=mid(acc,'phase_hi'),empty_hi=mid(emp,'phase_hi'),max_phase=int(b['max_phase']))
    for name in ('receive_to_release','release_to_crc_sample','receive_to_complete_entry'):
        for prefix,ls in [('first',[first]),('warm',warm),('all',acc)]:r[prefix+'_'+name]=mid(ls,name)
    r['warm_same_seq']=' '.join(str(v['receive_to_release']) for v in warm)
    groups.append(r)
for p in ('fifo','rr'):
    for arm in ('BASE','CRC','INLINE','BOTH'):
        rr=[r for r in groups if r['policy']==p and r['arm']==arm]; assert len(rr)==4
        summary.append(dict(policy=p,arm=arm,first_phase=' '.join(r['first_phase'] for r in rr),b0_accepted=sum(r['b0_kind']=='accepted' for r in rr),misses=sum(r['misses'] for r in rr),uncertain=sum(r['unknown'] for r in rr),boot_misses=[r['misses'] for r in rr],A0_misses=sum(r['A0_lo']>62500 for r in rr),A0_min_lo=min(r['A0_lo'] for r in rr),phase_max_hi=max(r['max_phase'] for r in rr),**{k:median(r[k] for r in rr) for k in ('A0_hi','full_first_hi','acc_hi','empty_hi','first_receive_to_release','warm_receive_to_release','first_release_to_crc_sample','warm_release_to_crc_sample','first_receive_to_complete_entry','warm_receive_to_complete_entry')}))
    for left,right in [('BASE','INLINE'),('CRC','BOTH'),('BASE','CRC'),('INLINE','BOTH'),('BASE','BOTH')]:
        before=sorted([r for r in groups if r['policy']==p and r['arm']==left],key=lambda r:r['block'])
        after=sorted([r for r in groups if r['policy']==p and r['arm']==right],key=lambda r:r['block'])
        for k in ('first_receive_to_release','warm_receive_to_release','first_release_to_crc_sample','warm_release_to_crc_sample','first_receive_to_complete_entry','warm_receive_to_complete_entry','acc_hi','empty_hi','max_phase','misses'):
            delta=[b[k]-a[k] for a,b in zip(before,after)]
            paired.append(dict(policy=p,before=left,after=right,metric=k,block_deltas=delta,median=median(delta),min=min(delta),max=max(delta),lower=sum(d<0 for d in delta)))
write('healthy-blocks.csv',groups);write('healthy-summary.csv',summary);write('paired.csv',paired)
for r in summary:print(r)
for r in paired:
    if r['after'] in ('INLINE','BOTH') and r['before'] in ('BASE','CRC') and r['metric'] in ('first_receive_to_release','warm_receive_to_release'):print(r)
