"""Check released ELF code and semantic package inputs without rebuilding."""
from pathlib import Path
import hashlib, json, re, struct, subprocess,sys,tarfile
from collections import defaultdict
from score import symtab,sha
root=Path(sys.argv[1]); out=root/'static';out.mkdir(exist_ok=True); refnames={'52e':'BASE','94c':'CRC','ca5':'INLINE','e00':'BOTH'}
def hashed(b): return hashlib.sha256(b).hexdigest()
def sections(x):
    data=x.read_bytes()
    off,=struct.unpack_from('<Q',data,40);ents,count,sid=struct.unpack_from('<HHH',data,58)
    rows=[struct.unpack_from('<IIQQQQIIQQ',data,off+i*ents) for i in range(count)]
    ix=rows[sid]; st=data[ix[4]:ix[4]+ix[5]]
    return {st[row[0]:].split(b'\0')[0].decode():data[row[4]:row[4]+row[5]] for row in rows if row[1]==1}
def dump(x):return subprocess.check_output(['aarch64-linux-gnu-objdump','-dC',str(x)],text=True)
def normalized(s):return re.sub(r'\s+',' ',s).strip()
def instructions(s):
    return [(int(m[1],16),normalized(m[2].split('//')[0])) for l in s.splitlines() if (m:=re.match(r'^\s*([0-9a-f]+):\s+[a-f0-9]{8}\s+(.+)$',l))]
def name(s):return refnames[s[:3]]
def span(pc):return f'{pc:#x}'
static={};kernels={};sem=defaultdict(set)
for folder in sorted((root/'apps').iterdir()):
    arm=name(folder.name); elf=folder/'controller.elf'; srcfile=root/'source-bundles'/(folder.name+'.tar.gz')
    with tarfile.open(srcfile) as fi:
        src=fi.extractfile('sdk/native-aarch64/rust/src/loan.rs').read()
        app=fi.extractfile('examples/native-safety-admission/controller/src/main.rs').read()
    assert b'assert!(offset < PAGE_BYTES);' in src and b'ptr::read_volatile' in src
    assert (b'#[inline]\n    pub unsafe fn read_page_byte' in src)==(arm in ['INLINE','BOTH'])
    body=dump(elf); syms=symtab(elf); main,mainlen=syms['main']; helper='jnox_native::loan::Reader::read_page_byte'
    ins=[(a,s) for a,s in instructions(body) if main<=a<main+mainlen]
    first=next(i for i,(a,s) in enumerate(ins) if s=='mov w8, #0x23')
    last=next(i for i,(a,s) in enumerate(ins[first:],first) if s=='mov w8, #0x24')+1
    segment=ins[first:last+1]; tokens=[s for a,s in segment]
    assert tokens[0:2]==['mov w8, #0x23','svc #0x4a01'] and tokens[-2:]==['mov w8, #0x24','svc #0x4a01']
    guards=[next(i for i,s in enumerate(tokens) if s==x) for x in ('cmp x3, #0x2c','and x8, x1, #0x3','cmp x8, #0x3','mov w9, #0x1600000','orr x8, x9, x8, lsl #12','cmp x2, x8')]
    assert guards==sorted(guards)
    assert [s.split()[0] for s in tokens[guards[0]:guards[-1]+2] if s.startswith('b.')]==['b.ne','b.eq','b.ne']
    calls=[i for i,s in enumerate(tokens) if 'bl ' in s and '<'+helper+'>' in s]
    concrete=[(i,int(m[1] or 0)) for i,s in enumerate(tokens) if (m:=re.fullmatch(r'ldrb w\d+, \[x2(?:, #(\d+))?\]',s))]
    stores=[int(m[1]) for s in tokens if (m:=re.fullmatch(r'strb w\d+, \[sp, #(\d+)\]',s))]
    assert len(stores)==44 and stores==list(range(stores[0],stores[0]+44))
    helpertext=''
    if arm in ('BASE','CRC'):
        assert len(calls)==44 and not concrete and helper in syms
        assert 'mov x1, xzr' in tokens[guards[-1]+2:calls[0]]
        assert [int(tokens[i-1].split('#')[1],16) for i in calls[1:]]==list(range(1,44))
        addr,sz=syms[helper]; hin=[(a,s) for a,s in instructions(body) if addr<=a<addr+sz]
        assert hin[0][1]=='cmp x1, #0x1, lsl #12' and hin[1][1].startswith('b.cs ') and hin[3][1]=='ldrb w0, [x8, x1]' and hin[4][1]=='ret'
        helpertext='\n'.join(f'{a:x} {s}' for a,s in hin)
    else:
        assert not calls and helper not in syms and [off for i,off in concrete]==list(range(44))
        assert all(tokens[i+1]==f'strb w8, [sp, #{stores[0]+off}]' for i,off in concrete)
    reader=folder/'reader.elf'; rdr=dump(reader); rs=symtab(reader); st,sz=rs['main'];ri=[(a,s) for a,s in instructions(rdr) if st<=a<st+sz]
    if arm in ('INLINE','BOTH'):
        li,=[(a,s) for a,s in ri if re.match(r'ldrb w\d+, \[x2, x16\]',s)]
        assert any(s=='cmp x16, #0x1, lsl #12' for a,s in ri) and any(s.startswith(f'b.ne {li[0]:x} ') for a,s in ri)
    (out/(arm+'-controller.txt')).write_text('\n'.join(f'{a:x} {s}' for a,s in segment)+'\n'+helpertext+'\n')
    (out/(arm+'-ordinary-reader.txt')).write_text('\n'.join(f'{a:x} {s}' for a,s in ri)+'\n')
    fields={'main','jnox_safety_channel::decode','jnox_safety_channel::encode',helper}
    static[arm]=dict(commit=folder.name,app={x.stem:sha(x) for x in sorted(folder.glob('*.elf'))},controller_source=hashed(app),loan_source=hashed(src),symbols={k:[span(syms[k][0]),syms[k][1]] for k in sorted(fields) if k in syms},reader_callsites=len(calls),direct_bytes=len(concrete),bytes_copied=len(stores),stack_dest=[min(stores),max(stores)],kernel_rx_release_service_ops=[35,36],copy_guard_va='0x01600000 + (handle & 3) * 4096',reader_text=hashed(sections(reader)['.text']),controller_text=hashed(sections(elf)['.text']))
    ls=(root/'source-bundles'/(folder.name+'.ls-tree')).read_text().splitlines()
    sem['kernel_board_arch_tools'].add(hashed(('\n'.join(x for x in ls if x.split('\t')[1].split('/')[0] in ('kernel','arch','boards','tools'))+'\n').encode()))
    for pkg in sorted((root/'pkg').glob(folder.name[:9]+'-*')):
        key=pkg.name.split('-',1)[1]
        kernel=pkg/'kernel.elf'; parts=sections(kernel); m=json.loads((pkg/'manifest.json').read_text())
        doc={k:m.get(k) for k in ('kernel_build','profile','app','board','rust','cargo','kernel_command','safety_channel','safety_qualification','loan_route','loan_pool','package_argv','ipc_routes','policy','quantum_ticks')}
        doc['slot_roles_ranks_argv']=[(slot['slot'],slot['priority'],slot['argv']) for slot in m['slots']]
        assert m['kernel_elf_sha256']==sha(kernel) and all(sha(pkg/slot['elf'])==slot['elf_sha256'] for slot in m['slots']) and sha(pkg/'build.log')==m['build_log_sha256']
        sem[key].add(hashed(json.dumps(doc,sort_keys=True,separators=(',',':')).encode()))
        kernels[pkg.name]=dict(full=sha(kernel),text=hashed(parts['.text']),text_bytes=len(parts['.text']),rodata=hashed(parts['.rodata']),data=hashed(parts['.data']),manifest=sha(pkg/'manifest.json'))
assert all(len(v)==1 for v in sem.values())
assert len({v['controller_source'] for v in static.values()})==1
assert len({v['app']['producer'] for v in static.values()})==1
assert len({v['app']['sender'] for v in static.values()})==1 and len({v['app']['supervisor'] for v in static.values()})==1
(root/'results/static.json').write_text(json.dumps(dict(controllers=static,kernels=kernels,common_semantic_input_hashes={k:sorted(v)[0] for k,v in sem.items()}),indent=1)+'\n')
for key,val in static.items():print(key,val['reader_callsites'],val['direct_bytes'],val['bytes_copied'],val['symbols'])
for key in sorted(sem):
    if key!='kernel_board_arch_tools':
        group=[v for k,v in kernels.items() if k.endswith(key)]
        print(key,'kernel hashes',len({v['full'] for v in group}),'text hashes',len({v['text'] for v in group}),'text extents',sorted({v['text_bytes'] for v in group}))
