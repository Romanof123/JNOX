#!/usr/bin/env bash
set -euo pipefail
lab=$(realpath "$1")
store="$lab/source-bundles"
cd "$lab/src"
for pair in "52e4a8b23897801a418da23cac18fefca4cea35b 682a07b994d18a4c501edc0fa0369733f2694388" "94c54b7da88cb93eaf65c2c2d95c3d0687b500e2 4cc9254b0957b88bcaa1c5e5f7f54afa15a93764" "ca5e50add6bf79f0064eb4b372c3a0274cccd08b 57300297514fdab612319ddb9305ec0c8732cad5" "e007c569f21b1180f0d4b63b6696fa3da19cd4de 91d888d4674eec4a480af301c6c1baff52154d03"; do
  read -r a b <<< "$pair"
  git diff --exit-code "$a" "$b"
  test "$(git rev-parse "$a^{tree}")" = "$(git rev-parse "$b^{tree}")"
  git cat-file -p "$b" > "$store/$b.commit"
  printf '%s %s %s\n' "$a" "$b" "$(git rev-parse "$a^{tree}")"
done

