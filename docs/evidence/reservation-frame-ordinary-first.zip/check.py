from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import hashlib,json
from collections import Counter
from reservation_handoff import decode
from audit import compact

root=Path(__file__).resolve().parent
sha=lambda data: hashlib.sha256(data).hexdigest()
for n in range(1,9):
    name=f'pos{n}'
    archive=root/(name+'.zip')
    manifest=json.loads((root/(name+'-verified.json')).read_text())
    assert sha(archive.read_bytes())==manifest['zip']
    with TemporaryDirectory() as tmp, ZipFile(archive) as z:
        p=Path(tmp)
        assert sorted(z.namelist())==sorted(manifest['files'])
        for member,digest in manifest['files'].items():
            assert Path(member).name==member
            data=z.read(member)
            assert sha(data)==digest
            (p/member).write_bytes(data)
        plan=json.loads((p/'plan.json').read_text())
        assert plan['position']==n and plan['sha256']==manifest['files']['kernel.elf']
        assert (p/'status').read_text().strip()=='124'
        uart=(p/'uart').read_bytes()
        result=decode(uart)
        rows=[list(map(int,line.split())) for line in uart.splitlines()[3:-1]]
        audit=compact(p,plan['app'],rows)
        rows_of=lambda t:[r for r in rows if r[0]==t]
        returns=Counter((r[2],r[3]) for r in rows_of(12) if r[3]<2)
        assert returns==Counter((r[2],r[3]) for r in rows_of(10))
        epoch=rows_of(2)[0][4]
        final=rows[-1]
        print(n,plan['app'],int(plan['traced']),final[2],rows_of(2)[0][5],sum(returns.values()),audit.get('first_offset'),final[6]-final[7] if final[4] else None,audit['violations'],result['result'])
