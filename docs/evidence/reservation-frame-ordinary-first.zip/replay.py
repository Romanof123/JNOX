"""Replay the paired first boots, including incomplete candidates. Run under WSL."""
from pathlib import Path
import hashlib,json,copy
from collections import Counter,defaultdict
from ledger import analyze,oracle
root=Path(__file__).resolve().parent
NA=2**64-1
def rows(path):return [list(map(int,l.split())) for l in (path/'uart').read_text().splitlines()[3:-1]]
def decode(rr,v,app):
 b=defaultdict(list)
 for r in rr:b[r[0]].append(r)
 def one(t):assert len(b[t])==1,(t,b[t]);return b[t][0]
 z=one(13);hz,S,policy,case=one(1)[4:]
 assert hz==62500000 and S==3125000 and policy==int(app.startswith('cbs')) and case=={'wake':0,'saturated':1,'refused':2}[app.split('-')[1]]
 if case==2:
  assert not any(b[t] for t in [2,3,4,5,6,7,8,9,10,11,12,17,18,19,21,22,23,24]);return {}
 model=oracle(app); E=one(2)[4];ms=hz//1000
 def each(t):
  keys=[(r[2],r[3]) for r in b[t]];assert len(set(keys))==len(keys)
 for t in [5,6,7,8,9,10,11,19,21,22,23]:each(t)
 def get(t,slot):return [r for r in b[t] if r[2]==slot]
 for r in b[7]:
  s,i=r[2:4];assert i==model[s]['owner'] and r[4:6]==[E+s*S,E+(s+1)*S]
  assert [x[3] for x in get(5,s)]==[0,1] and [x[3] for x in get(6,s)]==[0,1]
 for r in b[4]:
  s=r[2];k=r[5];assert r[7]&7==5;assert r[4]==E+(s+(1 if k else 0))*S-(ms if k else 0) and r[1]>=r[4] and r[6]==30
 result=dict(epoch=E,selected=[r[3] for r in b[7]],observed_demand=[r[2:] for r in b[6]],observed_qd=[r[2:] for r in b[5]],negative_opening_offsets=[],actual_periods={})
 for r in b[3]:
  assert r[4]==r[6] and r[5]&3==1
 seen_returns=[r[6] for r in b[12]]
 assert seen_returns==list(range(len(b[18])))
 for r in b[7]:
  s,i=r[2:4];plan=next(row for row in b[18] if row[2:4]==[s,i])
  assert plan[4:6]==r[6:8]
 serving={(r[2],r[3]) for r in b[10]}
 for t in [8,9,11,19]:
  assert {(r[2],r[3]) for r in b[t]}==serving
 result['violations']=[]
 for r in b[10]:
  slot,i,lo,first,hi,u=r[2:];opening=E+slot*S; off=first-opening
  q=2 if case==0 and i==0 else 1;end=opening+S;cutoff=end-ms
  alloc=next(x for x in get(19,slot) if x[3]==i)
  action=next(x for x in get(11,slot) if x[3]==i)[4]
  assert all(x[1]==hi for t in [8,9,10,11,19] for x in get(t,slot))
  if action==1:assert any(x[1]==hi and x[5]==1 and x[4]==cutoff for x in get(4,slot))
  for name,ok in [('opening',0<=off<=ms),('stop',hi<=end),('slot-service',u<=S),('allocation-service',alloc[5]<=q*S),('cutoff-delay',action!=1 or 0<=hi-cutoff<=ms),('short-trap',action==1 or hi<cutoff)]:
   if not ok:result['violations'].append([slot,i,name])
  if off<0:result['negative_opening_offsets'].append(slot)
  assert lo<=first<=hi and u==hi-lo
  if i==1:result['actual_periods'].setdefault(str((slot-1)//4 if case==0 else slot//2),[]).append(slot)
 if z[4:6]==[0,0]:
  assert not result['violations'] and z[2]==len(model)
  assert [(r[2],r[3]) for r in b[7]]==[(s,x['owner']) for s,x in enumerate(model)]
  assert [r[2] for r in b[4] if r[5]==0]==list(range(len(model)+1))
  assert serving=={(s,x['owner']) for s,x in enumerate(model) if x['owner']<2}
  assert [r[3] for r in b[21]]==[0,1]
  for r in b[21]:
   i=r[3];stops=[x for x in b[8] if x[3]==i];last=stops[-1];trap=next(x for x in get(11,last[2]) if x[3]==i)
   assert r[2]==len(model) and r[4:]==[last[5],last[7],trap[6],0]
  for r in b[11]:
   s,i=r[2:4]
   assert any(x[2:4]==[s,2] and x[1]>=r[1] for x in b[12])
   if r[4]==3:assert not any(x[2]>s and x[3]==i for x in b[7])
 if v=='v1':assert not any(b[t] for t in (22,23,24));return result
 post=one(24);prep=one(22);irq=next(x for x in b[4] if x[5]==0);returned=b[12][0]
 arm=next(x for x in b[3] if x[7]==0)
 assert post[2:4]==[NA,2] and post[5:]==[E,0,0] and prep[2:4]==[0,2] and prep[5:]==[E,E-prep[1],0]
 assert post[4]<=post[1]<=arm[1]<=returned[1]<=prep[4]<=prep[1]<E<=irq[1]
 assert arm[4:8]==[E,1,E,0] and irq[4]==E and irq[2:4]==[0,2]
 assert len(b[23])<=1
 result.update(boot_sample=post[4],boot_to_E=E-post[4],prep_duration=prep[1]-prep[4],prep_slack=E-prep[1],irq_offset=irq[1]-E)
 if b[23]:
  c=one(23);assert c[2:4]==[0,0] and c[4]==irq[1] and c[6:]==[E,1] and irq[1]<=c[5]<=c[1]
  assert not any(r[1]<c[1] for t in (5,6,7,8,10,19) for r in b[t])
  result.update(irq_to_precommit=c[5]-irq[1],commit_duration=c[1]-c[5],commit_offset=c[1]-E,irq_to_commit=c[1]-irq[1])
 if b[10]:
  c=one(23);g=b[10][0];cut=next(r for r in b[3] if r[7]==1)
  assert c[1]<=cut[1]<=b[7][0][1]<=g[4]<=g[5] and c[1]-E<=ms
  result.update(commit_to_arm=cut[1]-c[1],commit_to_preeret=g[4]-c[1],boot_to_first=g[5]-post[4],first_offset=g[5]-E)
 if z[4:6]==[2,5]:assert z[6]-E>ms and not b[7] and z[7]==E
 if z[4:6]==[2,2]:assert z[6]-z[7]>ms and z[6:8]==[b[10][-1][5],E+b[10][-1][2]*S]
 return result
