from pathlib import Path
import subprocess as sp, os, sys, json, time, re, hashlib, shutil, struct
D=Path('/home/ywcho/iv379-9271a68')
R=D/'raw'; S=D/'src'
os.chdir(S)
os.environ.update(PATH='/home/ywcho/.cargo/bin:'+os.environ['PATH'],CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR=str(D/'sdk-target'),PYTHONDONTWRITEBYTECODE='1')
def run(label,args):
    args=list(map(str,args))
    (R/(label+'.argv.json')).write_text(json.dumps(args,indent=2))
    with (R/(label+'.log')).open('xb') as f:
        rc=sp.run(args,stdout=f,stderr=sp.STDOUT).returncode
    print(label,rc,flush=True)
    return rc
apps=['writer','writer-rust','reader','anon-writer','anon-reader','shell','cat','wc']
for i,app in enumerate(apps):
    out=R/(app+'.elf')
    if app=='writer-rust':
        rc=run('sdk-'+app,['sh','sdk/native-aarch64/build-rust.sh','--pipes','examples/native-pipes/writer-rust/Cargo.toml',out])
    else:
        sub='native-shell-pipeline' if i>=5 else 'native-pipes'
        rc=run('sdk-'+app,['sh','sdk/native-aarch64/build.sh','--pipes',*(['--native-shell'] if i>=5 else []),f'examples/{sub}/{app}.c',out])
    if not rc:
        run('readelf-'+app,['readelf','-lW',out])
        run('nm-'+app,['aarch64-linux-gnu-nm','-nS',out])
run('host-compile',['rustc','--edition','2024','--test','kernel/src/pipe_ipc.rs','-o',D/'host-tests'])
if (D/'host-tests').exists():
    run('host-controls',[D/'host-tests','--test-threads=1','--nocapture'])
for k,v in {'a':b'first\nno final newline\nend', 'b':(b'0123456789\n'*74)+b'\n\npartial'}.items():
    f=R/('input-'+k+'.txt'); f.write_bytes(v)
    with f.open('rb') as x:
        (R/('wc-'+k+'.bin')).write_bytes(sp.check_output(['wc','-l'],stdin=x))
def capture(name,pkg,minimum,slots):
    import sys
    sys.path.insert(0,str(S/'tools'))
    from qemu_capture import request
    from ordinary_amc_capture import FLAGS
    c=R/('boot-'+name); c.mkdir()
    cmd=['qemu-system-aarch64',*FLAGS,'-qmp','stdio','-serial','file:'+str(c/'uart.bin'),'-kernel',str(pkg/'kernel.elf')]
    proc=sp.Popen(cmd,stdin=sp.PIPE,stdout=sp.PIPE,stderr=(c/'stderr').open('wb'))
    start=time.monotonic()
    status='timeout'
    try:
        assert 'QMP' in json.loads(proc.stdout.readline())
        class P: write=proc.stdin.write; readline=proc.stdout.readline
        conn=P(); request(conn,'qmp_capabilities')
        while time.monotonic()-start<4:
            raw=(c/'uart.bin').read_bytes()
            if re.search(rb'^NATIVE EL0 FAULT .*\n',raw,re.M) or b'PANIC' in raw:
                status='fault'; break
            ids={int(x) for x in re.findall(rb'^NATIVE EL0 EXIT PID (\d+) -?\d+\r?\n',raw,re.M)}
            if len(ids)>=minimum or (slots==1 and re.search(rb'^NATIVE EL0 EXIT -?\d+\r?\n',raw,re.M)):
                status='terminal'; break
            time.sleep(.01)
        request(conn,'stop')
        sym=sp.check_output(['aarch64-linux-gnu-nm','-nS',pkg/'kernel.elf'],text=True)
        (c/'kernel.nm').write_text(sym)
        lo=int(next(s.split()[0] for s in sym.splitlines() if s.endswith(' _start')),16)
        hi=int(next(s.split()[0] for s in sym.splitlines() if s.endswith(' __stack_top')),16)
        request(conn,'pmemsave',val=lo,size=hi-lo,filename=str(c/'ram.bin'))
        (c/'capture.json').write_text(json.dumps(dict(cmd=cmd,pid=proc.pid,capture=status,lo=lo,hi=hi,elapsed=time.monotonic()-start),indent=2))
    finally:
        proc.terminate()
        proc.wait(timeout=3)
    print('boot-'+name,status,flush=True)
def package(name,policy,names,opts,expected,prio=None):
    tg=R/('package-'+name)
    ps=[3]*len(names) if prio is None else prio
    args=['python3','tools/build_native_el0.py','--pipes','--board','virt','--policy',policy,'--out',tg,'--priority',ps[0],'--elf',R/(names[0]+'.elf')]
    for n,pri in zip(names[1:],ps[1:]):args+=['--peer-elf',R/(n+'.elf'),'--peer-priority',pri]
    if policy=='rr': args+=['--quantum-ticks','625000']
    args+=opts
    if run('package-'+name,args)==0:capture(name,tg,expected,len(names))
for policy in ('fifo','rr'):
    package('named-'+policy,policy,apps[:3],['--fifo-grant','0:4:3','--pipe-link','0:3:1:3','--pipe-link','0:4:2:3','--pipe-link','1:4:0:5'],3)
    package('anon-'+policy,policy,apps[3:5],['--pipe-link','0:1:1:0','--pipe-link','1:4:0:4'],2)
    for k,cmd,data,ex in [('a','cat sample.txt | wc -l','a',3),('b','cat sample.txt | wc -l','b',3),('missing','cat missing.txt | wc -l','a',3),('malformed','cat sample.txt |','a',1),('unknown','cat sample.txt | missing -l','a',2)]:
        package('shell-'+k+'-'+policy,policy,apps[5:],['--exec-child','1:cat','--exec-child','2:wc','--rom-file','sample.txt='+str(R/('input-'+data+'.txt')),'--arg',cmd],ex,[7,4,4])
print('END-ORIGINALS',flush=True)