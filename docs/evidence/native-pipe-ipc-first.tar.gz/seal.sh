set -eu
d=/home/ywcho/iv379-9271a68
cd "$d"
cp /mnt/d/codex/.jnox-work/next-fixed/379-verifier-9271a68/README.en-ko.md raw/
cp /mnt/d/codex/.jnox-work/next-fixed/379-verifier-9271a68/seal.sh raw/
git -C src archive --format=tar.gz --output="$d/raw/inputs-and-source.tar.gz" HEAD examples/native-pipes examples/native-shell-pipeline sdk/native-aarch64 kernel/src/native_el0_mmu.rs kernel/src/native_el0.rs kernel/src/native_spawn.rs kernel/src/native_pipe_ipc.rs kernel/src/pipe_ipc.rs tools/build_native_el0.py tools/native_shell_rom.py
git --git-dir=/mnt/d/codex/j-nox/.git show 4637f54cafdbcf417a7efdffc9691e931b7f5b95:docs/native-pipe-ipc.en-ko.md >raw/contract.en-ko.md
{ qemu-system-aarch64 --version; clang --version; ld.lld --version; /home/ywcho/.cargo/bin/rustc -vV; /home/ywcho/.cargo/bin/cargo --version; python3 --version; aarch64-linux-gnu-nm --version; uname -a; sha256sum "$(command -v qemu-system-aarch64)"; } >raw/provenance.txt
cd raw
find . -path '*/target' -prune -o -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
sha256sum -c SHA256SUMS > "$d/seal-verify.log"
tar --exclude='*/target' -czf "$d/379-9271a68-first.tar.gz" .
out=/mnt/d/codex/.jnox-work/next-fixed/379-verifier-9271a68
cp "$d/379-9271a68-first.tar.gz" "$out/"
cd "$out"
sha256sum 379-9271a68-first.tar.gz >379-9271a68-first.tar.gz.sha256
mkdir "$d/replay-fresh"
tar -xzf 379-9271a68-first.tar.gz -C "$d/replay-fresh"
cd "$d/replay-fresh"
sha256sum -c SHA256SUMS >"$d/after-unpack.log"
python3 replay.py > "$d/after-unpack.json"
cmp -s "$d/after-unpack.json" report.json
wc -l SHA256SUMS
cat "$out/379-9271a68-first.tar.gz.sha256"
ls -lh "$out/379-9271a68-first.tar.gz"