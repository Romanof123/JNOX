from pathlib import Path
import subprocess as s,socket,time,struct,shutil,json,sys,hashlib
p=Path(__file__).parent
for case,pcs in [('entry',[0x40202dd0,0x40202de0,0x40202eb4,0x40202ef0]),('after',[0x40202ec0,0x40202134,0x40201a74,0x40201a7c])]:
 d=Path('/tmp/jnox213-first-independent')/('saved-v3-'+case);d.mkdir(parents=True)
 elf=d/'kernel.elf';shutil.copyfile(p/'images/rm-C-a0/kernel.elf',elf)
 argv=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-m','128M','-nodefaults','-nic','none','-display','none','-monitor','none','-serial','file:'+str(d/'uart'),'-icount','shift=0,align=off,sleep=off','-S','-gdb','tcp:127.0.0.1:12473','-d','int,trace:pl061*','-D',str(d/'mechanism'),'-kernel',str(elf)]
 with (d/'stderr').open('wb') as err:
  proc=s.Popen(argv,stderr=err);events=[]
  try:
   for i in range(100):
    try:sock=socket.create_connection(('127.0.0.1',12473),.2);break
    except OSError:time.sleep(.02)
   sock.settimeout(10);sock.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
   def packet(msg):
    raw=msg.encode();sock.sendall(b'$'+raw+b'#'+('%02x'%(sum(raw)%256)).encode());a=sock.recv(1)
    while a!=b'$':
     if not a:raise EOFError()
     a=sock.recv(1)
    out=b''
    while (x:=sock.recv(1))!=b'#':out+=x
    sock.recv(2);sock.sendall(b'+');return out.decode()
   def regs():
    v=bytes.fromhex(packet('g'));return {'sp':int.from_bytes(v[248:256],'little'),'pc':int.from_bytes(v[256:264],'little'),'pstate':int.from_bytes(v[264:268],'little'),'x25':int.from_bytes(v[200:208],'little'),'x0':int.from_bytes(v[:8],'little')}
   print(packet('?'),packet('Hg0'),packet('Hc-1'),flush=True)
   for j,pc in enumerate(pcs):
    print(case,hex(pc),flush=True)
    if j==0:
     assert packet(f'Z0,{pc:x},4')=='OK';stop=packet('c');r=regs();assert packet(f'z0,{pc:x},4')=='OK'
    else:
     for step in range(12000):
      stop=packet('s');r=regs()
      if r['pc']==pc:break
      if step and step%1000==0:print('stepping',hex(r['pc']),flush=True)
    events.append(dict(stop=stop,**r,missed=packet('m40205130,10')));assert r['pc']==pc
    print(r,flush=True)
    if j==0:
     assert packet('M40205130,10:'+struct.pack('<QQ',1,0).hex())=='OK'
   assert events[-1]['pstate']&128==0
   if case=='entry':assert events[-1]['pstate']&0x3c0==events[-2]['x25']&0x3c0
   if case=='after':assert events[0]['sp']==events[2]['sp']
  finally:
   proc.kill();proc.wait(5);(d/'result.json').write_text(json.dumps(dict(case=case,argv=argv,events=events),indent=2));shutil.copytree(d,p/d.name)



