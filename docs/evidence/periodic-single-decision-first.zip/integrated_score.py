from pathlib import Path
import sys,json,subprocess as sp,re,hashlib,struct,collections,importlib.util
p=Path(__file__).resolve().parent;b=p.parent
spec=importlib.util.spec_from_file_location("observer",b/"permit-phase-independent-observer-v2/observe.py");o=importlib.util.module_from_spec(spec);spec.loader.exec_module(o)
read=lambda f:json.loads(f.read_bytes())
def save(f,v):f.write_text(json.dumps(v,indent=2)+'\n')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def loads(f):
 data=f.read_bytes();off=struct.unpack_from('<Q',data,32)[0];stride,n=struct.unpack_from('<HH',data,54);out=[]
 for i in range(n):
  kind,flags,at,va,pa,fs,ms,align=struct.unpack_from('<II6Q',data,off+i*stride)
  if kind==1:out.append([flags,va,pa,fs,ms,align,hashlib.sha256(data[at:at+fs]).hexdigest()])
 return out
comparisons={}
for pol in ['rm','dm']:
 d=p/f'{pol}-op-0';old=b/f'control53-integrated-gate/descriptor-{pol}-descriptor/kernel.elf'
 def dis(f):return sp.check_output(['aarch64-linux-gnu-objdump','-dC',f],text=True).splitlines()[2:]
 def code(f):return [x.split('\t')[1].strip() for x in dis(f) if re.match(r'^\s*[a-f0-9]+:\s+[0-9a-f]{8}',x)]
 elf=d/'kernel.elf';comparisons[pol]=dict(original='fe8821bf0e144c6bbef5b4408b28e27ab03e9488',original_hash=sha(old),hash=sha(elf),load_identical=loads(old)==loads(elf),disassembly_identical=dis(old)==dis(elf),machine_instructions_and_embedded_words_identical=code(elf)==code(old),original_segments=loads(old),current_segments=loads(elf))
save(p/'a0-comparisons.json',comparisons)
summary=[]
for pos in read(p/'freeze.json')['positions']:
 d=p/'raw'/pos['id'];f=d/'mechanism';uart=d/'uart';z=o.score(pos,uart,None,f)
 save(d/'observed.json',z)
 r=z['raw_rows']; rows=lambda tag:[x[1:] for x in r if x[0]==tag];log=f.read_text()
 writes=[(int(x,16),int(y,16)) for x,y in re.findall(r'pl061_write [^\n]+ offset (0x\w+) value (0x\w+)',log)]
 direction=[v for off,v in writes if off==1024]; data=[v for off,v in writes if off<1024 and off&4]
 readbits=set(re.findall(r'pl061_read [^\n]+ offset 0x4 value (0x\w+)',log))
 bits=re.findall(r'pl061_set_output [^\n]+ setting output 0 to (\d+)',log)
 elrs=z['mechanism']['elrs'];eret=z['mechanism']['erets'];ret=[hex(x[2]) for x in rows(93)]
 asm=(p/pos['key']/'linked.txt').read_text();syms=(p/pos['key']/'symbols.txt').read_text()
 symbols=[(int(v,16),int(s,16),n) for v,s,n in re.findall(r'^([a-f0-9]+) ([a-f0-9]+) [Tt] (.+)$',syms,re.M)]
 def symbol(pc):
  pc=int(pc,16);return next((n for at,size,n in symbols if at<=pc<at+size),'no-sized-symbol')
 def inst(pc):return re.search(r'^\s*'+format(pc,'x')+r':\s+[a-f0-9]+\s+(.*)$',asm,re.M)
 evidence=[]
 for evt,elr,pc in re.findall(r'Taking exception \d+ \[(SVC|IRQ)\](?:(?!Taking exception).)*?with ELR (0x\w+)(?:(?!Taking exception).)*?Exception return [^\n]+ PC (0x\w+)', '\n'.join(x for x in log.splitlines() if 'pl061_' not in x),re.S):
  prev=inst(int(elr,16)-4)
  evidence.append(dict(event=evt,elr=elr,from_symbol=symbol(elr),preceding=prev.group(1) if prev else None,eret=pc,to_symbol=symbol(pc)))
 obsdev=dict(reset='pl061_reset ' in log,direction=direction,bit0_data_writes=data,bit0_output_notifications=bits,readback_values=sorted(readbits),firmware_write_count=rows(89)[0][1] if rows(89) else None,guest_write_triplets=z['write_path_triplets_complete'],all_gpio_writes=writes,same_counter_sync=False)
 save(d/'mechanism-audit.json',dict(exception_pairs=evidence,device=obsdev,pre_eret=ret,actual_returns=eret,pre_eret_matches_order=ret==eret,eret_symbols=[symbol(pc) for pc in eret]))
 summary.append(dict(id=pos['id'],arm=pos['arm'],disposition=z['disposition'],complete=z['complete_dump'],freq=z['frequency'],missing=rows(65),latch=z['first_latch'],reject=z['first_rejection'],horizon=rows(90),issued=len(rows(11)),accepted=len(rows(12)),issue_delta=z['first_issue_gap'],publication_gap=z['first_publication_gap'],command=z['command'],hypothetical=len(rows(84)),device=obsdev,irq=z['mechanism']['irq_count'],svc=z['mechanism']['svc_count'],eret=len(eret),pre_eret_order=(ret==eret if ret else None),scheduler=z['scheduler'],terminal=z['terminal']))
 print(pos['id'],z['disposition'],z['first_rejection'],len(rows(11)),len(rows(12)),len(rows(84)),len(ret),len(eret),flush=True)
save(p/'results.json',summary)

