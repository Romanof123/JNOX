from pathlib import Path,PurePosixPath
import io,zipfile,tarfile,json,hashlib,sys,struct,collections
p=Path(__file__).resolve().parent;b=p.parent;orig=b/'permit-phase-first-verification'
sha=lambda x:hashlib.sha256(x).hexdigest()
def save(n,v):(p/n).write_text(json.dumps(v,indent=2)+'\n')
def get(f):return json.loads(f.read_bytes())
def strict(a,b):return type(a)==type(b) and (a.keys()==b.keys() and all(strict(a[k],b[k]) for k in a) if type(a)==dict else len(a)==len(b) and all(strict(x,y) for x,y in zip(a,b)) if type(a)==list else a==b)
def manifest(raw):
 m={}
 for line in raw.decode().splitlines():
  h,n=line.split('  ',1);assert n not in m and not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts;m[n]=h
 return m
d=b/'phase-main-pinned/docs/evidence';ev=get(d/'evd-054.json');zbytes=(d/'evd-054-first.zip').read_bytes();assert strict(ev['archive']['bytes'],len(zbytes)) and sha(zbytes)==ev['archive']['sha256']
with zipfile.ZipFile(io.BytesIO(zbytes)) as z:
 files={n:z.read(n) for n in z.namelist()};assert len(files)==len(z.namelist());m=manifest(files['FILES.sha256']);assert set(files)==set(m)|{'FILES.sha256'} and all(sha(files[n])==h for n,h in m.items())
 tar=files['permit-phase-first-verification/first-verification.tar.gz'];assert sha(tar)==ev['original_archive_sha256']==sha((orig/'first-verification.tar.gz').read_bytes())
 assert files['permit-phase-first-verification/archive.sha256'].decode().strip()==sha(tar)+'  first-verification.tar.gz'
 for pol in ('rm','dm'):
  k=f'control53-integrated-gate/descriptor-{pol}-descriptor/kernel.elf';assert files[k]==(b/k).read_bytes()
 assert files['permit-phase-independent-observer/observe.py']==(b/'permit-phase-independent-observer/observe.py').read_bytes()
with tarfile.open(fileobj=io.BytesIO(tar)) as t:
 names=t.getnames();assert len(names)==len(set(names)) and all(i.isfile() for i in t.getmembers())
 ledger=t.extractfile('SHA256SUMS').read();m=manifest(ledger);assert sha(ledger)==ev['reviewer_manifest_sha256'] and set(names)==set(m)|{'SHA256SUMS'}
 for n,h in m.items():assert sha(t.extractfile(n).read())==h
 assert ev['inputs_and_outcomes_sha256']=={n:m[n] for n in ['freeze.json','builds.json','plan.json','results.json','REPORT.md','score.py','finish.py']}
 rs=json.load(t.extractfile('results.json'));frozen=json.load(t.extractfile('freeze.json'))['positions']
 keys=['id','arm','disposition','complete','issued','accepted','issue_delta','hypothetical','irq','svc','eret']
 assert strict(ev['positions'],[{k:v[k] for k in keys} for v in rs]) and [x['id'] for x in rs]==[x['id'] for x in frozen] and len(set(x['id'] for x in rs))==32
 def sample(prefix):return [x for x in rs if x['id'].startswith(prefix)]
 op=sample('operational');off=sample('characterization');agg=dict(operational_positions=len(op),operational_healthy=sum(x['accepted']>0 and not x['latch'] for x in op),operational_a1_a2_refused=sum(x['disposition']=='refused-before-workers' for x in op),operational_a0_faulted=sum(x['arm']==0 and bool(x['latch']) for x in op),off_default_early_stops=sum('default' in x['id'] and x['disposition']=='observed-early-stop' for x in off),off_icount_completed=sum('icount' in x['id'] and x['disposition']=='observed-full-phase-horizon' for x in off),off_icount_accepted_permits=sum(x['accepted'] for x in off if 'icount' in x['id']),positive_device_edges=sum(x['device']['bit0_output_notifications'].count('1') for x in rs))
 for k,v in agg.items():assert strict(ev[k],v),k
 for k,v in dict(evidence_id='EVD-054',change='CHG-055',implementation='IMP-054',source='c382eb3c42955324b87ffff3b72d862b10bc8c7c').items():assert strict(ev[k],v)
 assert ev['archive']['file']=='evd-054-first.zip' and type(ev['archive']['offline_replay']) is str and type(ev['archive']['verification']) is str
 assert not strict(True,1) and not strict([0],[False])
 save('archive-audit.json',dict(zip_bytes=len(zbytes),zip_sha256=sha(zbytes),zip_members=len(files),tar_members=len(names),ledger_sha256=sha(ledger),typed_positions=len(rs),aggregates=agg))
def segments(f):
 data=f.read_bytes();off=struct.unpack_from('<Q',data,32)[0];step,n=struct.unpack_from('<HH',data,54);out=[]
 for i in range(n):
  k,flags,at,va,pa,fs,ms,align=struct.unpack_from('<II6Q',data,off+i*step)
  if k==1:out.append(((flags,va,pa,fs,ms,align),data[at:at+fs]))
 return out
loads={}
refmap={k:(p/k/'kernel.elf',orig/k/'kernel.elf') for k,v in get(p/'builds.json').items() if not v['exit']}
for k,v in get(p/'reg-builds.json').items():
 if v['valid']:refmap[k]=(p/'reg'/k/'kernel.elf',b/('control53-integrated-gate' if k.startswith('markers-') else 'partition-notice-release-builds')/k/'kernel.elf')
for k,(current,prior) in refmap.items():
 ss,tt=segments(prior),segments(current);assert len(ss)==len(tt);recs=[]
 for (old,ox),(new,nx) in zip(ss,tt):
  dif=[i for i,(a,c) in enumerate(zip(ox,nx)) if a!=c];covered=set();loc=[]
  for i in range(0,min(len(ox),len(nx))-23,8):
   ov,ol,ln,col=struct.unpack_from('<QQII',ox,i);nv,nl,newline,newcol=struct.unpack_from('<QQII',nx,i)
   if ov!=nv or ol!=nl or ln==newline or col!=newcol or not (0<ol<200 and old[1]<=ov and ov+ol<=old[1]+len(ox)):continue
   off=ov-old[1];path=ox[off:off+ol]
   if path!=nx[off:off+ol] or not path.endswith(b'.rs'):continue
   loc.append([i+16,path.decode(),ln,newline,col]);covered.update(range(i+16,i+20))
  unresolved=[i for i in dif if i not in covered];recs.append(dict(old_layout=old,new_layout=new,old_sha=sha(ox),new_sha=sha(nx),delta=len(dif),source_line_fields=loc,unexplained_offsets=unresolved[:200],unexplained_count=len(unresolved),equal_zero_fill_and_layout=old==new))
 loads[k]=dict(reference=str(prior.relative_to(b)),prior_sha=sha(prior.read_bytes()),current_sha=sha(current.read_bytes()),identical=ss==tt,only_source_metadata=all(r['equal_zero_fill_and_layout'] and not r['unexplained_count'] for r in recs),segments=recs)
save('load-audit.json',loads)
