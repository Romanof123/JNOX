from pathlib import Path
import hashlib,zipfile,sys
p=Path(__file__).parent
files=sorted(f for f in p.rglob('*') if f.is_file() and not {'target','__pycache__'}.intersection(f.relative_to(p).parts) and f.name!='SHA256SUMS')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
(p/'SHA256SUMS').write_text(''.join(sha(f)+'  '+f.relative_to(p).as_posix()+'\n' for f in files))
out=p.parent/'jnox213-independent-689a4c62.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
 for f in files+[p/'SHA256SUMS']:z.write(f,f.relative_to(p))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for f in files:assert hashlib.sha256(z.read(f.relative_to(p).as_posix())).hexdigest()==sha(f)
digest=sha(out);out.with_suffix('.zip.sha256').write_text(digest+'  '+out.name+'\n');print(len(files)+1,out.stat().st_size,digest)
