from pathlib import Path
import json
p=Path(__file__).parent
for d in sorted((p/'raw').iterdir())[:8]:
 o=json.loads((d/'observation.json').read_bytes());rows=o['raw_rows']
 r=lambda tag:[v[1:] for v in rows if v[0]==tag]
 epoch,f,last=r(1)[0];step=f//400
 phases=[]
 for ix in range(last+1):
  target=epoch+ix*step
  irq=next((v for v in r(3) if v[2]==ix),None)
  checks=[v for v in r(21) if v[1]==ix];exits=[v for v in r(10) if v[1]==ix]
  if not checks or not exits:continue
  first=checks[0][2];dispatch=[v for v in r(5) if v[1]==0 and v[0]<=first];svc=[v for v in r(6) if v[1]==0 and v[0]>=exits[0][0]]
  phases.append(dict(index=ix,target=target,irq=irq[0] if irq else None,dispatch=dispatch[-1][0] if dispatch else None,freshness_input=first,decision_complete=checks[0][0],phase_completion_upper=exits[0][0],subsequent_slice_end=svc[0][0] if svc else None,charged_slice_at_end=svc[0][2] if svc else None))
 (d/'phase-join.json').write_text(json.dumps(phases,indent=2))
