from pathlib import Path
import subprocess as s, json, hashlib,os, shutil, tarfile,zipfile,io
p=Path(__file__).parent
sources={'C':p.parent/'jnox213-independent-src','P':p.parent/'jnox213-base'}
sha=lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
builds={}
runs=[]
for pol in ('rm','dm'):
 for src in ('P','C'):
  for case in ['a0','stock','cold','marker']+(['op1','op2','off1','off2'] if src=='C' else []):
   env=dict(JNOX_BOARD='virt',JNOX_PROFILE='periodic',JNOX_APP='control-'+pol,JNOX_CONTROL_CASE='healthy')
   if case=='cold':env['JNOX_CONTROL_COLD']='diagnostic'
   elif case=='marker':env['JNOX_CONTROL_MARKERS']='1'
   elif case!='stock':env['JNOX_CONTROL_DESCRIPTOR']='1'
   if case[-1] in '12':
    env['JNOX_PERMIT_PHASE']=['nominal','anchor'][int(case[-1])-1]
    if 'off' in case:env['JNOX_PERMIT_PHASE_MODE']='characterize-off'
   builds[f'{pol}-{src}-{case}']=env
 for src in ('P','C','C','P'):runs.append([f'{pol}-{src}-a0','default'])
for pol in ('rm','dm'):
 for case,clock in [('op','default'),('off','default'),('off','icount')]:
  for arm in (1,2):runs.append([f'{pol}-C-{case}{arm}',clock])
for pol in ('rm','dm'):
 for case in ('stock','cold','marker'):runs.append([f'{pol}-C-{case}','default'])
(p/'freeze-plan.json').write_text(json.dumps(dict(builds=builds,runs=runs,source={k:s.check_output(['git','rev-parse','HEAD'],cwd=v,text=True).strip() for k,v in sources.items()},plan='c45948ff8c3d9f453c24f9199887ef26f88fc96c',timeout=10),indent=2))
with zipfile.ZipFile(sources['C']/'docs/evidence/evd-054-integration.zip') as z:
 with tarfile.open(fileobj=io.BytesIO(z.read(z.namelist()[0]))) as t:
  for n in ('guard.py','observer-v2/observe.py','integrated_score.py','audit.py'):
   (p/Path(n).name).write_bytes(t.extractfile(n).read().replace(b'\r\r\n',b'\n'))
for key,opts in builds.items():
 d=p/'images'/key;d.mkdir(parents=True)
 env={k:v for k,v in os.environ.items() if not k.startswith(('JNOX_','CARGO_PROFILE_','CARGO_TARGET_','RUST')) and k!='CARGO_ENCODED_RUSTFLAGS'}
 env.update(opts,CARGO_TARGET_DIR=str(p/'target'),CARGO_BUILD_JOBS='1')
 with (d/'build.log').open('wb') as log:s.run(['cargo','+1.95.0','build','--release','--locked','-j1','-vv'],cwd=sources[key.split('-')[1]]/'kernel',env=env,stdout=log,stderr=s.STDOUT,check=True)
 shutil.copy2(p/'target/aarch64-unknown-none/release/jnox-kernel',d/'kernel.elf')
 print(key,sha(d/'kernel.elf'),flush=True)
