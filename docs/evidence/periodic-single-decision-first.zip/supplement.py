from pathlib import Path
import json,time,shutil,subprocess as s,hashlib
p=Path(__file__).parent
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
for pos in json.loads((p/'supplement-freeze.json').read_bytes())['runs']:
 d=Path('/tmp/jnox213-cold-mode1')/pos['id'];d.mkdir(parents=True);assert 'ext4' in s.check_output(['df','-T',d],text=True)
 shutil.copyfile(p/'images'/pos['key']/'kernel.elf',d/'kernel.elf');assert sha(d/'kernel.elf')==pos['elf'];(d/'mode').write_bytes(bytes.fromhex(pos['input_hex']))
 t=time.monotonic()
 with (d/'stdout').open('wb') as out,(d/'stderr').open('wb') as err:
  proc=s.Popen(pos['argv'],stdout=out,stderr=err);reason='exit'
  while proc.poll() is None:
   if (d/'uart').exists() and (d/'uart').read_bytes().endswith(b'CONTROL END\n'):reason='terminal';break
   if time.monotonic()-t>=10:reason='timeout';break
   time.sleep(.002)
  if proc.poll() is None:proc.terminate()
  proc.wait(5)
 dest=p/d.name;shutil.copytree(d,dest);files={f.name:sha(f) for f in d.iterdir()};assert all(sha(dest/k)==v for k,v in files.items())
 (dest/'receipt.json').write_text(json.dumps(dict(reason=reason,elapsed=time.monotonic()-t,files=files),indent=2));print(d.name,reason)
