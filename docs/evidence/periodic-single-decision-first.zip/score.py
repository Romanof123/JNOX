from pathlib import Path
import json,sys,struct,hashlib,re
import observe
p=Path(__file__).parent
sys.path.insert(0,str(p.parent/'jnox213-independent-src/tools'))
import control_observations as co
def save(f,v):f.write_text(json.dumps(v,indent=2))
summary=[]
for pos in json.loads((p/'freeze.json').read_bytes())['positions']:
 d=p/'raw'/pos['id'];pol,src,case=pos['key'].split('-');arm=int(case[-1]) if case[-1] in '12' else 0
 mode='characterization' if case.startswith('off') else 'operational'
 o=observe.score(dict(id=pos['id'],policy=pol,mode=mode,clock=pos['clock'],arm=arm),d/'uart',None,d/'mechanism');save(d/'observation.json',o)
 gate=co.score_capture(d/'uart','healthy');save(d/'original-gate.json',gate)
 r=lambda tag:[v[1:] for v in o['raw_rows'] if v[0]==tag]
 service=[v[2] for v in r(6) if v[1]==0];irq=r(3);dec=r(10);epoch=r(1)
 log=(d/'mechanism').read_text()
 bits=re.findall('setting output 0 to ([01])',log)
 summary.append(dict(id=pos['id'],eligible=not gate['failures'],failures=gate['failures'],disposition=o['disposition'],first_service=service[:1],first_irq=[irq[0][0]-epoch[0][0]] if irq and epoch else [],first_phase=[dec[0][0]-dec[0][2]] if dec else [],issued=len(r(11)),accepted=len(r(12)),commands=len(r(17)),rearm=len(r(20)),edges=bits,missing=r(65),reject=o['first_rejection'],terminal=o['terminal'],horizon=o['horizon'],gap=o['first_issue_gap'],readbits=sorted(set(re.findall(r'pl061_read [^\n]+ offset 0x4 value (0x\w+)',log))),receipt=json.loads((d/'receipt.json').read_bytes())['reason']))
save(p/'summary.json',summary)
for x in summary:print(x['id'],x['eligible'],x['disposition'],x['first_service'],x['first_irq'],x['first_phase'],x['issued'],x['accepted'],x['missing'],x['edges'],x['gap'])
def loads(f):
 data=f.read_bytes();off=struct.unpack_from('<Q',data,32)[0];sz,n=struct.unpack_from('<HH',data,54);out=[]
 for i in range(n):
  typ,flags,at,va,pa,fs,ms,align=struct.unpack_from('<II6Q',data,off+i*sz)
  if typ==1:out.append([flags,va,pa,fs,ms,align,hashlib.sha256(data[at:at+fs]).hexdigest()])
 return out
save(p/'legacy-loads.json',{key:{side:loads(p/'images'/f'{key[:2]}-{side}-{key[3:]}'/'kernel.elf') for side in ('P','C')} for pol in ('rm','dm') for case in ('cold','stock','marker') for key in [pol+'-'+case]})
