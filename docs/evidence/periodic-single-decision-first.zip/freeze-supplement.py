from pathlib import Path
import json,hashlib
p=Path(__file__).parent
f=json.loads((p/'freeze.json').read_bytes())
runs=[]
for pol in ('rm','dm'):
 pos=next(x for x in f['positions'] if x['key']==pol+'-C-cold')
 name='supplement-'+pol+'-cold';root='/tmp/jnox213-cold-mode1/'+name
 args=[v.replace('/tmp/jnox213-first-independent/'+pos['id'],root) for v in pos['argv']]
 args+=['-fw_cfg','name=opt/jnox/cold-mode,file='+root+'/mode']
 runs.append(dict(id=name,key=pos['key'],elf=pos['elf'],argv=args,input_hex='31',mode=1,first_preserved=pos['id']))
(p/'supplement-freeze.json').write_text(json.dumps(dict(runs=runs,criteria=['ELF unchanged','row 48 input 1','terminal CONTROL END','absence of row 60 input refusal','real phase rows and independent GPIO readback','10 s, no retries, verified D archive before next guest']),indent=2))
