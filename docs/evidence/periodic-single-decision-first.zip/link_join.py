from pathlib import Path
import json,re,subprocess as sp
p=Path(__file__).parent
def save(f,v):f.write_text(json.dumps(v,indent=2))
for pos in json.loads((p/'freeze.json').read_bytes())['positions']:
 d=p/'raw'/pos['id'];z=json.loads((d/'observation.json').read_bytes());log=(d/'mechanism').read_text();r=z['raw_rows'];rows=lambda tag:[v[1:] for v in r if v[0]==tag]
 asm=(p/'images'/pos['key']/'linked.txt').read_text();syms=(p/'images'/pos['key']/'symbols.txt').read_text()
 symbols=[(int(v,16),int(sz,16),n) for v,sz,n in re.findall(r'^([a-f0-9]+) ([a-f0-9]+) [Tt] (.+)$',syms,re.M)]
 def symbol(pc):return next((n for at,sz,n in symbols if at<=int(pc,16)<at+sz),None)
 inst={int(pc,16):op for pc,op in re.findall(r'^\s*([a-f0-9]+):\s+[a-f0-9]+\s+([^\n]+)',asm,re.M)}
 irqlog='\n'.join(x for x in log.splitlines() if 'pl061_' not in x)
 ev=[dict(event=kind,elr=elr,origin=symbol(elr),preceding=inst.get(int(elr,16)-4),eret=eret,destination=symbol(eret)) for kind,elr,eret in re.findall(r'Taking exception \d+ \[(SVC|IRQ)\](?:(?!Taking exception).)*?with ELR (0x\w+)(?:(?!Taking exception).)*?Exception return [^\n]+ PC (0x\w+)',irqlog,re.S)]
 save(d/'linked-events.json',dict(events=ev,pre_ret_rows=rows(93),targets=rows(2),irq=rows(3),dispatch=rows(5),slices=rows(6),decisions=rows(10),exits=rows(34)+rows(35),issued=rows(11),accepted=rows(12),commands=rows(17),rearm=rows(20),output=rows(18)))
