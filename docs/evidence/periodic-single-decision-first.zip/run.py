from pathlib import Path
import subprocess as s,os,time,json,shutil,hashlib,sys
from guard import Guard,stop_process
p=Path(__file__).parent; n=Path('/tmp/jnox213-first-independent');n.mkdir(); assert 'ext4' in s.check_output(['df','-T',n],text=True)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def save(f,v):f.write_text(json.dumps(v,indent=2))
q=Path('/usr/bin/qemu-system-aarch64')
freeze={'qemu':sha(q),'version':s.check_output([q,'--version'],text=True),'positions':[]}
for i,(key,clock) in enumerate(json.loads((p/'freeze-plan.json').read_bytes())['runs'],1):
 d=n/f'{i:02}-{key}';d.mkdir();shutil.copyfile(p/'images'/key/'kernel.elf',d/'kernel.elf')
 args=[str(q),'-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-nic','none','-serial','file:'+str(d/'uart'),'-d','int,trace:pl061*','-D',str(d/'mechanism')]
 if clock=='icount':args+=['-icount','shift=0,align=off,sleep=off']
 args+=['-kernel',str(d/'kernel.elf')];freeze['positions'].append(dict(id=d.name,key=key,clock=clock,elf=sha(d/'kernel.elf'),argv=args))
save(p/'freeze.json',freeze)
for pos in freeze['positions']:
 d=n/pos['id'];g=Guard() if 'off' in pos['key'] else None;t=time.monotonic();reason='exit'
 with (d/'stderr').open('wb') as err,(d/'stdout').open('wb') as out:
  proc=s.Popen(pos['argv'],stdout=out,stderr=err)
  while proc.poll() is None:
   raw=(d/'uart').read_bytes() if (d/'uart').exists() else b''
   if g and (g.poll(d/'mechanism') or b'CONTAINMENT FAIL' in raw): reason='containment alarm';stop_process(proc);break
   if raw.endswith(b'CONTROL END\n'):reason='terminal';break
   if time.monotonic()-t>=10:reason='timeout';break
   time.sleep(.002)
  if proc.poll() is None:proc.terminate()
  proc.wait(5)
 if g:g.poll(d/'mechanism',final=True)
 files={f.name:sha(f) for f in d.iterdir()};save(d/'receipt.json',dict(reason=reason,exit=proc.returncode,elapsed=time.monotonic()-t,guard=vars(g)|{'partial':g.partial.hex()} if g else None,files=files))
 dest=p/'raw'/d.name;shutil.copytree(d,dest);assert all(sha(dest/f)==v for f,v in files.items()) and sha(dest/'receipt.json')==sha(d/'receipt.json')
 print(d.name,reason,flush=True)
 if reason=='containment alarm':raise RuntimeError(reason)
