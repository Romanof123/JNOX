from pathlib import Path
from fractions import Fraction
import hashlib,struct,re,subprocess,json
root=Path(__file__).parent
def loads(f):
 b=f.read_bytes(); off=struct.unpack_from('<Q',b,32)[0]; sz,n=struct.unpack_from('<HH',b,54); result=[]
 for i in range(n):
  t,flags,o,v,p,fs,ms,al=struct.unpack_from('<II6Q',b,off+i*sz)
  if t==1:result.append([flags,v,p,fs,ms,al,hashlib.sha256(b[o:o+fs]).hexdigest()])
 return result
out={}
for p in ('sjf','srtf','hrrn'):
 a,b=[loads(root/'legacy'/f'{t}-{p}.elf') for t in ('base','src')]
 out[p+"-load-comparison"]={"equal":a==b,"historical":a,"candidate":b}
 out['legacy-'+p]=a
 for mode in ('normal','trace'):
  d=root/f'{mode}-{p}'; u=(d/'uart.log').read_text().splitlines(); q=(d/'irq.log').read_text()
  assert (d/'exit').read_text().strip()=='124'
  assert u[:3]==['JNOX M1 BOOT','JNOX M1 READY','TELEMETRY FREQUENCY 62500000']
  assert u[3:9]==['TELEMETRY REQUEST '+s for s in ('4 UNKNOWN','3 LENGTH','0 ACCEPT','1 ACCEPT','2 ACCEPT','0 FULL')]
  jobs={}
  for s in u[9:12]:
   _,_,id,start,end,*res=s.split(); id=int(id)
   assert id not in jobs and ' '.join(res)==['SUMMARY 3 0 65535 65542','AT_LEAST_42 3','ERROR 4'][id]
   assert int(end)>int(start); jobs[id]=(int(start),int(end))
  assert len(jobs)==3 and (p=='hrrn' or list(jobs)==[2,1,0])
  returns=[int(x,16) for x in re.findall(r'Exception return .* PC (0x\w+)',q)]
  epcs=[int(x,16) for x in re.findall(r'with ELR (0x\w+)',q)]
  assert len(returns)==9 and len(epcs)==8 and re.findall(r'with ESR 0x15/0x5600000(\d)',q)==list('11112222')
  data={'worker_intervals':jobs,'order':list(jobs)};out[d.name]=data
  if mode=='normal':assert len(u)==12;continue
  rows=[[int(x,16) for x in s.split()[2:]] for s in u[13:-1]]
  assert len(rows)==9 and u[12].startswith('BATCH IDLE EMPTY ') and u[-1]=='BATCH TRACE END'
  nm=subprocess.check_output(['nm','-S',str(d/'kernel.elf')],text=True)
  def sym(name):
   a,l=re.search(r'^(\w+) (\w+) [bT] .*'+name+r'.*$',nm,re.M).groups();return int(a,16),int(l,16)
  stack,_=sym('6STACKS');idle,_=sym('10IDLE_STACK');ipc,ilen=sym('jnox_batch_idle');obs,sp=map(lambda x:int(x,16),u[12].split()[3:]);assert ipc<=obs<ipc+ilen and idle<=sp<=idle+16384
  live={};last=0;owner=0;charges={};wins=[];ranks=[];ties=0
  for i,(kind,now,old,new,src,pc,dst,ret,arg,est,delay,status,tok,left,armed) in enumerate(rows):
   assert old==owner and now>last and returns[i]==ret and not delay and not armed
   if old:
    assert epcs[i-1]==pc and stack+(old-1)*16384<=src<=stack+old*16384-832 and src%16==0
    duration=now-last;charges[old]=charges.get(old,0)+duration;live[old][2]=max(1,live[old][2]-duration)
   if i<4:
    assert (kind,arg,est,status,tok)==(0 if i==0 else 3,[0,0,1,2][i],[1,30000,20000,10000][i],0,i+1)
    live[tok]=[now,est,est]
   elif i==4:assert (kind,arg,est,status,tok,len(live))==(3,0,30000,2,0,4)
   else:
    assert (kind,arg,est,status,tok)==(4,old,0,0,0)
    if old!=1:
     s,e=jobs[old-2];assert last<=s<e<=now;wins.append(old-2)
    del live[old]
   rank={t:(-Fraction(now-v[0],v[1]) if p=='hrrn' else v[2] if p=='srtf' else v[1]) for t,v in live.items()}
   expected=old if old in live and p!='srtf' else min(live,key=lambda t:(rank[t],t!=old,t),default=0)
   if i>=5:ranks.append({k:str(v) for k,v in rank.items()})
   if rank and list(rank.values()).count(min(rank.values()))>1:ties+=1
   assert new==expected and left==(live[new][2] if new else 0)
   if new==old:assert (src,pc)==(dst,ret)
   else:assert dst==(stack+new*16384 if new else idle+16384)-832
   if not new:assert ret==ipc
   owner,last=new,now
  assert wins==list(jobs) and not live
  data.update(charges=charges,ranks_at_completions=ranks,equal_best_ranks=ties)
print(json.dumps(out,indent=2))
