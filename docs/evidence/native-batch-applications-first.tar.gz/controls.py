import os, subprocess, pathlib, hashlib, json, sys
r=pathlib.Path.home()/'jnox342-25a4198'; src=r/'src'; out=r/'controls'; out.mkdir()
app=r/'products/urgent.elf'; digest=hashlib.sha256(app.read_bytes()).hexdigest()
env=os.environ.copy(); env.update(PATH=str(pathlib.Path.home()/'.cargo/bin')+':'+env['PATH'], PYTHONPATH=str(pathlib.Path.home()/'jnox-169-first-e203caa/deps'))
results=[]
def run(name,cmd,good=True,cwd=src,changes={}):
 p=subprocess.run(list(map(str,cmd)),cwd=cwd,env=env|changes,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); (out/(name+'.log')).write_bytes(p.stdout)
 results.append(dict(name=name,cmd=list(map(str,cmd)),env=changes,rc=p.returncode,expected_success=good,accepted=(p.returncode==0)==good)); (out/'results.json').write_text(json.dumps(results,indent=2)); return p.returncode
pack=['python3','tools/build_native_el0.py']; base=['--policy','sjf','--elf',app,'--batch-job','0,1']
for name,args in {'duplicate':base+['--batch-job','0,1'],'missing':base[:-2],'peer-missing':base+['--peer-elf',app],'extra':base+['--peer-batch-job','0,1'],'fourth':base+['--peer-elf',app,'--peer-batch-job','0,1']*3,'quantum':base+['--quantum-ticks','1'],'fifo':['--policy','fifo','--elf',app,'--batch-job','0,1'],**{n:base[:-1]+[v] for n,v in {'zero':'0,0','overflow':'9223372036854775808,1','est-over':'0,9223372036854775808','field':'0,1,2','type':'a,1','negative':'-1,1'}.items()}}.items():run('cli-'+name,pack+['--out',out/('cli-'+name)]+args,False)
raw={'CARGO_TARGET_DIR':str(r/'raw-target'),'JNOX_BOARD':'virt','JNOX_PROFILE':'native','JNOX_APP':'process','JNOX_NATIVE_POLICY':'sjf','JNOX_NATIVE_ELF':str(app),'JNOX_NATIVE_ELF_SHA256':digest,'JNOX_NATIVE_BATCH_JOBS':'0,1'}
for name,changes in {'positive':{},'maximum':{'JNOX_NATIVE_BATCH_JOBS':'9223372036854775807,9223372036854775807'},'fourth':{'JNOX_NATIVE_PEER3_ELF':str(app)},'wrong-count':{'JNOX_NATIVE_BATCH_JOBS':'0,1;0,1'},'mix':{'JNOX_NATIVE_QUANTUM_TICKS':'1'},'fifo':{'JNOX_NATIVE_POLICY':'fifo'},**{n:{'JNOX_NATIVE_BATCH_JOBS':v} for n,v in {'zero':'0,0','overflow':'9223372036854775808,1','est-over':'0,9223372036854775808','field':'0,1,2','type':'A,1','negative':'-1,1','missing':''}.items()}}.items():run('raw-'+name,['cargo','build','--release','--locked','-j1'],name in ('positive','maximum'),src/'kernel',raw|changes)
run('host-build',['rustc','--edition=2021','--test','tools/scheduling_tests.rs','-o',out/'policy-tests'])
run('host-suite',[out/'policy-tests','--test-threads=1'])
pkg=out/'ordinary'; cap=out/'ordinary-first'
if not run('ordinary-build',pack+['--out',pkg]):
 if not run('ordinary-capture',['python3','tools/native_el0_capture.py',cap,pkg/'kernel.elf',pkg/'user.elf','examples/portability/native_startup_probe.c',(r/'products/revision').read_text().strip()]):
  run('ordinary-replay',['python3','tools/native_el0_replay.py',cap,hashlib.sha256((cap/'session.json').read_bytes()).hexdigest()])

