from pathlib import Path
import subprocess, os
r=Path.home()/'jnox342-25a4198'; src=r/'src'; out=r/'controls'
def grab(s,start,end): return s[s.index(start):s.index(end,s.index(start))]
runtime=(src/'kernel/src/native_batch.rs').read_text()
h=(src/'tools/scheduling_tests.rs').read_text().replace('../kernel/',str(src/'kernel')+'/')
import re
h=re.sub(r'#\[path = "(?!/)([^"]+)"\]',lambda m:'#[path = "'+str(src/'tools'/m[1])+'"]',h)
h+='\nstruct Runtime { arrivals:[u64;3], released:u64, sleepers:[Option<u64>;3] }\nconst COUNT:usize=3;\n'+grab(runtime,'fn next_event','fn step(')
h+='\nfn fail(_:u64)->! { panic!("checked fault") }\nfn offsets(epoch:u64, jobs:[(u64,u64);3])->[u64;3] { '+grab(runtime,'let arrivals = NATIVE_BATCH_JOBS.map','    unsafe {').replace('NATIVE_BATCH_JOBS','jobs')+' arrivals }\n'
h+='''
#[test] fn independent_adapter_order_and_overflow() {
 let mut r=Runtime {arrivals:[9,7,7],released:0,sleepers:[Some(7),None,None]};
 for expected in [(7,false,1),(7,false,2),(7,true,0),(9,false,0)] {
  let v=next_event(&r).unwrap();assert_eq!(v,expected);
  if v.1 {r.sleepers[v.2]=None} else {r.released|=1<<v.2}
 }
 assert_eq!(next_event(&r),None);
 assert_eq!(offsets(u64::MAX-3,[(0,1),(2,1),(3,1)])[2],u64::MAX);
 assert!(std::panic::catch_unwind(||offsets(u64::MAX-2,[(0,1),(2,1),(3,1)])).is_err());
}
#[test] fn independent_native_rejections_and_accounting(){
 use batch_policy::{NativeBatchScheduler as S,BatchPolicy as P,BatchError as E};
 let mut s=S::<3>::new(P::Hrrn,10);
 assert_eq!(s.release_due(20,10,3,1),Err(E::InvalidId));
 assert_eq!(s.release_due(20,10,0,0),Err(E::ZeroEstimate));
 s.release_due(20,10,0,1).unwrap();assert_eq!(s.release_due(20,10,0,1),Err(E::Duplicate));
 assert_eq!(s.decide(20),Ok(Some(0)));assert_eq!(s.eligible_wait(20,0),Some(10));
 s.charge(0,21,45).unwrap();assert_eq!(s.service(0),Some(24));assert_eq!(s.remaining(0),Some(1));
 s.suspend(45,0).unwrap();s.release_due(60,49,1,1).unwrap();
 s.wake_due(60,50,0).unwrap();assert_eq!(s.wake_due(60,50,0),Err(E::NotRunning));
 assert_eq!(s.eligible_wait(60,0),Some(20));assert_eq!(s.service(0),Some(24));assert_eq!(s.decide(60),Ok(Some(0)));
}
#[test] fn independent_linked_exact_controls(){
 use batch_policy::{BatchPolicy as P,BatchScheduler as S};
 let mut s=S::<2>::new(P::Srtf,0);s.release(0,0,5).unwrap();assert_eq!(s.decide(0),Ok(Some(0)));s.release(1,1,2).unwrap();assert_eq!(s.remaining(0),Some(4));assert_eq!(s.decide(1),Ok(Some(1)));
 let mut h=S::<3>::new(P::Hrrn,0);h.release(0,0,1).unwrap();h.decide(0).unwrap();h.release(0,1,10).unwrap();h.release(5,2,1).unwrap();h.complete(5,0).unwrap();assert_eq!(h.decide(5),Ok(Some(1)));
}
'''
(out/'independent.rs').write_text(h)
env=os.environ.copy();env['PATH']=str(Path.home()/'.cargo/bin')+':'+env['PATH']
with (out/'supp-host.log').open('w') as f:
 for c in [['rustc','--edition=2021','--test',out/'independent.rs','-o',out/'extra-tests'],[out/'extra-tests','independent_','--test-threads=1']]:
  subprocess.run(c,check=True,stdout=f,stderr=subprocess.STDOUT,env=env)

