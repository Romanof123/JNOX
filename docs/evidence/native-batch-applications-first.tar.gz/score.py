import json,re,hashlib,pathlib
r=pathlib.Path(__file__).resolve().parent; pro=r/'products'; summary={}
for f in sorted(pro.glob('first-*.replay.json')):
 name=f.name.split('.')[0]; d=pro/name; x=json.loads(f.read_bytes()); L=x['ledger']; es=L['events']; E=L['epoch']
 assert x['status']=='complete' and L['dropped']==0 and L['frequency']==62500000
 assert es[0]['dst']==3 and es[1]['src']==3 and es[1]['op']==es[1]['eoi']==30
 assert es[-1]['dst']==4
 sess=json.loads((d/'session.json').read_bytes())
 for nm,sha in sess['hashes'].items():assert hashlib.sha256((d/nm).read_bytes()).hexdigest()==sha
 ex=d/'exceptions.log'; detail={}
 if 'arrival-' in name or 'underestimate' in name:
  a=es[2]; assert a['releases']==2 and a['op']==a['eoi']==30 and a['due'] if 'due' in a else True
  assert a['releases']==2 and a['eoi']==a['op']==30 and a['src']==0 and a['src_pc']==0x400808
  st=a['states']; assert a['entry']>=E+6250000
  if 'underestimate' in name:assert st[0]['service']>1 and st[0]['remaining']==st[1]['remaining']==1 and a['dst']==0
  else:assert st[0]['remaining']>st[1]['remaining']==625000
  if 'srtf' in name:
   restored=es[3]; assert (a['src'],a['dst'],restored['src'],restored['dst'])==(0,1,1,0)
   for key in ['pc','sp','root','frame','pstate']:assert a['src_'+key]==restored['dst_'+key]
   assert a['src_root']!=a['dst_root'] and es[4]['segment']>0
  else:assert a['dst']==0 and es[3]['src']==0 and es[3]['dst']==1
  if ex.exists():
   q=ex.read_text(); qs=[int(v,16) for v in re.findall(r'Exception return .* to AArch64 EL0 PC (0x\w+)',q)]
   assert qs==[e['dst_pc'] for e in es[1:-1]]
   assert [int(v,16) for v in re.findall(r'with ELR (0x\w+)',q)]==[e['src_pc'] for e in es[1:]]
  detail=dict(delivery_tick=a['entry'],elapsed=a['entry']-E,rank=[v['remaining'] for v in st],interrupted_pc=hex(a['src_pc']))
 if 'aging-' in name:
  i=next(e for e in es if e['op']==1); t=i['decision']-E
  assert 9375000<=t<11718750 and t*625000>(t-9375000)*3125000
  assert i['dst']==(1 if 'hrrn' in name else 2)
  detail=dict(exit_tick_minus_epoch=t,cross_products=[t*625000,(t-9375000)*3125000])
 if 'tie-' in name:
  arrivals=next(e for e in es if e['releases']&6); assert arrivals['releases']&6==6
  assert [e['src'] for e in es if e['op']==1]==[0,1,2]; assert arrivals['dst']==0
  detail=dict(incoming=arrivals['src'],released=arrivals['releases'],handling_minus_epoch=arrivals['decision']-E)
 if 'solo' in name:assert es[1]['entry']>=E+3125000
 if 'lifecycle' in name:
  assert [(e['src'],e['dst']) for e in es[1:]]==[(3,0),(0,1),(1,0),(0,3),(3,0),(0,3),(3,1),(1,1),(1,4)]
  for slot in [0,1]:
   sl=next(e for e in es if e['op']==7 and e['src']==slot); w=next(e for e in es if e['wakes']==1<<slot); assert w['entry']>=sl['sleep_target'] and sl['states'][slot]['service']==w['states'][slot]['service']
 summary[name]=dict(products=x['products'],decisions=[[e[k] for k in ['seq','op','src','dst','releases','wakes','entry','decision','src_pc','dst_pc','src_sp','dst_sp','src_root','dst_root','src_frame','dst_frame','segment','transparent_ticks']] for e in es],epoch=E,detail=detail)
(r/'independent-replay.json').write_text(json.dumps(summary,indent=2))

