#!/bin/bash
set -ue
export PATH="$HOME/.cargo/bin:$PATH" PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
r="$HOME/jnox342-25a4198"; out="$r/compat"; mkdir "$out"; cd "$r/src"
export CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$r/compat-target" JNOX_BOARD=virt JNOX_PROFILE=batch
for mode in normal trace legacy legacy-trace; do for policy in sjf srtf hrrn; do
 d="$out/$mode-$policy"; mkdir "$d"; export JNOX_APP=batch-$policy
 unset JNOX_BATCH_WORKLOAD JNOX_BATCH_TRACE; case $mode in normal|trace) export JNOX_BATCH_WORKLOAD=telemetry;; esac; case $mode in trace|legacy-trace) export JNOX_BATCH_TRACE=1;; esac
 (cd kernel; cargo build --locked --release -j1) > "$d/build" 2>&1
 cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" "$d/kernel.elf"
 if [[ $mode == legacy* ]]; then
  if [[ $mode == legacy-trace ]]; then
   export JNOX_BATCH_CAPTURE_DIR="$d/qmp"; python3 tools/qemu_boot.py --kernel "$d/kernel.elf" --profile "$JNOX_APP-trace" --runs 1 --timeout 10 --qemu tools/batch_runtime_capture.py > "$d/host" 2>&1 && python3 tools/batch_runtime_observer.py "$JNOX_APP" "$d/kernel.elf" "$d/qmp" > "$d/replay" 2>&1 || echo FAIL >> "$d/host"
  else
   python3 tools/qemu_boot.py --kernel "$d/kernel.elf" --profile "$JNOX_APP" --runs 2 --timeout 10 --capture-dir "$d/qemu" > "$d/host" 2>&1 || echo FAIL >> "$d/host"
  fi
 else
  (cd "$d"; set +e; timeout 10s qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -accel tcg -smp 1 -m 128M -nographic -nic none -monitor none -serial file:uart.log -d int -D irq.log -kernel kernel.elf >host 2>&1; echo $? >exit)
 fi
done; done

