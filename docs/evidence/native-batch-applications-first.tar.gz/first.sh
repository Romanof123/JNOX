#!/bin/bash
set -eu
export PATH="$HOME/.cargo/bin:$PATH" PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
cd "$HOME/jnox342-25a4198/src"
out="$HOME/jnox342-25a4198/products"; mkdir "$out"; export out
git rev-parse HEAD > "$out/revision"; git ls-files --eol | cut -d' ' -f1 | sort | uniq -c > "$out/eol"
{ clang --version; ld.lld --version; rustc -Vv; cargo -V; qemu-system-aarch64 --version; sha256sum "$(which qemu-system-aarch64)" "$(which clang)" "$(which ld.lld)"; } > "$out/tools"
for app in batch urgent sleep_first sleep_last checksum; do
 src=examples/native-edf/$app.c; [[ $app != checksum ]] || src=examples/native-llf/checksum.c
 sh sdk/native-aarch64/build.sh "$src" "$out/$app.elf"
 sha256sum "$src" "$out/$app.elf" >> "$out/app-sha256"
 aarch64-linux-gnu-objdump -d "$out/$app.elf" > "$out/$app.dis"
done
sed -n '/^pack=(/,/^~~~/{/^~~~/!p;}' examples/native-batch/README.md > "$out/package.sh"
bash -ex "$out/package.sh" > "$out/package.log" 2>&1
for spec in arrival-sjf:plain arrival-sjf:traced arrival-srtf:plain arrival-srtf:traced arrival-hrrn:plain arrival-hrrn:traced aging-hrrn aging-sjf underestimate tie-sjf tie-srtf tie-hrrn lifecycle solo; do
 name=${spec%:*}; mode=${spec#*:}; flags=(); [[ "$mode" != plain ]] || flags=(--plain)
 src=batch; code=17; roles=batch,urgent
 case "$name" in aging*|tie*) roles=batch,urgent,checksum;; lifecycle) src=sleep_first; code=53; roles=sleep_first,sleep_last;; solo) src=urgent; code=43; roles=urgent;; esac
 pkg=$out/$name; cap=$out/first-${spec/:/-}
 set +e
 python3 tools/native_el0_capture.py "$cap" "$pkg/kernel.elf" "$pkg/user.elf" "examples/native-edf/$src.c" "$(cat "$out/revision")" --manifest "$pkg/manifest.json" --expect-exit "$code" "${flags[@]}" > "$cap.capture-log" 2>&1
 echo "$spec capture=$?" >> "$out/status"
 if [[ -f "$cap/session.json" ]]; then
 sha256sum "$cap/session.json" >> "$out/session-sha256"
 python3 tools/native_batch_replay.py "$pkg" "$cap" --session-sha256 "$(sha256sum "$cap/session.json" | cut -d' ' -f1)" --products "$roles" > "$cap.replay.json" 2>"$cap.replay.err"
 echo "$spec replay=$?" >> "$out/status"
 fi
 set -e
done
