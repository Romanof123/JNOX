pack=(python3 tools/build_native_el0.py)
a=(--elf "$out/batch.elf")
fixed=(--arg=--blocks --arg 32768)
b=(--peer-elf "$out/urgent.elf")
c=(--peer-elf "$out/checksum.elf")

for policy in sjf srtf hrrn; do
    "${pack[@]}" --out "$out/arrival-$policy" --policy "$policy" \
        "${a[@]}" "${fixed[@]}" --batch-job 0,18750000 "${b[@]}" --peer-batch-job 6250000,625000
    "${pack[@]}" --out "$out/tie-$policy" --policy "$policy" \
        "${a[@]}" --batch-job 0,1 "${b[@]}" --peer-batch-job 3125000,625000 \
        "${c[@]}" --peer-batch-job 3125000,625000
done
for policy in hrrn sjf; do
    "${pack[@]}" --out "$out/aging-$policy" --policy "$policy" \
        "${a[@]}" --batch-job 0,1 "${b[@]}" --peer-batch-job 0,3125000 \
        "${c[@]}" --peer-batch-job 9375000,625000
done
"${pack[@]}" --out "$out/underestimate" --policy srtf "${a[@]}" "${fixed[@]}" \
    --batch-job 0,1 "${b[@]}" --peer-batch-job 6250000,1
"${pack[@]}" --out "$out/lifecycle" --policy srtf --elf "$out/sleep_first.elf" \
    --batch-job 0,1 --peer-elf "$out/sleep_last.elf" --peer-batch-job 0,1
"${pack[@]}" --out "$out/solo" --policy sjf --elf "$out/urgent.elf" --batch-job 3125000,625000
