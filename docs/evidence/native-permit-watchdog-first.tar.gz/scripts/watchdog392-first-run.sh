set -eu
export PATH="$HOME/.cargo/bin:$PATH"
o=/mnt/d/codex/watchdog392-first-c3015b4
mkdir -p "$o"
cd /mnt/d/codex/jnox-watchdog-first
s=$(mktemp -d /tmp/first392.XXXXXX)
echo "$s" > "$o/source-root"
git -c safe.directory='*' archive c3015b4 | tar -x -C "$s"
cd "$s"
a=examples/native-safety-watchdog
exec > "$o/run.log" 2>&1
set -x
git --version; rustc -V; qemu-system-aarch64 --version
sh sdk/native-aarch64/build-rust.sh "$a/Cargo.toml" "$o/worker.elf"
for p in fifo rr; do
q=(); if [[ $p == rr ]]; then q=(--quantum-ticks 625000); fi
for t in healthy sleep-late compute-late controller-exit recover recover-live; do
k="$o/$p-$t"
python3 tools/build_native_el0.py --board virt --policy "$p" "${q[@]}" --out "$k" --elf "$o/worker.elf" --peer-elf "$o/worker.elf" --peer-elf "$o/worker.elf" --arg sender --arg "$t" --peer-arg controller --peer-arg "$t" --peer2-arg supervisor --peer2-arg "$t" --priority 6 --peer-priority 7 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel --safety-qualification --safety-watchdog > "$k.build.log" 2>&1 || continue
python3 tools/native_el0_capture.py "$o/capture-$p-$t" "$k/kernel.elf" "$o/worker.elf" "$a/src/main.rs" c3015b4f9316589e045feb73f0fb1d7aa90a78b5 --manifest "$k/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608 || true
done
done