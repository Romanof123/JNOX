set -eu
src=$(cat /mnt/d/codex/watchdog392-first-r1-c3015b4/source-root)
cd "$src"
export PATH="$HOME/.cargo/bin:$PATH"
o=/tmp/watchdog392-first-r2
mkdir -p "$o"
old=/mnt/d/codex/watchdog392-first-r1-c3015b4
while ! test -f "$old/capture-rr-recover-live/session.json"; do sleep 1; done
for p in fifo rr; do for t in healthy sleep-late compute-late controller-exit recover recover-live; do
k="$old/$p-$t"
python3 tools/native_el0_capture.py "$o/$p-$t" "$k/kernel.elf" "$old/worker.elf" examples/native-safety-watchdog/src/main.rs c3015b4f9316589e045feb73f0fb1d7aa90a78b5 --manifest "$k/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608 || true
mkdir -p /mnt/d/codex/watchdog392-first-ext4
cp -r "$o/$p-$t" /mnt/d/codex/watchdog392-first-ext4/
done; done