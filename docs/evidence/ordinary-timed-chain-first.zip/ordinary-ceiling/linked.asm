
/home/ywcho/jnox236-first/ordinary-ceiling/kernel.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000040200000 <_start>:
    40200000:	d5034fdf 	msr	daifset, #0xf
    40200004:	d5384240 	mrs	x0, currentel
    40200008:	f100101f 	cmp	x0, #0x4
    4020000c:	54000241 	b.ne	40200054 <_start+0x54>  // b.any
    40200010:	d50041bf 	msr	spsel, #0x1
    40200014:	58000260 	ldr	x0, 40200060 <_start+0x60>
    40200018:	9100001f 	mov	sp, x0
    4020001c:	d5381040 	mrs	x0, cpacr_el1
    40200020:	b26c0400 	orr	x0, x0, #0x300000
    40200024:	d5181040 	msr	cpacr_el1, x0
    40200028:	d5033fdf 	isb
    4020002c:	580001e0 	ldr	x0, 40200068 <_start+0x68>
    40200030:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    40200034:	f9000001 	str	x1, [x0]
    40200038:	580001c0 	ldr	x0, 40200070 <_start+0x70>
    4020003c:	580001e1 	ldr	x1, 40200078 <_start+0x78>
    40200040:	eb01001f 	cmp	x0, x1
    40200044:	54000062 	b.cs	40200050 <_start+0x50>  // b.hs, b.nlast
    40200048:	f800841f 	str	xzr, [x0], #8
    4020004c:	17fffffd 	b	40200040 <_start+0x40>
    40200050:	1400001c 	b	402000c0 <_ZN11jnox_kernel11kernel_main17ha0f1dd4d6a7d76bdE>
    40200054:	d503205f 	wfe
    40200058:	17ffffff 	b	40200054 <_start+0x54>
    4020005c:	00000000 	udf	#0
    40200060:	4021c270 	.word	0x4021c270
    40200064:	00000000 	.word	0x00000000
    40200068:	40205160 	.word	0x40205160
    4020006c:	00000000 	.word	0x00000000
    40200070:	40205160 	.word	0x40205160
    40200074:	00000000 	.word	0x00000000
    40200078:	40218268 	.word	0x40218268
    4020007c:	00000000 	.word	0x00000000

0000000040200080 <_RNvCsfLfy6EI15iL_7___rustc17rust_begin_unwind>:
    40200080:	d503205f 	wfe
    40200084:	17ffffff 	b	40200080 <_RNvCsfLfy6EI15iL_7___rustc17rust_begin_unwind>

0000000040200088 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E>:
    40200088:	b40001a1 	cbz	x1, 402000bc <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E+0x34>
    4020008c:	8b010008 	add	x8, x0, x1
    40200090:	52800309 	mov	w9, #0x18                  	// #24
    40200094:	72a12009 	movk	w9, #0x900, lsl #16
    40200098:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    4020009c:	3840140b 	ldrb	w11, [x0], #1
    402000a0:	b940012c 	ldr	w12, [x9]
    402000a4:	3628006c 	tbz	w12, #5, 402000b0 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E+0x28>
    402000a8:	d5033fdf 	isb
    402000ac:	17fffffd 	b	402000a0 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E+0x18>
    402000b0:	b900014b 	str	w11, [x10]
    402000b4:	eb08001f 	cmp	x0, x8
    402000b8:	54ffff21 	b.ne	4020009c <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E+0x14>  // b.any
    402000bc:	d65f03c0 	ret

00000000402000c0 <_ZN11jnox_kernel11kernel_main17ha0f1dd4d6a7d76bdE>:
    402000c0:	b0000028 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    402000c4:	f940b108 	ldr	x8, [x8, #352]
    402000c8:	b4000068 	cbz	x8, 402000d4 <_ZN11jnox_kernel11kernel_main17ha0f1dd4d6a7d76bdE+0x14>
    402000cc:	d503205f 	wfe
    402000d0:	17ffffff 	b	402000cc <_ZN11jnox_kernel11kernel_main17ha0f1dd4d6a7d76bdE+0xc>
    402000d4:	f81f0ffe 	str	x30, [sp, #-16]!
    402000d8:	52800608 	mov	w8, #0x30                  	// #48
    402000dc:	72a12008 	movk	w8, #0x900, lsl #16
    402000e0:	b900011f 	str	wzr, [x8]
    402000e4:	528001a9 	mov	w9, #0xd                   	// #13
    402000e8:	5280002a 	mov	w10, #0x1                   	// #1
    402000ec:	b81f4109 	stur	w9, [x8, #-12]
    402000f0:	b81f810a 	stur	w10, [x8, #-8]
    402000f4:	52800c09 	mov	w9, #0x60                  	// #96
    402000f8:	b81fc109 	stur	w9, [x8, #-4]
    402000fc:	52802029 	mov	w9, #0x101                 	// #257
    40200100:	b9000109 	str	w9, [x8]
    40200104:	d503201f 	nop
    40200108:	1001f800 	adr	x0, 40204008 <memset+0x154>
    4020010c:	52800361 	mov	w1, #0x1b                  	// #27
    40200110:	97ffffde 	bl	40200088 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E>
    40200114:	94000698 	bl	40201b74 <_ZN11jnox_kernel14ordinary_mutex3run17h2e8d428f4d32a81cE>

0000000040200118 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE>:
    40200118:	f81f0ffe 	str	x30, [sp, #-16]!
    4020011c:	f9401009 	ldr	x9, [x0, #32]
    40200120:	aa010128 	orr	x8, x9, x1
    40200124:	f1000d1f 	cmp	x8, #0x3
    40200128:	54000148 	b.hi	40200150 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x38>  // b.pmore
    4020012c:	aa1f03e8 	mov	x8, xzr
    40200130:	8b090c0a 	add	x10, x0, x9, lsl #3
    40200134:	d37df12b 	lsl	x11, x9, #3
    40200138:	eb08017f 	cmp	x11, x8
    4020013c:	540000e0 	b.eq	40200158 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x40>  // b.none
    40200140:	f868680c 	ldr	x12, [x0, x8]
    40200144:	91002108 	add	x8, x8, #0x8
    40200148:	eb01019f 	cmp	x12, x1
    4020014c:	54ffff61 	b.ne	40200138 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x20>  // b.any
    40200150:	2a1f03e8 	mov	w8, wzr
    40200154:	14000015 	b	402001a8 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x90>
    40200158:	b4000209 	cbz	x9, 40200198 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x80>
    4020015c:	d1000528 	sub	x8, x9, #0x1
    40200160:	f100153f 	cmp	x9, #0x5
    40200164:	54000302 	b.cs	402001c4 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0xac>  // b.hs, b.nlast
    40200168:	f1000d1f 	cmp	x8, #0x3
    4020016c:	54000240 	b.eq	402001b4 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x9c>  // b.none
    40200170:	aa0a03eb 	mov	x11, x10
    40200174:	f85f8d6c 	ldr	x12, [x11, #-8]!
    40200178:	f900014c 	str	x12, [x10]
    4020017c:	d1000508 	sub	x8, x8, #0x1
    40200180:	b100051f 	cmn	x8, #0x1
    40200184:	aa0b03ea 	mov	x10, x11
    40200188:	54fffec1 	b.ne	40200160 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x48>  // b.any
    4020018c:	f9401008 	ldr	x8, [x0, #32]
    40200190:	91000509 	add	x9, x8, #0x1
    40200194:	14000002 	b	4020019c <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x84>
    40200198:	52800029 	mov	w9, #0x1                   	// #1
    4020019c:	f9000001 	str	x1, [x0]
    402001a0:	52800028 	mov	w8, #0x1                   	// #1
    402001a4:	f9001009 	str	x9, [x0, #32]
    402001a8:	2a0803e0 	mov	w0, w8
    402001ac:	f84107fe 	ldr	x30, [sp], #16
    402001b0:	d65f03c0 	ret
    402001b4:	d503201f 	nop
    402001b8:	1001ff82 	adr	x2, 402041a8 <anon.c4e24dea056945e7185438d0e076311c.6.llvm.5430753883208388470>
    402001bc:	52800080 	mov	w0, #0x4                   	// #4
    402001c0:	14000004 	b	402001d0 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0xb8>
    402001c4:	d503201f 	nop
    402001c8:	1001fe42 	adr	x2, 40204190 <anon.c4e24dea056945e7185438d0e076311c.5.llvm.5430753883208388470>
    402001cc:	aa0803e0 	mov	x0, x8
    402001d0:	52800081 	mov	w1, #0x4                   	// #4
    402001d4:	94000c08 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

00000000402001d8 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE>:
    402001d8:	f81a0ffe 	str	x30, [sp, #-96]!
    402001dc:	a9016ffc 	stp	x28, x27, [sp, #16]
    402001e0:	a90267fa 	stp	x26, x25, [sp, #32]
    402001e4:	a9035ff8 	stp	x24, x23, [sp, #48]
    402001e8:	a90457f6 	stp	x22, x21, [sp, #64]
    402001ec:	a9054ff4 	stp	x20, x19, [sp, #80]
    402001f0:	f9401013 	ldr	x19, [x0, #32]
    402001f4:	f100167f 	cmp	x19, #0x5
    402001f8:	54000762 	b.cs	402002e4 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE+0x10c>  // b.hs, b.nlast
    402001fc:	b4000613 	cbz	x19, 402002bc <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE+0xe4>
    40200200:	aa0103f5 	mov	x21, x1
    40200204:	aa0003f4 	mov	x20, x0
    40200208:	2a1f03f9 	mov	w25, wzr
    4020020c:	aa1f03f7 	mov	x23, xzr
    40200210:	d37df278 	lsl	x24, x19, #3
    40200214:	910033fb 	add	x27, sp, #0xc
    40200218:	f8777a9c 	ldr	x28, [x20, x23, lsl #3]
    4020021c:	f1000f9f 	cmp	x28, #0x3
    40200220:	54000108 	b.hi	40200240 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE+0x68>  // b.pmore
    40200224:	aa1503e0 	mov	x0, x21
    40200228:	9400005a 	bl	40200390 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470>
    4020022c:	360000a0 	tbz	w0, #0, 40200240 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE+0x68>
    40200230:	d348fc08 	lsr	x8, x0, #8
    40200234:	b9000fe8 	str	w8, [sp, #12]
    40200238:	387c6b68 	ldrb	w8, [x27, x28]
    4020023c:	14000002 	b	40200244 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE+0x6c>
    40200240:	2a1f03e8 	mov	w8, wzr
    40200244:	12001d09 	and	w9, w8, #0xff
    40200248:	6b3a013f 	cmp	w9, w26, uxtb
    4020024c:	1a9f87e9 	cset	w9, ls  // ls = plast
    40200250:	6a09033f 	tst	w25, w9
    40200254:	9a9712d6 	csel	x22, x22, x23, ne  // ne = any
    40200258:	1a88135a 	csel	w26, w26, w8, ne  // ne = any
    4020025c:	f1002318 	subs	x24, x24, #0x8
    40200260:	910006f7 	add	x23, x23, #0x1
    40200264:	52800039 	mov	w25, #0x1                   	// #1
    40200268:	54fffd81 	b.ne	40200218 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE+0x40>  // b.any
    4020026c:	f1000edf 	cmp	x22, #0x3
    40200270:	54000508 	b.hi	40200310 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE+0x138>  // b.pmore
    40200274:	f8767a81 	ldr	x1, [x20, x22, lsl #3]
    40200278:	d1000668 	sub	x8, x19, #0x1
    4020027c:	f9001288 	str	x8, [x20, #32]
    40200280:	eb0802df 	cmp	x22, x8
    40200284:	54000202 	b.cs	402002c4 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE+0xec>  // b.hs, b.nlast
    40200288:	8b160e88 	add	x8, x20, x22, lsl #3
    4020028c:	91002109 	add	x9, x8, #0x8
    40200290:	910006c8 	add	x8, x22, #0x1
    40200294:	52800020 	mov	w0, #0x1                   	// #1
    40200298:	f100111f 	cmp	x8, #0x4
    4020029c:	54000300 	b.eq	402002fc <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE+0x124>  // b.none
    402002a0:	f940012a 	ldr	x10, [x9]
    402002a4:	f81f812a 	stur	x10, [x9, #-8]
    402002a8:	91002129 	add	x9, x9, #0x8
    402002ac:	91000508 	add	x8, x8, #0x1
    402002b0:	eb08027f 	cmp	x19, x8
    402002b4:	54ffff21 	b.ne	40200298 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE+0xc0>  // b.any
    402002b8:	14000004 	b	402002c8 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE+0xf0>
    402002bc:	aa1f03e0 	mov	x0, xzr
    402002c0:	14000002 	b	402002c8 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE+0xf0>
    402002c4:	52800020 	mov	w0, #0x1                   	// #1
    402002c8:	a9454ff4 	ldp	x20, x19, [sp, #80]
    402002cc:	a94457f6 	ldp	x22, x21, [sp, #64]
    402002d0:	a9435ff8 	ldp	x24, x23, [sp, #48]
    402002d4:	a94267fa 	ldp	x26, x25, [sp, #32]
    402002d8:	a9416ffc 	ldp	x28, x27, [sp, #16]
    402002dc:	f84607fe 	ldr	x30, [sp], #96
    402002e0:	d65f03c0 	ret
    402002e4:	d503201f 	nop
    402002e8:	1001f303 	adr	x3, 40204148 <anon.c4e24dea056945e7185438d0e076311c.2.llvm.5430753883208388470>
    402002ec:	aa1f03e0 	mov	x0, xzr
    402002f0:	aa1303e1 	mov	x1, x19
    402002f4:	52800082 	mov	w2, #0x4                   	// #4
    402002f8:	94000dbe 	bl	402039f0 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>
    402002fc:	d503201f 	nop
    40200300:	1001f3c2 	adr	x2, 40204178 <anon.c4e24dea056945e7185438d0e076311c.4.llvm.5430753883208388470>
    40200304:	aa0803e0 	mov	x0, x8
    40200308:	52800081 	mov	w1, #0x4                   	// #4
    4020030c:	94000bba 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40200310:	d503201f 	nop
    40200314:	1001f262 	adr	x2, 40204160 <anon.c4e24dea056945e7185438d0e076311c.3.llvm.5430753883208388470>
    40200318:	aa1603e0 	mov	x0, x22
    4020031c:	17fffffb 	b	40200308 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE+0x130>

0000000040200320 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE>:
    40200320:	f81f0ffe 	str	x30, [sp, #-16]!
    40200324:	aa0003e8 	mov	x8, x0
    40200328:	f9401000 	ldr	x0, [x0, #32]
    4020032c:	aa010009 	orr	x9, x0, x1
    40200330:	f1000d3f 	cmp	x9, #0x3
    40200334:	54000108 	b.hi	40200354 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE+0x34>  // b.pmore
    40200338:	d37df009 	lsl	x9, x0, #3
    4020033c:	aa0803ea 	mov	x10, x8
    40200340:	b40000e9 	cbz	x9, 4020035c <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE+0x3c>
    40200344:	f840854b 	ldr	x11, [x10], #8
    40200348:	d1002129 	sub	x9, x9, #0x8
    4020034c:	eb01017f 	cmp	x11, x1
    40200350:	54ffff81 	b.ne	40200340 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE+0x20>  // b.any
    40200354:	2a1f03e0 	mov	w0, wzr
    40200358:	14000008 	b	40200378 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE+0x58>
    4020035c:	f100101f 	cmp	x0, #0x4
    40200360:	54000102 	b.cs	40200380 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE+0x60>  // b.hs, b.nlast
    40200364:	f8207901 	str	x1, [x8, x0, lsl #3]
    40200368:	f9401109 	ldr	x9, [x8, #32]
    4020036c:	91000529 	add	x9, x9, #0x1
    40200370:	f9001109 	str	x9, [x8, #32]
    40200374:	52800020 	mov	w0, #0x1                   	// #1
    40200378:	f84107fe 	ldr	x30, [sp], #16
    4020037c:	d65f03c0 	ret
    40200380:	d503201f 	nop
    40200384:	1001f2a2 	adr	x2, 402041d8 <anon.c4e24dea056945e7185438d0e076311c.8.llvm.5430753883208388470>
    40200388:	52800081 	mov	w1, #0x4                   	// #4
    4020038c:	94000b9a 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040200390 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470>:
    40200390:	d10103ff 	sub	sp, sp, #0x40
    40200394:	f9001bfe 	str	x30, [sp, #48]
    40200398:	aa1f03e9 	mov	x9, xzr
    4020039c:	9100800a 	add	x10, x0, #0x20
    402003a0:	9102800b 	add	x11, x0, #0xa0
    402003a4:	9103e00c 	add	x12, x0, #0xf8
    402003a8:	9100e00d 	add	x13, x0, #0x38
    402003ac:	52a0002e 	mov	w14, #0x10000               	// #65536
    402003b0:	910073ef 	add	x15, sp, #0x1c
    402003b4:	aa1f03f2 	mov	x18, xzr
    402003b8:	8b091550 	add	x16, x10, x9, lsl #5
    402003bc:	aa0d03f1 	mov	x17, x13
    402003c0:	52800201 	mov	w1, #0x10                  	// #16
    402003c4:	8b120208 	add	x8, x16, x18
    402003c8:	91004252 	add	x18, x18, #0x10
    402003cc:	f9400102 	ldr	x2, [x8]
    402003d0:	f100045f 	cmp	x2, #0x1
    402003d4:	540000e1 	b.ne	402003f0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x60>  // b.any
    402003d8:	f9400508 	ldr	x8, [x8, #8]
    402003dc:	f100051f 	cmp	x8, #0x1
    402003e0:	54001a48 	b.hi	40200728 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x398>  // b.pmore
    402003e4:	8b080c08 	add	x8, x0, x8, lsl #3
    402003e8:	39439102 	ldrb	w2, [x8, #228]
    402003ec:	370000e2 	tbnz	w2, #0, 40200408 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x78>
    402003f0:	d1004021 	sub	x1, x1, #0x10
    402003f4:	91004231 	add	x17, x17, #0x10
    402003f8:	f100825f 	cmp	x18, #0x20
    402003fc:	54fffe41 	b.ne	402003c4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x34>  // b.any
    40200400:	2a1f03f1 	mov	w17, wzr
    40200404:	14000016 	b	4020045c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0xcc>
    40200408:	39439510 	ldrb	w16, [x8, #229]
    4020040c:	f100825f 	cmp	x18, #0x20
    40200410:	54000240 	b.eq	40200458 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0xc8>  // b.none
    40200414:	d344fc32 	lsr	x18, x1, #4
    40200418:	f85f8228 	ldur	x8, [x17, #-8]
    4020041c:	f100051f 	cmp	x8, #0x1
    40200420:	54000161 	b.ne	4020044c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0xbc>  // b.any
    40200424:	f9400228 	ldr	x8, [x17]
    40200428:	f100051f 	cmp	x8, #0x1
    4020042c:	540017e8 	b.hi	40200728 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x398>  // b.pmore
    40200430:	8b080c08 	add	x8, x0, x8, lsl #3
    40200434:	39439101 	ldrb	w1, [x8, #228]
    40200438:	360000a1 	tbz	w1, #0, 4020044c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0xbc>
    4020043c:	39439508 	ldrb	w8, [x8, #229]
    40200440:	12001e10 	and	w16, w16, #0xff
    40200444:	6b08021f 	cmp	w16, w8
    40200448:	1a888210 	csel	w16, w16, w8, hi  // hi = pmore
    4020044c:	f1000652 	subs	x18, x18, #0x1
    40200450:	91004231 	add	x17, x17, #0x10
    40200454:	54fffe21 	b.ne	40200418 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x88>  // b.any
    40200458:	52800031 	mov	w17, #0x1                   	// #1
    4020045c:	8b091168 	add	x8, x11, x9, lsl #4
    40200460:	f9400112 	ldr	x18, [x8]
    40200464:	f100065f 	cmp	x18, #0x1
    40200468:	540000e1 	b.ne	40200484 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0xf4>  // b.any
    4020046c:	f9400508 	ldr	x8, [x8, #8]
    40200470:	f100051f 	cmp	x8, #0x1
    40200474:	54001648 	b.hi	4020073c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x3ac>  // b.pmore
    40200478:	8b080c12 	add	x18, x0, x8, lsl #3
    4020047c:	39439252 	ldrb	w18, [x18, #228]
    40200480:	36000092 	tbz	w18, #0, 40200490 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x100>
    40200484:	38696988 	ldrb	w8, [x12, x9]
    40200488:	d3607d08 	lsl	x8, x8, #32
    4020048c:	1400000b 	b	402004b8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x128>
    40200490:	8b081008 	add	x8, x0, x8, lsl #4
    40200494:	b9400112 	ldr	w18, [x8]
    40200498:	f9400508 	ldr	x8, [x8, #8]
    4020049c:	38696981 	ldrb	w1, [x12, x9]
    402004a0:	53081d08 	lsl	w8, w8, #24
    402004a4:	7100025f 	cmp	w18, #0x0
    402004a8:	9a9f1108 	csel	x8, x8, xzr, ne  // ne = any
    402004ac:	aa018108 	orr	x8, x8, x1, lsl #32
    402004b0:	9a9f11d2 	csel	x18, x14, xzr, ne  // ne = any
    402004b4:	aa120108 	orr	x8, x8, x18
    402004b8:	12001e10 	and	w16, w16, #0xff
    402004bc:	2a1103f1 	mov	w17, w17
    402004c0:	aa102230 	orr	x16, x17, x16, lsl #8
    402004c4:	8b090931 	add	x17, x9, x9, lsl #2
    402004c8:	8b1101f1 	add	x17, x15, x17
    402004cc:	8b080208 	add	x8, x16, x8
    402004d0:	39000228 	strb	w8, [x17]
    402004d4:	d358fd10 	lsr	x16, x8, #24
    402004d8:	39000e30 	strb	w16, [x17, #3]
    402004dc:	d350fd10 	lsr	x16, x8, #16
    402004e0:	39000a30 	strb	w16, [x17, #2]
    402004e4:	d348fd10 	lsr	x16, x8, #8
    402004e8:	d360fd08 	lsr	x8, x8, #32
    402004ec:	39000630 	strb	w16, [x17, #1]
    402004f0:	39001228 	strb	w8, [x17, #4]
    402004f4:	91000529 	add	x9, x9, #0x1
    402004f8:	910081ad 	add	x13, x13, #0x20
    402004fc:	f100113f 	cmp	x9, #0x4
    40200500:	54fff5a1 	b.ne	402003b4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x24>  // b.any
    40200504:	3940b7e8 	ldrb	w8, [sp, #45]
    40200508:	3940b3e9 	ldrb	w9, [sp, #44]
    4020050c:	3940bbea 	ldrb	w10, [sp, #46]
    40200510:	394087eb 	ldrb	w11, [sp, #33]
    40200514:	394083ec 	ldrb	w12, [sp, #32]
    40200518:	2a082128 	orr	w8, w9, w8, lsl #8
    4020051c:	53103d49 	lsl	w9, w10, #16
    40200520:	39408bea 	ldrb	w10, [sp, #34]
    40200524:	2a0b218b 	orr	w11, w12, w11, lsl #8
    40200528:	53103d4a 	lsl	w10, w10, #16
    4020052c:	3940bfec 	ldrb	w12, [sp, #47]
    40200530:	2a0c6129 	orr	w9, w9, w12, lsl #24
    40200534:	39408fec 	ldrb	w12, [sp, #35]
    40200538:	2a0c614a 	orr	w10, w10, w12, lsl #24
    4020053c:	2a080128 	orr	w8, w9, w8
    40200540:	2a0b0149 	orr	w9, w10, w11
    40200544:	394077ea 	ldrb	w10, [sp, #29]
    40200548:	b9001be8 	str	w8, [sp, #24]
    4020054c:	394073e8 	ldrb	w8, [sp, #28]
    40200550:	aa0a2108 	orr	x8, x8, x10, lsl #8
    40200554:	39407bea 	ldrb	w10, [sp, #30]
    40200558:	d370bd4a 	lsl	x10, x10, #16
    4020055c:	39407feb 	ldrb	w11, [sp, #31]
    40200560:	aa0b614a 	orr	x10, x10, x11, lsl #24
    40200564:	aa080148 	orr	x8, x10, x8
    40200568:	aa098108 	orr	x8, x8, x9, lsl #32
    4020056c:	394097e9 	ldrb	w9, [sp, #37]
    40200570:	394093ea 	ldrb	w10, [sp, #36]
    40200574:	aa092149 	orr	x9, x10, x9, lsl #8
    40200578:	39409bea 	ldrb	w10, [sp, #38]
    4020057c:	d370bd4a 	lsl	x10, x10, #16
    40200580:	39409feb 	ldrb	w11, [sp, #39]
    40200584:	aa0b614a 	orr	x10, x10, x11, lsl #24
    40200588:	aa090149 	orr	x9, x10, x9
    4020058c:	910073ea 	add	x10, sp, #0x1c
    40200590:	9100214a 	add	x10, x10, #0x8
    40200594:	38404d4b 	ldrb	w11, [x10, #4]!
    40200598:	3940a7ec 	ldrb	w12, [sp, #41]
    4020059c:	2a0c216b 	orr	w11, w11, w12, lsl #8
    402005a0:	3940094c 	ldrb	w12, [x10, #2]
    402005a4:	53103d8c 	lsl	w12, w12, #16
    402005a8:	39400d4a 	ldrb	w10, [x10, #3]
    402005ac:	2a0a618a 	orr	w10, w12, w10, lsl #24
    402005b0:	2a0b014a 	orr	w10, w10, w11
    402005b4:	aa0a8129 	orr	x9, x9, x10, lsl #32
    402005b8:	a900a7e8 	stp	x8, x9, [sp, #8]
    402005bc:	29077fff 	stp	wzr, wzr, [sp, #56]
    402005c0:	910023e8 	add	x8, sp, #0x8
    402005c4:	b27f0108 	orr	x8, x8, #0x2
    402005c8:	9100e3e9 	add	x9, sp, #0x38
    402005cc:	b9001fff 	str	wzr, [sp, #28]
    402005d0:	5280028a 	mov	w10, #0x14                  	// #20
    402005d4:	9100f3eb 	add	x11, sp, #0x3c
    402005d8:	3940090c 	ldrb	w12, [x8, #2]
    402005dc:	385ff10d 	ldurb	w13, [x8, #-1]
    402005e0:	385fe10e 	ldurb	w14, [x8, #-2]
    402005e4:	6b0c01bf 	cmp	w13, w12
    402005e8:	1a8c81ad 	csel	w13, w13, w12, hi  // hi = pmore
    402005ec:	710001df 	cmp	w14, #0x0
    402005f0:	1a8c11ac 	csel	w12, w13, w12, ne  // ne = any
    402005f4:	3900012c 	strb	w12, [x9]
    402005f8:	3940010c 	ldrb	w12, [x8]
    402005fc:	7100059f 	cmp	w12, #0x1
    40200600:	540000e1 	b.ne	4020061c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x28c>  // b.any
    40200604:	3940050c 	ldrb	w12, [x8, #1]
    40200608:	f1000d9f 	cmp	x12, #0x3
    4020060c:	540007c8 	b.hi	40200704 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x374>  // b.pmore
    40200610:	386c696d 	ldrb	w13, [x11, x12]
    40200614:	110005ad 	add	w13, w13, #0x1
    40200618:	382c696d 	strb	w13, [x11, x12]
    4020061c:	91001508 	add	x8, x8, #0x5
    40200620:	91000529 	add	x9, x9, #0x1
    40200624:	f100154a 	subs	x10, x10, #0x5
    40200628:	54fffd81 	b.ne	402005d8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x248>  // b.any
    4020062c:	aa1f03e0 	mov	x0, xzr
    40200630:	aa1f03e8 	mov	x8, xzr
    40200634:	9100f3e9 	add	x9, sp, #0x3c
    40200638:	910073ea 	add	x10, sp, #0x1c
    4020063c:	3868692b 	ldrb	w11, [x9, x8]
    40200640:	350000ab 	cbnz	w11, 40200654 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x2c4>
    40200644:	f100101f 	cmp	x0, #0x4
    40200648:	54000902 	b.cs	40200768 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x3d8>  // b.hs, b.nlast
    4020064c:	38206948 	strb	w8, [x10, x0]
    40200650:	91000400 	add	x0, x0, #0x1
    40200654:	91000508 	add	x8, x8, #0x1
    40200658:	f100111f 	cmp	x8, #0x4
    4020065c:	54ffff01 	b.ne	4020063c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x2ac>  // b.any
    40200660:	b4000560 	cbz	x0, 4020070c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x37c>
    40200664:	aa1f03ea 	mov	x10, xzr
    40200668:	910073eb 	add	x11, sp, #0x1c
    4020066c:	910023ec 	add	x12, sp, #0x8
    40200670:	9100e3ed 	add	x13, sp, #0x38
    40200674:	9100f3ee 	add	x14, sp, #0x3c
    40200678:	f100115f 	cmp	x10, #0x4
    4020067c:	540006e0 	b.eq	40200758 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x3c8>  // b.none
    40200680:	386a6969 	ldrb	w9, [x11, x10]
    40200684:	f100113f 	cmp	x9, #0x4
    40200688:	54000602 	b.cs	40200748 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x3b8>  // b.hs, b.nlast
    4020068c:	8b090928 	add	x8, x9, x9, lsl #2
    40200690:	8b080188 	add	x8, x12, x8
    40200694:	3940090f 	ldrb	w15, [x8, #2]
    40200698:	3600024f 	tbz	w15, #0, 402006e0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x350>
    4020069c:	39400d08 	ldrb	w8, [x8, #3]
    402006a0:	f100111f 	cmp	x8, #0x4
    402006a4:	54000682 	b.cs	40200774 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x3e4>  // b.hs, b.nlast
    402006a8:	386869af 	ldrb	w15, [x13, x8]
    402006ac:	386969a9 	ldrb	w9, [x13, x9]
    402006b0:	386869d0 	ldrb	w16, [x14, x8]
    402006b4:	6b0f013f 	cmp	w9, w15
    402006b8:	51000610 	sub	w16, w16, #0x1
    402006bc:	1a8f8129 	csel	w9, w9, w15, hi  // hi = pmore
    402006c0:	382869a9 	strb	w9, [x13, x8]
    402006c4:	72001e1f 	tst	w16, #0xff
    402006c8:	382869d0 	strb	w16, [x14, x8]
    402006cc:	540000a1 	b.ne	402006e0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x350>  // b.any
    402006d0:	f1000c1f 	cmp	x0, #0x3
    402006d4:	54000588 	b.hi	40200784 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x3f4>  // b.pmore
    402006d8:	38206968 	strb	w8, [x11, x0]
    402006dc:	91000400 	add	x0, x0, #0x1
    402006e0:	9100054a 	add	x10, x10, #0x1
    402006e4:	eb00015f 	cmp	x10, x0
    402006e8:	54fffc83 	b.cc	40200678 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x2e8>  // b.lo, b.ul, b.last
    402006ec:	f100115f 	cmp	x10, #0x4
    402006f0:	1a9f17e8 	cset	w8, eq  // eq = none
    402006f4:	b9403be9 	ldr	w9, [sp, #56]
    402006f8:	d378dd29 	lsl	x9, x9, #8
    402006fc:	9a9f0129 	csel	x9, x9, xzr, eq  // eq = none
    40200700:	14000005 	b	40200714 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x384>
    40200704:	aa1f03e0 	mov	x0, xzr
    40200708:	14000005 	b	4020071c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x38c>
    4020070c:	2a1f03e8 	mov	w8, wzr
    40200710:	aa1f03e9 	mov	x9, xzr
    40200714:	2a0803e8 	mov	w8, w8
    40200718:	aa080120 	orr	x0, x9, x8
    4020071c:	f9401bfe 	ldr	x30, [sp, #48]
    40200720:	910103ff 	add	sp, sp, #0x40
    40200724:	d65f03c0 	ret
    40200728:	d503201f 	nop
    4020072c:	1001d622 	adr	x2, 402041f0 <anon.c4e24dea056945e7185438d0e076311c.8.llvm.5430753883208388470+0x18>
    40200730:	aa0803e0 	mov	x0, x8
    40200734:	52800041 	mov	w1, #0x2                   	// #2
    40200738:	94000aaf 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    4020073c:	d503201f 	nop
    40200740:	1001d642 	adr	x2, 40204208 <anon.c4e24dea056945e7185438d0e076311c.8.llvm.5430753883208388470+0x30>
    40200744:	17fffffb 	b	40200730 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x3a0>
    40200748:	d503201f 	nop
    4020074c:	1001de22 	adr	x2, 40204310 <anon.c4e24dea056945e7185438d0e076311c.16.llvm.5430753883208388470+0x90>
    40200750:	aa0903e0 	mov	x0, x9
    40200754:	1400000e 	b	4020078c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x3fc>
    40200758:	d503201f 	nop
    4020075c:	1001dce2 	adr	x2, 402042f8 <anon.c4e24dea056945e7185438d0e076311c.16.llvm.5430753883208388470+0x78>
    40200760:	52800080 	mov	w0, #0x4                   	// #4
    40200764:	1400000a 	b	4020078c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x3fc>
    40200768:	d503201f 	nop
    4020076c:	1001df62 	adr	x2, 40204358 <anon.c4e24dea056945e7185438d0e076311c.16.llvm.5430753883208388470+0xd8>
    40200770:	14000007 	b	4020078c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x3fc>
    40200774:	d503201f 	nop
    40200778:	1001dd82 	adr	x2, 40204328 <anon.c4e24dea056945e7185438d0e076311c.16.llvm.5430753883208388470+0xa8>
    4020077c:	aa0803e0 	mov	x0, x8
    40200780:	14000003 	b	4020078c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470+0x3fc>
    40200784:	d503201f 	nop
    40200788:	1001ddc2 	adr	x2, 40204340 <anon.c4e24dea056945e7185438d0e076311c.16.llvm.5430753883208388470+0xc0>
    4020078c:	52800081 	mov	w1, #0x4                   	// #4
    40200790:	94000a99 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040200794 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E>:
    40200794:	f81f0ffe 	str	x30, [sp, #-16]!
    40200798:	f1000c3f 	cmp	x1, #0x3
    4020079c:	540003e8 	b.hi	40200818 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E+0x84>  // b.pmore
    402007a0:	8b010008 	add	x8, x0, x1
    402007a4:	3943f108 	ldrb	w8, [x8, #252]
    402007a8:	f100111f 	cmp	x8, #0x4
    402007ac:	540003e2 	b.cs	40200828 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E+0x94>  // b.hs, b.nlast
    402007b0:	8b081008 	add	x8, x0, x8, lsl #4
    402007b4:	f900511f 	str	xzr, [x8, #160]
    402007b8:	f940780a 	ldr	x10, [x0, #240]
    402007bc:	d1000548 	sub	x8, x10, #0x1
    402007c0:	f9007808 	str	x8, [x0, #240]
    402007c4:	eb08003f 	cmp	x1, x8
    402007c8:	540001a2 	b.cs	402007fc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E+0x68>  // b.hs, b.nlast
    402007cc:	8b000028 	add	x8, x1, x0
    402007d0:	9103f509 	add	x9, x8, #0xfd
    402007d4:	aa2103e8 	mvn	x8, x1
    402007d8:	cb0a03ea 	neg	x10, x10
    402007dc:	b100111f 	cmn	x8, #0x4
    402007e0:	54000120 	b.eq	40200804 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E+0x70>  // b.none
    402007e4:	3940012b 	ldrb	w11, [x9]
    402007e8:	381ff12b 	sturb	w11, [x9, #-1]
    402007ec:	91000529 	add	x9, x9, #0x1
    402007f0:	d1000508 	sub	x8, x8, #0x1
    402007f4:	eb08015f 	cmp	x10, x8
    402007f8:	54ffff21 	b.ne	402007dc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E+0x48>  // b.any
    402007fc:	f84107fe 	ldr	x30, [sp], #16
    40200800:	d65f03c0 	ret
    40200804:	cb0803e0 	neg	x0, x8
    40200808:	d503201f 	nop
    4020080c:	1001d222 	adr	x2, 40204250 <anon.c4e24dea056945e7185438d0e076311c.8.llvm.5430753883208388470+0x78>
    40200810:	52800081 	mov	w1, #0x4                   	// #4
    40200814:	94000a78 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40200818:	d503201f 	nop
    4020081c:	1001d022 	adr	x2, 40204220 <anon.c4e24dea056945e7185438d0e076311c.8.llvm.5430753883208388470+0x48>
    40200820:	aa0103e0 	mov	x0, x1
    40200824:	17fffffb 	b	40200810 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E+0x7c>
    40200828:	d503201f 	nop
    4020082c:	1001d062 	adr	x2, 40204238 <anon.c4e24dea056945e7185438d0e076311c.8.llvm.5430753883208388470+0x60>
    40200830:	aa0803e0 	mov	x0, x8
    40200834:	17fffff7 	b	40200810 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E+0x7c>

0000000040200838 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.5430753883208388470>:
    40200838:	f81f0ffe 	str	x30, [sp, #-16]!
    4020083c:	91028009 	add	x9, x0, #0xa0
    40200840:	528000aa 	mov	w10, #0x5                   	// #5
    40200844:	f100054a 	subs	x10, x10, #0x1
    40200848:	54000240 	b.eq	40200890 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.5430753883208388470+0x58>  // b.none
    4020084c:	eb01005f 	cmp	x2, x1
    40200850:	54000200 	b.eq	40200890 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.5430753883208388470+0x58>  // b.none
    40200854:	f1000c5f 	cmp	x2, #0x3
    40200858:	54000228 	b.hi	4020089c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.5430753883208388470+0x64>  // b.pmore
    4020085c:	8b021128 	add	x8, x9, x2, lsl #4
    40200860:	f940010b 	ldr	x11, [x8]
    40200864:	f100057f 	cmp	x11, #0x1
    40200868:	54000101 	b.ne	40200888 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.5430753883208388470+0x50>  // b.any
    4020086c:	f9400508 	ldr	x8, [x8, #8]
    40200870:	f100091f 	cmp	x8, #0x2
    40200874:	54000202 	b.cs	402008b4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.5430753883208388470+0x7c>  // b.hs, b.nlast
    40200878:	8b081008 	add	x8, x0, x8, lsl #4
    4020087c:	b940010b 	ldr	w11, [x8]
    40200880:	f9400502 	ldr	x2, [x8, #8]
    40200884:	3707fe0b 	tbnz	w11, #0, 40200844 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.5430753883208388470+0xc>
    40200888:	2a1f03e0 	mov	w0, wzr
    4020088c:	14000002 	b	40200894 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.5430753883208388470+0x5c>
    40200890:	52800020 	mov	w0, #0x1                   	// #1
    40200894:	f84107fe 	ldr	x30, [sp], #16
    40200898:	d65f03c0 	ret
    4020089c:	d503201f 	nop
    402008a0:	1001ce48 	adr	x8, 40204268 <anon.c4e24dea056945e7185438d0e076311c.15.llvm.5430753883208388470>
    402008a4:	aa0203e0 	mov	x0, x2
    402008a8:	52800081 	mov	w1, #0x4                   	// #4
    402008ac:	aa0803e2 	mov	x2, x8
    402008b0:	94000a51 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    402008b4:	d503201f 	nop
    402008b8:	1001ce42 	adr	x2, 40204280 <anon.c4e24dea056945e7185438d0e076311c.16.llvm.5430753883208388470>
    402008bc:	aa0803e0 	mov	x0, x8
    402008c0:	52800041 	mov	w1, #0x2                   	// #2
    402008c4:	94000a4c 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

00000000402008c8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE>:
    402008c8:	f1000c3f 	cmp	x1, #0x3
    402008cc:	54000069 	b.ls	402008d8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x10>  // b.plast
    402008d0:	52800040 	mov	w0, #0x2                   	// #2
    402008d4:	d65f03c0 	ret
    402008d8:	a9bd5ffe 	stp	x30, x23, [sp, #-48]!
    402008dc:	a90157f6 	stp	x22, x21, [sp, #16]
    402008e0:	a9024ff4 	stp	x20, x19, [sp, #32]
    402008e4:	aa0203f3 	mov	x19, x2
    402008e8:	aa0103f4 	mov	x20, x1
    402008ec:	aa0003f5 	mov	x21, x0
    402008f0:	8b011408 	add	x8, x0, x1, lsl #5
    402008f4:	91008108 	add	x8, x8, #0x20
    402008f8:	52800409 	mov	w9, #0x20                  	// #32
    402008fc:	f940010a 	ldr	x10, [x8]
    40200900:	b40000aa 	cbz	x10, 40200914 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x4c>
    40200904:	91004108 	add	x8, x8, #0x10
    40200908:	f1004129 	subs	x9, x9, #0x10
    4020090c:	54ffff81 	b.ne	402008fc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x34>  // b.any
    40200910:	1400000a 	b	40200938 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x70>
    40200914:	f100067f 	cmp	x19, #0x1
    40200918:	54000108 	b.hi	40200938 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x70>  // b.pmore
    4020091c:	8b130ea9 	add	x9, x21, x19, lsl #3
    40200920:	b940e129 	ldr	w9, [x9, #224]
    40200924:	1ad42529 	lsr	w9, w9, w20
    40200928:	36000089 	tbz	w9, #0, 40200938 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x70>
    4020092c:	8b1412b6 	add	x22, x21, x20, lsl #4
    40200930:	f84a0ec9 	ldr	x9, [x22, #160]!
    40200934:	b40000c9 	cbz	x9, 4020094c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x84>
    40200938:	52800040 	mov	w0, #0x2                   	// #2
    4020093c:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40200940:	a94157f6 	ldp	x22, x21, [sp, #16]
    40200944:	a8c35ffe 	ldp	x30, x23, [sp], #48
    40200948:	d65f03c0 	ret
    4020094c:	8b1312a9 	add	x9, x21, x19, lsl #4
    40200950:	f940012a 	ldr	x10, [x9]
    40200954:	f100055f 	cmp	x10, #0x1
    40200958:	54000201 	b.ne	40200998 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0xd0>  // b.any
    4020095c:	f9407ab7 	ldr	x23, [x21, #240]
    40200960:	f1000eff 	cmp	x23, #0x3
    40200964:	54fffea8 	b.hi	40200938 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x70>  // b.pmore
    40200968:	f9400522 	ldr	x2, [x9, #8]
    4020096c:	aa1503e0 	mov	x0, x21
    40200970:	aa1403e1 	mov	x1, x20
    40200974:	97ffffb1 	bl	40200838 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.5430753883208388470>
    40200978:	3707fe00 	tbnz	w0, #0, 40200938 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x70>
    4020097c:	8b1702a8 	add	x8, x21, x23
    40200980:	3903f114 	strb	w20, [x8, #252]
    40200984:	910006e8 	add	x8, x23, #0x1
    40200988:	f9007aa8 	str	x8, [x21, #240]
    4020098c:	52800020 	mov	w0, #0x1                   	// #1
    40200990:	a9004ec0 	stp	x0, x19, [x22]
    40200994:	17ffffea 	b	4020093c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x74>
    40200998:	2a1f03e0 	mov	w0, wzr
    4020099c:	5280002a 	mov	w10, #0x1                   	// #1
    402009a0:	a9004d0a 	stp	x10, x19, [x8]
    402009a4:	a900512a 	stp	x10, x20, [x9]
    402009a8:	17ffffe5 	b	4020093c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x74>

00000000402009ac <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E>:
    402009ac:	f81b0ffe 	str	x30, [sp, #-80]!
    402009b0:	a90167fa 	stp	x26, x25, [sp, #16]
    402009b4:	a9025ff8 	stp	x24, x23, [sp, #32]
    402009b8:	a90357f6 	stp	x22, x21, [sp, #48]
    402009bc:	a9044ff4 	stp	x20, x19, [sp, #64]
    402009c0:	f100045f 	cmp	x2, #0x1
    402009c4:	540001c8 	b.hi	402009fc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x50>  // b.pmore
    402009c8:	aa0203f4 	mov	x20, x2
    402009cc:	aa0003f3 	mov	x19, x0
    402009d0:	8b021017 	add	x23, x0, x2, lsl #4
    402009d4:	a94026e8 	ldp	x8, x9, [x23]
    402009d8:	f100011f 	cmp	x8, #0x0
    402009dc:	fa411120 	ccmp	x9, x1, #0x0, ne  // ne = any
    402009e0:	540000e1 	b.ne	402009fc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x50>  // b.any
    402009e4:	f1000c3f 	cmp	x1, #0x3
    402009e8:	54000be8 	b.hi	40200b64 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x1b8>  // b.pmore
    402009ec:	91028279 	add	x25, x19, #0xa0
    402009f0:	d37cec28 	lsl	x8, x1, #4
    402009f4:	f8686b28 	ldr	x8, [x25, x8]
    402009f8:	b4000148 	cbz	x8, 40200a20 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x74>
    402009fc:	52800056 	mov	w22, #0x2                   	// #2
    40200a00:	aa1603e0 	mov	x0, x22
    40200a04:	aa1503e1 	mov	x1, x21
    40200a08:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40200a0c:	a94357f6 	ldp	x22, x21, [sp, #48]
    40200a10:	a9425ff8 	ldp	x24, x23, [sp, #32]
    40200a14:	a94167fa 	ldp	x26, x25, [sp, #16]
    40200a18:	f84507fe 	ldr	x30, [sp], #80
    40200a1c:	d65f03c0 	ret
    40200a20:	9100827a 	add	x26, x19, #0x20
    40200a24:	8b011668 	add	x8, x19, x1, lsl #5
    40200a28:	91012118 	add	x24, x8, #0x48
    40200a2c:	928003e8 	mov	x8, #0xffffffffffffffe0    	// #-32
    40200a30:	52800056 	mov	w22, #0x2                   	// #2
    40200a34:	b4fffe68 	cbz	x8, 40200a00 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x54>
    40200a38:	f85e8309 	ldur	x9, [x24, #-24]
    40200a3c:	d1004318 	sub	x24, x24, #0x10
    40200a40:	91004108 	add	x8, x8, #0x10
    40200a44:	b4ffff89 	cbz	x9, 40200a34 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x88>
    40200a48:	f85f8308 	ldur	x8, [x24, #-8]
    40200a4c:	b4fffd88 	cbz	x8, 402009fc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x50>
    40200a50:	f9400308 	ldr	x8, [x24]
    40200a54:	eb14011f 	cmp	x8, x20
    40200a58:	54fffd21 	b.ne	402009fc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x50>  // b.any
    40200a5c:	aa1303e0 	mov	x0, x19
    40200a60:	97fffe4c 	bl	40200390 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470>
    40200a64:	3607fcc0 	tbz	w0, #0, 402009fc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x50>
    40200a68:	d348fc08 	lsr	x8, x0, #8
    40200a6c:	b9000fe8 	str	w8, [sp, #12]
    40200a70:	f9407a68 	ldr	x8, [x19, #240]
    40200a74:	f100151f 	cmp	x8, #0x5
    40200a78:	540006a2 	b.cs	40200b4c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x1a0>  // b.hs, b.nlast
    40200a7c:	b4000568 	cbz	x8, 40200b28 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x17c>
    40200a80:	aa1f03eb 	mov	x11, xzr
    40200a84:	aa1f03e9 	mov	x9, xzr
    40200a88:	910033ea 	add	x10, sp, #0xc
    40200a8c:	8b09026c 	add	x12, x19, x9
    40200a90:	3943f180 	ldrb	w0, [x12, #252]
    40200a94:	f100101f 	cmp	x0, #0x4
    40200a98:	540006e2 	b.cs	40200b74 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x1c8>  // b.hs, b.nlast
    40200a9c:	8b00132c 	add	x12, x25, x0, lsl #4
    40200aa0:	f940018d 	ldr	x13, [x12]
    40200aa4:	f10005bf 	cmp	x13, #0x1
    40200aa8:	54000241 	b.ne	40200af0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x144>  // b.any
    40200aac:	f940058c 	ldr	x12, [x12, #8]
    40200ab0:	eb14019f 	cmp	x12, x20
    40200ab4:	540001e1 	b.ne	40200af0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x144>  // b.any
    40200ab8:	f100057f 	cmp	x11, #0x1
    40200abc:	54000141 	b.ne	40200ae4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x138>  // b.any
    40200ac0:	f10012bf 	cmp	x21, #0x4
    40200ac4:	54000602 	b.cs	40200b84 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x1d8>  // b.hs, b.nlast
    40200ac8:	3860694b 	ldrb	w11, [x10, x0]
    40200acc:	3875694c 	ldrb	w12, [x10, x21]
    40200ad0:	6b0c017f 	cmp	w11, w12
    40200ad4:	9a818121 	csel	x1, x9, x1, hi  // hi = pmore
    40200ad8:	9a958015 	csel	x21, x0, x21, hi  // hi = pmore
    40200adc:	5280002b 	mov	w11, #0x1                   	// #1
    40200ae0:	14000004 	b	40200af0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x144>
    40200ae4:	5280002b 	mov	w11, #0x1                   	// #1
    40200ae8:	aa0903e1 	mov	x1, x9
    40200aec:	aa0003f5 	mov	x21, x0
    40200af0:	91000529 	add	x9, x9, #0x1
    40200af4:	eb09011f 	cmp	x8, x9
    40200af8:	54fffca1 	b.ne	40200a8c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0xe0>  // b.any
    40200afc:	f100057f 	cmp	x11, #0x1
    40200b00:	54000141 	b.ne	40200b28 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x17c>  // b.any
    40200b04:	8b151748 	add	x8, x26, x21, lsl #5
    40200b08:	52800409 	mov	w9, #0x20                  	// #32
    40200b0c:	52800056 	mov	w22, #0x2                   	// #2
    40200b10:	f940010a 	ldr	x10, [x8]
    40200b14:	b400012a 	cbz	x10, 40200b38 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x18c>
    40200b18:	91004108 	add	x8, x8, #0x10
    40200b1c:	f1004129 	subs	x9, x9, #0x10
    40200b20:	54ffff81 	b.ne	40200b10 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x164>  // b.any
    40200b24:	17ffffb7 	b	40200a00 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x54>
    40200b28:	aa1f03f6 	mov	x22, xzr
    40200b2c:	f81f831f 	stur	xzr, [x24, #-8]
    40200b30:	a90056f6 	stp	x22, x21, [x23]
    40200b34:	17ffffb3 	b	40200a00 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x54>
    40200b38:	52800036 	mov	w22, #0x1                   	// #1
    40200b3c:	a9005116 	stp	x22, x20, [x8]
    40200b40:	aa1303e0 	mov	x0, x19
    40200b44:	97ffff14 	bl	40200794 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E>
    40200b48:	17fffff9 	b	40200b2c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x180>
    40200b4c:	d503201f 	nop
    40200b50:	1001bb03 	adr	x3, 402042b0 <anon.c4e24dea056945e7185438d0e076311c.16.llvm.5430753883208388470+0x30>
    40200b54:	aa1f03e0 	mov	x0, xzr
    40200b58:	aa0803e1 	mov	x1, x8
    40200b5c:	52800082 	mov	w2, #0x4                   	// #4
    40200b60:	94000ba4 	bl	402039f0 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>
    40200b64:	d503201f 	nop
    40200b68:	1001b982 	adr	x2, 40204298 <anon.c4e24dea056945e7185438d0e076311c.16.llvm.5430753883208388470+0x18>
    40200b6c:	aa0103e0 	mov	x0, x1
    40200b70:	14000003 	b	40200b7c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x1d0>
    40200b74:	d503201f 	nop
    40200b78:	1001ba82 	adr	x2, 402042c8 <anon.c4e24dea056945e7185438d0e076311c.16.llvm.5430753883208388470+0x48>
    40200b7c:	52800081 	mov	w1, #0x4                   	// #4
    40200b80:	9400099d 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40200b84:	d503201f 	nop
    40200b88:	1001bac2 	adr	x2, 402042e0 <anon.c4e24dea056945e7185438d0e076311c.16.llvm.5430753883208388470+0x60>
    40200b8c:	aa1503e0 	mov	x0, x21
    40200b90:	17fffffb 	b	40200b7c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x1d0>

0000000040200b94 <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E>:
    40200b94:	d103c3ff 	sub	sp, sp, #0xf0
    40200b98:	f9006bfe 	str	x30, [sp, #208]
    40200b9c:	a90e4ff4 	stp	x20, x19, [sp, #224]
    40200ba0:	aa0803f3 	mov	x19, x8
    40200ba4:	528000ab 	mov	w11, #0x5                   	// #5
    40200ba8:	34000100 	cbz	w0, 40200bc8 <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E+0x34>
    40200bac:	390017eb 	strb	w11, [sp, #5]
    40200bb0:	52800128 	mov	w8, #0x9                   	// #9
    40200bb4:	528000aa 	mov	w10, #0x5                   	// #5
    40200bb8:	390037e8 	strb	w8, [sp, #13]
    40200bbc:	52800029 	mov	w9, #0x1                   	// #1
    40200bc0:	5280006b 	mov	w11, #0x3                   	// #3
    40200bc4:	14000003 	b	40200bd0 <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E+0x3c>
    40200bc8:	2a1f03e9 	mov	w9, wzr
    40200bcc:	5280002a 	mov	w10, #0x1                   	// #1
    40200bd0:	aa1f03e8 	mov	x8, xzr
    40200bd4:	b90003eb 	str	w11, [sp]
    40200bd8:	5280a054 	mov	w20, #0x502                 	// #1282
    40200bdc:	72a00134 	movk	w20, #0x9, lsl #16
    40200be0:	390013e9 	strb	w9, [sp, #4]
    40200be4:	b9000bea 	str	w10, [sp, #8]
    40200be8:	390033e9 	strb	w9, [sp, #12]
    40200bec:	910003e9 	mov	x9, sp
    40200bf0:	910373ea 	add	x10, sp, #0xdc
    40200bf4:	b900dff4 	str	w20, [sp, #220]
    40200bf8:	8b08012c 	add	x12, x9, x8
    40200bfc:	b940018b 	ldr	w11, [x12]
    40200c00:	5100056d 	sub	w13, w11, #0x1
    40200c04:	71003dbf 	cmp	w13, #0xf
    40200c08:	54000642 	b.cs	40200cd0 <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E+0x13c>  // b.hs, b.nlast
    40200c0c:	3940118d 	ldrb	w13, [x12, #4]
    40200c10:	710005bf 	cmp	w13, #0x1
    40200c14:	540001a1 	b.ne	40200c48 <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E+0xb4>  // b.any
    40200c18:	aa1f03ed 	mov	x13, xzr
    40200c1c:	3940158c 	ldrb	w12, [x12, #5]
    40200c20:	f10011bf 	cmp	x13, #0x4
    40200c24:	54000120 	b.eq	40200c48 <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E+0xb4>  // b.none
    40200c28:	aa0d03ee 	mov	x14, x13
    40200c2c:	910005ad 	add	x13, x13, #0x1
    40200c30:	1ace256f 	lsr	w15, w11, w14
    40200c34:	3607ff6f 	tbz	w15, #0, 40200c20 <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E+0x8c>
    40200c38:	386e694e 	ldrb	w14, [x10, x14]
    40200c3c:	6b0c01df 	cmp	w14, w12
    40200c40:	54ffff09 	b.ls	40200c20 <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E+0x8c>  // b.plast
    40200c44:	14000023 	b	40200cd0 <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E+0x13c>
    40200c48:	91002108 	add	x8, x8, #0x8
    40200c4c:	f100411f 	cmp	x8, #0x10
    40200c50:	54fffd41 	b.ne	40200bf8 <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E+0x64>  // b.any
    40200c54:	aa1f03e8 	mov	x8, xzr
    40200c58:	910043e9 	add	x9, sp, #0x10
    40200c5c:	8b08012a 	add	x10, x9, x8
    40200c60:	f900015f 	str	xzr, [x10]
    40200c64:	f900095f 	str	xzr, [x10, #16]
    40200c68:	91008108 	add	x8, x8, #0x20
    40200c6c:	f102011f 	cmp	x8, #0x80
    40200c70:	54ffff61 	b.ne	40200c5c <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E+0xc8>  // b.any
    40200c74:	aa1f03e8 	mov	x8, xzr
    40200c78:	910243e9 	add	x9, sp, #0x90
    40200c7c:	f828693f 	str	xzr, [x9, x8]
    40200c80:	91004108 	add	x8, x8, #0x10
    40200c84:	f101011f 	cmp	x8, #0x40
    40200c88:	54ffffa1 	b.ne	40200c7c <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E+0xe8>  // b.any
    40200c8c:	294027e8 	ldp	w8, w9, [sp]
    40200c90:	291c2668 	stp	w8, w9, [x19, #224]
    40200c94:	294127e8 	ldp	w8, w9, [sp, #8]
    40200c98:	291d2668 	stp	w8, w9, [x19, #232]
    40200c9c:	f900027f 	str	xzr, [x19]
    40200ca0:	f9000a7f 	str	xzr, [x19, #16]
    40200ca4:	91008260 	add	x0, x19, #0x20
    40200ca8:	910043e1 	add	x1, sp, #0x10
    40200cac:	52801002 	mov	w2, #0x80                  	// #128
    40200cb0:	94000bfe 	bl	40203ca8 <memcpy>
    40200cb4:	91028260 	add	x0, x19, #0xa0
    40200cb8:	910243e1 	add	x1, sp, #0x90
    40200cbc:	52800802 	mov	w2, #0x40                  	// #64
    40200cc0:	94000bfa 	bl	40203ca8 <memcpy>
    40200cc4:	f9007a7f 	str	xzr, [x19, #240]
    40200cc8:	291f7e74 	stp	w20, wzr, [x19, #248]
    40200ccc:	14000003 	b	40200cd8 <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E+0x144>
    40200cd0:	52800048 	mov	w8, #0x2                   	// #2
    40200cd4:	f9000268 	str	x8, [x19]
    40200cd8:	a94e4ff4 	ldp	x20, x19, [sp, #224]
    40200cdc:	f9406bfe 	ldr	x30, [sp, #208]
    40200ce0:	9103c3ff 	add	sp, sp, #0xf0
    40200ce4:	d65f03c0 	ret

0000000040200ce8 <_ZN11jnox_kernel7context14init_timer_irq17hd7766ccbde3e84bbE>:
    40200ce8:	d503201f 	nop
    40200cec:	100018a8 	adr	x8, 40201000 <sched_vectors>
    40200cf0:	d518c008 	msr	vbar_el1, x8
    40200cf4:	d51be23f 	msr	cntp_ctl_el0, xzr
    40200cf8:	d5033fdf 	isb
    40200cfc:	52a10008 	mov	w8, #0x8000000             	// #134217728
    40200d00:	b900011f 	str	wzr, [x8]
    40200d04:	52a10029 	mov	w9, #0x8010000             	// #134283264
    40200d08:	b900013f 	str	wzr, [x9]
    40200d0c:	5280100a 	mov	w10, #0x80                  	// #128
    40200d10:	72a1000a 	movk	w10, #0x800, lsl #16
    40200d14:	b940014b 	ldr	w11, [x10]
    40200d18:	1201796b 	and	w11, w11, #0xbfffffff
    40200d1c:	b900014b 	str	w11, [x10]
    40200d20:	5280100b 	mov	w11, #0x80                  	// #128
    40200d24:	390e794b 	strb	w11, [x10, #926]
    40200d28:	52a8000b 	mov	w11, #0x40000000            	// #1073741824
    40200d2c:	b902014b 	str	w11, [x10, #512]
    40200d30:	b900814b 	str	w11, [x10, #128]
    40200d34:	5280008a 	mov	w10, #0x4                   	// #4
    40200d38:	72a1002a 	movk	w10, #0x801, lsl #16
    40200d3c:	52801feb 	mov	w11, #0xff                  	// #255
    40200d40:	b900014b 	str	w11, [x10]
    40200d44:	5280002a 	mov	w10, #0x1                   	// #1
    40200d48:	b900010a 	str	w10, [x8]
    40200d4c:	b900012a 	str	w10, [x9]
    40200d50:	d5033f9f 	dsb	sy
    40200d54:	d5033fdf 	isb
    40200d58:	d65f03c0 	ret
	...

0000000040201000 <sched_vectors>:
    40201000:	14000200 00000000 00000000 00000000     ................
	...
    40201080:	140001e0 00000000 00000000 00000000     ................
	...
    40201100:	140001c0 00000000 00000000 00000000     ................
	...
    40201180:	140001a0 00000000 00000000 00000000     ................
	...
    40201200:	140001b6 00000000 00000000 00000000     ................
	...
    40201280:	14000161 00000000 00000000 00000000     a...............
	...
    40201300:	14000140 00000000 00000000 00000000     @...............
	...
    40201380:	14000120 00000000 00000000 00000000      ...............
	...
    40201400:	14000100 00000000 00000000 00000000     ................
	...
    40201480:	140000e0 00000000 00000000 00000000     ................
	...
    40201500:	140000c0 00000000 00000000 00000000     ................
	...
    40201580:	140000a0 00000000 00000000 00000000     ................
	...
    40201600:	14000080 00000000 00000000 00000000     ................
	...
    40201680:	14000060 00000000 00000000 00000000     `...............
	...
    40201700:	14000040 00000000 00000000 00000000     @...............
	...
    40201780:	14000020 00000000 00000000 00000000      ...............
	...
    40201800:	140000aa d10d03ff f90027e9 d5033fdf     .........'...?..
    40201810:	d53be029 f9009fe9 f94027e9 a90007e0     ).;......'@.....
    40201820:	a9010fe2 a90217e4 a9031fe6 a90427e8     .............'..
    40201830:	a9052fea a90637ec a9073fee a90847f0     ./...7...?...G..
    40201840:	a9094ff2 a90a57f4 a90b5ff6 a90c67f8     .O...W..._...g..
    40201850:	a90d6ffa a90e77fc f9007bfe ad0a07e0     .o...w...{......
    40201860:	ad0b0fe2 ad0c17e4 ad0d1fe6 ad0e27e8     .............'..
    40201870:	ad0f2fea ad1037ec ad113fee ad1247f0     ./...7...?...G..
    40201880:	ad134ff2 ad1457f4 ad155ff6 ad1667f8     .O...W..._...g..
    40201890:	ad176ffa ad1877fc ad197ffe d5384029     .o...w......)@8.
    402018a0:	d538400a a90fabe9 d53b4409 d53b442a     .@8......D;.*D;.
    402018b0:	a910abe9 d538d089 d538410a a911abe9     ......8..A8.....
    402018c0:	d53bd049 d53bd06a a912abe9 910003e0     I.;.j.;.........
    402018d0:	94000459 14000036 d10d03ff f90027e9     Y...6........'..
    402018e0:	d5033fdf d53be029 f9009fe9 f94027e9     .?..).;......'@.
    402018f0:	a90007e0 a9010fe2 a90217e4 a9031fe6     ................
    40201900:	a90427e8 a9052fea a90637ec a9073fee     .'.../...7...?..
    40201910:	a90847f0 a9094ff2 a90a57f4 a90b5ff6     .G...O...W..._..
    40201920:	a90c67f8 a90d6ffa a90e77fc f9007bfe     .g...o...w...{..
    40201930:	ad0a07e0 ad0b0fe2 ad0c17e4 ad0d1fe6     ................
    40201940:	ad0e27e8 ad0f2fea ad1037ec ad113fee     .'.../...7...?..
    40201950:	ad1247f0 ad134ff2 ad1457f4 ad155ff6     .G...O...W..._..
    40201960:	ad1667f8 ad176ffa ad1877fc ad197ffe     .g...o...w......
    40201970:	d5384029 d538400a a90fabe9 d53b4409     )@8..@8......D;.
    40201980:	d53b442a a910abe9 d538d089 d538410a     *D;.......8..A8.
    40201990:	a911abe9 d53bd049 d53bd06a a912abe9     ....I.;.j.;.....
    402019a0:	910003e0 940002f1 14000001              ............

00000000402019ac <sched_start_frame>:
    402019ac:	9100001f 	mov	sp, x0
    402019b0:	a94fabe9 	ldp	x9, x10, [sp, #248]
    402019b4:	d5184029 	msr	elr_el1, x9
    402019b8:	d518400a 	msr	spsr_el1, x10
    402019bc:	a950abe9 	ldp	x9, x10, [sp, #264]
    402019c0:	d51b4409 	msr	fpcr, x9
    402019c4:	d51b442a 	msr	fpsr, x10
    402019c8:	a951abe9 	ldp	x9, x10, [sp, #280]
    402019cc:	d518d089 	msr	tpidr_el1, x9
    402019d0:	d518410a 	msr	sp_el0, x10
    402019d4:	a952abe9 	ldp	x9, x10, [sp, #296]
    402019d8:	d51bd049 	msr	tpidr_el0, x9
    402019dc:	d51bd06a 	msr	tpidrro_el0, x10
    402019e0:	ad4a07e0 	ldp	q0, q1, [sp, #320]
    402019e4:	ad4b0fe2 	ldp	q2, q3, [sp, #352]
    402019e8:	ad4c17e4 	ldp	q4, q5, [sp, #384]
    402019ec:	ad4d1fe6 	ldp	q6, q7, [sp, #416]
    402019f0:	ad4e27e8 	ldp	q8, q9, [sp, #448]
    402019f4:	ad4f2fea 	ldp	q10, q11, [sp, #480]
    402019f8:	ad5037ec 	ldp	q12, q13, [sp, #512]
    402019fc:	ad513fee 	ldp	q14, q15, [sp, #544]
    40201a00:	ad5247f0 	ldp	q16, q17, [sp, #576]
    40201a04:	ad534ff2 	ldp	q18, q19, [sp, #608]
    40201a08:	ad5457f4 	ldp	q20, q21, [sp, #640]
    40201a0c:	ad555ff6 	ldp	q22, q23, [sp, #672]
    40201a10:	ad5667f8 	ldp	q24, q25, [sp, #704]
    40201a14:	ad576ffa 	ldp	q26, q27, [sp, #736]
    40201a18:	ad5877fc 	ldp	q28, q29, [sp, #768]
    40201a1c:	ad597ffe 	ldp	q30, q31, [sp, #800]
    40201a20:	d503201f 	nop
    40201a24:	100b11e9 	adr	x9, 40217c60 <jnox_ap_returns>
    40201a28:	f940012a 	ldr	x10, [x9]
    40201a2c:	f101015f 	cmp	x10, #0x40
    40201a30:	54ffee82 	b.cs	40201800 <sched_vectors+0x800>  // b.hs, b.nlast
    40201a34:	9100054b 	add	x11, x10, #0x1
    40201a38:	f800852b 	str	x11, [x9], #8
    40201a3c:	d280030b 	mov	x11, #0x18                  	// #24
    40201a40:	9b0b2549 	madd	x9, x10, x11, x9
    40201a44:	910003ea 	mov	x10, sp
    40201a48:	d538402b 	mrs	x11, elr_el1
    40201a4c:	a9002d2a 	stp	x10, x11, [x9]
    40201a50:	d5033fdf 	isb
    40201a54:	d53be02a 	mrs	x10, cntpct_el0
    40201a58:	f900092a 	str	x10, [x9, #16]
    40201a5c:	a94007e0 	ldp	x0, x1, [sp]
    40201a60:	a9410fe2 	ldp	x2, x3, [sp, #16]
    40201a64:	a94217e4 	ldp	x4, x5, [sp, #32]
    40201a68:	a9431fe6 	ldp	x6, x7, [sp, #48]
    40201a6c:	a94427e8 	ldp	x8, x9, [sp, #64]
    40201a70:	a9452fea 	ldp	x10, x11, [sp, #80]
    40201a74:	a94637ec 	ldp	x12, x13, [sp, #96]
    40201a78:	a9473fee 	ldp	x14, x15, [sp, #112]
    40201a7c:	a94847f0 	ldp	x16, x17, [sp, #128]
    40201a80:	a9494ff2 	ldp	x18, x19, [sp, #144]
    40201a84:	a94a57f4 	ldp	x20, x21, [sp, #160]
    40201a88:	a94b5ff6 	ldp	x22, x23, [sp, #176]
    40201a8c:	a94c67f8 	ldp	x24, x25, [sp, #192]
    40201a90:	a94d6ffa 	ldp	x26, x27, [sp, #208]
    40201a94:	a94e77fc 	ldp	x28, x29, [sp, #224]
    40201a98:	f9407bfe 	ldr	x30, [sp, #240]
    40201a9c:	910d03ff 	add	sp, sp, #0x340
    40201aa0:	d5033f5f 	clrex
    40201aa4:	d69f03e0 	eret

0000000040201aa8 <_ZN11jnox_kernel14ordinary_mutex10unexpected17h38482129df987011E>:
    40201aa8:	f81f0ffe 	str	x30, [sp, #-16]!
    40201aac:	52800220 	mov	w0, #0x11                  	// #17
    40201ab0:	940000df 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

0000000040201ab4 <_ZN11jnox_kernel14ordinary_mutex3low17hba8ab34c8ee04c89E>:
    40201ab4:	d10103ff 	sub	sp, sp, #0x40
    40201ab8:	a90257fe 	stp	x30, x21, [sp, #32]
    40201abc:	a9034ff4 	stp	x20, x19, [sp, #48]
    40201ac0:	52800033 	mov	w19, #0x1                   	// #1
    40201ac4:	52800020 	mov	w0, #0x1                   	// #1
    40201ac8:	aa1f03e1 	mov	x1, xzr
    40201acc:	9400029f 	bl	40202548 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>
    40201ad0:	52800020 	mov	w0, #0x1                   	// #1
    40201ad4:	52800021 	mov	w1, #0x1                   	// #1
    40201ad8:	9400029c 	bl	40202548 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>
    40201adc:	d5033fdf 	isb
    40201ae0:	d53be028 	mrs	x8, cntpct_el0
    40201ae4:	d503201f 	nop
    40201ae8:	1001b794 	adr	x20, 402051d8 <_ZN11jnox_kernel14ordinary_mutex5TIMES17he770985d80da3796E>
    40201aec:	f9000288 	str	x8, [x20]
    40201af0:	910023e8 	add	x8, sp, #0x8
    40201af4:	94000468 	bl	40202c94 <mutex_batch_compute>
    40201af8:	d503201f 	nop
    40201afc:	1001b435 	adr	x21, 40205180 <_ZN11jnox_kernel14ordinary_mutex5BATCH17h6ddfd88359c843a2E>
    40201b00:	a940a7e8 	ldp	x8, x9, [sp, #8]
    40201b04:	f90006a8 	str	x8, [x21, #8]
    40201b08:	f9000aa9 	str	x9, [x21, #16]
    40201b0c:	f90002b3 	str	x19, [x21]
    40201b10:	d5033fdf 	isb
    40201b14:	d53be028 	mrs	x8, cntpct_el0
    40201b18:	f9000688 	str	x8, [x20, #8]
    40201b1c:	52800040 	mov	w0, #0x2                   	// #2
    40201b20:	52800021 	mov	w1, #0x1                   	// #1
    40201b24:	94000289 	bl	40202548 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>
    40201b28:	d503201f 	nop
    40201b2c:	1001b7a8 	adr	x8, 40205220 <_ZN11jnox_kernel14ordinary_mutex6CHUNKS17h3cec01e2eeeb4508E.0>
    40201b30:	f94002a9 	ldr	x9, [x21]
    40201b34:	c8dffd08 	ldar	x8, [x8]
    40201b38:	f90007e9 	str	x9, [sp, #8]
    40201b3c:	f9000fe8 	str	x8, [sp, #24]
    40201b40:	d503201f 	nop
    40201b44:	1001b168 	adr	x8, 40205170 <_ZN11jnox_kernel14ordinary_mutex5AUDIT17hadb49dc2f312a40eE>
    40201b48:	f94007e9 	ldr	x9, [sp, #8]
    40201b4c:	f9000109 	str	x9, [x8]
    40201b50:	f9400fe9 	ldr	x9, [sp, #24]
    40201b54:	f9000509 	str	x9, [x8, #8]
    40201b58:	d5033fdf 	isb
    40201b5c:	d53be028 	mrs	x8, cntpct_el0
    40201b60:	f9000a88 	str	x8, [x20, #16]
    40201b64:	52800040 	mov	w0, #0x2                   	// #2
    40201b68:	aa1f03e1 	mov	x1, xzr
    40201b6c:	94000277 	bl	40202548 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>
    40201b70:	9400004b 	bl	40201c9c <_ZN11jnox_kernel14ordinary_mutex4exit17h88ed5b88944c971aE>

0000000040201b74 <_ZN11jnox_kernel14ordinary_mutex3run17h2e8d428f4d32a81cE>:
    40201b74:	f81d0ffd 	str	x29, [sp, #-48]!
    40201b78:	a90157fe 	stp	x30, x21, [sp, #16]
    40201b7c:	a9024ff4 	stp	x20, x19, [sp, #32]
    40201b80:	d10983ff 	sub	sp, sp, #0x260
    40201b84:	97fffc59 	bl	40200ce8 <_ZN11jnox_kernel7context14init_timer_irq17hd7766ccbde3e84bbE>
    40201b88:	d53be014 	mrs	x20, cntfrq_el0
    40201b8c:	910583e8 	add	x8, sp, #0x160
    40201b90:	52800020 	mov	w0, #0x1                   	// #1
    40201b94:	97fffc00 	bl	40200b94 <_ZN11jnox_kernel23ordinary_mutex_manifest5locks17h2514eab813c18d04E>
    40201b98:	f940b3e8 	ldr	x8, [sp, #352]
    40201b9c:	f100091f 	cmp	x8, #0x2
    40201ba0:	54000061 	b.ne	40201bac <_ZN11jnox_kernel14ordinary_mutex3run17h2e8d428f4d32a81cE+0x38>  // b.any
    40201ba4:	52800020 	mov	w0, #0x1                   	// #1
    40201ba8:	940000a1 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40201bac:	910003f3 	mov	x19, sp
    40201bb0:	910583f5 	add	x21, sp, #0x160
    40201bb4:	910003e0 	mov	x0, sp
    40201bb8:	910583e1 	add	x1, sp, #0x160
    40201bbc:	52802002 	mov	w2, #0x100                 	// #256
    40201bc0:	9400083a 	bl	40203ca8 <memcpy>
    40201bc4:	91040260 	add	x0, x19, #0x100
    40201bc8:	2a1f03e1 	mov	w1, wzr
    40201bcc:	52800902 	mov	w2, #0x48                  	// #72
    40201bd0:	940008b9 	bl	40203eb4 <memset>
    40201bd4:	aa1f03e9 	mov	x9, xzr
    40201bd8:	b9015bff 	str	wzr, [sp, #344]
    40201bdc:	5280006a 	mov	w10, #0x3                   	// #3
    40201be0:	390573ff 	strb	wzr, [sp, #348]
    40201be4:	910042a8 	add	x8, x21, #0x10
    40201be8:	a914d3ea 	stp	x10, x20, [sp, #328]
    40201bec:	d503201f 	nop
    40201bf0:	10fff62a 	adr	x10, 40201ab4 <_ZN11jnox_kernel14ordinary_mutex3low17hba8ab34c8ee04c89E>
    40201bf4:	d503201f 	nop
    40201bf8:	100027ab 	adr	x11, 402020ec <_ZN11jnox_kernel14ordinary_mutex6medium17h477bcb7179dbf5cbE>
    40201bfc:	a9172fea 	stp	x10, x11, [sp, #368]
    40201c00:	d503201f 	nop
    40201c04:	1000058a 	adr	x10, 40201cb4 <_ZN11jnox_kernel14ordinary_mutex4high17h6a225b999eb58028E>
    40201c08:	d503201f 	nop
    40201c0c:	100009ab 	adr	x11, 40201d40 <_ZN11jnox_kernel14ordinary_mutex4idle17hac9e49461fe17051E>
    40201c10:	a9182fea 	stp	x10, x11, [sp, #384]
    40201c14:	9000004a 	adrp	x10, 40209000 <_ZN11jnox_kernel14ordinary_mutex6STACKS17h3be57ef615508284E+0x2dc0>
    40201c18:	913c014a 	add	x10, x10, #0xf00
    40201c1c:	528068ab 	mov	w11, #0x345                 	// #837
    40201c20:	528ce00c 	mov	w12, #0x6700                	// #26368
    40201c24:	f900cbff 	str	xzr, [sp, #400]
    40201c28:	f869790d 	ldr	x13, [x8, x9, lsl #3]
    40201c2c:	8b0c012e 	add	x14, x9, x12
    40201c30:	8b090e6f 	add	x15, x19, x9, lsl #3
    40201c34:	91000529 	add	x9, x9, #0x1
    40201c38:	f9008d49 	str	x9, [x10, #280]
    40201c3c:	f9004d4e 	str	x14, [x10, #152]
    40201c40:	a90fad4d 	stp	x13, x11, [x10, #248]
    40201c44:	f90095ea 	str	x10, [x15, #296]
    40201c48:	9140114a 	add	x10, x10, #0x4, lsl #12
    40201c4c:	f100113f 	cmp	x9, #0x4
    40201c50:	54fffec1 	b.ne	40201c28 <_ZN11jnox_kernel14ordinary_mutex3run17h2e8d428f4d32a81cE+0xb4>  // b.any
    40201c54:	910003e0 	mov	x0, sp
    40201c58:	52800061 	mov	w1, #0x3                   	// #3
    40201c5c:	2a1f03e2 	mov	w2, wzr
    40201c60:	94000226 	bl	402024f8 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E>
    40201c64:	910003e0 	mov	x0, sp
    40201c68:	aa1f03e1 	mov	x1, xzr
    40201c6c:	2a1f03e2 	mov	w2, wzr
    40201c70:	94000222 	bl	402024f8 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E>
    40201c74:	910003e0 	mov	x0, sp
    40201c78:	9400016c 	bl	40202228 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17he6cd7798df38ede5E>
    40201c7c:	aa0003f3 	mov	x19, x0
    40201c80:	d503201f 	nop
    40201c84:	10019be0 	adr	x0, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40201c88:	910003e1 	mov	x1, sp
    40201c8c:	52802c02 	mov	w2, #0x160                 	// #352
    40201c90:	94000806 	bl	40203ca8 <memcpy>
    40201c94:	aa1303e0 	mov	x0, x19
    40201c98:	97ffff45 	bl	402019ac <sched_start_frame>

0000000040201c9c <_ZN11jnox_kernel14ordinary_mutex4exit17h88ed5b88944c971aE>:
    40201c9c:	f81f0ffe 	str	x30, [sp, #-16]!
    40201ca0:	52800080 	mov	w0, #0x4                   	// #4
    40201ca4:	aa1f03e1 	mov	x1, xzr
    40201ca8:	94000228 	bl	40202548 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>
    40201cac:	52800180 	mov	w0, #0xc                   	// #12
    40201cb0:	9400005f 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

0000000040201cb4 <_ZN11jnox_kernel14ordinary_mutex4high17h6a225b999eb58028E>:
    40201cb4:	d100c3ff 	sub	sp, sp, #0x30
    40201cb8:	a9024ffe 	stp	x30, x19, [sp, #32]
    40201cbc:	d5033fdf 	isb
    40201cc0:	d53be028 	mrs	x8, cntpct_el0
    40201cc4:	90000033 	adrp	x19, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40201cc8:	9107c273 	add	x19, x19, #0x1f0
    40201ccc:	f9000268 	str	x8, [x19]
    40201cd0:	52800020 	mov	w0, #0x1                   	// #1
    40201cd4:	52800021 	mov	w1, #0x1                   	// #1
    40201cd8:	9400021c 	bl	40202548 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>
    40201cdc:	d5033fdf 	isb
    40201ce0:	d53be028 	mrs	x8, cntpct_el0
    40201ce4:	f9000668 	str	x8, [x19, #8]
    40201ce8:	d503201f 	nop
    40201cec:	1001a4a8 	adr	x8, 40205180 <_ZN11jnox_kernel14ordinary_mutex5BATCH17h6ddfd88359c843a2E>
    40201cf0:	f9400909 	ldr	x9, [x8, #16]
    40201cf4:	f940050a 	ldr	x10, [x8, #8]
    40201cf8:	f9400108 	ldr	x8, [x8]
    40201cfc:	a90123ea 	stp	x10, x8, [sp, #16]
    40201d00:	f90007e9 	str	x9, [sp, #8]
    40201d04:	f9400fe8 	ldr	x8, [sp, #24]
    40201d08:	d503201f 	nop
    40201d0c:	100228e9 	adr	x9, 40206228 <_ZN11jnox_kernel14ordinary_mutex6RESULT17h0c78663054aba51aE>
    40201d10:	f9000128 	str	x8, [x9]
    40201d14:	f9400be8 	ldr	x8, [sp, #16]
    40201d18:	f9000528 	str	x8, [x9, #8]
    40201d1c:	f94007e8 	ldr	x8, [sp, #8]
    40201d20:	f9000928 	str	x8, [x9, #16]
    40201d24:	d5033fdf 	isb
    40201d28:	d53be028 	mrs	x8, cntpct_el0
    40201d2c:	f9000a68 	str	x8, [x19, #16]
    40201d30:	52800040 	mov	w0, #0x2                   	// #2
    40201d34:	52800021 	mov	w1, #0x1                   	// #1
    40201d38:	94000204 	bl	40202548 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>
    40201d3c:	97ffffd8 	bl	40201c9c <_ZN11jnox_kernel14ordinary_mutex4exit17h88ed5b88944c971aE>

0000000040201d40 <_ZN11jnox_kernel14ordinary_mutex4idle17hac9e49461fe17051E>:
    40201d40:	d503207f 	wfi
    40201d44:	17ffffff 	b	40201d40 <_ZN11jnox_kernel14ordinary_mutex4idle17hac9e49461fe17051E>

0000000040201d48 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>:
    40201d48:	d10043ff 	sub	sp, sp, #0x10
    40201d4c:	52800308 	mov	w8, #0x18                  	// #24
    40201d50:	72a12008 	movk	w8, #0x900, lsl #16
    40201d54:	8b010009 	add	x9, x0, x1
    40201d58:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    40201d5c:	3840140b 	ldrb	w11, [x0], #1
    40201d60:	b940010c 	ldr	w12, [x8]
    40201d64:	3628006c 	tbz	w12, #5, 40201d70 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x28>
    40201d68:	d5033fdf 	isb
    40201d6c:	17fffffd 	b	40201d60 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x18>
    40201d70:	b900014b 	str	w11, [x10]
    40201d74:	eb09001f 	cmp	x0, x9
    40201d78:	54ffff21 	b.ne	40201d5c <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x14>  // b.any
    40201d7c:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40201d80:	8b030c4a 	add	x10, x2, x3, lsl #3
    40201d84:	5280040b 	mov	w11, #0x20                  	// #32
    40201d88:	910003ec 	mov	x12, sp
    40201d8c:	d503201f 	nop
    40201d90:	10012f8d 	adr	x13, 40204380 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x10>
    40201d94:	f940004e 	ldr	x14, [x2]
    40201d98:	910003ef 	mov	x15, sp
    40201d9c:	52800790 	mov	w16, #0x3c                  	// #60
    40201da0:	a9007fff 	stp	xzr, xzr, [sp]
    40201da4:	9ad025d1 	lsr	x17, x14, x16
    40201da8:	92400e31 	and	x17, x17, #0xf
    40201dac:	387169b1 	ldrb	w17, [x13, x17]
    40201db0:	380015f1 	strb	w17, [x15], #1
    40201db4:	d1001210 	sub	x16, x16, #0x4
    40201db8:	b100121f 	cmn	x16, #0x4
    40201dbc:	54ffff41 	b.ne	40201da4 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x5c>  // b.any
    40201dc0:	14000002 	b	40201dc8 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x80>
    40201dc4:	d5033fdf 	isb
    40201dc8:	b940010e 	ldr	w14, [x8]
    40201dcc:	372fffce 	tbnz	w14, #5, 40201dc4 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x7c>
    40201dd0:	aa1f03ee 	mov	x14, xzr
    40201dd4:	b900012b 	str	w11, [x9]
    40201dd8:	386e698f 	ldrb	w15, [x12, x14]
    40201ddc:	b9400110 	ldr	w16, [x8]
    40201de0:	36280070 	tbz	w16, #5, 40201dec <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0xa4>
    40201de4:	d5033fdf 	isb
    40201de8:	17fffffd 	b	40201ddc <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x94>
    40201dec:	910005ce 	add	x14, x14, #0x1
    40201df0:	b900012f 	str	w15, [x9]
    40201df4:	f10041df 	cmp	x14, #0x10
    40201df8:	54ffff01 	b.ne	40201dd8 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x90>  // b.any
    40201dfc:	91002042 	add	x2, x2, #0x8
    40201e00:	eb0a005f 	cmp	x2, x10
    40201e04:	54fffc81 	b.ne	40201d94 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x4c>  // b.any
    40201e08:	14000002 	b	40201e10 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0xc8>
    40201e0c:	d5033fdf 	isb
    40201e10:	b9400109 	ldr	w9, [x8]
    40201e14:	372fffc9 	tbnz	w9, #5, 40201e0c <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0xc4>
    40201e18:	52a12008 	mov	w8, #0x9000000             	// #150994944
    40201e1c:	52800149 	mov	w9, #0xa                   	// #10
    40201e20:	b9000109 	str	w9, [x8]
    40201e24:	910043ff 	add	sp, sp, #0x10
    40201e28:	d65f03c0 	ret

0000000040201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>:
    40201e2c:	d10243ff 	sub	sp, sp, #0x90
    40201e30:	a9037bfd 	stp	x29, x30, [sp, #48]
    40201e34:	a9046ffc 	stp	x28, x27, [sp, #64]
    40201e38:	a90567fa 	stp	x26, x25, [sp, #80]
    40201e3c:	a9065ff8 	stp	x24, x23, [sp, #96]
    40201e40:	a90757f6 	stp	x22, x21, [sp, #112]
    40201e44:	a9084ff4 	stp	x20, x19, [sp, #128]
    40201e48:	aa1f03e8 	mov	x8, xzr
    40201e4c:	52800315 	mov	w21, #0x18                  	// #24
    40201e50:	72a12015 	movk	w21, #0x900, lsl #16
    40201e54:	d5034fdf 	msr	daifset, #0xf
    40201e58:	d51be23f 	msr	cntp_ctl_el0, xzr
    40201e5c:	d5033fdf 	isb
    40201e60:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40201e64:	d503201f 	nop
    40201e68:	1001294a 	adr	x10, 40204390 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x20>
    40201e6c:	3868694b 	ldrb	w11, [x10, x8]
    40201e70:	b94002ac 	ldr	w12, [x21]
    40201e74:	3628006c 	tbz	w12, #5, 40201e80 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x54>
    40201e78:	d5033fdf 	isb
    40201e7c:	17fffffd 	b	40201e70 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x44>
    40201e80:	91000508 	add	x8, x8, #0x1
    40201e84:	b900012b 	str	w11, [x9]
    40201e88:	f100311f 	cmp	x8, #0xc
    40201e8c:	54ffff01 	b.ne	40201e6c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x40>  // b.any
    40201e90:	90000028 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40201e94:	d00000a9 	adrp	x9, 40217000 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17h3d45513848c8cd5aE+0xdb8>
    40201e98:	d503201f 	nop
    40201e9c:	10019c36 	adr	x22, 40205220 <_ZN11jnox_kernel14ordinary_mutex6CHUNKS17h3cec01e2eeeb4508E.0>
    40201ea0:	f940b514 	ldr	x20, [x8, #360]
    40201ea4:	f9463138 	ldr	x24, [x9, #3168]
    40201ea8:	f100829f 	cmp	x20, #0x20
    40201eac:	c8dffec8 	ldar	x8, [x22]
    40201eb0:	52800029 	mov	w9, #0x1                   	// #1
    40201eb4:	a90083e9 	stp	x9, x0, [sp, #8]
    40201eb8:	52800409 	mov	w9, #0x20                  	// #32
    40201ebc:	9a893299 	csel	x25, x20, x9, cc  // cc = lo, ul, last
    40201ec0:	f101031f 	cmp	x24, #0x40
    40201ec4:	52800809 	mov	w9, #0x40                  	// #64
    40201ec8:	9a893317 	csel	x23, x24, x9, cc  // cc = lo, ul, last
    40201ecc:	a901dff9 	stp	x25, x23, [sp, #24]
    40201ed0:	f90017e8 	str	x8, [sp, #40]
    40201ed4:	d503201f 	nop
    40201ed8:	10012620 	adr	x0, 4020439c <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x2c>
    40201edc:	910023e2 	add	x2, sp, #0x8
    40201ee0:	52800021 	mov	w1, #0x1                   	// #1
    40201ee4:	528000a3 	mov	w3, #0x5                   	// #5
    40201ee8:	97ffff98 	bl	40201d48 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    40201eec:	d503201f 	nop
    40201ef0:	30012560 	adr	x0, 4020439d <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x2d>
    40201ef4:	d503201f 	nop
    40201ef8:	10019502 	adr	x2, 40205198 <_ZN11jnox_kernel14ordinary_mutex5TIMER17ha83d3679ead177eaE>
    40201efc:	52800021 	mov	w1, #0x1                   	// #1
    40201f00:	52800103 	mov	w3, #0x8                   	// #8
    40201f04:	97ffff91 	bl	40201d48 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    40201f08:	aa1f03fc 	mov	x28, xzr
    40201f0c:	d503201f 	nop
    40201f10:	10021988 	adr	x8, 40206240 <_ZN11jnox_kernel14ordinary_mutex6STACKS17h3be57ef615508284E>
    40201f14:	f000001a 	adrp	x26, 40204000 <memset+0x14c>
    40201f18:	9103df5a 	add	x26, x26, #0xf7
    40201f1c:	5280681b 	mov	w27, #0x340                 	// #832
    40201f20:	d503201f 	nop
    40201f24:	70012473 	adr	x19, 402043b3 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x43>
    40201f28:	387c6b49 	ldrb	w9, [x26, x28]
    40201f2c:	a900a7fc 	stp	x28, x9, [sp, #8]
    40201f30:	9140111d 	add	x29, x8, #0x4, lsl #12
    40201f34:	9100079c 	add	x28, x28, #0x1
    40201f38:	a901f7e8 	stp	x8, x29, [sp, #24]
    40201f3c:	f90017fb 	str	x27, [sp, #40]
    40201f40:	910023e2 	add	x2, sp, #0x8
    40201f44:	aa1303e0 	mov	x0, x19
    40201f48:	52800021 	mov	w1, #0x1                   	// #1
    40201f4c:	528000a3 	mov	w3, #0x5                   	// #5
    40201f50:	97ffff7e 	bl	40201d48 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    40201f54:	f100139f 	cmp	x28, #0x4
    40201f58:	aa1d03e8 	mov	x8, x29
    40201f5c:	54fffe61 	b.ne	40201f28 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0xfc>  // b.any
    40201f60:	b40001b4 	cbz	x20, 40201f94 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x168>
    40201f64:	d503201f 	nop
    40201f68:	100a1713 	adr	x19, 40216248 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17h3d45513848c8cd5aE>
    40201f6c:	d503201f 	nop
    40201f70:	50012214 	adr	x20, 402043b2 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x42>
    40201f74:	aa1403e0 	mov	x0, x20
    40201f78:	52800021 	mov	w1, #0x1                   	// #1
    40201f7c:	aa1303e2 	mov	x2, x19
    40201f80:	52800343 	mov	w3, #0x1a                  	// #26
    40201f84:	97ffff71 	bl	40201d48 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    40201f88:	91034273 	add	x19, x19, #0xd0
    40201f8c:	f1000739 	subs	x25, x25, #0x1
    40201f90:	54ffff21 	b.ne	40201f74 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x148>  // b.any
    40201f94:	b40001b8 	cbz	x24, 40201fc8 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x19c>
    40201f98:	d00000b3 	adrp	x19, 40217000 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17h3d45513848c8cd5aE+0xdb8>
    40201f9c:	9131a273 	add	x19, x19, #0xc68
    40201fa0:	d503201f 	nop
    40201fa4:	30012074 	adr	x20, 402043b1 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x41>
    40201fa8:	aa1403e0 	mov	x0, x20
    40201fac:	52800021 	mov	w1, #0x1                   	// #1
    40201fb0:	aa1303e2 	mov	x2, x19
    40201fb4:	52800063 	mov	w3, #0x3                   	// #3
    40201fb8:	97ffff64 	bl	40201d48 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    40201fbc:	91006273 	add	x19, x19, #0x18
    40201fc0:	f10006f7 	subs	x23, x23, #0x1
    40201fc4:	54ffff21 	b.ne	40201fa8 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x17c>  // b.any
    40201fc8:	c8dffec8 	ldar	x8, [x22]
    40201fcc:	f104011f 	cmp	x8, #0x100
    40201fd0:	52802009 	mov	w9, #0x100                 	// #256
    40201fd4:	9a893116 	csel	x22, x8, x9, cc  // cc = lo, ul, last
    40201fd8:	b40001a8 	cbz	x8, 4020200c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x1e0>
    40201fdc:	d503201f 	nop
    40201fe0:	10019253 	adr	x19, 40205228 <_ZN11jnox_kernel14ordinary_mutex6LEDGER17h8bea2891e2f33014E>
    40201fe4:	d503201f 	nop
    40201fe8:	10011e54 	adr	x20, 402043b0 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x40>
    40201fec:	aa1403e0 	mov	x0, x20
    40201ff0:	52800021 	mov	w1, #0x1                   	// #1
    40201ff4:	aa1303e2 	mov	x2, x19
    40201ff8:	52800043 	mov	w3, #0x2                   	// #2
    40201ffc:	97ffff53 	bl	40201d48 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    40202000:	91004273 	add	x19, x19, #0x10
    40202004:	f10006d6 	subs	x22, x22, #0x1
    40202008:	54ffff21 	b.ne	40201fec <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x1c0>  // b.any
    4020200c:	d503201f 	nop
    40202010:	50011c60 	adr	x0, 4020439e <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x2e>
    40202014:	d503201f 	nop
    40202018:	10018b42 	adr	x2, 40205180 <_ZN11jnox_kernel14ordinary_mutex5BATCH17h6ddfd88359c843a2E>
    4020201c:	52800021 	mov	w1, #0x1                   	// #1
    40202020:	52800063 	mov	w3, #0x3                   	// #3
    40202024:	97ffff49 	bl	40201d48 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    40202028:	d503201f 	nop
    4020202c:	70011b80 	adr	x0, 4020439f <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x2f>
    40202030:	d503201f 	nop
    40202034:	10020fa2 	adr	x2, 40206228 <_ZN11jnox_kernel14ordinary_mutex6RESULT17h0c78663054aba51aE>
    40202038:	52800081 	mov	w1, #0x4                   	// #4
    4020203c:	52800063 	mov	w3, #0x3                   	// #3
    40202040:	97ffff42 	bl	40201d48 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    40202044:	d503201f 	nop
    40202048:	70011ac0 	adr	x0, 402043a3 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x33>
    4020204c:	d503201f 	nop
    40202050:	10018902 	adr	x2, 40205170 <_ZN11jnox_kernel14ordinary_mutex5AUDIT17hadb49dc2f312a40eE>
    40202054:	52800021 	mov	w1, #0x1                   	// #1
    40202058:	52800043 	mov	w3, #0x2                   	// #2
    4020205c:	97ffff3b 	bl	40201d48 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    40202060:	d503201f 	nop
    40202064:	100adf68 	adr	x8, 40217c50 <_ZN11jnox_kernel14ordinary_mutex8MED_READ17hd3c9a8ee9446ee10E>
    40202068:	b00000a9 	adrp	x9, 40217000 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17h3d45513848c8cd5aE+0xdb8>
    4020206c:	a940210a 	ldp	x10, x8, [x8]
    40202070:	a900a3ea 	stp	x10, x8, [sp, #8]
    40202074:	f9462528 	ldr	x8, [x9, #3144]
    40202078:	f9000fe8 	str	x8, [sp, #24]
    4020207c:	d503201f 	nop
    40202080:	10011920 	adr	x0, 402043a4 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x34>
    40202084:	910023e2 	add	x2, sp, #0x8
    40202088:	52800021 	mov	w1, #0x1                   	// #1
    4020208c:	52800063 	mov	w3, #0x3                   	// #3
    40202090:	97ffff2e 	bl	40201d48 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    40202094:	d503201f 	nop
    40202098:	30011860 	adr	x0, 402043a5 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x35>
    4020209c:	d503201f 	nop
    402020a0:	100189c2 	adr	x2, 402051d8 <_ZN11jnox_kernel14ordinary_mutex5TIMES17he770985d80da3796E>
    402020a4:	52800021 	mov	w1, #0x1                   	// #1
    402020a8:	52800123 	mov	w3, #0x9                   	// #9
    402020ac:	97ffff27 	bl	40201d48 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    402020b0:	aa1f03e8 	mov	x8, xzr
    402020b4:	52a12009 	mov	w9, #0x9000000             	// #150994944
    402020b8:	d503201f 	nop
    402020bc:	5001174a 	adr	x10, 402043a6 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x36>
    402020c0:	3868694b 	ldrb	w11, [x10, x8]
    402020c4:	b94002ac 	ldr	w12, [x21]
    402020c8:	3628006c 	tbz	w12, #5, 402020d4 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x2a8>
    402020cc:	d5033fdf 	isb
    402020d0:	17fffffd 	b	402020c4 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x298>
    402020d4:	91000508 	add	x8, x8, #0x1
    402020d8:	b900012b 	str	w11, [x9]
    402020dc:	f100291f 	cmp	x8, #0xa
    402020e0:	54ffff01 	b.ne	402020c0 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x294>  // b.any
    402020e4:	d503205f 	wfe
    402020e8:	17ffffff 	b	402020e4 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x2b8>

00000000402020ec <_ZN11jnox_kernel14ordinary_mutex6medium17h477bcb7179dbf5cbE>:
    402020ec:	d10083ff 	sub	sp, sp, #0x20
    402020f0:	f9000bfe 	str	x30, [sp, #16]
    402020f4:	52800028 	mov	w8, #0x1                   	// #1
    402020f8:	aa1f03e0 	mov	x0, xzr
    402020fc:	d4000001 	svc	#0x0
    40202100:	b50004c0 	cbnz	x0, 40202198 <_ZN11jnox_kernel14ordinary_mutex6medium17h477bcb7179dbf5cbE+0xac>
    40202104:	d503201f 	nop
    40202108:	10018348 	adr	x8, 40205170 <_ZN11jnox_kernel14ordinary_mutex5AUDIT17hadb49dc2f312a40eE>
    4020210c:	f9400509 	ldr	x9, [x8, #8]
    40202110:	f9400108 	ldr	x8, [x8]
    40202114:	f9000fe8 	str	x8, [sp, #24]
    40202118:	f90007e9 	str	x9, [sp, #8]
    4020211c:	f9400fe8 	ldr	x8, [sp, #24]
    40202120:	d503201f 	nop
    40202124:	100ad969 	adr	x9, 40217c50 <_ZN11jnox_kernel14ordinary_mutex8MED_READ17hd3c9a8ee9446ee10E>
    40202128:	f9000128 	str	x8, [x9]
    4020212c:	f94007e8 	ldr	x8, [sp, #8]
    40202130:	f9000528 	str	x8, [x9, #8]
    40202134:	d5033fdf 	isb
    40202138:	d53be028 	mrs	x8, cntpct_el0
    4020213c:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202140:	f9010528 	str	x8, [x9, #520]
    40202144:	52800048 	mov	w8, #0x2                   	// #2
    40202148:	d4000001 	svc	#0x0
    4020214c:	b5000260 	cbnz	x0, 40202198 <_ZN11jnox_kernel14ordinary_mutex6medium17h477bcb7179dbf5cbE+0xac>
    40202150:	aa1f03e8 	mov	x8, xzr
    40202154:	52800029 	mov	w9, #0x1                   	// #1
    40202158:	f104013f 	cmp	x9, #0x100
    4020215c:	9a89052a 	cinc	x10, x9, ne  // ne = any
    40202160:	f9000fe9 	str	x9, [sp, #24]
    40202164:	f9400fe9 	ldr	x9, [sp, #24]
    40202168:	8b080128 	add	x8, x9, x8
    4020216c:	54000080 	b.eq	4020217c <_ZN11jnox_kernel14ordinary_mutex6medium17h477bcb7179dbf5cbE+0x90>  // b.none
    40202170:	f104055f 	cmp	x10, #0x101
    40202174:	aa0a03e9 	mov	x9, x10
    40202178:	54ffff03 	b.cc	40202158 <_ZN11jnox_kernel14ordinary_mutex6medium17h477bcb7179dbf5cbE+0x6c>  // b.lo, b.ul, b.last
    4020217c:	b00000a9 	adrp	x9, 40217000 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17h3d45513848c8cd5aE+0xdb8>
    40202180:	f9062528 	str	x8, [x9, #3144]
    40202184:	d5033fdf 	isb
    40202188:	d53be028 	mrs	x8, cntpct_el0
    4020218c:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202190:	f9010928 	str	x8, [x9, #528]
    40202194:	97fffec2 	bl	40201c9c <_ZN11jnox_kernel14ordinary_mutex4exit17h88ed5b88944c971aE>
    40202198:	52800160 	mov	w0, #0xb                   	// #11
    4020219c:	97ffff24 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

00000000402021a0 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17had12d2d094a825fcE>:
    402021a0:	f81f0ffe 	str	x30, [sp, #-16]!
    402021a4:	aa0003e8 	mov	x8, x0
    402021a8:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    402021ac:	f940a520 	ldr	x0, [x9, #328]
    402021b0:	d503201f 	nop
    402021b4:	10020469 	adr	x9, 40206240 <_ZN11jnox_kernel14ordinary_mutex6STACKS17h3be57ef615508284E>
    402021b8:	8b003929 	add	x9, x9, x0, lsl #14
    402021bc:	92400d0a 	and	x10, x8, #0xf
    402021c0:	5287980b 	mov	w11, #0x3cc0                	// #15552
    402021c4:	8b0b012b 	add	x11, x9, x11
    402021c8:	eb08017f 	cmp	x11, x8
    402021cc:	fa402940 	ccmp	x10, #0x0, #0x0, cs  // cs = hs, nlast
    402021d0:	fa480122 	ccmp	x9, x8, #0x2, eq  // eq = none
    402021d4:	540001e8 	b.hi	40202210 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17had12d2d094a825fcE+0x70>  // b.pmore
    402021d8:	f1000c1f 	cmp	x0, #0x3
    402021dc:	540001e8 	b.hi	40202218 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17had12d2d094a825fcE+0x78>  // b.pmore
    402021e0:	d503201f 	nop
    402021e4:	100170e9 	adr	x9, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    402021e8:	8b000d29 	add	x9, x9, x0, lsl #3
    402021ec:	f940952a 	ldr	x10, [x9, #296]
    402021f0:	b500010a 	cbnz	x10, 40202210 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17had12d2d094a825fcE+0x70>
    402021f4:	f9408d0a 	ldr	x10, [x8, #280]
    402021f8:	9100040b 	add	x11, x0, #0x1
    402021fc:	eb0b015f 	cmp	x10, x11
    40202200:	54000081 	b.ne	40202210 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17had12d2d094a825fcE+0x70>  // b.any
    40202204:	f9009528 	str	x8, [x9, #296]
    40202208:	f84107fe 	ldr	x30, [sp], #16
    4020220c:	d65f03c0 	ret
    40202210:	52800080 	mov	w0, #0x4                   	// #4
    40202214:	97ffff06 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40202218:	d503201f 	nop
    4020221c:	10010ce2 	adr	x2, 402043b8 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x48>
    40202220:	52800081 	mov	w1, #0x4                   	// #4
    40202224:	940003f4 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040202228 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17he6cd7798df38ede5E>:
    40202228:	a9bf4ffe 	stp	x30, x19, [sp, #-16]!
    4020222c:	aa0003f3 	mov	x19, x0
    40202230:	91040000 	add	x0, x0, #0x100
    40202234:	aa1303e1 	mov	x1, x19
    40202238:	97fff7e8 	bl	402001d8 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h8ea738f65e69985dE>
    4020223c:	36000280 	tbz	w0, #0, 4020228c <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17he6cd7798df38ede5E+0x64>
    40202240:	f900a661 	str	x1, [x19, #328]
    40202244:	f1000c3f 	cmp	x1, #0x3
    40202248:	54000248 	b.hi	40202290 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17he6cd7798df38ede5E+0x68>  // b.pmore
    4020224c:	8b010e68 	add	x8, x19, x1, lsl #3
    40202250:	f9409500 	ldr	x0, [x8, #296]
    40202254:	f900951f 	str	xzr, [x8, #296]
    40202258:	f940a668 	ldr	x8, [x19, #328]
    4020225c:	d503201f 	nop
    40202260:	1001ff09 	adr	x9, 40206240 <_ZN11jnox_kernel14ordinary_mutex6STACKS17h3be57ef615508284E>
    40202264:	8b083928 	add	x8, x9, x8, lsl #14
    40202268:	92400c09 	and	x9, x0, #0xf
    4020226c:	5287980a 	mov	w10, #0x3cc0                	// #15552
    40202270:	8b0a010a 	add	x10, x8, x10
    40202274:	eb00015f 	cmp	x10, x0
    40202278:	fa402920 	ccmp	x9, #0x0, #0x0, cs  // cs = hs, nlast
    4020227c:	fa400102 	ccmp	x8, x0, #0x2, eq  // eq = none
    40202280:	54000128 	b.hi	402022a4 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17he6cd7798df38ede5E+0x7c>  // b.pmore
    40202284:	a8c14ffe 	ldp	x30, x19, [sp], #16
    40202288:	d65f03c0 	ret
    4020228c:	94000008 	bl	402022ac <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose28_$u7b$$u7b$closure$u7d$$u7d$17h2608ed9bb6a6f2a8E>
    40202290:	d503201f 	nop
    40202294:	100109e2 	adr	x2, 402043d0 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x60>
    40202298:	aa0103e0 	mov	x0, x1
    4020229c:	52800081 	mov	w1, #0x4                   	// #4
    402022a0:	940003d5 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    402022a4:	52800080 	mov	w0, #0x4                   	// #4
    402022a8:	97fffee1 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

00000000402022ac <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose28_$u7b$$u7b$closure$u7d$$u7d$17h2608ed9bb6a6f2a8E>:
    402022ac:	f81f0ffe 	str	x30, [sp, #-16]!
    402022b0:	52800060 	mov	w0, #0x3                   	// #3
    402022b4:	97fffede 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

00000000402022b8 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E>:
    402022b8:	d10283ff 	sub	sp, sp, #0xa0
    402022bc:	a9047bfd 	stp	x29, x30, [sp, #64]
    402022c0:	a9056ffc 	stp	x28, x27, [sp, #80]
    402022c4:	a90667fa 	stp	x26, x25, [sp, #96]
    402022c8:	a9075ff8 	stp	x24, x23, [sp, #112]
    402022cc:	a90857f6 	stp	x22, x21, [sp, #128]
    402022d0:	a9094ff4 	stp	x20, x19, [sp, #144]
    402022d4:	aa0103e9 	mov	x9, x1
    402022d8:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    402022dc:	91048108 	add	x8, x8, #0x120
    402022e0:	f9400101 	ldr	x1, [x8]
    402022e4:	f100143f 	cmp	x1, #0x5
    402022e8:	54000ea2 	b.cs	402024bc <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E+0x204>  // b.hs, b.nlast
    402022ec:	aa0403f4 	mov	x20, x4
    402022f0:	aa0303f5 	mov	x21, x3
    402022f4:	a900a7e0 	stp	x0, x9, [sp, #8]
    402022f8:	a90197e2 	stp	x2, x5, [sp, #24]
    402022fc:	f9401509 	ldr	x9, [x8, #40]
    40202300:	52800028 	mov	w8, #0x1                   	// #1
    40202304:	f90003e9 	str	x9, [sp]
    40202308:	9ac9211a 	lsl	x26, x8, x9
    4020230c:	b4000141 	cbz	x1, 40202334 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E+0x7c>
    40202310:	d37df028 	lsl	x8, x1, #3
    40202314:	52800029 	mov	w9, #0x1                   	// #1
    40202318:	f000000a 	adrp	x10, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    4020231c:	9104014a 	add	x10, x10, #0x100
    40202320:	f840854b 	ldr	x11, [x10], #8
    40202324:	9acb212b 	lsl	x11, x9, x11
    40202328:	aa1a017a 	orr	x26, x11, x26
    4020232c:	f1002108 	subs	x8, x8, #0x8
    40202330:	54ffff81 	b.ne	40202320 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E+0x68>  // b.any
    40202334:	aa1f03fd 	mov	x29, xzr
    40202338:	aa1f03fc 	mov	x28, xzr
    4020233c:	aa1f03f3 	mov	x19, xzr
    40202340:	f0000016 	adrp	x22, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202344:	9102a2d6 	add	x22, x22, #0xa8
    40202348:	a902ffff 	stp	xzr, xzr, [sp, #40]
    4020234c:	52800037 	mov	w23, #0x1                   	// #1
    40202350:	9100a3f8 	add	x24, sp, #0x28
    40202354:	9100f3fb 	add	x27, sp, #0x3c
    40202358:	d503201f 	nop
    4020235c:	10016539 	adr	x25, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202360:	b85f82c8 	ldur	w8, [x22, #-8]
    40202364:	36000108 	tbz	w8, #0, 40202384 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E+0xcc>
    40202368:	f94002c0 	ldr	x0, [x22]
    4020236c:	f100041f 	cmp	x0, #0x1
    40202370:	54000b08 	b.hi	402024d0 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E+0x218>  // b.pmore
    40202374:	9ad322e8 	lsl	x8, x23, x19
    40202378:	f8607b09 	ldr	x9, [x24, x0, lsl #3]
    4020237c:	aa080128 	orr	x8, x9, x8
    40202380:	f8207b08 	str	x8, [x24, x0, lsl #3]
    40202384:	aa1903e0 	mov	x0, x25
    40202388:	97fff802 	bl	40200390 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470>
    4020238c:	360000a0 	tbz	w0, #0, 402023a0 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E+0xe8>
    40202390:	d348fc08 	lsr	x8, x0, #8
    40202394:	b9003fe8 	str	w8, [sp, #60]
    40202398:	38736b68 	ldrb	w8, [x27, x19]
    4020239c:	14000002 	b	402023a4 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E+0xec>
    402023a0:	aa1f03e8 	mov	x8, xzr
    402023a4:	91000673 	add	x19, x19, #0x1
    402023a8:	910042d6 	add	x22, x22, #0x10
    402023ac:	9add2108 	lsl	x8, x8, x29
    402023b0:	aa1c011c 	orr	x28, x8, x28
    402023b4:	910023bd 	add	x29, x29, #0x8
    402023b8:	f100127f 	cmp	x19, #0x4
    402023bc:	54fffd21 	b.ne	40202360 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E+0xa8>  // b.any
    402023c0:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    402023c4:	f940b509 	ldr	x9, [x8, #360]
    402023c8:	f100813f 	cmp	x9, #0x20
    402023cc:	540008a0 	b.eq	402024e0 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E+0x228>  // b.none
    402023d0:	f9409ea2 	ldr	x2, [x21, #312]
    402023d4:	d5033fdf 	isb
    402023d8:	d53be021 	mrs	x1, cntpct_el0
    402023dc:	a94fb6ac 	ldp	x12, x13, [x21, #248]
    402023e0:	f9404eae 	ldr	x14, [x21, #152]
    402023e4:	f9407e89 	ldr	x9, [x20, #248]
    402023e8:	f9404e8a 	ldr	x10, [x20, #152]
    402023ec:	a9404b23 	ldp	x3, x18, [x25]
    402023f0:	a9411325 	ldp	x5, x4, [x25, #16]
    402023f4:	a942c3ef 	ldp	x15, x16, [sp, #40]
    402023f8:	d503201f 	nop
    402023fc:	1001712b 	adr	x11, 40205220 <_ZN11jnox_kernel14ordinary_mutex6CHUNKS17h3cec01e2eeeb4508E.0>
    40202400:	c8dffd6b 	ldar	x11, [x11]
    40202404:	d503201f 	nop
    40202408:	1009f1d1 	adr	x17, 40216240 <_ZN11jnox_kernel14ordinary_mutex7IN_WORK17h3cf0d660ecd4af71E.0>
    4020240c:	c8dffe31 	ldar	x17, [x17]
    40202410:	f940b500 	ldr	x0, [x8, #360]
    40202414:	f1007c1f 	cmp	x0, #0x1f
    40202418:	54000688 	b.hi	402024e8 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E+0x230>  // b.pmore
    4020241c:	f9400286 	ldr	x6, [x20]
    40202420:	f9408e87 	ldr	x7, [x20, #280]
    40202424:	52801a13 	mov	w19, #0xd0                  	// #208
    40202428:	d503201f 	nop
    4020242c:	1009f0f6 	adr	x22, 40216248 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17h3d45513848c8cd5aE>
    40202430:	9b135813 	madd	x19, x0, x19, x22
    40202434:	f9408eb6 	ldr	x22, [x21, #280]
    40202438:	a9000662 	stp	x2, x1, [x19]
    4020243c:	a94087e2 	ldp	x2, x1, [sp, #8]
    40202440:	a9010662 	stp	x2, x1, [x19, #16]
    40202444:	710000bf 	cmp	w5, #0x0
    40202448:	f0000001 	adrp	x1, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    4020244c:	da9f1082 	csinv	x2, x4, xzr, ne  // ne = any
    40202450:	7100007f 	cmp	w3, #0x0
    40202454:	f9400fe4 	ldr	x4, [sp, #24]
    40202458:	f94003e3 	ldr	x3, [sp]
    4020245c:	a9020e64 	stp	x4, x3, [x19, #32]
    40202460:	39457021 	ldrb	w1, [x1, #348]
    40202464:	da9f1252 	csinv	x18, x18, xzr, ne  // ne = any
    40202468:	a9033275 	stp	x21, x12, [x19, #48]
    4020246c:	a9043a6d 	stp	x13, x14, [x19, #64]
    40202470:	a9052674 	stp	x20, x9, [x19, #80]
    40202474:	a9066a6a 	stp	x10, x26, [x19, #96]
    40202478:	a9070a72 	stp	x18, x2, [x19, #112]
    4020247c:	a908426f 	stp	x15, x16, [x19, #128]
    40202480:	f94013e9 	ldr	x9, [sp, #32]
    40202484:	a909267c 	stp	x28, x9, [x19, #144]
    40202488:	a90a466b 	stp	x11, x17, [x19, #160]
    4020248c:	a90b5a61 	stp	x1, x22, [x19, #176]
    40202490:	a90c1a67 	stp	x7, x6, [x19, #192]
    40202494:	91000409 	add	x9, x0, #0x1
    40202498:	f900b509 	str	x9, [x8, #360]
    4020249c:	a9494ff4 	ldp	x20, x19, [sp, #144]
    402024a0:	a94857f6 	ldp	x22, x21, [sp, #128]
    402024a4:	a9475ff8 	ldp	x24, x23, [sp, #112]
    402024a8:	a94667fa 	ldp	x26, x25, [sp, #96]
    402024ac:	a9456ffc 	ldp	x28, x27, [sp, #80]
    402024b0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    402024b4:	910283ff 	add	sp, sp, #0xa0
    402024b8:	d65f03c0 	ret
    402024bc:	d503201f 	nop
    402024c0:	1000e803 	adr	x3, 402041c0 <anon.c4e24dea056945e7185438d0e076311c.7.llvm.5430753883208388470>
    402024c4:	aa1f03e0 	mov	x0, xzr
    402024c8:	52800082 	mov	w2, #0x4                   	// #4
    402024cc:	94000549 	bl	402039f0 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>
    402024d0:	d503201f 	nop
    402024d4:	1000f962 	adr	x2, 40204400 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x90>
    402024d8:	52800041 	mov	w1, #0x2                   	// #2
    402024dc:	94000346 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    402024e0:	528000a0 	mov	w0, #0x5                   	// #5
    402024e4:	97fffe52 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    402024e8:	d503201f 	nop
    402024ec:	1000f7e2 	adr	x2, 402043e8 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x78>
    402024f0:	52800401 	mov	w1, #0x20                  	// #32
    402024f4:	94000340 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

00000000402024f8 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E>:
    402024f8:	f81f0ffe 	str	x30, [sp, #-16]!
    402024fc:	39457008 	ldrb	w8, [x0, #348]
    40202500:	1ac12508 	lsr	w8, w8, w1
    40202504:	37000168 	tbnz	w8, #0, 40202530 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E+0x38>
    40202508:	8b011008 	add	x8, x0, x1, lsl #4
    4020250c:	f9405108 	ldr	x8, [x8, #160]
    40202510:	b5000108 	cbnz	x8, 40202530 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E+0x38>
    40202514:	8b010c08 	add	x8, x0, x1, lsl #3
    40202518:	f9409508 	ldr	x8, [x8, #296]
    4020251c:	b40000a8 	cbz	x8, 40202530 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E+0x38>
    40202520:	91040000 	add	x0, x0, #0x100
    40202524:	340000a2 	cbz	w2, 40202538 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E+0x40>
    40202528:	97fff6fc 	bl	40200118 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE>
    4020252c:	370000a0 	tbnz	w0, #0, 40202540 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E+0x48>
    40202530:	52800040 	mov	w0, #0x2                   	// #2
    40202534:	97fffe3e 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40202538:	97fff77a 	bl	40200320 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE>
    4020253c:	3607ffa0 	tbz	w0, #0, 40202530 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E+0x38>
    40202540:	f84107fe 	ldr	x30, [sp], #16
    40202544:	d65f03c0 	ret

0000000040202548 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>:
    40202548:	aa0003e8 	mov	x8, x0
    4020254c:	aa0103e0 	mov	x0, x1
    40202550:	d4000001 	svc	#0x0
    40202554:	b5000040 	cbnz	x0, 4020255c <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E+0x14>
    40202558:	d65f03c0 	ret
    4020255c:	f81f0ffe 	str	x30, [sp, #-16]!
    40202560:	52800160 	mov	w0, #0xb                   	// #11
    40202564:	97fffe32 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

0000000040202568 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E>:
    40202568:	d10243ff 	sub	sp, sp, #0x90
    4020256c:	f90023fe 	str	x30, [sp, #64]
    40202570:	a90567fa 	stp	x26, x25, [sp, #80]
    40202574:	a9065ff8 	stp	x24, x23, [sp, #96]
    40202578:	a90757f6 	stp	x22, x21, [sp, #112]
    4020257c:	a9084ff4 	stp	x20, x19, [sp, #128]
    40202580:	d5385208 	mrs	x8, esr_el1
    40202584:	9266d508 	and	x8, x8, #0xfffffffffc00ffff
    40202588:	52aa8009 	mov	w9, #0x54000000            	// #1409286144
    4020258c:	eb09011f 	cmp	x8, x9
    40202590:	54001ac1 	b.ne	402028e8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x380>  // b.any
    40202594:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202598:	f9400108 	ldr	x8, [x8]
    4020259c:	f100091f 	cmp	x8, #0x2
    402025a0:	54001a80 	b.eq	402028f0 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x388>  // b.none
    402025a4:	aa0003f4 	mov	x20, x0
    402025a8:	97fffefe 	bl	402021a0 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17had12d2d094a825fcE>
    402025ac:	aa0003f5 	mov	x21, x0
    402025b0:	f9402297 	ldr	x23, [x20, #64]
    402025b4:	f9400296 	ldr	x22, [x20]
    402025b8:	f1000aff 	cmp	x23, #0x2
    402025bc:	d503201f 	nop
    402025c0:	10015213 	adr	x19, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    402025c4:	5400068c 	b.gt	40202694 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x12c>
    402025c8:	f10006ff 	cmp	x23, #0x1
    402025cc:	54000980 	b.eq	402026fc <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x194>  // b.none
    402025d0:	f1000aff 	cmp	x23, #0x2
    402025d4:	540018a1 	b.ne	402028e8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x380>  // b.any
    402025d8:	d503201f 	nop
    402025dc:	10015139 	adr	x25, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    402025e0:	aa1903e0 	mov	x0, x25
    402025e4:	aa1503e1 	mov	x1, x21
    402025e8:	aa1603e2 	mov	x2, x22
    402025ec:	97fff8f0 	bl	402009ac <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E>
    402025f0:	f100081f 	cmp	x0, #0x2
    402025f4:	54001fe0 	b.eq	402029f0 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x488>  // b.none
    402025f8:	36000420 	tbz	w0, #0, 4020267c <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x114>
    402025fc:	aa0103f8 	mov	x24, x1
    40202600:	f1000c3f 	cmp	x1, #0x3
    40202604:	54001fe8 	b.hi	40202a00 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x498>  // b.pmore
    40202608:	8b180f28 	add	x8, x25, x24, lsl #3
    4020260c:	f9409508 	ldr	x8, [x8, #296]
    40202610:	d503201f 	nop
    40202614:	1001e169 	adr	x9, 40206240 <_ZN11jnox_kernel14ordinary_mutex6STACKS17h3be57ef615508284E>
    40202618:	8b183929 	add	x9, x9, x24, lsl #14
    4020261c:	5287980a 	mov	w10, #0x3cc0                	// #15552
    40202620:	8b0a012a 	add	x10, x9, x10
    40202624:	eb08015f 	cmp	x10, x8
    40202628:	54001f63 	b.cc	40202a14 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x4ac>  // b.lo, b.ul, b.last
    4020262c:	eb08013f 	cmp	x9, x8
    40202630:	54001f28 	b.hi	40202a14 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x4ac>  // b.pmore
    40202634:	92400d09 	and	x9, x8, #0xf
    40202638:	b5001ee9 	cbnz	x9, 40202a14 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x4ac>
    4020263c:	f900011f 	str	xzr, [x8]
    40202640:	d503201f 	nop
    40202644:	10014de0 	adr	x0, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202648:	aa1803e1 	mov	x1, x24
    4020264c:	2a1f03e2 	mov	w2, wzr
    40202650:	97ffffaa 	bl	402024f8 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E>
    40202654:	b5000155 	cbnz	x21, 4020267c <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x114>
    40202658:	f1000b1f 	cmp	x24, #0x2
    4020265c:	54000101 	b.ne	4020267c <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x114>  // b.any
    40202660:	d5033fdf 	isb
    40202664:	d53be028 	mrs	x8, cntpct_el0
    40202668:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    4020266c:	f9010d28 	str	x8, [x9, #536]
    40202670:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202674:	52800029 	mov	w9, #0x1                   	// #1
    40202678:	39056d09 	strb	w9, [x8, #347]
    4020267c:	f900029f 	str	xzr, [x20]
    40202680:	d503201f 	nop
    40202684:	10014be0 	adr	x0, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202688:	aa1503e1 	mov	x1, x21
    4020268c:	52800022 	mov	w2, #0x1                   	// #1
    40202690:	14000036 	b	40202768 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x200>
    40202694:	f1000eff 	cmp	x23, #0x3
    40202698:	54000520 	b.eq	4020273c <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x1d4>  // b.none
    4020269c:	f10012ff 	cmp	x23, #0x4
    402026a0:	54001241 	b.ne	402028e8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x380>  // b.any
    402026a4:	f1000ebf 	cmp	x21, #0x3
    402026a8:	54000260 	b.eq	402026f4 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x18c>  // b.none
    402026ac:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    402026b0:	39457109 	ldrb	w9, [x8, #348]
    402026b4:	5280002a 	mov	w10, #0x1                   	// #1
    402026b8:	1ad5214a 	lsl	w10, w10, w21
    402026bc:	6a0a013f 	tst	w9, w10
    402026c0:	540001a1 	b.ne	402026f4 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x18c>  // b.any
    402026c4:	5280006b 	mov	w11, #0x3                   	// #3
    402026c8:	f000000c 	adrp	x12, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    402026cc:	9100218c 	add	x12, x12, #0x8
    402026d0:	f100056b 	subs	x11, x11, #0x1
    402026d4:	54000500 	b.eq	40202774 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x20c>  // b.none
    402026d8:	aa0c03ed 	mov	x13, x12
    402026dc:	9100418c 	add	x12, x12, #0x10
    402026e0:	f85f81ae 	ldur	x14, [x13, #-8]
    402026e4:	b4ffff6e 	cbz	x14, 402026d0 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x168>
    402026e8:	f94001ad 	ldr	x13, [x13]
    402026ec:	eb1501bf 	cmp	x13, x21
    402026f0:	54ffff01 	b.ne	402026d0 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x168>  // b.any
    402026f4:	52800120 	mov	w0, #0x9                   	// #9
    402026f8:	97fffdcd 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    402026fc:	d503201f 	nop
    40202700:	10014800 	adr	x0, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202704:	aa1503e1 	mov	x1, x21
    40202708:	aa1603e2 	mov	x2, x22
    4020270c:	97fff86f 	bl	402008c8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE>
    40202710:	72001c08 	ands	w8, w0, #0xff
    40202714:	54000600 	b.eq	402027d4 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x26c>  // b.none
    40202718:	7100091f 	cmp	w8, #0x2
    4020271c:	540016e0 	b.eq	402029f8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x490>  // b.none
    40202720:	f1000abf 	cmp	x21, #0x2
    40202724:	54000081 	b.ne	40202734 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x1cc>  // b.any
    40202728:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    4020272c:	52800029 	mov	w9, #0x1                   	// #1
    40202730:	39056909 	strb	w9, [x8, #346]
    40202734:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    40202738:	14000012 	b	40202780 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x218>
    4020273c:	b5001535 	cbnz	x21, 402029e0 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x478>
    40202740:	d503201f 	nop
    40202744:	100156e8 	adr	x8, 40205220 <_ZN11jnox_kernel14ordinary_mutex6CHUNKS17h3cec01e2eeeb4508E.0>
    40202748:	c8dffd08 	ldar	x8, [x8]
    4020274c:	f102011f 	cmp	x8, #0x80
    40202750:	54001481 	b.ne	402029e0 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x478>  // b.any
    40202754:	f900029f 	str	xzr, [x20]
    40202758:	d503201f 	nop
    4020275c:	10014520 	adr	x0, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202760:	aa1f03e1 	mov	x1, xzr
    40202764:	2a1f03e2 	mov	w2, wzr
    40202768:	97ffff64 	bl	402024f8 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E>
    4020276c:	aa1f03f9 	mov	x25, xzr
    40202770:	14000004 	b	40202780 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x218>
    40202774:	aa1f03f9 	mov	x25, xzr
    40202778:	2a0a0129 	orr	w9, w9, w10
    4020277c:	39057109 	strb	w9, [x8, #348]
    40202780:	aa1303e0 	mov	x0, x19
    40202784:	97fffea9 	bl	40202228 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17he6cd7798df38ede5E>
    40202788:	aa0003f8 	mov	x24, x0
    4020278c:	aa1703e0 	mov	x0, x23
    40202790:	aa1603e1 	mov	x1, x22
    40202794:	aa1503e2 	mov	x2, x21
    40202798:	aa1403e3 	mov	x3, x20
    4020279c:	aa1803e4 	mov	x4, x24
    402027a0:	aa1903e5 	mov	x5, x25
    402027a4:	97fffec5 	bl	402022b8 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E>
    402027a8:	39457268 	ldrb	w8, [x19, #348]
    402027ac:	71001d1f 	cmp	w8, #0x7
    402027b0:	54000a40 	b.eq	402028f8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x390>  // b.none
    402027b4:	aa1803e0 	mov	x0, x24
    402027b8:	a9484ff4 	ldp	x20, x19, [sp, #128]
    402027bc:	a94757f6 	ldp	x22, x21, [sp, #112]
    402027c0:	a9465ff8 	ldp	x24, x23, [sp, #96]
    402027c4:	a94567fa 	ldp	x26, x25, [sp, #80]
    402027c8:	f94023fe 	ldr	x30, [sp, #64]
    402027cc:	910243ff 	add	sp, sp, #0x90
    402027d0:	d65f03c0 	ret
    402027d4:	f900029f 	str	xzr, [x20]
    402027d8:	d503201f 	nop
    402027dc:	1001413a 	adr	x26, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    402027e0:	aa1a03e0 	mov	x0, x26
    402027e4:	aa1503e1 	mov	x1, x21
    402027e8:	52800022 	mov	w2, #0x1                   	// #1
    402027ec:	97ffff43 	bl	402024f8 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E>
    402027f0:	aa1f03f9 	mov	x25, xzr
    402027f4:	b5fffc75 	cbnz	x21, 40202780 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x218>
    402027f8:	f10006df 	cmp	x22, #0x1
    402027fc:	54fffc21 	b.ne	40202780 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x218>  // b.any
    40202800:	39456355 	ldrb	w21, [x26, #344]
    40202804:	aa1a03e0 	mov	x0, x26
    40202808:	97fffe88 	bl	40202228 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17he6cd7798df38ede5E>
    4020280c:	aa0003f8 	mov	x24, x0
    40202810:	52800020 	mov	w0, #0x1                   	// #1
    40202814:	52800021 	mov	w1, #0x1                   	// #1
    40202818:	aa1f03e2 	mov	x2, xzr
    4020281c:	aa1403e3 	mov	x3, x20
    40202820:	aa1803e4 	mov	x4, x24
    40202824:	aa1f03e5 	mov	x5, xzr
    40202828:	97fffea4 	bl	402022b8 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E>
    4020282c:	39457348 	ldrb	w8, [x26, #348]
    40202830:	71001d1f 	cmp	w8, #0x7
    40202834:	54000620 	b.eq	402028f8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x390>  // b.none
    40202838:	3707fbf5 	tbnz	w21, #0, 402027b4 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x24c>
    4020283c:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202840:	f940a508 	ldr	x8, [x8, #328]
    40202844:	b50004e8 	cbnz	x8, 402028e0 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x378>
    40202848:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    4020284c:	f940a928 	ldr	x8, [x9, #336]
    40202850:	b4000488 	cbz	x8, 402028e0 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x378>
    40202854:	d28b296a 	mov	x10, #0x594b                	// #22859
    40202858:	f2a710ca 	movk	x10, #0x3886, lsl #16
    4020285c:	f2d8baca 	movk	x10, #0xc5d6, lsl #32
    40202860:	f2e68daa 	movk	x10, #0x346d, lsl #48
    40202864:	9bca7d0b 	umulh	x11, x8, x10
    40202868:	d34bfd6b 	lsr	x11, x11, #11
    4020286c:	5284e20c 	mov	w12, #0x2710                	// #10000
    40202870:	9b0ca168 	msub	x8, x11, x12, x8
    40202874:	b5000368 	cbnz	x8, 402028e0 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x378>
    40202878:	d5033fdf 	isb
    4020287c:	d53be028 	mrs	x8, cntpct_el0
    40202880:	f940a929 	ldr	x9, [x9, #336]
    40202884:	9bca7d29 	umulh	x9, x9, x10
    40202888:	ab492d09 	adds	x9, x8, x9, lsr #11
    4020288c:	54000c82 	b.cs	40202a1c <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x4b4>  // b.hs, b.nlast
    40202890:	f000000b 	adrp	x11, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202894:	9105416b 	add	x11, x11, #0x150
    40202898:	5280002c 	mov	w12, #0x1                   	// #1
    4020289c:	d503201f 	nop
    402028a0:	100147cd 	adr	x13, 40205198 <_ZN11jnox_kernel14ordinary_mutex5TIMER17ha83d3679ead177eaE>
    402028a4:	d51be249 	msr	cntp_cval_el0, x9
    402028a8:	d51be22c 	msr	cntp_ctl_el0, x12
    402028ac:	d5033fdf 	isb
    402028b0:	d53be24e 	mrs	x14, cntp_cval_el0
    402028b4:	d53be22a 	mrs	x10, cntp_ctl_el0
    402028b8:	a90139a9 	stp	x9, x14, [x13, #16]
    402028bc:	f940016f 	ldr	x15, [x11]
    402028c0:	a90021af 	stp	x15, x8, [x13]
    402028c4:	f90011aa 	str	x10, [x13, #32]
    402028c8:	3900216c 	strb	w12, [x11, #8]
    402028cc:	eb0901df 	cmp	x14, x9
    402028d0:	54000081 	b.ne	402028e0 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x378>  // b.any
    402028d4:	92400548 	and	x8, x10, #0x3
    402028d8:	f100051f 	cmp	x8, #0x1
    402028dc:	54fff6c0 	b.eq	402027b4 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x24c>  // b.none
    402028e0:	528001a0 	mov	w0, #0xd                   	// #13
    402028e4:	97fffd52 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    402028e8:	52800140 	mov	w0, #0xa                   	// #10
    402028ec:	97fffd50 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    402028f0:	52800020 	mov	w0, #0x1                   	// #1
    402028f4:	97fffd4e 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    402028f8:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    402028fc:	91056508 	add	x8, x8, #0x159
    40202900:	39400109 	ldrb	w9, [x8]
    40202904:	7100053f 	cmp	w9, #0x1
    40202908:	54000701 	b.ne	402029e8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x480>  // b.any
    4020290c:	39400509 	ldrb	w9, [x8, #1]
    40202910:	360006c9 	tbz	w9, #0, 402029e8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x480>
    40202914:	39400908 	ldrb	w8, [x8, #2]
    40202918:	36000688 	tbz	w8, #0, 402029e8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x480>
    4020291c:	d503201f 	nop
    40202920:	10014308 	adr	x8, 40205180 <_ZN11jnox_kernel14ordinary_mutex5BATCH17h6ddfd88359c843a2E>
    40202924:	f940090b 	ldr	x11, [x8, #16]
    40202928:	f940050a 	ldr	x10, [x8, #8]
    4020292c:	f9400114 	ldr	x20, [x8]
    40202930:	a9002bf4 	stp	x20, x10, [sp]
    40202934:	d503201f 	nop
    40202938:	1001c788 	adr	x8, 40206228 <_ZN11jnox_kernel14ordinary_mutex6RESULT17h0c78663054aba51aE>
    4020293c:	f9400909 	ldr	x9, [x8, #16]
    40202940:	f940050a 	ldr	x10, [x8, #8]
    40202944:	f9400108 	ldr	x8, [x8]
    40202948:	a90123eb 	stp	x11, x8, [sp, #16]
    4020294c:	a90227ea 	stp	x10, x9, [sp, #32]
    40202950:	d503201f 	nop
    40202954:	100a97e8 	adr	x8, 40217c50 <_ZN11jnox_kernel14ordinary_mutex8MED_READ17hd3c9a8ee9446ee10E>
    40202958:	f9400115 	ldr	x21, [x8]
    4020295c:	d503201f 	nop
    40202960:	10014617 	adr	x23, 40205220 <_ZN11jnox_kernel14ordinary_mutex6CHUNKS17h3cec01e2eeeb4508E.0>
    40202964:	f9400516 	ldr	x22, [x8, #8]
    40202968:	c8dffee8 	ldar	x8, [x23]
    4020296c:	f104011f 	cmp	x8, #0x100
    40202970:	54000341 	b.ne	402029d8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x470>  // b.any
    40202974:	910003e0 	mov	x0, sp
    40202978:	910063e1 	add	x1, sp, #0x18
    4020297c:	52800302 	mov	w2, #0x18                  	// #24
    40202980:	940004c0 	bl	40203c80 <memcmp>
    40202984:	350002a0 	cbnz	w0, 402029d8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x470>
    40202988:	f100069f 	cmp	x20, #0x1
    4020298c:	54000261 	b.ne	402029d8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x470>  // b.any
    40202990:	c8dffee8 	ldar	x8, [x23]
    40202994:	eb0802df 	cmp	x22, x8
    40202998:	fa410aa0 	ccmp	x21, #0x1, #0x0, eq  // eq = none
    4020299c:	540001e1 	b.ne	402029d8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x470>  // b.any
    402029a0:	2a1f03e8 	mov	w8, wzr
    402029a4:	aa1f03ea 	mov	x10, xzr
    402029a8:	2a0803e9 	mov	w9, w8
    402029ac:	d37ced48 	lsl	x8, x10, #4
    402029b0:	f8686a68 	ldr	x8, [x19, x8]
    402029b4:	b5000128 	cbnz	x8, 402029d8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x470>
    402029b8:	52800028 	mov	w8, #0x1                   	// #1
    402029bc:	5280002a 	mov	w10, #0x1                   	// #1
    402029c0:	3607ff49 	tbz	w9, #0, 402029a8 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x440>
    402029c4:	52800088 	mov	w8, #0x4                   	// #4
    402029c8:	a90323ff 	stp	xzr, x8, [sp, #48]
    402029cc:	9100c3e0 	add	x0, sp, #0x30
    402029d0:	9400007b 	bl	40202bbc <_ZN4core4iter6traits8iterator8Iterator3any17hfa76168ae744d62fE>
    402029d4:	36000260 	tbz	w0, #0, 40202a20 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x4b8>
    402029d8:	52800240 	mov	w0, #0x12                  	// #18
    402029dc:	97fffd14 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    402029e0:	52800100 	mov	w0, #0x8                   	// #8
    402029e4:	97fffd12 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    402029e8:	528001e0 	mov	w0, #0xf                   	// #15
    402029ec:	97fffd10 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    402029f0:	528000e0 	mov	w0, #0x7                   	// #7
    402029f4:	97fffd0e 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    402029f8:	528000c0 	mov	w0, #0x6                   	// #6
    402029fc:	97fffd0c 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40202a00:	d503201f 	nop
    40202a04:	1000d0a2 	adr	x2, 40204418 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0xa8>
    40202a08:	aa1803e0 	mov	x0, x24
    40202a0c:	52800081 	mov	w1, #0x4                   	// #4
    40202a10:	940001f9 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40202a14:	52800080 	mov	w0, #0x4                   	// #4
    40202a18:	97fffd05 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40202a1c:	94000003 	bl	40202a28 <_ZN11jnox_kernel14ordinary_mutex7request28_$u7b$$u7b$closure$u7d$$u7d$17hc443835555614997E>
    40202a20:	aa1f03e0 	mov	x0, xzr
    40202a24:	97fffd02 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

0000000040202a28 <_ZN11jnox_kernel14ordinary_mutex7request28_$u7b$$u7b$closure$u7d$$u7d$17hc443835555614997E>:
    40202a28:	f81f0ffe 	str	x30, [sp, #-16]!
    40202a2c:	528001a0 	mov	w0, #0xd                   	// #13
    40202a30:	97fffcff 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

0000000040202a34 <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E>:
    40202a34:	f81d0ffe 	str	x30, [sp, #-48]!
    40202a38:	a90157f6 	stp	x22, x21, [sp, #16]
    40202a3c:	a9024ff4 	stp	x20, x19, [sp, #32]
    40202a40:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202a44:	f9400108 	ldr	x8, [x8]
    40202a48:	f100091f 	cmp	x8, #0x2
    40202a4c:	54000b40 	b.eq	40202bb4 <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x180>  // b.none
    40202a50:	aa0003f3 	mov	x19, x0
    40202a54:	97fffdd3 	bl	402021a0 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17had12d2d094a825fcE>
    40202a58:	5280018a 	mov	w10, #0xc                   	// #12
    40202a5c:	72a1002a 	movk	w10, #0x801, lsl #16
    40202a60:	b9400149 	ldr	w9, [x10]
    40202a64:	d53be228 	mrs	x8, cntp_ctl_el0
    40202a68:	d53be256 	mrs	x22, cntp_cval_el0
    40202a6c:	d51be23f 	msr	cntp_ctl_el0, xzr
    40202a70:	d5033fdf 	isb
    40202a74:	f000000b 	adrp	x11, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202a78:	9107016b 	add	x11, x11, #0x1c0
    40202a7c:	a9002169 	stp	x9, x8, [x11]
    40202a80:	f9000976 	str	x22, [x11, #16]
    40202a84:	b9000549 	str	w9, [x10, #4]
    40202a88:	d5033f9f 	dsb	sy
    40202a8c:	d5033fdf 	isb
    40202a90:	f000000a 	adrp	x10, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202a94:	3945614a 	ldrb	w10, [x10, #344]
    40202a98:	360008aa 	tbz	w10, #0, 40202bac <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x178>
    40202a9c:	12002529 	and	w9, w9, #0x3ff
    40202aa0:	7100793f 	cmp	w9, #0x1e
    40202aa4:	54000841 	b.ne	40202bac <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x178>  // b.any
    40202aa8:	f0000009 	adrp	x9, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202aac:	39456529 	ldrb	w9, [x9, #345]
    40202ab0:	370007e9 	tbnz	w9, #0, 40202bac <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x178>
    40202ab4:	92400908 	and	x8, x8, #0x7
    40202ab8:	f100151f 	cmp	x8, #0x5
    40202abc:	54000781 	b.ne	40202bac <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x178>  // b.any
    40202ac0:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202ac4:	f940d508 	ldr	x8, [x8, #424]
    40202ac8:	eb0802df 	cmp	x22, x8
    40202acc:	54000701 	b.ne	40202bac <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x178>  // b.any
    40202ad0:	aa0003f4 	mov	x20, x0
    40202ad4:	d503201f 	nop
    40202ad8:	10012955 	adr	x21, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202adc:	52800028 	mov	w8, #0x1                   	// #1
    40202ae0:	390566a8 	strb	w8, [x21, #345]
    40202ae4:	aa1503e0 	mov	x0, x21
    40202ae8:	aa1403e1 	mov	x1, x20
    40202aec:	52800022 	mov	w2, #0x1                   	// #1
    40202af0:	97fffe82 	bl	402024f8 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E>
    40202af4:	aa1503e0 	mov	x0, x21
    40202af8:	52800041 	mov	w1, #0x2                   	// #2
    40202afc:	2a1f03e2 	mov	w2, wzr
    40202b00:	97fffe7e 	bl	402024f8 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E>
    40202b04:	aa1503e0 	mov	x0, x21
    40202b08:	52800021 	mov	w1, #0x1                   	// #1
    40202b0c:	2a1f03e2 	mov	w2, wzr
    40202b10:	97fffe7a 	bl	402024f8 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17h033ffd1e1eaaec88E>
    40202b14:	aa1503e0 	mov	x0, x21
    40202b18:	97fffdc4 	bl	40202228 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17he6cd7798df38ede5E>
    40202b1c:	aa0003f5 	mov	x21, x0
    40202b20:	528000a0 	mov	w0, #0x5                   	// #5
    40202b24:	aa1f03e1 	mov	x1, xzr
    40202b28:	aa1403e2 	mov	x2, x20
    40202b2c:	aa1303e3 	mov	x3, x19
    40202b30:	aa1503e4 	mov	x4, x21
    40202b34:	aa1f03e5 	mov	x5, xzr
    40202b38:	97fffde0 	bl	402022b8 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h9ad81cb9efab5ab5E>
    40202b3c:	b5000354 	cbnz	x20, 40202ba4 <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x170>
    40202b40:	d503201f 	nop
    40202b44:	1009b7e8 	adr	x8, 40216240 <_ZN11jnox_kernel14ordinary_mutex7IN_WORK17h3cf0d660ecd4af71E.0>
    40202b48:	c8dffd08 	ldar	x8, [x8]
    40202b4c:	f100051f 	cmp	x8, #0x1
    40202b50:	540002a1 	b.ne	40202ba4 <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x170>  // b.any
    40202b54:	f9409e68 	ldr	x8, [x19, #312]
    40202b58:	eb16011f 	cmp	x8, x22
    40202b5c:	54000243 	b.cc	40202ba4 <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x170>  // b.lo, b.ul, b.last
    40202b60:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202b64:	91004108 	add	x8, x8, #0x10
    40202b68:	f9400109 	ldr	x9, [x8]
    40202b6c:	f100053f 	cmp	x9, #0x1
    40202b70:	540001a1 	b.ne	40202ba4 <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x170>  // b.any
    40202b74:	f9400508 	ldr	x8, [x8, #8]
    40202b78:	b5000168 	cbnz	x8, 40202ba4 <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x170>
    40202b7c:	d503201f 	nop
    40202b80:	10013508 	adr	x8, 40205220 <_ZN11jnox_kernel14ordinary_mutex6CHUNKS17h3cec01e2eeeb4508E.0>
    40202b84:	c8dffd08 	ldar	x8, [x8]
    40202b88:	f101fd1f 	cmp	x8, #0x7f
    40202b8c:	540000c8 	b.hi	40202ba4 <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x170>  // b.pmore
    40202b90:	aa1503e0 	mov	x0, x21
    40202b94:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40202b98:	a94157f6 	ldp	x22, x21, [sp, #16]
    40202b9c:	f84307fe 	ldr	x30, [sp], #48
    40202ba0:	d65f03c0 	ret
    40202ba4:	52800200 	mov	w0, #0x10                  	// #16
    40202ba8:	97fffca1 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40202bac:	528001c0 	mov	w0, #0xe                   	// #14
    40202bb0:	97fffc9f 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40202bb4:	52800020 	mov	w0, #0x1                   	// #1
    40202bb8:	97fffc9d 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

0000000040202bbc <_ZN4core4iter6traits8iterator8Iterator3any17hfa76168ae744d62fE>:
    40202bbc:	f81a0ffe 	str	x30, [sp, #-96]!
    40202bc0:	a9016ffc 	stp	x28, x27, [sp, #16]
    40202bc4:	a90267fa 	stp	x26, x25, [sp, #32]
    40202bc8:	a9035ff8 	stp	x24, x23, [sp, #48]
    40202bcc:	a90457f6 	stp	x22, x21, [sp, #64]
    40202bd0:	a9054ff4 	stp	x20, x19, [sp, #80]
    40202bd4:	aa0003f3 	mov	x19, x0
    40202bd8:	d503201f 	nop
    40202bdc:	10012134 	adr	x20, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17hb4c8ea0de50dd3d6E>
    40202be0:	52800088 	mov	w8, #0x4                   	// #4
    40202be4:	a9405819 	ldp	x25, x22, [x0]
    40202be8:	eb1902df 	cmp	x22, x25
    40202bec:	9a9982d7 	csel	x23, x22, x25, hi  // hi = pmore
    40202bf0:	8b191289 	add	x9, x20, x25, lsl #4
    40202bf4:	f100133f 	cmp	x25, #0x4
    40202bf8:	9a888335 	csel	x21, x25, x8, hi  // hi = pmore
    40202bfc:	9102813a 	add	x26, x9, #0xa0
    40202c00:	910033fb 	add	x27, sp, #0xc
    40202c04:	d000001c 	adrp	x28, 40204000 <memset+0x14c>
    40202c08:	9103df9c 	add	x28, x28, #0xf7
    40202c0c:	eb1902ff 	cmp	x23, x25
    40202c10:	54000240 	b.eq	40202c58 <_ZN4core4iter6traits8iterator8Iterator3any17hfa76168ae744d62fE+0x9c>  // b.none
    40202c14:	aa1903f8 	mov	x24, x25
    40202c18:	91000739 	add	x25, x25, #0x1
    40202c1c:	f9000279 	str	x25, [x19]
    40202c20:	eb1802bf 	cmp	x21, x24
    40202c24:	540002e0 	b.eq	40202c80 <_ZN4core4iter6traits8iterator8Iterator3any17hfa76168ae744d62fE+0xc4>  // b.none
    40202c28:	f8410748 	ldr	x8, [x26], #16
    40202c2c:	b5000188 	cbnz	x8, 40202c5c <_ZN4core4iter6traits8iterator8Iterator3any17hfa76168ae744d62fE+0xa0>
    40202c30:	aa1403e0 	mov	x0, x20
    40202c34:	97fff5d7 	bl	40200390 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.5430753883208388470>
    40202c38:	36000120 	tbz	w0, #0, 40202c5c <_ZN4core4iter6traits8iterator8Iterator3any17hfa76168ae744d62fE+0xa0>
    40202c3c:	d348fc08 	lsr	x8, x0, #8
    40202c40:	b9000fe8 	str	w8, [sp, #12]
    40202c44:	38786b68 	ldrb	w8, [x27, x24]
    40202c48:	38786b89 	ldrb	w9, [x28, x24]
    40202c4c:	6b09011f 	cmp	w8, w9
    40202c50:	54fffde0 	b.eq	40202c0c <_ZN4core4iter6traits8iterator8Iterator3any17hfa76168ae744d62fE+0x50>  // b.none
    40202c54:	14000002 	b	40202c5c <_ZN4core4iter6traits8iterator8Iterator3any17hfa76168ae744d62fE+0xa0>
    40202c58:	aa1703f8 	mov	x24, x23
    40202c5c:	eb16031f 	cmp	x24, x22
    40202c60:	1a9f27e0 	cset	w0, cc  // cc = lo, ul, last
    40202c64:	a9454ff4 	ldp	x20, x19, [sp, #80]
    40202c68:	a94457f6 	ldp	x22, x21, [sp, #64]
    40202c6c:	a9435ff8 	ldp	x24, x23, [sp, #48]
    40202c70:	a94267fa 	ldp	x26, x25, [sp, #32]
    40202c74:	a9416ffc 	ldp	x28, x27, [sp, #16]
    40202c78:	f84607fe 	ldr	x30, [sp], #96
    40202c7c:	d65f03c0 	ret
    40202c80:	d503201f 	nop
    40202c84:	1000bd62 	adr	x2, 40204430 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0xc0>
    40202c88:	aa1503e0 	mov	x0, x21
    40202c8c:	52800081 	mov	w1, #0x4                   	// #4
    40202c90:	94000159 	bl	402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040202c94 <mutex_batch_compute>:
    40202c94:	d10083ff 	sub	sp, sp, #0x20
    40202c98:	f9000bfe 	str	x30, [sp, #16]
    40202c9c:	aa0803e9 	mov	x9, x8
    40202ca0:	aa1f03ea 	mov	x10, xzr
    40202ca4:	aa1f03eb 	mov	x11, xzr
    40202ca8:	aa1f03e8 	mov	x8, xzr
    40202cac:	d503201f 	nop
    40202cb0:	1009ac8c 	adr	x12, 40216240 <_ZN11jnox_kernel14ordinary_mutex7IN_WORK17h3cf0d660ecd4af71E.0>
    40202cb4:	d503201f 	nop
    40202cb8:	1000b5cd 	adr	x13, 40204370 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE>
    40202cbc:	5280002f 	mov	w15, #0x1                   	// #1
    40202cc0:	d503201f 	nop
    40202cc4:	10012b2e 	adr	x14, 40205228 <_ZN11jnox_kernel14ordinary_mutex6LEDGER17h8bea2891e2f33014E>
    40202cc8:	c89ffd8f 	stlr	x15, [x12]
    40202ccc:	d503201f 	nop
    40202cd0:	10012a8f 	adr	x15, 40205220 <_ZN11jnox_kernel14ordinary_mutex6CHUNKS17h3cec01e2eeeb4508E.0>
    40202cd4:	52802010 	mov	w16, #0x100                 	// #256
    40202cd8:	92400d51 	and	x17, x10, #0xf
    40202cdc:	387169b1 	ldrb	w17, [x13, x17]
    40202ce0:	8b11016b 	add	x11, x11, x17
    40202ce4:	9100054a 	add	x10, x10, #0x1
    40202ce8:	71000610 	subs	w16, w16, #0x1
    40202cec:	54ffff61 	b.ne	40202cd8 <mutex_batch_compute+0x44>  // b.any
    40202cf0:	91000510 	add	x16, x8, #0x1
    40202cf4:	8b0811d1 	add	x17, x14, x8, lsl #4
    40202cf8:	f9000fea 	str	x10, [sp, #24]
    40202cfc:	f90007eb 	str	x11, [sp, #8]
    40202d00:	f9400ff2 	ldr	x18, [sp, #24]
    40202d04:	f9000232 	str	x18, [x17]
    40202d08:	f94007f2 	ldr	x18, [sp, #8]
    40202d0c:	f9000632 	str	x18, [x17, #8]
    40202d10:	c89ffdf0 	stlr	x16, [x15]
    40202d14:	f101fd1f 	cmp	x8, #0x7f
    40202d18:	540000a0 	b.eq	40202d2c <mutex_batch_compute+0x98>  // b.none
    40202d1c:	f103fd1f 	cmp	x8, #0xff
    40202d20:	aa1003e8 	mov	x8, x16
    40202d24:	54fffd81 	b.ne	40202cd4 <mutex_batch_compute+0x40>  // b.any
    40202d28:	14000008 	b	40202d48 <mutex_batch_compute+0xb4>
    40202d2c:	aa1f03e0 	mov	x0, xzr
    40202d30:	52800068 	mov	w8, #0x3                   	// #3
    40202d34:	d4000001 	svc	#0x0
    40202d38:	52801008 	mov	w8, #0x80                  	// #128
    40202d3c:	b4fffcc0 	cbz	x0, 40202cd4 <mutex_batch_compute+0x40>
    40202d40:	52800160 	mov	w0, #0xb                   	// #11
    40202d44:	97fffc3a 	bl	40201e2c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40202d48:	c89ffd9f 	stlr	xzr, [x12]
    40202d4c:	a9002d2a 	stp	x10, x11, [x9]
    40202d50:	f9400bfe 	ldr	x30, [sp, #16]
    40202d54:	910083ff 	add	sp, sp, #0x20
    40202d58:	d65f03c0 	ret

0000000040202d5c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral>:
    40202d5c:	d101c3ff 	sub	sp, sp, #0x70
    40202d60:	a9017bfd 	stp	x29, x30, [sp, #16]
    40202d64:	a9026ffc 	stp	x28, x27, [sp, #32]
    40202d68:	a90367fa 	stp	x26, x25, [sp, #48]
    40202d6c:	a9045ff8 	stp	x24, x23, [sp, #64]
    40202d70:	a90557f6 	stp	x22, x21, [sp, #80]
    40202d74:	a9064ff4 	stp	x20, x19, [sp, #96]
    40202d78:	910043fd 	add	x29, sp, #0x10
    40202d7c:	b940101a 	ldr	w26, [x0, #16]
    40202d80:	52a00229 	mov	w9, #0x110000              	// #1114112
    40202d84:	aa0503f3 	mov	x19, x5
    40202d88:	aa0403fc 	mov	x28, x4
    40202d8c:	aa0303f6 	mov	x22, x3
    40202d90:	aa0003f5 	mov	x21, x0
    40202d94:	926b0348 	and	x8, x26, #0x200000
    40202d98:	d355574a 	ubfx	x10, x26, #21, #1
    40202d9c:	7100011f 	cmp	w8, #0x0
    40202da0:	52800568 	mov	w8, #0x2b                  	// #43
    40202da4:	1a880128 	csel	w8, w9, w8, eq  // eq = none
    40202da8:	7100003f 	cmp	w1, #0x0
    40202dac:	528005a9 	mov	w9, #0x2d                  	// #45
    40202db0:	9a9f154a 	csinc	x10, x10, xzr, ne  // ne = any
    40202db4:	1a891118 	csel	w24, w8, w9, ne  // ne = any
    40202db8:	8b05015b 	add	x27, x10, x5
    40202dbc:	37b8033a 	tbnz	w26, #23, 40202e20 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0xc4>
    40202dc0:	aa1f03f7 	mov	x23, xzr
    40202dc4:	79402ab4 	ldrh	w20, [x21, #20]
    40202dc8:	eb14037f 	cmp	x27, x20
    40202dcc:	54001503 	b.cc	4020306c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x310>  // b.lo, b.ul, b.last
    40202dd0:	a94056b9 	ldp	x25, x21, [x21]
    40202dd4:	2a1803e2 	mov	w2, w24
    40202dd8:	aa1703e3 	mov	x3, x23
    40202ddc:	aa1603e4 	mov	x4, x22
    40202de0:	aa1903e0 	mov	x0, x25
    40202de4:	aa1503e1 	mov	x1, x21
    40202de8:	9400032f 	bl	40203aa4 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix>
    40202dec:	37001d60 	tbnz	w0, #0, 40203198 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    40202df0:	f9400ea3 	ldr	x3, [x21, #24]
    40202df4:	aa1903e0 	mov	x0, x25
    40202df8:	aa1c03e1 	mov	x1, x28
    40202dfc:	aa1303e2 	mov	x2, x19
    40202e00:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40202e04:	a94557f6 	ldp	x22, x21, [sp, #80]
    40202e08:	a9445ff8 	ldp	x24, x23, [sp, #64]
    40202e0c:	a94367fa 	ldp	x26, x25, [sp, #48]
    40202e10:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40202e14:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40202e18:	9101c3ff 	add	sp, sp, #0x70
    40202e1c:	d61f0060 	br	x3
    40202e20:	aa0203f7 	mov	x23, x2
    40202e24:	f10082df 	cmp	x22, #0x20
    40202e28:	540000e2 	b.cs	40202e44 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0xe8>  // b.hs, b.nlast
    40202e2c:	b4000156 	cbz	x22, 40202e54 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0xf8>
    40202e30:	f10022df 	cmp	x22, #0x8
    40202e34:	54000142 	b.cs	40202e5c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x100>  // b.hs, b.nlast
    40202e38:	aa1f03e8 	mov	x8, xzr
    40202e3c:	aa1f03e0 	mov	x0, xzr
    40202e40:	14000080 	b	40203040 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x2e4>
    40202e44:	aa1703e0 	mov	x0, x23
    40202e48:	aa1603e1 	mov	x1, x22
    40202e4c:	94000102 	bl	40203254 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars>
    40202e50:	14000083 	b	4020305c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x300>
    40202e54:	aa1f03e0 	mov	x0, xzr
    40202e58:	14000081 	b	4020305c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x300>
    40202e5c:	aa1703ea 	mov	x10, x23
    40202e60:	39400ae9 	ldrb	w9, [x23, #2]
    40202e64:	394006e8 	ldrb	w8, [x23, #1]
    40202e68:	38404d4b 	ldrb	w11, [x10, #4]!
    40202e6c:	3940094c 	ldrb	w12, [x10, #2]
    40202e70:	394002ed 	ldrb	w13, [x23]
    40202e74:	39400eee 	ldrb	w14, [x23, #3]
    40202e78:	d370bd29 	lsl	x9, x9, #16
    40202e7c:	394016ef 	ldrb	w15, [x23, #5]
    40202e80:	39400d4a 	ldrb	w10, [x10, #3]
    40202e84:	53103d8c 	lsl	w12, w12, #16
    40202e88:	aa0821a8 	orr	x8, x13, x8, lsl #8
    40202e8c:	aa0e6129 	orr	x9, x9, x14, lsl #24
    40202e90:	0f05e7e4 	movi	v4.8b, #0xbf
    40202e94:	2a0f216b 	orr	w11, w11, w15, lsl #8
    40202e98:	2a0a618a 	orr	w10, w12, w10, lsl #24
    40202e9c:	aa080128 	orr	x8, x9, x8
    40202ea0:	2a0b0149 	orr	w9, w10, w11
    40202ea4:	aa098108 	orr	x8, x8, x9, lsl #32
    40202ea8:	9e670100 	fmov	d0, x8
    40202eac:	52800028 	mov	w8, #0x1                   	// #1
    40202eb0:	4e080d03 	dup	v3.2d, x8
    40202eb4:	927d06c8 	and	x8, x22, #0x18
    40202eb8:	f100211f 	cmp	x8, #0x8
    40202ebc:	0e243400 	cmgt	v0.8b, v0.8b, v4.8b
    40202ec0:	2f08a400 	uxtl	v0.8h, v0.8b
    40202ec4:	6f10a401 	uxtl2	v1.4s, v0.8h
    40202ec8:	2f10a400 	uxtl	v0.4s, v0.4h
    40202ecc:	6f20a422 	uxtl2	v2.2d, v1.4s
    40202ed0:	2f20a421 	uxtl	v1.2d, v1.2s
    40202ed4:	6f20a405 	uxtl2	v5.2d, v0.4s
    40202ed8:	2f20a406 	uxtl	v6.2d, v0.2s
    40202edc:	4e231c40 	and	v0.16b, v2.16b, v3.16b
    40202ee0:	4e231c22 	and	v2.16b, v1.16b, v3.16b
    40202ee4:	4e231ca1 	and	v1.16b, v5.16b, v3.16b
    40202ee8:	4e231cc3 	and	v3.16b, v6.16b, v3.16b
    40202eec:	540009c0 	b.eq	40203024 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x2c8>  // b.none
    40202ef0:	aa1703e9 	mov	x9, x23
    40202ef4:	f100411f 	cmp	x8, #0x10
    40202ef8:	38408d2a 	ldrb	w10, [x9, #8]!
    40202efc:	3940052b 	ldrb	w11, [x9, #1]
    40202f00:	39400d2c 	ldrb	w12, [x9, #3]
    40202f04:	3940092d 	ldrb	w13, [x9, #2]
    40202f08:	3940152e 	ldrb	w14, [x9, #5]
    40202f0c:	38404d2f 	ldrb	w15, [x9, #4]!
    40202f10:	39400930 	ldrb	w16, [x9, #2]
    40202f14:	39400d29 	ldrb	w9, [x9, #3]
    40202f18:	d370bdad 	lsl	x13, x13, #16
    40202f1c:	aa0b214a 	orr	x10, x10, x11, lsl #8
    40202f20:	53103e10 	lsl	w16, w16, #16
    40202f24:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40202f28:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40202f2c:	2a096209 	orr	w9, w16, w9, lsl #24
    40202f30:	aa0a018a 	orr	x10, x12, x10
    40202f34:	2a0b0129 	orr	w9, w9, w11
    40202f38:	aa098149 	orr	x9, x10, x9, lsl #32
    40202f3c:	9e670125 	fmov	d5, x9
    40202f40:	52800029 	mov	w9, #0x1                   	// #1
    40202f44:	4e080d26 	dup	v6.2d, x9
    40202f48:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40202f4c:	2f08a484 	uxtl	v4.8h, v4.8b
    40202f50:	6f10a485 	uxtl2	v5.4s, v4.8h
    40202f54:	2f10a484 	uxtl	v4.4s, v4.4h
    40202f58:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40202f5c:	2f20a490 	uxtl	v16.2d, v4.2s
    40202f60:	6f20a484 	uxtl2	v4.2d, v4.4s
    40202f64:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40202f68:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40202f6c:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40202f70:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40202f74:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40202f78:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40202f7c:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40202f80:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40202f84:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40202f88:	540004e0 	b.eq	40203024 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x2c8>  // b.none
    40202f8c:	aa1703e9 	mov	x9, x23
    40202f90:	0f05e7e4 	movi	v4.8b, #0xbf
    40202f94:	38410d2a 	ldrb	w10, [x9, #16]!
    40202f98:	3940052b 	ldrb	w11, [x9, #1]
    40202f9c:	39400d2c 	ldrb	w12, [x9, #3]
    40202fa0:	3940092d 	ldrb	w13, [x9, #2]
    40202fa4:	3940152e 	ldrb	w14, [x9, #5]
    40202fa8:	38404d2f 	ldrb	w15, [x9, #4]!
    40202fac:	39400930 	ldrb	w16, [x9, #2]
    40202fb0:	39400d29 	ldrb	w9, [x9, #3]
    40202fb4:	d370bdad 	lsl	x13, x13, #16
    40202fb8:	aa0b214a 	orr	x10, x10, x11, lsl #8
    40202fbc:	53103e10 	lsl	w16, w16, #16
    40202fc0:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40202fc4:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40202fc8:	2a096209 	orr	w9, w16, w9, lsl #24
    40202fcc:	aa0a018a 	orr	x10, x12, x10
    40202fd0:	2a0b0129 	orr	w9, w9, w11
    40202fd4:	aa098149 	orr	x9, x10, x9, lsl #32
    40202fd8:	9e670125 	fmov	d5, x9
    40202fdc:	52800029 	mov	w9, #0x1                   	// #1
    40202fe0:	4e080d26 	dup	v6.2d, x9
    40202fe4:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    40202fe8:	2f08a484 	uxtl	v4.8h, v4.8b
    40202fec:	6f10a485 	uxtl2	v5.4s, v4.8h
    40202ff0:	2f10a484 	uxtl	v4.4s, v4.4h
    40202ff4:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    40202ff8:	2f20a490 	uxtl	v16.2d, v4.2s
    40202ffc:	6f20a484 	uxtl2	v4.2d, v4.4s
    40203000:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40203004:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    40203008:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    4020300c:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40203010:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40203014:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40203018:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    4020301c:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40203020:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40203024:	4ee28462 	add	v2.2d, v3.2d, v2.2d
    40203028:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    4020302c:	eb0802df 	cmp	x22, x8
    40203030:	4ee08440 	add	v0.2d, v2.2d, v0.2d
    40203034:	5ef1b800 	addp	d0, v0.2d
    40203038:	9e660000 	fmov	x0, d0
    4020303c:	54000100 	b.eq	4020305c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x300>  // b.none
    40203040:	cb0802c9 	sub	x9, x22, x8
    40203044:	8b0802e8 	add	x8, x23, x8
    40203048:	38c0150a 	ldrsb	w10, [x8], #1
    4020304c:	3101055f 	cmn	w10, #0x41
    40203050:	9a80d400 	cinc	x0, x0, gt
    40203054:	f1000529 	subs	x9, x9, #0x1
    40203058:	54ffff81 	b.ne	40203048 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x2ec>  // b.any
    4020305c:	8b1b001b 	add	x27, x0, x27
    40203060:	79402ab4 	ldrh	w20, [x21, #20]
    40203064:	eb14037f 	cmp	x27, x20
    40203068:	54ffeb42 	b.cs	40202dd0 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x74>  // b.hs, b.nlast
    4020306c:	f90007fc 	str	x28, [sp, #8]
    40203070:	37c0011a 	tbnz	w26, #24, 40203090 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x334>
    40203074:	531d7b48 	ubfx	w8, w26, #29, #2
    40203078:	4b1b029b 	sub	w27, w20, w27
    4020307c:	7100051f 	cmp	w8, #0x1
    40203080:	540003cc 	b.gt	402030f8 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x39c>
    40203084:	35000568 	cbnz	w8, 40203130 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3d4>
    40203088:	2a1f03fc 	mov	w28, wzr
    4020308c:	1400002a 	b	40203134 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3d8>
    40203090:	a940f2ba 	ldp	x26, x28, [x21, #8]
    40203094:	52b3fc08 	mov	w8, #0x9fe00000            	// #-1612709888
    40203098:	f94002b9 	ldr	x25, [x21]
    4020309c:	2a1803e2 	mov	w2, w24
    402030a0:	aa1703e3 	mov	x3, x23
    402030a4:	aa1603e4 	mov	x4, x22
    402030a8:	0a080388 	and	w8, w28, w8
    402030ac:	aa1903e0 	mov	x0, x25
    402030b0:	aa1a03e1 	mov	x1, x26
    402030b4:	321c0508 	orr	w8, w8, #0x30
    402030b8:	32030108 	orr	w8, w8, #0x20000000
    402030bc:	b90012a8 	str	w8, [x21, #16]
    402030c0:	94000279 	bl	40203aa4 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix>
    402030c4:	370006a0 	tbnz	w0, #0, 40203198 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    402030c8:	2a1f03f6 	mov	w22, wzr
    402030cc:	4b1b0294 	sub	w20, w20, w27
    402030d0:	12003ec8 	and	w8, w22, #0xffff
    402030d4:	6b34211f 	cmp	w8, w20, uxth
    402030d8:	540001a2 	b.cs	4020310c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3b0>  // b.hs, b.nlast
    402030dc:	f9401348 	ldr	x8, [x26, #32]
    402030e0:	aa1903e0 	mov	x0, x25
    402030e4:	52800601 	mov	w1, #0x30                  	// #48
    402030e8:	110006d6 	add	w22, w22, #0x1
    402030ec:	d63f0100 	blr	x8
    402030f0:	3607ff00 	tbz	w0, #0, 402030d0 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x374>
    402030f4:	14000029 	b	40203198 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    402030f8:	7100091f 	cmp	w8, #0x2
    402030fc:	2a1b03fc 	mov	w28, w27
    40203100:	540001a1 	b.ne	40203134 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3d8>  // b.any
    40203104:	53013f7c 	ubfx	w28, w27, #1, #15
    40203108:	1400000b 	b	40203134 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3d8>
    4020310c:	f9400f48 	ldr	x8, [x26, #24]
    40203110:	f94007e1 	ldr	x1, [sp, #8]
    40203114:	aa1903e0 	mov	x0, x25
    40203118:	aa1303e2 	mov	x2, x19
    4020311c:	d63f0100 	blr	x8
    40203120:	370003c0 	tbnz	w0, #0, 40203198 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    40203124:	2a1f03f3 	mov	w19, wzr
    40203128:	f9000abc 	str	x28, [x21, #16]
    4020312c:	1400001c 	b	4020319c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x440>
    40203130:	2a1b03fc 	mov	w28, w27
    40203134:	a94056b9 	ldp	x25, x21, [x21]
    40203138:	2a1f03f4 	mov	w20, wzr
    4020313c:	12003e88 	and	w8, w20, #0xffff
    40203140:	6b3c211f 	cmp	w8, w28, uxth
    40203144:	54000102 	b.cs	40203164 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x408>  // b.hs, b.nlast
    40203148:	f94012a8 	ldr	x8, [x21, #32]
    4020314c:	12005341 	and	w1, w26, #0x1fffff
    40203150:	aa1903e0 	mov	x0, x25
    40203154:	11000694 	add	w20, w20, #0x1
    40203158:	d63f0100 	blr	x8
    4020315c:	3607ff00 	tbz	w0, #0, 4020313c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3e0>
    40203160:	1400000e 	b	40203198 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    40203164:	aa1903e0 	mov	x0, x25
    40203168:	aa1503e1 	mov	x1, x21
    4020316c:	2a1803e2 	mov	w2, w24
    40203170:	aa1703e3 	mov	x3, x23
    40203174:	aa1603e4 	mov	x4, x22
    40203178:	9400024b 	bl	40203aa4 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix>
    4020317c:	370000e0 	tbnz	w0, #0, 40203198 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    40203180:	f9400ea8 	ldr	x8, [x21, #24]
    40203184:	f94007e1 	ldr	x1, [sp, #8]
    40203188:	aa1903e0 	mov	x0, x25
    4020318c:	aa1303e2 	mov	x2, x19
    40203190:	d63f0100 	blr	x8
    40203194:	36000160 	tbz	w0, #0, 402031c0 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x464>
    40203198:	52800033 	mov	w19, #0x1                   	// #1
    4020319c:	2a1303e0 	mov	w0, w19
    402031a0:	a9464ff4 	ldp	x20, x19, [sp, #96]
    402031a4:	a94557f6 	ldp	x22, x21, [sp, #80]
    402031a8:	a9445ff8 	ldp	x24, x23, [sp, #64]
    402031ac:	a94367fa 	ldp	x26, x25, [sp, #48]
    402031b0:	a9426ffc 	ldp	x28, x27, [sp, #32]
    402031b4:	a9417bfd 	ldp	x29, x30, [sp, #16]
    402031b8:	9101c3ff 	add	sp, sp, #0x70
    402031bc:	d65f03c0 	ret
    402031c0:	2a1f03f4 	mov	w20, wzr
    402031c4:	4b1c0376 	sub	w22, w27, w28
    402031c8:	12003e88 	and	w8, w20, #0xffff
    402031cc:	6b36211f 	cmp	w8, w22, uxth
    402031d0:	1a9f27f3 	cset	w19, cc  // cc = lo, ul, last
    402031d4:	54fffe42 	b.cs	4020319c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x440>  // b.hs, b.nlast
    402031d8:	f94012a8 	ldr	x8, [x21, #32]
    402031dc:	12005341 	and	w1, w26, #0x1fffff
    402031e0:	aa1903e0 	mov	x0, x25
    402031e4:	11000694 	add	w20, w20, #0x1
    402031e8:	d63f0100 	blr	x8
    402031ec:	3607fee0 	tbz	w0, #0, 402031c8 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x46c>
    402031f0:	17ffffeb 	b	4020319c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x440>

00000000402031f4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>:
    402031f4:	d10103ff 	sub	sp, sp, #0x40
    402031f8:	a9037bfd 	stp	x29, x30, [sp, #48]
    402031fc:	9100c3fd 	add	x29, sp, #0x30
    40203200:	910023e8 	add	x8, sp, #0x8
    40203204:	d503201f 	nop
    40203208:	10004929 	adr	x9, 40203b2c <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>
    4020320c:	a90007e0 	stp	x0, x1, [sp]
    40203210:	b0000000 	adrp	x0, 40204000 <memset+0x14c>
    40203214:	91017800 	add	x0, x0, #0x5e
    40203218:	a90127e8 	stp	x8, x9, [sp, #16]
    4020321c:	910003e8 	mov	x8, sp
    40203220:	910043e1 	add	x1, sp, #0x10
    40203224:	a90227e8 	stp	x8, x9, [sp, #32]
    40203228:	94000001 	bl	4020322c <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>

000000004020322c <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>:
    4020322c:	d10103ff 	sub	sp, sp, #0x40
    40203230:	a9037bfd 	stp	x29, x30, [sp, #48]
    40203234:	9100c3fd 	add	x29, sp, #0x30
    40203238:	910023e8 	add	x8, sp, #0x8
    4020323c:	a90087e0 	stp	x0, x1, [sp, #8]
    40203240:	910063e0 	add	x0, sp, #0x18
    40203244:	a9018be8 	stp	x8, x2, [sp, #24]
    40203248:	52800028 	mov	w8, #0x1                   	// #1
    4020324c:	790053e8 	strh	w8, [sp, #40]
    40203250:	97fff38c 	bl	40200080 <_RNvCsfLfy6EI15iL_7___rustc17rust_begin_unwind>

0000000040203254 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars>:
    40203254:	d10183ff 	sub	sp, sp, #0x60
    40203258:	fd0023ea 	str	d10, [sp, #64]
    4020325c:	6d0523e9 	stp	d9, d8, [sp, #80]
    40203260:	91001c08 	add	x8, x0, #0x7
    40203264:	927df10d 	and	x13, x8, #0xfffffffffffffff8
    40203268:	cb0001ac 	sub	x12, x13, x0
    4020326c:	eb0c002b 	subs	x11, x1, x12
    40203270:	540000e2 	b.cs	4020328c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x38>  // b.hs, b.nlast
    40203274:	b4000721 	cbz	x1, 40203358 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x104>
    40203278:	f100203f 	cmp	x1, #0x8
    4020327c:	54001b82 	b.cs	402035ec <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x398>  // b.hs, b.nlast
    40203280:	aa1f03e9 	mov	x9, xzr
    40203284:	aa1f03e8 	mov	x8, xzr
    40203288:	140001d2 	b	402039d0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x77c>
    4020328c:	d343fd69 	lsr	x9, x11, #3
    40203290:	b4ffff29 	cbz	x9, 40203274 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x20>
    40203294:	eb0001bf 	cmp	x13, x0
    40203298:	9240096a 	and	x10, x11, #0x7
    4020329c:	aa1f03e8 	mov	x8, xzr
    402032a0:	54000100 	b.eq	402032c0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x6c>  // b.none
    402032a4:	cb0d000d 	sub	x13, x0, x13
    402032a8:	aa0003ee 	mov	x14, x0
    402032ac:	38c015cf 	ldrsb	w15, [x14], #1
    402032b0:	310105ff 	cmn	w15, #0x41
    402032b4:	9a88d508 	cinc	x8, x8, gt
    402032b8:	b10005ad 	adds	x13, x13, #0x1
    402032bc:	54ffff83 	b.cc	402032ac <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x58>  // b.lo, b.ul, b.last
    402032c0:	8b0c000e 	add	x14, x0, x12
    402032c4:	b400056a 	cbz	x10, 40203370 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x11c>
    402032c8:	927ded6b 	and	x11, x11, #0x7ffffffffffffff8
    402032cc:	8b0b01cc 	add	x12, x14, x11
    402032d0:	39c0018b 	ldrsb	w11, [x12]
    402032d4:	3101057f 	cmn	w11, #0x41
    402032d8:	1a9fd7eb 	cset	w11, gt
    402032dc:	f100055f 	cmp	x10, #0x1
    402032e0:	540004a0 	b.eq	40203374 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    402032e4:	39c0058d 	ldrsb	w13, [x12, #1]
    402032e8:	310105bf 	cmn	w13, #0x41
    402032ec:	9a8bd56b 	cinc	x11, x11, gt
    402032f0:	f100095f 	cmp	x10, #0x2
    402032f4:	54000400 	b.eq	40203374 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    402032f8:	39c0098d 	ldrsb	w13, [x12, #2]
    402032fc:	310105bf 	cmn	w13, #0x41
    40203300:	9a8bd56b 	cinc	x11, x11, gt
    40203304:	f1000d5f 	cmp	x10, #0x3
    40203308:	54000360 	b.eq	40203374 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    4020330c:	39c00d8d 	ldrsb	w13, [x12, #3]
    40203310:	310105bf 	cmn	w13, #0x41
    40203314:	9a8bd56b 	cinc	x11, x11, gt
    40203318:	f100115f 	cmp	x10, #0x4
    4020331c:	540002c0 	b.eq	40203374 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    40203320:	39c0118d 	ldrsb	w13, [x12, #4]
    40203324:	310105bf 	cmn	w13, #0x41
    40203328:	9a8bd56b 	cinc	x11, x11, gt
    4020332c:	f100155f 	cmp	x10, #0x5
    40203330:	54000220 	b.eq	40203374 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    40203334:	39c0158d 	ldrsb	w13, [x12, #5]
    40203338:	310105bf 	cmn	w13, #0x41
    4020333c:	9a8bd56b 	cinc	x11, x11, gt
    40203340:	f100195f 	cmp	x10, #0x6
    40203344:	54000180 	b.eq	40203374 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    40203348:	39c0198a 	ldrsb	w10, [x12, #6]
    4020334c:	3101055f 	cmn	w10, #0x41
    40203350:	9a8bd56b 	cinc	x11, x11, gt
    40203354:	14000008 	b	40203374 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>
    40203358:	aa1f03e8 	mov	x8, xzr
    4020335c:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40203360:	aa0803e0 	mov	x0, x8
    40203364:	fd4023ea 	ldr	d10, [sp, #64]
    40203368:	910183ff 	add	sp, sp, #0x60
    4020336c:	d65f03c0 	ret
    40203370:	aa1f03eb 	mov	x11, xzr
    40203374:	4f00e420 	movi	v0.16b, #0x1
    40203378:	8b080168 	add	x8, x11, x8
    4020337c:	5280180a 	mov	w10, #0xc0                  	// #192
    40203380:	b20083eb 	mov	x11, #0x1000100010001       	// #281479271743489
    40203384:	1400000c 	b	402033b4 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x160>
    40203388:	aa1f03f1 	mov	x17, xzr
    4020338c:	d348fe2f 	lsr	x15, x17, #8
    40203390:	92009e30 	and	x16, x17, #0xff00ff00ff00ff
    40203394:	8b0e018e 	add	x14, x12, x14
    40203398:	cb0d0129 	sub	x9, x9, x13
    4020339c:	92009def 	and	x15, x15, #0xff00ff00ff00ff
    402033a0:	8b1001ef 	add	x15, x15, x16
    402033a4:	9b0b7df0 	mul	x16, x15, x11
    402033a8:	924005af 	and	x15, x13, #0x3
    402033ac:	8b50c108 	add	x8, x8, x16, lsr #48
    402033b0:	b5000d8f 	cbnz	x15, 40203560 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x30c>
    402033b4:	b4fffd49 	cbz	x9, 4020335c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x108>
    402033b8:	f103013f 	cmp	x9, #0xc0
    402033bc:	aa0e03ec 	mov	x12, x14
    402033c0:	9a8a312d 	csel	x13, x9, x10, cc  // cc = lo, ul, last
    402033c4:	d37df1ae 	lsl	x14, x13, #3
    402033c8:	f27b15d0 	ands	x16, x14, #0x7e0
    402033cc:	54fffde0 	b.eq	40203388 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x134>  // b.none
    402033d0:	d10081cf 	sub	x15, x14, #0x20
    402033d4:	f10181ff 	cmp	x15, #0x60
    402033d8:	54000082 	b.cs	402033e8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x194>  // b.hs, b.nlast
    402033dc:	aa1f03f1 	mov	x17, xzr
    402033e0:	aa0c03ef 	mov	x15, x12
    402033e4:	14000044 	b	402034f4 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x2a0>
    402033e8:	d345fdef 	lsr	x15, x15, #5
    402033ec:	6f00e401 	movi	v1.2d, #0x0
    402033f0:	6f00e402 	movi	v2.2d, #0x0
    402033f4:	91010180 	add	x0, x12, #0x40
    402033f8:	910005f1 	add	x17, x15, #0x1
    402033fc:	927ee632 	and	x18, x17, #0xffffffffffffffc
    40203400:	927ee621 	and	x1, x17, #0xffffffffffffffc
    40203404:	8b12158f 	add	x15, x12, x18, lsl #5
    40203408:	d1010002 	sub	x2, x0, #0x40
    4020340c:	4c400c10 	ld4	{v16.2d-v19.2d}, [x0]
    40203410:	f1001021 	subs	x1, x1, #0x4
    40203414:	91020000 	add	x0, x0, #0x80
    40203418:	4c400c43 	ld4	{v3.2d-v6.2d}, [x2]
    4020341c:	6e205a07 	mvn	v7.16b, v16.16b
    40203420:	6e205a35 	mvn	v21.16b, v17.16b
    40203424:	6e205a5a 	mvn	v26.16b, v18.16b
    40203428:	6e205876 	mvn	v22.16b, v3.16b
    4020342c:	6e205897 	mvn	v23.16b, v4.16b
    40203430:	6e2058b8 	mvn	v24.16b, v5.16b
    40203434:	6f7a0614 	ushr	v20.2d, v16.2d, #6
    40203438:	6f7a0639 	ushr	v25.2d, v17.2d, #6
    4020343c:	6f7a065b 	ushr	v27.2d, v18.2d, #6
    40203440:	6f7a047c 	ushr	v28.2d, v3.2d, #6
    40203444:	6f7a049d 	ushr	v29.2d, v4.2d, #6
    40203448:	6f7a04be 	ushr	v30.2d, v5.2d, #6
    4020344c:	6f7906d6 	ushr	v22.2d, v22.2d, #7
    40203450:	6f7906f7 	ushr	v23.2d, v23.2d, #7
    40203454:	6f790718 	ushr	v24.2d, v24.2d, #7
    40203458:	6f7904e7 	ushr	v7.2d, v7.2d, #7
    4020345c:	6f7906b5 	ushr	v21.2d, v21.2d, #7
    40203460:	6f79075a 	ushr	v26.2d, v26.2d, #7
    40203464:	6e205a7f 	mvn	v31.16b, v19.16b
    40203468:	6f7a0670 	ushr	v16.2d, v19.2d, #6
    4020346c:	6e2058d1 	mvn	v17.16b, v6.16b
    40203470:	4ebc1ed2 	orr	v18.16b, v22.16b, v28.16b
    40203474:	4ebd1ef3 	orr	v19.16b, v23.16b, v29.16b
    40203478:	4ebe1f16 	orr	v22.16b, v24.16b, v30.16b
    4020347c:	4eb41ce7 	orr	v7.16b, v7.16b, v20.16b
    40203480:	4eb91eb4 	orr	v20.16b, v21.16b, v25.16b
    40203484:	4ebb1f55 	orr	v21.16b, v26.16b, v27.16b
    40203488:	6f7a04c3 	ushr	v3.2d, v6.2d, #6
    4020348c:	6f7907e4 	ushr	v4.2d, v31.2d, #7
    40203490:	6f790625 	ushr	v5.2d, v17.2d, #7
    40203494:	4e201e46 	and	v6.16b, v18.16b, v0.16b
    40203498:	4e201e71 	and	v17.16b, v19.16b, v0.16b
    4020349c:	4e201ed2 	and	v18.16b, v22.16b, v0.16b
    402034a0:	4e201ce7 	and	v7.16b, v7.16b, v0.16b
    402034a4:	4e201e93 	and	v19.16b, v20.16b, v0.16b
    402034a8:	4e201eb4 	and	v20.16b, v21.16b, v0.16b
    402034ac:	4eb01c84 	orr	v4.16b, v4.16b, v16.16b
    402034b0:	4ea31ca3 	orr	v3.16b, v5.16b, v3.16b
    402034b4:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    402034b8:	4ef18646 	add	v6.2d, v18.2d, v17.2d
    402034bc:	4ee284e2 	add	v2.2d, v7.2d, v2.2d
    402034c0:	4ef38685 	add	v5.2d, v20.2d, v19.2d
    402034c4:	4e201c63 	and	v3.16b, v3.16b, v0.16b
    402034c8:	4e201c84 	and	v4.16b, v4.16b, v0.16b
    402034cc:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    402034d0:	4ee284a2 	add	v2.2d, v5.2d, v2.2d
    402034d4:	4ee18461 	add	v1.2d, v3.2d, v1.2d
    402034d8:	4ee28482 	add	v2.2d, v4.2d, v2.2d
    402034dc:	54fff961 	b.ne	40203408 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x1b4>  // b.any
    402034e0:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    402034e4:	eb12023f 	cmp	x17, x18
    402034e8:	5ef1b821 	addp	d1, v1.2d
    402034ec:	9e660031 	fmov	x17, d1
    402034f0:	54fff4e0 	b.eq	4020338c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x138>  // b.none
    402034f4:	8b100190 	add	x16, x12, x16
    402034f8:	f9400df2 	ldr	x18, [x15, #24]
    402034fc:	f9001ff2 	str	x18, [sp, #56]
    40203500:	f94009f2 	ldr	x18, [x15, #16]
    40203504:	f9001bf2 	str	x18, [sp, #48]
    40203508:	f94005f2 	ldr	x18, [x15, #8]
    4020350c:	f90017f2 	str	x18, [sp, #40]
    40203510:	f84205f2 	ldr	x18, [x15], #32
    40203514:	eb1001ff 	cmp	x15, x16
    40203518:	f90013f2 	str	x18, [sp, #32]
    4020351c:	ad4107e2 	ldp	q2, q1, [sp, #32]
    40203520:	6e205823 	mvn	v3.16b, v1.16b
    40203524:	6e205844 	mvn	v4.16b, v2.16b
    40203528:	6f7a0421 	ushr	v1.2d, v1.2d, #6
    4020352c:	6f7a0442 	ushr	v2.2d, v2.2d, #6
    40203530:	6f790463 	ushr	v3.2d, v3.2d, #7
    40203534:	6f790484 	ushr	v4.2d, v4.2d, #7
    40203538:	4ea21c82 	orr	v2.16b, v4.16b, v2.16b
    4020353c:	4ea11c61 	orr	v1.16b, v3.16b, v1.16b
    40203540:	4e201c21 	and	v1.16b, v1.16b, v0.16b
    40203544:	4e201c42 	and	v2.16b, v2.16b, v0.16b
    40203548:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    4020354c:	5ef1b821 	addp	d1, v1.2d
    40203550:	9e660032 	fmov	x18, d1
    40203554:	8b110251 	add	x17, x18, x17
    40203558:	54fffd01 	b.ne	402034f8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x2a4>  // b.any
    4020355c:	17ffff8c 	b	4020338c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x138>
    40203560:	927e15a9 	and	x9, x13, #0xfc
    40203564:	f10005ff 	cmp	x15, #0x1
    40203568:	8b090d8a 	add	x10, x12, x9, lsl #3
    4020356c:	f9400149 	ldr	x9, [x10]
    40203570:	aa2903eb 	mvn	x11, x9
    40203574:	d347fd6b 	lsr	x11, x11, #7
    40203578:	aa491969 	orr	x9, x11, x9, lsr #6
    4020357c:	9200c129 	and	x9, x9, #0x101010101010101
    40203580:	540001e0 	b.eq	402035bc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x368>  // b.none
    40203584:	f940054b 	ldr	x11, [x10, #8]
    40203588:	f10009ff 	cmp	x15, #0x2
    4020358c:	aa2b03ec 	mvn	x12, x11
    40203590:	d347fd8c 	lsr	x12, x12, #7
    40203594:	aa4b198b 	orr	x11, x12, x11, lsr #6
    40203598:	9200c16b 	and	x11, x11, #0x101010101010101
    4020359c:	8b090169 	add	x9, x11, x9
    402035a0:	540000e0 	b.eq	402035bc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x368>  // b.none
    402035a4:	f940094a 	ldr	x10, [x10, #16]
    402035a8:	aa2a03eb 	mvn	x11, x10
    402035ac:	d347fd6b 	lsr	x11, x11, #7
    402035b0:	aa4a196a 	orr	x10, x11, x10, lsr #6
    402035b4:	9200c14a 	and	x10, x10, #0x101010101010101
    402035b8:	8b090149 	add	x9, x10, x9
    402035bc:	d348fd2a 	lsr	x10, x9, #8
    402035c0:	92009d29 	and	x9, x9, #0xff00ff00ff00ff
    402035c4:	92009d4a 	and	x10, x10, #0xff00ff00ff00ff
    402035c8:	8b090149 	add	x9, x10, x9
    402035cc:	b20083ea 	mov	x10, #0x1000100010001       	// #281479271743489
    402035d0:	9b0a7d29 	mul	x9, x9, x10
    402035d4:	8b49c108 	add	x8, x8, x9, lsr #48
    402035d8:	6d4523e9 	ldp	d9, d8, [sp, #80]
    402035dc:	aa0803e0 	mov	x0, x8
    402035e0:	fd4023ea 	ldr	d10, [sp, #64]
    402035e4:	910183ff 	add	sp, sp, #0x60
    402035e8:	d65f03c0 	ret
    402035ec:	f100803f 	cmp	x1, #0x20
    402035f0:	54000082 	b.cs	40203600 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x3ac>  // b.hs, b.nlast
    402035f4:	aa1f03e9 	mov	x9, xzr
    402035f8:	aa1f03e8 	mov	x8, xzr
    402035fc:	140000bc 	b	402038ec <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x698>
    40203600:	6f00e400 	movi	v0.2d, #0x0
    40203604:	4f05e7e3 	movi	v3.16b, #0xbf
    40203608:	52800028 	mov	w8, #0x1                   	// #1
    4020360c:	6f00e402 	movi	v2.2d, #0x0
    40203610:	6f00e407 	movi	v7.2d, #0x0
    40203614:	927d042a 	and	x10, x1, #0x18
    40203618:	6f00e401 	movi	v1.2d, #0x0
    4020361c:	6f00e412 	movi	v18.2d, #0x0
    40203620:	927be829 	and	x9, x1, #0xffffffffffffffe0
    40203624:	6f00e405 	movi	v5.2d, #0x0
    40203628:	6f00e406 	movi	v6.2d, #0x0
    4020362c:	927be82b 	and	x11, x1, #0xffffffffffffffe0
    40203630:	6f00e404 	movi	v4.2d, #0x0
    40203634:	6f00e416 	movi	v22.2d, #0x0
    40203638:	6f00e411 	movi	v17.2d, #0x0
    4020363c:	6f00e410 	movi	v16.2d, #0x0
    40203640:	6f00e417 	movi	v23.2d, #0x0
    40203644:	6f00e414 	movi	v20.2d, #0x0
    40203648:	6f00e415 	movi	v21.2d, #0x0
    4020364c:	6f00e413 	movi	v19.2d, #0x0
    40203650:	6f00e418 	movi	v24.2d, #0x0
    40203654:	4e080d19 	dup	v25.2d, x8
    40203658:	91004008 	add	x8, x0, #0x10
    4020365c:	aa0803ec 	mov	x12, x8
    40203660:	385f1112 	ldurb	w18, [x8, #-15]
    40203664:	385f5102 	ldurb	w2, [x8, #-11]
    40203668:	385f0d8d 	ldrb	w13, [x12, #-16]!
    4020366c:	aa0c03ef 	mov	x15, x12
    40203670:	3940098e 	ldrb	w14, [x12, #2]
    40203674:	38404df0 	ldrb	w16, [x15, #4]!
    40203678:	394009f1 	ldrb	w17, [x15, #2]
    4020367c:	39400d83 	ldrb	w3, [x12, #3]
    40203680:	39400def 	ldrb	w15, [x15, #3]
    40203684:	d370bdce 	lsl	x14, x14, #16
    40203688:	aa1221ad 	orr	x13, x13, x18, lsl #8
    4020368c:	2a022210 	orr	w16, w16, w2, lsl #8
    40203690:	53103e31 	lsl	w17, w17, #16
    40203694:	f100816b 	subs	x11, x11, #0x20
    40203698:	aa0361ce 	orr	x14, x14, x3, lsl #24
    4020369c:	2a0f622f 	orr	w15, w17, w15, lsl #24
    402036a0:	aa0d01cd 	orr	x13, x14, x13
    402036a4:	2a1001ee 	orr	w14, w15, w16
    402036a8:	aa0e81ad 	orr	x13, x13, x14, lsl #32
    402036ac:	f9000bed 	str	x13, [sp, #16]
    402036b0:	aa0c03ed 	mov	x13, x12
    402036b4:	38408dae 	ldrb	w14, [x13, #8]!
    402036b8:	39400daf 	ldrb	w15, [x13, #3]
    402036bc:	394009b0 	ldrb	w16, [x13, #2]
    402036c0:	38404db1 	ldrb	w17, [x13, #4]!
    402036c4:	394009b2 	ldrb	w18, [x13, #2]
    402036c8:	39402582 	ldrb	w2, [x12, #9]
    402036cc:	3940358c 	ldrb	w12, [x12, #13]
    402036d0:	39400dad 	ldrb	w13, [x13, #3]
    402036d4:	d370be10 	lsl	x16, x16, #16
    402036d8:	53103e52 	lsl	w18, w18, #16
    402036dc:	aa0221ce 	orr	x14, x14, x2, lsl #8
    402036e0:	2a0c222c 	orr	w12, w17, w12, lsl #8
    402036e4:	aa0f620f 	orr	x15, x16, x15, lsl #24
    402036e8:	2a0d624d 	orr	w13, w18, w13, lsl #24
    402036ec:	aa0e01ee 	orr	x14, x15, x14
    402036f0:	2a0c01ac 	orr	w12, w13, w12
    402036f4:	aa0c81cc 	orr	x12, x14, x12, lsl #32
    402036f8:	f9000fec 	str	x12, [sp, #24]
    402036fc:	aa0803ec 	mov	x12, x8
    40203700:	3940090e 	ldrb	w14, [x8, #2]
    40203704:	38404d8f 	ldrb	w15, [x12, #4]!
    40203708:	39400990 	ldrb	w16, [x12, #2]
    4020370c:	3940050d 	ldrb	w13, [x8, #1]
    40203710:	39400111 	ldrb	w17, [x8]
    40203714:	39400d12 	ldrb	w18, [x8, #3]
    40203718:	39401502 	ldrb	w2, [x8, #5]
    4020371c:	39400d8c 	ldrb	w12, [x12, #3]
    40203720:	d370bdce 	lsl	x14, x14, #16
    40203724:	53103e10 	lsl	w16, w16, #16
    40203728:	aa0d222d 	orr	x13, x17, x13, lsl #8
    4020372c:	2a0221ef 	orr	w15, w15, w2, lsl #8
    40203730:	3dc007fa 	ldr	q26, [sp, #16]
    40203734:	aa1261ce 	orr	x14, x14, x18, lsl #24
    40203738:	2a0c620c 	orr	w12, w16, w12, lsl #24
    4020373c:	4e23375a 	cmgt	v26.16b, v26.16b, v3.16b
    40203740:	aa0d01cd 	orr	x13, x14, x13
    40203744:	2a0f018c 	orr	w12, w12, w15
    40203748:	aa0c81ac 	orr	x12, x13, x12, lsl #32
    4020374c:	aa0803ed 	mov	x13, x8
    40203750:	6f08a75b 	uxtl2	v27.8h, v26.16b
    40203754:	2f08a75a 	uxtl	v26.8h, v26.8b
    40203758:	f90003ec 	str	x12, [sp]
    4020375c:	38408dac 	ldrb	w12, [x13, #8]!
    40203760:	39400dae 	ldrb	w14, [x13, #3]
    40203764:	394009af 	ldrb	w15, [x13, #2]
    40203768:	38404db0 	ldrb	w16, [x13, #4]!
    4020376c:	394009b1 	ldrb	w17, [x13, #2]
    40203770:	39402512 	ldrb	w18, [x8, #9]
    40203774:	39403502 	ldrb	w2, [x8, #13]
    40203778:	39400dad 	ldrb	w13, [x13, #3]
    4020377c:	d370bdef 	lsl	x15, x15, #16
    40203780:	6f10a77c 	uxtl2	v28.4s, v27.8h
    40203784:	53103e31 	lsl	w17, w17, #16
    40203788:	aa12218c 	orr	x12, x12, x18, lsl #8
    4020378c:	2a022210 	orr	w16, w16, w2, lsl #8
    40203790:	aa0e61ee 	orr	x14, x15, x14, lsl #24
    40203794:	2f10a77b 	uxtl	v27.4s, v27.4h
    40203798:	2f10a75e 	uxtl	v30.4s, v26.4h
    4020379c:	2a0d622d 	orr	w13, w17, w13, lsl #24
    402037a0:	6f20a79d 	uxtl2	v29.2d, v28.4s
    402037a4:	6f10a75a 	uxtl2	v26.4s, v26.8h
    402037a8:	aa0c01cc 	orr	x12, x14, x12
    402037ac:	2f20a79c 	uxtl	v28.2d, v28.2s
    402037b0:	91008108 	add	x8, x8, #0x20
    402037b4:	2a1001ad 	orr	w13, w13, w16
    402037b8:	6f20a768 	uxtl2	v8.2d, v27.4s
    402037bc:	6f20a7c9 	uxtl2	v9.2d, v30.4s
    402037c0:	aa0d818c 	orr	x12, x12, x13, lsl #32
    402037c4:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    402037c8:	6f20a74a 	uxtl2	v10.2d, v26.4s
    402037cc:	2f20a75a 	uxtl	v26.2d, v26.2s
    402037d0:	2f20a77b 	uxtl	v27.2d, v27.2s
    402037d4:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    402037d8:	f90007ec 	str	x12, [sp, #8]
    402037dc:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    402037e0:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    402037e4:	3dc003ff 	ldr	q31, [sp]
    402037e8:	4efd86d6 	add	v22.2d, v22.2d, v29.2d
    402037ec:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    402037f0:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    402037f4:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    402037f8:	4efc8484 	add	v4.2d, v4.2d, v28.2d
    402037fc:	4e2337ff 	cmgt	v31.16b, v31.16b, v3.16b
    40203800:	4ee884c6 	add	v6.2d, v6.2d, v8.2d
    40203804:	2f20a7de 	uxtl	v30.2d, v30.2s
    40203808:	4eea8652 	add	v18.2d, v18.2d, v10.2d
    4020380c:	4ee984e7 	add	v7.2d, v7.2d, v9.2d
    40203810:	4efa8421 	add	v1.2d, v1.2d, v26.2d
    40203814:	4efb84a5 	add	v5.2d, v5.2d, v27.2d
    40203818:	6f08a7fd 	uxtl2	v29.8h, v31.16b
    4020381c:	2f08a7ff 	uxtl	v31.8h, v31.8b
    40203820:	4e391fde 	and	v30.16b, v30.16b, v25.16b
    40203824:	6f10a7bc 	uxtl2	v28.4s, v29.8h
    40203828:	6f10a7e8 	uxtl2	v8.4s, v31.8h
    4020382c:	2f10a7bd 	uxtl	v29.4s, v29.4h
    40203830:	2f10a7fa 	uxtl	v26.4s, v31.4h
    40203834:	4efe8442 	add	v2.2d, v2.2d, v30.2d
    40203838:	2f20a79b 	uxtl	v27.2d, v28.2s
    4020383c:	6f20a79c 	uxtl2	v28.2d, v28.4s
    40203840:	2f20a7bf 	uxtl	v31.2d, v29.2s
    40203844:	6f20a509 	uxtl2	v9.2d, v8.4s
    40203848:	6f20a7bd 	uxtl2	v29.2d, v29.4s
    4020384c:	2f20a74a 	uxtl	v10.2d, v26.2s
    40203850:	6f20a75a 	uxtl2	v26.2d, v26.4s
    40203854:	2f20a508 	uxtl	v8.2d, v8.2s
    40203858:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    4020385c:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    40203860:	4e391fff 	and	v31.16b, v31.16b, v25.16b
    40203864:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    40203868:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    4020386c:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40203870:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    40203874:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    40203878:	4efc8718 	add	v24.2d, v24.2d, v28.2d
    4020387c:	4efb8673 	add	v19.2d, v19.2d, v27.2d
    40203880:	4eff8694 	add	v20.2d, v20.2d, v31.2d
    40203884:	4efd86b5 	add	v21.2d, v21.2d, v29.2d
    40203888:	4ee986f7 	add	v23.2d, v23.2d, v9.2d
    4020388c:	4eea8631 	add	v17.2d, v17.2d, v10.2d
    40203890:	4ee88610 	add	v16.2d, v16.2d, v8.2d
    40203894:	4efa8400 	add	v0.2d, v0.2d, v26.2d
    40203898:	54ffee21 	b.ne	4020365c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x408>  // b.any
    4020389c:	4ef286e3 	add	v3.2d, v23.2d, v18.2d
    402038a0:	4ef68712 	add	v18.2d, v24.2d, v22.2d
    402038a4:	eb09003f 	cmp	x1, x9
    402038a8:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    402038ac:	4ee28622 	add	v2.2d, v17.2d, v2.2d
    402038b0:	4ee58685 	add	v5.2d, v20.2d, v5.2d
    402038b4:	4ee686a6 	add	v6.2d, v21.2d, v6.2d
    402038b8:	4ee18601 	add	v1.2d, v16.2d, v1.2d
    402038bc:	4ee48664 	add	v4.2d, v19.2d, v4.2d
    402038c0:	4ef28463 	add	v3.2d, v3.2d, v18.2d
    402038c4:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    402038c8:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    402038cc:	4ee68400 	add	v0.2d, v0.2d, v6.2d
    402038d0:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    402038d4:	4ee38400 	add	v0.2d, v0.2d, v3.2d
    402038d8:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    402038dc:	5ef1b800 	addp	d0, v0.2d
    402038e0:	9e660008 	fmov	x8, d0
    402038e4:	54ffd3c0 	b.eq	4020335c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x108>  // b.none
    402038e8:	b400074a 	cbz	x10, 402039d0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x77c>
    402038ec:	6f00e400 	movi	v0.2d, #0x0
    402038f0:	6f00e401 	movi	v1.2d, #0x0
    402038f4:	aa0903ea 	mov	x10, x9
    402038f8:	0f05e7e2 	movi	v2.8b, #0xbf
    402038fc:	6f00e403 	movi	v3.2d, #0x0
    40203900:	927df029 	and	x9, x1, #0xfffffffffffffff8
    40203904:	6f00e404 	movi	v4.2d, #0x0
    40203908:	4e081d00 	mov	v0.d[0], x8
    4020390c:	52800028 	mov	w8, #0x1                   	// #1
    40203910:	4e080d05 	dup	v5.2d, x8
    40203914:	cb090148 	sub	x8, x10, x9
    40203918:	8b0a000a 	add	x10, x0, x10
    4020391c:	aa0a03ed 	mov	x13, x10
    40203920:	3940094c 	ldrb	w12, [x10, #2]
    40203924:	3940054b 	ldrb	w11, [x10, #1]
    40203928:	38404dae 	ldrb	w14, [x13, #4]!
    4020392c:	394009af 	ldrb	w15, [x13, #2]
    40203930:	39400150 	ldrb	w16, [x10]
    40203934:	39400d51 	ldrb	w17, [x10, #3]
    40203938:	d370bd8c 	lsl	x12, x12, #16
    4020393c:	39401552 	ldrb	w18, [x10, #5]
    40203940:	39400dad 	ldrb	w13, [x13, #3]
    40203944:	53103def 	lsl	w15, w15, #16
    40203948:	aa0b220b 	orr	x11, x16, x11, lsl #8
    4020394c:	aa11618c 	orr	x12, x12, x17, lsl #24
    40203950:	b1002108 	adds	x8, x8, #0x8
    40203954:	2a1221ce 	orr	w14, w14, w18, lsl #8
    40203958:	2a0d61ed 	orr	w13, w15, w13, lsl #24
    4020395c:	9100214a 	add	x10, x10, #0x8
    40203960:	aa0b018b 	orr	x11, x12, x11
    40203964:	2a0e01ac 	orr	w12, w13, w14
    40203968:	aa0c816b 	orr	x11, x11, x12, lsl #32
    4020396c:	9e670166 	fmov	d6, x11
    40203970:	0e2234c6 	cmgt	v6.8b, v6.8b, v2.8b
    40203974:	2f08a4c6 	uxtl	v6.8h, v6.8b
    40203978:	6f10a4c7 	uxtl2	v7.4s, v6.8h
    4020397c:	2f10a4c6 	uxtl	v6.4s, v6.4h
    40203980:	6f20a4f0 	uxtl2	v16.2d, v7.4s
    40203984:	2f20a4d1 	uxtl	v17.2d, v6.2s
    40203988:	6f20a4c6 	uxtl2	v6.2d, v6.4s
    4020398c:	2f20a4e7 	uxtl	v7.2d, v7.2s
    40203990:	4e251e10 	and	v16.16b, v16.16b, v5.16b
    40203994:	4e251e31 	and	v17.16b, v17.16b, v5.16b
    40203998:	4e251cc6 	and	v6.16b, v6.16b, v5.16b
    4020399c:	4e251ce7 	and	v7.16b, v7.16b, v5.16b
    402039a0:	4ef08484 	add	v4.2d, v4.2d, v16.2d
    402039a4:	4ee68463 	add	v3.2d, v3.2d, v6.2d
    402039a8:	4ef18400 	add	v0.2d, v0.2d, v17.2d
    402039ac:	4ee78421 	add	v1.2d, v1.2d, v7.2d
    402039b0:	54fffb61 	b.ne	4020391c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x6c8>  // b.any
    402039b4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    402039b8:	4ee48461 	add	v1.2d, v3.2d, v4.2d
    402039bc:	eb09003f 	cmp	x1, x9
    402039c0:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    402039c4:	5ef1b800 	addp	d0, v0.2d
    402039c8:	9e660008 	fmov	x8, d0
    402039cc:	54ffcc80 	b.eq	4020335c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x108>  // b.none
    402039d0:	cb09002a 	sub	x10, x1, x9
    402039d4:	8b090009 	add	x9, x0, x9
    402039d8:	38c0152b 	ldrsb	w11, [x9], #1
    402039dc:	3101057f 	cmn	w11, #0x41
    402039e0:	9a88d508 	cinc	x8, x8, gt
    402039e4:	f100054a 	subs	x10, x10, #0x1
    402039e8:	54ffff81 	b.ne	402039d8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x784>  // b.any
    402039ec:	17fffe5c 	b	4020335c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x108>

00000000402039f0 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>:
    402039f0:	d10103ff 	sub	sp, sp, #0x40
    402039f4:	a9037bfd 	stp	x29, x30, [sp, #48]
    402039f8:	9100c3fd 	add	x29, sp, #0x30
    402039fc:	eb02001f 	cmp	x0, x2
    40203a00:	540001a9 	b.ls	40203a34 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail+0x44>  // b.plast
    40203a04:	910003e8 	mov	x8, sp
    40203a08:	d503201f 	nop
    40203a0c:	10000909 	adr	x9, 40203b2c <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>
    40203a10:	a9000be0 	stp	x0, x2, [sp]
    40203a14:	b0000000 	adrp	x0, 40204000 <memset+0x14c>
    40203a18:	9103ec00 	add	x0, x0, #0xfb
    40203a1c:	a90127e8 	stp	x8, x9, [sp, #16]
    40203a20:	910023e8 	add	x8, sp, #0x8
    40203a24:	a90227e8 	stp	x8, x9, [sp, #32]
    40203a28:	910043e1 	add	x1, sp, #0x10
    40203a2c:	aa0303e2 	mov	x2, x3
    40203a30:	97fffdff 	bl	4020322c <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>
    40203a34:	eb02003f 	cmp	x1, x2
    40203a38:	540001e8 	b.hi	40203a74 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail+0x84>  // b.pmore
    40203a3c:	eb01001f 	cmp	x0, x1
    40203a40:	540001a9 	b.ls	40203a74 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail+0x84>  // b.plast
    40203a44:	910003e8 	mov	x8, sp
    40203a48:	d503201f 	nop
    40203a4c:	10000709 	adr	x9, 40203b2c <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>
    40203a50:	a90127e8 	stp	x8, x9, [sp, #16]
    40203a54:	910023e8 	add	x8, sp, #0x8
    40203a58:	a90007e0 	stp	x0, x1, [sp]
    40203a5c:	b0000000 	adrp	x0, 40204000 <memset+0x14c>
    40203a60:	9100d800 	add	x0, x0, #0x36
    40203a64:	a90227e8 	stp	x8, x9, [sp, #32]
    40203a68:	910043e1 	add	x1, sp, #0x10
    40203a6c:	aa0303e2 	mov	x2, x3
    40203a70:	97fffdef 	bl	4020322c <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>
    40203a74:	910003e8 	mov	x8, sp
    40203a78:	d503201f 	nop
    40203a7c:	10000589 	adr	x9, 40203b2c <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>
    40203a80:	a90127e8 	stp	x8, x9, [sp, #16]
    40203a84:	910023e8 	add	x8, sp, #0x8
    40203a88:	b0000000 	adrp	x0, 40204000 <memset+0x14c>
    40203a8c:	9102ac00 	add	x0, x0, #0xab
    40203a90:	a9000be1 	stp	x1, x2, [sp]
    40203a94:	a90227e8 	stp	x8, x9, [sp, #32]
    40203a98:	910043e1 	add	x1, sp, #0x10
    40203a9c:	aa0303e2 	mov	x2, x3
    40203aa0:	97fffde3 	bl	4020322c <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>

0000000040203aa4 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix>:
    40203aa4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40203aa8:	a90157f6 	stp	x22, x21, [sp, #16]
    40203aac:	a9024ff4 	stp	x20, x19, [sp, #32]
    40203ab0:	910003fd 	mov	x29, sp
    40203ab4:	aa0403f3 	mov	x19, x4
    40203ab8:	aa0303f4 	mov	x20, x3
    40203abc:	aa0103f5 	mov	x21, x1
    40203ac0:	7144405f 	cmp	w2, #0x110, lsl #12
    40203ac4:	540001a0 	b.eq	40203af8 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix+0x54>  // b.none
    40203ac8:	f94012a8 	ldr	x8, [x21, #32]
    40203acc:	2a0203e1 	mov	w1, w2
    40203ad0:	aa0003f6 	mov	x22, x0
    40203ad4:	d63f0100 	blr	x8
    40203ad8:	2a0003e8 	mov	w8, w0
    40203adc:	aa1603e0 	mov	x0, x22
    40203ae0:	360000c8 	tbz	w8, #0, 40203af8 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix+0x54>
    40203ae4:	52800020 	mov	w0, #0x1                   	// #1
    40203ae8:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40203aec:	a94157f6 	ldp	x22, x21, [sp, #16]
    40203af0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40203af4:	d65f03c0 	ret
    40203af8:	b4000114 	cbz	x20, 40203b18 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix+0x74>
    40203afc:	f9400ea3 	ldr	x3, [x21, #24]
    40203b00:	aa1403e1 	mov	x1, x20
    40203b04:	aa1303e2 	mov	x2, x19
    40203b08:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40203b0c:	a94157f6 	ldp	x22, x21, [sp, #16]
    40203b10:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40203b14:	d61f0060 	br	x3
    40203b18:	2a1f03e0 	mov	w0, wzr
    40203b1c:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40203b20:	a94157f6 	ldp	x22, x21, [sp, #16]
    40203b24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40203b28:	d65f03c0 	ret

0000000040203b2c <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>:
    40203b2c:	d100c3ff 	sub	sp, sp, #0x30
    40203b30:	a9027bfd 	stp	x29, x30, [sp, #32]
    40203b34:	910083fd 	add	x29, sp, #0x20
    40203b38:	f9400009 	ldr	x9, [x0]
    40203b3c:	d503201f 	nop
    40203b40:	10004848 	adr	x8, 40204448 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0xd8>
    40203b44:	f10fa13f 	cmp	x9, #0x3e8
    40203b48:	540004e3 	b.cc	40203be4 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0xb8>  // b.lo, b.ul, b.last
    40203b4c:	d28b296c 	mov	x12, #0x594b                	// #22859
    40203b50:	910033ea 	add	x10, sp, #0xc
    40203b54:	5292cff1 	mov	w17, #0x967f                	// #38527
    40203b58:	f2a710cc 	movk	x12, #0x3886, lsl #16
    40203b5c:	9280026b 	mov	x11, #0xffffffffffffffec    	// #-20
    40203b60:	5284e20d 	mov	w13, #0x2710                	// #10000
    40203b64:	f2d8bacc 	movk	x12, #0xc5d6, lsl #32
    40203b68:	52828f6e 	mov	w14, #0x147b                	// #5243
    40203b6c:	91004d4f 	add	x15, x10, #0x13
    40203b70:	f2e68dac 	movk	x12, #0x346d, lsl #48
    40203b74:	52800c90 	mov	w16, #0x64                  	// #100
    40203b78:	72a01311 	movk	w17, #0x98, lsl #16
    40203b7c:	aa0903ea 	mov	x10, x9
    40203b80:	aa0a03f2 	mov	x18, x10
    40203b84:	9bcc7d4a 	umulh	x10, x10, x12
    40203b88:	9100116b 	add	x11, x11, #0x4
    40203b8c:	eb11025f 	cmp	x18, x17
    40203b90:	d34bfd4a 	lsr	x10, x10, #11
    40203b94:	1b0dc940 	msub	w0, w10, w13, w18
    40203b98:	53023c02 	ubfx	w2, w0, #2, #14
    40203b9c:	1b0e7c42 	mul	w2, w2, w14
    40203ba0:	53117c42 	lsr	w2, w2, #17
    40203ba4:	1b108040 	msub	w0, w2, w16, w0
    40203ba8:	8b224502 	add	x2, x8, w2, uxtw #1
    40203bac:	39400043 	ldrb	w3, [x2]
    40203bb0:	39400442 	ldrb	w2, [x2, #1]
    40203bb4:	8b202500 	add	x0, x8, w0, uxth #1
    40203bb8:	381fd1e3 	sturb	w3, [x15, #-3]
    40203bbc:	39400003 	ldrb	w3, [x0]
    40203bc0:	39400400 	ldrb	w0, [x0, #1]
    40203bc4:	381fe1e2 	sturb	w2, [x15, #-2]
    40203bc8:	381ff1e3 	sturb	w3, [x15, #-1]
    40203bcc:	381fc5e0 	strb	w0, [x15], #-4
    40203bd0:	54fffd88 	b.hi	40203b80 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x54>  // b.pmore
    40203bd4:	cb0b03eb 	neg	x11, x11
    40203bd8:	f100255f 	cmp	x10, #0x9
    40203bdc:	540000c8 	b.hi	40203bf4 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0xc8>  // b.pmore
    40203be0:	14000015 	b	40203c34 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x108>
    40203be4:	5280028b 	mov	w11, #0x14                  	// #20
    40203be8:	aa0903ea 	mov	x10, x9
    40203bec:	f100253f 	cmp	x9, #0x9
    40203bf0:	54000229 	b.ls	40203c34 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x108>  // b.plast
    40203bf4:	53023d4c 	ubfx	w12, w10, #2, #14
    40203bf8:	52828f6d 	mov	w13, #0x147b                	// #5243
    40203bfc:	910033ef 	add	x15, sp, #0xc
    40203c00:	1b0d7d8c 	mul	w12, w12, w13
    40203c04:	52800c8d 	mov	w13, #0x64                  	// #100
    40203c08:	53117d8c 	lsr	w12, w12, #17
    40203c0c:	1b0da98a 	msub	w10, w12, w13, w10
    40203c10:	d100096d 	sub	x13, x11, #0x2
    40203c14:	8b0b01eb 	add	x11, x15, x11
    40203c18:	8b2a250a 	add	x10, x8, w10, uxth #1
    40203c1c:	3940014e 	ldrb	w14, [x10]
    40203c20:	3940054a 	ldrb	w10, [x10, #1]
    40203c24:	382d69ee 	strb	w14, [x15, x13]
    40203c28:	381ff16a 	sturb	w10, [x11, #-1]
    40203c2c:	aa0c03ea 	mov	x10, x12
    40203c30:	aa0d03eb 	mov	x11, x13
    40203c34:	b4000049 	cbz	x9, 40203c3c <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x110>
    40203c38:	b40000ca 	cbz	x10, 40203c50 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x124>
    40203c3c:	8b0a0508 	add	x8, x8, x10, lsl #1
    40203c40:	d100056b 	sub	x11, x11, #0x1
    40203c44:	910033e9 	add	x9, sp, #0xc
    40203c48:	39400508 	ldrb	w8, [x8, #1]
    40203c4c:	382b6928 	strb	w8, [x9, x11]
    40203c50:	52800288 	mov	w8, #0x14                  	// #20
    40203c54:	aa0103e0 	mov	x0, x1
    40203c58:	52800021 	mov	w1, #0x1                   	// #1
    40203c5c:	cb0b0105 	sub	x5, x8, x11
    40203c60:	910033e8 	add	x8, sp, #0xc
    40203c64:	52800022 	mov	w2, #0x1                   	// #1
    40203c68:	8b0b0104 	add	x4, x8, x11
    40203c6c:	aa1f03e3 	mov	x3, xzr
    40203c70:	97fffc3b 	bl	40202d5c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral>
    40203c74:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40203c78:	9100c3ff 	add	sp, sp, #0x30
    40203c7c:	d65f03c0 	ret

0000000040203c80 <memcmp>:
    40203c80:	b40000e2 	cbz	x2, 40203c9c <memcmp+0x1c>
    40203c84:	38401408 	ldrb	w8, [x0], #1
    40203c88:	38401429 	ldrb	w9, [x1], #1
    40203c8c:	6b090108 	subs	w8, w8, w9
    40203c90:	54000081 	b.ne	40203ca0 <memcmp+0x20>  // b.any
    40203c94:	f1000442 	subs	x2, x2, #0x1
    40203c98:	54ffff61 	b.ne	40203c84 <memcmp+0x4>  // b.any
    40203c9c:	2a1f03e8 	mov	w8, wzr
    40203ca0:	2a0803e0 	mov	w0, w8
    40203ca4:	d65f03c0 	ret

0000000040203ca8 <memcpy>:
    40203ca8:	f100405f 	cmp	x2, #0x10
    40203cac:	54000723 	b.cc	40203d90 <memcpy+0xe8>  // b.lo, b.ul, b.last
    40203cb0:	cb0003ec 	neg	x12, x0
    40203cb4:	92400988 	and	x8, x12, #0x7
    40203cb8:	8b080009 	add	x9, x0, x8
    40203cbc:	eb09001f 	cmp	x0, x9
    40203cc0:	54000422 	b.cs	40203d44 <memcpy+0x9c>  // b.hs, b.nlast
    40203cc4:	f100111f 	cmp	x8, #0x4
    40203cc8:	aa0003ea 	mov	x10, x0
    40203ccc:	aa0103eb 	mov	x11, x1
    40203cd0:	54000323 	b.cc	40203d34 <memcpy+0x8c>  // b.lo, b.ul, b.last
    40203cd4:	cb01000a 	sub	x10, x0, x1
    40203cd8:	aa0103eb 	mov	x11, x1
    40203cdc:	f100815f 	cmp	x10, #0x20
    40203ce0:	aa0003ea 	mov	x10, x0
    40203ce4:	54000283 	b.cc	40203d34 <memcpy+0x8c>  // b.lo, b.ul, b.last
    40203ce8:	927e018c 	and	x12, x12, #0x4
    40203cec:	aa0003ed 	mov	x13, x0
    40203cf0:	aa0103ee 	mov	x14, x1
    40203cf4:	8b0c000a 	add	x10, x0, x12
    40203cf8:	8b0c002b 	add	x11, x1, x12
    40203cfc:	aa0c03ef 	mov	x15, x12
    40203d00:	39400dd0 	ldrb	w16, [x14, #3]
    40203d04:	394009d1 	ldrb	w17, [x14, #2]
    40203d08:	f10011ef 	subs	x15, x15, #0x4
    40203d0c:	394001d2 	ldrb	w18, [x14]
    40203d10:	394005c3 	ldrb	w3, [x14, #1]
    40203d14:	910011ce 	add	x14, x14, #0x4
    40203d18:	39000db0 	strb	w16, [x13, #3]
    40203d1c:	390009b1 	strb	w17, [x13, #2]
    40203d20:	390005a3 	strb	w3, [x13, #1]
    40203d24:	380045b2 	strb	w18, [x13], #4
    40203d28:	54fffec1 	b.ne	40203d00 <memcpy+0x58>  // b.any
    40203d2c:	eb0c011f 	cmp	x8, x12
    40203d30:	540000a0 	b.eq	40203d44 <memcpy+0x9c>  // b.none
    40203d34:	3840156c 	ldrb	w12, [x11], #1
    40203d38:	3800154c 	strb	w12, [x10], #1
    40203d3c:	eb09015f 	cmp	x10, x9
    40203d40:	54ffffa1 	b.ne	40203d34 <memcpy+0x8c>  // b.any
    40203d44:	cb08004b 	sub	x11, x2, x8
    40203d48:	8b08002a 	add	x10, x1, x8
    40203d4c:	927df16c 	and	x12, x11, #0xfffffffffffffff8
    40203d50:	f240095f 	tst	x10, #0x7
    40203d54:	8b0c0128 	add	x8, x9, x12
    40203d58:	540007a1 	b.ne	40203e4c <memcpy+0x1a4>  // b.any
    40203d5c:	eb08013f 	cmp	x9, x8
    40203d60:	540000c2 	b.cs	40203d78 <memcpy+0xd0>  // b.hs, b.nlast
    40203d64:	aa0a03ed 	mov	x13, x10
    40203d68:	f84085ae 	ldr	x14, [x13], #8
    40203d6c:	f800852e 	str	x14, [x9], #8
    40203d70:	eb08013f 	cmp	x9, x8
    40203d74:	54ffffa3 	b.cc	40203d68 <memcpy+0xc0>  // b.lo, b.ul, b.last
    40203d78:	8b0c0141 	add	x1, x10, x12
    40203d7c:	92400962 	and	x2, x11, #0x7
    40203d80:	8b020109 	add	x9, x8, x2
    40203d84:	eb09011f 	cmp	x8, x9
    40203d88:	540000c3 	b.cc	40203da0 <memcpy+0xf8>  // b.lo, b.ul, b.last
    40203d8c:	1400002f 	b	40203e48 <memcpy+0x1a0>
    40203d90:	aa0003e8 	mov	x8, x0
    40203d94:	8b020009 	add	x9, x0, x2
    40203d98:	eb09001f 	cmp	x0, x9
    40203d9c:	54000562 	b.cs	40203e48 <memcpy+0x1a0>  // b.hs, b.nlast
    40203da0:	f100105f 	cmp	x2, #0x4
    40203da4:	540004a3 	b.cc	40203e38 <memcpy+0x190>  // b.lo, b.ul, b.last
    40203da8:	cb01010a 	sub	x10, x8, x1
    40203dac:	f100815f 	cmp	x10, #0x20
    40203db0:	54000443 	b.cc	40203e38 <memcpy+0x190>  // b.lo, b.ul, b.last
    40203db4:	39400c2a 	ldrb	w10, [x1, #3]
    40203db8:	3940082b 	ldrb	w11, [x1, #2]
    40203dbc:	3940002c 	ldrb	w12, [x1]
    40203dc0:	3940042d 	ldrb	w13, [x1, #1]
    40203dc4:	39000d0a 	strb	w10, [x8, #3]
    40203dc8:	927e044a 	and	x10, x2, #0xc
    40203dcc:	f100115f 	cmp	x10, #0x4
    40203dd0:	3900090b 	strb	w11, [x8, #2]
    40203dd4:	3900050d 	strb	w13, [x8, #1]
    40203dd8:	3900010c 	strb	w12, [x8]
    40203ddc:	54000260 	b.eq	40203e28 <memcpy+0x180>  // b.none
    40203de0:	39401c2b 	ldrb	w11, [x1, #7]
    40203de4:	3940182c 	ldrb	w12, [x1, #6]
    40203de8:	f100215f 	cmp	x10, #0x8
    40203dec:	3940102d 	ldrb	w13, [x1, #4]
    40203df0:	3940142e 	ldrb	w14, [x1, #5]
    40203df4:	39001d0b 	strb	w11, [x8, #7]
    40203df8:	3900190c 	strb	w12, [x8, #6]
    40203dfc:	3900150e 	strb	w14, [x8, #5]
    40203e00:	3900110d 	strb	w13, [x8, #4]
    40203e04:	54000120 	b.eq	40203e28 <memcpy+0x180>  // b.none
    40203e08:	39402c2b 	ldrb	w11, [x1, #11]
    40203e0c:	3940282c 	ldrb	w12, [x1, #10]
    40203e10:	3940202d 	ldrb	w13, [x1, #8]
    40203e14:	3940242e 	ldrb	w14, [x1, #9]
    40203e18:	39002d0b 	strb	w11, [x8, #11]
    40203e1c:	3900290c 	strb	w12, [x8, #10]
    40203e20:	3900250e 	strb	w14, [x8, #9]
    40203e24:	3900210d 	strb	w13, [x8, #8]
    40203e28:	eb0a005f 	cmp	x2, x10
    40203e2c:	540000e0 	b.eq	40203e48 <memcpy+0x1a0>  // b.none
    40203e30:	8b0a0108 	add	x8, x8, x10
    40203e34:	8b0a0021 	add	x1, x1, x10
    40203e38:	3840142a 	ldrb	w10, [x1], #1
    40203e3c:	3800150a 	strb	w10, [x8], #1
    40203e40:	eb09011f 	cmp	x8, x9
    40203e44:	54ffffa1 	b.ne	40203e38 <memcpy+0x190>  // b.any
    40203e48:	d65f03c0 	ret
    40203e4c:	eb08013f 	cmp	x9, x8
    40203e50:	54fff942 	b.cs	40203d78 <memcpy+0xd0>  // b.hs, b.nlast
    40203e54:	aa0a03ed 	mov	x13, x10
    40203e58:	aa0d03f0 	mov	x16, x13
    40203e5c:	394009af 	ldrb	w15, [x13, #2]
    40203e60:	394005ae 	ldrb	w14, [x13, #1]
    40203e64:	38404e11 	ldrb	w17, [x16, #4]!
    40203e68:	39400a12 	ldrb	w18, [x16, #2]
    40203e6c:	394001a1 	ldrb	w1, [x13]
    40203e70:	39400da2 	ldrb	w2, [x13, #3]
    40203e74:	d370bdef 	lsl	x15, x15, #16
    40203e78:	394015a3 	ldrb	w3, [x13, #5]
    40203e7c:	39400e10 	ldrb	w16, [x16, #3]
    40203e80:	53103e52 	lsl	w18, w18, #16
    40203e84:	aa0e202e 	orr	x14, x1, x14, lsl #8
    40203e88:	aa0261ef 	orr	x15, x15, x2, lsl #24
    40203e8c:	910021ad 	add	x13, x13, #0x8
    40203e90:	2a032231 	orr	w17, w17, w3, lsl #8
    40203e94:	2a106250 	orr	w16, w18, w16, lsl #24
    40203e98:	aa0e01ee 	orr	x14, x15, x14
    40203e9c:	2a11020f 	orr	w15, w16, w17
    40203ea0:	aa0f81ce 	orr	x14, x14, x15, lsl #32
    40203ea4:	f800852e 	str	x14, [x9], #8
    40203ea8:	eb08013f 	cmp	x9, x8
    40203eac:	54fffd63 	b.cc	40203e58 <memcpy+0x1b0>  // b.lo, b.ul, b.last
    40203eb0:	17ffffb2 	b	40203d78 <memcpy+0xd0>

0000000040203eb4 <memset>:
    40203eb4:	f100405f 	cmp	x2, #0x10
    40203eb8:	540009e3 	b.cc	40203ff4 <memset+0x140>  // b.lo, b.ul, b.last
    40203ebc:	cb0003eb 	neg	x11, x0
    40203ec0:	92400968 	and	x8, x11, #0x7
    40203ec4:	8b080009 	add	x9, x0, x8
    40203ec8:	eb09001f 	cmp	x0, x9
    40203ecc:	54000302 	b.cs	40203f2c <memset+0x78>  // b.hs, b.nlast
    40203ed0:	f100111f 	cmp	x8, #0x4
    40203ed4:	aa0003ea 	mov	x10, x0
    40203ed8:	54000243 	b.cc	40203f20 <memset+0x6c>  // b.lo, b.ul, b.last
    40203edc:	0e020c20 	dup	v0.4h, w1
    40203ee0:	927e016b 	and	x11, x11, #0x4
    40203ee4:	aa0003ec 	mov	x12, x0
    40203ee8:	8b0b000a 	add	x10, x0, x11
    40203eec:	aa0b03ed 	mov	x13, x11
    40203ef0:	5e0e0401 	mov	h1, v0.h[3]
    40203ef4:	5e0a0402 	mov	h2, v0.h[2]
    40203ef8:	5e060403 	mov	h3, v0.h[1]
    40203efc:	3d000180 	str	b0, [x12]
    40203f00:	f10011ad 	subs	x13, x13, #0x4
    40203f04:	3c003181 	stur	b1, [x12, #3]
    40203f08:	3c002182 	stur	b2, [x12, #2]
    40203f0c:	3c001183 	stur	b3, [x12, #1]
    40203f10:	9100118c 	add	x12, x12, #0x4
    40203f14:	54ffff41 	b.ne	40203efc <memset+0x48>  // b.any
    40203f18:	eb0b011f 	cmp	x8, x11
    40203f1c:	54000080 	b.eq	40203f2c <memset+0x78>  // b.none
    40203f20:	38001541 	strb	w1, [x10], #1
    40203f24:	eb09015f 	cmp	x10, x9
    40203f28:	54ffffc1 	b.ne	40203f20 <memset+0x6c>  // b.any
    40203f2c:	cb08004a 	sub	x10, x2, x8
    40203f30:	927df148 	and	x8, x10, #0xfffffffffffffff8
    40203f34:	8b080128 	add	x8, x9, x8
    40203f38:	eb08013f 	cmp	x9, x8
    40203f3c:	54000102 	b.cs	40203f5c <memset+0xa8>  // b.hs, b.nlast
    40203f40:	12001c2b 	and	w11, w1, #0xff
    40203f44:	3200c3ec 	mov	w12, #0x1010101             	// #16843009
    40203f48:	1b0c7d6b 	mul	w11, w11, w12
    40203f4c:	aa0b816b 	orr	x11, x11, x11, lsl #32
    40203f50:	f800852b 	str	x11, [x9], #8
    40203f54:	eb08013f 	cmp	x9, x8
    40203f58:	54ffffc3 	b.cc	40203f50 <memset+0x9c>  // b.lo, b.ul, b.last
    40203f5c:	92400942 	and	x2, x10, #0x7
    40203f60:	8b020109 	add	x9, x8, x2
    40203f64:	eb09011f 	cmp	x8, x9
    40203f68:	54000442 	b.cs	40203ff0 <memset+0x13c>  // b.hs, b.nlast
    40203f6c:	f100105f 	cmp	x2, #0x4
    40203f70:	540003a3 	b.cc	40203fe4 <memset+0x130>  // b.lo, b.ul, b.last
    40203f74:	927e044a 	and	x10, x2, #0xc
    40203f78:	39000d01 	strb	w1, [x8, #3]
    40203f7c:	f100115f 	cmp	x10, #0x4
    40203f80:	8b0a010b 	add	x11, x8, x10
    40203f84:	39000901 	strb	w1, [x8, #2]
    40203f88:	39000501 	strb	w1, [x8, #1]
    40203f8c:	39000101 	strb	w1, [x8]
    40203f90:	54000240 	b.eq	40203fd8 <memset+0x124>  // b.none
    40203f94:	0e020c20 	dup	v0.4h, w1
    40203f98:	f100215f 	cmp	x10, #0x8
    40203f9c:	5e0e0401 	mov	h1, v0.h[3]
    40203fa0:	5e0a0402 	mov	h2, v0.h[2]
    40203fa4:	5e060403 	mov	h3, v0.h[1]
    40203fa8:	3c004100 	stur	b0, [x8, #4]
    40203fac:	3c007101 	stur	b1, [x8, #7]
    40203fb0:	3c006102 	stur	b2, [x8, #6]
    40203fb4:	3c005103 	stur	b3, [x8, #5]
    40203fb8:	54000100 	b.eq	40203fd8 <memset+0x124>  // b.none
    40203fbc:	5e0e0401 	mov	h1, v0.h[3]
    40203fc0:	5e0a0402 	mov	h2, v0.h[2]
    40203fc4:	3c008100 	stur	b0, [x8, #8]
    40203fc8:	5e060403 	mov	h3, v0.h[1]
    40203fcc:	3c00b101 	stur	b1, [x8, #11]
    40203fd0:	3c00a102 	stur	b2, [x8, #10]
    40203fd4:	3c009103 	stur	b3, [x8, #9]
    40203fd8:	eb0a005f 	cmp	x2, x10
    40203fdc:	aa0b03e8 	mov	x8, x11
    40203fe0:	54000080 	b.eq	40203ff0 <memset+0x13c>  // b.none
    40203fe4:	38001501 	strb	w1, [x8], #1
    40203fe8:	eb09011f 	cmp	x8, x9
    40203fec:	54ffffc1 	b.ne	40203fe4 <memset+0x130>  // b.any
    40203ff0:	d65f03c0 	ret
    40203ff4:	aa0003e8 	mov	x8, x0
    40203ff8:	8b020009 	add	x9, x0, x2
    40203ffc:	eb09001f 	cmp	x0, x9
    40204000:	54fffb63 	b.cc	40203f6c <memset+0xb8>  // b.lo, b.ul, b.last
    40204004:	17fffffb 	b	40203ff0 <memset+0x13c>
