
/home/ywcho/jnox236-first/ordinary-chain/kernel.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000040200000 <_start>:
    40200000:	d5034fdf 	msr	daifset, #0xf
    40200004:	d5384240 	mrs	x0, currentel
    40200008:	f100101f 	cmp	x0, #0x4
    4020000c:	54000241 	b.ne	40200054 <_start+0x54>  // b.any
    40200010:	d50041bf 	msr	spsel, #0x1
    40200014:	58000260 	ldr	x0, 40200060 <_start+0x60>
    40200018:	9100001f 	mov	sp, x0
    4020001c:	d5381040 	mrs	x0, cpacr_el1
    40200020:	b26c0400 	orr	x0, x0, #0x300000
    40200024:	d5181040 	msr	cpacr_el1, x0
    40200028:	d5033fdf 	isb
    4020002c:	580001e0 	ldr	x0, 40200068 <_start+0x68>
    40200030:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    40200034:	f9000001 	str	x1, [x0]
    40200038:	580001c0 	ldr	x0, 40200070 <_start+0x70>
    4020003c:	580001e1 	ldr	x1, 40200078 <_start+0x78>
    40200040:	eb01001f 	cmp	x0, x1
    40200044:	54000062 	b.cs	40200050 <_start+0x50>  // b.hs, b.nlast
    40200048:	f800841f 	str	xzr, [x0], #8
    4020004c:	17fffffd 	b	40200040 <_start+0x40>
    40200050:	140008cd 	b	40202384 <_ZN11jnox_kernel11kernel_main17ha0f1dd4d6a7d76bdE>
    40200054:	d503205f 	wfe
    40200058:	17ffffff 	b	40200054 <_start+0x54>
    4020005c:	00000000 	udf	#0
    40200060:	4021b400 	.word	0x4021b400
    40200064:	00000000 	.word	0x00000000
    40200068:	402173f0 	.word	0x402173f0
    4020006c:	00000000 	.word	0x00000000
    40200070:	40205170 	.word	0x40205170
    40200074:	00000000 	.word	0x00000000
    40200078:	402173f8 	.word	0x402173f8
	...

0000000040200800 <sched_vectors>:
    40200800:	14000200 00000000 00000000 00000000     ................
	...
    40200880:	140001e0 00000000 00000000 00000000     ................
	...
    40200900:	140001c0 00000000 00000000 00000000     ................
	...
    40200980:	140001a0 00000000 00000000 00000000     ................
	...
    40200a00:	140001b6 00000000 00000000 00000000     ................
	...
    40200a80:	14000161 00000000 00000000 00000000     a...............
	...
    40200b00:	14000140 00000000 00000000 00000000     @...............
	...
    40200b80:	14000120 00000000 00000000 00000000      ...............
	...
    40200c00:	14000100 00000000 00000000 00000000     ................
	...
    40200c80:	140000e0 00000000 00000000 00000000     ................
	...
    40200d00:	140000c0 00000000 00000000 00000000     ................
	...
    40200d80:	140000a0 00000000 00000000 00000000     ................
	...
    40200e00:	14000080 00000000 00000000 00000000     ................
	...
    40200e80:	14000060 00000000 00000000 00000000     `...............
	...
    40200f00:	14000040 00000000 00000000 00000000     @...............
	...
    40200f80:	14000020 00000000 00000000 00000000      ...............
	...
    40201000:	140000aa d10d03ff f90027e9 d5033fdf     .........'...?..
    40201010:	d53be029 f9009fe9 f94027e9 a90007e0     ).;......'@.....
    40201020:	a9010fe2 a90217e4 a9031fe6 a90427e8     .............'..
    40201030:	a9052fea a90637ec a9073fee a90847f0     ./...7...?...G..
    40201040:	a9094ff2 a90a57f4 a90b5ff6 a90c67f8     .O...W..._...g..
    40201050:	a90d6ffa a90e77fc f9007bfe ad0a07e0     .o...w...{......
    40201060:	ad0b0fe2 ad0c17e4 ad0d1fe6 ad0e27e8     .............'..
    40201070:	ad0f2fea ad1037ec ad113fee ad1247f0     ./...7...?...G..
    40201080:	ad134ff2 ad1457f4 ad155ff6 ad1667f8     .O...W..._...g..
    40201090:	ad176ffa ad1877fc ad197ffe d5384029     .o...w......)@8.
    402010a0:	d538400a a90fabe9 d53b4409 d53b442a     .@8......D;.*D;.
    402010b0:	a910abe9 d538d089 d538410a a911abe9     ......8..A8.....
    402010c0:	d53bd049 d53bd06a a912abe9 910003e0     I.;.j.;.........
    402010d0:	940003b7 14000036 d10d03ff f90027e9     ....6........'..
    402010e0:	d5033fdf d53be029 f9009fe9 f94027e9     .?..).;......'@.
    402010f0:	a90007e0 a9010fe2 a90217e4 a9031fe6     ................
    40201100:	a90427e8 a9052fea a90637ec a9073fee     .'.../...7...?..
    40201110:	a90847f0 a9094ff2 a90a57f4 a90b5ff6     .G...O...W..._..
    40201120:	a90c67f8 a90d6ffa a90e77fc f9007bfe     .g...o...w...{..
    40201130:	ad0a07e0 ad0b0fe2 ad0c17e4 ad0d1fe6     ................
    40201140:	ad0e27e8 ad0f2fea ad1037ec ad113fee     .'.../...7...?..
    40201150:	ad1247f0 ad134ff2 ad1457f4 ad155ff6     .G...O...W..._..
    40201160:	ad1667f8 ad176ffa ad1877fc ad197ffe     .g...o...w......
    40201170:	d5384029 d538400a a90fabe9 d53b4409     )@8..@8......D;.
    40201180:	d53b442a a910abe9 d538d089 d538410a     *D;.......8..A8.
    40201190:	a911abe9 d53bd049 d53bd06a a912abe9     ....I.;.j.;.....
    402011a0:	910003e0 940002d4 14000001              ............

00000000402011ac <sched_start_frame>:
    402011ac:	9100001f 	mov	sp, x0
    402011b0:	a94fabe9 	ldp	x9, x10, [sp, #248]
    402011b4:	d5184029 	msr	elr_el1, x9
    402011b8:	d518400a 	msr	spsr_el1, x10
    402011bc:	a950abe9 	ldp	x9, x10, [sp, #264]
    402011c0:	d51b4409 	msr	fpcr, x9
    402011c4:	d51b442a 	msr	fpsr, x10
    402011c8:	a951abe9 	ldp	x9, x10, [sp, #280]
    402011cc:	d518d089 	msr	tpidr_el1, x9
    402011d0:	d518410a 	msr	sp_el0, x10
    402011d4:	a952abe9 	ldp	x9, x10, [sp, #296]
    402011d8:	d51bd049 	msr	tpidr_el0, x9
    402011dc:	d51bd06a 	msr	tpidrro_el0, x10
    402011e0:	ad4a07e0 	ldp	q0, q1, [sp, #320]
    402011e4:	ad4b0fe2 	ldp	q2, q3, [sp, #352]
    402011e8:	ad4c17e4 	ldp	q4, q5, [sp, #384]
    402011ec:	ad4d1fe6 	ldp	q6, q7, [sp, #416]
    402011f0:	ad4e27e8 	ldp	q8, q9, [sp, #448]
    402011f4:	ad4f2fea 	ldp	q10, q11, [sp, #480]
    402011f8:	ad5037ec 	ldp	q12, q13, [sp, #512]
    402011fc:	ad513fee 	ldp	q14, q15, [sp, #544]
    40201200:	ad5247f0 	ldp	q16, q17, [sp, #576]
    40201204:	ad534ff2 	ldp	q18, q19, [sp, #608]
    40201208:	ad5457f4 	ldp	q20, q21, [sp, #640]
    4020120c:	ad555ff6 	ldp	q22, q23, [sp, #672]
    40201210:	ad5667f8 	ldp	q24, q25, [sp, #704]
    40201214:	ad576ffa 	ldp	q26, q27, [sp, #736]
    40201218:	ad5877fc 	ldp	q28, q29, [sp, #768]
    4020121c:	ad597ffe 	ldp	q30, q31, [sp, #800]
    40201220:	d503201f 	nop
    40201224:	100ade29 	adr	x9, 40216de8 <jnox_ap_returns>
    40201228:	f940012a 	ldr	x10, [x9]
    4020122c:	f101015f 	cmp	x10, #0x40
    40201230:	54ffee82 	b.cs	40201000 <sched_vectors+0x800>  // b.hs, b.nlast
    40201234:	9100054b 	add	x11, x10, #0x1
    40201238:	f800852b 	str	x11, [x9], #8
    4020123c:	d280030b 	mov	x11, #0x18                  	// #24
    40201240:	9b0b2549 	madd	x9, x10, x11, x9
    40201244:	910003ea 	mov	x10, sp
    40201248:	d538402b 	mrs	x11, elr_el1
    4020124c:	a9002d2a 	stp	x10, x11, [x9]
    40201250:	d5033fdf 	isb
    40201254:	d53be02a 	mrs	x10, cntpct_el0
    40201258:	f900092a 	str	x10, [x9, #16]
    4020125c:	a94007e0 	ldp	x0, x1, [sp]
    40201260:	a9410fe2 	ldp	x2, x3, [sp, #16]
    40201264:	a94217e4 	ldp	x4, x5, [sp, #32]
    40201268:	a9431fe6 	ldp	x6, x7, [sp, #48]
    4020126c:	a94427e8 	ldp	x8, x9, [sp, #64]
    40201270:	a9452fea 	ldp	x10, x11, [sp, #80]
    40201274:	a94637ec 	ldp	x12, x13, [sp, #96]
    40201278:	a9473fee 	ldp	x14, x15, [sp, #112]
    4020127c:	a94847f0 	ldp	x16, x17, [sp, #128]
    40201280:	a9494ff2 	ldp	x18, x19, [sp, #144]
    40201284:	a94a57f4 	ldp	x20, x21, [sp, #160]
    40201288:	a94b5ff6 	ldp	x22, x23, [sp, #176]
    4020128c:	a94c67f8 	ldp	x24, x25, [sp, #192]
    40201290:	a94d6ffa 	ldp	x26, x27, [sp, #208]
    40201294:	a94e77fc 	ldp	x28, x29, [sp, #224]
    40201298:	f9407bfe 	ldr	x30, [sp, #240]
    4020129c:	910d03ff 	add	sp, sp, #0x340
    402012a0:	d5033f5f 	clrex
    402012a4:	d69f03e0 	eret

00000000402012a8 <_ZN11jnox_kernel14ordinary_mutex10unexpected17h38482129df987011E>:
    402012a8:	f81f0ffe 	str	x30, [sp, #-16]!
    402012ac:	52800220 	mov	w0, #0x11                  	// #17
    402012b0:	940000ec 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

00000000402012b4 <_ZN11jnox_kernel14ordinary_mutex3low17hba8ab34c8ee04c89E>:
    402012b4:	d10083ff 	sub	sp, sp, #0x20
    402012b8:	f9000bfe 	str	x30, [sp, #16]
    402012bc:	52800020 	mov	w0, #0x1                   	// #1
    402012c0:	aa1f03e1 	mov	x1, xzr
    402012c4:	94000284 	bl	40201cd4 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>
    402012c8:	52800020 	mov	w0, #0x1                   	// #1
    402012cc:	52800021 	mov	w1, #0x1                   	// #1
    402012d0:	94000281 	bl	40201cd4 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>
    402012d4:	d503201f 	nop
    402012d8:	1001f508 	adr	x8, 40205178 <_ZN11jnox_kernel14ordinary_mutex5BATCH17hb040c9570b4ccc5fE>
    402012dc:	f9400509 	ldr	x9, [x8, #8]
    402012e0:	f9400108 	ldr	x8, [x8]
    402012e4:	f9000fe8 	str	x8, [sp, #24]
    402012e8:	f90007e9 	str	x9, [sp, #8]
    402012ec:	f9400fe8 	ldr	x8, [sp, #24]
    402012f0:	d503201f 	nop
    402012f4:	100ad729 	adr	x9, 40216dd8 <_ZN11jnox_kernel14ordinary_mutex9PUBLISHED17hbda705983ad3137aE>
    402012f8:	f9000128 	str	x8, [x9]
    402012fc:	f94007e8 	ldr	x8, [sp, #8]
    40201300:	f9000528 	str	x8, [x9, #8]
    40201304:	52800040 	mov	w0, #0x2                   	// #2
    40201308:	52800021 	mov	w1, #0x1                   	// #1
    4020130c:	94000272 	bl	40201cd4 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>
    40201310:	52800040 	mov	w0, #0x2                   	// #2
    40201314:	aa1f03e1 	mov	x1, xzr
    40201318:	9400026f 	bl	40201cd4 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>
    4020131c:	9400008b 	bl	40201548 <_ZN11jnox_kernel14ordinary_mutex4exit17h88ed5b88944c971aE>

0000000040201320 <_ZN11jnox_kernel14ordinary_mutex3run17h2e8d428f4d32a81cE>:
    40201320:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40201324:	a90157f6 	stp	x22, x21, [sp, #16]
    40201328:	a9024ff4 	stp	x20, x19, [sp, #32]
    4020132c:	d109c3ff 	sub	sp, sp, #0x270
    40201330:	9400052a 	bl	402027d8 <_ZN11jnox_kernel7context14init_timer_irq17hd7766ccbde3e84bbE>
    40201334:	d53be014 	mrs	x20, cntfrq_el0
    40201338:	f10fa29f 	cmp	x20, #0x3e8
    4020133c:	540003c3 	b.cc	402013b4 <_ZN11jnox_kernel14ordinary_mutex3run17h2e8d428f4d32a81cE+0x94>  // b.lo, b.ul, b.last
    40201340:	d343fe88 	lsr	x8, x20, #3
    40201344:	d29ef9e9 	mov	x9, #0xf7cf                	// #63439
    40201348:	f2bc6a69 	movk	x9, #0xe353, lsl #16
    4020134c:	f2d374a9 	movk	x9, #0x9ba5, lsl #32
    40201350:	f2e41889 	movk	x9, #0x20c4, lsl #48
    40201354:	9bc97d08 	umulh	x8, x8, x9
    40201358:	d344fd08 	lsr	x8, x8, #4
    4020135c:	52807d09 	mov	w9, #0x3e8                 	// #1000
    40201360:	9b09d108 	msub	x8, x8, x9, x20
    40201364:	b5000288 	cbnz	x8, 402013b4 <_ZN11jnox_kernel14ordinary_mutex3run17h2e8d428f4d32a81cE+0x94>
    40201368:	52804035 	mov	w21, #0x201                 	// #513
    4020136c:	72a08075 	movk	w21, #0x403, lsl #16
    40201370:	390033ff 	strb	wzr, [sp, #12]
    40201374:	52800148 	mov	w8, #0xa                   	// #10
    40201378:	b9000be8 	str	w8, [sp, #8]
    4020137c:	52800068 	mov	w8, #0x3                   	// #3
    40201380:	b90013e8 	str	w8, [sp, #16]
    40201384:	390053ff 	strb	wzr, [sp, #20]
    40201388:	910023f3 	add	x19, sp, #0x8
    4020138c:	9105c3e8 	add	x8, sp, #0x170
    40201390:	910023e1 	add	x1, sp, #0x8
    40201394:	52804020 	mov	w0, #0x201                 	// #513
    40201398:	72a08060 	movk	w0, #0x403, lsl #16
    4020139c:	940005c3 	bl	40202aa8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$3new17h6e64bc8051b703e1E>
    402013a0:	f940bbe8 	ldr	x8, [sp, #368]
    402013a4:	f100091f 	cmp	x8, #0x2
    402013a8:	540000a1 	b.ne	402013bc <_ZN11jnox_kernel14ordinary_mutex3run17h2e8d428f4d32a81cE+0x9c>  // b.any
    402013ac:	52800020 	mov	w0, #0x1                   	// #1
    402013b0:	940000ac 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    402013b4:	528001a0 	mov	w0, #0xd                   	// #13
    402013b8:	940000aa 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    402013bc:	9105c3f6 	add	x22, sp, #0x170
    402013c0:	910023e0 	add	x0, sp, #0x8
    402013c4:	9105c3e1 	add	x1, sp, #0x170
    402013c8:	52802002 	mov	w2, #0x100                 	// #256
    402013cc:	94000aa1 	bl	40203e50 <memcpy>
    402013d0:	7902dbff 	strh	wzr, [sp, #364]
    402013d4:	91040260 	add	x0, x19, #0x100
    402013d8:	2a1f03e1 	mov	w1, wzr
    402013dc:	52800b02 	mov	w2, #0x58                  	// #88
    402013e0:	94000b1f 	bl	4020405c <memset>
    402013e4:	aa1f03e9 	mov	x9, xzr
    402013e8:	b9016bf5 	str	w21, [sp, #360]
    402013ec:	910042c8 	add	x8, x22, #0x10
    402013f0:	f900b3f4 	str	x20, [sp, #352]
    402013f4:	d503201f 	nop
    402013f8:	100004ea 	adr	x10, 40201494 <_ZN11jnox_kernel14ordinary_mutex4base17hbc6bdab6d4b3df93E>
    402013fc:	d503201f 	nop
    40201400:	10fff5ab 	adr	x11, 402012b4 <_ZN11jnox_kernel14ordinary_mutex3low17hba8ab34c8ee04c89E>
    40201404:	a9182fea 	stp	x10, x11, [sp, #384]
    40201408:	d503201f 	nop
    4020140c:	100022aa 	adr	x10, 40201860 <_ZN11jnox_kernel14ordinary_mutex6medium17h477bcb7179dbf5cbE>
    40201410:	d503201f 	nop
    40201414:	10000a6b 	adr	x11, 40201560 <_ZN11jnox_kernel14ordinary_mutex4high17h6a225b999eb58028E>
    40201418:	a9192fea 	stp	x10, x11, [sp, #400]
    4020141c:	f000002a 	adrp	x10, 40208000 <_ZN11jnox_kernel14ordinary_mutex6STACKS17h3be57ef615508284E+0x2e40>
    40201420:	913a014a 	add	x10, x10, #0xe80
    40201424:	528068ab 	mov	w11, #0x345                 	// #837
    40201428:	f900d3ff 	str	xzr, [sp, #416]
    4020142c:	528ce00c 	mov	w12, #0x6700                	// #26368
    40201430:	f869790d 	ldr	x13, [x8, x9, lsl #3]
    40201434:	8b0c012e 	add	x14, x9, x12
    40201438:	8b090e6f 	add	x15, x19, x9, lsl #3
    4020143c:	91000529 	add	x9, x9, #0x1
    40201440:	f9008d49 	str	x9, [x10, #280]
    40201444:	f9004d4e 	str	x14, [x10, #152]
    40201448:	a90fad4d 	stp	x13, x11, [x10, #248]
    4020144c:	f90095ea 	str	x10, [x15, #296]
    40201450:	9140114a 	add	x10, x10, #0x4, lsl #12
    40201454:	f100113f 	cmp	x9, #0x4
    40201458:	54fffec1 	b.ne	40201430 <_ZN11jnox_kernel14ordinary_mutex3run17h2e8d428f4d32a81cE+0x110>  // b.any
    4020145c:	910023e0 	add	x0, sp, #0x8
    40201460:	aa1f03e1 	mov	x1, xzr
    40201464:	2a1f03e2 	mov	w2, wzr
    40201468:	94000207 	bl	40201c84 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE>
    4020146c:	910023e0 	add	x0, sp, #0x8
    40201470:	9400012c 	bl	40201920 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17hd980273460ecc890E>
    40201474:	aa0003f3 	mov	x19, x0
    40201478:	d503201f 	nop
    4020147c:	1001dc20 	adr	x0, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201480:	910023e1 	add	x1, sp, #0x8
    40201484:	52802d02 	mov	w2, #0x168                 	// #360
    40201488:	94000a72 	bl	40203e50 <memcpy>
    4020148c:	aa1303e0 	mov	x0, x19
    40201490:	97ffff47 	bl	402011ac <sched_start_frame>

0000000040201494 <_ZN11jnox_kernel14ordinary_mutex4base17hbc6bdab6d4b3df93E>:
    40201494:	d10083ff 	sub	sp, sp, #0x20
    40201498:	f9000bfe 	str	x30, [sp, #16]
    4020149c:	52800028 	mov	w8, #0x1                   	// #1
    402014a0:	52800020 	mov	w0, #0x1                   	// #1
    402014a4:	d4000001 	svc	#0x0
    402014a8:	b50004c0 	cbnz	x0, 40201540 <_ZN11jnox_kernel14ordinary_mutex4base17hbc6bdab6d4b3df93E+0xac>
    402014ac:	aa1f03e9 	mov	x9, xzr
    402014b0:	d503201f 	nop
    402014b4:	1009e868 	adr	x8, 402151c0 <_ZN11jnox_kernel14ordinary_mutex7IN_WORK17h3cf0d660ecd4af71E.0>
    402014b8:	5280002c 	mov	w12, #0x1                   	// #1
    402014bc:	d503201f 	nop
    402014c0:	1001770a 	adr	x10, 402043a0 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE>
    402014c4:	c89ffd0c 	stlr	x12, [x8]
    402014c8:	d503201f 	nop
    402014cc:	1001e76b 	adr	x11, 402051b8 <_ZN11jnox_kernel14ordinary_mutex6CHUNKS17h3cec01e2eeeb4508E.0>
    402014d0:	aa1f03ed 	mov	x13, xzr
    402014d4:	92400dae 	and	x14, x13, #0xf
    402014d8:	386e694e 	ldrb	w14, [x10, x14]
    402014dc:	910005ad 	add	x13, x13, #0x1
    402014e0:	8b0e0129 	add	x9, x9, x14
    402014e4:	f10401bf 	cmp	x13, #0x100
    402014e8:	54ffff61 	b.ne	402014d4 <_ZN11jnox_kernel14ordinary_mutex4base17hbc6bdab6d4b3df93E+0x40>  // b.any
    402014ec:	f140119f 	cmp	x12, #0x4, lsl #12
    402014f0:	9a8c058d 	cinc	x13, x12, ne  // ne = any
    402014f4:	c89ffd6c 	stlr	x12, [x11]
    402014f8:	54000080 	b.eq	40201508 <_ZN11jnox_kernel14ordinary_mutex4base17hbc6bdab6d4b3df93E+0x74>  // b.none
    402014fc:	f14011bf 	cmp	x13, #0x4, lsl #12
    40201500:	aa0d03ec 	mov	x12, x13
    40201504:	54fffe69 	b.ls	402014d0 <_ZN11jnox_kernel14ordinary_mutex4base17hbc6bdab6d4b3df93E+0x3c>  // b.plast
    40201508:	52a0080a 	mov	w10, #0x400000              	// #4194304
    4020150c:	f9000fea 	str	x10, [sp, #24]
    40201510:	f90007e9 	str	x9, [sp, #8]
    40201514:	f9400fe9 	ldr	x9, [sp, #24]
    40201518:	d503201f 	nop
    4020151c:	1001e2ea 	adr	x10, 40205178 <_ZN11jnox_kernel14ordinary_mutex5BATCH17hb040c9570b4ccc5fE>
    40201520:	f9000149 	str	x9, [x10]
    40201524:	f94007e9 	ldr	x9, [sp, #8]
    40201528:	f9000549 	str	x9, [x10, #8]
    4020152c:	c89ffd1f 	stlr	xzr, [x8]
    40201530:	52800040 	mov	w0, #0x2                   	// #2
    40201534:	52800021 	mov	w1, #0x1                   	// #1
    40201538:	940001e7 	bl	40201cd4 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>
    4020153c:	94000003 	bl	40201548 <_ZN11jnox_kernel14ordinary_mutex4exit17h88ed5b88944c971aE>
    40201540:	52800160 	mov	w0, #0xb                   	// #11
    40201544:	94000047 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

0000000040201548 <_ZN11jnox_kernel14ordinary_mutex4exit17h88ed5b88944c971aE>:
    40201548:	f81f0ffe 	str	x30, [sp, #-16]!
    4020154c:	52800080 	mov	w0, #0x4                   	// #4
    40201550:	aa1f03e1 	mov	x1, xzr
    40201554:	940001e0 	bl	40201cd4 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>
    40201558:	52800180 	mov	w0, #0xc                   	// #12
    4020155c:	94000041 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

0000000040201560 <_ZN11jnox_kernel14ordinary_mutex4high17h6a225b999eb58028E>:
    40201560:	f81f0ffe 	str	x30, [sp, #-16]!
    40201564:	aa1f03e0 	mov	x0, xzr
    40201568:	52800068 	mov	w8, #0x3                   	// #3
    4020156c:	d4000001 	svc	#0x0
    40201570:	b00000a8 	adrp	x8, 40216000 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17haa882bf2f0c60c42E+0xe38>
    40201574:	f906e900 	str	x0, [x8, #3536]
    40201578:	f100041f 	cmp	x0, #0x1
    4020157c:	54000041 	b.ne	40201584 <_ZN11jnox_kernel14ordinary_mutex4high17h6a225b999eb58028E+0x24>  // b.any
    40201580:	97fffff2 	bl	40201548 <_ZN11jnox_kernel14ordinary_mutex4exit17h88ed5b88944c971aE>
    40201584:	52800160 	mov	w0, #0xb                   	// #11
    40201588:	94000036 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

000000004020158c <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>:
    4020158c:	d10043ff 	sub	sp, sp, #0x10
    40201590:	52800308 	mov	w8, #0x18                  	// #24
    40201594:	72a12008 	movk	w8, #0x900, lsl #16
    40201598:	3940000c 	ldrb	w12, [x0]
    4020159c:	b9400109 	ldr	w9, [x8]
    402015a0:	36280069 	tbz	w9, #5, 402015ac <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x20>
    402015a4:	d5033fdf 	isb
    402015a8:	17fffffd 	b	4020159c <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x10>
    402015ac:	52a12009 	mov	w9, #0x9000000             	// #150994944
    402015b0:	8b020c2a 	add	x10, x1, x2, lsl #3
    402015b4:	5280040b 	mov	w11, #0x20                  	// #32
    402015b8:	b900012c 	str	w12, [x9]
    402015bc:	910003ec 	mov	x12, sp
    402015c0:	d503201f 	nop
    402015c4:	7001688d 	adr	x13, 402042d7 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0x14>
    402015c8:	f940002e 	ldr	x14, [x1]
    402015cc:	910003ef 	mov	x15, sp
    402015d0:	52800790 	mov	w16, #0x3c                  	// #60
    402015d4:	a9007fff 	stp	xzr, xzr, [sp]
    402015d8:	9ad025d1 	lsr	x17, x14, x16
    402015dc:	92400e31 	and	x17, x17, #0xf
    402015e0:	387169b1 	ldrb	w17, [x13, x17]
    402015e4:	380015f1 	strb	w17, [x15], #1
    402015e8:	d1001210 	sub	x16, x16, #0x4
    402015ec:	b100121f 	cmn	x16, #0x4
    402015f0:	54ffff41 	b.ne	402015d8 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x4c>  // b.any
    402015f4:	14000002 	b	402015fc <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x70>
    402015f8:	d5033fdf 	isb
    402015fc:	b940010e 	ldr	w14, [x8]
    40201600:	372fffce 	tbnz	w14, #5, 402015f8 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x6c>
    40201604:	aa1f03ee 	mov	x14, xzr
    40201608:	b900012b 	str	w11, [x9]
    4020160c:	386e698f 	ldrb	w15, [x12, x14]
    40201610:	b9400110 	ldr	w16, [x8]
    40201614:	36280070 	tbz	w16, #5, 40201620 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x94>
    40201618:	d5033fdf 	isb
    4020161c:	17fffffd 	b	40201610 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x84>
    40201620:	910005ce 	add	x14, x14, #0x1
    40201624:	b900012f 	str	w15, [x9]
    40201628:	f10041df 	cmp	x14, #0x10
    4020162c:	54ffff01 	b.ne	4020160c <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x80>  // b.any
    40201630:	91002021 	add	x1, x1, #0x8
    40201634:	eb0a003f 	cmp	x1, x10
    40201638:	54fffc81 	b.ne	402015c8 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0x3c>  // b.any
    4020163c:	14000002 	b	40201644 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0xb8>
    40201640:	d5033fdf 	isb
    40201644:	b9400109 	ldr	w9, [x8]
    40201648:	372fffc9 	tbnz	w9, #5, 40201640 <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE+0xb4>
    4020164c:	52a12008 	mov	w8, #0x9000000             	// #150994944
    40201650:	52800149 	mov	w9, #0xa                   	// #10
    40201654:	b9000109 	str	w9, [x8]
    40201658:	910043ff 	add	sp, sp, #0x10
    4020165c:	d65f03c0 	ret

0000000040201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>:
    40201660:	d101c3ff 	sub	sp, sp, #0x70
    40201664:	a90367fe 	stp	x30, x25, [sp, #48]
    40201668:	a9045ff8 	stp	x24, x23, [sp, #64]
    4020166c:	a90557f6 	stp	x22, x21, [sp, #80]
    40201670:	a9064ff4 	stp	x20, x19, [sp, #96]
    40201674:	aa1f03e8 	mov	x8, xzr
    40201678:	52800315 	mov	w21, #0x18                  	// #24
    4020167c:	72a12015 	movk	w21, #0x900, lsl #16
    40201680:	d5034fdf 	msr	daifset, #0xf
    40201684:	d51be23f 	msr	cntp_ctl_el0, xzr
    40201688:	d5033fdf 	isb
    4020168c:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40201690:	d503201f 	nop
    40201694:	7001628a 	adr	x10, 402042e7 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0x24>
    40201698:	3868694b 	ldrb	w11, [x10, x8]
    4020169c:	b94002ac 	ldr	w12, [x21]
    402016a0:	3628006c 	tbz	w12, #5, 402016ac <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x4c>
    402016a4:	d5033fdf 	isb
    402016a8:	17fffffd 	b	4020169c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x3c>
    402016ac:	91000508 	add	x8, x8, #0x1
    402016b0:	b900012b 	str	w11, [x9]
    402016b4:	f100311f 	cmp	x8, #0xc
    402016b8:	54ffff01 	b.ne	40201698 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x38>  // b.any
    402016bc:	90000034 	adrp	x20, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    402016c0:	f940ba88 	ldr	x8, [x20, #368]
    402016c4:	b00000b6 	adrp	x22, 40216000 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17haa882bf2f0c60c42E+0xe38>
    402016c8:	a90023e0 	stp	x0, x8, [sp]
    402016cc:	f946f6c8 	ldr	x8, [x22, #3560]
    402016d0:	f9000be8 	str	x8, [sp, #16]
    402016d4:	d503201f 	nop
    402016d8:	700160c0 	adr	x0, 402042f3 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0x30>
    402016dc:	910003e1 	mov	x1, sp
    402016e0:	52800062 	mov	w2, #0x3                   	// #3
    402016e4:	97ffffaa 	bl	4020158c <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    402016e8:	d503201f 	nop
    402016ec:	10016040 	adr	x0, 402042f4 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0x31>
    402016f0:	d503201f 	nop
    402016f4:	1001d4a1 	adr	x1, 40205188 <_ZN11jnox_kernel14ordinary_mutex5TIMER17h079f39c6acd91389E>
    402016f8:	528000c2 	mov	w2, #0x6                   	// #6
    402016fc:	97ffffa4 	bl	4020158c <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    40201700:	aa1f03f8 	mov	x24, xzr
    40201704:	d503201f 	nop
    40201708:	1001d5c8 	adr	x8, 402051c0 <_ZN11jnox_kernel14ordinary_mutex6STACKS17h3be57ef615508284E>
    4020170c:	52806817 	mov	w23, #0x340                 	// #832
    40201710:	d503201f 	nop
    40201714:	10016073 	adr	x19, 40204320 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0x5d>
    40201718:	aa1803e9 	mov	x9, x24
    4020171c:	91401119 	add	x25, x8, #0x4, lsl #12
    40201720:	91000718 	add	x24, x24, #0x1
    40201724:	a90023e9 	stp	x9, x8, [sp]
    40201728:	a9015ff9 	stp	x25, x23, [sp, #16]
    4020172c:	910003e1 	mov	x1, sp
    40201730:	aa1303e0 	mov	x0, x19
    40201734:	52800082 	mov	w2, #0x4                   	// #4
    40201738:	97ffff95 	bl	4020158c <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    4020173c:	f100131f 	cmp	x24, #0x4
    40201740:	aa1903e8 	mov	x8, x25
    40201744:	54fffea1 	b.ne	40201718 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0xb8>  // b.any
    40201748:	f940ba97 	ldr	x23, [x20, #368]
    4020174c:	b40001f7 	cbz	x23, 40201788 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x128>
    40201750:	d503201f 	nop
    40201754:	1009d3b3 	adr	x19, 402151c8 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17haa882bf2f0c60c42E>
    40201758:	52800418 	mov	w24, #0x20                  	// #32
    4020175c:	d503201f 	nop
    40201760:	30015d14 	adr	x20, 40204301 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0x3e>
    40201764:	b4000758 	cbz	x24, 4020184c <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x1ec>
    40201768:	aa1403e0 	mov	x0, x20
    4020176c:	aa1303e1 	mov	x1, x19
    40201770:	52800382 	mov	w2, #0x1c                  	// #28
    40201774:	97ffff86 	bl	4020158c <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    40201778:	d10006f7 	sub	x23, x23, #0x1
    4020177c:	91038273 	add	x19, x19, #0xe0
    40201780:	d1000718 	sub	x24, x24, #0x1
    40201784:	b5ffff17 	cbnz	x23, 40201764 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x104>
    40201788:	f946f6c8 	ldr	x8, [x22, #3560]
    4020178c:	f101011f 	cmp	x8, #0x40
    40201790:	52800809 	mov	w9, #0x40                  	// #64
    40201794:	9a893116 	csel	x22, x8, x9, cc  // cc = lo, ul, last
    40201798:	b4000188 	cbz	x8, 402017c8 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x168>
    4020179c:	b00000b3 	adrp	x19, 40216000 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17haa882bf2f0c60c42E+0xe38>
    402017a0:	9137c273 	add	x19, x19, #0xdf0
    402017a4:	d503201f 	nop
    402017a8:	10015ad4 	adr	x20, 40204300 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0x3d>
    402017ac:	aa1403e0 	mov	x0, x20
    402017b0:	aa1303e1 	mov	x1, x19
    402017b4:	52800062 	mov	w2, #0x3                   	// #3
    402017b8:	97ffff75 	bl	4020158c <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    402017bc:	91006273 	add	x19, x19, #0x18
    402017c0:	f10006d6 	subs	x22, x22, #0x1
    402017c4:	54ffff41 	b.ne	402017ac <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x14c>  // b.any
    402017c8:	d503201f 	nop
    402017cc:	1001cd68 	adr	x8, 40205178 <_ZN11jnox_kernel14ordinary_mutex5BATCH17hb040c9570b4ccc5fE>
    402017d0:	d503201f 	nop
    402017d4:	100ab029 	adr	x9, 40216dd8 <_ZN11jnox_kernel14ordinary_mutex9PUBLISHED17hbda705983ad3137aE>
    402017d8:	b00000aa 	adrp	x10, 40216000 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17haa882bf2f0c60c42E+0xe38>
    402017dc:	b00000ab 	adrp	x11, 40216000 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17haa882bf2f0c60c42E+0xe38>
    402017e0:	f946e94a 	ldr	x10, [x10, #3536]
    402017e4:	a940210c 	ldp	x12, x8, [x8]
    402017e8:	a940252d 	ldp	x13, x9, [x9]
    402017ec:	a90023ec 	stp	x12, x8, [sp]
    402017f0:	a90127ed 	stp	x13, x9, [sp, #16]
    402017f4:	f946e568 	ldr	x8, [x11, #3528]
    402017f8:	a90223ea 	stp	x10, x8, [sp, #32]
    402017fc:	d503201f 	nop
    40201800:	300157a0 	adr	x0, 402042f5 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0x32>
    40201804:	910003e1 	mov	x1, sp
    40201808:	528000c2 	mov	w2, #0x6                   	// #6
    4020180c:	97ffff60 	bl	4020158c <_ZN11jnox_kernel14ordinary_mutex4line17hdb78134fb0eef21aE>
    40201810:	aa1f03e8 	mov	x8, xzr
    40201814:	52a12009 	mov	w9, #0x9000000             	// #150994944
    40201818:	d503201f 	nop
    4020181c:	500156ca 	adr	x10, 402042f6 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0x33>
    40201820:	3868694b 	ldrb	w11, [x10, x8]
    40201824:	b94002ac 	ldr	w12, [x21]
    40201828:	3628006c 	tbz	w12, #5, 40201834 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x1d4>
    4020182c:	d5033fdf 	isb
    40201830:	17fffffd 	b	40201824 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x1c4>
    40201834:	91000508 	add	x8, x8, #0x1
    40201838:	b900012b 	str	w11, [x9]
    4020183c:	f100291f 	cmp	x8, #0xa
    40201840:	54ffff01 	b.ne	40201820 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x1c0>  // b.any
    40201844:	d503205f 	wfe
    40201848:	17ffffff 	b	40201844 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E+0x1e4>
    4020184c:	d503201f 	nop
    40201850:	100155c2 	adr	x2, 40204308 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0x45>
    40201854:	52800400 	mov	w0, #0x20                  	// #32
    40201858:	52800401 	mov	w1, #0x20                  	// #32
    4020185c:	940006da 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040201860 <_ZN11jnox_kernel14ordinary_mutex6medium17h477bcb7179dbf5cbE>:
    40201860:	aa1f03e8 	mov	x8, xzr
    40201864:	aa1f03ea 	mov	x10, xzr
    40201868:	d503201f 	nop
    4020186c:	100159a9 	adr	x9, 402043a0 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE>
    40201870:	92400d4b 	and	x11, x10, #0xf
    40201874:	386b692b 	ldrb	w11, [x9, x11]
    40201878:	9100054a 	add	x10, x10, #0x1
    4020187c:	8b0b0108 	add	x8, x8, x11
    40201880:	f104015f 	cmp	x10, #0x100
    40201884:	54ffff61 	b.ne	40201870 <_ZN11jnox_kernel14ordinary_mutex6medium17h477bcb7179dbf5cbE+0x10>  // b.any
    40201888:	f81f0ffe 	str	x30, [sp, #-16]!
    4020188c:	b00000a9 	adrp	x9, 40216000 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17haa882bf2f0c60c42E+0xe38>
    40201890:	f906e528 	str	x8, [x9, #3528]
    40201894:	97ffff2d 	bl	40201548 <_ZN11jnox_kernel14ordinary_mutex4exit17h88ed5b88944c971aE>

0000000040201898 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17h3e9ce961dab359aaE>:
    40201898:	f81f0ffe 	str	x30, [sp, #-16]!
    4020189c:	aa0003e8 	mov	x8, x0
    402018a0:	90000029 	adrp	x9, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    402018a4:	f940a520 	ldr	x0, [x9, #328]
    402018a8:	d503201f 	nop
    402018ac:	1001c8a9 	adr	x9, 402051c0 <_ZN11jnox_kernel14ordinary_mutex6STACKS17h3be57ef615508284E>
    402018b0:	8b003929 	add	x9, x9, x0, lsl #14
    402018b4:	92400d0a 	and	x10, x8, #0xf
    402018b8:	5287980b 	mov	w11, #0x3cc0                	// #15552
    402018bc:	8b0b012b 	add	x11, x9, x11
    402018c0:	eb08017f 	cmp	x11, x8
    402018c4:	fa402940 	ccmp	x10, #0x0, #0x0, cs  // cs = hs, nlast
    402018c8:	fa480122 	ccmp	x9, x8, #0x2, eq  // eq = none
    402018cc:	540001e8 	b.hi	40201908 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17h3e9ce961dab359aaE+0x70>  // b.pmore
    402018d0:	f1000c1f 	cmp	x0, #0x3
    402018d4:	540001e8 	b.hi	40201910 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17h3e9ce961dab359aaE+0x78>  // b.pmore
    402018d8:	d503201f 	nop
    402018dc:	1001b929 	adr	x9, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    402018e0:	8b000d29 	add	x9, x9, x0, lsl #3
    402018e4:	f940952a 	ldr	x10, [x9, #296]
    402018e8:	b500010a 	cbnz	x10, 40201908 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17h3e9ce961dab359aaE+0x70>
    402018ec:	f9408d0a 	ldr	x10, [x8, #280]
    402018f0:	9100040b 	add	x11, x0, #0x1
    402018f4:	eb0b015f 	cmp	x10, x11
    402018f8:	54000081 	b.ne	40201908 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17h3e9ce961dab359aaE+0x70>  // b.any
    402018fc:	f9009528 	str	x8, [x9, #296]
    40201900:	f84107fe 	ldr	x30, [sp], #16
    40201904:	d65f03c0 	ret
    40201908:	52800080 	mov	w0, #0x4                   	// #4
    4020190c:	97ffff55 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40201910:	d503201f 	nop
    40201914:	100150a2 	adr	x2, 40204328 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0x65>
    40201918:	52800081 	mov	w1, #0x4                   	// #4
    4020191c:	940006aa 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040201920 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17hd980273460ecc890E>:
    40201920:	d100c3ff 	sub	sp, sp, #0x30
    40201924:	a90157fe 	stp	x30, x21, [sp, #16]
    40201928:	a9024ff4 	stp	x20, x19, [sp, #32]
    4020192c:	aa0003f3 	mov	x19, x0
    40201930:	aa1f03f4 	mov	x20, xzr
    40201934:	f90007e0 	str	x0, [sp, #8]
    40201938:	910013f5 	add	x21, sp, #0x4
    4020193c:	910023e0 	add	x0, sp, #0x8
    40201940:	aa1403e1 	mov	x1, x20
    40201944:	94000272 	bl	4020230c <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17hb359a444ecdeb373E>
    40201948:	38346aa0 	strb	w0, [x21, x20]
    4020194c:	91000694 	add	x20, x20, #0x1
    40201950:	f100129f 	cmp	x20, #0x4
    40201954:	54ffff41 	b.ne	4020193c <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17hd980273460ecc890E+0x1c>  // b.any
    40201958:	b94007e8 	ldr	w8, [sp, #4]
    4020195c:	b9016268 	str	w8, [x19, #352]
    40201960:	91040260 	add	x0, x19, #0x100
    40201964:	91058261 	add	x1, x19, #0x160
    40201968:	940002cd 	bl	4020249c <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E>
    4020196c:	360002e0 	tbz	w0, #0, 402019c8 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17hd980273460ecc890E+0xa8>
    40201970:	f900a661 	str	x1, [x19, #328]
    40201974:	f1000c3f 	cmp	x1, #0x3
    40201978:	540002a8 	b.hi	402019cc <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17hd980273460ecc890E+0xac>  // b.pmore
    4020197c:	8b010e68 	add	x8, x19, x1, lsl #3
    40201980:	f9409500 	ldr	x0, [x8, #296]
    40201984:	f900951f 	str	xzr, [x8, #296]
    40201988:	f940a668 	ldr	x8, [x19, #328]
    4020198c:	d503201f 	nop
    40201990:	1001c189 	adr	x9, 402051c0 <_ZN11jnox_kernel14ordinary_mutex6STACKS17h3be57ef615508284E>
    40201994:	8b083928 	add	x8, x9, x8, lsl #14
    40201998:	52879809 	mov	w9, #0x3cc0                	// #15552
    4020199c:	8b090109 	add	x9, x8, x9
    402019a0:	eb00013f 	cmp	x9, x0
    402019a4:	540001e3 	b.cc	402019e0 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17hd980273460ecc890E+0xc0>  // b.lo, b.ul, b.last
    402019a8:	92400c09 	and	x9, x0, #0xf
    402019ac:	b50001a9 	cbnz	x9, 402019e0 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17hd980273460ecc890E+0xc0>
    402019b0:	eb00011f 	cmp	x8, x0
    402019b4:	54000168 	b.hi	402019e0 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17hd980273460ecc890E+0xc0>  // b.pmore
    402019b8:	a9424ff4 	ldp	x20, x19, [sp, #32]
    402019bc:	a94157fe 	ldp	x30, x21, [sp, #16]
    402019c0:	9100c3ff 	add	sp, sp, #0x30
    402019c4:	d65f03c0 	ret
    402019c8:	94000008 	bl	402019e8 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose28_$u7b$$u7b$closure$u7d$$u7d$17h020233871b708062E>
    402019cc:	d503201f 	nop
    402019d0:	10014b82 	adr	x2, 40204340 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0x7d>
    402019d4:	aa0103e0 	mov	x0, x1
    402019d8:	52800081 	mov	w1, #0x4                   	// #4
    402019dc:	9400067a 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    402019e0:	52800080 	mov	w0, #0x4                   	// #4
    402019e4:	97ffff1f 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

00000000402019e8 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose28_$u7b$$u7b$closure$u7d$$u7d$17h020233871b708062E>:
    402019e8:	f81f0ffe 	str	x30, [sp, #-16]!
    402019ec:	52800060 	mov	w0, #0x3                   	// #3
    402019f0:	97ffff1c 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

00000000402019f4 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE>:
    402019f4:	d10203ff 	sub	sp, sp, #0x80
    402019f8:	a9027bfd 	stp	x29, x30, [sp, #32]
    402019fc:	a9036ffc 	stp	x28, x27, [sp, #48]
    40201a00:	a90467fa 	stp	x26, x25, [sp, #64]
    40201a04:	a9055ff8 	stp	x24, x23, [sp, #80]
    40201a08:	a90657f6 	stp	x22, x21, [sp, #96]
    40201a0c:	a9074ff4 	stp	x20, x19, [sp, #112]
    40201a10:	90000029 	adrp	x9, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201a14:	91048129 	add	x9, x9, #0x120
    40201a18:	f9400128 	ldr	x8, [x9]
    40201a1c:	f100151f 	cmp	x8, #0x5
    40201a20:	54001082 	b.cs	40201c30 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x23c>  // b.hs, b.nlast
    40201a24:	f940153e 	ldr	x30, [x9, #40]
    40201a28:	52800029 	mov	w9, #0x1                   	// #1
    40201a2c:	9ade2129 	lsl	x9, x9, x30
    40201a30:	b4000148 	cbz	x8, 40201a58 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x64>
    40201a34:	d37df108 	lsl	x8, x8, #3
    40201a38:	5280002b 	mov	w11, #0x1                   	// #1
    40201a3c:	9000002c 	adrp	x12, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201a40:	9104018c 	add	x12, x12, #0x100
    40201a44:	f840858d 	ldr	x13, [x12], #8
    40201a48:	9acd216d 	lsl	x13, x11, x13
    40201a4c:	aa0901a9 	orr	x9, x13, x9
    40201a50:	f1002108 	subs	x8, x8, #0x8
    40201a54:	54ffff81 	b.ne	40201a44 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x50>  // b.any
    40201a58:	aa1f03ed 	mov	x13, xzr
    40201a5c:	aa1f03eb 	mov	x11, xzr
    40201a60:	aa1f03f1 	mov	x17, xzr
    40201a64:	a9017fff 	stp	xzr, xzr, [sp, #16]
    40201a68:	9000002e 	adrp	x14, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201a6c:	9102a1ce 	add	x14, x14, #0xa8
    40201a70:	5280002f 	mov	w15, #0x1                   	// #1
    40201a74:	910043f0 	add	x16, sp, #0x10
    40201a78:	d503201f 	nop
    40201a7c:	1001ac2c 	adr	x12, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201a80:	b85f81c8 	ldur	w8, [x14, #-8]
    40201a84:	36000108 	tbz	w8, #0, 40201aa4 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0xb0>
    40201a88:	f94001c8 	ldr	x8, [x14]
    40201a8c:	f100051f 	cmp	x8, #0x1
    40201a90:	54000e28 	b.hi	40201c54 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x260>  // b.pmore
    40201a94:	9ad121f2 	lsl	x18, x15, x17
    40201a98:	f8687a0a 	ldr	x10, [x16, x8, lsl #3]
    40201a9c:	aa120152 	orr	x18, x10, x18
    40201aa0:	f8287a12 	str	x18, [x16, x8, lsl #3]
    40201aa4:	8b110188 	add	x8, x12, x17
    40201aa8:	91000631 	add	x17, x17, #0x1
    40201aac:	39458108 	ldrb	w8, [x8, #352]
    40201ab0:	910041ce 	add	x14, x14, #0x10
    40201ab4:	9acd2108 	lsl	x8, x8, x13
    40201ab8:	aa0b010b 	orr	x11, x8, x11
    40201abc:	910021ad 	add	x13, x13, #0x8
    40201ac0:	f100123f 	cmp	x17, #0x4
    40201ac4:	54fffde1 	b.ne	40201a80 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x8c>  // b.any
    40201ac8:	9000002d 	adrp	x13, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201acc:	f940b9a8 	ldr	x8, [x13, #368]
    40201ad0:	f100811f 	cmp	x8, #0x20
    40201ad4:	54000ca0 	b.eq	40201c68 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x274>  // b.none
    40201ad8:	f9409c6e 	ldr	x14, [x3, #312]
    40201adc:	d5033fdf 	isb
    40201ae0:	d53be02a 	mrs	x10, cntpct_el0
    40201ae4:	a94f9c66 	ldp	x6, x7, [x3, #248]
    40201ae8:	f9404c73 	ldr	x19, [x3, #152]
    40201aec:	f9407c90 	ldr	x16, [x4, #248]
    40201af0:	f9404c91 	ldr	x17, [x4, #152]
    40201af4:	a9405d9a 	ldp	x26, x23, [x12]
    40201af8:	a941659b 	ldp	x27, x25, [x12, #16]
    40201afc:	a9413ff4 	ldp	x20, x15, [sp, #16]
    40201b00:	d503201f 	nop
    40201b04:	1001b5a8 	adr	x8, 402051b8 <_ZN11jnox_kernel14ordinary_mutex6CHUNKS17h3cec01e2eeeb4508E.0>
    40201b08:	c8dffd12 	ldar	x18, [x8]
    40201b0c:	d503201f 	nop
    40201b10:	1009b588 	adr	x8, 402151c0 <_ZN11jnox_kernel14ordinary_mutex7IN_WORK17h3cf0d660ecd4af71E.0>
    40201b14:	c8dffd15 	ldar	x21, [x8]
    40201b18:	f9409188 	ldr	x8, [x12, #288]
    40201b1c:	f100151f 	cmp	x8, #0x5
    40201b20:	54000882 	b.cs	40201c30 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x23c>  // b.hs, b.nlast
    40201b24:	aa1f03f6 	mov	x22, xzr
    40201b28:	b4000108 	cbz	x8, 40201b48 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x154>
    40201b2c:	9000003c 	adrp	x28, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201b30:	9104039c 	add	x28, x28, #0x100
    40201b34:	f840879d 	ldr	x29, [x28], #8
    40201b38:	8b1613b6 	add	x22, x29, x22, lsl #4
    40201b3c:	910006d6 	add	x22, x22, #0x1
    40201b40:	f1000508 	subs	x8, x8, #0x1
    40201b44:	54ffff81 	b.ne	40201b34 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x140>  // b.any
    40201b48:	90000028 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201b4c:	f9407908 	ldr	x8, [x8, #240]
    40201b50:	f100151f 	cmp	x8, #0x5
    40201b54:	54000742 	b.cs	40201c3c <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x248>  // b.hs, b.nlast
    40201b58:	f90007f5 	str	x21, [sp, #8]
    40201b5c:	aa1e03f5 	mov	x21, x30
    40201b60:	aa0203f8 	mov	x24, x2
    40201b64:	aa1f03fc 	mov	x28, xzr
    40201b68:	b4000108 	cbz	x8, 40201b88 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x194>
    40201b6c:	9000003d 	adrp	x29, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201b70:	9103f3bd 	add	x29, x29, #0xfc
    40201b74:	384017be 	ldrb	w30, [x29], #1
    40201b78:	8b1c13dc 	add	x28, x30, x28, lsl #4
    40201b7c:	9100079c 	add	x28, x28, #0x1
    40201b80:	f1000508 	subs	x8, x8, #0x1
    40201b84:	54ffff81 	b.ne	40201b74 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x180>  // b.any
    40201b88:	f940b9a8 	ldr	x8, [x13, #368]
    40201b8c:	f1007d1f 	cmp	x8, #0x1f
    40201b90:	54000708 	b.hi	40201c70 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x27c>  // b.pmore
    40201b94:	aa0503e2 	mov	x2, x5
    40201b98:	f9408c7d 	ldr	x29, [x3, #280]
    40201b9c:	f9408c9e 	ldr	x30, [x4, #280]
    40201ba0:	52801c0d 	mov	w13, #0xe0                  	// #224
    40201ba4:	d503201f 	nop
    40201ba8:	1009b105 	adr	x5, 402151c8 <_ZN11jnox_kernel14ordinary_mutex7JOURNAL17haa882bf2f0c60c42E>
    40201bac:	9b0d150d 	madd	x13, x8, x13, x5
    40201bb0:	f9400085 	ldr	x5, [x4]
    40201bb4:	a90029ae 	stp	x14, x10, [x13]
    40201bb8:	a90105a0 	stp	x0, x1, [x13, #16]
    40201bbc:	3945958c 	ldrb	w12, [x12, #357]
    40201bc0:	7100037f 	cmp	w27, #0x0
    40201bc4:	da9f1320 	csinv	x0, x25, xzr, ne  // ne = any
    40201bc8:	7100035f 	cmp	w26, #0x0
    40201bcc:	a90255b8 	stp	x24, x21, [x13, #32]
    40201bd0:	da9f12ea 	csinv	x10, x23, xzr, ne  // ne = any
    40201bd4:	a90319a3 	stp	x3, x6, [x13, #48]
    40201bd8:	a9044da7 	stp	x7, x19, [x13, #64]
    40201bdc:	a90541a4 	stp	x4, x16, [x13, #80]
    40201be0:	a90625b1 	stp	x17, x9, [x13, #96]
    40201be4:	a90701aa 	stp	x10, x0, [x13, #112]
    40201be8:	a9083db4 	stp	x20, x15, [x13, #128]
    40201bec:	a90909ab 	stp	x11, x2, [x13, #144]
    40201bf0:	f94007e9 	ldr	x9, [sp, #8]
    40201bf4:	a90a25b2 	stp	x18, x9, [x13, #160]
    40201bf8:	a90b75ac 	stp	x12, x29, [x13, #176]
    40201bfc:	a90c15be 	stp	x30, x5, [x13, #192]
    40201c00:	a90d71b6 	stp	x22, x28, [x13, #208]
    40201c04:	91000508 	add	x8, x8, #0x1
    40201c08:	90000029 	adrp	x9, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201c0c:	f900b928 	str	x8, [x9, #368]
    40201c10:	a9474ff4 	ldp	x20, x19, [sp, #112]
    40201c14:	a94657f6 	ldp	x22, x21, [sp, #96]
    40201c18:	a9455ff8 	ldp	x24, x23, [sp, #80]
    40201c1c:	a94467fa 	ldp	x26, x25, [sp, #64]
    40201c20:	a9436ffc 	ldp	x28, x27, [sp, #48]
    40201c24:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40201c28:	910203ff 	add	sp, sp, #0x80
    40201c2c:	d65f03c0 	ret
    40201c30:	d503201f 	nop
    40201c34:	100140a3 	adr	x3, 40204448 <anon.2ee6e03bef39482496584c4320571626.7.llvm.17174990919417010942>
    40201c38:	14000003 	b	40201c44 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE+0x250>
    40201c3c:	d503201f 	nop
    40201c40:	10014943 	adr	x3, 40204568 <anon.a10a9a1c8b04bc618efc151eec4051b8.2.llvm.10515195519271835186>
    40201c44:	aa1f03e0 	mov	x0, xzr
    40201c48:	aa0803e1 	mov	x1, x8
    40201c4c:	52800082 	mov	w2, #0x4                   	// #4
    40201c50:	940007dc 	bl	40203bc0 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>
    40201c54:	d503201f 	nop
    40201c58:	100138c2 	adr	x2, 40204370 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0xad>
    40201c5c:	aa0803e0 	mov	x0, x8
    40201c60:	52800041 	mov	w1, #0x2                   	// #2
    40201c64:	940005d8 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40201c68:	528000a0 	mov	w0, #0x5                   	// #5
    40201c6c:	97fffe7d 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40201c70:	d503201f 	nop
    40201c74:	10013722 	adr	x2, 40204358 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0x95>
    40201c78:	aa0803e0 	mov	x0, x8
    40201c7c:	52800401 	mov	w1, #0x20                  	// #32
    40201c80:	940005d1 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040201c84 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE>:
    40201c84:	f81f0ffe 	str	x30, [sp, #-16]!
    40201c88:	39459408 	ldrb	w8, [x0, #357]
    40201c8c:	1ac12508 	lsr	w8, w8, w1
    40201c90:	37000168 	tbnz	w8, #0, 40201cbc <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE+0x38>
    40201c94:	8b011008 	add	x8, x0, x1, lsl #4
    40201c98:	f9405108 	ldr	x8, [x8, #160]
    40201c9c:	b5000108 	cbnz	x8, 40201cbc <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE+0x38>
    40201ca0:	8b010c08 	add	x8, x0, x1, lsl #3
    40201ca4:	f9409508 	ldr	x8, [x8, #296]
    40201ca8:	b40000a8 	cbz	x8, 40201cbc <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE+0x38>
    40201cac:	91040000 	add	x0, x0, #0x100
    40201cb0:	340000a2 	cbz	w2, 40201cc4 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE+0x40>
    40201cb4:	940001ca 	bl	402023dc <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE>
    40201cb8:	370000a0 	tbnz	w0, #0, 40201ccc <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE+0x48>
    40201cbc:	52800040 	mov	w0, #0x2                   	// #2
    40201cc0:	97fffe68 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40201cc4:	94000238 	bl	402025a4 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE>
    40201cc8:	3607ffa0 	tbz	w0, #0, 40201cbc <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE+0x38>
    40201ccc:	f84107fe 	ldr	x30, [sp], #16
    40201cd0:	d65f03c0 	ret

0000000040201cd4 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E>:
    40201cd4:	aa0003e8 	mov	x8, x0
    40201cd8:	aa0103e0 	mov	x0, x1
    40201cdc:	d4000001 	svc	#0x0
    40201ce0:	b5000040 	cbnz	x0, 40201ce8 <_ZN11jnox_kernel14ordinary_mutex7checked17hecc6f8bc82302380E+0x14>
    40201ce4:	d65f03c0 	ret
    40201ce8:	f81f0ffe 	str	x30, [sp, #-16]!
    40201cec:	52800160 	mov	w0, #0xb                   	// #11
    40201cf0:	97fffe5c 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

0000000040201cf4 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E>:
    40201cf4:	f81c0ffe 	str	x30, [sp, #-64]!
    40201cf8:	a9015ff8 	stp	x24, x23, [sp, #16]
    40201cfc:	a90257f6 	stp	x22, x21, [sp, #32]
    40201d00:	a9034ff4 	stp	x20, x19, [sp, #48]
    40201d04:	90000028 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201d08:	f9400108 	ldr	x8, [x8]
    40201d0c:	f100091f 	cmp	x8, #0x2
    40201d10:	54001280 	b.eq	40201f60 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x26c>  // b.none
    40201d14:	aa0003f3 	mov	x19, x0
    40201d18:	97fffee0 	bl	40201898 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17h3e9ce961dab359aaE>
    40201d1c:	aa0003f4 	mov	x20, x0
    40201d20:	f9402276 	ldr	x22, [x19, #64]
    40201d24:	f9400275 	ldr	x21, [x19]
    40201d28:	f1000adf 	cmp	x22, #0x2
    40201d2c:	5400050c 	b.gt	40201dcc <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0xd8>
    40201d30:	f10006df 	cmp	x22, #0x1
    40201d34:	54000680 	b.eq	40201e04 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x110>  // b.none
    40201d38:	f1000adf 	cmp	x22, #0x2
    40201d3c:	540011a1 	b.ne	40201f70 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x27c>  // b.any
    40201d40:	d503201f 	nop
    40201d44:	100195f7 	adr	x23, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201d48:	aa1703e0 	mov	x0, x23
    40201d4c:	aa1403e1 	mov	x1, x20
    40201d50:	aa1503e2 	mov	x2, x21
    40201d54:	940003d2 	bl	40202c9c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E>
    40201d58:	f100081f 	cmp	x0, #0x2
    40201d5c:	540010e0 	b.eq	40201f78 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x284>  // b.none
    40201d60:	360002a0 	tbz	w0, #0, 40201db4 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0xc0>
    40201d64:	f1000c3f 	cmp	x1, #0x3
    40201d68:	540010c8 	b.hi	40201f80 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x28c>  // b.pmore
    40201d6c:	8b010ee8 	add	x8, x23, x1, lsl #3
    40201d70:	f9409508 	ldr	x8, [x8, #296]
    40201d74:	d503201f 	nop
    40201d78:	1001a249 	adr	x9, 402051c0 <_ZN11jnox_kernel14ordinary_mutex6STACKS17h3be57ef615508284E>
    40201d7c:	8b013929 	add	x9, x9, x1, lsl #14
    40201d80:	5287980a 	mov	w10, #0x3cc0                	// #15552
    40201d84:	8b0a012a 	add	x10, x9, x10
    40201d88:	eb08015f 	cmp	x10, x8
    40201d8c:	54001063 	b.cc	40201f98 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x2a4>  // b.lo, b.ul, b.last
    40201d90:	eb08013f 	cmp	x9, x8
    40201d94:	54001028 	b.hi	40201f98 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x2a4>  // b.pmore
    40201d98:	92400d09 	and	x9, x8, #0xf
    40201d9c:	b5000fe9 	cbnz	x9, 40201f98 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x2a4>
    40201da0:	f900011f 	str	xzr, [x8]
    40201da4:	d503201f 	nop
    40201da8:	100192c0 	adr	x0, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201dac:	2a1f03e2 	mov	w2, wzr
    40201db0:	97ffffb5 	bl	40201c84 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE>
    40201db4:	f900027f 	str	xzr, [x19]
    40201db8:	d503201f 	nop
    40201dbc:	10019220 	adr	x0, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201dc0:	aa1403e1 	mov	x1, x20
    40201dc4:	52800022 	mov	w2, #0x1                   	// #1
    40201dc8:	14000034 	b	40201e98 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x1a4>
    40201dcc:	f1000edf 	cmp	x22, #0x3
    40201dd0:	540001a0 	b.eq	40201e04 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x110>  // b.none
    40201dd4:	f10012df 	cmp	x22, #0x4
    40201dd8:	54000cc1 	b.ne	40201f70 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x27c>  // b.any
    40201ddc:	52800028 	mov	w8, #0x1                   	// #1
    40201de0:	1ad42108 	lsl	w8, w8, w20
    40201de4:	90000029 	adrp	x9, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201de8:	3945952a 	ldrb	w10, [x9, #357]
    40201dec:	2a080148 	orr	w8, w10, w8
    40201df0:	39059528 	strb	w8, [x9, #357]
    40201df4:	71003d1f 	cmp	w8, #0xf
    40201df8:	54000521 	b.ne	40201e9c <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x1a8>  // b.any
    40201dfc:	aa1f03e0 	mov	x0, xzr
    40201e00:	97fffe18 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40201e04:	d503201f 	nop
    40201e08:	10018fc0 	adr	x0, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201e0c:	aa1403e1 	mov	x1, x20
    40201e10:	aa1503e2 	mov	x2, x21
    40201e14:	94000369 	bl	40202bb8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE>
    40201e18:	72001c08 	ands	w8, w0, #0xff
    40201e1c:	54000240 	b.eq	40201e64 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x170>  // b.none
    40201e20:	7100091f 	cmp	w8, #0x2
    40201e24:	54000a20 	b.eq	40201f68 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x274>  // b.none
    40201e28:	f100069f 	cmp	x20, #0x1
    40201e2c:	540003c1 	b.ne	40201ea4 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x1b0>  // b.any
    40201e30:	f10006bf 	cmp	x21, #0x1
    40201e34:	54000381 	b.ne	40201ea4 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x1b0>  // b.any
    40201e38:	d503201f 	nop
    40201e3c:	10018e37 	adr	x23, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201e40:	aa1703e0 	mov	x0, x23
    40201e44:	52800061 	mov	w1, #0x3                   	// #3
    40201e48:	2a1f03e2 	mov	w2, wzr
    40201e4c:	97ffff8e 	bl	40201c84 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE>
    40201e50:	aa1703e0 	mov	x0, x23
    40201e54:	52800041 	mov	w1, #0x2                   	// #2
    40201e58:	2a1f03e2 	mov	w2, wzr
    40201e5c:	97ffff8a 	bl	40201c84 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE>
    40201e60:	1400002e 	b	40201f18 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x224>
    40201e64:	f1000edf 	cmp	x22, #0x3
    40201e68:	54000800 	b.eq	40201f68 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x274>  // b.none
    40201e6c:	f900027f 	str	xzr, [x19]
    40201e70:	d503201f 	nop
    40201e74:	10018c60 	adr	x0, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201e78:	aa1403e1 	mov	x1, x20
    40201e7c:	52800022 	mov	w2, #0x1                   	// #1
    40201e80:	97ffff81 	bl	40201c84 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE>
    40201e84:	b50000d4 	cbnz	x20, 40201e9c <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x1a8>
    40201e88:	d503201f 	nop
    40201e8c:	10018ba0 	adr	x0, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201e90:	52800021 	mov	w1, #0x1                   	// #1
    40201e94:	2a1f03e2 	mov	w2, wzr
    40201e98:	97ffff7b 	bl	40201c84 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE>
    40201e9c:	aa1f03f7 	mov	x23, xzr
    40201ea0:	1400001f 	b	40201f1c <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x228>
    40201ea4:	f1000e9f 	cmp	x20, #0x3
    40201ea8:	54000601 	b.ne	40201f68 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x274>  // b.any
    40201eac:	f1000edf 	cmp	x22, #0x3
    40201eb0:	540005c1 	b.ne	40201f68 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x274>  // b.any
    40201eb4:	b50005b5 	cbnz	x21, 40201f68 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x274>
    40201eb8:	d5033fdf 	isb
    40201ebc:	d53be028 	mrs	x8, cntpct_el0
    40201ec0:	90000029 	adrp	x9, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201ec4:	f940ad2a 	ldr	x10, [x9, #344]
    40201ec8:	d343fd49 	lsr	x9, x10, #3
    40201ecc:	d29ef9eb 	mov	x11, #0xf7cf                	// #63439
    40201ed0:	f2bc6a6b 	movk	x11, #0xe353, lsl #16
    40201ed4:	f2d374ab 	movk	x11, #0x9ba5, lsl #32
    40201ed8:	f2e4188b 	movk	x11, #0x20c4, lsl #48
    40201edc:	9bcb7d29 	umulh	x9, x9, x11
    40201ee0:	ab491109 	adds	x9, x8, x9, lsr #4
    40201ee4:	54000582 	b.cs	40201f94 <_ZN11jnox_kernel14ordinary_mutex7request17h63e5fa44932506e4E+0x2a0>  // b.hs, b.nlast
    40201ee8:	9000002b 	adrp	x11, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201eec:	9105416b 	add	x11, x11, #0x150
    40201ef0:	f9000169 	str	x9, [x11]
    40201ef4:	5280002c 	mov	w12, #0x1                   	// #1
    40201ef8:	d503201f 	nop
    40201efc:	1001946d 	adr	x13, 40205188 <_ZN11jnox_kernel14ordinary_mutex5TIMER17h079f39c6acd91389E>
    40201f00:	3900516c 	strb	w12, [x11, #20]
    40201f04:	a90021aa 	stp	x10, x8, [x13]
    40201f08:	f90009a9 	str	x9, [x13, #16]
    40201f0c:	d51be249 	msr	cntp_cval_el0, x9
    40201f10:	d51be22c 	msr	cntp_ctl_el0, x12
    40201f14:	d5033fdf 	isb
    40201f18:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    40201f1c:	d503201f 	nop
    40201f20:	10018700 	adr	x0, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201f24:	97fffe7f 	bl	40201920 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17hd980273460ecc890E>
    40201f28:	aa0003f8 	mov	x24, x0
    40201f2c:	aa1603e0 	mov	x0, x22
    40201f30:	aa1503e1 	mov	x1, x21
    40201f34:	aa1403e2 	mov	x2, x20
    40201f38:	aa1303e3 	mov	x3, x19
    40201f3c:	aa1803e4 	mov	x4, x24
    40201f40:	aa1703e5 	mov	x5, x23
    40201f44:	97fffeac 	bl	402019f4 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE>
    40201f48:	aa1803e0 	mov	x0, x24
    40201f4c:	a9434ff4 	ldp	x20, x19, [sp, #48]
    40201f50:	a94257f6 	ldp	x22, x21, [sp, #32]
    40201f54:	a9415ff8 	ldp	x24, x23, [sp, #16]
    40201f58:	f84407fe 	ldr	x30, [sp], #64
    40201f5c:	d65f03c0 	ret
    40201f60:	52800020 	mov	w0, #0x1                   	// #1
    40201f64:	97fffdbf 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40201f68:	528000c0 	mov	w0, #0x6                   	// #6
    40201f6c:	97fffdbd 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40201f70:	52800100 	mov	w0, #0x8                   	// #8
    40201f74:	97fffdbb 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40201f78:	528000e0 	mov	w0, #0x7                   	// #7
    40201f7c:	97fffdb9 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40201f80:	d503201f 	nop
    40201f84:	10012022 	adr	x2, 40204388 <anon.a10a9a1c8b04bc618efc151eec4051b8.0.llvm.10515195519271835186+0xc5>
    40201f88:	aa0103e0 	mov	x0, x1
    40201f8c:	52800081 	mov	w1, #0x4                   	// #4
    40201f90:	9400050d 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40201f94:	94000003 	bl	40201fa0 <_ZN11jnox_kernel14ordinary_mutex7request28_$u7b$$u7b$closure$u7d$$u7d$17hf6ad98a43e807364E>
    40201f98:	52800080 	mov	w0, #0x4                   	// #4
    40201f9c:	97fffdb1 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

0000000040201fa0 <_ZN11jnox_kernel14ordinary_mutex7request28_$u7b$$u7b$closure$u7d$$u7d$17hf6ad98a43e807364E>:
    40201fa0:	f81f0ffe 	str	x30, [sp, #-16]!
    40201fa4:	528000c0 	mov	w0, #0x6                   	// #6
    40201fa8:	97fffdae 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

0000000040201fac <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E>:
    40201fac:	f81e0ffe 	str	x30, [sp, #-32]!
    40201fb0:	a9014ff4 	stp	x20, x19, [sp, #16]
    40201fb4:	90000028 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201fb8:	f9400108 	ldr	x8, [x8]
    40201fbc:	f100091f 	cmp	x8, #0x2
    40201fc0:	54000ba0 	b.eq	40202134 <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x188>  // b.none
    40201fc4:	aa0003f3 	mov	x19, x0
    40201fc8:	97fffe34 	bl	40201898 <_ZN11jnox_kernel14ordinary_mutex7Runtime4save17h3e9ce961dab359aaE>
    40201fcc:	5280018a 	mov	w10, #0xc                   	// #12
    40201fd0:	72a1002a 	movk	w10, #0x801, lsl #16
    40201fd4:	b940014b 	ldr	w11, [x10]
    40201fd8:	d53be229 	mrs	x9, cntp_ctl_el0
    40201fdc:	d53be248 	mrs	x8, cntp_cval_el0
    40201fe0:	d51be23f 	msr	cntp_ctl_el0, xzr
    40201fe4:	d5033fdf 	isb
    40201fe8:	9000002c 	adrp	x12, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40201fec:	9106818c 	add	x12, x12, #0x1a0
    40201ff0:	a900258b 	stp	x11, x9, [x12]
    40201ff4:	f9000988 	str	x8, [x12, #16]
    40201ff8:	b900054b 	str	w11, [x10, #4]
    40201ffc:	d5033f9f 	dsb	sy
    40202000:	d5033fdf 	isb
    40202004:	1200256a 	and	w10, w11, #0x3ff
    40202008:	7100795f 	cmp	w10, #0x1e
    4020200c:	54000901 	b.ne	4020212c <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x180>  // b.any
    40202010:	b50008e0 	cbnz	x0, 4020212c <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x180>
    40202014:	f000000a 	adrp	x10, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40202018:	9105414a 	add	x10, x10, #0x150
    4020201c:	3940514b 	ldrb	w11, [x10, #20]
    40202020:	3600086b 	tbz	w11, #0, 4020212c <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x180>
    40202024:	92400929 	and	x9, x9, #0x7
    40202028:	f100153f 	cmp	x9, #0x5
    4020202c:	54000801 	b.ne	4020212c <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x180>  // b.any
    40202030:	f9400149 	ldr	x9, [x10]
    40202034:	eb09011f 	cmp	x8, x9
    40202038:	540007a1 	b.ne	4020212c <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x180>  // b.any
    4020203c:	f9409e69 	ldr	x9, [x19, #312]
    40202040:	eb08013f 	cmp	x9, x8
    40202044:	54000743 	b.cc	4020212c <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x180>  // b.lo, b.ul, b.last
    40202048:	d503201f 	nop
    4020204c:	10018b68 	adr	x8, 402051b8 <_ZN11jnox_kernel14ordinary_mutex6CHUNKS17h3cec01e2eeeb4508E.0>
    40202050:	c8dffd08 	ldar	x8, [x8]
    40202054:	d1000508 	sub	x8, x8, #0x1
    40202058:	5287ffc9 	mov	w9, #0x3ffe                	// #16382
    4020205c:	eb09011f 	cmp	x8, x9
    40202060:	54000668 	b.hi	4020212c <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x180>  // b.pmore
    40202064:	d503201f 	nop
    40202068:	10098ac8 	adr	x8, 402151c0 <_ZN11jnox_kernel14ordinary_mutex7IN_WORK17h3cf0d660ecd4af71E.0>
    4020206c:	c8dffd08 	ldar	x8, [x8]
    40202070:	f100051f 	cmp	x8, #0x1
    40202074:	540005c1 	b.ne	4020212c <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x180>  // b.any
    40202078:	d503201f 	nop
    4020207c:	10017c20 	adr	x0, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40202080:	52800061 	mov	w1, #0x3                   	// #3
    40202084:	94000380 	bl	40202e84 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7timeout17h03056121c932bc99E>
    40202088:	34000520 	cbz	w0, 4020212c <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x180>
    4020208c:	f0000008 	adrp	x8, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    40202090:	91050108 	add	x8, x8, #0x140
    40202094:	3900911f 	strb	wzr, [x8, #36]
    40202098:	f9400108 	ldr	x8, [x8]
    4020209c:	f0000069 	adrp	x9, 40211000 <_ZN11jnox_kernel14ordinary_mutex6STACKS17h3be57ef615508284E+0xbe40>
    402020a0:	91070129 	add	x9, x9, #0x1c0
    402020a4:	eb09011f 	cmp	x8, x9
    402020a8:	540004a3 	b.cc	4020213c <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x190>  // b.lo, b.ul, b.last
    402020ac:	92400d09 	and	x9, x8, #0xf
    402020b0:	b5000469 	cbnz	x9, 4020213c <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x190>
    402020b4:	d0000089 	adrp	x9, 40214000 <_ZN11jnox_kernel14ordinary_mutex6STACKS17h3be57ef615508284E+0xee40>
    402020b8:	913a0129 	add	x9, x9, #0xe80
    402020bc:	eb09011f 	cmp	x8, x9
    402020c0:	540003e8 	b.hi	4020213c <_ZN11jnox_kernel14ordinary_mutex9interrupt17h94daa8a7920335b6E+0x190>  // b.pmore
    402020c4:	52800029 	mov	w9, #0x1                   	// #1
    402020c8:	f9000109 	str	x9, [x8]
    402020cc:	d503201f 	nop
    402020d0:	10017994 	adr	x20, 40205000 <_ZN11jnox_kernel14ordinary_mutex6ACTIVE17h4e6d3dbb0cea3529E>
    402020d4:	aa1403e0 	mov	x0, x20
    402020d8:	aa1f03e1 	mov	x1, xzr
    402020dc:	52800022 	mov	w2, #0x1                   	// #1
    402020e0:	97fffee9 	bl	40201c84 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE>
    402020e4:	aa1403e0 	mov	x0, x20
    402020e8:	52800061 	mov	w1, #0x3                   	// #3
    402020ec:	2a1f03e2 	mov	w2, wzr
    402020f0:	97fffee5 	bl	40201c84 <_ZN11jnox_kernel14ordinary_mutex7Runtime7enqueue17hc9a866b2a59bbc0eE>
    402020f4:	aa1403e0 	mov	x0, x20
    402020f8:	97fffe0a 	bl	40201920 <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose17hd980273460ecc890E>
    402020fc:	aa0003f4 	mov	x20, x0
    40202100:	528000a0 	mov	w0, #0x5                   	// #5
    40202104:	aa1f03e1 	mov	x1, xzr
    40202108:	aa1f03e2 	mov	x2, xzr
    4020210c:	aa1303e3 	mov	x3, x19
    40202110:	aa1403e4 	mov	x4, x20
    40202114:	52800025 	mov	w5, #0x1                   	// #1
    40202118:	97fffe37 	bl	402019f4 <_ZN11jnox_kernel14ordinary_mutex7Runtime6record17h1d19b8c45513e54dE>
    4020211c:	aa1403e0 	mov	x0, x20
    40202120:	a9414ff4 	ldp	x20, x19, [sp, #16]
    40202124:	f84207fe 	ldr	x30, [sp], #32
    40202128:	d65f03c0 	ret
    4020212c:	52800120 	mov	w0, #0x9                   	// #9
    40202130:	97fffd4c 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    40202134:	52800020 	mov	w0, #0x1                   	// #1
    40202138:	97fffd4a 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>
    4020213c:	52800080 	mov	w0, #0x4                   	// #4
    40202140:	97fffd48 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

0000000040202144 <_RNvCsfLfy6EI15iL_7___rustc17rust_begin_unwind>:
    40202144:	d503205f 	wfe
    40202148:	17ffffff 	b	40202144 <_RNvCsfLfy6EI15iL_7___rustc17rust_begin_unwind>

000000004020214c <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E>:
    4020214c:	d10203ff 	sub	sp, sp, #0x80
    40202150:	f90023fe 	str	x30, [sp, #64]
    40202154:	a9055ff8 	stp	x24, x23, [sp, #80]
    40202158:	a90657f6 	stp	x22, x21, [sp, #96]
    4020215c:	a9074ff4 	stp	x20, x19, [sp, #112]
    40202160:	aa0103f3 	mov	x19, x1
    40202164:	f1000c3f 	cmp	x1, #0x3
    40202168:	54000c28 	b.hi	402022ec <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0x1a0>  // b.pmore
    4020216c:	aa1f03f5 	mov	x21, xzr
    40202170:	f9400014 	ldr	x20, [x0]
    40202174:	8b131696 	add	x22, x20, x19, lsl #5
    40202178:	910082c8 	add	x8, x22, #0x20
    4020217c:	910102c9 	add	x9, x22, #0x40
    40202180:	a902a7e8 	stp	x8, x9, [sp, #40]
    40202184:	d37bea78 	lsl	x24, x19, #5
    40202188:	910023e8 	add	x8, sp, #0x8
    4020218c:	f90007ff 	str	xzr, [sp, #8]
    40202190:	f9000fff 	str	xzr, [sp, #24]
    40202194:	9100c108 	add	x8, x8, #0x30
    40202198:	f9001ff4 	str	x20, [sp, #56]
    4020219c:	f90027e8 	str	x8, [sp, #72]
    402021a0:	928005e8 	mov	x8, #0xffffffffffffffd0    	// #-48
    402021a4:	cb160117 	sub	x23, x8, x22
    402021a8:	8b1502c8 	add	x8, x22, x21
    402021ac:	f9401109 	ldr	x9, [x8, #32]
    402021b0:	f100053f 	cmp	x9, #0x1
    402021b4:	540000a1 	b.ne	402021c8 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0x7c>  // b.any
    402021b8:	910123e0 	add	x0, sp, #0x48
    402021bc:	9100a101 	add	x1, x8, #0x28
    402021c0:	9400034b 	bl	40202eec <_ZN4core3ops8function5impls79_$LT$impl$u20$core..ops..function..FnMut$LT$A$GT$$u20$for$u20$$RF$mut$u20$F$GT$8call_mut17h748db8cf10bd7dfcE>
    402021c4:	370000c0 	tbnz	w0, #0, 402021dc <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0x90>
    402021c8:	910042b5 	add	x21, x21, #0x10
    402021cc:	f10082bf 	cmp	x21, #0x20
    402021d0:	54fffec1 	b.ne	402021a8 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0x5c>  // b.any
    402021d4:	2a1f03e8 	mov	w8, wzr
    402021d8:	1400001e 	b	40202250 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0x104>
    402021dc:	8b180288 	add	x8, x20, x24
    402021e0:	8b150109 	add	x9, x8, x21
    402021e4:	9100c128 	add	x8, x9, #0x30
    402021e8:	f90017e8 	str	x8, [sp, #40]
    402021ec:	f9401bea 	ldr	x10, [sp, #48]
    402021f0:	eb0a011f 	cmp	x8, x10
    402021f4:	540002c0 	b.eq	4020224c <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0x100>  // b.none
    402021f8:	f9401fe8 	ldr	x8, [sp, #56]
    402021fc:	9100e129 	add	x9, x9, #0x38
    40202200:	8b17014a 	add	x10, x10, x23
    40202204:	cb15014a 	sub	x10, x10, x21
    40202208:	d344fd4a 	lsr	x10, x10, #4
    4020220c:	f85f812b 	ldur	x11, [x9, #-8]
    40202210:	f100057f 	cmp	x11, #0x1
    40202214:	54000161 	b.ne	40202240 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0xf4>  // b.any
    40202218:	f9400120 	ldr	x0, [x9]
    4020221c:	f100041f 	cmp	x0, #0x1
    40202220:	540005e8 	b.hi	402022dc <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0x190>  // b.pmore
    40202224:	8b000d0b 	add	x11, x8, x0, lsl #3
    40202228:	3943916c 	ldrb	w12, [x11, #228]
    4020222c:	360000ac 	tbz	w12, #0, 40202240 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0xf4>
    40202230:	3943956b 	ldrb	w11, [x11, #229]
    40202234:	12001c2c 	and	w12, w1, #0xff
    40202238:	6b0b019f 	cmp	w12, w11
    4020223c:	1a8b8181 	csel	w1, w12, w11, hi  // hi = pmore
    40202240:	f100054a 	subs	x10, x10, #0x1
    40202244:	91004129 	add	x9, x9, #0x10
    40202248:	54fffe21 	b.ne	4020220c <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0xc0>  // b.any
    4020224c:	52800028 	mov	w8, #0x1                   	// #1
    40202250:	8b131289 	add	x9, x20, x19, lsl #4
    40202254:	f940512a 	ldr	x10, [x9, #160]
    40202258:	f100055f 	cmp	x10, #0x1
    4020225c:	540000e1 	b.ne	40202278 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0x12c>  // b.any
    40202260:	f9405520 	ldr	x0, [x9, #168]
    40202264:	f100041f 	cmp	x0, #0x1
    40202268:	540004c8 	b.hi	40202300 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0x1b4>  // b.pmore
    4020226c:	8b000e89 	add	x9, x20, x0, lsl #3
    40202270:	39439129 	ldrb	w9, [x9, #228]
    40202274:	360000a9 	tbz	w9, #0, 40202288 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0x13c>
    40202278:	8b130289 	add	x9, x20, x19
    4020227c:	3943e129 	ldrb	w9, [x9, #248]
    40202280:	d3607d29 	lsl	x9, x9, #32
    40202284:	1400000d 	b	402022b8 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0x16c>
    40202288:	8b001289 	add	x9, x20, x0, lsl #4
    4020228c:	b940012a 	ldr	w10, [x9]
    40202290:	f9400529 	ldr	x9, [x9, #8]
    40202294:	8b13028b 	add	x11, x20, x19
    40202298:	3943e16b 	ldrb	w11, [x11, #248]
    4020229c:	53081d29 	lsl	w9, w9, #24
    402022a0:	7100015f 	cmp	w10, #0x0
    402022a4:	9a9f1129 	csel	x9, x9, xzr, ne  // ne = any
    402022a8:	aa0b8129 	orr	x9, x9, x11, lsl #32
    402022ac:	52a0002a 	mov	w10, #0x10000               	// #65536
    402022b0:	9a9f114a 	csel	x10, x10, xzr, ne  // ne = any
    402022b4:	aa0a0129 	orr	x9, x9, x10
    402022b8:	2a0803e8 	mov	w8, w8
    402022bc:	b3781c28 	bfi	x8, x1, #8, #8
    402022c0:	8b090100 	add	x0, x8, x9
    402022c4:	a9474ff4 	ldp	x20, x19, [sp, #112]
    402022c8:	a94657f6 	ldp	x22, x21, [sp, #96]
    402022cc:	a9455ff8 	ldp	x24, x23, [sp, #80]
    402022d0:	f94023fe 	ldr	x30, [sp, #64]
    402022d4:	910203ff 	add	sp, sp, #0x80
    402022d8:	d65f03c0 	ret
    402022dc:	d503201f 	nop
    402022e0:	10010d82 	adr	x2, 40204490 <anon.2ee6e03bef39482496584c4320571626.8.llvm.17174990919417010942+0x30>
    402022e4:	52800041 	mov	w1, #0x2                   	// #2
    402022e8:	94000437 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    402022ec:	d503201f 	nop
    402022f0:	10010c42 	adr	x2, 40204478 <anon.2ee6e03bef39482496584c4320571626.8.llvm.17174990919417010942+0x18>
    402022f4:	aa1303e0 	mov	x0, x19
    402022f8:	52800081 	mov	w1, #0x4                   	// #4
    402022fc:	94000432 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40202300:	d503201f 	nop
    40202304:	10010d22 	adr	x2, 402044a8 <anon.2ee6e03bef39482496584c4320571626.8.llvm.17174990919417010942+0x48>
    40202308:	17fffff7 	b	402022e4 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E+0x198>

000000004020230c <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17hb359a444ecdeb373E>:
    4020230c:	d10083ff 	sub	sp, sp, #0x20
    40202310:	a9014ffe 	stp	x30, x19, [sp, #16]
    40202314:	f1000c3f 	cmp	x1, #0x3
    40202318:	54000188 	b.hi	40202348 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17hb359a444ecdeb373E+0x3c>  // b.pmore
    4020231c:	aa0103f3 	mov	x19, x1
    40202320:	f9400000 	ldr	x0, [x0]
    40202324:	9400014a 	bl	4020284c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.10515195519271835186>
    40202328:	36000100 	tbz	w0, #0, 40202348 <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17hb359a444ecdeb373E+0x3c>
    4020232c:	d348fc08 	lsr	x8, x0, #8
    40202330:	b9000fe8 	str	w8, [sp, #12]
    40202334:	910033e8 	add	x8, sp, #0xc
    40202338:	38736900 	ldrb	w0, [x8, x19]
    4020233c:	a9414ffe 	ldp	x30, x19, [sp, #16]
    40202340:	910083ff 	add	sp, sp, #0x20
    40202344:	d65f03c0 	ret
    40202348:	94000121 	bl	402027cc <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose28_$u7b$$u7b$closure$u7d$$u7d$28_$u7b$$u7b$closure$u7d$$u7d$17hcf4d62fb9f0f9b6fE.llvm.17174990919417010942>

000000004020234c <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E>:
    4020234c:	b40001a1 	cbz	x1, 40202380 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E+0x34>
    40202350:	8b010008 	add	x8, x0, x1
    40202354:	52800309 	mov	w9, #0x18                  	// #24
    40202358:	72a12009 	movk	w9, #0x900, lsl #16
    4020235c:	52a1200a 	mov	w10, #0x9000000             	// #150994944
    40202360:	3840140b 	ldrb	w11, [x0], #1
    40202364:	b940012c 	ldr	w12, [x9]
    40202368:	3628006c 	tbz	w12, #5, 40202374 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E+0x28>
    4020236c:	d5033fdf 	isb
    40202370:	17fffffd 	b	40202364 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E+0x18>
    40202374:	b900014b 	str	w11, [x10]
    40202378:	eb08001f 	cmp	x0, x8
    4020237c:	54ffff21 	b.ne	40202360 <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E+0x14>  // b.any
    40202380:	d65f03c0 	ret

0000000040202384 <_ZN11jnox_kernel11kernel_main17ha0f1dd4d6a7d76bdE>:
    40202384:	b00000a8 	adrp	x8, 40217000 <jnox_ap_returns+0x218>
    40202388:	f941f908 	ldr	x8, [x8, #1008]
    4020238c:	b4000068 	cbz	x8, 40202398 <_ZN11jnox_kernel11kernel_main17ha0f1dd4d6a7d76bdE+0x14>
    40202390:	d503205f 	wfe
    40202394:	17ffffff 	b	40202390 <_ZN11jnox_kernel11kernel_main17ha0f1dd4d6a7d76bdE+0xc>
    40202398:	f81f0ffe 	str	x30, [sp, #-16]!
    4020239c:	52800608 	mov	w8, #0x30                  	// #48
    402023a0:	72a12008 	movk	w8, #0x900, lsl #16
    402023a4:	b900011f 	str	wzr, [x8]
    402023a8:	528001a9 	mov	w9, #0xd                   	// #13
    402023ac:	5280002a 	mov	w10, #0x1                   	// #1
    402023b0:	b81f4109 	stur	w9, [x8, #-12]
    402023b4:	b81f810a 	stur	w10, [x8, #-8]
    402023b8:	52800c09 	mov	w9, #0x60                  	// #96
    402023bc:	b81fc109 	stur	w9, [x8, #-4]
    402023c0:	52802029 	mov	w9, #0x101                 	// #257
    402023c4:	b9000109 	str	w9, [x8]
    402023c8:	d503201f 	nop
    402023cc:	1000ff20 	adr	x0, 402043b0 <_ZN11jnox_kernel14ordinary_mutex5INPUT17h3acd42f53d4ce59fE+0x10>
    402023d0:	52800361 	mov	w1, #0x1b                  	// #27
    402023d4:	97ffffde 	bl	4020234c <_ZN11jnox_kernel10uart_write17habd6388f7b8c42a9E>
    402023d8:	97fffbd2 	bl	40201320 <_ZN11jnox_kernel14ordinary_mutex3run17h2e8d428f4d32a81cE>

00000000402023dc <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE>:
    402023dc:	f81f0ffe 	str	x30, [sp, #-16]!
    402023e0:	f9401009 	ldr	x9, [x0, #32]
    402023e4:	aa010128 	orr	x8, x9, x1
    402023e8:	f1000d1f 	cmp	x8, #0x3
    402023ec:	54000148 	b.hi	40202414 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x38>  // b.pmore
    402023f0:	aa1f03e8 	mov	x8, xzr
    402023f4:	8b090c0a 	add	x10, x0, x9, lsl #3
    402023f8:	d37df12b 	lsl	x11, x9, #3
    402023fc:	eb08017f 	cmp	x11, x8
    40202400:	540000e0 	b.eq	4020241c <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x40>  // b.none
    40202404:	f868680c 	ldr	x12, [x0, x8]
    40202408:	91002108 	add	x8, x8, #0x8
    4020240c:	eb01019f 	cmp	x12, x1
    40202410:	54ffff61 	b.ne	402023fc <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x20>  // b.any
    40202414:	2a1f03e8 	mov	w8, wzr
    40202418:	14000015 	b	4020246c <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x90>
    4020241c:	b4000209 	cbz	x9, 4020245c <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x80>
    40202420:	d1000528 	sub	x8, x9, #0x1
    40202424:	f100153f 	cmp	x9, #0x5
    40202428:	54000302 	b.cs	40202488 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0xac>  // b.hs, b.nlast
    4020242c:	f1000d1f 	cmp	x8, #0x3
    40202430:	54000240 	b.eq	40202478 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x9c>  // b.none
    40202434:	aa0a03eb 	mov	x11, x10
    40202438:	f85f8d6c 	ldr	x12, [x11, #-8]!
    4020243c:	f900014c 	str	x12, [x10]
    40202440:	d1000508 	sub	x8, x8, #0x1
    40202444:	b100051f 	cmn	x8, #0x1
    40202448:	aa0b03ea 	mov	x10, x11
    4020244c:	54fffec1 	b.ne	40202424 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x48>  // b.any
    40202450:	f9401008 	ldr	x8, [x0, #32]
    40202454:	91000509 	add	x9, x8, #0x1
    40202458:	14000002 	b	40202460 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0x84>
    4020245c:	52800029 	mov	w9, #0x1                   	// #1
    40202460:	f9000001 	str	x1, [x0]
    40202464:	52800028 	mov	w8, #0x1                   	// #1
    40202468:	f9001009 	str	x9, [x0, #32]
    4020246c:	2a0803e0 	mov	w0, w8
    40202470:	f84107fe 	ldr	x30, [sp], #16
    40202474:	d65f03c0 	ret
    40202478:	d503201f 	nop
    4020247c:	1000fda2 	adr	x2, 40204430 <anon.2ee6e03bef39482496584c4320571626.6.llvm.17174990919417010942>
    40202480:	52800080 	mov	w0, #0x4                   	// #4
    40202484:	14000004 	b	40202494 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$10push_front17h14ab78baca55ef5cE+0xb8>
    40202488:	d503201f 	nop
    4020248c:	1000fc62 	adr	x2, 40204418 <anon.2ee6e03bef39482496584c4320571626.5.llvm.17174990919417010942>
    40202490:	aa0803e0 	mov	x0, x8
    40202494:	52800081 	mov	w1, #0x4                   	// #4
    40202498:	940003cb 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

000000004020249c <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E>:
    4020249c:	f81f0ffe 	str	x30, [sp, #-16]!
    402024a0:	aa0103e9 	mov	x9, x1
    402024a4:	f9401001 	ldr	x1, [x0, #32]
    402024a8:	f100143f 	cmp	x1, #0x5
    402024ac:	540005a2 	b.cs	40202560 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E+0xc4>  // b.hs, b.nlast
    402024b0:	b40004c1 	cbz	x1, 40202548 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E+0xac>
    402024b4:	2a1f03eb 	mov	w11, wzr
    402024b8:	aa1f03ee 	mov	x14, xzr
    402024bc:	d37df02d 	lsl	x13, x1, #3
    402024c0:	f86e780a 	ldr	x10, [x0, x14, lsl #3]
    402024c4:	f100115f 	cmp	x10, #0x4
    402024c8:	54000562 	b.cs	40202574 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E+0xd8>  // b.hs, b.nlast
    402024cc:	386a692a 	ldrb	w10, [x9, x10]
    402024d0:	12001d4f 	and	w15, w10, #0xff
    402024d4:	6b2c01ff 	cmp	w15, w12, uxtb
    402024d8:	1a9f87ef 	cset	w15, ls  // ls = plast
    402024dc:	6a0f017f 	tst	w11, w15
    402024e0:	9a8e1108 	csel	x8, x8, x14, ne  // ne = any
    402024e4:	910005ce 	add	x14, x14, #0x1
    402024e8:	1a8a118c 	csel	w12, w12, w10, ne  // ne = any
    402024ec:	f10021ad 	subs	x13, x13, #0x8
    402024f0:	5280002b 	mov	w11, #0x1                   	// #1
    402024f4:	54fffe61 	b.ne	402024c0 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E+0x24>  // b.any
    402024f8:	f1000d1f 	cmp	x8, #0x3
    402024fc:	540004e8 	b.hi	40202598 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E+0xfc>  // b.pmore
    40202500:	f8687809 	ldr	x9, [x0, x8, lsl #3]
    40202504:	d100042a 	sub	x10, x1, #0x1
    40202508:	f900100a 	str	x10, [x0, #32]
    4020250c:	eb0a011f 	cmp	x8, x10
    40202510:	54000202 	b.cs	40202550 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E+0xb4>  // b.hs, b.nlast
    40202514:	8b080c0a 	add	x10, x0, x8, lsl #3
    40202518:	9100214a 	add	x10, x10, #0x8
    4020251c:	91000508 	add	x8, x8, #0x1
    40202520:	52800020 	mov	w0, #0x1                   	// #1
    40202524:	f100111f 	cmp	x8, #0x4
    40202528:	540002e0 	b.eq	40202584 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E+0xe8>  // b.none
    4020252c:	f940014b 	ldr	x11, [x10]
    40202530:	f81f814b 	stur	x11, [x10, #-8]
    40202534:	9100214a 	add	x10, x10, #0x8
    40202538:	91000508 	add	x8, x8, #0x1
    4020253c:	eb08003f 	cmp	x1, x8
    40202540:	54ffff21 	b.ne	40202524 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E+0x88>  // b.any
    40202544:	14000004 	b	40202554 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E+0xb8>
    40202548:	aa1f03e0 	mov	x0, xzr
    4020254c:	14000002 	b	40202554 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E+0xb8>
    40202550:	52800020 	mov	w0, #0x1                   	// #1
    40202554:	aa0903e1 	mov	x1, x9
    40202558:	f84107fe 	ldr	x30, [sp], #16
    4020255c:	d65f03c0 	ret
    40202560:	d503201f 	nop
    40202564:	1000f363 	adr	x3, 402043d0 <anon.2ee6e03bef39482496584c4320571626.2.llvm.17174990919417010942>
    40202568:	aa1f03e0 	mov	x0, xzr
    4020256c:	52800082 	mov	w2, #0x4                   	// #4
    40202570:	94000594 	bl	40203bc0 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>
    40202574:	d503201f 	nop
    40202578:	1000fe02 	adr	x2, 40204538 <anon.2ee6e03bef39482496584c4320571626.20.llvm.17174990919417010942>
    4020257c:	aa0a03e0 	mov	x0, x10
    40202580:	14000004 	b	40202590 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E+0xf4>
    40202584:	d503201f 	nop
    40202588:	1000f3c2 	adr	x2, 40204400 <anon.2ee6e03bef39482496584c4320571626.4.llvm.17174990919417010942>
    4020258c:	aa0803e0 	mov	x0, x8
    40202590:	52800081 	mov	w1, #0x4                   	// #4
    40202594:	9400038c 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40202598:	d503201f 	nop
    4020259c:	1000f262 	adr	x2, 402043e8 <anon.2ee6e03bef39482496584c4320571626.3.llvm.17174990919417010942>
    402025a0:	17fffffb 	b	4020258c <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$11pop_highest17h2fbbdaab3b329726E+0xf0>

00000000402025a4 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE>:
    402025a4:	f81f0ffe 	str	x30, [sp, #-16]!
    402025a8:	aa0003e8 	mov	x8, x0
    402025ac:	f9401000 	ldr	x0, [x0, #32]
    402025b0:	aa010009 	orr	x9, x0, x1
    402025b4:	f1000d3f 	cmp	x9, #0x3
    402025b8:	54000108 	b.hi	402025d8 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE+0x34>  // b.pmore
    402025bc:	d37df009 	lsl	x9, x0, #3
    402025c0:	aa0803ea 	mov	x10, x8
    402025c4:	b40000e9 	cbz	x9, 402025e0 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE+0x3c>
    402025c8:	f840854b 	ldr	x11, [x10], #8
    402025cc:	d1002129 	sub	x9, x9, #0x8
    402025d0:	eb01017f 	cmp	x11, x1
    402025d4:	54ffff81 	b.ne	402025c4 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE+0x20>  // b.any
    402025d8:	2a1f03e0 	mov	w0, wzr
    402025dc:	14000008 	b	402025fc <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE+0x58>
    402025e0:	f100101f 	cmp	x0, #0x4
    402025e4:	54000102 	b.cs	40202604 <_ZN11jnox_kernel11ready_queue19ReadyQueue$LT$_$GT$9push_back17h45fcd5bf98bf716bE+0x60>  // b.hs, b.nlast
    402025e8:	f8207901 	str	x1, [x8, x0, lsl #3]
    402025ec:	f9401109 	ldr	x9, [x8, #32]
    402025f0:	91000529 	add	x9, x9, #0x1
    402025f4:	f9001109 	str	x9, [x8, #32]
    402025f8:	52800020 	mov	w0, #0x1                   	// #1
    402025fc:	f84107fe 	ldr	x30, [sp], #16
    40202600:	d65f03c0 	ret
    40202604:	d503201f 	nop
    40202608:	1000f2c2 	adr	x2, 40204460 <anon.2ee6e03bef39482496584c4320571626.8.llvm.17174990919417010942>
    4020260c:	52800081 	mov	w1, #0x4                   	// #4
    40202610:	9400036d 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040202614 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE>:
    40202614:	d10083ff 	sub	sp, sp, #0x20
    40202618:	f9000bfe 	str	x30, [sp, #16]
    4020261c:	b9000fff 	str	wzr, [sp, #12]
    40202620:	29037fff 	stp	wzr, wzr, [sp, #24]
    40202624:	910033e8 	add	x8, sp, #0xc
    40202628:	91000809 	add	x9, x0, #0x2
    4020262c:	5280028a 	mov	w10, #0x14                  	// #20
    40202630:	910063eb 	add	x11, sp, #0x18
    40202634:	3940092c 	ldrb	w12, [x9, #2]
    40202638:	385ff12d 	ldurb	w13, [x9, #-1]
    4020263c:	385fe12e 	ldurb	w14, [x9, #-2]
    40202640:	6b0c01bf 	cmp	w13, w12
    40202644:	1a8c81ad 	csel	w13, w13, w12, hi  // hi = pmore
    40202648:	710001df 	cmp	w14, #0x0
    4020264c:	1a8c11ac 	csel	w12, w13, w12, ne  // ne = any
    40202650:	3900010c 	strb	w12, [x8]
    40202654:	3940012c 	ldrb	w12, [x9]
    40202658:	7100059f 	cmp	w12, #0x1
    4020265c:	540000e1 	b.ne	40202678 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x64>  // b.any
    40202660:	3940052c 	ldrb	w12, [x9, #1]
    40202664:	f1000d9f 	cmp	x12, #0x3
    40202668:	540007a8 	b.hi	4020275c <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x148>  // b.pmore
    4020266c:	386c696d 	ldrb	w13, [x11, x12]
    40202670:	110005ad 	add	w13, w13, #0x1
    40202674:	382c696d 	strb	w13, [x11, x12]
    40202678:	91001529 	add	x9, x9, #0x5
    4020267c:	91000508 	add	x8, x8, #0x1
    40202680:	f100154a 	subs	x10, x10, #0x5
    40202684:	54fffd81 	b.ne	40202634 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x20>  // b.any
    40202688:	aa1f03e8 	mov	x8, xzr
    4020268c:	aa1f03e9 	mov	x9, xzr
    40202690:	910063ea 	add	x10, sp, #0x18
    40202694:	910073eb 	add	x11, sp, #0x1c
    40202698:	3869694c 	ldrb	w12, [x10, x9]
    4020269c:	350000ac 	cbnz	w12, 402026b0 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x9c>
    402026a0:	f100111f 	cmp	x8, #0x4
    402026a4:	540007c2 	b.cs	4020279c <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x188>  // b.hs, b.nlast
    402026a8:	38286969 	strb	w9, [x11, x8]
    402026ac:	91000508 	add	x8, x8, #0x1
    402026b0:	91000529 	add	x9, x9, #0x1
    402026b4:	f100113f 	cmp	x9, #0x4
    402026b8:	54ffff01 	b.ne	40202698 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x84>  // b.any
    402026bc:	b4000548 	cbz	x8, 40202764 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x150>
    402026c0:	aa1f03eb 	mov	x11, xzr
    402026c4:	910073ec 	add	x12, sp, #0x1c
    402026c8:	910033ed 	add	x13, sp, #0xc
    402026cc:	910063ee 	add	x14, sp, #0x18
    402026d0:	f100117f 	cmp	x11, #0x4
    402026d4:	540005c0 	b.eq	4020278c <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x178>  // b.none
    402026d8:	386b698a 	ldrb	w10, [x12, x11]
    402026dc:	f100115f 	cmp	x10, #0x4
    402026e0:	540004e2 	b.cs	4020277c <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x168>  // b.hs, b.nlast
    402026e4:	8b0a0949 	add	x9, x10, x10, lsl #2
    402026e8:	8b090009 	add	x9, x0, x9
    402026ec:	3940092f 	ldrb	w15, [x9, #2]
    402026f0:	3600024f 	tbz	w15, #0, 40202738 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x124>
    402026f4:	39400d29 	ldrb	w9, [x9, #3]
    402026f8:	f100113f 	cmp	x9, #0x4
    402026fc:	54000562 	b.cs	402027a8 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x194>  // b.hs, b.nlast
    40202700:	386969af 	ldrb	w15, [x13, x9]
    40202704:	386a69aa 	ldrb	w10, [x13, x10]
    40202708:	386969d0 	ldrb	w16, [x14, x9]
    4020270c:	6b0f015f 	cmp	w10, w15
    40202710:	51000610 	sub	w16, w16, #0x1
    40202714:	1a8f814a 	csel	w10, w10, w15, hi  // hi = pmore
    40202718:	382969aa 	strb	w10, [x13, x9]
    4020271c:	72001e1f 	tst	w16, #0xff
    40202720:	382969d0 	strb	w16, [x14, x9]
    40202724:	540000a1 	b.ne	40202738 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x124>  // b.any
    40202728:	f1000d1f 	cmp	x8, #0x3
    4020272c:	54000468 	b.hi	402027b8 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x1a4>  // b.pmore
    40202730:	38286989 	strb	w9, [x12, x8]
    40202734:	91000508 	add	x8, x8, #0x1
    40202738:	9100056b 	add	x11, x11, #0x1
    4020273c:	eb08017f 	cmp	x11, x8
    40202740:	54fffc83 	b.cc	402026d0 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0xbc>  // b.lo, b.ul, b.last
    40202744:	f100117f 	cmp	x11, #0x4
    40202748:	1a9f17e8 	cset	w8, eq  // eq = none
    4020274c:	b9400fe9 	ldr	w9, [sp, #12]
    40202750:	d378dd29 	lsl	x9, x9, #8
    40202754:	9a9f0129 	csel	x9, x9, xzr, eq  // eq = none
    40202758:	14000004 	b	40202768 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x154>
    4020275c:	aa1f03e0 	mov	x0, xzr
    40202760:	14000004 	b	40202770 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x15c>
    40202764:	aa1f03e9 	mov	x9, xzr
    40202768:	2a0803e8 	mov	w8, w8
    4020276c:	aa080120 	orr	x0, x9, x8
    40202770:	f9400bfe 	ldr	x30, [sp, #16]
    40202774:	910083ff 	add	sp, sp, #0x20
    40202778:	d65f03c0 	ret
    4020277c:	d503201f 	nop
    40202780:	1000eac2 	adr	x2, 402044d8 <anon.2ee6e03bef39482496584c4320571626.8.llvm.17174990919417010942+0x78>
    40202784:	aa0a03e0 	mov	x0, x10
    40202788:	1400000f 	b	402027c4 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x1b0>
    4020278c:	d503201f 	nop
    40202790:	1000e982 	adr	x2, 402044c0 <anon.2ee6e03bef39482496584c4320571626.8.llvm.17174990919417010942+0x60>
    40202794:	52800080 	mov	w0, #0x4                   	// #4
    40202798:	1400000b 	b	402027c4 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x1b0>
    4020279c:	d503201f 	nop
    402027a0:	1000ec02 	adr	x2, 40204520 <anon.2ee6e03bef39482496584c4320571626.8.llvm.17174990919417010942+0xc0>
    402027a4:	14000007 	b	402027c0 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x1ac>
    402027a8:	d503201f 	nop
    402027ac:	1000ea22 	adr	x2, 402044f0 <anon.2ee6e03bef39482496584c4320571626.8.llvm.17174990919417010942+0x90>
    402027b0:	aa0903e0 	mov	x0, x9
    402027b4:	14000004 	b	402027c4 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE+0x1b0>
    402027b8:	d503201f 	nop
    402027bc:	1000ea62 	adr	x2, 40204508 <anon.2ee6e03bef39482496584c4320571626.8.llvm.17174990919417010942+0xa8>
    402027c0:	aa0803e0 	mov	x0, x8
    402027c4:	52800081 	mov	w1, #0x4                   	// #4
    402027c8:	940002ff 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

00000000402027cc <_ZN11jnox_kernel14ordinary_mutex7Runtime6choose28_$u7b$$u7b$closure$u7d$$u7d$28_$u7b$$u7b$closure$u7d$$u7d$17hcf4d62fb9f0f9b6fE.llvm.17174990919417010942>:
    402027cc:	f81f0ffe 	str	x30, [sp, #-16]!
    402027d0:	52800060 	mov	w0, #0x3                   	// #3
    402027d4:	97fffba3 	bl	40201660 <_ZN11jnox_kernel14ordinary_mutex4stop17hcd867233f9f23617E>

00000000402027d8 <_ZN11jnox_kernel7context14init_timer_irq17hd7766ccbde3e84bbE>:
    402027d8:	d503201f 	nop
    402027dc:	10ff0128 	adr	x8, 40200800 <sched_vectors>
    402027e0:	d518c008 	msr	vbar_el1, x8
    402027e4:	d51be23f 	msr	cntp_ctl_el0, xzr
    402027e8:	d5033fdf 	isb
    402027ec:	52a10008 	mov	w8, #0x8000000             	// #134217728
    402027f0:	b900011f 	str	wzr, [x8]
    402027f4:	52a10029 	mov	w9, #0x8010000             	// #134283264
    402027f8:	b900013f 	str	wzr, [x9]
    402027fc:	5280100a 	mov	w10, #0x80                  	// #128
    40202800:	72a1000a 	movk	w10, #0x800, lsl #16
    40202804:	b940014b 	ldr	w11, [x10]
    40202808:	1201796b 	and	w11, w11, #0xbfffffff
    4020280c:	b900014b 	str	w11, [x10]
    40202810:	5280100b 	mov	w11, #0x80                  	// #128
    40202814:	390e794b 	strb	w11, [x10, #926]
    40202818:	52a8000b 	mov	w11, #0x40000000            	// #1073741824
    4020281c:	b902014b 	str	w11, [x10, #512]
    40202820:	b900814b 	str	w11, [x10, #128]
    40202824:	5280008a 	mov	w10, #0x4                   	// #4
    40202828:	72a1002a 	movk	w10, #0x801, lsl #16
    4020282c:	52801feb 	mov	w11, #0xff                  	// #255
    40202830:	b900014b 	str	w11, [x10]
    40202834:	5280002a 	mov	w10, #0x1                   	// #1
    40202838:	b900010a 	str	w10, [x8]
    4020283c:	b900012a 	str	w10, [x9]
    40202840:	d5033f9f 	dsb	sy
    40202844:	d5033fdf 	isb
    40202848:	d65f03c0 	ret

000000004020284c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.10515195519271835186>:
    4020284c:	d10143ff 	sub	sp, sp, #0x50
    40202850:	f9001bfe 	str	x30, [sp, #48]
    40202854:	a9044ff4 	stp	x20, x19, [sp, #64]
    40202858:	aa1f03f3 	mov	x19, xzr
    4020285c:	f90007e0 	str	x0, [sp, #8]
    40202860:	910073f4 	add	x20, sp, #0x1c
    40202864:	910023e0 	add	x0, sp, #0x8
    40202868:	aa1303e1 	mov	x1, x19
    4020286c:	97fffe38 	bl	4020214c <_ZN113_$LT$core..ops..try_trait..Wrapped$LT$T$C$A$C$F$GT$$u20$as$u20$core..ops..function..FnMut$LT$$LP$A$C$$RP$$GT$$GT$8call_mut17ha2ab13ca9bfa4095E>
    40202870:	39000280 	strb	w0, [x20]
    40202874:	91000673 	add	x19, x19, #0x1
    40202878:	d358fc08 	lsr	x8, x0, #24
    4020287c:	39000e88 	strb	w8, [x20, #3]
    40202880:	d350fc08 	lsr	x8, x0, #16
    40202884:	d348fc09 	lsr	x9, x0, #8
    40202888:	39000a88 	strb	w8, [x20, #2]
    4020288c:	d360fc08 	lsr	x8, x0, #32
    40202890:	39000689 	strb	w9, [x20, #1]
    40202894:	39001288 	strb	w8, [x20, #4]
    40202898:	91001694 	add	x20, x20, #0x5
    4020289c:	f100127f 	cmp	x19, #0x4
    402028a0:	54fffe21 	b.ne	40202864 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.10515195519271835186+0x18>  // b.any
    402028a4:	3940b7e8 	ldrb	w8, [sp, #45]
    402028a8:	3940b3e9 	ldrb	w9, [sp, #44]
    402028ac:	3940bbea 	ldrb	w10, [sp, #46]
    402028b0:	3940bfeb 	ldrb	w11, [sp, #47]
    402028b4:	394087ec 	ldrb	w12, [sp, #33]
    402028b8:	2a082128 	orr	w8, w9, w8, lsl #8
    402028bc:	394083e9 	ldrb	w9, [sp, #32]
    402028c0:	2a0c2129 	orr	w9, w9, w12, lsl #8
    402028c4:	39408bec 	ldrb	w12, [sp, #34]
    402028c8:	53103d4a 	lsl	w10, w10, #16
    402028cc:	2a0b614a 	orr	w10, w10, w11, lsl #24
    402028d0:	39408feb 	ldrb	w11, [sp, #35]
    402028d4:	53103d8c 	lsl	w12, w12, #16
    402028d8:	2a0b618b 	orr	w11, w12, w11, lsl #24
    402028dc:	394077ec 	ldrb	w12, [sp, #29]
    402028e0:	2a080148 	orr	w8, w10, w8
    402028e4:	2a090169 	orr	w9, w11, w9
    402028e8:	b9001be8 	str	w8, [sp, #24]
    402028ec:	394073e8 	ldrb	w8, [sp, #28]
    402028f0:	aa0c2108 	orr	x8, x8, x12, lsl #8
    402028f4:	39407fea 	ldrb	w10, [sp, #31]
    402028f8:	39407beb 	ldrb	w11, [sp, #30]
    402028fc:	d370bd6b 	lsl	x11, x11, #16
    40202900:	aa0a616a 	orr	x10, x11, x10, lsl #24
    40202904:	aa080148 	orr	x8, x10, x8
    40202908:	aa098108 	orr	x8, x8, x9, lsl #32
    4020290c:	394097e9 	ldrb	w9, [sp, #37]
    40202910:	394093ea 	ldrb	w10, [sp, #36]
    40202914:	aa092149 	orr	x9, x10, x9, lsl #8
    40202918:	39409bea 	ldrb	w10, [sp, #38]
    4020291c:	d370bd4a 	lsl	x10, x10, #16
    40202920:	39409feb 	ldrb	w11, [sp, #39]
    40202924:	aa0b614a 	orr	x10, x10, x11, lsl #24
    40202928:	aa090149 	orr	x9, x10, x9
    4020292c:	910073ea 	add	x10, sp, #0x1c
    40202930:	9100214a 	add	x10, x10, #0x8
    40202934:	38404d4b 	ldrb	w11, [x10, #4]!
    40202938:	3940a7ec 	ldrb	w12, [sp, #41]
    4020293c:	2a0c216b 	orr	w11, w11, w12, lsl #8
    40202940:	3940094c 	ldrb	w12, [x10, #2]
    40202944:	53103d8c 	lsl	w12, w12, #16
    40202948:	39400d4a 	ldrb	w10, [x10, #3]
    4020294c:	2a0a618a 	orr	w10, w12, w10, lsl #24
    40202950:	2a0b014a 	orr	w10, w10, w11
    40202954:	aa0a8129 	orr	x9, x9, x10, lsl #32
    40202958:	a900a7e8 	stp	x8, x9, [sp, #8]
    4020295c:	910023e0 	add	x0, sp, #0x8
    40202960:	97ffff2d 	bl	40202614 <_ZN11jnox_kernel13domain_policy20effective_priorities17h346740b96dbd177aE>
    40202964:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40202968:	f9401bfe 	ldr	x30, [sp, #48]
    4020296c:	910143ff 	add	sp, sp, #0x50
    40202970:	d65f03c0 	ret

0000000040202974 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E.llvm.10515195519271835186>:
    40202974:	f81f0ffe 	str	x30, [sp, #-16]!
    40202978:	f1000c3f 	cmp	x1, #0x3
    4020297c:	540003e8 	b.hi	402029f8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E.llvm.10515195519271835186+0x84>  // b.pmore
    40202980:	8b010008 	add	x8, x0, x1
    40202984:	3943f108 	ldrb	w8, [x8, #252]
    40202988:	f100111f 	cmp	x8, #0x4
    4020298c:	540003e2 	b.cs	40202a08 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E.llvm.10515195519271835186+0x94>  // b.hs, b.nlast
    40202990:	8b081008 	add	x8, x0, x8, lsl #4
    40202994:	f900511f 	str	xzr, [x8, #160]
    40202998:	f940780a 	ldr	x10, [x0, #240]
    4020299c:	d1000548 	sub	x8, x10, #0x1
    402029a0:	f9007808 	str	x8, [x0, #240]
    402029a4:	eb08003f 	cmp	x1, x8
    402029a8:	540001a2 	b.cs	402029dc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E.llvm.10515195519271835186+0x68>  // b.hs, b.nlast
    402029ac:	8b000028 	add	x8, x1, x0
    402029b0:	9103f509 	add	x9, x8, #0xfd
    402029b4:	aa2103e8 	mvn	x8, x1
    402029b8:	cb0a03ea 	neg	x10, x10
    402029bc:	b100111f 	cmn	x8, #0x4
    402029c0:	54000120 	b.eq	402029e4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E.llvm.10515195519271835186+0x70>  // b.none
    402029c4:	3940012b 	ldrb	w11, [x9]
    402029c8:	381ff12b 	sturb	w11, [x9, #-1]
    402029cc:	91000529 	add	x9, x9, #0x1
    402029d0:	d1000508 	sub	x8, x8, #0x1
    402029d4:	eb08015f 	cmp	x10, x8
    402029d8:	54ffff21 	b.ne	402029bc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E.llvm.10515195519271835186+0x48>  // b.any
    402029dc:	f84107fe 	ldr	x30, [sp], #16
    402029e0:	d65f03c0 	ret
    402029e4:	cb0803e0 	neg	x0, x8
    402029e8:	d503201f 	nop
    402029ec:	1000de22 	adr	x2, 402045b0 <anon.a10a9a1c8b04bc618efc151eec4051b8.5.llvm.10515195519271835186>
    402029f0:	52800081 	mov	w1, #0x4                   	// #4
    402029f4:	94000274 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    402029f8:	d503201f 	nop
    402029fc:	1000dc22 	adr	x2, 40204580 <anon.a10a9a1c8b04bc618efc151eec4051b8.3.llvm.10515195519271835186>
    40202a00:	aa0103e0 	mov	x0, x1
    40202a04:	17fffffb 	b	402029f0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E.llvm.10515195519271835186+0x7c>
    40202a08:	d503201f 	nop
    40202a0c:	1000dc62 	adr	x2, 40204598 <anon.a10a9a1c8b04bc618efc151eec4051b8.4.llvm.10515195519271835186>
    40202a10:	aa0803e0 	mov	x0, x8
    40202a14:	17fffff7 	b	402029f0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E.llvm.10515195519271835186+0x7c>

0000000040202a18 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.10515195519271835186>:
    40202a18:	f81f0ffe 	str	x30, [sp, #-16]!
    40202a1c:	91028009 	add	x9, x0, #0xa0
    40202a20:	528000aa 	mov	w10, #0x5                   	// #5
    40202a24:	f100054a 	subs	x10, x10, #0x1
    40202a28:	54000240 	b.eq	40202a70 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.10515195519271835186+0x58>  // b.none
    40202a2c:	eb01005f 	cmp	x2, x1
    40202a30:	54000200 	b.eq	40202a70 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.10515195519271835186+0x58>  // b.none
    40202a34:	f1000c5f 	cmp	x2, #0x3
    40202a38:	54000228 	b.hi	40202a7c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.10515195519271835186+0x64>  // b.pmore
    40202a3c:	8b021128 	add	x8, x9, x2, lsl #4
    40202a40:	f940010b 	ldr	x11, [x8]
    40202a44:	f100057f 	cmp	x11, #0x1
    40202a48:	54000101 	b.ne	40202a68 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.10515195519271835186+0x50>  // b.any
    40202a4c:	f9400508 	ldr	x8, [x8, #8]
    40202a50:	f100091f 	cmp	x8, #0x2
    40202a54:	54000202 	b.cs	40202a94 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.10515195519271835186+0x7c>  // b.hs, b.nlast
    40202a58:	8b081008 	add	x8, x0, x8, lsl #4
    40202a5c:	b940010b 	ldr	w11, [x8]
    40202a60:	f9400502 	ldr	x2, [x8, #8]
    40202a64:	3707fe0b 	tbnz	w11, #0, 40202a24 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.10515195519271835186+0xc>
    40202a68:	2a1f03e0 	mov	w0, wzr
    40202a6c:	14000002 	b	40202a74 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.10515195519271835186+0x5c>
    40202a70:	52800020 	mov	w0, #0x1                   	// #1
    40202a74:	f84107fe 	ldr	x30, [sp], #16
    40202a78:	d65f03c0 	ret
    40202a7c:	d503201f 	nop
    40202a80:	1000da48 	adr	x8, 402045c8 <anon.a10a9a1c8b04bc618efc151eec4051b8.6.llvm.10515195519271835186>
    40202a84:	aa0203e0 	mov	x0, x2
    40202a88:	52800081 	mov	w1, #0x4                   	// #4
    40202a8c:	aa0803e2 	mov	x2, x8
    40202a90:	9400024d 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40202a94:	d503201f 	nop
    40202a98:	1000da42 	adr	x2, 402045e0 <anon.a10a9a1c8b04bc618efc151eec4051b8.7.llvm.10515195519271835186>
    40202a9c:	aa0803e0 	mov	x0, x8
    40202aa0:	52800041 	mov	w1, #0x2                   	// #2
    40202aa4:	94000248 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040202aa8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$3new17h6e64bc8051b703e1E>:
    40202aa8:	d10383ff 	sub	sp, sp, #0xe0
    40202aac:	f90063fe 	str	x30, [sp, #192]
    40202ab0:	a90d4ff4 	stp	x20, x19, [sp, #208]
    40202ab4:	2a0003f4 	mov	w20, w0
    40202ab8:	aa0803f3 	mov	x19, x8
    40202abc:	aa1f03e8 	mov	x8, xzr
    40202ac0:	b900cfe0 	str	w0, [sp, #204]
    40202ac4:	910333e9 	add	x9, sp, #0xcc
    40202ac8:	8b08002b 	add	x11, x1, x8
    40202acc:	b940016a 	ldr	w10, [x11]
    40202ad0:	5100054c 	sub	w12, w10, #0x1
    40202ad4:	71003d9f 	cmp	w12, #0xf
    40202ad8:	54000642 	b.cs	40202ba0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$3new17h6e64bc8051b703e1E+0xf8>  // b.hs, b.nlast
    40202adc:	3940116c 	ldrb	w12, [x11, #4]
    40202ae0:	7100059f 	cmp	w12, #0x1
    40202ae4:	540001a1 	b.ne	40202b18 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$3new17h6e64bc8051b703e1E+0x70>  // b.any
    40202ae8:	aa1f03ec 	mov	x12, xzr
    40202aec:	3940156b 	ldrb	w11, [x11, #5]
    40202af0:	f100119f 	cmp	x12, #0x4
    40202af4:	54000120 	b.eq	40202b18 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$3new17h6e64bc8051b703e1E+0x70>  // b.none
    40202af8:	aa0c03ed 	mov	x13, x12
    40202afc:	9100058c 	add	x12, x12, #0x1
    40202b00:	1acd254e 	lsr	w14, w10, w13
    40202b04:	3607ff6e 	tbz	w14, #0, 40202af0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$3new17h6e64bc8051b703e1E+0x48>
    40202b08:	386d692d 	ldrb	w13, [x9, x13]
    40202b0c:	6b0b01bf 	cmp	w13, w11
    40202b10:	54000488 	b.hi	40202ba0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$3new17h6e64bc8051b703e1E+0xf8>  // b.pmore
    40202b14:	17fffff7 	b	40202af0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$3new17h6e64bc8051b703e1E+0x48>
    40202b18:	91002108 	add	x8, x8, #0x8
    40202b1c:	f100411f 	cmp	x8, #0x10
    40202b20:	54fffd41 	b.ne	40202ac8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$3new17h6e64bc8051b703e1E+0x20>  // b.any
    40202b24:	aa1f03e8 	mov	x8, xzr
    40202b28:	910003e9 	mov	x9, sp
    40202b2c:	8b08012a 	add	x10, x9, x8
    40202b30:	f900015f 	str	xzr, [x10]
    40202b34:	f900095f 	str	xzr, [x10, #16]
    40202b38:	91008108 	add	x8, x8, #0x20
    40202b3c:	f102011f 	cmp	x8, #0x80
    40202b40:	54ffff61 	b.ne	40202b2c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$3new17h6e64bc8051b703e1E+0x84>  // b.any
    40202b44:	aa1f03e8 	mov	x8, xzr
    40202b48:	910203e9 	add	x9, sp, #0x80
    40202b4c:	f828693f 	str	xzr, [x9, x8]
    40202b50:	91004108 	add	x8, x8, #0x10
    40202b54:	f101011f 	cmp	x8, #0x40
    40202b58:	54ffffa1 	b.ne	40202b4c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$3new17h6e64bc8051b703e1E+0xa4>  // b.any
    40202b5c:	29402428 	ldp	w8, w9, [x1]
    40202b60:	291c2668 	stp	w8, w9, [x19, #224]
    40202b64:	29412428 	ldp	w8, w9, [x1, #8]
    40202b68:	291d2668 	stp	w8, w9, [x19, #232]
    40202b6c:	f900027f 	str	xzr, [x19]
    40202b70:	f9000a7f 	str	xzr, [x19, #16]
    40202b74:	91008260 	add	x0, x19, #0x20
    40202b78:	910003e1 	mov	x1, sp
    40202b7c:	52801002 	mov	w2, #0x80                  	// #128
    40202b80:	940004b4 	bl	40203e50 <memcpy>
    40202b84:	91028260 	add	x0, x19, #0xa0
    40202b88:	910203e1 	add	x1, sp, #0x80
    40202b8c:	52800802 	mov	w2, #0x40                  	// #64
    40202b90:	940004b0 	bl	40203e50 <memcpy>
    40202b94:	f9007a7f 	str	xzr, [x19, #240]
    40202b98:	291f7e74 	stp	w20, wzr, [x19, #248]
    40202b9c:	14000003 	b	40202ba8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$3new17h6e64bc8051b703e1E+0x100>
    40202ba0:	52800048 	mov	w8, #0x2                   	// #2
    40202ba4:	f9000268 	str	x8, [x19]
    40202ba8:	a94d4ff4 	ldp	x20, x19, [sp, #208]
    40202bac:	f94063fe 	ldr	x30, [sp, #192]
    40202bb0:	910383ff 	add	sp, sp, #0xe0
    40202bb4:	d65f03c0 	ret

0000000040202bb8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE>:
    40202bb8:	f1000c3f 	cmp	x1, #0x3
    40202bbc:	54000069 	b.ls	40202bc8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x10>  // b.plast
    40202bc0:	52800040 	mov	w0, #0x2                   	// #2
    40202bc4:	d65f03c0 	ret
    40202bc8:	a9bd5ffe 	stp	x30, x23, [sp, #-48]!
    40202bcc:	a90157f6 	stp	x22, x21, [sp, #16]
    40202bd0:	a9024ff4 	stp	x20, x19, [sp, #32]
    40202bd4:	aa0203f3 	mov	x19, x2
    40202bd8:	aa0103f4 	mov	x20, x1
    40202bdc:	aa0003f5 	mov	x21, x0
    40202be0:	8b011408 	add	x8, x0, x1, lsl #5
    40202be4:	91008108 	add	x8, x8, #0x20
    40202be8:	52800409 	mov	w9, #0x20                  	// #32
    40202bec:	f940010a 	ldr	x10, [x8]
    40202bf0:	b40000aa 	cbz	x10, 40202c04 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x4c>
    40202bf4:	91004108 	add	x8, x8, #0x10
    40202bf8:	f1004129 	subs	x9, x9, #0x10
    40202bfc:	54ffff81 	b.ne	40202bec <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x34>  // b.any
    40202c00:	1400000a 	b	40202c28 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x70>
    40202c04:	f100067f 	cmp	x19, #0x1
    40202c08:	54000108 	b.hi	40202c28 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x70>  // b.pmore
    40202c0c:	8b130ea9 	add	x9, x21, x19, lsl #3
    40202c10:	b940e129 	ldr	w9, [x9, #224]
    40202c14:	1ad42529 	lsr	w9, w9, w20
    40202c18:	36000089 	tbz	w9, #0, 40202c28 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x70>
    40202c1c:	8b1412b6 	add	x22, x21, x20, lsl #4
    40202c20:	f84a0ec9 	ldr	x9, [x22, #160]!
    40202c24:	b40000c9 	cbz	x9, 40202c3c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x84>
    40202c28:	52800040 	mov	w0, #0x2                   	// #2
    40202c2c:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40202c30:	a94157f6 	ldp	x22, x21, [sp, #16]
    40202c34:	a8c35ffe 	ldp	x30, x23, [sp], #48
    40202c38:	d65f03c0 	ret
    40202c3c:	8b1312a9 	add	x9, x21, x19, lsl #4
    40202c40:	f940012a 	ldr	x10, [x9]
    40202c44:	f100055f 	cmp	x10, #0x1
    40202c48:	54000201 	b.ne	40202c88 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0xd0>  // b.any
    40202c4c:	f9407ab7 	ldr	x23, [x21, #240]
    40202c50:	f1000eff 	cmp	x23, #0x3
    40202c54:	54fffea8 	b.hi	40202c28 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x70>  // b.pmore
    40202c58:	f9400522 	ldr	x2, [x9, #8]
    40202c5c:	aa1503e0 	mov	x0, x21
    40202c60:	aa1403e1 	mov	x1, x20
    40202c64:	97ffff6d 	bl	40202a18 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11would_cycle17h4b1e5089482b9563E.llvm.10515195519271835186>
    40202c68:	3707fe00 	tbnz	w0, #0, 40202c28 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x70>
    40202c6c:	8b1702a8 	add	x8, x21, x23
    40202c70:	3903f114 	strb	w20, [x8, #252]
    40202c74:	910006e8 	add	x8, x23, #0x1
    40202c78:	f9007aa8 	str	x8, [x21, #240]
    40202c7c:	52800020 	mov	w0, #0x1                   	// #1
    40202c80:	a9004ec0 	stp	x0, x19, [x22]
    40202c84:	17ffffea 	b	40202c2c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x74>
    40202c88:	2a1f03e0 	mov	w0, wzr
    40202c8c:	5280002a 	mov	w10, #0x1                   	// #1
    40202c90:	a9004d0a 	stp	x10, x19, [x8]
    40202c94:	a900512a 	stp	x10, x20, [x9]
    40202c98:	17ffffe5 	b	40202c2c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7acquire17he2232885cac9425eE+0x74>

0000000040202c9c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E>:
    40202c9c:	f81b0ffe 	str	x30, [sp, #-80]!
    40202ca0:	a90167fa 	stp	x26, x25, [sp, #16]
    40202ca4:	a9025ff8 	stp	x24, x23, [sp, #32]
    40202ca8:	a90357f6 	stp	x22, x21, [sp, #48]
    40202cac:	a9044ff4 	stp	x20, x19, [sp, #64]
    40202cb0:	f100045f 	cmp	x2, #0x1
    40202cb4:	540001c8 	b.hi	40202cec <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x50>  // b.pmore
    40202cb8:	aa0203f4 	mov	x20, x2
    40202cbc:	aa0003f3 	mov	x19, x0
    40202cc0:	8b021017 	add	x23, x0, x2, lsl #4
    40202cc4:	a94026e8 	ldp	x8, x9, [x23]
    40202cc8:	f100011f 	cmp	x8, #0x0
    40202ccc:	fa411120 	ccmp	x9, x1, #0x0, ne  // ne = any
    40202cd0:	540000e1 	b.ne	40202cec <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x50>  // b.any
    40202cd4:	f1000c3f 	cmp	x1, #0x3
    40202cd8:	54000be8 	b.hi	40202e54 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x1b8>  // b.pmore
    40202cdc:	91028279 	add	x25, x19, #0xa0
    40202ce0:	d37cec28 	lsl	x8, x1, #4
    40202ce4:	f8686b28 	ldr	x8, [x25, x8]
    40202ce8:	b4000148 	cbz	x8, 40202d10 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x74>
    40202cec:	52800056 	mov	w22, #0x2                   	// #2
    40202cf0:	aa1603e0 	mov	x0, x22
    40202cf4:	aa1503e1 	mov	x1, x21
    40202cf8:	a9444ff4 	ldp	x20, x19, [sp, #64]
    40202cfc:	a94357f6 	ldp	x22, x21, [sp, #48]
    40202d00:	a9425ff8 	ldp	x24, x23, [sp, #32]
    40202d04:	a94167fa 	ldp	x26, x25, [sp, #16]
    40202d08:	f84507fe 	ldr	x30, [sp], #80
    40202d0c:	d65f03c0 	ret
    40202d10:	9100827a 	add	x26, x19, #0x20
    40202d14:	8b011668 	add	x8, x19, x1, lsl #5
    40202d18:	91012118 	add	x24, x8, #0x48
    40202d1c:	928003e8 	mov	x8, #0xffffffffffffffe0    	// #-32
    40202d20:	52800056 	mov	w22, #0x2                   	// #2
    40202d24:	b4fffe68 	cbz	x8, 40202cf0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x54>
    40202d28:	f85e8309 	ldur	x9, [x24, #-24]
    40202d2c:	d1004318 	sub	x24, x24, #0x10
    40202d30:	91004108 	add	x8, x8, #0x10
    40202d34:	b4ffff89 	cbz	x9, 40202d24 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x88>
    40202d38:	f85f8308 	ldur	x8, [x24, #-8]
    40202d3c:	b4fffd88 	cbz	x8, 40202cec <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x50>
    40202d40:	f9400308 	ldr	x8, [x24]
    40202d44:	eb14011f 	cmp	x8, x20
    40202d48:	54fffd21 	b.ne	40202cec <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x50>  // b.any
    40202d4c:	aa1303e0 	mov	x0, x19
    40202d50:	97fffebf 	bl	4020284c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$10priorities17h557058def287d315E.llvm.10515195519271835186>
    40202d54:	3607fcc0 	tbz	w0, #0, 40202cec <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x50>
    40202d58:	d348fc08 	lsr	x8, x0, #8
    40202d5c:	b9000fe8 	str	w8, [sp, #12]
    40202d60:	f9407a68 	ldr	x8, [x19, #240]
    40202d64:	f100151f 	cmp	x8, #0x5
    40202d68:	540006a2 	b.cs	40202e3c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x1a0>  // b.hs, b.nlast
    40202d6c:	b4000568 	cbz	x8, 40202e18 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x17c>
    40202d70:	aa1f03eb 	mov	x11, xzr
    40202d74:	aa1f03e9 	mov	x9, xzr
    40202d78:	910033ea 	add	x10, sp, #0xc
    40202d7c:	8b09026c 	add	x12, x19, x9
    40202d80:	3943f180 	ldrb	w0, [x12, #252]
    40202d84:	f100101f 	cmp	x0, #0x4
    40202d88:	540006e2 	b.cs	40202e64 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x1c8>  // b.hs, b.nlast
    40202d8c:	8b00132c 	add	x12, x25, x0, lsl #4
    40202d90:	f940018d 	ldr	x13, [x12]
    40202d94:	f10005bf 	cmp	x13, #0x1
    40202d98:	54000241 	b.ne	40202de0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x144>  // b.any
    40202d9c:	f940058c 	ldr	x12, [x12, #8]
    40202da0:	eb14019f 	cmp	x12, x20
    40202da4:	540001e1 	b.ne	40202de0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x144>  // b.any
    40202da8:	f100057f 	cmp	x11, #0x1
    40202dac:	54000141 	b.ne	40202dd4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x138>  // b.any
    40202db0:	f10012bf 	cmp	x21, #0x4
    40202db4:	54000602 	b.cs	40202e74 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x1d8>  // b.hs, b.nlast
    40202db8:	3860694b 	ldrb	w11, [x10, x0]
    40202dbc:	3875694c 	ldrb	w12, [x10, x21]
    40202dc0:	6b0c017f 	cmp	w11, w12
    40202dc4:	9a818121 	csel	x1, x9, x1, hi  // hi = pmore
    40202dc8:	9a958015 	csel	x21, x0, x21, hi  // hi = pmore
    40202dcc:	5280002b 	mov	w11, #0x1                   	// #1
    40202dd0:	14000004 	b	40202de0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x144>
    40202dd4:	5280002b 	mov	w11, #0x1                   	// #1
    40202dd8:	aa0903e1 	mov	x1, x9
    40202ddc:	aa0003f5 	mov	x21, x0
    40202de0:	91000529 	add	x9, x9, #0x1
    40202de4:	eb09011f 	cmp	x8, x9
    40202de8:	54fffca1 	b.ne	40202d7c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0xe0>  // b.any
    40202dec:	f100057f 	cmp	x11, #0x1
    40202df0:	54000141 	b.ne	40202e18 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x17c>  // b.any
    40202df4:	8b151748 	add	x8, x26, x21, lsl #5
    40202df8:	52800409 	mov	w9, #0x20                  	// #32
    40202dfc:	52800056 	mov	w22, #0x2                   	// #2
    40202e00:	f940010a 	ldr	x10, [x8]
    40202e04:	b400012a 	cbz	x10, 40202e28 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x18c>
    40202e08:	91004108 	add	x8, x8, #0x10
    40202e0c:	f1004129 	subs	x9, x9, #0x10
    40202e10:	54ffff81 	b.ne	40202e00 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x164>  // b.any
    40202e14:	17ffffb7 	b	40202cf0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x54>
    40202e18:	aa1f03f6 	mov	x22, xzr
    40202e1c:	f81f831f 	stur	xzr, [x24, #-8]
    40202e20:	a90056f6 	stp	x22, x21, [x23]
    40202e24:	17ffffb3 	b	40202cf0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x54>
    40202e28:	52800036 	mov	w22, #0x1                   	// #1
    40202e2c:	a9005116 	stp	x22, x20, [x8]
    40202e30:	aa1303e0 	mov	x0, x19
    40202e34:	97fffed0 	bl	40202974 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E.llvm.10515195519271835186>
    40202e38:	17fffff9 	b	40202e1c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x180>
    40202e3c:	d503201f 	nop
    40202e40:	1000be83 	adr	x3, 40204610 <anon.a10a9a1c8b04bc618efc151eec4051b8.7.llvm.10515195519271835186+0x30>
    40202e44:	aa1f03e0 	mov	x0, xzr
    40202e48:	aa0803e1 	mov	x1, x8
    40202e4c:	52800082 	mov	w2, #0x4                   	// #4
    40202e50:	9400035c 	bl	40203bc0 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>
    40202e54:	d503201f 	nop
    40202e58:	1000bd02 	adr	x2, 402045f8 <anon.a10a9a1c8b04bc618efc151eec4051b8.7.llvm.10515195519271835186+0x18>
    40202e5c:	aa0103e0 	mov	x0, x1
    40202e60:	14000003 	b	40202e6c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x1d0>
    40202e64:	d503201f 	nop
    40202e68:	1000be02 	adr	x2, 40204628 <anon.a10a9a1c8b04bc618efc151eec4051b8.7.llvm.10515195519271835186+0x48>
    40202e6c:	52800081 	mov	w1, #0x4                   	// #4
    40202e70:	94000155 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>
    40202e74:	d503201f 	nop
    40202e78:	1000be42 	adr	x2, 40204640 <anon.a10a9a1c8b04bc618efc151eec4051b8.7.llvm.10515195519271835186+0x60>
    40202e7c:	aa1503e0 	mov	x0, x21
    40202e80:	17fffffb 	b	40202e6c <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7release17h9dbe586c57c7cf00E+0x1d0>

0000000040202e84 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7timeout17h03056121c932bc99E>:
    40202e84:	f81f0ffe 	str	x30, [sp, #-16]!
    40202e88:	aa0103e8 	mov	x8, x1
    40202e8c:	f9407801 	ldr	x1, [x0, #240]
    40202e90:	f100143f 	cmp	x1, #0x5
    40202e94:	54000222 	b.cs	40202ed8 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7timeout17h03056121c932bc99E+0x54>  // b.hs, b.nlast
    40202e98:	b4000121 	cbz	x1, 40202ebc <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7timeout17h03056121c932bc99E+0x38>
    40202e9c:	aa1f03e9 	mov	x9, xzr
    40202ea0:	8b09000a 	add	x10, x0, x9
    40202ea4:	3943f14a 	ldrb	w10, [x10, #252]
    40202ea8:	eb0a011f 	cmp	x8, x10
    40202eac:	540000c0 	b.eq	40202ec4 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7timeout17h03056121c932bc99E+0x40>  // b.none
    40202eb0:	91000529 	add	x9, x9, #0x1
    40202eb4:	eb09003f 	cmp	x1, x9
    40202eb8:	54ffff41 	b.ne	40202ea0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7timeout17h03056121c932bc99E+0x1c>  // b.any
    40202ebc:	2a1f03e0 	mov	w0, wzr
    40202ec0:	14000004 	b	40202ed0 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$7timeout17h03056121c932bc99E+0x4c>
    40202ec4:	aa0903e1 	mov	x1, x9
    40202ec8:	97fffeab 	bl	40202974 <_ZN11jnox_kernel12mutex_policy20LockSet$LT$_$C$_$GT$11remove_wait17h814f552bec729d43E.llvm.10515195519271835186>
    40202ecc:	52800020 	mov	w0, #0x1                   	// #1
    40202ed0:	f84107fe 	ldr	x30, [sp], #16
    40202ed4:	d65f03c0 	ret
    40202ed8:	d503201f 	nop
    40202edc:	1000bbe3 	adr	x3, 40204658 <anon.a10a9a1c8b04bc618efc151eec4051b8.12.llvm.10515195519271835186>
    40202ee0:	aa1f03e0 	mov	x0, xzr
    40202ee4:	52800082 	mov	w2, #0x4                   	// #4
    40202ee8:	94000336 	bl	40203bc0 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>

0000000040202eec <_ZN4core3ops8function5impls79_$LT$impl$u20$core..ops..function..FnMut$LT$A$GT$$u20$for$u20$$RF$mut$u20$F$GT$8call_mut17h748db8cf10bd7dfcE>:
    40202eec:	aa0003e8 	mov	x8, x0
    40202ef0:	f9400020 	ldr	x0, [x1]
    40202ef4:	f100041f 	cmp	x0, #0x1
    40202ef8:	54000108 	b.hi	40202f18 <_ZN4core3ops8function5impls79_$LT$impl$u20$core..ops..function..FnMut$LT$A$GT$$u20$for$u20$$RF$mut$u20$F$GT$8call_mut17h748db8cf10bd7dfcE+0x2c>  // b.pmore
    40202efc:	f9400108 	ldr	x8, [x8]
    40202f00:	f9400108 	ldr	x8, [x8]
    40202f04:	8b000d08 	add	x8, x8, x0, lsl #3
    40202f08:	39439100 	ldrb	w0, [x8, #228]
    40202f0c:	36000040 	tbz	w0, #0, 40202f14 <_ZN4core3ops8function5impls79_$LT$impl$u20$core..ops..function..FnMut$LT$A$GT$$u20$for$u20$$RF$mut$u20$F$GT$8call_mut17h748db8cf10bd7dfcE+0x28>
    40202f10:	39439501 	ldrb	w1, [x8, #229]
    40202f14:	d65f03c0 	ret
    40202f18:	f81f0ffe 	str	x30, [sp, #-16]!
    40202f1c:	d503201f 	nop
    40202f20:	1000b182 	adr	x2, 40204550 <anon.a10a9a1c8b04bc618efc151eec4051b8.1.llvm.10515195519271835186>
    40202f24:	52800041 	mov	w1, #0x2                   	// #2
    40202f28:	94000127 	bl	402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>

0000000040202f2c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral>:
    40202f2c:	d101c3ff 	sub	sp, sp, #0x70
    40202f30:	a9017bfd 	stp	x29, x30, [sp, #16]
    40202f34:	a9026ffc 	stp	x28, x27, [sp, #32]
    40202f38:	a90367fa 	stp	x26, x25, [sp, #48]
    40202f3c:	a9045ff8 	stp	x24, x23, [sp, #64]
    40202f40:	a90557f6 	stp	x22, x21, [sp, #80]
    40202f44:	a9064ff4 	stp	x20, x19, [sp, #96]
    40202f48:	910043fd 	add	x29, sp, #0x10
    40202f4c:	b940101a 	ldr	w26, [x0, #16]
    40202f50:	52a00229 	mov	w9, #0x110000              	// #1114112
    40202f54:	aa0503f3 	mov	x19, x5
    40202f58:	aa0403fc 	mov	x28, x4
    40202f5c:	aa0303f6 	mov	x22, x3
    40202f60:	aa0003f5 	mov	x21, x0
    40202f64:	926b0348 	and	x8, x26, #0x200000
    40202f68:	d355574a 	ubfx	x10, x26, #21, #1
    40202f6c:	7100011f 	cmp	w8, #0x0
    40202f70:	52800568 	mov	w8, #0x2b                  	// #43
    40202f74:	1a880128 	csel	w8, w9, w8, eq  // eq = none
    40202f78:	7100003f 	cmp	w1, #0x0
    40202f7c:	528005a9 	mov	w9, #0x2d                  	// #45
    40202f80:	9a9f154a 	csinc	x10, x10, xzr, ne  // ne = any
    40202f84:	1a891118 	csel	w24, w8, w9, ne  // ne = any
    40202f88:	8b05015b 	add	x27, x10, x5
    40202f8c:	37b8033a 	tbnz	w26, #23, 40202ff0 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0xc4>
    40202f90:	aa1f03f7 	mov	x23, xzr
    40202f94:	79402ab4 	ldrh	w20, [x21, #20]
    40202f98:	eb14037f 	cmp	x27, x20
    40202f9c:	54001503 	b.cc	4020323c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x310>  // b.lo, b.ul, b.last
    40202fa0:	a94056b9 	ldp	x25, x21, [x21]
    40202fa4:	2a1803e2 	mov	w2, w24
    40202fa8:	aa1703e3 	mov	x3, x23
    40202fac:	aa1603e4 	mov	x4, x22
    40202fb0:	aa1903e0 	mov	x0, x25
    40202fb4:	aa1503e1 	mov	x1, x21
    40202fb8:	9400032f 	bl	40203c74 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix>
    40202fbc:	37001d60 	tbnz	w0, #0, 40203368 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    40202fc0:	f9400ea3 	ldr	x3, [x21, #24]
    40202fc4:	aa1903e0 	mov	x0, x25
    40202fc8:	aa1c03e1 	mov	x1, x28
    40202fcc:	aa1303e2 	mov	x2, x19
    40202fd0:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40202fd4:	a94557f6 	ldp	x22, x21, [sp, #80]
    40202fd8:	a9445ff8 	ldp	x24, x23, [sp, #64]
    40202fdc:	a94367fa 	ldp	x26, x25, [sp, #48]
    40202fe0:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40202fe4:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40202fe8:	9101c3ff 	add	sp, sp, #0x70
    40202fec:	d61f0060 	br	x3
    40202ff0:	aa0203f7 	mov	x23, x2
    40202ff4:	f10082df 	cmp	x22, #0x20
    40202ff8:	540000e2 	b.cs	40203014 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0xe8>  // b.hs, b.nlast
    40202ffc:	b4000156 	cbz	x22, 40203024 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0xf8>
    40203000:	f10022df 	cmp	x22, #0x8
    40203004:	54000142 	b.cs	4020302c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x100>  // b.hs, b.nlast
    40203008:	aa1f03e8 	mov	x8, xzr
    4020300c:	aa1f03e0 	mov	x0, xzr
    40203010:	14000080 	b	40203210 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x2e4>
    40203014:	aa1703e0 	mov	x0, x23
    40203018:	aa1603e1 	mov	x1, x22
    4020301c:	94000102 	bl	40203424 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars>
    40203020:	14000083 	b	4020322c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x300>
    40203024:	aa1f03e0 	mov	x0, xzr
    40203028:	14000081 	b	4020322c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x300>
    4020302c:	aa1703ea 	mov	x10, x23
    40203030:	39400ae9 	ldrb	w9, [x23, #2]
    40203034:	394006e8 	ldrb	w8, [x23, #1]
    40203038:	38404d4b 	ldrb	w11, [x10, #4]!
    4020303c:	3940094c 	ldrb	w12, [x10, #2]
    40203040:	394002ed 	ldrb	w13, [x23]
    40203044:	39400eee 	ldrb	w14, [x23, #3]
    40203048:	d370bd29 	lsl	x9, x9, #16
    4020304c:	394016ef 	ldrb	w15, [x23, #5]
    40203050:	39400d4a 	ldrb	w10, [x10, #3]
    40203054:	53103d8c 	lsl	w12, w12, #16
    40203058:	aa0821a8 	orr	x8, x13, x8, lsl #8
    4020305c:	aa0e6129 	orr	x9, x9, x14, lsl #24
    40203060:	0f05e7e4 	movi	v4.8b, #0xbf
    40203064:	2a0f216b 	orr	w11, w11, w15, lsl #8
    40203068:	2a0a618a 	orr	w10, w12, w10, lsl #24
    4020306c:	aa080128 	orr	x8, x9, x8
    40203070:	2a0b0149 	orr	w9, w10, w11
    40203074:	aa098108 	orr	x8, x8, x9, lsl #32
    40203078:	9e670100 	fmov	d0, x8
    4020307c:	52800028 	mov	w8, #0x1                   	// #1
    40203080:	4e080d03 	dup	v3.2d, x8
    40203084:	927d06c8 	and	x8, x22, #0x18
    40203088:	f100211f 	cmp	x8, #0x8
    4020308c:	0e243400 	cmgt	v0.8b, v0.8b, v4.8b
    40203090:	2f08a400 	uxtl	v0.8h, v0.8b
    40203094:	6f10a401 	uxtl2	v1.4s, v0.8h
    40203098:	2f10a400 	uxtl	v0.4s, v0.4h
    4020309c:	6f20a422 	uxtl2	v2.2d, v1.4s
    402030a0:	2f20a421 	uxtl	v1.2d, v1.2s
    402030a4:	6f20a405 	uxtl2	v5.2d, v0.4s
    402030a8:	2f20a406 	uxtl	v6.2d, v0.2s
    402030ac:	4e231c40 	and	v0.16b, v2.16b, v3.16b
    402030b0:	4e231c22 	and	v2.16b, v1.16b, v3.16b
    402030b4:	4e231ca1 	and	v1.16b, v5.16b, v3.16b
    402030b8:	4e231cc3 	and	v3.16b, v6.16b, v3.16b
    402030bc:	540009c0 	b.eq	402031f4 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x2c8>  // b.none
    402030c0:	aa1703e9 	mov	x9, x23
    402030c4:	f100411f 	cmp	x8, #0x10
    402030c8:	38408d2a 	ldrb	w10, [x9, #8]!
    402030cc:	3940052b 	ldrb	w11, [x9, #1]
    402030d0:	39400d2c 	ldrb	w12, [x9, #3]
    402030d4:	3940092d 	ldrb	w13, [x9, #2]
    402030d8:	3940152e 	ldrb	w14, [x9, #5]
    402030dc:	38404d2f 	ldrb	w15, [x9, #4]!
    402030e0:	39400930 	ldrb	w16, [x9, #2]
    402030e4:	39400d29 	ldrb	w9, [x9, #3]
    402030e8:	d370bdad 	lsl	x13, x13, #16
    402030ec:	aa0b214a 	orr	x10, x10, x11, lsl #8
    402030f0:	53103e10 	lsl	w16, w16, #16
    402030f4:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    402030f8:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    402030fc:	2a096209 	orr	w9, w16, w9, lsl #24
    40203100:	aa0a018a 	orr	x10, x12, x10
    40203104:	2a0b0129 	orr	w9, w9, w11
    40203108:	aa098149 	orr	x9, x10, x9, lsl #32
    4020310c:	9e670125 	fmov	d5, x9
    40203110:	52800029 	mov	w9, #0x1                   	// #1
    40203114:	4e080d26 	dup	v6.2d, x9
    40203118:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    4020311c:	2f08a484 	uxtl	v4.8h, v4.8b
    40203120:	6f10a485 	uxtl2	v5.4s, v4.8h
    40203124:	2f10a484 	uxtl	v4.4s, v4.4h
    40203128:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    4020312c:	2f20a490 	uxtl	v16.2d, v4.2s
    40203130:	6f20a484 	uxtl2	v4.2d, v4.4s
    40203134:	2f20a4a5 	uxtl	v5.2d, v5.2s
    40203138:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    4020313c:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    40203140:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    40203144:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    40203148:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    4020314c:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40203150:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    40203154:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40203158:	540004e0 	b.eq	402031f4 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x2c8>  // b.none
    4020315c:	aa1703e9 	mov	x9, x23
    40203160:	0f05e7e4 	movi	v4.8b, #0xbf
    40203164:	38410d2a 	ldrb	w10, [x9, #16]!
    40203168:	3940052b 	ldrb	w11, [x9, #1]
    4020316c:	39400d2c 	ldrb	w12, [x9, #3]
    40203170:	3940092d 	ldrb	w13, [x9, #2]
    40203174:	3940152e 	ldrb	w14, [x9, #5]
    40203178:	38404d2f 	ldrb	w15, [x9, #4]!
    4020317c:	39400930 	ldrb	w16, [x9, #2]
    40203180:	39400d29 	ldrb	w9, [x9, #3]
    40203184:	d370bdad 	lsl	x13, x13, #16
    40203188:	aa0b214a 	orr	x10, x10, x11, lsl #8
    4020318c:	53103e10 	lsl	w16, w16, #16
    40203190:	2a0e21eb 	orr	w11, w15, w14, lsl #8
    40203194:	aa0c61ac 	orr	x12, x13, x12, lsl #24
    40203198:	2a096209 	orr	w9, w16, w9, lsl #24
    4020319c:	aa0a018a 	orr	x10, x12, x10
    402031a0:	2a0b0129 	orr	w9, w9, w11
    402031a4:	aa098149 	orr	x9, x10, x9, lsl #32
    402031a8:	9e670125 	fmov	d5, x9
    402031ac:	52800029 	mov	w9, #0x1                   	// #1
    402031b0:	4e080d26 	dup	v6.2d, x9
    402031b4:	0e2434a4 	cmgt	v4.8b, v5.8b, v4.8b
    402031b8:	2f08a484 	uxtl	v4.8h, v4.8b
    402031bc:	6f10a485 	uxtl2	v5.4s, v4.8h
    402031c0:	2f10a484 	uxtl	v4.4s, v4.4h
    402031c4:	6f20a4a7 	uxtl2	v7.2d, v5.4s
    402031c8:	2f20a490 	uxtl	v16.2d, v4.2s
    402031cc:	6f20a484 	uxtl2	v4.2d, v4.4s
    402031d0:	2f20a4a5 	uxtl	v5.2d, v5.2s
    402031d4:	4e261ce7 	and	v7.16b, v7.16b, v6.16b
    402031d8:	4e261e10 	and	v16.16b, v16.16b, v6.16b
    402031dc:	4e261c84 	and	v4.16b, v4.16b, v6.16b
    402031e0:	4e261ca5 	and	v5.16b, v5.16b, v6.16b
    402031e4:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    402031e8:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    402031ec:	4ef08463 	add	v3.2d, v3.2d, v16.2d
    402031f0:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    402031f4:	4ee28462 	add	v2.2d, v3.2d, v2.2d
    402031f8:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    402031fc:	eb0802df 	cmp	x22, x8
    40203200:	4ee08440 	add	v0.2d, v2.2d, v0.2d
    40203204:	5ef1b800 	addp	d0, v0.2d
    40203208:	9e660000 	fmov	x0, d0
    4020320c:	54000100 	b.eq	4020322c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x300>  // b.none
    40203210:	cb0802c9 	sub	x9, x22, x8
    40203214:	8b0802e8 	add	x8, x23, x8
    40203218:	38c0150a 	ldrsb	w10, [x8], #1
    4020321c:	3101055f 	cmn	w10, #0x41
    40203220:	9a80d400 	cinc	x0, x0, gt
    40203224:	f1000529 	subs	x9, x9, #0x1
    40203228:	54ffff81 	b.ne	40203218 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x2ec>  // b.any
    4020322c:	8b1b001b 	add	x27, x0, x27
    40203230:	79402ab4 	ldrh	w20, [x21, #20]
    40203234:	eb14037f 	cmp	x27, x20
    40203238:	54ffeb42 	b.cs	40202fa0 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x74>  // b.hs, b.nlast
    4020323c:	f90007fc 	str	x28, [sp, #8]
    40203240:	37c0011a 	tbnz	w26, #24, 40203260 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x334>
    40203244:	531d7b48 	ubfx	w8, w26, #29, #2
    40203248:	4b1b029b 	sub	w27, w20, w27
    4020324c:	7100051f 	cmp	w8, #0x1
    40203250:	540003cc 	b.gt	402032c8 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x39c>
    40203254:	35000568 	cbnz	w8, 40203300 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3d4>
    40203258:	2a1f03fc 	mov	w28, wzr
    4020325c:	1400002a 	b	40203304 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3d8>
    40203260:	a940f2ba 	ldp	x26, x28, [x21, #8]
    40203264:	52b3fc08 	mov	w8, #0x9fe00000            	// #-1612709888
    40203268:	f94002b9 	ldr	x25, [x21]
    4020326c:	2a1803e2 	mov	w2, w24
    40203270:	aa1703e3 	mov	x3, x23
    40203274:	aa1603e4 	mov	x4, x22
    40203278:	0a080388 	and	w8, w28, w8
    4020327c:	aa1903e0 	mov	x0, x25
    40203280:	aa1a03e1 	mov	x1, x26
    40203284:	321c0508 	orr	w8, w8, #0x30
    40203288:	32030108 	orr	w8, w8, #0x20000000
    4020328c:	b90012a8 	str	w8, [x21, #16]
    40203290:	94000279 	bl	40203c74 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix>
    40203294:	370006a0 	tbnz	w0, #0, 40203368 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    40203298:	2a1f03f6 	mov	w22, wzr
    4020329c:	4b1b0294 	sub	w20, w20, w27
    402032a0:	12003ec8 	and	w8, w22, #0xffff
    402032a4:	6b34211f 	cmp	w8, w20, uxth
    402032a8:	540001a2 	b.cs	402032dc <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3b0>  // b.hs, b.nlast
    402032ac:	f9401348 	ldr	x8, [x26, #32]
    402032b0:	aa1903e0 	mov	x0, x25
    402032b4:	52800601 	mov	w1, #0x30                  	// #48
    402032b8:	110006d6 	add	w22, w22, #0x1
    402032bc:	d63f0100 	blr	x8
    402032c0:	3607ff00 	tbz	w0, #0, 402032a0 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x374>
    402032c4:	14000029 	b	40203368 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    402032c8:	7100091f 	cmp	w8, #0x2
    402032cc:	2a1b03fc 	mov	w28, w27
    402032d0:	540001a1 	b.ne	40203304 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3d8>  // b.any
    402032d4:	53013f7c 	ubfx	w28, w27, #1, #15
    402032d8:	1400000b 	b	40203304 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3d8>
    402032dc:	f9400f48 	ldr	x8, [x26, #24]
    402032e0:	f94007e1 	ldr	x1, [sp, #8]
    402032e4:	aa1903e0 	mov	x0, x25
    402032e8:	aa1303e2 	mov	x2, x19
    402032ec:	d63f0100 	blr	x8
    402032f0:	370003c0 	tbnz	w0, #0, 40203368 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    402032f4:	2a1f03f3 	mov	w19, wzr
    402032f8:	f9000abc 	str	x28, [x21, #16]
    402032fc:	1400001c 	b	4020336c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x440>
    40203300:	2a1b03fc 	mov	w28, w27
    40203304:	a94056b9 	ldp	x25, x21, [x21]
    40203308:	2a1f03f4 	mov	w20, wzr
    4020330c:	12003e88 	and	w8, w20, #0xffff
    40203310:	6b3c211f 	cmp	w8, w28, uxth
    40203314:	54000102 	b.cs	40203334 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x408>  // b.hs, b.nlast
    40203318:	f94012a8 	ldr	x8, [x21, #32]
    4020331c:	12005341 	and	w1, w26, #0x1fffff
    40203320:	aa1903e0 	mov	x0, x25
    40203324:	11000694 	add	w20, w20, #0x1
    40203328:	d63f0100 	blr	x8
    4020332c:	3607ff00 	tbz	w0, #0, 4020330c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x3e0>
    40203330:	1400000e 	b	40203368 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    40203334:	aa1903e0 	mov	x0, x25
    40203338:	aa1503e1 	mov	x1, x21
    4020333c:	2a1803e2 	mov	w2, w24
    40203340:	aa1703e3 	mov	x3, x23
    40203344:	aa1603e4 	mov	x4, x22
    40203348:	9400024b 	bl	40203c74 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix>
    4020334c:	370000e0 	tbnz	w0, #0, 40203368 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x43c>
    40203350:	f9400ea8 	ldr	x8, [x21, #24]
    40203354:	f94007e1 	ldr	x1, [sp, #8]
    40203358:	aa1903e0 	mov	x0, x25
    4020335c:	aa1303e2 	mov	x2, x19
    40203360:	d63f0100 	blr	x8
    40203364:	36000160 	tbz	w0, #0, 40203390 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x464>
    40203368:	52800033 	mov	w19, #0x1                   	// #1
    4020336c:	2a1303e0 	mov	w0, w19
    40203370:	a9464ff4 	ldp	x20, x19, [sp, #96]
    40203374:	a94557f6 	ldp	x22, x21, [sp, #80]
    40203378:	a9445ff8 	ldp	x24, x23, [sp, #64]
    4020337c:	a94367fa 	ldp	x26, x25, [sp, #48]
    40203380:	a9426ffc 	ldp	x28, x27, [sp, #32]
    40203384:	a9417bfd 	ldp	x29, x30, [sp, #16]
    40203388:	9101c3ff 	add	sp, sp, #0x70
    4020338c:	d65f03c0 	ret
    40203390:	2a1f03f4 	mov	w20, wzr
    40203394:	4b1c0376 	sub	w22, w27, w28
    40203398:	12003e88 	and	w8, w20, #0xffff
    4020339c:	6b36211f 	cmp	w8, w22, uxth
    402033a0:	1a9f27f3 	cset	w19, cc  // cc = lo, ul, last
    402033a4:	54fffe42 	b.cs	4020336c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x440>  // b.hs, b.nlast
    402033a8:	f94012a8 	ldr	x8, [x21, #32]
    402033ac:	12005341 	and	w1, w26, #0x1fffff
    402033b0:	aa1903e0 	mov	x0, x25
    402033b4:	11000694 	add	w20, w20, #0x1
    402033b8:	d63f0100 	blr	x8
    402033bc:	3607fee0 	tbz	w0, #0, 40203398 <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x46c>
    402033c0:	17ffffeb 	b	4020336c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral+0x440>

00000000402033c4 <_RNvNtCsbcsGJ9IzBgZ_4core9panicking18panic_bounds_check>:
    402033c4:	d10103ff 	sub	sp, sp, #0x40
    402033c8:	a9037bfd 	stp	x29, x30, [sp, #48]
    402033cc:	9100c3fd 	add	x29, sp, #0x30
    402033d0:	910023e8 	add	x8, sp, #0x8
    402033d4:	d503201f 	nop
    402033d8:	10004929 	adr	x9, 40203cfc <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>
    402033dc:	a90007e0 	stp	x0, x1, [sp]
    402033e0:	b0000000 	adrp	x0, 40204000 <memcpy+0x1b0>
    402033e4:	91081c00 	add	x0, x0, #0x207
    402033e8:	a90127e8 	stp	x8, x9, [sp, #16]
    402033ec:	910003e8 	mov	x8, sp
    402033f0:	910043e1 	add	x1, sp, #0x10
    402033f4:	a90227e8 	stp	x8, x9, [sp, #32]
    402033f8:	94000001 	bl	402033fc <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>

00000000402033fc <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>:
    402033fc:	d10103ff 	sub	sp, sp, #0x40
    40203400:	a9037bfd 	stp	x29, x30, [sp, #48]
    40203404:	9100c3fd 	add	x29, sp, #0x30
    40203408:	910023e8 	add	x8, sp, #0x8
    4020340c:	a90087e0 	stp	x0, x1, [sp, #8]
    40203410:	910063e0 	add	x0, sp, #0x18
    40203414:	a9018be8 	stp	x8, x2, [sp, #24]
    40203418:	52800028 	mov	w8, #0x1                   	// #1
    4020341c:	790053e8 	strh	w8, [sp, #40]
    40203420:	97fffb49 	bl	40202144 <_RNvCsfLfy6EI15iL_7___rustc17rust_begin_unwind>

0000000040203424 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars>:
    40203424:	d10183ff 	sub	sp, sp, #0x60
    40203428:	fd0023ea 	str	d10, [sp, #64]
    4020342c:	6d0523e9 	stp	d9, d8, [sp, #80]
    40203430:	91001c08 	add	x8, x0, #0x7
    40203434:	927df10d 	and	x13, x8, #0xfffffffffffffff8
    40203438:	cb0001ac 	sub	x12, x13, x0
    4020343c:	eb0c002b 	subs	x11, x1, x12
    40203440:	540000e2 	b.cs	4020345c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x38>  // b.hs, b.nlast
    40203444:	b4000721 	cbz	x1, 40203528 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x104>
    40203448:	f100203f 	cmp	x1, #0x8
    4020344c:	54001b82 	b.cs	402037bc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x398>  // b.hs, b.nlast
    40203450:	aa1f03e9 	mov	x9, xzr
    40203454:	aa1f03e8 	mov	x8, xzr
    40203458:	140001d2 	b	40203ba0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x77c>
    4020345c:	d343fd69 	lsr	x9, x11, #3
    40203460:	b4ffff29 	cbz	x9, 40203444 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x20>
    40203464:	eb0001bf 	cmp	x13, x0
    40203468:	9240096a 	and	x10, x11, #0x7
    4020346c:	aa1f03e8 	mov	x8, xzr
    40203470:	54000100 	b.eq	40203490 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x6c>  // b.none
    40203474:	cb0d000d 	sub	x13, x0, x13
    40203478:	aa0003ee 	mov	x14, x0
    4020347c:	38c015cf 	ldrsb	w15, [x14], #1
    40203480:	310105ff 	cmn	w15, #0x41
    40203484:	9a88d508 	cinc	x8, x8, gt
    40203488:	b10005ad 	adds	x13, x13, #0x1
    4020348c:	54ffff83 	b.cc	4020347c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x58>  // b.lo, b.ul, b.last
    40203490:	8b0c000e 	add	x14, x0, x12
    40203494:	b400056a 	cbz	x10, 40203540 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x11c>
    40203498:	927ded6b 	and	x11, x11, #0x7ffffffffffffff8
    4020349c:	8b0b01cc 	add	x12, x14, x11
    402034a0:	39c0018b 	ldrsb	w11, [x12]
    402034a4:	3101057f 	cmn	w11, #0x41
    402034a8:	1a9fd7eb 	cset	w11, gt
    402034ac:	f100055f 	cmp	x10, #0x1
    402034b0:	540004a0 	b.eq	40203544 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    402034b4:	39c0058d 	ldrsb	w13, [x12, #1]
    402034b8:	310105bf 	cmn	w13, #0x41
    402034bc:	9a8bd56b 	cinc	x11, x11, gt
    402034c0:	f100095f 	cmp	x10, #0x2
    402034c4:	54000400 	b.eq	40203544 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    402034c8:	39c0098d 	ldrsb	w13, [x12, #2]
    402034cc:	310105bf 	cmn	w13, #0x41
    402034d0:	9a8bd56b 	cinc	x11, x11, gt
    402034d4:	f1000d5f 	cmp	x10, #0x3
    402034d8:	54000360 	b.eq	40203544 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    402034dc:	39c00d8d 	ldrsb	w13, [x12, #3]
    402034e0:	310105bf 	cmn	w13, #0x41
    402034e4:	9a8bd56b 	cinc	x11, x11, gt
    402034e8:	f100115f 	cmp	x10, #0x4
    402034ec:	540002c0 	b.eq	40203544 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    402034f0:	39c0118d 	ldrsb	w13, [x12, #4]
    402034f4:	310105bf 	cmn	w13, #0x41
    402034f8:	9a8bd56b 	cinc	x11, x11, gt
    402034fc:	f100155f 	cmp	x10, #0x5
    40203500:	54000220 	b.eq	40203544 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    40203504:	39c0158d 	ldrsb	w13, [x12, #5]
    40203508:	310105bf 	cmn	w13, #0x41
    4020350c:	9a8bd56b 	cinc	x11, x11, gt
    40203510:	f100195f 	cmp	x10, #0x6
    40203514:	54000180 	b.eq	40203544 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>  // b.none
    40203518:	39c0198a 	ldrsb	w10, [x12, #6]
    4020351c:	3101055f 	cmn	w10, #0x41
    40203520:	9a8bd56b 	cinc	x11, x11, gt
    40203524:	14000008 	b	40203544 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x120>
    40203528:	aa1f03e8 	mov	x8, xzr
    4020352c:	6d4523e9 	ldp	d9, d8, [sp, #80]
    40203530:	aa0803e0 	mov	x0, x8
    40203534:	fd4023ea 	ldr	d10, [sp, #64]
    40203538:	910183ff 	add	sp, sp, #0x60
    4020353c:	d65f03c0 	ret
    40203540:	aa1f03eb 	mov	x11, xzr
    40203544:	4f00e420 	movi	v0.16b, #0x1
    40203548:	8b080168 	add	x8, x11, x8
    4020354c:	5280180a 	mov	w10, #0xc0                  	// #192
    40203550:	b20083eb 	mov	x11, #0x1000100010001       	// #281479271743489
    40203554:	1400000c 	b	40203584 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x160>
    40203558:	aa1f03f1 	mov	x17, xzr
    4020355c:	d348fe2f 	lsr	x15, x17, #8
    40203560:	92009e30 	and	x16, x17, #0xff00ff00ff00ff
    40203564:	8b0e018e 	add	x14, x12, x14
    40203568:	cb0d0129 	sub	x9, x9, x13
    4020356c:	92009def 	and	x15, x15, #0xff00ff00ff00ff
    40203570:	8b1001ef 	add	x15, x15, x16
    40203574:	9b0b7df0 	mul	x16, x15, x11
    40203578:	924005af 	and	x15, x13, #0x3
    4020357c:	8b50c108 	add	x8, x8, x16, lsr #48
    40203580:	b5000d8f 	cbnz	x15, 40203730 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x30c>
    40203584:	b4fffd49 	cbz	x9, 4020352c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x108>
    40203588:	f103013f 	cmp	x9, #0xc0
    4020358c:	aa0e03ec 	mov	x12, x14
    40203590:	9a8a312d 	csel	x13, x9, x10, cc  // cc = lo, ul, last
    40203594:	d37df1ae 	lsl	x14, x13, #3
    40203598:	f27b15d0 	ands	x16, x14, #0x7e0
    4020359c:	54fffde0 	b.eq	40203558 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x134>  // b.none
    402035a0:	d10081cf 	sub	x15, x14, #0x20
    402035a4:	f10181ff 	cmp	x15, #0x60
    402035a8:	54000082 	b.cs	402035b8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x194>  // b.hs, b.nlast
    402035ac:	aa1f03f1 	mov	x17, xzr
    402035b0:	aa0c03ef 	mov	x15, x12
    402035b4:	14000044 	b	402036c4 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x2a0>
    402035b8:	d345fdef 	lsr	x15, x15, #5
    402035bc:	6f00e401 	movi	v1.2d, #0x0
    402035c0:	6f00e402 	movi	v2.2d, #0x0
    402035c4:	91010180 	add	x0, x12, #0x40
    402035c8:	910005f1 	add	x17, x15, #0x1
    402035cc:	927ee632 	and	x18, x17, #0xffffffffffffffc
    402035d0:	927ee621 	and	x1, x17, #0xffffffffffffffc
    402035d4:	8b12158f 	add	x15, x12, x18, lsl #5
    402035d8:	d1010002 	sub	x2, x0, #0x40
    402035dc:	4c400c10 	ld4	{v16.2d-v19.2d}, [x0]
    402035e0:	f1001021 	subs	x1, x1, #0x4
    402035e4:	91020000 	add	x0, x0, #0x80
    402035e8:	4c400c43 	ld4	{v3.2d-v6.2d}, [x2]
    402035ec:	6e205a07 	mvn	v7.16b, v16.16b
    402035f0:	6e205a35 	mvn	v21.16b, v17.16b
    402035f4:	6e205a5a 	mvn	v26.16b, v18.16b
    402035f8:	6e205876 	mvn	v22.16b, v3.16b
    402035fc:	6e205897 	mvn	v23.16b, v4.16b
    40203600:	6e2058b8 	mvn	v24.16b, v5.16b
    40203604:	6f7a0614 	ushr	v20.2d, v16.2d, #6
    40203608:	6f7a0639 	ushr	v25.2d, v17.2d, #6
    4020360c:	6f7a065b 	ushr	v27.2d, v18.2d, #6
    40203610:	6f7a047c 	ushr	v28.2d, v3.2d, #6
    40203614:	6f7a049d 	ushr	v29.2d, v4.2d, #6
    40203618:	6f7a04be 	ushr	v30.2d, v5.2d, #6
    4020361c:	6f7906d6 	ushr	v22.2d, v22.2d, #7
    40203620:	6f7906f7 	ushr	v23.2d, v23.2d, #7
    40203624:	6f790718 	ushr	v24.2d, v24.2d, #7
    40203628:	6f7904e7 	ushr	v7.2d, v7.2d, #7
    4020362c:	6f7906b5 	ushr	v21.2d, v21.2d, #7
    40203630:	6f79075a 	ushr	v26.2d, v26.2d, #7
    40203634:	6e205a7f 	mvn	v31.16b, v19.16b
    40203638:	6f7a0670 	ushr	v16.2d, v19.2d, #6
    4020363c:	6e2058d1 	mvn	v17.16b, v6.16b
    40203640:	4ebc1ed2 	orr	v18.16b, v22.16b, v28.16b
    40203644:	4ebd1ef3 	orr	v19.16b, v23.16b, v29.16b
    40203648:	4ebe1f16 	orr	v22.16b, v24.16b, v30.16b
    4020364c:	4eb41ce7 	orr	v7.16b, v7.16b, v20.16b
    40203650:	4eb91eb4 	orr	v20.16b, v21.16b, v25.16b
    40203654:	4ebb1f55 	orr	v21.16b, v26.16b, v27.16b
    40203658:	6f7a04c3 	ushr	v3.2d, v6.2d, #6
    4020365c:	6f7907e4 	ushr	v4.2d, v31.2d, #7
    40203660:	6f790625 	ushr	v5.2d, v17.2d, #7
    40203664:	4e201e46 	and	v6.16b, v18.16b, v0.16b
    40203668:	4e201e71 	and	v17.16b, v19.16b, v0.16b
    4020366c:	4e201ed2 	and	v18.16b, v22.16b, v0.16b
    40203670:	4e201ce7 	and	v7.16b, v7.16b, v0.16b
    40203674:	4e201e93 	and	v19.16b, v20.16b, v0.16b
    40203678:	4e201eb4 	and	v20.16b, v21.16b, v0.16b
    4020367c:	4eb01c84 	orr	v4.16b, v4.16b, v16.16b
    40203680:	4ea31ca3 	orr	v3.16b, v5.16b, v3.16b
    40203684:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    40203688:	4ef18646 	add	v6.2d, v18.2d, v17.2d
    4020368c:	4ee284e2 	add	v2.2d, v7.2d, v2.2d
    40203690:	4ef38685 	add	v5.2d, v20.2d, v19.2d
    40203694:	4e201c63 	and	v3.16b, v3.16b, v0.16b
    40203698:	4e201c84 	and	v4.16b, v4.16b, v0.16b
    4020369c:	4ee184c1 	add	v1.2d, v6.2d, v1.2d
    402036a0:	4ee284a2 	add	v2.2d, v5.2d, v2.2d
    402036a4:	4ee18461 	add	v1.2d, v3.2d, v1.2d
    402036a8:	4ee28482 	add	v2.2d, v4.2d, v2.2d
    402036ac:	54fff961 	b.ne	402035d8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x1b4>  // b.any
    402036b0:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    402036b4:	eb12023f 	cmp	x17, x18
    402036b8:	5ef1b821 	addp	d1, v1.2d
    402036bc:	9e660031 	fmov	x17, d1
    402036c0:	54fff4e0 	b.eq	4020355c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x138>  // b.none
    402036c4:	8b100190 	add	x16, x12, x16
    402036c8:	f9400df2 	ldr	x18, [x15, #24]
    402036cc:	f9001ff2 	str	x18, [sp, #56]
    402036d0:	f94009f2 	ldr	x18, [x15, #16]
    402036d4:	f9001bf2 	str	x18, [sp, #48]
    402036d8:	f94005f2 	ldr	x18, [x15, #8]
    402036dc:	f90017f2 	str	x18, [sp, #40]
    402036e0:	f84205f2 	ldr	x18, [x15], #32
    402036e4:	eb1001ff 	cmp	x15, x16
    402036e8:	f90013f2 	str	x18, [sp, #32]
    402036ec:	ad4107e2 	ldp	q2, q1, [sp, #32]
    402036f0:	6e205823 	mvn	v3.16b, v1.16b
    402036f4:	6e205844 	mvn	v4.16b, v2.16b
    402036f8:	6f7a0421 	ushr	v1.2d, v1.2d, #6
    402036fc:	6f7a0442 	ushr	v2.2d, v2.2d, #6
    40203700:	6f790463 	ushr	v3.2d, v3.2d, #7
    40203704:	6f790484 	ushr	v4.2d, v4.2d, #7
    40203708:	4ea21c82 	orr	v2.16b, v4.16b, v2.16b
    4020370c:	4ea11c61 	orr	v1.16b, v3.16b, v1.16b
    40203710:	4e201c21 	and	v1.16b, v1.16b, v0.16b
    40203714:	4e201c42 	and	v2.16b, v2.16b, v0.16b
    40203718:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    4020371c:	5ef1b821 	addp	d1, v1.2d
    40203720:	9e660032 	fmov	x18, d1
    40203724:	8b110251 	add	x17, x18, x17
    40203728:	54fffd01 	b.ne	402036c8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x2a4>  // b.any
    4020372c:	17ffff8c 	b	4020355c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x138>
    40203730:	927e15a9 	and	x9, x13, #0xfc
    40203734:	f10005ff 	cmp	x15, #0x1
    40203738:	8b090d8a 	add	x10, x12, x9, lsl #3
    4020373c:	f9400149 	ldr	x9, [x10]
    40203740:	aa2903eb 	mvn	x11, x9
    40203744:	d347fd6b 	lsr	x11, x11, #7
    40203748:	aa491969 	orr	x9, x11, x9, lsr #6
    4020374c:	9200c129 	and	x9, x9, #0x101010101010101
    40203750:	540001e0 	b.eq	4020378c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x368>  // b.none
    40203754:	f940054b 	ldr	x11, [x10, #8]
    40203758:	f10009ff 	cmp	x15, #0x2
    4020375c:	aa2b03ec 	mvn	x12, x11
    40203760:	d347fd8c 	lsr	x12, x12, #7
    40203764:	aa4b198b 	orr	x11, x12, x11, lsr #6
    40203768:	9200c16b 	and	x11, x11, #0x101010101010101
    4020376c:	8b090169 	add	x9, x11, x9
    40203770:	540000e0 	b.eq	4020378c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x368>  // b.none
    40203774:	f940094a 	ldr	x10, [x10, #16]
    40203778:	aa2a03eb 	mvn	x11, x10
    4020377c:	d347fd6b 	lsr	x11, x11, #7
    40203780:	aa4a196a 	orr	x10, x11, x10, lsr #6
    40203784:	9200c14a 	and	x10, x10, #0x101010101010101
    40203788:	8b090149 	add	x9, x10, x9
    4020378c:	d348fd2a 	lsr	x10, x9, #8
    40203790:	92009d29 	and	x9, x9, #0xff00ff00ff00ff
    40203794:	92009d4a 	and	x10, x10, #0xff00ff00ff00ff
    40203798:	8b090149 	add	x9, x10, x9
    4020379c:	b20083ea 	mov	x10, #0x1000100010001       	// #281479271743489
    402037a0:	9b0a7d29 	mul	x9, x9, x10
    402037a4:	8b49c108 	add	x8, x8, x9, lsr #48
    402037a8:	6d4523e9 	ldp	d9, d8, [sp, #80]
    402037ac:	aa0803e0 	mov	x0, x8
    402037b0:	fd4023ea 	ldr	d10, [sp, #64]
    402037b4:	910183ff 	add	sp, sp, #0x60
    402037b8:	d65f03c0 	ret
    402037bc:	f100803f 	cmp	x1, #0x20
    402037c0:	54000082 	b.cs	402037d0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x3ac>  // b.hs, b.nlast
    402037c4:	aa1f03e9 	mov	x9, xzr
    402037c8:	aa1f03e8 	mov	x8, xzr
    402037cc:	140000bc 	b	40203abc <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x698>
    402037d0:	6f00e400 	movi	v0.2d, #0x0
    402037d4:	4f05e7e3 	movi	v3.16b, #0xbf
    402037d8:	52800028 	mov	w8, #0x1                   	// #1
    402037dc:	6f00e402 	movi	v2.2d, #0x0
    402037e0:	6f00e407 	movi	v7.2d, #0x0
    402037e4:	927d042a 	and	x10, x1, #0x18
    402037e8:	6f00e401 	movi	v1.2d, #0x0
    402037ec:	6f00e412 	movi	v18.2d, #0x0
    402037f0:	927be829 	and	x9, x1, #0xffffffffffffffe0
    402037f4:	6f00e405 	movi	v5.2d, #0x0
    402037f8:	6f00e406 	movi	v6.2d, #0x0
    402037fc:	927be82b 	and	x11, x1, #0xffffffffffffffe0
    40203800:	6f00e404 	movi	v4.2d, #0x0
    40203804:	6f00e416 	movi	v22.2d, #0x0
    40203808:	6f00e411 	movi	v17.2d, #0x0
    4020380c:	6f00e410 	movi	v16.2d, #0x0
    40203810:	6f00e417 	movi	v23.2d, #0x0
    40203814:	6f00e414 	movi	v20.2d, #0x0
    40203818:	6f00e415 	movi	v21.2d, #0x0
    4020381c:	6f00e413 	movi	v19.2d, #0x0
    40203820:	6f00e418 	movi	v24.2d, #0x0
    40203824:	4e080d19 	dup	v25.2d, x8
    40203828:	91004008 	add	x8, x0, #0x10
    4020382c:	aa0803ec 	mov	x12, x8
    40203830:	385f1112 	ldurb	w18, [x8, #-15]
    40203834:	385f5102 	ldurb	w2, [x8, #-11]
    40203838:	385f0d8d 	ldrb	w13, [x12, #-16]!
    4020383c:	aa0c03ef 	mov	x15, x12
    40203840:	3940098e 	ldrb	w14, [x12, #2]
    40203844:	38404df0 	ldrb	w16, [x15, #4]!
    40203848:	394009f1 	ldrb	w17, [x15, #2]
    4020384c:	39400d83 	ldrb	w3, [x12, #3]
    40203850:	39400def 	ldrb	w15, [x15, #3]
    40203854:	d370bdce 	lsl	x14, x14, #16
    40203858:	aa1221ad 	orr	x13, x13, x18, lsl #8
    4020385c:	2a022210 	orr	w16, w16, w2, lsl #8
    40203860:	53103e31 	lsl	w17, w17, #16
    40203864:	f100816b 	subs	x11, x11, #0x20
    40203868:	aa0361ce 	orr	x14, x14, x3, lsl #24
    4020386c:	2a0f622f 	orr	w15, w17, w15, lsl #24
    40203870:	aa0d01cd 	orr	x13, x14, x13
    40203874:	2a1001ee 	orr	w14, w15, w16
    40203878:	aa0e81ad 	orr	x13, x13, x14, lsl #32
    4020387c:	f9000bed 	str	x13, [sp, #16]
    40203880:	aa0c03ed 	mov	x13, x12
    40203884:	38408dae 	ldrb	w14, [x13, #8]!
    40203888:	39400daf 	ldrb	w15, [x13, #3]
    4020388c:	394009b0 	ldrb	w16, [x13, #2]
    40203890:	38404db1 	ldrb	w17, [x13, #4]!
    40203894:	394009b2 	ldrb	w18, [x13, #2]
    40203898:	39402582 	ldrb	w2, [x12, #9]
    4020389c:	3940358c 	ldrb	w12, [x12, #13]
    402038a0:	39400dad 	ldrb	w13, [x13, #3]
    402038a4:	d370be10 	lsl	x16, x16, #16
    402038a8:	53103e52 	lsl	w18, w18, #16
    402038ac:	aa0221ce 	orr	x14, x14, x2, lsl #8
    402038b0:	2a0c222c 	orr	w12, w17, w12, lsl #8
    402038b4:	aa0f620f 	orr	x15, x16, x15, lsl #24
    402038b8:	2a0d624d 	orr	w13, w18, w13, lsl #24
    402038bc:	aa0e01ee 	orr	x14, x15, x14
    402038c0:	2a0c01ac 	orr	w12, w13, w12
    402038c4:	aa0c81cc 	orr	x12, x14, x12, lsl #32
    402038c8:	f9000fec 	str	x12, [sp, #24]
    402038cc:	aa0803ec 	mov	x12, x8
    402038d0:	3940090e 	ldrb	w14, [x8, #2]
    402038d4:	38404d8f 	ldrb	w15, [x12, #4]!
    402038d8:	39400990 	ldrb	w16, [x12, #2]
    402038dc:	3940050d 	ldrb	w13, [x8, #1]
    402038e0:	39400111 	ldrb	w17, [x8]
    402038e4:	39400d12 	ldrb	w18, [x8, #3]
    402038e8:	39401502 	ldrb	w2, [x8, #5]
    402038ec:	39400d8c 	ldrb	w12, [x12, #3]
    402038f0:	d370bdce 	lsl	x14, x14, #16
    402038f4:	53103e10 	lsl	w16, w16, #16
    402038f8:	aa0d222d 	orr	x13, x17, x13, lsl #8
    402038fc:	2a0221ef 	orr	w15, w15, w2, lsl #8
    40203900:	3dc007fa 	ldr	q26, [sp, #16]
    40203904:	aa1261ce 	orr	x14, x14, x18, lsl #24
    40203908:	2a0c620c 	orr	w12, w16, w12, lsl #24
    4020390c:	4e23375a 	cmgt	v26.16b, v26.16b, v3.16b
    40203910:	aa0d01cd 	orr	x13, x14, x13
    40203914:	2a0f018c 	orr	w12, w12, w15
    40203918:	aa0c81ac 	orr	x12, x13, x12, lsl #32
    4020391c:	aa0803ed 	mov	x13, x8
    40203920:	6f08a75b 	uxtl2	v27.8h, v26.16b
    40203924:	2f08a75a 	uxtl	v26.8h, v26.8b
    40203928:	f90003ec 	str	x12, [sp]
    4020392c:	38408dac 	ldrb	w12, [x13, #8]!
    40203930:	39400dae 	ldrb	w14, [x13, #3]
    40203934:	394009af 	ldrb	w15, [x13, #2]
    40203938:	38404db0 	ldrb	w16, [x13, #4]!
    4020393c:	394009b1 	ldrb	w17, [x13, #2]
    40203940:	39402512 	ldrb	w18, [x8, #9]
    40203944:	39403502 	ldrb	w2, [x8, #13]
    40203948:	39400dad 	ldrb	w13, [x13, #3]
    4020394c:	d370bdef 	lsl	x15, x15, #16
    40203950:	6f10a77c 	uxtl2	v28.4s, v27.8h
    40203954:	53103e31 	lsl	w17, w17, #16
    40203958:	aa12218c 	orr	x12, x12, x18, lsl #8
    4020395c:	2a022210 	orr	w16, w16, w2, lsl #8
    40203960:	aa0e61ee 	orr	x14, x15, x14, lsl #24
    40203964:	2f10a77b 	uxtl	v27.4s, v27.4h
    40203968:	2f10a75e 	uxtl	v30.4s, v26.4h
    4020396c:	2a0d622d 	orr	w13, w17, w13, lsl #24
    40203970:	6f20a79d 	uxtl2	v29.2d, v28.4s
    40203974:	6f10a75a 	uxtl2	v26.4s, v26.8h
    40203978:	aa0c01cc 	orr	x12, x14, x12
    4020397c:	2f20a79c 	uxtl	v28.2d, v28.2s
    40203980:	91008108 	add	x8, x8, #0x20
    40203984:	2a1001ad 	orr	w13, w13, w16
    40203988:	6f20a768 	uxtl2	v8.2d, v27.4s
    4020398c:	6f20a7c9 	uxtl2	v9.2d, v30.4s
    40203990:	aa0d818c 	orr	x12, x12, x13, lsl #32
    40203994:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    40203998:	6f20a74a 	uxtl2	v10.2d, v26.4s
    4020399c:	2f20a75a 	uxtl	v26.2d, v26.2s
    402039a0:	2f20a77b 	uxtl	v27.2d, v27.2s
    402039a4:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    402039a8:	f90007ec 	str	x12, [sp, #8]
    402039ac:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    402039b0:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    402039b4:	3dc003ff 	ldr	q31, [sp]
    402039b8:	4efd86d6 	add	v22.2d, v22.2d, v29.2d
    402039bc:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    402039c0:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    402039c4:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    402039c8:	4efc8484 	add	v4.2d, v4.2d, v28.2d
    402039cc:	4e2337ff 	cmgt	v31.16b, v31.16b, v3.16b
    402039d0:	4ee884c6 	add	v6.2d, v6.2d, v8.2d
    402039d4:	2f20a7de 	uxtl	v30.2d, v30.2s
    402039d8:	4eea8652 	add	v18.2d, v18.2d, v10.2d
    402039dc:	4ee984e7 	add	v7.2d, v7.2d, v9.2d
    402039e0:	4efa8421 	add	v1.2d, v1.2d, v26.2d
    402039e4:	4efb84a5 	add	v5.2d, v5.2d, v27.2d
    402039e8:	6f08a7fd 	uxtl2	v29.8h, v31.16b
    402039ec:	2f08a7ff 	uxtl	v31.8h, v31.8b
    402039f0:	4e391fde 	and	v30.16b, v30.16b, v25.16b
    402039f4:	6f10a7bc 	uxtl2	v28.4s, v29.8h
    402039f8:	6f10a7e8 	uxtl2	v8.4s, v31.8h
    402039fc:	2f10a7bd 	uxtl	v29.4s, v29.4h
    40203a00:	2f10a7fa 	uxtl	v26.4s, v31.4h
    40203a04:	4efe8442 	add	v2.2d, v2.2d, v30.2d
    40203a08:	2f20a79b 	uxtl	v27.2d, v28.2s
    40203a0c:	6f20a79c 	uxtl2	v28.2d, v28.4s
    40203a10:	2f20a7bf 	uxtl	v31.2d, v29.2s
    40203a14:	6f20a509 	uxtl2	v9.2d, v8.4s
    40203a18:	6f20a7bd 	uxtl2	v29.2d, v29.4s
    40203a1c:	2f20a74a 	uxtl	v10.2d, v26.2s
    40203a20:	6f20a75a 	uxtl2	v26.2d, v26.4s
    40203a24:	2f20a508 	uxtl	v8.2d, v8.2s
    40203a28:	4e391f7b 	and	v27.16b, v27.16b, v25.16b
    40203a2c:	4e391f9c 	and	v28.16b, v28.16b, v25.16b
    40203a30:	4e391fff 	and	v31.16b, v31.16b, v25.16b
    40203a34:	4e391d29 	and	v9.16b, v9.16b, v25.16b
    40203a38:	4e391fbd 	and	v29.16b, v29.16b, v25.16b
    40203a3c:	4e391d4a 	and	v10.16b, v10.16b, v25.16b
    40203a40:	4e391f5a 	and	v26.16b, v26.16b, v25.16b
    40203a44:	4e391d08 	and	v8.16b, v8.16b, v25.16b
    40203a48:	4efc8718 	add	v24.2d, v24.2d, v28.2d
    40203a4c:	4efb8673 	add	v19.2d, v19.2d, v27.2d
    40203a50:	4eff8694 	add	v20.2d, v20.2d, v31.2d
    40203a54:	4efd86b5 	add	v21.2d, v21.2d, v29.2d
    40203a58:	4ee986f7 	add	v23.2d, v23.2d, v9.2d
    40203a5c:	4eea8631 	add	v17.2d, v17.2d, v10.2d
    40203a60:	4ee88610 	add	v16.2d, v16.2d, v8.2d
    40203a64:	4efa8400 	add	v0.2d, v0.2d, v26.2d
    40203a68:	54ffee21 	b.ne	4020382c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x408>  // b.any
    40203a6c:	4ef286e3 	add	v3.2d, v23.2d, v18.2d
    40203a70:	4ef68712 	add	v18.2d, v24.2d, v22.2d
    40203a74:	eb09003f 	cmp	x1, x9
    40203a78:	4ee78400 	add	v0.2d, v0.2d, v7.2d
    40203a7c:	4ee28622 	add	v2.2d, v17.2d, v2.2d
    40203a80:	4ee58685 	add	v5.2d, v20.2d, v5.2d
    40203a84:	4ee686a6 	add	v6.2d, v21.2d, v6.2d
    40203a88:	4ee18601 	add	v1.2d, v16.2d, v1.2d
    40203a8c:	4ee48664 	add	v4.2d, v19.2d, v4.2d
    40203a90:	4ef28463 	add	v3.2d, v3.2d, v18.2d
    40203a94:	4ee58442 	add	v2.2d, v2.2d, v5.2d
    40203a98:	4ee48421 	add	v1.2d, v1.2d, v4.2d
    40203a9c:	4ee68400 	add	v0.2d, v0.2d, v6.2d
    40203aa0:	4ee18441 	add	v1.2d, v2.2d, v1.2d
    40203aa4:	4ee38400 	add	v0.2d, v0.2d, v3.2d
    40203aa8:	4ee08420 	add	v0.2d, v1.2d, v0.2d
    40203aac:	5ef1b800 	addp	d0, v0.2d
    40203ab0:	9e660008 	fmov	x8, d0
    40203ab4:	54ffd3c0 	b.eq	4020352c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x108>  // b.none
    40203ab8:	b400074a 	cbz	x10, 40203ba0 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x77c>
    40203abc:	6f00e400 	movi	v0.2d, #0x0
    40203ac0:	6f00e401 	movi	v1.2d, #0x0
    40203ac4:	aa0903ea 	mov	x10, x9
    40203ac8:	0f05e7e2 	movi	v2.8b, #0xbf
    40203acc:	6f00e403 	movi	v3.2d, #0x0
    40203ad0:	927df029 	and	x9, x1, #0xfffffffffffffff8
    40203ad4:	6f00e404 	movi	v4.2d, #0x0
    40203ad8:	4e081d00 	mov	v0.d[0], x8
    40203adc:	52800028 	mov	w8, #0x1                   	// #1
    40203ae0:	4e080d05 	dup	v5.2d, x8
    40203ae4:	cb090148 	sub	x8, x10, x9
    40203ae8:	8b0a000a 	add	x10, x0, x10
    40203aec:	aa0a03ed 	mov	x13, x10
    40203af0:	3940094c 	ldrb	w12, [x10, #2]
    40203af4:	3940054b 	ldrb	w11, [x10, #1]
    40203af8:	38404dae 	ldrb	w14, [x13, #4]!
    40203afc:	394009af 	ldrb	w15, [x13, #2]
    40203b00:	39400150 	ldrb	w16, [x10]
    40203b04:	39400d51 	ldrb	w17, [x10, #3]
    40203b08:	d370bd8c 	lsl	x12, x12, #16
    40203b0c:	39401552 	ldrb	w18, [x10, #5]
    40203b10:	39400dad 	ldrb	w13, [x13, #3]
    40203b14:	53103def 	lsl	w15, w15, #16
    40203b18:	aa0b220b 	orr	x11, x16, x11, lsl #8
    40203b1c:	aa11618c 	orr	x12, x12, x17, lsl #24
    40203b20:	b1002108 	adds	x8, x8, #0x8
    40203b24:	2a1221ce 	orr	w14, w14, w18, lsl #8
    40203b28:	2a0d61ed 	orr	w13, w15, w13, lsl #24
    40203b2c:	9100214a 	add	x10, x10, #0x8
    40203b30:	aa0b018b 	orr	x11, x12, x11
    40203b34:	2a0e01ac 	orr	w12, w13, w14
    40203b38:	aa0c816b 	orr	x11, x11, x12, lsl #32
    40203b3c:	9e670166 	fmov	d6, x11
    40203b40:	0e2234c6 	cmgt	v6.8b, v6.8b, v2.8b
    40203b44:	2f08a4c6 	uxtl	v6.8h, v6.8b
    40203b48:	6f10a4c7 	uxtl2	v7.4s, v6.8h
    40203b4c:	2f10a4c6 	uxtl	v6.4s, v6.4h
    40203b50:	6f20a4f0 	uxtl2	v16.2d, v7.4s
    40203b54:	2f20a4d1 	uxtl	v17.2d, v6.2s
    40203b58:	6f20a4c6 	uxtl2	v6.2d, v6.4s
    40203b5c:	2f20a4e7 	uxtl	v7.2d, v7.2s
    40203b60:	4e251e10 	and	v16.16b, v16.16b, v5.16b
    40203b64:	4e251e31 	and	v17.16b, v17.16b, v5.16b
    40203b68:	4e251cc6 	and	v6.16b, v6.16b, v5.16b
    40203b6c:	4e251ce7 	and	v7.16b, v7.16b, v5.16b
    40203b70:	4ef08484 	add	v4.2d, v4.2d, v16.2d
    40203b74:	4ee68463 	add	v3.2d, v3.2d, v6.2d
    40203b78:	4ef18400 	add	v0.2d, v0.2d, v17.2d
    40203b7c:	4ee78421 	add	v1.2d, v1.2d, v7.2d
    40203b80:	54fffb61 	b.ne	40203aec <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x6c8>  // b.any
    40203b84:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    40203b88:	4ee48461 	add	v1.2d, v3.2d, v4.2d
    40203b8c:	eb09003f 	cmp	x1, x9
    40203b90:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    40203b94:	5ef1b800 	addp	d0, v0.2d
    40203b98:	9e660008 	fmov	x8, d0
    40203b9c:	54ffcc80 	b.eq	4020352c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x108>  // b.none
    40203ba0:	cb09002a 	sub	x10, x1, x9
    40203ba4:	8b090009 	add	x9, x0, x9
    40203ba8:	38c0152b 	ldrsb	w11, [x9], #1
    40203bac:	3101057f 	cmn	w11, #0x41
    40203bb0:	9a88d508 	cinc	x8, x8, gt
    40203bb4:	f100054a 	subs	x10, x10, #0x1
    40203bb8:	54ffff81 	b.ne	40203ba8 <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x784>  // b.any
    40203bbc:	17fffe5c 	b	4020352c <_RNvNtNtCsbcsGJ9IzBgZ_4core3str5count14do_count_chars+0x108>

0000000040203bc0 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail>:
    40203bc0:	d10103ff 	sub	sp, sp, #0x40
    40203bc4:	a9037bfd 	stp	x29, x30, [sp, #48]
    40203bc8:	9100c3fd 	add	x29, sp, #0x30
    40203bcc:	eb02001f 	cmp	x0, x2
    40203bd0:	540001a9 	b.ls	40203c04 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail+0x44>  // b.plast
    40203bd4:	910003e8 	mov	x8, sp
    40203bd8:	d503201f 	nop
    40203bdc:	10000909 	adr	x9, 40203cfc <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>
    40203be0:	a9000be0 	stp	x0, x2, [sp]
    40203be4:	b0000000 	adrp	x0, 40204000 <memcpy+0x1b0>
    40203be8:	910a2800 	add	x0, x0, #0x28a
    40203bec:	a90127e8 	stp	x8, x9, [sp, #16]
    40203bf0:	910023e8 	add	x8, sp, #0x8
    40203bf4:	a90227e8 	stp	x8, x9, [sp, #32]
    40203bf8:	910043e1 	add	x1, sp, #0x10
    40203bfc:	aa0303e2 	mov	x2, x3
    40203c00:	97fffdff 	bl	402033fc <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>
    40203c04:	eb02003f 	cmp	x1, x2
    40203c08:	540001e8 	b.hi	40203c44 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail+0x84>  // b.pmore
    40203c0c:	eb01001f 	cmp	x0, x1
    40203c10:	540001a9 	b.ls	40203c44 <_RNvNtNtCsbcsGJ9IzBgZ_4core5slice5index16slice_index_fail+0x84>  // b.plast
    40203c14:	910003e8 	mov	x8, sp
    40203c18:	d503201f 	nop
    40203c1c:	10000709 	adr	x9, 40203cfc <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>
    40203c20:	a90127e8 	stp	x8, x9, [sp, #16]
    40203c24:	910023e8 	add	x8, sp, #0x8
    40203c28:	a90007e0 	stp	x0, x1, [sp]
    40203c2c:	b0000000 	adrp	x0, 40204000 <memcpy+0x1b0>
    40203c30:	91077c00 	add	x0, x0, #0x1df
    40203c34:	a90227e8 	stp	x8, x9, [sp, #32]
    40203c38:	910043e1 	add	x1, sp, #0x10
    40203c3c:	aa0303e2 	mov	x2, x3
    40203c40:	97fffdef 	bl	402033fc <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>
    40203c44:	910003e8 	mov	x8, sp
    40203c48:	d503201f 	nop
    40203c4c:	10000589 	adr	x9, 40203cfc <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>
    40203c50:	a90127e8 	stp	x8, x9, [sp, #16]
    40203c54:	910023e8 	add	x8, sp, #0x8
    40203c58:	b0000000 	adrp	x0, 40204000 <memcpy+0x1b0>
    40203c5c:	9108f800 	add	x0, x0, #0x23e
    40203c60:	a9000be1 	stp	x1, x2, [sp]
    40203c64:	a90227e8 	stp	x8, x9, [sp, #32]
    40203c68:	910043e1 	add	x1, sp, #0x10
    40203c6c:	aa0303e2 	mov	x2, x3
    40203c70:	97fffde3 	bl	402033fc <_RNvNtCsbcsGJ9IzBgZ_4core9panicking9panic_fmt>

0000000040203c74 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix>:
    40203c74:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40203c78:	a90157f6 	stp	x22, x21, [sp, #16]
    40203c7c:	a9024ff4 	stp	x20, x19, [sp, #32]
    40203c80:	910003fd 	mov	x29, sp
    40203c84:	aa0403f3 	mov	x19, x4
    40203c88:	aa0303f4 	mov	x20, x3
    40203c8c:	aa0103f5 	mov	x21, x1
    40203c90:	7144405f 	cmp	w2, #0x110, lsl #12
    40203c94:	540001a0 	b.eq	40203cc8 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix+0x54>  // b.none
    40203c98:	f94012a8 	ldr	x8, [x21, #32]
    40203c9c:	2a0203e1 	mov	w1, w2
    40203ca0:	aa0003f6 	mov	x22, x0
    40203ca4:	d63f0100 	blr	x8
    40203ca8:	2a0003e8 	mov	w8, w0
    40203cac:	aa1603e0 	mov	x0, x22
    40203cb0:	360000c8 	tbz	w8, #0, 40203cc8 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix+0x54>
    40203cb4:	52800020 	mov	w0, #0x1                   	// #1
    40203cb8:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40203cbc:	a94157f6 	ldp	x22, x21, [sp, #16]
    40203cc0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40203cc4:	d65f03c0 	ret
    40203cc8:	b4000114 	cbz	x20, 40203ce8 <_RNvNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB7_9Formatter12pad_integral12write_prefix+0x74>
    40203ccc:	f9400ea3 	ldr	x3, [x21, #24]
    40203cd0:	aa1403e1 	mov	x1, x20
    40203cd4:	aa1303e2 	mov	x2, x19
    40203cd8:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40203cdc:	a94157f6 	ldp	x22, x21, [sp, #16]
    40203ce0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40203ce4:	d61f0060 	br	x3
    40203ce8:	2a1f03e0 	mov	w0, wzr
    40203cec:	a9424ff4 	ldp	x20, x19, [sp, #32]
    40203cf0:	a94157f6 	ldp	x22, x21, [sp, #16]
    40203cf4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40203cf8:	d65f03c0 	ret

0000000040203cfc <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt>:
    40203cfc:	d100c3ff 	sub	sp, sp, #0x30
    40203d00:	a9027bfd 	stp	x29, x30, [sp, #32]
    40203d04:	910083fd 	add	x29, sp, #0x20
    40203d08:	f9400009 	ldr	x9, [x0]
    40203d0c:	d503201f 	nop
    40203d10:	10004b08 	adr	x8, 40204670 <anon.a10a9a1c8b04bc618efc151eec4051b8.12.llvm.10515195519271835186+0x18>
    40203d14:	f10fa13f 	cmp	x9, #0x3e8
    40203d18:	540004e3 	b.cc	40203db4 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0xb8>  // b.lo, b.ul, b.last
    40203d1c:	d28b296c 	mov	x12, #0x594b                	// #22859
    40203d20:	910033ea 	add	x10, sp, #0xc
    40203d24:	5292cff1 	mov	w17, #0x967f                	// #38527
    40203d28:	f2a710cc 	movk	x12, #0x3886, lsl #16
    40203d2c:	9280026b 	mov	x11, #0xffffffffffffffec    	// #-20
    40203d30:	5284e20d 	mov	w13, #0x2710                	// #10000
    40203d34:	f2d8bacc 	movk	x12, #0xc5d6, lsl #32
    40203d38:	52828f6e 	mov	w14, #0x147b                	// #5243
    40203d3c:	91004d4f 	add	x15, x10, #0x13
    40203d40:	f2e68dac 	movk	x12, #0x346d, lsl #48
    40203d44:	52800c90 	mov	w16, #0x64                  	// #100
    40203d48:	72a01311 	movk	w17, #0x98, lsl #16
    40203d4c:	aa0903ea 	mov	x10, x9
    40203d50:	aa0a03f2 	mov	x18, x10
    40203d54:	9bcc7d4a 	umulh	x10, x10, x12
    40203d58:	9100116b 	add	x11, x11, #0x4
    40203d5c:	eb11025f 	cmp	x18, x17
    40203d60:	d34bfd4a 	lsr	x10, x10, #11
    40203d64:	1b0dc940 	msub	w0, w10, w13, w18
    40203d68:	53023c02 	ubfx	w2, w0, #2, #14
    40203d6c:	1b0e7c42 	mul	w2, w2, w14
    40203d70:	53117c42 	lsr	w2, w2, #17
    40203d74:	1b108040 	msub	w0, w2, w16, w0
    40203d78:	8b224502 	add	x2, x8, w2, uxtw #1
    40203d7c:	39400043 	ldrb	w3, [x2]
    40203d80:	39400442 	ldrb	w2, [x2, #1]
    40203d84:	8b202500 	add	x0, x8, w0, uxth #1
    40203d88:	381fd1e3 	sturb	w3, [x15, #-3]
    40203d8c:	39400003 	ldrb	w3, [x0]
    40203d90:	39400400 	ldrb	w0, [x0, #1]
    40203d94:	381fe1e2 	sturb	w2, [x15, #-2]
    40203d98:	381ff1e3 	sturb	w3, [x15, #-1]
    40203d9c:	381fc5e0 	strb	w0, [x15], #-4
    40203da0:	54fffd88 	b.hi	40203d50 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x54>  // b.pmore
    40203da4:	cb0b03eb 	neg	x11, x11
    40203da8:	f100255f 	cmp	x10, #0x9
    40203dac:	540000c8 	b.hi	40203dc4 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0xc8>  // b.pmore
    40203db0:	14000015 	b	40203e04 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x108>
    40203db4:	5280028b 	mov	w11, #0x14                  	// #20
    40203db8:	aa0903ea 	mov	x10, x9
    40203dbc:	f100253f 	cmp	x9, #0x9
    40203dc0:	54000229 	b.ls	40203e04 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x108>  // b.plast
    40203dc4:	53023d4c 	ubfx	w12, w10, #2, #14
    40203dc8:	52828f6d 	mov	w13, #0x147b                	// #5243
    40203dcc:	910033ef 	add	x15, sp, #0xc
    40203dd0:	1b0d7d8c 	mul	w12, w12, w13
    40203dd4:	52800c8d 	mov	w13, #0x64                  	// #100
    40203dd8:	53117d8c 	lsr	w12, w12, #17
    40203ddc:	1b0da98a 	msub	w10, w12, w13, w10
    40203de0:	d100096d 	sub	x13, x11, #0x2
    40203de4:	8b0b01eb 	add	x11, x15, x11
    40203de8:	8b2a250a 	add	x10, x8, w10, uxth #1
    40203dec:	3940014e 	ldrb	w14, [x10]
    40203df0:	3940054a 	ldrb	w10, [x10, #1]
    40203df4:	382d69ee 	strb	w14, [x15, x13]
    40203df8:	381ff16a 	sturb	w10, [x11, #-1]
    40203dfc:	aa0c03ea 	mov	x10, x12
    40203e00:	aa0d03eb 	mov	x11, x13
    40203e04:	b4000049 	cbz	x9, 40203e0c <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x110>
    40203e08:	b40000ca 	cbz	x10, 40203e20 <_RNvXsd_NtNtNtCsbcsGJ9IzBgZ_4core3fmt3num3impyNtB9_7Display3fmt+0x124>
    40203e0c:	8b0a0508 	add	x8, x8, x10, lsl #1
    40203e10:	d100056b 	sub	x11, x11, #0x1
    40203e14:	910033e9 	add	x9, sp, #0xc
    40203e18:	39400508 	ldrb	w8, [x8, #1]
    40203e1c:	382b6928 	strb	w8, [x9, x11]
    40203e20:	52800288 	mov	w8, #0x14                  	// #20
    40203e24:	aa0103e0 	mov	x0, x1
    40203e28:	52800021 	mov	w1, #0x1                   	// #1
    40203e2c:	cb0b0105 	sub	x5, x8, x11
    40203e30:	910033e8 	add	x8, sp, #0xc
    40203e34:	52800022 	mov	w2, #0x1                   	// #1
    40203e38:	8b0b0104 	add	x4, x8, x11
    40203e3c:	aa1f03e3 	mov	x3, xzr
    40203e40:	97fffc3b 	bl	40202f2c <_RNvMsa_NtCsbcsGJ9IzBgZ_4core3fmtNtB5_9Formatter12pad_integral>
    40203e44:	a9427bfd 	ldp	x29, x30, [sp, #32]
    40203e48:	9100c3ff 	add	sp, sp, #0x30
    40203e4c:	d65f03c0 	ret

0000000040203e50 <memcpy>:
    40203e50:	f100405f 	cmp	x2, #0x10
    40203e54:	54000723 	b.cc	40203f38 <memcpy+0xe8>  // b.lo, b.ul, b.last
    40203e58:	cb0003ec 	neg	x12, x0
    40203e5c:	92400988 	and	x8, x12, #0x7
    40203e60:	8b080009 	add	x9, x0, x8
    40203e64:	eb09001f 	cmp	x0, x9
    40203e68:	54000422 	b.cs	40203eec <memcpy+0x9c>  // b.hs, b.nlast
    40203e6c:	f100111f 	cmp	x8, #0x4
    40203e70:	aa0003ea 	mov	x10, x0
    40203e74:	aa0103eb 	mov	x11, x1
    40203e78:	54000323 	b.cc	40203edc <memcpy+0x8c>  // b.lo, b.ul, b.last
    40203e7c:	cb01000a 	sub	x10, x0, x1
    40203e80:	aa0103eb 	mov	x11, x1
    40203e84:	f100815f 	cmp	x10, #0x20
    40203e88:	aa0003ea 	mov	x10, x0
    40203e8c:	54000283 	b.cc	40203edc <memcpy+0x8c>  // b.lo, b.ul, b.last
    40203e90:	927e018c 	and	x12, x12, #0x4
    40203e94:	aa0003ed 	mov	x13, x0
    40203e98:	aa0103ee 	mov	x14, x1
    40203e9c:	8b0c000a 	add	x10, x0, x12
    40203ea0:	8b0c002b 	add	x11, x1, x12
    40203ea4:	aa0c03ef 	mov	x15, x12
    40203ea8:	39400dd0 	ldrb	w16, [x14, #3]
    40203eac:	394009d1 	ldrb	w17, [x14, #2]
    40203eb0:	f10011ef 	subs	x15, x15, #0x4
    40203eb4:	394001d2 	ldrb	w18, [x14]
    40203eb8:	394005c3 	ldrb	w3, [x14, #1]
    40203ebc:	910011ce 	add	x14, x14, #0x4
    40203ec0:	39000db0 	strb	w16, [x13, #3]
    40203ec4:	390009b1 	strb	w17, [x13, #2]
    40203ec8:	390005a3 	strb	w3, [x13, #1]
    40203ecc:	380045b2 	strb	w18, [x13], #4
    40203ed0:	54fffec1 	b.ne	40203ea8 <memcpy+0x58>  // b.any
    40203ed4:	eb0c011f 	cmp	x8, x12
    40203ed8:	540000a0 	b.eq	40203eec <memcpy+0x9c>  // b.none
    40203edc:	3840156c 	ldrb	w12, [x11], #1
    40203ee0:	3800154c 	strb	w12, [x10], #1
    40203ee4:	eb09015f 	cmp	x10, x9
    40203ee8:	54ffffa1 	b.ne	40203edc <memcpy+0x8c>  // b.any
    40203eec:	cb08004b 	sub	x11, x2, x8
    40203ef0:	8b08002a 	add	x10, x1, x8
    40203ef4:	927df16c 	and	x12, x11, #0xfffffffffffffff8
    40203ef8:	f240095f 	tst	x10, #0x7
    40203efc:	8b0c0128 	add	x8, x9, x12
    40203f00:	540007a1 	b.ne	40203ff4 <memcpy+0x1a4>  // b.any
    40203f04:	eb08013f 	cmp	x9, x8
    40203f08:	540000c2 	b.cs	40203f20 <memcpy+0xd0>  // b.hs, b.nlast
    40203f0c:	aa0a03ed 	mov	x13, x10
    40203f10:	f84085ae 	ldr	x14, [x13], #8
    40203f14:	f800852e 	str	x14, [x9], #8
    40203f18:	eb08013f 	cmp	x9, x8
    40203f1c:	54ffffa3 	b.cc	40203f10 <memcpy+0xc0>  // b.lo, b.ul, b.last
    40203f20:	8b0c0141 	add	x1, x10, x12
    40203f24:	92400962 	and	x2, x11, #0x7
    40203f28:	8b020109 	add	x9, x8, x2
    40203f2c:	eb09011f 	cmp	x8, x9
    40203f30:	540000c3 	b.cc	40203f48 <memcpy+0xf8>  // b.lo, b.ul, b.last
    40203f34:	1400002f 	b	40203ff0 <memcpy+0x1a0>
    40203f38:	aa0003e8 	mov	x8, x0
    40203f3c:	8b020009 	add	x9, x0, x2
    40203f40:	eb09001f 	cmp	x0, x9
    40203f44:	54000562 	b.cs	40203ff0 <memcpy+0x1a0>  // b.hs, b.nlast
    40203f48:	f100105f 	cmp	x2, #0x4
    40203f4c:	540004a3 	b.cc	40203fe0 <memcpy+0x190>  // b.lo, b.ul, b.last
    40203f50:	cb01010a 	sub	x10, x8, x1
    40203f54:	f100815f 	cmp	x10, #0x20
    40203f58:	54000443 	b.cc	40203fe0 <memcpy+0x190>  // b.lo, b.ul, b.last
    40203f5c:	39400c2a 	ldrb	w10, [x1, #3]
    40203f60:	3940082b 	ldrb	w11, [x1, #2]
    40203f64:	3940002c 	ldrb	w12, [x1]
    40203f68:	3940042d 	ldrb	w13, [x1, #1]
    40203f6c:	39000d0a 	strb	w10, [x8, #3]
    40203f70:	927e044a 	and	x10, x2, #0xc
    40203f74:	f100115f 	cmp	x10, #0x4
    40203f78:	3900090b 	strb	w11, [x8, #2]
    40203f7c:	3900050d 	strb	w13, [x8, #1]
    40203f80:	3900010c 	strb	w12, [x8]
    40203f84:	54000260 	b.eq	40203fd0 <memcpy+0x180>  // b.none
    40203f88:	39401c2b 	ldrb	w11, [x1, #7]
    40203f8c:	3940182c 	ldrb	w12, [x1, #6]
    40203f90:	f100215f 	cmp	x10, #0x8
    40203f94:	3940102d 	ldrb	w13, [x1, #4]
    40203f98:	3940142e 	ldrb	w14, [x1, #5]
    40203f9c:	39001d0b 	strb	w11, [x8, #7]
    40203fa0:	3900190c 	strb	w12, [x8, #6]
    40203fa4:	3900150e 	strb	w14, [x8, #5]
    40203fa8:	3900110d 	strb	w13, [x8, #4]
    40203fac:	54000120 	b.eq	40203fd0 <memcpy+0x180>  // b.none
    40203fb0:	39402c2b 	ldrb	w11, [x1, #11]
    40203fb4:	3940282c 	ldrb	w12, [x1, #10]
    40203fb8:	3940202d 	ldrb	w13, [x1, #8]
    40203fbc:	3940242e 	ldrb	w14, [x1, #9]
    40203fc0:	39002d0b 	strb	w11, [x8, #11]
    40203fc4:	3900290c 	strb	w12, [x8, #10]
    40203fc8:	3900250e 	strb	w14, [x8, #9]
    40203fcc:	3900210d 	strb	w13, [x8, #8]
    40203fd0:	eb0a005f 	cmp	x2, x10
    40203fd4:	540000e0 	b.eq	40203ff0 <memcpy+0x1a0>  // b.none
    40203fd8:	8b0a0108 	add	x8, x8, x10
    40203fdc:	8b0a0021 	add	x1, x1, x10
    40203fe0:	3840142a 	ldrb	w10, [x1], #1
    40203fe4:	3800150a 	strb	w10, [x8], #1
    40203fe8:	eb09011f 	cmp	x8, x9
    40203fec:	54ffffa1 	b.ne	40203fe0 <memcpy+0x190>  // b.any
    40203ff0:	d65f03c0 	ret
    40203ff4:	eb08013f 	cmp	x9, x8
    40203ff8:	54fff942 	b.cs	40203f20 <memcpy+0xd0>  // b.hs, b.nlast
    40203ffc:	aa0a03ed 	mov	x13, x10
    40204000:	aa0d03f0 	mov	x16, x13
    40204004:	394009af 	ldrb	w15, [x13, #2]
    40204008:	394005ae 	ldrb	w14, [x13, #1]
    4020400c:	38404e11 	ldrb	w17, [x16, #4]!
    40204010:	39400a12 	ldrb	w18, [x16, #2]
    40204014:	394001a1 	ldrb	w1, [x13]
    40204018:	39400da2 	ldrb	w2, [x13, #3]
    4020401c:	d370bdef 	lsl	x15, x15, #16
    40204020:	394015a3 	ldrb	w3, [x13, #5]
    40204024:	39400e10 	ldrb	w16, [x16, #3]
    40204028:	53103e52 	lsl	w18, w18, #16
    4020402c:	aa0e202e 	orr	x14, x1, x14, lsl #8
    40204030:	aa0261ef 	orr	x15, x15, x2, lsl #24
    40204034:	910021ad 	add	x13, x13, #0x8
    40204038:	2a032231 	orr	w17, w17, w3, lsl #8
    4020403c:	2a106250 	orr	w16, w18, w16, lsl #24
    40204040:	aa0e01ee 	orr	x14, x15, x14
    40204044:	2a11020f 	orr	w15, w16, w17
    40204048:	aa0f81ce 	orr	x14, x14, x15, lsl #32
    4020404c:	f800852e 	str	x14, [x9], #8
    40204050:	eb08013f 	cmp	x9, x8
    40204054:	54fffd63 	b.cc	40204000 <memcpy+0x1b0>  // b.lo, b.ul, b.last
    40204058:	17ffffb2 	b	40203f20 <memcpy+0xd0>

000000004020405c <memset>:
    4020405c:	f100405f 	cmp	x2, #0x10
    40204060:	540009e3 	b.cc	4020419c <memset+0x140>  // b.lo, b.ul, b.last
    40204064:	cb0003eb 	neg	x11, x0
    40204068:	92400968 	and	x8, x11, #0x7
    4020406c:	8b080009 	add	x9, x0, x8
    40204070:	eb09001f 	cmp	x0, x9
    40204074:	54000302 	b.cs	402040d4 <memset+0x78>  // b.hs, b.nlast
    40204078:	f100111f 	cmp	x8, #0x4
    4020407c:	aa0003ea 	mov	x10, x0
    40204080:	54000243 	b.cc	402040c8 <memset+0x6c>  // b.lo, b.ul, b.last
    40204084:	0e020c20 	dup	v0.4h, w1
    40204088:	927e016b 	and	x11, x11, #0x4
    4020408c:	aa0003ec 	mov	x12, x0
    40204090:	8b0b000a 	add	x10, x0, x11
    40204094:	aa0b03ed 	mov	x13, x11
    40204098:	5e0e0401 	mov	h1, v0.h[3]
    4020409c:	5e0a0402 	mov	h2, v0.h[2]
    402040a0:	5e060403 	mov	h3, v0.h[1]
    402040a4:	3d000180 	str	b0, [x12]
    402040a8:	f10011ad 	subs	x13, x13, #0x4
    402040ac:	3c003181 	stur	b1, [x12, #3]
    402040b0:	3c002182 	stur	b2, [x12, #2]
    402040b4:	3c001183 	stur	b3, [x12, #1]
    402040b8:	9100118c 	add	x12, x12, #0x4
    402040bc:	54ffff41 	b.ne	402040a4 <memset+0x48>  // b.any
    402040c0:	eb0b011f 	cmp	x8, x11
    402040c4:	54000080 	b.eq	402040d4 <memset+0x78>  // b.none
    402040c8:	38001541 	strb	w1, [x10], #1
    402040cc:	eb09015f 	cmp	x10, x9
    402040d0:	54ffffc1 	b.ne	402040c8 <memset+0x6c>  // b.any
    402040d4:	cb08004a 	sub	x10, x2, x8
    402040d8:	927df148 	and	x8, x10, #0xfffffffffffffff8
    402040dc:	8b080128 	add	x8, x9, x8
    402040e0:	eb08013f 	cmp	x9, x8
    402040e4:	54000102 	b.cs	40204104 <memset+0xa8>  // b.hs, b.nlast
    402040e8:	12001c2b 	and	w11, w1, #0xff
    402040ec:	3200c3ec 	mov	w12, #0x1010101             	// #16843009
    402040f0:	1b0c7d6b 	mul	w11, w11, w12
    402040f4:	aa0b816b 	orr	x11, x11, x11, lsl #32
    402040f8:	f800852b 	str	x11, [x9], #8
    402040fc:	eb08013f 	cmp	x9, x8
    40204100:	54ffffc3 	b.cc	402040f8 <memset+0x9c>  // b.lo, b.ul, b.last
    40204104:	92400942 	and	x2, x10, #0x7
    40204108:	8b020109 	add	x9, x8, x2
    4020410c:	eb09011f 	cmp	x8, x9
    40204110:	54000442 	b.cs	40204198 <memset+0x13c>  // b.hs, b.nlast
    40204114:	f100105f 	cmp	x2, #0x4
    40204118:	540003a3 	b.cc	4020418c <memset+0x130>  // b.lo, b.ul, b.last
    4020411c:	927e044a 	and	x10, x2, #0xc
    40204120:	39000d01 	strb	w1, [x8, #3]
    40204124:	f100115f 	cmp	x10, #0x4
    40204128:	8b0a010b 	add	x11, x8, x10
    4020412c:	39000901 	strb	w1, [x8, #2]
    40204130:	39000501 	strb	w1, [x8, #1]
    40204134:	39000101 	strb	w1, [x8]
    40204138:	54000240 	b.eq	40204180 <memset+0x124>  // b.none
    4020413c:	0e020c20 	dup	v0.4h, w1
    40204140:	f100215f 	cmp	x10, #0x8
    40204144:	5e0e0401 	mov	h1, v0.h[3]
    40204148:	5e0a0402 	mov	h2, v0.h[2]
    4020414c:	5e060403 	mov	h3, v0.h[1]
    40204150:	3c004100 	stur	b0, [x8, #4]
    40204154:	3c007101 	stur	b1, [x8, #7]
    40204158:	3c006102 	stur	b2, [x8, #6]
    4020415c:	3c005103 	stur	b3, [x8, #5]
    40204160:	54000100 	b.eq	40204180 <memset+0x124>  // b.none
    40204164:	5e0e0401 	mov	h1, v0.h[3]
    40204168:	5e0a0402 	mov	h2, v0.h[2]
    4020416c:	3c008100 	stur	b0, [x8, #8]
    40204170:	5e060403 	mov	h3, v0.h[1]
    40204174:	3c00b101 	stur	b1, [x8, #11]
    40204178:	3c00a102 	stur	b2, [x8, #10]
    4020417c:	3c009103 	stur	b3, [x8, #9]
    40204180:	eb0a005f 	cmp	x2, x10
    40204184:	aa0b03e8 	mov	x8, x11
    40204188:	54000080 	b.eq	40204198 <memset+0x13c>  // b.none
    4020418c:	38001501 	strb	w1, [x8], #1
    40204190:	eb09011f 	cmp	x8, x9
    40204194:	54ffffc1 	b.ne	4020418c <memset+0x130>  // b.any
    40204198:	d65f03c0 	ret
    4020419c:	aa0003e8 	mov	x8, x0
    402041a0:	8b020009 	add	x9, x0, x2
    402041a4:	eb09001f 	cmp	x0, x9
    402041a8:	54fffb63 	b.cc	40204114 <memset+0xb8>  // b.lo, b.ul, b.last
    402041ac:	17fffffb 	b	40204198 <memset+0x13c>
