import copy,json,sys,hashlib,subprocess as sp
from pathlib import Path
sys.path.insert(0,'source/tools')
import pi4_fixed_witness as w
j=lambda p:json.loads(Path(p).read_bytes());h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=Path('audit');controls=out/'controls';controls.mkdir(exist_ok=True);p=Path('captures/E1');raw=(p/'uart.bin').read_bytes();proto=w.decode(raw);prefix=raw[:raw.index(b'PW 0')]
def score(inp,assets,tool,expected):
 manifest=assets/'manifest.json';profile=j(manifest)['profile'];a=sp.run([sys.executable,str(tool),str(inp),'--profile',profile,'--manifest',str(manifest),'--elf',str(assets/'kernel.elf'),'--image',str(assets/'kernel8.img')],capture_output=True)
 assert a.returncode==expected,(inp,tool,a.returncode,a.stderr)
 return dict(rc=a.returncode,stderr=a.stderr.decode(),uart_sha256=h(inp),profile=profile,complete=json.loads(a.stdout)['complete'] if a.stdout else None)
records={}
for name in ('bad-mail','bad-site','bad-owner','bad-value','bad-gen','duplicate','missing','bad-order','ambiguous-inner'):
 rows=copy.deepcopy(proto);inn=[r for t,r in rows if t==6];outer=[r for t,r in rows if t==5]
 if name=='bad-mail':inn[1][5]+=8
 if name=='bad-site':inn[0][4]=inn[1][4]
 if name=='bad-owner':inn[1][0]=0
 if name=='bad-value':outer[1][7]+=1
 if name=='bad-gen':inn[1][2]=4
 if name=='duplicate':rows.insert(-1,(6,inn[1]))
 if name=='missing':rows.remove((6,inn[1]))
 if name=='bad-order':idx=rows.index((6,inn[0]));rows[idx],rows[idx+1]=rows[idx+1],rows[idx]
 if name=='ambiguous-inner':inn[1][1:4]=[2,4,6]
 val=0xcbf29ce484222325;data=bytearray(prefix)
 for t,r in rows:
  for x in [t,*r]:val=w.fold(val,x)
  data.extend(('PW '+' '.join(map(str,[t,*r]))+'\n').encode())
 data.extend(f'PW END {len(rows)} {val}\n'.encode());f=controls/(name+'.bin');f.write_bytes(data);records[name]=score(f,p,Path('source/tools/pi4_fixed_witness.py'),2 if name=='ambiguous-inner' else 1)
(out/'negative.json').write_text(json.dumps(records,indent=2))
v2meta=j('source/docs/evidence/pi4-rr-handoff-integration.json')
assert h('source/docs/evidence/pi4-rr-handoff-integration.zip')==v2meta['archive_sha256']
rec={}
for case in ['E1','E2']:
 uart=Path('archived-v2/captures')/case/'uart.bin';assert h(uart)==v2meta['positions'][case]['uart_sha256']
 for role in ['parent','source']:rec['v2-'+case+'-'+role]=score(uart,Path('archived-v2/valid/rr-eng'),Path(role+'/tools/pi4_fixed_witness.py'),2)
for kind,folder,expected in [('original','jnox-pi4-146-independent',(0,0)),('integration','jnox-pi4-integration-aa69146',(0,2))]:
 for k,rc in zip(['fifo','rr'],expected):
  d=Path.home()/folder/(k+'-eng')
  if not (d/'uart.bin').exists():d=d/'first'
  rec[kind+'-'+k]=score(d/'uart.bin',d,Path('source/tools/pi4_fixed_witness.py'),rc)
(out/'archive-replays.json').write_text(json.dumps(rec,indent=2));print({k:v['rc'] for k,v in rec.items()})
