import os,sys,shutil,hashlib,subprocess as s,time,json,selectors,pathlib as P
d=P.Path(__file__).resolve().parent;src=d/'source';q='<WORKSPACE>/arm-speed-lab/build/system/qemu-system-aarch64'
native=P.Path('/tmp/jnox-pi4-170-first-b6222fd'); native.mkdir(exist_ok=False)
plans=[]
for pos,label in [('O1','rr-normal'),('E1','rr-eng'),('E2','rr-eng'),('O2','rr-normal')]:
 o=native/pos;o.mkdir();i=d/'valid'/label; mode=label.split('-')[0];eng=label.endswith('eng')
 for f in ('kernel8.img','kernel.elf','manifest.json'): shutil.copyfile(i/f,o/f)
 s.run([sys.executable,str(src/'tools/package_pi4.py'),'--kernel',str(o/'kernel8.img'),'--output',str(o/'boot'),'--firmware-dir',str(d.parent/('pi4-fixed-'+mode)/'boot')],check=True)
 with (o/'package-verify.log').open('wb') as f:s.run(['sha256sum','-c','SHA256SUMS'],cwd=o/'boot',stdout=f,check=True)
 cmd=[q,'-M','raspi4b','-accel','tcg','-display','none','-serial','stdio','-kernel',str(o/'boot/kernel8.img'),'-d','int','-D',str(o/'exceptions.log')]
 if not eng:
  import re
  names='alarm|sleeper|producer|worker_a|worker_b'
  ranges=re.findall(r'^([a-f0-9]+) ([a-f0-9]+) t .*::selected::('+names+r')$',(i/'symbols.txt').read_text(),re.M)
  assert len(ranges)==3
  cmd[cmd.index('int')]='int,exec,nochain'
  cmd.extend(['-dfilter',','.join(f'0x{int(pc,16):x}+0x{int(size,16):x}' for pc,size,_ in ranges)])
 plans.append((pos,label,o,i,eng,cmd))
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(d/"freeze.json").write_text(json.dumps(dict(source="b6222fd741b5696ddcb92e82d2e3aeebfbb29f22",tools={str(p):h(p) for p in (P.Path(q),d/"protocol.txt",d/"boots.py",src/"tools/pi4_fixed_witness.py",src/"tools/package_pi4.py")},positions=[dict(position=pos,argv=cmd,elf=h(o/"kernel.elf"),image=h(o/"boot/kernel8.img"),manifest=h(o/"manifest.json"),firmware=h(o/"boot/SHA256SUMS")) for pos,label,o,i,eng,cmd in plans]),indent=2))
for pos,label,o,i,eng,cmd in plans:
 start=time.monotonic(); data=bytearray();reads=[];last=start;reason='timeout';err=(o/'stderr').open('wb')
 p=s.Popen(cmd,stdin=s.DEVNULL,stdout=s.PIPE,stderr=err,cwd=o);sel=selectors.DefaultSelector();sel.register(p.stdout,selectors.EVENT_READ)
 with (o/'uart.bin').open('wb') as f:
  while time.monotonic()-start<31.2:
   if sel.select(.05):
    part=os.read(p.stdout.fileno(),65536)
    if not part:reason='early-exit';break
    data.extend(part);f.write(part);f.flush();last=time.monotonic();reads.append([last-start,len(part)])
   if ((eng and b'PW END ' in data and data.endswith(b'\n')) or (not eng and b'B DONE\n' in data)) and time.monotonic()-last>=1: reason='complete-and-quiet' if last-start<=30 else 'late';break
 p.terminate();p.wait(timeout=5);err.close()
 (o/'run.json').write_text(json.dumps(dict(argv=cmd,arm=start,last_from_arm=last-start,quiet=time.monotonic()-last,wall=time.monotonic()-start,stop=reason,exit=p.returncode,reads=reads),indent=2))
 mirror=d/'captures'/pos;shutil.copytree(o,mirror)
 sums={str(f.relative_to(o)):hashlib.sha256(f.read_bytes()).hexdigest() for f in o.rglob('*') if f.is_file()}
 assert all(hashlib.sha256((mirror/f).read_bytes()).hexdigest()==v for f,v in sums.items())
 for x in (o,mirror):(x/'verified.json').write_text(json.dumps(sums,indent=2))
 print(label,reason,len(data),flush=True)


