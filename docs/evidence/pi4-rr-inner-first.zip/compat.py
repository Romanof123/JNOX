from pathlib import Path
import os,json,subprocess as s,hashlib
d=Path(__file__).parent
opts=dict(JNOX_BOARD='pi4',JNOX_PROFILE='fixed',JNOX_APP='fixed-rr',JNOX_PI4_WITNESS='1',JNOX_PI4_WITNESS_ID='159073',JNOX_RR_HANDOFF='2')
m={}
for tree in ['parent','source']:
 for case,env0 in [('default',{}),('smp',dict(JNOX_BOARD='pi4',JNOX_PROFILE='smp',JNOX_APP='directed-wake'))]+([] if tree=='parent' else [(name,{**opts,**over}) for name,over in [('bad-arch',{'JNOX_ARCH':'arm32'}),('bad-board',{'JNOX_BOARD':'virt'}),('bad-fifo',{'JNOX_APP':'fixed-fifo'}),('bad-flag',{'JNOX_RR_HANDOFF':'3'}),('no-witness',{'JNOX_PI4_WITNESS':None}),('zero-id',{'JNOX_PI4_WITNESS_ID':'0'}),('with-smp',dict(JNOX_PROFILE='smp',JNOX_APP='directed-wake'))]]):
  out=d/'compat'/tree/case;out.mkdir(parents=True);target=out/'target'
  env={k:v for k,v in os.environ.items() if not k.startswith('JNOX_')};env.update({k:v for k,v in env0.items() if v is not None});env['CARGO_TARGET_DIR']=str(target)
  r=s.run(['cargo','+1.95.0','build','--release','--locked','-j1'],env=env,cwd=d/tree/'kernel',stdout=s.PIPE,stderr=s.STDOUT);(out/'build.log').write_bytes(r.stdout)
  v={'rc':r.returncode,'selectors':env0}
  if not r.returncode:
   f=target/'aarch64-unknown-none/release/jnox-kernel';b=f.read_bytes()
   import struct
   ph=struct.unpack_from('<Q',b,32)[0];sz,n=struct.unpack_from('<HH',b,54);seg=[]
   for i in range(n):
    p=struct.unpack_from('<II6Q',b,ph+i*sz)
    if p[0]==1:seg.append([*p,hashlib.sha256(b[p[2]:p[2]+p[5]]).hexdigest()])
   v.update(elf=hashlib.sha256(b).hexdigest(),loads=seg)
  m[tree+'/'+case]=v
  print(tree,case,r.returncode,flush=True)
(d/'compat.json').write_text(json.dumps(m,indent=2))

