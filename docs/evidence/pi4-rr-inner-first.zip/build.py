from pathlib import Path
import subprocess as sp,json,os,shutil,hashlib
D=Path.cwd()
for role,configs in [('source',['rr-normal','rr-eng','rr-v2','rr-v1','fifo-v1']),('parent',['rr-normal','rr-v2','rr-v1','fifo-v1'])]:
 for name in configs:
  target=D/('target-'+role+'-'+name);o=D/('valid' if role=='source' else 'reference')/name;o.mkdir(parents=True)
  env={k:v for k,v in os.environ.items() if not k.startswith(('JNOX_','CARGO_','RUST'))};env.update(JNOX_BOARD='pi4',JNOX_PROFILE='fixed',JNOX_APP='fixed-'+name.split('-')[0],CARGO_TARGET_DIR=str(target))
  if not name.endswith('normal'):env.update(JNOX_PI4_WITNESS='1',JNOX_PI4_WITNESS_ID='159073')
  selector={'rr-v2':'1','rr-eng':'2'}.get(name)
  if selector:env['JNOX_RR_HANDOFF']=selector
  cmd=['cargo','+1.95.0','build','--locked','--release','-j1']
  with (o/'build.log').open('xb') as f:sp.run(cmd,cwd=D/role/'kernel',env=env,stdout=f,stderr=sp.STDOUT,check=True)
  shutil.copyfile(target/'aarch64-unknown-none/release/jnox-kernel',o/'kernel.elf')
  script='aarch64-linux-gnu-objcopy -O binary kernel.elf kernel8.img && aarch64-linux-gnu-objdump -dC kernel.elf > disassembly.txt && aarch64-linux-gnu-nm -SC kernel.elf > symbols.txt && aarch64-linux-gnu-readelf -lSW kernel.elf > sections.txt'
  sp.run(['wsl','-d','Ubuntu','--','bash','-c',script],cwd=o,check=True)
  profile={'rr-normal':'pi4-fixed-rr','rr-v2':'pi4-fixed-rr-handoff','rr-eng':'pi4-fixed-rr-handoff-v3','rr-v1':'pi4-fixed-rr-witness','fifo-v1':'pi4-fixed-fifo-witness'}[name]
  h=lambda p:hashlib.sha256((o/p).read_bytes()).hexdigest()
  rec=dict(elf_sha256=h('kernel.elf'),image_sha256=h('kernel8.img'),image_id=None if name.endswith('normal') else 159073,profile=profile,source=sp.check_output(['git','-C',role,'rev-parse','HEAD'],text=True).strip(),command=cmd,selectors={k:v for k,v in env.items() if k.startswith('JNOX_')})
  (o/'manifest.json').write_text(json.dumps(rec,indent=2));print(role,name,flush=True)
