import sys,pathlib as P,json,subprocess as s,re,hashlib
d=P.Path(__file__).resolve().parent;sys.path.insert(0,str(d/'source/tools'))
from fixed_runtime_observer import validate
import pi4_fixed_witness as w
for label in ('O1','E1','E2','O2'):
 eng=label[0]!='O'
 if '-' in label:
  a,m=label.split('-');base=P.Path.home()/('jnox-pi4-146-independent' if a=='original' else 'jnox-pi4-integration-aa69146')/(m+'-eng')
  if not (base/'uart.bin').exists():base=base/'first'
 else:base=d/'captures'/label;m='rr'
 o=d/'audit'/label;o.mkdir(parents=True,exist_ok=True)
 data=(base/'uart.bin').read_bytes()
 if not eng:
  print(label,'ordinary',validate(data,b'FIXED RR',b'PI4'));continue
 profile=json.loads((base/'manifest.json').read_bytes())['profile']
 cmd=[sys.executable,str(d/'source/tools/pi4_fixed_witness.py'),str(base/'uart.bin'),'--profile',profile,'--manifest',str(base/'manifest.json'),'--elf',str(base/'kernel.elf'),'--image',str(base/'kernel8.img')]
 rr=s.run(cmd,capture_output=True);(o/'score.json').write_bytes(rr.stdout);(o/'stderr').write_bytes(rr.stderr);(o/'status.json').write_text(json.dumps(dict(argv=cmd,rc=rr.returncode,uart=hashlib.sha256(data).hexdigest())))
 print(label,'rc',rr.returncode,rr.stderr.decode()[:250])
 if '-' in label:continue
 rows=w.decode(data);events=[r for k,r in rows if k==2]
 log=(base/'exceptions.log').read_text();returns=re.findall(r'Exception return from AArch64 EL1 to AArch64 EL1 PC (0x\w+)',log)
 entries=re.findall(r'Taking exception \d+ \[(\w+)\] on CPU (\d+)\n\.\.\.from EL1 to EL1\n\.\.\.with ESR \w+/(0x\w+)\n\.\.\.with SPSR \w+\n\.\.\.with ELR (0x\w+)\n\.\.\.to EL1 PC (0x\w+)',log)
 assert len(events)==len(returns)==1+len(entries)
 vector_base=int(re.search(r'^([0-9a-f]+) [0-9a-f]+ T sched_vectors$',(d/'valid/rr-eng/symbols.txt').read_text(),re.M)[1],16)
 ledger=[]
 for j,(e,ret) in enumerate(zip(events,returns)):
  assert e[10]==int(ret,16)
  if j:
   kind,cpu,esr,elr,vector=entries[j-1];assert cpu=='0' and int(elr,16)==e[7] and ((kind=='IRQ' and e[1]==1 and e[2]==30 and int(vector,16)==vector_base+0x280) or (kind=='SVC' and e[1]==2 and e[2]==int(esr,16) and int(vector,16)==vector_base+0x200))
  ledger.append(dict(generation=e[0],outgoing=e[4],incoming=e[5],eret=ret,exception=entries[j-1] if j else None,samples=[r for k,r in rows if k==3 and r[0]==e[0]]))
 (o/'ledger.json').write_text(json.dumps(ledger,indent=2))



