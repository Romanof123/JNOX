from pathlib import Path
import hashlib,json,subprocess as s,re,sys
d=Path.cwd();native=Path.home()/'jnox-pi4-159-main-f1e2a73';out=d/'audit'
rows=[]
for l in ['O1','O2']:
 o=d/'captures'/l;meta=json.loads((o/'run.json').read_bytes())
 pm=json.loads((o/'manifest.json').read_bytes());log=(o/'exceptions.log').read_text()
 if l.startswith('O'):
  syms=[(int(a,16),int(n,16),name) for a,n,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) [tT] (.+)$',(d/'valid/rr-normal/symbols.txt').read_text(),re.M)]
  def sym(pc):return next((name for start,n,name in syms if start<=pc<start+n),None)
  ledger=[]
  for block in re.split(r'(?=Exception return from AArch64 EL1 to AArch64 EL1 PC )',log)[1:]:
   pc=int(block.splitlines()[0].split()[-1],16);traces=re.findall(r'^Trace 0: .*?\[[^/]+/([a-f0-9]+)/',block,re.M);irq=re.search(r'Taking exception \d+ \[(\w+)\] on CPU 0.*?with ESR \w+/(\w+).*?with ELR (\w+).*?to EL1 PC (\w+)',block,re.S)
   ledger.append(dict(eret=hex(pc),target=sym(pc),task_blocks=list(dict.fromkeys(sym(int(x,16)) for x in traces)),next=irq.groups() if irq else None))
  (out/l/'ledger.json').write_text(json.dumps(ledger,indent=2))