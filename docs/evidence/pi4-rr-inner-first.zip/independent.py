from pathlib import Path
import hashlib,json,re,struct
j=lambda p:json.loads(Path(p).read_bytes());h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def sizes(d):
 return {k:int(n,16) for k,n in re.findall(r'\[\s*\d+\]\s+\.(text|bss|rodata|data|stack)\s+\S+\s+\w+\s+\w+\s+(\w+)',(d/'sections.txt').read_text())}
s={p.name:sizes(p) for p in Path('valid').iterdir()}
cmp={}
for name in ('rr-normal','rr-v1','fifo-v1','rr-v2'):
 p=Path('valid')/name;q=Path('reference')/name;a=(p/'kernel8.img').read_bytes();b=(q/'kernel8.img').read_bytes();cmp[name]=dict(image_same=a==b,elf_same=h(p/'kernel.elf')==h(q/'kernel.elf'),text_same=a[:s[name]['text']]==b[:sizes(q)['text']],image_diff_bytes=sum(x!=y for x,y in zip(a,b))+abs(len(a)-len(b)))
data={}
for case in ('O1','E1','E2','O2'):
 p=Path('captures')/case;meta=j(p/'run.json');assert meta['stop']=='complete-and-quiet'; assert h(p/'kernel.elf')==j(p/'manifest.json')['elf_sha256'];link=j('audit/'+case+'/ledger.json')
 if case.startswith('O'):
  assert [l.rsplit(' ',1)[-1] for l in (p/'uart.bin').read_text().splitlines()[-2:]]==['DONE','DONE']
  names=[s.split('::')[-1] for e in link for s in e['task_blocks'] if s]
  assert names==['worker_a','alarm','worker_b','worker_a','worker_b'],names
  data[case]=dict(rc=0,linked_worker_blocks=names);continue
 score=j('audit/'+case+'/score.json');events=score['dispatch_rows'];work=score['work_rows'];wide=score['handoff_cells'];inner=score['inner_handoff_cells']
 assert [e[5] for e in events]==[0,1,0,2,0,2,4] and [e[1] for e in events]==[0,1,2,1,1,2,2]
 assert link[2]['eret']==link[1]['exception'][3] and link[5]['eret']==link[4]['exception'][3]=='0x816e0'
 at={w[0]:w[-1] for w in work if w[1]==1};assert at[3]>score['preemptions'][0]['outgoing_progress'] and at[4]>0
 assert inner==[[0,1,5,5,0x817b0,0x89ea8],[1,1,6,6,0x816fc,0x89ea8]]
 assert [w[2:4] for w in wide]==[[5,5],[4,6]] and wide[0][7]==wide[1][7]>0 and wide[1][4]<=wide[0][4]<=wide[0][5]<=wide[1][5]
 ranges=[list(map(int,l.split()[2:])) for l in (p/'uart.bin').read_text().splitlines() if l.startswith('PW 1 ')]
 # tag1: slot, physical role, stack bottom, top, entry
 data[case]=dict(rc=0,payload=wide[0][7],operations=inner,outer_ticks=[[w[4],w[5]] for w in wide],outer_generations=[w[2:4] for w in wide],wide_rc=2,loop_rc=2,progress_by_generation=at,high_preempted_at=score['preemptions'][0]['outgoing_progress'],saved_resumed_B_elr=link[5]['eret'],stacks=ranges,operation_sps=[w[9] for w in wide],postrotation_arithmetic_A=5 in at,postrotation_arithmetic_B=6 in at)
meta=j('compat.json')
assert all(meta['source/'+k]['rc']!=0 for k in ['bad-arch','bad-board','bad-fifo','bad-flag','no-witness','zero-id','with-smp'])
for k in ('default','smp'):cmp[k]=dict(elf_same=meta['parent/'+k]['elf']==meta['source/'+k]['elf'],load_same=meta['parent/'+k]['loads']==meta['source/'+k]['loads'])
print(json.dumps(dict(cases=data,sections=s,legacy_comparison=cmp),indent=2))

