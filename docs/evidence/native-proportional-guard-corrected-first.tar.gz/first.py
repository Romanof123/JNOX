import subprocess as sp,os,pathlib,json,hashlib
from pathlib import Path
base=Path(__file__).resolve().parent
src=base/'src'
os.chdir(src)
os.environ['PATH']=str(Path.home()/'.cargo/bin')+':'+os.environ['PATH']
os.environ['RUSTUP_TOOLCHAIN']='1.95.0'
elf=base/'elf'
elf.mkdir()
def run(label,argv):
    with (base/(label+'.log')).open('w') as f:
        print(json.dumps(list(map(str,argv))),file=f,flush=True)
        rc=sp.run(list(map(str,argv)),stdout=f,stderr=sp.STDOUT).returncode
    print(label,rc,flush=True)
    return rc
clients={'crc':'examples/native-weighted-analytics/checksum.c','histogram':'examples/native-weighted-analytics-rust/Cargo.toml','energy':'examples/native-weighted-analytics/energy.c','reporter':'examples/native-proportional/reporter.c'}
for k,s in clients.items():
    run('app-'+k,['sh','-x','sdk/native-aarch64/'+('build-rust.sh' if k=='histogram' else 'build.sh'),s,elf/(k+'.elf')])
cases=[('seed1','lottery','1','5,3,11'),('seed2','lottery','2','1,7,10'),('stable','stride','',''),('dynlot','lottery','1',''),('dynstride','stride','',''),('solo','lottery','1',''),('legacy','','',''),('refusal','lottery','1','6,3,11')]
for name,pol,seed,floors in cases:
    pkg=base/('pkg-'+name)
    args=['python3','tools/build_native_el0.py','--out',pkg]
    if pol: args+=['--policy',pol,'--quantum-ticks','625000']
    if seed: args+=['--lottery-seed',seed]
    if floors: args+=['--lottery-window','48,24','--lottery-floors',floors]
    slots=['reporter','crc'] if name.startswith('dyn') else ['crc'] if name in ('solo','legacy') else ['crc','histogram','energy']
    for i,k in enumerate(slots):
        prefix='--peer-' if i else '--'
        args +=[prefix+'elf',elf/(k+'.elf')]
        if pol: args +=[prefix+'weight',str(1<<i)]
    if run('build-'+name,args) or name=='refusal':continue
    run('boot-'+name,['python3','tools/native_el0_capture.py',base/('cap-'+name),pkg/'kernel.elf',pkg/'user.elf',clients[slots[0]],'f3be8089034a70bfa4baf35e81ee520f05813526','--manifest',pkg/'manifest.json','--expect-exit','53' if slots[0]=='reporter' else '237','--timeout','180','--uart-limit','33554432'])