import os,subprocess as sp,sys,json,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
os.chdir(p)
os.environ['PYTHONPATH']='/home/ywcho/jnox-169-first-e203caa/deps'
for n,roles in [('seed1','crc,histogram,energy'),('seed2','crc,histogram,energy'),('stable','crc,histogram,energy'),('dynlot','reporter,crc'),('dynstride','reporter,crc'),('solo','crc')]:
 c=Path('cap-'+n); s=hashlib.sha256((c/'session.json').read_bytes()).hexdigest()
 a=['python3','src/tools/native_proportional_replay.py','pkg-'+n,c,'--session-sha256',s,'--products',roles]
 if n=='stable':a+=['--stride-prefix','48']
 with open('score-'+n+'.json','w') as f: r=sp.run(a,stdout=f)
 d=json.load(open('score-'+n+'.json'));print(n,r.returncode,d.get('status'),d.get('detail'),list(d.get('ledger',{})))

