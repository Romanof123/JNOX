from pathlib import Path
import os,subprocess as sp,hashlib,json
b=Path(__file__).resolve().parent
os.chdir(b/'src')
env=dict(os.environ,PATH=str(Path.home()/'.cargo/bin')+':'+os.environ['PATH'],RUSTUP_TOOLCHAIN='1.95.0',JNOX_BOARD='virt',JNOX_PROFILE='native',JNOX_APP='process',JNOX_NATIVE_POLICY='lottery',JNOX_NATIVE_WEIGHTS='1,2,4',JNOX_NATIVE_QUANTUM_TICKS='0',JNOX_NATIVE_LOTTERY_SEED='1',JNOX_NATIVE_LOTTERY_WINDOW='48,24',JNOX_NATIVE_LOTTERY_FLOORS='6,3,11',CARGO_TARGET_DIR=str(b/'raw-target'))
for var,k in zip(['ELF','PEER_ELF','PEER2_ELF'],['crc','histogram','energy']):
 p=b/'elf'/(k+'.elf');env['JNOX_NATIVE_'+var]=str(p);env['JNOX_NATIVE_'+var+'_SHA256']=hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args):
 with (b/(name+'.log')).open('w') as f:
  print(args,file=f,flush=True); r=sp.run(args,stdout=f,stderr=sp.STDOUT,env=env)
 return r.returncode
rc=run('raw-invalid-zero',['python3','tools/build_kernel.py','--arch','aarch64'])
print(rc,'lottery interval [24,48) owner 0: count 5 < floor 6' in (b/'raw-invalid-zero.log').read_text())
