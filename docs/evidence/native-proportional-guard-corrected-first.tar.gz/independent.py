from pathlib import Path
import os,re,hashlib,json,subprocess,sys,math,zlib
from fractions import Fraction as F
from collections import Counter
p=Path(__file__).resolve().parent
os.chdir(p)
sys.path[:0]=[str(p/'src/tools'),'/home/ywcho/jnox-169-first-e203caa/deps']
import native_el0_replay as mm
from native_proportional_replay import Event
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def dump(name,obj):Path(name).write_text(json.dumps(obj,indent=2)+'\n')
def dis(path,out):
 d=subprocess.check_output(['aarch64-linux-gnu-objdump','-d',path],text=True);Path(out).write_text(d)
 return set(int(pc,16) for pc in re.findall(r'^\s*([0-9a-f]+):\s+[0-9a-f]{8}',d,re.M))
oracle={'crc':zlib.crc32(bytes(range(256))*524288),'histogram':[math.comb(8,k)*2097152 for k in range(9)],'energy':sum(i*i for i in range(-128,128))*4194304,'reporter':[sum((17*i+3+r)%256>=240 for i in range(4096)) for r in range(3)]}
pcs={a.stem:dis(a,str(a)+'.dis') for a in Path('elf').glob('*.elf')}
reports={}
for n in ['seed1','seed2','stable','dynlot','dynstride','solo','legacy']:
 c=Path('cap-'+n);pkg=Path('pkg-'+n);man=json.loads((pkg/'manifest.json').read_bytes());launch=json.loads((c/'launch.json').read_bytes())
 session=json.loads((c/'session.json').read_bytes())
 assert all(sha(c/f)==h for f,h in session['hashes'].items())
 assert man==launch['argument_package'] and sha(pkg/'kernel.elf')==sha(c/'kernel.elf')
 uart=(c/'uart.bin').read_bytes();ext=(c/'exceptions.log').read_text()
 mem=mm.Snapshot(launch['ram_base'],(c/'ram.bin').read_bytes());stacks=mm.argument_stacks((pkg/'kernel.elf').read_bytes(),mem,man,uart)
 roles=['reporter','crc'] if n.startswith('dyn') else ['crc'] if len(stacks)==1 else ['crc','histogram','energy']
 physical=[];products=[]
 for i,r in enumerate(roles):
  root=stacks[i]['root'];elf=mm.elf_file((Path('elf')/(r+'.elf')).read_bytes())
  def vals(sym,unit):
   v,size=mm.symbol(elf,sym);b=mm.vread(mem,root,v,size);return [int.from_bytes(b[x:x+unit],'little') for x in range(0,len(b),unit)]
  va,size=mm.symbol(elf,'private_result');pa=(mem.leaf(root,va)&mm.PA_MASK)+(va&4095)
  physical.append({'root':root,'stack_pa':mem.leaf(root,stacks[i]['initial_sp'])&mm.PA_MASK,'product_pa':pa})
  if r=='reporter':
   assert vals('round_count',4)==oracle[r] and vals('private_bytes',8)==[12288] and vals('private_blocks',4)==[3] and vals('private_result',4)==[768]
   products.append({'round_counts':oracle[r],'result':768,'blocks':3,'bytes':12288,'request_ns':vals('request_ns',8),'observed_ns':vals('observed_ns',8),'exit':53})
  else:
   product=vals('private_result',8 if r=='energy' else 4);expected=oracle[r] if r=='histogram' else [oracle[r]]
   count=vals('private_progress',4)[0];assert product==expected and count=={'energy':1073741824,'histogram':536870912,'crc':134217728}[r]
   products.append({'role':r,'blocks':count//256,'bytes_or_samples':count,'result':product,'exit':{'energy':179,'histogram':70,'crc':237}[r]})
 assert len(set(x['product_pa']//4096 for x in physical))==len(roles)
 for i,x in enumerate(products):assert (('NATIVE EL0 EXIT '+str(x['exit'])) if len(roles)==1 else ('NATIVE EL0 EXIT PID '+str(i)+' '+str(x['exit']))).encode() in uart.splitlines()
 dis(pkg/'kernel.elf',str(pkg/'kernel.dis'))
 report=dict(session=sha(c/'session.json'),kernel=sha(c/'kernel.elf'),slots=roles,products=products,private=physical)
 reports[n]=report
 if n=='legacy':continue
 rows=[Event(*map(int,l.split()[3:])) for l in uart.decode().splitlines() if l.startswith('NATIVE PROP EVENT ')]
 trace=[('ret',int(a,16)) if a else (k,int(b,16)) for a,k,b in re.findall(r'Exception return from AArch64 EL1 to AArch64 EL0 PC 0x(\w+)|Taking exception \d+ \[(IRQ|SVC)\]\n\.\.\.from EL0 to EL1\n[^\n]*\n\.\.\.with ELR 0x(\w+)',ext)]
 truth=[];last={};waits=[];start=None;accounts=[0]*len(roles);cuts=[];samples=[];step=0;maxspread=0;maxerr=[F(0)]*3
 for e in rows:
  if e.src<len(roles):
   k='IRQ' if e.kind==1 else 'SVC';truth.append((k,e.src_pc));assert e.src_pc in pcs[roles[e.src]]
   if k=='IRQ':assert e.op==e.eoi==30 and e.entry>=e.cval
   last[e.src]=(e.src_pc,e.src_sp,e.src_pstate,e.src_frame)
   if e.before==2 and e.src==1 and start is not None:samples.append([e.seq,e.src_pc,e.dt])
   if e.stop:
    accounts[e.src]+=e.dt
    if len(cuts)<48 and len(roles)==3:
     assert e.full and e.before==7 and e.dt>=625000
     cuts.append([e.src,e.dt])
     if n=='stable':
      ns=[F(s,1<<i) for i,s in enumerate(accounts)];step=max(step,F(e.dt,1<<e.src));spread=max(ns)-min(ns);assert spread<=step
      maxspread=max(spread,maxspread)
      for i,x in enumerate(accounts):
       err=abs(x-F(sum(accounts)*(1<<i),7));assert err<=(1<<i)*step;maxerr[i]=max(maxerr[i],err)
  if e.dst<len(roles):
   truth.append(('ret',e.dst_pc));assert e.dst_pc in pcs[roles[e.dst]]
   if e.dst in last:assert last[e.dst]==(e.dst_pc,e.dst_sp,e.dst_pstate,e.dst_frame)
  if e.sleep:
   assert start is None;start=e;samples=[]
  if e.woke:
   assert start and e.op==30 and e.entry>=start.sleep and samples and all(x[2]>0 for x in samples)
   waits.append(dict(sleep_event=start.seq,deadline=start.sleep,wake_event=e.seq,wake_sample=e.entry,background=samples,background_ticks=sum(x[2] for x in samples),bounded_service_ticks=sum(max(0,min(rows[i].stop,e.entry)-max(rows[i].start,start.entry)) for i,_,_ in samples)))
   start=None
 assert trace==truth,(n,len(trace),len(truth),next(((i,t,u) for i,(t,u) in enumerate(zip(trace,truth)) if t!=u),None))
 report.update(events=len(rows),selections=sum(e.selection and e.dst<len(roles) for e in rows),service=accounts,qemu_records=len(trace),ppi=sum(k=='IRQ' for k,pc in trace),yield_count=sum(e.kind==2 and e.op==8 for e in rows),waits=waits,dropped=0)
 if waits:
  assert len(waits)==3 and report['yield_count']==3
  report['shortest_positive_lease']=min(e.dt for e in rows if e.dt)
 if len(roles)==3:
  report['first48_service']=[sum(dt for who,dt in cuts if who==i) for i in range(3)]
  assert len(cuts)==48
  if n=='stable':report.update(maximum_step=str(step),maximum_spread=str(maxspread),maximum_errors=list(map(str,maxerr)))
  else:
   seq=''.join('ABC'[i] for i,dt in cuts);assert seq=={'seed1':'BABACBACBCBBACCCCCCBACCAAABACACCCCBCBCCCBBACCBCB','seed2':'CAABCBACBBABACCCCCBBBBCCCBCCCCCBABCBCCABBCBACCCB'}[n]
   wins=[[seq[i:i+24].count(c) for c in 'ABC'] for i in range(25)]
   report.update(winners=seq,counts=[seq.count(c) for c in 'ABC'],windows=wins,minima=list(map(min,zip(*wins))))
dump('independent.json',reports)
print('Independent product, roots, exact seed/stride, and all external trace records agree.')

