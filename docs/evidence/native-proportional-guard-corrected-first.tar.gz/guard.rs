#[path="src/kernel/src/feedback_policy.rs"] mod feedback_policy;
#[path="src/kernel/src/proportional_policy.rs"] mod policy;
use policy::*;
fn snap(p:&Proportional<2>)->(u32,[Option<u128>;2],Option<u128>,Option<u64>,Option<(u32,u32)>){
 (p.ready_mask(), [p.pass_wide(0),p.pass_wide(1)],p.last_normalization_wide(),p.lottery_state(),p.last_draw())
}
fn check(site:u64,r:Rejection,expect:[u64;8]) {
 let w=r.words(site);assert_eq!(w,expect);println!("PIN {:?}",w);
}
#[test] fn independent_normal_calls(){
 for lottery in [false,true] {
 let mut p=if lottery{Proportional::lottery([1,2],44)}else{Proportional::stride([1,2])}.unwrap();
 let before=snap(&p);check(17,p.try_stop_elapsed(0,u64::MAX).unwrap_err(),[17,9,0,0,u64::MAX,0,u64::MAX,0]);
 check(18,p.try_dispatch().unwrap_err(),[18,4,0,0,1,0,0,0]);
 check(10,p.try_mask(8).unwrap_err(),[10,2,8,0,3,0,0,0]);assert_eq!(before,snap(&p));
 p.try_mask(2).unwrap();assert_eq!(p.try_dispatch(),Ok(1));let live=snap(&p);
 let wrong=p.try_stop_elapsed(0,u64::MAX).unwrap_err();
 check(17,wrong,[17,10,0,0,1,0,u64::MAX,0]);
 check(10,p.try_mask(8).unwrap_err(),[10,1,1,0,u64::MAX,0,8,0]);
 check(18,p.try_dispatch().unwrap_err(),[18,3,1,0,u64::MAX,0,2,0]);
 assert_eq!(live,snap(&p));assert_eq!(p.try_stop_elapsed(1,9),Ok(()));
 let mut first=FirstRejection::default();let a=*first.record(17,wrong);
 assert_eq!(*first.record(24,Rejection(0,0,1,0)),a);
 }
 for (h,w,f,weights,expect) in [(0,0,[9,9],[0,0],[4,13,0,0,1,0,64,0]),(2,3,[9,9],[0,0],[4,14,3,0,1,0,2,0]),(2,2,[0,3],[0,0],[4,15,3,0,2,0,1,0]),(2,2,[2,1],[0,0],[4,16,3,0,2,0,0,0]),(2,2,[1,1],[1,17],[4,17,17,0,16,0,1,0])] {
 check(4,NativeWindowInput{seed:7,weights,horizon:h,width:w,floors:f}.try_analyze().unwrap_err(),expect);}
 let high=Rejection(11,(2u128<<64)+3,(4u128<<64)+5,(6u128<<64)+7);
 check(17,high,[17,11,3,2,5,4,7,6]);
}
