from pathlib import Path
import struct,json,hashlib,subprocess,re
for name in "seed1 seed2 stable dynlot dynstride solo".split():
 c=Path("cap-"+name); ram=(c/"ram.bin").read_bytes();launch=json.loads((c/"launch.json").read_bytes());base=launch["ram_base"]
 nm=subprocess.check_output(["aarch64-linux-gnu-nm",str(c/"kernel.elf")],text=True)
 def words(s,n):
  line=next(x for x in nm.splitlines() if s in x);addr=int(line.split()[0],16)
  return list(struct.unpack_from("<"+"Q"*n,ram,addr-base))
 rec=words("FIRST_REJECTION",9);evt=words("GUARD_EVENT",6)
 assert rec==[0]*9 and evt[0] in [0,1,2] and b"NATIVE PROP FAULT" not in (c/"uart.bin").read_bytes()
 print(name,json.dumps(dict(record=rec,event=evt,session=hashlib.sha256((c/"session.json").read_bytes()).hexdigest())))
