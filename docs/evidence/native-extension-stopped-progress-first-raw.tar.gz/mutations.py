import os,subprocess
from pathlib import Path
o=Path(os.environ['out']);repo=o/'mut-src'; src=repo/'kernel/src'
target='native_extension_transaction.rs';policy='extension_policy.rs'
pub='publication_and_absence_at_cutoff';stale='obsolete_producer_cannot_change_a_newer_transaction';watch='missing_progress_reservations_and_inclusive_watchdog'
cases=[('inclusive-publication',target,'stamp >= self.cutoff','stamp > self.cutoff',pub),
('early-consume',target,'now < self.cutoff','now.saturating_add(1) < self.cutoff',pub),
('duplicate-consume',target,'self.evaluating = false;\n        if let Some(reply)','self.evaluating = true;\n        if let Some(reply)',pub),
('stale-erases-new',target,'if !self.pending() || self.cell != Some(reply.cell) { return false; }','if !self.pending() || self.cell != Some(reply.cell) { self.reply = None; return false; }',stale),
('obsolete-identity',target,' || self.cell != Some(reply.cell)','',stale),
('stale-consumer',target,' || self.cell != Some(cell)','',stale),
('terminal-forgets-reply',target,'self.reply = None;\n        self.evaluating = false;','self.evaluating = false;',stale),
('trust-before-commit',target,'self.reply = Some(reply);','self.heartbeat = reply.progress; self.reply = Some(reply);',pub),
('watchdog-off-by-one',policy,'now - self.last_change >= self.timeout','now - self.last_change > self.timeout',watch),
('lost-heartbeat-reset',policy,'self.last_change = now;', 'self.last_change = self.origin;',watch),
('accept-regressed',policy,'progress < self.progress','false',watch)]
for tag,file,a,b,test in cases:
 p=src/file; orig=p.read_text();assert orig.count(a)==1
 try:
  p.write_text(orig.replace(a,b)); logfile=o/('mut-'+tag+'.log')
  with logfile.open('w') as l:
   subprocess.run(['rustc','--edition=2024','--test','tools/scheduling_tests.rs','-o',str(o/'mutant')],cwd=repo,stdout=l,stderr=l,check=True)
   name='native_extension_transaction::tests::'+test
   r=subprocess.run([str(o/'mutant'),'--exact',name,'--nocapture'],stdout=l,stderr=l)
  assert r.returncode==101 and '1 failed' in logfile.read_text();print(tag,name,r.returncode,flush=True)
 finally:p.write_text(orig)
