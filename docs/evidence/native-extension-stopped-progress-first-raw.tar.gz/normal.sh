set -eu
r="$prev/ref/accepted"
for n in accepted stale cpu fuel extended sleep; do
p="$out/$n"
if [ "$n" = accepted ]; then p="$prev/a/ordinary"; else
rule=$n; args=()
case "$n" in extended) rule=accepted; args=(--peer2-arg four-batches);; sleep) rule=accepted; args=(--arg sleep-400);; esac
python3 tools/build_native_el0.py --out "$p" --policy extension --elf "$r/user.elf" --peer-elf "$r/native_peer.elf" --peer-elf "$r/native_peer2.elf" --extension-program "examples/native-extension/rules/$rule.txt" "${args[@]}" > "$out/$n.build" 2>&1
fi
rev=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["commit"])' "$p/manifest.json")
for mode in plain trace; do
args=(); [ "$mode" = trace ] || args=(--plain); cap="$out/$n-$mode"
python3 tools/native_el0_capture.py "$cap" "$p/kernel.elf" "$r/user.elf" "$prev/ref/accepted-trace/probe.c" "$rev" --expect-exit 30 "${args[@]}" > "$cap.capture" 2>&1 || cat "$cap.capture"
python3 tools/native_extension_replay.py "$p" "$cap" --session-sha256 "$(sha256sum "$cap/session.json" | cut -d' ' -f1)" > "$cap.replay" 2> "$cap.err" || cat "$cap.err"
done
done
