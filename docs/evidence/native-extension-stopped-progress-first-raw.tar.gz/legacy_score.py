import struct,re,os,json
from pathlib import Path
o=Path(os.environ['out']);p=o/'legacy-diagnostic/capture'
b=(p/'audit.bin').read_bytes(); n,f,t,q,a,h,w=struct.unpack('<7Q',b[:56]);rows=list(struct.iter_unpack('<25Q',b[56:]));assert [r[5] for r in rows]==[0,1,7,1,2,7,3,3,7];assert [r[7] for r in rows]==[2,1,0,1,1,0,1,255,0];assert [r[9] for r in rows]==[1,2,2,3,4,4,4,4,4]
irq=[int(v,16) for v in re.findall(r'Taking exception 5 \[IRQ\].*?with ELR (0x[0-9a-f]+)',(p/'int.trace').read_text(),re.S)]
pc=[]
for k,r in enumerate(rows):
 s=t+k*q
 if k%3!=2:
  assert r[10]==s+a<=r[11]<=r[15]<=r[17]<s+h and r[23]==30;pc.append(r[12])
 assert r[18]==s+q<=r[19]<s+q+a and r[24]==30;pc.append(r[20])
assert irq==pc
print('legacy diagnostic matched all 9 cells and 15 IRQ PCs; watchdog equals 2; zero delegate readiness gave idle at 7')
