set -u
sha() { sha256sum "$1" | cut -d' ' -f1; }
for pos in "$@"; do
g=${pos%-*}; v=${pos#*-}
r="$prev/ref/accepted/manifest.json"; l="$prev/ref/accepted-trace/launch.json"; p="$prev/$g/$v"; e="$out/$g-gate/equivalence.json"
for m in plain trace; do
c="$out/$pos-$m"; opts=(); [ "$m" = trace ] || opts=(--plain)
args=("$pos" "$p" "$c" "$r" --cohort-sha256 "$(sha "$prev/$g/cohort.json")" --preflight "$e" --preflight-sha256 "$(sha "$e")" --reference-sha256 "$(sha "$r")" --reference-launch "$l" --reference-launch-sha256 "$(sha "$l")")
python3 tools/native_extension_stop.py capture "${args[@]}" --probe "$prev/ref/accepted-trace/probe.c" "${opts[@]}" > "$c.capture" 2>&1
cap_rc=$?
if [ -f "$c/session.json" ]; then python3 tools/native_extension_stop.py replay "${args[@]}" --session-sha256 "$(sha "$c/session.json")" > "$c.replay" 2> "$c.err"; rc=$?; else rc=99; fi
echo "$pos $m capture=$cap_rc replay=$rc" | tee -a "$out/fixture-status"; [ ! -f "$c.err" ] || cat "$c.err"
done
done
