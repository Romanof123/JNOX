import json,os,re,struct,subprocess
from pathlib import Path
o=Path(os.environ['out']);prev=Path(os.environ['prev'])
def load(p):return json.loads(p.read_text())
def sym(p):
 t=subprocess.check_output(['aarch64-linux-gnu-nm','-nS',p],text=True)
 return {n:(int(v,16),int(z,16)) for v,z,n in re.findall(r'(?m)^([0-9a-f]+) ([0-9a-f]+) \w (\S+)$',t)}
def phys(mem,base,root,va):
 t=root&0xfffffffff000
 for sh in (30,21,12):
  desc=struct.unpack_from('<Q',mem,t+8*((va>>sh)&511)-base)[0];assert desc&3==3;t=desc&0xfffffffff000
 return t+(va&4095)-base,desc
scores={}
for p in sorted(o.glob('*/session.json')):
 c=p.parent;tag=c.name
 if '-' not in tag:continue
 name,mode=tag.rsplit('-',1)
 if name in ['accepted','stale','cpu','fuel','extended','sleep']: 
  pkg=prev/'a/ordinary' if name=='accepted' else o/name
 else:g,v=name.split('-');pkg=prev/g/v
 d=load(c.with_suffix('.corrected-replay') if tag=='b-ordinary-plain' else c.with_suffix('.replay'));assert not d['issues'] and not d.get('unknown')
 uart=(c/'uart.bin').read_text();rows=[list(map(int,r.split())) for r in re.findall('(?m)^NATIVE EXTENSION EVENT (.+)$',uart)]
 ver,epoch,hz,q,*spec=map(int,re.search('NATIVE EXTENSION CONFIG (.+)',uart)[1].split());assert hz==62500000 and q==6250000 and spec==[5,2,3]
 dec=[r for r in rows if r[18] in range(9)]
 expected={'a-active':'21012021','a-dormant':'22021011','extended':'2202201131','sleep':'220213110','accepted':'22021011'}.get(name,'220110130330' if name.startswith('b-') else '11012022')
 assert ''.join(str(r[10]) for r in dec)==expected
 stopped=([1,3] if name=='a-active' else [9] if name=='b-active' else [])
 assert [r[5] for r in rows if r[17]]==stopped and all(r[13]==0 for r in rows)
 base=load(c/'launch.json')['ram_base'];mem=(c/'ram.bin').read_bytes();hb=0;last=0;work=[];ends=[];reg=[]
 for k,r in enumerate(dec):
  S=epoch+k*q;assert r[0:2]==[1,30] and r[37]==r[11] and r[38]&7==5
  if r[16]:assert S<=r[16]<S+q//4<=r[2]; hb+=1;last=k
  if k%3==2:assert r[18:20]==[7,0] and not r[16]
  assert hb==r[20]
  if k in stopped:
   assert r[16]==0 and r[37]==S+q//4 and r[18]==(8 if k-last<2 else 3) and r[19]==0 and r[9]==3
   a,desc=phys(mem,base,r[29],r[25]);assert mem[a:a+4]==b'\x00\x00\x00\x14' and desc>>53&1==0
   if mode=='trace':
    ex=(c/'exceptions.log').read_text()
    pts=list(re.finditer(r'Taking exception 5 \[IRQ\](?: on CPU 0)?\n\.\.\.from EL1 to EL1\n[^\n]*\n\.\.\.with ELR 0x'+f'{r[25]:x}'+r'\n',ex))
    match=pts[stopped.index(k)]; assert len(pts)==len(stopped)
    pat=r' PC=([a-f0-9]+) X00=([0-9a-f]+).*? SP=([a-f0-9]+)\nPSTATE=([a-f0-9]+)'
    v=[tuple(int(x,16) for x in z) for z in re.findall(pat,ex[:match.start()],re.S)]
    pc,x0,sp,ps=v[-1];assert pc==r[25] and x0==k and ps&0x8f==5
    kernel=sym(c/'kernel.elf');lo,sz=next(v for n,v in kernel.items() if 'EVALUATOR' in n and v[1]==16384);assert lo<=sp<lo+sz
    _,desc=phys(mem,base,r[29],sp);assert desc>>54&1 and desc>>53&1 and (desc>>6)&3==0
    reg.append(dict(k=k,last=last,age=k-last,pc=hex(pc),pstate=hex(ps),sp=hex(sp),root=hex(r[29]),irq_lag=r[2]-r[37],selected=r[10],grant=r[22]))
  if r[10]==3: t=r[32]
  else:t=next(x[2] for x in rows if x[5]==k and x[9]==r[10] and x[0]==2 and (x[1] in (1,8) or (name=='sleep' and k==2 and x[1]==6)))
  assert S<=t<S+q//2;work.append(t-S)
  if k<len(dec)-1:
   x=next(v for v in rows if v[4]==k and v[5]==k+1);assert x[0:2]==[1,30] and x[37]==S+q and x[38]&7==5 and S+q<=x[2]<S+q+q//4;ends.append(x[2]-S-q)
 assert rows[-1][24]==7 and rows[-1][12]==0 and rows[-1][10]==4
 totals=[];expected_totals=[262144,62,9900] if name.startswith('b-') else [9900,62,262144 if name=='extended' else 196608]
 for i,app in enumerate(('user.elf','native_peer.elf','native_peer2.elf')):
  root=next(r[29] for r in rows if r[0]==2 and r[9]==i);va=sym(pkg/app)['private_result'][0];a,desc=phys(mem,base,root,va);totals.append(struct.unpack_from('<Q',mem,a)[0])
 assert totals==expected_totals
 scores[tag]=dict(owners=expected,work=work,ends=ends,products=totals,canceled=stopped,regs=reg)
print(json.dumps(scores,indent=2))
