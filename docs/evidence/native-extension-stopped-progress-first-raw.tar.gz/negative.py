import os,sys,shutil,json,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
from native_extension_source_equivalence import check_inputs
o=Path(os.environ['out']); orig=Path(os.environ['prev'])/'a'
for name,idx,new,want in [('erratum-typo',2,'--fix-cortex-a53-843418','flavour'),('duplicate',9,'--fix-cortex-a53-843419','flavour'),('z-unknown',18,'execstack','unknown -z'),('foreign-search',14,'/tmp/foreign','search directory'),('unknown-option',9,'--unrelated-option','unaccounted')]:
 d=o/('negative-'+name);(d/'link').mkdir(parents=True);(d/'link/blobs').symlink_to(orig/'link/blobs');shutil.copy(orig/'spec.json',d)
 def read(p):return json.loads((orig/p).read_text())
 def write(p,x):(d/p).write_text(json.dumps(x,indent=2))
 inp=read('link/inputs.json');inv=read('link/invocation.json');rec=read('cohort.json')
 for flags in (inp['raw_flags'],inp['expanded_flags'],inv['argv']):flags[idx]=new
 write('link/inputs.json',inp);write('link/invocation.json',inv);rec['inputs_sha256']=hashlib.sha256((d/'link/inputs.json').read_bytes()).hexdigest();write('cohort.json',rec)
 try:check_inputs(d,{},{});raise AssertionError('accepted')
 except ValueError as e: print(name,str(e));assert want in str(e)
