from pathlib import Path
import ast,base64,hashlib,json,re,struct,sys
p=Path
docs=p(sys.argv[1]) if len(sys.argv)>1 else p('src/docs/evidence')
load=lambda name: json.loads((docs/name).read_bytes())
one=load('evd-006.json'); wake=load('evd-029.json')
events=lambda s: re.findall(r'(Exception return from AArch64 EL1 to AArch64 EL1 PC |\.\.\.with ELR )(0x[0-9a-f]+)',s)
res={}
for folder in ['outputs/cbs','parent/cbs']:
 d=p(folder);log=(d/'runner.log').read_text(); m=re.search(r'UART \((\d+) bytes\) = (b.*)',log)
 uart=ast.literal_eval(m[2]); assert len(uart)==int(m[1]); (d/'uart.bin').write_bytes(uart)
 trace=(d/'int.trace').read_text(); ev=events(trace); baseline=events(one['exception_trace'])
 assert ev==baseline[:len(ev)] and 'Taking exception 2 [SVC]' not in trace
 success=uart==bytes.fromhex(one['uart_hex']) and ev==baseline
 res[folder]=dict(rc=int((d/'status').read_text()),elf_sha256=hashlib.sha256((d/'kernel.elf').read_bytes()).hexdigest(),uart_hex=uart.hex(),irqs=trace.count('[IRQ]'),entry_and_stop_pcs=ev,acceptance=success)
assert not res['outputs/cbs']['acceptance'] and res['parent/cbs']['acceptance']
d=p('outputs/cbs-wake');raw=(d/'audit.bin').read_bytes()
parse=lambda b:list(struct.iter_unpack('<24Q',b))
a=parse(raw);b=parse(base64.b64decode(wake['raw_base64']['audit.bin']));assert len(a)==len(b)==34
cols=[*range(11),12,14,15,17,18,21,22,23]
for i,(x,y) in enumerate(zip(a,b)):
 assert all(x[k]==y[k] for k in cols)
 assert x[11]==a[0][11] and x[13]==x[11]+(i+1)*x[12] and x[13]<=x[16]<x[13]+x[12]
 if x[20]:assert x[13]-x[12]<=x[20]<x[13]
 assert x[19]>0
trace=(d/'int.trace').read_text()
assert (d/'uart.bin').read_bytes()==base64.b64decode(wake['raw_base64']['uart.bin'])
assert events(trace)==events(wake['exception_trace']) and len(events(trace))==78
assert trace.count('[IRQ]')==34 and trace.count('[SVC]')==5
assert [i for i,x in enumerate(a) if x[20]]==[0,4,8,14,22]
res[str(d).replace('\\','/')]=dict(accepted=True,rows=len(a),same_columns=cols,irq_count=34,svc_count=5,svc_slots=[i for i,x in enumerate(a) if x[20]],grants=[x[6] for x in a],pc_events=78,quantum=a[0][12],irq_lateness=[x[16]-x[13] for x in a],elf_sha256=hashlib.sha256((d/'kernel.elf').read_bytes()).hexdigest())
print(json.dumps(res,indent=2))
