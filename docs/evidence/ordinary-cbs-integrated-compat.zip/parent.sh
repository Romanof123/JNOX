set -eu
r=$PWD
d=$(mktemp -d /tmp/jnox-cbs172-XXXXXXXX)
export CARGO_HOME="$HOME/jnox-169-first-e203caa/cargo" RUSTUP_HOME="$HOME/jnox-169-first-e203caa/rustup" CARGO_BUILD_JOBS=1 PYTHONDONTWRITEBYTECODE=1
export PATH="$CARGO_HOME/bin:$PATH"
git clone -q --no-checkout "$r/src/.git" "$d/src"
git -C "$d/src" checkout -q --detach 12a98a9178903798b6b90cced17bd785d219eedc
cd "$d/src"
mkdir "$r/parent"
for profile in cbs; do
 o="$r/parent/$profile"
 mkdir "$o"
 export CARGO_TARGET_DIR="$d/target-$profile"
 (cd kernel && cargo +1.95.0 build --release --locked --features "$profile-bench" -j1) > "$o/build.log" 2>&1
 cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" "$o/kernel.elf"
 if [ "$profile" = cbs ]; then
  export CBS_EVIDENCE="$o"
  printf '%s\n' '#!/bin/sh' 'exec qemu-system-aarch64 -d int -D "$CBS_EVIDENCE/int.trace" "$@"' > "$d/qemu-int"
  chmod +x "$d/qemu-int"
  q="$d/qemu-int"; deadline=5
 else
  export CBS_WAKE_CAPTURE_DIR="$d/wake-capture"
  q=./tools/cbs_wake_capture.py; deadline=15
 fi
 set +e
 python3 tools/qemu_boot.py --profile "$profile" --timeout "$deadline" --qemu "$q" --kernel "$o/kernel.elf" > "$o/runner.log" 2>&1
 rc=$?
 set -e
 echo "$rc" > "$o/status"
 if [ "$profile" = cbs-wake ] && [ -d "$d/wake-capture" ]; then cp -r "$d/wake-capture/." "$o/"; fi
 aarch64-linux-gnu-nm -nS "$o/kernel.elf" > "$o/symbols.txt"
 aarch64-linux-gnu-objdump -d "$o/kernel.elf" > "$o/disassembly.txt"
 echo "$profile rc=$rc"; tail -3 "$o/runner.log"
done