from pathlib import Path
import csv, hashlib, json, zipfile, shutil, struct, subprocess
r=Path.home()/'iv219repeat'
e=r/'evidence'
o=Path('/mnt/d/codex')
name='jnox219-01521256-counterbalanced'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,rows):
 with (e/name).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader();w.writerows(rows)
cells={}; stages=[]; frames=[]; boots=[]; paired=[]
for rnd in range(5):
 for c in ['default','icount3']:
  for t in ['p','q']:
   pair=[]
   for v in ['base','cand']:
    n=f'{rnd}-partition-{t}-{c}-{v}'; folder=e/n
    a=json.loads((e/(n+'.json')).read_text()); ws=a['windows']; i=ws[0]['release']; assert a['frequency']==62500000
    sy=subprocess.check_output(['aarch64-linux-gnu-nm','-n',folder/'kernel.elf'],text=True)
    off=int(next(x.split()[0] for x in sy.splitlines() if x.endswith(' native_vruntime_journal')),16)-0x40200000
    raw=(folder/'ram.bin').read_bytes()
    rows=list(struct.iter_unpack('<16Q',raw[off:off+513*128])); prev={}
    for k in range(len(ws)+2):
     g=rows[4+k*19:23+k*19]; pid=g[0][2]
     banks=[]
     for tag,rr in [(24,g[1:9]),(25,g[11:19])]:
      assert len(rr)==8 and all(x[:3]==(tag,rr[0][1],pid) for x in rr)
      b=b''.join(struct.pack('<13Q',*x[3:]) for x in rr); assert len(b)==832; banks.append(b)
     if pid in prev: assert prev[pid]==banks[0]
     prev[pid]=banks[1]; frames.append(dict(boot=n,generation=k+1,pid=pid,restore_sha256=hashlib.sha256(banks[0]).hexdigest(),stop_sha256=hashlib.sha256(banks[1]).hexdigest()))
    for w in ws:
     d,s,ret,x=[w[j] for j in ('release','selected','return_sample','user_tick')]
     assert d<=i<=s<=ret<=x and x-d==w['latency']
     stages.append(dict(boot=n,generation=w['generation'],owner=w['owner'],pid=w['pid'],d=d,i=i,selection=s,r=ret,x=x,d_i=i-d,i_selection=s-i,selection_r=ret-s,r_x=x-ret,total=x-d,miss=int(x-d>62500)))
     i=w['irq_entry']
    mx=max(w['latency'] for w in ws); miss=a['timing_misses']; g2=ws[1]['latency']
    b=dict(boot=n,round=rnd,table=t,clock=c,revision=v,maximum=mx,gen2=g2,misses=len(miss),generations=','.join(map(str,miss)),session=a['session_sha256'])
    boots.append(b);pair.append(b);cells.setdefault((t,c,v),[]).append(b)
   paired.append(dict(table=t,clock=c,round=rnd,order='CB' if rnd in (2,3) else 'BC',base_max=pair[0]['maximum'],cand_max=pair[1]['maximum'],max_delta=pair[1]['maximum']-pair[0]['maximum'],base_gen2=pair[0]['gen2'],cand_gen2=pair[1]['gen2'],gen2_delta=pair[1]['gen2']-pair[0]['gen2'],base_misses=pair[0]['misses'],cand_misses=pair[1]['misses']))
save('stages.csv',stages);save('frames.csv',frames);save('boots.csv',boots);save('pairs.csv',paired)
for a in e.glob('compat*.json'):
 assert (e/(a.stem+'.replay-rc')).read_text().strip()=='0' or json.loads(a.read_text()).get('timing_misses')
hist=e/'historical';hist.mkdir(exist_ok=True)
for f in (Path.home()/'jnox219-first').glob('partition-*-*'):
 if f.is_dir(): shutil.copytree(f,hist/f.name,dirs_exist_ok=True)
 elif 'build' not in f.name:shutil.copy2(f,hist/f.name)
for p in r.glob('build-*'):
 for f in ['build.log','manifest.json']:
  shutil.copy2(p/f,e/(p.name+'-'+f))
for f in ('run.sh','progress.log','analyze.py'):shutil.copy2(r/f,e/f)
l=['# Native partition frame journal / 네이티브 파티션 프레임 기록','',
'Parent f7d62aaea34ca4d298c5e052747f4f0e6602f76b, candidate 01521256ef1052d07a9fc73b82f7b38af0a70a00, plan c04c00236cefaa076e561f972bb0e256c47fd53d. Serial WSL ext4, CARGO_BUILD_JOBS=1, one QEMU Cortex-A72 per cold run. Five pairs per cell (first BC plus BC, CB, CB, BC). Bound 62,500 ticks at 62.5 MHz. Historical first P/default generation 2 was 73,392 ticks. Four historical originals are retained separately.','',
'|Table / clock|Revision|First max|First miss generations|Boots over limit / 5|Windows over limit|Max across 5|','|---|---|---:|---|---:|---:|---:|']
for (t,c,v),bs in cells.items():l.append(f"|{t.upper()} / {c}|{v}|{bs[0]['maximum']}|{bs[0]['generations'] or 'none'}|{sum(b['misses']>0 for b in bs)}|{sum(b['misses'] for b in bs)}|{max(b['maximum'] for b in bs)}|")
l+=['','Every fresh P/Q boot completed the exact parent parser. It verified all 104 restored words against the private saved frame, stopped RAM and private address spaces, true EL0 returns and IRQ/SVC transitions against QEMU exceptions, readiness, explicit idle, positive private 3n/5n work and exits 41/42. frames.csv independently fingerprints both banks for every dispatch including drains and checks consecutive restoration per PID. stages.csv gives raw d, i, selection, r and x plus each interval for every timed generation. First generation uses the epoch for i. boots.csv and pairs.csv retain first and repeat values and paired deltas without pooling clocks.','',
'두 버전의 기본 시계 최초 P/Q에서 모두 2세대 한도 초과가 발생했다. 결정적 시계 최초 P/Q는 모두 통과했다. 시간 초과와 무관하게 모든 P/Q 부팅에서 실제 EL0 실행, 전용 주소 공간, 104워드 문맥 복구, IRQ/SVC 및 두 작업의 정상 종료를 원판 재생기로 확인했다. 기본 시계에서는 수정본이 원래의 1 ms 기준을 보장한다는 결론을 내릴 수 없다. 가상 장치 관측만으로 지연의 원인을 특정할 수 없다.','',
'The first default-clock P and Q pairs both missed generation 2 in both revisions. The candidate does not establish a 1 ms bound on the default virtual clock. The stage timings alone do not identify a causal speedup or host cause.','', '## Compatibility / 호환성','']
for f in sorted(e.glob('compat*.replay-rc')):l.append(f"- {f.name.split('.')[0]}: parent replay exit {f.read_text().strip()}")
assert len(list(e.glob('compat*.replay-rc')))==5
report=e/'REPORT.md';report.write_text('\n'.join(l)+'\n');shutil.copy2(report,o/(name+'.md'))
m=e/'SHA256SUMS';m.write_text(''.join(f'{digest(p)}  {p.relative_to(e)}\n' for p in sorted(e.rglob('*')) if p.is_file() and p!=m))
z=o/(name+'.zip')
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,6) as ar:
 for p in sorted(e.rglob('*')):
  if p.is_file():ar.write(p,p.relative_to(e))
with zipfile.ZipFile(z) as ar:assert ar.testzip() is None
z.with_suffix('.zip.sha256').write_text(digest(z)+'  '+z.name+'\n');print(report.read_text(),digest(z))

