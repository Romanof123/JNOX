set -eu
cd ~/iv219repeat
R=$PWD
export CARGO_BUILD_JOBS=1 PYTHONPATH=$HOME/jnox-169-first-e203caa/deps PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH
for v in base cand; do
 for a in partition-p partition-q $(test "$v" != cand || echo weighted-share weighted-wake startup-probe); do
 cd "$R/$v"; python3 tools/build_native_el0.py --out "$R/build-$v-$a" --app "$a"
 done
done
boot(){
 v=$1; a=$2; c=$3; tag=$4; cd "$R/$v"; b=$R/build-$v-$a; d=$R/evidence/$tag-$a-$c-$v; rev=$(git rev-parse HEAD)
 case $a in partition-*) src=native_partition_monitor; args="$a $c"; t=native_weighted_capture; rep=native_partition_replay;; weighted-*) src=native_weighted_monitor; args="${a#weighted-} $c"; t=native_weighted_capture; rep=native_weighted_replay;; *) src=native_startup_probe; args=""; t=native_el0_capture; rep=native_el0_replay;; esac
 rc=0; python3 tools/$t.py $args "$d" "$b/kernel.elf" "$b/user.elf" "examples/portability/$src.c" "$rev" >"$d.stdout" 2>"$d.stderr" || rc=$?
 echo "$rc" >"$d.capture-rc"
 if [ -s "$d/session.json" ]; then rc=0; python3 "$R/base/tools/$rep.py" "$d" "$(sha256sum "$d/session.json" | cut -d' ' -f1)" >"$d.json" 2>"$d.replay-err" || rc=$?; echo "$rc" >"$d.replay-rc"; fi
 echo "$tag $v $a $c $rc"
}
for round in 0 1 2 3 4; do
 for c in default icount3; do for a in partition-p partition-q; do
 order="base cand"; case $round in 2|3) order="cand base";; esac
 for v in $order; do boot "$v" "$a" "$c" "$round"; done
 done; done
done
for a in weighted-share weighted-wake; do for c in default icount3; do boot cand "$a" "$c" compat; done; done
boot cand startup-probe default compat

