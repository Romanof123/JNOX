import json, pathlib, hashlib
p=pathlib.Path(__file__).parent
cases=[
('plain','#11','#22',1),('qualified','Romanof123/JNOX#11','Romanof123/JNOX#22',1),('url','https://github.com/Romanof123/JNOX/issues/11','https://github.com/Romanof123/JNOX/pull/22',1),('link','[ticket](https://github.com/Romanof123/JNOX/issues/11)','#22',1),('auto','<https://github.com/Romanof123/JNOX/issues/11>','#22',1),('ipv6','http://[::1]/a #11','#22',1),('afterurl','https://example.org/a #11','#22',1),('inline','`#11`','#22',0),('fence','~~~text\n#11\n~~~','#22',0),('comment','<!-- #11 -->','#22',0),('quote','> #11','#22',0),('foreign','https://example.org/#11','#22',0),('foreignrepo','Elsewhere/JNOX#11','#22',0),('oneway','#11','waiting',0),('otherway','waiting','#22',0),('wrongnum','#110','#22',0),('duplicates','#11 and #11','#22 and #22',1),('paragraph','Tracking\n\n#11','#22',1),('quotethenvalid','> example #87\n\n#11','#22',1),('issuemasked','#11','`#22`',0),('query','https://example.org/?x=#11','#22',0),('multiowner','#11','#22',1),('noowner','#11','#22',1)]
oracle=[]
for name,pr,issue,match in cases:
 def obj(n,b,kind):
  x=dict(number=n,state='open',title='Work item',body=b,labels=[dict(name='team:development')],html_url=f'https://github.com/Romanof123/JNOX/{kind}/{n}')
  if kind=='pull': x['pull_request']={'url':f'https://api.github.com/repos/Romanof123/JNOX/pulls/{n}'}
  return x
 rows=[obj(11,issue,'issues'),obj(22,pr,'pull')]
 if name=='multiowner':rows[0]['labels'].append({'name':'team:pm'})
 if name=='noowner':rows[1]['labels']=[]
 (p/(name+'.json')).write_text(json.dumps(rows),encoding='utf8')
 oracle.append(dict(case=name,exit=0 if match and name not in ('multiowner','noowner') else 1,pairs=[[22,11]] if match else []))
(p/'oracle.json').write_text(json.dumps(oracle,indent=2),encoding='utf8')
m=''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in sorted(p.glob('*.json')))
(p/'SHA256SUMS').write_bytes(m.encode())
print(hashlib.sha256(m.encode()).hexdigest(),len(oracle))
