import json, subprocess, re, hashlib,sys
from pathlib import Path
p=Path('.')
for line in Path('SHA256SUMS').read_text().splitlines():
 h,f=line.split('  ')
 assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h
results=[]
for row in json.loads(Path('oracle.json').read_text()):
 cmd=[sys.executable,'open_tracking.py',row['case']+'.json']
 res=subprocess.run(cmd,capture_output=True)
 out=res.stdout.decode()
 pairs=[[int(pr),int(n)] for pr,part in re.findall(r'^PR #(\d+): reciprocal issues (.*)$',out,re.M) for n in re.findall(r'#(\d+)',part)]
 results.append(dict(case=row['case'],command=cmd,stdout=out,stderr=res.stderr.decode(),exit=res.returncode,pairs=pairs,matched=res.returncode==row['exit'] and pairs==row['pairs']))
Path('results.json').write_text(json.dumps(results,indent=2))
print('matches',sum(r['matched'] for r in results),'of',len(results),[r['case'] for r in results if not r['matched']])
