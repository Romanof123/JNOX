#!/bin/bash
set -eu
base=$HOME/jnox272-typed
outbase=$base/firsts
export CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup
export PATH=$CARGO_HOME/bin:$PATH
export JNOX_BOARD=virt JNOX_PROFILE=multilevel JNOX_APP=mlfq-wake
cd "$base/pinned"
test "$(git rev-parse HEAD)" = 10413a1ae6a34b85caf414444e26b23758b39879
mkdir -p "$outbase"
for frame in unset 1; do
for mode in off disabled active saturate; do
out=$outbase/$frame-$mode
mkdir "$out"
export CARGO_TARGET_DIR=$base/target SCHED_APP_TRACE_CAPTURE_DIR=$out/guest
unset JNOX_SCHED_APP_TRACE JNOX_MULTILEVEL_TRACE
if [ "$frame" = 1 ]; then export JNOX_MULTILEVEL_TRACE=1; fi
if [ "$mode" != off ]; then export JNOX_SCHED_APP_TRACE=$mode; fi
(cd kernel && set -x && cargo +1.95.0 -V && rustc +1.95.0 -Vv && aarch64-linux-gnu-nm --version && cargo +1.95.0 build --locked --release -j1) >"$out/build.log" 2>&1
python3 tools/qemu_boot.py --profile "$JNOX_APP" --qemu tools/sched_app_trace_capture.py --kernel "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" >"$out/boot.log" 2>&1 && boot=0 || boot=$?
python3 tools/sched_app_trace_decode.py seal "$out/guest" --build-log "$out/build.log" --boot-log "$out/boot.log" >"$out/seal.log" 2>&1 && seal=0 || seal=$?
python3 tools/sched_app_trace_decode.py decode "$out/guest" >"$out/decode.log" 2>&1 && decode=0 || decode=$?
echo "$frame $mode $boot $seal $decode" | tee -a "$base/progress"
cp -a "$out" /mnt/d/codex/jnox272-typed-first/
done
done
