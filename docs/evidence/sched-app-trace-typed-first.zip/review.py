from pathlib import Path
import subprocess as sp,zipfile,hashlib,json,shutil,sys
r=Path.home()/'jnox272-typed'
dest=Path('/mnt/d/codex/jnox272-typed-first')
prior=Path.home()/'jnox272-corrected'
for name in ['oracle.py','frames.py','packet.c']:
 s=(prior/name).read_text().replace('jnox272-corrected','jnox272-typed').replace("p.name.split('-')[0][:-1]","p.name.split('-')[1]").replace("pre=q['status'];","assert type(q['cpus'][0]['cpu-index']) is int and q['stop_return']=={}; pre=q['status'];")
 (r/name).write_text(s)
sp.run(['cc','-shared','-O2','-fPIC',r/'packet.c','-o',r/'packet.so'],check=True)
for name in ['oracle.py','frames.py']:
 sp.run([sys.executable,r/name],check=True)
for name in ['oracle.py','oracle.json','frames.py','frames.json','packet.c','progress']:
 shutil.copy2(r/name,dest/name)
src=r/'pinned'
for test in ['test_sched_app_trace_halt','test_sched_app_trace_decode']:
 p=sp.run([sys.executable,'-m','unittest','-v',test],cwd=src/'tools',stdout=sp.PIPE,stderr=sp.STDOUT);(dest/(test+'.log')).write_bytes(p.stdout);assert p.returncode==0
hist=[]
for label,archive in [('valid','jnox272-corrected.zip'),('original','jnox271-first-33d8fbf.zip')]:
 z=zipfile.ZipFile(dest.parent/archive)
 dirs=[n[:-len('manifest.json')] for n in z.namelist() if n.endswith('/guest/manifest.json') and n.startswith('firsts/')]
 if not dirs: print(z.namelist()[:10]);continue
 for d in dirs:
  g=r/'historical'/label/d
  g.mkdir(parents=True,exist_ok=True)
  for n in z.namelist():
   if n.startswith(d) and not n.endswith('/'): (g/Path(n).name).write_bytes(z.read(n))
  q=json.loads((g/'qmp.json').read_text());assert 'stop_return' not in q
  run=json.loads((g/'manifest.json').read_text())['run_uuid'];p=sp.run([sys.executable,src/'tools/sched_app_trace_decode.py','decode',g],capture_output=True,text=True)
  hist.append([label,run,p.returncode,(p.stdout+p.stderr).strip()])
  assert (p.returncode==0)==(label=='valid')
(dest/'historical.json').write_text(json.dumps(hist,indent=2))