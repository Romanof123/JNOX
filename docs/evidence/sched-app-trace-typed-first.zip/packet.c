#include <stdint.h>
uint64_t packet(uint64_t d,uint64_t n){for(unsigned j=0;j<32;j++){d^=((n<<j)|(n>>((64-j)%64)))^j;d*=1099511628211ULL;}return d;}
uint64_t stream(uint64_t n,unsigned id){uint64_t d=id+1;for(uint64_t k=1;k<=n;k++)d=packet(d,k);return d;}
