from pathlib import Path
import json,hashlib,subprocess as sp,shutil,zipfile
r=Path('/mnt/d/codex/jnox272-typed-first'); orig=Path.home()/'jnox271-first'; old=Path.home()/'jnox272-corrected'; d=json.loads((r/'oracle.json').read_text())
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
ids={v['run'] for v in d.values()}; hist=json.loads((r/'historical.json').read_text());assert len(ids|{v[1] for v in hist})==24
shutil.copy(old/'older-helper-boot.log',r/'prior-nontrace-boot.log')
shutil.copy(orig/'progress',r/'prior-joint-progress.txt')
sizes={}
for k,v in d.items():
 g=r/k/'guest'; elf=g/'kernel.elf'; mode=k.split('-')[1]; frame=k.startswith('1')
 other=next((orig/'firsts').glob('*-mlfq-wake-'+mode+'-'+str(int(frame))))/'kernel.elf'
 sizes[k]={}
 for sec in ['.text','.rodata','.data','.bss','.stack']:
  args=['aarch64-linux-gnu-size','-A']
  def size(e):return int(next(x.split()[1] for x in sp.check_output(args+[e],text=True).splitlines() if x.split() and x.split()[0]==sec))
  n=size(elf);assert n==size(other);sizes[k][sec]=n
  if sec in ['.text','.rodata','.data']:
   def hashsec(e):return hashlib.sha256(sp.check_output(['aarch64-linux-gnu-objcopy','-O','binary','-j',sec,e,'/dev/stdout'])).hexdigest()
   a,b=hashsec(elf),hashsec(other); sizes[k][sec+'_sha256']=[a,b]
 q=json.loads((g/'qmp.json').read_text()); assert type(q['stop_return'])==dict and not q['stop_return'] and len(q['cpus'])==1 and type(q['cpus'][0]['cpu-index'])==int
(r/'sections.json').write_text(json.dumps(sizes,indent=2))
lines=['# CPU0 typed QMP independent review / CPU0 QMP 형식 독립 검증','', 'Public source 10413a1ae6a34b85caf414444e26b23758b39879. Eight first cold boots on WSL ext4, Rust 1.95.0 locked release -j1, serial Cortex-A72 single CPU QEMU 6.2 TCG. All eight public boot/seal/decode commands exited 0. Saturating traces explicitly decode incomplete due to loss. The per-run source status lists only Python bytecode cache as untracked. Tracked source matched the pinned commit. The runner, original captures, manifests, logs, raw oracle and per-run section comparisons accompany this report.','', '| Frame / mode | Run UUID | W | Q | S | E | E−W | Timer overlap E−S | Kernel/app loss |','|---|---|---:|---:|---:|---:|---:|---:|---|']
for k,v in d.items():lines.append('| '+' | '.join(map(str,[k,v['run'],v['W'],v.get('Q','—'),v['S'],v['E'],v['wall'],v.get('timer_overlap_final','—'),v.get('loss','—')]))+' |')
lines+=['','All boots had integer CPU index zero, real empty-object stop acknowledgement, then running=false/paused and a terminal controller value of zero. Production code and the instrumented mock peer establish save/command/extraction order. Genuine captures retain the replies; they do not carry a wire-level command transcript. All 32 worker publications reproduced from raw work counts and supplier sequence. Each run met B=23U=14,375,000 ticks (U=625,000) with six timer IRQs and frame/peer/wake checks. oracle.json contains each digest, lateness, gaps, service durations and joins. Frame restoration in full mode also matched the interrupt transcript. OFF symbol absent, disabled commits and losses zero. Both saturation records retained their first four events and lost exactly 22 kernel and one application event. Missing Q in those rows is withheld.','', 'Ten host Python tests and three Rust producer tests passed. Historical manifests replayed on copies using the pinned decoder: all eight 0174fe3 old-format successes passed and all eight original 33d8fbf receipts failed with missing halted.json. All 24 UUIDs are distinct. The raw oracle is adapted from the prior independent witness parser, with new inputs, typed assertions and unchanged packet reconstruction.','', 'Historical joint controls are retained as earlier observations. Git comparisons from 33d8fbf through 10413a1 found identical arch, boards, kernel, sdk, examples, tools/qemu_boot.py and tools/mlfq_wake_capture.py. The 0174fe3→10413a1 shared capture helper change is confined to capture_halt; the earlier nontrace client bypasses that function by its ordinary default. Prior nontrace boot log and fresh host legacy path test retained. sections.json compares fresh/first-joint section sizes and both byte hashes for loadable code/data. Stack allocation is static. Dynamic stack high-water, IRQ mask duration and WCET were unmeasured. The nested IRQ control is a host model.','', '공개 소스의 WSL ext4 독립 최초 부팅 8건 모두 부팅·봉인·복호화 명령에 성공했다. 각 실행에서 단일 정수 CPU0, 빈 객체 stop 응답, 정지 상태를 확인했다. 모의 QMP와 소스로 응답 저장·정지 확인·메모리 읽기 순서를 검증했다. 원본 워크 카운트로 결과 32개와 공급 순서를 재계산했고 8건 모두 23U 이내였다. 활성 모드의 타이머 중첩과 포화 모드의 손실(커널 22, 응용 1)은 표에 표시했다. 정상 구형 기록 8건은 통과했고 정지 응답이 없는 최초 8건은 다시 거부됐다. 과거 공동 대조군은 입력 동일성을 확인해 유지했다. 스택 최대 사용량, 인터럽트 차단 시간, 최악 실행 시간은 실측하지 않았다.']
(r/'report.en-ko.md').write_text('\n'.join(lines)+'\n')
zpath=r.parent/'jnox272-typed-first.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(r.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(r))
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
print(zpath,zpath.stat().st_size,sha(zpath))