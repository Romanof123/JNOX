from pathlib import Path
import os,subprocess,tempfile,shutil,json
root=Path(__file__).resolve().parent
tools=root.parent/'reservations-runtime-final/tools'
assert (root/'raw/cbs-wake-bench/plain/meta.json').exists()
for name,profile in [('cbs-bench','cbs'),('cbs-wake-bench','cbs-wake')]:
    d=Path(tempfile.mkdtemp(prefix='jnox-legacy-')); elf=d/'kernel.elf'; shutil.copy2(root/'raw'/name/'plain/kernel.elf',elf)
    wrap=d/'qemu-int'
    wrap.write_text('#!/bin/sh\nexec qemu-system-aarch64 -d int -D "'+str(d/'int.log')+'" "$@"\n')
    wrap.chmod(0o755)
    env=dict(os.environ,CBS_WAKE_CAPTURE_DIR=str(d/'capture'),PYTHONDONTWRITEBYTECODE='1')
    args=['python3',str(tools/'qemu_boot.py'),'--profile',profile,'--timeout','15','--qemu',str(wrap if profile=='cbs' else tools/'cbs_wake_capture.py'),'--kernel',str(elf)]
    with (d/'launcher.log').open('wb') as f: rc=subprocess.run(args,cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
    (d/'meta.json').write_text(json.dumps(dict(rc=rc,argv=args),indent=2)); shutil.copytree(d,root/'legacy'/name)
