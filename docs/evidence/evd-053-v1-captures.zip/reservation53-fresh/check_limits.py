from verify import root,analyze
import json
def eligible(start,cutoff,end,first,stop,u,total,S,Q,ms):
    return start<=first<=start+ms and stop<=cutoff+ms and stop<=end and u<=S and total<=Q*S
args=[100,199,200,101,200,100,200,100,2,1]
assert eligible(*args)
for index in [3,4,5,6]:
    bad=args.copy(); bad[index]+=1
    assert not eligible(*bad)
results=json.loads((root/'observations.json').read_text())
for label,data in results.items():
    if not data['grants']: continue
    g=data['grants'][0]; start=g['open']; S=g['slot_limit']; ms=g['dispatch_limit']; Q=g['allocation_limit']//S
    assert not eligible(start,start+S-ms,start+S,start+g['worker_offset'],g['stop'],g['upper'],g['allocation_upper'],S,Q,ms)
    assert data['status'][:2]==[2,2] and data['status'][2:]==[start+g['worker_offset'],start]
    if 'late' in label:
        assert data['overrun']['fixture_valid'] and data['overrun']['excess']>0 and g['upper']>S and g['allocation_upper']>Q*S
    else:
        assert g['pre_eret_offset']>ms and g['stop']<=start+S and g['upper']<=S and g['allocation_upper']<=Q*S
print('12/12 case checks; inclusive threshold and one-tick-over controls passed')
