from verify import root,oracle
import struct,re,json,subprocess
def events(path):
    rx=r'Exception return .*? PC (0x[\da-f]+)|Taking exception \d+ \[(IRQ|SVC)\]\n.*?with ESR [^/]+/(0x[\da-f]+)\n.*?with ELR (0x[\da-f]+)'
    return [(exc or 'ERET',int(ret or elr,16)) for ret,exc,esr,elr in re.findall(rx,path.read_text(),re.S)]
def syms(path):
    return {n:(int(s,16),int(l,16)) for s,l,n in re.findall(r'^([\da-f]+) ([\da-f]+) [Tt] (\S+)',subprocess.check_output(['aarch64-linux-gnu-nm','-nS',str(path)],text=True),re.M)}
result={}
for name in ['cbs-bench','cbs-wake-bench']:
    d=root/'legacy'/name
    assert json.loads((d/'meta.json').read_text())['rc']==0
    data=(root/'raw'/name/'plain/uart').read_text().splitlines()
    assert data==['JNOX M1 BOOT','JNOX M1 READY']+(['CBS A FIRST','CBS B FIRST','CBS IDLE','CBS A RESUMED','CBS B RESUMED','CBS TIMER STOP','CBS PASS'] if name=='cbs-bench' else ['CBS WAKE TIMER STOP','CBS WAKE PASS'])
    if name=='cbs-bench':
        ev=events(d/'int.log')
        owners=['cbs_a','cbs_b','cbs_idle','cbs_a','cbs_b']
        sy=syms(d/'kernel.elf')
        assert len(ev)==10
        for k,n in enumerate(owners):
            start,size=sy[n]
            ret,irq=ev[2*k:2*k+2]
            assert ret[0]=='ERET' and irq[0]=='IRQ' and all(start<=pc<start+size for kind,pc in (ret,irq))
            if k>=3: assert ret[1]==ev[2*(k-3)+1][1]
        result[name]=dict(owners=owners,events=ev)
    else:
        rows=list(struct.iter_unpack('<24Q',(d/'capture/audit.bin').read_bytes()))
        assert len(rows)==34
        ev=events(d/'capture/int.trace'); expected=[]
        for i,(row,slot) in enumerate(zip(rows,oracle('cbs-wake'))):
            assert row[0]==i and row[6]==slot['owner'] and row[13]<=row[16]<row[13]+row[12]
            expected.append(('ERET',row[14]))
            if row[20]:
                expected.extend([('SVC',row[21]),('ERET',None)])
            expected.append(('IRQ',row[18]))
        assert len(ev)==len(expected) and all(t==u and (q is None or p==q) for (t,p),(u,q) in zip(ev,expected))
        result[name]=dict(owners=[r[6] for r in rows],blocks=[r[0] for r in rows if r[20]],events=ev)
(root/'legacy-checks.json').write_text(json.dumps(result,indent=2))
