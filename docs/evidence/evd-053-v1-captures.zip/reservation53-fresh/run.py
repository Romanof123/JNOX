import hashlib,json,subprocess,tempfile,shutil
from pathlib import Path
root=Path(__file__).resolve().parent
build=root.parent/'reservations53-builds'
index=build/'index.json'
assert hashlib.sha256(index.read_bytes()).hexdigest()=='22de1966a3def8bb661187786b70349150ad6a6980dc73b73a3eac684910d2d6'
j=json.loads(index.read_text())
order=['aligned-wake/plain','cbs-wake/trace','aligned-saturated/trace','cbs-saturated/plain','aligned-wake/trace','cbs-wake/plain','aligned-saturated/plain','cbs-saturated/trace','aligned-refused/plain','cbs-refused/plain','aligned-late/plain','cbs-late/plain','cbs-bench/plain','cbs-wake-bench/plain']
(root/'order.json').write_text(json.dumps(order))
for label in order:
    app,arm=label.split('/')
    d=Path(tempfile.mkdtemp(prefix='jnox-reservation-'))
    elf=d/'kernel.elf'
    shutil.copy2(build/app/'kernel.elf',elf)
    sha=hashlib.sha256(elf.read_bytes()).hexdigest()
    if app in j['images']: assert sha==j['images'][app]['sha256']
    q=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','stdio','-kernel',str(elf)]
    if arm=='trace': q+=['-d','int','-D',str(d/'exceptions.log')]
    with (d/'uart').open('wb') as out,(d/'stderr').open('wb') as err:
        rc=subprocess.run(['timeout','15s',*q],stdout=out,stderr=err,cwd=d).returncode
    (d/'meta.json').write_text(json.dumps(dict(argv=q,status=rc,sha256=sha,path=str(d),rust=j['rustc'],cargo=j['cargo'],qemu=subprocess.check_output([q[0],'--version'],text=True)),indent=2))
    shutil.copytree(d,root/'raw'/label)
    print(label,rc,flush=True)
