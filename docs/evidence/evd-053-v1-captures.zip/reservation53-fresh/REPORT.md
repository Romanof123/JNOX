# Independent first-cold POL-008 review

Frozen source c2efde463ee48ef7754a56c52e7dd63552b53b5b. The complete reservation profile fails this default-clock virtual-machine gate. No normal first boot progressed past the first A grant. All 12 predeclared reservation attempts and two legacy plain regressions were launched sequentially from individual native Linux /tmp directories. The two additional legacy captures used the documented launchers. order.json and run.py give the frozen order and 15-second host timeout. Raw ELF, UART, stderr, argv, version and timeout status accompany each attempt. Host timeout 124 follows terminal guest output. SHA256SUMS covers retained files.

## Measured ordinary frames

All values below are architectural counter ticks at 62.5 MHz. The 1 ms limit is 62,500 ticks, each slot is 3,125,000. Pre-ERET and first generation marker are offsets from slot opening. Cutoff delta is the vector sample minus the programmed cutoff. Tail is nominal end minus the vector sample. Positive cutoff delta belongs to outgoing A’s conservative service bound. Positive tail after short A SVC is unused slot capacity. Terminal failure prevents any observed idle redispatch in these attempts.

| Application and arm | Boundary IRQ delay | Pre-ERET | First marker | Updates | Upper service | Cutoff delta | Tail | Status/reason |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| aligned-late/plain | 15374 | 63892 | 67200 | 9227056 | 3186871 | 188263 | -125763 | 2/2 |
| aligned-saturated/plain | 18707 | 74213 | 78061 | 18224080 | 2994943 | 6656 | 55844 | 2/2 |
| aligned-saturated/trace | 23730 | 76601 | 79245 | 17498288 | 2995236 | 9337 | 53163 | 2/2 |
| aligned-wake/plain | 24424 | 85584 | 88118 | 256 | 9642 | -2967274 | 3029774 | 2/2 |
| aligned-wake/trace | 26697 | 78801 | 81594 | 256 | 10191 | -2973508 | 3036008 | 2/2 |
| cbs-late/plain | 14420 | 68335 | 70717 | 9244688 | 3182422 | 188257 | -125757 | 2/2 |
| cbs-saturated/plain | 19631 | 69479 | 71909 | 16564816 | 3003771 | 10750 | 51750 | 2/2 |
| cbs-saturated/trace | 23214 | 70126 | 72704 | 17055248 | 3004108 | 11734 | 50766 | 2/2 |
| cbs-wake/plain | 17008 | 80290 | 83809 | 256 | 11409 | -2970801 | 3033301 | 2/2 |
| cbs-wake/trace | 19371 | 77638 | 81137 | 256 | 10683 | -2974179 | 3036679 | 2/2 |

Each row 8 checksum independently matches the wrapping affine recurrence from A’s private seed, with positive committed chunks of 16. Each W block completed exactly 256 updates. The saved PC maps to the linked work body, the frame and stack local lie in A’s range, and TPIDR matches the seed. All eight normal pre-ERET samples already exceed the opening bound. Recorded first IRQ entry and post-entry time to dispatch are separately available. Data locate the delay on that path but cannot distinguish TCG translation, host scheduling, guest instruction costs and other causes. On S, the cutoff vector arrives after the programmed cutoff and before nominal end. The outgoing upper bound includes the post-cutoff ticks and restore/entry uncertainty. The upper bound and allocation charge coincide for the only observed grant. EL1 idle, setup and validation outside that interval are not client work. Executed arithmetic cycles and a physical-board stop instant cannot be isolated.

Independent external order in each W trace is idle ERET, opening IRQ, A ERET, SVC #1. In S it is idle ERET, opening IRQ, A ERET, cutoff IRQ. Every traced return PC matches the corresponding pre-ERET plan, and the interrupted worker PC matches the saved PC. observations.json contains the per-run addresses, symbols, elapsed bounds, checksums and timing deltas. Plain arms have only guest samples.

## Expected schedule and missing observations

- aligned-wake expected owners in slot order: A B I I A B I I A B I I I A B I I B I I I B A A A B A I I B I I A B.
- cbs-wake expected owners in slot order: A B I I A B I I A B I I I B A I I B I I I B A A I B I I I B A A I B.
- aligned-saturated expected owners in slot order: A B A B A B A B I I.
- cbs-saturated expected owners in slot order: A B A B A B A B I I.

expected.json expands every slot into each owner’s q/d before and after debit, releases, demand, eligibility state and action. verify.py matches every emitted allocation/demand row to this independent model. For W, five blocks and five post-SVC resumes were required. Each run shows one block, no resumed A, no B grant and no later opportunity or tail executed by idle. No W late wake rule is demonstrated. For S, B has four pending units in slot zero. Failure precedes B’s slot-one opportunity. Neither fourth-unit exit nor exited-frame isolation, B progress, ten-slot horizon or the final snapshots was reached. No full-load or neighbor guarantee is established.

## Refusal and diagnostic fixtures

Both refused guests report 9/8 over capacity before building any frame or arming a timer. The four invalid/overflow cases report the frozen reasons and zero frames/arms, with no selection, service or return rows. Exact rational 1/2+1/2=1 and 1+1/8=9/8 confirm the boundary and refusal independently.

aligned-late/plain {"mask_begin": 6172941, "cutoff": 6233863, "end": 6296363, "edge": 6296365, "edge_count": 8875168, "unmask": 6421979, "end_count": 9227056, "stop": 6422126, "excess": 125763, "lost_owner": 1, "fixture_valid": true}. First terminal status/reason [2, 2].
cbs-late/plain {"mask_begin": 6154176, "cutoff": 6214896, "end": 6277396, "edge": 6277397, "edge_count": 8892528, "unmask": 6402975, "end_count": 9244688, "stop": 6403153, "excess": 125757, "lost_owner": 1, "fixture_valid": true}. First terminal status/reason [2, 2].

Both diagnostic runs must show mask before cutoff, increasing committed updates from the end crossing through pre-unmask, unmask at least 2 ms after nominal end, actual trap/stop and B’s lost opportunity. The table and observations.json record observed excess, including diagnostic-hook and exception costs. A slot-zero timing failure preceding the intended overrun decision prevents credit for that fail-stop branch even when actual excess and lack of redispatch are visible. There is no independent exception trace in these diagnostic arms.

## Legacy cold regressions

Both plain boots produced exact expected UART. Both documented launchers passed quiet-window host stop with exit 0. The independent basic CBS capture yielded ten ordered ERET/IRQ events for A, B, idle, A, B, with both resumed PCs equal to their saved IRQ PC. The CBS-wake capture yielded 34 journal entries and 78 corroborating external events. A blocked at 0, 4, 8, 14, 22. B received all nine specified opportunities. All 34 timer entries occurred within their one-slot legacy bound. inspect legacy-checks.json and legacy/ for raw QMP, UART, trace and kernel evidence.

Independent controls in check_limits.py accept exact limits and reject one tick beyond first-marker, cutoff/end, slot and allocation limits. These arithmetic controls do not establish ordinary guest timing.
