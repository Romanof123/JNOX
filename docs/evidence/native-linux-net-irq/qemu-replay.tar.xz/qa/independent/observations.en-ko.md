# Independent IRQ evidence / 독립 IRQ 검증

| Boot | NIC IRQs | Software-pending IRQs | Blocked wakes | skb_recv_done | virtnet_poll | GRO |
|---|---:|---:|---:|---:|---:|---:|
| capture-a | 19 | 0 | 10 | 10 | 20 | 81 |
| capture-b | 14 | 0 | 10 | 10 | 20 | 81 |
| directed-final | 14 | 1 | 11 | 11 | 21 | 81 |

Each QEMU AArch64 boot showed a blocked receiver with an empty RX ring while its peer completed three timed waits. Every device IRQ had a virtio assertion, GIC input 79, full IAR token 79, NIC status 1, ACK 1 and matching full EOIR. The linked Linux callback and poll entry instructions matched their captured objects outside relocation sites and executed in the trace. Each host socket stream agreed with Ethernet PCAP and peer RAM for 80 sequenced frames and the final ACK. Driver and peer had distinct translation roots.

Only the directed boot exposed both ends of the callback rearm interval. Its raw used index advanced from 1 to 2 while the saved poll snapshot stayed at 1 and the pending test returned true. Its separate distributor software-pending write produced an IAR and EOI of 79 with zero NIC status, no NIC ACK, zero RX progress and zero waiter wakes at the ready checkpoint. Ordinary runs establish normal hardware delivery and do not measure the directed interval. These observations cover the three recorded QEMU boots.

세 부팅 모두 빈 RX 링에서 수신자가 대기하는 동안 별도 피어가 타이머 대기 세 번을 마쳤다. 장치 IRQ마다 virtio 신호와 GIC 입력 79, IAR 79, NIC 상태 및 ACK 1, 동일한 전체 EOI 값을 확인했다. 원본 콜백과 폴 함수의 실행 기록을 링크된 ELF 명령어와 대조했다. 호스트가 보낸 순번 프레임 80개와 마지막 ACK는 소켓 기록, PCAP, 별도 페이지 테이블의 피어 메모리에서 바이트 단위로 일치했다.

지정 재현 부팅에서만 콜백 재활성화 전후의 상태를 직접 관찰했다. 저장된 스냅샷은 1을 유지했고 used 인덱스는 1에서 2로 증가했으며 pending 검사 결과는 참이었다. 별도로 소프트웨어가 pending 비트를 설정했을 때 NIC 상태는 0이었고 장치 ACK, 수신 진행, 대기자 깨우기는 없었다. 표의 횟수는 각 QEMU 부팅의 관측값이다.

Replay one archived boot with Python 3 from the package root using, for example, `python3 independent/read_irq.py ordinary ordinary/capture-a`. The three JSON files include ELF and raw-input hashes, per-epoch trace line numbers, ring snapshots and timer readings.
