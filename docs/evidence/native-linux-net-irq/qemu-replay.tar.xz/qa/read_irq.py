"""Independent offline reader for native RX IRQ evidence. Python 3 stdlib."""
import hashlib
import json
import re
import struct
import sys
from collections import Counter
from pathlib import Path


def check(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def cstring(data, offset):
    return data[offset:data.index(0, offset)].decode()


class ELF:
    def __init__(self, path):
        self.data = path.read_bytes()
        d = self.data
        check(d[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<H', d, 18)[0] == 183, str(path))
        off = struct.unpack_from('<Q', d, 40)[0]
        size, count, names = struct.unpack_from('<HHH', d, 58)
        self.headers = [struct.unpack_from('<IIQQQQIIQQ', d, off + i * size) for i in range(count)]
        strings = self.section(names)
        self.names = [cstring(strings, h[0]) for h in self.headers]
        self.symbols = {}
        for i, h in enumerate(self.headers):
            if h[1] == 2:
                strings = self.section(h[6])
                for name, _, _, idx, value, length in struct.iter_unpack('<IBBHQQ', self.section(i)):
                    if idx and idx < count and name:
                        self.symbols[cstring(strings, name)] = (idx, value, length)

    def section(self, idx):
        h = self.headers[idx]
        return self.data[h[4]:h[4]+h[5]]

    def code(self, name):
        idx, addr, size = self.symbols[name]
        start = addr - self.headers[idx][3]
        return self.section(idx)[start:start+size]

    def relocations(self, name):
        idx = self.symbols[name][0]
        return {off for i,h in enumerate(self.headers) if h[1] == 4 and h[7] == idx
                for off, _, _ in struct.iter_unpack('<QQq', self.section(i))}


def unpack_stream(data, wire):
    pos = 24 if wire else 0
    if wire:
        check(data[:4] == bytes.fromhex('d4c3b2a1') and struct.unpack_from('<I',data,20)[0] == 1,'pcap Ethernet')
    records = []
    while pos < len(data):
        if wire:
            _, _, n, original = struct.unpack_from('<4I', data, pos)
            check(n == original, 'truncated pcap frame')
            pos += 16
        else:
            n = struct.unpack_from('>I', data, pos)[0]
            pos += 4
        check(0 < n <= len(data)-pos, 'incomplete frame')
        records.append(data[pos:pos+n])
        pos += n
    return records


class Ram:
    def __init__(self, path):
        self.blocks = {}
        for key, value in json.loads(path.read_text()).items():
            address, size = key.split('/')
            block = bytes.fromhex(value)
            check(len(block) == int(size), key)
            self.blocks[int(address,16),len(block)] = block

    def read(self, address, size):
        for (base,n), block in self.blocks.items():
            if base <= address and address + size <= base + n:
                return block[address-base:address-base+size]
        raise KeyError((hex(address),size))

    def phys(self, root, va):
        table = root
        for shift in (30,21,12):
            entry = struct.unpack('<Q',self.read(table+8*((va>>shift)&511),8))[0]
            check(entry & 3 == 3, 'missing page descriptor')
            table = entry & 0xfffffffff000
        return table + (va & 4095)

    def virt(self, root, va, n):
        chunks = []
        while n:
            step = min(n,4096-(va & 4095))
            chunks.append(self.read(self.phys(root,va),step))
            va += step
            n -= step
        return b''.join(chunks)

    def address_space(self, va, signature):
        matches = []
        for base in {b & ~4095 for b,n in self.blocks}:
            if base:
                try:
                    if self.virt(base,va,len(signature)) == signature:
                        matches.append(base)
                except (ValueError, KeyError):
                    pass
        check(len(matches)==1, 'unique task root')
        return matches[0]


def analyze(build, cap):
    kernel, driver, peer = [ELF(build/'native'/name) for name in ('kernel.elf','user.elf','native_peer.elf')]
    obj = ELF(build/'imported/virtio_net.callback.o')
    packet = ELF(build/'imported/virtio_net.packet.o')
    uart = (cap/'uart.log').read_text()
    launch = json.loads((cap/'launch.json').read_bytes())
    for elf, key in [(kernel,'kernel_sha256'),(driver,'driver_sha256')]:
        check(sha(elf.data)==launch['identities'][key],key)
    for slot, elf, label in [(0,driver,'ELF'),(1,peer,'PEER ELF')]:
        check('NATIVE EL0 '+label+' '+sha(elf.data) in uart and
              f'NATIVE EL0 EXIT PID {slot} 0' in uart, 'boot identities/exit')
    addresses = {name:driver.symbols[name][1] for name in
                 ('skb_recv_done','virtnet_poll','gro_receive_skb','virtqueue_enable_cb_prepare')}
    for name in ('skb_recv_done','virtnet_poll'):
        raw = obj.code(name)
        check(raw == packet.code(name) and len(raw)==len(driver.code(name)), name+' original instructions')
        linked = driver.code(name)
        reloc = obj.relocations(name)
        check(all(raw[i:i+4]==linked[i:i+4] for i in range(0,len(raw),4) if i not in reloc),name+' linked code')
    reverse = {address:name for name,address in addresses.items()}
    for pc in reverse:
        check(not any(h[2]&4 and h[3]<=pc<h[3]+h[5] for h in peer.headers), 'address aliases peer')
    events, hits, opcodes, rings = [], Counter(), set(), {}
    active = None
    selected = 0
    gic_pending = 0
    first_entries = {}
    input_lines=[]
    pending_writes=[]
    for_device=0
    for line_no,line in enumerate((cap/'machine.log').open(errors='replace'),1):
        if 'virtio_mmio_setting_irq virtio_mmio setting IRQ 1' in line:
            for_device=line_no
        if 'gic_set_irq irq 79 level 1' in line:
            check(for_device==line_no-1,'IRQ assertion from NIC')
            input_lines.append(line_no)
        if 'memory_region_ops_write' in line and 'addr 0x8000208 value 0x8000 size 4' in line:
            pending_writes.append(line_no)
        if 'gic_acknowledge_irq' in line and line.rstrip().endswith('acknowledged irq 79'):
            gic_pending += 1
        m = re.search(r'gic_cpu_read cpu 0 iface read at 0x0000000c: (0x\w+)',line)
        if m:
            token = int(m[1],16)
            check(active is None,'nested IAR')
            if token & 1023 == 79:
                check(gic_pending==1,'missing controller acknowledgement')
                gic_pending=0
                active=[token,[],[],line_no]
        m = re.search(r'gic_cpu_write cpu 0 iface write at 0x00000010 (0x\w+)',line)
        if m and active:
            token,status,ack,start = active
            check(int(m[1],16)==token and len(status)==1 and status[0] in (0,1,2,3)
                  and ack==([status[0]] if status[0] else []),'IAR/status/ACK/EOI')
            events.append((start,line_no,token,status[0]))
            active=None
        m = re.search(r'memory_region_ops_(read|write).*?addr (0x\w+) value (0x\w+) size (\d+)',line)
        if m:
            addr,val,size=int(m[2],16),int(m[3],16),int(m[4])
            if active and addr in (0xa003e60,0xa003e64):
                idx=1 if addr==0xa003e60 else 2
                check(size==4 and m[1]==('read' if idx==1 else 'write'),'NIC transaction width/direction')
                active[idx].append(val)
            if m[1]=='write' and 0xa003e00<=addr<0xa004000:
                off=addr-0xa003e00
                if off==0x30:
                    selected=val
                elif off in (0x90,0x94,0xa0,0xa4):
                    rings.setdefault(selected,{})[off]=val
        m=re.match(r'Trace \d+: .*?\[[^/]+/([0-9a-f]+)/',line)
        if m and int(m[1],16) in reverse:
            name=reverse[int(m[1],16)]
            hits[name]+=1
            first_entries.setdefault(name,line_no)
        m=re.match(r'0x([0-9a-f]+):\s+([0-9a-f]{8})\b',line)
        if m and int(m[1],16) in reverse:
            name=reverse[int(m[1],16)]
            check(int(m[2],16)==int.from_bytes(driver.code(name)[:4],'little'),name+' opcode')
            opcodes.add(name)
    check(events and active is None and not gic_pending and any(e[3]&1 for e in events),'hardware IRQ epochs')
    previous=0
    for start,end,token,status in events:
        check(any(previous < pos < start for pos in input_lines)==bool(status) and
              any(previous < pos < start for pos in pending_writes)==(status==0),'IRQ source')
        previous=start
    check(set(hits)==set(addresses)==opcodes and hits['gro_receive_skb']==81,'executed entry points')
    wire=unpack_stream((cap/'wire.pcap').read_bytes(),True)
    check(wire==unpack_stream((cap/'host-to-guest.bin').read_bytes(),False) and len(wire)==81 and
          not (cap/'guest-to-host.bin').read_bytes(),'wire direction')
    nonce=(cap/'nonce.bin').read_bytes()
    for i,f in enumerate(wire):
        check(f[22:30]==nonce and f[12:14]==bytes.fromhex('88b5'),'frame identity')
        if i<80:
            check(f[14:22]==b'JNOXRECV' and int.from_bytes(f[30:34],'big')==i and len(f)==60+i%32 and
                  f[34:]==bytes(i+j for j in range(34,len(f))),'data sequence/payload')
        else:
            check(f[14:22]==b'JNOXACK!' and len(f)==60,'final ACK')
    phases={}
    directed='jnox_irq_race_gate' in driver.symbols
    for phase in ['ready','active','final']+(['race-1','race-3'] if directed else []):
        folder=cap/phase
        q=json.loads((folder/'qmp.json').read_bytes())
        h=json.loads((folder/'halted.json').read_bytes())
        check(q['status']['running'] and [cpu['cpu-index'] for cpu in q['cpus']]==[0] and
              q['stop_return']=={} and h['status']=='paused' and not h['running'],'QMP stop '+phase)
        ram=Ram(folder/'ram.json')
        def words(addr,n):
            return struct.unpack('<'+'Q'*n,ram.read(addr,n*8))
        k=words(kernel.symbols['jnox_linux_net_irq_metrics'][1],32)
        if not phase.startswith('race'):
            pr=ram.address_space(peer.symbols['jnox_rx_peer_result'][1],struct.pack('<Q',0x4a4e525850454531))
        def virtual(elf,root,name,n):
            return struct.unpack('<'+'Q'*n,ram.virt(root,elf.symbols[name][1],8*n))
        timer=None if phase.startswith('race') else virtual(peer,pr,'jnox_rx_irq_peer',16)
        indices=[]
        for lo in (0x90,0xa0):
            address=rings[0][lo]|rings[0][lo+4]<<32
            indices.append(struct.unpack('<H',ram.read(address+2,2))[0])
        phases[phase]=dict(peer_timer=timer,metrics=k,rx_ring_indices=indices,peer_root=None if phase.startswith('race') else hex(pr))
        if phase=='ready':
            check(k[6]>0 and k[22]==1 and not k[7] and not k[2] and indices[1]==0,'wait before RX')
            check(timer[8]==3 and all(timer[4+i]>=timer[4]+i*10_000_000 for i in (1,2,3)), 'timer peer')
        if phase=='final':
            dr=ram.address_space(driver.symbols['jnox_rx_poll_receipt'][1],struct.pack('<Q',addresses['virtnet_poll']))
            check(dr!=pr,'distinct address spaces')
            for i,f in enumerate(wire):
                va=peer.symbols['jnox_rx_peer_frames'][1]+91*i if i<80 else peer.symbols['jnox_rx_peer_ack'][1]
                check(ram.virt(pr,va,len(f))==f,'peer byte identity')
            poll=virtual(driver,dr,'jnox_rx_poll_receipt',8)
            check(poll[2]==hits['virtnet_poll'] and poll[3]==poll[5]==81,'NAPI consumed completions')
            check(k[7]>0 and k[0]==k[14]==len(events) and k[11]==k[15]==events[-1][2],'wakes and full EOI')
            phases[phase].update(driver_root=hex(dr),poll=poll)
        if phase.startswith('race'):
            va=driver.symbols['jnox_irq_race_gate'][1]
            dr=ram.address_space(va,struct.pack('<Q',0x4952515241434531))
            phases[phase]['gate']=virtual(driver,dr,'jnox_irq_race_gate',16)
    if directed:
        before,after=phases['race-1'],phases['race-3']
        gate=after['gate']
        check(before['gate'][1]==1 and gate[1]==3 and before['rx_ring_indices'][1]==1 and
              after['rx_ring_indices'][1]==2 and gate[3]==gate[8]==1 and gate[9]==1 and gate[4]==1 and
              gate[6]==2 and gate[2]==gate[13],'rearm window')
        check(events[0][3]==0 and phases['ready']['metrics'][5]==1 and
              phases['ready']['metrics'][27]==1,'software-pended zero-status IRQ')
    return dict(profile='directed' if directed else 'ordinary',nonce=nonce.hex(),events=events,
                physical_assertions=input_lines,pending_writes=pending_writes,entry_counts=hits,first_entries=first_entries,phases=phases,
                hashes={str(p.relative_to(cap)):sha(p.read_bytes()) for p in
                        [cap/n for n in ('machine.log','uart.log','launch.json','wire.pcap','nonce.bin',
                                         'host-to-guest.bin','guest-to-host.bin')]+
                        [cap/phase/n for phase in phases for n in ('qmp.json','halted.json','ram.json')]},
                elf_sha256=[sha(e.data) for e in (kernel,driver,peer)])


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('build',type=Path)
    parser.add_argument('capture',type=Path)
    args=parser.parse_args()
    print(json.dumps(analyze(args.build,args.capture),indent=2))
