#!/usr/bin/env python3
"""Replay the packaged native NIC IRQ evidence on Linux without booting a guest."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


COMMON_CONTROLS = {
    "running CPU at burst", "wire.pcap", "host-to-guest.bin", "registered NAPI pointer", "no budget exhaustion",
    "skb build", "removed executed virtnet_poll", "removed executed gro_receive_skb", "removed executed skb_recv_done",
    "missing committed scheduler block", "missing target readback", "removed transport assertion only",
    "wrong full EOIR token",
}


def main():
    root = Path(__file__).resolve().parent
    for line in (root / "SHA256SUMS").read_text().splitlines():
        digest, name = line.split("  ", 1)
        with (root / name).open("rb") as stream:
            h = hashlib.sha256()
            for block in iter(lambda: stream.read(1 << 20), b""):
                h.update(block)
        if h.hexdigest() != digest:
            sys.exit(f"checksum mismatch: {name}")
    summary = json.loads((root / "result.json").read_bytes())
    env = dict(os.environ, PYTHONPATH=os.pathsep.join(str(root / part) for part in ("vendor", "tools")),
               PYTHONDONTWRITEBYTECODE="1", LC_ALL="C")
    env.pop("PYTHONOPTIMIZE", None)
    for item in summary["captures"]:
        command = item["replay_argv"]
        computed = json.loads(subprocess.check_output([sys.executable, *command[1:]], cwd=root, env=env))
        rejected = computed.pop("rejected_mutations")
        expected = COMMON_CONTROLS | ({"removed only software-pending write"} if item["profile"] == "race" else set())
        if len(rejected) != len(set(rejected)) or set(rejected) != expected:
            sys.exit(f"{item['path']}: incomplete mutation controls")
        recorded = json.loads((root / item["path"] / "result.json").read_bytes())
        if computed != recorded:
            sys.exit(f"{item['path']}: replay differs from retained result")
        print(f"PASS {item['path']}: retained IRQ result reproduced, {len(rejected)} mutations rejected", flush=True)
        reader = item["independent_replay_argv"]
        separate = json.loads(subprocess.check_output([sys.executable, *reader[1:]], cwd=root, env=env))
        reference = item.get("independent_report")
        if reference and separate != json.loads((root / reference).read_bytes()):
            sys.exit(f"{item['path']}: independent report differs from retained output")
        if separate["nonce"] != item["nonce"] or separate["hashes"]["wire.pcap"] != item["pcap_sha256"]:
            sys.exit(f"{item['path']}: independent reader used different raw input")
        print(f"PASS {item['path']}: independent reader" + (" matched retained report" if reference else ""), flush=True)


if __name__ == "__main__":
    main()
