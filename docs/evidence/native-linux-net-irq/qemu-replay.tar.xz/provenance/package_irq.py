#!/usr/bin/env python3
"""Package existing #434 ordinary and directed rearm IRQ evidence for offline replay."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tarfile
import tempfile


PM = Path(__file__).resolve().parent
LAB = Path.home() / "jnox406-lab"
VERIFIER = "tools/verify_linux_source_net_irq.py"
TOOLS = ("verify_linux_source_net_irq", "verify_linux_source_net_rx_poll", "verify_linux_source_net_rx",
         "verify_linux_source_net_packets", "verify_linux_source_net_queues", "verify_linux_source_net",
         "verify_linux_source_rtc", "native_el0_replay", "native_amc_roots", "ordinary_amc_replay",
         "ordinary_amc_capture", "qemu_capture")
BOARD = Path("docs/evidence/native-linux-net-irq-board")
RAW = ("wire.pcap", "host-to-guest.bin", "guest-to-host.bin", "nonce.bin", "machine.log", "uart.log",
       "launch.json", "result.json", "burst.json", "net.events", "stderr.log")
GENERATED = ("jnox_rx_original_prefix.h", "jnox_rx_fault_select.inc", "jnox_virtnet_layout.h")
EXTRA_SOURCE = ("kernel", "arch/aarch64", "boards", "examples/linux-source-net-rx",
                "drivers/linux-compat/profiles/virtio-net.json", "drivers/linux-compat/packet/rx_poll_unsupported.S",
                "tools/build_linux_source_virtio_net.py", "tools/build_native_el0.py", "tools/build_kernel.py",
                "tools/import_linux_driver.py", "tools/linux_driver_el0_audit.py", "tools/linux_driver_relocations.py",
                "tools/linux_driver_tx_layout.py", "tools/prepare_linux_virtio_net_headers.py")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def copy(src, dest, digest=None, *, source_root=None):
    require(not src.is_symlink() and src.resolve().is_relative_to((source_root or src.parent).resolve()),
            f"external or linked input: {src}")
    require(src.is_file(), f"missing evidence input: {src}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        require(sha(src) == sha(dest), f"conflicting copies of {dest}")
    else:
        shutil.copyfile(src, dest)
    if digest is not None:
        require(sha(dest) == digest, f"SHA-256 mismatch: {src}")


def git(repo, *args):
    return subprocess.check_output(["git", "-c", f"safe.directory={repo.resolve().as_posix()}",
                                    "-C", str(repo), *args])


def sources(stage, args, profile, build, manifest, imp):
    """Snapshot tracked sources by measured commit; map every compiler input back to archived bytes."""
    rev = manifest["commit"]
    base = stage / "source/jnox" / rev
    original = imp["upstream"]["path"]
    inputs = imp["input_sha256"]
    tracked = set(EXTRA_SOURCE)
    files = {}
    for name, digest in inputs.items():
        path = Path(name)
        require(".." not in path.parts, f"invalid compiler path: {name}")
        if name.startswith("headers/"):
            dest = stage / "source/linux-headers" / imp["header_tree_sha256"] / path.relative_to("headers")
            header_root = args.headers or Path(imp["header_root"])
            copy(header_root / path.relative_to("headers"), dest, digest, source_root=header_root)
        elif name == original:
            dest = stage / "source/linux" / imp["upstream"]["commit"] / name
            copy(args.linux_source or Path(imp["source"]["path"]), dest, digest)
        elif path.is_absolute():
            require(path.parent.name == "build" and path.name in GENERATED, f"unknown external compiler input: {name}")
            dest = stage / profile / "imported" / path.name
            copy(build / "imported" / path.name, dest, digest)
        else:
            dest = base / path
            tracked.add(name)
        files[name] = dest.relative_to(stage).as_posix()
    snapshot = git(args.repo, "archive", "--format=tar", rev, "--", *sorted(tracked))
    with tarfile.open(fileobj=io.BytesIO(snapshot)) as tree:
        for entry in tree:
            if entry.isfile():
                dest = base / entry.name
                dest.parent.mkdir(parents=True, exist_ok=True)
                with tree.extractfile(entry) as data, dest.open("wb") as out:
                    shutil.copyfileobj(data, out)
    for name, target in files.items():
        require(sha(stage / target) == inputs[name], f"{profile}: compiler input {name} differs")
    peer = imp["irq_peer"]["source"]
    require(peer in imp["input_sha256_by_object"]["irq_peer.o"] and peer in files,
            f"{profile}: peer translation unit is absent from compiler dependencies")
    require(sha(base / "drivers/linux-compat/profiles/virtio-net.json") == imp["profile_sha256"]
            and sha(base / "tools/linux_driver_tx_layout.py") == imp["layout_view"]["generator_sha256"],
            f"{profile}: source profile or layout generator differs from build")
    write(stage / profile / "source-index.json", {"commit": rev, "compiler_inputs": files})


def build_artifacts(stage, args, profile, build):
    native, imported = build / "native", build / "imported"
    manifest, imp = read(native / "manifest.json"), read(imported / "import.json")
    race = profile == "race"
    require(re.fullmatch("[a-f0-9]{40}", manifest["commit"]) and not manifest["tracked_changes"]
            and (manifest["board"], manifest["app"], manifest["policy"]) == ("virt", "process", "fifo"),
            f"{profile}: expected clean native virt FIFO build")
    require(imp["mode"] == "rx-irq-service" and imp["irq_rearm_test"]["test_only"] is race
            and manifest["linux_source_net_rx_irq"]["rearm_test_only"] is race
            and imp["irq_peer"]["test_only_rearm"] is race and imp["irq_peer"]["slot"] == 1,
            f"{profile}: wrong kernel, driver or fixture peer variant")
    require([(s["slot"], s["elf"], s["argv"], s["priority"]) for s in manifest["slots"]]
            == [(0, "user.elf", ["/bin/app"], 8), (1, "native_peer.elf", ["/bin/app"], 8)],
            f"{profile}: unexpected process slots")
    argv = manifest["package_argv"]
    require("--linux-source-net-rx-irq" in argv and ("--linux-source-net-rx-irq-rearm-test" in argv) == race
            and argv[argv.index("--elf") + 1] == manifest["slots"][0]["input"]["path"]
            and argv[argv.index("--peer-elf") + 1] == manifest["slots"][1]["input"]["path"],
            f"{profile}: recorded IRQ package arguments disagree with the two input ELFs")
    require(native.resolve().is_relative_to(build.resolve()) and imported.resolve().is_relative_to(build.resolve()),
            f"{profile}: external linked build subtree")
    dest = stage / profile
    copy(native / "manifest.json", dest / "native/manifest.json")
    for name, key in (("kernel.elf", "kernel_elf_sha256"), ("build.log", "build_log_sha256"),
                      ("user.elf", "user_elf_sha256"), ("native_peer.elf", "peer_elf_sha256")):
        copy(native / name, dest / "native" / name, manifest[key])
    copy(build / "build.log", dest / "build.log")
    for slot, artifact, original in zip(manifest["slots"], ("service", "peer"), (imp["service"], imp["irq_peer"]["elf"])):
        digest = slot["elf_sha256"]
        require(digest == sha(dest / "native" / slot["elf"]) == original["sha256"]
                == slot["input"]["sha256"] == manifest["source_sha256"][slot["input"]["path"]],
                f"{profile}: {artifact} ELF provenance mismatch")
        copy(imported / (artifact + ".elf"), dest / "imported" / (artifact + ".elf"), digest)
    copy(imported / "service.map", dest / "imported/service.map", imp["link_map_sha256"])
    copy(imported / "peer.map", dest / "imported/peer.map", imp["irq_peer"]["link_map_sha256"])
    copy(imported / "import.json", dest / "imported/import.json")
    for name in GENERATED:
        copy(imported / name, dest / "imported" / name)
    required_objects = {"virtio_net.original.o", "virtio_net.callback.o", "virtio_net.packet.o", "irq_peer.o",
                        *imp["input_sha256_by_object"]}
    objects = {p.name for p in imported.glob("*.o")}
    require(required_objects <= objects, f"{profile}: missing objects {required_objects - objects}")
    for name in sorted(objects):
        copy(imported / name, dest / "imported" / name)
    for key in ("callback_object", "driver_object"):
        item = imp[key]
        require(sha(dest / "imported" / item["filename"]) == item["sha256"], f"{profile}: altered {key}")
    for name, item in imp["objects"].items():
        require(sha(dest / "imported" / name) == item["sha256"], f"{profile}: altered {name}")
    sources(stage, args, profile, build, manifest, imp)
    return {"commit": manifest["commit"], "kernel_sha256": manifest["kernel_elf_sha256"],
            "driver_sha256": manifest["user_elf_sha256"], "peer_sha256": manifest["peer_elf_sha256"],
            "manifest_sha256": sha(dest / "native/manifest.json"), "import_sha256": sha(dest / "imported/import.json"),
            "upstream": imp["upstream"], "header_tree_sha256": imp["header_tree_sha256"],
            "rearm_test_only": race, "package_argv": argv}


def install_observers(stage, args, profiles):
    records = {}
    for profile, (build, labels) in profiles.items():
        for label in labels:
            require(re.fullmatch(r"[A-Za-z0-9][\w.-]*", label), f"invalid capture name: {label}")
            folder = build / label
            revision = (folder / "observer-commit.txt").read_text().strip()
            require(re.fullmatch("[a-f0-9]{40}", revision), f"{folder}: invalid observer commit")
            records[(profile, label)] = revision
    revisions = sorted(set(records.values()))
    observers = {}
    for revision in revisions:
        where = Path(".") if len(revisions) == 1 else Path("observers") / revision
        files = [Path("tools") / (n + ".py") for n in TOOLS] + [BOARD / n for n in ("board.json", "virt-net.dtb.gz")]
        snapshot = git(args.repo, "archive", "--format=tar", revision, "--", *(p.as_posix() for p in files))
        with tarfile.open(fileobj=io.BytesIO(snapshot)) as tree:
            for path in files:
                dest = stage / where / path
                dest.parent.mkdir(parents=True, exist_ok=True)
                member = tree.getmember(path.as_posix())
                require(member.isfile(), f"observer input is not a regular Git blob: {path}")
                dest.write_bytes(tree.extractfile(member).read())
        base = stage / where
        board = read(base / BOARD / "board.json")
        require(hashlib.sha256(gzip.decompress((base / BOARD / "virt-net.dtb.gz").read_bytes())).hexdigest()
                == board["sha256"], "board DTB hash differs from board.json")
        observers[revision] = {"root": where.as_posix(), "board_dtb_sha256": board["sha256"],
                               "board_json_sha256": sha(base / BOARD / "board.json"),
                               "board_gzip_sha256": sha(base / BOARD / "virt-net.dtb.gz"),
                               "board_qemu_sha256": board["qemu_sha256"], "board_qemu_version": board["qemu_version"],
                               "module_sha256": {p.as_posix(): sha(base / p) for p in files if p.suffix == ".py"}}
    return records, observers


def capture(stage, profile, build, label, identity, observer_revision, observer):
    require(re.fullmatch(r"[A-Za-z0-9][\w.-]*", label) and label not in ("imported", "native", "source"),
            f"invalid capture directory name: {label}")
    src = build / label
    require(not src.is_symlink() and src.resolve().is_relative_to(build.resolve()), f"linked capture: {src}")
    path = Path(profile) / label
    dest = stage / path
    require(not (src / "failure.json").exists(), f"failed capture: {src}")
    phases = ["ready", "active", "final"]
    if profile == "race":
        phases += ["race-1", "race-3"]
    else:
        require(not list(src.glob("race-*")), f"{src}: ordinary capture contains directed checkpoints")
    for name in RAW:
        copy(src / name, dest / name)
    for phase in phases:
        for name in ("ram.json", "qmp.json", "halted.json"):
            copy(src / phase / name, dest / phase / name, source_root=src)
    for sidecar in ("observer.sha256", "observer-commit.txt"):
        copy(src / sidecar, dest / sidecar)
    require((dest / "observer-commit.txt").read_text().strip() == observer_revision,
            f"{path}: observer commit changed during packaging")
    observer_checksums = {}
    for row in (dest / "observer.sha256").read_text().splitlines():
        digest, name = row.split("  ", 1)
        require(name not in observer_checksums, f"{path}: duplicate observer checksum")
        observer_checksums[name] = digest
    require(all(observer_checksums.get(name) == digest for name, digest in observer["module_sha256"].items()),
            f"{path}: observer bytes differ from captured hashes")
    observed, launch = read(dest / "result.json"), read(dest / "launch.json")
    require(launch["schema"] == 2 and launch["qemu_sha256"] == observer["board_qemu_sha256"]
            and launch["qemu_version"] == observer["board_qemu_version"]
            and {"virtio_mmio_setting_irq", "gic_set_irq", "gic_acknowledge_irq", "gic_cpu_read", "gic_cpu_write"}
            <= set((dest / "net.events").read_text().splitlines()), f"{path}: missing schema-2 trace or board identity")
    ids = launch["identities"]
    for key in ("kernel_sha256", "driver_sha256", "manifest_sha256", "import_sha256"):
        require(ids[key] == identity[key], f"{path}: launch {key} differs from selected build")
    require(ids["board_dtb_sha256"] == observer["board_dtb_sha256"] and ids["original_source"] == identity["upstream"]["sha256"],
            f"{path}: board DTB or driver source differs")
    irq = observed["irq"]
    require((irq["rearm_race"] is not None) == (profile == "race") and len(irq["hardware_epochs"]) > 0
            and irq["transport_assert_clear_pairs"] > 0 and irq["routing"]["implemented_ids"] > 79
            and (observed["data_frames"], observed["terminal_ack_frames"]) == (80, 1),
            f"{path}: unexpected recorded IRQ result")
    nonce = (dest / "nonce.bin").read_bytes()
    require(len(nonce) == 8 and any(nonce), f"{path}: invalid external nonce")
    argv = ["python3", "-B", (Path(observer["root"]) / VERIFIER).as_posix(),
            "--replay", "--mutation-tests", "--package", profile + "/native",
            "--driver-manifest", profile + "/imported/import.json", "--out", path.as_posix(),
            "--mac", launch["mac"], "--mtu", str(launch["mtu"])]
    return {"path": path.as_posix(), "profile": profile, "observer_commit": observer_revision, "replay_argv": argv,
            "independent_replay_argv": ["python3", "-B", "qa/read_irq.py", profile, path.as_posix()],
            "nonce": nonce.hex(), "mac": launch["mac"], "mtu": launch["mtu"], "qemu_version": launch["qemu_version"],
            "qemu_sha256": launch["qemu_sha256"], "result_sha256": sha(dest / "result.json"),
            "pcap_sha256": sha(dest / "wire.pcap"), "machine_log_sha256": sha(dest / "machine.log")}


def package(stage, args):
    profiles = {"ordinary": (args.ordinary_build, args.ordinary_capture or ["capture-a", "capture-b"]),
                "race": (args.race_build, args.race_capture or ["directed-final"])}
    require(args.ordinary_build.resolve() != args.race_build.resolve(), "ordinary and directed builds must be distinct")
    capture_observers, observers = install_observers(stage, args, profiles)
    for path in sorted((args.vendor / "elftools").rglob("*.py")):
        copy(path, stage / "vendor" / path.relative_to(args.vendor))
    require((stage / "vendor/elftools/elf/elffile.py").is_file(), "missing pyelftools package")
    for name in ("METADATA", "LICENSE"):
        rel = Path("pyelftools-0.32.dist-info") / name
        copy(args.vendor / rel, stage / "vendor" / rel)
    copy(args.license, stage / "source/GPL-2.0")
    copy(PM / "replay_irq.py", stage / "replay.py")
    copy(args.independent_reader, stage / "qa/read_irq.py")
    for name in ("build.sh", "capture.sh", "package_irq.py", "replay_irq.py"):
        copy(PM / name, stage / "provenance" / name)
    summary = {"profiles": {}, "captures": [], "independent_reports": {}, "observers": observers}
    for profile, (build, labels) in profiles.items():
        require(len(labels) == len(set(labels)), f"{profile}: duplicate capture name")
        identity = build_artifacts(stage, args, profile, build)
        summary["profiles"][profile] = identity
        for label in labels:
            revision = capture_observers[(profile, label)]
            summary["captures"].append(capture(stage, profile, build, label, identity, revision, observers[revision]))
    ordinary, race = summary["profiles"].values()
    require(all(ordinary[key] != race[key] for key in ("kernel_sha256", "driver_sha256"))
            and ordinary["upstream"] == race["upstream"], "unexpected ordinary/race artifact pairing")
    summary["same_peer_elf"] = ordinary["peer_sha256"] == race["peer_sha256"]
    require(len({run["nonce"] for run in summary["captures"]}) == len(summary["captures"]), "duplicate capture nonces")
    for report in args.report:
        require(not report.is_symlink(), f"report argument is a symlink: {report}")
        if report.is_dir():
            files = sorted(p for p in report.rglob("*") if p.suffix.lower() in (".json", ".md")
                           and not p.is_symlink() and p.is_file() and p.resolve().is_relative_to(report.resolve())
                           and not any(part == "__pycache__" or part.startswith(".")
                                       for part in p.relative_to(report).parts))
            require(files, f"empty report directory: {report}")
        else:
            files = [report]
        for path in files:
            if path.resolve() == args.independent_reader.resolve():
                continue
            relative = Path("qa") / report.name
            if report.is_dir():
                relative /= path.relative_to(report)
            require(relative.as_posix() not in summary["independent_reports"], f"duplicate report name: {relative}")
            copy(path, stage / relative, source_root=report if report.is_dir() else report.parent)
            summary["independent_reports"][relative.as_posix()] = sha(stage / relative)
            if path.suffix == ".json":
                data = read(stage / relative)
                if isinstance(data, dict) and {"nonce", "profile", "elf_sha256", "hashes"} <= data.keys():
                    for item in summary["captures"]:
                        if item["nonce"] == data["nonce"]:
                            require(item["profile"] == {"ordinary": "ordinary", "directed": "race"}.get(data["profile"])
                                    and item["pcap_sha256"] == data["hashes"]["wire.pcap"]
                                    and item["machine_log_sha256"] == data["hashes"]["machine.log"],
                                    f"independent report does not match its capture: {relative}")
                            item["independent_report"] = relative.as_posix()
    write(stage / "result.json", summary)
    commands = "\n".join(shlex.join(case["replay_argv"]) for case in summary["captures"])
    independent = "\n".join(shlex.join(case["independent_replay_argv"]) for case in summary["captures"])
    peer_text = (f"The two packaged peer ELFs are byte-identical with SHA-256 `{ordinary['peer_sha256']}`. "
                 "The peer selects its directed check at runtime from the session flag." if summary["same_peer_elf"]
                 else "The profile records identify each peer ELF by its SHA-256 digest.")
    (stage / "README.md").write_text(
        "# JNOX native NIC IRQ capture replay\n\n"
        "Extract into an empty directory on Linux and run `python3 -B replay.py`. Use Python 3.10 or newer and "
        "`aarch64-linux-gnu-nm` from binutils-aarch64-linux-gnu. The archive contains pyelftools 0.32. "
        "The runner checks SHA256SUMS, executes the offline verifier for every capture, compares its decoded "
        "result to the original and checks the rejected mutation list. Mutation tests use temporary disk space.\n\n"
        "Each profile includes its original import and native build manifests, the service and fixture peer ELF "
        "files, both link maps, compiler inputs, kernel, and a build log. Each capture includes its original launch "
        "record, QEMU execution/MMIO trace, raw UART, both socket directions, PCAP and halted RAM snapshots. "
        "The directed build additionally records race-1 and race-3. Source-index files map compiler paths to archive "
        "paths. The launch records retain the historical QEMU arguments and binary identities. "
        "Each captured observer commit and SHA-256 list identifies the archived verifier modules. "
        "result.json lists their hashes and any supplied independent reports. " + peer_text + " "
        "The upstream driver, included headers and pyelftools retain their original license notices.\n\n"
        "To run each individual offline decoder from the extraction root, use the following commands. "
        "The replay.py runner also checks the recorded output and file digests.\n\n"
        "```sh\nexport PYTHONPATH=\"$PWD/vendor:$PWD/tools\" PYTHONDONTWRITEBYTECODE=1 LC_ALL=C\nunset PYTHONOPTIMIZE\n"
        + commands + "\n```\n\nThe independent reader uses only the Python standard library. Run it separately "
        "on the same raw files from the extraction root. Each invocation writes JSON to standard output.\n\n"
        "```sh\n" + independent + "\n```\n", encoding="utf-8")
    return summary


def archive(stage, release):
    entries = sorted(stage.rglob("*"))
    require(all(not p.is_symlink() and p.resolve().is_relative_to(stage.resolve()) for p in entries),
            "link or external entry in staged archive")
    paths = [p for p in entries if p.is_file()]
    checksums = stage / "SHA256SUMS"
    checksums.write_text("".join(f"{sha(p)}  {p.relative_to(stage).as_posix()}\n" for p in paths), encoding="utf-8")
    release.mkdir()
    payload = release / "qemu-replay.tar.xz"
    with tarfile.open(payload, mode="x:xz", preset=4) as tar:
        for path in sorted([*paths, checksums]):
            info = tar.gettarinfo(str(path), path.relative_to(stage).as_posix())
            require(info.isfile(), f"archive entry must be a regular file: {path}")
            info.mode, info.uid, info.gid, info.mtime = 0o644, 0, 0, 0
            info.uname = info.gname = ""
            with path.open("rb") as data:
                tar.addfile(info, data)
    for name in ("result.json", "README.md"):
        copy(stage / name, release / name)
    digest = sha(payload)
    (release / (payload.name + ".sha256")).write_text(f"{digest}  {payload.name}\n", encoding="utf-8")
    (release / "SHA256SUMS").write_text("".join(f"{sha(release / name)}  {name}\n" for name in
                                        (payload.name, "result.json", "README.md")), encoding="utf-8")
    return digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ordinary-build", type=Path, required=True)
    parser.add_argument("--race-build", type=Path, required=True)
    parser.add_argument("--ordinary-capture", action="append", metavar="DIRNAME", help="repeatable, defaults to capture-a and capture-b")
    parser.add_argument("--race-capture", action="append", metavar="DIRNAME", help="repeatable, defaults to directed-final")
    parser.add_argument("--independent-reader", type=Path, default=PM / "independent/read_irq.py")
    parser.add_argument("--report", type=Path, action="append", default=[],
                        help="existing independent report file or directory of JSON/Markdown reports")
    parser.add_argument("--output", type=Path, required=True, help="new output directory for archive, digest and summary")
    parser.add_argument("--repo", type=Path, default=LAB / "src", help="Git object store containing the build and observer commits")
    parser.add_argument("--vendor", type=Path, default=PM.parent / "jnox332-release-deps", help="extracted pyelftools 0.32 and dist-info")
    parser.add_argument("--license", type=Path, default=PM.parent / "jnox424-pm/GPL-2.0")
    parser.add_argument("--linux-source", type=Path, help="relocated pinned virtio_net.c")
    parser.add_argument("--headers", type=Path, help="relocated Linux headers root")
    args = parser.parse_args()
    output = args.output.resolve()
    require(not output.exists(), f"output already exists: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as work:
        stage, release = Path(work) / "payload", Path(work) / "release"
        summary = package(stage, args)
        digest = archive(stage, release)
        release.rename(output)
    print(json.dumps({"archive": str(output / "qemu-replay.tar.xz"), "sha256": digest, "captures": len(summary["captures"])}))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, KeyError, subprocess.CalledProcessError) as exc:
        sys.exit(str(exc))
