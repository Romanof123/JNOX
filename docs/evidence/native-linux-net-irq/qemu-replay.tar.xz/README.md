# JNOX native NIC IRQ capture replay

Extract into an empty directory on Linux and run `python3 -B replay.py`. Use Python 3.10 or newer and `aarch64-linux-gnu-nm` from binutils-aarch64-linux-gnu. The archive contains pyelftools 0.32. The runner checks SHA256SUMS, executes the offline verifier for every capture, compares its decoded result to the original and checks the rejected mutation list. Mutation tests use temporary disk space.

Each profile includes its original import and native build manifests, the service and fixture peer ELF files, both link maps, compiler inputs, kernel, and a build log. Each capture includes its original launch record, QEMU execution/MMIO trace, raw UART, both socket directions, PCAP and halted RAM snapshots. The directed build additionally records race-1 and race-3. Source-index files map compiler paths to archive paths. The launch records retain the historical QEMU arguments and binary identities. Each captured observer commit and SHA-256 list identifies the archived verifier modules. result.json lists their hashes and any supplied independent reports. The two packaged peer ELFs are byte-identical with SHA-256 `68dcb5af16b9ea88c3220e36a8aece017d642b1fd33ffa428d2ebf4c163d007b`. The peer selects its directed check at runtime from the session flag. The upstream driver, included headers and pyelftools retain their original license notices.

To run each individual offline decoder from the extraction root, use the following commands. The replay.py runner also checks the recorded output and file digests.

```sh
export PYTHONPATH="$PWD/vendor:$PWD/tools" PYTHONDONTWRITEBYTECODE=1 LC_ALL=C
unset PYTHONOPTIMIZE
python3 -B observers/08e492586020588cb4afcde631c3d3bf356ca109/tools/verify_linux_source_net_irq.py --replay --mutation-tests --package ordinary/native --driver-manifest ordinary/imported/import.json --out ordinary/capture-a --mac 52:54:00:19:34:41 --mtu 1410
python3 -B observers/08e492586020588cb4afcde631c3d3bf356ca109/tools/verify_linux_source_net_irq.py --replay --mutation-tests --package ordinary/native --driver-manifest ordinary/imported/import.json --out ordinary/capture-b --mac 52:54:00:19:34:42 --mtu 1386
python3 -B observers/9559913e98abc7a1a2033e69dc90d1071cbc2a7b/tools/verify_linux_source_net_irq.py --replay --mutation-tests --package race/native --driver-manifest race/imported/import.json --out race/directed-final --mac 52:54:00:19:34:43 --mtu 1420
```

The independent reader uses only the Python standard library. Run it separately on the same raw files from the extraction root. Each invocation writes JSON to standard output.

```sh
python3 -B qa/read_irq.py ordinary ordinary/capture-a
python3 -B qa/read_irq.py ordinary ordinary/capture-b
python3 -B qa/read_irq.py race race/directed-final
```
