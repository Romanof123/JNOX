#!/bin/bash
set -euo pipefail
base="$HOME/jnox406-lab"; src=/mnt/d/codex/.jnox-work/source-net-poll; exec 9>"$base/run.lock"; flock 9
d="$base/$1"; label="$2"; shift 2; export LC_ALL=C PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/mnt/d/codex/jnox332-release-deps
python3 -B "$src/tools/verify_linux_source_net_rx_poll.py" --package "$d/native" --driver-manifest "$d/imported/import.json" --out "$d/$label" "$@"
