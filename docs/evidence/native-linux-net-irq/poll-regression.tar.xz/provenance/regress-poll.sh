#!/bin/bash
set -euo pipefail
rev="$1"
name="$2"
pm=/mnt/d/codex/jnox432-pm
base="$HOME/jnox406-lab"
bash "$pm/poll-build.sh" "$rev" "$name"
bash "$pm/poll-capture.sh" "$name" regression --mtu 1430 --mac 52:54:00:19:34:55 >"$base/$name/regression.log"
python3 - "$base/$name/regression/result.json" <<'PY'
import sys,json
r=json.load(open(sys.argv[1]))
print({k:r[k] for k in ('data_frames','terminal_ack_frames','budget_exhaustions')})
PY
