#!/usr/bin/env python3
import hashlib, json, os, subprocess, sys
from pathlib import Path

root = Path(__file__).resolve().parent
for line in (root / 'SHA256SUMS').read_text().splitlines():
    digest, name = line.split('  ', 1)
    if hashlib.sha256((root / name).read_bytes()).hexdigest() != digest:
        sys.exit('checksum mismatch: ' + name)
record = json.loads((root / 'provenance.json').read_bytes())
manifest = json.loads((root / 'native/manifest.json').read_bytes())
if 'linux_source_net_rx_irq' in manifest or 'linux_source_net_rx_poll' not in manifest:
    sys.exit('unexpected polling profile')
env = dict(os.environ, PYTHONPATH=str(root / 'vendor'), PYTHONDONTWRITEBYTECODE='1', LC_ALL='C')
env.pop('PYTHONOPTIMIZE', None)
actual = json.loads(subprocess.check_output([sys.executable, *record['replay_argv'][1:]], cwd=root, env=env))
controls = actual.pop('rejected_mutations')
if len(controls) != 8 or set(controls) != {'running CPU at burst','wire.pcap','host-to-guest.bin',
        'registered NAPI pointer','no budget exhaustion','skb build','removed executed virtnet_poll',
        'removed executed gro_receive_skb'}:
    sys.exit('poll mutation controls differ')
if actual != json.loads((root / 'regression/result.json').read_bytes()):
    sys.exit('recorded poll result differs')
print(json.dumps(dict(passed=True, source_commit=manifest['commit'], data_frames=actual['data_frames'],
    terminal_ack_frames=actual['terminal_ack_frames'], budget_exhaustions=actual['budget_exhaustions'],
    typed_gro_normal_deliveries=actual['typed_gro_normal_deliveries'], rejected_mutations=controls), indent=2))
