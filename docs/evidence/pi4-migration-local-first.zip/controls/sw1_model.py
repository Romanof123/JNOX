import os,selectors,time,json,hashlib,shutil,re,subprocess
from pathlib import Path
d=Path('controls/sw1-bounded'); d.mkdir(); q='/mnt/d/codex/arm-speed-lab/build/system/qemu-system-aarch64'
for name,src in [('kernel8.img','sw1.img'),('kernel.elf','sw1.elf')]: shutil.copyfile(d.parent/src,d/name)
args=[q,'-machine','raspi4b','-accel','tcg,thread=multi','-smp','4','-m','2G','-display','none','-monitor','none','-serial','stdio','-d','int,tid','-D',str(d/'observer-%d.log'),'-kernel',str(d/'kernel8.img')]
t=last=time.monotonic_ns(); raw=b''; ids={}
with (d/'stderr').open('wb') as err,subprocess.Popen(args,stdout=subprocess.PIPE,stderr=err) as proc:
    try:
        with selectors.DefaultSelector() as sel:
            sel.register(proc.stdout,selectors.EVENT_READ)
            while time.monotonic_ns()-t<30e9:
                for f in Path(f'/proc/{proc.pid}/task').glob('*/comm'):
                    name=f.read_text().strip()
                    if re.fullmatch('CPU [0-3]/TCG',name): ids[f.parent.name]=int(name.split()[1][0])
                if b'\nSW END ' in raw and time.monotonic_ns()-last>=1e9: break
                if sel.select(.02):
                    b=os.read(proc.stdout.fileno(),65536)
                    if not b: break
                    raw+=b;last=time.monotonic_ns()
            end=time.monotonic_ns()
    finally:
        proc.terminate();proc.wait()
(d/'uart.bin').write_bytes(raw); (d/'threads.json').write_text(json.dumps(ids)); events=[]
for tid,c in sorted(ids.items(),key=lambda pair:pair[1]):
    p=d/f'observer-{tid}.log'
    if not p.exists(): continue
    kind=None
    for line in p.read_text().splitlines():
        if 'Taking exception' in line: kind='irq' if '[IRQ]' in line else 'svc' if '[SVC]' in line else 'unknown'
        if line.startswith('...with ELR '): events.append((c,kind,line.split()[-1]))
        if line.startswith('Exception return from AArch64 EL1 to AArch64 EL1 PC'): events.append((c,'eret',line.split()[-1]))
(d/'external.log').write_text(''.join(f'CPU {c} {k} {pc}\n' for c,k,pc in events))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
(d/'session.json').write_text(json.dumps(dict(mode='model',run_id='bounded-sw1-control',elapsed_ns=end-t,quiet_ns=end-last,argv=args,sha256={f.name:sha(f) for f in d.iterdir() if f.is_file()}),indent=2))
r=subprocess.run(['python3','source/tools/pi4_smp_replay.py',str(d),sha(d/'session.json')],capture_output=True,text=True)
(d/'replay.log').write_text(r.stdout+r.stderr); print(r.returncode,r.stdout[-450:],r.stderr)
