import re,json,subprocess
from pathlib import Path
for d in sorted(Path('frozen').iterdir()):
    raw=subprocess.check_output(['aarch64-linux-gnu-objdump','-D','-b','binary','-maarch64','--adjust-vma=0x80000',str(d/'kernel8.img')],text=True).splitlines()
    selected=[]
    for i,line in enumerate(raw):
        if re.search(r'\b(?:mrs|msr)\b.*\b(?:tpidr_el1|sp_el0|tpidr_el0|tpidrro_el0)\b',line):
            selected.extend(raw[max(0,i-2):i+3])
    assert len([s for s in raw if re.search(r'msr\s+tpidr_el1,',s)])==1
    assert all(any(re.search(reg,s) for s in raw) for reg in (r'msr\s+tpidr_el0',r'mrs\s+x9, tpidr_el0',r'mrs\s+x10, tpidrro_el0',r'msr\s+sp_el0',r'mov\s+x9, xzr'))
    content=(d/'disassembly.txt').read_text().splitlines()
    for i,s in enumerate(content):
        if re.search(r'bl\s+.*<(.*(?:7install|11checked_tls|6digest|11local_lease|10checkpoint|13pi4_migration3irq).*)>',s):
            selected.extend(content[max(i-2,0):i+7])
    (d/'linked-review.txt').write_text('\n'.join(selected)+'\n')
