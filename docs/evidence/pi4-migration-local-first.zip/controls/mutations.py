from pathlib import Path
import sys,copy,json
sys.path.insert(0,'source/tools')
from pi4_mg3_replay import witnesses
d=Path('frozen/stream-global'); syms=json.loads((d/'freeze.json').read_text())['local_symbols']
rows={0:[],1:[]}
for line in (d/'first-1/uart.bin').read_text().splitlines():
    if line.startswith('MG ROW '):
        c,s,k,*data=map(int,line.split()[2:]); rows[c].append((k,tuple(data)))
for label,k,l,field,val in [('original',0,0,0,0),('swapped CPU',15,4,3,syms['PI4_MIG_CPU0']['address']),('zero TLS',15,4,4,0),('foreign TLS',15,4,4,syms['PI4_MIG_TLS_P0']['address']),('reuse P1',14,5,4,syms['PI4_MIG_TLS_P1_OPEN']['address']),('wrong token',15,4,5,0x10604),('stale claimed lease',15,4,2,1),('stale live lease',14,4,7,1),('prefix digest',15,4,7,1),('missing destination',15,4,None,None),('saved only',-1,4,None,None)]:
    r=copy.deepcopy(rows)
    if k==-1: r[1]=[(t,a) for t,a in r[1] if not (t in (5,15) and a[2]==l)]
    elif k:
        i=next(i for i,(t,a) in enumerate(r[1]) if t==k and a[2]==l)
        if field is None: r[1].pop(i)
        else:
            a=list(r[1][i][1]); a[field]=val; r[1][i]=(k,tuple(a))
    try: witnesses(r,syms,0,True)
    except ValueError as e:
        assert k; print(label,'REJECT',e)
    else:
        assert k==0;print(label,'PASS')
