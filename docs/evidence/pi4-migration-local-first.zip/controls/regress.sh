set -eu
D=$(pwd); c="$D/controls"
export PATH="$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH" CARGO_HOME="$HOME/jnox-169-first-e203caa/cargo" CARGO_TARGET_DIR="$D/target" PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
cd source/kernel
E="$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel"
cargo build -j1 --release --offline --locked --features smp-bench >"$c/virt-build" 2>&1
cp "$E" "$c/virt.elf"
printf '#!/bin/bash\nexec python3 "%s/source/tools/smp_capture.py" "$@"\n' "$D" >"$c/virt-wrapper"
chmod +x "$c/virt-wrapper"
SMP_CAPTURE_DIR="$c/virt-run" python3 ../tools/qemu_boot.py --profile smp --kernel "$c/virt.elf" --qemu "$c/virt-wrapper" >"$c/virt-verdict" 2>&1 || echo $? >>"$c/virt-verdict"
JNOX_BOARD=pi4 JNOX_PROFILE=smp JNOX_APP=directed-wake cargo build --offline --locked --release -j1 >"$c/sw1-build" 2>&1
cp "$E" "$c/sw1.elf"
aarch64-linux-gnu-objcopy -O binary "$E" "$c/sw1.img"
Q=/mnt/d/codex/arm-speed-lab/build/system/qemu-system-aarch64
timeout 3 "$Q" -machine raspi4b -accel tcg,thread=multi -smp 4 -m 2G -display none -monitor none -serial stdio -d int -D "$c/sw1-observer.log" -kernel "$c/sw1.img" >"$c/sw1-uart" 2>"$c/sw1-stderr" || echo $? >>"$c/sw1-stderr"
cargo build --all-features --release --offline --locked -j1 >"$c/all-build" 2>&1
cp "$E" "$c/all.elf"
JNOX_BOARD=virt JNOX_PROFILE=smp JNOX_APP=migration-global cargo build --release --offline --locked -j1 >"$c/reject-board" 2>&1 && exit 2
cargo build --features pi4-stream-v1 --release --locked --offline -j1 >"$c/reject-stream" 2>&1 && exit 3
exit 0
