set -eu
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
for w in short stream; do for p in global partitioned clustered; do for i in 1 2; do
echo "$w-$p $i"
done; done; done >order
sha256sum plan.md freeze-digests order >commitment
while read name i; do
d=frozen/$name
h=$(sha256sum "$d/freeze.json" | cut -d' ' -f1)
python3 source/tools/pi4_migration_capture.py run "$d" "$h" "$i" >"$d/run-$i.log" 2>&1 || echo $? >>"$d/run-$i.log"
s="$d/first-$i/session.json"
if test -f "$s"; then
sh=$(sha256sum "$s" | cut -d' ' -f1)
echo "$name $i $sh" >>session-digests
python3 source/tools/pi4_migration_replay.py "$d" "$i" "$sh" >"$d/replay-$i.log" 2>&1 || echo $? >>"$d/replay-$i.log"
fi
done <order
