set -eu
D=$(pwd)
export PATH="$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH"
export CARGO_TARGET_DIR="$D/target" PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_HOME="$HOME/jnox-169-first-e203caa/cargo"
Q=/mnt/d/codex/arm-speed-lab/build/system/qemu-system-aarch64
mkdir -p "$D/frozen"
cd source/kernel
for w in short stream; do
  f=(); work=sum-65536
  if [ "$w" = stream ]; then f=(--features pi4-stream-v1); work=sample-crc32-v1; fi
  for p in global partitioned clustered; do
    JNOX_PROFILE=smp JNOX_BOARD=pi4 JNOX_APP=migration-$p cargo build -j1 --locked --offline --release "${f[@]}"
    e="$D/target/aarch64-unknown-none/release/jnox-kernel"
    aarch64-linux-gnu-objcopy -O binary "$e" "$D/raw"
    aarch64-linux-gnu-objdump -d "$e" >"$D/dis"
    python3 ../tools/pi4_migration_capture.py freeze migration-$p "$D/frozen/$w-$p" "$e" "$D/raw" "$D/dis" "$Q" --source "$(git rev-parse HEAD)" --wire-version 3 --compiler "$(rustc -V)" --workload "$work" >>"$D/freeze-digests"
  done
done
