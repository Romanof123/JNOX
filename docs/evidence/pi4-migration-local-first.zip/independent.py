import json,re,zlib
from pathlib import Path
from functools import lru_cache
@lru_cache(None)
def history(stream,act):
    first,last,step=(0,4194304,1024) if stream and act==0 else [(0,65536,16),(0,32,16),(0,16,16),(16,32,16)][act]
    h=v=0; out={}
    for i in range(first+step,last+1,step):
        if step==1024:
            v=zlib.crc32(bytes((a^(a>>8)^(a>>16))%256 for a in range(i-step,i)),v)
        else:
            v+=step*(2*i-step+1)//2
        h=((((h<<7)|(h>>57))%(1<<64)^i)+v)%(1<<64)
        out[i]=(v,h)
    return out
def read(d,i):
    f=json.loads((d/'freeze.json').read_text()); sym=f['local_symbols']; local=lambda s:sym['PI4_MIG_'+s]['address']
    p=d/f'first-{i}'; raw=(p/'uart.bin').read_text(); threads=json.loads((p/'threads.json').read_text())
    sections=[[],[]]; saved={}; lives={}; sums=[]; irq=None; dst=None
    bounds=f['loop_range']
    for line in raw.splitlines():
        if not line.startswith('MG ROW'): continue
        c,seq,k,*a=map(int,line.split()[2:]); r=sections[c]; assert seq==len(r)<96; r.append((k,a)); prev=r[-2][1] if seq else []
        if k==4 and a[0:2]==[0,0] and a[6]!=65535: irq=a
        if k==11 and a[:2]==[1,0]: dst=(c,a)
        if k not in (14,15,13): continue
        if k==13:
            task,epoch,lease,n,h,index,v,res=a; act=task+(task==2 and epoch==1)
            ref=history('stream' in d.name,act); assert n==len(ref) and index==max(ref) and ref[index]==(v,h)
            sums.append((act,n,h,index,v)); continue
        task,t,l=a[:3]; act=t-0x10601; ptr=local('TLS_'+['M','P0','P1_OPEN','P1_REPLACEMENT'][act]); base=local('CPU'+str(c))
        assert task==min(act,2) and 0<=act<=3
        if k==14:
            assert r[-2][0]==4 and prev[1]==task and (prev[0]==1)==(act==3) if task==2 else r[-2][0]==4 and prev[1]==task
            assert a[3:]==[prev[2],ptr,t,base,l]; saved[l]=(c,ptr,t)
        else:
            assert r[-2][0]==5 and (prev[0],prev[2],prev[3])==(task,l,a[6]) and a[3:6]==[base,ptr,t]
            assert history('stream' in d.name,act)[a[6]]==(prev[4],a[7]); lives[l]=(c,ptr,t)
    assert len(sums)==4 and len(lives)==len(saved)==5 and lives==saved
    c,a=dst; pc=irq[3]; assert [a[3],a[4],a[5],a[6]]==[irq[2],pc,irq[4],irq[5]]
    assert lives[a[2]][1:]==saved[1][1:] and c==lives[a[2]][0] and saved[1][0]==0
    traces={int(v.split()[1][0]):(p/f'observer-{tid}.log').read_text() for tid,v in threads.items() if (p/f'observer-{tid}.log').is_file()}
    assert re.search(r'Taking exception 5 \[IRQ\] on CPU 0\n(?:\.\.\.[^\n]*\n)*?\.\.\.with ELR '+hex(pc)+r'\n',traces[0])
    assert 'Exception return from AArch64 EL1 to AArch64 EL1 PC '+hex(pc)+'\n' in traces[c]
    return dict(image=d.name,i=i,rows=list(map(len,sections)),saved=len(saved),live=len(lives),source=0,dest=c,pc=hex(pc),loop=list(map(hex,bounds)),inner=bounds[0]<=pc<bounds[1],M=sorted(sums)[0])
positions=[read(Path('frozen')/n,int(i)) for n,i in map(str.split,Path('order').read_text().splitlines())]
print(json.dumps(positions,indent=2))
