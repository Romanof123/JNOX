#include <errno.h>
_Static_assert(ENOENT == 2, "ENOENT");
_Static_assert(ENFILE == 23, "ENFILE");
_Static_assert(ENAMETOOLONG == 36, "ENAMETOOLONG");
_Static_assert(EDESTADDRREQ == 89, "EDESTADDRREQ");
_Static_assert(EPROTOTYPE == 91, "EPROTOTYPE");
_Static_assert(ESOCKTNOSUPPORT == 94, "ESOCKTNOSUPPORT");
int socket_errno_header_consumer(void) { return 0; }
