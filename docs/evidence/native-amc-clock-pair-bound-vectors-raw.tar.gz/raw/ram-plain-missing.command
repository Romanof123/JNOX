/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/iv354-fixed/ram-controls/plain-missing 4b60cc9ff2793baaadf97373aa6738376970325eea2ba4a370bedb6ac0980864
