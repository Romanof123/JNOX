/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/iv354-fixed/ram-controls/plain-ambiguous 58374acee2b1e43d18c011e56a966eaf5f46f51eb235b35ae8b0d8b836c78558
