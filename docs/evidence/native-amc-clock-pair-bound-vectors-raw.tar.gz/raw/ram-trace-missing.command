/usr/bin/python3 tools/native_amc_report.py report /home/ywcho/iv354-fixed/ram-controls/trace-missing 1b813c611f51f2f4e4476424c60d7fc796f9c098ff114b09955bc0729e5fbf54
