import json,hashlib,subprocess,sys
from pathlib import Path
p=Path.cwd();co=Path.home()/'iv354-final/first/cohort';src=co/'first-2';sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
for label,patch,want in [('cpu0',' on CPU 0',0),('cpu1',' on CPU 1',2)]:
 d=p/label;d.mkdir();sub=d/'first-2';sub.mkdir()
 for x in co.iterdir():
    if x.is_file():(d/x.name).symlink_to(x)
 for x in src.iterdir():
    if x.name not in ('session.json','exceptions.log'):(sub/x.name).symlink_to(x)
 t=(src/'exceptions.log').read_text().replace('Taking exception 5 [IRQ]\n','Taking exception 5 [IRQ]'+patch+'\n');(sub/'exceptions.log').write_text(t)
 s=json.load(open(src/'session.json'));s['hashes']['exceptions.log']=sha(sub/'exceptions.log');(sub/'session.json').write_text(json.dumps(s))
 r=subprocess.run([sys.executable,str(p/'source/tools/native_amc_clock_report.py'),'report',str(d/'cohort.json'),sha(d/'cohort.json'),'2',sha(sub/'session.json')],capture_output=True);(p/(label+'.result')).write_bytes(r.stdout);print(label,r.returncode);assert r.returncode==want
z=json.load(open('raw/verified.json'));assert all(x['status']=='failed' for k in ['prior_falsifications','additional_ram_controls'] for x in z[k].values())
for n,a in z['authentic'].items():assert a['status']==('incomplete' if n in ('normal-hi-trace','staggered-trace') else 'observations-met')
print([(n,z['authentic'][n]['unknown']) for n in ('normal-hi-trace','staggered-trace')])
