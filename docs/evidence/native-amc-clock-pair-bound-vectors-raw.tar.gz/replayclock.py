from pathlib import Path
import sys,re,subprocess,hashlib,json
from elftools.elf.elffile import ELFFile
p=Path.cwd(); old=Path.home()/'iv354-final';co=old/'first/cohort'; source=p/'source';out=p/'clock';out.mkdir()
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
seal=sha(co/'cohort.json'); records=[]
def go(label,d,i,want):
 s=d/f'first-{i}'/'session.json'
 cmd=[sys.executable,str(source/'tools/native_amc_clock_report.py'),'report',str(d/'cohort.json'),seal,str(i),sha(s)]
 r=subprocess.run(cmd,capture_output=True);(out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr)
 j=json.loads(r.stdout);rec=dict(label=label,position=i,session=sha(s),rc=r.returncode,expected=want,status=j['status'],details=j.get('issues') or j.get('detail'),command=cmd);records.append(rec);print(label,r.returncode,rec['status'],flush=True)
for i in range(1,7):go('first-'+str(i),co,i,0)
for r in json.load(open(old/'negatives.json')):go(r['name'],old/'neg'/r['name'],r['i'],2)
for i,name in ((2,'label'),(4,'label'),(2,'vector'),(4,'vector4')):
 label=f'{i}-trace-{name}';go(label,old/'neg'/label,i,2)
v=co/'first-2'; text=(v/'exceptions.log').read_text()
with (v/'kernel.elf').open('rb') as f:
 sym,=ELFFile(f).get_section_by_name('.symtab').get_symbol_by_name('native_el0_vectors');base=sym['st_value'];assert sym['st_size']==2048 and base%2048==0
for sy,origin,num,code,slot in [('idle',1,5,'IRQ',5),('irq',0,5,'IRQ',9),('svc',0,2,'SVC',8)]:
 pattern=rf'(?P<head>Taking exception {num} \[{code}\]\n\.\.\.from EL{origin} to EL1\n\.\.\.with ESR [^\n]+\n\.\.\.with ELR [^\n]+\n)(?P<dest>\.\.\.to EL1 PC {base+128*slot:#x} PSTATE [^\n]+\n)';m=re.search(pattern,text);assert m
 for mode in ('wrong','missing'):
    label=sy+'-'+mode;d=p/label;d.mkdir();sub=d/'first-2';sub.mkdir()
    for x in co.iterdir():
       if x.is_file():(d/x.name).symlink_to(x)
    for x in v.iterdir():
       if x.name not in ('session.json','exceptions.log'):(sub/x.name).symlink_to(x)
    y=m['dest'].replace(hex(base+128*slot),hex(base+128*(8 if slot!=8 else 9))) if mode=='wrong' else ''
    raw=text[:m.start('dest')]+y+text[m.end('dest'):];(sub/'exceptions.log').write_text(raw)
    sess=json.load(open(v/'session.json'));sess['hashes']['exceptions.log']=sha(sub/'exceptions.log');(sub/'session.json').write_text(json.dumps(sess));go(label,d,2,2)
(p/'clock-results.json').write_text(json.dumps(dict(source='d01e7f30fc35e4a50e2cc81285bf5802387c6e9e',table=hex(base),records=records),indent=2))
assert all(r['rc']==r['expected'] for r in records)
