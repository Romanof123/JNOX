from pathlib import Path
import json,tarfile,hashlib,shutil,os
p=Path.cwd(); dest=Path('/mnt/d/codex/iv350-deadline-evidence');dest.mkdir(exist_ok=True)
files=[f for f in p.iterdir() if f.is_file() and f.suffix in {'.py','.json','.log','.sh','.md','.rs','.uart'}]
files+=list((p/'dependencies').glob('*'));files+=[f for f in (p/'evidence').glob('*') if f.is_file()]
for pol in ['edf','llf']:
 files += [f for f in (p/'evidence'/pol).iterdir() if f.is_file()]
 for mode in ['plain','traced']:files += [p/'evidence'/('run-'+pol+'-'+mode)/'public.json']
for n in ['004','005','015','048']:
 files.extend((p/'checkout/docs/evidence').glob('evd-'+n+'*.json'))
for n in ['native-edf-applications-first/scores.json','native-edf-block-input-first/scores.json','native-llf-applications-first/ev/reconstruction.json','native-llf-applications-first/ev/products.json','edf48/results.json','deadline-supply-command-replay/first-observed.en-ko.md']:
 files.append(p/'archive'/n)
for nm in ['oracle.py','negative.py','build.sh','capture.py']:files.append(p/'archive/native-deadline-service-first/independent-319-verifier'/nm)
fs=sorted(set(files)); report=p/'first-report.en-ko.md';report.write_text(report.read_text().replace('and cals.','and calendar.'))
def sha(x):return hashlib.sha256(x.read_bytes()).hexdigest()
m=p/'MEMBER-SHA256';m.write_text(''.join(sha(f)+'  '+str(f.relative_to(p))+'\n' for f in fs))
out=dest/'first.tar.gz'
with tarfile.open(out,'x:gz') as t:
 for f in [m,*fs]:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(out) as t:
 for f in fs:assert hashlib.sha256(t.extractfile(str(f.relative_to(p))).read()).hexdigest()==sha(f)
shutil.copy2(report,dest/report.name)
(dest/'SHA256SUMS').write_text(sha(out)+'  first.tar.gz\n'+sha(report)+'  '+report.name+'\n')
print((dest/'SHA256SUMS').read_text(),len(fs),out.stat().st_size)
