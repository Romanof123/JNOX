import gzip,hashlib,json,os,re,socket,subprocess,sys,time,struct,mmap,shutil,tarfile
from pathlib import Path
o=Path.home()/'iv350/evidence'
dest=o
positions=[('edf-plain','edf'),('edf-traced','edf'),('llf-plain','llf'),('llf-traced','llf')]
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def argv(n,p):
 d=o/('run-'+n)
 return ['/usr/bin/qemu-system-aarch64','-machine','virt,gic-version=2,memory-backend=mem','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-object',f'memory-backend-file,id=mem,size=128M,mem-path={d}/ram,share=on','-nodefaults','-display','none','-monitor','none','-qmp',f'unix:{d}/qmp,server=on,wait=off','-no-reboot','-serial',f'file:{d}/uart.bin',*(['-d','int','-D',str(d/'exceptions.log')] if 'traced' in n else []),'-kernel',str(o/p/'kernel.elf')]
if sys.argv[1]=='freeze':
 print(json.dumps({'positions':[(n,sha(o/p/'kernel.elf'),argv(n,p)) for n,p in positions],'timeout_s':120,'apps':[sha(o/(a+'.elf')) for a in 'ABS'],'qemu':subprocess.check_output(['qemu-system-aarch64','--version'],text=True)},indent=2));sys.exit()
n=sys.argv[1]; p=dict(positions)[n];d=o/('run-'+n);d.mkdir()
base=int(next(l.split()[0] for l in subprocess.check_output(['llvm-nm','-an',o/p/'kernel.elf'],text=True).splitlines() if 'mmu6SPACES' in l),16)
proc=subprocess.Popen(argv(n,p),stderr=open(d/'stderr','wb')); start=time.monotonic(); cause='timeout'; samples=[]
while time.monotonic()-start<120 and proc.poll() is None:
 u=(d/'uart.bin').read_bytes() if (d/'uart.bin').exists() else b''
 if re.search(rb'(RECURRING END [^\n]+|FAULT [^\n]+|EXIT PID 1 197)\r?\n',u):
  cause='terminal UART';break
 if 'traced' in n and (d/'ram').exists():
  with open(d/'ram','rb') as f:
   addr=base+0x415000+0x5000+0x2000-0x40000000; f.seek(addr); raw=f.read(4)
   if len(raw)==4: samples.append((time.monotonic_ns(),int.from_bytes(raw,'little')))
 time.sleep(.005)
s=socket.socket(socket.AF_UNIX);s.connect(str(d/'qmp')); fp=s.makefile('rwb',buffering=0);fp.readline()
def q(command,**args):
 fp.write((json.dumps(dict(execute=command,arguments=args))+'\n').encode())
 while True:
  r=json.loads(fp.readline())
  if 'return' in r:return r['return']
  if 'error' in r:raise RuntimeError(r)
q('qmp_capabilities');q('stop');regs=q('human-monitor-command',**{'command-line':'info registers'});(d/'regs').write_text(regs)
q('quit');proc.wait();(d/'status').write_text(f'{cause}, host QMP quit {proc.returncode}, elapsed {time.monotonic()-start:.4f}s\n')
(d/'progress.json').write_text(json.dumps(samples))
with open(d/'ram','rb') as f,gzip.open(d/'ram.gz','wb',compresslevel=2) as g:shutil.copyfileobj(f,g)
archive=dest/(n+'.tar.gz')
with tarfile.open(archive,'x:gz') as t:
 for f in d.iterdir():
  if f.is_file() and f.name!='ram':t.add(f,arcname=f.name)
print(n,(d/'status').read_text(),(d/'uart.bin').read_bytes()[-150:],sha(archive))