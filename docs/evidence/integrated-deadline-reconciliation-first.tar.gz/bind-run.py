from pathlib import Path
import sys,json,hashlib,subprocess,os
p=Path.home()/'iv350'; e=p/'evidence'; orig=Path('/mnt/d/codex/independent-319-verifier')
cap=(orig/'capture.py').read_text().replace("Path.home()/'ind319/evidence'","Path.home()/'iv350/evidence'").replace("Path('/mnt/d/codex/independent-319-verifier')","o")
cap=cap[:cap.index("def sha")] .split(",('alternate-plain'")[0]+"]\n"+cap[cap.index("def sha"):]
(p/'capture.py').write_text(cap)
(p/'oracle.py').write_bytes((orig/'oracle.py').read_bytes())
def call(*cmd):return subprocess.check_output(cmd,text=True)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
for pol in ('edf','llf'):
 f=e/pol/'kernel.elf';(e/pol/'kernel.sym').write_text(call('llvm-nm','-an',f))
binding=json.loads(call('python3',p/'capture.py','freeze'))
binding.update(candidate='9f4ce082600fe73e5ee3e8b98ae826d9d52a4ed3',main='3373dcc6',source_tree=call('git','-C',p/'checkout','rev-parse','HEAD^{tree}').strip(),configs={x:json.loads((e/x/'manifest.json').read_text()) for x in ('edf','llf')},witnesses=(p/'checkout/docs/deadline-release-reconciliation.en-ko.md').read_text(),toolchain=call(str(Path.home()/'.cargo/bin/rustc'),'+1.95.0','-Vv'),raw_commands=[['python3',str(p/'capture.py'),z[0]] for z in binding['positions']],hashes={str(f):sha(f) for f in [p/'capture.py',p/'oracle.py',p/'checkout/tools/replay_native_deadline_service.py',Path('/usr/bin/qemu-system-aarch64'),*e.glob('*/*.sym'),*e.glob('*.sym'),*e.glob('*.dis')]},destinations=[str(e/(z[0]+'.tar.gz')) for z in binding['positions']])
with (p/'binding.json').open('x') as f:json.dump(binding,f,indent=2)
(p/'binding.json').chmod(0o444)
print(sha(p/'binding.json'),flush=True)
for name,_,_ in binding['positions']:
 rc=subprocess.call(['python3',p/'capture.py',name]);print('cold',name,rc,flush=True)
