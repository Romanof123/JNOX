import json,sys,subprocess,itertools,tarfile
from pathlib import Path
p=Path.cwd();root=p/'evidence';sys.argv=[sys.argv[0],str(root)]
import oracle
scores={}
for policy,mode in itertools.product(('edf','llf'),('plain','traced')):
 n=policy+'-'+mode; d=root/('run-'+n);u=d/'uart.bin'
 details=oracle.run(n,policy)
 pub=subprocess.run(['python3',p/'checkout/tools/replay_native_deadline_service.py',u,'--expect','accepted'],capture_output=True); (d/'public.json').write_bytes(pub.stdout);assert pub.returncode==0,pub.stderr
 ev=[list(map(int,l.split('EVENT ')[1].split())) for l in u.read_text().splitlines() if 'RECURRING EVENT ' in l];E=details['epoch'];Q=6250000
 irqs=[r for r in ev if r[1]==1];assert [r[3] for r in irqs]==list(range(len(irqs))) and all(r[6]==30 and r[13]==E+r[3]*Q and 0<=r[2]-r[13]<Q for r in irqs)
 changes=[r for r in ev if r[5]!=4 and r[4]!=r[5]]
 windows=[dict(t=r[2],events=[z[0] for z in ev if r[2]<=z[2]<r[2]+Q],changes=[z[0] for z in changes if r[2]<=z[2]<r[2]+Q]) for r in ev]
 idle=[(E+(r[3]+1)*Q-r[16]) for r in ev if r[4]==2 and r[5]==3]
 assert len(idle)==2 and min(idle)>0 and ev[0][5]==int(policy=='llf')
 results=dict(oracle=details,public=json.loads(pub.stdout),windows=windows,peak_entries=max(len(x['events']) for x in windows),peak_changes=max(len(x['changes']) for x in windows),whole_changes=len(changes),adjacent_dwell=[b[2]-a[2] for a,b in zip(changes,changes[1:])],lateness=[r[2]-r[13] for r in irqs],idle_residual=idle)
 scores[n]=results;print(n,[results[k] for k in ('peak_entries','peak_changes','whole_changes')],max(results['lateness']),details['margin'],details['restored'],flush=True)
(p/'scores.json').write_text(json.dumps(scores,indent=2))
