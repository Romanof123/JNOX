from pathlib import Path
import re,json,zipfile,tarfile,hashlib,subprocess,sys
p=Path.cwd(); docs=p/'checkout/docs/evidence';zz=p/'archive';zz.mkdir(exist_ok=True)
for f in [*docs.glob('deadline*.zip'),docs/'cooperative-deadline-combined.zip',*docs.glob('native-edf*first.tar.gz'),*docs.glob('native-llf*first.tar.gz'),docs/'native-deadline-service-first.tar.gz']:
 d=zz/f.name.split('.')[0];d.mkdir(exist_ok=True)
 if f.suffix=='.zip':
    with zipfile.ZipFile(f) as t:assert t.testzip() is None;t.extractall(d)
 else:
    with tarfile.open(f) as t:t.extractall(d,filter='data')
 print(f.name,hashlib.sha256(f.read_bytes()).hexdigest(),sum(x.is_file() for x in d.rglob('*')),flush=True)
for n in ['004','005','015','048']:
 for f in docs.glob('evd-'+n+'*.json'):
    r=json.loads(f.read_text()); print(f.name,str(list(r)[:15]),flush=True)
