import json,struct,subprocess,re,itertools,hashlib
from pathlib import Path
p=Path.cwd();d=p/'checkout/docs/evidence';h=p/'archive';results={}
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def sh(args):return subprocess.check_output(args,text=True)
for pol in ('edf','llf'):
 for mode in ('plain','traced'):
    n=pol+'-'+mode;r=p/'evidence'/('run-'+n);u=(r/'uart.bin').read_text().splitlines()
    fields=lambda k:[list(map(int,l.split(' '+k+' ')[1].split())) for l in u if 'RECURRING '+k+' ' in l]
    _,epoch,q,*_=fields('CONFIG')[0];rows=fields('EVENT');rem={};ready=[];owner=None;out=[]
    for row in rows:
        i,kind,t,k,src,dst,op=row[:7]
        if kind==1:
            if owner is not None:rem[owner]=max(1,rem[owner]-1)
            if k==0:rem.update({0:1,1:4});ready.extend([0,1])
            if k in (1,3):
                if owner is not None:ready.insert(0,owner);owner=None
        elif src in (0,1):
            assert owner==src;del rem[src];owner=None
        ranks={j:([12,13][j] if pol=='edf' else [12,13][j]-k-rem[j]) for j in rem}
        if k not in (1,3) and (ready or owner is not None):
            candidate=min(ready,key=ranks.get) if ready else None
            if candidate is not None and (owner is None or ranks[candidate]<ranks[owner]):
                ready.remove(candidate)
                if owner is not None:ready.append(owner)
                owner=candidate
            assert dst==owner
        if dst!=4:
            assert row[20:22]==[rem.get(j,2**64-1) for j in range(2)] and row[22]==sum((j+1)*16**bit for bit,j in enumerate(reversed(ready)))
        out.append(dict(row=i,remaining=rem.copy(),ranks=ranks,ready=ready.copy(),selected=dst))
    intervals=[]
    for a in range(16):
      for b in range(a+1,17):
        demand=sum(cost for due,cost in [(12,1),(13,4)] if a==0 and due<=b)
        supply=sum(k not in (1,3) for k in range(a,b))
        assert demand<=supply;intervals.append([a,b,demand,supply])
    results[n]={'fifo':out,'supply_intervals':intervals,'endpoint_predicate':[{'t':epoch+12*q+i,'D':epoch+12*q,'late':epoch+12*q+i>epoch+12*q} for i in (-1,0,1)]}
(p/'operands.json').write_text(json.dumps(results,indent=2))
# Replay the surviving corrected linked command rows, independently preserving the missing first.
for policy,mode,ref in itertools.product(('edf','llf'),('plain','trace'),('','-refuse')):
 name='ordinary-'+policy+'-supply'+ref
 case=h/'deadline-supply-command-replay/second'/(name+'-'+mode)
 raw=next((f for f in case.iterdir() if f.name.startswith('uart')),None)
 if raw:
    cmd=['python3',str(p/'checkout/tools/deadline_supply_replay.py'),name,str(raw)]+(['--plain'] if mode=='plain' else [])
    o=subprocess.run(cmd,capture_output=True);print(case.name,o.returncode,raw.name);assert o.returncode==0,o.stderr
    (p/('095-'+case.name+'.json')).write_bytes(o.stdout)
for nn in ('004','005','015','015-first'):
 r=json.loads((d/('evd-'+nn+'.json')).read_text())
 if nn=='005':
    assert hashlib.sha256(bytes.fromhex(r['uart_hex'])).hexdigest()==r['uart_sha256']
 if nn.startswith('015'):
    for c in r.get('clocks',[]):
        assert all(z['observed']-z['expected']==z['late_counts'] and z['expected']==c['origin']+z['tick']*c['interval'] for z in c['samples'])
 print(nn,'record keys',list(r))
