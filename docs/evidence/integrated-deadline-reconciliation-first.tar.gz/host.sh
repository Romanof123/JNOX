set -u
cd ~/iv350
export PATH="$HOME/.cargo/bin:$PATH" RUSTUP_TOOLCHAIN=1.95.0
rustc --test --edition=2024 checkout/tools/scheduling_tests.rs -o schedule-host > host-build.log 2>&1 && ./schedule-host > host.log; echo schedule=$?
rustc --test --edition=2024 --cfg jnox_ordinary_deadline checkout/tools/deadline_supply_tests.rs -o supply-host > supply-build.log 2>&1 && ./supply-host > supply-host.log; echo supply=$?
sed "s@../edf48-src/@checkout/@g" archive/edf48/controls.rs > controls_current.rs
rustc --edition 2024 --cfg jnox_ordinary_deadline -Awarnings controls_current.rs -o active-controls > controls-build.log 2>&1 && ./active-controls > controls-current.log; echo original_controls=$?
python3 archive/native-edf-applications-first/score.py > score117.log 2>&1; echo 117=$?
python3 archive/native-llf-applications-first/report.py > score121.log 2>&1; echo 121=$?
tail -2 host.log; tail -2 supply-host.log; head -5 controls-build.log
