from elftools.elf.elffile import ELFFile
from pathlib import Path
import json,hashlib
base=Path.home()
for nm in ['A.elf','B.elf','S.elf','edf/kernel.elf','llf/kernel.elf']:
 def sections(d):
    with (base/d/'evidence'/nm).open('rb') as f:return {s.name:(s['sh_addr'],s['sh_size'],hashlib.sha256(s.data()).hexdigest()) for s in ELFFile(f).iter_sections() if s['sh_flags']&2}
 a,b=sections('ind319'),sections('iv350'); print(nm,{k:[a.get(k),b.get(k)] for k in a.keys()|b.keys() if a.get(k)!=b.get(k)})
