#[path="checkout/kernel/src/ready_queue.rs"] mod ready_queue;
#[path="checkout/kernel/src/deadline_policy.rs"] mod deadline_policy;
#[path="checkout/kernel/src/deadline_jobs.rs"] mod deadline_jobs;
mod ordinary_deadline {pub fn counter()->u64 {0}}
use deadline_jobs::*;
use deadline_policy::*;
use DeadlinePolicy::*;
use Refusal::*;
fn main(){
 let e=EDF[0];let t=|jobs:&[Job],want|assert_eq!(admit(Edf,jobs,62500000,123),want);
 t(&[],Err(Table));t(&[e;4],Err(Table));t(&[Job{id:3,..e}],Err(Table));t(&[e,e],Err(Duplicate));t(&[Job{entry:None,..e}],Err(Entry));t(&[Job{cost:0,..e}],Err(Cost));t(&[Job{deadline:0,..e}],Err(Deadline));t(&[Job{deadline:17,..e}],Err(Deadline));t(&[Job{milliseconds:0,..e}],Err(Grid));t(&[Job{milliseconds:u64::MAX,..e}],Err(Overflow));t(&[Job{cost:9,..e}],Err(Demand));t(&[Job{cost:8,..e}],Ok(()));t(&EDF,Ok(()));
 assert_eq!(admit(Llf,&LLF,62500000,123),Err(Miss));assert_eq!(admit(Llf,&LLF[..2],62500000,123),Ok(()));
 for hz in [0,11]{assert_eq!(admit(Edf,&EDF,hz,123),Err(Grid));}
 assert_eq!(admit(Edf,&EDF,62500000,u64::MAX),Err(Overflow));assert_eq!(absolute(0,u64::MAX,2),Err(Overflow));
 for policy in [Edf,Llf] {let mut s=DeadlineScheduler::<3>::new(policy,0,1).unwrap();s.release(0,2,1,5).unwrap();s.release(0,0,1,5).unwrap();assert_eq!(s.decide(0).unwrap(),Some(2));assert_eq!(s.decide(0).unwrap(),Some(2));s.release(0,1,8,1).unwrap();assert_eq!(s.decide(0).unwrap(),Some(2));assert_eq!(s.laxity(1),Some(-7));assert_eq!(s.decide(1).unwrap(),Some(1));}
 println!("PASS compiled frozen admission and scheduling controls");
}
