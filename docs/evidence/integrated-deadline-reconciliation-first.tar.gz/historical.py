import json,subprocess,re,sys,tarfile,base64,io,hashlib
from pathlib import Path
p=Path.cwd();d=p/'checkout/docs/evidence';ar=p/'archive'; sr=ar/'native-deadline-service-first/independent-319-verifier'
def call(cmd,cwd=None):
 r=subprocess.run(cmd,cwd=cwd,capture_output=True);return r.returncode,r.stdout.decode(errors='replace'),r.stderr.decode(errors='replace')
a=json.loads((d/'evd-048.json').read_text())['archive'];raw=b''.join(base64.b64decode(json.loads((d/n).read_text())['base64']) for n in a['parts']);assert hashlib.sha256(raw).hexdigest()==a['sha256']
ed=ar/'edf48';ed.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:xz') as t:t.extractall(ed,filter='data')
for line in (ed/'MANIFEST.sha256').read_text().splitlines():
 h,n=line.split('  ./',1);assert hashlib.sha256((ed/n).read_bytes()).hexdigest()==h
for name,command,wd in [('48-oracle',['python3','-B','verify.py'],ed),('48-cross',['python3','-B','cross.py'],ed),('128-archived',['python3','oracle.py',str(sr)],sr),('124-archive',['python3','score.py'],ar/'native-edf-block-input-first')]:
 rc,out,err=call(command,wd);(p/(name+'.log')).write_text(out+err);print(name,rc,flush=True)
for nm in ['edf-cap','llf-cap','edf-demand','llf-demand','alternate-plain']:
 with tarfile.open(sr/(nm+'.tar.gz')) as t:data=t.extractfile('uart.bin').read()
 dest=p/('old-'+nm+'.uart');dest.write_bytes(data)
 rc,out,err=call(['python3',str(p/'checkout/tools/replay_native_deadline_service.py'),str(dest),'--expect',('cap' if nm.endswith('cap') else 'supply' if nm.endswith('demand') else 'accepted')]);assert rc==0,err;(p/('old-'+nm+'.json')).write_text(out)
u=(p/'evidence/run-edf-plain/uart.bin').read_text().splitlines()
for nm,lines in [('missing-end',[l for l in u if 'RECURRING END' not in l]),('missing-event',[l for l in u if ' EVENT 4 ' not in l]),('invalid-irq',[l.replace(' 30 ',' 29 ',1) if ' EVENT 2 ' in l else l for l in u])]:
 dest=p/(nm+'.uart');dest.write_text('\n'.join(lines)+'\n');rc,out,err=call(['python3',str(p/'checkout/tools/replay_native_deadline_service.py'),str(dest)]);print(nm,rc,err.strip());assert rc!=0
for n in [-1,0,1]: assert ((100+n)>100)==(n==1)
