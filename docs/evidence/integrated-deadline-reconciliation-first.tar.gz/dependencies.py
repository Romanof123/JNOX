import re,json,subprocess,base64,hashlib
from pathlib import Path
p=Path.cwd();g=p/'checkout';dst=p/'dependencies';dst.mkdir(exist_ok=True)
fixtures={'004':('c0ca5ac1',['kernel/src/dispatch_policy.rs','kernel/src/ready_queue.rs']),'005':('2d5b5ff',['kernel/src/sched.rs','kernel/src/sched.S','kernel/src/dispatch_policy.rs']),'015':('21d82d4',['kernel/src/deadline.rs','kernel/src/deadline.S','kernel/src/deadline_policy.rs']),'048':('1481074',['kernel/src/ordinary_deadline.rs','kernel/src/deadline_policy.rs','kernel/src/deadline_jobs.rs']),'095':('608de71',['kernel/src/ordinary_deadline.rs','kernel/src/deadline_jobs.rs','tools/deadline_supply_replay.py']),'100':('4c62e02',['kernel/src/ordinary_deadline.rs','kernel/src/deadline_jobs.rs']),'104':('4ecce4b',['kernel/src/deadline_recurring.rs','kernel/src/ordinary_deadline.rs','kernel/src/deadline_jobs.rs']),'117':('ffc2e323',['kernel/src/native_edf.rs','kernel/src/native_el0_vectors.S','kernel/src/native_el0_mmu.rs','examples/native-edf']),'121':('af022d6',['kernel/src/native_edf.rs','kernel/src/deadline_numeric.rs','examples/native-llf']),'124':('424a63f',['kernel/src/native_edf.rs','kernel/src/native_el0_vectors.S','examples/native-edf']),'128':('0054957',['kernel/src/native_deadline_recurring.rs','kernel/src/deadline_policy.rs','kernel/src/deadline_numeric.rs','kernel/src/native_el0.rs','kernel/src/native_el0_mmu.rs','kernel/src/native_el0_vectors.S','kernel/build.rs','sdk/native-aarch64/io.c','tools/build_native_el0.py','tools/replay_native_deadline_service.py'])}
for k,(ref,paths) in fixtures.items():
 (dst/(k+'.diff')).write_bytes(subprocess.check_output(['git','diff',ref,'HEAD','--',*paths],cwd=g))
 (dst/(k+'.index')).write_bytes(subprocess.check_output(['git','ls-tree','-r',ref,'--',*paths],cwd=g)+b'\nCURRENT\n'+subprocess.check_output(['git','ls-tree','-r','HEAD','--',*paths],cwd=g))
ev=json.load(open(g/'docs/evidence/evd-005.json'))
for key, b in ev['raw_base64'].items():
 row=base64.b64decode(b); (dst/('005-'+key+'.bin')).write_bytes(row)
for n in ['edf','llf']:
 dis=(p/'evidence'/n/'kernel.dis').read_text(); writes=[l for l in dis.splitlines() if re.search(r'msr\s+cntp_(?:cval|tval)_el0',l)];assert len(writes)==2 and all(a in l for a,l in zip(('402039b8','40204148'),writes))
for app in 'ABS':
 assert not re.search(r'msr\s+cntp_(?:cval|tval)_el0',(p/'evidence'/(app+'.elf.dis')).read_text(),re.I)
print('Archived and current per-fixture source trees and differences stored; two kernel compare writers, no user/relative writer.')
