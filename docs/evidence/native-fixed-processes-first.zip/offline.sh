#!/bin/bash
set -euo pipefail
D=/mnt/d/codex/jnox294-independent-evidence
work=$HOME/jnox294-independent-first
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup
export PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH"
exec 9>"$D/lane.lock"; flock -n 9
cd "$work/src"
rustc --edition=2021 --cfg jnox_native_el0 "$D/replay/main.rs" -o "$work/replay"
python3 "$D/check.py" "$work/replay" >"$D/outcomes.json"
