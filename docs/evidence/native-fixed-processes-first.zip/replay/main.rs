mod fixed_policy;
mod ready_queue;
use fixed_policy::{Fixed,Mode,Config,Action};
use std::io::{self,BufRead};
fn main() {
    let argv:Vec<String>=std::env::args().skip(1).collect();
    let q:u64=argv[0].parse().unwrap();
    let cfg:Vec<_>=argv[1..].iter().map(|v|Config{priority:v.parse().unwrap(),delay:0}).collect();
    let mut policy:Option<Fixed>=None;
    let absent=u64::MAX;
    for line in io::stdin().lock().lines().map(Result::unwrap) {
        let Some(rest)=line.strip_prefix("NATIVE FIXED EVENT ") else {continue};
        let v:Vec<u64>=rest.split_whitespace().map(|s|s.parse().unwrap()).collect();
        assert_eq!(v.len(),21);
        if let Some(p)=policy.as_mut() {
            assert_eq!(p.current().map_or(absent,|x|x as u64),v[3]);
            assert_eq!(p.next_wake().unwrap_or(0),v[9]);
            assert_eq!(p.expiry().unwrap().unwrap_or(0),v[10]);
            let a=match v[1]{1=>Action::Yield,2=>Action::Sleep(v[2]),3=>Action::Exit,4|5=>Action::Poll,_=>panic!()};
            assert_eq!(p.event(v[0],a),Some(true));
        } else {
            assert_eq!((v[1],v[3],v[9],v[10]),(0,absent,0,0));
            policy=Fixed::new(&cfg,if q==0 {Mode::Fifo}else{Mode::RoundRobin(q)},v[0]);
        }
        let p=policy.as_ref().unwrap();
        assert_eq!(p.current().map_or(absent,|x|x as u64),v[4]);
        assert_eq!(p.deadline().unwrap().unwrap_or(0),v[11]);
        let mut ready=[absent;3]; p.ready_order(&mut ready); assert_eq!(&ready,&v[12..15]);
        for i in 0..cfg.len(){assert_eq!(p.service(i),Some(v[15+i]));assert_eq!(p.remaining(i),v[18+i]);}
    }
    assert!(policy.unwrap().finished());
}
