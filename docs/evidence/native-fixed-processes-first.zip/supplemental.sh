#!/bin/bash
set -euo pipefail
D=/mnt/d/codex/jnox294-independent-evidence
work=$HOME/jnox294-independent-first
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup CARGO_BUILD_JOBS=1
export PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH"
exec 9>"$D/lane.lock"
flock -n 9
exec >>"$D/supplemental.log" 2>&1
set -x
cd "$work/src"
test "$(git rev-parse HEAD)" = c7f88eadf582aba0d350bb444a553426ef01be37
sha256sum -c "$D/inputs/frozen.sha256"
source <(sed -n '/^run(){/,/^}/p' "$D/first.sh")
A="$D/inputs/prime_low.elf"; B="$D/inputs/fixed.elf"; H="$D/inputs/calendar_report.elf"
run rr-equal-1250000 --elf "$A" --peer-elf "$B" --policy rr --priority 3 --peer-priority 3 --quantum-ticks 1250000
run rr-residual-1250000 --elf "$H" --peer-elf "$A" --peer-elf "$B" --policy rr --priority 7 --peer-priority 3 --peer-priority 3 --quantum-ticks 1250000