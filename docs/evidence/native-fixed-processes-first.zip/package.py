from pathlib import Path
import hashlib,zipfile
D=Path(__file__).resolve().parent
Z=D.parent/'jnox294-independent-evidence.zip'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=sorted((f for f in D.rglob('*') if f.is_file() and f.relative_to(D).parts[0] not in ('src','lane.lock','SHA256SUMS')),key=lambda f:f.relative_to(D).as_posix())
(D/'SHA256SUMS').write_text(''.join(f'{digest(f)}  {f.relative_to(D).as_posix()}\n' for f in files),encoding='utf-8')
with zipfile.ZipFile(Z,'w') as z:
 for f in [*files,D/'SHA256SUMS']:
  i=zipfile.ZipInfo(f.relative_to(D).as_posix(),(2026,11,25,0,0,0));i.external_attr=0o100644<<16
  z.writestr(i,f.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 for f in files:assert hashlib.sha256(z.read(f.relative_to(D).as_posix())).hexdigest()==digest(f)
print(len(files)+1,Z.stat().st_size,digest(Z))
Z.with_suffix('.zip.sha256').write_text(digest(Z)+'  '+Z.name+'\n')

