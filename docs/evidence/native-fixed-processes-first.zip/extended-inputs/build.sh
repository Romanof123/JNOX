#!/bin/sh
# Usage: sh build.sh /path/to/j-nox /new/output/directory
set -eu
[ "$#" -eq 2 ] || exit 2
repo=$(CDPATH= cd -- "$1" && pwd)
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir "$2"
out=$(CDPATH= cd -- "$2" && pwd)
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT
cp -R "$src/rust" "$stage/rust"
ln -s "$repo" "$stage/jnox"
for name in prime_low prime_low_yield calendar_report; do
    sh "$repo/sdk/native-aarch64/build.sh" "$src/$name.c" "$out/$name.elf"
done
sh "$repo/sdk/native-aarch64/build-rust.sh" "$stage/rust/Cargo.toml" "$out/prime_high.elf"
