# Extended prime inputs / 확장 소수 입력

Freeze before any boot. Record source and ELF digests, repository commit and toolchain. From this directory use `sha256sum -c SHA256SUMS`, then `sh build.sh /absolute/path/to/j-nox /new/output/directory` in a POSIX shell with the native SDK toolchain. The launcher stages the Rust package beside a temporary symlink to that checkout. Existing output directories are rejected.

첫 부팅 전 입력을 고정한다. 위 명령으로 원본 해시를 확인하고 새 경로에 빌드한다. 저장소 커밋, 도구 버전, 생성 ELF 해시와 패키지 명령을 기록한다.

| ELF | Fixed calculation / 고정 계산 | Full result | Exit |
| --- | --- | ---: | ---: |
| prime_low | Count primes in [2, 5,000,000) | 348513 | 25 |
| prime_low_yield | Same count, yield once after calculation | 348513 | 25 |
| prime_high | Count primes in [5,000,000, 10,000,000) | 316066 | 90 |
| calendar_report | Original HIGH, five-ms absolute sleep then leap years in [1970, 2100) | 32 | 32 |

Counts follow π(5,000,000) = 348513 and π(10,000,000) = 664579. Both boundaries are composite. Each prime worker checks its full result and returns the count modulo 127 on success. Match interrupted PCs against count_low_primes and count_high_primes and sample each worker’s private_result.

Use Q = 12,500,000 physical counter ticks for RR. Score these ELFs separately from the original binaries and Q = 1,250,000 cohort. Retain first raw output even if a gate misses. Apply every gate in docs/native-fixed-processes.en-ko.md at dc91fb6dc1b7c5ef8d1aeb56ba340414d557ddb4. Equal FIFO covers yield and direct exit. Reuse direct-exit binaries for equal RR A→B→A. Higher wake uses both slot orders and both policies. For residual RR package HIGH/A/B at 7/3/3. At A start S, HIGH wake W and HIGH exit X, require 0 < W−S < Q, R = Q−(W−S), first compare min(HIGH deadline, S+Q), resume A at its interrupted PC with B waiting and compare X+R, then a real IRQ selecting B in [X+R, X+Q). Require later A return and all expected exits, replay decisions and preserve original captures. Classify a simultaneous wake/expiry only on equal logical deadlines.

확장 입력의 RR 퀀텀은 물리 카운터 12,500,000틱이다. 기존 입력 및 1,250,000틱 결과와 따로 판정한다. 최초 원본 출력을 보존하고 위 설계의 FIFO 양보·종료, RR 교대, 두 슬롯 순서의 상위 기상, 세 프로세스 잔여 퀀텀 기준을 그대로 적용한다. ELF별 중단 주소·개별 누계·종료값을 확인한다. 위 부등식, 비교기, IRQ, 재개, 재생 판정을 모두 충족해야 잔여 퀀텀 사례를 인정한다.
