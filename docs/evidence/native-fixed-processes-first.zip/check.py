import hashlib,json,pathlib,re,subprocess,sys
D=pathlib.Path(__file__).resolve().parent
U=2**64-1
def digest(file):return hashlib.sha256(file.read_bytes()).hexdigest()
def main():
 summary={}
 for r in sorted(p for p in (D/'runs').iterdir() if p.is_dir()):
  m=json.loads((r/'manifest.json').read_text())
  raw=(r/'uart.log').read_text()
  assert m['commit']=='c7f88eadf582aba0d350bb444a553426ef01be37' and not m['tracked_changes']
  assert digest(r/'kernel.elf')==m['kernel_elf_sha256']
  for s in m['slots']:assert digest(r/s['elf'])==s['elf_sha256'] and s['elf_sha256'] in raw
  if m['policy']=='cooperative':
   assert ('NATIVE EL0 EXIT 37' in raw if r.name=='warmup' else all(t in raw for t in ('EXIT PID 0 17','EXIT PID 1 29')))
   summary[r.name]={'compatibility':True};continue
  ext=r.name.startswith('ext-')
  expected={'prime_low.elf':(25 if ext else 12),'prime_low_yield.elf':(25 if ext else 12),'fixed.elf':77,'prime_high.elf':90,'calendar_report.elf':32}
  names=[pathlib.Path(s['input']['path']).name for s in m['slots']]
  source=D/('extended-elf' if ext else 'inputs')
  assert all(digest(source/n)==s['elf_sha256'] for s,n in zip(m['slots'],names))
  statuses=sorted((int(a),int(b)) for a,b in re.findall(r'NATIVE EL0 EXIT PID (\d+) (\d+)',raw))
  assert statuses==list(enumerate(expected[n] for n in names))
  assert raw.count('NATIVE FIXED DROPPED 0')==1
  rows=[list(map(int,l.split()[3:])) for l in raw.splitlines() if l.startswith('NATIVE FIXED EVENT ')]
  q=m['quantum_ticks'] or 0
  subprocess.run([sys.argv[1],str(q),*(str(s['priority']) for s in m['slots'])],input=raw,text=True,check=True)
  frames={}; total=[0]*3; switches=[]; ties=[]; late=[]
  for idx,v in enumerate(rows):
   t,reason,arg,prev,nxt=v[:5]
   if idx and prev!=U:total[prev]+=t-rows[idx-1][0]
   assert total==v[15:18]
   if prev!=U:frames[prev]=v[5:7]
   if nxt in frames:assert v[7:9]==frames[nxt]
   if reason==4:
    assert rows[idx-1][11] and t>=rows[idx-1][11]
    w,e=v[9:11]
    if w and e and t>=max(w,e):(ties if w==e else late).append(idx)
    if prev!=nxt:
     switches.append((prev,nxt))
     if names[prev] in ('prime_low.elf','fixed.elf','prime_high.elf'):
      sym='count_low_primes' if names[prev]=='prime_low.elf' else 'count_high_primes'
      table=(source/(names[prev]+'.map')).read_text()
      match=re.search(r'\d+:\s+([\da-f]+)\s+(\d+) FUNC\s+GLOBAL\s+DEFAULT\s+\d+ '+sym+r'\b',table)
      addr=int(match[1],16);assert addr<=v[5]<addr+int(match[2])
  out={'rows':len(rows),'irq_switches':switches,'service':total,'tie_rows':ties,'late_distinct_rows':late,'statuses':statuses}
  short=r.name.removeprefix('ext-')
  if short=='fifo-exit':assert [v[1] for v in rows]==[0,3,3]
  if short=='fifo-yield':assert [(v[1],v[3],v[4]) for v in rows[1:]]==[(1,0,1),(3,1,0),(3,0,U)]
  if short.startswith('rr-equal'):
   out['alternation']=switches[:2]==[(0,1),(1,0)]
   assert out['alternation']==(r.name!='rr-equal')
  if 'high-' in short or 'residual' in short:
   high=names.index('calendar_report.elf');a=names.index('prime_low.elf')
   s=next(v for v in rows if v[1]==2);w=next(v for v in rows if v[1]==4 and v[4]==high);x=next(v for v in rows if v[1]==3 and v[3]==high)
   assert s[3:5]==[high,a] and w[3]==a and w[9]==s[0]+s[2] and w[0]>=w[9] and x[4]==a and x[7:9]==w[5:7]
   out['wake']=[s[0],w[9],w[0],x[0]]
   if 'residual' in short:
    left=q-(w[0]-s[0]);assert 0<left<q and s[11]==min(w[9],s[0]+q)
    assert w[12:14]==[a,2] and x[12]==2 and x[11]==x[0]+left
    after=rows[rows.index(x)+1];ok=after[1]==4 and after[3:5]==[a,2] and x[11]<=after[0]<x[0]+q
    if ok:assert (2,a) in switches
    out['residual']={'R':left,'compare':x[11],'next':after[0],'limit':x[0]+q,'qualified':ok}
    assert ok==(r.name!='rr-residual')
  if ext:
   records=[v['counts'] for l in (r/'monitor.jsonl').read_text().splitlines() if isinstance(v:=json.loads(l),dict)]
   finals=[{'prime_low.elf':348513,'prime_low_yield.elf':348513,'prime_high.elf':316066,'calendar_report.elf':32}[n] for n in names]
   assert records[-1]==finals
   for i,n in enumerate(names):
    a=[c[i] for c in records]
    assert all(y>=x for x,y in zip(a,a[1:]))
    if 'prime' in n:assert len(set(a))>=3
   out['distinct_observed_values']=[len(set(c[i] for c in records)) for i in range(len(names))]
   out['private_final']=records[-1]
  summary[r.name]=out
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
