import json,subprocess,pathlib,sys
D=pathlib.Path(__file__).resolve().parent
bad=D/'rejected';bad.mkdir()
a=str(D/'inputs'/'prime_low.elf')
cases={
 'unknown-policy':['--policy','other'], 'orphan-priority':['--priority','1'],
 'missing-primary':['--policy','fifo'],'missing-peer':['--peer-elf',a,'--policy','fifo','--priority','3'],
 'extra-peer-priority':['--policy','fifo','--priority','3','--peer-priority','3'],
 'bad-priority':['--policy','fifo','--priority','256'],'negative-priority':['--policy','fifo','--priority','-1'],
 'fifo-quantum':['--policy','fifo','--priority','3','--quantum-ticks','2'],
 'rr-no-quantum':['--policy','rr','--priority','3'],'zero-q':['--policy','rr','--priority','3','--quantum-ticks','0'],
 'huge-q':['--policy','rr','--priority','3','--quantum-ticks',str(2**63)],
 'repeated-policy':['--policy','rr','--policy','fifo','--priority','3'],
 'fourth-slot':['--peer-elf',a]*3,'conflicting-input':['--source','examples/portability/clock_checksum.c']}
for name,args in cases.items():
 out=bad/(name+'-package');cmd=[sys.executable,'tools/build_native_el0.py','--out',str(out),'--elf',a,*args]
 p=subprocess.run(cmd,capture_output=True,text=True)
 (bad/(name+'.json')).write_text(json.dumps(dict(command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2))
 assert p.returncode==2 and not out.exists()
