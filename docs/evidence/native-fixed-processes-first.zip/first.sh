#!/bin/bash
set -euo pipefail
D=/mnt/d/codex/jnox294-independent-evidence
work=$HOME/jnox294-independent-first
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup
export PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH"
mkdir -p "$work" "$D/inputs" "$D/runs"
exec 9>"$D/lane.lock"
flock -n 9
exec >>"$D/wrapper.log" 2>&1
set -x
sha=c7f88eadf582aba0d350bb444a553426ef01be37
git init -q "$work/src"
cd "$work/src"
git fetch -q /mnt/d/codex/j-nox/.git "$sha"
git -c core.autocrlf=false checkout --detach FETCH_HEAD
test "$(git rev-parse HEAD)" = "$sha"
export CARGO_TARGET_DIR="$work/user-target" CARGO_BUILD_JOBS=1
i="$D/inputs"
git archive HEAD examples/native-fixed examples/native-fixed-rust examples/native-cooperative-rust examples/portability sdk/native-aarch64 tools/build_native_el0.py >"$i/source.tar"
qemu-system-aarch64 --version; rustc -vV; clang --version
for a in prime_low prime_low_yield calendar_report; do sh sdk/native-aarch64/build.sh "examples/native-fixed/$a.c" "$i/$a.elf"; done
for a in fixed cooperative; do sh sdk/native-aarch64/build-rust.sh "examples/native-$a-rust/Cargo.toml" "$i/$a.elf"; done
for a in "$i"/*.elf; do aarch64-linux-gnu-objdump -d "$a" >"$a.dis"; readelf -lWs "$a" >"$a.map"; done
sha256sum "$i"/*.elf "$i/source.tar" "$D/first.sh" >"$i/frozen.sha256"
python3 - <<'PY'
p=bytearray([1])*2000000
p[:2]=bytes(2)
for n in range(2,1415):
 if p[n]: p[n*n::n]=bytes(len(p[n*n::n]))
counts=[sum(p[:1000000]),sum(p[1000000:])]
assert counts==[78498,70435] and [v%127 for v in counts]==[12,77]
assert sum(y%4==0 and (y%100!=0 or y%400==0) for y in range(1970,2100))==32
PY
run(){
 name=$1; shift
 r="$D/runs/$name"
 mkdir "$r"
 printf '%q ' python3 tools/build_native_el0.py --out "$work/$name" "$@" >"$r/command"
 if ! python3 tools/build_native_el0.py --out "$work/$name" "$@" >"$r/package.stdout" 2>"$r/package.stderr"; then cp "$work/$name/build.log" "$r/" || true; echo FAIL >"$r/result"; return; fi
 cp "$work/$name/"{*.elf,manifest.json,build.log} "$r/"
 set +e
 timeout 5s qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -accel tcg -m 128M -nodefaults -display none -monitor none -serial stdio -kernel "$r/kernel.elf" </dev/null >"$r/uart.log" 2>"$r/qemu.stderr"
 code=$?
 set -e
 echo "$code" >"$r/qemu.status"
 (cd "$r" && sha256sum * >../"$name.sha256")
}
A="$i/prime_low.elf"; B="$i/fixed.elf"; H="$i/calendar_report.elf"
run warmup
run cooperative --source examples/portability/native_cooperative_report.c --peer-elf "$i/cooperative.elf"
for pol in fifo rr; do
 q=(); if [[ $pol == rr ]]; then q=(--quantum-ticks 12500000); fi
 if [[ $pol == fifo ]]; then
 run fifo-exit --elf "$A" --peer-elf "$B" --policy fifo --priority 3 --peer-priority 3
 run fifo-yield --elf "$i/prime_low_yield.elf" --peer-elf "$B" --policy fifo --priority 3 --peer-priority 3
 run rr-equal --elf "$A" --peer-elf "$B" --policy rr --priority 3 --peer-priority 3 --quantum-ticks 12500000
 fi
 run "$pol-high-first" --elf "$H" --peer-elf "$A" --policy "$pol" --priority 7 --peer-priority 3 "${q[@]}"
 run "$pol-high-second" --elf "$A" --peer-elf "$H" --policy "$pol" --priority 3 --peer-priority 7 "${q[@]}"
done
run rr-residual --elf "$H" --peer-elf "$A" --peer-elf "$B" --policy rr --priority 7 --peer-priority 3 --peer-priority 3 --quantum-ticks 12500000
rustc --test tools/fixed_runtime_tests.rs -o "$work/fixed_runtime_tests"
"$work/fixed_runtime_tests" --test-threads=1 >"$D/linked-tests.log"