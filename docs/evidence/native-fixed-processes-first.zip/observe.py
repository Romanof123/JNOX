import sys, pathlib, subprocess, re, json, time, os
r=pathlib.Path(sys.argv[1])
m=json.loads((r/'manifest.json').read_text())
n=len(m['slots'])
sym=subprocess.check_output(['aarch64-linux-gnu-nm','-S',str(r/'kernel.elf')],text=True)
line=next(l for l in sym.splitlines() if '6SPACES' in l)
base,size=[int(v,16) for v in line.split()[:2]]
stride=5*4096+0x400000+0x10000
assert size==stride*n
addrs=[base+k*stride+5*4096+0x2000 for k in range(n)]
args=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(r/'uart.log'),'-kernel',str(r/'kernel.elf')]
(r/'monitor-command.json').write_text(json.dumps(dict(argv=args,symbol=line,addresses=addrs),indent=2))
with (r/'qemu.stderr').open('w') as err,(r/'monitor.jsonl').open('w') as log:
 with subprocess.Popen(args,text=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as p:
  try:
   def read():
    while True:
     line=p.stdout.readline()
     if not line: raise RuntimeError('monitor closed')
     msg=json.loads(line)
     print(json.dumps([time.monotonic_ns(),msg]),file=log,flush=True)
     if 'event' not in msg:return msg
   def cmd(command,arguments={}):
    req=dict(execute=command,arguments=arguments)
    print(json.dumps(req),file=p.stdin,flush=True)
    reply=read()
    assert 'return' in reply,reply
    return reply['return']
   read();cmd('qmp_capabilities')
   start=time.monotonic()
   while True:
    counts=[]
    for addr in addrs:
     result=cmd('human-monitor-command',{'command-line':f'xp /1wx 0x{addr:x}'})
     counts.append(int(result.split(':')[1].strip(),16))
    print(json.dumps({'counts':counts,'host_ns':time.monotonic_ns()}),file=log,flush=True)
    if (r/'uart.log').read_text().count('NATIVE EL0 EXIT PID')==n:break
    if time.monotonic()-start>12:raise TimeoutError('capture watchdog')
    time.sleep(.02)
   cmd('quit');p.wait(timeout=5)
  finally:
   if p.poll() is None:p.kill();p.wait()
  (r/'qemu.status').write_text(str(p.returncode)+'\n')
