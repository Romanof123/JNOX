#!/bin/bash
set -euo pipefail
D=/mnt/d/codex/jnox294-independent-evidence
work=$HOME/jnox294-independent-first
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup CARGO_BUILD_JOBS=1
export PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH"
exec 9>"$D/lane.lock"; flock -n 9
exec >>"$D/extended.log" 2>&1; set -x
cd "$work/src"; test "$(git rev-parse HEAD)" = c7f88eadf582aba0d350bb444a553426ef01be37
rustc --edition=2021 --test tools/scheduling_tests.rs -o "$work/scheduling_tests"
"$work/scheduling_tests" fixed_runtime_tests --test-threads=1 >"$D/linked-tests.log"
cd "$D/extended-inputs"; sha256sum -c SHA256SUMS
echo '45880613963161fc50eac75d98ffe17d67ab04b3e7ec19b5aeda5b29ac18eca0  SHA256SUMS' | sha256sum -c -
python3 - <<'PY'
p=bytearray([1])*10000000
p[:2]=bytes(2)
for n in range(2,3163):
 if p[n]: p[n*n::n]=bytes(len(p[n*n::n]))
counts=[sum(p[:5000000]),sum(p[5000000:])]
assert counts==[348513,316066] and [v%127 for v in counts]==[25,90]
print(counts)
PY
i="$D/extended-elf"
sh build.sh "$work/src" "$i"
cd "$work/src"
for a in "$i"/*.elf; do aarch64-linux-gnu-objdump -d "$a" >"$a.dis"; readelf -lWs "$a" >"$a.map"; done
sha256sum "$i"/*.elf "$D/observe.py" "$D/extended.sh" >"$i/frozen.sha256"
run(){
 name=ext-$1; shift; r="$D/runs/$name"; mkdir "$r"
 printf '%q ' python3 tools/build_native_el0.py --out "$work/$name" "$@" >"$r/command"
 if ! python3 tools/build_native_el0.py --out "$work/$name" "$@" >"$r/package.stdout" 2>"$r/package.stderr"; then cp "$work/$name/build.log" "$r/" || true; echo FAIL >"$r/result"; return; fi
 cp "$work/$name/"{*.elf,manifest.json,build.log} "$r/"
 python3 "$D/observe.py" "$r" || echo 'observer failed' >"$r/result"
 (cd "$r" && sha256sum * >../"$name.sha256")
}
A="$i/prime_low.elf"; B="$i/prime_high.elf"; H="$i/calendar_report.elf"
run fifo-exit --elf "$A" --peer-elf "$B" --policy fifo --priority 3 --peer-priority 3
run fifo-yield --elf "$i/prime_low_yield.elf" --peer-elf "$B" --policy fifo --priority 3 --peer-priority 3
run rr-equal --elf "$A" --peer-elf "$B" --policy rr --priority 3 --peer-priority 3 --quantum-ticks 12500000
for pol in fifo rr; do
 q=(); if [[ $pol == rr ]]; then q=(--quantum-ticks 12500000); fi
 run "$pol-high-first" --elf "$H" --peer-elf "$A" --policy "$pol" --priority 7 --peer-priority 3 "${q[@]}"
 run "$pol-high-second" --elf "$A" --peer-elf "$H" --policy "$pol" --priority 3 --peer-priority 7 "${q[@]}"
done
run rr-residual --elf "$H" --peer-elf "$A" --peer-elf "$B" --policy rr --priority 7 --peer-priority 3 --peer-priority 3 --quantum-ticks 12500000