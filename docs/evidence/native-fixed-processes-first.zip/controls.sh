#!/bin/bash
set -euo pipefail
D=/mnt/d/codex/jnox294-independent-evidence
work=$HOME/jnox294-independent-first
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup CARGO_BUILD_JOBS=1
export PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH"
exec 9>"$D/lane.lock"; flock -n 9
cd "$work/src"
exec >>"$D/controls.log" 2>&1;set -x
python3 "$D/rejections.py"
for app in fixed-ties fixed-late; do
 r="$D/linked-$app"; mkdir "$r"
 JNOX_BOARD=virt JNOX_PROFILE=fixed JNOX_APP="$app" CARGO_TARGET_DIR="$work/$app" python3 tools/build_kernel.py --arch aarch64 >"$r/build.log" 2>&1
 cp "$work/$app/aarch64-unknown-none/release/jnox-kernel" "$r/kernel.elf"
 set +e
 timeout 4s qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -accel tcg -m 128M -nodefaults -display none -monitor none -serial stdio -d int -D "$r/trace.log" -kernel "$r/kernel.elf" </dev/null >"$r/uart.log" 2>"$r/qemu.stderr"
 code=$?;set -e
 echo "$code" >"$r/qemu.status"
 (cd "$r" && sha256sum * >../"linked-$app.sha256")
done