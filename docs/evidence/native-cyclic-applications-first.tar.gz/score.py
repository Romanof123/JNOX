from pathlib import Path
import json,re,struct,bisect
D=Path.home()/'e324'
out={}
for name in (D/'order').read_text().split():
 R=D/'runs'/name
 u=(R/'uart.log').read_text()
 def rows(p):return [[int(w) for w in l.split()] for l in re.findall('^NATIVE '+p+' (.*)$',u,re.M)]
 a=rows('CYCLIC EVENT'); _,epoch,F,frame=rows('CYCLIC CONFIG')[0]
 assert rows('CYCLIC DROPPED')==[[0]] and rows('EL0 EXIT PID')==[[0,41],[1,42]]
 table=([(1,50),(2,50),(0,100),(1,50)] if name.startswith('Q') else [(0,100),(1,50),(2,50)])
 lens=[ms*F//1000 for _,ms in table]; assert sum(lens)==frame
 mem=(R/'space.raw').read_bytes()
 roots=[next(x[27] for x in a if x[5]==i) for i in range(2)]
 mask=0x0000fffffffff000;base=roots[0]&mask
 samples=[]; apps=[]
 for id,app in enumerate(('energy','density')):
  sym={m[-1]:int(m[0],16) for l in (D/(app+'.sym')).read_text().splitlines() if len(m:=l.split())>=3}
  def q(addr,size=8):
   page=roots[id]&mask
   for shift in (30,21,12):
    desc=struct.unpack_from('<Q',mem,page-base+8*((addr>>shift)&511))[0];assert desc&3==3;page=desc&mask
   return int.from_bytes(mem[page-base+(addr&4095):page-base+(addr&4095)+size],'little')
  v=lambda key:q(sym[key])
  blocks=v('private_blocks')
  prod=[q(sym['private_result']+8*i) for i in range(9 if id else 1)]
  assert prod==[blocks*c for c in ([1,8,28,56,70,56,28,8,1] if id else [5559680])] and blocks>0
  cnt=q(sym['record_count'],4); assert q(sym['record_overflow'],4)==0 and 1<cnt<=8192
  ss=[tuple(q(sym['records']+24*k+8*j) for j in range(3)) for k in range(cnt)]
  first=v('first_counter'); final=v('final_counter')
  assert v('observed_frequency')==F and final-first>=F*9//10 and ss[0]==(first,0,0)
  assert all(b[0]-p[0]>=(F+4999)//5000 and b[1]>p[1] for p,b in zip(ss,ss[1:]))
  assert all(w==n*(70 if id else 5559680) for _,n,w in ss)
  apps.append(dict(blocks=blocks,product=prod,count=cnt,first=first,final=final,frequency=F))
  if id: apps[-1].update(request_ns=v('request_ns'),observed_ns=v('observed_ns'))
  samples.append(ss)
 edges=[]; wake=[0,0]; exited=0; saved={}; lastseq=-1
 for k,x in enumerate(a[1:],1):
  prev=a[k-1]; _,kind,i,op,old,new=x[:6];pos=(i-epoch)%frame
  slot=bisect.bisect_right([sum(lens[:j+1]) for j in range(len(lens))],pos)
  f=(i-epoch)//frame; seq=f*len(lens)+slot; d=epoch+f*frame+sum(lens[:slot]); owner=table[slot][0]
  assert (x[7:13])==[seq,f,slot,owner,d,d+lens[slot]]
  assert x[13]==prev[14] and x[20]==max(0,seq-lastseq-1) and x[21]==max(0,i-prev[12])
  assert old==prev[5] and x[24]==prev[27]
  if kind==1:assert op==30
  if old<2:saved[old]=x[22:24]
  if kind==2 and op==1:exited|=1<<old
  if kind==2 and op==7:wake[old]=x[17+old];assert wake[old]>i
  woke=sum(1<<j for j in range(2) if wake[j] and wake[j]<=i)
  for j in range(2):
   if woke>>j&1:wake[j]=0
  ready=sum(1<<j for j in range(2) if not wake[j] and not exited>>j&1)
  target=3 if exited==3 else owner if owner<2 and ready>>owner&1 else 2
  assert [new,x[15],x[16],*x[17:20]]==[target,ready,woke,*wake,exited]
  assert x[14]==(0 if new==3 else min([x[12]]+[w for w in wake if w]))
  if new<2:
   assert x[27]==roots[new] and (x[25:27]==saved[new] if new in saved else x[25]==0x400000)
  if seq!=lastseq and seq<=3*len(table)+1 and not name.startswith('sleep'):
   j=a[k+1][2];r=x[28];obs=[v for v in samples[new] if r<=v[0]<j] if new<2 else []
   actual=obs[0][0] if obs else x[29] if new==2 else None
   work=obs[-1][1]-obs[0][1] if obs else None
   ok=actual is not None and d<=i<=r<=actual<j and actual-d<=F//1000 and (new==2 or work>0) and x[20]==0
   edges.append(dict(seq=seq,owner=new,d=d,i=i,r=r,x=actual,j=j,ticks=actual-d if actual else None,work=work,qualified=ok))
  lastseq=seq
 z=out[name]=dict(epoch=epoch,frequency=F,roots=roots,apps=apps,events=len(a),edges=edges,skipped=sum(x[20] for x in a))
 if edges:assert len(edges)==3*len(table)+2
 if 'traced' in name:
  t=(R/'exceptions.log').read_text()
  entry=[(int(kind),int(el),int(pc,16)) for kind,el,pc in re.findall(r'Taking exception (\d+) \[\w+\]\n\.\.\.from EL(\d) to EL1\n[^\n]*\n\.\.\.with ELR (0x[0-9a-f]+)',t)]
  ret=[int(p,16) for p in re.findall(r'EL1 to AArch64 EL0 PC (0x[0-9a-f]+)',t)]
  assert entry==[(5 if x[1]==1 else 2,int(x[4]==2),x[22]) for x in a[1:]]
  assert ret==[x[25] for x in a if x[5]<2];z.update(trace_entries=len(entry),trace_el0_returns=len(ret))
 if name.startswith('sleep'):
  sl=next(x for x in a if x[1]==2 and x[3]==7)
  wk=next(x for x in a if x[16]==2); resume=next(x for x in a if x[0]>sl[0] and x[5]==1)
  assert sl[5]==2 and wk[5]==0 and wk[2]>=sl[18] and resume[2]>=sl[18] and apps[1]['observed_ns']>=apps[1]['request_ns']
  z['sleep']=dict(block=sl[2],deadline=sl[18],release=wk[2],resume=resume[28])
 print(name,[(e['seq'],e['ticks']) for e in edges if not e['qualified']],max([0]+[e['ticks'] for e in edges]),flush=True)
(D/'score.json').write_text(json.dumps(out,indent=2))