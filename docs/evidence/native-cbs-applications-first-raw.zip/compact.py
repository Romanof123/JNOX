from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import re,json
d=Path(__file__).resolve().parent
with (d/'first-openings.tsv').open('w') as out:
 print('position\tfirst_open_handler_minus_open\tfirst_pre_eret_minus_open\tfirst_EL0_witness_minus_open\tinhibit_sample_minus_open\tinhibit_reason',file=out)
 for case in (d/'cases').read_text().splitlines():
  for mode in ('plain','traced'):
   r=d/'runs'/(case.split()[0]+'-'+mode);log=(r/'uart.log').read_text()
   rows=[[int(x) for x in s.split()] for s in re.findall(r'^NATIVE CBS EVENT ([0-9 ]+)$',log,re.M)]
   b=next((v for v in rows if v[0] in [1,2,3,4,7]),None)
   print(r.name,*([b[7]-b[4],b[9]-b[4] if b[9] else 'NA',b[10]-b[4] if b[10] else 'NA',b[1]-b[4] if b[0]==7 else 'NA',b[34] if b[0]==7 else 'NA'] if b else ['NA']*5),sep='\t',file=out)
with ZipFile(d/'independent-compact.zip','w',ZIP_DEFLATED) as z:
 for f in sorted(d.iterdir()):
  if f.is_file() and f.suffix not in ('.zip','.gz'):z.write(f,f.name)
 for f in sorted((d/'runs').glob('*/*')):
  if f.name!='exceptions.log':z.write(f,f.relative_to(d))
 for f in sorted((d/'elf').glob('*/manifest.json')):z.write(f,f.relative_to(d))
