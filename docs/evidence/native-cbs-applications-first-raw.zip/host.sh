set -eu
cd ~/jnox303-independent
D=/mnt/d/codex/jnox303-independent-evidence
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
rustc --edition=2021 --test kernel/src/temporal_policy.rs -o /tmp/jnox303-independent-host
/tmp/jnox303-independent-host
for spec in 0,4 5,4 malformed; do
 python3 tools/build_native_el0.py --out "$HOME/jnox303-pkgs/invalid-$spec" --policy cbs --elf "$D/elf/crc.elf" --reservation "$spec" && echo accepted || echo rejected
done
