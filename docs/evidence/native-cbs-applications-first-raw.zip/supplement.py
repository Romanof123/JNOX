from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from hashlib import sha256
d=Path(__file__).resolve().parent
report=d/'independent-native-cbs.en-ko.md'
report.write_bytes(report.read_text(encoding='utf-8-sig').rstrip().encode()+b'\n')
paths=sorted({p for p in d.rglob('*') if p.is_file() and p.suffix!='.zip' and p.name!='supplement.sha256'})
digest=lambda b:sha256(b).hexdigest()
index=''.join(f'{digest(p.read_bytes())}  {p.relative_to(d).as_posix()}\n' for p in paths)
(d/'supplement.sha256').write_bytes(index.encode())
out=d/'independent-raw-supplement.zip'
with ZipFile(out,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in paths+[d/'supplement.sha256']: z.write(p,p.relative_to(d))
with ZipFile(out) as z:
 for p in paths: assert digest(z.read(p.relative_to(d).as_posix()))==digest(p.read_bytes())
for p in [report,out,d/'supplement.sha256',d/'independent-compact.zip']:print(p.name,p.stat().st_size,digest(p.read_bytes()))
