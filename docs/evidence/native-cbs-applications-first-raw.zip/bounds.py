from pathlib import Path
import json,re
D=Path(__file__).resolve().parent
for name in ('sat','iso','short'):
 r=D/'runs'/(name+'-plain');log=(r/'uart.log').read_text()
 rows=[[int(x) for x in s.split()] for s in re.findall(r'^NATIVE CBS EVENT ([0-9 ]+)$',log,re.M)]
 stops=[b for b in rows if 1<=b[0]<=4]; q={int(i):int(n) for i,n in re.findall(r'NATIVE CBS JOB ([0-9]+) ([0-9]+)',log)}
 wall={}; previous={}; restored=[]; totals={}
 for b in stops:
  pid=b[3]; key=pid,b[24+2*pid];wall[key]=wall.get(key,0)+b[13]
  if pid in previous:restored.append((b[32],b[33])==previous[pid])
  previous[pid]=(b[18],b[19]);totals[pid]=totals.get(pid,0)+b[13]
 print(name,'per-allocation wall cap',all(w<=q[i]*3125000 for (i,d),w in wall.items()),'stop <= end',all(b[12]<=b[5] for b in stops),'per-grant wall cap',all(b[13]<=3125000 for b in stops),'cutoff lateness range',[b[12]-b[6] for b in stops if b[0]==4], 'restores',sum(restored),len(restored),'per-PID wall counts',totals)
 for i in range(len(q)):
  obs=[x[1][i] for x in map(json.loads,(r/'progress.jsonl').read_text().splitlines())]
  print('sampled worker',i,'positive intervals',sum(b>a for a,b in zip(obs,obs[1:])))
# Isolated host predicates are independent oracle controls, never guest observations.
G,S=62500,3125000
for lim in [G,S,2*S]:
 assert lim<=lim and not lim+1<=lim
def qualifies(launch_lo,launch_hi,cutoff_late,stop_delta,elapsed,allocation,progress):
 return launch_lo<=launch_hi<=G and cutoff_late<=G and stop_delta<=0 and elapsed<=S and allocation<=2*S and progress>0
base=[G,G,G,0,S,2*S,1]
assert qualifies(*base)
for j in (1,2,3,4,5,6):
 v=base.copy();v[j]+=(-1 if j==6 else 1);assert not qualifies(*v)
print('Independent oracle equality/one-count-over and zero-progress controls passed.')
