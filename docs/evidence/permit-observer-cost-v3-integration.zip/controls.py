import hashlib,json,os,signal,sys,tempfile,zipfile
from pathlib import Path
work=Path(__file__).resolve().parent
sys.path.insert(0,str(work/'source/tools'))
from permit_observer_cost import run_one
from permit_cost_retention import publish,verify
z=zipfile.ZipFile(work/'source/docs/evidence/permit-observer-cost-v3.zip')
samples='v3/02-rm-off-1-R/'
result={}
with tempfile.TemporaryDirectory() as tmp:
    t=Path(tmp)
    original_uart=z.read(samples+'uart');original_mech=z.read(samples+'mechanism')
    (t/'uart-golden').write_bytes(original_uart);(t/'mech-golden').write_bytes(original_mech)
    (t/'images').mkdir();(t/'images/rm-off-1').write_bytes(z.read('v3/frozen-inputs/images/rm-off-1'))
    child="""import sys,os,signal
from pathlib import Path
t=Path(sys.argv[1]); case=sys.argv[2]; d=t/case
def finish(sig,fr):
 p=os.getppid();n=Path('/proc/%d/comm'%p).read_text().strip();exe=Path(os.readlink('/proc/self/exe')).name
 if case!='silent':
  sys.stderr.write(f'{exe}: terminating on signal {sig} from pid {p} ({n})\\\\n'.replace('\\\\n','\\n'))
 if case=='late-noise':sys.stderr.write('noise\\n')
 sys.exit(0)
signal.signal(signal.SIGTERM, finish)
mechanism=(t/'mech-golden').read_bytes()
if case=='edge':mechanism=mechanism.replace(b'setting output 0 to 0',b'setting output 0 to 1',1)
if case=='read-in-reduced':mechanism+=b'pl061_read /machine/unattached/device[6] offset 0x4 value 0x0\\n'
(d/'mechanism').write_bytes(mechanism); uart=(t/'uart-golden').read_bytes()
if case=='early-exit':(d/'uart').write_bytes(uart[:-12]);sys.exit(0)
(d/'uart').write_bytes(uart);signal.pause()
"""
    for case,expected in [('ack','observed-off-only'),('silent','observed-off-only'),('edge','containment'),('read-in-reduced','incomplete'),('late-noise','incomplete'),('early-exit','incomplete')]:
        pos=dict(argv=[os.path.realpath(sys.executable),'-B','-c',child,str(t),case],name=case,key='rm-off-1',arm='R')
        r=run_one(t,pos,[]);assert r['disposition']==expected,(case,r['disposition'],r.get('first_failure'))
        assert r['files']['uart']['sha256']==hashlib.sha256((t/case/'uart').read_bytes()).hexdigest()
        result[case]={k:r[k] for k in ['disposition','host_status','termination_output','first_failure'] if k in r}
    files=['uart','mechanism','stdout','stderr','result.json']; copied=publish(t/'ack',t/'accepted',files,files)
    verify(t/'ack',t/'accepted',files,copied); result['retained-positive']='five artifacts, source and replica hashes, manifest exact'
    corrupt=t/'accepted/uart'; b=corrupt.read_bytes();corrupt.write_bytes(b[:-1]+b'\x01')
    def reject(key,fn):
        try:fn()
        except ValueError as e:result[key]=str(e)
        else:raise RuntimeError('accepted '+key)
    reject('same-size-final-mutation',lambda:verify(t/'ack',t/'accepted',files,copied))
    (t/'ack'/'unexpected').mkdir()
    reject('empty-source-directory',lambda:publish(t/'ack',t/'refused',files,files))
    assert not (t/'refused').exists() and (t/'ack'/'unexpected').is_dir()
    (t/'ack'/'unexpected').rmdir();(t/'ack'/'unexpected').symlink_to('uart')
    reject('source-extra-symlink',lambda:publish(t/'ack',t/'refused',files,files))
    assert not (t/'refused').exists() and (t/'ack'/'unexpected').is_symlink()
(work/'controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
