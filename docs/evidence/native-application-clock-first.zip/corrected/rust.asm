
rust-run/user.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000400000 <_start>:
  400000:	aa1f03fd 	mov	x29, xzr
  400004:	aa1f03fe 	mov	x30, xzr
  400008:	f94003e0 	ldr	x0, [sp]
  40000c:	910023e1 	add	x1, sp, #0x8
  400010:	94000005 	bl	400024 <main>

0000000000400014 <__jnox_exit>:
  400014:	93407c00 	sxtw	x0, w0
  400018:	d2800028 	mov	x8, #0x1                   	// #1
  40001c:	d4094021 	svc	#0x4a01
  400020:	d4200000 	brk	#0x0

0000000000400024 <main>:
  400024:	d10103ff 	sub	sp, sp, #0x40
  400028:	a90257fe 	stp	x30, x21, [sp, #32]
  40002c:	a9034ff4 	stp	x20, x19, [sp, #48]
  400030:	52994013 	mov	w19, #0xca00                	// #51712
  400034:	910043e8 	add	x8, sp, #0x10
  400038:	72a77353 	movk	w19, #0x3b9a, lsl #16
  40003c:	94000048 	bl	40015c <_ZN11jnox_native14monotonic_time17heff32389ba1ae0eeE>
  400040:	b9401bf4 	ldr	w20, [sp, #24]
  400044:	6b13029f 	cmp	w20, w19
  400048:	540000c1 	b.ne	400060 <main+0x3c>  // b.any
  40004c:	52800020 	mov	w0, #0x1                   	// #1
  400050:	a9434ff4 	ldp	x20, x19, [sp, #48]
  400054:	a94257fe 	ldp	x30, x21, [sp, #32]
  400058:	910103ff 	add	sp, sp, #0x40
  40005c:	d65f03c0 	ret
  400060:	d503201f 	nop
  400064:	10007da8 	adr	x8, 401018 <clock_gettime+0xd24>
  400068:	f9400bf5 	ldr	x21, [sp, #16]
  40006c:	f9000be8 	str	x8, [sp, #16]
  400070:	910043e8 	add	x8, sp, #0x10
  400074:	5293b8aa 	mov	w10, #0x9dc5                	// #40389
  400078:	72b0238a 	movk	w10, #0x811c, lsl #16
  40007c:	f9400be8 	ldr	x8, [sp, #16]
  400080:	39400109 	ldrb	w9, [x8]
  400084:	3940050b 	ldrb	w11, [x8, #1]
  400088:	4a0a0129 	eor	w9, w9, w10
  40008c:	5280326a 	mov	w10, #0x193                 	// #403
  400090:	72a0200a 	movk	w10, #0x100, lsl #16
  400094:	1b0a7d29 	mul	w9, w9, w10
  400098:	4a0b0129 	eor	w9, w9, w11
  40009c:	3940090b 	ldrb	w11, [x8, #2]
  4000a0:	1b0a7d29 	mul	w9, w9, w10
  4000a4:	4a0b0129 	eor	w9, w9, w11
  4000a8:	39400d0b 	ldrb	w11, [x8, #3]
  4000ac:	39401108 	ldrb	w8, [x8, #4]
  4000b0:	1b0a7d29 	mul	w9, w9, w10
  4000b4:	4a0b0129 	eor	w9, w9, w11
  4000b8:	1b0a7d29 	mul	w9, w9, w10
  4000bc:	4a080128 	eor	w8, w9, w8
  4000c0:	1b0a7d08 	mul	w8, w8, w10
  4000c4:	b9000fe8 	str	w8, [sp, #12]
  4000c8:	910043e8 	add	x8, sp, #0x10
  4000cc:	94000024 	bl	40015c <_ZN11jnox_native14monotonic_time17heff32389ba1ae0eeE>
  4000d0:	b9401be8 	ldr	w8, [sp, #24]
  4000d4:	6b13011f 	cmp	w8, w19
  4000d8:	540000c1 	b.ne	4000f0 <main+0xcc>  // b.any
  4000dc:	52800040 	mov	w0, #0x2                   	// #2
  4000e0:	a9434ff4 	ldp	x20, x19, [sp, #48]
  4000e4:	a94257fe 	ldp	x30, x21, [sp, #32]
  4000e8:	910103ff 	add	sp, sp, #0x40
  4000ec:	d65f03c0 	ret
  4000f0:	f9400be9 	ldr	x9, [sp, #16]
  4000f4:	6b14011f 	cmp	w8, w20
  4000f8:	1a9f27e8 	cset	w8, cc  // cc = lo, ul, last
  4000fc:	eb15013f 	cmp	x9, x21
  400100:	1a9f27e9 	cset	w9, cc  // cc = lo, ul, last
  400104:	1a890108 	csel	w8, w8, w9, eq  // eq = none
  400108:	360000c8 	tbz	w8, #0, 400120 <main+0xfc>
  40010c:	52800060 	mov	w0, #0x3                   	// #3
  400110:	a9434ff4 	ldp	x20, x19, [sp, #48]
  400114:	a94257fe 	ldp	x30, x21, [sp, #32]
  400118:	910103ff 	add	sp, sp, #0x40
  40011c:	d65f03c0 	ret
  400120:	b9400fe8 	ldr	w8, [sp, #12]
  400124:	52859569 	mov	w9, #0x2cab                	// #11435
  400128:	72a9f3e9 	movk	w9, #0x4f9f, lsl #16
  40012c:	6b09011f 	cmp	w8, w9
  400130:	540000c1 	b.ne	400148 <main+0x124>  // b.any
  400134:	2a1f03e0 	mov	w0, wzr
  400138:	a9434ff4 	ldp	x20, x19, [sp, #48]
  40013c:	a94257fe 	ldp	x30, x21, [sp, #32]
  400140:	910103ff 	add	sp, sp, #0x40
  400144:	d65f03c0 	ret
  400148:	52800080 	mov	w0, #0x4                   	// #4
  40014c:	a9434ff4 	ldp	x20, x19, [sp, #48]
  400150:	a94257fe 	ldp	x30, x21, [sp, #32]
  400154:	910103ff 	add	sp, sp, #0x40
  400158:	d65f03c0 	ret

000000000040015c <_ZN11jnox_native14monotonic_time17heff32389ba1ae0eeE>:
  40015c:	d100c3ff 	sub	sp, sp, #0x30
  400160:	a9024ff4 	stp	x20, x19, [sp, #32]
  400164:	aa0803f3 	mov	x19, x8
  400168:	92800008 	mov	x8, #0xffffffffffffffff    	// #-1
  40016c:	910003e1 	mov	x1, sp
  400170:	52800020 	mov	w0, #0x1                   	// #1
  400174:	a900fbe8 	stp	x8, x30, [sp, #8]
  400178:	f90003e8 	str	x8, [sp]
  40017c:	9400005e 	bl	4002f4 <clock_gettime>
  400180:	34000160 	cbz	w0, 4001ac <_ZN11jnox_native14monotonic_time17heff32389ba1ae0eeE+0x50>
  400184:	52994014 	mov	w20, #0xca00                	// #51712
  400188:	72a77354 	movk	w20, #0x3b9a, lsl #16
  40018c:	9400001e 	bl	400204 <__jnox_errno_location>
  400190:	b9400008 	ldr	w8, [x0]
  400194:	2900227f 	stp	wzr, w8, [x19]
  400198:	b9000a74 	str	w20, [x19, #8]
  40019c:	a9424ff4 	ldp	x20, x19, [sp, #32]
  4001a0:	f9400bfe 	ldr	x30, [sp, #16]
  4001a4:	9100c3ff 	add	sp, sp, #0x30
  4001a8:	d65f03c0 	ret
  4001ac:	f94003e8 	ldr	x8, [sp]
  4001b0:	b7f80188 	tbnz	x8, #63, 4001e0 <_ZN11jnox_native14monotonic_time17heff32389ba1ae0eeE+0x84>
  4001b4:	f94007f4 	ldr	x20, [sp, #8]
  4001b8:	52994009 	mov	w9, #0xca00                	// #51712
  4001bc:	72a77349 	movk	w9, #0x3b9a, lsl #16
  4001c0:	eb09029f 	cmp	x20, x9
  4001c4:	540000e2 	b.cs	4001e0 <_ZN11jnox_native14monotonic_time17heff32389ba1ae0eeE+0x84>  // b.hs, b.nlast
  4001c8:	f9000268 	str	x8, [x19]
  4001cc:	b9000a74 	str	w20, [x19, #8]
  4001d0:	a9424ff4 	ldp	x20, x19, [sp, #32]
  4001d4:	f9400bfe 	ldr	x30, [sp, #16]
  4001d8:	9100c3ff 	add	sp, sp, #0x30
  4001dc:	d65f03c0 	ret
  4001e0:	52800028 	mov	w8, #0x1                   	// #1
  4001e4:	52994014 	mov	w20, #0xca00                	// #51712
  4001e8:	72a77354 	movk	w20, #0x3b9a, lsl #16
  4001ec:	b9000268 	str	w8, [x19]
  4001f0:	b9000a74 	str	w20, [x19, #8]
  4001f4:	a9424ff4 	ldp	x20, x19, [sp, #32]
  4001f8:	f9400bfe 	ldr	x30, [sp, #16]
  4001fc:	9100c3ff 	add	sp, sp, #0x30
  400200:	d65f03c0 	ret

0000000000400204 <__jnox_errno_location>:
  400204:	d503201f 	nop
  400208:	1000efc0 	adr	x0, 402000 <__jnox_errno_location.initial_thread_errno>
  40020c:	d65f03c0 	ret

0000000000400210 <open>:
  400210:	d100c3ff 	sub	sp, sp, #0x30
  400214:	a90093e3 	stp	x3, x4, [sp, #8]
  400218:	f90003e2 	str	x2, [sp]
  40021c:	a9019be5 	stp	x5, x6, [sp, #24]
  400220:	f90017e7 	str	x7, [sp, #40]
  400224:	340000e1 	cbz	w1, 400240 <open+0x30>
  400228:	d0000008 	adrp	x8, 402000 <__jnox_errno_location.initial_thread_errno>
  40022c:	528002c9 	mov	w9, #0x16                  	// #22
  400230:	12800000 	mov	w0, #0xffffffff            	// #-1
  400234:	b9000109 	str	w9, [x8]
  400238:	9100c3ff 	add	sp, sp, #0x30
  40023c:	d65f03c0 	ret
  400240:	aa1f03e1 	mov	x1, xzr
  400244:	aa1f03e2 	mov	x2, xzr
  400248:	52800048 	mov	w8, #0x2                   	// #2
  40024c:	d4094021 	svc	#0x4a01
  400250:	b7f80060 	tbnz	x0, #63, 40025c <open+0x4c>
  400254:	9100c3ff 	add	sp, sp, #0x30
  400258:	d65f03c0 	ret
  40025c:	4b0003e8 	neg	w8, w0
  400260:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  400264:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  400268:	b9000128 	str	w8, [x9]
  40026c:	9100c3ff 	add	sp, sp, #0x30
  400270:	d65f03c0 	ret

0000000000400274 <read>:
  400274:	52800068 	mov	w8, #0x3                   	// #3
  400278:	93407c00 	sxtw	x0, w0
  40027c:	d4094021 	svc	#0x4a01
  400280:	b7f80040 	tbnz	x0, #63, 400288 <read+0x14>
  400284:	d65f03c0 	ret
  400288:	4b0003e8 	neg	w8, w0
  40028c:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  400290:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  400294:	b9000128 	str	w8, [x9]
  400298:	d65f03c0 	ret

000000000040029c <write>:
  40029c:	52800088 	mov	w8, #0x4                   	// #4
  4002a0:	93407c00 	sxtw	x0, w0
  4002a4:	d4094021 	svc	#0x4a01
  4002a8:	b7f80040 	tbnz	x0, #63, 4002b0 <write+0x14>
  4002ac:	d65f03c0 	ret
  4002b0:	4b0003e8 	neg	w8, w0
  4002b4:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  4002b8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  4002bc:	b9000128 	str	w8, [x9]
  4002c0:	d65f03c0 	ret

00000000004002c4 <close>:
  4002c4:	aa1f03e1 	mov	x1, xzr
  4002c8:	aa1f03e2 	mov	x2, xzr
  4002cc:	93407c00 	sxtw	x0, w0
  4002d0:	528000a8 	mov	w8, #0x5                   	// #5
  4002d4:	d4094021 	svc	#0x4a01
  4002d8:	b7f80040 	tbnz	x0, #63, 4002e0 <close+0x1c>
  4002dc:	d65f03c0 	ret
  4002e0:	4b0003e8 	neg	w8, w0
  4002e4:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  4002e8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  4002ec:	b9000128 	str	w8, [x9]
  4002f0:	d65f03c0 	ret

00000000004002f4 <clock_gettime>:
  4002f4:	aa1f03e2 	mov	x2, xzr
  4002f8:	528000c8 	mov	w8, #0x6                   	// #6
  4002fc:	93407c00 	sxtw	x0, w0
  400300:	d4094021 	svc	#0x4a01
  400304:	b7f80040 	tbnz	x0, #63, 40030c <clock_gettime+0x18>
  400308:	d65f03c0 	ret
  40030c:	4b0003e8 	neg	w8, w0
  400310:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  400314:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  400318:	b9000128 	str	w8, [x9]
  40031c:	d65f03c0 	ret
