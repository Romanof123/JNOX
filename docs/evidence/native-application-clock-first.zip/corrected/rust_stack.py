import sys, struct, json
from pathlib import Path
sys.path.insert(0,'src/tools')
from native_el0_replay import Snapshot,vread
r=json.loads(Path('rust.replay').read_text()); base=int(r['clock_output_addresses'][1],16)
m=Snapshot(0x40200000,Path('rust-run/ram.bin').read_bytes())
read=lambda a,n:vread(m,r['ttbr0'],a,n)
print('Start nanoseconds, main w20 spilled at helper SP+32',hex(base+32),struct.unpack('<Q',read(base+32,8))[0])
print('End seconds and nanoseconds at ABI destination',hex(base),struct.unpack('<qq',read(base,16)))
print('Rust checksum at main SP+12',hex(base+48+12),hex(struct.unpack('<I',read(base+48+12,4))[0]))

