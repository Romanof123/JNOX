import sys, struct,json
from pathlib import Path
sys.path.insert(0,'src/tools')
from native_el0_replay import Snapshot,elf_file,symbol,vread
for n in sys.argv[1:]:
 d=Path(n+'-run'); k=elf_file((d/'kernel.elf').read_bytes()); u=elf_file((d/'user.elf').read_bytes()); m=Snapshot(0x40200000,(d/'ram.bin').read_bytes())
 jp,size=symbol(k,'jnox_native_el0_journal'); rows=list(struct.iter_unpack('<16Q',m.read(jp,size))); root=rows[0][14]
 kr=k.get_section_by_name('.symtab'); dom=next(i for i in kr.iter_symbols() if 'CLOCK_DOMAIN' in i.name)
 epoch,hz=struct.unpack('<QQ',m.read(dom['st_value'],16))
 traces=(d/'exceptions.log').read_text()
 log={'app':n,'epoch_ticks':epoch,'frequency_hz':hz,'exit':rows[0][9],'journal_events':rows[0][8],'el0_svc_traps':traces.count('...from EL0 to EL1'),'kernel_samples':[]}
 if n!='startup':
  if n in ('loop','timed'):
   addr,size=symbol(u,'readings' if n=='loop' else 'OBSERVED')
   samples=list(struct.iter_unpack('<qq',vread(m,root,addr,size)))
  else:
   r=json.loads(Path(n+'.replay').read_text()); addrs=[int(v,16) for v in r['clock_output_addresses']]
   samples=[struct.unpack('<qq',vread(m,root,addr,16)) for addr in dict.fromkeys(addrs)]
  assert all(s>=0 and 0<=ns<10**9 for s,ns in samples) and samples==sorted(samples)
  log['final_RAM_distinct_timespec_locations']=samples
  if n=='loop':assert len(samples)==16 and log['el0_svc_traps']==17 and log['exit']==0
 print(json.dumps(log))

