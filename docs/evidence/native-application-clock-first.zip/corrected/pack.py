from pathlib import Path
import zipfile
b=Path('/mnt/d/codex/jnox288-independent-evidence')
with zipfile.ZipFile(b/'native-clock-independent.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.write(b/'report.en-ko.md','report.en-ko.md')
 z.write(b/'first-clock-apps.zip','first-clock-apps.zip',compress_type=zipfile.ZIP_STORED)
 for pat in ('*-run/*','*-package/manifest.json','*-package/build.log','*.sh','*.py','*.replay','*.digest','*.log','*.asm','*.jsonl','*.txt','external/Cargo.toml','external/src/main.rs'):
  for p in Path().glob(pat):
   if p.is_file(): z.write(p,'corrected/'+str(p))
with zipfile.ZipFile(b/'native-clock-independent.zip') as z:
 assert z.testzip() is None
