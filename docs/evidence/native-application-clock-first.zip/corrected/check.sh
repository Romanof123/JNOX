set -euxo pipefail
cd "$(dirname "$0")"
w=$PWD
export CARGO_HOME=$HOME/jnox-169-first-e203caa/cargo RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup
export PATH=$CARGO_HOME/bin:$PATH
export RUSTUP_TOOLCHAIN=1.95.0
cd src
sha=$(git rev-parse HEAD)
mkdir -p "$w/external/src"
cp examples/native-clock-rust/src/main.rs "$w/external/src/main.rs"
sed "s|../../sdk/native-aarch64/rust|$PWD/sdk/native-aarch64/rust|" examples/native-clock-rust/Cargo.toml > "$w/external/Cargo.toml"
run_app(){
 name=$1
 source=$2
 shift 2
 python3 tools/build_native_el0.py --out "$w/$name-package" "$@"
 status=0
 replay=(--clock-app)
 if [[ $name == startup ]]; then status=37; replay=(); fi
 python3 tools/native_el0_capture.py "$w/$name-run" "$w/$name-package/kernel.elf" "$w/$name-package/user.elf" "$source" "$sha" --expect-exit "$status" | tee "$w/$name.digest"
 if [[ $name != loop ]]; then python3 tools/native_el0_replay.py "$w/$name-run" "$(cat "$w/$name.digest")" "${replay[@]}" | tee "$w/$name.replay"; fi
}
run_app c examples/portability/clock_checksum.c --source examples/portability/clock_checksum.c
sh sdk/native-aarch64/build-rust.sh "$w/external/Cargo.toml" "$w/clock-rust.elf"
run_app rust "$w/external/src/main.rs" --elf "$w/clock-rust.elf"
