
c-run/user.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000400000 <_start>:
  400000:	aa1f03fd 	mov	x29, xzr
  400004:	aa1f03fe 	mov	x30, xzr
  400008:	f94003e0 	ldr	x0, [sp]
  40000c:	910023e1 	add	x1, sp, #0x8
  400010:	9400004c 	bl	400140 <main>

0000000000400014 <__jnox_exit>:
  400014:	93407c00 	sxtw	x0, w0
  400018:	d2800028 	mov	x8, #0x1                   	// #1
  40001c:	d4094021 	svc	#0x4a01
  400020:	d4200000 	brk	#0x0

0000000000400024 <__jnox_errno_location>:
  400024:	d503201f 	nop
  400028:	1000fec0 	adr	x0, 402000 <__jnox_errno_location.initial_thread_errno>
  40002c:	d65f03c0 	ret

0000000000400030 <open>:
  400030:	d100c3ff 	sub	sp, sp, #0x30
  400034:	a90093e3 	stp	x3, x4, [sp, #8]
  400038:	f90003e2 	str	x2, [sp]
  40003c:	a9019be5 	stp	x5, x6, [sp, #24]
  400040:	f90017e7 	str	x7, [sp, #40]
  400044:	340000e1 	cbz	w1, 400060 <open+0x30>
  400048:	d0000008 	adrp	x8, 402000 <__jnox_errno_location.initial_thread_errno>
  40004c:	528002c9 	mov	w9, #0x16                  	// #22
  400050:	12800000 	mov	w0, #0xffffffff            	// #-1
  400054:	b9000109 	str	w9, [x8]
  400058:	9100c3ff 	add	sp, sp, #0x30
  40005c:	d65f03c0 	ret
  400060:	aa1f03e1 	mov	x1, xzr
  400064:	aa1f03e2 	mov	x2, xzr
  400068:	52800048 	mov	w8, #0x2                   	// #2
  40006c:	d4094021 	svc	#0x4a01
  400070:	b7f80060 	tbnz	x0, #63, 40007c <open+0x4c>
  400074:	9100c3ff 	add	sp, sp, #0x30
  400078:	d65f03c0 	ret
  40007c:	4b0003e8 	neg	w8, w0
  400080:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  400084:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  400088:	b9000128 	str	w8, [x9]
  40008c:	9100c3ff 	add	sp, sp, #0x30
  400090:	d65f03c0 	ret

0000000000400094 <read>:
  400094:	52800068 	mov	w8, #0x3                   	// #3
  400098:	93407c00 	sxtw	x0, w0
  40009c:	d4094021 	svc	#0x4a01
  4000a0:	b7f80040 	tbnz	x0, #63, 4000a8 <read+0x14>
  4000a4:	d65f03c0 	ret
  4000a8:	4b0003e8 	neg	w8, w0
  4000ac:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  4000b0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  4000b4:	b9000128 	str	w8, [x9]
  4000b8:	d65f03c0 	ret

00000000004000bc <write>:
  4000bc:	52800088 	mov	w8, #0x4                   	// #4
  4000c0:	93407c00 	sxtw	x0, w0
  4000c4:	d4094021 	svc	#0x4a01
  4000c8:	b7f80040 	tbnz	x0, #63, 4000d0 <write+0x14>
  4000cc:	d65f03c0 	ret
  4000d0:	4b0003e8 	neg	w8, w0
  4000d4:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  4000d8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  4000dc:	b9000128 	str	w8, [x9]
  4000e0:	d65f03c0 	ret

00000000004000e4 <close>:
  4000e4:	aa1f03e1 	mov	x1, xzr
  4000e8:	aa1f03e2 	mov	x2, xzr
  4000ec:	93407c00 	sxtw	x0, w0
  4000f0:	528000a8 	mov	w8, #0x5                   	// #5
  4000f4:	d4094021 	svc	#0x4a01
  4000f8:	b7f80040 	tbnz	x0, #63, 400100 <close+0x1c>
  4000fc:	d65f03c0 	ret
  400100:	4b0003e8 	neg	w8, w0
  400104:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  400108:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  40010c:	b9000128 	str	w8, [x9]
  400110:	d65f03c0 	ret

0000000000400114 <clock_gettime>:
  400114:	aa1f03e2 	mov	x2, xzr
  400118:	528000c8 	mov	w8, #0x6                   	// #6
  40011c:	93407c00 	sxtw	x0, w0
  400120:	d4094021 	svc	#0x4a01
  400124:	b7f80040 	tbnz	x0, #63, 40012c <clock_gettime+0x18>
  400128:	d65f03c0 	ret
  40012c:	4b0003e8 	neg	w8, w0
  400130:	d0000009 	adrp	x9, 402000 <__jnox_errno_location.initial_thread_errno>
  400134:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  400138:	b9000128 	str	w8, [x9]
  40013c:	d65f03c0 	ret

0000000000400140 <main>:
  400140:	d10103ff 	sub	sp, sp, #0x40
  400144:	910043e1 	add	x1, sp, #0x10
  400148:	52800020 	mov	w0, #0x1                   	// #1
  40014c:	a9027bfd 	stp	x29, x30, [sp, #32]
  400150:	910083fd 	add	x29, sp, #0x20
  400154:	f9001bf3 	str	x19, [sp, #48]
  400158:	52800033 	mov	w19, #0x1                   	// #1
  40015c:	97ffffee 	bl	400114 <clock_gettime>
  400160:	35000940 	cbnz	w0, 400288 <main+0x148>
  400164:	f9400be8 	ldr	x8, [sp, #16]
  400168:	b7f800c8 	tbnz	x8, #63, 400180 <main+0x40>
  40016c:	f9400fe8 	ldr	x8, [sp, #24]
  400170:	52993ff3 	mov	w19, #0xc9ff                	// #51711
  400174:	72a77353 	movk	w19, #0x3b9a, lsl #16
  400178:	eb13011f 	cmp	x8, x19
  40017c:	54000069 	b.ls	400188 <main+0x48>  // b.plast
  400180:	52800033 	mov	w19, #0x1                   	// #1
  400184:	14000041 	b	400288 <main+0x148>
  400188:	b0000008 	adrp	x8, 401000 <main+0xec0>
  40018c:	910003e1 	mov	x1, sp
  400190:	91006108 	add	x8, x8, #0x18
  400194:	52800020 	mov	w0, #0x1                   	// #1
  400198:	39400109 	ldrb	w9, [x8]
  40019c:	3940050a 	ldrb	w10, [x8, #1]
  4001a0:	3940090b 	ldrb	w11, [x8, #2]
  4001a4:	11000529 	add	w9, w9, #0x1
  4001a8:	39400d0c 	ldrb	w12, [x8, #3]
  4001ac:	0b0a012a 	add	w10, w9, w10
  4001b0:	3940110d 	ldrb	w13, [x8, #4]
  4001b4:	0b090149 	add	w9, w10, w9
  4001b8:	0b0b014a 	add	w10, w10, w11
  4001bc:	3940150b 	ldrb	w11, [x8, #5]
  4001c0:	0b090149 	add	w9, w10, w9
  4001c4:	0b0c014a 	add	w10, w10, w12
  4001c8:	529ffe2c 	mov	w12, #0xfff1                	// #65521
  4001cc:	0b090149 	add	w9, w10, w9
  4001d0:	0b0d014a 	add	w10, w10, w13
  4001d4:	0b090149 	add	w9, w10, w9
  4001d8:	0b0b014a 	add	w10, w10, w11
  4001dc:	11003d2b 	add	w11, w9, #0xf
  4001e0:	11003d4d 	add	w13, w10, #0xf
  4001e4:	6b29219f 	cmp	w12, w9, uxth
  4001e8:	1a8b8129 	csel	w9, w9, w11, hi  // hi = pmore
  4001ec:	6b2a219f 	cmp	w12, w10, uxth
  4001f0:	3940190b 	ldrb	w11, [x8, #6]
  4001f4:	1a8d814a 	csel	w10, w10, w13, hi  // hi = pmore
  4001f8:	0b090149 	add	w9, w10, w9
  4001fc:	39401d0d 	ldrb	w13, [x8, #7]
  400200:	39402108 	ldrb	w8, [x8, #8]
  400204:	0b0b014a 	add	w10, w10, w11
  400208:	11003d2b 	add	w11, w9, #0xf
  40020c:	6b29219f 	cmp	w12, w9, uxth
  400210:	1a8b8129 	csel	w9, w9, w11, hi  // hi = pmore
  400214:	11003d4b 	add	w11, w10, #0xf
  400218:	6b2a219f 	cmp	w12, w10, uxth
  40021c:	1a8b814a 	csel	w10, w10, w11, hi  // hi = pmore
  400220:	0b090149 	add	w9, w10, w9
  400224:	0b0d014a 	add	w10, w10, w13
  400228:	11003d2b 	add	w11, w9, #0xf
  40022c:	6b29219f 	cmp	w12, w9, uxth
  400230:	1a8b8129 	csel	w9, w9, w11, hi  // hi = pmore
  400234:	11003d4b 	add	w11, w10, #0xf
  400238:	6b2a219f 	cmp	w12, w10, uxth
  40023c:	1a8b814a 	csel	w10, w10, w11, hi  // hi = pmore
  400240:	0b090149 	add	w9, w10, w9
  400244:	0b080148 	add	w8, w10, w8
  400248:	11003d2a 	add	w10, w9, #0xf
  40024c:	6b29219f 	cmp	w12, w9, uxth
  400250:	1a8a8129 	csel	w9, w9, w10, hi  // hi = pmore
  400254:	11003d0a 	add	w10, w8, #0xf
  400258:	6b28219f 	cmp	w12, w8, uxth
  40025c:	1a8a8108 	csel	w8, w8, w10, hi  // hi = pmore
  400260:	0b090109 	add	w9, w8, w9
  400264:	53103d2a 	lsl	w10, w9, #16
  400268:	1143c14b 	add	w11, w10, #0xf0, lsl #12
  40026c:	6b29219f 	cmp	w12, w9, uxth
  400270:	1a8b8149 	csel	w9, w10, w11, hi  // hi = pmore
  400274:	33003d09 	bfxil	w9, w8, #0, #16
  400278:	b9001fa9 	str	w9, [x29, #28]
  40027c:	97ffffa6 	bl	400114 <clock_gettime>
  400280:	340000e0 	cbz	w0, 40029c <main+0x15c>
  400284:	52800053 	mov	w19, #0x2                   	// #2
  400288:	a9427bfd 	ldp	x29, x30, [sp, #32]
  40028c:	2a1303e0 	mov	w0, w19
  400290:	f9401bf3 	ldr	x19, [sp, #48]
  400294:	910103ff 	add	sp, sp, #0x40
  400298:	d65f03c0 	ret
  40029c:	f94003e9 	ldr	x9, [sp]
  4002a0:	b7ffff29 	tbnz	x9, #63, 400284 <main+0x144>
  4002a4:	f94007e8 	ldr	x8, [sp, #8]
  4002a8:	eb13011f 	cmp	x8, x19
  4002ac:	54fffec8 	b.hi	400284 <main+0x144>  // b.pmore
  4002b0:	f9400bea 	ldr	x10, [sp, #16]
  4002b4:	eb0a013f 	cmp	x9, x10
  4002b8:	540000cb 	b.lt	4002d0 <main+0x190>  // b.tstop
  4002bc:	eb0a013f 	cmp	x9, x10
  4002c0:	540000c1 	b.ne	4002d8 <main+0x198>  // b.any
  4002c4:	f9400fe9 	ldr	x9, [sp, #24]
  4002c8:	eb09011f 	cmp	x8, x9
  4002cc:	5400006a 	b.ge	4002d8 <main+0x198>  // b.tcont
  4002d0:	52800073 	mov	w19, #0x3                   	// #3
  4002d4:	17ffffed 	b	400288 <main+0x148>
  4002d8:	b9401fa8 	ldr	w8, [x29, #28]
  4002dc:	52807309 	mov	w9, #0x398                 	// #920
  4002e0:	72a23cc9 	movk	w9, #0x11e6, lsl #16
  4002e4:	6b09011f 	cmp	w8, w9
  4002e8:	1a9f07e8 	cset	w8, ne  // ne = any
  4002ec:	531e7513 	lsl	w19, w8, #2
  4002f0:	17ffffe6 	b	400288 <main+0x148>
