for name,begin,end in [('M',1,65536),('P0',1,32),('P1 opening',1,16),('P1 second',17,32)]:
 h=n=s=0
 for i in range(begin,end+1):
  s+=i
  if i%16==0:
   h=((((h<<7)|(h>>57))&((1<<64)-1))^i)+s
   h%=1<<64
   n+=1
 print(name,n,h,hex(h),end,s)
