from pathlib import Path
import sys,copy,json
sys.dont_write_bytecode=True
sys.path.insert(0,'candidate/tools')
from pi4_migration_replay import journal,layout,score
r=Path('mg1/partitioned')
s,h,t=journal((r/'first-1/uart.bin').read_bytes(),1,1)
b,_=layout(*[(r/p).read_bytes() for p in ['kernel.elf','kernel8.img','disassembly.txt']])
expected={(0,1):(4096,18080812676020141577,65536,2147516416),(1,1):(2,20016,32,528),(2,0):(1,152,16,136),(2,1):(1,424,32,392)}
for c in s:
 rows=[]
 for k,d in s[c]:
  if k==9:
   task,value,lease,ep=d[:4]
   rows.append((13,(task,ep,lease,*expected[task,ep],0)))
  rows.append((k,d))
 s[c]=rows
results={}
for name,field in [('synthetic-valid',None),('count',3),('digest',4),('index',5),('sum',6),('lease',2),('reserved',7),('missing',-1)]:
 altered=copy.deepcopy(s)
 c=next(c for c in s if any(k==13 for k,d in s[c]))
 idx=next(i for i,(k,d) in enumerate(s[c]) if k==13)
 if field==-1:altered[c].pop(idx)
 elif field is not None:
  arr=list(altered[c][idx][1]);arr[field]+=1;altered[c][idx]=(13,tuple(arr))
 try:score(altered,h,t,1,b,2); outcome='accepted'
 except ValueError as exc:outcome=str(exc)
 assert (outcome=='accepted')==(field is None),(name,outcome)
 results[name]=outcome
print(json.dumps(results,indent=2))
