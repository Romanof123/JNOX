from pathlib import Path
import json,re,sys,hashlib
sys.dont_write_bytecode=True
sys.path.insert(0,'candidate/tools')
from pi4_migration_replay import layout
from elftools.elf.elffile import ELFFile
summary=[]
for case in ['global','partitioned','clustered']:
 r=Path(case)
 bodies,_=layout(*[(r/p).read_bytes() for p in ['kernel.elf','kernel8.img','disassembly.txt']])
 with (r/'kernel.elf').open('rb') as f:
  sym=ELFFile(f).get_section_by_name('.symtab').get_symbol_by_name('pi4_migration_m')[0];base=sym['st_value'];end=base+sym['st_size']
 for n in [1,2]:
  p=r/f'first-{n}';mapping=json.loads((p/'threads.json').read_bytes());cpu={}
  for thread,name in mapping.items():
   log=p/f'observer-{thread}.log'
   if log.exists():
    raw=log.read_text();cpu[name]=dict(erets=re.findall('Exception return[^\n]* PC (0x[0-9a-f]+)',raw),traps=re.findall(r'Taking exception \d+ \[(\w+)\] on CPU (\d+).*?with ELR (0x[0-9a-f]+)',raw,re.S))
  m=cpu['CPU 0/TCG']
  assert m['traps']==[('SVC','0',m['traps'][0][2])] and base<=int(m['traps'][0][2],16)<end
  assert b'000000000000001d' in (p/'uart.bin').read_bytes()
  summary.append(dict(case=case,position=n,strict_loop=bodies,M_extent=[base,end],trace=cpu,session_sha256=hashlib.sha256((p/'session.json').read_bytes()).hexdigest(),verdict='M finished before IRQ; missing MG2 journal and continuation'))
print(json.dumps(summary,indent=2))
