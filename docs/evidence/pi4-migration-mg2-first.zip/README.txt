Offline replay, Python 3 plus pyelftools. From the extracted directory:
python candidate/tools/pi4_migration_replay.py global 1 DIGEST
Use the digest from global/session-1.digest and repeat for each case/ordinal.
All six original first positions return status 1 (M finished before migration IRQ).
For independent PC joins use python inspect-trace.py. expected.py reproduces the protocol expectations.
For host controls extract the MG1 archive docs/evidence/pi4-migration-first.zip from the indicated commit into mg1/ then use python controls.py. MG1 output files in this pack are archived replay results.
provenance.json pairs original and portable digests. Only model executable/build path text and dependent digests were normalized.
