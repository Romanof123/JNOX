import sys,subprocess,tarfile,hashlib
from pathlib import Path
from types import SimpleNamespace
base=Path.home()/'iv318-f0'/'orig'
root=base/'raw'
src=base/'src'
backup=Path('/mnt/d/codex/jnox318-independent-evidence/reconstructed')
sys.path.insert(0,str(src/'tools'))
import native_el0_capture as c
for mode,arg,trace in [('coop','normal',False),('coop','normal',True),('rr','normal',False),('rr','normal',True)]+[(m,a,True) for m in ('coop','rr') for a in ('sleep-owner','controls')]:
    legacy=arg=='legacy'
    pkg=root/(('legacy-'+mode) if legacy else (mode+'-'+arg))
    dst=root/('run-'+pkg.name+('-trace' if trace else '-plain'))
    original=c.command
    def command(q,r):
        cmd=original(q,r)
        if not trace:
            i=cmd.index('-d'); del cmd[i:i+4]
        return cmd
    c.command=command
    probe='native-thread-mutex/sensor.c' if not legacy else ('native-threads/sensor.c' if mode=='coop' else 'native-thread-rr/stream.c')
    status=c.capture(SimpleNamespace(root=dst,kernel=pkg/'kernel.elf',user=pkg/'user.elf',probe=src/'examples'/probe,revision='f0ef88f8d1796b51801f7f72432545d2d223c34d',expect_exit=17 if legacy else 0,manifest=pkg/'manifest.json',arg=[] if arg in ('normal','legacy') else [arg],peer_arg=[],peer2_arg=[],qemu='qemu-system-aarch64',nm='aarch64-linux-gnu-nm'))
    c.command=original
    archive=backup/(dst.name+'.tar.gz')
    with tarfile.open(archive,'w:gz') as t: t.add(dst,arcname=dst.name)
    with tarfile.open(archive) as t:
        for f in t.getmembers():
            if f.isfile(): assert t.extractfile(f).read()==(dst/f.name.split('/')[-1]).read_bytes()
    print(dst.name,status,hashlib.sha256(archive.read_bytes()).hexdigest(),flush=True)
