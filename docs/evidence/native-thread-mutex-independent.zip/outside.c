#include <pthread.h>
#include <errno.h>
static pthread_mutex_t m;
int main(void) {
 errno=22;
 if(pthread_mutex_init(&m,0)!=ENOTSUP) return 1;
 return errno==22 ? 0 : 2;
}
