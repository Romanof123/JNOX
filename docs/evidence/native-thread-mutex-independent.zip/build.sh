set -eu
cd "$HOME/iv318-f0/src"
export RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH=$HOME/jnox-169-first-e203caa/cargo/bin:/usr/local/bin:/usr/bin:/bin
sh sdk/native-aarch64/build-rust.sh examples/native-thread-mutex/Cargo.toml ../raw/sensor.elf >../raw/build.txt 2>&1
for mode in coop rr; do
 opts=(); if [[ $mode == rr ]]; then opts=(--policy rr --quantum-ticks 625000); fi
 for arg in normal sleep-owner controls; do
  extra=(); if [[ $arg != normal ]]; then extra=(--arg $arg); fi
  python3 tools/build_native_el0.py --out ../raw/$mode-$arg --threads 2 --elf ../raw/sensor.elf "${opts[@]}" "${extra[@]}" >../raw/build-$mode-$arg.log 2>&1
 done
done
for m in coop rr; do
 opts=(); f=examples/native-threads/sensor.c
 if [[ $m = rr ]]; then opts=(--policy rr --quantum-ticks 625000); f=examples/native-thread-rr/stream.c; fi
 python3 tools/build_native_el0.py --out ../raw/legacy-$m --threads 2 "${opts[@]}" --source $f >../raw/build-legacy-$m.log 2>&1
done
cd ../raw; sha256sum sensor.elf */kernel.elf >freeze.sha256
