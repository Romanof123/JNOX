import sys,struct,subprocess,re,json
from pathlib import Path
none=(1<<64)-1
for d in sorted(Path(sys.argv[1]).glob('run-*')):
 if 'legacy' in d.name: continue
 def syms(f):
  return {p[2]:int(p[0],16) for l in subprocess.check_output(['aarch64-linux-gnu-nm','-n',str(d/f)],text=True).splitlines() if len(p:=l.split())==3}
 kernel=syms('kernel.elf'); user=syms('user.elf');ram=(d/'ram.bin').read_bytes()
 def phys(p,fmt):return struct.unpack_from('<'+fmt,ram,p-0x40200000)
 def data(n,fmt):return phys(next(a for k,a in kernel.items() if '6SPACES' in k)+5*4096+user[n]-0x400000,fmt)
 hz=phys(next(a+(0 if '.1.' in k else 8) for k,a in kernel.items() if 'CLOCK_DOMAIN' in k and '.0.' not in k),'Q')[0]
 lines=(d/'uart.bin').read_text().splitlines()
 events=[list(map(int,l.split()[3:])) for l in lines if l.startswith('NATIVE THREAD EVENT ')]
 mutex={p[0]:p[1:] for l in lines if l.startswith('NATIVE THREAD MUTEX ') and (p:=list(map(int,l.split()[3:])))}
 assert 'NATIVE THREAD DROPPED 0' in lines and 'NATIVE EL0 EXIT 0' in lines
 product=data('sensor_total','3Q'); assert product==(256,sum(range(1,257)),sum(i*i for i in range(1,257)))
 assert data('joined_aggregate','Q')[0]==user['sensor_total']
 vals={n:data(n,'i')[0] for n in ('worker_try','worker_lock','worker_errno_after','main_errno_after','main_try_after','self_try','busy_destroy','nonowner_error')}
 assert [vals[n] for n in ('worker_try','worker_lock','worker_errno_after','main_errno_after')]==[16,0,38,22]
 b=next(i for i,e in enumerate(events) if e[2:5]==[1,0,15] and e[20]==7)
 h=next(i for i,e in enumerate(events) if e[2:5]==[0,0,17] and mutex[i][8:]==[1,1,none,0])
 assert mutex[b][8:]==[0,0,1,1] and events[h][23]==2 and b<h
 s=next(i for i,e in enumerate(events[h+1:],h+1) if e[3]==1)
 assert events[b][10:13]==events[s][13:16] and events[s][16]==0 and events[s][27]>=events[s][0] and len({e[26] for e in events})==1
 trace=(d/'exceptions.log').read_text() if (d/'exceptions.log').exists() else ''
 if trace:
  pcs=[int(v,16) for v in re.findall(r'Exception return from AArch64 EL1 to AArch64 EL0 PC 0x([0-9a-f]+)',trace)]
  assert pcs==[e[13] for e in events if e[3]!=none]
 sleep=None
 if 'sleep-owner' in d.name:
  idle=next(e for e in events if e[4]==7 and e[3]==none and e[20]==7)
  wake=next(e for e in events if e[1]==3 and e[2]==none and e[3]==0)
  a,z=[data(n,'Q')[0] for n in ['sleep_target_ns','sleep_observed_ns']]
  assert a<=z and idle[25]<=wake[0]<=wake[27] and '[IRQ]\n...from EL1 to EL1' in trace
  sleep=[a,z,idle[25],wake[0],wake[27]]
 if 'controls' in d.name:
  assert [vals[n] for n in ('self_try','busy_destroy','nonowner_error')]==[16,16,1]
  assert [e[9] for e in events if e[4]==13]==[4,8]
 if 'coop' in d.name:assert vals['main_try_after']==16
 assert hz>0
 print(json.dumps(dict(run=d.name,product=product,joined=user['sensor_total'],hz=hz,values=vals,block=b,handoff=h,resume=s,frame=events[b][10:13],sleep=sleep,dropped=0)))
