#[path="../src/kernel/src/ready_queue.rs"] mod ready_queue;
#[path="../src/kernel/src/fixed_policy.rs"] mod fixed_policy;
#[path="../src/kernel/src/native_thread_policy.rs"] mod native_thread_policy;
use native_thread_policy::{Policy,State};
#[test] fn independent_lifecycle(){
 let mut p=Policy::new();
 for (i,&a) in [80,88,96,104].iter().enumerate(){assert_eq!(p.mutex(13,a,0),Ok(4+i as u64));}
 let saved=*p.mutex_slots();assert_eq!(p.mutex(13,112,0),Err(11));assert_eq!(saved,*p.mutex_slots());
 assert_eq!(p.mutex(14,88,5),Ok(0));assert_eq!(p.mutex(13,88,0),Ok(9));assert_eq!(p.mutex(15,88,5),Err(22));
 let h=p.create().unwrap();p.join(h).unwrap();p.mutex(15,96,6).unwrap();p.thread_exit(99);
 p.create().unwrap();p.yield_now();assert_eq!(p.mutex(17,96,6),Err(1));
 p.mutex(15,96,6).unwrap();p.mutex(15,96,6).unwrap();assert_eq!(p.current(),None);assert_eq!(p.next_compare(),None);
 assert_eq!(p.state(1),State::MutexWait(6));p.process_exit(31);assert!(p.mutex_slots().iter().all(|s|s.address.is_none()));
}
