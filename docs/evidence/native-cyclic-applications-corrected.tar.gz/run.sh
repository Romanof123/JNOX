set -eu
E=$HOME/e324fix
cd "$E"
D=/mnt/d/codex/ind324fix-evidence
mkdir -p "$D/runs"
cp ~/rr316ind/e/capture.py .
sed -i "s/size=0x415000/size=0x82a000/;s/,'-trace','enable=gic_acknowledge_irq'//" capture.py
cp /mnt/d/codex/ind324fix-build.sh build.sh
cp /mnt/d/codex/ind324fix-run.sh run.sh
order="P-plain Q-plain P-traced Q-traced sleep-plain"
echo "$order" > order
qemu-system-aarch64 --version > qemu-version
findmnt -T "$E" > filesystem
for n in energy density; do aarch64-linux-gnu-objdump -d "$n.elf" > "$n.dis"; aarch64-linux-gnu-nm -nS "$n.elf" > "$n.sym"; done
for n in P Q sleep coop; do aarch64-linux-gnu-nm -nS "$n/kernel.elf" > "$n.sym"; done
sha256sum *.elf */kernel.elf */manifest.json capture.py order > freeze
cp -t "$D" *.elf *.sym *.dis *.sh *.log source.tar.gz freeze revision order qemu-version filesystem capture.py
for n in P Q sleep coop; do mkdir -p "$D/$n"; cp "$n/"{kernel.elf,manifest.json} "$D/$n/"; done
for c in $order; do
 python3 capture.py "$E" "$c"
 tar -C runs -czf "$D/runs/$c.tar.gz" "$c"
 tar -tzf "$D/runs/$c.tar.gz" > "$D/runs/$c.contents"
 tar -C runs -dzf "$D/runs/$c.tar.gz"
done