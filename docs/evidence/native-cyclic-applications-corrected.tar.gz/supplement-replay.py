from pathlib import Path
import json,re,struct,subprocess
D=Path.home()/'e324fix';R=D/'runs/batch-traced'
u=(R/'uart.log').read_text();t=(R/'exceptions.log').read_text()
a=[[int(w) for w in l.split()] for l in re.findall('^NATIVE CYCLIC EVENT (.*)$',u,re.M)]
assert re.findall(r'NATIVE EL0 EXIT PID (\d) (\d+)',u)==[('0','23'),('1','23')] and 'NATIVE CYCLIC DROPPED 0' in u
entry=[(int(k),int(el),int(pc,16)) for k,el,pc in re.findall(r'Taking exception (\d+) \[\w+\]\n\.\.\.from EL(\d) to EL1\n[^\n]*\n\.\.\.with ELR (0x[0-9a-f]+)',t)]
assert entry==[(5 if x[1]==1 else 2,int(x[4]==2),x[22]) for x in a[1:]]
assert [int(p,16) for p in re.findall(r'EL1 to AArch64 EL0 PC (0x[0-9a-f]+)',t)]==[x[25] for x in a if x[5]<2]
roots=[next(x[27] for x in a if x[5]==j) for j in range(2)]
m=(R/'space.raw').read_bytes(); mask=0xfffffffff000;base=roots[0]&mask
sym={l.split()[-1]:int(l.split()[0],16) for l in subprocess.check_output(['aarch64-linux-gnu-nm','-n',str(D/'batch.elf')],text=True).splitlines() if len(l.split())>=3}
def read(id,var):
 addr=sym[var];page=roots[id]&mask
 for shift in (30,21,12):
  desc=struct.unpack_from('<Q',m,page-base+8*((addr>>shift)&511))[0];assert desc&3==3;page=desc&mask
 return struct.unpack_from('<Q',m,page-base+(addr&4095))[0]
state=1;expected=0
for _ in range(220*8192):
 state=(state*1664525+1013904223)&0xffffffff;expected+=state>>24
for j in range(2):assert read(j,'samples')==220 and read(j,'checksum')==expected
epoch=a[0][12]; saved={};exited=0
for prev,x in zip(a,a[1:]):
 assert x[2]<=x[33]<=x[32] and (x[1]==2 or x[2]==x[33])
 seq=(x[33]-epoch)//62500
 assert x[7]==seq and x[10]==seq%2 and x[11]==epoch+seq*62500 and x[12]==x[11]+62500
 if x[1]==2 and x[3]==1:exited|=1<<x[4]
 owner=seq%2
 assert x[5]==(3 if exited==3 else 2 if exited>>owner&1 else owner)
 if x[4]<2:saved[x[4]]=x[22:24]
 if x[5]<2:
  assert x[27]==roots[x[5]] and (x[25:27]==saved[x[5]] if x[5] in saved else x[25]==0x400000)
cross=[dict(row=x[0],op=x[3],entry=x[2],boundary=x[11],decision=x[33],old=x[4],new=x[5],r=x[28],next_entry=a[x[0]+1][2]) for x in a if x[1]==2 and x[2]<x[11]<=x[33]]
assert cross
print(json.dumps(dict(rows=len(a),clock_gettime_calls=sum(x[1]==2 and x[3]==6 for x in a),clock_cross=cross,external_entries=len(entry),each_private_checksum=expected,each_private_intervals=220),indent=2))