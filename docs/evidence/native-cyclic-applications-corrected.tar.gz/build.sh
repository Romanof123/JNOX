set -euxo pipefail
source ~/jnox314-3d53da8/env.sh
cd ~/ind324fix
E=$HOME/e324fix
mkdir -p "$E"
git rev-parse HEAD > "$E/revision"
git archive --format=tar.gz -o "$E/source.tar.gz" HEAD
sh sdk/native-aarch64/build.sh examples/native-cyclic/energy.c "$E/energy.elf"
sh sdk/native-aarch64/build-rust.sh examples/native-cyclic-rust/Cargo.toml "$E/density.elf"
for n in P Q sleep coop; do
 args=(--policy partition --partition-windows a:100,b:50,idle:50)
 case $n in Q) args=(--policy partition --partition-windows b:50,idle:50,a:100,b:50);; sleep) args+=(--peer-arg sleep-160);; coop) args=();; esac
 python3 tools/build_native_el0.py --out "$E/$n" --elf "$E/energy.elf" --peer-elf "$E/density.elf" "${args[@]}" > "$E/$n.build" 2>&1 || { cat "$E/$n.build"; exit 1; }
done