#include <time.h>
#include <stdint.h>
volatile uint64_t checksum, samples, last_ns;
int main(void) {
    uint32_t state = 1;
    for (unsigned batch = 0; batch < 220; ++batch) {
        for (unsigned byte = 0; byte < 8192; ++byte) {
            state = state * 1664525u + 1013904223u;
            checksum += (state >> 24);
        }
        struct timespec t;
        if (clock_gettime(CLOCK_MONOTONIC, &t)) return 96;
        uint64_t now = (uint64_t)t.tv_sec * 1000000000u + (uint64_t)t.tv_nsec;
        if (now < last_ns) return 97;
        last_ns = now;
        ++samples;
    }
    return 23;
}