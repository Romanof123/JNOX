set -eux
source ~/jnox314-3d53da8/env.sh
cd ~/ind324fix
E=$HOME/e324fix
sh sdk/native-aarch64/build.sh examples/native-fixed/prime_low.c "$E/prime.elf"
python3 tools/build_native_el0.py --out "$E/legacy" --elf "$E/prime.elf" --peer-elf "$E/prime.elf" > "$E/legacy.build" 2>&1
python3 "$E/capture.py" "$E" legacy-plain
for t in 'a:1' 'a:1,b:0' 'a:1,,b:2' 'a:18446744073709551615,b:1' 'a:2,b:-1' 'c:1,b:1'; do
 if python3 tools/build_native_el0.py --out "$E/invalid" --elf "$E/energy.elf" --peer-elf "$E/density.elf" --policy partition --partition-windows "$t"; then exit 1; fi
done
D=/mnt/d/codex/ind324fix-evidence
tar -C "$E" -czf "$D/legacy.tar.gz" runs/legacy-plain legacy/kernel.elf legacy/manifest.json prime.elf
tar -C "$E" -dzf "$D/legacy.tar.gz"