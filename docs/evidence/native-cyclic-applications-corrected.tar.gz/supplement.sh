set -eux
source ~/jnox314-3d53da8/env.sh
cd ~/ind324fix
E=$HOME/e324fix
D=/mnt/d/codex/ind324fix-evidence
cp "$D/batch.c" "$E/batch.c"
sh sdk/native-aarch64/build.sh "$E/batch.c" "$E/batch.elf"
python3 tools/build_native_el0.py --out "$E/batch" --policy partition --partition-windows a:1,b:1 --elf "$E/batch.elf" --peer-elf "$E/batch.elf"
python3 "$E/capture.py" "$E" batch-traced
tar -C "$E" -czf "$D/supplement.tar.gz" runs/batch-traced batch/manifest.json batch/kernel.elf batch.elf
tar -C "$E" -dzf "$D/supplement.tar.gz"