from pathlib import Path
import json,sys,re,hashlib,subprocess,os
d,r,source=map(Path,sys.argv[1:])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
apps=[sha(source/(role+'.elf')) for role in ('sender','controller','supervisor')]
reports=[]
for p in sorted((d/'results').glob('*.json')):
 n=p.stem; case=r/n; cap=case/'cap'; x=json.loads(p.read_text())
 uart=(cap/'uart.bin').read_text(); meta=json.loads((case/'pkg/manifest.json').read_text()); launch=json.loads((cap/'launch.json').read_text())
 receipt=json.loads((cap/'session.json').read_text())['hashes']
 assert all(sha(cap/f)==h for f,h in receipt.items())
 assert sha(case/'pkg/kernel.elf')==sha(cap/'kernel.elf')==x['kernel_sha256']
 assert meta==launch['argument_package']
 assert re.findall(r'^NATIVE EL0 (?:PEER2? )?ELF ([0-9a-f]{64})$',uart,re.M)==apps==x['slot_sha256']
 assert sha(cap/'user.elf')==apps[0]
 raw=[list(map(int,z.split()[3:])) for z in uart.splitlines() if z.startswith('NATIVE QUAL ROW ')]
 sched=[z for z in raw if z[1]==2]
 priorities=[s['priority'] for s in meta['slots']]
 ranks=0
 for z in sched:
  assert not z[7]&~7
  slots=[i for i in range(3) if z[7]&(1<<i)]
  assert z[9]==(max(slots,key=lambda i:priorities[i]) if slots else 2**64-1)
  ranks+=1
 starts=[z for z in raw if z[1]==1 and z[5]==1]
 finishes=[z for z in raw if z[1]==1 and z[5]==3]
 for seg in x['segments']:
  pid,j,phase=seg['pid'],seg['job'],dict(A=1,B=2,sender=3)[seg['phase']]
  mark=next(z for z in finishes if z[2:5]==[pid,j,phase])
  targets=[z for z in starts if z[2:5]==[pid,j,phase]]
  assert len(targets)==1 and targets[0][6]==seg['target']
  nxt=next((z for z in starts if z[2]==pid and z[0]>mark[0]),None)
  e=next(z for z in sched if z[0]>mark[0] and z[8]==pid and (z[2]==22 if nxt is None else z[2]==62 and z[3]==nxt[8]))
  assert seg['block_row']==e[0] and seg['end_row']==mark[0]
  blocked=bool(e[6]&(1<<pid) and not e[7]&(1<<pid))
  assert seg['upper_ticks']==(e[5]-seg['target'] if blocked else None)
  assert seg['lower_ticks']==max(mark[7]-seg['target'],e[4]-seg['target'] if blocked else 0)
 reports.append(dict(case=n,archive_sha256=sha(source/(n+'.tgz')),kernel=x['kernel_sha256'],uart=x['uart_sha256'],checked_segments=len(x['segments']),dispatch_rows=ranks,slot_sha256=apps,excesses=[z for z in x['segments'] if z['lower_ticks']>(625000 if z['pid']==0 else 62500)],missing_boundary=[z for z in x['segments'] if z['upper_ticks'] is None]))
(d/'crosscheck.json').write_text(json.dumps(reports,indent=1))