from pathlib import Path
import hashlib,subprocess,sys,json,shutil
d,r,old,src=map(Path,sys.argv[1:])
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
def load(p):return json.loads(p.read_bytes())
def check(p,out):
 v=subprocess.run([sys.executable,str(d/'native_safety_admission.py'),str(p)],capture_output=True)
 out.write_bytes(v.stdout)
 return v.returncode,load(out)
results=d/'results';results.mkdir(exist_ok=True)
e=[]
for prev in sorted((old/'results').glob('*.json')):
 p=r/prev.stem; out=results/prev.name
 rc,x=check(p,out)
 e.append([prev.stem,rc,len(x.get('segments',[])),prev.read_bytes()==out.read_bytes()])
write(d/'original-comparison.json',e)
assert len(e)==24 and all(v[1:]==[1,40,True] for v in e)
p=r/'corrected-controls';c=p/'cap';g=p/'pkg'
def receipt(name):
 j=load(c/'session.json');j['hashes'][name]=sha((c/name).read_bytes());write(c/'session.json',j)
def change_launch(k,val):
 j=load(c/'launch.json');j[k]=val;write(c/'launch.json',j);receipt('launch.json')
def mut(name):
 if name in ('machine','smp','accel','duplicate-cpu','icount'):
  a=load(c/'launch.json')['argv']
  if name=='duplicate-cpu':a+=['-cpu','cortex-a72']
  elif name=='icount':a+=['-icount','auto']
  else:
   flag,val={'machine':('-machine','virt,gic-version=3'),'smp':('-smp','2'),'accel':('-accel','kvm')}[name];a[a.index(flag)+1]=val
  change_launch('argv',a)
 if name=='emulator-digest':change_launch('qemu_sha256','0'*64)
 if name=='stale-ram':
  with (c/'ram.bin').open('r+b') as f:f.write(b'xyz')
 if name=='missing-ram':(c/'ram.bin').unlink()
 if name=='missing-probe':(c/'probe.c').unlink()
 if name=='counter-hz':
  u=c/'uart.bin';u.write_bytes(u.read_bytes().replace(b'NATIVE QUAL COUNTS 62500000',b'NATIVE QUAL COUNTS 62500001'));receipt('uart.bin')
 if name in ('new-profile','build-option','priority'):
  m=load(g/'manifest.json')
  if name=='new-profile':m['slots'][0]['argv'][1]='new-profile'
  if name=='build-option':m['package_argv']+=['--safety-channel']
  if name=='priority':m['slots'][0]['priority']+=1
  write(g/'manifest.json',m);change_launch('argument_package',m)
 if name=='stale-sender':(c/'user.elf').open('ab').write(b'Q')
 if name=='missing-sender':(c/'user.elf').unlink()
 if name in ('ordered-peers-ok','swapped-peers','staged-peer-stale','missing-receipted-peer'):
  for n,role in [('native_peer.elf','controller'),('native_peer2.elf','supervisor')]:
   shutil.copyfile(src/(role+'.elf'),c/n);receipt(n)
  if name=='swapped-peers':shutil.copyfile(c/'native_peer2.elf',c/'native_peer.elf')
  if name=='staged-peer-stale':shutil.copyfile(c/'native_peer2.elf',g/'native_peer.elf')
  if name=='missing-receipted-peer':(c/'native_peer.elf').unlink()
 if name in ('uart-receipted-peer-order','uart-stale'):
  u=c/'uart.bin';b=u.read_bytes();u.write_bytes(b.replace(b'PEER2 ELF',b'PEER ELF',1))
  if name.startswith('uart-receipted'):receipt('uart.bin')
 if name=='cross-kernel':shutil.copyfile(r/'rr-overrun/pkg/kernel.elf',g/'kernel.elf')
 if name=='changed-embedded-peer':
  k=g/'kernel.elf';b=k.read_bytes();peer=(src/'controller.elf').read_bytes();i=b.index(peer)+100
  b=b[:i]+bytes([b[i]^1])+b[i+1:];k.write_bytes(b);(c/'kernel.elf').write_bytes(b)
  m=load(g/'manifest.json');m['kernel_elf_sha256']=sha(b);write(g/'manifest.json',m)
  j=load(c/'launch.json');j['argument_package']=m;j['kernel_sha256']=sha(b);write(c/'launch.json',j)
  receipt('launch.json');receipt('kernel.elf')
 if name=='launcher-revision':change_launch('revision','0'*40)
 if name=='launcher-sender':change_launch('user_sha256','0'*64)
 if name=='launcher-cpu':
  a=load(c/'launch.json')['argv'];a[a.index('-cpu')+1]='cortex-a53';change_launch('argv',a)
controls=d/'controls';controls.mkdir(exist_ok=True)
summary=[]
for name in 'stale-sender missing-sender ordered-peers-ok swapped-peers staged-peer-stale missing-receipted-peer uart-receipted-peer-order uart-stale cross-kernel changed-embedded-peer launcher-revision launcher-sender launcher-cpu machine smp accel duplicate-cpu icount emulator-digest stale-ram missing-ram missing-probe counter-hz new-profile build-option priority'.split():
 if p.exists():
  assert p.parent==r and p.name=='corrected-controls'
  shutil.rmtree(p)
 shutil.copytree(r/'fifo-healthy',p);mut(name)
 rc,x=check(p,controls/(name+'.json'));summary.append([name,rc,len(x.get('segments',[])),x.get('input_error')])
write(d/'control-table.json',summary)