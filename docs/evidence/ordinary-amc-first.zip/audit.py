import re,json,hashlib
from pathlib import Path
from elftools.elf.elffile import ELFFile
ring=[2,5,1,6,3,7,4,8]
for case in ['exact-lo','exact-hi','over-hi']:
 root=Path(case); rows=[x.split() for x in (root/'first/uart.bin').read_text().splitlines() if x.startswith('AMR ')]
 def get(tag):return [[int(t) for t in r[2:]] for r in rows if r[1]==tag]
 expected=[]; grants=get('GRANT'); irqs=get('IRQ'); prods={}; stacks={(r[1],r[2]):r[5:7] for r in get('RELEASE')}
 with (root/'kernel.elf').open('rb') as f:
  syms=ELFFile(f).get_section_by_name('.symtab'); addr=grants[0][7]; workers=[(s.name,s['st_value'],s['st_size']) for s in syms.iter_symbols() if s['st_value']==addr and s['st_size']>0]
 assert workers
 for g,i,w in zip(grants,irqs,get('WORK')):
  k,t,b=g[:3]; expected.extend([('eret',g[7]),('irq',i[8])]); low,high=stacks[t,b]; assert low<=i[7] and i[7]+832==i[9]<=high and addr<=i[8]<addr+workers[0][2]
  for n,v in [(w[4],w[5]),(w[7],w[8])]:assert v==(36*(n//8)+sum(ring[(t+b+j)%8] for j in range(n%8)))%2**64
  assert w[4]>prods.get((t,b),(0,))[0]
  prods[t,b]=tuple(w[7:9])+tuple(w[6:7])
 actual=[]
 for l in (root/'first/exceptions.log').read_text().splitlines():
  if l.startswith('Exception return'):actual.append(('eret',int(l.split()[-1],16)))
  if 'with ELR' in l:actual.append(('irq',int(l.split()[-1],16)))
 assert actual==expected
 for t,b,n,v,stamp in get('FINAL'):assert (n,v,stamp)==prods.get((t,b),(0,0,0))
 verdict=dict(case=case,worker=workers,exception_returns_and_irqs=actual,stacks=get('RELEASE'),grant_owners=[g[1] for g in grants],work=get('WORK'),final=get('FINAL'),elf_sha256=hashlib.sha256((root/'kernel.elf').read_bytes()).hexdigest(),original_first_verdict='accepted' if case=='exact-lo' else 'rejected: fresh LO final result late')
 (Path(case+'-independent.json')).write_text(json.dumps(verdict,indent=2))
 print(case, workers, verdict['elf_sha256'])
