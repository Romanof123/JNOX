import sys, json
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
from ordinary_amc_replay import assess, Incomplete
root=Path('exact-lo')
u=(root/'first/uart.bin').read_bytes()
e=(root/'kernel.elf').read_bytes()
t=(root/'first/exceptions.log').read_bytes()
def change(tag, field):
 lines=u.splitlines(True)
 for i,line in enumerate(lines):
  if line.startswith(b'AMR '+tag+b' '):
   cols=line.split(); cols[field]=str(int(cols[field])+1).encode()
   lines[i]=b' '.join(cols)+b'\n';return b''.join(lines)
 raise AssertionError(tag)
results={}
for name,uart,trace,expected in [
 ('unchanged',u,t,'accepted'),('owner',change(b'GRANT',3),t,'rejected'),
 ('checksum',change(b'WORK',10),t,'rejected'),('generation-final',change(b'FINAL',3),t,'rejected'),
 ('wrong-eret',u,t.replace(b'40202028',b'4020202c',1),'rejected'),
 ('missing-trace',u,b'','inconclusive')]:
 try: assess(0,uart,e,trace); got='accepted'; reason=''
 except Incomplete as err:got='inconclusive';reason=str(err)
 except ValueError as err:got='rejected';reason=str(err)
 assert got==expected,(name,got,expected)
 results[name]=[got,reason]
print(json.dumps(results,indent=2))
