from pathlib import Path
import zipfile, json, hashlib, re
p=Path(__file__).resolve().parent
for label in ('201','mailbox','203','178','204','207'):
    d=p/label
    digest=hashlib.sha256((d/'raw.zip').read_bytes()).hexdigest()
    assert digest in (d/'report.md').read_text('utf8')
    with zipfile.ZipFile(d/'raw.zip') as z:
        assert z.testzip() is None
        def obj(f): return json.loads(z.read(f))
        if label in ('201','mailbox'):
            rows=[obj(f'pos{i}-official.json') for i in range(1,9)]
            assert [r['result'][0] for r in rows]==[2]+[0]*7
            a,b=rows[0]['result'][2:]
            assert a-b=={'201':68393,'mailbox':64696}[label]
            if label=='mailbox': assert a-b-62500==2196 and not rows[0]['actual_worker_return']
        if label=='203':
            raw=z.read('absent-first-boot.log')
            assert b'DENIED' in raw and b'AP EVENT' not in raw
            for f in ('default-first-boot.log','default-repeat.log'):
                assert b'AP EVENT' in z.read(f) and b'AP END' not in z.read(f)
            assert b'AP END 0000000000000000' in z.read('default-complete.log')
        if label=='178':
            rows=obj('independent.json')
            assert [k for k,r in rows.items() if r.get('replay_misses')]==['wake-default']
            row=rows['wake-default']
            assert row['replay_misses']==['lease 14: gap 487, elapsed 890546'] and 890546-row['H']==109296
        if label=='204':
            rs=[obj(n) for n in z.namelist() if n.endswith('.replay')]
            assert len(rs)==6 and all(r==dict(outcome='unobserved',reason='M finished before migration IRQ') for r in rs)
        if label=='207':
            rows=obj('jnox207-independent-f959/observations.json')
            assert len(rows)==16 and [(r[0],r[1]) for r in rows if r[1]]==[('14-selected-return-ordinary-pi-traced',16)]
    print(label,digest)
for candidate in p.glob('head-*.md'):
    prior=(p/candidate.name.replace('head-','base-')).read_text('utf8').splitlines()
    after=candidate.read_text('utf8').splitlines()
    assert len(prior)==len(after)
    diffs=[(x,y) for x,y in zip(prior,after) if x!=y]
    assert [x.split('|')[1].strip() for x,y in diffs]==['POL-007','POL-008','POL-011','POL-013','POL-014']
    assert all(x.split('|')[-2:]==y.split('|')[-2:] for x,y in diffs)
print('PASS')
