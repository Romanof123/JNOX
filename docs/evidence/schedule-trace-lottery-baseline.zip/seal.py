from pathlib import Path
import hashlib,zipfile,json,struct
p=Path(__file__).resolve().parent
for d in (p/'new').iterdir():
 if not (d/'score.json').exists():continue
 rows=json.loads((d/'score.json').read_text())['raw_rows']
 b=next((d/'guest').glob('*3LOG*.bin')).read_bytes()
 assert [list(struct.unpack_from('<7Q',b,i*56)) for i in range(len(rows))]==rows
 checks=[]
 for i in range(5):
  f=next((d/'guest').glob('*FIRST_FAILURE*.'+str(i)+'.bin'),None)
  checks.append(int.from_bytes(f.read_bytes(),'little') if f else None)
 (d/'ram-check.json').write_text(json.dumps(dict(rows_matching_uart=len(rows),first_failure_symbols=checks)))
files=sorted(x for x in p.rglob('*') if x.is_file() and x.name!='SHA256SUMS')
(p/'SHA256SUMS').write_text(''.join(hashlib.sha256(x.read_bytes()).hexdigest()+'  '+x.relative_to(p).as_posix()+'\n' for x in files))
with zipfile.ZipFile(str(p)+'.zip','w',zipfile.ZIP_DEFLATED) as z:
 for x in files+[p/'SHA256SUMS']:z.write(x,x.relative_to(p))
with zipfile.ZipFile(str(p)+'.zip') as z: assert z.testzip() is None