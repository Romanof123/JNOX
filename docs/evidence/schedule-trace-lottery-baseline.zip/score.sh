set -eu
cd ~/jnox268-269-baseline
out=/mnt/d/codex/jnox268-269-baseline
unzip -p src/docs/evidence/evd-055-diagnostics.zip score.py > "$out/score.py"
for a in lottery1 lottery2 stride lottery-miss stride-delay; do
 d=$out/new/$a
 python3 "$out/score.py" score "$a" "$d/guest/uart.bin" --elf "$d/kernel.elf" --exceptions "$d/guest/int.trace" > "$d/score.json"
done