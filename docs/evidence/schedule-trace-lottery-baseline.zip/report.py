from pathlib import Path
import hashlib,json,re,zipfile,sys,struct
P=Path(__file__).parent
src=Path.home()/'jnox268-269-baseline/src/docs/evidence'
sha=lambda b:hashlib.sha256(b).hexdigest()
def counts(data):
 return [len(re.findall(p,data)) for p in [rb'Taking exception \d+ \[IRQ\]',rb'Taking exception \d+ \[SVC\]',rb'Exception return from']]
def save(name,d): (P/name).write_text(json.dumps(d,indent=2)+'\n')
def fmt(seq):return '/'.join(map(str,seq))
cases=[]; refs={}
for a in ['lottery1','lottery2','stride','lottery-miss','stride-delay','proportional-bench']:
 d=P/'new'/a; g=d/'guest'; trace=g/'int.trace'
 if not trace.exists():trace=d/'boot/run-1/exceptions.log'
 sc=json.loads((d/'score.json').read_text()) if (d/'score.json').exists() else {}
 ram={f.name:f.stat().st_size for f in g.glob('*.bin') if f.name!='uart.bin'}
 t=(g/'uart.bin').read_bytes().splitlines()[-1].decode()
 cases.append(dict(case=a,terminal=t,grants=sc.get('counts'),service=sc.get('whole_service'),IRQ_SVC_ERET=counts(trace.read_bytes()),elf=sha((d/'kernel.elf').read_bytes()),ram=ram,ram_bytes=sum(ram.values()),benchmark_header=list(struct.unpack_from('<5Q',(g/'audit.bin').read_bytes())) if (g/'audit.bin').exists() else None))
for arc in ['feedback-wake-first','strict-class-owner-window-combined']:
 f=src/(arc+'.zip'); ref=refs[arc]={'sha256':sha(f.read_bytes()),'rows':[]}
 with zipfile.ZipFile(f) as z:
  for n in sorted(z.namelist()):
   if n.startswith('control-reruns/'):continue
   if not re.search(r'(?:^|/)ml[^/]+/kernel\.elf$',n):continue
   root=n.rsplit('/',1)[0]; a=root.split('/')[-1]; prefix=root+'/guest/'
   members={i.filename[len(prefix):]:i.file_size for i in z.infolist() if i.filename.startswith(prefix) and not i.is_dir()}
   x=prefix+'int.trace'
   if x not in z.namelist():x=root+'/boot/run-1/exceptions.log'
   uart=z.read(prefix+'uart.bin')
   r={'case':a,'prefix':root,'elf':sha(z.read(n)),'terminal':uart.splitlines()[-1].decode(),'uart_sha256':sha(uart),'guest_files':members,'ram':{k:v for k,v in members.items() if k.endswith('.bin') and k!='uart.bin'},'exception_path':x,'IRQ_SVC_ERET':counts(z.read(x)),'pc':re.search(rb'PC=([a-fA-F0-9]+)',z.read(prefix+'registers.txt'))[1].decode()}
   ref['rows'].append(r)
save('baseline.json',{'source':'ec00258bad43e510e8fd9ee609a98845a4107231','new':cases,'published':refs})
lines=['# CPU0 baseline · CPU0 기준 측정','', 'Source / 소스 `ec00258bad43e510e8fd9ee609a98845a4107231`. Six consecutive first boots, Rust 1.95.0 release --locked on WSL ext4, one virt Cortex-A72, GICv2, TCG default clock. 6개 구성마다 새 ELF를 빌드하고 최초 부팅 결과를 보존했다.','', '| Case | Terminal UART | A/B/C grants | A/B/C ticks | IRQ/SVC/ERET | RAM bytes |','|---|---|---|---|---|---:|']
for c in cases:lines.append('| '+' | '.join([c['case'],c['terminal'],fmt(c['grants']) if c['grants'] else '—',fmt(c['service']) if c['service'] else '—',fmt(c['IRQ_SVC_ERET']),str(c['ram_bytes'])])+' |')
lines+=['','Lottery-miss expected refusal at seed fixture slot 0, two ticks against one. Stride-delay charged A three ticks and advanced pass by 2,162,160. 복권 거부와 지연 stride의 실제 서비스량을 각각 기록했다. Benchmark RAM has 81 populated rows. Ordinary runs retained symbol RAM and terminal registers. Benchmark observer retained witness RAM and QMP status. Its profile did not collect terminal PC. Guest measurements establish virtual CPU observations only.','','## Published multilevel records · 공개된 다단계 측정','','All 20 rows below come from feedback-wake-first.zip. The older strict-class-owner-window-combined.zip contains 16 corresponding configurations. baseline.json records each original path, both archives’ ELF hashes, capture inventory, sizes, terminal PC, IRQ/SVC/ERET counts and UART digest. Reused observations retain their original build provenance. 아래 20건은 공개 원본에서 읽었고 재부팅하지 않았다. 처음 16개 구성은 두 자료 모두에 존재하며 ELF별 해시는 JSON에 있다.','']
for k,v in refs.items():lines.append('- '+k+'.zip `'+v['sha256']+'` ('+str(len(v['rows']))+' cases)')
lines+=['','| Case | Terminal UART | IRQ/SVC/ERET | RAM bytes | ELF SHA-256 |','|---|---|---|---:|---|']
for c in refs['feedback-wake-first']['rows']:lines.append('| '+' | '.join([c['case'],c['terminal'],fmt(c['IRQ_SVC_ERET']),str(sum(c['ram'].values())),c['elf']])+' |')
(P/'report.en-ko.md').write_text('\n'.join(lines)+'\n')