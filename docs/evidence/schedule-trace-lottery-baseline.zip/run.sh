set -eu
base=~/jnox268-269-baseline
src=$base/src
out=$base/new
mkdir "$out"
scripts=/mnt/d/codex/jnox268-269-baseline
export CARGO_HOME=~/jnox-169-first-e203caa/cargo RUSTUP_HOME=~/jnox-169-first-e203caa/rustup
export PATH=$CARGO_HOME/bin:$PATH RUSTUP_TOOLCHAIN=1.95.0
cd "$src/kernel"
rustc +1.95.0 -Vv > "$out/toolchain.txt"
qemu-system-aarch64 --version > "$out/qemu.txt"
for app in lottery1 lottery2 stride lottery-miss stride-delay proportional-bench; do
 d=$out/$app
 mkdir "$d"
 flags=()
 if [ "$app" = proportional-bench ]; then
 unset JNOX_BOARD JNOX_PROFILE JNOX_APP
 flags=(--features proportional-bench)
 else
 export JNOX_BOARD=virt JNOX_PROFILE=proportional JNOX_APP=$app
 fi
 (env | grep '^JNOX_' || true; echo cargo +1.95.0 build --release --locked -j1 "${flags[@]}") > "$d/config.txt"
 cargo +1.95.0 build --release --locked -j1 "${flags[@]}" > "$d/build.log" 2>&1
 cp target/aarch64-unknown-none/release/jnox-kernel "$d/kernel.elf"
 if [ "$app" = proportional-bench ]; then
 cd "$src"
 printf '#!/bin/bash\nexec python3 -B "%s/tools/proportional_capture.py" "$@"\n' "$src" > "$base/capture"
 chmod +x "$base/capture"
 rc=0
 PROPORTIONAL_CAPTURE_DIR="$d/guest" python3 tools/qemu_boot.py --runs 1 --profile proportional --kernel "$d/kernel.elf" --qemu "$base/capture" --capture-dir "$d/boot" > "$d/observer.log" 2>&1 || rc=$?
 echo "$rc" > "$d/observer.rc"
 else
 python3 "$scripts/raw.py" "$d/kernel.elf" "$d/guest" > "$d/observer.log" 2>&1
 fi
 echo "captured $app"
done
cp -r "$out" "$scripts/"