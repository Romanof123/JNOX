#include <stdint.h>
uint64_t pkt(uint64_t h,uint64_t s){ for(unsigned j=0;j<32;j++){uint64_t v=j?(s<<j)|(s>>(64-j)):s;h=(h^(v^j))*1099511628211ULL;}return h;}
uint64_t digest(unsigned slot,uint64_t count){uint64_t h=slot+1;for(uint64_t s=1;s<=count;s++)h=pkt(h,s);return h;}
