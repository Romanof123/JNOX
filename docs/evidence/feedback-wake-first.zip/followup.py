from pathlib import Path
import zipfile,sys,struct,json,subprocess,re
root=Path(__file__).parent
repo=Path.home()/'jnox265-first'
sys.path.insert(0,str(repo/'tools'))
import ordinary_multilevel_replay as replay,mlq_receipt_check as receipts
z=zipfile.ZipFile('/tmp/265base.zip')
def ro(b):
 o=struct.unpack_from('<Q',b,40)[0]; s,n,i=struct.unpack_from('<HHH',b,58)
 rows=[struct.unpack_from('<IIQQQQIIQQ',b,o+j*s) for j in range(n)]
 tab=rows[i][4]
 for x in rows:
  if b[tab+x[0]:].split(bytes(1),1)[0]==b'.rodata':return x[3],b[x[4]:x[4]+x[5]]
results={}
for d in sorted((root/'legacy').iterdir()):
 key=d.name;app,mode=key.rsplit('-',1);g=d/'guest';pref='originals/'+key+'/'
 old=z.read(pref+'kernel.elf');new=(d/'kernel.elf').read_bytes()
 v,a=ro(old);v2,b=ro(new); assert v==v2 and len(a)==len(b)
 diff={i for i in range(len(b)) if a[i]!=b[i]};left=diff.copy();sites=[]
 for i in range(0,len(b)-23,8):
  p,n,l,c=struct.unpack_from('<QQII',a,i);p2,n2,l2,c2=struct.unpack_from('<QQII',b,i)
  if p!=p2 or n!=n2 or not (v<=p<v+len(a) and 0<n<128):continue
  name=a[p-v:p-v+n]
  if name.endswith(b'.rs') and name==b[p-v:p-v+n] and (l,c)!=(l2,c2):
   sites.append([i,name.decode(),l,c,l2,c2]);left-=set(range(i+16,i+24))
 assert not left,(key,left)
 result=dict(rodata_difference_bytes=len(diff),locations=sites)
 if app in ('mlq-admit','mlq-refuse'):
  for data in [(g/'mlq_admission_witness.bin').read_bytes(),z.read(pref+'guest/audit.bin')]:receipts.check(data,app=='mlq-refuse')
  result['strict_receipt_verified']=True
 if mode=='trace' and app in ('mlq','mlfq'):
  result['new_decisions']=replay.replay((g/'ordinary_multilevel_witness.bin').read_bytes(),app=='mlfq')
  result['historical_repeat_decisions']=replay.replay(z.read('post/trace-repeats/originals-'+app+'/guest/audit.bin'),app=='mlfq')
 for tag,irq in [('new',(g/'int.trace').read_bytes()),('old',z.read(pref+'guest/int.trace'))]:result[tag+'_irq_svc']=[irq.count(b'[IRQ]'),irq.count(b'[SVC]')]
 results[key]=result
(root/'legacy-analysis.json').write_text(json.dumps(results,indent=2))
src=z.read('limits.py').decode()
src=src.replace("r=p.Path.home()/'jnox262-combined'","r=p.Path(__file__).parent").replace("(r/'post/trace-repeats').glob('*')","(r/'legacy').glob('*-trace')").replace("if not d.is_dir():continue","if not any(a in d.name for a in ('blocked','exited','saturated','delayed')):continue").replace("guest/audit.bin","guest/ordinary_multilevel_witness.bin").replace("d.name.endswith(('blocked','exited'))","any(a in d.name for a in ('blocked','exited'))").replace("d.name.endswith('blocked')","'blocked' in d.name").replace("d.name.endswith('saturated')","'saturated' in d.name").replace("'post/limits.json'","'legacy-limits.json'")
exec(src)
