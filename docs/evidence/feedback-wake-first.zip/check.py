from pathlib import Path
import struct,ctypes as c,re,json,subprocess
root=Path(__file__).parent
lib=c.CDLL('/tmp/265digest.so')
for f in [lib.digest,lib.pkt]:
 f.argtypes=[c.c_uint64]*2;f.restype=c.c_uint64
result={}
for d in sorted(root.glob('mlfq-wake*')):
 w=lambda p:list(x[0] for x in struct.iter_unpack('<Q',p.read_bytes()))
 a=w(d/'guest/audit.bin'); h=a[:40]; rows=[a[40+15*i:55+15*i] for i in range(h[4])]
 unit=h[1];assert h[2]==23*unit
 ex=(d/'boot/run-1/exceptions.log').read_text()
 if 'refuse' in d.name:
  assert h[0]==2 and h[3]+1==h[2] and not any(a[4:]) and not ex.strip()
  result[d.name]=dict(dispatches=0);continue
 assert h[0]==4 and h[3]==h[2] and len(rows)==13
 assert [r[9] for r in rows]==[0,1,2,3,0,1,2,3,0,1,2,3,4]
 assert [r[0] for r in rows]==[0,4,4,4,4,2,3,4,4,1,1,1,1]
 total=0; saved={};eret=[int(v,16) for v in re.findall(r'Exception return .* PC 0x([0-9a-f]+)',ex)]
 elr=[int(v,16) for v in re.findall(r'with ELR 0x([0-9a-f]+)',ex)]
 tr=w(d/'guest/trace.bin') if (d/'guest/trace.bin').exists() else []
 assert len(eret)==len(elr)==12 and ex.count('[IRQ]')==6
 for i,r in enumerate(rows):
  if i:
   assert r[2]==rows[i-1][9] and r[3]==rows[i-1][10] and r[3]<=r[5]<=r[4]+unit
   if i<=4 or i==8:assert r[4]-r[3]==2*unit
   if 5<=i<=7:assert r[4]-r[3]==10*unit-total
   prev=total;total+=r[5]-r[3];assert total==r[6] and r[7]==(prev//(10*unit)!=total//(10*unit))
   saved[r[2]]=(r[12],elr[i-1])
  if i<12 and r[9] in saved:assert saved[r[9]]==(r[13],eret[i])
  if tr:
   t=tr[2+131*i:2+131*(i+1)]
   assert t[3]==r[2] and t[8]==r[12] and t[10]==r[9] and t[13]==r[13]
   if i:assert t[58]==elr[i-1]
   if i<12:assert t[14]==eret[i]
 assert rows[5][11]==rows[6][11]==rows[7][14]==1 and rows[7][11]==2 and rows[6][1]==1
 assert [hex(rows[i][8]) for i in [5,6,7,8]]==['0x234','0x3412','0x4123','0x1234']
 pre=rows[7][6]-rows[6][6];post=rows[8][6]-rows[7][6];gap=sum(r[10]-r[5] for r in rows[6:9]);partial=h[9]-rows[8][10]
 assert rows[6][5]==h[5] and rows[7][5]==h[6] and post==h[7] and rows[8][10]==h[8] and gap==h[10] and partial==h[16]
 assert h[15]==h[9]-h[5]==pre+post+gap+partial and pre<=11*unit and post<=3*unit and gap<=2*unit and 0<=partial<=unit and h[9]<=rows[9][5]
 assert h[12]==rows[5][12]==rows[8][13]
 dg=[lib.digest(i,n) for i,n in enumerate(h[20:24])];assert dg==h[24:28]
 supplied=lib.digest(1,h[32]);assert h[17]==lib.digest(3,1) and supplied==h[19]
 receipt=lib.pkt(dg[0]^supplied,h[20]+1)
 receipts=[receipt]+[lib.pkt(dg[i]^receipt,h[20+i]+1) for i in range(1,4)]
 assert receipts==h[28:32]
 asm=subprocess.check_output(['aarch64-linux-gnu-objdump','-d',str(d/'kernel.elf')]).decode()
 ix=asm.index('    %x:'%elr[4]);(d/'resume-asm.txt').write_text(asm[ix-100:ix+1500])
 result[d.name]=dict(W=h[5],E=h[9],elapsed=h[15],pre=pre,post=post,gap=gap,partial=partial,blocked_frame=hex(h[12]),resumed_pc=hex(elr[4]),receipts=receipts,packets=h[20:24],irq=6,rows=rows)
(root/'independent.json').write_text(json.dumps(result,indent=2))
