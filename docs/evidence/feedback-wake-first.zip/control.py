import pathlib as p,sys,zipfile,subprocess as s,os,shutil,hashlib,re,json
root=p.Path.home()/'jnox265-first'
out=p.Path('/mnt/d/codex/jnox265-first')
z=zipfile.ZipFile('/tmp/265base.zip')
raw=z.read('raw.py').decode().replace("p.Path.home()/'jnox262-combined/src/tools'","p.Path.home()/'jnox265-first/tools'").replace("<=131072","<=4194304")
(out/'raw.py').write_text(raw)
env=dict(os.environ,PATH=str(p.Path.home()/'jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')+':'+os.environ['PATH'],JNOX_BOARD='virt',JNOX_PROFILE='multilevel')
import struct
from io import BytesIO
def sections(b):
 off=struct.unpack_from("<Q",b,40)[0];sz,num,idx=struct.unpack_from("<HHH",b,58)
 xs=[struct.unpack_from("<IIQQQQIIQQ",b,off+i*sz) for i in range(num)]
 tab=xs[idx][4];return {b[tab+x[0]:].split(bytes(1),1)[0].decode():(x[3],x[5],hashlib.sha256(b[x[4]:x[4]+x[5]] if x[1]!=8 else bytes(x[5])).hexdigest()) for x in xs if x[2]&2}
results={}
for f in z.namelist():
 if not re.fullmatch('originals/ml[^/]+/kernel.elf',f):continue
 key=f.split('/')[1]; app,mode=key.rsplit('-',1); d=out/'legacy'/key; d.mkdir(parents=True)
 e=dict(env,JNOX_APP=app)
 if mode=='trace':e['JNOX_MULTILEVEL_TRACE']='1'
 with (d/'build.log').open('wb') as log:s.run(['python3','tools/build_kernel.py'],cwd=root,env=e,stdout=log,stderr=s.STDOUT,check=True)
 elf=d/'kernel.elf';shutil.copyfile(root/'kernel/target/aarch64-unknown-none/release/jnox-kernel',elf)
 with (d/'capture.log').open('wb') as log:s.run(['python3',str(out/'raw.py'),str(elf),str(d/'guest')],stdout=log,stderr=s.STDOUT,check=True)
 a=z.read(f); b=elf.read_bytes(); old=sections(a);new=sections(b)
 pref=f.rsplit('/',1)[0]+'/guest/'
 ua=z.read(pref+'uart.bin');ub=(d/'guest/uart.bin').read_bytes()
 pc=lambda x:re.search(rb'PC=([a-fA-F0-9]+)',x)[1].decode()
 results[key]=dict(exact=a==b,same_text=old['.text']==new['.text'],old=old,new=new,uart_equal=ua==ub,old_uart=ua.decode(),new_uart=ub.decode(),old_pc=pc(z.read(pref+'registers.txt')),new_pc=pc((d/'guest/registers.txt').read_bytes()),wake_symbol='mlfq_wake_witness' in (d/'guest/symbols').read_text(),ram={n.split('/')[-1]:[len(z.read(n)),(d/'guest'/n.split('/')[-1]).stat().st_size if (d/'guest'/n.split('/')[-1]).exists() else None] for n in z.namelist() if n.startswith(pref) and n.endswith('.bin')})
 (out/'controls.json').write_text(json.dumps(results,indent=2))

