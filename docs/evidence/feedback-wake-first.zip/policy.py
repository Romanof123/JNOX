from pathlib import Path
import struct
root=Path(__file__).parent
d=root/'mlfq-wake-trace/guest'
b=(d/'trace.bin').read_bytes()
n,hz=struct.unpack_from('<QQ',b);u=hz//100;p=10*u
q=list(range(4));period_service=[0]*4;life=[0]*4;total=0;owner=4
def rank_grant(i):
 s=period_service[i]
 if s<2*u:return 2,2*u-s
 if s<6*u:return 1,6*u-s
 return 0,6*u-(s-6*u)%(6*u)
for i in range(n):
 t=struct.unpack_from('<131Q',b,16+1048*i)
 kind,arg,res,out,start,due,stop,boost,frame,source,nxt,packed,reported=t[:13]
 assert owner==out
 if i:
  assert due==start+min(rank_grant(owner)[1],p-total%p)
  inc=stop-start;prev=total;total+=inc;period_service[owner]+=inc;life[owner]+=inc
  if kind==4:assert source&1023==30 and source>>32&7==5
  else:assert source>>26==0x15 and source&65535==kind
  if kind==3:assert arg==0 and res==1;q.append(arg)
  if kind not in (1,2):q.append(owner)
  assert bool(boost)==(prev//p!=total//p)
  if boost:period_service=[0]*4
 assert reported==total and list(t[23:27])==life
 assert list(t[15:19])==[rank_grant(j)[0] for j in range(4)] and list(t[19:23])==[rank_grant(j)[1] for j in range(4)]
 assert packed==sum((j+1)*16**k for k,j in enumerate(reversed(q)))
 owner=max(q,key=lambda j:rank_grant(j)[0],default=4);assert nxt==owner
 if q:q.remove(owner)
print(n,'full rows agree with independent four-slot service/queue oracle')
