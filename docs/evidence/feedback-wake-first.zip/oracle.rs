#[path="/home/ywcho/jnox265-first/kernel/src/wake_bound.rs"] mod candidate;
fn main(){
 let mut cases=0;
 let max=u64::MAX/23;
 for u in (0..=8192).chain((max-4096)..=(max+4096)).chain((u64::MAX-4096)..=u64::MAX) {
  for n in 0..=8 {
   let expected=if n==4 && u>0 {u64::try_from((u as u128)*23).ok()}else{None};
   assert_eq!(candidate::bound(u,n),expected);
   let x=expected.unwrap_or(u64::MAX);
   for lim in [0,1,x.saturating_sub(1),x,x.saturating_add(1),u64::MAX]{
    assert_eq!(candidate::admits(u,n,lim),expected.is_some_and(|v|v<=lim));cases+=1;
   }
  }
 }
 println!("{cases} checked");
}
