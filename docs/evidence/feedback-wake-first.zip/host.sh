set -eu
d=/mnt/d/codex/jnox265-first
cd ~/jnox265-first
git show eb3d00e4:docs/evidence/strict-class-owner-window-combined.zip >/tmp/265base.zip
python3 "$d/followup.py"
export PATH=~/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH
{ rustc -Vv; qemu-system-aarch64 --version; git rev-parse HEAD; stat -f -c %T .; rustc --edition=2024 --test tools/mlfq_wake_bound_tests.rs -o /tmp/tests265; /tmp/tests265; rustc --edition=2024 -O "$d/oracle.rs" -o /tmp/o265; /tmp/o265; } > "$d/host.log" 2>&1
cat "$d/host.log"
