set -u
cd ~/jnox265-first
export CARGO_HOME=~/jnox-169-first-e203caa/cargo RUSTUP_HOME=~/jnox-169-first-e203caa/rustup
export PATH=$CARGO_HOME/bin:$PATH RUSTUP_TOOLCHAIN=1.95.0 JNOX_BOARD=virt JNOX_PROFILE=multilevel
out=~/jnox265-record
mkdir -p "$out"
for app in mlfq-wake mlfq-wake-refuse; do
 for mode in plain trace; do
 d=$out/$app-$mode
 mkdir "$d" || exit 9
 export JNOX_APP=$app
 unset JNOX_MULTILEVEL_TRACE
 if [ "$mode" = trace ]; then export JNOX_MULTILEVEL_TRACE=1; fi
 python3 tools/build_kernel.py >"$d/build.log" 2>&1
 b=$?
 echo $b > "$d/build.rc"
 if [ $b -eq 0 ]; then
 cp kernel/target/aarch64-unknown-none/release/jnox-kernel "$d/kernel.elf" || exit 8
 MLFQ_WAKE_CAPTURE_DIR="$d/guest" python3 tools/qemu_boot.py --profile "$app" --kernel "$d/kernel.elf" --qemu tools/mlfq_wake_capture.py --runs 1 --capture-dir "$d/boot" >"$d/observer.log" 2>&1
 echo $? > "$d/observer.rc"
 fi
 done
done
cd "$out"
find . -type f -print0 | sort -z | xargs -0 sha256sum > ../jnox265-seal
cp ../jnox265-seal FIRST.sha256
cp -r . /mnt/d/codex/jnox265-first/
