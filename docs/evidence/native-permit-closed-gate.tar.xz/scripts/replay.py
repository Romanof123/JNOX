"""Recompute measurements from cold capture, per-slot translated RAM and package input ELFs."""
import argparse
from collections import Counter, deque
import functools
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import tarfile
import zlib

REV = 'b9c4d7aafed05aeecc695dc39f0c81f4e3a7367e'
TREE = 'b57eb56d86185b984b3117c7af121ba76b1d8ac5'
FIXTURE = bytes.fromhex('01012c000100010101000000000000000400000000000000000000000000000014000000010000000995750b')
SKIP = 1 << 63
def signed(v):
    return v - (1 << 64) if v >= SKIP else v
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def gitid(kind,data):
    return hashlib.sha1(f'{kind} {len(data)}\0'.encode()+data).hexdigest()
def source(p):
    commit=(p/'commit').read_bytes(); tree=(p/'tree').read_bytes()
    assert gitid('commit',commit)==REV and gitid('tree',tree)==TREE
    assert commit.splitlines()[:2]==[('tree '+TREE).encode(),b'parent a7aa0a659f239950fa29b3326813cf4b35d846f9']
    expected={line.split('\t',1)[1]:tuple(line.split('\t')[0].split()) for line in (p/'file-list').read_text().splitlines()}
    nodes={}
    def node(path,mode,oid):
        parent,_,name=path.rpartition('/')
        nodes.setdefault(parent,[]).append((name,mode,oid))
    with tarfile.open(p/'build-source.tar.gz') as t:
        for item in t:
            if item.isdir(): continue
            mode,kind,oid=expected.pop(item.name)
            assert item.isfile() and kind=='blob' and gitid(kind,t.extractfile(item).read())==oid
            assert bool(item.mode&0o111)==(mode=='100755')
            node(item.name,mode,oid)
    assert not expected
    while any(nodes.keys()-{''}):
        path=max(nodes.keys()-{''},key=lambda x:x.count('/'))
        entries=nodes.pop(path)
        raw=b''.join(f'{m} {n}\0'.encode()+bytes.fromhex(h) for n,m,h in sorted(entries,key=lambda x:(x[0]+('/' if x[1]=='40000' else '')).encode()))
        node(path,'40000',gitid('tree',raw))
    assert all(f'{mode} {n}\0'.encode()+bytes.fromhex(oid) in tree for n,mode,oid in nodes[''])

@functools.lru_cache(None)
def symbols(elf):
    table={}
    for l in subprocess.check_output(['aarch64-linux-gnu-nm','-CS',str(elf)],text=True).splitlines():
        w=l.split(None,3)
        if len(w)==4: table[w[3]]=(int(w[0],16),int(w[1],16))
    return table
def split(buf,n):
    assert len(buf)%n==0
    return [buf[i:i+n] for i in range(0,len(buf),n)]
def single(vals):
    v,=vals
    return v
def write_json(path,obj):
    path.write_text(json.dumps(obj,indent=1)+'\n')

class Boot:
    def __init__(self,root,run):
        self.policy,self.name=run.name.split('-',1)
        self.run=run.name
        cap=run/'cap'; pkg=root/'pkg'/run.name
        self.case='gate-invalid' if self.name in ('denial','guards') else self.name
        m=json.loads((pkg/'manifest.json').read_text())
        launch=json.loads((cap/'launch.json').read_text()); self.ram=(cap/'ram.bin').read_bytes(); self.base=launch['ram_base']
        kernel=cap/'kernel.elf'; self.sym=symbols(kernel)
        receipt=json.loads((cap/'session.json').read_text())
        assert (run/'status').read_text().strip()=='0' and receipt['marker']=='EXIT 71'
        assert all(sha(cap/name)==h for name,h in receipt['hashes'].items())
        assert m==launch['argument_package'] and m['commit']==launch['revision']==REV and m['tracked_changes']==''
        assert launch['kernel_sha256']==m['kernel_elf_sha256']==sha(kernel)==sha(pkg/'kernel.elf')
        assert sha(pkg/'build.log')==m['build_log_sha256']
        assert launch['argv'][1:-4]==['-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-no-reboot','-qmp','stdio']
        assert launch['argv'][-4]=='-serial' and launch['argv'][-2]=='-kernel'
        self.lines=(cap/'uart.bin').read_text().splitlines()
        self.apps=[pkg/s['elf'] for s in m['slots']]
        app_root=root/('controls' if self.name=='guards' else 'apps')
        assert [sha(v) for v in self.apps]==[s['elf_sha256'] for s in m['slots']]==[sha(app_root/(r+'.elf')) for r in ('sender','controller','supervisor')]==[s.split()[-1] for s in self.lines if re.match(r'^NATIVE EL0 (?:PEER2? )?ELF ',s)]
        assert m['board']=='virt' and m['app']=='process' and m['profile']=='native'
        assert m['policy']==self.policy and m['quantum_ticks']==(625000 if self.policy=='rr' else None)
        assert [s['priority'] for s in m['slots']]==[6,7,4] and all(s['argv']==['/bin/app',self.case] for s in m['slots'])
        assert m['loan_route']==dict(producer=0,consumer=1) and m['loan_pool']['ring_entries']==2 and m['loan_pool']['page_bytes']==4096 and m['loan_pool']['pages']==3
        assert m['ipc_routes']==[dict(caller=2,server=0),dict(caller=2,server=1)]
        self.opt=self.name in ('gate-invalid','gate-saturation','guards')
        assert ('safety_downstream_injector' in m)==self.opt and ('--safety-downstream-injector' in m['package_argv'])==self.opt
        if self.opt: assert m['safety_downstream_injector']==dict(scenario=self.case,issuer_slot=2,command=5,event=14,maximum_attempts_per_generation=64,fixture_bytes=44)
        assert m['safety_qualification'] and not any(k in m for k in ['safety_interference','safety_watchdog','safety_boundary'])
        self.ev=self.rows('NATIVE SAFETY EVENT')
        self.q=self.rows('NATIVE QUAL ROW')
        hz,n,kept,dropped=single(self.rows('NATIVE QUAL COUNTS'))
        assert hz==62500000 and n==kept==len(self.q) and dropped==0
        assert all(r[0]==i and len(r)==13 for i,r in enumerate(self.q))
        assert self.rows('NATIVE SAFETY DROPPED')==[[0]] and all(len(r)==10 for r in self.ev)
        assert all(b[1]>=a[1] for a,b in zip(self.ev,self.ev[1:]))
        self.hz=hz; self.maps=self.rows('NATIVE LOAN MAP'); self.state=single(self.rows('NATIVE LOAN STATE'))
        assert self.state[-2:]==[len(self.maps),0] and self.state[2]==0 and self.state[0]==self.state[1]
        assert self.rows('NATIVE LOAN PAGE')==[[i,0,0,0] for i in range(3)]
        self.pagebase,self.poolsize=self.sym['jnox_native_loan_pages']
        assert self.poolsize==3*4096 and len(self.ram)==launch['ram_bytes']
        register,_=self.sym['jnox_virtual_permit_enable']
        assert self.phys(register,8)==bytes(8)
        exits=sorted(self.rows('NATIVE EL0 EXIT PID'))
        assert exits==[[0,71],[1,72],[2,96 if self.name=='denial' else 73]]
        self.out=dict(run=self.run,source=REV,kernel_sha256=sha(kernel),ram_sha256=sha(cap/'ram.bin'),uart_sha256=sha(cap/'uart.bin'),session_sha256=sha(cap/'session.json'),manifest_sha256=sha(pkg/'manifest.json'),app_sha256=[sha(v) for v in self.apps],qemu_sha256=launch['qemu_sha256'],qemu_version=launch['qemu_version'].splitlines()[0],exits=exits,fixed_dropped=single(self.rows('NATIVE FIXED DROPPED'))[0],safety_dropped=0,qual_dropped=0,loan_map_dropped=0,hz=hz)
    def rows(self,tag): return [list(map(int,l[len(tag):].split())) for l in self.lines if l.startswith(tag+' ')]
    def events(self,k): return [r for r in self.ev if r[0]==k]
    def phys(self,addr,n):
        off=addr-self.base; assert 0<=off<=len(self.ram)-n
        return self.ram[off:off+n]
    def data(self,pid,name):
        base,size=self.sym['jnox_kernel::native_el0_mmu::SPACES']; va,n=symbols(self.apps[pid])[name]; out=bytearray()
        while len(out)<n:
            addr=va+len(out); page=base+pid*(size//3)
            for shift in (30,21,12):
                pte=int.from_bytes(self.phys(page+8*((addr>>shift)&511),8),'little'); assert pte&3==3
                page=pte&0x0000fffffffff000
            off=addr&4095; out+=self.phys(page+off,min(4096-off,n-len(out)))
        return bytes(out)
    def words(self,pid,name): return [x for x, in struct.iter_unpack('<Q',self.data(pid,name))]
    def mappings(self):
        leaves=[[0,0,0] for _ in range(3)]
        for op,pid,slot,length,*v in self.maps:
            before,after=v[:3],v[3:]
            assert leaves[slot]==before and pid in (0,1)
            if op in (1,3):
                assert not any(before) and sum(bool(x) for x in after)==1 and after[pid]&0xc3==(0x43 if op==1 else 0xc3)
                assert pid==(0 if op==1 else 1) and after[pid]&(3<<53)==3<<53
                assert after[pid]&0x0000fffffffff000==self.pagebase+slot*4096
            else: assert op in (2,4) and not any(after) and before[pid] and sum(bool(x) for x in before)==1
            leaves[slot]=after
        assert not any(any(x) for x in leaves)
        kernel_l3,_=self.sym['jnox_native_loan_l3_tables']
        assert all(self.phys(kernel_l3+4096*pid,24)==bytes(24) for pid in range(3))

def guard(b):
    sup=list(map(signed,b.words(2,'supervisor_control')))
    assert sup[:73]==[-116,-16,-116,-116,0,0]+[-11]*62+[-75,-116,-16,0,-32]
    assert list(map(signed,b.words(0,'sender_control')))[:6]==[-13,-32,-32,-32,-116,-116]
    assert list(map(signed,b.words(1,'controller_control')))[:2]==[-13,-116]
    assert b.data(1,'fixture_pages')==(FIXTURE+bytes(4052))*2
    w=b.words(0,'writer_handles'); r=b.words(1,'reader_handles')
    assert len(set(w+r[1:]))==5 and r[0]==w[0]
    assert [(v[0],v[1],v[2]) for v in b.maps]==[(1,0,0),(2,0,0),(1,0,1),(2,0,1),(1,0,2),(3,1,0),(4,1,0),(4,0,2),(3,1,0),(4,1,0),(3,1,1),(4,1,1)]
    a=b.events(14); services=[r for r in b.events(5) if r[3:5]==[59,5]]
    assert len(a)==len(services)==75
    assert [signed(v[5]) for v in a]==sup[:2]+[-13,-13]+sup[2:73]
    assert [v[3] for v in a][:4]==[2,2,0,1]
    for v,svc in zip(a,services):
        assert v[3]==svc[2] and v[5]==svc[5] and v[2]<=v[1]<=svc[1]
        assert v[8]-v[7]==(1 if v[5]==0 else 0)
        if signed(v[5])==-11: assert v[7:9]==[2,2]
    assert [v[6] for v in a if not v[5]][:2]==r[1:]
    assert a[-5][7:9]==[0,0] and single(b.events(8))[2]==1 and a[-1][2]>b.events(8)[0][1]
    assert all(v[7:9]==[0,1] for v in a if v[4]==2 and not v[5])
    assert not b.events(2) and not b.events(3)
    b.out.update(supervisor_status=sup[:73],writer_grants=w,reader_grants=r,first_gen_full_denials=62,attempt65_at_empty=-75,post_controller_exit=-32,live_fixture_pages=2,bytes_verified_per_page=4096,terminated_pte_zero=True)

def endpoints(b,pid,count,epoch):
    marks={tuple(r[2:6]):r for r in b.q if r[1]==1}
    out=[]
    for i in range(count):
        job,phase=(i//2,1+i%2) if pid==1 else (i,3)
        a,start,c=[marks[(pid,job,phase,k)] for k in (1,2,3)]
        target=a[6]; assert a[6]==start[6]==c[6]==epoch+i*(156250 if pid==1 else 625000)
        if i+1<count:
            nxt=next(v for v in b.q[c[0]+1:] if v[1]==1 and v[2]==pid)
            assert nxt[5]==1
            block=next((v for v in b.q[nxt[0]+1:] if v[1]==2 and v[2]==62 and v[3]==nxt[8] and v[8]==pid),None)
        else:
            block=next((v for v in b.q[c[0]+1:] if v[1]==2 and v[2]==22 and v[8]==pid),None)
        if block and block[6]&(1<<pid) and not block[7]&(1<<pid):
            lo,hi=max(c[7],block[4])-target,block[5]-target
            assert 0<=lo<=hi
        else:
            lo,hi=c[7]-target,None
        out.append(dict(job=job,phase=phase,lo=lo,hi=hi))
    return out

def ordinary(b):
    name=b.name; closed=name!='healthy'; injected=b.opt
    caseid={'silence':3,'healthy':1,'gate-invalid':11,'gate-saturation':12}[b.case]
    hdr=[b.words(i,'admission_header') for i in range(3)]
    epoch=hdr[0][2]; hz=b.hz
    assert all(r[:4]==[0x51414c31,caseid,epoch,hz] for r in hdr)
    assert [r[4] for r in hdr]==[8,32,13 if b.case.startswith('gate-') else 8]
    assert [r[5] for r in hdr]==[0,0,96 if name=='denial' else 0]
    ctl=split(b.words(1,'admission_controller_rows'),18); sup=split(b.words(2,'admission_supervisor_rows'),12)[:hdr[2][4]]
    assert b.words(0,'admission_sender_count')==[8]
    sr=split(b.words(0,'admission_sender_rows'),10)[:8]; sb=split(b.data(0,'admission_sender_bytes'),44)[:8]
    assert [r[0] for r in sr]==list(range(8)) and all(r[1]==epoch+i*625000 and r[4]==i+1 for i,r in enumerate(sr))
    assert all(r[5]==(r[1] if i<2 else r[2]) for i,r in enumerate(sr))
    assert all(r[7:10]==([0,0,0] if i<3 or not closed else [(1<<64)-32,SKIP,0]) for i,r in enumerate(sr))
    attempts=split(b.words(2,'admission_gate_attempts'),5)[:single(b.words(2,'admission_gate_attempt_count'))]
    cmds=[r for r in b.events(5) if r[3:5]==[59,5]]
    qcmd=[r for r in b.q if r[1:5]==[4,2,59,5]]
    inj=b.events(14)
    assert len(attempts)==len(cmds)==len(qcmd)=={'gate-invalid':7,'gate-saturation':21,'denial':7}.get(name,0)
    assert len(inj)==(len(attempts) if injected else 0)
    for r,k,q in zip(attempts,cmds,qcmd):
        assert r[2]<=q[5]<=k[1]<=q[7]<=r[3] and r[4]==k[5]==q[8] and k[2]==2 and k[6]==1
        if name=='denial': assert signed(r[4])==-22
    receives=b.events(7); rx={r[2]:r for r in receives}; assert len(rx)==len(receives)
    pubs=b.events(11); normal={r[6]:(r,data) for r,data in zip(sr,sb) if r[8]==0}
    assert len(pubs)==len(normal)==(3 if closed else 8)
    for v in pubs:
        r,_=normal[v[4]]; assert v[5:10]==[0,1,1,r[4],r[5]] and r[2]<=v[2]<=v[3]<=v[1]<=r[3]
    pending=deque(); seen=set(); success={}; full=[]; drains=[]; frames=[]
    for v in b.ev:
        if v[0]==6 and v[2:4]==[0,34] and not v[4]: pending.append(v[6]); assert len(pending)==v[5]
        if v[0]==14:
            status=signed(v[5]); assert v[7]==len(pending) and v[3:5]==[2,1] and v[9]==1
            if status==0:
                assert v[6] not in success and v[6] not in normal and v[6] and len(pending)<2
                pending.append(v[6]); success[v[6]]=v
            else:
                assert status==-11 and len(pending)==2 and v[6]==0
                full.append(v[1])
            assert v[8]==len(pending)
        if v[0]==6 and v[2:4]==[1,35] and not v[4]:
            assert pending.popleft()==v[7] and len(pending)==v[5]; drains.append(v[1])
    assert not pending and set(rx)==set(success)|set(normal)
    assert len(full)>0 if name=='gate-saturation' else len(full)==0
    if full: assert any(f<d<s[2] for f in full for d in drains for s in success.values())
    bycheck=[r for r in b.events(12) if r[3]==1]; completed=b.events(10)
    assert len(bycheck)==len(completed)==len(ctl)==32
    phases=endpoints(b,1,32,epoch); sender_endpoints=endpoints(b,0,8,epoch)
    complete_gap=[[later[2]-prior[3],later[3]-prior[2]] for prior,later in zip(completed,completed[1:])]
    assert all(0<=low<=high for low,high in complete_gap)
    b.out.update(phase_endpoints=phases,sender_endpoints=sender_endpoints,
                 phase_over_1ms_confirmed=[i for i,v in enumerate(phases) if v['lo']>62500],
                 phase_1ms_straddle=[i for i,v in enumerate(phases) if v['lo']<=62500 and (v['hi'] is None or v['hi']>62500)],
                 complete_gaps=complete_gap,complete_gap_max_upper_ticks=max(v[1] for v in complete_gap))
    commits=[r for r in b.events(5) if r[2:5]==[1,60,2]]
    assert len(commits)==len(normal) and [r[7] for r in commits]==list(range(1,len(normal)+1)) and all(r[5]==0 for r in commits)
    lastseq=lastissue=lastrecovery=0
    for i,r in enumerate(ctl):
        assert r[0]==epoch+i*156250 and bycheck[i][2]<=r[1]<=r[2] and r[1]<=completed[i][2]<=completed[i][3]<=r[2]
        assert r[11:13]==r[13:15]
        inside=[v for v in b.ev if r[1]<=v[1]<=r[2]]; poll=single(v for v in inside if v[0] in (6,9) and v[2:4]==[1,35])
        assert poll[4]==r[3]
        if r[3]:
            assert signed(r[3]) in (-11,-32) and r[4:7]==[SKIP,SKIP,0] and not any(v[0]==7 for v in inside)
        else:
            raw=single(v for v in inside if v[0]==7); rel=single(v for v in inside if v[0]==6 and v[2:4]==[1,36])
            h=raw[2]; assert h==rel[6]==poll[7] and rel[4]==0 and rel[8]==poll[8]==44
            assert raw[1]<=poll[1]<=rel[1]<=r[6]<=completed[i][2] and h not in seen
            wire=b''.join(n.to_bytes(8,'little') for n in raw[4:])[:44]
            seq,issue=struct.unpack_from('<QQ',wire,16); crc=zlib.crc32(wire[:40]); stored=int.from_bytes(wire[40:],'little')
            if h in normal:
                assert wire==normal[h][1] and crc==stored and r[4:6]==[0,0] and [seq,issue]==r[13:15]
                c=single(v for v in inside if v[0]==5 and v[2:5]==[1,60,2]); assert c[5:9]==[0,1,seq,issue]
            else:
                assert wire==FIXTURE and (stored^crc)==1 and r[4] in (2,10,17) and r[5]==SKIP
                assert success[h][1]<raw[1] and not any(v[0]==5 and v[2:5]==[1,60,2] for v in inside)
                assert r[13:16]==[lastseq,lastissue,lastrecovery]
            frames.append(dict(phase=i,handle=h,source='fixture' if h in success else 'sender',wire=wire.hex(),crc=crc,wire_crc=stored,rx=raw[1],release=rel[1],private_sample=r[6],local_result=r[4],private=r[13:18],protected=r[10:13]))
            seen.add(h)
        if closed and lastseq==3: assert r[13:16]==[lastseq,lastissue,lastrecovery]
        lastseq,lastissue,lastrecovery=r[13:16]
    assert seen==set(rx)
    # The descriptor transitions and terminal backing RAM corroborate the last wire per used slot.
    mapped=[r[2] for r in b.maps if r[0]==3]
    assert mapped==[r[2]&3 for r in receives]
    latest={}
    for f in frames: latest[f['handle']&3]=bytes.fromhex(f['wire'])
    for slot,wire in latest.items(): assert b.phys(b.pagebase+slot*4096,4096)==wire+bytes(4052)
    writes=b.events(2); assert [(r[4],r[5]) for r in writes]==[(0,1),(1,0)]
    enables=writes[0]; inhibits=writes[1]
    qcomp=[r for r in b.q if r[1]==5 and r[4]]
    assert qcomp and all(r[5]==r[6] and r[7]&1 for r in qcomp)
    irq=[r for r in b.q if r[1]==3 and r[4]==30]
    assert irq and all(r[5]<=r[2]<=r[3]<=r[11] for r in irq)
    def level(t): return None if any(v[2]<=t<v[3] for v in writes) else next((v[5] for v in reversed(writes) if v[3]<=t),0)
    b.out.update(epoch=epoch,original_sender_publications=len(pubs),rearm_transition=enables[2:4],level_at_18ms=level(epoch+18*62500),level_at_37ms=level(epoch+37*62500),private_last=ctl[-1][13:18],terminal_page_slots=sorted(latest),fixture_successes=len(success),full_refusals=len(full),protected_commit_sequences=[r[7] for r in commits],fixture_private_status_counts=dict(Counter(f['local_result'] for f in frames if f['source']=='fixture')),compare_readbacks=len(qcomp),ppi30_events=len(irq),protected_max_check_gap=max(v[2]-u[2] for u,v in zip(bycheck,bycheck[1:])),attempts=attempts,injector_events=inj,frames=frames)
    denies=[r for r in b.events(9) if r[2:4]==[0,33]]
    if not closed:
        assert not b.events(4) and not b.events(3) and not denies and [r[13] for r in ctl][-1]==8
        return
    close=single(b.events(4)); fault=single(b.events(3)); assert close[4:7]==[3,1,3] and fault[3:6]==[1,3,close[7]]
    assert len(denies)==5 and all(signed(v[4])==-32 and v[1]>=close[3] for v in denies)
    assert [lastseq,lastissue]==[3,close[7]] and ctl[-1][16:18]==[0,1]
    previous=single(r for r in sup if r[3]==3)
    assert previous[5]&3==3 and previous[6]&3==2 and previous[7:11]==[3,3,lastissue,lastissue]
    assert commits[-1][1]<previous[1]<=close[2]<=close[3]<=previous[2] and enables[3]<close[2]
    assert all(v[2]>close[3] for v in inj) and all(signed(row[4])==signed(j[5]) and row[2]<=j[2]<=j[1]<=row[3] for row,j in zip(attempts,inj))
    threshold=lastissue+20*hz//1000; detect=fault[2]
    assert threshold<=detect<=fault[1]<=inhibits[2]<=inhibits[3]<single(b.events(8))[1]
    assert close[3]<detect<=fault[1]<inhibits[2]
    bounds=[fault[1]-close[2],inhibits[3]-detect,inhibits[3]-close[2]]
    assert all(x*1000<=ms*hz for x,ms in zip(bounds,(25,5,30)))
    if success:
        assert any(v[1]<threshold for v in success.values()) and any(v[2]>=threshold for v in success.values())
        assert any(f['local_result']==2 and f['private_sample']<threshold for f in frames if f['source']=='fixture')
    b.out.update(close_bracket=close[2:4],last_valid_issue=lastissue,valid_expiry=threshold,detect_bracket=[detect,fault[1]],safe_bracket=inhibits[2:4],close_detect_safe_ticks=bounds,last_issue_to_detect_upper=fault[1]-lastissue,expiry_to_detect_upper=fault[1]-threshold,denied_normal_acquisitions=len(denies),no_option_statuses=[signed(r[5]) for r in cmds] if name=='denial' else [])

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('packet',type=Path); parser.add_argument('out',type=Path); args=parser.parse_args()
    p=args.packet; args.out.mkdir(exist_ok=True,parents=True); source(p/'sources')
    boots=[]
    for run in sorted((p/'runs').iterdir()):
        b=Boot(p,run); b.mappings()
        if b.name=='guards': guard(b)
        else: ordinary(b)
        boots.append(b.out)
        print(b.run, 'PASS', b.out.get('close_detect_safe_ticks'),b.out.get('level_at_18ms'),b.out.get('level_at_37ms'),b.out.get('fixture_successes'),b.out.get('full_refusals'))
    assert {b['run'] for b in boots}=={p+'-'+n for p in ('fifo','rr') for n in ('silence','gate-invalid','gate-saturation','healthy','denial','guards')}
    write_json(args.out/'results.json',boots)
if __name__=='__main__': main()
