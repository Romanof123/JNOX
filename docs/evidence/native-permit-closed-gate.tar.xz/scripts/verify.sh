#!/usr/bin/env bash
set -euo pipefail
packet=$(realpath "${1:-.}")
cd "$packet"
sha256sum --quiet -c SHA256SUMS
export PYTHONDONTWRITEBYTECODE=1
scratch=$(mktemp -d)
trap 'rm -r -- "$scratch"' EXIT
python3 scripts/replay.py "$packet" "$scratch"
python3 scripts/false_claims.py "$packet" > "$scratch/false-claims.txt"
python3 scripts/controls.py "$packet" "$scratch"
cmp "$scratch/results.json" results/results.json
cmp "$scratch/false-claims.txt" results/false-claims.txt
cmp "$scratch/package-controls.json" results/package-controls.json
python3 scripts/report.py "$packet" > "$scratch/REPORT.en-ko.md"
cmp "$scratch/REPORT.en-ko.md" REPORT.en-ko.md
echo "Verified all $(wc -l < SHA256SUMS) original input and report digests and regenerated the twelve-boot record."
