"""Check that the auditor refuses selected false claims against retained original rows."""
import sys
from pathlib import Path
from replay import Boot, ordinary, guard
root=Path(sys.argv[1]).resolve()
def refuses(name,run,change):
    b=Boot(root,root/'runs'/run); change(b)
    try:
        (guard if b.name=='guards' else ordinary)(b)
    except (AssertionError, ValueError):
        print(name,'REFUSED')
        return
    raise RuntimeError('false claim accepted: '+name)
def edit_event(b,kind,predicate,col,x):
    row=next(v for v in b.ev if v[0]==kind and predicate(v))
    row[col]=x(row[col])
def flip_private(b,pid,symbol,offset):
    read=b.data
    def changed(p,n):
        v=read(p,n)
        if (p,n)==(pid,symbol):
            data=bytearray(v); data[offset]^=1; return bytes(data)
        return v
    b.data=changed
b1='fifo-gate-saturation'
refuses('full recorded at occupancy one',b1,lambda b:edit_event(b,14,lambda r:r[5]!=0,7,lambda _:1))
refuses('new transmission reuses stale handle',b1,lambda b:edit_event(b,14,lambda r:r[5]==0,6,lambda _:4))
refuses('received fixture presented as valid CRC',b1,lambda b:edit_event(b,7,lambda r:r[2]>=16,9,lambda n:n^1))
refuses('late safe endpoint claimed within limit',b1,lambda b:edit_event(b,2,lambda r:r[4]==1,3,lambda n:n+62500*31))
refuses('private recovery counter advanced by corrupt frame',b1,lambda b:flip_private(b,1,'admission_controller_rows',18*8*13+15*8))
refuses('nonzero byte in initialized live fixture tail','rr-guards',lambda b:flip_private(b,1,'fixture_pages',4095))
refuses('65th attempt at an empty ring claimed successful','rr-guards',lambda b:flip_private(b,2,'supervisor_control',68*8))
