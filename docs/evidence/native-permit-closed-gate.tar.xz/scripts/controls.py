"""Run validated and malformed package selectors and execute checked-in loan tests on the host."""
import contextlib, hashlib, json, os, re, subprocess, sys, tarfile, tempfile
from pathlib import Path
packet=Path(sys.argv[1]).resolve(); result=Path(sys.argv[2]).resolve(); result.mkdir(exist_ok=True,parents=True)
env={k:v for k,v in os.environ.items() if not k.startswith('JNOX_')}
env['PYTHONDONTWRITEBYTECODE']='1'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def encode(args):
    items=[s.encode() for s in args]
    return (bytes([len(items)])+b''.join(len(i).to_bytes(2,'little')+i for i in items)).hex()
def run(cmd,cwd,environ):
    return subprocess.run(cmd,cwd=cwd,env=environ,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
def recorded(label,cmd,cwd,environ,ok,pattern,selector=False):
    proc=run(cmd,cwd,environ)
    if (proc.returncode==0)!=ok or (pattern and pattern not in proc.stdout):
        print(label,proc.returncode,proc.stdout[-2100:],flush=True)
        raise RuntimeError(label)
    if selector and ok: assert ('cargo::rustc-cfg=jnox_native_safety_downstream\n' in proc.stdout)==(selector=='on')
    print(label,proc.returncode,pattern or 'PASS')
    evidence=[re.sub(r'; finished in [0-9.]+s$','',x.strip()) for x in proc.stdout.splitlines() if pattern and pattern in x or x.startswith('test result:')]
    return dict(label=label,status=proc.returncode,expected=pattern,diagnostic_lines=evidence)
with tempfile.TemporaryDirectory() as temp:
    work=Path(temp); src=work/'src'; src.mkdir()
    with tarfile.open(packet/'sources/build-source.tar.gz') as t: t.extractall(src)
    kernel=src/'kernel'
    package=packet/'pkg/fifo-gate-invalid'
    m=json.loads((package/'manifest.json').read_text())
    args=m['package_argv'][1:]; args[args.index('--out')+1]=str(work/'cli-package')
    i=args.index('--elf'); args[i+1]=str(package/m['slots'][0]['elf'])
    peers=[i for i,x in enumerate(args) if x=='--peer-elf']
    for i,s in zip(peers,m['slots'][1:]): args[i+1]=str(package/s['elf'])
    def cli(k,edit,pattern):
        v=args.copy(); edit(v)
        return recorded('cli-'+k,[sys.executable,'tools/build_native_el0.py']+v,src,env,False,pattern)
    def swap(v,k,x): v[v.index(k)+1]=x
    same='downstream qualification requires the same closed-gate case'
    scope='--safety-channel requires exactly three virt FIFO/RR processes'
    ns=[cli('no-qualification',lambda v:v.remove('--safety-qualification'),'requires --safety-qualification'),
        cli('duplicate-option',lambda v:v.append('--safety-downstream-injector'),'may appear once'),
        cli('missing-channel',lambda v:v.remove('--safety-channel'),'--safety-qualification requires --safety-channel'),
        cli('other-case',lambda v:swap(v,'--arg','healthy'),same),
        cli('unequal-supervisor',lambda v:swap(v,'--peer2-arg','gate-saturation'),same),
        cli('unequal-controller',lambda v:swap(v,'--peer-arg','gate-saturation'),same),
        cli('wrong-board',lambda v:swap(v,'--board','pi4'),scope),
        cli('wrong-route',lambda v:swap(v,'--loan-route','1:0'),scope),
        cli('wrong-priorities',lambda v:swap(v,'--priority','8'),'priorities must order controller > sender > supervisor')]
    build=work/'build-script'
    cc=run(['rustc','--edition=2024','build.rs','-o',str(build)],kernel,{**env,'CARGO_MANIFEST_DIR':str(kernel)})
    assert cc.returncode==0,cc.stdout
    out=work/'out';out.mkdir()
    base={'TARGET':'aarch64-unknown-none','OUT_DIR':str(out),'JNOX_ARCH':'aarch64','JNOX_PROFILE':'native','JNOX_APP':'process','JNOX_BOARD':'virt','JNOX_NATIVE_POLICY':'fifo','JNOX_NATIVE_LOAN_ROUTE':'0:1','JNOX_NATIVE_IPC_ROUTES':'2:0,2:1','JNOX_NATIVE_PRIORITIES':'6,7,4','JNOX_NATIVE_SAFETY_CHANNEL':'1','JNOX_NATIVE_SAFETY_QUALIFICATION':'1','JNOX_NATIVE_SAFETY_DOWNSTREAM':'1'}
    for i,slot in enumerate(m['slots']):
        var='JNOX_NATIVE_'+('','PEER_','PEER2_')[i]+'ELF'
        base[var]=str(package/slot['elf']);base[var+'_SHA256']=slot['elf_sha256']
        base[f'JNOX_NATIVE_ARGV{i}_HEX']=encode(['gate-invalid'])
    def direct(k,change,ok,pat,selector=False):
        cfg={**env,**base,**change}
        cfg={k:v for k,v in cfg.items() if v is not None}
        return recorded('direct-'+k,[str(build)],kernel,cfg,ok,pat,selector)
    named='downstream fixture requires matching gate-invalid or gate-saturation scenarios'
    gate='safety channel requires three ordinary virt FIFO/RR processes'
    ds='downstream injection requires the protected virtual qualification profile'
    dsrows=[direct('valid',{},True,None,'on'),direct('valid-controller-fused',{'JNOX_NATIVE_ARGV1_HEX':encode(['gate-invalid','fused-phase'])},True,None,'on'),direct('absent',{'JNOX_NATIVE_SAFETY_DOWNSTREAM':None},True,None,'off'),
        direct('no-qualification',{'JNOX_NATIVE_SAFETY_QUALIFICATION':None},False,ds),
        direct('invalid-value',{'JNOX_NATIVE_SAFETY_DOWNSTREAM':'2'},False,ds),
        direct('no-channel',{'JNOX_NATIVE_SAFETY_CHANNEL':None},False,'safety qualification requires the protected channel'),
        direct('missing-third-slot',{'JNOX_NATIVE_PEER2_ELF':None,'JNOX_NATIVE_PEER2_ELF_SHA256':None},False,gate),
        direct('extra-slot',{'JNOX_NATIVE_PEER3_ELF':base['JNOX_NATIVE_PEER2_ELF'],'JNOX_NATIVE_PEER3_ELF_SHA256':base['JNOX_NATIVE_PEER2_ELF_SHA256']},False,gate),
        direct('wrong-board',{'JNOX_BOARD':'pi4'},False,gate),direct('wrong-route',{'JNOX_NATIVE_LOAN_ROUTE':'1:0'},False,gate),
        direct('supervisor-mismatch',{'JNOX_NATIVE_ARGV2_HEX':encode(['gate-saturation'])},False,named),
        direct('wrong-controller-mode',{'JNOX_NATIVE_ARGV1_HEX':encode(['gate-invalid','phase'])},False,named),
        direct('extra-argv',{'JNOX_NATIVE_ARGV3_HEX':encode(['gate-invalid'])},False,named),
        direct('historical-case',{f'JNOX_NATIVE_ARGV{i}_HEX':encode(['invalid']) for i in range(3)},False,named)]
    c=(src/'sdk/native-aarch64/include/jnox/safety_channel.h').read_text()
    rust=(src/'sdk/native-aarch64/rust/src/safety_channel.rs').read_text()
    assert re.search(r'jnox_safety_inject_invalid\(uint64_t generation\)\s*\{\s*return jnox_safety_operation\(59, 5, generation, 0, 0, 0\);',c)
    assert re.search(r'pub fn inject_invalid\(generation: u64\).*?\{\s*operation\(59, 5, generation, 0, 0, 0\)',rust)
    test=work/'loan-tests'
    cc=run(['rustc','--edition=2024','--test','--cfg','jnox_native_safety_downstream','--cfg','jnox_native_safety_channel','src/loan_ipc.rs','-o',str(test)],kernel,env);assert cc.returncode==0,cc.stdout
    tests=recorded('host-loan-policy',[str(test),'--test-threads=1'],kernel,env,True,'test result: ok')
    (result/'package-controls.json').write_text(json.dumps(dict(cli=ns,direct=dsrows,host_tests=tests,wrapper=['SVC 59','command 5','generation x1']),indent=1)+'\n')
