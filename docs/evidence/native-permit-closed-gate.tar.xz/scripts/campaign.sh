#!/usr/bin/env bash
set -euo pipefail
base=/home/ywcho/permit11-closed-gate-first
shared=/mnt/d/codex/permit11-closed-gate-first
rev=b9c4d7aafed05aeecc695dc39f0c81f4e3a7367e
tree=b57eb56d86185b984b3117c7af121ba76b1d8ac5
src=$base/work/src
packet=$base/work/packet
export HOME=$base/home CARGO_HOME=$base/home/.cargo RUSTUP_HOME=/home/ywcho/.rustup
export PATH="/home/ywcho/.cargo/bin:$PATH" LC_ALL=C TZ=UTC CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1
unset RUSTFLAGS CARGO_TARGET_DIR PYTHONPATH
for n in $(env | sed -n 's/^\(JNOX_[^=]*\)=.*/\1/p'); do unset "$n"; done
mkdir -p "$CARGO_HOME" "$packet"/{apps,pkg,runs,logs,sources}
if [[ ! -d $CARGO_HOME/registry ]]; then cp -a /home/ywcho/.cargo/registry "$CARGO_HOME/"; fi
if [[ ! -d $src/.git ]]; then
  git init -q "$src"
  echo /mnt/d/codex/.jnox-work/policy-v1/.git/objects > "$src/.git/objects/info/alternates"
  git -C "$src" sparse-checkout init --cone
  git -C "$src" sparse-checkout set arch boards examples kernel sdk services tools trace verification
  git -C "$src" checkout --quiet --detach "$rev"
fi
cd "$src"
test "$(git rev-parse HEAD)" = "$rev"
test "$(git rev-parse HEAD^{tree})" = "$tree"
test -z "$(git status --short --untracked-files=no)"
{ git show -s --format=raw HEAD; uname -a; rustc -Vv; cargo -V; python3 -V; clang --version; qemu-system-aarch64 --version; sha256sum "$(command -v qemu-system-aarch64)"; git --version; } > "$packet/host.txt"
git cat-file commit HEAD > "$packet/sources/commit"
git cat-file tree HEAD > "$packet/sources/tree"
git ls-tree -r HEAD arch boards examples kernel sdk services tools trace verification > "$packet/sources/file-list"
git archive -o "$packet/sources/build-source.tar.gz" HEAD arch boards examples kernel sdk services tools trace verification
for role in sender controller supervisor; do
  sh sdk/native-aarch64/build-rust.sh "examples/native-safety-admission/$role/Cargo.toml" "$packet/apps/$role.elf" > "$packet/logs/app-$role" 2>&1 || { cat "$packet/logs/app-$role"; exit 1; }
done
for policy in fifo rr; do
 for name in silence gate-invalid gate-saturation healthy denial; do
  scenario=$name
  [[ $name != denial ]] || scenario=gate-invalid
  pkg="$packet/pkg/$policy-$name"
  dest="$packet/runs/$policy-$name"
  q=(); fixture=()
  [[ $policy != rr ]] || q=(--quantum-ticks 625000)
  case $name in gate-invalid|gate-saturation) fixture=(--safety-downstream-injector);; esac
  test ! -e "$dest"
  test ! -e "$pkg"
  (set -x; python3 tools/build_native_el0.py --out "$pkg" --board virt --policy "$policy" "${q[@]}" --elf "$packet/apps/sender.elf" --peer-elf "$packet/apps/controller.elf" --peer-elf "$packet/apps/supervisor.elf" --arg "$scenario" --peer-arg "$scenario" --peer2-arg "$scenario" --priority 6 --peer-priority 7 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel --safety-qualification "${fixture[@]}") > "$packet/logs/$policy-$name.build" 2>&1 || { cat "$packet/logs/$policy-$name.build"; exit 2; }
  mkdir "$dest"
  set +e
  date -u +%FT%T.%NZ > "$dest/start.utc"
  (set -x; python3 tools/native_el0_capture.py "$dest/cap" "$pkg/kernel.elf" "$packet/apps/sender.elf" examples/native-safety-admission/sender/src/main.rs "$rev" --manifest "$pkg/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608) > "$dest/capture.log" 2>&1
  echo "$?" > "$dest/status"
  date -u +%FT%T.%NZ > "$dest/end.utc"
  set -e
  echo "$policy $name $(cat "$dest/status") $(grep -a 'NATIVE EL0 EXIT PID' "$dest/cap/uart.bin" | tr '\n' ',') $(date -u +%FT%T)"
 done
done
