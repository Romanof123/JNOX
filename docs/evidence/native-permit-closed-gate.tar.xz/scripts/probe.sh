#!/usr/bin/env bash
set -euo pipefail
base=/home/ywcho/permit11-closed-gate-first
export HOME=$base/home CARGO_HOME=$base/home/.cargo RUSTUP_HOME=/home/ywcho/.rustup PATH="/home/ywcho/.cargo/bin:$PATH" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true LC_ALL=C
unset RUSTFLAGS CARGO_TARGET_DIR PYTHONPATH
cd "$base/work/src"
p=$base/work/packet
s=/mnt/d/codex/permit11-closed-gate-first
mkdir -p "$p/controls"
for role in sender controller supervisor; do
  cp "$s/probe-$role.c" "$p/controls/"
  sh sdk/native-aarch64/build.sh "$p/controls/probe-$role.c" "$p/controls/$role.elf"
done
for policy in fifo rr; do
  q=(); [[ $policy != rr ]] || q=(--quantum-ticks 625000)
  pkg=$p/pkg/$policy-guards; dest=$p/runs/$policy-guards
  test ! -e "$pkg"; test ! -e "$dest"
  (set -x; python3 tools/build_native_el0.py --out "$pkg" --board virt --policy "$policy" "${q[@]}" --elf "$p/controls/sender.elf" --peer-elf "$p/controls/controller.elf" --peer-elf "$p/controls/supervisor.elf" --arg gate-invalid --peer-arg gate-invalid --peer2-arg gate-invalid --priority 6 --peer-priority 7 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel --safety-qualification --safety-downstream-injector) > "$p/logs/$policy-guards.build" 2>&1
  mkdir "$dest"; date -u +%FT%T.%NZ > "$dest/start.utc"
  set +e
  (set -x; python3 tools/native_el0_capture.py "$dest/cap" "$pkg/kernel.elf" "$p/controls/sender.elf" "$p/controls/probe-sender.c" "$(git rev-parse HEAD)" --manifest "$pkg/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608) > "$dest/capture.log" 2>&1
  echo "$?" > "$dest/status"; date -u +%FT%T.%NZ > "$dest/end.utc"; set -e
  grep 'NATIVE EL0 EXIT PID' "$dest/cap/uart.bin"
done
