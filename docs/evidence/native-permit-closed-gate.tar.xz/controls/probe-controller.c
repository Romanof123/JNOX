#include <jnox/ipc.h>
#include <jnox/loan.h>
#include <jnox/safety_channel.h>
volatile long controller_control[12];
volatile uint64_t reader_handles[3];
volatile unsigned char fixture_pages[2][4096];
int main(void) {
    for (;;) {
        jnox_ipc_request q = jnox_ipc_receive();
        if (q.status) return 104;
        if (q.word == 1) {
            controller_control[0] = jnox_safety_inject_invalid(1);
            if (jnox_safety_check()) return 105;
            jnox_reader_loan g = jnox_loan_receive();
            if (g.status || g.length != 4096 || g.page[4095] != 0xA5) return 106;
            reader_handles[0] = g.handle;
            if (jnox_safety_complete()) return 107;
        } else if (q.word == 2) {
            if (jnox_safety_check()) return 108;
            controller_control[1] = jnox_loan_release(reader_handles[0]);
            for (int n=0; n<2; ++n) {
                jnox_reader_loan g = jnox_loan_receive();
                if (g.status || g.length != 44) return 109;
                reader_handles[n+1] = g.handle;
                for (unsigned i=0; i<4096; ++i) fixture_pages[n][i] = g.page[i];
                if (jnox_loan_release(g.handle)) return 110;
            }
            if (jnox_safety_complete()) return 111;
        }
        if (jnox_ipc_reply(q.token,q.word)) return 112;
        if (q.word == 9) return 72;
    }
}
