#include <jnox/ipc.h>
#include <jnox/safety_channel.h>
volatile long supervisor_control[80];
static int ask(unsigned pid, unsigned word) {
    jnox_ipc_response out = jnox_ipc_call(pid,word,UINT64_MAX);
    return out.status == 0 && out.word == word;
}
int main(void) {
    supervisor_control[0] = jnox_safety_inject_invalid(1);
    if (jnox_safety_supervise(JNOX_SAFETY_OPEN,1)) return 113;
    supervisor_control[1] = jnox_safety_inject_invalid(1);
    if (!ask(0,1) || !ask(1,1)) return 114;
    if (jnox_safety_supervise(JNOX_SAFETY_CLOSE,1)) return 115;
    supervisor_control[2] = jnox_safety_inject_invalid(0);
    supervisor_control[3] = jnox_safety_inject_invalid(2);
    if (!ask(0,2)) return 116;
    for (unsigned n=0; n<64; ++n)
        supervisor_control[4+n] = jnox_safety_inject_invalid(1);
    if (!ask(1,2)) return 117;
    supervisor_control[68] = jnox_safety_inject_invalid(1);
    if (jnox_safety_supervise(JNOX_SAFETY_OPEN,2)) return 118;
    if (!ask(0,3)) return 119;
    supervisor_control[69] = jnox_safety_inject_invalid(1);
    supervisor_control[70] = jnox_safety_inject_invalid(2);
    if (jnox_safety_supervise(JNOX_SAFETY_CLOSE,2)) return 120;
    supervisor_control[71] = jnox_safety_inject_invalid(2);
    if (!ask(1,9)) return 121;
    supervisor_control[72] = jnox_safety_inject_invalid(2);
    if (!ask(0,9)) return 122;
    return 73;
}
