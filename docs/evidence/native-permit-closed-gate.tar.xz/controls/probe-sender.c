#include <jnox/ipc.h>
#include <jnox/loan.h>
#include <jnox/safety_channel.h>
volatile long sender_control[12];
volatile uint64_t writer_handles[3];
int main(void) {
    for (;;) {
        jnox_ipc_request q = jnox_ipc_receive();
        if (q.status) return 100;
        if (q.word == 1) {
            sender_control[0] = jnox_safety_inject_invalid(1);
            for (unsigned k=0; k<3; ++k) {
                jnox_writer_loan g = jnox_loan_acquire();
                if (g.status) return 101;
                writer_handles[k] = g.handle;
                for (unsigned i=0; i<4096; ++i) g.page[i] = 0xA5;
                if (k < 2 && jnox_loan_publish(g.handle, 4096)) return 102;
            }
        } else if (q.word == 2) {
            sender_control[1] = jnox_loan_acquire().status;
            sender_control[2] = jnox_loan_publish(writer_handles[2],44);
            sender_control[3] = jnox_loan_release(writer_handles[2]);
        } else if (q.word == 3) {
            sender_control[4] = jnox_loan_publish(writer_handles[2],44);
            sender_control[5] = jnox_loan_release(writer_handles[2]);
        }
        if (jnox_ipc_reply(q.token,q.word)) return 103;
        if (q.word == 9) return 71;
    }
}
