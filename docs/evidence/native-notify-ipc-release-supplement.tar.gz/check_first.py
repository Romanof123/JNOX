"""Bind each original guest journal to its two packaged ELFs and launch configuration."""
import hashlib
import json
import re
import sys
from pathlib import Path

root = Path(sys.argv[1])
frozen = "10ccba0f3d4aaf9e259eb8713a844e9acc725cb4"
captures = sorted(root.glob("capture-*/uart.bin")) + list(root.glob("corrected-width/capture-width/uart.bin"))
assert len(captures) == 11
for path in captures:
    cap = path.parent
    package = cap.with_name(cap.name.replace("capture-", "package-", 1))
    manifest = json.loads((package / "manifest.json").read_text())
    launch = json.loads((cap / "launch.json").read_text())
    assert launch["revision"] == manifest["commit"] == frozen
    assert manifest == launch["argument_package"] and not manifest["tracked_changes"]
    argv = launch["argv"]
    assert all(argv[argv.index(k) + 1] == value for k, value in [
        ("-machine", "virt,gic-version=2"), ("-cpu", "cortex-a72"), ("-smp", "1"), ("-accel", "tcg")])
    assert hashlib.sha256((cap / "kernel.elf").read_bytes()).hexdigest() == launch["kernel_sha256"] == manifest["kernel_elf_sha256"]
    hashes = [hashlib.sha256((package / slot["elf"]).read_bytes()).hexdigest() for slot in manifest["slots"]]
    assert re.findall(r"NATIVE EL0 (?:PEER )?ELF (\w+)", path.read_text()) == hashes
    assert hashes == [slot["elf_sha256"] for slot in manifest["slots"]]
    print(path.relative_to(root), manifest["policy"], launch["kernel_sha256"], *hashes)
