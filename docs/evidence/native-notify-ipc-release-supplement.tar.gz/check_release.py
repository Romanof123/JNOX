"""Check the Release guest from raw UART, RAM, ELF, manifests and session hashes."""
import hashlib
import json
import re
import struct
import subprocess
import sys
from pathlib import Path

from first_decode import analyze, symbols


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def layout(path):
    data = path.read_bytes()
    header = struct.unpack_from("<16sHHIQQQIHHHHHH", data)
    assert data[:6] == b"\x7fELF\x02\x01"
    segments = []
    for i in range(header[10]):
        ph = struct.unpack_from("<II6Q", data, header[5] + i * header[9])
        if ph[0] == 1:
            segments.append({"flags": ph[1], "vaddr": ph[3], "file": ph[5], "memory": ph[6]})
    size_line = subprocess.check_output(["aarch64-linux-gnu-size", path], text=True).splitlines()[1]
    text, initialized, bss = map(int, size_line.split()[:3])
    return {"sections": [text, initialized, bss], "load": segments, "elf_file": len(data)}


out = Path(sys.argv[1])
package = out / "package-split"
cap = out / "capture-split"
disabled = out / "disabled-footprint"
row = analyze(out, "split", [75, 76])
assert row["issues"] == []
manifest = json.loads((package / "manifest.json").read_text())
launch = json.loads((cap / "launch.json").read_text())
assert launch["argument_package"] == manifest
assert manifest["policy"] == "rr" and manifest["quantum_ticks"] == 625000
assert manifest["ipc_routes"] == [{"caller": 1, "server": 0}]
assert manifest["mailbox_routes"] == [{"caller": 1, "owner": 0}]
assert manifest["notify_routes"] == [{"sender": 0, "owner": 1}]
uart = (cap / "uart.bin").read_text()
assert re.findall(r"NATIVE EL0 (?:PEER )?ELF (\w+)", uart) == [s["elf_sha256"] for s in row["slots"]]
assert row["notify_journal"] == ["NATIVE NOTIFY STATE 0 0 0 0 0", "NATIVE NOTIFY STATE 0 1 0 0 0",
                                 "NATIVE NOTIFY STATE 1 0 0 0 0", "NATIVE NOTIFY STATE 1 1 0 4 0"]
assert re.findall(r"NATIVE MAILBOX STATE (.+)", uart) == ["0 0 0", "1 0 0"]
idle = (1 << 64) - 1
sample = 0xdeadbeef12345678
all_bits = (1 << 32) - 1
expected = [
    [0, 0, 0, 0, -11, 0, 0, -11, -11, -13, -13, 0, 41, 0, 42, 0],
    [-13, -13, 0, 1, 101, 0, 2, 202, 0, all_bits, sample, 0, all_bits, sample, -11,
     0, 1 << 31, -11, 0, 0, 43],
]
for slot, values in zip(row["slots"], expected):
    actual = slot["private_data"]["probe_results"]
    assert actual == [v & idle for v in values] + [0] * (32 - len(values))
decisions = row["fixed_journal"]
assert decisions[-1][4] == idle and decisions[-1][12:15] == [idle] * 3
assert [(r[1], r[3], r[4]) for r in decisions if r[1] in (21, 22, 23, 24, 25)] == [
    (24, 0, 0), (21, 0, 0), (25, 0, 1), (24, 1, 0), (22, 0, 1), (21, 1, 0), (23, 0, 0)]
disabled_manifest = json.loads((disabled / "manifest.json").read_text())
for key in ["commit", "tracked_changes", "policy", "quantum_ticks", "ipc_routes", "mailbox_routes", "slots", "rust"]:
    assert manifest[key] == disabled_manifest[key]
assert "notify_routes" not in disabled_manifest
assert digest(disabled / "kernel.elf") == disabled_manifest["kernel_elf_sha256"]
state = [size for name, (_, size) in symbols(package / "kernel.elf").items() if "3ipc6NOTIFY" in name]
assert state == [296]
assert not any("3ipc6NOTIFY" in name for name in symbols(disabled / "kernel.elf"))
print(json.dumps({"exits": row["observed_exits"], "private_results": expected,
                  "notify_states": row["notify_journal"], "scheduler_decisions": len(decisions),
                  "enabled_kernel_sha256": row["kernel_sha256"], "disabled_kernel_sha256": disabled_manifest["kernel_elf_sha256"],
                  "notify_storage_bytes": state[0], "enabled": layout(package / "kernel.elf"),
                  "disabled": layout(disabled / "kernel.elf")}, indent=2))
