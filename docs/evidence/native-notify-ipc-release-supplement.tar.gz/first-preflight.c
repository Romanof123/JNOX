#include <jnox/ipc.h>
#include <jnox/mailbox.h>
#include <jnox/notify.h>

volatile uint64_t probe_results[32];
static unsigned index_next;
static const uint32_t signal_bit = UINT32_C(0x80000000);
static const uint64_t sample = UINT64_C(0xdeadbeef12345678);

static int check(uint64_t actual, uint64_t expected) {
    probe_results[index_next++] = actual;
    return actual == expected;
}

static int source(void) {
    /* Two occupied slots leave exactly two slots for identical records. */
    if (!check(jnox_pulse_send(1, 1, 101), 0)) return 101;
    if (!check(jnox_pulse_send(1, 2, 202), 0)) return 102;
    if (!check(jnox_pulse_send(1, UINT32_MAX, sample), 0)) return 103;
    if (!check(jnox_pulse_send(1, UINT32_MAX, sample), 0)) return 104;
    if (!check(jnox_pulse_send(1, 3, 303), -11)) return 105;
    if (!check(jnox_event_set(1, signal_bit), 0)) return 106;
    if (!check(jnox_event_set(1, signal_bit), 0)) return 107;
    if (!check(jnox_pulse_recv(0).status, -11)) return 108;
    if (!check(jnox_event_take(signal_bit, 0).status, -11)) return 109;
    if (!check(jnox_mailbox_send(1, 11, 0), -13)) return 110;
    if (!check(jnox_ipc_call(1, 12, UINT64_MAX).status, -13)) return 111;

    jnox_mailbox_result msg = jnox_mailbox_receive(UINT64_MAX);
    if (!check(msg.status, 0) || !check(msg.word, 41)) return 112;
    jnox_ipc_request request = jnox_ipc_receive();
    if (!check(request.status, 0) || !check(request.word, 42)) return 113;
    if (!check(jnox_ipc_reply(request.token, 43), 0)) return 114;
    return 75;
}

static int owner(void) {
    if (!check(jnox_pulse_send(0, 3, 303), -13)) return 121;
    if (!check(jnox_event_set(0, signal_bit), -13)) return 122;
    const uint32_t codes[] = {1, 2, UINT32_MAX, UINT32_MAX};
    const uint64_t words[] = {101, 202, sample, sample};
    for (unsigned i = 0; i < 4; ++i) {
        jnox_pulse_result p = jnox_pulse_recv(0);
        if (!check(p.status, 0) || !check(p.code, codes[i]) || !check(p.word, words[i])) return 123;
    }
    if (!check(jnox_pulse_recv(0).status, -11)) return 124;
    jnox_event_result e = jnox_event_take(UINT32_MAX, 0);
    if (!check(e.status, 0) || !check(e.bits, signal_bit)) return 125;
    if (!check(jnox_event_take(UINT32_MAX, 0).status, -11)) return 126;
    if (!check(jnox_mailbox_send(0, 41, 0), 0)) return 127;
    jnox_ipc_response response = jnox_ipc_call(0, 42, UINT64_MAX);
    if (!check(response.status, 0) || !check(response.word, 43)) return 128;
    return 76;
}

int main(int argc, char **argv) {
    if (argc != 2) return 199;
    if (argv[1][0] == 's') return source();
    if (argv[1][0] == 'o') return owner();
    return 198;
}
