#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
out=${1:?new output directory}
src=${2:?clean candidate checkout}
cd "$src"
test "$(git rev-parse HEAD)" = 10ccba0f3d4aaf9e259eb8713a844e9acc725cb4
test "$(git rev-parse HEAD^{tree})" = c78ca5be264a3a93c4714830e5787d797ff97e04
test -z "$(git status --porcelain -uno)"
export PATH="$HOME/.cargo/bin:$PATH" CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=1
mkdir "$out"
sh sdk/native-aarch64/build.sh "$root/split.c" "$out/split.elf"
args=(--elf "$out/split.elf" --peer-elf "$out/split.elf" --policy rr --quantum-ticks 625000 --priority 7 --peer-priority 1 --arg source --peer-arg owner --ipc-route 1:0 --mailbox-route 1:0)
python3 tools/build_native_el0.py "${args[@]}" --notify-route 0:1 --out "$out/package-split"
python3 tools/native_el0_capture.py "$out/capture-split" "$out/package-split/kernel.elf" "$out/split.elf" "$root/split.c" "$(git rev-parse HEAD)" --plain --manifest "$out/package-split/manifest.json" --expect-exit 75 --timeout 12
# Same input and all other grants retained for the linked footprint comparison.
python3 tools/build_native_el0.py "${args[@]}" --out "$out/disabled-footprint"
