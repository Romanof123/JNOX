import json,pathlib
p=pathlib.Path(__file__).parent
u="https://github.com/Romanof123/JNOX/issues/6"
f="https://[2001:db8::42]:8443/a(b)?n=1#6"
cases={0:["Tracks #6.","(#6)","Romanof123/JNOX#6",u,"<"+u+">","[primary]("+u+")",f+" #6", "#6 "+f,"https://foreign.example/guide(#6) #6","See #6,#77","No relationship to #6"],1:["#60","Other/JNOX#6","X#6",f,"https://foreign.example/guide(#6)","https://github.com/Other/JNOX/issues/6","https://github.com/Romanof123/JNOX/pull/6","`#6`","> #6","~~~\n#6\n~~~","    #6","<!-- #6 -->","<pre>#6</pre>"]}
roles={k:0 for k in "pm systems functional-safety development integration verification release".split()}
roles.update({"owner":1,"verification,pm":1,"":1})
(p/"oracle.json").write_text(json.dumps({"body":[[x,k] for k,ls in cases.items() for x in ls],"roles":list(roles.items())},indent=2))
