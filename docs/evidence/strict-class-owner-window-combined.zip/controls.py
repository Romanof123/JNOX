import json,hashlib,struct,zipfile,pathlib as P,subprocess as s,shutil
r=P.Path.home()/'jnox262-combined';z=zipfile.ZipFile('/mnt/d/codex/jnox259260-baseline.zip');out=r/'control-reruns';out.mkdir(exist_ok=True);a=json.loads(z.read('matrix.json'));result={}
def elfstats(f):
 d=f.read_bytes();ph,sh=struct.unpack_from('<QQ',d,32);pe,pn,se,sn,si=struct.unpack_from('<5H',d,54);rows=[struct.unpack_from('<IIQQQQIIQQ',d,sh+i*se) for i in range(sn)];nm=rows[si];names=d[nm[4]:nm[4]+nm[5]];h=lambda b:hashlib.sha256(b).hexdigest();sects={}
 for name,t,_,addr,offset,size,*_ in rows:
  name=names[name:names.index(0,name)].decode()
  if name in ['.text','.rodata','.data','.bss','.stack']:sects[name]=[addr,size,h(d[offset:offset+size]) if t!=8 else None]
 loads=[]
 for i in range(pn):
  t,fl,off,va,pa,sz,ms,al=struct.unpack_from('<II6Q',d,ph+i*pe)
  if t==1:loads.append([va,pa,sz,ms,fl,h(d[off:off+sz])])
 return dict(file=[len(d),h(d)],sections=sects,loads=loads)
def term(g):
 uart=(g/'uart.bin').read_text();return dict(terminal=uart.splitlines()[-1],results=[l for l in uart.splitlines() if l.startswith(('RESULT','MISS','EXHAUST','SUPPLY','MLQ','MLFQ','MULTILEVEL','ORDINARY'))],pc=(g/'registers.txt').read_text().split('X00')[0].strip(),exceptions=(g/'int.trace').read_text().count('Taking exception'))
for row in a:
 key=row['app']+'-'+row['mode'];d=out/key;d.mkdir(exist_ok=True);elf=d/'kernel.elf';elf.write_bytes(z.read(key+'/kernel.elf'));g=d/'guest';new=r/'originals'/key
 if not g.exists():s.run(['python3',str(r/'raw.py'),str(elf),str(g)],check=True)
 a1=elfstats(elf);a2=elfstats(new/'kernel.elf');baseline=term(g);current=term(new/'guest')
 result[key]=dict(baseline=a1,current=a2,baseline_runtime=baseline,current_runtime=current,terminal_equal=baseline['terminal']==current['terminal'],identical=a1['file']==a2['file'],load_equal=a1['loads']==a2['loads'],text_equal=a1['sections']['.text']==a2['sections']['.text'],rodata_equal=a1['sections']['.rodata']==a2['sections']['.rodata'],registered_guest_files=[p for p in z.namelist() if p.startswith(key+'/') and ('guest.' in p or '/uart.' in p)])
 (r/'comparison.json').write_text(json.dumps(result,indent=2))
