import os,sys,subprocess as s,pathlib as p,shutil,json,time,signal,hashlib
r=p.Path.home()/'jnox262-combined'; src=r/'src'; out=r/'originals'; out.mkdir(exist_ok=True); mirror=p.Path('/mnt/d/codex/jnox262-combined')
tool=p.Path.home()/'jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin'
env=dict(os.environ, PATH=str(tool)+':'+os.environ['PATH'],CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR=str(r/'build'))
apps=[('multilevel',a,'') for a in ['mlq-admit','mlq-refuse']]+[('deadline','ordinary-'+alg+'-supply',str(c)) for alg in ['edf','llf'] for c in [3,4]]+[('multilevel',a,'') for a in ['mlq','mlfq','mlq-blocked','mlq-exited','mlq-saturated','mlfq-delayed']]+[('deadline','ordinary-'+a,'') for a in ['edf','llf','edf-overrun','llf-overload','edf-supply','llf-supply','edf-supply-refuse','llf-supply-refuse']]
def run(args,env,path): 
 with path.open('wb') as log:return s.run(args,cwd=src,env=env,stdout=log,stderr=s.STDOUT).returncode
for prof,app,cap in apps:
 for tr in [0,1]:
  key=app+('-cap'+cap if cap else '')+('-trace' if tr else '-plain'); d=out/key
  if d.exists(): continue
  d.mkdir(); print(key,flush=True); e=dict(env,JNOX_PROFILE=prof,JNOX_APP=app,JNOX_CAPTURE_PROFILE=app)
  if tr:e['JNOX_'+prof.upper()+'_TRACE']='1'
  if cap:e['JNOX_DEADLINE_OWNER_CAP']=cap
  build=['python3','tools/build_kernel.py']; rep=dict(env={k:v for k,v in e.items() if k.startswith(('JNOX','CARGO'))},build=build)
  try:
   assert run(build,e,d/'build.log')==0
   elf=d/'kernel.elf'; shutil.copyfile(r/'build/aarch64-unknown-none/release/jnox-kernel',elf)
   if app in ('mlq-admit','mlq-refuse') or (app=='mlq-blocked' and tr):
    strict=app in ('mlq-admit','mlq-refuse');helper='mlq_admission_capture' if strict else 'ordinary_multilevel_capture'
    e['MLQ_ADMISSION_CAPTURE_DIR' if strict else 'ORDINARY_MULTILEVEL_CAPTURE_DIR']=str(d/'guest')
    args=['python3','tools/qemu_boot.py','--qemu','tools/'+helper+'.py','--kernel',str(elf),'--profile',app,'--runs','1','--timeout','10'];rep['guest']=args;rep['rc']=run(args,e,d/'observation.log')
   else:
    args=['python3',str(r/'raw.py'),str(elf),str(d/'guest')];rep['guest']=args;rep['rc']=run(args,e,d/'observation.log')
  except Exception as ex:rep['error']=repr(ex)
  (d/'record.json').write_text(json.dumps(rep));shutil.copytree(d,mirror/'originals'/key)
