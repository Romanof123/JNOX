import pathlib as P,struct,re,json,subprocess as s,hashlib,zipfile
r=P.Path.home()/'jnox262-combined';out=r/'post';rows={};a=json.loads((r/'comparison.json').read_text())
def sec(elf,name):
 b=elf.read_bytes();sh=struct.unpack_from('<Q',b,40)[0];sz,n,si=struct.unpack_from('<3H',b,58);all=[struct.unpack_from('<IIQQQQIIQQ',b,sh+sz*i) for i in range(n)];names=b[all[si][4]:][:all[si][5]]
 x=next(x for x in all if names[x[0]:].split(b'\0',1)[0].decode()==name);return x[3],b[x[4]:][:x[5]]
def lines(g):return (g/'uart.bin').read_text().splitlines()
def numeric(g,tag):return [list(map(int,l.split()[1:])) for l in lines(g) if l.startswith(tag+' ')]
def product(seed,n):
 # Modular geometric series evaluated by geometric doubling; one block has 64 steps.
 mod=2**64;v=pow(33,64*n,32*mod);return (seed*pow(33,64*n,mod)+(v-1)//32)%mod
for k,v in a.items():
 new=r/'originals'/k;old=r/'control-reruns'/k;anchor,baseline=sec(old/'kernel.elf','.rodata');_,fresh=sec(new/'kernel.elf','.rodata');assert len(baseline)==len(fresh)
 diff=[i for i,(x,y) in enumerate(zip(baseline,fresh)) if x!=y];deltas=[];other=[]
 for i in diff:
  record=None
  for off in range(max(0,i-23),min(len(fresh)-23,i+1)):
   ptr,n,l,c=struct.unpack_from('<QQII',fresh,off)
   if anchor<=ptr<anchor+len(fresh) and 0<n<256 and off+16<=i<off+24:
    path=fresh[ptr-anchor:ptr-anchor+n].decode('ascii','replace')
    if '.rs' in path: record=[i,path,*struct.unpack_from('<II',baseline,off+16),l,c];break
  (deltas if record else other).append(record if record else i)
 g1=new/'guest';g0=old/'guest';get=lambda g:[[x[i] for i in (0,1,2,9,10,15,16,17,18)] for x in numeric(g,'D')]
 common=dict(size_equal=v['baseline']['file'][0]==v['current']['file'][0],all_section_sizes=all(v['baseline']['sections'][n][:2]==v['current']['sections'][n][:2] for n in v['baseline']['sections']),last_load_equal=v['baseline']['loads'][-1]==v['current']['loads'][-1],rodata_changed_line_bytes=deltas,unattributed_rodata=other,irq_svc_counts=[v[x+'_runtime']['exceptions'] for x in ('baseline','current')],phase_equal=get(g1)==get(g0))
 assert v['terminal_equal'] and v['current_runtime']['pc']==v['baseline_runtime']['pc']
 rows[k]=common
(out/'differences.json').write_text(json.dumps(rows,indent=2))
details={}
for d in sorted((r/'originals').glob('*-cap4-*')):
 g=d/'guest';ds=numeric(g,'D');js=numeric(g,'J');T=[x[7] for x in ds];epoch,end,q,*_=numeric(g,'OWNER_CAP')[0];assert [x[0] for x in ds]==[1,1,1,2,2];assert all((x[7]-epoch)//q==x[1]==x[2] and x[4]==epoch+x[1]*q and x[5]&1023==30 for x in ds[:3]);assert all(T[i]<epoch+3*q for i in (3,4))
 result=numeric(g,'RESULT')[0];assert result[0]==sum(i*i for i in range(1,65));assert [product(i+1,js[-3+i][5]) for i in (0,1)]==result[2:]
 pc=int(re.search(r'PC=([0-9a-f]+)',(g/'registers.txt').read_text())[1],16);asm=s.check_output(['aarch64-linux-gnu-objdump','-d',str(d/'kernel.elf'),'--start-address='+str(pc-4),'--stop-address='+str(pc+8)],text=True);assert 'wfe' in asm
 details[d.name]=dict(park=asm,service_sum=result[0],worker_products=result[2:],worker_blocks=[j[5] for j in js[-3:-1]],timer_cells=[(t-epoch)//q for t in T[:3]])
for d in sorted((r/'originals').glob('mlq-admit-*')):
 g=d/'guest';w=struct.unpack('<30Q',(g/'audit.bin').read_bytes());asm=s.check_output(['aarch64-linux-gnu-objdump','-d',str(d/'kernel.elf')],text=True);addr=int(re.search(r'\[IRQ\].*?ELR (0x\w+)',(g/'int.trace').read_text(),re.S)[1],16);area=next(x for x in asm.split('\n\n') if re.search(r'^\s*%x:'%addr,x,re.M));(out/(d.name+'-interrupted-worker.asm')).write_text(area);assert 'ldar' in area and '#0x1, lsl #12' in area and 'stlr' in area
 ro,bs=sec(d/'kernel.elf','.rodata');assert bytes(range(1,17))*256 in bs; sample=list(bytes(range(1,17))*256);assert w[18:22]==(sum(sample),sum(i*i for i in sample),sum(i&1 for i in sample)*w[24],max(sample))
 if (g/'trace.bin').exists():
  b=(g/'trace.bin').read_bytes();count,hz=struct.unpack_from('<QQ',b);rr=[struct.unpack_from('<131Q',b,16+1048*i) for i in range(count)];assert [x[10] for x in rr]==[0,1,2,3,2,4];assert rr[3][8]==rr[4][13] and rr[3][58]==rr[4][14]==addr
  assert [x[6]-x[4] for x in rr[1:4]]==list(w[9:12]);assert rr[4][4]==w[7];assert rr[3][40]+1==rr[5][40]==w[29];assert rr[3][42]==0 and rr[5][42]==16
  details[d.name]=dict(owners=[x[10] for x in rr],charged=[x[6]-x[4] for x in rr[1:4]],irq_frame=rr[3][8],resumed_frame=rr[4][13],irq_pc=addr,restored_pc=rr[4][14],irq_block=rr[3][40],irq_inner_offset=rr[3][43],receipt_at_irq=rr[3][42],receipt_final=rr[5][42],postreceipt_block=rr[5][40])
(out/'additional.json').write_text(json.dumps(details,indent=2))
print('unattributed',[(k,v['unattributed_rodata']) for k,v in rows.items() if v['unattributed_rodata']]);print('phase',[(k,v['irq_svc_counts']) for k,v in rows.items() if not v['phase_equal']]);print('layouts',[(k,v) for k,v in rows.items() if not v['all_section_sizes'] or not v['last_load_equal']])
