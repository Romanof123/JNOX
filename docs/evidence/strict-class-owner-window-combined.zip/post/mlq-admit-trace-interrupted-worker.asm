0000000040201dc8 <_ZN11jnox_kernel13mlq_admission6worker17h43e89e4b46ae2595E.llvm.14636270032416860276>:
    40201dc8:	f81f0ffe 	str	x30, [sp, #-16]!
    40201dcc:	900002e8 	adrp	x8, 4025d000 <ordinary_multilevel_witness+0x46e60>
    40201dd0:	91098108 	add	x8, x8, #0x260
    40201dd4:	c85ffd09 	ldaxr	x9, [x8]
    40201dd8:	b27e0129 	orr	x9, x9, #0x4
    40201ddc:	c80afd09 	stlxr	w10, x9, [x8]
    40201de0:	35ffffaa 	cbnz	w10, 40201dd4 <_ZN11jnox_kernel13mlq_admission6worker17h43e89e4b46ae2595E.llvm.14636270032416860276+0xc>
    40201de4:	2a1f03ee 	mov	w14, wzr
    40201de8:	aa1f03e8 	mov	x8, xzr
    40201dec:	52800030 	mov	w16, #0x1                   	// #1
    40201df0:	52909009 	mov	w9, #0x8480                	// #33920
    40201df4:	72a003c9 	movk	w9, #0x1e, lsl #16
    40201df8:	900002ea 	adrp	x10, 4025d000 <ordinary_multilevel_witness+0x46e60>
    40201dfc:	910a414a 	add	x10, x10, #0x290
    40201e00:	910023eb 	add	x11, sp, #0x8
    40201e04:	d503201f 	nop
    40201e08:	300107cc 	adr	x12, 40203f01 <_ZN11jnox_kernel13mlq_admission7SAMPLES17hc6dbbabbecf21d08E>
    40201e0c:	3700038e 	tbnz	w14, #0, 40201e7c <_ZN11jnox_kernel13mlq_admission6worker17h43e89e4b46ae2595E.llvm.14636270032416860276+0xb4>
    40201e10:	aa1003ed 	mov	x13, x16
    40201e14:	eb09021f 	cmp	x16, x9
    40201e18:	54000328 	b.hi	40201e7c <_ZN11jnox_kernel13mlq_admission6worker17h43e89e4b46ae2595E.llvm.14636270032416860276+0xb4>  // b.pmore
    40201e1c:	aa1f03f0 	mov	x16, xzr
    40201e20:	c8dffd4f 	ldar	x15, [x10]
    40201e24:	f90007ec 	str	x12, [sp, #8]
    40201e28:	f94007ee 	ldr	x14, [sp, #8]
    40201e2c:	387069d1 	ldrb	w17, [x14, x16]
    40201e30:	91000610 	add	x16, x16, #0x1
    40201e34:	92400231 	and	x17, x17, #0x1
    40201e38:	8b110108 	add	x8, x8, x17
    40201e3c:	f140061f 	cmp	x16, #0x1, lsl #12
    40201e40:	54ffff61 	b.ne	40201e2c <_ZN11jnox_kernel13mlq_admission6worker17h43e89e4b46ae2595E.llvm.14636270032416860276+0x64>  // b.any
    40201e44:	eb0901bf 	cmp	x13, x9
    40201e48:	1a9f17ee 	cset	w14, eq  // eq = none
    40201e4c:	9a8d0530 	csinc	x16, x9, x13, eq  // eq = none
    40201e50:	f10041ff 	cmp	x15, #0x10
    40201e54:	54fffdc1 	b.ne	40201e0c <_ZN11jnox_kernel13mlq_admission6worker17h43e89e4b46ae2595E.llvm.14636270032416860276+0x44>  // b.any
    40201e58:	900002e9 	adrp	x9, 4025d000 <ordinary_multilevel_witness+0x46e60>
    40201e5c:	91094129 	add	x9, x9, #0x250
    40201e60:	9101212a 	add	x10, x9, #0x48
    40201e64:	c89ffd4d 	stlr	x13, [x10]
    40201e68:	9100812a 	add	x10, x9, #0x20
    40201e6c:	c89ffd4d 	stlr	x13, [x10]
    40201e70:	c89ffd28 	stlr	x8, [x9]
    40201e74:	f84107fe 	ldr	x30, [sp], #16
    40201e78:	d65f03c0 	ret
    40201e7c:	528000e0 	mov	w0, #0x7                   	// #7
    40201e80:	94000165 	bl	40202414 <_ZN11jnox_kernel13mlq_admission9violation17h7b5f515cafa1da7bE.llvm.14636270032416860276>