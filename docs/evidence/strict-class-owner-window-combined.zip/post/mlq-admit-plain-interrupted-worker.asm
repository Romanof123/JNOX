00000000402004a4 <_ZN11jnox_kernel13mlq_admission6worker17h43e89e4b46ae2595E>:
    402004a4:	f81f0ffe 	str	x30, [sp, #-16]!
    402004a8:	d0000028 	adrp	x8, 40206000 <_ZN11jnox_kernel18multilevel_service5STATE17h737d29a3f1f40929E>
    402004ac:	9108e108 	add	x8, x8, #0x238
    402004b0:	c85ffd09 	ldaxr	x9, [x8]
    402004b4:	b27e0129 	orr	x9, x9, #0x4
    402004b8:	c80afd09 	stlxr	w10, x9, [x8]
    402004bc:	35ffffaa 	cbnz	w10, 402004b0 <_ZN11jnox_kernel13mlq_admission6worker17h43e89e4b46ae2595E+0xc>
    402004c0:	2a1f03ee 	mov	w14, wzr
    402004c4:	aa1f03e8 	mov	x8, xzr
    402004c8:	52800030 	mov	w16, #0x1                   	// #1
    402004cc:	52909009 	mov	w9, #0x8480                	// #33920
    402004d0:	72a003c9 	movk	w9, #0x1e, lsl #16
    402004d4:	d000002a 	adrp	x10, 40206000 <_ZN11jnox_kernel18multilevel_service5STATE17h737d29a3f1f40929E>
    402004d8:	9109a14a 	add	x10, x10, #0x268
    402004dc:	910023eb 	add	x11, sp, #0x8
    402004e0:	d503201f 	nop
    402004e4:	1001b02c 	adr	x12, 40203ae8 <_ZN11jnox_kernel13mlq_admission7SAMPLES17hc6dbbabbecf21d08E>
    402004e8:	3700038e 	tbnz	w14, #0, 40200558 <_ZN11jnox_kernel13mlq_admission6worker17h43e89e4b46ae2595E+0xb4>
    402004ec:	aa1003ed 	mov	x13, x16
    402004f0:	eb09021f 	cmp	x16, x9
    402004f4:	54000328 	b.hi	40200558 <_ZN11jnox_kernel13mlq_admission6worker17h43e89e4b46ae2595E+0xb4>  // b.pmore
    402004f8:	aa1f03f0 	mov	x16, xzr
    402004fc:	c8dffd4f 	ldar	x15, [x10]
    40200500:	f90007ec 	str	x12, [sp, #8]
    40200504:	f94007ee 	ldr	x14, [sp, #8]
    40200508:	387069d1 	ldrb	w17, [x14, x16]
    4020050c:	91000610 	add	x16, x16, #0x1
    40200510:	92400231 	and	x17, x17, #0x1
    40200514:	8b110108 	add	x8, x8, x17
    40200518:	f140061f 	cmp	x16, #0x1, lsl #12
    4020051c:	54ffff61 	b.ne	40200508 <_ZN11jnox_kernel13mlq_admission6worker17h43e89e4b46ae2595E+0x64>  // b.any
    40200520:	eb0901bf 	cmp	x13, x9
    40200524:	1a9f17ee 	cset	w14, eq  // eq = none
    40200528:	9a8d0530 	csinc	x16, x9, x13, eq  // eq = none
    4020052c:	f10041ff 	cmp	x15, #0x10
    40200530:	54fffdc1 	b.ne	402004e8 <_ZN11jnox_kernel13mlq_admission6worker17h43e89e4b46ae2595E+0x44>  // b.any
    40200534:	d0000029 	adrp	x9, 40206000 <_ZN11jnox_kernel18multilevel_service5STATE17h737d29a3f1f40929E>
    40200538:	9108a129 	add	x9, x9, #0x228
    4020053c:	9101212a 	add	x10, x9, #0x48
    40200540:	c89ffd4d 	stlr	x13, [x10]
    40200544:	9100812a 	add	x10, x9, #0x20
    40200548:	c89ffd4d 	stlr	x13, [x10]
    4020054c:	c89ffd28 	stlr	x8, [x9]
    40200550:	f84107fe 	ldr	x30, [sp], #16
    40200554:	d65f03c0 	ret
    40200558:	528000e0 	mov	w0, #0x7                   	// #7
    4020055c:	94000165 	bl	40200af0 <_ZN11jnox_kernel13mlq_admission9violation17h7b5f515cafa1da7bE.llvm.4541369779561240874>