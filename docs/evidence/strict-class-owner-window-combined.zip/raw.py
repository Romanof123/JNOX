import sys,pathlib as p,subprocess as s,signal,time,socket,json,tempfile
elf=p.Path(sys.argv[1]);out=p.Path(sys.argv[2]);out.mkdir();sys.path.insert(0,str(p.Path.home()/'jnox262-combined/src/tools'));from qemu_capture import request
args=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','stdio','-kernel',str(elf),'-d','int','-D',str(out/'int.trace')]
with tempfile.TemporaryDirectory() as td, (out/'uart.bin').open('wb') as u,(out/'stderr').open('wb') as err:
 sockpath=td+'/sock';args+=['-qmp','unix:'+sockpath+',server=on,wait=off'];(out/'launch.json').write_text(json.dumps(args))
 proc=s.Popen(args,stdout=u,stderr=err)
 try:
  time.sleep(2)
  with socket.socket(socket.AF_UNIX) as so:
   so.connect(sockpath); st=so.makefile('rwb',buffering=0);st.readline();request(st,'qmp_capabilities');(out/'status.json').write_text(json.dumps(request(st,'query-status')));request(st,'stop');(out/'registers.txt').write_text(request(st,'human-monitor-command',**{'command-line':'info registers'}));nm=s.check_output(['aarch64-linux-gnu-nm','-S','-n',str(elf)],text=True);(out/'symbols').write_text(nm)
   for line in nm.splitlines():
    f=line.split()
    if len(f)==4 and f[2] in 'bBdD' and int(f[1],16) and int(f[1],16)<=131072:
     request(st,'pmemsave',val=int(f[0],16),size=int(f[1],16),filename=str(out/(f[3]+'.bin')))
 finally:proc.terminate();proc.wait(3)
