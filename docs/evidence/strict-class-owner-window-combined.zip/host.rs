#[path="src/kernel/src/mlq_bound.rs"] mod mlq_bound;
#[path="src/kernel/src/deadline_jobs.rs"] mod deadline_jobs;
#[path="src/kernel/src/deadline_policy.rs"] mod deadline_policy;
#[path="src/kernel/src/ready_queue.rs"] mod ready_queue;
mod ordinary_deadline {pub fn counter()->u64{unreachable!()}}
fn main(){
 let mut ml=0u64; let mut dl=0u64;
 for n in 1..=4usize {for mask in 0..3usize.pow(n as u32){for demand in 0..2usize.pow(n as u32){for t in 0..n {for q in 1..=3u64 {
 let v:Vec<_>=(0..n).map(|i|(((mask/3usize.pow(i as u32))%3) as u8,Some(if demand>>i&1==1{4u64}else{1u64}))).collect();
 let mut fifo:Vec<usize>=(0..n).collect(); let mut left:Vec<_>=v.iter().map(|x|x.1.unwrap()).collect();let mut tick=2;
 loop { let rank=fifo.iter().map(|&i|v[i].0).max().unwrap();let pos=fifo.iter().position(|&i|v[i].0==rank).unwrap();let i=fifo.remove(pos);if i==t{break}let service=q.min(left[i]);tick+=service;left[i]-=service;if left[i]>0 {fifo.push(i)} }
 assert_eq!(mlq_bound::bound(&v,t,q,Some(2)),Some(tick));assert!(mlq_bound::admits(Some(tick),tick));assert!(!mlq_bound::admits(Some(tick),tick-1));ml+=1;
 }}}}}
 assert_eq!(mlq_bound::bound(&[(1,Some(u64::MAX)),(0,None)],1,1,Some(1)),None);
 assert_eq!(mlq_bound::bound(&[(2,None),(1,None)],1,1,Some(0)),None);
 for q in 1..=4u64{for cells in 1..=3u64 {let dom=q*cells;for w in 1..=dom{for jobs in 0..=2u64{
 let mut peak=0;for layout in 0..q.pow(cells as u32){let irqs:Vec<_>=(0..cells).map(|c|c*q+layout/q.pow(c as u32)%q).collect();
 for a in 0..dom{for b in 0..dom{for start in 0..=dom-w{let inside=|v:u64|start<=v&&v<start+w;
 let total=irqs.iter().filter(|&&v|inside(v)).count() as u64 + (jobs>=1&&inside(a)) as u64+(jobs>=2&&inside(b)) as u64;peak=peak.max(total);dl+=1;}}}}
 assert_eq!(deadline_jobs::owner_window_bound(q,cells,w,jobs).unwrap(),peak);
 }}}}
 for (q,c,w,j) in [(0,1,1,0),(1,1,0,0),(1,1,2,0),(u64::MAX,2,1,0),(1,1,1,u64::MAX)]{assert!(deadline_jobs::owner_window_bound(q,c,w,j).is_err())}
 println!("PASS independent queue simulations {ml} exhaustive event-window observations {dl}");
}
