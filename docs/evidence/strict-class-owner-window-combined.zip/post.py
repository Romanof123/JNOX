import pathlib as P,subprocess as s,sys,json,os,hashlib,struct,re
r=P.Path.home()/'jnox262-combined';src=r/'src';out=r/'post';out.mkdir(exist_ok=True);rust=str(P.Path.home()/'jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc');rows=[]
def run(name,args,cwd=src):
 with (out/(name+'.log')).open('wb') as f:rc=s.run(args,cwd=cwd,stdout=f,stderr=s.STDOUT).returncode
 rows.append(dict(name=name,argv=args,rc=rc));(out/'commands.json').write_text(json.dumps(rows,indent=2));return rc
run('environment',['bash','-c',f'git rev-parse HEAD; git status --short; df -T .; {rust} -Vv; {P.Path(rust).parent}/cargo -V; qemu-system-aarch64 --version; uname -a; date -u'])
for name,srcfile,opts in [('independent',str(r/'host.rs'),['--cfg','jnox_ordinary_deadline','-O']),('mlq','tools/mlq_admission_tests.rs',['--test']),('deadline','tools/deadline_supply_tests.rs',['--cfg','jnox_ordinary_deadline','--test']),('deadline-policy','tools/deadline_tests.rs',['--test']),('mlq-policy','tools/multilevel_oracle.rs',['--test'])]:
 exe=str(out/name);rc=run(name+'-build',[rust,'--edition=2024',*opts,srcfile,'-o',exe]); 
 if rc==0:run(name,[exe])
run('matrix',['python3','tools/scheduling_evidence.py']);run('graph',['python3','tools/requirement_graph.py']);run('focused-python',['python3','-m','unittest','discover','-s','tools','-p','test_*evidence.py']);run('graph-python',['python3','-m','unittest','discover','-s','tools','-p','test_requirement_graph.py'])
for d in sorted((r/'originals').glob('ordinary-*-supply-*')):
 if '-cap3' in d.name:continue
 app=re.sub(r'(-cap4)?-(plain|trace)$','',d.name);opts=['--plain'] if d.name.endswith('-plain') and 'cap' not in d.name else []
 run('supply-'+d.name,['python3','tools/deadline_supply_replay.py',app,str(d/'guest/uart.bin'),*opts])
print([(x['name'],x['rc']) for x in rows])
