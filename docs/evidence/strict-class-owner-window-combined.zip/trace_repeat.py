import json,os,subprocess as s,pathlib as P
r=P.Path.home()/'jnox262-combined';src=r/'src';out=r/'post'/'trace-repeats';out.mkdir();all=[]
for family in ['originals','control-reruns']:
 for app in ['mlq','mlfq','mlq-blocked','mlq-exited','mlq-saturated','mlfq-delayed']:
  d=out/(family+'-'+app);d.mkdir();old=r/family/(app+'-trace'); env=dict(os.environ,JNOX_CAPTURE_PROFILE=app,ORDINARY_MULTILEVEL_CAPTURE_DIR=str(d/'guest'))
  args=['python3','tools/qemu_boot.py','--kernel',str(old/'kernel.elf'),'--profile',app,'--qemu','tools/ordinary_multilevel_capture.py','--runs','1','--timeout','10']
  with (d/'capture.log').open('wb') as f:rc=s.run(args,env=env,cwd=src,stdout=f,stderr=s.STDOUT).returncode
  all.append([args,rc])
  if app in ('mlq','mlfq'):
   args=['python3','tools/ordinary_multilevel_replay.py',app,str(d/'guest/audit.bin')]
   with (d/'replay.log').open('wb') as f:rc=s.run(args,cwd=src,stdout=f,stderr=s.STDOUT).returncode
   all.append([args,rc])
(out/'commands.json').write_text(json.dumps(all,indent=2))
