import pathlib as p,struct,json
r=p.Path.home()/'jnox262-combined';z={}
for d in (r/'post/trace-repeats').glob('*'):
 if not d.is_dir():continue
 b=(d/'guest/audit.bin').read_bytes();n,hz=struct.unpack_from('<QQ',b);arr=[struct.unpack_from('<131Q',b,16+1048*i) for i in range(n)];q=hz//100;period=16*q
 if len(b)==268304:continue
 L=[struct.unpack_from('<11Q',b,268304+88*i) for i in range(n)];last=arr[-1]
 assert L[-1][8]&1==0 and last[10:12]==(4,0) and struct.unpack('<Q',(d/'guest/multilevel_terminal_ctl.bin').read_bytes())[0]&1==0
 service=[0]*4
 for a in arr[1:]:
  service[a[3]]+=a[6]-a[4];assert tuple(service)==a[23:27] and sum(service)==a[12]
 res=dict(rows=n,service=service,live=L[-1][4],asleep=L[-1][5],ctl=L[-1][8])
 if d.name.endswith(('blocked','exited')):
  blocked=d.name.endswith('blocked'); assert [a[0] for a in arr[1:]]==[2 if blocked else 1]*2 and [a[3] for a in arr[1:]]==[0,1];assert L[-1][4]==3*blocked and L[-1][5]&L[-1][4]==3*blocked
 elif d.name.endswith('saturated'):
  assert L[0][9]==arr[1][4]+24*q and [a[3] for a in arr[1:9]]==[1,2]*4 and all(a[0]==4 and a[23]==0 and a[6]-a[4]>=q for a in arr[1:9]);first=next(i for i,a in enumerate(arr) if a[10]==0);assert arr[first][0]==1 and L[first][4]==1 and last[23]>0;res.update(first_low=first,first_eight=[a[3] for a in arr[1:9]],absolute_end=L[0][9])
 else:
  a=arr[1];assert a[0]==4 and a[5]==a[4]+4*q and L[1][6]==a[4]+3*period+period//4 and L[1][6]<=a[6]<a[4]+4*period and a[12]//period==3 and L[1][3]==1 and a[10]==1 and a[11]==0x231
  assert L[0][9]==a[4]+96*q
  for i,x in enumerate(arr[2:],2):
   prev=arr[i-1];grant=min(prev[19+x[3]],period-prev[12]%period);assert x[4]+grant==x[5]==L[i][6] and L[i][3]-L[i-1][3]==int(x[12]//period>prev[12]//period)
  res.update(delayed_elapsed=a[6]-a[4],absolute_end=L[0][9],resets=L[-1][3],period=period)
 z[d.name]=res
(r/'post/limits.json').write_text(json.dumps(z,indent=2))

