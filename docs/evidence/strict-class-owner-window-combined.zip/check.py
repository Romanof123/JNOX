import struct,re,json,pathlib as P,hashlib,subprocess as sp
root=P.Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def nums(g,name):return [list(map(int,l.split()[1:])) for l in (g/'uart.bin').read_text().splitlines() if l.startswith(name+' ')]
def irq(g):return (g/'int.trace').read_text()
def mlq(g,admit):
 w=list(struct.unpack('<30Q',(g/'audit.bin').read_bytes())); assert w[:5]==[4 if admit else 2,62500000,4000000,4000000,24000000];assert w[5]==24000000-int(not admit)
 if not admit:assert w[6:]==[0]*24 and '[IRQ]' not in irq(g);return dict(words=w)
 q=w[2]; product=sum(1+i%16 for i in range(4096)); odd=sum((1+i%16)%2 for i in range(4096))
 assert w[12]==0 and w[14]==max(0,w[11]-q) and w[15]==w[8]-w[7] and w[13]==w[7]-w[6]-sum(w[9:13]);assert w[16]==sum(w[13:16])<=w[3];assert w[17]==w[8]-w[6]==w[9]+w[10]+min(q,w[11])+w[16]<=w[5];assert max(w[9:12])<=8000000
 assert w[18:24]==[product,11*product,w[24]*odd,16,15,1] and w[24]>0 and w[25:29]==[1,1,0,16] and w[29]==w[24]
 t=irq(g);m=re.search(r'\[IRQ\].*?ELR (0x\w+).*?Exception return .*?PC (0x\w+).*?\[SVC\].*?Exception return .*?PC (0x\w+)',t,re.S);assert m and m[1]==m[3] and m[1]!=m[2];return dict(words=w,IRQ_ELR=m[1],target_trampoline=m[2],restored_PC=m[3])
def dl(g,cap):
 cfg=nums(g,'CONFIG')[0]; epoch,end,q,ones,b,limit,yes=nums(g,'OWNER_CAP')[0];assert epoch==cfg[1] and q==cfg[2]==6250000 and ones==2 and b==4 and limit==cap and yes==int(cap==4);assert nums(g,'OWNER_PRELAUNCH')==[[0]*4];D=nums(g,'D')
 if cap==3:assert not D and not irq(g).strip() and not nums(g,'JOB') and 'REFUSED BEFORE LAUNCH' in (g/'uart.bin').read_text();return dict(epoch=epoch,cap=cap)
 E=nums(g,'OWNER_EVENT');assert len(E)==len(D)==5
 ret=[int(n,16) for n in re.findall(r'Exception return [^\n]* PC (0x\w+)',irq(g))];assert ret[1:]==[x[14] for x in D[:-1]]
 pair=[(x[9],x[10]) for x in D]; assert pair==[(3,0),(0,4),(4,0),(0,1),(1,3)]
 assert D[1][11:13]==D[2][13:15];a=nums(g,'A_PROGRESS')[0];assert a[0]==a[1]>0 and a[2]>a[1]
 starts={epoch,end-q};T=[x[7] for x in D]
 for t in T:starts.update(s for s in (t+1,t,t-q+1,t-q) if epoch<=s<=end-q)
 eventpeak=changepeak=0
 for s in starts:
  inside=[i for i,t in enumerate(T) if s<=t<s+q];nchg=sum(i<4 and pair[i][0]!=pair[i][1] for i in inside);eventpeak=max(eventpeak,len(inside));changepeak=max(changepeak,nchg)
 assert eventpeak<=4 and changepeak<=4
 for i,(x,e) in enumerate(zip(D,E)):assert e[:7]==[i,x[0],x[7],x[9],x[10],int(i<4),int(i<4)]
 assert nums(g,'OWNER_PEAK')[0]==[5,4,eventpeak,changepeak,4]
 jobs=nums(g,'JOB');dead=[epoch+j[2]*q for j in jobs];assert all(t<=d for t,d in zip(T[-2:],dead));J=nums(g,'J');assert J[-3][4]<jobs[0][3]*q and J[-2][4]<jobs[1][3]*q
 assert nums(g,'RESULT')[0][0]==89440;return dict(entry=T,pairs=pair,events=eventpeak,changes=changepeak,deadlines=dead,actual_service=[J[-3][4],J[-2][4]],restored=D[2][13:15],progress=a,eret=ret,checksum=89440,pc=re.search(r'PC=([0-9a-f]+)',(g/'registers.txt').read_text())[1])
if __name__=='__main__':
 result={}
 for d in sorted((root/'originals').iterdir()):
  if not (d/'record.json').exists():continue
  g=d/'guest';key=d.name
  try:
   st=json.loads((d/'record.json').read_text()); assert st.get('rc')==0,st
   x=mlq(g,'mlq-admit' in key) if key.startswith(('mlq-admit','mlq-refuse')) else dl(g,int(key.split('cap')[1][0])) if '-cap' in key else {}
   x['terminal']=(g/'uart.bin').read_text().splitlines()[-1];x['elf']=sha(d/'kernel.elf');result[key]=x
  except Exception as e:
   import traceback;result[key]=dict(error=traceback.format_exc())
 print(json.dumps(result,indent=2))
