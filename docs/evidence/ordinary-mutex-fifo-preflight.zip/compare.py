"""Compare the preflight ELF with the independently booted FIFO ELF archive."""
import hashlib
import json
from pathlib import Path
import struct
import sys
from zipfile import ZipFile


def load_image(payload):
    header = struct.unpack_from("<16sHHIQQQIHHHHHH", payload)
    if header[0][:6] != b"\x7fELF\x02\x01":
        raise ValueError("expected little-endian ELF64")
    segments = []
    for index in range(header[10]):
        fields = struct.unpack_from("<IIQQQQQQ", payload, header[5] + index * header[9])
        kind, flags, offset, virtual, physical, size, memory, align = fields
        if kind == 1:
            segments.append(dict(flags=flags, virtual=virtual, physical=physical,
                                 offset=offset, size=size, memory=memory, align=align,
                                 sha256=hashlib.sha256(payload[offset:offset + size]).hexdigest()))
    return segments


def main():
    pre = Path(sys.argv[1]).read_bytes()
    with ZipFile(sys.argv[2]) as bundle:
        guest = bundle.read("fifo/kernel.elf")
    left, right = load_image(pre), load_image(guest)
    result = dict(preflight=hashlib.sha256(pre).hexdigest(),
                  guest=hashlib.sha256(guest).hexdigest(), count=len(left),
                  equal=left == right, preflight_segments=left, guest_segments=right)
    print(json.dumps(result, sort_keys=True, indent=2))
    return int(len(left) != 2 or left != right)


if __name__ == "__main__":
    sys.exit(main())
