set -eu
dest=$(mktemp -d /tmp/jnox-277-integration-XXXXXX)
echo "$dest" > /mnt/d/codex/.jnox-work/277-integration-preflight/ext4-path.txt
tar -xf /mnt/d/codex/.jnox-work/277-integration-preflight/inputs.tar -C "$dest"
export CARGO_HOME="$HOME/jnox-169-first-e203caa/cargo" RUSTUP_HOME="$HOME/jnox-169-first-e203caa/rustup" RUSTUP_TOOLCHAIN=1.95.0
export PATH="$CARGO_HOME/bin:/usr/bin:/bin"
cd "$dest/kernel"
JNOX_BOARD=virt JNOX_PROFILE=mutex JNOX_APP=ordinary-fifo cargo +1.95.0 build --locked --release -j1
cd "$dest"
rustc +1.95.0 --edition=2024 --test tools/mutex_tests.rs -o "$dest/host-mutex"
"$dest/host-mutex"
