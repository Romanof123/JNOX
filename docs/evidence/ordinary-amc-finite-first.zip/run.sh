set -eu
base=$PWD
run=$(mktemp -d /tmp/jnox-amc-finite-first-XXXXXXXX)
echo "$run" > "$base/native-path.txt"
cd "$run"
df -T . > "$base/filesystem.txt"
for c in exact-lo exact-hi over-hi; do
 d=$(python3 "$base/source/tools/ordinary_amc_capture.py" freeze "$c" "$c" "$base/$c.elf" /usr/bin/qemu-system-aarch64 420eaaa2f7d85507b716cfb862fb2c7c137dfabf)
 python3 "$base/source/tools/ordinary_amc_capture.py" run "$c" "$d" || true
 cp -r "$c" "$base/"
 aarch64-linux-gnu-objdump -d "$c/kernel.elf" > "$base/$c.dis"
done
