import re,json,sys
from pathlib import Path
sys.path.insert(0,"source/tools")
from ordinary_amc_replay import assess,Incomplete
results={}
for ci,case in enumerate(("exact-lo","exact-hi","over-hi")):
 p=Path(case); raw=(p/"first/uart.bin").read_bytes(); trace=(p/"first/exceptions.log").read_bytes(); elf=(p/"kernel.elf").read_bytes()
 def get(tag):return [list(map(int,l.split()[2:])) for l in raw.splitlines() if l.startswith(b"AMR "+tag.encode()+b" ")]
 grants=get("GRANT"); works=get("WORK"); irq=get("IRQ"); ret=get("RETIRE")
 assert [g[1] for g in grants]==([0,1,0] if not ci else [0,1,1,1,3,0])
 for w in works:
  for n,s in ((w[4],w[5]),(w[7],w[8])):
   assert s==36*(n//8)+sum([2,5,1,6,3,7,4,8][(w[1]+w[2]+j)%8] for j in range(n%8))
 if not ci:
  assert get("BEGIN")[0][0]==1 and not get("COMPLETE") and not get("FROZEN")
  results[case]="original continuous exact-LO passed"; continue
 c,=get("COMPLETE"); f,=get("FROZEN"); b6=grants[-1][9]; last=irq[-1]; dis=Path(case+".dis").read_text()
 assert c[:5]==[5,0,2,8,36] and c[5]<=c[6]<b6<=last[6]<=ret[-1][6]
 assert f==[5,0,2,8,36,c[5],last[6]] and ret[-1][:6]==[6,0,2,1,0,8]
 assert len(ret)==len(grants)==6 and last[3:5]==[30,b6]
 assert re.search(rf"^\s*{c[8]-4:x}:.*\bsvc\s+#0x4c",dis,re.M)
 assert c[9]-c[7]==832 and c[12]-c[10]==832 and last[9]-last[7]==832
 tail=trace.split(b"Taking exception 2 [SVC]")
 assert len(tail)==2 and re.findall(rb"(?:with ELR|to AArch64 EL1 PC) (0x[0-9a-f]+)",tail[1])==[hex(x).encode() for x in [c[8],c[11],last[8]]]
 assert b"Taking exception 5 [IRQ]" in tail[1] and works[-1][6:]==[c[5],8,36]
 def mutate(tag,idx,value):
  line=next(l for l in raw.splitlines() if l.startswith(b"AMR "+tag.encode()+b" ")); words=line.split(); words[2+idx]=str(value).encode();return raw.replace(line,b" ".join(words),1)
 controls={}
 for name,u,t in [('svc-at-b6',mutate('COMPLETE',6,b6),trace),('changed-frozen-sum',mutate('FROZEN',4,37),trace),('wrong-idle-return',raw,trace.replace(b'to AArch64 EL1 PC '+hex(c[11]).encode(),b'to AArch64 EL1 PC '+hex(c[8]).encode())),('duplicate-svc',raw,trace+trace[trace.index(b"Taking exception 2 [SVC]"):])]:
  try: assess(ci,u,elf,t)
  except (ValueError,Incomplete) as e: controls[name]=str(e)
  else: raise ValueError(name+" accepted")
 results[case]=dict(task=c[5],svc=c[6],b6=b6,irq=last[6],retirement=ret[-1][6],transition_ticks=works[2][3]-irq[1][4],controls=controls)
print(json.dumps(results,indent=2))
