from pathlib import Path
import sys,hashlib,re,zipfile
p=Path(sys.argv[1]); H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for name,num in [('published','095'),('held','096')]:
 for lang in ['.en.md','.md']:
  root=p/name; f=root/'docs/evidence'/('evd-'+num+lang); t=f.read_text()
  for target in re.findall(r'\]\(([^)]+)\)',t):
   if '://' in target:continue
   dest=(f.parent/target).resolve();assert dest.exists()
   if dest.suffix=='.zip':
    assert H(dest) in t and zipfile.ZipFile(dest).testzip() is None
    print(name,lang,target,H(dest))
  doc=(root/'docs'/('scheduling-release-cases'+lang)).read_text()
  ids=set(re.findall(r'^\| (POL-\d{3})',doc,re.M))
  assert len(ids)==18 and '18' in doc.splitlines()[4]
  print(name,lang,'18 rows;',doc.splitlines()[4].split('.')[-2])
d=Path('/mnt/d/codex/jnox252-command-ver');cmd=(p/'published/docs/deadline-supply-plan.md').read_text().split('```bash\n',1)[1].split('```',1)[0].encode()
assert cmd==(d/'recipe').read_bytes()
