from pathlib import Path
import sys,hashlib,zipfile
d=Path(__file__).resolve().parent
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
rep=['# Independent documented command verification / 공개 명령 독립 검증','','Tested b816c26b54d98526cfc0f3f97505f19abc75e19d on WSL ext4 with the published literal Bash recipe, one Cortex-A72 QEMU virt/GICv2 TCG vCPU, 128 MiB. The original aggregate was 0. Original UART and ELFs were lost when WSL cleared /tmp before the copy to D:. first-observed.en-ko.md retains observed terminal data. The second invocation used persistent ext4 TMPDIR. 원본 바이트를 보존하지 못한 첫 실행과 원본 보관에 성공한 재실행을 분리했다.','','Second aggregate / 재실행 종료 코드 '+(d/'second-program.rc').read_text().strip()+'.','','|Position|Mode|Selector|Build/QEMU/replay|UART terminal|Reason or A progress|','|---|---|---|---|---|---|']
n=0
for mode in ['trace','plain']:
 for app in ['ordinary-edf-supply-refuse','ordinary-llf-supply-refuse','ordinary-edf-supply','ordinary-llf-supply']:
  n+=1; pos=d/'second'/(app+'-'+mode)
  for line in (pos/'SHA256SUMS').read_text().splitlines():
   digest,name=line.split();assert h(pos/name)==digest
  rc='/'.join((pos/(x+'.rc')).read_text().strip() for x in ['build','qemu','replay']);t=(pos/'uart.raw').read_text().splitlines()
  note=next((l for l in t if l.startswith('A_PROGRESS')),next(l for l in t if l.startswith('CONFIG')))
  rep.append(f'|{n}|{mode}|{app}|{rc}|{t[-1]}|{note}|')
rep += ['','All sixteen archived ELF/UART hashes were independently recomputed after copying. See second/*/SHA256SUMS. 정상 및 거부 결과의 UART, ELF, 예외 로그, 재생 JSON과 종료 코드를 모두 보관했다.','','dcbf2251887bcaca73a040eb7774572e659d396d changes five documentation/evidence files. Kernel, tests, trace CSV and literal command match the tested checkout. b816c26 adds only the recipe document over 608de71. Both graph tools exited 0. The diff adds 17 typed links, with three requirement chains, two design links and three implementation, test and policy evidence links. The benchmark tools/qemu_boot.py matches main 8609aab and requires its fixed deadline transcript after the boot prefix. EVD-095 historically records bacd8dc with LLF plain failure, 5/6 host checks, and the interrupted overload capture and successful retry. The corrected archive preserves eight truncated acquisitions, eighteen before-guest failures, eight complete supply captures and ten complete legacy controls. 17개 유형 연결과 원래 실패 기록, 수정 후 별도 증거를 확인했다.','', 'Both language receipts resolve their local documents and CRC-valid ZIPs. Digests are in receipts.txt. EVD-096 at held #251 28050f99867ad86a40689127af43b041f1c2f304 reports default-clock candidate P exceeding 62,500 ticks in 3/5 boots. All 18 scheduling release decisions remain open in both languages on both branches. 두 언어에서 18개 출시 판정이 모두 열려 있다. #251의 P 게이트는 보류 상태다. Physical/product timing was outside this QEMU run.']
(d/'report.en-ko.md').write_text('\n'.join(rep)+'\n',encoding='utf8')
with zipfile.ZipFile(d/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(d.rglob('*')):
  if f.is_file() and f.name not in ['raw.zip','SHA256SUMS.txt','pm256.en-ko.md']:z.write(f,f.relative_to(d))
assert zipfile.ZipFile(d/'raw.zip').testzip() is None
(d/'SHA256SUMS.txt').write_text(''.join(h(d/x)+'  '+x+'\n' for x in ['raw.zip','report.en-ko.md','pm256.en-ko.md']))
print((d/'SHA256SUMS.txt').read_text());print('\n'.join(rep[6:16]))
