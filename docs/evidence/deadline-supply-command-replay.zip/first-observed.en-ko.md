# First documented run / 문서 명령 최초 실행
The original literal program reported aggregate 0. Observed build/QEMU/replay codes in all eight positions were 0/124/0. The WSL /tmp staging and capture directories disappeared before the copy to D:. These transcribed observations were retained from terminal output. ELF, UART byte streams and exception logs for this first invocation could not be recovered. Its hashes cannot be independently rechecked. The second invocation has a separate receipt and persistent raw archive.
최초 실행은 8개 모두 0/124/0이었다. D: 복사 전 임시 경로가 사라져 최초 원시 바이트·ELF 해시를 재검증할 수 없다. 이후 재실행 결과를 별도로 기록한다.

|Position|Mode|Selector|Terminal|Reason or A progress at suspend / resume / finish|
|---|---|---|---|---|
|1|trace|EDF refuse|REFUSED BEFORE LAUNCH|8|
|2|trace|LLF refuse|REFUSED BEFORE LAUNCH|9|
|3|trace|EDF|FINISHED; RESULT 89440|613399 / 613399 / 849316|
|4|trace|LLF|FINISHED; RESULT 89440|606223 / 606223 / 910457|
|5|plain|EDF refuse|REFUSED BEFORE LAUNCH|8|
|6|plain|LLF refuse|REFUSED BEFORE LAUNCH|9|
|7|plain|EDF|FINISHED; RESULT 89440|586964 / 586964 / 857083|
|8|plain|LLF|FINISHED; RESULT 89440|601742 / 601742 / 901163|
