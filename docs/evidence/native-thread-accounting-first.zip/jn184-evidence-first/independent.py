import hashlib,json
from pathlib import Path
p=Path(__file__).parent/'first'
m=json.loads((p/'manifest.json').read_text())
s=json.loads((p/'result.json').read_text())
for k,n in [('stdout','stdout.txt'),('stderr','stderr.txt'),('fixture','../fixture')]:
 assert hashlib.sha256((p/n).read_bytes()).hexdigest()==m[k+'_sha256']
lines=(p/'stdout.txt').read_text().splitlines()
rw,rc=map(int,lines[1].split()[1:])
assert 0<min(rw,rc)<=max(rw,rc)<=100000 and lines[-1]=='complete' and len(lines)==109
prev=[0]*5
width=0
for i,name in enumerate([f'empty{i}' for i in range(32)]+['cpu','blocked','contended']):
 start,end,act=[x.split() for x in lines[3+i*3:6+i*3]]
 assert start[:3]==['sample',name,'start'] and end[:3]==['sample',name,'end'] and act[:2]==['activity',name]
 a,b=[list(map(int,x[3:])) for x in (start,end)]
 for w,c,r,q,t,C,W in (a,b):
  assert all(v>=u for v,u in zip([w,c,r,q,t],prev)) and 0<=W-w<=10**6 and 0<=C-c<=10**6
  prev=[W,C,r,q,t]
 def bounds(left,right,res):
  return [max(0,b[left]-a[right]-2*res),b[right]-a[left]+2*res]
 w,c=bounds(0,6,rw),bounds(1,5,rc)
 rate=-(-w[1]//1000)
 o=[max(0,w[0]-c[1]-rate),max(0,w[1]-c[0]+rate)]
 delta=[b[k]-a[k] for k in [2,3,4]]
 v,V,n,N,progress=map(int,act[2:])
 assert V>=v and N>=n and c[0]<=w[1]+rate
 assert s['intervals'][name]==dict(wall_ns=w,cpu_ns=c,outside_cpu_ns=o,schedstat_delta=delta,voluntary=V-v,involuntary=N-n,peer_batches=progress)
 if i<32:
  assert w[1]<=2000000
  width=max(width,w[1]-w[0])
 else:
  assert c[0]-1000000<=delta[0]<=c[1]+1000000 and delta[1]<=o[1]+1000000
  if name=='blocked': assert o[0]>=70000000 and c[1]<=5000000 and V>v and delta[1]<=5000000
  else: assert c[0]>=39000000
  if name=='contended': assert o[0]>=10000000 and N>n and progress>0 and delta[1]>=10000000 and delta[2]>=1
  print(name,w,c,o,delta,V-v,N-n,progress)
print('maximum empty wall bracket width ns',width)
