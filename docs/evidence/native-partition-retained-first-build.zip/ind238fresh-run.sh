set -eu
cd /tmp/ind238verify
r=/home/ywcho/ind238fresh
mkdir "$r"
mkdir "$r/evidence"
export CARGO_BUILD_JOBS=1 PYTHONPATH=$HOME/jnox-169-first-e203caa/deps PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH
for a in p q; do for v in A B C D; do
opt=()
case $v in B|D) opt+=(--partition-frames retained-v1);; esac
case $v in C|D) opt+=(--partition-phase irq-v1);; esac
rc=0
python3 tools/build_native_el0.py --app partition-$a "${opt[@]}" --out "$r/build-$a$v" >"$r/build-$a$v.log" 2>&1 || rc=$?
echo "$rc" >"$r/build-$a$v.rc"
done; done
i=0
for a in p q; do for clock in default icount3; do for order in ABCD DCBA BADC CDAB ABCD; do for ((j=0;j<4;j++)); do
v=${order:j:1}; i=$((i+1)); b="$r/build-$a$v"; d="$r/evidence/$(printf %02d $i)-$a-$clock-$v"; rc=0
python3 tools/native_weighted_capture.py partition-$a "$clock" "$d" "$b/kernel.elf" "$b/user.elf" examples/portability/native_partition_monitor.c 714f89f5bd010ab6e2eecac03fbb44446c431453 >"$d.log" 2>&1 || rc=$?
echo "$rc" >"$d.capture"
if test -f "$d/session.json"; then h=$(sha256sum "$d/session.json"|cut -d' ' -f1); echo "$h" >"$d.digest"; rc=0; python3 tools/native_partition_replay.py "$d" "$h" >"$d.json" 2>"$d.err" || rc=$?; echo "$rc" >"$d.rc"; fi
done; done; done; done
