set -eu
cd /tmp/ind238verify
r=/home/ywcho/ind238fresh
export CARGO_BUILD_JOBS=1 PYTHONPATH=$HOME/jnox-169-first-e203caa/deps PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH
mkdir "$r/controls"
for a in weighted-share weighted-wake startup-probe; do
b="$r/build-$a"; rc=0; python3 tools/build_native_el0.py --app "$a" --out "$b" >"$b.log" 2>&1 || rc=$?; echo "$rc" >"$b.rc"; if ((rc)); then continue; fi
for c in default icount3; do t=native_weighted; args=("${a#weighted-}" "$c"); p=native_weighted_monitor; if [[ $a == startup-probe ]]; then [[ $c == default ]] || continue; t=native_el0; args=(); p=native_startup_probe; fi
d="$r/controls/$a-$c"; rc=0; python3 tools/${t}_capture.py "${args[@]}" "$d" "$b/kernel.elf" "$b/user.elf" "examples/portability/$p.c" "$(git rev-parse HEAD)" >"$d.log" 2>&1 || rc=$?; echo "$rc" >"$d.capture"; if [[ -f "$d/session.json" ]]; then rc=0; python3 tools/${t}_replay.py "$d" "$(sha256sum "$d/session.json" |cut -d' ' -f1)" >"$d.json" 2>"$d.err" || rc=$?; echo "$rc" >"$d.rc"; fi
done; done
unzip -qo docs/evidence/native-partition-ordinary-first.zip -d "$r/historical"
for session in "$r"/historical/*/session.json; do d=${session%/*}; a=${d##*/}; case "$a" in partition*) t=native_partition;; weighted*) t=native_weighted;; startup*) t=native_el0;; *) continue;; esac
rc=0; python3 tools/${t}_replay.py "$d" "$(sha256sum "$session" |cut -d' ' -f1)" >"$r/controls/old-$a.json" 2>"$r/controls/old-$a.err" || rc=$?; echo "$rc" >"$r/controls/old-$a.rc"
done
