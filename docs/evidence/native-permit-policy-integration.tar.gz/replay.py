#!/usr/bin/env python3
"""Build and capture six serial boots. Usage: python3 replay.py SOURCE NEW_RESULTS"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SRC, OUT = (Path(p).resolve() for p in sys.argv[1:3])
exact = sys.argv[3:] == ["--approved-policy"]
REV = "52e4a8b23897801a418da23cac18fefca4cea35b"
TREE = "aa185fdf2ee73cd1633153ab4ce7ddd6577bf321"
INPUT = HERE / ("approved-policy" if exact else "inputs")
assert (len(sys.argv) == 3 or exact) and not OUT.exists()
OUT.mkdir(parents=True)
env = {k: v for k, v in os.environ.items() if not k.startswith(("JNOX_", "CARGO_FEATURE_")) and k not in ("RUSTFLAGS", "PYTHONPATH", "CARGO_TARGET_DIR", "CARGO_BUILD_TARGET", "CARGO_ENCODED_RUSTFLAGS")}
env.update(CARGO_BUILD_JOBS="1", LC_ALL="C", TZ="UTC", PYTHONDONTWRITEBYTECODE="1")
def output(*argv):
    return subprocess.check_output(argv, cwd=SRC, env=env, text=True).strip()
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def put(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(tag, *argv):
    argv = [str(a) for a in argv]
    with (folder / (tag + ".log")).open("x") as log:
        log.write("$ " + shlex.join(argv) + "\n")
        log.flush()
        began = now()
        result = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT, env=env, cwd=SRC)
        put(folder / (tag + ".command.json"), dict(argv=argv, cwd=str(SRC), start_utc=began, finish_utc=now(), returncode=result.returncode))
        if result.returncode:
            print(folder.name, tag, "FAILED", result.returncode, flush=True)
            return False
    return True
assert output("git", "rev-parse", "HEAD") == REV
assert output("git", "rev-parse", "HEAD^{tree}") == TREE
assert output("git", "status", "--porcelain", "--untracked-files=no") == ""
subprocess.run(["sha256sum", "-c", "inputs.sha256"], cwd=HERE, check=True, stdout=subprocess.DEVNULL)
if exact:
    subprocess.run(["sha256sum", "-c", "approved-policy.sha256"], cwd=HERE, check=True, stdout=subprocess.DEVNULL)
put(OUT / "host.json", dict(commit=REV, tree=TREE, rustc=output("rustc","-vV"), cargo=output("cargo","-V"), qemu=output("qemu-system-aarch64","--version"), qemu_sha256=digest(Path(shutil.which("qemu-system-aarch64"))), python=sys.version, uname=output("uname","-a")))
failures=[]
cases = ("on", "off", "scale20")
if not exact:
    cases += ("fifo-healthy", "rr-healthy", "loan-fifo")
for case in cases:
    folder = OUT / case
    folder.mkdir()
    pkg = folder / "pkg"
    args = ["python3", "tools/build_native_el0.py", "--out", pkg, "--board", "virt"]
    if case in ("on", "off", "scale20"):
        prefix = {"on":"policy", "off":"unmonitored", "scale20":"scale20"}[case]
        args += ["--task-policy", INPUT / (prefix + ".txt")]
        cap = ["python3", HERE / "helpers/policy_capture.py", folder / "cap", pkg, case, "JNOX POLICY DONE"]
    else:
        fused = case != "loan-fifo"
        policy = "rr" if case.startswith("rr") else "fifo"
        args += ["--policy", policy]
        if policy == "rr":
            args += ["--quantum-ticks", "625000"]
        if fused:
            app, probe, status = "sender", "examples/native-safety-admission/sender/src/main.rs", "71"
            args += ["--elf",INPUT/"sender.elf","--peer-elf",INPUT/"controller.elf","--peer-elf",INPUT/"supervisor.elf","--arg","healthy","--peer-arg","healthy","--peer-arg","fused-phase","--peer2-arg","healthy","--priority","6","--peer-priority","7","--peer-priority","4","--ipc-route","2:0","--ipc-route","2:1","--loan-route","0:1","--safety-channel","--safety-qualification"]
        else:
            app, probe, status = "producer", "examples/native-loan/producer.c", "73"
            args += ["--elf",INPUT/"producer.elf","--peer-elf",INPUT/"reader.elf","--priority","7","--peer-priority","1","--loan-route","0:1"]
        cap = ["python3","tools/native_el0_capture.py",folder/"cap",pkg/"kernel.elf",INPUT/(app+".elf"),probe,REV,"--manifest",pkg/"manifest.json","--plain","--expect-exit",status,"--timeout","40","--uart-limit","8388608"]
    if not run("build", *args):
        failures.append(case + ":build")
        continue
    manifest = json.loads((pkg/"manifest.json").read_text())
    assert manifest["commit"] == REV and not manifest["tracked_changes"]
    assert digest(pkg/"kernel.elf") == manifest["kernel_elf_sha256"]
    put(folder/"provenance.json",dict(commit=REV, tree=output("git","rev-parse",REV+"^{tree}"), manifest_sha256=digest(pkg/"manifest.json"), kernel_elf_sha256=digest(pkg/"kernel.elf"), app_sha256=[s["elf_sha256"] for s in (manifest.get("apps") or manifest["slots"])]))
    if not run("guest", *cap):
        failures.append(case + ":guest")
    print(now(), case, flush=True)
put(OUT/"failures.json", failures)
sys.exit(bool(failures))
