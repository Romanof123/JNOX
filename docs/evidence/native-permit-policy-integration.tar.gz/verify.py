#!/usr/bin/env python3
"""Offline reduction. python3 verify.py SIX_RESULTS EXACT_POLICY_RESULTS > findings.json"""
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile

packet = Path(__file__).resolve().parent
sys.path.insert(0, str(packet / "helpers"))
from score import analyze

first, exact = [Path(arg).resolve() for arg in sys.argv[1:]]
def read(path):
    return json.loads(path.read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def policy(result, tag, original, inputs, require_same):
    run=result/tag
    m=read(run/"pkg/manifest.json")
    prov=read(run/"provenance.json")
    kernel=run/"pkg/kernel.elf"
    wire=run/"pkg/policy.bin"
    assert prov["commit"]==m["commit"]=="52e4a8b23897801a418da23cac18fefca4cea35b" and not m["tracked_changes"]
    assert prov["tree"]=="aa185fdf2ee73cd1633153ab4ce7ddd6577bf321"
    assert digest(run/"pkg/manifest.json")==prov["manifest_sha256"] and digest(kernel)==prov["kernel_elf_sha256"]==m["kernel_elf_sha256"]
    blob=wire.read_bytes()
    assert digest(wire)==m["policy_sha256"] and kernel.read_bytes().count(blob)==1
    assert [a["elf_sha256"] for a in m["apps"]]==prov["app_sha256"]
    if require_same:
        assert m["policy_sha256"]==original["policy_sha256"] and m["apps"]==original["apps"]
    assert all(digest(inputs/a["path"])==a["elf_sha256"]==hashlib.sha256(blob[a["elf_offset"]:a["elf_offset"]+a["elf_size"]]).hexdigest() for a in m["apps"])
    assert all(read(run/(step+".command.json"))["returncode"]==0 for step in ("build","guest"))
    uart=(run/"cap"/(tag+".uart")).read_text()
    assert re.search(r"^JNOX POLICY DONE$", uart,re.M)
    cpus=read(run/"cap"/(tag+".cpus.json"))
    assert len(cpus)==1
    ram=read(run/"cap"/(tag+".ram.json"))
    assert len({r["rw_pa"] for r in ram})==len(m["apps"])
    assert all(s["guard_before"]==s["guard_after"]==0 for r in ram for s in r["stacks"])
    summaries=re.findall(r"SUMMARY app=(\w+) task=(\w+)",uart)
    assert summaries==[(a["name"],t["name"]) for a in m["apps"] for t in a["tasks"]]
    exits={a+"."+t:[int(tick),int(status)] for a,t,tick,status in re.findall(r"^JNOX POLICY EXIT app=(\w+) task=(\w+) tick=(\d+).*status=(-?\d+)$",uart,re.M)}
    if tag=="scale20":
        assert len(exits)==20 and all(v[1]==25 for v in exits.values())
        assert all(int.from_bytes(bytes.fromhex(r["rw_hex"])[:4],"little")==8 for r in ram)
        return dict(apps=20,tasks=20,distinct_rw_pages=20,heartbeat_exits=20,final_value=8,policy_sha256=digest(wire))
    freq=int(re.search(r"JNOX POLICY CLOCK .*hz=(\d+)",uart)[1])
    assert freq==62500000
    expected={"sensor.sample":21,"sensor.observe":22,"heartbeat.beat":25,"late.batch":24}
    if tag=="off":
        expected["heavy.burn"]=23
    assert {k:e[1] for k,e in exits.items()}==expected
    assert re.search(r"FAULT app=fault task=report .*source=svc status=37",uart)
    out=dict(exit_ticks_status=exits,fault_status=37,apps=5,tasks=6,policy_sha256=digest(wire))
    samples=struct.unpack_from("<2I",bytes.fromhex(ram[0]["rw_hex"]),12)
    assert samples[0]==20 and 8<=samples[1]<=20
    out["sensor_terminal"]=samples
    release=int(re.search(r"RELEASE app=heavy task=burn tick=(\d+)",uart)[1])
    for event,ms in (("DEADLINE",15),("WATCHDOG",30)):
        if tag=="off" and event=="WATCHDOG":
            assert "JNOX POLICY WATCHDOG" not in uart
            continue
        ev=re.search(rf"{event} app=heavy task=burn tick=(\d+) observed=(\d+) source=irq_user irq=30 running_app=heavy running_task=burn",uart)
        assert ev,(tag,event)
        due,observed=map(int,ev.groups())
        assert due==release+ms*(freq//1000)+1 and observed>=due
        out[event.lower()]=dict(first_release=release,due=due,observed=observed,delta_ticks=observed-due)
    if tag=="on":
        assert re.search(r"FAULT app=heavy task=burn tick=\d+ reason=watchdog status=-110",uart)
        assert all(v[0]>out["watchdog"]["observed"] for v in exits.values())
    return out

results = {}
for name,base,inputs in (("first",first,packet/"inputs"),("approved",exact,packet/"approved-policy")):
    assert read(base/"failures.json")==[]
    results[name]={}
    for tag in ("on","off","scale20"):
        original=read(packet/"reference"/(("scale" if tag=="scale20" else tag)+".json"))
        results[name][tag]=policy(base,tag,original,inputs,name=="approved")
def load_segments(path):
    image=path.read_bytes()
    offset=struct.unpack_from("<Q",image,32)[0]
    size,count=struct.unpack_from("<HH",image,54)
    records=[]
    for i in range(count):
        ph=struct.unpack_from("<II6Q",image,offset+i*size)
        if ph[0]==1:
            records.append((ph, image[ph[2]:ph[2]+ph[5]]))
    return records
assert load_segments(packet/"inputs/heartbeat.elf")==load_segments(packet/"approved-policy/heartbeat.elf")
results["fused"]={}
with tempfile.TemporaryDirectory() as temp:
    root=Path(temp)
    (root/"apps").symlink_to(packet/"inputs",target_is_directory=True)
    (root/"pkg").mkdir()
    for case,role,policy_name in (("fifo-healthy","fused","fifo"),("rr-healthy","fused","rr"),("loan-fifo","loan","fifo")):
        tag="52e4a8b23-"+role+"-"+policy_name+"-"+("healthy" if role=="fused" else "ordinary")
        link=root/("001-"+tag)
        link.mkdir()
        (link/"cap").symlink_to(first/case/"cap",target_is_directory=True)
        (root/"pkg"/tag).symlink_to(first/case/"pkg",target_is_directory=True)
        (link/"status").write_text(str(read(first/case/"guest.command.json")["returncode"]))
        m=read(first/case/"provenance.json")
        assert m["commit"]=="52e4a8b23897801a418da23cac18fefca4cea35b" and m["tree"]=="aa185fdf2ee73cd1633153ab4ce7ddd6577bf321" and digest(first/case/"pkg/manifest.json")==m["manifest_sha256"]
        b=analyze(root,link)
        if role=="loan":
            assert b["passed"]
            results["loan"]={k:b[k] for k in ("exits","state","attempts","pages","full","stale","final","reads")}
            continue
        phases=b["phases"]
        assert b["functional"] and b["output"]==[1,1] and b["commit_ok"]==8 and b["rx"]==8
        maximum=lambda arr: max(arr,default=None)
        results["fused"][policy_name]=dict(
            exits=b["exits"], role_errors=[h[-1] for h in b["headers"]], frequency=b["headers"][0][3],
            phases=phases, max_lo=maximum(r["lo"] for r in phases), max_hi=maximum(r["hi"] for r in phases if r["hi"] is not None),
            open=len(b["unbounded"]), misses=b["misses"], prewake_missing=[i for i,r in enumerate(phases) if not r["prewake"]],
            job_hi=maximum(156250+r["hi"] for r in phases if r["phase"]==2 and r["hi"] is not None),
            sender_hi=maximum(r["hi"] for r in b["sender"] if r["hi"] is not None), sender_open=sum(r["hi"] is None for r in b["sender"]),
            gap_hi=maximum(g[1] for g in b["complete_gap"]), irq_hi=b["max_grid_irq"], output=b["output"],
            checked_completes=b["protected_complete"], entries=len(b["entries"]), commits=b["commit_ok"], receive=b["rx"],
            private_rejections=b["private_rejections"], fixed_lost=b["fixed_loss"], qual_lost=b["qual_loss"], safety_lost=b["safety_loss"])
print(json.dumps(results,indent=2))
