# Host replay of the first raspi4b recordings

Original commit c388505e576f3019966ae2c74215767097c6fc18. Protocol tree 85660a1502c93d9cee6aa4dac1fc619db0cdce96. Corrected tree 7295223c4f83cf29bbe7683659c586e6218b394a. The decoder and its shared fixed_runtime_observer dependency were exported from Git.
- original.py SHA-256 9bcae27290d395d82aab696a5fa100d782b834dabd3035bb837491331abb09ea
- candidate.py SHA-256 c2cb4f8ee13061f8fc2bf3699c0ffe9a4419f4aea69ff54f97e7c601b60d7fa9
- fixed_runtime_observer.py SHA-256 87477a4b587ac79016ec95fd5127d007bb22391b9b043fb26743ccaaed7fe04d

## FIFO

Original rejected with exit 1, terminal idle mismatch. Corrected exited 0. Generation 4 interrupted slot 0 and selected HIGH slot 2. Generation 5 retired HIGH and restored slot 0. The interrupted and selected (frame, ELR, SP) both equal ('0x88d80', '0x812b8', '0x890c0'). Final generation 10 selects idle with ('0x98e30', '0x82d70', '0x99170'). Terminal record routine 0x82d70.

UART markers in recorded order: JNOX PI4 BOOT → JNOX PI4 READY → FIXED FIFO START → FIXED FIFO A START → FIXED FIFO B YIELD → FIXED FIFO A RESUME → FIXED FIFO HIGH → FIXED FIFO A DONE → FIXED FIFO B SLEEP → FIXED FIFO B DONE

All ordered EL1 returns (10) equal their selected PCs. Every incoming ELR and exception type matched (2 IRQ, 7 SVC). Separate EL2 boot returns: 1.

SHA-256
- kernel.elf bd309a1f80bd45f56b582f7d3c55836d1df2c7863880f7fca6526a34b0399991
- kernel8.img a1c84352e8e022fa969375097bc6fbc8e64ceda8ca2f2ad75bb901e8979fa91e
- manifest.json 76000635781f35538491d72be83371d773ce92cb1634497ac5af275ca2f2cdb2
- exceptions.log d0242f540d743d330c772aa425cd6fba1bacd0c51d0ebaf547a4393aba8df65b
- uart.bin 3c0977fc5875d5bc35852ba79dd499077795a2356ef73975d3dee280bc2c09bc

Host controls
- frame-as-target: exit 1 incomplete evidence: invalid dispatch sequence, CPU or selected PC
- different-code: exit 1 incomplete evidence: terminal idle mismatch
- changed-continuation: exit 1 incomplete evidence: selected frame does not match saved continuation
- missing-progress: exit 2 
- truncated: exit 1 incomplete evidence: truncated or extra engineering row
- unknown-tag: exit 1 incomplete evidence: invalid schema
- roundtrip: exit 0 

## RR

Original rejected with exit 1, terminal idle mismatch. Corrected exited 0. Generation 2 interrupted slot 0 and selected HIGH slot 1. Generation 3 retired HIGH and restored slot 0. The interrupted and selected (frame, ELR, SP) both equal ('0x88d70', '0x81388', '0x890b0'). Final generation 7 selects idle with ('0x98e30', '0x82d2c', '0x99170'). Terminal record routine 0x82d2c.

UART markers in recorded order: JNOX PI4 BOOT → JNOX PI4 READY → FIXED RR START → FIXED RR A START → FIXED RR HIGH → FIXED RR B START → FIXED RR A DONE → FIXED RR B DONE

All ordered EL1 returns (7) equal their selected PCs. Every incoming ELR and exception type matched (3 IRQ, 3 SVC). Separate EL2 boot returns: 1.

SHA-256
- kernel.elf 15d6b1336f80b24462c16192a4b3ae733f237bbcbb0445e976c73b559f953ed7
- kernel8.img f7cbb3dda3a279cfda0e4f3f6fc7b3f19620152909f69323527db75e922b4a36
- manifest.json e059178316772c132b6633e249f990f784f10ad86979087cbfc21a8ba466c4c5
- exceptions.log 69a1a44aa4d11053076cb1a0247211e10b4bf4a4f20ca47afcfc5d25e5cdf11d
- uart.bin eeccb78bea27a54126b8abc0ff0899a1caaf24d2f6359b60f5ddf0b4da5c9c8d

Host controls
- frame-as-target: exit 1 incomplete evidence: invalid dispatch sequence, CPU or selected PC
- different-code: exit 1 incomplete evidence: terminal idle mismatch
- changed-continuation: exit 1 incomplete evidence: selected frame does not match saved continuation
- missing-progress: exit 2 
- truncated: exit 1 incomplete evidence: truncated or extra engineering row
- unknown-tag: exit 1 incomplete evidence: invalid schema
- roundtrip: exit 0 

Raw argument vectors, outputs, byte offsets and typed dispatch words are in replay.json. The first native Windows setup attempts lacked the observer module and then a supported nm. Formal reproduction used WSL with GNU AArch64 nm. No guest or builds were run. This replay concerns existing QEMU observations. The task probe brackets positive progress, and the external trace supplies model return PCs. Physical hardware, independently retired instructions, and timing bounds remain unverified.
