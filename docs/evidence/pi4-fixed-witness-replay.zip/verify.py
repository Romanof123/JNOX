import subprocess, pathlib, hashlib, json, re, copy
P=pathlib.Path
out={}
def invoke(cli, uart):
    cmd=['python3',cli,str(uart),'--profile','pi4-fixed-'+mode+'-witness','--manifest',str(d/'manifest.json'),'--elf',str(d/'kernel.elf'),'--image',str(d/'kernel8.img')]
    a=subprocess.run(cmd,capture_output=True,text=True)
    return dict(cmd=cmd,rc=a.returncode,stdout=a.stdout,stderr=a.stderr)
def encode(rows):
    h=14695981039346656037
    for row in rows:
        for v in row:
            for b in v.to_bytes(8,'little'): h=((h^b)*1099511628211)%2**64
    return ('\n'.join(markers+['PW '+' '.join(map(str,r)) for r in rows]+[f'PW END {len(rows)} {h}'])+'\n').encode()
for mode in ['fifo','rr']:
    d=P('../pi4-witness-independent')/(mode+'-eng')/'first'
    uart=d/'uart.bin'
    orig=invoke('original.py',uart)
    P(mode+'-original-linux.json').write_text(json.dumps(orig,indent=2))
    assert orig['rc']==1 and 'terminal idle mismatch' in str(orig),orig
    raw=uart.read_bytes(); lines=raw.decode().splitlines()
    rows=[list(map(int,s.split()[1:])) for s in lines if s.startswith('PW ') and 'END' not in s]
    markers=[s for s in lines if not s.startswith('PW ')]
    disp=[r[1:] for r in rows if r[0]==2]
    high=next(r for r in disp if r[1]==1 and next(t[2] for t in rows if t[0]==1 and t[1]==r[5])==2)
    resume=next(r for r in disp if r[0]>high[0] and r[5]==high[4])
    e=(d/'exceptions.log').read_text()
    pcs=[int(s,16) for s in re.findall(r'Exception return from AArch64 EL1 to AArch64 EL1 PC (0x\w+)',e)]
    ins=[int(s,16) for s in re.findall(r'with ELR (0x\w+)',e)]
    kinds=re.findall(r'Taking exception \d+ \[(\w+)\]',e)
    assert pcs==[r[10] for r in disp] and ins==[r[7] for r in disp[1:]] and kinds==[{1:'IRQ',2:'SVC'}[r[1]] for r in disp[1:]]
    assert high[6:9]==resume[9:12] and disp[-1][10]==rows[-1][-1]
    data=dict(original=orig,hashes={n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in ['kernel.elf','kernel8.img','manifest.json','exceptions.log','uart.bin']},markers=markers,offsets=[(raw.index((s+'\n').encode()),s) for s in lines if s.startswith('PW ')],high=high,resume=resume,terminal=disp[-1],idle=rows[-1],irq=kinds.count('IRQ'),svc=kinds.count('SVC'),eret_el1=len(pcs),eret_el2=e.count('return from AArch64 EL2'),controls={})
    data['candidate']=invoke('candidate.py',uart)
    for case in ['frame-as-target','different-code','changed-continuation','missing-progress','truncated','unknown-tag','roundtrip']:
        ctrl=copy.deepcopy(rows)
        ds=[r for r in ctrl if r[0]==2]
        if case=='frame-as-target': ds[-1][11]=ds[-1][10]
        if case=='different-code': ds[-1][11]=ds[0][11]
        if case=='changed-continuation': ds[resume[0]-1][11]=ds[0][11]
        if case=='missing-progress': ctrl=[r for r in ctrl if not(r[0]==3 and r[1]==resume[0] and r[2]==1)]
        if case=='unknown-tag': ctrl[-1][0]=44
        f=P(mode+'-'+case+'.bin'); f.write_bytes(encode(ctrl) if case!='truncated' else raw[:-15]); data['controls'][case]=invoke('candidate.py',f)
    out[mode]=data
    P('replay.json').write_text(json.dumps(out,indent=2))
    print(mode,orig['stderr'],data['candidate']['rc'],data['irq'],data['svc'],data['eret_el1'],[(k,v['rc'],v['stderr']) for k,v in data['controls'].items()])
