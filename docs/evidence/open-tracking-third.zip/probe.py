import json,subprocess,sys
from pathlib import Path
cases=["https://example.org/guide(#193)", "[guide](https://example.org/guide(#193))", "<https://example.org/guide(#193)>", "https://github.com/other/JNOX/wiki/Related(#193)"]
Path("foreign-probe-freeze.json").write_text(json.dumps([[v,1] for v in cases]))
out=[]
for i,v in enumerate(cases):
 d=json.load(open("inputs/00.json"));d[0]["body"]=v;k="inputs/foreign-%d.json"%i;Path(k).write_text(json.dumps(d));r=subprocess.run([sys.executable,"D:/codex/.jnox-work/ticket-context-third-qa/tools/open_tracking.py",k],text=True,capture_output=True);out.append([v,1,r.returncode,r.stdout]);print(out[-1])
Path("foreign-probe-results.json").write_text(json.dumps(out,indent=2))
