set -eu
D=/mnt/d/codex/jnox301-independent-evidence
cd "$D"
for tag in main independent; do
 out="$D/compat/$tag/binaries"; mkdir -p "$out"
 for app in edf startup; do
  cp "$HOME/jnox301-pkgs/$tag-$app/kernel.elf" "$out/$app.kernel.elf"
  cp "$HOME/jnox301-pkgs/$tag-$app/user.elf" "$out/$app.user.elf"
  cp "$HOME/jnox301-pkgs/$tag-$app/manifest.json" "$out/$app.manifest.json"
  test "$(sha256sum "$out/$app.kernel.elf" | cut -d' ' -f1)" = "$(cut -d' ' -f1 "$D/compat/$tag/$app.sha256")"
 done
 cp "$HOME/jnox301-$tag/kernel/target/aarch64-unknown-none/release/jnox-kernel" "$out/control-dm.kernel.elf"
 test "$(sha256sum "$out/control-dm.kernel.elf" | cut -d' ' -f1)" = "$(cut -d' ' -f1 "$D/compat/$tag/control-dm.sha256")"
done
find . -type f ! -name input-source.tar.gz ! -name PACKET-SHA256 -print0 | sort -z | xargs -0 sha256sum > PACKET-SHA256
dest=/mnt/d/codex/jnox301-firsts-4a0c17a-portable.tar.gz
tar --exclude=./input-source.tar.gz -czf "$dest" .
t=$(mktemp -d)
tar -xzf "$dest" -C "$t"
(cd "$t" && sha256sum -c PACKET-SHA256 > /dev/null && python3 replay.py > /dev/null && python3 fixed/replay.py > /dev/null)
sha256sum "$dest" "$D/verification.en-ko.md"