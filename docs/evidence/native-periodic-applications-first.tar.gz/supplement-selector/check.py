import hashlib,json,os,pathlib,subprocess,sys,tempfile
from pathlib import Path
S=Path(__file__).resolve().parent
D=S.parent
repo=Path.cwd()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='4a0c17a7025d663d90b67535ccc27b594277ec08'
elf=D/'elf/crc.elf'
digest=hashlib.sha256(elf.read_bytes()).hexdigest()
assert digest=='5099e3f8a9f9f05816838853f1c173429914efe8ed7cf333b0c9bd62d95f1528'
peer=str(D/'elf/histogram.elf')
cli=[('--policy rm --periodic 0,0,1','require u64 nanoseconds'),('--policy dm --periodic 0,5,0','require u64 nanoseconds'),('--policy dm --periodic 0,5,6','require u64 nanoseconds'),('--policy rm --periodic=-1,5,4','expected phase,period'),('--policy rm --periodic 0,5','expected phase,period'),('--policy rm --periodic 0,5,4,1','expected phase,period'),('--policy rm --periodic 18446744073709551616,5,4','require u64 nanoseconds'),('--policy rm --periodic 0,5,4 --periodic 0,5,4','--periodic may appear only once'),('--policy rm --periodic 0,5,4 --peer-periodic 0,5,4','one periodic tuple per supplied ELF'),('--policy rm --periodic 0,5,4 --peer-elf '+peer,'one periodic tuple per supplied ELF'),('--policy rm','one periodic tuple per supplied ELF'),('--policy rm --policy dm --periodic 0,5,4','--policy may appear only once'),('--policy rm --periodic 0,5,4 --priority 1','priorities require --policy fifo or rr'),('--policy rm --periodic 0,5,4 --weight 1','weights require --policy weighted'),('--policy dm --periodic 0,5,4 --quantum-ticks 2','--quantum-ticks is required exclusively'),('--policy rm --periodic 0,5,4 --job 0,8,2','job tuples require --policy edf'),('--policy edf --periodic 0,5,4','periodic tuples require --policy rm or dm')]
raw=[({'PERIODIC':'0,5,4;0,5,4'},'supply one periodic tuple per slot'),({'PERIODIC':'0,5,6'},'require 0 < relative deadline <= period'),({'PERIODIC':'bad,5,4'},'invalid scheduling tuple number'),({'PERIODIC':'0,5'},'native scheduling tuple requires three integers'),({'PERIODIC':'0,5,4,1'},'extra scheduling tuple fields'),({'PERIODIC':'18446744073709551616,5,4'},'scheduling tuple number exceeds u64'),({'PERIODIC':'0,5,4','EDF_JOBS':'0,8,2'},'job tuples require EDF'),({'PERIODIC':'0,5,4','WEIGHTS':'1'},'weights require weighted scheduling'),({'PERIODIC':'0,5,4','POLICY':'fifo'},'periodic tuples require RM or DM'),({},'RM and DM require periodic tuples')]
binary,=list(repo.glob('kernel/target/release/build/jnox-kernel-*/build-script-build'))
records=[]
with tempfile.TemporaryDirectory() as temp:
 for args,want in cli:
  argv=[sys.executable,'tools/build_native_el0.py','--elf',str(elf),'--out',temp+'/package',*args.split()]
  p=subprocess.run(argv,text=True,capture_output=True); err=p.stderr.splitlines()[-1]
  assert p.returncode==2 and want in err and not Path(temp+'/package').exists(),(args,err)
  records.append(dict(layer='CLI',args=argv,expected=want,actual=err,status=p.returncode))
 for fields,want in raw:
  env=dict(PATH=os.environ['PATH'],OUT_DIR=temp,JNOX_PROFILE='native',JNOX_APP='process',JNOX_BOARD='virt',JNOX_NATIVE_POLICY='rm',JNOX_NATIVE_ELF=str(elf),JNOX_NATIVE_ELF_SHA256=digest)
  env.update({'JNOX_NATIVE_'+k:v for k,v in fields.items()})
  p=subprocess.run([binary],env=env,cwd=repo/'kernel',capture_output=True,text=True)
  assert p.returncode!=0 and want in p.stderr,(fields,p.stderr)
  records.append(dict(layer='raw existing Cargo build script',env=env,expected=want,actual=p.stderr,status=p.returncode))
(S/'records.json').write_text(json.dumps(dict(elf_sha256=digest,raw_build_script_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),records=records),indent=2))
print(len(cli),len(raw))