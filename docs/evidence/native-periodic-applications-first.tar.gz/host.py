import json,pathlib,subprocess,sys
D=pathlib.Path(__file__).parent
for mode in ('rm','dm'):
 src=D/(mode+'-rta.json')
 src.write_text(json.dumps(dict(policy=mode,tasks=[dict(id='A',period=10,deadline=9,wcet=1),dict(id='B',period=12,deadline=4,wcet=1)])))
 r=subprocess.run([sys.executable,'tools/fp_response.py',str(src)],check=True,capture_output=True,text=True)
 (D/(mode+'-rta-result.json')).write_text(r.stdout)
invalid=['--policy rm --periodic 0,0,1','--policy dm --periodic 0,1,2','--policy rm --periodic -1,5,4','--policy rm --periodic 0,5,4 --periodic 0,5,4','--policy rm --peer-periodic 0,5,4','--policy rm --policy dm --periodic 0,5,4','--policy rm --periodic 0,5,4 --priority 1','--policy rm --periodic 0,5,4 --job 0,8,2','--policy rm --periodic 18446744073709551616,5,4','--policy edf --periodic 0,5,4','--policy rm']
with (D/'rejections.log').open('w') as f:
 for args in invalid:
  r=subprocess.run([sys.executable,'tools/build_native_el0.py','--out',str(D/'invalid-should-not-exist'),*args.split()],capture_output=True,text=True)
  print(args,r.returncode,r.stderr.splitlines()[-1],file=f)
  assert r.returncode==2 and not (D/'invalid-should-not-exist').exists()