set -euo pipefail
D=/mnt/d/codex/jnox301-independent-evidence
cd ~/jnox301-independent
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH" CARGO_BUILD_JOBS=1
test "$(git rev-parse HEAD)" = 4a0c17a7025d663d90b67535ccc27b594277ec08
git status --porcelain > "$D/source-status.txt"
mkdir -p "$D/elf" "$D/runs" ~/jnox301-pkgs
git archive HEAD | gzip > "$D/input-source.tar.gz"
{ date -u; git rev-parse HEAD; clang --version; rustc -Vv; cargo -V; qemu-system-aarch64 --version; } > "$D/toolchain.txt"
for app in crc crc_overrun yield_report sleep_backlog unsupported; do sh sdk/native-aarch64/build.sh examples/native-periodic-job/"$app".c "$D/elf/$app.elf"; done
sh sdk/native-aarch64/build-rust.sh examples/native-periodic-job-rust/Cargo.toml "$D/elf/histogram.elf"
for app in "$D"/elf/*.elf; do aarch64-linux-gnu-nm -nS "$app" > "$app.sym"; aarch64-linux-gnu-objdump -d "$app" > "$app.dis"; done
while read -r name policy specs; do
 args=(); if [[ $policy != default ]]; then args+=(--policy "$policy"); fi
 pre=--; mkdir -p "$D/elf/$name"
 for s in $specs; do args+=("${pre}elf" "$D/elf/${s%:*}.elf"); if [[ $policy != default ]]; then args+=("${pre}periodic" "${s#*:}"); fi; pre=--peer-; done
 python3 tools/build_native_el0.py --out "$HOME/jnox301-pkgs/$name" "${args[@]}" > "$D/elf/$name/package.log" 2>&1 || { cat "$D/elf/$name/package.log"; tail -60 "$HOME/jnox301-pkgs/$name/build.log"; exit 1; }
 cp "$HOME/jnox301-pkgs/$name/"{kernel.elf,manifest.json,build.log} "$D/elf/$name/"
done < "$D/cases"
sha256sum "$D/input-source.tar.gz" "$D"/elf/*.elf "$D"/elf/*/kernel.elf "$D"/{cases,first-run-protocol.md,capture.py,build.sh} > "$D/prelaunch.sha256"