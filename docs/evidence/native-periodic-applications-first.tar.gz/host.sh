set -eu
cd ~/jnox301-independent
export RUSTUP_TOOLCHAIN=1.95.0 RUSTUP_HOME=$HOME/jnox-169-first-e203caa/rustup PATH="$HOME/jnox-169-first-e203caa/cargo/bin:$PATH"
D=/mnt/d/codex/jnox301-independent-evidence
rustc --edition=2024 --test tools/scheduling_tests.rs -o ~/jnox301-policy-tests > "$D/host-build.log" 2>&1
~/jnox301-policy-tests --test-threads=1 > "$D/host-results.txt"
python3 "$D/host.py"
tail -3 "$D/host-results.txt"