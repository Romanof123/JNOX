#!/bin/bash
# Acquisition-owner transcription of the original invocation.
set -eu
rev=fcef15921d0d8cc3a0eb71e8b77273ba07990dc4
root=/mnt/d/codex/jnox426-lifecycle
for mode in ordinary failures assertion duplex; do
  label=441-combined-$mode-01
  bash "$root/build.sh" "$rev" "$label" "$mode"
  case $mode in
    ordinary) opt=();;
    failures) opt=(--failure-profile);;
    assertion) opt=(--assertion-profile);;
    duplex) opt=(--duplex-profile);;
  esac
  bash "$root/capture.sh" "$label" cold-01 "$rev" "${opt[@]}" --mutation-tests
done
