#!/usr/bin/env python3
"""Package the four completed native NIC profiles on one combined source revision."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import stat
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
from evidence_io import archive, copy, export, extract, git, read, regular, require, sha, write
from replay import BOARD, COMMIT, HEADERS_HASH, LINUX, MODES, PROFILE, observer_args

PM = Path(__file__).resolve().parent
LAB = Path.home() / "jnox406-lab"
KNOWN_SOURCE = {"arch/aarch64", "kernel", "boards", "examples/linux-source-net-duplex", "examples/linux-source-net-lifecycle", PROFILE}
BUILD_TOOLS = ["tools/build_linux_source_virtio_net.py", "tools/build_native_el0.py", "tools/build_kernel.py"]


def tool_closure(repo, rev, entrypoints):
    """Follow imports only among Python modules tracked under tools/ at this revision."""
    paths = {p for p in git(repo, "ls-tree", "-r", "--name-only", rev, "--", "tools").decode().splitlines()
             if re.fullmatch(r"tools/[A-Za-z_][A-Za-z_0-9]*\.py", p)}
    selected, pending = set(), list(entrypoints)
    while pending:
        path = pending.pop()
        if path in selected:
            continue
        require(path in paths, f"missing tracked Python tool {rev}:{path}")
        selected.add(path)
        code = git(repo, "show", f"{rev}:{path}")
        for node in ast.walk(ast.parse(code)):
            if isinstance(node, ast.Import):
                names = [n.name for n in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                names = [node.module]
            else:
                continue
            for name in names:
                dependency = "tools/" + name.split(".")[0] + ".py"
                if dependency in paths and dependency not in selected:
                    pending.append(dependency)
    return selected


def header_ledger(headers, dest):
    dest.mkdir(parents=True, exist_ok=True)
    if (dest / "tree.json").exists():
        return
    records = {}
    for root, dirs, files in os.walk(headers, followlinks=False):
        directory = Path(root)
        for name in dirs:
            require(stat.S_ISDIR((directory / name).lstat().st_mode), f"linked header directory {directory / name}")
        for name in files:
            file = directory / name
            require(stat.S_ISREG(file.lstat().st_mode), f"linked or irregular header {file}")
            records[file.relative_to(headers).as_posix()] = sha(file)
    whole = hashlib.sha256()
    for name, digest in sorted(records.items()):
        whole.update(name.encode() + b"\0" + bytes.fromhex(digest))
    require(len(records) == 9403 and whole.hexdigest() == HEADERS_HASH, "pinned compiler header tree differs")
    write(dest / "tree.json", records)


def add_build(stage, args, build, bid, mode):
    dest = stage / "builds" / bid
    m, imp = read(regular(build, "native/manifest.json")), read(regular(build, "imported/import.json"))
    require(m["tracked_changes"] == "" and imp["mode"] == MODES[mode]["intake"] and m["commit"] == COMMIT, "combined clean build profile")
    native = ["manifest.json", "kernel.elf", "user.elf", "native_peer.elf", "build.log"]
    for name in native:
        copy(regular(build, Path("native") / name), dest / "native" / name)
    copy(regular(build, "build.log"), dest / "build.log")
    objects = set(imp["input_sha256_by_object"]) | set(imp["objects"]) | {imp[k]["filename"] for k in ("callback_object","driver_object")}
    for name in objects | {"service.elf","peer.elf","service.map","peer.map","import.json"}:
        require(Path(name).name == name, f"unexpected intake filename {name}")
        copy(regular(build, Path("imported") / name), dest / "imported" / name)
    rev = m["commit"]
    require(re.fullmatch("[0-9a-f]{40}", rev) and imp["header_tree_sha256"] == HEADERS_HASH, "commit or header profile")
    headers = args.headers or Path(imp["header_root"])
    source = args.linux_source or Path(imp["source"]["path"])
    hdir = stage / "source/linux-headers" / HEADERS_HASH
    header_ledger(headers, hdir)
    for path, digest in imp["header_profile"]["generated_sha256"].items():
        copy(regular(headers, path), hdir / "files" / path, digest)
    tracked = KNOWN_SOURCE | tool_closure(args.repo, rev, BUILD_TOOLS)
    inputs = {}
    for name, digest in imp["input_sha256"].items():
        path = Path(name)
        require(".." not in path.parts, f"invalid compiler path {name}")
        if name.startswith("headers/"):
            rel = path.relative_to("headers")
            target = hdir / "files" / rel
            copy(regular(headers, rel), target, digest)
        elif name == imp["upstream"]["path"]:
            require(imp["upstream"]["commit"] == LINUX and name == "drivers/net/virtio_net.c", "upstream input")
            target = stage / "source/linux" / LINUX / name
            copy(source, target, digest)
        elif path.is_absolute():
            require(path.parent.name == "build" and path.suffix in (".h",".inc"), f"unrecognized generated input {name}")
            target = dest / "imported" / path.name
            copy(regular(build, Path("imported") / path.name), target, digest)
        else:
            tracked.add(name)
            target = stage / "source/jnox" / rev / path
        inputs[name] = target.relative_to(stage).as_posix()
    export(args.repo, rev, tracked, stage / "source/jnox" / rev)
    write(dest / "source-index.json", {"commit": rev, "compiler_inputs": inputs})
    return m


def package(stage,args):
    files=tool_closure(args.repo,COMMIT,["tools/"+m["verifier"]+".py" for m in MODES.values()])
    export(args.repo,COMMIT,files|{BOARD+"/board.json",BOARD+"/virt-net.dtb.gz"},stage/"observer")
    profiles,commands,table=[],[],[]
    for mode,cfg in MODES.items():
        build=args.lab/f"441-combined-{mode}-01"
        cap=build/"cold-01"
        require(cap.is_dir() and not cap.is_symlink() and not (cap/"failure.json").exists(),f"cold capture {cap}")
        require(regular(cap,"observer-commit.txt").read_text().strip()==COMMIT and
                {p.name for p in cap.iterdir() if p.is_dir()}==set(cfg["stages"]),f"{mode} frozen revision and stages")
        bid=sha(regular(build,"native/manifest.json"))
        add_build(stage,args,build,bid,mode)
        directory=stage/"profiles"/mode
        for file in sorted(cap.rglob("*")):
            require(not file.is_symlink(),f"linked capture member {file}")
            if not file.is_dir():
                rel=file.relative_to(cap)
                copy(regular(cap,rel),directory/"cold-01"/rel)
        observed_roots=[p for p in build.glob("observer.*") if p.is_dir() and (p/"output.log").is_file()
                        and sha(regular(p,"observer.sha256"))==sha(regular(cap,"observer.sha256"))]
        require(len(observed_roots)==1,f"expected a unique measured observer directory for {mode}")
        stdout=regular(observed_roots[0],"output.log")
        copy(stdout,directory/"capture-stdout.log")
        for name in (("qemu-after.txt",) if mode=="ordinary" else ("qemu-before.txt","qemu-process.txt","qemu-after.txt")):
            copy(regular(build,name),directory/"qemu-identity"/name)
        item={"mode":mode,"build":bid,"original_build_path":build.as_posix(),"stdout_origin":stdout.as_posix()}
        profiles.append(item)
        commands.append("PYTHONPATH=vendor "+shlex.join(["python3","-B",*observer_args(item,read(cap/"launch.json"))]))
        table.append(f"| {mode} | {len(cfg['stages'])} | {len(cfg['controls'])} | "+
                     ("After run. Observer also recorded launch binary SHA-256." if mode=="ordinary" else "Before, live process and after.")+" |")
    for p in (args.vendor/"elftools").rglob("*.py"):
        rel=p.relative_to(args.vendor)
        copy(regular(args.vendor,rel),stage/"vendor"/rel)
    regular(stage,"vendor/elftools/elf/elffile.py")
    for name in ("LICENSE","METADATA"):
        rel=Path("pyelftools-0.32.dist-info")/name
        copy(regular(args.vendor,rel),stage/"vendor"/rel)
    copy(args.license,stage/"source/GPL-2.0")
    for file in ("replay.py","evidence_io.py"):
        copy(PM/file,stage/file)
    copy(PM/"package_integrated.py",stage/"provenance/package_integrated.py")
    copy(args.build_script,stage/"provenance/build.sh")
    copy(args.capture_script,stage/"provenance/capture.sh")
    write(stage/"bundle.json",{"commit":COMMIT,"profiles":profiles})
    builder = ("set -eu\nrev="+COMMIT+"\nroot=/mnt/d/codex/jnox426-lifecycle\n"
               "for mode in ordinary failures assertion duplex; do\n  label=441-combined-$mode-01\n"
               "  bash \"$root/build.sh\" \"$rev\" \"$label\" \"$mode\"\n"
               "  case $mode in\n    ordinary) opt=();;\n    failures) opt=(--failure-profile);;\n"
               "    assertion) opt=(--assertion-profile);;\n    duplex) opt=(--duplex-profile);;\n  esac\n"
               "  bash \"$root/capture.sh\" \"$label\" cold-01 \"$rev\" \"${opt[@]}\" --mutation-tests\ndone\n")
    (stage/"provenance/combined-commands.sh").write_text("#!/bin/bash\n# Acquisition-owner transcription of the original invocation.\n"+builder)
    (stage/"README.md").write_text(
        "# Four native VirtIO-net profiles on one combined revision\n\n"
        f"Guest source and frozen primary observers were both built or exported at JNOX Git commit `{COMMIT}`. "
        "Four separate AArch64 virt/FIFO kernels each cold-booted their own driver and peer image. "
        "From a new extraction on Linux, run `python3 -B replay.py`. Python 3.10+, GNU nm and aarch64-linux-gnu-nm "
        "are required. Pyelftools 0.32 is bundled. This command verifies every archived file, decodes all four observed "
        "boots from their original RAM and traces, and compares all mutation verdicts to the original observer stdout.\n\n"
        "| Profile | Stopped checkpoints | Corruption controls | External QEMU executable measurement |\n|---|---:|---:|---|\n"+
        "\n".join(table)+"\n\n**Evidence boundaries.** One complete two-generation ordinary lifecycle, four controlled "
        "EL0 provider failures followed by clean recovery, one deliberate owner BRK with peer survival, and one "
        "full-duplex RX/TX lifecycle ran on the same source revision. These are four independent cold boots. "
        "Single-profile acceptance packages contain the separate independent reader results on their earlier captures. "
        "This archive reproduces the capture-time primary observer on the new integrated specimens.\n\n"
        "The profile directories retain the original capture stdout, streams, PCAP, UART, QEMU execution/IRQ/MMIO trace, "
        "QMP stops and sparse physical reads, including page tables used by the observers. Duplex checkpoints "
        "also retain QEMU trace byte offsets. The assertion capture retains its last scratch probe separately within "
        "the original capture directory. No hardware TLB tracing or physical-device measurement is claimed.\n\n"
        "Each launch.json carries the observed QEMU command line. For the three externally monitored boots, the process log "
        "records the live PID, executable target, SHA-256 via /proc/PID/exe, and the actual process argument list. "
        "The surrounding records contain executable path, version and SHA-256. Ordinary ran before the external process "
        "recorder started. Its launch digest and after-run record are checked separately. The source index under each "
        "build maps every compiler input to archived bytes. The original upstream Linux C file, actual header dependencies, "
        "complete pinned header hash ledger, linked maps, objects, native ELFs, import manifests, compiler version "
        "identities and command lines are included. The common source and headers are stored once.\n\n"
        "provenance/combined-commands.sh transcribes the acquisition owner's build and capture command. The retained "
        "profile stdout, build logs and launch records are original measurements. Individual offline observer commands follow.\n\n"
        "```sh\n"+"\n".join(commands)+"\n```\n",encoding="utf-8")
    members=sorted(p for p in stage.rglob("*") if p.is_file())
    (stage/"SHA256SUMS").write_text("".join(f"{sha(p)}  {p.relative_to(stage).as_posix()}\n" for p in members))


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--lab",type=Path,default=LAB)
    cli.add_argument("--repo",type=Path,default=LAB/"src")
    cli.add_argument("--linux-source",type=Path)
    cli.add_argument("--headers",type=Path)
    cli.add_argument("--vendor",type=Path,default=PM.parent/"jnox332-release-deps")
    cli.add_argument("--license",type=Path,default=PM.parent/"jnox424-pm/GPL-2.0")
    cli.add_argument("--build-script",type=Path,default=PM.parent/"jnox426-lifecycle/build.sh")
    cli.add_argument("--capture-script",type=Path,default=PM.parent/"jnox426-lifecycle/capture.sh")
    cli.add_argument("--output",type=Path,required=True)
    args=cli.parse_args()
    output=args.output.absolute()
    require(not output.exists(),f"output exists {output}")
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="jnox-integrated-") as tmp, tempfile.TemporaryDirectory(
            prefix=".jnox-integrated-",dir=output.parent) as pubroot:
        work,pub=Path(tmp),Path(pubroot)/"release"
        stage=work/"bundle"
        stage.mkdir()
        pub.mkdir()
        package(stage,args)
        tar=pub/"integrated.tar.xz"
        archive(stage,tar)
        fresh=work/"extracted"
        extract(tar,fresh)
        result=json.loads(subprocess.check_output([sys.executable,"-B","replay.py"],cwd=fresh))
        write(pub/"result.json",result)
        copy(fresh/"README.md",pub/"README.md")
        digest=sha(tar)
        (pub/(tar.name+".sha256")).write_text(f"{digest}  {tar.name}\n")
        require(not output.exists(),f"output appeared during packaging {output}")
        pub.rename(output)
        print(f"{digest}  {output/tar.name}")


if __name__=="__main__":
    main()
