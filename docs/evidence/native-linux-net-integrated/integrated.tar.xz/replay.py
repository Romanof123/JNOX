#!/usr/bin/env python3
"""Replay four native NIC profiles from the same combined Git revision."""
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
from datetime import datetime
import subprocess
import sys

sys.dont_write_bytecode = True
from evidence_io import checksums, read, regular, require, sha

COMMIT = "fcef15921d0d8cc3a0eb71e8b77273ba07990dc4"
BOARD = "docs/evidence/native-linux-net-irq-board"
PROFILE = "drivers/linux-compat/profiles/virtio-net.json"
MODES = {
    "ordinary":{"verifier":"verify_linux_source_net_lifecycle","intake":"lifecycle-service","flag":"--linux-source-net-lifecycle",
        "stages":["first-probed","first-open","first-ack","first-removed","second-probed","second-open","second-ack","final"],
        "controls":{"live original ndo_open pointer","registered netdevice identity","missing first original probe entry","second-generation private RX payload"}},
    "failures":{"verifier":"verify_linux_source_net_lifecycle_failures","intake":"lifecycle-failure-service","flag":"--linux-source-net-lifecycle-failures",
        "stages":[f"case-{i}-{s}" for i in range(1,5) for s in ("armed","failed","retired")]+["recovery-ready","recovery-ack","final"],
        "controls":{"absent register failure","unremoved hotplug instance","false DOWN registration","corrupted peer nonce"}},
    "assertion":{"verifier":"verify_linux_source_net_assertion","intake":"lifecycle-service","flag":"--linux-source-net-lifecycle",
        "stages":["armed","final"],"controls":{"wrong ELR","wrong TTBR ASID","wrong syndrome","peer falsely trapped",
        "terminal decision at wrong tick","ordinary scheduler reason","wrong surviving PID","false peer decision",
        "removed live DMA authority","no survivor timer progress","cooperative exit","missing second QueueReady readback"}},
    "duplex":{"verifier":"verify_linux_source_net_duplex","intake":"lifecycle-duplex-service","flag":"--linux-source-net-duplex",
        "stages":["ready","held","overlap","completed","ack","final"],"controls":{"pcap","used","peer","grant"}}
}
LINUX = "4700e3adf3b24b39dd4929e9c6d62811ba3ccea8"
LINUX_HASH = "05e676f7fc4f91783c961c860b930fae33462348064887eea95be3a440282a29"
HEADERS_HASH = "901bb6ced9321e225b59395161f80a66146e3beaa9252f94c6430f545c84806b"


def git_identity(file, kind, oid):
    data = file.read_bytes()
    require(hashlib.sha1(f"{kind} {len(data)}\0".encode() + data).hexdigest() == oid, f"Git {kind} identity {file}")


def build_evidence(root, name, mode):
    base = root / "builds" / name
    native, imported = base / "native", base / "imported"
    pkg, imp = read(native / "manifest.json"), read(imported / "import.json")
    rev = pkg["commit"]
    require(re.fullmatch("[0-9a-f]{40}", rev) and sha(native / "manifest.json") == name and
            (pkg["tracked_changes"], pkg["board"], pkg["app"], pkg["policy"]) == ("", "virt", "process", "fifo") and
            imp["mode"] == MODES[mode]["intake"] and rev == COMMIT and len(pkg["slots"]) == 2,
            "native lifecycle build")
    require((mode=="assertion") == ("lifecycle_assert_test" in imp) and
            (mode=="failures") == ("linux_source_net_lifecycle_failures" in pkg) and
            (mode=="duplex") == ("linux_source_net_duplex" in pkg), "profile-only selection")
    sources = root / "source/jnox" / rev
    git_identity(sources / "commit.raw", "commit", rev)
    require(sha(native / "kernel.elf") == pkg["kernel_elf_sha256"] and
            sha(native / "build.log") == pkg["build_log_sha256"], "kernel digest or build log")
    kernel = (native / "kernel.elf").read_bytes()
    argv = pkg["package_argv"]
    require(MODES[mode]["flag"] in argv and
            [argv[i+1] for i,k in enumerate(argv) if k in ("--elf","--peer-elf")] ==
            [s["input"]["path"] for s in pkg["slots"]], "selected ELF arguments")
    directory = "examples/linux-source-net-" + ("duplex" if mode == "duplex" else "lifecycle")
    driver_source = directory + ("/failure_driver.c" if mode == "failures" else "/driver.c")
    roles = []
    peer = imp["irq_peer"]
    spec = importlib.util.spec_from_file_location("linked_native_roots", regular(sources, "tools/native_amc_roots.py"))
    roots_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(roots_module)
    roots = roots_module.linked_roots(native / "kernel.elf", len(pkg["slots"]))
    for slot, (s, role, src, elf, digest, map_hash) in enumerate(zip(pkg["slots"], ("driver","peer"),
            (driver_source, peer["source"]), ("service.elf","peer.elf"),
            (imp["service"]["sha256"], peer["elf"]["sha256"]), (imp["link_map_sha256"],peer["link_map_sha256"]))):
        app = regular(native, s["elf"])
        obj = ("driver.o","irq_peer.o")[slot]
        require((s["slot"],s["argv"],s["priority"]) == (slot,["/bin/app"],8) and src in imp["input_sha256_by_object"][obj],
                f"{role} slot or source")
        require(sha(app) == sha(imported / elf) == s["input"]["sha256"] == s["elf_sha256"] == digest ==
                pkg["source_sha256"][s["input"]["path"]] and app.read_bytes() in kernel and
                sha(imported / Path(elf).with_suffix(".map")) == map_hash, f"{role} link or embedded ELF")
        require(s.get("expected_ttbr0_el1", roots[slot]) == roots[slot], f"{role} linked address-space root")
        roles.append({"role": role, "slot": slot, "sha256": digest, "source": src,
                      "linked_ttbr0_el1": hex(roots[slot]), "map_sha256": map_hash})
    require(roles[0]["linked_ttbr0_el1"] != roles[1]["linked_ttbr0_el1"], "two distinct slot roots")
    for filename, item in imp["objects"].items():
        require(sha(regular(imported, filename)) == item["sha256"], f"object {filename}")
    for key in ("driver_object", "callback_object"):
        item = imp[key]
        require(sha(regular(imported, item["filename"])) == item["sha256"], key)
    for name in imp["input_sha256_by_object"]:
        regular(imported, name)
    index = read(base / "source-index.json")
    files = index["compiler_inputs"]
    require(set(files) == set(imp["input_sha256"]) and sha(sources / PROFILE) == imp["profile_sha256"],
            "compiler file inventory or import profile")
    profile = read(sources / PROFILE)
    require(profile["upstream"] == imp["upstream"] and profile["headers"] == imp["header_profile"], "intake source profile")
    upstream = imp["upstream"]
    require(upstream["commit"] == LINUX and upstream["sha256"] == imp["source"]["sha256"] == LINUX_HASH and
            upstream["path"] == "drivers/net/virtio_net.c", "pinned original Linux source")
    git_identity(regular(root, files[upstream["path"]]), "blob", upstream["git_blob_sha1"])
    header_root = root / "source/linux-headers" / HEADERS_HASH
    ledger = read(header_root / "tree.json")
    whole = hashlib.sha256()
    for path, digest in sorted(ledger.items()):
        whole.update(path.encode() + b"\0" + bytes.fromhex(digest))
    require(len(ledger) == 9403 and whole.hexdigest() == imp["header_tree_sha256"] == HEADERS_HASH, "header tree identity")
    for path, digest in profile["headers"]["generated_sha256"].items():
        require(ledger[path] == digest == sha(regular(header_root / "files", path)), f"generated header {path}")
    for path, target in files.items():
        digest = imp["input_sha256"][path]
        require(sha(regular(root, target)) == digest, f"compiler input {path}")
        if path.startswith("headers/"):
            require(ledger[path[8:]] == digest, f"header provenance {path}")
    for path, digest in pkg["kernel_build"]["config_sha256"].items():
        require(sha(regular(sources, path)) == digest, f"kernel configuration {path}")
    return {"source_commit": rev, "linux_commit": LINUX, "linux_tu_sha256": LINUX_HASH,
            "header_tree_sha256": HEADERS_HASH, "compiler_input_count": len(files), "roles": roles,
            "import_sha256": sha(imported / "import.json"), "kernel_sha256": pkg["kernel_elf_sha256"],
            "objects": {n:sha(imported / n) for n in ("virtio_net.original.o","virtio_net.packet.o","virtio_net.callback.o")}}


def python(root, args, **opts):
    env = dict(os.environ, LC_ALL="C", PYTHONPATH=str(root / "vendor"),
               PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1")
    env.pop("PYTHONOPTIMIZE", None)
    return subprocess.check_output([sys.executable, "-B", *args], cwd=root, env=env, **opts)


def observer_args(item,launch):
    mode,bid=item["mode"],item["build"]
    return ["observer/tools/"+MODES[mode]["verifier"]+".py","--replay","--mutation-tests",
            "--package","builds/"+bid+"/native","--driver-manifest","builds/"+bid+"/imported/import.json",
            "--out","profiles/"+mode+"/cold-01","--mac",launch["mac"],"--mtu",str(launch["mtu"])]


def qemu_identity(directory,mode,launch,board):
    launch_path=launch["argv"][0]
    digest=board["qemu_sha256"]
    def timestamp(text):
        match=re.fullmatch(r"(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d),(\d{9})\+00:00",text)
        require(match is not None,"UTC nanosecond timestamp")
        datetime.fromisoformat(match[1]+"+00:00")
        return match[1]+"."+match[2]+"+00:00"
    def disk(name):
        lines=(directory/name).read_text().splitlines()
        stamp=timestamp(lines[0])
        require(lines[1:3]==[launch_path,launch_path] and lines[3]==f"{digest}  {launch_path}" and
                lines[4]==board["qemu_version"],f"{mode} {name} sampled executable")
        return stamp
    after=disk("qemu-after.txt")
    emitted=launch.get("qemu_sha256")
    require(emitted is None or emitted==digest,"capture observer reported QEMU digest")
    result={"qemu_path":launch_path,"qemu_version":board["qemu_version"],"measured_sha256":digest,
            "after":after,"launch_embedded_sha256":emitted}
    if mode=="ordinary":
        require({p.name for p in directory.iterdir()}=={"qemu-after.txt"},"ordinary observer coverage")
        result["external_record_scope"]="after only"
        return result
    require({p.name for p in directory.iterdir()}=={"qemu-before.txt","qemu-process.txt","qemu-after.txt"},"external record scope")
    before=disk("qemu-before.txt")
    lines=(directory/"qemu-process.txt").read_text().splitlines()
    stamp=timestamp(lines[0])
    pid,exe=lines[1].split(" ",1)
    require(len(lines)==4 and pid.isdigit() and exe==launch_path and lines[2]==f"{digest}  /proc/{pid}/exe" and
            before<=stamp<=after and shlex.split(lines[3])==launch["argv"],"live QEMU executable identity, order or proc argv")
    if "pid" in launch:
        require(launch["pid"]==int(pid),"observer PID differs from live proc")
    result.update(external_record_scope="before, live /proc/PID/exe and after",before=before,
                  live_at=stamp,live_pid=int(pid),live_exe=exe)
    return result


def replay(root):
    members=checksums(root)
    spec=read(root/"bundle.json")
    require(spec["commit"]==COMMIT and [c["mode"] for c in spec["profiles"]]==list(MODES),"integrated profile inventory")
    obs=root/"observer"
    git_identity(obs/"commit.raw","commit",COMMIT)
    board=read(obs/BOARD/"board.json")
    require(hashlib.sha256(gzip.decompress((obs/BOARD/"virt-net.dtb.gz").read_bytes())).hexdigest()==board["sha256"],
            "pinned observer board record")
    results={}
    for item in spec["profiles"]:
        mode,bid=item["mode"],item["build"]
        require(re.fullmatch("[0-9a-f]{64}",bid),"manifest digest")
        cfg=MODES[mode]
        directory=root/"profiles"/mode
        cap=directory/"cold-01"
        identity=build_evidence(root,bid,mode)
        launch=read(cap/"launch.json")
        require((cap/"observer-commit.txt").read_text().strip()==COMMIT and
                identity["kernel_sha256"]==launch["kernel_sha256"] and identity["import_sha256"]==launch["import_sha256"]
                and ("driver_sha256" not in launch or identity["roles"][0]["sha256"]==launch["driver_sha256"]),
                f"{mode} launch and embedded images")
        module_hashes={}
        for row in (cap/"observer.sha256").read_text().splitlines():
            digest,path=row.split("  ",1)
            require(path not in module_hashes,"duplicate captured module")
            module_hashes[path]=digest
        for path in (obs/"tools").glob("*.py"):
            require(sha(path)==module_hashes["tools/"+path.name],f"{mode} at-capture helper {path.name}")
        stages=cfg["stages"]
        require({p.name for p in cap.iterdir() if p.is_dir()}==set(stages),"captured stage set")
        for name in stages:
            require({p.name for p in (cap/name).iterdir()}==({"qmp.json","halted.json","ram.json"} |
                    ({"trace.json"} if mode=="duplex" else set())),"checkpoint files")
        binary=qemu_identity(directory/"qemu-identity",mode,launch,board)
        argv=observer_args(item,launch)
        live=json.loads(python(root,argv))
        baseline=read(directory/"capture-stdout.log")
        require(live==baseline,f"{mode}: detached replay differs from original observer stdout")
        if (cap/"result.json").is_file():
            require(live==read(cap/"result.json"),f"{mode}: original captured result differs")
        mutations=live["rejected"] if mode=="duplex" else live["rejected_mutations"]
        require(set(mutations)==cfg["controls"] and len(mutations)==len(set(mutations)),f"incomplete {mode} controls")
        if mode=="ordinary":
            require(live["checkpoints"]==stages and live["peer_frames"]==83 and live["tokens"]==[1,2],"ordinary lifecycle scope")
        elif mode=="failures":
            require([r["case"] for r in live["injected"]]==[1,2,3,4] and all(r["errno"]==-12 for r in live["injected"]) and
                    live["recovery_frames"]==2,"four bounded failures and recovery")
        elif mode=="assertion":
            require(live["protected_fifo_decision"]==[live["tick"],256,0,1,(1<<64)-5,int(live["elr"],16)]
                    and int(live["esr"],16)==0xf2000440 and live["peer_elapsed_ns"]>=100000000,"EL0 owner containment")
        else:
            require((live["incoming_frames"],live["reply_frames"],live["original_entries"]["start_xmit"])==(81,80,80),
                    "duplex scope")
        results[mode]={"build":identity,"capture_observer_commit":COMMIT,"original_build_path":item["original_build_path"],
                      "capture_stdout_origin":item["stdout_origin"],"original_stdout_sha256":sha(directory/"capture-stdout.log"),
                      "original_launch_argv":launch["argv"],"qemu_identity":binary,"board_dtb_sha256":board["sha256"],
                      "raw_capture_sha256":{p.relative_to(cap).as_posix():sha(p) for p in sorted(cap.rglob("*")) if p.is_file()},
                      "checkpoints":stages,"replay_argv":["python3","-B",*argv],"result":live,"mutation_count":len(mutations)}
    return {"source_commit":COMMIT,"checksummed_members":members,"combined_primary_replays":results,
            "total_mutation_rejections":sum(s["mutation_count"] for s in results.values()),
            "verification_scope":"Four cold boots of one combined source revision, with capture-time primary observers replayed on extracted raw evidence."}


if __name__=="__main__":
    print(json.dumps(replay(Path(__file__).resolve().parent),indent=2))
