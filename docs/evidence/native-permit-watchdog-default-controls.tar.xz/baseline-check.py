from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1])
for r in sorted((root/"runs").iterdir()):
    cap=r/"cap"
    m=json.loads((r/"manifest.json").read_text())
    assert 'safety_watchdog' not in m and 'safety_qualification' not in m and m['policy']==r.name
    launch=json.loads((cap/'launch.json').read_text());assert m==launch['argument_package']
    for f,digest in json.loads((cap/'session.json').read_text())['hashes'].items():
        assert hashlib.sha256((cap/f).read_bytes()).hexdigest()==digest
    s=(cap/'uart.bin').read_text().splitlines()
    ev=[[int(v) for v in l.split()[3:]] for l in s if l.startswith('NATIVE SAFETY EVENT ')]
    assert ((r/'status').read_text().strip()=='0' and 'NATIVE SAFETY DROPPED 0' in s and
            [l.split()[4:] for l in s if l.startswith('NATIVE EL0 EXIT PID ')]==[['0','71'],['1','72'],['2','73']])
    assert ev and not any(e[0]==13 for e in ev)
    states=[e[5] for e in ev if e[0]==2];assert states==[1,0],states
    assert not any(l.startswith('NATIVE QUAL') for l in s)
    assert [x['priority'] for x in m['slots']]==[7,6,4]
    assert all(hashlib.sha256((root/'apps'/(name+'.elf')).read_bytes()).hexdigest()==m['slots'][pid]['elf_sha256'] for pid,name in enumerate(['sender','receiver','supervisor']))
    print(r.name,'exits 71/72/73, no watchdog events, output',states)
