#!/usr/bin/env bash
set -euo pipefail
rev=$1
lab="$HOME/permit402-$rev"; src="$lab/src"; out="$lab/unmonitored"
cd "$src"; exec 9>"$lab/lane.lock"; flock -n 9
test ! -e "$out"; mkdir -p "$out"/{apps,packages,runs}
export PATH="$HOME/.cargo/bin:$PATH" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true PYTHONDONTWRITEBYTECODE=1 LC_ALL=C TZ=UTC
for var in $(compgen -e JNOX_); do unset "$var"; done
test "$(git rev-parse HEAD)" = "$rev"; test -z "$(git status --short --untracked-files=no)"
for role in sender receiver supervisor; do sh sdk/native-aarch64/build-rust.sh "examples/native-safety-channel/$role/Cargo.toml" "$out/apps/$role.elf" >"$out/$role.build" 2>&1; done
for policy in fifo rr; do
 pkg="$out/packages/$policy"; dest="$out/runs/$policy"; mkdir "$dest"
 quantum=(); if [[ $policy = rr ]]; then quantum=(--quantum-ticks 625000); fi
 (set -x; python3 tools/build_native_el0.py --board virt --policy "$policy" "${quantum[@]}" --out "$pkg" --elf "$out/apps/sender.elf" --peer-elf "$out/apps/receiver.elf" --peer-elf "$out/apps/supervisor.elf" --arg healthy --peer-arg healthy --peer2-arg healthy --priority 7 --peer-priority 6 --peer-priority 4 --ipc-route 2:0 --ipc-route 2:1 --loan-route 0:1 --safety-channel) >"$dest/build.log" 2>&1
 cp "$pkg/manifest.json" "$dest/manifest.json"
 date -u +%FT%T.%NZ >"$dest/start.utc"; rc=0
 (set -x; python3 tools/native_el0_capture.py "$dest/cap" "$pkg/kernel.elf" "$out/apps/sender.elf" examples/native-safety-channel/sender/src/main.rs "$rev" --manifest "$pkg/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608) >"$dest/capture.log" 2>&1 || rc=$?
 date -u +%FT%T.%NZ >"$dest/finish.utc"; echo "$rc" >"$dest/status"
 echo "$policy $rc"
done
