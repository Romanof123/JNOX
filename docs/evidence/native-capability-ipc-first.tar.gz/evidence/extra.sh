set -eux
out=$PWD/evidence
rev=912f3ec7b1d763d2ebd7e93dfddae4e084b64772
for t in time-origin time-target stock; do sh sdk/native-aarch64/build.sh "$out/$t.c" "$out/$t.elf"; done
for policy in fifo rr; do
  opt=(); if [ "$policy" = rr ]; then opt=(--quantum-ticks 625000); fi
  pkg="$out/deadline-$policy"
  python3 tools/build_native_el0.py --out "$pkg" --elf "$out/time-origin.elf" --peer-elf "$out/time-target.elf" --policy "$policy" "${opt[@]}" --priority 7 --peer-priority 2 --ipc-route 0:1 --cap-grant 0:1:3 --cap-route 0:1
  python3 tools/native_el0_capture.py "$out/cap-deadline-$policy" "$pkg/kernel.elf" "$out/time-origin.elf" "$out/time-origin.c" "$rev" --plain --manifest "$pkg/manifest.json" --expect-exit 71 --timeout 8 || true
done
python3 tools/build_native_el0.py --out "$out/stock" --elf "$out/stock.elf"
python3 tools/native_el0_capture.py "$out/cap-stock" "$out/stock/kernel.elf" "$out/stock.elf" "$out/stock.c" "$rev" --manifest "$out/stock/manifest.json" --plain --expect-exit 71
rustc --test kernel/src/capability_ipc.rs --edition=2024 -o "$out/core-tests"
"$out/core-tests"
rustc --test kernel/src/mailbox_ipc.rs --edition=2024 --crate-type lib -o "$out/mail-tests"
"$out/mail-tests"
