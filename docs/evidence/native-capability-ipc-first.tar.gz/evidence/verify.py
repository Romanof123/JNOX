from pathlib import Path
import hashlib,json,re,struct,subprocess
p=Path(__file__).resolve().parent
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def symbols(f):
    return {s[3]:(int(s[0],16),int(s[1],16)) for line in subprocess.check_output(["nm","-S",str(f)],text=True).splitlines() if len(s:=line.split())==4}
def signed(x):return x if x<2**63 else x-2**64
results={}
cases=dict(transfer=list(range(1,7)),before=[7],pending=[],active=[8],target=[],mailbox=list(range(9,14)))
for cap in sorted(p.glob("cap-*")):
    name=cap.name[4:]
    session=json.loads((cap/"session.json").read_text())
    assert session["marker"]=="EXIT 71"
    for f,h in session["hashes"].items():assert sha(cap/f)==h
    manifest=json.loads((p/name/"manifest.json").read_text())
    assert manifest["commit"]=="912f3ec7b1d763d2ebd7e93dfddae4e084b64772" and not manifest["tracked_changes"]
    uart=(cap/"uart.bin").read_text()
    if name=="stock":
        assert "NATIVE EL0 EXIT 71" in uart
        results[name]={"exit":71}
        continue
    case,policy=name.split("-")
    apps=["time-origin","time-target"] if case=="deadline" else ["origin","receiver","target"]
    n=len(apps)
    assert re.findall(r"NATIVE EL0 (?:PEER2? )?ELF ([0-9a-f]{64})",uart)==[sha(p/(a+".elf")) for a in apps]
    assert list(map(int,re.findall(r"NATIVE EL0 EXIT PID \d+ (\d+)",uart)))==list(range(71,71+n))
    assert manifest["mailbox_routes"]==[]
    ram=(cap/"ram.bin").read_bytes()
    base=json.loads((cap/"launch.json").read_text())["ram_base"]
    def word(pa):
        assert base<=pa<=base+len(ram)-8
        return struct.unpack_from("<Q",ram,pa-base)[0]
    spaces,= [v for k,v in symbols(cap/"kernel.elf").items() if "native_el0_mmu6SPACES" in k]
    roots=[spaces[0]+i*(spaces[1]//n) for i in range(n)]
    data={}
    for root,app in zip(roots,apps):
        for sym,(addr,size) in symbols(p/(app+".elf")).items():
            if not sym.startswith(("cap_origin_","cap_receiver_","cap_target_","times_result","time_words")):continue
            values=[]
            for va in range(addr,addr+size,8):
                table=root
                for shift in [30,21,12]:
                    desc=word(table+8*((va>>shift)&511));assert desc&3==3
                    table=desc&0xfffffffff000
                values.append(word(table+(va%4096)))
            data[sym]=values
    states=[list(map(int,l.split()[3:])) for l in uart.splitlines() if l.startswith("NATIVE CAP STATE")]
    assert len(states)==2*n and all(r[2:5]==[0,0,0] and r[7]==0 for r in states[n:])
    assert states[0][2:5]==[1,1,0] and states[n-1][7]==1
    events=[list(map(int,l.split()[3:])) for l in uart.splitlines() if l.startswith("NATIVE FIXED EVENT")]
    assert "NATIVE FIXED DROPPED 0" in uart and all(a[0]<=b[0] for a,b in zip(events,events[1:]))
    if case=="deadline":
        t=list(map(signed,data["times_result"]))
        assert t[1:4]==[-11,-110,-110] and t[4]-t[0]>=100000000 and t[5]==0
        assert data["time_words"]==list(range(101,106))
        assert any(e[1]==56 and e[3:5]==[0,1] for e in events)
    else:
        assert data["cap_origin_result"]==[71]
        for role,field,width in [("origin","log",3),("origin","counts",5),("receiver","log",3),("receiver","counts",5),("receiver","notices",5),("target","words",1),("target","empty",1)]:
            prefix="cap_"+role+"_"
            raw=data[prefix+field]
            used=data[prefix+"n"+field][0]
            assert used*width<=len(raw)
            rows=[raw[i*width:(i+1)*width] for i in range(used)]
            if field=="log":
                for r in rows:r[1]=signed(r[1])
            data[prefix+field]=[signed(r[0]) for r in rows] if field=="empty" else [r[0] for r in rows] if width==1 else rows
        assert data["cap_target_words"]==[0xcafe000000000000|(i<<32)|(0x301+11*i) for i in cases[case]]
        assert all(v==-11 for v in data["cap_target_empty"])
        if case=="transfer":
            assert data["cap_receiver_notices"]==[[0xe910000000000000+i,h,0,2,r] for i,(h,r) in enumerate(zip([20,21,22,23,36],[1,2,1,1,3]))]
            assert [r[1:3] for r in data["cap_receiver_counts"]]==[[2,2],[2,0],[4,2],[4,0],[4,0],[3,0],[4,1],[0,0]]
            origin={r[0]:r for r in data["cap_origin_log"]}
            assert [origin[i][1] for i in (30,31,32,33,34,35,36,37,38,39)]==[-11,-24,0,-116,-116,-116,0,-11,-13,0]
            assert origin[36][2]==32
    results[name]={"events":len(events),"first_tick":events[0][0],"last_tick":events[-1][0],"roots":roots,"states":states,"data":data}
assert len(results)==15
print(json.dumps(results,indent=2))
