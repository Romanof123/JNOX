# JNOX #386 compact evidence / 경량 증거 패키지

All 15 original guest captures, eight host-test results, ELFs, UART, RAM, command logs and observation records are preserved byte-for-byte. The only omitted member is the redundant frozen-source.tar.gz. ORIGINAL-SHA256SUMS retains its SHA and the original inventory. Original archive SHA-256 is 6bf4f230f697378be7a08e0f4b9396ef567c833d4c90418c5c50c4204dbd897f.

원본의 게스트 15회와 호스트 시험 8개 결과, ELF, UART, RAM, 명령 로그 및 관측 기록의 해시가 모두 일치한다. 중복 원본 소스 압축본 하나만 제외했으며 원래의 전체 해시 목록도 보존했다.

Frozen local revision 912f3ec7b1d763d2ebd7e93dfddae4e084b64772. Public source revision e75addbccc80e98bf0a98d975ef6dded3d450a22. Shared tree 471c00c0ca7ce1c09952b7b97585a027eff145b2.

From the extracted packet / 압축 해제 후 오프라인 재검증

    sha256sum --quiet -c SHA256SUMS
    python3 evidence/verify.py > replay.json
    cmp replay.json evidence/observations.json

The detailed bilingual report is evidence/REPORT.md. / 상세 검증 결과는 evidence/REPORT.md에 있다.
