from pathlib import Path as P
import json,subprocess as sp,os,hashlib,shutil,tarfile,shlex
B=P.home()/'permit389-profiles-first-f48c41a'; S=B/'shipping'; W=B/'shipping-result'; W.mkdir()
D=P('/mnt/d/codex/kernel393-shipping-first-a8037d2');D.mkdir(exist_ok=True)
env=dict(os.environ,PATH=str(P.home()/'.cargo/bin')+':'+os.environ['PATH']);os.chdir(S)
def run(cmd,log,e=env,expected=0):
    with log.open('w') as f:
        print(shlex.join(map(str,cmd)),file=f,flush=True);rc=sp.run(cmd,stdout=f,stderr=sp.STDOUT,env=e).returncode
    assert rc==expected,(rc,cmd)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
rev=sp.check_output(['git','rev-parse','HEAD'],text=True).strip()
tree=sp.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()
assert tree=='db16b7313ad2c263e71d1061fe173bba1bcab3e2' and rev.startswith('a8037d2')
res={}
for p in ('default','release','speed'):
    target=W/'target'/p; opt=[] if p=='default' else ['--kernel-profile',p];real='release' if p=='default' else p
    run(['python3','tools/build_kernel.py','--arch','aarch64',*opt],W/(p+'.direct.log'),dict(env,CARGO_TARGET_DIR=str(target)))
    image=target/'aarch64-unknown-none'/real/'jnox-kernel'
    pkg=W/p;run(['python3','tools/build_native_el0.py','--board','virt','--out',str(pkg),*opt],W/(p+'.package.log'))
    m=json.loads((pkg/'manifest.json').read_text());k=m['kernel_build'];assert k['cargo_profile']==real and m['tracked_changes']=='' and k['profile_environment']=={}
    assert m['kernel_elf_sha256']==sha(pkg/'kernel.elf')==sha(pkg/k['artifact'])
    cap=W/(p+'-cap')
    run(['python3','tools/native_el0_capture.py',str(cap),str(pkg/'kernel.elf'),str(pkg/'user.elf'),'examples/portability/native_startup_probe.c',rev,'--plain','--expect-exit','37'],W/(p+'.capture.log'))
    lines=(cap/'uart.bin').read_text().splitlines();assert lines==['JNOX M1 BOOT','JNOX M1 READY','NATIVE EL0 ELF '+m['user_elf_sha256'],'NATIVE EL0 EXIT 37']
    res[p]=dict(direct=sha(image),manifest_kernel=sha(pkg/'kernel.elf'),user=sha(pkg/'user.elf'),uart=lines,build=k,rust=m['rust'],cargo=m['cargo'])
for i,args in enumerate((['tools/build_kernel.py','--arch','invalid'],['tools/build_kernel.py','--kernel-profile','invalid'],['tools/build_native_el0.py','--out',str(W/'invalid'),'--kernel-profile','invalid'])):
    run(['python3',*args],W/f'reject-{i}.log',expected=2)
assert res['default']['direct']==res['release']['direct']!=res['speed']['direct']
assert res['default']['manifest_kernel']==res['release']['manifest_kernel']!=res['speed']['manifest_kernel']
assert len({r['user'] for r in res.values()})==1
(W/'verification.json').write_text(json.dumps(dict(rev=rev,tree=tree,results=res),indent=2))
(W/'RECEIPT.en-ko.md').write_text('# Kernel profile shipping verification / 커널 빌드 프로파일 검증\n\nLocal '+rev+', tree '+tree+'. Default, explicit release and speed passed direct and ordinary native package builds. Each package artifact matched its profile path and exited 37 with the four expected UART lines in a cold single-core Cortex-A72 QEMU guest. Default and explicit release kernels were byte-identical. Speed differed and all three user ELFs matched. Three invalid selections returned status 2. No permit workload ran on this tree.\n\n기본값·명시적 release·speed 각각 독립 빌드와 일반 네이티브 부팅을 통과했다. 세 경우 모두 예상 UART 네 줄과 종료값 37을 기록했다. 기본값과 release 커널 해시는 같고 speed 커널 해시는 달랐다. 앱 ELF 세 개는 동일했다. 지원하지 않는 선택 세 가지는 종료값 2로 거부됐다.\n')
with tarfile.open(D/'replay.tgz','w:gz') as t:
    for f in W.rglob('*'):
        rel=f.relative_to(W)
        if f.is_file() and 'target' not in rel.parts:t.add(f,arcname=rel)
    t.add(__file__,arcname='verify.py')
for f in ('verification.json','RECEIPT.en-ko.md'):shutil.copy(W/f,D/f)
shutil.copy(D/'replay.tgz',W/'replay.tgz')
