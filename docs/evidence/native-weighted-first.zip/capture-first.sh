#!/bin/bash
set -u
cd "$(dirname "$0")"
base="$(pwd)"
tc=/home/ywcho/jnox-169-first-e203caa
export PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$tc/deps"
cd src
for arm in share wake; do
  test -f "$base/build-$arm/manifest.json" || continue
  for clock in default icount3; do
    case_dir="$base/evidence/$arm-$clock"
    python3 tools/native_weighted_capture.py "$arm" "$clock" "$case_dir" "$base/build-$arm/kernel.elf" "$base/build-$arm/user.elf" examples/portability/native_weighted_monitor.c 56d6e0b7cb7183fdc1b9b06275050ce64254e6f6 > "$case_dir.capture" 2>&1
    echo "$?" > "$case_dir.capture-exit"
    if test -f "$case_dir/session.json"; then
      digest="$(sha256sum "$case_dir/session.json" | cut -d' ' -f1)"
      python3 tools/native_weighted_replay.py "$case_dir" "$digest" > "$case_dir.replay" 2> "$case_dir.replay-stderr"
      echo "$?" > "$case_dir.replay-exit"
    fi
    echo "$arm $clock capture $(cat "$case_dir.capture-exit") replay $(cat "$case_dir.replay-exit")"
    cat "$case_dir/uart.bin" "$case_dir.replay-stderr"
  done
done
