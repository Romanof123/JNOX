"""Inspect CHG-088 first-failure evidence directly. No candidate capture/replay imports."""
import hashlib
import io
import json
from pathlib import Path
import re
import struct

from elftools.elf.elffile import ELFFile

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"
PAGE = 4096
ADDRESS = 0x0000fffffffff000
EXPECTED_SOURCE = "56d6e0b7cb7183fdc1b9b06275050ce64254e6f6"

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads(path.read_text())

def symbol(elf, name):
    entries = elf.get_section_by_name(".symtab").get_symbol_by_name(name)
    assert len(entries) == 1, name
    return entries[0]["st_value"], entries[0]["st_size"]

def ram_review(raw, launch, kernel, user, irq_pc):
    def read(address,size):
        offset=address-launch["ram_base"]
        assert 0<=offset<=len(raw)-size
        return raw[offset:offset+size]
    def u64(addr):
        return int.from_bytes(read(addr,8),"little")
    def desc(root, va):
        table=root
        for shift in (30,21,12):
            item=u64(table+8*((va>>shift)&511))
            if item==0: return 0
            assert item&3==3
            table=item&ADDRESS
        return item
    def mapped(leaf):
        return {"page":hex(leaf&ADDRESS),"ap":(leaf>>6)&3,"pxn":(leaf>>53)&1,
                "uxn":(leaf>>54)&1,"ng":(leaf>>11)&1}
    k=ELFFile(io.BytesIO(kernel))
    u=ELFFile(io.BytesIO(user))
    assert len(raw)==launch["ram_bytes"]
    note=u.get_section_by_name(".note.jnox.abi")
    assert note["sh_type"]=="SHT_NOTE" and note["sh_flags"]==2
    assert note.data()==struct.pack("<III8sI",5,4,1,b"JNOX",1)
    loads=[seg for seg in u.iter_segments() if seg["p_type"]=="PT_LOAD" and seg["p_memsz"]]
    assert [s["p_flags"] for s in loads]==[5,4,6]
    assert loads[1]["p_vaddr"]<=note["sh_addr"]<loads[1]["p_vaddr"]+loads[1]["p_filesz"]
    locations=[]
    for seg in k.iter_segments():
        if seg["p_type"]=="PT_LOAD" and user in seg.data():
            pos=seg.data().index(user)
            assert seg.data().count(user)==1
            locations.append(seg["p_paddr"]+pos)
    assert len(locations)==1 and read(locations[0],len(user))==user
    journal,capacity=symbol(k,"native_vruntime_journal")
    assert capacity==513*128
    words=list(struct.iter_unpack("<16Q",read(journal,capacity)))
    header=words[0]
    rows=words[1:1+header[6]]
    assert header[0:2]==(1,4) and header[7:9]==(0,11)
    assert header[3:5]==(62500000,625000)
    assert header[9:14]==(0,0,0,0,0)
    assert header[2]==(1 if launch["arm"]=="share" else 2)
    assert [r[0] for r in rows]==[1,1,2,11,12]
    assert not any(any(r) for r in words[1+header[6]:])
    assert [r[2] for r in rows]==[0,1,0,0,0]
    addr,size=symbol(u,"native_weighted_result")
    assert addr==header[14] and size==224
    procs=[]
    private_pages=set()
    for pid,row in enumerate(rows[:2]):
        ttbr,rpa,spa,entry,sp=row[3:8]
        assert ttbr>>48==pid+1 and entry==u["e_entry"]==0x400000
        root=ttbr&ADDRESS
        image=[]
        for seg in loads:
            va=seg["p_vaddr"]
            for offset in range(0,seg["p_memsz"],PAGE):
                item=desc(root,va+offset)
                attrs=mapped(item)
                expected={5:(3,1,0),4:(3,1,1),6:(1,1,1)}[seg["p_flags"]]
                assert (attrs["ap"],attrs["pxn"],attrs["uxn"])==expected and attrs["ng"]==1
                if seg["p_flags"]==6:
                    assert item&ADDRESS not in private_pages
                    private_pages.add(item&ADDRESS)
                else:
                    length=min(PAGE,seg["p_filesz"]-offset)
                    if length>0: assert read(item&ADDRESS,length)==seg.data()[offset:offset+length]
                image.append({"va":hex(va+offset),**attrs})
        stack=[]
        for va in range(0x01001000,0x01011000,PAGE):
            item=desc(root,va)
            attrs=mapped(item)
            assert (attrs["ap"],attrs["pxn"],attrs["uxn"],attrs["ng"])==(1,1,1,1)
            assert item&ADDRESS not in private_pages
            private_pages.add(item&ADDRESS)
            stack.append({"va":hex(va),**attrs})
        assert desc(root,0x1000000)==desc(root,0x1011000)==0
        assert desc(root,addr)&ADDRESS==rpa and desc(root,sp)&ADDRESS==spa
        horizon=desc(root,0x01200000)
        assert mapped(horizon)["ap"]==3 and u64(horizon&ADDRESS)==0
        result=read(rpa+addr%PAGE,size)
        product=struct.unpack("<28Q",result)
        if pid==0:
            assert product[:3]==(1,1,header[2])
            assert product[4]>0 and product[27]==0
            stable=product[3]%2==0
            if stable:
                # Direct sum over the workload's 16 source samples for one chunk.
                ring=[3,1,4,1,5,9,2,6,5,3,5,8,9,7,9,3]
                assert product[3]==2*product[4]
                assert product[5]==256*product[4]
                assert product[6]==product[4]*16*sum(ring)
                assert product[7]==product[4]*16*sum((j+1)*v for j,v in enumerate(ring))
        else:
            assert not any(product)
            stable=False
        procs.append(dict(asid=ttbr>>48,root=hex(root),elf_pages=image,stack_pages=stack,
                          guarded_stack=True,entry=hex(entry),initial_sp=hex(sp),result_va=hex(addr),
                          result_page=hex(rpa),initial_stack_page=hex(spa),completion_page=hex(horizon&ADDRESS),
                          result_sha256=digest(result),result_words=product,completed_stable_A_chunk=stable))
    assert procs[0]["root"]!=procs[1]["root"] and procs[0]["completion_page"]==procs[1]["completion_page"]
    selected,frame=rows[2],rows[3]
    frame_addr=frame[5]
    saved=struct.unpack("<104Q",read(frame_addr,832))
    assert saved[33]==irq_pc and saved[35]==4 and saved[32]&0x3ff==0x340
    assert saved[102]==selected[10] and 0x01001000<=saved[34]<=0x01011000
    chunk,extent=symbol(u,"chunk")
    assert chunk<=irq_pc<chunk+extent
    return dict(header=header,raw_rows=rows,processes=procs,embedded_user_pa=hex(locations[0]),
                saved_A_frame_sha256=digest(read(frame_addr,832)),saved_A_pc=hex(saved[33]),
                saved_A_sp=hex(saved[34]),saved_A_tls=hex(saved[102]),initial_pre_eret_tick=u64(symbol(k,"native_vruntime_return_tick")[0]),
                fail_code=11,committed_closures=0,wake_rounds=0)

def review(name):
    path=EVIDENCE/name
    session=read_json(path/"session.json")
    launch=read_json(path/"launch.json")
    assert launch["revision"]==EXPECTED_SOURCE
    assert launch["arm"]+"-"+launch["clock"]==name
    assert all(digest((path/f).read_bytes())==value for f,value in session["hashes"].items())
    kernel=(path/"kernel.elf").read_bytes()
    user=(path/"user.elf").read_bytes()
    for key,file in (("kernel_sha256","kernel.elf"),("user_sha256","user.elf"),("probe_sha256","probe.c")):
        assert launch[key]==session["hashes"][file]
    assert (path/"uart.bin").read_bytes()==b"JNOX M1 BOOT\nJNOX M1 READY\nNATIVE VRUNTIME FAIL\n"
    trace=(path/"exceptions.log").read_text().splitlines()
    assert len(trace)==6 and trace[0]=="Exception return from AArch64 EL1 to AArch64 EL0 PC 0x400000"
    assert trace[1]=="Taking exception 5 [IRQ]" and trace[2]=="...from EL0 to EL1"
    assert trace[5]=="...to EL1 PC 0x40200c80 PSTATE 0x3c5"
    irq_pc=int(trace[4].split()[-1],16)
    report=dict(case=name,guest="FAIL",session_sha256=digest((path/"session.json").read_bytes()),
                pid=session["pid"],guest_uart="NATIVE VRUNTIME FAIL",capture_marker=session["marker"],
                kernel_sha256=digest(kernel),user_sha256=digest(user),eret=[hex(0x400000)],irq_pc=hex(irq_pc),
                subsequent_eret=0,observed_svc=0,share_prefixes_qualified=0,wake_cycles_qualified=0)
    if (path/"ram.bin").exists():
        report["memory"]=ram_review((path/"ram.bin").read_bytes(),launch,kernel,user,irq_pc)
    else:
        assert name=="share-icount3" and "No data available" in session["marker"]
        report["memory"]=None
    return report

if __name__=="__main__":
    reports=[review(a+"-"+c) for a in ("share","wake") for c in ("default","icount3")]
    print(json.dumps(reports,indent=2))
