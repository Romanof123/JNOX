"""Summarize control image equivalence, supplemental attribution and frozen first cases."""
from pathlib import Path
import hashlib, json, re, struct
from elftools.elf.elffile import ELFFile
from independent import review, digest

root=Path(__file__).resolve().parent
ev=root/"evidence"
comparison=json.loads((ev/"controls/results.json").read_text())
firsts=[review(a+"-"+c) for a in ("share","wake") for c in ("default","icount3")]

def loads(p):
    with p.open("rb") as f:
        elf=ELFFile(f)
        return [elf["e_entry"], [[*[s[k] for k in ("p_vaddr","p_paddr","p_filesz","p_memsz","p_flags","p_align")],digest(s.data())] for s in elf.iter_segments() if s["p_type"]=="PT_LOAD"]]

controls=[]
for parent, current in zip(comparison[:6],comparison[6:]):
    case=parent["case"]
    a=ev/"controls"/("baseline-"+case)
    b=ev/"controls"/("src-"+case)
    assert case==current["case"] and parent["build"]==0
    data=dict(case=case,parent_kernel=parent["kernel_sha256"],candidate_kernel=current.get("kernel_sha256"))
    if case=="startup-probe":
        assert parent["capture"]==parent["replay"]==0 and current["build"]==1
        assert b"NATIVE EL0 EXIT 37\n" in (a/"capture/uart.bin").read_bytes()
        assert "symbol '.Lpark' is already defined" in (b/"package-build.log").read_text()
        data.update(parent="EXIT 37; replay passed",candidate="kernel compile failed; guest not launched",
                    candidate_user_sha256=digest((b/"user.elf").read_bytes()))
    else:
        assert loads(a/"kernel.elf")==loads(b/"kernel.elf")
        for filename in ("uart","exceptions.log"):
            assert (a/filename).read_bytes()==(b/filename).read_bytes()
        assert current["build"]==0 and current["last_uart"]==parent["last_uart"]
        if case.startswith("weighted"): assert parent["replay"]==current["replay"]==0
        data.update(load_headers_and_data_equal=True,uart_equal=True,external_exceptions_equal=True,
                    observed=parent["last_uart"][0],replayed=case.startswith("weighted"))
    controls.append(data)
d=ev/"supplemental-share-icount3"
registers={name:int(value,16) for name,value in re.findall(r"\b(PC|SP|X\d+)=(\w+)",(d/"registers.txt").read_text())}
raw=(d/"ram.bin").read_bytes()
entry=struct.unpack_from("<Q",raw,registers["SP"]-0x40200000+40)[0]
assert registers["PC"] in (0x402016e8,0x402016ec) and registers["X21"]==1023 and registers["X23"]==5
assert entry>=registers["X20"]==registers["X19"]+625000
def brief(r):
    ram=r["memory"]
    return dict(case=r["case"],guest=r["guest"],capture=r["capture_marker"],session_sha256=r["session_sha256"],
                first_ram=ram is not None,guest_failure_code=ram["fail_code"] if ram else None,
                external_eret_count=1,external_irq_count=1,external_svc_count=0,interrupted_A_pc=r["irq_pc"],
                checked_A_chunks=ram["processes"][0]["result_words"][4] if ram else None,
                share_closures_committed=ram["committed_closures"] if ram else None,
                qualifying_share_prefixes=0,qualifying_wake_cycles=0,
                D_I_W_R_S_intervals=None,SDK_exits_observed=0)
report=dict(candidate="56d6e0b7cb7183fdc1b9b06275050ce64254e6f6",
            frozen_parent="7549e57614221f4e6f71db32b0b369ef390e97f7",engineering_verdict="FAIL",
            input_hashes={r["case"]:dict(kernel_sha256=r["kernel_sha256"],user_sha256=r["user_sha256"]) for r in firsts},
            first_cases=[brief(r) for r in firsts],
            supplemental_diagnostic=dict(case="separate same-image share icount3 run",IAR=registers["X21"],
                CNTP_CTL=registers["X23"],entry_tick=entry,compare_tick=registers["X20"],
                pre_eret=registers["X19"],first_guard_failed="IAR INTID 1023, required 30"),
            controls=controls)
(root/"native-weighted-first.json").write_text(json.dumps(report,indent=2)+"\n")

