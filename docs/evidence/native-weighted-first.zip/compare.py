"""Build and run the CHG-088 legacy controls once for each source.""" 
import hashlib, json, os, pathlib, shutil, subprocess, sys, tempfile, time
from elftools.elf.elffile import ELFFile

base = pathlib.Path(__file__).resolve().parent
work = pathlib.Path(tempfile.mkdtemp(prefix="jnox-178-controls-"))
out = base / "evidence" / "controls"
out.mkdir()
results = []
flags = ["-machine", "virt,gic-version=2", "-cpu","cortex-a72","-smp","1","-accel","tcg","-m","128M","-nodefaults","-display","none","-monitor","none","-no-reboot"]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(cmd, loc, log, env=None):
    with log.open("wb") as stream:
        return subprocess.run(cmd, cwd=loc, env=env, stdout=stream, stderr=subprocess.STDOUT).returncode

for tree in ("baseline","src"):
    src = base/tree
    rev = subprocess.check_output(["git","rev-parse","HEAD"],cwd=src,text=True).strip()
    for case in ("startup-probe","weighted-share","weighted-share-trace","weighted-wake","weighted-wake-trace","vruntime-bench"):
        name = tree+"-"+case
        dest = out/name
        dest.mkdir()
        package = work/(name+"-build")
        row = {"tree":tree,"revision":rev,"case":case}
        results.append(row)
        env = os.environ.copy()
        env.update(CARGO_TARGET_DIR=str(package),JNOX_BOARD="virt")
        if case == "startup-probe":
            cmd=["python3","tools/build_native_el0.py","--out",str(package)]
            kernel=package/"kernel.elf"
            loc=src
        else:
            cmd=["cargo","build","--locked","--release","-j1","--target","aarch64-unknown-none"]
            kernel=package/"aarch64-unknown-none/release/jnox-kernel"
            loc=src/"kernel"
            if case == "vruntime-bench":
                cmd+=["--features",case]
            else:
                env.update(JNOX_PROFILE="weighted",JNOX_APP=case.removesuffix("-trace"))
                if case.endswith("-trace"):
                    env["JNOX_WEIGHTED_TRACE"]="1"
        row.update(build=run(cmd,loc,dest/"build.console",env),build_argv=cmd)
        if row["build"]==0:
            row["kernel_sha256"]=sha(kernel)
            with kernel.open("rb") as stream:
                row["pt_load_sha256"]=[hashlib.sha256(p.data()).hexdigest() for p in ELFFile(stream).iter_segments() if p["p_type"]=="PT_LOAD"]
            shutil.copyfile(kernel,dest/"kernel.elf")
            if case == "startup-probe":
                user=package/"user.elf"
                row["user_sha256"]=sha(user)
                cap=work/(name+"-capture")
                args=["python3","tools/native_el0_capture.py",str(cap),str(kernel),str(user),str(src/"examples/portability/native_startup_probe.c"),rev]
                row["capture"]=run(args,src,dest/"capture.console")
                row["replay"]=run(["python3","tools/native_el0_replay.py",str(cap),sha(cap/"session.json")],src,dest/"replay")
                shutil.copytree(cap,dest/"capture")
                shutil.copyfile(package/"manifest.json",dest/"manifest.json")
            else:
                uart=dest/"uart"
                cmd=["qemu-system-aarch64",*flags,"-icount","shift=3,align=off,sleep=off","-serial","file:"+str(uart),"-d","int","-D",str(dest/"exceptions.log"),"-kernel",str(kernel)]
                row.update(guest_argv=cmd)
                with (dest/"stderr").open("wb") as err:
                    proc=subprocess.Popen(cmd,stderr=err,stdout=subprocess.DEVNULL)
                    try:
                        cutoff=time.monotonic()+20
                        while time.monotonic()<cutoff and proc.poll() is None:
                            raw=uart.read_bytes() if uart.exists() else b""
                            if any(mark in raw for mark in (b"VR PASS\n",b"WEIGHTED TERMINAL\n",b"VR FAIL\n",b"WEIGHTED FAIL\n")):
                                break
                            time.sleep(.01)
                    finally:
                        if proc.poll() is None:
                            proc.terminate()
                        proc.wait(timeout=5)
                row["last_uart"]=uart.read_text().splitlines()[-1:]
                if case.startswith("weighted"):
                    replay=["python3","tools/weighted_replay.py",str(uart)]
                    if "wake" in case: replay+=["--wake"]
                    if "trace" in case: replay+=["--diagnostic"]
                    row["replay"]=run(replay,src,dest/"replay")
        (out/"results.json").write_text(json.dumps(results,indent=2)+"\n")
        print(name,row.get("build"),row.get("capture"),row.get("replay"),row.get("last_uart"),flush=True)
