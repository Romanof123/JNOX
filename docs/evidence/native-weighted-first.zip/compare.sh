#!/bin/bash
set -eu
cd "$(dirname "$0")"
base="$(pwd)"
tc=/home/ywcho/jnox-169-first-e203caa
export PATH="$tc/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH" CARGO_HOME="$base/cargo-home" CARGO_BUILD_JOBS=1 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$tc/deps"
exec python3 compare.py
