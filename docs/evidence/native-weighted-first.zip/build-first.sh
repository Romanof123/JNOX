#!/bin/bash
set -u
cd "$(dirname "$0")"
base="$(pwd)"
tc=/home/ywcho/jnox-169-first-e203caa
export PATH="$tc/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH"
export CARGO_HOME="$base/cargo-home" CARGO_BUILD_JOBS=1 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$tc/deps"
mkdir -p evidence
cd src
for arm in share wake; do
  python3 tools/build_native_el0.py --app "weighted-$arm" --out "$base/build-$arm" > "$base/evidence/build-$arm.console" 2>&1
  status=$?
  echo "$status" > "$base/evidence/build-$arm.exit"
  cat "$base/evidence/build-$arm.console"
  tail -15 "$base/build-$arm/build.log"
done
