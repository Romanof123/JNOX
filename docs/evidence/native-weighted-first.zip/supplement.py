"""One separately labelled icount3 diagnostic for the fail(11) guard registers."""
import hashlib, json, os, pathlib, shutil, subprocess, tempfile, time

base = pathlib.Path(__file__).resolve().parent
out = base/"evidence"/"supplemental-share-icount3"
out.mkdir()
prior = json.loads((base/"evidence/share-icount3/launch.json").read_text())
with tempfile.TemporaryDirectory(prefix="jnox178-diag-") as scratch:
    work = pathlib.Path(scratch)
    kernel = base/"evidence/share-icount3/kernel.elf"
    assert hashlib.sha256(kernel.read_bytes()).hexdigest()==prior["kernel_sha256"]
    args = list(prior["argv"])
    args[args.index("-serial")+1]="file:"+str(work/"uart.bin")
    args[args.index("-D")+1]=str(work/"exceptions.log")
    args[-1]=str(kernel)
    (out/"argv.json").write_text(json.dumps(args,indent=2)+"\n")
    with (out/"stderr").open("wb") as err:
        with subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as process:
            def req(cmd, **kwargs):
                process.stdin.write((json.dumps(dict(execute=cmd,arguments=kwargs))+"\n").encode())
                process.stdin.flush()
                while True:
                    data=json.loads(process.stdout.readline())
                    if "error" in data:
                        raise ValueError(data)
                    if "return" in data:
                        return data["return"]
            try:
                assert "QMP" in json.loads(process.stdout.readline())
                req("qmp_capabilities")
                start=time.monotonic()
                while time.monotonic()-start < 10:
                    uart=work/"uart.bin"
                    if uart.exists() and b"NATIVE VRUNTIME FAIL\n" in uart.read_bytes(): break
                    time.sleep(.01)
                assert b"NATIVE VRUNTIME FAIL\n" in uart.read_bytes()
                req("stop")
                (out/"registers.txt").write_text(req("human-monitor-command",**{"command-line":"info registers"}))
                req("pmemsave",val=prior["ram_base"],size=prior["ram_bytes"],filename=str(work/"ram.bin"))
                req("quit")
                process.wait(timeout=3)
            finally:
                if process.poll() is None: process.kill()
        for f in work.iterdir():
            shutil.copyfile(f,out/f.name)
(out/"disassembly.txt").write_bytes(subprocess.check_output(["aarch64-linux-gnu-objdump","-d","--start-address=0x40201698","--stop-address=0x402016f0",str(kernel)])+subprocess.check_output(["aarch64-linux-gnu-objdump","-d","--start-address=0x40201c94","--stop-address=0x40201cf8",str(kernel)])+subprocess.check_output(["aarch64-linux-gnu-objdump","-d","--start-address=0x40202650","--stop-address=0x40202658",str(kernel)]))
