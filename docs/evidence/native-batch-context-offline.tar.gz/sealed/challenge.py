import hashlib,json,pathlib,subprocess,sys,tempfile
root=pathlib.Path.cwd()
tool=pathlib.Path.home()/'iv342-offline-src/tools/native_batch_context.py'
p=root/'raw/base/products'
cases=['kind','release-pa','ordinal','balanced-ordinal','chronology','pc','trace-return','private-word','x23']
sha=lambda b:hashlib.sha256(b).hexdigest()
for test in cases:
 c='arrival-srtf' if test=='x23' else 'tie-sjf'
 src=root/'raw/iv342-correct-data/observed'/c
 with tempfile.TemporaryDirectory() as td:
  dst=pathlib.Path(td)/c;dst.mkdir()
  for f in src.iterdir(): (dst/f.name).symlink_to(f)
  s=json.loads((src/'session.json').read_bytes())
  def put(name,b):
   f=dst/name;f.unlink();f.write_bytes(b)
   if name!='session.json':s['hashes'][name]=sha(b)
  rows=list(map(json.loads,(src/'context.jsonl').read_text().splitlines()))
  lines=(src/'uart.bin').read_bytes().splitlines(keepends=True)
  for i,line in enumerate(lines):
   if not line.startswith(b'NATIVE BATCH EVENT '): continue
   a=line.split();seq=int(a[3]);offset=3
   if seq==2:
    if test=='kind': a[offset+1]=b'1'
    if test in ('balanced-ordinal','ordinal'): a[offset+37]=str(int(a[offset+37])+1).encode()
    if test=='chronology':a[offset+33]=str(int(a[offset+3])-1).encode()
    if test=='pc':a[offset+21]=a[offset+25]=b'4194976'
   if seq==3 and test=='balanced-ordinal':a[offset+37]=str(int(a[offset+37])-1).encode()
   lines[i]=b' '.join(a)+line[len(line.rstrip()):]
  if test=='kind':
   for r in rows:
    if 'event_kind' in r:r['event_kind']=1
  if test=='release-pa': next(r for r in rows if r['kind']=='release')['pa']+=8
  if test=='private-word':
   r=next(r for r in rows if r['kind']=='release');r['value']+=1
  if test=='x23':[r for r in rows if r['kind']=='restore'][-1]['frame'][23]^=1
  if test=='trace-return':
   b=(src/'exceptions.log').read_bytes();old=b'Exception return from AArch64 EL1 to AArch64 EL0 PC 0x40029c';put('exceptions.log',b.replace(old,old[:-1]+b'8',1))
  put('uart.bin',b''.join(lines));put('context.jsonl',(''.join(json.dumps(r)+'\n' for r in rows)).encode());b=json.dumps(s).encode();put('session.json',b)
  r=subprocess.run([sys.executable,str(tool),'observed',str(p),td,c,sha(b),s['hashes']['observer.so']],capture_output=True,text=True)
  j=json.loads(r.stdout);print(test,r.returncode,j.get('detail',j.get('gaps')));assert r.returncode in (1,2)
