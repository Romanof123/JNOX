import sys,json,struct,zlib
from pathlib import Path
d,prior=map(Path,sys.argv[1:])
data=json.loads((d/'observations.json').read_text());old=json.loads((prior/'observations.json').read_text())
out=["# Permit runtime decision / 허가 런타임 판정", "", "Revision 7c5b0c2d20f1404f433cc0bf972d790f6a3faa45. Refuse admission under FIFO and RR. Both policies exceed the unchanged inclusive 62,500-tick phase bound in every one of their twelve sampled positions. All 24 provide complete waits and 32 COMPLETEs. Identical workload commands and ELFs can be compared against the original separately sealed series fbbb5ce. Wall-clock QEMU TCG, Cortex-A72, 62,500 ticks/ms. Cold means job 0 here. Finite observations give no analytical hard-time bound or hardware evidence.", "", "FIFO·RR 각각 12개 실행 모두 1 ms 위상 제한을 넘었다. 이번 표본은 모든 대기와 32개 완료를 기록했으며, 첫 작업과 후속 작업을 구분했다. 실제 장치의 응답시간 상한은 미확정이다.", "", "|Position|Old phase upper|New lower–upper|Job 0 A/B upper|Later max upper|Old/new gap upper|Old/new missing|", "|---|---:|---:|---:|---:|---:|---:|"]
for n,x in data.items():
 if 'jobs' not in x:continue
 o=old[n];j=[a for a in x['jobs'] if a['pid']==1]
 assert not x['missing_wait'] and x['completed_checks']==32 and x['max_ctrl_lo']>62500
 out.append(f"|{n}|{o['max_ctrl_hi']}|{x['max_ctrl_lo']}–{x['max_ctrl_hi']}|"+"/".join(str(a['response'][1]) for a in j if a['job']==0)+f"|{max(a['response'][1] for a in j if a['job']>0)}|{o['max_complete_gap_upper']}/{x['max_complete_gap_upper']}|{len(o['missing_wait'])}/0|")
out+=["","## Live wire / 실제 발행 프레임",""]
for n in ('fifo-live','rr-live'):
 def gaps(x):
  s=x['private'][0]; b=bytes.fromhex(s['admission_sender_bytes']);t=[]
  for k in range(s['admission_sender_count'][0]):
   f=b[44*k:44*k+44];assert zlib.crc32(f[:40])==int.from_bytes(f[40:44],'little')
   v=int.from_bytes(f[24:32],'little');assert v==s['admission_sender_rows'][10*k+2];t.append(v)
  return [b-a for a,b in zip(t,t[1:])]
 out.append(f"{n} encoded issue deltas in ticks, first series {gaps(old[n])}, corrected {gaps(data[n])}. Required first pair 625000. ENABLE 18/37 ms {data[n]['enabled18']}/{data[n]['enabled37']}.")
out+=["","## Authentic single-check observations / 단일 검사","", "|Boot|Exit values|Enabled immediately before expiry|Detect ticks after expiry|Next publication relative to expiry|","|---|---|---|---:|---|"]
for n,x in data.items():
 if 'jobs' not in x:out.append(f"|{n}|{x['exits']}|{x.get('enabled_before_expiry')}|{x.get('detect_offset')}|{x.get('next_pub_offset')}|")
out+=["","## Runtime regressions / 런타임 회귀","","The safety-enabled timeout case returns exits 54/55/70. Its server rejects the expired token and answers the second indefinite call. The safety-enabled donation case returns 51/52/53 with the lower priority server dispatched before the ready middle-priority task. The frame case returns 69/70/70. After both peers exit, PID 0 twice sleeps from its own active root, resumes with the saved PC/SP shown by FIXED, and checks the x19/SP and x20 sentinel in EL0. The same capture first switches across distinct private roots. Real 44-byte healthy traffic includes NATIVE LOAN MAP 1/2/3/4, with writable producer PTE, revoked producer PTE, read-only receiver PTE and revoked receiver PTE. The ordinary variable-length loan regression returns 73/74/70. Its deliberately retained first run with the permit profile returns 82/90/70 (incompatible variable-length data); inspect reg-loan separately.", "", "유한 타임아웃·기부 및 무기한 요청/응답, 동일 루트 유휴 복귀와 서로 다른 프로세스 전환, 실제 허가 페이지 전달·회수의 관측 자료를 포함한다. 일반 가변 길이 대여를 허가 프로파일에서 시도한 실패도 보존했다.","","## Reproduction / 재현","","Extract each qualification/default/observer tar into a directory named for its stem; place the supplied role ELFs at their common parent. Run reduce.py WORK OUTPUT with Linux aarch64-linux-gnu-nm and then compare.py OUTPUT FIRST_EVIDENCE. The original first package is an external comparison input. Regression sources and commands are supplied. Startup shell quoting failed before checkout, the first frame fixture used an unsupported plain asm spelling (failed C source retained), and trailing CR in two host output paths was corrected after capture. No guest position was removed or replaced. Both output copies contain the same sealed archive."]
(d/'DECISION.en-ko.md').write_text('\n'.join(out)+'\n',encoding='utf8')
