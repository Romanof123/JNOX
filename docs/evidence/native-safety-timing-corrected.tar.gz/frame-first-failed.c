#include <time.h>
int main(int argc, char **argv) {
    if(argc!=2 || argv[1][0]!='f') return 70;
    for(int i=0;i<3;i++){
        struct timespec t;
        if(clock_gettime(1,&t)) return 81;
        t.tv_nsec+=20000000;
        if(t.tv_nsec>=1000000000){t.tv_sec++;t.tv_nsec-=1000000000;}
        register long status asm("x0")=1;
        register long flags asm("x1")=1;
        register void *arg asm("x2")=&t;
        register long id asm("x8")=7;
        long frame_ok;
        asm volatile("mov x19, sp\nmov x20, #0x5789\nsvc #0x4a01\nmov x21, sp\ncmp x19,x21\ncset %0,eq\nmov x21,#0x5789\ncmp x20,x21\ncsel %0,%0,xzr,eq" : "=&r"(frame_ok),"+r"(status),"+r"(flags):"r"(arg),"r"(id):"x19","x20","x21","cc","memory");
        if(status || !frame_ok) return 82;
    }
    return 69;
}
