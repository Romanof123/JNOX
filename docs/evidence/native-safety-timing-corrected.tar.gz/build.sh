set -eu
base=$HOME/permit389-recheck-7c5b0c2
cd "$base/src"
for role in sender controller supervisor; do
 sh sdk/native-aarch64/build-rust.sh examples/native-safety-admission/$role/Cargo.toml "$base/$role.elf" > "$base/$role.build.log" 2>&1 || { cp "$base"/*.log /mnt/d/codex/permit389-recheck-7c5b0c2/; tail -40 "$base/$role.build.log"; exit 1; }
done
