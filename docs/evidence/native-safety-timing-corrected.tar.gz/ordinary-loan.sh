set -eu
source ~/.cargo/env
b=$HOME/permit389-recheck-7c5b0c2
d=/mnt/d/codex/permit389-recheck-7c5b0c2
cd "$b/src"
cp "$d/frame.c" "$d/regress.sh" "$b/"
sh sdk/native-aarch64/build.sh "$b/frame.c" "$b/frame.elf"
sh sdk/native-aarch64/build.sh examples/native-sync-ipc/cases/operational.c "$b/op.elf"
sh sdk/native-aarch64/build.sh examples/native-loan/producer.c "$b/prod.elf"
sh sdk/native-aarch64/build-rust.sh examples/native-loan/reader/Cargo.toml "$b/read.elf"
for s in loan; do
 dir=$b/regress/ordinary-$s; mkdir -p "$dir"
 op=$b/op.elf; f=$b/frame.elf; src=examples/native-sync-ipc/cases/operational.c
 case $s in
 timeout) ex=54; a=(--elf "$op" --arg timeout --peer-elf "$op" --peer-arg late --peer-elf "$f" --peer2-arg noop --ipc-route 0:1);;
 donation) ex=51; a=(--elf "$op" --arg high --peer-elf "$op" --peer-arg medium --peer-elf "$op" --peer2-arg low --ipc-route 0:2);;
 frame) ex=69; src=$b/frame.c; a=(--elf "$f" --arg frame --peer-elf "$f" --peer-arg noop --peer-elf "$f" --peer2-arg noop --ipc-route 0:1);;
 loan) ex=73; src=examples/native-loan/producer.c; a=(--elf "$b/prod.elf" --peer-elf "$b/read.elf" --peer-elf "$f" --peer2-arg noop --ipc-route 0:1);;
 esac
 (set -x; python3 tools/build_native_el0.py --board virt --policy fifo --priority 7 --peer-priority 4 --peer-priority 1 --loan-route 0:1 --out "$dir/pkg" "${a[@]}") > "$dir/build.log" 2>&1
 (set -x; python3 tools/native_el0_capture.py "$dir/cap" "$dir/pkg/kernel.elf" "${a[1]}" "$src" "$(git rev-parse HEAD)" --manifest "$dir/pkg/manifest.json" --plain --expect-exit "$ex" --timeout 35) > "$dir/boot.log" 2>&1 || echo UNRESOLVED >> "$dir/boot.log"
 (cd "$dir"; tar -czf "$d/reg-ordinary-$s.tgz" cap pkg/kernel.elf pkg/manifest.json build.log boot.log)
done
cp "$b"/{frame,op,prod,read}.elf "$d/"
