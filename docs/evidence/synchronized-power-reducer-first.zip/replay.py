import sys, pathlib, json, hashlib, subprocess
from fractions import Fraction as F
root=pathlib.Path(sys.argv[1]).resolve()
base=pathlib.Path(__file__).resolve().parent
def sha(raw): return hashlib.sha256(raw).hexdigest()
def write(path,obj):
    raw=(json.dumps(obj,sort_keys=True)+'\n').encode()
    path.write_bytes(raw)
    return sha(raw)
for case in ['rise','fall','cut','tie']:
    d=base/case
    d.mkdir(exist_ok=True)
    ev={k:'fixture '+k for k in 'board firmware workload cpu_opp thermal shared_load environment idle_state instrument trigger limits'.split()}
    ev.update(counter_hz=3,trigger_tick=100,trigger_ns=17,idle_start_tick=100,idle_end_tick=101,release_tick=102,wake_tick=103,first_tick=104,complete_tick=105,deadline_tick={'rise':106,'tie':105}.get(case,104),sync_uncertainty_ns=7,max_gap_ns=10**9)
    powers=[4,3,2] if case=='fall' else [1,2,3]
    # Both channels change. Endpoint products lie on the affine line in watts.
    samples=[[17+i*10**9,(i+1)*500000,p*2000000//(i+1)] for i,p in enumerate(powers)]
    if case=='fall': samples[-1][1:]=[4000000,500000]
    if case=='cut': samples.pop()
    m={'kind':'fixture','producer':'power244 independent verifier'}
    for k,v in [('events',ev),('samples',samples)]:
        m[k]=dict(file=k+'.json',sha256=write(d/(k+'.json'),v))
    mh=write(d/'manifest.json',m)
    cmd=[sys.executable,'tools/power_reduce.py',str(d/'manifest.json')]
    p=subprocess.run(cmd,cwd=root,capture_output=True)
    (d/'actual.json').write_bytes(p.stdout)
    a=json.loads(p.stdout)
    assert p.returncode==(case=='cut') and a['manifest_sha256']==mh and all(a[k]==m[k] for k in m)
    assert a['context']=={k:v for k,v in ev.items() if isinstance(v,str)}
    assert a['sync_uncertainty_ns']==7 and a['counter_hz']==3 and a['max_gap_ns']==10**9
    assert a['wake_s']=='1/3' and a['response_s']=='1' and F(a['deadline_margin_s'])==F(ev['deadline_tick']-105,3) and a['observed_miss']==(ev['deadline_tick']<105)
    cov=a['coverage']
    assert F(cov['run']['start_ns'])==17+F(2*10**9,3) and F(cov['run']['end_ns'])==17+F(5*10**9,3)
    assert F(cov['idle']['covered_ns'])==F(10**9,3) and F(cov['run']['covered_ns'])==(F(10**9,3) if case=='cut' else 10**9)
    if case=='cut':
        assert a['status']=='incomplete sample coverage' and all(k not in a for k in ['adjusted_J','run_J','idle_J','idle_mean_W'])
    else:
        expected=['23/18','23/6','17/6','-1'] if case=='fall' else ['7/18','7/6','13/6','1']
        assert [a[k] for k in ['idle_J','idle_mean_W','run_J','adjusted_J']]==expected
    print(case,p.returncode,a['status'])
