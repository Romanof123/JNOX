set -eu
cd "$HOME/verify330-ea19/src"
o="$HOME/verify330-ea19/raw"
rev=$(git rev-parse HEAD)
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
python3 -c 'import elftools'
sha256sum $(command -v qemu-system-aarch64 clang ld.lld aarch64-linux-gnu-objdump) "$o"/*.py "$o"/*.elf "$o"/*/kernel.elf tools/{native_el0_capture,read_multilevel_telemetry,build_native_el0}.py examples/native-multilevel/{report.c,alarms.h,publication.h} > "$o/freeze.sha256"
for a in report crc; do aarch64-linux-gnu-objdump -d "$o/$a.elf" > "$o/$a.dis"; aarch64-linux-gnu-nm -S "$o/$a.elf" > "$o/$a.sym"; done
for k in strict-plain strict-traced feedback-plain feedback-traced compat-plain invalid-plain; do
 pkg="$o/${k%-*}"
 a=()
 if [[ $k == *-plain ]]; then a+=(--plain); fi
 st=53; if [[ $k == invalid-plain ]]; then st=106; fi
 python3 "$o/instrument.py" "$o/$k" "$pkg/kernel.elf" "$pkg/user.elf" examples/native-multilevel/report.c "$rev" --manifest "$pkg/manifest.json" --expect-exit "$st" "${a[@]}" > "$o/$k.capture" 2>&1 || echo "$k capture $?"
 python3 tools/read_multilevel_telemetry.py "$pkg" "$o/$k" > "$o/$k/results.json" 2> "$o/$k/reader.err" || echo "$k reader $?"
done
