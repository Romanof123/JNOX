set -eu
p=$HOME/verify330-ea19
mkdir -p "$p/raw"
cd "$p"
git init -q src
cd src
git fetch -q --depth=1 https://github.com/Romanof123/JNOX.git ea19c884f07367ce8ab514f2e28e2fffb80e90e7
git checkout -q FETCH_HEAD
export PATH="$HOME/.cargo/bin:$PATH"
o="$p/raw"
cc -std=c11 examples/native-multilevel/publication_arithmetic_test.c -o "$o/arithmetic"
"$o/arithmetic"
sh sdk/native-aarch64/build.sh examples/native-multilevel/report.c "$o/report.elf"
sh sdk/native-aarch64/build.sh examples/native-cbs/crc.c "$o/crc.elf"
for k in strict feedback compat invalid; do
 a=(--policy mlq --class 7 --peer-class 1 --quantum-ticks 625000)
 if [[ $k == feedback ]]; then a=(--policy mlfq --allotment-ticks 625000,1250000,2500000 --boost-ticks 6250000); fi
 case $k in strict|feedback) a+=(--arg=--publication-deadline-ms=40);; invalid) a+=(--arg=--publication-deadline-ms=0);; esac
 python3 tools/build_native_el0.py --out "$o/$k" --elf "$o/report.elf" --peer-elf "$o/crc.elf" "${a[@]}" > "$o/$k.build" 2>&1
done
