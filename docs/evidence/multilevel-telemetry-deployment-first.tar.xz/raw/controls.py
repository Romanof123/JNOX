import base64,hashlib,zipfile,tarfile,json,io,subprocess,sys,re
from pathlib import Path
p=Path.home()/'verify330-ea19';o=p/'raw';src=p/'src';ev=src/'docs/evidence'
h=lambda b:hashlib.sha256(b).hexdigest()
def cmd(*args,cwd=src):return subprocess.check_output(args,cwd=cwd,text=True)
a=json.loads((ev/'evd-040.json').read_text()); blob=base64.b64decode(a['zip_base64']);assert h(blob)==a['zip_sha256']
t=p/'old040';t.mkdir(exist_ok=True)
with zipfile.ZipFile(io.BytesIO(blob)) as z:
 for n,s in a['files'].items():
  b=z.read(n);assert h(b)==s['sha256'];f=t/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
log=cmd('python3',str(t/'verify.py'),cwd=t)
old={'EVD040':dict(source=a['source'],archive_sha=h(blob),replay=log)}
for name,ids in [('mlq',[0,10,11,12]),('mlfq',[1,4,6,8,10])]:
 data=json.loads((t/(name+'-rows.json')).read_text());old['EVD040'][name]=[dict(index=j,record=data[j]) for j in ids]
file=ev/'native-multilevel-applications-first.tar.gz'; oldsha=h(file.read_bytes());assert oldsha=='0b0c5db9e5c4a43d976e09e179b1c3fb3317fa5fe878538d4419dc2833adaaaf'
with tarfile.open(file) as z:z.extractall(p/'old122',filter='data')
t=p/'old122/evidence';cmd('python3',str(t/'score.py'),cwd=t)
score=json.loads((t/'score.json').read_text())
old['EVD122']=dict(source=json.loads((t/'freeze.json').read_text())['sha'],archive_sha=oldsha,loss={k:score[k]['dropped'] for k in ['equal','cumulative','solo']},first_yield_demotion=next(row for row in score['cumulative']['demotions'] if row[1]==0))
R=[list(map(int,l.split()[3:])) for l in (t/'three/uart.log').read_text().splitlines() if ' EVENT ' in l]
old['EVD122']['three']=dict(first=[r[3] for r in R[:3]],first_low=next([j,r[31]] for j,r in enumerate(R) if r[3]==2))
files=['kernel/src/'+v+'.rs' for v in ['native_multilevel','multilevel_policy','feedback_policy','multilevel_service']]
assert not cmd('git','diff','--name-only',old['EVD122']['source'],'HEAD','--',*files)
old['EVD122']['unchanged_semantics']={f:h((src/f).read_bytes()) for f in files}
(o/'original-controls.json').write_text(json.dumps(old,indent=2))
sys.path.insert(0,str(src/'tools'))
from native_el0_replay import Snapshot,permissions,PA_MASK
out=json.loads((o/'verified.json').read_text())
for n,v in out.items():
 d=o/n;sy=cmd('aarch64-linux-gnu-nm','-S',str(d/'kernel.elf'))
 b,s=[int(k,16) for k in next(l for l in sy.splitlines() if '6SPACES' in l).split()[:2]]
 roots=[b,b+s//2];mem=Snapshot(json.loads((d/'launch.json').read_text())['ram_base'],(d/'ram.bin').read_bytes())
 for key,va in [('stack',16846672),('data',0x402008)]:
  addrs=[]
  for root in roots:
   permissions(mem,root,va,'user rw');addrs.append(mem.leaf(root,va)&PA_MASK)
  assert addrs[0]!=addrs[1];v[key+'_physical_pages']=addrs
(o/'verified.json').write_text(json.dumps(out,indent=2))

