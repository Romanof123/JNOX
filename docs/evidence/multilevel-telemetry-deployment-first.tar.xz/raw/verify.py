import json,re,struct,subprocess,hashlib,tarfile,zipfile,base64,io,zlib
from pathlib import Path
o=Path(__file__).parent; src=o.parent/'src'; NA=2**64-1
def h(b):return hashlib.sha256(b).hexdigest()
def dump(f,a): (o/f).write_text(json.dumps(a,indent=2))
def rows(u):return [list(map(int,l.split()[3:])) for l in u.splitlines() if ' EVENT ' in l]
def order(q):return sum((x+1)*16**i for i,x in enumerate(reversed(q)))
def nm(p):return subprocess.check_output(['aarch64-linux-gnu-nm','-S',p],text=True).splitlines()
out={}
for name in ['strict-plain','strict-traced','feedback-plain','feedback-traced','compat-plain','invalid-plain']:
 d=o/name; u=(d/'uart.bin').read_text(); R=rows(u); fb=name.startswith('feedback')
 res=json.loads((d/'results.json').read_text()); ram=(d/'ram.bin').read_bytes()
 launch=json.loads((d/'launch.json').read_text()); base=launch['ram_base']; sy=nm(d/'kernel.elf')
 adr=lambda k:int(next(l for l in sy if k in l).split()[0],16)
 epoch,hz=[struct.unpack_from('<Q',ram,int(l.split()[0],16)-base)[0] for l in sorted(l for l in sy if 'CLOCK_DOMAIN' in l)]
 assert hz==62500000 and 'DROPPED 0' in u
 q=[0,1]; sleepers={}; own=NA; level=[2,2] if fb else [7,1]; left=[625000]*2; svc=[0,0]; saved={};frame={};wake=[];boost=[];sw=[];exited=0
 for j,r in enumerate(R):
  reason,t,old,new,start,charge=r[:6];assert old==own and order(q)==r[21] and r[38:40]==level and r[41:43]==left
  if j:assert r[4]==R[j-1][11] and r[6:11]==R[j-1][12:17]
  if reason==4:assert 0<r[10]<=t
  woke=sorted((target,pid) for pid,target in sleepers.items() if target<=t)
  assert r[17]==order([pid for _,pid in woke])
  for due,pid in woke:q.append(pid);del sleepers[pid];wake.append((j,due))
  if old!=NA:
   saved[old]=r[24:26]; assert frame[old]==r[28] and charge==t-start; svc[old]+=charge
   if reason==2:sleepers[old]=r[30];sw.append((j,r[30]))
   elif reason==3:exited|=1<<old
   else:q.append(old)
   if fb:
    while charge>=left[old]:
     charge-=left[old];level[old]=max(0,level[old]-1);left[old]=[2500000,1250000,625000][level[old]]
    left[old]-=charge
  assert r[22]==order(q) and r[31]==exited and r[32:34]==svc and r[18]==sum(svc) and r[44:46]==level and r[47:49]==left
  if fb:
   cross=sum(svc)//6250000-(R[j-1][18]//6250000 if j else 0);assert r[19]==cross
   if cross:boost.append(dict(row=j,ready=q.copy(),selected=new,next_owner=R[j+1][2],charged=sum(svc)));level=[2,2];left=[625000,625000]
   assert r[20]==(sum(svc)//6250000+1)*6250000
  assert r[50:52]==level and r[53:55]==left
  pick=max(q,key=lambda i:level[i]) if q else NA
  assert new==pick
  if q:
   q.remove(pick);assert r[26:28]==saved.get(pick,[4194304,16846768]) and frame.setdefault(pick,r[29])==r[29]
   assert r[12]==left[pick] and r[13]==r[11]+left[pick] and r[16]==min(v for v in r[13:16] if v)
  assert r[23]==order(q);own=new
 assert exited==3 and own==NA and frame[0]!=frame[1]
 obs=[json.loads(l) for l in (d/'progress.ndjson').read_text().splitlines()]
 rounds=[]
 if name!='invalid-plain':assert len(sw)==len(wake)==3
 for i,((sj,due),(wj,wd)) in enumerate(zip(sw,wake)):
  a=res['rounds'][i];r=R[wj];sp=R[sj];off=epoch*16;D=a['request_ns'];W=a['observed_ns'];U=a['publication_ns']
  assert D%16==0 and due==wd==epoch+D//16 and r[0]==4 and r[9]==r[10]==due and r[2:4]==[1,0] and r[1]>=due and r[11]*16<=off+W
  nxt=next(v for v in R[wj+1:] if v[3]==1);assert nxt[26:28]==r[24:26] and nxt[29]==r[28]
  vals=[b for _,a0,b,a1 in obs if a0==a1 and a0[i]==D and not a0[i+3]]
  assert max(vals)>min(vals)
  if not name.startswith('compat'):assert D<W<=U<=D+40000000 and a['publication_verdict']==1 and a['publication_marker']==i+1
  assert (a['round_count'],a['cumulative_count'])==(256,256*(i+1))
  rounds.append(dict(round=i+1,D=D,W=W,U=U,delay=a['sampled_delay_ns'],margin=a['sampled_margin_ns'],sleep_row=sj,irq_row=wj,due_tick=due,irq_tick=r[1],dispatch_tick=r[11],crc_before=min(vals),crc_after=max(vals),crc_saved=r[24:26],crc_resumed=nxt[26:28]))
 assert res['crc_exit']==17 and res['crc_matches'] and zlib.crc32(bytes(range(256))*16*res['crc_blocks'])==res['crc32']
 invalid=name.startswith('invalid');assert res['reporter_exit']==(106 if invalid else 53) and res['reporter_bytes']==(0 if invalid else 12288) and res['reporter_blocks']==(0 if invalid else 3)
 if invalid:assert all(not any(v for k,v in a.items() if k!='round') for a in res['rounds'])
 pairs=[]
 if 'traced' in name:
  raw=(d/'exceptions.log').read_text();pairs=[(k,int(v,16),int(w,16)) for k,v,w in re.findall(r'Taking exception \d+ \[(IRQ|SVC)\]\n\.\.\.from EL0 to EL1\n[^\n]*\n\.\.\.with ELR 0x([a-f0-9]+)\n[^\n]*\nException return from AArch64 EL1 to AArch64 EL0 PC 0x([a-f0-9]+)',raw)]
  cursor=0;idx={}
  for j,r in enumerate(R):
   if NA in r[2:4]:continue
   item=('IRQ' if r[0]==4 else 'SVC',r[24],r[26]);cursor=pairs.index(item,cursor)+1;idx[j]=cursor-1
  for a in rounds:
   k=idx[a['irq_row']]; nxt=next(j for j in idx if j>a['irq_row']); calls=[t for t in range(k+1,idx[nxt]) if pairs[t]==('SVC',0x40027c,0x40027c)]
   assert len(calls)>=2;a['traced_postwake_publication_clock_ordinals']=calls[:2]
 out[name]=dict(epoch=epoch,hz=hz,journal_rows=len(R),dropped=0,crc_blocks=res['crc_blocks'],crc_bytes=res['crc_bytes'],crc32=res['crc32'],reporter_exit=res['reporter_exit'],crc_exit=17,boosts=boost,rounds=rounds,private_frames=frame)
dump('verified.json',out)

