from pathlib import Path
import sys, subprocess, struct, time, json
src=Path.home()/'verify330-ea19/src'
sys.path.insert(0,str(src/'tools'))
def observe(proc,root):
    if not hasattr(observe,'mem'):
        kernel=(root/'kernel.elf').read_bytes()
        ph=struct.unpack_from('<Q',kernel,32)[0]
        seg=next(h for i in range(struct.unpack_from('<H',kernel,56)[0]) if (h:=struct.unpack_from('<II6Q',kernel,ph+56*i))[0]==1 and h[5]>=256)
        mem=open(f'/proc/{proc.pid}/mem','rb',buffering=0)
        for line in Path(f'/proc/{proc.pid}/maps').read_text().splitlines():
            lo,hi=[int(v,16) for v in line.split()[0].split('-')]
            if hi-lo<128*1024**2 or 'rw' not in line.split()[1]: continue
            mem.seek(lo+seg[4]-0x40000000)
            if mem.read(256)==kernel[seg[2]:seg[2]+256]: break
        else: return
        syms=subprocess.check_output(['aarch64-linux-gnu-nm','-S',root/'kernel.elf'],text=True)
        base,size=(int(x,16) for x in next(l for l in syms.splitlines() if '6SPACES' in l).split()[:2])
        observe.mem=mem
        observe.crc=lo+base+size//2+0x5000+0x2008-0x40000000
        observe.report=lo+base+0x5000+0x3020-0x40000000
    m=observe.mem
    m.seek(observe.report); before=struct.unpack('<6Q',m.read(48))
    m.seek(observe.crc); blocks=struct.unpack('<Q',m.read(8))[0]
    m.seek(observe.report); after=struct.unpack('<6Q',m.read(48))
    with (root/'progress.ndjson').open('a') as f: print(json.dumps([time.monotonic_ns(),before,blocks,after]),file=f)
code=(src/'tools/native_el0_capture.py').read_text().replace('raw = uart.read_bytes()', 'observe(proc,root)\n                        raw = uart.read_bytes()')
exec(compile(code,'native_el0_capture.py','exec'))

