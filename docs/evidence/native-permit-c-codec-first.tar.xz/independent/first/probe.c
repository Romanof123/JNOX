/* The stopped guest exposes each raw destination, guard bytes and actual result. */
#include <jnox/permit_codec.h>
#include <stddef.h>
#include <stdint.h>

struct fixture {
    int encode;
    size_t length;
    int32_t expected_status;
    int null_input;
    int null_output;
    jnox_permit_fields fields;
    unsigned char wire[44];
    unsigned char expected_destination[48];
};
#include "fixtures.inc"
#define CASE_COUNT (sizeof(cases) / sizeof(cases[0]))

struct guarded_fields {
    uint64_t guard_start;
    jnox_permit_fields fields;
    uint64_t guard_end;
};
struct observation {
    int32_t status;
    unsigned char destination[48];
};
struct case_report {
    uint32_t magic;
    uint32_t count;
    uint32_t completed;
    uint32_t failed;
    struct observation observations[CASE_COUNT];
};
volatile struct case_report permit405_guest_report;

_Static_assert(JNOX_PERMIT_FRAME_BYTES == 44, "44-byte wire");
_Static_assert(sizeof(jnox_permit_fields) == 32, "public C fields");
_Static_assert(__builtin_offsetof(struct guarded_fields, fields) == 8, "aligned output");
_Static_assert(sizeof(struct guarded_fields) == 48, "guards surround fields");
_Static_assert(sizeof(struct observation) == 52, "observation size");
_Static_assert(sizeof(struct case_report) == 16 + CASE_COUNT * 52, "report size");

int main(void)
{
    permit405_guest_report.magic = 0x35434b50;
    permit405_guest_report.count = CASE_COUNT;
    for (size_t i = 0; i < CASE_COUNT; ++i) {
        const struct fixture *f = &cases[i];
        struct guarded_fields fields;
        unsigned char encode_buffer[48];
        unsigned char decode_buffer[46];
        unsigned char *destination = f->encode ? encode_buffer : (unsigned char *)&fields;
        for (size_t j = 0; j < 48; ++j)
            destination[j] = (unsigned char)(0x31 + j);
        /* The exposed frame begins between guard bytes in both directions. */
        decode_buffer[0] = 0x5a;
        for (size_t j = 0; j < sizeof(f->wire); ++j)
            decode_buffer[j + 1] = f->wire[j];
        decode_buffer[45] = 0xa5;
        int32_t status;
        if (f->encode) {
            status = jnox_permit_encode(f->fields, f->null_output ? NULL : encode_buffer + 2,
                                        f->length);
        } else {
            status = jnox_permit_decode(f->null_input ? NULL : decode_buffer + 1, f->length,
                                        f->null_output ? NULL : &fields.fields);
        }
        permit405_guest_report.observations[i].status = status;
        int passed = status == f->expected_status;
        for (size_t j = 0; j < 48; ++j) {
            permit405_guest_report.observations[i].destination[j] = destination[j];
            if (destination[j] != f->expected_destination[j])
                passed = 0;
        }
        if (!passed)
            ++permit405_guest_report.failed;
        permit405_guest_report.completed = (uint32_t)(i + 1);
    }
    return permit405_guest_report.failed != 0;
}
