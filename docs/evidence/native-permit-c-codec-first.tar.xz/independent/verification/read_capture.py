"""Read first-capture evidence from native_el0_capture.py using only stdlib and nm."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def symbol(path, name):
    listing = subprocess.check_output(["aarch64-linux-gnu-nm", "-nS", path], text=True)
    items = [line.split() for line in listing.splitlines() if line.endswith(" " + name)]
    need(len(items) == 1, f"missing or duplicate {name}")
    return tuple(int(n, 16) for n in items[0][:2])


def filebacked_segment(blob, addr, size):
    hdr = struct.unpack_from("<16sHHIQQQIHHHHHH", blob)
    need(hdr[0][:6] == b"\x7fELF\x02\x01" and hdr[1:3] == (2, 183), "AArch64 executable")
    segments = [struct.unpack_from("<IIQQQQQQ", blob, hdr[5] + i * hdr[9])
                for i in range(hdr[10])]
    matched = [off + addr - va for tag, _, off, va, _, filesz, _, _ in segments
               if tag == 1 and va <= addr and addr + size <= va + filesz]
    need(len(matched) == 1, "embedded ELF file segment")
    return blob[matched[0]:matched[0] + size]


parser = argparse.ArgumentParser()
parser.add_argument("capture", type=Path)
parser.add_argument("expected", type=Path)
parser.add_argument("source", type=Path)
parser.add_argument("revision")
parser.add_argument("session_sha256")
args = parser.parse_args()
cap = args.capture
cases = json.loads(args.expected.read_bytes())
session_raw = (cap/"session.json").read_bytes()
need(sha(session_raw) == args.session_sha256, "session digest")
session = json.loads(session_raw)
for name, digest in session["hashes"].items():
    need(sha((cap/name).read_bytes()) == digest, f"retained {name}")
launch = json.loads((cap/"launch.json").read_bytes())
pkg = launch["argument_package"]
need(launch["revision"] == pkg["commit"] == args.revision, "source revision")
need(pkg["app"] == "process" and pkg["board"] == "virt" and len(pkg["slots"]) == 1, "single process")
need(pkg["tracked_changes"] == "", "tracked source modifications")
user = (cap/"user.elf").read_bytes()
kernel = (cap/"kernel.elf").read_bytes()
need(sha(user) == launch["user_sha256"] == pkg["user_elf_sha256"]
     == pkg["slots"][0]["elf_sha256"] == pkg["input"]["sha256"], "packaged caller identity")
need(sha(kernel) == pkg["kernel_elf_sha256"] == launch["kernel_sha256"], "packaged kernel identity")
need(sha(args.source.read_bytes()) == launch["probe_sha256"] == sha((cap/"probe.c").read_bytes()),
     "capture source identity")
need((cap/"stderr").read_bytes().strip() in (b"",)
     or b"terminating on signal 15" in (cap/"stderr").read_bytes(), "unexpected QEMU stderr")
uart = (cap/"uart.bin").read_bytes().splitlines()
elf_events = [line for line in uart if b"NATIVE EL0 ELF " in line]
exits = [line for line in uart if b"NATIVE EL0 EXIT " in line]
need(elf_events == [b"NATIVE EL0 ELF "+sha(user).encode()] and exits == [b"NATIVE EL0 EXIT 0"]
     and uart.index(elf_events[0]) < uart.index(exits[0]) and not any(b"FAULT" in line for line in uart),
     "original UART load and exit")
need(session["marker"] == "EXIT 0", "captured exit")
mem = (cap/"ram.bin").read_bytes()
base = launch["ram_base"]
need(len(mem) == launch["ram_bytes"], "RAM extent")


def physical(address, size):
    index = address - base
    need(0 <= index <= len(mem) - size, "physical address")
    return mem[index:index+size]


image, extent = symbol(cap/"kernel.elf", "jnox_native_el0_image")
need(extent == len(user) and physical(image, extent) == filebacked_segment(kernel, image, extent)
     == user, "ELF bytes embedded in linked kernel and stopped RAM")
journal, extent = symbol(cap/"kernel.elf", "jnox_native_el0_journal")
header = struct.unpack("<16Q", physical(journal, 128))
need(header[:4] == (1, 3, 0, len(user)) and header[9:11] == (0, 1), "guest EXIT journal")
root = header[14] & 0x0000fffffffff000
report_va, report_len = symbol(cap/"user.elf", "permit405_guest_report")
need(report_len == 16+52*len(cases), "report symbol size")
remaining = report_len
address = report_va
parts = []
mappings = []
while remaining:
    page = root
    for shift in (30, 21, 12):
        entry = struct.unpack("<Q", physical(page + ((address >> shift) & 511)*8, 8))[0]
        need(entry & 3 == 3, f"table or page mapping {shift}")
        page = entry & 0x0000fffffffff000
    need((entry >> 6) & 3 == 1 and (entry >> 54) & 1 == 1, "private writable user page")
    offset = address & 4095
    count = min(4096-offset, remaining)
    parts.append(physical(page+offset, count))
    mappings.append(dict(va=hex(address), pa=hex(page+offset), length=count))
    address += count
    remaining -= count
report = b"".join(parts)
magic, declared, completed, failed = struct.unpack_from("<4I", report)
need((magic, declared, completed, failed) == (0x35434b50, len(cases), len(cases), 0),
     "guest report completion")
observations = []
for i, case in enumerate(cases):
    at = 16+52*i
    status, actual = struct.unpack_from("<i48s", report, at)
    need((status, actual.hex()) == (case["status"], case["expected_destination"]), case["name"])
    observations.append(dict(name=case["name"], status=status, destination=actual.hex()))
print(json.dumps(dict(revision=args.revision, sha256_user=sha(user), sha256_kernel=sha(kernel),
                      decoded_from=hex(report_va), source_page_table=hex(root), mappings=mappings,
                      original_uart=[s.decode("ascii") for s in uart], count=completed,
                      cases=observations), indent=2))
