#!/usr/bin/env bash
# Use a clean checkout, full revision and a new evidence directory.
set -euo pipefail
shared=$(cd "$(dirname "$0")" && pwd)
src=$(realpath "$1")
revision=$2
packet=$(realpath -m "$3")
[[ $revision =~ ^[0-9a-f]{40}$ ]]
cd "$src"
[[ $(git rev-parse HEAD) == "$revision" ]]
[[ -z $(git status --porcelain --untracked-files=no) ]]
export PATH="$HOME/.cargo/bin:$PATH" CARGO_NET_OFFLINE=true LC_ALL=C TZ=UTC PYTHONDONTWRITEBYTECODE=1
for variable in $(compgen -e JNOX_); do unset "$variable"; done
unset RUSTFLAGS CARGO_ENCODED_RUSTFLAGS CARGO_TARGET_DIR
mkdir "$packet"
mkdir "$packet/verification" "$packet/logs"
cp "$shared"/{make_vectors.py,expected.json,caller.c,fixtures.inc,read_capture.py,first.sh} "$packet/verification/"
(cd "$packet/verification" && sha256sum *.py *.c *.inc *.json *.sh) > "$packet/verification.sha256"
(date -u +%FT%T.%NZ; uname -a; clang --version; ld.lld --version; rustc -vV;
 cargo --version; qemu-system-aarch64 --version; git --version) > "$packet/logs/environment"
git rev-parse 'HEAD^{tree}' > "$packet/tree"
printf '%s\n' "$revision" > "$packet/revision"
git ls-tree -r "$revision" sdk/native-aarch64 sdk/native-safety-channel > "$packet/sdk-tree"
(
    set -x
    sh -x sdk/native-aarch64/build.sh --permit-codec "$packet/verification/caller.c" "$packet/caller.elf"
) > "$packet/logs/sdk-build" 2>&1
{
    aarch64-linux-gnu-readelf -h -l "$packet/caller.elf"
    aarch64-linux-gnu-nm -nSC "$packet/caller.elf"
} > "$packet/logs/caller-elf-layout"
aarch64-linux-gnu-objdump -dC "$packet/caller.elf" > "$packet/logs/caller-disassembly"
(
    set -x
    python3 tools/build_native_el0.py --out "$packet/package" --board virt --elf "$packet/caller.elf"
) > "$packet/logs/package" 2>&1
date -u +%FT%T.%NZ > "$packet/logs/first.start"
set +e
(
    set -x
    python3 tools/native_el0_capture.py "$packet/first" "$packet/package/kernel.elf" \
        "$packet/package/user.elf" "$packet/verification/caller.c" "$revision" --plain \
        --manifest "$packet/package/manifest.json" --expect-exit 0
) > "$packet/logs/capture" 2>&1
rc=$?
set -e
date -u +%FT%T.%NZ > "$packet/logs/first.finish"
printf '%s\n' "$rc" > "$packet/logs/capture.status"
[[ $rc == 0 ]]
session=$(sha256sum "$packet/first/session.json" | cut -c1-64)
printf '%s\n' "$session" > "$packet/session.sha256"
python3 "$packet/verification/read_capture.py" "$packet/first" "$packet/verification/expected.json" \
   "$packet/verification/caller.c" "$revision" "$session" > "$packet/observed.json"
sha256sum "$packet/observed.json"
