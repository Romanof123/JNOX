#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C PYTHONDONTWRITEBYTECODE=1
cd "$(dirname "$0")"
sha256sum --quiet -c SHA256SUMS
python3 - <<'PY'
import hashlib,json,struct
from pathlib import Path
for name,marker,perms in [('example','FAULT 5',[5,4]),('example-fixed','EXIT 0',[5,4,6]),('independent','EXIT 0',[5,4,6])]:
 cap=Path(name)/'first'
 session=json.loads((cap/'session.json').read_bytes())
 assert session['marker']==marker and ('NATIVE EL0 '+marker) in (cap/'uart.bin').read_text().splitlines()
 for leaf,digest in session['hashes'].items():
  assert hashlib.sha256((cap/leaf).read_bytes()).hexdigest()==digest
 elf=(cap/'user.elf').read_bytes()
 assert elf[:6]==b'\x7fELF\x02\x01'
 phoff,=struct.unpack_from('<Q',elf,32)
 ents,count=struct.unpack_from('<HH',elf,54)
 headers=[struct.unpack_from('<II',elf,phoff+i*ents) for i in range(count)]
 assert [flags for tag,flags in headers if tag==1]==perms
 print(name,marker,'PT_LOAD permissions',perms)
PY
(
 cd independent
 python3 -B verification/read_capture.py first verification/expected.json verification/caller.c "$(cat revision)" "$(cat session.sha256)" | cmp - observed.json
)
echo 'All 48 independent C caller records reproduced.'
