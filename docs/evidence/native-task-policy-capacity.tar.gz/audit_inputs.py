"""Verify distinct SDK binaries and all named executable symbols before examining limits."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

inputs = Path(sys.argv[1]).resolve()
expected = json.loads((inputs/'expected.json').read_text())
hashes = json.loads((inputs/'elf-hashes.json').read_text())
assert len(expected)==len(set(hashes.values()))==32
for app, tasks in expected.items():
    elf = inputs/f'{app}.elf'
    assert hashlib.sha256(elf.read_bytes()).hexdigest()==hashes[elf.name]
    nm = subprocess.check_output(['nm','--defined-only',str(elf)],text=True)
    table = {entry:int(addr,16) for addr,entry in re.findall(r'^([0-9a-f]+) T (\w+)$',nm,re.M)}
    header = subprocess.check_output(['readelf','-Whl',str(elf)],text=True)
    assert 'AArch64' in header and '0x400000' in header
    loads = re.findall(r'^\s+LOAD\s+0x\w+\s+0x(\w+)\s+0x\w+\s+0x(\w+)\s+0x\w+\s+(.+?)\s+0x\w+$',header,re.M)
    assert [f.strip() for _,_,f in loads]==['R E','R','RW']
    base,size = [int(v,16) for v in loads[0][:2]]
    addrs = [table[symbol] for _,symbol,_ in tasks]
    assert len(set(addrs))==len(tasks)
    assert all(v%4==0 and base<=v and v+4<=base+size for v in addrs)
    print(f'{app} {hashes[elf.name]} '+' '.join(f'{n}/{s}@{v:#x}={exit}' for (n,s,exit),v in zip(tasks,addrs)))
