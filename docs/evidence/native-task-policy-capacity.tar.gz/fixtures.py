#!/usr/bin/env python3
"""Create ordinary native SDK apps and well-formed deployment texts."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

src, dest = map(lambda s: Path(s).resolve(), sys.argv[1:])
dest.mkdir()
commands = []
inputs = {}
for n in [*range(1, 32), 0]:
    app = f"node{n:02}" if n else "stacks"
    tasks = [(f"work{n:02}", f"node{n:02}_entry", 50+n)] if n else [
        (f"slot{i:02}", f"stack{i:02}_entry", 100+i) for i in range(1, 32)]
    inputs[app] = tasks
    body = ['#include <jnox/task_policy.h>', f'static volatile unsigned completed[{len(tasks)}];', '']
    for i, (task, symbol, status) in enumerate(tasks):
        body.extend([f'void {symbol}(void)', '{', f'    completed[{i}] = 1;',
                     f'    if (jnox_task_complete() == 0 && completed[{i}] == 1)',
                     f'        (void)jnox_task_exit({status});',
                     '    (void)jnox_task_exit(199);', '}', ''])
    body.append(f'int main(void) {{ {tasks[0][1]}(); return 198; }}')
    source = dest / f'{app}.c'
    source.write_text('\n'.join(body)+'\n')
    cmd = ['sh', str(src/'sdk/native-aarch64/build.sh'), str(source), str(source.with_suffix('.elf'))]
    commands.append(cmd)
    subprocess.run(cmd, check=True)

for case, apps, limit in [('ram31', list(inputs)[:31], 1), ('ram30', list(inputs)[:30], 1),
                          ('stack31', ['stacks'], 31), ('stack30', ['stacks'], 30)]:
    rows = ['version 1']
    for app in apps:
        rows.append(f'app {app} {app}.elf')
        rows.extend(f'task {app} {task} {symbol} 500 120 500 off' for task, symbol, _ in inputs[app][:limit])
    (dest/f'{case}.txt').write_text('\n'.join(rows)+'\n')
(dest/'commands.json').write_text(json.dumps(commands, indent=2)+'\n')
(dest/'expected.json').write_text(json.dumps(inputs, indent=2)+'\n')
digests = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dest.glob('*.elf'))}
assert len(digests) == len(set(digests.values())) == 32
(dest/'elf-hashes.json').write_text(json.dumps(digests, indent=2)+'\n')
print(f'{len(digests)} distinct native ELF hashes, 4 deployment texts')
