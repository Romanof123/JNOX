#!/usr/bin/env bash
set -eu
src=$(realpath "$1")
out=$(realpath -m "$2")
packet=$(cd "$(dirname "$0")" && pwd)
test "$(git -C "$src" rev-parse HEAD)" = 002c47c1ad311ec347310662aa256011f4f5388f
test "$(git -C "$src" rev-parse 'HEAD^{tree}')" = cf7e7792da0c9dd12636c8b28daf711178e89c85
test -z "$(git -C "$src" status --porcelain)"
mkdir "$out"
mkdir "$out/stage" "$out/logs" "$out/packages"
export PYTHONDONTWRITEBYTECODE=1 PATH="$HOME/.cargo/bin:$PATH"
python3 "$packet/fixtures.py" "$src" "$out/inputs"
python3 "$packet/audit_inputs.py" "$out/inputs" > "$out/logs/all-inputs.txt"
diff -u "$packet/inputs/elf-hashes.json" "$out/inputs/elf-hashes.json"
for name in ram31 stack31 ram30 stack30; do
    python3 "$packet/package.py" "$src" "$out/inputs" "$out/stage/package" "$out/logs" "$name"
    case "$name" in
        ram30|stack30)
            python3 "$packet/boot.py" "$out/inputs" "$out/stage/package" "$out/logs" "$name"
            mv "$out/stage/package" "$out/packages/$name"
            ;;
    esac
done
test -z "$(git -C "$src" status --porcelain)"
