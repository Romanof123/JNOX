#include <jnox/task_policy.h>
static volatile unsigned completed[31];

void stack01_entry(void)
{
    completed[0] = 1;
    if (jnox_task_complete() == 0 && completed[0] == 1)
        (void)jnox_task_exit(101);
    (void)jnox_task_exit(199);
}

void stack02_entry(void)
{
    completed[1] = 1;
    if (jnox_task_complete() == 0 && completed[1] == 1)
        (void)jnox_task_exit(102);
    (void)jnox_task_exit(199);
}

void stack03_entry(void)
{
    completed[2] = 1;
    if (jnox_task_complete() == 0 && completed[2] == 1)
        (void)jnox_task_exit(103);
    (void)jnox_task_exit(199);
}

void stack04_entry(void)
{
    completed[3] = 1;
    if (jnox_task_complete() == 0 && completed[3] == 1)
        (void)jnox_task_exit(104);
    (void)jnox_task_exit(199);
}

void stack05_entry(void)
{
    completed[4] = 1;
    if (jnox_task_complete() == 0 && completed[4] == 1)
        (void)jnox_task_exit(105);
    (void)jnox_task_exit(199);
}

void stack06_entry(void)
{
    completed[5] = 1;
    if (jnox_task_complete() == 0 && completed[5] == 1)
        (void)jnox_task_exit(106);
    (void)jnox_task_exit(199);
}

void stack07_entry(void)
{
    completed[6] = 1;
    if (jnox_task_complete() == 0 && completed[6] == 1)
        (void)jnox_task_exit(107);
    (void)jnox_task_exit(199);
}

void stack08_entry(void)
{
    completed[7] = 1;
    if (jnox_task_complete() == 0 && completed[7] == 1)
        (void)jnox_task_exit(108);
    (void)jnox_task_exit(199);
}

void stack09_entry(void)
{
    completed[8] = 1;
    if (jnox_task_complete() == 0 && completed[8] == 1)
        (void)jnox_task_exit(109);
    (void)jnox_task_exit(199);
}

void stack10_entry(void)
{
    completed[9] = 1;
    if (jnox_task_complete() == 0 && completed[9] == 1)
        (void)jnox_task_exit(110);
    (void)jnox_task_exit(199);
}

void stack11_entry(void)
{
    completed[10] = 1;
    if (jnox_task_complete() == 0 && completed[10] == 1)
        (void)jnox_task_exit(111);
    (void)jnox_task_exit(199);
}

void stack12_entry(void)
{
    completed[11] = 1;
    if (jnox_task_complete() == 0 && completed[11] == 1)
        (void)jnox_task_exit(112);
    (void)jnox_task_exit(199);
}

void stack13_entry(void)
{
    completed[12] = 1;
    if (jnox_task_complete() == 0 && completed[12] == 1)
        (void)jnox_task_exit(113);
    (void)jnox_task_exit(199);
}

void stack14_entry(void)
{
    completed[13] = 1;
    if (jnox_task_complete() == 0 && completed[13] == 1)
        (void)jnox_task_exit(114);
    (void)jnox_task_exit(199);
}

void stack15_entry(void)
{
    completed[14] = 1;
    if (jnox_task_complete() == 0 && completed[14] == 1)
        (void)jnox_task_exit(115);
    (void)jnox_task_exit(199);
}

void stack16_entry(void)
{
    completed[15] = 1;
    if (jnox_task_complete() == 0 && completed[15] == 1)
        (void)jnox_task_exit(116);
    (void)jnox_task_exit(199);
}

void stack17_entry(void)
{
    completed[16] = 1;
    if (jnox_task_complete() == 0 && completed[16] == 1)
        (void)jnox_task_exit(117);
    (void)jnox_task_exit(199);
}

void stack18_entry(void)
{
    completed[17] = 1;
    if (jnox_task_complete() == 0 && completed[17] == 1)
        (void)jnox_task_exit(118);
    (void)jnox_task_exit(199);
}

void stack19_entry(void)
{
    completed[18] = 1;
    if (jnox_task_complete() == 0 && completed[18] == 1)
        (void)jnox_task_exit(119);
    (void)jnox_task_exit(199);
}

void stack20_entry(void)
{
    completed[19] = 1;
    if (jnox_task_complete() == 0 && completed[19] == 1)
        (void)jnox_task_exit(120);
    (void)jnox_task_exit(199);
}

void stack21_entry(void)
{
    completed[20] = 1;
    if (jnox_task_complete() == 0 && completed[20] == 1)
        (void)jnox_task_exit(121);
    (void)jnox_task_exit(199);
}

void stack22_entry(void)
{
    completed[21] = 1;
    if (jnox_task_complete() == 0 && completed[21] == 1)
        (void)jnox_task_exit(122);
    (void)jnox_task_exit(199);
}

void stack23_entry(void)
{
    completed[22] = 1;
    if (jnox_task_complete() == 0 && completed[22] == 1)
        (void)jnox_task_exit(123);
    (void)jnox_task_exit(199);
}

void stack24_entry(void)
{
    completed[23] = 1;
    if (jnox_task_complete() == 0 && completed[23] == 1)
        (void)jnox_task_exit(124);
    (void)jnox_task_exit(199);
}

void stack25_entry(void)
{
    completed[24] = 1;
    if (jnox_task_complete() == 0 && completed[24] == 1)
        (void)jnox_task_exit(125);
    (void)jnox_task_exit(199);
}

void stack26_entry(void)
{
    completed[25] = 1;
    if (jnox_task_complete() == 0 && completed[25] == 1)
        (void)jnox_task_exit(126);
    (void)jnox_task_exit(199);
}

void stack27_entry(void)
{
    completed[26] = 1;
    if (jnox_task_complete() == 0 && completed[26] == 1)
        (void)jnox_task_exit(127);
    (void)jnox_task_exit(199);
}

void stack28_entry(void)
{
    completed[27] = 1;
    if (jnox_task_complete() == 0 && completed[27] == 1)
        (void)jnox_task_exit(128);
    (void)jnox_task_exit(199);
}

void stack29_entry(void)
{
    completed[28] = 1;
    if (jnox_task_complete() == 0 && completed[28] == 1)
        (void)jnox_task_exit(129);
    (void)jnox_task_exit(199);
}

void stack30_entry(void)
{
    completed[29] = 1;
    if (jnox_task_complete() == 0 && completed[29] == 1)
        (void)jnox_task_exit(130);
    (void)jnox_task_exit(199);
}

void stack31_entry(void)
{
    completed[30] = 1;
    if (jnox_task_complete() == 0 && completed[30] == 1)
        (void)jnox_task_exit(131);
    (void)jnox_task_exit(199);
}

int main(void) { stack01_entry(); return 198; }
