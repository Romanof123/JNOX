#include <jnox/task_policy.h>
static volatile unsigned completed[1];

void node05_entry(void)
{
    completed[0] = 1;
    if (jnox_task_complete() == 0 && completed[0] == 1)
        (void)jnox_task_exit(55);
    (void)jnox_task_exit(199);
}

int main(void) { node05_entry(); return 198; }
