#include <jnox/task_policy.h>
static volatile unsigned completed[1];

void node11_entry(void)
{
    completed[0] = 1;
    if (jnox_task_complete() == 0 && completed[0] == 1)
        (void)jnox_task_exit(61);
    (void)jnox_task_exit(199);
}

int main(void) { node11_entry(); return 198; }
