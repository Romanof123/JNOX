"""Run the public text packager and record publication and content identity."""
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

src, inputs, out, log = map(lambda p: Path(p).resolve(), sys.argv[1:5])
case = sys.argv[5]
log.mkdir(exist_ok=True)
policy = inputs/f'{case}.txt'
digest = lambda data: hashlib.sha256(data).hexdigest()
wanted = {'ram31':'policy exceeds virt RAM', 'stack31':'policy count exceeds ASID or stack layout'}.get(case)
assert not out.exists()
siblings = sorted(p.name for p in out.parent.iterdir())
args = ['python3', 'tools/build_native_el0.py', '--board', 'virt', '--task-policy', str(policy), '--out', str(out)]
result = subprocess.run(args, cwd=src, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=630)
(log/f'{case}.log').write_bytes(result.stdout)
record = dict(argv=args, cwd=str(src), source_sha256=digest(policy.read_bytes()), exit_code=result.returncode,
              output=str(out), output_before=False, output_after=out.exists())
(log/f'{case}.json').write_text(json.dumps(record, indent=2)+'\n')
print(shlex.join(args), 'rc=', result.returncode, 'output_after=', out.exists(), flush=True)
if wanted:
    lines = [line.strip() for line in result.stdout.decode().splitlines() if wanted in line]
    assert result.returncode == 2 and not out.exists() and len(lines)==1, (wanted,lines)
    assert sorted(p.name for p in out.parent.iterdir())==siblings
    record.update(diagnostic=lines[0], unchanged_output_parent=True)
    print(lines[0], flush=True)
else:
    assert result.returncode == 0 and out.is_dir()
    manifest = json.loads((out/'manifest.json').read_bytes())
    assert manifest['commit'] == '002c47c1ad311ec347310662aa256011f4f5388f' and manifest['tracked_changes']==''
    assert manifest['source_sha256']==record['source_sha256']
    image = (out/'kernel.elf').read_bytes()
    binary = (out/'policy.bin').read_bytes()
    assert manifest['policy_sha256']==digest(binary) and manifest['kernel_elf_sha256']==digest(image)
    assert image.count(binary)==1
    expected = json.loads((inputs/'expected.json').read_text())
    rows = [s.split() for s in policy.read_text().splitlines()[1:]]
    apps = [r[1] for r in rows if r[0]=='app']
    tasks = [(r[1],r[2],r[3]) for r in rows if r[0]=='task']
    assert [a['name'] for a in manifest['apps']]==apps
    assert [(a['name'],t['name'],t['symbol']) for a in manifest['apps'] for t in a['tasks']]==tasks
    assert len(apps)==(30 if case=='ram30' else 1) and len(tasks)==30
    for app in manifest['apps']:
        path = inputs/app['path']
        elf = path.read_bytes()
        assert app['elf_sha256']==digest(elf)
        assert binary[app['elf_offset']:app['elf_offset']+app['elf_size']]==elf
        symbols = {line.split()[-1]:int(line.split()[0],16) for line in subprocess.check_output(
            ['nm','--defined-only',str(path)],text=True).splitlines() if len(line.split())==3 and line.split()[1]=='T'}
        assert all(t['entry']==symbols[t['symbol']] for t in app['tasks'])
    record.update(kernel_sha256=digest(image), policy_sha256=digest(binary), manifest_sha256=digest((out/'manifest.json').read_bytes()),
                  embedded_policy_occurrences=1, apps=len(apps), tasks=len(tasks))
    print('verified manifest, linked policy and embedded app bytes', record['kernel_sha256'], flush=True)
(log/f'{case}.json').write_text(json.dumps(record, indent=2)+'\n')
