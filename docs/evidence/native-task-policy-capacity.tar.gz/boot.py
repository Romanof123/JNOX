"""Boot one accepted package. Match guest-observed names and statuses against source fixtures."""
import json
from pathlib import Path
import re
import shlex
import socket
import subprocess
import sys
import time

inputs, package, log = map(lambda p: Path(p).resolve(), sys.argv[1:4])
case = sys.argv[4]
expected = json.loads((inputs/'expected.json').read_text())
rows = [line.split() for line in (inputs/f'{case}.txt').read_text().splitlines()]
wanted = {(app,task):status for kind, *row in rows if kind=='task'
          for app,declared in [row[:2]] for task,_,status in expected[app] if declared==task}
assert len(wanted)==30
qmp = log/f'{case}.sock'
uart = log/f'{case}.uart'
cmd = ['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1',
       '-accel','tcg','-m','128M','-nodefaults','-display','none','-serial','mon:stdio',
       '-nic','none','-no-reboot','-kernel',str(package/'kernel.elf'),
       '-qmp',f'unix:{qmp},server=on,wait=off']
(log/f'{case}.qemu.json').write_text(json.dumps(cmd,indent=2)+'\n')
with uart.open('xb') as output, (log/f'{case}.qemu-stderr').open('xb') as err:
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=output, stderr=err)
    try:
        until = time.monotonic()+35
        while b'JNOX POLICY DONE\n' not in uart.read_bytes().replace(b'\r',b''):
            if proc.poll() is not None or time.monotonic()>until:
                raise RuntimeError(f'{case}: no DONE, QEMU rc={proc.poll()}')
            time.sleep(.025)
        with socket.socket(socket.AF_UNIX) as sock:
            sock.settimeout(3)
            sock.connect(str(qmp))
            stream = sock.makefile('rwb',buffering=0)
            greeting = json.loads(stream.readline())
            observations = {}
            def query(name, **args):
                stream.write((json.dumps(dict(execute=name,arguments=args))+'\n').encode())
                while True:
                    answer = json.loads(stream.readline())
                    if 'return' in answer: return answer['return']
                    if 'error' in answer: raise RuntimeError(answer)
            query('qmp_capabilities')
            observations['version'] = greeting['QMP']['version']
            observations['cpus'] = query('query-cpus-fast')
            observations['gic_version'] = query('qom-get',path='/machine',property='gic-version')
            observations['memory'] = query('query-memory-size-summary')
            (log/f'{case}.machine.json').write_text(json.dumps(observations,indent=2)+'\n')
            assert len(observations['cpus'])==1 and observations['cpus'][0]['cpu-index']==0
            assert str(observations['gic_version'])=='2'
            assert observations['memory']['base-memory']==128*1024*1024
            query('quit')
        assert proc.wait(timeout=5)==0
    finally:
        if proc.poll() is None:
            proc.terminate()
            proc.wait(timeout=5)

events = {}
lines = uart.read_text().splitlines()
assert lines.count('JNOX M1 READY')==lines.count('JNOX POLICY DONE')==1
for line in lines:
    match = re.fullmatch(r'JNOX POLICY (\w+) app=(\w+) task=(\w+) (.+)',line)
    if match:
        event, app, task, detail = match.groups()
        events.setdefault((app,task),[]).append((event,dict(item.split('=',1) for item in detail.split())))
assert set(events)==set(wanted)
reports = []
for (app, task), status in wanted.items():
    records = events[app,task]
    assert [e for e,_ in records]==['RELEASE','START','COMPLETE','RELEASE','START','EXIT','SUMMARY'], (app,task,records)
    summary = records[-1][1]
    expected_counts=dict(releases=2, starts=2, completes=1, misses=0, watchdogs=0, faults=0, exits=1)
    assert all(int(summary[k])==v for k,v in expected_counts.items())
    assert int(records[-2][1]['status'])==status and records[-2][1]['source']=='svc'
    reports.append(dict(app=app,task=task,exit_status=status,**expected_counts))
(log/f'{case}.verified.json').write_text(json.dumps(reports,indent=2)+'\n')
print(case, 'observed expected exit status and healthy summary for all',len(wanted),'tasks; CPUs=1 GIC=2 RAM=128 MiB')
