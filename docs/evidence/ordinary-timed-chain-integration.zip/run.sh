set -eu
repo=/mnt/d/codex/jnox-236-integration-06fbc19
out=/mnt/d/codex/jnox236-merge-raw
exec 3>"$out/commands.log"
export BASH_XTRACEFD=3
set -x

export PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR=$HOME/jnox236-merge-target
cd "$repo/kernel"
(rustc -vV; cargo -V; qemu-system-aarch64 --version; uname -a) > "$out/versions"
for app in ordinary-chain ordinary-pi ordinary-ceiling; do
 d=$out/$app
 mkdir "$d"
 JNOX_BOARD=virt JNOX_PROFILE=mutex JNOX_APP="$app" cargo build --locked --release -j1 > "$d/build.log" 2>&1
 cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" "$d/kernel.elf"
 aarch64-linux-gnu-objdump -d "$d/kernel.elf" > "$d/linked.asm"
 for mode in plain trace; do
 opts=()
 if [ "$mode" = trace ]; then opts=(-d int -D "$d/exceptions.log"); fi
 rc=0
 timeout -k 2s 15s qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -smp 1 -accel tcg -m 128M -nodefaults -display none -monitor none -serial stdio "${opts[@]}" -kernel "$d/kernel.elf" </dev/null >"$d/$mode.uart" 2>"$d/$mode.stderr" || rc=$?
 echo "$rc" > "$d/$mode.rc"
 done
done
cd "$repo"
rustc --edition=2021 --test tools/scheduling_tests.rs -o "$HOME/jnox236-merge-host" > "$out/host-build.log" 2>&1
"$HOME/jnox236-merge-host" --test-threads=1 > "$out/host.log"