set -u
repo=/mnt/d/codex/jnox-236-integration-06fbc19
out=/mnt/d/codex/jnox236-merge-raw
exec 3>"$out/check-commands.log"
export BASH_XTRACEFD=3
set -x
export PATH=$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR=$HOME/jnox236-merge-target PYTHONDONTWRITEBYTECODE=1
cd "$repo/kernel"
for spec in fixed:ordinary-chain mutex:fixed-fifo mutex:ordinary-chain:rust-prepared none:ordinary-chain; do
 IFS=: read -r profile app anchor <<<"$spec"
 args=(JNOX_BOARD=virt JNOX_APP="$app")
 if [[ $profile != none ]]; then args+=(JNOX_PROFILE="$profile"); fi
 if [[ -n $anchor ]]; then args+=(JNOX_MUTEX_ANCHOR="$anchor"); fi
 rc=0; env "${args[@]}" cargo build --locked --release -j1 >"$out/negative-$profile-$app.log" 2>&1 || rc=$?
 echo "$profile/$app/$anchor $rc" >>"$out/negative-status"
done
cd "$repo"
python3 "$out/check.py" >"$out/replay.log" 2>&1; echo $? >"$out/replay.rc"
python3 tools/requirement_graph.py >"$out/graph.log" 2>&1; echo $? >"$out/graph.rc"
python3 tools/scheduling_evidence.py >"$out/matrix.json"; echo $? >"$out/matrix.rc"
cd tools
python3 -m unittest -v test_mutex_anchor_replay test_scheduling_evidence test_requirement_graph test_build_kernel >"$out/scoped.log" 2>&1; echo $? >"$out/scoped.rc"