from pathlib import Path
import json,sys,subprocess,shutil,hashlib
d,r=map(Path,sys.argv[1:]); p=r/'controls-copy';shutil.copytree(r/'fifo-healthy',p,dirs_exist_ok=True)
def run(name,args=[]):
 v=subprocess.run([sys.executable,str(d/'check.py'),str(p),*args],capture_output=True,text=True)
 (d/(name+'.json')).write_text(v.stdout)
 return [name,v.returncode,json.loads(v.stdout).get('input_error'),json.loads(v.stdout).get('missing',[])[:1]]
results=[]
s=(p/'cap/user.elf');blob=s.read_bytes();s.write_bytes(blob+b'Q');results.append(run('stale-slot-elf'));s.write_bytes(blob)
u=p/'cap/uart.bin';blob=u.read_bytes();u.write_bytes(blob+b'Q');results.append(run('stale-uart'));u.write_bytes(blob)
arg=p/'bounds.json';arg.write_text(json.dumps({'kernel_sha256':'0'*64,'policy':'fifo','bounds':{}}));results.append(run('wrong-bound-kernel',['--bounds',str(arg)]))
(d/'controls-receipt.json').write_text(json.dumps(results,indent=1))