from pathlib import Path
import tempfile,subprocess as s,shutil,json,hashlib
r=Path('/mnt/d/codex/.jnox-work/next-fixed')
o=r/'partition-notice-fresh'
t=Path(tempfile.mkdtemp(prefix='jnox-notices-'))
(o/'linux-temp').write_text(str(t))
b=r/'partition-final-builds/127'
idx=b/'index.json'
assert hashlib.sha256(idx.read_bytes()).hexdigest()=='cca2363fbf5a94cf60f091560923a3aebe637e8e46c77d3a85b897b0c374ac64'
shutil.copy(idx,o/'build-index.json')
for table in 'PQ':
 for mode in ['short','long']:
  name=table+'-'+mode
  row=json.loads(idx.read_text())['images']['ordinary-partition-'+table.lower()+'-'+mode]
  elf=t/(name+'.elf');shutil.copy(b/row['path'],elf)
  cmd=['sh',str(r/'notice-integrated-src/tools/capture_partition_notice.sh'),table,mode,str(elf),row['sha256'],str(t/name)]
  p=s.run(cmd,cwd=t,capture_output=True)
  (t/name/'wrapper-status').write_text(str(p.returncode))
  (t/name/'wrapper-stderr').write_bytes(p.stderr)
  shutil.copytree(t/name,o/name)
  print(name,p.returncode,p.stderr.decode(),flush=True)
