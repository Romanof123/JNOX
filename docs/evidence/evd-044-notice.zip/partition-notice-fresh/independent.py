from pathlib import Path
import re,json,subprocess as s
from collections import Counter
o=Path(__file__).resolve().parent
def audit(t,mode,d):
 rows={}
 for line in (d/'uart').read_text().splitlines():
  if line.startswith('OP '):
   _,k,*fields=line.split();rows.setdefault(k,[]).append({a:int(b) if b.isdecimal() else b for a,b in (f.split('=') for f in fields)})
 h=rows['HEADER'][0];E=h['epoch'];q=h['q'];F=h['freq'];assert F%1000==0 and q==F//20
 layout=[(0,2),(1,1),(2,1)] if t=='P' else [(1,1),(2,1),(0,2),(1,1)]
 windows=[];tick=0
 for frame in range(4):
  for own,n in layout:
   windows.append((E+q*tick,E+q*(tick+n),own,2 if own==1 and tick<(3 if t=='P' else 1) else own));tick+=n
 edges=rows['EDGE'];ws=[next(w for w in windows if w[0]<=e['live']<w[1]) for e in edges];assert ws[-1]==windows[3*len(layout)];obs=rows['OBS'];tim=rows['TIMER'];stop=rows['STOP'][0];assert len(ws)==len(edges)==len(tim)==len(obs)==h['n']
 tr=(d/'exceptions.log').read_text();returns=[int(n,16) for n in re.findall(r'Exception return .*? PC 0x(\w+)',tr)];elrs=[int(n,16) for n in re.findall(r'with ELR 0x(\w+)',tr)]
 assert returns==[r['in_pc'] for r in edges] and elrs==[r['out_pc'] for r in edges[1:]+[stop]] and tr.count('Taking exception')==len(ws)
 syms=re.findall(r'^([0-9a-f]+) <([^>]+)>:',(d/'disassembly').read_text(),re.M)
 spans={name:(int(addr,16),int(syms[i+1][0],16)) for i,(addr,name) in enumerate(syms[:-1]) if name in ['ordinary_a','ordinary_b','ordinary_idle']}
 stacks=rows['STACK'];assert all(r['hi']-r['lo']==16384 for r in stacks) and all(a['hi']<=b['lo'] for a,b in zip(stacks,stacks[1:]))
 assert all(0<r['n']<len(edges) for r in rows['BOUND'])
 saved={};state={};segs=[];details=[]
 for i,((a,b,own,task),edge,x,c,out) in enumerate(zip(ws,edges,obs,tim,edges[1:]+[stop])):
  assert c['n']==edge['n']==x['n']==i and edge['owner']==own and edge['chosen']==x['task']==out['from']==task
  due=(ws[i-1][1] if i else E);assert due==edge['due'] and b==edge['next']==c['d']==out['due']
  assert a<=edge['live']<=c['p']<=c['after']<=edge['ret']<=x['x']<=out['last']<=out['entry'] and x['x']<b<=out['entry']
  target=(0 if t=='P' else 2)
  delay=0 if i!=target or mode=='healthy' else (F//1000+1 if mode=='short' else 5*q//4)
  assert c['c']==b+delay
  if mode!='healthy':
   irq=rows['IRQ'][i]
   assert irq['n']==i+1 and irq['iar']==30 and irq['c']==c['c']<=out['entry'] and irq['ctl']==5 and irq['spsr']&128==0
   cur=next(w for w in windows if w[0]<=out['entry']<w[1])
   assert irq['end']==(cur[1]-E)//q
   if delay:
    assert task==0 and c['after']<edge['ret']<b<c['c']<=out['entry']
    assert cur[0]<irq['prior_a']<out['last']<=out['entry']
    recovery_i=i+1
    assert windows.index(cur)==windows.index((a,b,own,task))+(2 if mode=='long' else 1)
  if i:
   assert [v for v in rows['BOUND'] if v['n']==i]==[dict(n=i,tick=(lo-E)//q,end=(hi-E)//q,owner=no,runnable=el,skipped=int(hi<=edge['live'])) for lo,hi,no,el in windows if due<=lo<=edge['live']]
   assert edge['entry']<=edge['live'] and a<=edge['entry']<b
  else:assert edge['from']==3 and edge['entry']==0
  pc0,pc1=spans[['ordinary_a','ordinary_b','ordinary_idle'][task]];assert pc0<=out['out_pc']<pc1
  if task in saved:assert saved[task]==tuple(edge['in_'+k] for k in ('pc','sp','hash'))
  else:assert edge['in_pc']==pc0
  saved[task]=tuple(out['out_'+k] for k in ('pc','sp','hash'))
  for sp in (edge['in_sp'],x['sp'],out['out_sp']): assert stacks[task]['lo']<sp<=stacks[task]['hi'] and sp%16==0
  step=[17,31,1][task];count,v,old=state.get(task,(0,step,0));assert x['count']>=old and out['out_count']>x['count']
  mask=2**64-1
  for _ in range(x['count']-count):v=(((v<<7)|(v>>57))+step)&mask
  assert v==x['value'];state[task]=(x['count'],v,out['out_count'])
  for l,r,who in [(edge['entry'] or E,edge['ret'],'kernel'),(edge['ret'],x['x'],'uncertain'),(x['x'],out['last'],str(task)),(out['last'],out['entry'],'uncertain')]:
   for lo,hi,no,eligible in windows:
    if min(r,hi)>max(l,lo):segs.append((max(l,lo),min(r,hi),who,no,eligible))
  details.append(dict(n=i,nominal=due,entry=edge['entry'],live=edge['live'],ret=edge['ret'],x=x['x'],ticks=x['x']-due,within=x['x']-due<=F//1000,task=task))
 totals=Counter();spill=Counter()
 for l,r,k,no,eligible in segs:
  totals[k]+=r-l
  if k in '012' and int(k)!=eligible:spill[str(eligible)]+=r-l
 assert segs[0][0]==E and segs[-1][1]==stop['entry'] and all(a[1]==b[0] for a,b in zip(segs,segs[1:]))
 extra={}
 if mode!='healthy':
  vector=int(next(v for v,nm in syms if nm=='sched_vectors'),16)+0x280
  assert [int(v,16) for v in re.findall(r'to EL1 PC 0x([a-f0-9]+) PSTATE',tr)]==[vector]*len(ws)
  n=recovery_i; due=edges[n]['due'];c=tim[n-1]['c'];entry=edges[n]['entry'];x=obs[n]['x'];k=windows.index(ws[n])
  rel=rows['RELEASE'][0];rn=rel['n'];assert rel['due']==E+q*(3 if t=='P' else 1) and edges[rn]['entry']<=rel['before']<=rel['after']<=edges[rn]['ret'] and rel['due']<=rel['before']
  assert ws[n:n+3]==windows[k:k+3] and obs[n]['task']==(2 if t=='P' else 1) and x-due>F//1000
  loss=[dict(start=l,end=r,owner=no,displaced=el,ticks=r-l) for l,r,k2,no,el in segs if k2=='0' and due<=l<entry]
  assert len(loss)==(2 if mode=='long' else 1) and all(v['displaced']==(2 if t=='P' else 1) for v in loss)
  extra=dict(controlled_generation=n,compare_delay=c-due,entry_after_compare=entry-c,observation_after_entry=x-entry,original_latency=x-due,prior_a=rows['IRQ'][n-1]['prior_a'],last_a=edges[n]['last'],recovered_task=ws[n][3],lost_windows=loss,protected=details[n+1:n+3],release=rel,unrelated_late=[v['n'] for v in details if not v['within'] and v['n']!=n])
 return dict(extra=extra,table=t,frequency=F,limit=F//1000,elapsed=stop['entry']-E,totals=totals,measured_spill_by_displaced_eligible=spill,edges=details,segments=segs,first_b_selection=next(v['live'] for v in details if v['task']==1),release=E+q*(3 if t=='P' else 1),symbol_ranges=spans)

for t in 'PQ':
 for mode in ['short','long','healthy']:
  d=o/(('127-ordinary-partition-'+t.lower()) if mode=='healthy' else t+'-'+mode)
  if mode=='healthy':
   digest=json.loads((d/'execution.json').read_text())['elf_sha256']
   p=s.run(['python3',str(o.parent/'notice-integrated-src/tools/ordinary_partition_account.py'),'uart','--table',t,'--case','healthy','--origin','guest','--elf','kernel.elf','--elf-sha256',digest,'--exceptions','exceptions.log'],cwd=d,capture_output=True)
   (d/'score.json').write_bytes(p.stdout);(d/'score-stderr').write_bytes(p.stderr);(d/'score-status').write_text(str(p.returncode))
  res=audit(t,mode,d)
  (d/'independent.json').write_text(json.dumps(res,indent=2))
  print(t,mode,[v['n'] for v in res['edges'] if not v['within']],flush=True)
