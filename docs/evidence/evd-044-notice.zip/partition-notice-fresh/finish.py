from pathlib import Path
import json,hashlib,re,subprocess as s
o=Path(__file__).resolve().parent
names=['A','B','idle']
report=['# First cold controlled timer notifications, #127','', 'Producer 9ffd653d906b26fcb30e272295c0b43b9acf4839. Four first boots in P-short, P-long, Q-short, Q-long order. Native Linux temporary ELFs, UART and IRQ traces, one Cortex-A72 QEMU at a time, default virtual clock. No recapture. All times below are counter ticks at 62,500,000 Hz (1 ms = 62,500 ticks).','', '| Case | compare − due | entry − compare | observation − entry | original delay | confirmed A spill per window | recovery | next two | unrelated late edges |','|---|---:|---:|---:|---:|---|---|---|---|']
for t in 'PQ':
 for m in ['short','long']:
  d=o/(t+'-'+m);r=json.loads((d/'independent.json').read_text());a=r['extra'];j=json.loads((d/'score.json').read_text());assert int((d/'score-status').read_text())==0 and j['controlled_case_met'] and not j['timing_envelope_met'] and not a['unrelated_late']
  dis=(d/'disassembly').read_text()
  worker=dis.split('<ordinary_a>:')[1].split('<ordinary_b>:')[0]
  assert re.search(r'mov\s+x0, x8.*?mrs\s+x8, CNTPCT_EL0.*?stlr\s+x8, \[x11\].*?stlr\s+x0, \[x12\]',worker,re.S)
  assert re.search(r'mrs\s+x\d+, CNTP_CVAL_EL0.*?mrs\s+x\d+, CNTP_CTL_EL0.*?msr\s+CNTP_CTL_EL0',dis,re.S)
  assert [e['ticks'] for e in a['lost_windows']]==[v['ticks'] for v in j['first_a_close']['measured_a_spill_by_window']]
  loss=', '.join(names[v['owner']]+' → '+names[v['displaced']]+' '+str(v['ticks']) for v in a['lost_windows'])
  report.append('| '+' | '.join(map(str,[d.name,a['compare_delay'],a['entry_after_compare'],a['observation_after_entry'],a['original_latency'],loss,names[a['recovered_task']],', '.join(names[v['task']] for v in a['protected']), 'none']))+' |')
report+=['','The loss column gives nominal owner → displaced eligible recipient. The interval between A’s last sample and IRQ entry remains uncertain. All four intentional original-envelope failures recovered. Each capture reached the original frame-four dispatch with no later unrelated timing failure. The independent replay reconstructed direct return PCs, all IRQ ELRs including STOP, the vector, private stacks, worker recurrence, two distinct A samples and release brackets from raw inputs. ELF disassembly shows the previous counter sample copied before the next read and separate current/previous stores. IRQ rows identify PPI 30 and active CNTP_CVAL_EL0, with timer control value 5 and unmasked interrupted PSTATE. This is emulated timer programming. Live worker masking and physical latency remain unmeasured.','']
for t in 'PQ':
 d=o/('127-ordinary-partition-'+t.lower());r=json.loads((d/'independent.json').read_text());assert int((d/'score-status').read_text())==0 and all(x['within'] for x in r['edges'])
 report.append(f"Passive #127 {t}: {len(r['edges'])}/{len(r['edges'])} within 1 ms, maximum {max(x['ticks'] for x in r['edges'])} ticks.")
for case in ['partition-bench','partition-legacy-diag','partition-legacy-diag-negative']:
 d=o/('112-'+case);u=(d/'uart').read_text().splitlines();tr=(d/'exceptions.log').read_text();irq=tr.count('Taking exception 5 [IRQ]');returns=tr.count('Exception return');assert json.loads((d/'execution.json').read_text())['uart_stable']
 if case.endswith('negative'):
  assert irq==0 and returns==1 and u[-1]=='PART FAIL'
  v=[int(n,16) for n in u[-2].split()[2:]];assert v[:7]==[99,0,1,2**64-1,0,0,2] and v[7]>0 and v[8]==0
 else:
  assert irq==6==returns and u==['JNOX M1 BOOT','JNOX M1 READY','PART A FIRST','PART IDLE FIRST','PART B READY','PART A RESUMED','PART B FIRST','PART IDLE RESUMED','PART STOP','PART PASS'] and tr.count('...to EL1 PC 0x40200a80')==6
 report.append(f"Legacy #112 {case}: {u[-1]}, IRQs {irq}, returns {returns}."+(' Expected guard 99.' if case.endswith('negative') else ''))
(o/'report.md').write_text('\n'.join(report)+'\n')
(o/'sha256sums').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(o).as_posix()+'\n' for f in sorted(o.rglob('*')) if f.is_file() and f.name!='sha256sums'))
