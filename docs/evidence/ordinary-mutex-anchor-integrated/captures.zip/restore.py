from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
for name,(original,public) in json.loads((root/'index.json').read_bytes()).items():
 target=root/'restored'/name
 target.resolve().relative_to((root/'restored').resolve())
 b=(root/'objects'/public).read_bytes()
 assert hashlib.sha256(b).hexdigest()==public
 target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('xb') as f:f.write(b)
