import sys,io,tempfile,json,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path(r'D:/codex/pi391-verify-6b39b22964ed44be981042ebfaaeeb57')
sys.path.insert(0,str(root/'tools'))
import test_pi4_native_serial_replay as t
import pi4_serial_capture as c
out=Path(__file__).parent
T=t.NativeReplayTests; T.setUpClass()
class Port(io.BytesIO):
 def reset_input_buffer(self): pass
 def read(self,n):
  if self.tell()>=62 and broken: raise OSError('simulated USB disconnect')
  return super().read(min(n,31))
with tempfile.TemporaryDirectory() as tmp:
 obj=T(); obj.folder=Path(tmp); obj.runs=0
 for policy in ('rr','fifo'):
  pkg=obj.stage(policy); inputs=[obj.uart[policy+'-'+k] for k in ('plain','traced')]
  import shutil
  path=obj.replay(pkg,'pi4-native-'+policy,inputs,0)
  shutil.copytree(path,out/('file-'+policy))
  for broken in ((True,False) if policy=='rr' else (False,)):
   folder=out/('SIMULATED-port-'+policy+('-disconnect' if broken else ''))
   args=['collector','--port','SIMULATED','--profile','pi4-native-'+policy,'--board-revision','SIMULATED','--eeprom','SIMULATED','--elf',str(pkg/'kernel.elf'),'--boot-dir',str(pkg.parent/('boot-'+policy)),'--native-manifest',str(pkg/'manifest.json'),'--output',str(folder)]
   with patch.object(sys,'argv',args),patch('builtins.input',return_value=''),patch.object(c,'serial_port',side_effect=[Port(x) for x in inputs]):
    rc=c.main()
   print(folder.name,rc,(folder/'run-1/uart.bin').stat().st_size,'result?',(folder/'run-1/result.json').exists(),flush=True)
   if not broken:
    assert rc==0 and all((folder/f'run-{i}/uart.bin').read_bytes()==v for i,v in enumerate(inputs,1))
