#[path = "waitset_ipc.rs"] mod waitset;
use waitset::{Completion, Levels, WaitsetIpc};

fn main() {
    let mut w = WaitsetIpc::<2>::new();
    let empty = Levels::default();
    let ready = Levels { events: 0xb, ..empty };
    let peer = w.attach(1, 1, 3, 0x2).unwrap();
    for also_complete in [false, true] {
        let own = w.attach(0, 0, 3, 0x9).unwrap();
        assert_eq!(w.detach(1, own), Err(-13));
        w.wait(0, 50, 10, empty).unwrap();
        if also_complete {
            w.refresh(0, 49, ready);
            assert!(!w.blocked(0));
        }
        w.exit(0, 49);
        assert!(!w.blocked(0));
        assert_eq!(w.next_deadline(), None);
        w.refresh(0, 51, ready);
        assert_eq!(w.registered(0), 0);
        assert_eq!(w.take(0), None);
        assert_eq!(w.wait(0, 0, 51, ready), Err(-3));
        w.restart(0).unwrap();
        assert_eq!(w.detach(0, own), Err(-116));
        assert_eq!(w.wait(0, 0, 51, ready), Err(-11));
        w.wait(1, 0, 51, ready).unwrap();
        assert_eq!(w.take(1), Some(Completion{status:0,x1:peer,x2:2}));
    }
    let mut regs = Vec::new();
    for m in [1,2,4,8] { regs.push(w.attach(0, 0, 3, m).unwrap()); }
    assert_eq!(w.attach(0, 0, 3, 16), Err(-28));
    let levels = Levels {events:15,..empty};
    for _ in 0..3 {
        for (i, &id) in regs.iter().enumerate() {
            w.wait(0, 0, 100, levels).unwrap();
            assert_eq!(w.take(0),Some(Completion{status:0,x1:id,x2:1<<i}));
        }
    }
    for (k,m) in [(1,1),(2,1),(3,0),(3,1u64<<32),(99,0)] {
        assert_eq!(w.attach(0,0,k,m), Err(-22));
    }
    // Equal-time transition order cannot move a timeout back to readiness.
    for advance_first in [true, false] {
        w.wait(0, 110, 100, empty).unwrap();
        assert!(w.blocked(0));
        if advance_first { w.advance(110); }
        w.refresh(0, 110, levels);
        w.advance(110);
        assert_eq!(w.take(0), Some(Completion{status:-110,x1:0,x2:0}));
        assert_eq!(w.take(0),None);
    }
    println!("PASS exit while blocked and while result pending, dead-owner state, generation invalidation, peer survival, 4/5 capacity, 3 full rotations, invalid masks, equal-time both orders");
}
