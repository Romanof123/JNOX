#!/usr/bin/env bash
set -eu -o pipefail
source "$HOME/iv373-first-d33b49e-raw/env"
prep=/mnt/d/codex/.jnox-work/373-first-independent
cp "$prep"/{verify.py,decode.sh,source.sh} "$d/"
python3 "$d/verify.py" "$d" > "$d/results.json"
python3 - "$d/results.json" <<'PY'
import json,sys
for name,row in json.load(open(sys.argv[1])).items():
    print(name, row["exits"], row.get("causality", {}))
    if name.startswith("waitset-"): print(row["slots"][0]["values"])
PY
