#include <jnox/waitset.h>
#include <jnox/ipc.h>
#include <jnox/notify.h>
#include <jnox/mailbox.h>

volatile long checks[32];
volatile uint64_t nchecked;
static int check(long value, long expected) {
    checks[nchecked++] = value;
    return value == expected;
}

static int features(char mode) {
    if (mode == 'd') {
        return check(jnox_waitset_attach(0, JNOX_WAITSET_MAILBOX, 0).status, -38)
            && check(jnox_waitset_detach(0), -38)
            && check(jnox_waitset_wait(0).status, -38)
            && check(jnox_mailbox_receive(0).status, -11)
            && check(jnox_event_take(1, 0).status, -11);
    }
    int mail = mode == 'm';
    jnox_waitset_registration a = jnox_waitset_attach(0, JNOX_WAITSET_MAILBOX, 0);
    jnox_waitset_registration b = jnox_waitset_attach(0, JNOX_WAITSET_PULSE, 0);
    jnox_waitset_registration e = jnox_waitset_attach(0, JNOX_WAITSET_EVENT, 8);
    return check(a.status, mail ? 0 : -95) && check(b.status, mail ? -95 : 0)
        && check(e.status, mail ? -95 : 0)
        && check(jnox_mailbox_receive(0).status, mail ? -11 : -38)
        && check(jnox_pulse_recv(0).status, mail ? -38 : -11)
        && check(jnox_waitset_wait(0).status, -11)
        && check(jnox_ipc_reply(0, 0), -38);
}

static int sender(void) {
    jnox_mailbox_result word = jnox_mailbox_receive(0);
    if (!check(word.status, 0) || !check(jnox_waitset_detach(word.word), -13)
        || !check(jnox_waitset_attach(0, JNOX_WAITSET_PULSE, 0).status, -13)) return 0;
    return check(jnox_pulse_send(0, 7, 0xabc0123456789defULL), 0)
        && check(jnox_event_set(0, 0x30), 0);
}

static int receiver(void) {
    jnox_waitset_registration p = jnox_waitset_attach(0, JNOX_WAITSET_PULSE, 0);
    if (!check(p.status, 0) || !check(jnox_mailbox_send(1, p.handle, 0), 0)) return 0;
    jnox_waitset_result r = jnox_waitset_wait(UINT64_MAX);
    if (!check(r.status, 0) || !check(r.handle == p.handle, 1) || !check(r.ready, 1)) return 0;
    r = jnox_waitset_wait(0);
    if (!check(r.status, 0) || !check(r.handle == p.handle, 1) || !check(r.ready, 1)) return 0;
    jnox_pulse_result pulse = jnox_pulse_recv(0);
    if (!check(pulse.status, 0) || !check(pulse.code, 7) || !check(pulse.word == 0xabc0123456789defULL, 1)
        || !check(jnox_waitset_wait(0).status, -11) || !check(jnox_pulse_recv(0).status, -11)) return 0;

    jnox_waitset_registration e = jnox_waitset_attach(0, JNOX_WAITSET_EVENT, 0x1c);
    if (!check(e.status, 0)) return 0;
    r = jnox_waitset_wait(UINT64_MAX);
    if (!check(r.status, 0) || !check(r.handle == e.handle, 1) || !check(r.ready, 0x10)) return 0;
    r = jnox_waitset_wait(0);
    if (!check(r.status, 0) || !check(r.handle == e.handle, 1) || !check(r.ready, 0x10)) return 0;
    jnox_event_result bits = jnox_event_take(0x1c, 0);
    if (!check(bits.status, 0) || !check(bits.bits, 0x10) || !check(jnox_waitset_wait(0).status, -11)) return 0;
    bits = jnox_event_take(~0U, 0);
    return check(bits.status, 0) && check(bits.bits, 0x20) && check(jnox_event_take(~0U, 0).status, -11);
}

int main(int argc, char **argv) {
    if (argc != 2) return 100;
    switch (argv[1][0]) {
        case 'q': return 74;
        case 'p': return sender() ? 74 : 101;
        case 'r': return receiver() ? 73 : 102;
        default: return features(argv[1][0]) ? 73 : 103;
    }
}
