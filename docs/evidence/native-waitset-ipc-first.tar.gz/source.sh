#!/usr/bin/env bash
set -eu -o pipefail
source "$HOME/iv373-first-d33b49e-raw/env"
base=04d699c8a445fc837a423c96ba35825810550c4b
git bundle create "$d/candidate.bundle" HEAD "^$base"
git bundle verify "$d/candidate.bundle" > "$d/bundle-verify.txt" 2>&1
git bundle list-heads "$d/candidate.bundle" >> "$d/bundle-verify.txt"
git diff --name-only "$base" "$rev" > "$d/source-changes.txt"
git ls-tree -r "$rev" -- arch boards kernel sdk tools examples/native-waitset examples/native-sync-ipc examples/native-mailbox examples/native-notify > "$d/input-tree.txt"
git ls-tree -r --name-only "$rev" -- arch boards kernel sdk tools examples/native-waitset examples/native-sync-ipc examples/native-mailbox examples/native-notify | xargs -d '\n' sha256sum > "$d/source-SHA256SUMS"
sha256sum "$d/candidate.bundle"
cat "$d/bundle-verify.txt"
