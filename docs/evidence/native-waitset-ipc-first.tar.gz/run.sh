#!/usr/bin/env bash
set -eu -o pipefail
prep=/mnt/d/codex/.jnox-work/373-first-independent
src=$HOME/iv373-first-d33b49e-src
d=$HOME/iv373-first-d33b49e-raw
rev=d33b49ee0d3daac51af70d90b4c4a2e4b5dc573c
contract=16e989077dd27e34f37f6377978c04245b778570
mkdir "$src" "$d"
source "$HOME/.cargo/env"
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_TARGET_DIR="$d/app-target" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true
git -C "$src" init -q
echo /mnt/d/codex/j-nox/.git/objects > "$src/.git/objects/info/alternates"
cd "$src"
git sparse-checkout init --cone
git sparse-checkout set arch boards examples kernel sdk tools trace verification
git -c advice.detachedHead=false checkout -q --detach "$rev"
git rev-parse HEAD 'HEAD^{tree}' > "$d/revision.txt"
test "$(git rev-parse 'HEAD^{tree}')" = 13778a42bb5d9f11072bcef5e9ec2d2336d17e25
test -z "$(git status --porcelain --untracked-files=no)"
cp "$prep"/{freeze.txt,issue.json,run.sh} "$d/"
git show "$contract:docs/native-waitset-ipc.en-ko.md" > "$d/contract.md"
sha256sum "$d"/{freeze.txt,run.sh,issue.json,contract.md} > "$d/freeze.sha256"
cat > "$d/env" <<'EOF'
source "$HOME/.cargo/env"
export PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_TARGET_DIR="$HOME/iv373-first-d33b49e-raw/app-target" CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true
d=$HOME/iv373-first-d33b49e-raw
src=$HOME/iv373-first-d33b49e-src
rev=d33b49ee0d3daac51af70d90b4c4a2e4b5dc573c
cd "$src"
run() {
    local tag=$1 rc=0
    shift
    printf '%q ' "$@" >> "$d/commands.sh"
    echo >> "$d/commands.sh"
    "$@" > "$d/$tag.log" 2>&1 || rc=$?
    echo "$tag $rc" | tee -a "$d/status"
    if [ "$rc" -ne 0 ]; then tail -12 "$d/$tag.log"; fi
    return "$rc"
}
guest() {
    local tag=$1 pol=$2 expect=$3 first=$4 firstsrc=$5 second=$6
    shift 6
    local args=()
    if [ "$pol" = rr ]; then args+=(--quantum-ticks 625000); fi
    run "pkg-$tag" python3 tools/build_native_el0.py --out "$d/pkg-$tag" --elf "$first" --peer-elf "$second" --priority 7 --peer-priority 1 --policy "$pol" "${args[@]}" "$@" || return 0
    run "cap-$tag" python3 tools/native_el0_capture.py "$d/cap-$tag" "$d/pkg-$tag/kernel.elf" "$first" "$firstsrc" "$rev" --plain --manifest "$d/pkg-$tag/manifest.json" --expect-exit "$expect" --timeout 14 || :
    if [ -f "$d/cap-$tag/uart.bin" ]; then awk '/EXIT PID|DROPPED|FAULT/{print}' "$d/cap-$tag/uart.bin"; fi
}
EOF
source "$d/env"
run receiver sh sdk/native-aarch64/build-rust.sh examples/native-waitset/receiver/Cargo.toml "$d/receiver.elf"
run sender sh sdk/native-aarch64/build.sh examples/native-waitset/sender.c "$d/sender.elf"
for pol in fifo rr; do
    guest "waitset-$pol" "$pol" 71 "$d/receiver.elf" examples/native-waitset/receiver/src/main.rs "$d/sender.elf" --mailbox-route 1:0 --notify-route 1:0 --waitset
done
run host-build rustc --edition 2021 --test kernel/src/waitset_ipc.rs -o "$d/host-tests"
run host "$d/host-tests" --nocapture
for row in sync mailbox notify; do
    case "$row" in
        sync) base=examples/native-sync-ipc; c=client; r=server; expect=41; flag=--ipc-route;;
        mailbox) base=examples/native-mailbox; c=sender; r=receiver; expect=51; flag=--mailbox-route;;
        notify) base=examples/native-notify; c=sender; r=receiver; expect=61; flag=--notify-route;;
    esac
    run "cc-$row" sh sdk/native-aarch64/build.sh "$base/$c.c" "$d/$row-0.elf"
    run "rs-$row" sh sdk/native-aarch64/build-rust.sh "$base/$r/Cargo.toml" "$d/$row-1.elf"
    for pol in fifo rr; do
        guest "$row-$pol" "$pol" "$expect" "$d/$row-0.elf" "$base/$c.c" "$d/$row-1.elf" "$flag" 0:1
    done
done
