"""Offline #373 checker. Run python3 verify.py PATH_TO_EXTRACTED_PACKET with GNU AArch64 nm on PATH."""
import hashlib
import json
import re
import struct
import subprocess
import sys
from pathlib import Path

ROOT = Path(sys.argv[1])
REV = "d33b49ee0d3daac51af70d90b4c4a2e4b5dc573c"
IDLE = (1 << 64) - 1

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def symbols(elf):
    out = subprocess.check_output(["aarch64-linux-gnu-nm", "-nS", str(elf)], text=True)
    return {f[3]: (int(f[0], 16), int(f[1], 16)) for line in out.splitlines()
            if len(f := line.split()) == 4}

def unpack_private(ram, base, root, sym, fmt):
    va, size = sym
    assert struct.calcsize("<" + fmt) == size
    data = bytearray()
    physical = []
    while len(data) < size:
        page = root
        for shift in [30, 21, 12]:
            index = page - base + 8 * ((va >> shift) & 511)
            assert index >= 0 and index+8 <= len(ram)
            entry, = struct.unpack_from("<Q", ram, index)
            assert entry & 3 == 3
            page = entry & 0x0000fffffffff000
        off = va & 4095
        pos = page + off - base
        width = min(4096 - off, size - len(data))
        assert 0 <= pos and pos + width <= len(ram)
        data.extend(ram[pos:pos+width])
        physical.append([hex(page+off),width])
        va += width
    return list(struct.unpack("<" + fmt, data)), physical

REQUEST = sum(x << (16*i) for i,x in enumerate([300,512,257,1025]))
REPLY = 0x000404010101082e
WORDS = [(i+1)<<32 | x for i,x in enumerate([300,512,257,1025,88])]
PRODUCTS = [0x10000012c,17,0x200000200,812]
REG = {
 "waitset": [
  {"waitset_handles":("5Q",None),"waitset_observations":("10Q",None),
   "waitset_errors":("5q",[-13,-116,-11,-11,-110]), "waitset_products":("4Q",PRODUCTS)},
  {"waitset_sender_foreign":("q",[-13]),"waitset_send_status":("5q",[0]*5)}],
 "notify":[{"notify_send_status":("8q",[0,0,0,0,-11,0,0,0])},
  {"notify_codes":("4I",[17,17,23,23]),"notify_words":("4Q",WORDS[:4]),
   "notify_channel_sums":("2Q",[812,1282]),"notify_empty_pulse":("q",[-11]),
   "notify_event_results":("4q",[1,-11,12,-11])}],
 "mailbox":[{"mailbox_send_status":("7q",[0,0,0,0,-11,-110,0]),"mailbox_send_times":("3Q",None)},
  {"mailbox_received":("5Q",WORDS),"mailbox_empty_status":("q",[-11]),"mailbox_reading_sum":("Q",[2182])}],
 "sync":[{"ipc_request_word":("Q",[REQUEST]),"ipc_call_status":("q",[0]),"ipc_reply_word":("Q",[REPLY])},
  {"ipc_server_words":("3Q",None),"ipc_reply_statuses":("3q",[-116,0,-116])}],
 "probe":[{"checks":("32q",None),"nchecked":("Q",None)}]*2
}
PROBE = {
 "only-mail": [[0,-95,-95,-11,-38,-11,-38],[]],
 "only-notify":[[-95,0,0,-38,-11,-11,-38],[]],
 "no-wait":[[-38,-38,-38,-11,-11],[]],
 "more":[[0,0,0,1,1,0,1,1,0,7,1,-11,-11,0,0,1,16,0,1,16,0,16,-11,0,32,-11],
         [0,-13,-13,0,0]]
}

def official_journal(rows):
    sequence = [(0,IDLE,0),(30,0,0),(30,0,0),(32,0,1),(30,1,1),(24,1,1),
     (26,1,1),(28,1,1),(28,1,0),(29,0,0),(30,0,0),(32,0,0),(32,0,0),
     (25,0,0),(32,0,0),(30,0,0),(30,0,0),(32,0,0),(31,0,0),(30,0,0),
     (31,0,0),(32,0,0),(32,0,1),(28,1,0),(29,0,0),(29,0,0),(27,0,0),
     (32,0,0),(5,0,0),(32,0,1),(3,1,IDLE),(4,IDLE,0),(3,0,IDLE)]
    # Allow a timer interrupt that leaves the same running process selected.
    rows = [r for r in rows if not (r[1] == 4 and r[3] == r[4])]
    assert [(r[1],r[3],r[4]) for r in rows] == sequence
    first, wake, second, wake2, finite, idle, irq = [rows[i] for i in [3,8,22,23,29,30,31]]
    # Each continuation resumes at its actual saved post-SVC PC/SP.
    for block,resume in [(first,wake),(second,wake2),(finite,irq)]:
        assert block[5:7] == resume[7:9]
        assert 0 not in block[5:7]
    assert finite[0] < finite[11] == idle[11] <= irq[0]
    return {"first_block_tick":first[0],"wake_on_matching_set_tick":wake[0],
      "second_block_tick":second[0],"replacement_wake_tick":wake2[0],
      "timed_block_tick":finite[0],"timer_compare":finite[11],"timer_irq_tick":irq[0],
      "resume_pcs":[hex(r[7]) for r in [wake,wake2,irq]]}

def analyze(name):
    cap = ROOT/("cap-"+name)
    pkg = ROOT/("pkg-"+name)
    m = json.loads((pkg/"manifest.json").read_text())
    launch = json.loads((cap/"launch.json").read_text())
    sess = json.loads((cap/"session.json").read_text())
    assert m == launch["argument_package"] and m["commit"] == REV and m["tracked_changes"] == ""
    assert launch["revision"] == REV and "tcg" in launch["argv"]
    assert m["kernel_elf_sha256"] == sha(cap/"kernel.elf")
    for f, val in sess["hashes"].items(): assert sha(cap/f) == val, f
    uart = (cap/"uart.bin").read_text()
    assert "FAULT" not in uart and "NATIVE FIXED DROPPED 0\n" in uart
    exits = {int(i):int(v) for i,v in re.findall(r"^NATIVE EL0 EXIT PID (\d+) (-?\d+)$", uart, re.M)}
    family = next((k for k in ["waitset","sync","mailbox","notify"] if name.startswith(k+"-") or name=="mixed-"+k),"probe")
    ex0={"waitset":71,"sync":41,"mailbox":51,"notify":61,"probe":73}[family]
    assert exits == {0:ex0,1:ex0+1} and sess["marker"] == "EXIT " + str(ex0)
    feature = family == "waitset" or name.startswith(("mixed-","more-","only-"))
    assert bool(m.get("waitset")) == feature
    rows = [list(map(int,s.split()[3:])) for s in uart.splitlines() if s.startswith("NATIVE FIXED EVENT ")]
    assert rows and all(len(r)==21 for r in rows)
    assert all(a[0] <= b[0] for a,b in zip(rows,rows[1:]))
    ksy = symbols(cap/"kernel.elf")
    spaces, = [v for k,v in ksy.items() if "6SPACES" in k]
    assert spaces[1] % 2 == 0
    ram = (cap/"ram.bin").read_bytes()
    assert len(ram) == launch["ram_bytes"]
    result = {"exits":list(exits.values()),"kernel":m["kernel_elf_sha256"],"journal_count":len(rows),
              "policy":m["policy"],"slots":[]}
    values = []
    for i,slot in enumerate(m["slots"]):
        elf = pkg/slot["elf"]
        elfhash = sha(elf)
        assert elfhash == slot["elf_sha256"] and elfhash in uart
        sy = symbols(elf)
        root = spaces[0]+i*(spaces[1]//2)
        vals = {}
        addresses = {}
        for sym,(fmt,want) in REG[family][i].items():
            vals[sym],phys = unpack_private(ram,launch["ram_base"],root,sy[sym],fmt)
            addresses[sym] = [hex(sy[sym][0]),phys]
            if want is not None: assert vals[sym] == want,(sym,vals[sym])
        result["slots"].append({"elf":elfhash,"root":hex(root),"addresses":addresses,"values":vals})
        values.append(vals)
    if family == "waitset":
        e,mh,f,p,new = values[0]["waitset_handles"]
        assert len(set([e,mh,f,p,new])) == 5 and all([e,mh,f,p,new])
        assert values[0]["waitset_observations"] == [e,1,mh,1,mh,1,p,1,new,8]
        assert "NATIVE NOTIFY STATE 1 0 0 1 0" in uart and "NATIVE MAILBOX STATE 0 0 1" in uart
        result["causality"] = official_journal(rows)
    elif family == "probe":
        want = PROBE["more" if name.startswith("more-") else name]
        for slot,(vals,expected) in enumerate(zip(values,want)):
            n = vals["nchecked"][0]
            assert n == len(expected) and vals["checks"][:n] == expected,(slot,n,vals["checks"])
    elif family == "mailbox":
        t0,d,t1 = values[0]["mailbox_send_times"]
        assert d - t0 == 100000000 and t1 >= d
    elif family == "sync":
        token,req,rep = values[1]["ipc_server_words"]
        assert token > 0 and req == REQUEST and rep == REPLY
    return result

cases = ([p+"-"+pol for p in ["waitset","sync","mailbox","notify","more"] for pol in ["fifo","rr"]]
         + ["only-mail","only-notify","no-wait","mixed-sync","mixed-mailbox","mixed-notify"])
data = {}
for c in cases:
    try: data[c] = analyze(c)
    except Exception as exc:
        print("FAILED", c, repr(exc), file=sys.stderr)
        raise
print(json.dumps(data,indent=2))
