#!/usr/bin/env bash
set -eu -o pipefail
source "$HOME/iv373-first-d33b49e-raw/env"
prep=/mnt/d/codex/.jnox-work/373-first-independent
pack=$HOME/iv373-first-d33b49e-portable
mkdir "$pack"
cp "$prep"/{REPORT.en-ko.md,pack.sh} "$d/"
cp "$d"/{*.sh,*.py,*.json,*.txt,*.rs,*.c,*.log,*.sha256,*.bundle,contract.md,REPORT.en-ko.md,env,status,source-SHA256SUMS} "$pack/"
for cap in "$d"/cap-*; do
    if [ ! -d "$cap" ]; then continue; fi
    name=${cap##*/cap-}
    cp -a "$cap" "$pack/"
    mkdir "$pack/pkg-$name"
    cp "$d/pkg-$name/"{manifest.json,build.log,user.elf,native_peer.elf} "$pack/pkg-$name/"
done
cd "$pack"
find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
sha256sum -c --quiet SHA256SUMS
python3 verify.py . > "$d/packed-replay.json"
cmp "$d/packed-replay.json" results.json
file=373-first-d33b49e.tar.gz
tar -czf "$prep/$file" .
cd "$prep"
sha256sum "$file" > "$file.sha256"
ls -lh "$file"
cat "$file.sha256"
dest=$HOME/iv373-first-d33b49e-replay
mkdir "$dest"
tar -xzf "$file" -C "$dest"
cd "$dest"
sha256sum --quiet -c SHA256SUMS
python3 verify.py . > "$d/extracted-replay.json"
cmp results.json "$d/extracted-replay.json"
echo 'PASS: extracted bytes and decoded private data for all 16 original boots'
