#!/usr/bin/env bash
set -eu -o pipefail
source "$HOME/iv373-first-d33b49e-raw/env"
prep=/mnt/d/codex/.jnox-work/373-first-independent
cp "$prep"/{probe.c,independent.rs,extra.sh} "$d/"
cp kernel/src/waitset_ipc.rs "$d/"
sha256sum "$d"/{probe.c,independent.rs,extra.sh,waitset_ipc.rs} > "$d/extra.sha256"
run controls-build rustc --edition 2021 "$d/independent.rs" -o "$d/independent"
run controls "$d/independent"
run probe-cc sh sdk/native-aarch64/build.sh "$d/probe.c" "$d/probe.elf"
probe() {
    local tag=$1 p=$2 owner=$3 peer=$4
    shift 4
    guest "$tag" "$p" 73 "$d/probe.elf" "$d/probe.c" "$d/probe.elf" --arg "$owner" --peer-arg "$peer" "$@"
}
probe only-mail fifo mail quiet --mailbox-route 1:0 --waitset
probe only-notify fifo notify quiet --notify-route 1:0 --waitset
probe no-wait fifo disabled quiet --mailbox-route 1:0 --notify-route 1:0
for pol in fifo rr; do
    probe "more-$pol" "$pol" receiver producer --mailbox-route 0:1 --notify-route 1:0 --ipc-route 0:1 --waitset
done
for family in sync mailbox notify; do
    case "$family" in sync) f=examples/native-sync-ipc/client.c; ex=41;; mailbox) f=examples/native-mailbox/sender.c; ex=51;; notify) f=examples/native-notify/sender.c; ex=61;; esac
    guest "mixed-$family" fifo "$ex" "$d/$family-0.elf" "$f" "$d/$family-1.elf" --ipc-route 0:1 --mailbox-route 0:1 --notify-route 0:1 --waitset
done
for mix in empty duplicate; do
    args=(--waitset)
    if [ "$mix" = duplicate ]; then args+=(--waitset --notify-route 1:0); fi
    rc=0
    run "reject-$mix" python3 tools/build_native_el0.py --out "$d/rejected-$mix" --elf "$d/probe.elf" --peer-elf "$d/probe.elf" --policy fifo --priority 7 --peer-priority 1 "${args[@]}" || rc=$?
    test "$rc" = 2
done
