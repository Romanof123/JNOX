from pathlib import Path
from collections import Counter
import json,hashlib
from replay import root,main,rows,decode
from ledger import oracle
def write():
 data=main()
 archived=json.loads((root.parent/'reservation53-fresh/observations.json').read_text())
 doc=['# CHG-056 independent first-cold comparison','',
 'The frozen gate requires all eight ordinary cases to complete every opening and budget check. The matched v1 and v2 arms are separate first boots. Each pair uses the same manifest and trace setting. Pair order alternates, one QEMU at a time on the default virtual clock. Cold means a new guest process and native Linux /tmp capture directory, without forced host cache eviction.',
 '', '## Inputs and scoring','',
 'Candidate 51567ba55644cad48d15331523574b4e940095fc. The two index hashes and exact launch order were written before any QEMU start in freeze.json. run.py verifies each executable against the corresponding original index. Raw images, guest UART, stderr, metadata and external exception events are preserved per launch. Timeout 124 at 15 seconds follows terminal UART in each complete capture. The original 12 v1 reservation records remain at ../reservation53-fresh/raw. No rebuilds or retries.',
 '', 'Timing below is in CNTPCT ticks at 62.5 MHz. The opening limit is inclusive at 62,500 ticks. A slot spans 3,125,000 ticks. An empty observation is shown as a dash. Source for each raw row is raw/{v1,v2}/application/arm/uart. replay.py and ledger.py reconstruct both policies independently of guest code. Run python3 make_report.py in WSL with aarch64-linux-gnu-nm available.',
 '', '## Matched ordinary outcomes','','| Case | Archived v1 first marker − E | Matched v1 first marker − E | v2 first marker − E | v2 last slot | v2 A/B grants | v2 status/reason |','|---|---:|---:|---:|---:|---|---|']
 def cell(k,r):return r.get(k,'—')
 def table(items):return '| '+' | '.join(str(x) for x in items)+' |'
 labels=[l for v,l in json.loads((root/'freeze.json').read_text())['order'] if v=='v2' and 'refused' not in l]
 for l in labels:
  if 'v2/'+l not in data or 'v1/'+l not in data:continue
  a=data['v2/'+l];ctl=data['v1/'+l];g=a['grants'];orig=archived[l]
  doc.append(table([l,orig['grants'][0]['worker_offset'],ctl['grants'][0]['worker_offset'] if ctl['grants'] else '—',cell('first_offset',a),a['slot'],str(sum(v['owner']==0 for v in g))+'/'+str(sum(v['owner']==1 for v in g)),'/'.join(map(str,a['status'][:2]))]))
 doc+=['','All eight matched v1 controls stopped on the first A marker with status 2/2. The aligned W/plain v2 guest published generation 1 at E+71,644 and stopped before any row 5/6 ledger, operational cutoff arm, selection or worker marker. Its rows cannot independently establish a visible demand or debit. Six other v2 runs reached the first A trap but missed the opening threshold. Only CBS S/trace completed.']
 doc+=['','## Candidate opening cost','','| Case | Boot sample → E | Idle setup | Setup end → E | E → IRQ | IRQ → precommit | Commit bracket | E → commit | Commit → cutoff arm | Commit → pre-ERET | Boot sample → first marker |','|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
 for l in labels:
  if 'v2/'+l in data:doc.append(table([l]+[cell(k,data['v2/'+l]) for k in ['boot_to_E','prep_duration','prep_slack','irq_offset','irq_to_precommit','commit_duration','commit_offset','commit_to_arm','commit_to_preeret','boot_to_first']]))
 doc+=['','Row 24.a is the first runtime counter sample. The later row 24 header is post-admission. Row 22 measures private preparation after the real idle return and before E. Outer mask and return instructions extend beyond that bracket. Row 23.a matches the actual boundary vector, 23.b is the final precommit sample, its header measures publication and 23.d records generation 1. Selection and restore are downstream. A 2/5 pre/post-commit timeout can prevent worker selection and an actual generation marker. A 2/2 records an observed late worker marker. A dash is an absent stage. V1 lacks the boot and setup probes, so its true boot-to-worker delta against v2 is unobservable.',
 '', 'For a comparable but narrower startup interval the following uses row 1 header through the first worker (an interval covering the wait to the original E). Paired changes include guest and host timing variability. Measured v2 private setup uses idle capacity; v1 has no corresponding private stage. The preparation duration is a measured inner bracket, not its complete CPU cost.',
 '', '| Case | Matched v1 config → first | v2 config → first | Paired difference |','|---|---:|---:|---:|']
 for l in labels:
  if 'v2/'+l not in data or 'v1/'+l not in data:continue
  vals=[]
  for v in ['v1','v2']:
   rr=rows(root/'raw'/v/l);g=next((r for r in rr if r[0]==10),None); vals.append(g[5]-rr[0][1] if g else None)
  doc.append(table([l]+[v if v is not None else '—' for v in vals]+[vals[1]-vals[0] if None not in vals else '—']))
 doc+=['','## Real service, entitlement and neighbor observations','','Slot-level observations.json retains every actual grant, owner, update count and checksum, linked PC and frame, service interval, allocation charge, cutoff delta, release/demand and q/d. expected.json is the separate prospective ledger over all 34 W or 10 S slots. For each observed grant the replay recalculates wrapping x=3x+1, matches pre-ERET frame/PC and saved stack, verifies trap syndrome, and sums elapsed upper by actual owner/deadline. External IRQ/SVC/ERET evidence applies only to traced arms.','',
 '| v2 case | Observed owners by slot | A/B committed updates | Max marker offset | Max upper S | Max cumulative upper | B grants by manifest period | IDLE selections |','|---|---|---|---:|---:|---:|---|---:|']
 for l in labels:
  if 'v2/'+l not in data:continue
  r=data['v2/'+l];gs=r['grants'];doc.append(table([l,''.join('ABI'[i] for i in r['selected']) or '—','/'.join(str(sum(g['count'] for g in gs if g['owner']==i)) for i in [0,1]),max([g['worker_offset'] for g in gs],default='—'),max([g['upper'] for g in gs],default='—'),max([g['allocation_upper'] for g in gs],default='—'),r['actual_periods'] or 'none',r['selected'].count(2)]))
 doc+=['','### Completed normal boots','']
 for l in labels:
  r=data.get('v2/'+l,{})
  if r.get('status',[])[:2]!=[0,0]:continue
  doc+=['**'+l+'**. The observed horizon reached slot '+str(r['slot'])+'. The external trace matched '+str(len(r['traces']))+' ordered ERET/IRQ/SVC events. Both final private stack snapshots matched the last committed count, checksum and address.','','| Slot | Owner | Action | Allocation deadline | Updates | Marker − opening | Elapsed upper | Allocation cumulative | Stop − cutoff | End − stop |','|---:|---|---|---:|---:|---:|---:|---:|---:|---:|']
  for g in r['grants']:
   qd=next(x for x in r['observed_qd'] if x[:2]==[g['slot'],g['owner']])
   doc.append(table([g['slot'],'AB'[g['owner']],{1:'cutoff IRQ',2:'block SVC',3:'exit SVC'}[g['action']],qd[-1],g['count'],g['worker_offset'],g['upper'],g['allocation_upper'],g['after_cutoff'],g['remaining_tail']]))
  doc+=['','Both workers received one budget unit per two-slot period during active demand. Each received three long preemptions and a fourth finite exit after 256 updates. The remaining two slots selected idle after both exits. The independent exception trace confirms actual idle returns after grant closure and both SVC #2 exits. No W case reached its first B grant or demonstrated its wake/replenishment sequence.']
 doc+=['','A block/exit requires SVC #1/#2 and 256 committed updates. Long grants require a real cutoff IRQ and positive 16-update chunks. The conservative elapsed upper spans the pre-ERET sample to actual exception vector sample and includes outgoing service after programmed cutoff. Eligible workers carry one whole grant debit regardless of the measured duration. Each reported cumulative upper must stay within Q times slot length (A/W two slots, others one). Unobserved periods, block/resume sequences, exits, idle tails and terminal snapshots cannot establish complete demand isolation or success.',
 '', '## Refusals and negative controls','']
 for k,r in data.items():
  if 'refused' in k:doc.append('- '+k+' returned '+str(r['status'])+' with the five documented refusal/invalid-input reasons, zero frames and zero operational arms; no setup, return, service or commit.')
 doc+=['','The independent parser rejects duplicate preparation or commit, wrong generation, early real IRQ, stale commit epoch, and a candidate prepared at/after E (controls.json). These are mutated capture controls. The build-indexed 15/15 host Rust tests additionally exercise duplicate/stale publication, incompatible origin, blocked/exited state, ownership swap, missing idle return and inclusive/one-tick-over opening arithmetic. None of those tests injects a stale candidate or duplicate into a live guest. Normal actual records are positive controls for pre-E preparation and unique commit if emitted. No v2 late guest is part of this iteration. Archived v1 late fixtures measured B opportunity loss of 125763 and 125757 ticks with an earlier dispatch failure. Neither a qualified v2 late fail-stop nor a physical execution bound follows.',
 '', '## Verdict','']
 normals=[data['v2/'+l] for l in labels if 'v2/'+l in data]
 complete=sum(r['status'][:2]==[0,0] for r in normals); timely=sum(bool(r['grants']) and r['grants'][0]['worker_offset']<=62500 for r in normals)
 doc.append(f'{complete}/{len(normals)} normal candidate runs reached terminal success; {timely}/{len(normals)} observed a first Rust marker inside the opening bound. B made positive progress in {sum(any(g["owner"]==1 for g in r["grants"]) for r in normals)} of the eight runs. Timing applies only to these observed virtual-machine first attempts. The full reservation profile remains unqualified.')
 (root/'REPORT.md').write_text('\n'.join(doc)+'\n',encoding='utf-8')
if __name__=='__main__':write()
