"""Verify input identity and raw inventory, write a deterministic SHA-256 manifest."""
from pathlib import Path
import hashlib,json
from controls import controls
from make_report import write,root
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def finalize():
 order=json.loads((root/'freeze.json').read_text())['order']
 assert len(order)==20 and len(set(tuple(k) for k in order))==20
 for v,l in order:
  raw=root/'raw'/v/l
  expected=json.loads((root.parent/('reservations53-builds' if v=='v1' else 'reservations53-v2-builds')/'index.json').read_text())['images'][l.split('/')[0]]['sha256']
  assert digest(raw/'kernel.elf')==expected
  if v=='v1':assert digest(root.parent/'reservation53-fresh/raw'/l/'kernel.elf')==expected
  assert (raw/'uart').read_text().endswith('RSRV END\n') and (raw/'meta.json').exists()
 controls();write()
 files=[p for p in root.rglob('*') if p.is_file() and p.name!='manifest.sha256' and '__pycache__' not in p.parts]
 (root/'manifest.sha256').write_text(''.join(f'{digest(p)}  {p.relative_to(root).as_posix()}\n' for p in sorted(files)),encoding='ascii')
if __name__=='__main__':finalize()
