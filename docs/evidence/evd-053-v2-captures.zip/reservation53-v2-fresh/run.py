from pathlib import Path
import json, subprocess as sp, shutil, tempfile,hashlib,time
root=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
labels=json.loads((root.parent/'reservation53-fresh/order.json').read_text())[:10]
order=[(v,l) for i,l in enumerate(labels) for v in (['v1','v2'] if i%2==0 else ['v2','v1'])]
assert not (root/'raw').exists()
build={v:root.parent/('reservations53-builds' if v=='v1' else 'reservations53-v2-builds') for v in ['v1','v2']}
pins=['22de1966a3def8bb661187786b70349150ad6a6980dc73b73a3eac684910d2d6','6754c0724de40a88351f30ef94962127322084055276ed33716fbfc0db45590f']
for (v,b),pin in zip(build.items(),pins):
 assert h(b/'index.json')==pin
 for label in labels:
  a=label.split('/')[0];assert h(b/a/'kernel.elf')==json.loads((b/'index.json').read_text())['images'][a]['sha256']
(root/'freeze.json').write_text(json.dumps(dict(order=order,pins=pins,timeout=15,clock='default',late='excluded, separate rollout'),indent=2))
for v,label in order:
 a,arm=label.split('/'); d=Path(tempfile.mkdtemp(dir='/tmp',prefix='reservation-first-')); elf=d/'kernel.elf';shutil.copy2(build[v]/a/'kernel.elf',elf)
 q=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','stdio','-kernel',str(elf)]
 if arm=='trace':q+=['-d','int','-D',str(d/'exceptions.log')]
 with (d/'uart').open('wb') as out,(d/'stderr').open('wb') as err:
  rc=sp.run(['timeout','15s',*q],cwd=d,stdout=out,stderr=err).returncode
 (d/'meta.json').write_text(json.dumps(dict(argv=q,status=rc,sha256=h(elf),path=str(d),qemu=sp.check_output([q[0],'--version'],text=True)),indent=2))
 shutil.copytree(d,root/'raw'/v/label);print(v,label,rc,flush=True)
