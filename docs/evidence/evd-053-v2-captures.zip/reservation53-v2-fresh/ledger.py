"""Independent frozen logical ledger and evidence joins. Run in WSL Python 3."""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction
import json,re,subprocess
root=Path(__file__).resolve().parent
def oracle(app):
    wake='wake' in app
    aligned='aligned' in app
    par=[(2,8,0),(1,4,1)] if wake else [(1,2,0),(1,2,0)]
    q=[0,0]; d=[0,1 if aligned and wake else 0]; demand=[0,0]; state=[0,0]; ledger=[]
    for t in range(34 if wake else 10):
        releases=[(1 if t in (0,4,5,13,22) else 100 if t==23 else 0),100 if t==1 else 0] if wake else [4,4] if t==0 else [0,0]
        for i,(Q,P,offset) in enumerate(par):
            if releases[i]:
                demand[i]+=releases[i]; state[i]=1
            if aligned:
                refill=t>=offset and (t-offset)%P==0
                if refill: q[i],d[i]=Q,t+P
            elif releases[i] and (t>=d[i] or q[i]*P>Q*(d[i]-t)):
                q[i],d[i]=Q,t+P
            elif demand[i] and not q[i] and t>=d[i]:
                q[i],d[i]=Q,d[i]+P
        before=list(zip(q,d))
        eligible=[i for i in range(2) if demand[i] and q[i]]
        owner=min(eligible,key=lambda i:(d[i],i)) if eligible else 2
        act=0
        if owner<2:
            q[owner]-=1; demand[owner]-=1
            act=1 if demand[owner] else 2 if wake else 3
        ledger.append(dict(slot=t,owner=owner,alloc=[[*before[i],q[i],d[i]] for i in range(2)],jobs=[[releases[i],demand[i],state[i],act if owner==i else 0] for i in range(2)]))
        if owner<2: state[owner]=[0,2,3,4][act]
    return ledger
def advance(seed,n):
    return (((2*seed+1)*pow(3,n,1<<65)-1)%(1<<65))//2
def analyze(path,app):
    lines=(path/'uart').read_text().splitlines()
    assert lines[:3]==['JNOX M1 BOOT','JNOX M1 READY','RSRV RAW 1'] and lines[-1]=='RSRV END'
    rows=[list(map(int,l.split())) for l in lines[3:-1]]
    assert all(len(r)==8 and all(0<=v<2**64 for v in r) for r in rows)
    by=defaultdict(list)
    for r in rows: by[r[0]].append(r)
    z=by[13][0]; freq,S=by[1][0][4:6]; ms=freq//1000
    assert len(by[13])==1 and rows[-1]==z
    report=dict(status=z[4:],slot=z[2],grants=[],traces=[],returns=len(by[12]),horizon=len(by[21]),irqs=[dict(slot=r[2],kind=r[5],ticks_after_target=r[1]-r[4]) for r in by[4]])
    if 'refused' in app:
        assert [(r[4:]) for r in by[15]]==[[0,2,0,0],[1,1,0,0],[2,1,0,0],[3,3,0,0],[4,1,0,0]]
        assert not any(by[k] for k in (2,3,4,7,8,12,17,18)) and z[4:]==[1,2,9,8]
        assert Fraction(1,2)*2==1 and Fraction(1,2)*2+Fraction(1,8)==Fraction(9,8)>1
        return report
    model=oracle(app)
    for tag,key in ((5,'alloc'),(6,'jobs')):
        for r in by[tag]: assert r[4:]==model[r[2]][key][r[3]],r
    for r in by[7]: assert r[3]==model[r[2]]['owner']
    for r in by[3]: assert r[4]==r[6] and r[5]&3==1
    sym=subprocess.check_output(['aarch64-linux-gnu-nm','-nS',str(path/'kernel.elf')],text=True)
    def symbol(pc):
        for match in re.finditer(r'^([\da-f]+) ([\da-f]+) [Tt] (\S+)',sym,re.M):
            start,size=[int(v,16) for v in match.group(1,2)]
            if start<=pc<start+size: return match[3]
        return '?'
    stacks={r[3]:r[4:6] for r in by[17]}
    seeds=[0xa19,0xb19,0xc19]
    assert all(stacks[i][1]<=stacks[i+1][0] for i in (0,1))
    saved={}; progress={}; total=defaultdict(int)
    def row(tag,slot,i): return next(r for r in by[tag] if r[2:4]==[slot,i])
    assert len(by[12])==len(by[18])
    for idx,(actual,plan) in enumerate(zip(by[12],by[18])):
        assert actual[2:6]==plan[2:6] and actual[6]==idx and plan[7]==seeds[plan[3]]
    for r in by[10]:
        slot,i=r[2:4]; lo,first,hi,U=r[4:]; pick=row(7,slot,i); start,end,frame,pc=pick[4:]
        count0,count1,x,y=row(8,slot,i)[4:]; sf,spc,x19,tpidr=row(9,slot,i)[4:]
        action,esr,local,sp=row(11,slot,i)[4:]; deadline,cum,rf,rpc=row(19,slot,i)[4:]
        assert (count0,x)==progress.get(i,(0,seeds[i])) and count1>count0 and (count1-count0)%16==0 and advance(x,count1-count0)==y
        assert action==model[slot]['jobs'][i][3] and (action==1 or count1-count0==256)
        assert esr=={1:0,2:0x56000001,3:0x56000002}[action]
        assert stacks[i][0]<=sf<sp<=local<stacks[i][1] and stacks[i][0]<=frame<stacks[i][1] and tpidr==seeds[i]
        assert 'reservation_rust_work' in symbol(spc) or ('late' in app and symbol(spc)!='?')
        if i in saved: assert (frame,pc)==saved[i][:2]
        else: assert symbol(pc)=='reservation_worker_'+('ab'[i])
        plan=row(18,slot,i)
        if i in saved: assert plan[6]==saved[i][2]
        saved[i]=(sf,spc,x19); progress[i]=(count1,y)
        assert (rf,rpc)==(frame,pc) and lo==row(12,slot,i)[1] and lo<=first<=hi and U==hi-lo
        assert deadline==model[slot]['alloc'][i][3]
        total[i,deadline]+=U
        assert cum==total[i,deadline]
        cutoff=end-ms
        assert any(v[4]==cutoff and v[7]==1 for v in by[3] if v[2]==slot)
        report['grants'].append(dict(slot=slot,owner=i,action=action,count=count1-count0,checksum=y,open=start,pre_eret_offset=lo-start,worker_offset=first-start,upper=U,allocation_upper=cum,allocation_limit=S*(2 if 'wake' in app and i==0 else 1),slot_limit=S,dispatch_limit=ms,stop=hi,after_cutoff=hi-cutoff,after_end=hi-end,remaining_tail=max(0,end-hi),saved_frame=sf,saved_pc=hex(spc),linked_pc=symbol(spc),stack_local=local))
    tr=path/'exceptions.log'
    if tr.exists():
        external=re.findall(r'Exception return .*? PC (0x[\da-f]+)|Taking exception \d+ \[(IRQ|SVC)\]\n.*?with ESR [^/]+/(0x[\da-f]+)\n.*?with ELR (0x[\da-f]+)',tr.read_text(),re.S)
        # Interleave terminal-dumped returns at their actual monotonic sampled ticks.
        ev=[(r[1],'ERET',r[5],None) for r in by[12]]+[(r[1],'IRQ',None,None) for r in by[4]]+[(r[1],'SVC',row(9,r[2],r[3])[5],r[5]) for r in by[11] if r[4] in (2,3)]
        ev.sort()
        assert len(ev)==len(external)
        for (_,kind,pc,esr),(ret,exc,sy,elr) in zip(ev,external):
            actual=int(ret or elr,16); assert (exc or 'ERET')==kind and (pc is None or actual==pc)
            if esr: assert int(sy,16)==esr
            if kind=='IRQ':
                saved_at=[r for r in by[9] if r[1]==_]
                if saved_at: assert saved_at[0][5]==actual
                else: assert 'idle' in symbol(actual)
            report['traces'].append([kind,hex(actual),symbol(actual)])
    if by[14]:
        edge,c0,unmask,c1=by[20][0][4:]; begin,endmask,cutoff,end=by[16][0][4:]
        end2,stop,lost,excess=by[14][0][4:]
        report['overrun']=dict(mask_begin=begin,cutoff=cutoff,end=end,edge=edge,edge_count=c0,unmask=unmask,end_count=c1,stop=stop,excess=excess,lost_owner=lost,fixture_valid=0<begin<cutoff and end<=edge<unmask==endmask and unmask>=end+2*ms and c1>c0 and unmask<=stop)
        assert end==end2 and stop-end==excess and lost==1 and all(r[2]==0 for r in by[7])
    return report
