"""Mutate a copy of a measured guest capture; these checks never execute guests."""
import copy,json
from replay import root,rows,decode
def controls():
 path=root/'raw/v2/cbs-wake/trace';base=rows(path)
 def pick(rr,tag):return next(r for r in rr if r[0]==tag)
 def field(rr,t,col,val):pick(rr,t)[col]=val
 E=pick(base,2)[4]
 def late(rr):
  p=pick(rr,22);p[1]=E;p[6]=0
 def earlier(rr):
  pick(rr,4)[1]=E-1;pick(rr,23)[4]=E-1
 checks={
 'absent idle return':lambda rr:rr.remove(pick(rr,12)),
 'duplicate commit':lambda rr:rr.insert(-1,pick(rr,23).copy()),
 'duplicate preparation':lambda rr:rr.insert(-1,pick(rr,22).copy()),
 'stale generation':lambda rr:field(rr,23,7,0),
 'stale epoch':lambda rr:field(rr,23,6,E-1),
 'IRQ one tick early':earlier,
 'setup ends at E':late,
 'cutoff readback differs':lambda rr:field(rr,3,6,E+1),
 'second owner mislabeled':lambda rr:field(rr,7,3,1)}
 result={}
 for name,mutate in checks.items():
  rr=copy.deepcopy(base);mutate(rr)
  try:decode(rr,'v2','cbs-wake')
  except (AssertionError,IndexError,StopIteration):result[name]='rejected'
  else:raise AssertionError(name)
 limit=62500
 for name,off in [('early',-1),('exact',62500),('one beyond',62501)]:
  result['model marker '+name]='accepted' if 0<=off<=limit else 'rejected'
 assert result['model marker early']==result['model marker one beyond']=='rejected' and result['model marker exact']=='accepted'
 (root/'controls.json').write_text(json.dumps(result,indent=2))
if __name__=='__main__':controls()
