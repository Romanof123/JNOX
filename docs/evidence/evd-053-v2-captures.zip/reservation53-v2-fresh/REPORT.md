# CHG-056 independent first-cold comparison

The frozen gate requires all eight ordinary cases to complete every opening and budget check. The matched v1 and v2 arms are separate first boots. Each pair uses the same manifest and trace setting. Pair order alternates, one QEMU at a time on the default virtual clock. Cold means a new guest process and native Linux /tmp capture directory, without forced host cache eviction.

## Inputs and scoring

Candidate 51567ba55644cad48d15331523574b4e940095fc. The two index hashes and exact launch order were written before any QEMU start in freeze.json. run.py verifies each executable against the corresponding original index. Raw images, guest UART, stderr, metadata and external exception events are preserved per launch. Timeout 124 at 15 seconds follows terminal UART in each complete capture. The original 12 v1 reservation records remain at ../reservation53-fresh/raw. No rebuilds or retries.

Timing below is in CNTPCT ticks at 62.5 MHz. The opening limit is inclusive at 62,500 ticks. A slot spans 3,125,000 ticks. An empty observation is shown as a dash. Source for each raw row is raw/{v1,v2}/application/arm/uart. replay.py and ledger.py reconstruct both policies independently of guest code. Run python3 make_report.py in WSL with aarch64-linux-gnu-nm available.

## Matched ordinary outcomes

| Case | Archived v1 first marker − E | Matched v1 first marker − E | v2 first marker − E | v2 last slot | v2 A/B grants | v2 status/reason |
|---|---:|---:|---:|---:|---|---|
| aligned-wake/plain | 88118 | 118133 | — | 0 | 0/0 | 2/5 |
| cbs-wake/trace | 81137 | 84939 | 63691 | 0 | 1/0 | 2/2 |
| aligned-saturated/trace | 79245 | 87932 | 75826 | 0 | 1/0 | 2/2 |
| cbs-saturated/plain | 71909 | 87981 | 64286 | 0 | 1/0 | 2/2 |
| aligned-wake/trace | 81594 | 76978 | 66789 | 0 | 1/0 | 2/2 |
| cbs-wake/plain | 83809 | 90860 | 63392 | 0 | 1/0 | 2/2 |
| aligned-saturated/plain | 78061 | 87556 | 71213 | 0 | 1/0 | 2/2 |
| cbs-saturated/trace | 72704 | 77739 | 57262 | 10 | 4/4 | 0/0 |

All eight matched v1 controls stopped on the first A marker with status 2/2. The aligned W/plain v2 guest published generation 1 at E+71,644 and stopped before any row 5/6 ledger, operational cutoff arm, selection or worker marker. Its rows cannot independently establish a visible demand or debit. Six other v2 runs reached the first A trap but missed the opening threshold. Only CBS S/trace completed.

## Candidate opening cost

| Case | Boot sample → E | Idle setup | Setup end → E | E → IRQ | IRQ → precommit | Commit bracket | E → commit | Commit → cutoff arm | Commit → pre-ERET | Boot sample → first marker |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| aligned-wake/plain | 3126433 | 50621 | 3013708 | 29146 | 30556 | 11942 | 71644 | — | — | — |
| cbs-wake/trace | 3126431 | 57240 | 3008725 | 26315 | 18836 | 4833 | 49984 | 8323 | 11011 | 3190122 |
| aligned-saturated/trace | 3126424 | 62699 | 2997995 | 26561 | 22497 | 7913 | 56971 | 11621 | 14757 | 3202250 |
| cbs-saturated/plain | 3126444 | 47894 | 3020049 | 23517 | 20754 | 6083 | 50354 | 9787 | 11726 | 3190730 |
| aligned-wake/trace | 3126400 | 47137 | 3017785 | 22152 | 20232 | 6310 | 48694 | 9904 | 13319 | 3193189 |
| cbs-wake/plain | 3126436 | 48688 | 3015304 | 17929 | 23627 | 6707 | 48263 | 10031 | 12356 | 3189828 |
| aligned-saturated/plain | 3126490 | 51865 | 3017050 | 22598 | 22345 | 7828 | 52771 | 10742 | 15325 | 3197703 |
| cbs-saturated/trace | 3126448 | 47718 | 3016409 | 21600 | 17240 | 4955 | 43795 | 8135 | 10735 | 3183710 |

Row 24.a is the first runtime counter sample. The later row 24 header is post-admission. Row 22 measures private preparation after the real idle return and before E. Outer mask and return instructions extend beyond that bracket. Row 23.a matches the actual boundary vector, 23.b is the final precommit sample, its header measures publication and 23.d records generation 1. Selection and restore are downstream. A 2/5 pre/post-commit timeout can prevent worker selection and an actual generation marker. A 2/2 records an observed late worker marker. A dash is an absent stage. V1 lacks the boot and setup probes, so its true boot-to-worker delta against v2 is unobservable.

For a comparable but narrower startup interval the following uses row 1 header through the first worker (an interval covering the wait to the original E). Paired changes include guest and host timing variability. Measured v2 private setup uses idle capacity; v1 has no corresponding private stage. The preparation duration is a measured inner bracket, not its complete CPU cost.

| Case | Matched v1 config → first | v2 config → first | Paired difference |
|---|---:|---:|---:|
| aligned-wake/plain | 3237584 | — | — |
| cbs-wake/trace | 3204219 | 3184143 | -20076 |
| aligned-saturated/trace | 3207270 | 3196450 | -10820 |
| cbs-saturated/plain | 3204780 | 3184937 | -19843 |
| aligned-wake/trace | 3197378 | 3187481 | -9897 |
| cbs-wake/plain | 3209605 | 3183440 | -26165 |
| aligned-saturated/plain | 3207915 | 3191678 | -16237 |
| cbs-saturated/trace | 3198080 | 3177184 | -20896 |

## Real service, entitlement and neighbor observations

Slot-level observations.json retains every actual grant, owner, update count and checksum, linked PC and frame, service interval, allocation charge, cutoff delta, release/demand and q/d. expected.json is the separate prospective ledger over all 34 W or 10 S slots. For each observed grant the replay recalculates wrapping x=3x+1, matches pre-ERET frame/PC and saved stack, verifies trap syndrome, and sums elapsed upper by actual owner/deadline. External IRQ/SVC/ERET evidence applies only to traced arms.

| v2 case | Observed owners by slot | A/B committed updates | Max marker offset | Max upper S | Max cumulative upper | B grants by manifest period | IDLE selections |
|---|---|---|---:|---:|---:|---|---:|
| aligned-wake/plain | — | 0/0 | — | — | — | none | 0 |
| cbs-wake/trace | A | 256/0 | 63691 | 9750 | 9750 | none | 0 |
| aligned-saturated/trace | A | 15000368/0 | 75826 | 2998771 | 2998771 | none | 0 |
| cbs-saturated/plain | A | 17968880/0 | 64286 | 3007704 | 3007704 | none | 0 |
| aligned-wake/trace | A | 256/0 | 66789 | 13972 | 13972 | none | 0 |
| cbs-wake/plain | A | 256/0 | 63392 | 11229 | 11229 | none | 0 |
| aligned-saturated/plain | A | 17943072/0 | 71213 | 3004951 | 3004951 | none | 0 |
| cbs-saturated/trace | ABABABABII | 53467600/54019808 | 57262 | 3070002 | 3070002 | {'0': [1], '1': [3], '2': [5], '3': [7]} | 2 |

### Completed normal boots

**cbs-saturated/trace**. The observed horizon reached slot 10. The external trace matched 38 ordered ERET/IRQ/SVC events. Both final private stack snapshots matched the last committed count, checksum and address.

| Slot | Owner | Action | Allocation deadline | Updates | Marker − opening | Elapsed upper | Allocation cumulative | Stop − cutoff | End − stop |
|---:|---|---|---:|---:|---:|---:|---:|---:|---:|
| 0 | A | cutoff IRQ | 2 | 17827968 | 57262 | 3018649 | 3018649 | 10679 | 51821 |
| 1 | B | cutoff IRQ | 2 | 18032496 | 21001 | 3053055 | 3053055 | 10813 | 51687 |
| 2 | A | cutoff IRQ | 4 | 17367296 | 9764 | 3065386 | 3065386 | 11841 | 50659 |
| 3 | B | cutoff IRQ | 4 | 17912112 | 7996 | 3070002 | 3070002 | 15285 | 47215 |
| 4 | A | cutoff IRQ | 6 | 18272080 | 9315 | 3066880 | 3066880 | 13432 | 49068 |
| 5 | B | cutoff IRQ | 6 | 18074944 | 6536 | 3066171 | 3066171 | 10013 | 52487 |
| 6 | A | exit SVC | 8 | 256 | 15432 | 11812 | 11812 | -3036150 | 3098650 |
| 7 | B | exit SVC | 8 | 256 | 21532 | 1580 | 1580 | -3039755 | 3102255 |

Both workers received one budget unit per two-slot period during active demand. Each received three long preemptions and a fourth finite exit after 256 updates. The remaining two slots selected idle after both exits. The independent exception trace confirms actual idle returns after grant closure and both SVC #2 exits. No W case reached its first B grant or demonstrated its wake/replenishment sequence.

A block/exit requires SVC #1/#2 and 256 committed updates. Long grants require a real cutoff IRQ and positive 16-update chunks. The conservative elapsed upper spans the pre-ERET sample to actual exception vector sample and includes outgoing service after programmed cutoff. Eligible workers carry one whole grant debit regardless of the measured duration. Each reported cumulative upper must stay within Q times slot length (A/W two slots, others one). Unobserved periods, block/resume sequences, exits, idle tails and terminal snapshots cannot establish complete demand isolation or success.

## Refusals and negative controls

- v1/aligned-refused/plain returned [1, 2, 9, 8] with the five documented refusal/invalid-input reasons, zero frames and zero operational arms; no setup, return, service or commit.
- v2/aligned-refused/plain returned [1, 2, 9, 8] with the five documented refusal/invalid-input reasons, zero frames and zero operational arms; no setup, return, service or commit.
- v2/cbs-refused/plain returned [1, 2, 9, 8] with the five documented refusal/invalid-input reasons, zero frames and zero operational arms; no setup, return, service or commit.
- v1/cbs-refused/plain returned [1, 2, 9, 8] with the five documented refusal/invalid-input reasons, zero frames and zero operational arms; no setup, return, service or commit.

The independent parser rejects duplicate preparation or commit, wrong generation, early real IRQ, stale commit epoch, and a candidate prepared at/after E (controls.json). These are mutated capture controls. The build-indexed 15/15 host Rust tests additionally exercise duplicate/stale publication, incompatible origin, blocked/exited state, ownership swap, missing idle return and inclusive/one-tick-over opening arithmetic. None of those tests injects a stale candidate or duplicate into a live guest. Normal actual records are positive controls for pre-E preparation and unique commit if emitted. No v2 late guest is part of this iteration. Archived v1 late fixtures measured B opportunity loss of 125763 and 125757 ticks with an earlier dispatch failure. Neither a qualified v2 late fail-stop nor a physical execution bound follows.

## Verdict

1/8 normal candidate runs reached terminal success; 1/8 observed a first Rust marker inside the opening bound. B made positive progress in 1 of the eight runs. Timing applies only to these observed virtual-machine first attempts. The full reservation profile remains unqualified.
