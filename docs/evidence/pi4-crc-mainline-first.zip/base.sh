set -eu
b=$HOME/jnox229-first
ev=$b/evidence
cd "$b"
git worktree add -q --detach "$b/base" 2c3b813
export PATH="$HOME/jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH" CARGO_BUILD_JOBS=1 PYTHONPATH="$HOME/jnox-169-first-e203caa/deps" CARGO_TARGET_DIR="$b/base-build" PYTHONDONTWRITEBYTECODE=1
q=/mnt/d/codex/arm-speed-lab/build/system/qemu-system-aarch64
export JNOX_BOARD=pi4 JNOX_PROFILE=smp
cd "$b/base/kernel"
for c in global partitioned clustered; do
 d="$ev/base-$c"; mkdir "$d"; export JNOX_APP=migration-$c
 cargo rustc --locked --release -j1 > "$d/build.log" 2>&1
 elf=$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel
 aarch64-linux-gnu-objcopy -O binary "$elf" "$b/img"
 aarch64-linux-gnu-objdump -dC "$elf" > "$b/dis"
 python3 ../tools/pi4_migration_capture.py freeze "$JNOX_APP" "$d/frozen" "$elf" "$b/img" "$b/dis" "$q" --source "$(git rev-parse HEAD)" > "$d/freeze.sha"
 for k in base legacy; do
 x="$ev/$k-$c"
 rc=0; python3 ../tools/pi4_migration_capture.py run "$x/frozen" "$(cat "$x/freeze.sha")" 1 > "$x/session.sha" 2>"$x/capture.err" || rc=$?; echo "$rc" > "$x/capture.rc"
 for reader in "$b/base" "$b"; do
 tag=old; if [ "$reader" = "$b" ]; then tag=new; fi
 rc=0; python3 "$reader/tools/pi4_migration_replay.py" "$x/frozen" 1 "$(cat "$x/session.sha")" > "$x/replay-$tag.json" 2>"$x/replay-$tag.err" || rc=$?; echo "$rc" > "$x/replay-$tag.rc"
 done
 done
done
unset JNOX_BOARD JNOX_APP JNOX_PROFILE
cd "$b"
python3 tools/test_partition_selectors.py > "$ev/host-selectors.log" 2>&1
python3 -m unittest discover -s tools -p 'test_pi4*.py' > "$ev/host-pi4.log" 2>&1