set -eu
base=$HOME/jnox229-first
cd "$base"
export PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$HOME/jnox-169-first-e203caa/deps"
ev=$base/evidence
for c in global partitioned clustered; do
 d="$ev/stream-$c"
 cat "$d/freeze.sha"
 sed -n '/<pi4_stream_crc32_loop_v1>:/,/^$/p' "$d/frozen/disassembly.txt"
done > "$ev/prospective.txt"
date -u -Ins >> "$ev/prospective.txt"
sha256sum "$ev/prospective.txt" > "$ev/prospective.sha"
for c in global partitioned clustered; do
 d="$ev/stream-$c"
 for n in 1 2; do
  rc=0; python3 tools/pi4_migration_capture.py run "$d/frozen" "$(cat "$d/freeze.sha")" "$n" > "$d/session-$n.sha" 2> "$d/capture-$n.err" || rc=$?
  echo "$rc" > "$d/capture-$n.rc"
  rc=0; python3 tools/pi4_migration_replay.py "$d/frozen" "$n" "$(cat "$d/session-$n.sha")" > "$d/replay-$n.json" 2> "$d/replay-$n.err" || rc=$?
  echo "$rc" > "$d/replay-$n.rc"
 done
done