from pathlib import Path
import hashlib,json,struct,zlib,re,zipfile
b=Path.home()/'jnox229-first'; e=b/'evidence'; out=Path('/mnt/d/codex/jnox229-first')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
R=['# Pi 4 main integration · 독립 통합 검증','#229 / #228 · 4d8ea7af9c2a2cc0482025bd56809f5df98b6c66, plan ed0ac5b458aa48f4e37d7379f859a909a62f3dc7, main 2c3b813e3425391d36f83a0bb788e0025955e3ec.','Six of six first stock-model positions qualified. All three legacy executable sections match main byte for byte. Each loaded image differs at three diagnostic source locations. 최초 여섯 모델 실행이 모두 통과했다. 기존 세 이미지의 실행 코드는 동일하며 진단용 소스 위치에서 각 3바이트가 달라졌다.','Stock QEMU SHA-256 3ae2c079d4491362fece2abb641f0ff17d88e9008c9fcd13600f249b9bd1c862. Native scheduling 137/137, host Python 109/109, effective selector matrix passed. Four invalid selector builds rejected; fallback all-features coop and the six intended builds succeeded. 호스트 스케줄링·파이썬 테스트 및 선택기 검증 통과.','|Case|#|IRQ = ERET PC|SP / X21|CPU / lease|Owned prefix bytes (CRC) before → after|Observed M rows|','|---|---:|---|---|---|---|---:|']
prefix={}; h=crc=0
for n in range(4096):
 i=n*1024; end=i+1024; crc=zlib.crc32(bytes((j^(j>>8)^(j>>16))&255 for j in range(i,end)),crc); prefix[end]=crc; h=(((((h<<7)|(h>>57))&((1<<64)-1))^end)+crc)&((1<<64)-1)
assert (h,crc)==(8765611335505774534,0x78d22ad1)
(e/'expected-prefixes.csv').write_text('end,crc32\n'+''.join(f'{i},{v:08x}\n' for i,v in prefix.items()))
last=0; controls=[]
for c in ('global','partitioned','clustered'):
 d=e/('stream-'+c); dis=(d/'frozen/disassembly.txt').read_text().split('<pi4_stream_crc32_loop_v1>:\n')[1].split('\n\n')[0]
 start=int(re.search(r'^\s*([0-9a-f]+):.*ldr\s+x9, \[x21\]',dis,re.M)[1],16)
 stop=int(re.search(r'^\s*([0-9a-f]+):.*b.cc\s+'+f'{start:x}',dis,re.M)[1],16)+4
 for n in (1,2):
  f=d/'frozen'/f'first-{n}'; a=load(d/f'replay-{n}.json'); s=load(f/'session.json')
  assert s['wall_start_ns']>last and s['reason']=='terminal_quiet'; last=s['wall_end_ns']
  rows=[list(map(int,l.split()[2:])) for l in (f/'uart.bin').read_text().splitlines() if l.startswith('MG ROW')]
  t=next(x for x in rows if x[0]==0 and x[2]==4 and x[4]==0 and x[9]!=65535); frame,pc,sp,ptr=t[5:9]
  dest=int(c=='global'); ret=next(x for x in rows if x[0]==dest and x[2:5]==[11,1,0]); assert ret[6:10]==[frame,pc,sp,ptr] and start<=pc<stop
  stack=next(x for x in rows if x[2:4]==[1,0]); assert stack[4]<=frame<=sp<=ptr<stack[5]
  ext=[(cpu,k,p) for _,_,_,cpu,k,p in a['raw_observer_mapping']]; assert (0,'irq',pc) in ext and (dest,'eret',pc) in ext
  points=[x for x in rows if x[2:4]==[5,0]]; assert all(prefix[x[6]]==x[7] and x[8]==ptr for x in points)
  pre=max((x for x in points if x[4:6]==[1,1]),key=lambda x:x[6]); post=min((x for x in points if x[4:6]==[ret[5],ret[5]]),key=lambda x:x[6]); assert pre[0]==0 and post[0]==dest and pre[6]<post[6]
  terms=[x for x in rows if x[2]==13]; assert any(x[3]==0 and x[6:10]==[4096,h,4194304,crc] for x in terms) and sorted(x[9] for x in terms if x[3])==[136,392,528]
  R.append(f'|{c}|{n}|{pc:#x}|{sp:#x} / {ptr:#x}|0→{dest} / 1→{ret[5]}|{pre[6]} ({pre[7]:08x}) → {post[6]} ({post[7]:08x})|{len(points)}|')
 old,new=[e/(k+'-'+c) for k in ('base','legacy')]
 aa,bb=[(q/'frozen/kernel8.img').read_bytes() for q in (old,new)]
 dif=[i for i,(x,y) in enumerate(zip(aa,bb)) if x!=y]; assert len(aa)==len(bb) and dif==[20680,20736,20808]
 for i in dif:
  p,l,line,col=struct.unpack_from('<QQII',aa,i-16); assert aa[p-0x80000:p-0x80000+l]==b'src/pi4_migration.rs' and struct.unpack_from('<I',bb,i)[0]==line+1
 ma,mb=[load(q/'frozen/freeze.json') for q in (old,new)]; assert {k:v for k,v in ma.items() if k not in ('hashes','source')}=={k:v for k,v in mb.items() if k not in ('hashes','source')}
 for q in (old,new):
  x,y=[load(q/f'replay-{tag}.json') for tag in ('old','new')]; assert x.get('reason')==y.get('reason') and x.get('observation')==y.get('observation')
  controls.append(f"|{q.name}|{sha(q/'frozen/kernel8.img')}|{x.get('reason',x.get('observation'))}|")
R+=['All 4,096 expected prefix CRCs regenerated independently using zlib. UART contains sparse per-lease samples and one ordered summary for 4,194,304 bytes, CRC 0x78d22ad1 and digest 8765611335505774534 per position. Peer products 136, 392 and 528. 각 실행의 UART는 일부 접두 행과 전체 순서 요약을 보존한다. 독립 생성한 4096개 예상 접두값은 CSV에 담았다.','## Legacy controls / 기존 경로','One first control launch per base/candidate policy, read by both old and new tools. Wire v2 schema, flags, QEMU hash, timing and ordinal manifests identical except source/artifact hashes. Image offsets 20680, 20736 and 20808 encode Rust panic source line numbers in .rodata, changing 269→270, 487→488 and 333→334 in src/pi4_migration.rs. Full executable, workload, IRQ/return paths and scheduler/context machine instructions identical. 기존 실행 코드와 매니페스트 설정이 일치하며 .rodata의 패닉 소스 줄 번호만 달라졌다. 기본 합산과 스케줄링 정책은 그대로이며 조기 종료에서는 최종 UART 합계 증거를 얻지 못했다.','|Control|Image SHA-256|Old and new reader outcome|','|---|---|---|',*controls,'Legacy workload target 4,096 checkpoints, sum 2,147,516,416 and digest 18,080,812,676,020,141,577. Only completed control summaries can attest these at runtime. 이번 검증은 결함 주입 없이 stock Pi 4 QEMU에서 수행했다. 실기 결과는 포함하지 않는다.']
for p in (out/'report.en-ko.md',e/'report.en-ko.md'):p.write_text('\n\n'.join(R[:4])+'\n\n'+'\n'.join(R[4:13])+'\n\n'+'\n\n'.join(R[13:16])+'\n\n'+'\n'.join(R[16:])+'\n')
for name in ['build.sh','run.sh','base.sh','verify.py']:(e/name).write_bytes((out/name).read_bytes())
files=sorted(p for p in e.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
(e/'SHA256SUMS').write_text(''.join(sha(p)+'  '+str(p.relative_to(e))+'\n' for p in files))
with zipfile.ZipFile(out/'observations.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[e/'SHA256SUMS']:z.write(p,p.relative_to(e))
with zipfile.ZipFile(out/'observations.zip') as z:assert z.testzip() is None
print(sha(out/'observations.zip'))