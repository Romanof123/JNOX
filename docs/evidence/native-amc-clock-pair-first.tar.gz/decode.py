from pathlib import Path
import collections,hashlib,json,re,struct
r=Path(__file__).resolve().parent;co=r/'cohort';raw=r/'raw';frozen=json.loads((raw/'combined-freeze.json').read_bytes()); ring=(2,5,1,6,3,7,4,8)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def decode(f):
    k=f['index'];d=co/f'first-{k}';u=collections.defaultdict(list);pv=json.loads((raw/f'first-{k}-report.stdout').read_bytes())
    se=json.loads((d/'session.json').read_bytes());assert se['marker']=='end' and all(sha(d/n)==h for n,h in se['hashes'].items())
    la=json.loads((d/'launch.json').read_bytes());assert la['argv']==f['argv'] and sha(d/'manifest.json')==f['manifest']
    for line in (d/'uart.bin').read_text().splitlines():
        p=line.split()
        if p[:2]==['NATIVE','AMC']:u[p[2]].append(tuple(map(int,p[3:])))
    ver,E,hz,q,N,idle,term,origin=u['CONFIG'][0]; assert hz==62500000 and q==3125000
    state=f['states']; roots=[s['root'] for s in state]; mem=(d/'ram.bin').read_bytes(); base=la['ram_base'];phys=lambda a,l:mem[a-base:a-base+l]
    def desc(ttbr,va):
        pa=ttbr&0x0000fffffffff000
        for off in (30,21,12):
            leaf=struct.unpack('<Q',phys(pa+8*((va>>off)&511),8))[0]
            if not leaf&1:return None
            assert leaf&3==3;pa=leaf&0x0000fffffffff000
        return leaf
    pages=[]
    for s in state:
        pte=desc(s['root'],0x1400000)
        if f['page']:
            assert pte and pte>>6&3==3 and pte>>53&3==3 and pte>>10&1 and pte>>2&7==0 and pte&0x0000fffffffff000==s['clock_pa']
            for root in roots:
                priv=desc(root,s['clock_pa']);assert priv and priv>>6&3==0 and priv>>53&3==3 and priv&0x0000fffffffff000==s['clock_pa']
            page=phys(s['clock_pa'],4096);assert int.from_bytes(page[:8],'little')==0 and not any(page[64:])
            pages.append((s['slot'],hex(s['clock_pa']),hex(pte),hex(s['root'])))
        else:assert pte is None
    assert len({a[1] for a in pages})==len(pages)
    a,count,w,loss=u['INTERVALS'][0];rows=list(struct.iter_unpack('<23Q',phys(a,count*23*8)));assert loss==0 and u['END'][0][1]==0
    if f['page']:
        _,va,a,cn,cw,closs,cntk=u['CLOCKS'][0];assert (va,cn,cw,closs,cntk)==(0x1400000,count,4,0,1)
        pubs=list(struct.iter_unpack('<4Q',phys(a,32*count)))
    else:pubs=[];cntk=None;assert not u['CLOCKS']
    trace=None
    if f['external']:
        expected=[(r[0],r[10]) for r in rows if r[0] in (1,2) and r[4]<N]
        trace=[(1 if x==b'5' else 2,int(y,16)) for x,y in re.findall(rb'Taking exception (2|5) \[(?:SVC|IRQ)\]\r?\n\.\.\.from EL0 to EL1\r?\n(?:\.\.\.with ESR [^\n]+\n)?\.\.\.with ELR (0x[0-9a-fA-F]+)',(d/'exceptions.log').read_bytes())]
        assert trace==expected;trace=len(trace)
    service=collections.Counter(); last={}; grants=collections.defaultdict(list); calls=collections.defaultdict(list);switches=[];frames={}
    for i,v in enumerate(rows):
        cause,op,t,R,src,g,delta,used=v[:8];dst,dg=v[13:15]
        if src<N:
            assert v[12]==roots[src]; frames[src,g]=v[10:12]
            if cause!=3:
                assert delta==t-R and (not i or R>=rows[i-1][2]);service[src,g]+=delta
            assert service[src,g]==used
            if cause==2:calls[src,g].append(v)
        else:assert delta==0
        if dst<N:
            assert v[21] in (0,roots[dst]) and v[18]>0
            if (dst,dg) in frames:assert v[15:17]==frames[dst,dg]
        if dst!=src:switches.append(dict(i=i,cause=cause,op=op,entry=t,compare=v[9],src=src,g=g,dst=dst,dg=dg,srcpc=v[10],dstpc=v[15],srcsp=v[11],dstsp=v[16],srcroot=v[12],dstroot=v[21],used=used))
        if f['page']:
            seq,pR,b,pg=pubs[i];k2=dst,dg
            if dst>=N or i+1>=len(rows) or rows[i+1][0]==3:assert seq==pR==0;continue
            z=rows[i+1]
            assert seq>last.get(k2,0) and seq%2==0 and pR==z[3] and v[2]<=pR<=z[2] and z[4:6]==k2 and pg==dg and b==service[k2] and z[7]==b+(z[2]-pR) and z[9]==min(v[17],pR+v[18])
            last[k2]=seq;grants[k2].append((pR,z[2],b,seq))
    def sample(key,wall,cpu):
        assert wall%16==0 and cpu%16==0;tick=origin+wall//16
        assert any(start<=tick<=end and (settled+tick-start)*16==cpu for start,end,settled,seq in grants[key]);return tick
    _,IX,AR,L,drops=u['CLOCK_EVIDENCE'][0];assert not drops
    pa,gn,stride=u['RESULTS'][0]; results={}; admitted={}; st={}; bracket_tick_map={}
    for e in u['LIFE']:
        kind,now,slot,g,mode=e[:5];key=slot,g
        if kind==1:admitted[key]=e
        if kind not in (3,4,5):continue
        ad=admitted[key];args=state[slot]['task']['argv'][ad[7]]; captured=phys(pa+(16*slot+g)*stride,936)
        _,plen,off,elen=struct.unpack('<4Q',phys(IX+32*(16*slot+g),32));assert plen==elen and off+elen<=L
        cc=phys(AR+off,elen);fail,fast,slow,bc,ov=struct.unpack_from('<3Q2I',cc);assert fail==ov==0;sys=calls[key]
        discover=[z for z in sys if z[1]==20];clocks=[z for z in sys if z[1]==6];assert len(discover)==int(bool(fast+slow)) and (not discover or discover[0][20] in ([0x1400000] if f['page'] else [2**64-38,2**64-95]))
        if f['page']:
            assert not slow
            if k<6:assert not clocks
        else:
            assert not fast and [z[19] for z in clocks]==([2,1]*((len(clocks)+1)//2))[:len(clocks)] and len(clocks)>=2*slow
        n=total=fn=fs=ck=cs=0; stamp=[]; fresh=any(captured)
        if fresh:
            version,id,gen,index=struct.unpack_from('<4I',captured);assert (version,id,gen)==(1,slot,g) and index<2
            n,total=struct.unpack_from('<2Q',captured,16+16*index);RING=[ring[(slot+g+j)%8] for j in range(16)]
            assert total==36*(n//8)+sum(RING[:n%8]);ck,fn,cs,fs,ns,overflow=struct.unpack_from('<IIQQII',captured,112);assert not overflow
            stamp=[struct.unpack_from('<3Q',captured,144+24*j) for j in range(ns)]
            if kind==3:
                stamp.append(struct.unpack_from('<3Q',captured,912));assert stamp[-1][2]==n and now<=ad[6] and e[7]==slot
                assert any(c[1]==1 and c[2]==now and c[19]==slot for c in sys)
                if args[1]!='stream':assert fn==(int(args[2]) if args[1]=='finite' else 16) and list(struct.unpack_from('<16I',captured,48))[:fn]==RING[:fn] and fs==sum(RING[:fn])
                if args[1]=='survivor':assert (ck,cs)==(8,36)
            if f['page']:st[key]=[(sample(key,x,y),z) for x,y,z in stamp]
            else:
                pairs={(v[7]*16,(w[2]-origin)*16) for v,w in zip(clocks,clocks[1:]) if v[19]==2 and w[19]==1};assert all((y,x) in pairs for x,y,z in stamp)
                st[key]=[(origin+x//16,z) for x,y,z in stamp]
        brs=[]
        if k==6:
            assert len(clocks)==4*bc and 2<=bc<=1024 and fast>=bc
            for j in range(bc):
                g0,pr,c0,m0,cpu,wall,m1,c1,backend=struct.unpack_from('<9Q',cc,32+j*72)
                assert g0==g and backend==1 and c0<=cpu<=c1 and m0<=wall<=m1
                tick=sample(key,wall,cpu); cs4=clocks[4*j:4*j+4];assert [z[19] for z in cs4]==[2,1,1,2] and [((z[7] if z[19]==2 else z[2]-origin)*16) for z in cs4]==[c0,m0,m1,c1]
                brs.append([tick,c1-c0,m1-m0])
            bracket_tick_map[key]=[b[0] for b in brs]
        assert service[key]==e[5]
        results[f'{slot}.{g}']=dict(kind=kind,count=n,sum=total,finite=[fn,fs],checkpoint=[ck,cs],charge=e[5],margin=e[6]-now,page=fast,fallback=slow,discover=len(discover),clock_svcs=len(clocks),brackets=bc,bracket_cpu_range=[min(b[1] for b in brs),max(b[1] for b in brs)] if brs else None,bracket_wall_range=[min(b[2] for b in brs),max(b[2] for b in brs)] if brs else None)
    cross=None; control=None
    if k==6:
        pre=next(x for x in switches if (x['src'],x['g'],x['dst'],x['dg'])==(0,0,1,0));back=next(x for x in switches if (x['src'],x['g'],x['dst'],x['dg'])==(1,0,0,0))
        assert pre['srcpc']==back['dstpc'] and pre['srcsp']==back['dstsp'] and pre['srcroot']==back['dstroot']
        assert min(bracket_tick_map[0,0])<pre['entry']<back['entry']<max(bracket_tick_map[0,0]) and grants[0,1][0][2:]==(0,2)
        control=dict(preemption=pre,resumption=back,low_clock_samples_before_after=[min(bracket_tick_map[0,0]),max(bracket_tick_map[0,0])],fresh_initial_R_settled_seq=grants[0,1][0],peer_service=service[1,0],low_service=service[0,0])
    else:
        e=next(e for e in u['LIFE'] if e[0]==9);v=next(v for v in rows if v[4:6]==(1,0) and v[7]>=q)
        b=E+(5 if f['case']=='staggered' else 2)*q;x=min(t for t,n in st[1,0] if t>=e[1] and n)
        cross=dict(b=b,CVAL=v[9],i=v[2],c=e[1],x=x,observed_ns=(x-b)*16,cause=v[:2],used=v[7],spill=v[8],root=hex(v[12]),ppi=v[:2]==(1,30),timely=(b<=v[2]<=e[1]<=x<b+q))
        assert cross['timely'] and ((not f['page']) or cross['ppi'])
    return dict(position=k,session=sha(d/'session.json'),public_verdict=pv['status'],public_issues=pv['issues'],intervals=count,lifecycle=len(u['LIFE']),drops=[loss,u['END'][0][1],drops],trace_el0=trace,pages=pages,cntkctl=cntk,publications=sum(len(v) for v in grants.values()),products=results,crossing=cross,control=control)
result=[]
for p in frozen['positions']:
    v=decode(p);result.append(v);print(v['position'],v['public_verdict'],v['crossing'],v['control'],flush=True)
(raw/'independent.json').write_text(json.dumps(result,indent=2)+'\n')
