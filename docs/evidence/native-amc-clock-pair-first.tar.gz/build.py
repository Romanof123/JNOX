import hashlib,json,os,shlex,shutil,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;src=r/'source';raw=r/'raw';out=src/'output/amc-clock';out.mkdir(parents=True)
os.environ['PATH']='/home/ywcho/.cargo/bin:'+os.environ['PATH']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,cmd):
    (raw/(label+'.cmd')).write_text(shlex.join(list(map(str,cmd)))+'\n')
    p=subprocess.run(cmd,cwd=src,capture_output=True)
    (raw/(label+'.stdout')).write_bytes(p.stdout);(raw/(label+'.stderr')).write_bytes(p.stderr);(raw/(label+'.exit')).write_text(str(p.returncode)+'\n')
    print(label,p.returncode, (p.stderr or p.stdout).decode(errors='replace')[-420:] if p.returncode else '',flush=True)
    return p.returncode
run('source',['git','rev-parse','HEAD']);run('fs',['findmnt','-T',str(src),'-no','SOURCE,FSTYPE']);run('rust',['rustc','-Vv']);run('cargo',['cargo','--version']);run('targets',['rustup','target','list','--installed'])
for label in ('clang','ld.lld','cc','qemu-system-aarch64','aarch64-linux-gnu-objdump'):run(label,[label,'--version'])
run('sdk-production-controls',['python3','tools/native_clock_pair_controls.py'])
base='examples/native-amc-clock'
for i in range(4):run(f'build-slot{i}',['sh','sdk/native-aarch64/build.sh',f'{base}/slot{i}.c',f'output/amc-clock/slot{i}.elf'])
pack=['python3','tools/build_native_el0.py','--policy','amc']
four=['--elf','output/amc-clock/slot0.elf']
for i in range(1,4):four+=['--peer-elf',f'output/amc-clock/slot{i}.elf']
recipes=[('page-normal-hi','normal-hi',True),('page-staggered','staggered',True),('fallback-normal-hi','normal-hi',False)]
if all((out/f'slot{i}.elf').is_file() for i in range(4)):
    for dir,fixture,enabled in recipes:
        run('pack-'+dir,pack+four+['--out','output/amc-clock/'+dir]+(['--amc-clock-page'] if enabled else [])+['--amc-manifest','examples/native-amc/config/'+fixture+'.json'])
run('build-control-C',['sh','sdk/native-aarch64/build.sh',f'{base}/control0.c','output/amc-clock/low-control.elf'])
run('build-control-Rust',['sh','sdk/native-aarch64/build-rust.sh',f'{base}/control-rust/Cargo.toml','output/amc-clock/high-control.elf'])
if all((out/(a+'-control.elf')).is_file() for a in ('low','high')):run('pack-brackets',pack+['--out','output/amc-clock/brackets','--amc-clock-page','--amc-manifest',f'{base}/control.json','--elf','output/amc-clock/low-control.elf','--peer-elf','output/amc-clock/high-control.elf'])
if all((out/n/'manifest.json').is_file() for n in ['page-normal-hi','page-staggered','fallback-normal-hi','brackets']):
    run('cohort-seal',['python3','tools/native_amc_clock_report.py','seal',r/'cohort',*[out/n for n in ['page-normal-hi','page-normal-hi','page-staggered','page-staggered','fallback-normal-hi','brackets']]])
run('worktree',['git','status','--porcelain','--untracked-files=normal'])
