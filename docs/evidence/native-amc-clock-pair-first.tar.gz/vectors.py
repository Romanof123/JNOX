from pathlib import Path
import re,subprocess,json
r=Path(__file__).resolve().parent;raw=r/'raw';co=r/'cohort';out={};data=json.loads((co/'cohort.json').read_bytes())
for item in data['positions']:
    j=item['ordinal'];pk=Path(item['package']);ker=pk/'kernel.elf'
    sy=subprocess.check_output(['aarch64-linux-gnu-nm','-S',ker],text=True)
    vec=int(next(s.split()[0] for s in sy.splitlines() if s.endswith(' native_el0_vectors')),16)
    def dis(start,end):
        return subprocess.check_output(['aarch64-linux-gnu-objdump','-D','-j','.text','--start-address='+hex(start),'--stop-address='+hex(end),ker],text=True)
    tmp=[]
    for offset in (0x400,0x480):
        txt=dis(vec+offset,vec+offset+24);tmp.append(txt)
        assert re.search(r'str\s+x2, \[sp, #-16\]!',txt) and 'cntpct_el0' in txt and 'isb' in txt
    cat=(co/f'{j}-kernel.dis').read_text().splitlines()
    for i,line in enumerate(cat):
        if re.search(r'mrs\s+x17, cntpct_el0',line) and any(re.search('msr\\s+cntp_cval_el0',l) for l in cat[i:i+15]):
            stop=next(k for k in range(i+1,i+70) if re.search(r'\beret\b',cat[k]))
            lo=int(line.split(':')[0].strip(),16);hi=int(cat[stop].split(':')[0].strip(),16)
            tmp.append('\n'.join(cat[i:stop+1]));break
    else:raise ValueError('return sequence')
    ena=item['enabled']; assert ('stlr' in tmp[-1])==ena
    (raw/f'vectors-{j}.dis').write_text('\n'.join(tmp)+'\n')
    out[str(j)]={'return_mrs':hex(lo),'eret':hex(hi),'return_instruction_distance':(hi-lo)//4,'user_sync_entry':hex(vec+0x400),'user_sync_mrs':hex(vec+0x408),'user_IRQ_entry':hex(vec+0x480),'user_IRQ_mrs':hex(vec+0x488),'entry_instruction_distance':2,'R_publication':ena}
(raw/'vector-brackets.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['1']))
