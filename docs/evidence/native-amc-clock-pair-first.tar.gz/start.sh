set -eu
cd /home/ywcho/jnox353-896518d.oU4wB1sx
mkdir source raw
cd source
git init -q
git remote add origin https://github.com/Romanof123/JNOX.git
git fetch -q --depth=2 origin 896518d8edcfc850dc16361dcde2d1edd87c0d4c
git checkout -q --detach FETCH_HEAD
git log --oneline -2
cat docs/native-amc-clock-pair.en-ko.md
git ls-files | grep -Ei 'amc.*clock|clock.*amc|clock.pair|clock.page'