from pathlib import Path
import datetime,hashlib,json,shlex,shutil,subprocess,sys
r=Path(__file__).resolve().parent;raw=r/'raw';src=r/'source';co=r/'cohort'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dig=sha(co/'cohort.json');assert dig==(raw/'cohort-seal.stdout').read_text().strip()
data=json.loads((co/'cohort.json').read_bytes());assert data['timeout']==120
rev='896518d8edcfc850dc16361dcde2d1edd87c0d4c'
assert (raw/'source.stdout').read_text().strip()==rev
supp={'source':rev,'cohort':dig,'sdk_controls_stdout':sha(raw/'sdk-production-controls.stdout'),'requirements':sha(src/'docs/native-amc-clock-pair.en-ko.md'),'tools':{k:(raw/(k+'.stdout')).read_text().strip() for k in ['rust','targets','cargo','clang','ld.lld','qemu-system-aarch64','aarch64-linux-gnu-objdump','cc']},'positions':[]}
for j,pos in enumerate(data['positions'],1):
    pk=Path(pos['package']);m=json.loads((pk/'manifest.json').read_bytes())
    assert sha(pk/'kernel.elf')==pos['kernel'] and m['commit']==rev and m['tracked_changes']=='' and len(m['slots'])==(2 if j==6 else 4)
    cfg=src/('examples/native-amc-clock/control.json' if j==6 else 'examples/native-amc/config/'+pos['case']+'.json');assert sha(cfg)==pos['config'] and json.loads(cfg.read_bytes())==m['amc']
    symbols=subprocess.check_output(['aarch64-linux-gnu-readelf','-Ws',pk/'kernel.elf'],text=True)
    def symbol(n):
        rows=[line.split() for line in symbols.splitlines() if 'OBJECT' in line and n in line]
        return [(int(x[1],16),int(x[2],0)) for x in rows]
    spaces=[(int(x[1],16),int(x[2],0)) for x in [l.split() for l in symbols.splitlines() if 'native_el0_mmu' in l and '6SPACES' in l and 'OBJECT' in l]]
    (addr,size),=spaces; pages=symbol('jnox_native_amc_clock_pages');assert bool(pages)==pos['enabled']
    states=[]
    if pages:assert pages[0][1]==4096*len(m['slots'])
    for i,a in enumerate(m['slots']):
        assert sha(pk/a['elf'])==a['elf_sha256']==pos['slots'][i]
        expected=((i+1)<<48)|(addr+i*(size//len(m['slots'])))
        assert expected==a['expected_ttbr0_el1'] and a['amc_task']==m['amc']['tasks'][i]
        states.append(dict(slot=i,root=expected,clock_pa=pages[0][0]+i*4096 if pages else None,elf=a['elf_sha256'],task=a['amc_task']))
        dis=(co/f'{j}-slot{i}.dis').read_text();assert '<jnox_clock_sample>' in dis and 'cntpct_el0' in dis
        if j==6 and i==1:assert '<rust_clock_sample>' in dis
    path=co/f'first-{j}'
    supp['positions'].append(dict(index=j,case=pos['case'],page=pos['enabled'],external=pos['trace'],source_config=pos['config'],manifest=pos['manifest'],states=states,argv=pos['argv'],raw_uart=str(path/'uart.bin'),ram=str(path/'ram.bin'),exceptions=str(path/'exceptions.log') if pos['trace'] else None,session=str(path/'session.json')))
assert len({(v['case'],v['page'],v['external']) for v in supp['positions']})==6
supp['frozen_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
path=raw/'combined-freeze.json';path.write_text(json.dumps(supp,indent=2)+'\n');(raw/'combined-freeze.sha256').write_text(sha(path)+'\n')
print('combined',sha(path),'public',dig,flush=True)
