sh sdk/native-aarch64/build.sh examples/native-amc-clock/slot0.c output/amc-clock/slot0.elf
