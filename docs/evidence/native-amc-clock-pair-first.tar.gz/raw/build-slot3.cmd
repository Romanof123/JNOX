sh sdk/native-aarch64/build.sh examples/native-amc-clock/slot3.c output/amc-clock/slot3.elf
