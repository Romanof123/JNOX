sh sdk/native-aarch64/build.sh examples/native-amc-clock/slot2.c output/amc-clock/slot2.elf
