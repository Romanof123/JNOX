sh sdk/native-aarch64/build-rust.sh examples/native-amc-clock/control-rust/Cargo.toml output/amc-clock/high-control.elf
