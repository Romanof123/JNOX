sh sdk/native-aarch64/build.sh examples/native-amc-clock/control0.c output/amc-clock/low-control.elf
