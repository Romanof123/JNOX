findmnt -T /home/ywcho/jnox353-896518d.oU4wB1sx/source -no SOURCE,FSTYPE
