sh sdk/native-aarch64/build.sh examples/native-amc-clock/slot1.c output/amc-clock/slot1.elf
