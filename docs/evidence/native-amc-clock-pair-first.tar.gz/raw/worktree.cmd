git status --porcelain --untracked-files=normal
