/usr/bin/python3 tools/native_amc_clock_report.py capture /home/ywcho/jnox353-896518d.oU4wB1sx/cohort/cohort.json f1c496b445ba4baf2657abd078d9fda72fe07b26739e6141e026108d5a205e13 2
