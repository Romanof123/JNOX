from pathlib import Path
import hashlib,json,shlex,subprocess,sys,datetime
r=Path(__file__).resolve().parent;raw=r/'raw';src=r/'source';co=r/'cohort'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=sha(co/'cohort.json');assert sha(raw/'combined-freeze.json')==(raw/'combined-freeze.sha256').read_text().strip();assert not (co/'first-1').exists()
for i in range(1,7):
    if i>1 and not (co/f'first-{i-1}'/'session.json').is_file():break
    for action in ('capture','report'):
        label=f'first-{i}-{action}'; cmd=[sys.executable,'tools/native_amc_clock_report.py',action,str(co/'cohort.json'),digest,str(i)]
        ses=co/f'first-{i}'/'session.json'
        if action=='report':
            if not ses.is_file():break
            cmd.append(sha(ses))
        (raw/(label+'.cmd')).write_text(shlex.join(cmd)+'\n');(raw/(label+'.utc')).write_text(datetime.datetime.now(datetime.timezone.utc).isoformat())
        p=subprocess.run(cmd,cwd=src,capture_output=True)
        (raw/(label+'.exit')).write_text(str(p.returncode)+'\n');(raw/(label+'.stdout')).write_bytes(p.stdout);(raw/(label+'.stderr')).write_bytes(p.stderr)
        try:
            v=json.loads(p.stdout);print(label,p.returncode,v.get('status'),v.get('issues'),v.get('unknown'),v.get('detail'),flush=True)
        except (ValueError,AttributeError):print(label,p.returncode,p.stdout[:160],p.stderr[-400:],flush=True)
