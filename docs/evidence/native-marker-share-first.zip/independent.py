from pathlib import Path
import json, struct, zipfile, hashlib
from fractions import Fraction
z=zipfile.ZipFile(Path(__file__).with_name('original.zip'))
def j(p): return json.loads(z.read(p))
for arm in ['plain','observed']:
    def raw(p): return z.read(arm+'/'+p)
    sess=j(arm+'/session.json')
    for name,h in sess['hashes'].items(): assert hashlib.sha256(raw(name)).hexdigest()==h
    assert hashlib.sha256(raw('session.json')).hexdigest()==z.read(arm+'.stdout').decode().strip()
    mem=raw('ram.bin'); report=j(arm+'.json')
    table=list(struct.iter_unpack('<16Q',mem[0xf008:0xf008+0x10080]))
    assert table[0][1]==3 and table[0][7:9]==(0,0)
    stops=[x for x in table[1:1+table[0][6]] if x[0]==3]
    assert len(stops)==len(report['closures'])==38
    A=[0,0]; svc=[]; gaps=[]; prefix=[]; previous=None
    for x,g in zip(stops,report['closures']):
        _,end,pid,lease,vec,start,compare=x[:7]
        assert (lease,start,compare,end,pid)==tuple(g[k] for k in ('lease','start','compare','stop','pid'))
        gaps.append(start-previous if previous else 0); previous=end
        A[pid]+=end-start
        if vec==0x480:
            assert compare-start==625000
            svc.append(end-start); prefix.append(2*A[0]-A[1]); a,b=A
    assert len(svc)==36 and min(svc)>=625000 and max(svc)<=781250 and min(gaps)>=0 and max(gaps)<=156250 and min(prefix)>=-781250 and max(prefix)<=1562500
    assert a+b>=22500000 and abs(Fraction(a,a+b)-Fraction(1,3))<=Fraction(1562500,67500000)
    print(arm,min(svc),max(svc),max(gaps),min(prefix),max(prefix),a,b,a+b,a/(a+b))
    if arm=='plain': continue
    for pc,op in [(0x1218,0xd53be031),(0x121c,0xf9000211),(0x1040,0xd53be020),(0x1044,0xd2808001),(0x1058,0xd53be020),(0x105c,0xd2809001)]:
        assert struct.unpack_from('<I',mem,pc)[0]==op
    buf=raw('markers.bin'); n,err,r,t=struct.unpack_from('<4Q',buf)
    assert n==152 and err==0 and 0<min(r,t)<=max(r,t)<=100000 and not any(buf[32+n*48:])
    rows=list(struct.iter_unpack('<6Q',buf[32:32+n*48])); tid=j(arm+'/marker-cpu.json')['thread-id']
    last=lt=0
    for site,cpu,thread,w,c,v in rows:
        assert cpu==0 and thread==tid and last<=w<=v and lt<=c
        last,lt=v,c
    intervals=report['marker_observation']['intervals']; widths=[]; classes={}
    for i,(grant,x) in enumerate(zip(intervals,stops)):
        a,b,c,d=rows[4*i:4*i+4]; irq=x[4]==0x480; site=4 if irq else 2
        assert [q[0] for q in (a,b,c,d)]==[0,1,site,site+1]
        ws=[b[5]-a[3]+2*r,d[5]-c[3]+2*r]; widths.extend(ws)
        wall=[max(0,c[3]-b[5]-2*r),d[5]-a[3]+2*r]
        cpu=[max(0,c[4]-b[4]-2*t),d[4]-a[4]+2*t]
        e=-(-wall[1]//1000); off=[max(0,wall[0]-cpu[1]-e),max(0,wall[1]-cpu[0]+e)]
        assert cpu[0]<=wall[1]+e and max(ws)<=1000000 and [ws,wall,cpu,off]==[grant[k] for k in ('bracket_ns','wall_ns','cpu_ns','outside_cpu_ns')]
        classes.setdefault('irq' if irq else 'svc',[]).append(off)
    print(tid,r,t,min(widths),max(widths),{k:(min(a for a,b in v),max(b for a,b in v),sum(a>0 for a,b in v)) for k,v in classes.items()})
