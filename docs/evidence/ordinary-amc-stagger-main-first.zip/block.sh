set -eu
public_revision=0cc2e63c1dc5ba10b4103237846b180c295417cb
revision=${JNOX_REPLAY_REVISION:-$public_revision}
# For an override, fetch its integration branch first / 통합 브랜치는 먼저 가져온다.
if [ "$revision" = "$public_revision" ] && ! git cat-file -e "$revision^{commit}" 2>/dev/null; then
    git fetch https://github.com/Romanof123/JNOX.git refs/pull/237/head
fi
revision=$(git rev-parse --verify "$revision^{commit}")
out=$(mktemp -d)
git worktree add --detach "$out/source" "$revision"
cd "$out/source"
qemu=$(command -v qemu-system-aarch64)
export CARGO_TARGET_DIR="$out/target"
status=0
for app in exact-lo exact-hi over-hi stagger-idle; do
    (cd kernel && JNOX_BOARD=virt JNOX_PROFILE=amc JNOX_APP="$app" \
        cargo rustc --release --locked -j1 -- -C "link-arg=-Map=$out/$app.map")
    elf="$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel"
    python3 tools/ordinary_amc_capture.py freeze "$app" "$out/$app" "$elf" "$qemu" "$revision" > "$out/$app.freeze"
    python3 tools/ordinary_amc_capture.py run "$out/$app" "$(cat "$out/$app.freeze")" > "$out/$app.session" || status=1
    python3 tools/ordinary_amc_replay.py "$out/$app" "$(cat "$out/$app.session")" > "$out/$app.replay.json" || status=1
done
exit "$status"
