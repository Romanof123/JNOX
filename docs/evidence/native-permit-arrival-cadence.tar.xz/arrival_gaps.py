"""Decompose #401's adjacent COMPLETE brackets into target spacing and per-activation latency differences."""
import csv
import hashlib
import json
import runpy
import struct
import sys
from pathlib import Path


def table(root,run,cold=False):
    cap=run/"cap"
    launch=json.loads((cap/"launch.json").read_bytes())
    module=root/"verification"/"capture.py"
    assert hashlib.sha256(module.read_bytes()).hexdigest()=="dc0bda0e0c008c4fc702d1b5b988aac8e1a5a1ec3a7bce9236e792ac4a5e7e2f"
    helpers=runpy.run_path(str(module))
    d=helpers["read_run"](root,run)
    assert d["revision"]=="aa8e7e104033a372eed0675f3b76f7fb9af2a38e" and d["safety_loss"]==[[0]]
    syms=helpers["symtab"](root/"apps/receiver.elf")
    ram=(cap/"ram.bin").read_bytes()
    def region(addr,size):
        i=addr-launch["ram_base"]
        assert 0<=i<=len(ram)-size
        return ram[i:i+size]
    def read(sym):
        addr,n=syms["safety_"+sym]
        out=bytearray()
        while len(out)<n:
            va=addr+len(out)
            page=d["roots"][1]
            for shift in (30,21,12):
                pte=int.from_bytes(region(page+8*((va>>shift)&511),8),"little")
                assert pte&3==3
                page=pte&0x0000fffffffff000
            k=va%4096
            out.extend(region(page+k,min(n-len(out),4096-k)))
        return bytes(out)
    assert int.from_bytes(read("activation_count"),"little")==17
    activations=list(struct.iter_unpack("<19Q",read("activations")))[:17]
    ev=d["events"]
    checks=[x for x in ev if x[0]==12 and x[3]==1]
    completes=[x for x in ev if x[0]==10]
    assert len(checks)==len(completes)==17
    def term(i):
        p,w,e,end=activations[i][:4]
        c=checks[i][2]
        en,ex=completes[i][2:4]
        assert p==d["epoch"]+62500*(5*i+(i!=8))
        assert p<=w<=c<=e<=en<=ex<=end
        assert ev[ev.index(checks[i])+1][2:6]==[1,60,1,0]
        assert completes[i][4]==0
        r=[x for x in d["received_rows"] if x[0]==i]
        return dict(target=p,wake=w,check=c,complete_entry=en,width=ex-en,
                    target_wake=w-p,wake_check=c-w,check_entry=en-c,rx=len(r),
                    commit=[int(x[6]==0) for x in r].count(1))
    terms=list(map(term,range(17)))
    if cold:
        def one(rows):
            row,=rows
            return row
        first=ev[ev.index(checks[0]):ev.index(completes[0])+1]
        snap=one(x for x in first if x[0]==7)
        handle=snap[2]
        received=one(x for x in first if x[0]==6 and x[2:5]==[1,35,0] and x[7:9]==[handle,44])
        released=one(x for x in first if x[0]==6 and x[2:5]==[1,36,0] and x[6]==handle)
        pre=one(x for x in first if x[0]==12 and x[3]==2)
        committed=one(x for x in first if x[0]==5 and x[2:8]==[1,60,2,0,1,1])
        empty=one(x for x in first if x[0]==6 and x[2:5]==[1,35,2**64-11])
        a=terms[0]
        ends=[a["target"],a["wake"],a["check"],snap[1],received[1],released[1],pre[2],committed[1],
              empty[1],a["complete_entry"],a["complete_entry"]+a["width"]]
        assert ends==sorted(ends)
        names=["target_to_wake","wake_to_check","check_to_snapshot","snapshot_to_recv_audit",
               "recv_audit_to_release_audit","release_audit_to_commit_precheck","precheck_to_commit_status",
               "commit_status_to_empty_audit","empty_audit_to_complete_entry","complete_service_width"]
        yield dict(run=run.name,**dict(zip(names,[y-x for x,y in zip(ends,ends[1:])])))
        return
    for j in range(1,17):
        a,b=terms[j-1:j+1]
        spacing=b["target"]-a["target"]
        e=b["complete_entry"]-a["complete_entry"]
        lo=e-a["width"]
        hi=e+b["width"]
        ds=[b[k]-a[k] for k in ["target_wake","wake_check","check_entry"]]
        assert e==spacing+sum(ds)
        yield dict(run=run.name,clock=run.name.split("-")[1],policy=d["policy"],case=d["roles"][0][1],
                   i=j-1,j=j,spacing=spacing,gap_lo=lo,gap_hi=hi,
                   verdict="over" if lo>312500 else ("cross" if hi>312500 else "within"),
                   diff_wake=ds[0],diff_wake_check=ds[1],diff_check_complete_entry=ds[2],
                   previous_complete_width=a["width"],next_complete_width=b["width"],
                   previous_target_to_complete_entry=a["complete_entry"]-a["target"],
                   next_target_to_complete_entry=b["complete_entry"]-b["target"],
                   previous_target_to_wake=a["target_wake"],previous_wake_to_check=a["wake_check"],
                   previous_check_to_complete_entry=a["check_entry"],next_target_to_wake=b["target_wake"],
                   next_wake_to_check=b["wake_check"],next_check_to_complete_entry=b["check_entry"],
                   previous_frames=a["rx"],next_frames=b["rx"],previous_commits=a["commit"],next_commits=b["commit"])


if __name__=="__main__":
    root=Path(sys.argv[1])
    cold=sys.argv[2:]==["--cold-body"]
    assert cold or len(sys.argv)==2
    rows=[r for run in sorted((root/"runs").iterdir()) for r in table(root,run,cold)]
    assert len(rows)==(12 if cold else 192)
    writer=csv.DictWriter(sys.stdout,fieldnames=rows[0].keys(),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
