# CHG-073 integration QA

Candidate f1e2a730614f9313e711b89dcc5a1a9f0b96e760. Independent main reference 17cf31bd02903ea874c8e23b09f342bcebc7ec8b. Handoff predecessor 5ee2f8d47669d8b1ac9833ab02ad7390bf020d7a. All four first cold raspi4b launches ended complete and quiet. The ordinary parser accepted O1/O2. Separate indexed ordinary ERET/task-block and engineering IRQ/SVC/ERET ledgers are included.
- default: full ELF match True; all PT_LOAD headers and bytes match True.
- smp: full ELF match True; all PT_LOAD headers and bytes match True.
- rr: full ELF match False; all PT_LOAD headers and bytes match False.
- E1 RC2. Payload 1958498 / 1958498, generations [5, 5] and [4, 6], statuses ['attributed', 'ambiguous']. Observed intervals 631 and 19896 ticks. SP 0x89220 / 0x91160, depths 0 / 192 bytes. Atomic PCs 0x82208 / 0x82178. Loop rotation False, handoff False.
- E2 RC2. Payload 1744682 / 1744682, generations [5, 5] and [4, 6], statuses ['attributed', 'ambiguous']. Observed intervals 1121 and 30303 ticks. SP 0x89220 / 0x91160, depths 0 / 192 bytes. Atomic PCs 0x82208 / 0x82178. Loop rotation False, handoff False.

Functional replay in E1/E2 verified HIGH resume and structure. Main RR text matches exactly. Compared with main, the only two raw-image byte differences are Rust source location lines 195 to 210 and 181 to 189 in fixed_runtime.rs (columns 9 and 20). Raw RR image matches handoff predecessor. Compared with integrated v1 engineering, linked text grows 452 bytes, rodata 1 byte and BSS 176 bytes. Data and allocated stack sizes match. Each two-cell witness uses 176 bytes. Separate original #146 FIFO/RR replay RC0/0. Integrated v1 FIFO/RR replay RC0/2. Six malformed host replays rejected RC1. Seven incompatible handoff selectors rejected during compilation. The predecessor without the main SMP implementation also rejected the SMP selector. No guest reruns. An initial partial source archive omitted arch/aarch64/target and stopped with build RC101 before any guest. Full pinned worktrees provided that dependency. All four launches ran only after the complete source builds. Raw evidence retained locally; public package paths use relative labels. No physical timing or uninstrumented probe-cost measurements.

Pinned ordinary kernel8.img SHA-256 69db6275a2f6b2dbab0893e92495ce4d6bd3a7480027b1b16ddd5acf9c64beee. Engineering image SHA-256 8b9a459cbb792886e5c37a72a2bdf059426ca4b7bc5d35a63c4d7803b92bbd39.

~~~
   821fc:	d5033fdf 	isb
   82200:	1000004c 	adr	x12, 82208 <pi4_rr_publish+0x24>
   82204:	910003eb 	mov	x11, sp
   82208:	c89ffc01 	stlr	x1, [x0]
   8220c:	d53800a9 	mrs	x9, mpidr_el1
   82210:	d5033fdf 	isb
   82214:	d53be02e 	mrs	x14, cntpct_el0
~~~

~~~
   8216c:	d5033fdf 	isb
   82170:	1000004c 	adr	x12, 82178 <pi4_rr_consume+0x24>
   82174:	910003eb 	mov	x11, sp
   82178:	c8dffd00 	ldar	x0, [x8]
   8217c:	b4000320 	cbz	x0, 821e0 <pi4_rr_consume+0x8c>
   82180:	d53800aa 	mrs	x10, mpidr_el1
   82184:	d5033fdf 	isb
~~~
