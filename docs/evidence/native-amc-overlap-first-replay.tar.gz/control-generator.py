import copy,hashlib,json,re,shlex,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent;source=root/'source';raw=root/'raw'; sc=raw/'checked-controls';sc.mkdir(exist_ok=True)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def examine(name,mode):
    base=root/'original/captures'/('overlap-'+mode); dst=root/'checked-synthetic'/mode/name;dst.mkdir(parents=True)
    for f in base.iterdir():
        if f.name not in ('uart.bin','session.json'): (dst/f.name).hardlink_to(f)
    records=[list(map(int,row.split()[3:])) for row in (base/'uart.bin').read_text().splitlines() if row.startswith('NATIVE AMC LIFE ')]
    lo=[r for r in records if r[2]==0]; hi=[r for r in records if r[2]==1]
    admit,miss,reject,ex=lo;peerin,peerout=hi
    b1=admit[6];epoch=admit[5];q=b1-epoch
    if name=='late-peer':peerout[1]=peerin[6]+1
    if name=='miss-wrong-due':miss[5]+=q
    if name=='miss-removed':records.remove(miss)
    if name=='refusal-removed':records.remove(reject)
    if name=='no-continued-service':ex[5]=miss[6]
    if name=='exit-before-fault':ex[1]=b1-1
    if name=='miss-after-refusal':
        i,j=records.index(miss),records.index(reject);records[i],records[j]=records[j],records[i]; assert records[j] is miss and records[i] is reject
    if name=='miss-only-time-moved':miss[1]+=100
    if name=='wrong-gen':miss[3]+=1
    if name=='misreported-charge':miss[6]+=1
    if name=='late-paired-decision':
        miss[1]+=q//2;reject[1]=miss[1]
    text=(base/'uart.bin').read_bytes()
    start=text.index(b'NATIVE AMC LIFE ');end=text.index(b'NATIVE AMC INTERVALS ',start)
    nl=b'\r\n' if b'\r\n' in text else b'\n'
    text=text[:start]+b''.join(b'NATIVE AMC LIFE '+b' '.join(str(x).encode() for x in r)+nl for r in records)+text[end:]
    text=re.sub(rb'NATIVE AMC END [0-9]+ ',b'NATIVE AMC END '+str(len(records)).encode()+b' ',text)
    (dst/'uart.bin').write_bytes(text)
    session=json.loads((base/'session.json').read_bytes());session['hashes']['uart.bin']=sha(dst/'uart.bin')
    (dst/'session.json').write_text(json.dumps(session,indent=2)+'\n')
    short=mode+'-'+name
    cmd=[sys.executable,'tools/native_amc_report.py','report',str(dst),sha(dst/'session.json')]
    run=subprocess.run(cmd,cwd=source,capture_output=True)
    (sc/(short+'.stdout')).write_bytes(run.stdout);(sc/(short+'.stderr')).write_bytes(run.stderr)
    try:report=json.loads(run.stdout);status=report['status']; issues=report['issues']
    except ValueError:status='rejected';issues=[run.stderr.decode().strip()]
    return {'case':short,'exit':run.returncode,'status':status,'issues':issues,'as_observed':sha(base/'session.json'),'synthetic':sha(dst/'session.json'),'cli':shlex.join(cmd),'records':records}
cases=('late-peer','miss-wrong-due','miss-removed','refusal-removed','no-continued-service','exit-before-fault','miss-after-refusal','miss-only-time-moved','wrong-gen','misreported-charge','late-paired-decision')
results=[]
for m in ('plain','trace'):
    for n in cases:
        x=examine(n,m);results.append(x);print(x['case'],x['status'],x['issues'],flush=True)
(sc/'manifest.json').write_text(json.dumps(results,indent=2)+'\n')
