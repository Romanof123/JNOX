import collections,hashlib,json,re,struct,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent;src=root/'source';orig=root/'original';raw=root/'raw'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
archive=src/'docs/evidence/native-amc-applications-first.tar.gz'
assert sha(archive)=='28d9d30d1b7ed7d848118f90cdd5d59291c73fa9934ea1033c7887d52b35e561'
blob=subprocess.check_output(['git','rev-parse','HEAD^:docs/evidence/native-amc-applications-first.tar.gz'],cwd=src).decode().strip()
assert subprocess.check_output(['git','hash-object',str(archive)],cwd=src).decode().strip()==blob
assert sha(orig/'REPORT.en-ko.md')=='2b904814901b03ae5f2f57c29ed99f8983c4ea8ea7717fef0953ff8fa6df8899'
for line in (orig/'SHA256SUMS').read_text().splitlines():
    h,k=line.split('  ',1);assert sha(orig/k)==h
index=json.loads((orig/'session-index.json').read_bytes());detailed=json.loads((orig/'independent-detailed.json').read_bytes())
result={};overlap={};crossings={}
for name,prior in index.items():
    f=orig/'captures'/name; session=sha(f/'session.json');assert session==prior['session_sha256']
    for k,h in json.loads((f/'session.json').read_bytes())['hashes'].items():assert sha(f/k)==h
    sc=json.loads((raw/(name+'.stdout')).read_bytes());assert sc['session']==session
    result[name]=dict(original=prior['status'],corrected=sc['status'],session=session,issues=sc['issues'],unknown=sc['unknown'])
    if not (name.startswith('overlap-') or name in ('normal-hi-trace','staggered-trace')):continue
    d=collections.defaultdict(list)
    for line in (f/'uart.bin').read_text().splitlines():
        a=line.split()
        if a[:2]==['NATIVE','AMC']:d[a[2]].append(list(map(int,a[3:])))
    addr,count,words,loss=d['INTERVALS'][0];base=json.loads((f/'launch.json').read_bytes())['ram_base'];ram=(f/'ram.bin').read_bytes()
    rows=list(struct.iter_unpack('<23Q',ram[addr-base:addr-base+count*words*8]));_,epoch,hz,q,*_=d['CONFIG'][0];life=d['LIFE']
    if name.startswith('overlap-'):
        lo=[e for e in life if e[2]==0];hi=[e for e in life if e[2]==1]
        admit,miss,reject,exit=lo;assert [e[0] for e in lo]==[1,7,2,3] and [e[0] for e in hi]==[1,3]
        assert miss[5]==reject[5]==epoch+q and miss[1]==reject[1]<exit[1] and reject[7:9]==[1,1]
        assert [admit[3],miss[3],reject[3],exit[3]]==[0,0,1,0] and exit[7]==0 and hi[1][7]==1
        assert len([e for e in life if e[0]==3 and e[1]>e[6]])==1 and hi[1][1]<=hi[1][6]
        assert sum(r[6] for r in rows if r[4:6]==(0,0) and r[2]<=miss[1])==miss[6]
        assert sum(r[6] for r in rows if r[4:6]==(0,0))==exit[5]
        assert any(r[:2]==(2,1) and r[4:6]==(0,0) and r[2]==exit[1] and r[19]==0 for r in rows)
        controls=[(i,r) for i,r in enumerate(rows[:-1]) if r[2]<=miss[1] and rows[i+1][3]>miss[1]];assert len(controls)==1
        i,r=controls[0];nxt=rows[i+1][3];assert r[2]<=miss[1]<nxt and miss[1]+q//2>nxt
        late=exit[1]-exit[6];assert sc['products']['0.0']['completion_lateness_ticks']==late
        overlap[name]=dict(epoch=epoch,q=q,admit=admit,miss=miss,refusal=reject,exit=exit,peer_exit=hi[1],service_at_miss=miss[6],service_at_exit=exit[5],late_ticks=late,late_ns=late*16,decision_entry=r[2],decision_cause=r[:2],decision_CVAL=r[9],next_dispatch_start=nxt,synthetic_moved_tick=miss[1]+q//2)
    else:
        b=epoch+q*(2 if name.startswith('normal') else 5);c=next(e[1] for e in life if e[0]==9);r=next(r for r in rows if r[4:6]==(1,0) and r[7]>=q)
        x=detailed[name]['crossing']['x'];irq=[a for a in rows if a[:2]==(1,30) and a[4:6]==(1,0)]
        assert not irq and r[:2]==(2,6) and r[19]==2 and b<=r[2]<=c<=x<b+q
        expected=[(rr[0],rr[10]) for rr in rows if rr[0] in (1,2) and rr[4]<d['CONFIG'][0][4]]
        external=[(1 if k==b'5' else 2,int(pc,16)) for k,pc in re.findall(rb'Taking exception (2|5) \[(?:SVC|IRQ)\]\r?\n\.\.\.from EL0 to EL1\r?\n(?:\.\.\.with ESR [^\n]+\n)?\.\.\.with ELR (0x[0-9a-fA-F]+)',(f/'exceptions.log').read_bytes())]
        assert expected==external
        crossings[name]=dict(b=b,CVAL=r[9],SVC=r[2],commit=c,x=x,HI1_PPI=len(irq),external_events=len(external),loss=loss,gate=False)
(raw/'genuine.json').write_text(json.dumps(dict(results=result,overlap=overlap,crossings=crossings,archive_sha256=sha(archive),git_blob=blob),indent=2)+'\n')
print(json.dumps(overlap))
