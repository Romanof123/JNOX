"""Independent offline review of saved #428 QEMU runs. Run under WSL Python."""
import hashlib
import json
import re
import struct
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
imp = root / "imported"
native = root / "native"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def symbol(path, name):
    output = subprocess.check_output(["nm", "-S", str(path)], text=True)
    match = re.search(r"^(\w+) (\w+) \w " + name + "$", output, re.M)
    assert match, name
    return tuple(int(v, 16) for v in match.groups())


def section(path, name):
    data = path.read_bytes()
    off = struct.unpack_from("<Q", data, 40)[0]
    size, count, names = struct.unpack_from("<HHH", data, 58)
    headers = [struct.unpack_from("<IIQQQQIIQQ", data, off + i * size) for i in range(count)]
    name_start = headers[names][4]
    for head in headers:
        start = name_start + head[0]
        if data[start:data.index(b"\0", start)].decode() == name:
            return data[head[4]:head[4] + head[5]]
    raise ValueError(name)


svc = imp / "service.elf"
peer = native / "native_peer.elf"
pool, length = symbol(native / "kernel.elf", "jnox_linux_net_queue_pool")
assert length == 8192
orig = section(imp / "virtio_net.original.o", ".text.virtnet_validate")
assert orig == section(imp / "virtio_net.callback.o", ".text.virtnet_validate")
assert svc.read_bytes() == (native / "user.elf").read_bytes()
kernel = (native / "kernel.elf").read_bytes()
assert svc.read_bytes() in kernel and peer.read_bytes() in kernel
validate, val_size = symbol(svc, "virtnet_validate")
bus, bus_size = symbol(svc, "jnox_queue_find_vqs")
assert val_size == len(orig)
report = dict(scope="Original Linux virtnet_validate and JNOX implementation of find_vqs. Original probe, TX, RX and IRQ paths untested.", kernel=digest(native / "kernel.elf"), service=digest(svc), peer=digest(peer), original_validate_object_section=hashlib.sha256(orig).hexdigest(), pool=[hex(pool),length], captures={})

for label in ("a", "b"):
    cap = root / ("capture-" + label)
    data = json.loads((cap / "ram.json").read_text())
    def read(address, size):
        for key, value in data.items():
            base, n = key.split("/")
            offset = address - int(base, 16)
            if 0 <= offset and offset + size <= int(n):
                return bytes.fromhex(value)[offset:offset + size]
        raise KeyError(hex(address))
    def receipt(elf, name, table):
        va, n = symbol(elf, name)
        for shift in (30, 21, 12):
            entry, = struct.unpack("<Q", read(table + ((va >> shift) & 511)*8, 8))
            assert entry & 3 == 3
            table = entry & 0xfffffffff000
        pa = table + (va & 4095)
        return struct.unpack("<" + "q" * (n//8), read(pa, n))
    driver = receipt(svc, "jnox_queue_driver_result", 0x40235000)
    other = receipt(peer, "jnox_queue_peer_result", 0x4064a000)
    launch = json.loads((cap/"launch.json").read_text())
    tr = (cap/"callback.log").read_text()
    uart = (cap/"uart.log").read_text()
    for binary in (svc, peer):
        assert digest(binary) in uart
    for pid in (0,1):
        assert f"NATIVE EL0 EXIT PID {pid} 0" in uart
    hits = [int(x,16) for x in re.findall(r"Trace \d+: \S+ \[\w+/(\w+)/",tr)]
    assert hits.count(validate) == 2 and any(bus <= pc < bus+bus_size for pc in hits)
    assert driver[:3] == (0x5651445256303031,100,0)
    assert driver[7:15] == (0,launch["mtu"],1,0,0,-22,-22,0)
    assert driver[15] == 1 and driver[28] == 2
    assert driver[22:30] == (3,0,0,11,0,-116,2,-116)
    assert other[:6] == (0x5651504545303031,100,0,-13,-13,6)
    rows = re.findall(r"memory_region_ops_(read|write).*? addr (0x\w+) value (0x\w+) size (\d+) name 'virtio-mmio'", tr)
    status, ready, setups, mtus = [], [[],[]], [], []
    q, regs = None, {}
    for op, addr, value, width in rows:
        off = int(addr,16)-0xa003e00
        v = int(value,16) & ((1 << (8*int(width))) - 1)
        if off == 0x70 and op == "write": status.append(v)
        if off == 0x10a and op == "read": mtus.append(v)
        if off == 0x30 and op == "write": q, regs = v, {}
        if off in (0x38,0x80,0x84,0x90,0x94,0xa0,0xa4) and op == "write": regs[off] = v
        if off == 0x44 and op == "read": ready[q].append(v)
        if off == 0x44 and op == "write":
            base = pool + 4096*q
            assert v == 1 and regs == {0x38:32,0x80:base,0x84:0,0x90:base+512,0x94:0,0xa0:base+584,0xa4:0}
            setups.append(q)
        assert not (off == 0x50 and op == "write")
    assert status == [0,1,3,11,0]*2 and setups == [0,1]*2
    assert mtus == [launch["mtu"]]*2
    for reads in ready:
        assert [v for i,v in enumerate(reads) if i==0 or v!=reads[i-1]] == [0,1,0,1,0]
    assert all(read(pool+i*4096,4096)==bytes(4096) for i in (0,1))
    report["captures"][label] = dict(raw_sha256={f:digest(cap/f) for f in ("uart.log","callback.log","ram.json","launch.json")}, status=status, ready_reads=ready, mtu_reads=mtus, queue_setup_order=setups, tokens=[driver[15],driver[28]], peer_denials=list(other[3:5]), stale_denials=[driver[27],driver[29]], argument_denials=list(driver[12:14]), original_validate_entry_hits=hits.count(validate), bus_helper_entry_hits=hits.count(bus), pool_zero_at_stop=True)
print(json.dumps(report,indent=2))
