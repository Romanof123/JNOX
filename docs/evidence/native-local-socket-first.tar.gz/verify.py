"""Decode the e7d3ded first attempts from their own manifests, page tables and raw bytes."""
import hashlib
import json
import re
import struct
import subprocess
import sys
from pathlib import Path

REV = "e7d3ded373b58df1a8f520d6a3d3aa3d418eef2a"
FRAME_MASK = 0x0000FFFFFFFFF000
MODES = ("stream", "dgram", "seq", "plain", "sync")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def symbols(path):
    lines = subprocess.check_output(["aarch64-linux-gnu-nm", "-nS", path], text=True)
    return {f[3]: (int(f[0], 16), int(f[1], 16)) for l in lines.splitlines()
            if len(f := l.split()) == 4}


def read_private(ram, base, root, syms, name, fmt):
    va, size = syms[name]
    assert size == struct.calcsize(fmt) and (va & 4095) + size <= 4096
    lengths = (30, 21, 12)
    addr = root
    for shift in lengths:
        slot = addr - base + ((va >> shift) & 511) * 8
        assert 0 <= slot <= len(ram) - 8
        entry, = struct.unpack_from("<Q", ram, slot)
        assert entry & 3 == 3
        addr = entry & FRAME_MASK
    assert entry & 64
    return list(struct.unpack_from(fmt, ram, addr + (va & 4095) - base))


def load_flags(path):
    elf = path.read_bytes()
    assert elf[:6] == b"\x7fELF\x02\x01"
    assert struct.unpack_from("<H", elf, 18)[0] == 183
    assert struct.unpack_from("<Q", elf, 24)[0] == 0x400000
    start, = struct.unpack_from("<Q", elf, 32)
    length, count = struct.unpack_from("<HH", elf, 54)
    headers = [struct.unpack_from("<II", elf, start+i*length) for i in range(count)]
    return [flags for typ, flags in headers if typ == 1]


def calculate(root, case):
    mode, policy = case.split("-")
    cap, pkg = root / ("cap-" + case), root / ("pkg-" + case)
    manifest = json.loads((pkg / "manifest.json").read_text())
    launch = json.loads((cap / "launch.json").read_text())
    session = json.loads((cap / "session.json").read_text())
    assert launch["argument_package"] == manifest
    assert launch["revision"] == manifest["commit"] == REV and not manifest["tracked_changes"]
    assert manifest["policy"] == policy and manifest["board"] == "virt"
    flags = launch["argv"]
    for key, val in (("-smp", "1"), ("-cpu", "cortex-a72"), ("-accel", "tcg")):
        assert flags[flags.index(key)+1] == val
    for name, h in session["hashes"].items():
        assert sha(cap/name) == h
    assert manifest["kernel_elf_sha256"] == sha(pkg/"kernel.elf") == launch["kernel_sha256"]
    uart = (cap/"uart.bin").read_text()
    slots = manifest["slots"]
    for s in slots:
        assert s["elf_sha256"] == sha(pkg/s["elf"]) and s["elf_sha256"] in uart
    exits = [list(map(int, row)) for row in re.findall(r"^NATIVE EL0 EXIT PID (\d+) (-?\d+)$", uart, re.M)]
    result = {"kernel_sha256":launch["kernel_sha256"], "slot_sha256":[s["elf_sha256"] for s in slots],
              "slot_pt_load_flags":[load_flags(pkg/s["elf"]) for s in slots],
              "marker":session["marker"], "pid_exit":exits}
    if mode in ("stream", "dgram", "seq"):
        assert len(slots) == 3
        assert manifest["socket_service"] == {"slot":2, "authorized_clients":[0,1]}
        assert manifest["ipc_routes"] == [{"caller":0,"server":2},{"caller":1,"server":2}]
        assert [s["argv"][1:] for s in slots] == [[mode], [mode], ["3"]]
        assert result["slot_pt_load_flags"] == [[5,4,6],[5,4,6],[5,4]]
        assert "NATIVE EL0 FAULT 5" in uart and not exits and session["marker"] == "FAULT 5"
        return result
    assert "socket_service" not in manifest and "FAULT" not in uart
    assert result["slot_pt_load_flags"] == [[5,4,6],[5,4,6]]
    ram = (cap/"ram.bin").read_bytes()
    assert len(ram) == launch["ram_bytes"]
    k = symbols(pkg/"kernel.elf")
    start, sz = next(item for name,item in k.items() if "6SPACES" in name)
    assert sz % 2 == 0
    def field(i, name, fmt):
        return read_private(ram,launch["ram_base"],start + i*sz//2,
                            symbols(pkg/slots[i]["elf"]),name,fmt)
    if mode == "plain":
        assert exits == [[0,17],[1,43]] and session["marker"] == "EXIT 17"
        counts = [field(i,"sensor_count","<I")[0] for i in range(2)]
        sums = [field(i,"sensor_sum","<Q")[0] for i in range(2)]
        assert counts == [16,16] and sums == [sum(range(16,32)),sum(range(240,256))]
        result.update(counts=counts,sums=sums)
    else:
        samples = [300,512,257,1025]
        req = sum(x << (16*i) for i,x in enumerate(samples))
        reply = len(samples)<<48 | max(samples)<<32 | min(samples)<<16 | sum(samples)
        assert exits == [[0,41],[1,42]] and session["marker"] == "EXIT 41"
        assert manifest["ipc_routes"] == [{"caller":0, "server":1}]
        assert field(0,"ipc_call_status","<q") == [0]
        assert field(0,"ipc_request_word","<Q") == [req] and field(0,"ipc_reply_word","<Q") == [reply]
        words = field(1,"ipc_server_words","<3Q")
        statuses = field(1,"ipc_reply_statuses","<3q")
        assert words[0] and words[1:] == [req,reply] and statuses == [-116,0,-116]
        result.update(request=req,reply=reply,server_words=words,reply_statuses=statuses)
    return result


if __name__ == "__main__":
    root = Path(sys.argv[1])
    report = {m+"-"+p: calculate(root,m+"-"+p) for m in MODES for p in ("fifo","rr")}
    print(json.dumps(report,indent=2))
