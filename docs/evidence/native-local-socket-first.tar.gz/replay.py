"""Replay ten captured guest images with their frozen inputs on Linux."""
import argparse
import json
import subprocess
import sys
from pathlib import Path
from verify import MODES, REV, calculate

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("packet", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
packet, output = args.packet.resolve(), args.output.resolve()
output.mkdir()
for mode in MODES:
    for p in ("fifo","rr"):
        case = mode+"-"+p
        pkg = output/("pkg-"+case)
        pkg.symlink_to(packet/pkg.name,target_is_directory=True)
        info = json.loads((pkg/"manifest.json").read_text())
        cap = output/("cap-"+case)
        expected = {"sync":41,"plain":17}.get(mode,73)
        cmd = [sys.executable,packet/"replay-tools/native_el0_capture.py",cap,pkg/"kernel.elf",
               pkg/info["slots"][0]["elf"],packet/cap.name/"probe.c",REV,"--plain",
               "--manifest",pkg/"manifest.json","--expect-exit",str(expected),"--timeout","18"]
        rc = subprocess.run(cmd).returncode
        assert rc == int(mode in ("stream","seq","dgram")), (case,rc)
        assert calculate(output,case) == calculate(packet,case)
        print(case, "matched")
