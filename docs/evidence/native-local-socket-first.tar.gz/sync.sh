#!/usr/bin/env bash
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
cd "$src"
cp "$prep/sync.sh" "$raw"
run cc-sync sh sdk/native-aarch64/build.sh examples/native-sync-ipc/client.c "$raw/sync-c.elf"
run rust-sync sh sdk/native-aarch64/build-rust.sh examples/native-sync-ipc/server/Cargo.toml "$raw/sync-rust.elf"
for pol in fifo rr; do
    guest "sync-$pol" "$pol" 41 "$raw/sync-c.elf" examples/native-sync-ipc/client.c --priority 7 --peer-elf "$raw/sync-rust.elf" --peer-priority 1 --ipc-route 0:1 || true
done
