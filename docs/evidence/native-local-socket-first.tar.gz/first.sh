#!/usr/bin/env bash
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
mkdir "$src" "$raw"
git -C "$src" init -q
echo "${OBJECTS:-/mnt/d/codex/j-nox/.git/objects}" > "$src/.git/objects/info/alternates"
cd "$src"
git sparse-checkout init --cone
git sparse-checkout set arch boards examples kernel sdk services tools trace verification
git -c advice.detachedHead=false checkout -q --detach "$rev"
git rev-parse HEAD 'HEAD^{tree}' > "$raw/revision.txt"
test "$(git rev-parse 'HEAD^{tree}')" = "$tree"
test -z "$(git status --porcelain --untracked-files=no)"
git show 559c91ee76cd7ff133ee1a3cf7ec3942afdd5197:docs/native-socket-service.en-ko.md > "$raw/contract.md"
cp "$prep"/{first.sh,env.sh} "$raw"
(date -u; uname -a; rustc -Vv; cargo -V; qemu-system-aarch64 --version; clang --version; python3 -V) > "$raw/platform.txt"
run cc sh sdk/native-aarch64/build.sh --local-socket examples/native-local-sockets/server.c "$raw/server.elf"
run rust sh sdk/native-aarch64/build-rust.sh --local-socket examples/native-local-sockets/client/Cargo.toml "$raw/client.elf"
run broker sh sdk/native-aarch64/build-rust.sh services/socket/Cargo.toml "$raw/broker.elf"
for pol in fifo rr; do
    for mode in stream dgram seq; do
        guest "$mode-$pol" "$pol" 73 "$raw/server.elf" examples/native-local-sockets/server.c --arg "$mode" --priority 7 --peer-elf "$raw/client.elf" --peer-arg "$mode" --peer-priority 4 --peer-elf "$raw/broker.elf" --peer2-arg 3 --peer-priority 1 --socket-service 2 --ipc-route 0:2 --ipc-route 1:2
    done
done
