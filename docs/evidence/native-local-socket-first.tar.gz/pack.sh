#!/usr/bin/env bash
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
cd "$src"
cp "$prep"/{verify.py,replay.py,REPORT.en-ko.md,pack.sh} "$raw/"
mkdir -p "$raw/replay-tools" "$raw/candidate-source"
cp tools/{native_el0_capture.py,ordinary_amc_capture.py,qemu_capture.py} "$raw/replay-tools/"
for app in server client broker; do
    aarch64-linux-gnu-readelf -lW "$raw/$app.elf" > "$raw/$app-program-headers.txt"
done
git ls-files kernel/src/native_el0.rs kernel/src/native_sync_ipc.rs kernel/src/sync_ipc.rs kernel/build.rs sdk/native-aarch64 services/socket examples/native-local-sockets examples/native-argv examples/native-argv-rust examples/native-sync-ipc tools/build_native_el0.py tools/build_kernel.py > "$raw/candidate-inputs.txt"
while IFS= read -r f; do
    mkdir -p "$raw/candidate-source/$(dirname "$f")"
    git show "$rev:$f" > "$raw/candidate-source/$f"
done < "$raw/candidate-inputs.txt"
python3 "$raw/verify.py" "$raw" > "$raw/results.json"
cd "$raw"
files=$(mktemp)
find . \( -type d \( -name app-target -o -name target -o -name __pycache__ \) -prune \) -o \( -type f ! -name local-tests ! -name SHA256SUMS -print \) | LC_ALL=C sort > "$files"
while IFS= read -r file; do sha256sum "$file"; done < "$files" > SHA256SUMS
echo ./SHA256SUMS >> "$files"
name=376-first-e7d3ded.tar.gz
tar --sort=name --owner=0 --group=0 --numeric-owner -czf "$prep/$name" -T "$files"
audit=$(mktemp -d)
tar -xzf "$prep/$name" -C "$audit"
(cd "$audit"; sha256sum -c SHA256SUMS > /dev/null; python3 verify.py . > decoded.json; cmp results.json decoded.json)
cp "$raw"/{results.json,status.txt,commands.sh} "$prep"
(cd "$prep"; sha256sum "$name" | tee "$name.sha256")
