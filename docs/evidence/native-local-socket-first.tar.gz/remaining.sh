#!/usr/bin/env bash
prep=$(cd "$(dirname "$0")" && pwd)
source "$prep/env.sh"
cd "$src"
cp "$prep/remaining.sh" "$raw"
cp "$prep/../issue-376-verifier-snapshot.md" "$raw/issue-376.md"
run trace-fifo python3 tools/native_el0_capture.py "$raw/diag-stream-fifo" "$raw/pkg-stream-fifo/kernel.elf" "$raw/server.elf" examples/native-local-sockets/server.c "$rev" --manifest "$raw/pkg-stream-fifo/manifest.json" --expect-exit 73 --timeout 18 || true
for pol in fifo rr; do
    for mode in stream dgram seq; do
        if [[ $pol == fifo && $mode == stream ]]; then continue; fi
        guest "$mode-$pol" "$pol" 73 "$raw/server.elf" examples/native-local-sockets/server.c --arg "$mode" --priority 7 --peer-elf "$raw/client.elf" --peer-arg "$mode" --peer-priority 4 --peer-elf "$raw/broker.elf" --peer2-arg 3 --peer-priority 1 --socket-service 2 --ipc-route 0:2 --ipc-route 1:2 || true
    done
done
run cc-plain sh sdk/native-aarch64/build.sh examples/native-argv/sensor.c "$raw/plain-c.elf"
run rust-plain sh sdk/native-aarch64/build-rust.sh examples/native-argv-rust/Cargo.toml "$raw/plain-rust.elf"
for pol in fifo rr; do
    guest "plain-$pol" "$pol" 17 "$raw/plain-c.elf" examples/native-argv/sensor.c --arg sum --arg 16 --arg 32 --arg 'west rack' --priority 7 --peer-elf "$raw/plain-rust.elf" --peer-arg sum --peer-arg 240 --peer-arg 256 --peer-arg 'east rack' --peer-priority 4 || true
done
run host-build rustc --edition 2021 --test services/socket/src/local.rs -o "$raw/local-tests"
run host "$raw/local-tests" --nocapture
