from pathlib import Path
import struct, hashlib, re, json
root=Path(__file__).resolve().parent
def sha(x): return hashlib.sha256(x).hexdigest()
rows=[]
for elf in sorted(root.glob('*/kernel.elf')):
    d=elf.parent
    raw=elf.read_bytes()
    assert raw[:6]==b'\x7fELF\x02\x01'
    off=struct.unpack_from('<Q',raw,32)[0]
    stride,count=struct.unpack_from('<HH',raw,54)
    segments=[]
    joined=b''
    for i in range(count):
        typ,flags,start,va,pa,fs,ms,align=struct.unpack_from('<IIQQQQQQ',raw,off+i*stride)
        if typ!=1: continue
        part=raw[start:start+fs]
        assert len(part)==fs<=ms
        (d/f'load-{i}.bin').write_bytes(part)
        segments.append(dict(index=i,offset=start,vaddr=va,paddr=pa,filesz=fs,memsz=ms,flags=flags,align=align,sha256=sha(part)))
        joined+=part
    lines=(d/'sections.txt').read_text()
    sections={n:int(s,16) for n,s in re.findall(r'\[\s*\d+\]\s+(\.\S+)\s+\w+\s+\w+\s+\w+\s+(\w+)\s+\w+\s+[A-Z]*A[A-Z]*\s',lines)}
    stk=int(re.search(r'\w+\s+(\d+) OBJECT.*6STACKS17', (d/'symbols.txt').read_text())[1])
    rows.append(dict(case=d.name,status='build succeeded',elf_bytes=len(raw),elf_sha256=sha(raw),load_bytes=len(joined),load_sha256=sha(joined),segments=segments,alloc_sections=sections,bss_stack_array_subset=stk))
(root/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
head="""# Legacy selector baseline / 기존 선택기 빌드 기준

Public origin/main and clean detached checkout 8609aab7eeb509b7aa032fcf6cafe124770ab751. All 10 WSL builds succeeded. 전체 10개 빌드 성공. 게스트 실행 및 시간 측정 없음. Sizes represent linked ELF fields, without physical memory or WCET measurements.

Run from PowerShell with `wsl env -i HOME=/home/ywcho PATH=/usr/bin:/bin bash /mnt/d/codex/jnox-baseline-248250-evidence/build.sh`. See build.sh, per-case build.log and tools.txt. kernel/build.rs selects board virt and deadline or fixed profiles without Cargo features. docs/ordinary-deadline-plan.md defines four deadline helpers with optional JNOX_DEADLINE_TRACE=1. docs/coop-runtime.en.md and build.rs select coop-events and coop-single with fixed trace unset. kernel/.cargo/config.toml targets aarch64-unknown-none and cortex-a72.

All sizes in bytes. LOAD is the concatenation of p_filesz bytes from each PT_LOAD at its p_offset in program-header order. manifest.json also records each segment and hash. .bss includes the stack array shown in the subset column. .stack is a separate reservation. 스택 배열은 .bss에 이미 포함된다. 정렬 패딩 때문에 섹션 합과 세그먼트 길이는 다를 수 있다.

|Case|ELF|LOAD|.text|.rodata|.data|.bss|Stack array subset|.stack|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
"""
for r in rows:
    s=r['alloc_sections']
    head+='|'+'|'.join(map(str,[r['case'],r['elf_bytes'],r['load_bytes'],s['.text'],s['.rodata'],s['.data'],s['.bss'],r['bss_stack_array_subset'],s['.stack']]))+'|\n'
(root/'REPORT.md').write_text(head,encoding='utf-8')
