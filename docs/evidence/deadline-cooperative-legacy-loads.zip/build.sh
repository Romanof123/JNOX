set -eu
src=${1:-/mnt/d/codex/jnox-base248250-8609}
out=$(cd "$(dirname "$0")" && pwd)
cd "$src/kernel"
export GIT_DIR=$(wslpath "$(cut -d' ' -f2- "$src/.git" | tr -d '\r')")
export GIT_WORK_TREE="$src"
export CARGO_HOME=${CARGO_HOME:-/home/ywcho/jnox-169-first-e203caa/cargo}
export RUSTUP_HOME=${RUSTUP_HOME:-/home/ywcho/jnox-169-first-e203caa/rustup}
export PATH="$CARGO_HOME/bin:$PATH" CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR=$(mktemp -d)
test "$(git -c core.filemode=false -c core.autocrlf=true -c safe.directory='*' rev-parse HEAD)" = 8609aab7eeb509b7aa032fcf6cafe124770ab751
test -z "$(git -c core.filemode=false -c core.autocrlf=true -c safe.directory='*' status --porcelain)"
{ rustc +1.95.0 -vV; cargo +1.95.0 -V; readelf -v; uname -a; } > "$out/tools.txt"
for app in ordinary-edf ordinary-llf ordinary-llf-overload ordinary-edf-overrun coop-events coop-single; do
 profile=deadline; modes="plain trace"
 case "$app" in coop-*) profile=fixed; modes=plain;; esac
 for mode in $modes; do
  d="$out/$app-$mode"; mkdir -p "$d"
  opts=("JNOX_BOARD=virt" "JNOX_PROFILE=$profile" "JNOX_APP=$app")
  if [[ $mode == trace ]]; then opts+=(JNOX_DEADLINE_TRACE=1); fi
  (set -x; env "${opts[@]}" cargo +1.95.0 build --locked --release -j1) > "$d/build.log" 2>&1 || { cat "$d/build.log"; exit 1; }
  cp "$CARGO_TARGET_DIR/aarch64-unknown-none/release/jnox-kernel" "$d/kernel.elf"
  readelf -lW "$d/kernel.elf" > "$d/programs.txt"
  readelf -SW "$d/kernel.elf" > "$d/sections.txt"
  readelf -sW "$d/kernel.elf" > "$d/symbols.txt"
 done
done
