import hashlib, json, struct
from pathlib import Path
base=Path(__file__).resolve().parent
inputs=base.parent / 'virt-090-blind-inputs'
known=json.loads((inputs/'inputs.json').read_text())
def inspect(p):
    b=p.read_bytes()
    d={'sha256':hashlib.sha256(b).hexdigest(), 'bytes':len(b)}
    assert known[p.name]==d['sha256']
    if b[:4]!=b'\x7fELF' or len(b)<64:
        d['error']='no complete ELF64 header'; return d
    hdr=struct.unpack_from('<16sHHIQQQIHHHHHH', b)
    ident,typ,mach,ver,entry,phoff,shoff,flags,ehsz,phsz,phnum,shsz,shnum,sstr=hdr
    d.update(ident=ident.hex(),type=typ,machine=mach,version=ver,entry=entry,ph=[],sh=[])
    for i in range(phnum):
        typ,flags,off,va,pa,fs,ms,align=struct.unpack_from('<IIQQQQQQ',b,phoff+i*phsz)
        d['ph'].append(dict(type=typ,flags=flags,off=off,va=va,pa=pa,file=fs,mem=ms,align=align))
    ss=[struct.unpack_from('<IIQQQQIIQQ',b,shoff+i*shsz) for i in range(shnum)]
    st=b[ss[sstr][4]:ss[sstr][4]+ss[sstr][5]]
    for name,typ,flags,va,off,size,link,info,align,esz in ss:
        n=st[name:st.index(0,name)].decode("ascii")
        if flags&2:
            d['sh'].append(dict(name=n,type=typ,flags=flags,va=va,off=off,size=size,align=align))
    return d
out={p.name:inspect(p) for p in sorted(inputs.glob('*.elf'))}
(base/'independent-extraction.json').write_text(json.dumps(out,indent=2)+'\n')
for k,v in out.items():
    print(k)
    if 'error' in v:
        print('   ',v['error']); continue
    print('    entry',hex(v['entry']),'ident',v['ident'],'type machine',v['type'],v['machine'])
    for h in v['ph']: print('    ph',*[hex(x) for x in h.values()])
    for s in v['sh']: print('    sh',s['name'],*[hex(x) for k,x in s.items() if k!='name'])
