from datetime import datetime,timezone
from pathlib import Path
import hashlib,json
base=Path(__file__).resolve().parent
obs=json.loads((base/'independent-extraction.json').read_text())
notes={
 '1e30':'RX at ceiling; RW exclusive end is 0x40400010.',
 '1e6e':'Ordinary two-load image with aligned BSS and stack.',
 '267a':'Eleven bytes; no complete ELF header.',
 '7461':'RX exceeds by one byte and RW end exceeds reserved limit by 16 bytes.',
 '79cc':'Read-only .rodata flags 0x200002 include GNU retain. Access permissions are compatible.',
 '975f':'BSS begins at 0x40201008 but ends at 0x40205029, violating 8-byte exclusive-end alignment.',
 'ab30':'RX exceeds by one byte; reserved extent equals limit.',
 'c852':'Read-only .rodata merge/string metadata is compatible with RX backing.',
 'c90b':'Empty .data owns no writable bytes; zero-length allocated PROGBITS at RW start is compatible with empty RW file image.',
 'e34c':'Both dimensions exactly at the respective inclusive limits.'
}
verdict=[]
for name,x in obs.items():
    pref=name[:4]
    valid=pref not in ('975f','267a')
    v={'name':name,'sha256':x['sha256'],'layout_valid':valid,'reason':notes[pref]}
    if 'ph' in x:
        rx,rw=x['ph']
        reserved=rw['va']+rw['mem']-rx['va']
        v.update(rx_bytes=rx['file'],reserved_bytes=reserved,rx_remaining=262144-rx['file'],ram_remaining=2097152-reserved,rw_end=hex(rw['va']+rw['mem']))
        v['numeric_rx_within']=rx['file']<=262144
        v['numeric_ram_within']=reserved<=2097152
    v.update(minimal_fits=(v['numeric_rx_within'] and v['numeric_ram_within']) if valid else None,
             minimal_status=(0 if v.get('numeric_rx_within') and v.get('numeric_ram_within') else 1) if valid else 2,
             comparator_status=0 if valid else 2)
    verdict.append(v)
record={'utc':datetime.now(timezone.utc).isoformat(),'method':'Independent manual layout classification from Python struct extraction of ten opaque inputs. Scoring arithmetic calculated directly from two load headers. Status predictions use valid opposite-role inputs. Invalid layouts have no eligible ceiling score.','rx_limit':262144,'ram_limit':2097152,'results':verdict}
p=base/'frozen-first-verdict.json'
with p.open('x',encoding='utf-8',newline='\n') as f: f.write(json.dumps(record,indent=2)+'\n')
digest=hashlib.sha256(p.read_bytes()).hexdigest()
stamp=datetime.now(timezone.utc).isoformat()
with (base/'frozen-first-verdict.sha256').open('x',encoding='utf-8',newline='\n') as f: f.write(f'{digest}  {p.name}\nUTC {stamp}\n')
print(stamp,digest)
for v in verdict: print(v['name'],v.get('rx_bytes'),v.get('reserved_bytes'),v['minimal_status'],v['comparator_status'])
