from pathlib import Path
from datetime import datetime, timezone
import subprocess,sys,json,hashlib
base=Path(__file__).resolve().parent
inputs=base.parent/'virt-090-blind-inputs'
reference=inputs/'1e6ef20779cb7b09.elf'
verdict=base/'frozen-first-verdict.json'
digest=hashlib.sha256(verdict.read_bytes()).hexdigest()
assert digest==(base/'frozen-first-verdict.sha256').read_text().split()[0]
rows=[]
for e in json.loads(verdict.read_text())['results']:
    p=inputs/e['name']
    for role,mini,comp in [('minimal',p,reference),('comparator',reference,p)]:
        run=subprocess.run([sys.executable,str(base/'virt_footprint.py'),'--minimal',str(mini),'--fixed-rr',str(comp)],capture_output=True,text=True)
        rows.append(dict(name=p.name,role=role,opposite=reference.name,code=run.returncode,predicted=e[role+'_status'],stdout=run.stdout,stderr=run.stderr))
        print(p.name,role,run.returncode,run.stdout[-400:],run.stderr[:200])
out={'utc':datetime.now(timezone.utc).isoformat(),'freeze_sha256':digest,'candidate':'812cfd80c62b8936bfd53e5ff4ffe185195375a3','tool_git_blob':'37e2d9b262a93606b1d9b3553b9630bb71db87a4','dependency_git_blob':'673e8bba0c2ee640f2c44e7057ac48ea67cc3862','python_version':sys.version,'runs':rows}
(base/'candidate-results.json').write_text(json.dumps(out,indent=2)+'\n')
