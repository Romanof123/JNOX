import json,os,selectors,subprocess,sys,time
from pathlib import Path
from score import sha
base=Path(sys.argv[1]).resolve()
scripts=Path(__file__).resolve().parent
for p in ('fifo','rr'):
    key=f'5d4f65488-fused-{p}-healthy'
    kernel=base/'pkg'/key/'kernel.elf'
    linked=json.loads((base/'observations'/key/'sites.json').read_text())
    pc,end=linked['regions']['arm_compare']
    out=base/'observations'/f'vector-{p}'
    out.mkdir(exist_ok=False)
    src=out/'vector.o'
    binary=out/'vector.elf'
    commands=[['clang','--target=aarch64-none-elf',f'-DARM_PC=0x{pc:x}','-c',str(scripts/'vector.S'),'-o',str(src)],
              ['ld.lld','-m','aarch64elf','-Ttext=0x43000000','-e','_start',str(src),'-o',str(binary)]]
    for cmd in commands:subprocess.run(cmd,check=True)
    plugin=base/'observations/timer_insns.so'
    cmd=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M',
         '-nodefaults','-display','none','-monitor','none','-no-reboot','-serial','stdio','-device','loader,file='+str(kernel),
         '-kernel',str(binary),'-plugin',f'{plugin},{out}/hits.bin,{pc:x}-{end:x}']
    (out/'argv.json').write_text(json.dumps(dict(commands=commands+[cmd],kernel=sha(kernel),driver=sha(binary),plugin=sha(plugin)),indent=1)+'\n')
    uart=b''
    with (out/'stderr').open('wb') as err,subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=err) as child:
        try:
            sel=selectors.DefaultSelector()
            sel.register(child.stdout,selectors.EVENT_READ)
            stop=time.monotonic()+10
            while not uart.endswith(b'!\n') and time.monotonic()<stop:
                if sel.select(.25):
                    part=os.read(child.stdout.fileno(),65536)
                    if not part:break
                    uart+=part
        finally:
            child.terminate()
            child.wait(timeout=3)
            (out/'uart.bin').write_bytes(uart)
    assert uart.endswith(b'!\n'),(out,uart)
