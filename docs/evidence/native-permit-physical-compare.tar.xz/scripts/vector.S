// Isolated EL1 exerciser. The called routine resides in the normal unmodified linked kernel.
.text
.global _start
_start:
    msr daifset,#15
    ldr x9,=0x47000000
    mov sp,x9
    mrs x0,CurrentEL
    bl hex
    bl newline
    adr x20,vectors
    adr x21,vectors_end
1:
    ldp x22,x23,[x20],#16
    ldp x24,x25,[x20],#16
    msr cntp_cval_el0,x22
    msr cntp_ctl_el0,x23
    isb
    mrs x26,cntp_cval_el0
    mrs x27,cntp_ctl_el0
    mov x0,x24
    mov x1,x25
    ldr x9,=ARM_PC
    blr x9
    mrs x28,cntp_cval_el0
    mrs x19,cntp_ctl_el0
    mov x0,x22
    bl hex
    mov x0,x23
    bl hex
    mov x0,x24
    bl hex
    mov x0,x25
    bl hex
    mov x0,x26
    bl hex
    mov x0,x27
    bl hex
    mov x0,x28
    bl hex
    mov x0,x19
    bl hex
    bl newline
    cmp x20,x21
    b.ne 1b
    mov w0,#33
    ldr x9,=0x09000000
    str w0,[x9]
    bl newline
2:  wfe
    b 2b
hex:
    ldr x9,=0x09000000
    mov x10,#60
3:  lsr x11,x0,x10
    and w11,w11,#15
    add w12,w11,#48
    add w13,w11,#87
    cmp w11,#10
    csel w12,w12,w13,lo
    str w12,[x9]
    subs x10,x10,#4
    b.pl 3b
    mov w11,#32
    str w11,[x9]
    ret
newline:
    ldr x9,=0x09000000
    mov w11,#10
    str w11,[x9]
    ret
.balign 8
vectors:
// program prior CVAL/CTL, request Some/None, desired CVAL.
    .quad 0x100000000,0,0,0
    .quad 0x100000000,1,1,0x100000000
    .quad 0x100000000,1,1,0x0fffffff0
    .quad 0x100000000,1,1,0x100000010
    .quad 0x100000000,0,1,0x100000000
    .quad 0x100000000,2,1,0x100000000
    .quad 0x100000000,3,1,0x100000000
    .quad 0x100000000,1,0,0
    .quad 0x100000000,2,0,0
    .quad 0x100000000,3,0,0
    .quad 1,1,1,1
    .quad 1,3,1,1
    .quad 1,1,1,0x100000000
    .quad 1,1,0,0
vectors_end:
