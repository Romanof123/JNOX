import collections,csv,json,sys
from pathlib import Path
from score import signed
base=Path(sys.argv[1]); result=base/'results';boots=json.loads((result/'boots.json').read_text())
out=[]; phases=[]
for b in boots:
    if b['role']=='fused':
        for phase in b['phases']:
            phases.append(dict(run=b['run'],rev=b['rev'],**phase))
    if b['role']!='watchdog':continue
    raw=(base/'runs'/b['run']/'cap/uart.bin').read_text().splitlines()
    ev=[list(map(int,line.split()[3:])) for line in raw if line.startswith('NATIVE SAFETY EVENT ')]
    clocks=[r for r in b['wd'] if r[2] in (2,3)]; track=b['case']
    seen=[r[5] for r in b['writes']];sups=[r for r in ev if r[0]==5 and r[2:4]==[2,59]]
    deaths=[r[2] for r in ev if r[0]==8]
    late=bool(b['complete_late'])
    late_modes=track in ['sleep-late','compute-late','recover','recover-live']
    checks={'private':b['passed'],'inclusive deadline':len(clocks)>0 and all(r[9]==r[8]+312501 for r in clocks),'timer':len(b['due'])==int(late_modes) and all(r[7]==30 and r[6]>=r[5] for r in b['due']),'late refusal':late==late_modes,'output':seen==([1,0,1,0] if track=='recover' else [1,0])}
    due=b['due']; matches=[r for group in b['matched_irq'] for r in group]
    if late_modes:
        checks['due irq and off']=len(matches)==1 and any(v[5]==0 and due[0][6]<=v[2]<=v[3]<=due[0][1] for v in b['writes'])
    if track=='sleep-late':checks['idle interrupted']=len(matches)==1 and matches[0][9]==1 and matches[0][8]&15==5
    if track=='compute-late':
        checks['compute irq pc']=len(matches)==1 and b['loop'][0]<=matches[0][7]<b['loop'][1]
    if track=='controller-exit':checks['death refusal']=deaths==[1] and [(r[4],signed(r[5])) for r in sups[-2:]]==[(2,-32),(1,-32)]
    if track in ['recover','recover-live']:
        x=b['pair'];rc=signed(sups[-1][5]);checks['pair']=x[4]==1 and bool(x[3])==(x[1]-x[0]==625000) and rc==(0 if x[3] else -11)
    out.append(dict(run=b['run'],checks=checks,due_delay=[r[6]-r[5] for r in due],irq_pc=[r[7] for r in matches],writes=seen,supervisor_status=[[r[4],signed(r[5]),r[6]] for r in sups],passed=all(checks.values())))
with (result/'phase-brackets.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=phases[0].keys());w.writeheader();w.writerows(phases)
(result/'watchdog.json').write_text(json.dumps(out,indent=1)+'\n')
for b in out:
    if not b['passed']:print('watchdog discrepancy',b)
print('watchdog',sum(b['passed'] for b in out),'/',len(out))

