"""Replay selected-PC execution, checking continuity to the next journal call."""
import collections,csv,json,re,struct,sys
from pathlib import Path
root=Path(sys.argv[1]); result=root/'results'
rows=[]; hist=[]
for folder in sorted((root/'observations').glob('*-fused-*-healthy')):
    site=json.loads((folder/'sites.json').read_text())
    raw=next(folder.glob('hits.bin*')).read_bytes()
    n,loss=struct.unpack_from('<II',raw)
    assert loss==0 and n>0
    hits=struct.unpack_from(f'<{n}I',raw,8)
    ops={int(a):v for a,v in site['ops'].items()}
    trace_lo,trace_hi=site['regions']['permit_trace::compare']
    groups=[]; current=None
    for pc in hits:
        if pc==site['start']:
            assert current is None
            current=[]
        if current is None:continue
        if pc==site['stop']:
            groups.append(current);current=None
        else:current.append(pc)
    assert current is None
    uart=(folder/'cap/uart.bin').read_text().splitlines()
    assert [l.split()[-2:] for l in uart if l.startswith('NATIVE EL0 EXIT PID')]==[['0','71'],['1','72'],['2','73']]
    counts=collections.Counter()
    for i,g in enumerate(groups):
        stack=[]
        for p,nxt in zip(g,g[1:]+[site['stop']]):
            name,_,args=ops[p].partition('\t')
            if name=='ret':
                assert stack and nxt==stack.pop()
            elif name=='b' or name=='bl':
                assert nxt==int(args.split()[0],16)
                if name=='bl':stack.append(p+4)
            elif name.startswith('b.') or name in ('cbz','cbnz','tbz','tbnz'):
                assert nxt==p+4 or nxt==int(re.search(r'([0-9a-f]+) <',args).group(1),16)
            else:assert nxt==p+4,(ops[p],nxt)
        assert not stack
        main=[ops[p] for p in g if not trace_lo<=p<trace_hi]
        trace=[ops[p] for p in g if trace_lo<=p<trace_hi]
        changed=any('cntp_cval_el0' in op for op in trace)
        some=any('cntp_cval_el0' in op for op in main)
        cval_w=sum(op.startswith('msr\tcntp_cval_el0') for op in main)
        ctl_w=sum(op.startswith('msr\tcntp_ctl_el0') for op in main)
        if not changed:
            assert (cval_w,ctl_w)==((0,0) if folder.name.startswith('5d4') else (int(some),1))
        kind=('changed-' if changed else 'same-')+('armed' if some else 'disabled')
        vals=(kind,len(g),len(main),cval_w,ctl_w)
        counts[vals]+=1
        rows.append(dict(observation=folder.name,request=i,kind=kind,executed=len(g),outside_journal=len(main),cval_writes=cval_w,ctl_writes=ctl_w))
    for vals,count in sorted(counts.items()):
        hist.append(dict(observation=folder.name,kind=vals[0],executed=vals[1],outside_journal=vals[2],cval_writes=vals[3],ctl_writes=vals[4],requests=count))
for name,rs in [('instruction-requests.csv',rows),('instruction-counts.csv',hist)]:
    with (result/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rs[0]);w.writeheader();w.writerows(rs)
