#!/usr/bin/env bash
set -euo pipefail
root=$(realpath "${1:-.}")
cd "$root"
export LC_ALL=C PYTHONDONTWRITEBYTECODE=1
sha256sum --quiet -c SHA256SUMS
for step in score reduce watchdog timing decode_insns vector_decode checks; do python3 "scripts/$step.py" "$root"; done
sha256sum --quiet -c SHA256SUMS
