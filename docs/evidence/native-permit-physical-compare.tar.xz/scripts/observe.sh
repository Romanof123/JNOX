#!/usr/bin/env bash
set -euo pipefail
scripts=$(dirname "$(realpath "$0")")
base=${LAB_ROOT:-$HOME/permit389-timer-first}
cd "$base/src"
export PYTHONDONTWRITEBYTECODE=1
cp "$HOME/host389-first/header/qemu-plugin.h" "$base/observations/qemu-plugin.h"
cc -Wall -Wextra -O2 -fPIC -shared -I"$base/observations" "$scripts/timer_insns.c" -o "$base/observations/timer_insns.so"
for rev in a7aa0a659f239950fa29b3326813cf4b35d846f9 5d4f6548874548ffb773e3935e35c2576c03007c; do
    git checkout -q --detach "$rev"
    for p in fifo rr; do
        key=${rev:0:9}-fused-$p-healthy
        obs=$base/observations/$key
        mkdir -p "$obs"
        kernel=$base/pkg/$key/kernel.elf
        ranges=$(python3 "$scripts/sites.py" "$kernel" "$obs")
        export OBS_PLUGIN="$base/observations/timer_insns.so,$obs/hits.bin,$ranges"
        export OBS_ARGV="$obs/actual-argv.json"
        PYTHONPATH="$scripts/instrument" python3 tools/native_el0_capture.py "$obs/cap" "$kernel" "$base/apps/sender.elf" examples/native-safety-admission/sender/src/main.rs "$rev" --manifest "$base/pkg/$key/manifest.json" --plain --expect-exit 71 --timeout 40 --uart-limit 8388608 > "$obs/capture.log" 2>&1
    done
done
