import json,re,subprocess,sys
from pathlib import Path
from score import sha,symtab
elf=Path(sys.argv[1]); out=Path(sys.argv[2]);tab=symtab(elf)
regions={}
ops={}
for key in ('fixed_event','permit_trace::compare','arm_compare'):
    sym='jnox_kernel::native_el0::'+key
    if sym not in tab:continue
    start,size=tab[sym]
    dis=subprocess.check_output(['aarch64-linux-gnu-objdump','-dC',f'--start-address={start}',f'--stop-address={start+size}',str(elf)],text=True)
    ins={int(pc,16):op.strip() for pc,op in re.findall(r'^\s*([0-9a-f]+):\s+[a-f0-9]{8}\s+(.+)$',dis,re.M)}
    if key=='fixed_event':
        start,=[k+4 for k,v in ins.items() if 'bl\t' in v and '::ipc::next_compare>' in v]
        stop,=[k for k,v in ins.items() if 'bl\t' in v and '::record>' in v]
        end=stop+4
    else:end=start+size
    regions[key]=[start,end]
    ops.update({p:o for p,o in ins.items() if start<=p<end})
    (out/(key.replace('::','-')+'.dis')).write_text(dis.replace(str(elf),'kernel.elf'))
meta={'kernel':sha(elf),'start':regions['fixed_event'][0],'stop':regions['fixed_event'][1]-4,'regions':regions,'ops':ops}
(out/'sites.json').write_text(json.dumps(meta,indent=1)+'\n')
print(','.join(f'{a:x}-{z:x}' for a,z in regions.values()))
