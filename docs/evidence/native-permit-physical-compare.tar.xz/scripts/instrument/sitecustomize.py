import json,os,subprocess
from pathlib import Path
Original=subprocess.Popen
class Observed(Original):
    def __init__(self,args,*a,**kw):
        if isinstance(args,list) and '-qmp' in args:
            args=args+['-plugin',os.environ['OBS_PLUGIN']]
            Path(os.environ['OBS_ARGV']).write_text(json.dumps(args,indent=1)+'\n')
        super().__init__(args,*a,**kw)
subprocess.Popen=Observed
