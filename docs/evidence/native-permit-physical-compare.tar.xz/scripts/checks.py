import csv,hashlib,json,subprocess,sys,tarfile,tempfile
from pathlib import Path
from score import sha
root=Path(sys.argv[1]).resolve()
results=root/'results'
source=root/'source-bundles'
old='a7aa0a659f239950fa29b3326813cf4b35d846f9'
new='5d4f6548874548ffb773e3935e35c2576c03007c'
pub=json.loads((source/'public-commit.json').read_text())
assert pub['sha']=='537480b54357c0c742429540ee3f604fe29f6533'
def gitid(kind,data):
    return hashlib.sha1(f'{kind} {len(data)}\0'.encode()+data).hexdigest()
for rev in (old,new):
    commit=(source/(rev+'.commit')).read_bytes()
    assert gitid('commit',commit)==rev
    if rev==new:assert commit.splitlines()[:2]==[('tree '+pub['tree']['sha']).encode(),('parent '+old).encode()]
    files={l.split('\t')[1]:l.split()[2] for l in (source/(rev+'.ls-tree')).read_text().splitlines()}
    with tarfile.open(source/(rev+'.tar.gz')) as tf:
        for m in tf:
            if m.isdir():continue
            assert m.isfile() and gitid('blob',tf.extractfile(m).read())==files.pop(m.name)
    assert not files
boots=json.loads((results/'boots.json').read_text())
assert len(boots)==48
assert [b['rev'] for b in boots[:16]]==[old,new,new,old,new,old,old,new,new,old,old,new,old,new,new,old]
assert [b['policy'] for b in boots[:16]]==(['fifo']*4+['rr']*4)*2
assert all(b['case']=='healthy' and b['role']=='fused' for b in boots[:16])
assert all(b.get('functional',b.get('passed')) for b in boots)
assert len(list((root/'pkg').glob('*/manifest.json')))==36
for manifest in (root/'pkg').glob('*/manifest.json'):
    m=json.loads(manifest.read_text()); pkg=manifest.parent
    assert sha(pkg/'kernel.elf')==m['kernel_elf_sha256'] and sha(pkg/'build.log')==m['build_log_sha256']
    assert all(sha(pkg/s['elf'])==s['elf_sha256'] for s in m['slots'])
for o in sorted((root/'observations').glob('*-fused-*-healthy')):
    kernel=root/'pkg'/o.name/'kernel.elf'
    assert sha(kernel)==sha(o/'cap/kernel.elf')
    rec=json.loads((o/'cap/session.json').read_text())
    assert all(sha(o/'cap'/n)==h for n,h in rec['hashes'].items())
    with tempfile.TemporaryDirectory() as t:
        dest=Path(t)
        subprocess.run([sys.executable,str(Path(__file__).with_name('sites.py')),str(kernel),str(dest)],check=True,stdout=subprocess.DEVNULL)
        assert all((o/f.name).read_bytes()==f.read_bytes() for f in dest.iterdir())
wd=json.loads((results/'watchdog.json').read_text())
assert len(wd)==20 and all(v['passed'] for v in wd)
phases=list(csv.DictReader((results/'endpoints.csv').open()))
assert len(phases)==768
print('Replayed 48 serial stock boots, four execution traces, 28 EL1 vectors and both detached source identities.')
