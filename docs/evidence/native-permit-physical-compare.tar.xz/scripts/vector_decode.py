import csv,json,struct,sys
from pathlib import Path
base=Path(sys.argv[1]); result=base/'results'
rows=[]
for p in ('fifo','rr'):
    obs=base/'observations'/f'vector-{p}'
    parent=base/'observations'/f'5d4f65488-fused-{p}-healthy'
    sites=json.loads((parent/'sites.json').read_text())
    start,end=sites['regions']['arm_compare']
    insns={int(k):v for k,v in sites['ops'].items()}
    ram=next(obs.glob('hits.bin*')).read_bytes()
    n,loss=struct.unpack_from('<II',ram)
    assert not loss
    paths=[]
    for addr in struct.unpack_from(f'<{n}I',ram,8):
        if addr==start:paths.append([])
        paths[-1].append(addr)
    lines=(obs/'uart.bin').read_text().splitlines()
    assert int(lines[0],16)==4 and lines[-1]=='!' and len(paths)==len(lines)-2==14
    for i,(text,pcs) in enumerate(zip(lines[1:-1],paths)):
        before,ctl,enabled,target,actual_pre,actual_ctl,after,final_ctl=[int(x,16) for x in text.split()]
        equal=(ctl&3==1 and before==target) if enabled else ctl&3==0
        assert actual_pre==before and actual_ctl&3==ctl
        assert after==(target if enabled else before) and final_ctl&3==enabled
        if ctl&1:assert bool(actual_ctl&4)==(before==1)
        if enabled:assert bool(final_ctl&4)==(target==1)
        cval=sum(insns[k].startswith('msr\tcntp_cval_el0') for k in pcs)
        control=sum(insns[k].startswith('msr\tcntp_ctl_el0') for k in pcs)
        assert (cval,control)==(int(enabled and not equal),int(not equal))
        assert pcs[-1]==end-4 and insns[pcs[-2]]=='isb'
        rows.append(dict(policy=p,index=i,prior_cval=before,prior_ctl=actual_ctl,enable=enabled,target=target,
                         final_cval=after,final_ctl=final_ctl,cval_writes=cval,ctl_writes=control,guest_instructions=len(pcs)))
with (result/'forced-timer-vectors.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
