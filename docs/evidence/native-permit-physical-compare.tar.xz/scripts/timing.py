"""Replay timer state and phase timing from the untouched captures."""
import csv
import json
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

root = Path(sys.argv[1])
result = root / 'results'
boots = json.loads((result / 'boots.json').read_text())
phases = {(r['run'],int(r['index'])):r for r in csv.DictReader((result/'phases.csv').open())}
timer_rows, phase_rows, boot_rows = [], [], []

def table(name, values):
    with (result/name).open('w',newline='') as file:
        writer=csv.DictWriter(file,fieldnames=list(dict.fromkeys(k for r in values for k in r)))
        writer.writeheader()
        writer.writerows(values)

for boot in boots:
    run=boot['run']
    if boot['role']=='loan':
        assert boot['passed']
        continue
    lines=(root/'runs'/run/'cap/uart.bin').read_text().splitlines()
    q=[list(map(int,l.split()[3:])) for l in lines if l.startswith('NATIVE QUAL ROW ')]
    timer=last=None
    irq=0
    cases=Counter()
    for r in q:
        if r[1]==5:
            target=r[5] if r[4] else None
            if r[4]:
                assert r[4]==1 and r[5]==r[6] and r[7]&3==1
            else:
                assert r[7]&3==0
            assert r[2]<=r[3]
            if last is None: kind='initial'
            elif timer is None: kind='rearm'
            elif target is None: kind='disable'
            elif target<timer: kind='earlier'
            else:
                assert target>timer
                kind='later'
            cases[kind]+=1
            timer=target
            last=r[0]
            timer_rows.append(dict(run=run,row=r[0],kind=kind,target=target,cval=r[6],ctl=r[7],begin=r[2],end=r[3]))
        elif r[1]==3 and r[4]==30:
            assert timer is not None and r[5]==timer and r[6]&7==5
            assert r[5]<=r[2]<=r[3]<=r[11] and r[11] and r[12]
            irq+=1
            timer_rows.append(dict(run=run,row=r[0],kind='irq',target=timer,cval=r[5],ctl=r[6],begin=r[2],end=r[11],prior_row=last,interrupted_pc=r[7],return_pc=r[12],idle=r[9]))
    assert not boot['qual_loss'] and not boot['safety_loss']
    b=dict(run=run,build=boot['rev'][:9],policy=boot['policy'],role=boot['role'],case=boot['case'],irqs=irq,**cases)
    if boot['role']=='fused':
        for i,p in enumerate(boot['phases']):
            prev=phases[run,i]
            ready=q[p['ready']] if p['ready'] is not None else None
            dispatch=q[p['dispatch']] if p['dispatch'] is not None else None
            target=p['target']
            d=dict(run=run,phase=prev['phase'],frame=prev.get('wire_sequence') or '',kind=prev['kind'],
                   phase_lo=p['lo'],phase_hi=p['hi'],first=p['marks'][0],ready_row=p['ready'],dispatch_row=p['dispatch'],
                   release=target,ready_lo=(ready[4]-target if ready else None),ready_hi=(ready[5]-target if ready else None),
                   user_return=(dispatch[11]-target if dispatch else None),user_pc=(dispatch[12] if dispatch else None),
                   phase_mark2=q[p['marks'][1]][7]-target,check_exit_to_receive=prev['check_exit_to_receive'],
                   receive_to_complete_entry=prev['receive_to_complete_entry'],check_ticks=boot['check_service'][i],
                   complete_ticks=boot['complete_service'][i],receive_to_release=prev.get('receive_to_release',''),
                   check_enter=q[int(prev['check_row'])][5]-target,
                   release_to_recv=int(prev['receive_journal'])-target)
            if ready and dispatch:
                assert ready[4]<=ready[5]<=dispatch[11]<=q[p['marks'][1]][7]
                d['ready_to_return_lo']=dispatch[11]-ready[5]
                d['ready_to_return_hi']=dispatch[11]-ready[4]
            phase_rows.append(d)
        selected=phase_rows[-32:]
        a0=selected[0]
        first,=[p for p in selected if p['frame']=='1']
        b.update(phase_count=32,closed=sum(p['hi'] is not None for p in boot['phases']),
                 miss=len(boot['misses']),indeterminate=sum(p['lo']<=62500 and (p['hi'] is None or p['hi']>62500) for p in boot['phases']),
                 prewake=sum(p['prewake'] for p in boot['phases']),
                 A0_ready_hi=a0['ready_hi'],A0_return=a0['user_return'],A0_hi=a0['phase_hi'],A0_recv=a0['release_to_recv'],
                 A0_empty=(a0['kind']=='empty'),A0_check_to_recv=a0['check_exit_to_receive'],first_phase=first['phase'],
                 first_hi=first['phase_hi'],first_receive_release=first['receive_to_release'],max_hi=max(p['phase_hi'] for p in selected),
                 max_job=max(156250+p['hi'] for p in boot['phases'] if p['phase']==2),
                 max_sender=max((p['hi'] or 0) for p in boot['sender']),sender_open=sum(p['hi'] is None for p in boot['sender']),
                 max_check_gap=max(boot['check_gap']),max_complete_gap=max(p[1] for p in boot['complete_gap']),max_grid_irq=boot['max_grid_irq'])
    boot_rows.append(b)
table('timer-readbacks.csv',timer_rows)
table('endpoints.csv',phase_rows)
table('timer-boots.csv',boot_rows)

def pretty(v):
    return int(v) if int(v)==v else v

summary=[]
for pol in ('fifo','rr'):
    for arm in ('a7aa0a659','5d4f65488'):
        rows=[b for b in boot_rows if b['case']=='healthy' and b['role']=='fused' and b['policy']==pol and b['build']==arm]
        assert len(rows)==4
        s=dict(policy=pol,arm=arm,closed=sum(r['closed'] for r in rows),miss=sum(r['miss'] for r in rows),
               indeterminate=sum(r['indeterminate'] for r in rows),prewake=sum(r['prewake'] for r in rows),first_placement=[r['first_phase'] for r in rows])
        for field in ('A0_hi','A0_ready_hi','A0_return','A0_recv','A0_check_to_recv','first_hi','first_receive_release'):
            vals=[int(r[field]) for r in rows if r[field] is not None]
            s[field]=[min(vals),pretty(statistics.median(vals)),max(vals)] if vals else []
        summary.append(s)
(result/'timing-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
