// SPDX-License-Identifier: GPL-2.0-or-later
// One-vCPU, selected-kernel-PC execution trace. The first words record size and loss.
#include <qemu-plugin.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
QEMU_PLUGIN_EXPORT int qemu_plugin_version=QEMU_PLUGIN_VERSION;
enum { CAP=262144 };
static uint32_t *words;
static uint64_t lo[6], hi[6];
static unsigned ranges;
static void hit(unsigned cpu,void *tag){
    if(cpu || words[0]==CAP){ words[1]++; return; }
    words[2+words[0]++]=(uint32_t)(uintptr_t)tag;
}
static void translated(qemu_plugin_id_t id,struct qemu_plugin_tb *tb){
    (void)id;
    for(size_t j=0;j<qemu_plugin_tb_n_insns(tb);j++){
        struct qemu_plugin_insn *ins=qemu_plugin_tb_get_insn(tb,j);
        uint64_t pc=qemu_plugin_insn_vaddr(ins);
        for(unsigned i=0;i<ranges;i++) if(pc>=lo[i] && pc<hi[i]){
            qemu_plugin_register_vcpu_insn_exec_cb(ins,hit,QEMU_PLUGIN_CB_NO_REGS,(void*)(uintptr_t)pc);
            break;
        }
    }
}
QEMU_PLUGIN_EXPORT int qemu_plugin_install(qemu_plugin_id_t id,const qemu_info_t *info,int argc,char **argv){
    if(argc<2 || argc>7 || !info->system_emulation || info->system.smp_vcpus!=1 || strcmp(info->target_name,"aarch64"))return -1;
    for(int i=1;i<argc;i++) if(sscanf(argv[i],"%"SCNx64"-%"SCNx64,&lo[i-1],&hi[i-1])!=2 || lo[i-1]>=hi[i-1]) return -1;
    ranges=argc-1;
    int fd=open(argv[0],O_CREAT|O_EXCL|O_RDWR,0600);
    size_t size=(CAP+2)*sizeof(*words);
    if(fd<0 || ftruncate(fd,size))return -1;
    words=mmap(NULL,size,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
    close(fd);
    if(words==MAP_FAILED)return -1;
    qemu_plugin_register_vcpu_tb_trans_cb(id,translated);
    return 0;
}
