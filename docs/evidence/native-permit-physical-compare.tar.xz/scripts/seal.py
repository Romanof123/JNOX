import hashlib,os,shutil,subprocess,sys
from pathlib import Path
root,external=[Path(x).resolve() for x in sys.argv[1:]]
packet=root/'packet'
packet.mkdir()
files={}
for top in ('apps','logs','pkg','results','runs','source-bundles','observations'):
    for p in (root/top).rglob('*'):
        if p.is_file() and 'target' not in p.relative_to(root).parts:
            files[p.relative_to(root)]=p
files[Path('host.txt')]=root/'host.txt'
for name in ('campaign.sh','lane.sh','fixtures.sha256','score.py','reduce.py','watchdog.py','timing.py','timer_insns.c','sites.py','instrument/sitecustomize.py','observe.sh','decode_insns.py','vector.S','vector.py','vector_decode.py','checks.py','replay.sh','seal.py'):
    files[Path('scripts')/name]=external/name
files[Path('logs/campaign.log')]=external/'campaign.log'
files[Path('REPORT.en-ko.md')]=external/'REPORT.en-ko.md'
hashes={}; prior={}
for dst,src in sorted(files.items()):
    digest=hashlib.sha256(src.read_bytes()).hexdigest()
    hashes[dst]=digest
    d=packet/dst;d.parent.mkdir(parents=True,exist_ok=True)
    if digest in prior:os.link(prior[digest],d)
    elif src.stat().st_dev==packet.stat().st_dev:os.link(src,d)
    else:shutil.copyfile(src,d)
    prior[digest]=d
manifest=packet/'SHA256SUMS'
manifest.write_text(''.join(f'{h}  {p}\n' for p,h in sorted(hashes.items())))
def order(p):
    parts=p.parts
    if ('runs' in parts or 'observations' in parts) and len(parts)>2:
        key=parts[1].split('-')
        return (p.name,'-'.join(key[-3:]),str(p))
    return (p.name,'',str(p))
paths=sorted(list(files)+[Path('SHA256SUMS')],key=order)
orderfile=root/'packet-order'
orderfile.write_bytes(b''.join(str(p).encode()+b'\0' for p in paths))
tar=root/'packet.tar'
subprocess.run(['tar','--sparse','--hole-detection=raw','--format=gnu','--owner=0','--group=0','--numeric-owner','--mtime=@0','--null','-T',str(orderfile),'-cf',str(tar)],check=True,cwd=packet)
archive=external/'native-permit-physical-compare.tar.xz'
with archive.open('wb') as f:subprocess.run(['xz','-8','-T1','-c',str(tar)],stdout=f,check=True)
h=hashlib.sha256(archive.read_bytes()).hexdigest()
(external/(archive.name+'.sha256')).write_text(f'{h}  {archive.name}\n')
print(len(hashes),archive.stat().st_size,h,flush=True)
