#!/usr/bin/env bash
set -euo pipefail
base=${LAB_ROOT:-$HOME/permit389-timer-first}
scripts=$(dirname "$(realpath "$0")")
lane=$scripts/lane.sh
a=a7aa0a659f239950fa29b3326813cf4b35d846f9
b=5d4f6548874548ffb773e3935e35c2576c03007c
bash "$lane" prepare
git -C "$base/src" diff "$a" "$b" > "$base/source-bundles/frozen.diff"
for rev in "$a" "$b"; do
    bash "$lane" checkout "$rev"
    for pol in fifo rr; do
        for caseid in healthy overrun invalid; do bash "$lane" build "$rev" "$pol" "$caseid" fused; done
        for caseid in healthy sleep-late compute-late recover recover-live; do bash "$lane" build "$rev" "$pol" "$caseid" watchdog; done
        bash "$lane" build "$rev" "$pol" ordinary loan
        echo "built $rev $pol $(date -u +%T)"
    done
done
n=0
run() {
    n=$((n+1))
    git -C "$base/src" checkout -q --detach "$1"
    bash "$lane" boot "$1" "$2" "$3" "$4" "$(printf %03d "$n")"
    echo "completed position $n $1 $2 $3 $4 $(date -u +%T)"
}
for block in 1 2; do
    for pol in fifo rr; do
        if [[ "$block:$pol" = 1:fifo || "$block:$pol" = 2:rr ]]; then order=("$a" "$b" "$b" "$a"); else order=("$b" "$a" "$a" "$b"); fi
        for rev in "${order[@]}"; do run "$rev" "$pol" healthy fused; done
    done
done
for pol in fifo rr; do
    for rev in "$a" "$b"; do
        for caseid in overrun invalid; do run "$rev" "$pol" "$caseid" fused; done
        for caseid in healthy sleep-late compute-late recover recover-live; do run "$rev" "$pol" "$caseid" watchdog; done
        run "$rev" "$pol" ordinary loan
    done
done
