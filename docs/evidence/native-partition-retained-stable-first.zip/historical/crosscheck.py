import json, struct, subprocess, pathlib, re
from itertools import accumulate
root = pathlib.Path(__file__).resolve().parent
for cap in sorted(root.glob("partition-*-*")):
    if not cap.is_dir(): continue
    symbols=subprocess.check_output(["aarch64-linux-gnu-nm","-nS",cap/"kernel.elf"],text=True)
    addr=int(next(s.split()[0] for s in symbols.splitlines() if s.endswith(" native_vruntime_journal")),16)
    mem=(cap/"ram.bin").read_bytes()
    rows=list(struct.iter_unpack("<16Q",mem[addr-0x40200000:addr-0x40200000+513*128]))
    h=rows[0]; e=h[5]; prev=e; off=0
    ids=[(0,2),(1,1),(2,1)] if "-p-" in cap.name else [(1,1),(2,1),(0,2),(1,1)]
    released=False; result=[]; frames={}; roots={}; pcs=[]
    for k in range(3*len(ids)+3):
        a=rows[4+19*k:4+19*(k+1)]
        disp=a[0]; stop=a[9]; obs=a[10]; pid=disp[2]
        assert [disp[0],stop[0],obs[0]]==[21,22,23]
        frame=tuple(v for row in a[1:9] for v in row[3:])
        if pid in frames: assert frame==frames[pid]
        frames[pid]=tuple(v for row in a[11:19] for v in row[3:])
        pcs.append((frame[33],frames[pid][33]))
        roots[pid]=disp[9]
        if k>=3*len(ids)+1:
            assert pid==k-(3*len(ids)+1) and obs[9]==41+pid and obs[8]==obs[7]*(3+2*pid)
            continue
        owner,units=ids[k%len(ids)]
        released|=owner==2
        assert disp[6:8]==(owner,3 if released else 1) and pid==(2 if owner==1 and not released else owner)
        d=e+off; off+=units*h[4]; r=stop[4]; x=obs[6]; j=stop[1]
        assert d==disp[4] and stop[5]==e+off and stop[6:8]==(5,30) and d<=prev<=r<=x<j and x<e+off
        result.append((k+1,pid,prev-d,r-prev,x-r,x-d))
        prev=j
    assert len(set(roots.values()))==3
    trace=(cap/"exceptions.log").read_text()
    assert [(int(a,16),int(b,16)) for a,b in re.findall(r"return from AArch64 EL1 to AArch64 EL0 PC (0x\w+).*?with ELR (0x\w+)",trace,re.S)]==pcs
    print(cap.name, "generation pid spill entry_to_preeret preeret_to_user total",result)
