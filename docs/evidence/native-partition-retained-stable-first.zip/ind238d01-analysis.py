from pathlib import Path
import json,sys,collections,hashlib,zipfile,subprocess
from native_partition_phase import compare
from elftools.elf.elffile import ELFFile
r=Path('/home/ywcho/ind238d01')
e=r/'evidence'
ds=sorted(d for d in e.iterdir() if d.is_dir())
stats=collections.defaultdict(list)
phase={}
delta={}
layout={}
for i in range(0,len(ds),4):
    group={d.name[-1]:d for d in ds[i:i+4]}
    for x,y in [('A','C'),('B','D')]:
        a,b=group[x],group[y]
        phase[a.name+'_'+b.name]=compare(a,a.with_suffix('.digest').read_text().strip(),b,b.with_suffix('.digest').read_text().strip())
    rows={}
    for v,d in group.items():
        j=json.loads(d.with_suffix('.json').read_text())
        w=j['windows']
        assert [x['status'] for x in j['exits']]==[41,42] and j['frequency']==62500000
        stats[d.name[3:]].append([i+1,j['timing_misses'],w[1]['latency'],len(w)])
        rows[v]=[[k['selected']-w[n-1]['irq_entry'] if n else None,k['return_sample']-k['selected'],k['return_bracket'],k['latency'],62500-k['latency']] for n,k in enumerate(w)]
    for x,y in [('A','B'),('C','D')]:
        delta[group[x].name+'_'+group[y].name]=[dict(generation=n+1,base=a,retained=b,delta=[None if k is None else l-k for k,l in zip(a,b)]) for n,(a,b) in enumerate(zip(rows[x],rows[y]))]
for f in sorted(r.glob('build-??/kernel.elf')):
    with f.open('rb') as fp:
        elf=ELFFile(fp)
        sym=elf.get_section_by_name('.symtab')
        layout[f.parent.name]=dict(file=f.stat().st_size,load=[{k:p[k] for k in ['p_paddr','p_filesz','p_memsz']} for p in elf.iter_segments() if p['p_type']=='PT_LOAD'],alloc={s.name:s['sh_size'] for s in elf.iter_sections() if s['sh_flags']&2},stack={s.name:[s['st_value'],s['st_size']] for s in sym.iter_symbols() if 'stack' in s.name and s.name in ['__stack_top','native_vruntime_stack_top','native_vruntime_stack_bottom']},ram=json.loads(next(e.glob('*-'+f.parent.name[-2]+'-default-'+f.parent.name[-1]+'/launch.json')).read_text())['ram_bytes'])
for name,data in [('phase',phase),('delta',delta),('layout',layout),('stats',stats)]:
    (r/(name+'.json')).write_text(json.dumps(data,indent=1))
for key,ss in sorted(stats.items()):
    miss=collections.Counter(g for _,m,_,_ in ss for g in m)
    print(key,dict(miss),[w[2] for w in ss],ss[0][-1])
print('controls',[(p.stem,p.read_text().strip()) for p in sorted((r/'controls').glob('*.rc'))])