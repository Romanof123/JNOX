
user.elf:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000400000 <_start>:
  400000:	aa1f03fd 	mov	x29, xzr
  400004:	aa1f03fe 	mov	x30, xzr
  400008:	f94003e0 	ldr	x0, [sp]
  40000c:	910023e1 	add	x1, sp, #0x8
  400010:	94000041 	bl	400114 <main>
  400014:	93407c00 	sxtw	x0, w0
  400018:	d2800028 	mov	x8, #0x1                   	// #1
  40001c:	d4094021 	svc	#0x4a01
  400020:	d4200000 	brk	#0x0

0000000000400024 <__jnox_errno_location>:
  400024:	d503201f 	nop
  400028:	1000fee0 	adr	x0, 402004 <__jnox_errno_location.initial_thread_errno>
  40002c:	d65f03c0 	ret

0000000000400030 <open>:
  400030:	d100c3ff 	sub	sp, sp, #0x30
  400034:	a90093e3 	stp	x3, x4, [sp, #8]
  400038:	f90003e2 	str	x2, [sp]
  40003c:	a9019be5 	stp	x5, x6, [sp, #24]
  400040:	f90017e7 	str	x7, [sp, #40]
  400044:	340000e1 	cbz	w1, 400060 <open+0x30>
  400048:	d0000008 	adrp	x8, 402000 <bias>
  40004c:	528002c9 	mov	w9, #0x16                  	// #22
  400050:	12800000 	mov	w0, #0xffffffff            	// #-1
  400054:	b9000509 	str	w9, [x8, #4]
  400058:	9100c3ff 	add	sp, sp, #0x30
  40005c:	d65f03c0 	ret
  400060:	aa1f03e1 	mov	x1, xzr
  400064:	aa1f03e2 	mov	x2, xzr
  400068:	52800048 	mov	w8, #0x2                   	// #2
  40006c:	d4094021 	svc	#0x4a01
  400070:	b7f80060 	tbnz	x0, #63, 40007c <open+0x4c>
  400074:	9100c3ff 	add	sp, sp, #0x30
  400078:	d65f03c0 	ret
  40007c:	4b0003e8 	neg	w8, w0
  400080:	d0000009 	adrp	x9, 402000 <bias>
  400084:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  400088:	b9000528 	str	w8, [x9, #4]
  40008c:	9100c3ff 	add	sp, sp, #0x30
  400090:	d65f03c0 	ret

0000000000400094 <read>:
  400094:	52800068 	mov	w8, #0x3                   	// #3
  400098:	93407c00 	sxtw	x0, w0
  40009c:	d4094021 	svc	#0x4a01
  4000a0:	b7f80040 	tbnz	x0, #63, 4000a8 <read+0x14>
  4000a4:	d65f03c0 	ret
  4000a8:	4b0003e8 	neg	w8, w0
  4000ac:	d0000009 	adrp	x9, 402000 <bias>
  4000b0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  4000b4:	b9000528 	str	w8, [x9, #4]
  4000b8:	d65f03c0 	ret

00000000004000bc <write>:
  4000bc:	52800088 	mov	w8, #0x4                   	// #4
  4000c0:	93407c00 	sxtw	x0, w0
  4000c4:	d4094021 	svc	#0x4a01
  4000c8:	b7f80040 	tbnz	x0, #63, 4000d0 <write+0x14>
  4000cc:	d65f03c0 	ret
  4000d0:	4b0003e8 	neg	w8, w0
  4000d4:	d0000009 	adrp	x9, 402000 <bias>
  4000d8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  4000dc:	b9000528 	str	w8, [x9, #4]
  4000e0:	d65f03c0 	ret

00000000004000e4 <close>:
  4000e4:	aa1f03e1 	mov	x1, xzr
  4000e8:	aa1f03e2 	mov	x2, xzr
  4000ec:	93407c00 	sxtw	x0, w0
  4000f0:	528000a8 	mov	w8, #0x5                   	// #5
  4000f4:	d4094021 	svc	#0x4a01
  4000f8:	b7f80040 	tbnz	x0, #63, 400100 <close+0x1c>
  4000fc:	d65f03c0 	ret
  400100:	4b0003e8 	neg	w8, w0
  400104:	d0000009 	adrp	x9, 402000 <bias>
  400108:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  40010c:	b9000528 	str	w8, [x9, #4]
  400110:	d65f03c0 	ret

0000000000400114 <main>:
  400114:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  400118:	2a0003e8 	mov	w8, w0
  40011c:	52800b40 	mov	w0, #0x5a                  	// #90
  400120:	71000d1f 	cmp	w8, #0x3
  400124:	a9014ff4 	stp	x20, x19, [sp, #16]
  400128:	910003fd 	mov	x29, sp
  40012c:	540000e1 	b.ne	400148 <main+0x34>  // b.any
  400130:	b40000c1 	cbz	x1, 400148 <main+0x34>
  400134:	f9400c28 	ldr	x8, [x1, #24]
  400138:	b5000068 	cbnz	x8, 400144 <main+0x30>
  40013c:	f9401028 	ldr	x8, [x1, #32]
  400140:	b40000a8 	cbz	x8, 400154 <main+0x40>
  400144:	52800b40 	mov	w0, #0x5a                  	// #90
  400148:	a9414ff4 	ldp	x20, x19, [sp, #16]
  40014c:	a8c27bfd 	ldp	x29, x30, [sp], #32
  400150:	d65f03c0 	ret
  400154:	f9400028 	ldr	x8, [x1]
  400158:	b40009c8 	cbz	x8, 400290 <main+0x17c>
  40015c:	39400109 	ldrb	w9, [x8]
  400160:	7100bd3f 	cmp	w9, #0x2f
  400164:	54000961 	b.ne	400290 <main+0x17c>  // b.any
  400168:	39400509 	ldrb	w9, [x8, #1]
  40016c:	7101893f 	cmp	w9, #0x62
  400170:	54000901 	b.ne	400290 <main+0x17c>  // b.any
  400174:	39400909 	ldrb	w9, [x8, #2]
  400178:	7101a53f 	cmp	w9, #0x69
  40017c:	540008a1 	b.ne	400290 <main+0x17c>  // b.any
  400180:	39400d09 	ldrb	w9, [x8, #3]
  400184:	7101b93f 	cmp	w9, #0x6e
  400188:	54000841 	b.ne	400290 <main+0x17c>  // b.any
  40018c:	39401109 	ldrb	w9, [x8, #4]
  400190:	7100bd3f 	cmp	w9, #0x2f
  400194:	540007e1 	b.ne	400290 <main+0x17c>  // b.any
  400198:	39401509 	ldrb	w9, [x8, #5]
  40019c:	7101b93f 	cmp	w9, #0x6e
  4001a0:	54000781 	b.ne	400290 <main+0x17c>  // b.any
  4001a4:	39401909 	ldrb	w9, [x8, #6]
  4001a8:	7101853f 	cmp	w9, #0x61
  4001ac:	54000721 	b.ne	400290 <main+0x17c>  // b.any
  4001b0:	39401d09 	ldrb	w9, [x8, #7]
  4001b4:	7101d13f 	cmp	w9, #0x74
  4001b8:	540006c1 	b.ne	400290 <main+0x17c>  // b.any
  4001bc:	39402109 	ldrb	w9, [x8, #8]
  4001c0:	7101a53f 	cmp	w9, #0x69
  4001c4:	54000661 	b.ne	400290 <main+0x17c>  // b.any
  4001c8:	39402509 	ldrb	w9, [x8, #9]
  4001cc:	7101d93f 	cmp	w9, #0x76
  4001d0:	54000601 	b.ne	400290 <main+0x17c>  // b.any
  4001d4:	39402909 	ldrb	w9, [x8, #10]
  4001d8:	7101953f 	cmp	w9, #0x65
  4001dc:	540005a1 	b.ne	400290 <main+0x17c>  // b.any
  4001e0:	39402d09 	ldrb	w9, [x8, #11]
  4001e4:	71017d3f 	cmp	w9, #0x5f
  4001e8:	54000541 	b.ne	400290 <main+0x17c>  // b.any
  4001ec:	39403109 	ldrb	w9, [x8, #12]
  4001f0:	7101cd3f 	cmp	w9, #0x73
  4001f4:	540004e1 	b.ne	400290 <main+0x17c>  // b.any
  4001f8:	39403509 	ldrb	w9, [x8, #13]
  4001fc:	7101d13f 	cmp	w9, #0x74
  400200:	54000481 	b.ne	400290 <main+0x17c>  // b.any
  400204:	39403909 	ldrb	w9, [x8, #14]
  400208:	7101853f 	cmp	w9, #0x61
  40020c:	54000421 	b.ne	400290 <main+0x17c>  // b.any
  400210:	39403d09 	ldrb	w9, [x8, #15]
  400214:	7101c93f 	cmp	w9, #0x72
  400218:	540003c1 	b.ne	400290 <main+0x17c>  // b.any
  40021c:	39404109 	ldrb	w9, [x8, #16]
  400220:	7101d13f 	cmp	w9, #0x74
  400224:	54000361 	b.ne	400290 <main+0x17c>  // b.any
  400228:	39404509 	ldrb	w9, [x8, #17]
  40022c:	7101d53f 	cmp	w9, #0x75
  400230:	54000301 	b.ne	400290 <main+0x17c>  // b.any
  400234:	39404909 	ldrb	w9, [x8, #18]
  400238:	7101c13f 	cmp	w9, #0x70
  40023c:	540002a1 	b.ne	400290 <main+0x17c>  // b.any
  400240:	39404d09 	ldrb	w9, [x8, #19]
  400244:	71017d3f 	cmp	w9, #0x5f
  400248:	54000241 	b.ne	400290 <main+0x17c>  // b.any
  40024c:	39405109 	ldrb	w9, [x8, #20]
  400250:	7101c13f 	cmp	w9, #0x70
  400254:	540001e1 	b.ne	400290 <main+0x17c>  // b.any
  400258:	39405509 	ldrb	w9, [x8, #21]
  40025c:	7101c93f 	cmp	w9, #0x72
  400260:	54000181 	b.ne	400290 <main+0x17c>  // b.any
  400264:	39405909 	ldrb	w9, [x8, #22]
  400268:	7101bd3f 	cmp	w9, #0x6f
  40026c:	54000121 	b.ne	400290 <main+0x17c>  // b.any
  400270:	39405d09 	ldrb	w9, [x8, #23]
  400274:	7101893f 	cmp	w9, #0x62
  400278:	540000c1 	b.ne	400290 <main+0x17c>  // b.any
  40027c:	39406109 	ldrb	w9, [x8, #24]
  400280:	7101953f 	cmp	w9, #0x65
  400284:	54000061 	b.ne	400290 <main+0x17c>  // b.any
  400288:	39406508 	ldrb	w8, [x8, #25]
  40028c:	34000068 	cbz	w8, 400298 <main+0x184>
  400290:	52800b60 	mov	w0, #0x5b                  	// #91
  400294:	17ffffad 	b	400148 <main+0x34>
  400298:	f9400428 	ldr	x8, [x1, #8]
  40029c:	b4ffffa8 	cbz	x8, 400290 <main+0x17c>
  4002a0:	39400109 	ldrb	w9, [x8]
  4002a4:	7100e13f 	cmp	w9, #0x38
  4002a8:	54ffff41 	b.ne	400290 <main+0x17c>  // b.any
  4002ac:	39400509 	ldrb	w9, [x8, #1]
  4002b0:	35ffff09 	cbnz	w9, 400290 <main+0x17c>
  4002b4:	f9400829 	ldr	x9, [x1, #16]
  4002b8:	b4fffec9 	cbz	x9, 400290 <main+0x17c>
  4002bc:	3940012a 	ldrb	w10, [x9]
  4002c0:	7100c55f 	cmp	w10, #0x31
  4002c4:	54fffe61 	b.ne	400290 <main+0x17c>  // b.any
  4002c8:	3940052a 	ldrb	w10, [x9, #1]
  4002cc:	7100cd5f 	cmp	w10, #0x33
  4002d0:	54fffe01 	b.ne	400290 <main+0x17c>  // b.any
  4002d4:	3940092a 	ldrb	w10, [x9, #2]
  4002d8:	35fffdca 	cbnz	w10, 400290 <main+0x17c>
  4002dc:	d000000a 	adrp	x10, 402000 <bias>
  4002e0:	b940094a 	ldr	w10, [x10, #8]
  4002e4:	3500056a 	cbnz	w10, 400390 <main+0x27c>
  4002e8:	d0000013 	adrp	x19, 402000 <bias>
  4002ec:	b9400e6a 	ldr	w10, [x19, #12]
  4002f0:	3500050a 	cbnz	w10, 400390 <main+0x27c>
  4002f4:	d0000014 	adrp	x20, 402000 <bias>
  4002f8:	b940028a 	ldr	w10, [x20]
  4002fc:	7100215f 	cmp	w10, #0x8
  400300:	54000481 	b.ne	400390 <main+0x27c>  // b.any
  400304:	39400108 	ldrb	w8, [x8]
  400308:	5280014b 	mov	w11, #0xa                   	// #10
  40030c:	3940012a 	ldrb	w10, [x9]
  400310:	39400529 	ldrb	w9, [x9, #1]
  400314:	5100c100 	sub	w0, w8, #0x30
  400318:	1b0b2549 	madd	w9, w10, w11, w9
  40031c:	51084121 	sub	w1, w9, #0x210
  400320:	94000027 	bl	4003bc <multiply>
  400324:	d503201f 	nop
  400328:	1000e70b 	adr	x11, 402008 <products>
  40032c:	b9400168 	ldr	w8, [x11]
  400330:	b9400569 	ldr	w9, [x11, #4]
  400334:	b940028a 	ldr	w10, [x20]
  400338:	b940016b 	ldr	w11, [x11]
  40033c:	7100417f 	cmp	w11, #0x10
  400340:	540002c1 	b.ne	400398 <main+0x284>  // b.any
  400344:	b9400e6b 	ldr	w11, [x19, #12]
  400348:	52800ba0 	mov	w0, #0x5d                  	// #93
  40034c:	7100357f 	cmp	w11, #0xd
  400350:	54ffefc1 	b.ne	400148 <main+0x34>  // b.any
  400354:	0b080128 	add	w8, w9, w8
  400358:	0b0a0108 	add	w8, w8, w10
  40035c:	7100951f 	cmp	w8, #0x25
  400360:	54ffef41 	b.ne	400148 <main+0x34>  // b.any
  400364:	97ffff30 	bl	400024 <__jnox_errno_location>
  400368:	b0000001 	adrp	x1, 401000 <multiply+0xc44>
  40036c:	b900001f 	str	wzr, [x0]
  400370:	91008021 	add	x1, x1, #0x20
  400374:	52800020 	mov	w0, #0x1                   	// #1
  400378:	52800062 	mov	w2, #0x3                   	// #3
  40037c:	97ffff50 	bl	4000bc <write>
  400380:	b100041f 	cmn	x0, #0x1
  400384:	540000e0 	b.eq	4003a0 <main+0x28c>  // b.none
  400388:	52800bc0 	mov	w0, #0x5e                  	// #94
  40038c:	17ffff6f 	b	400148 <main+0x34>
  400390:	52800b80 	mov	w0, #0x5c                  	// #92
  400394:	17ffff6d 	b	400148 <main+0x34>
  400398:	52800ba0 	mov	w0, #0x5d                  	// #93
  40039c:	17ffff6b 	b	400148 <main+0x34>
  4003a0:	97ffff21 	bl	400024 <__jnox_errno_location>
  4003a4:	b9400009 	ldr	w9, [x0]
  4003a8:	52800be8 	mov	w8, #0x5f                  	// #95
  4003ac:	7100993f 	cmp	w9, #0x26
  4003b0:	528004a9 	mov	w9, #0x25                  	// #37
  4003b4:	1a880120 	csel	w0, w9, w8, eq  // eq = none
  4003b8:	17ffff64 	b	400148 <main+0x34>

00000000004003bc <multiply>:
  4003bc:	b0000008 	adrp	x8, 401000 <multiply+0xc44>
  4003c0:	d000000a 	adrp	x10, 402000 <bias>
  4003c4:	91006108 	add	x8, x8, #0x18
  4003c8:	9100214a 	add	x10, x10, #0x8
  4003cc:	b9400109 	ldr	w9, [x8]
  4003d0:	1b007d29 	mul	w9, w9, w0
  4003d4:	b9000149 	str	w9, [x10]
  4003d8:	b9400508 	ldr	w8, [x8, #4]
  4003dc:	1b017d08 	mul	w8, w8, w1
  4003e0:	b9000548 	str	w8, [x10, #4]
  4003e4:	d65f03c0 	ret
