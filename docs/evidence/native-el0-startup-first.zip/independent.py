from pathlib import Path
import json,re,struct,hashlib
p=Path('first');run=json.loads((p/'launch.json').read_bytes());mem=(p/'ram.bin').read_bytes();base=run['ram_base']
def pa(a,n):
 i=a-base;assert 0<=i<=len(mem)-n;return mem[i:i+n]
journal=int(re.search(r'^(\w+) \w+ B jnox_native_el0_journal$',Path('kernel.map').read_text(),re.M)[1],16)
rows=list(struct.iter_unpack('<16Q',pa(journal,1152)));header,w,e=rows[:3];root=header[14];sp=header[5]
def translate(va):
 t=root;mask=0xfffffffff000
 for shift in [30,21,12]:
  desc=int.from_bytes(pa(t+8*(va>>shift&511),8),'little')
  if desc&1==0:return None
  assert desc&3==3;t=desc&mask
 return t+(va&4095)
def read(va,n):return bytes(pa(translate(va+i),1)[0] for i in range(n))
stack=struct.unpack('<6Q',read(sp,48));argv=[read(addr,n).decode() for addr,n in zip(stack[1:4],(25,1,2))]
assert stack[0]==3 and stack[4:]==(0,0) and argv==['/bin/native_startup_probe','8','13']
assert translate(0x1000000)==translate(0x1011000)==None and sp%16==0
assert w[7:9]==(4,1) and w[10]==3 and struct.unpack('<q',struct.pack('<Q',w[11]))[0]==-38 and read(w[9],3)==b'37\n'
assert e[7:9]==(1,37) and all(row[3]==0x56004a01 and row[4]&31==0 and read(row[5]-4,4)==bytes.fromhex('214009d4') for row in [w,e])
print(json.dumps(dict(argc=3,sp=hex(sp),argv=argv,argv_ptrs=[hex(i) for i in stack[1:4]],header=header,write=w,exit=e,write_bytes=list(read(w[9],3)),guards=['0x1000000','0x1011000'],original_replay_rc=1,reason='Original validator omitted existing JNOX M1 BOOT and JNOX M1 READY privileged banners'),indent=2))
