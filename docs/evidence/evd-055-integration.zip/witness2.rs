#[path="../ordinary-proportional-main-pinned/kernel/src/feedback_policy.rs"] mod feedback_policy;
#[path="../ordinary-proportional-main-pinned/kernel/src/proportional_policy.rs"] mod proportional_policy;
use proportional_policy::{Proportional,reduce_word};
fn main() {
    for (raw, expected) in [(0,None),(1,None),(2,Some(2)),(6,Some(6)),(7,Some(0))] {
        assert_eq!(reduce_word(raw,7),expected);
    }
    let seed=0x61c8864680b583eb;
    let mut p=Proportional::lottery([1,2,4],seed).unwrap();
    assert_eq!(p.dispatch(), None);
    assert_eq!(p.lottery_state(),Some(seed));
    assert!(p.draw_record().is_none());
    assert!(p.set_ready_mask(7));
    let owner=p.dispatch().unwrap();
    let d=p.draw_record().unwrap();
    assert_eq!((d.before,d.after,d.words,d.raw,d.total),(seed,0x9e3779b97f4a7c15,2,0xe220a8397b1dcdaf,7));
    assert_eq!(d.ticket,(d.raw%7) as u32);
    assert_eq!(Some(owner),p.winner_for_draw(d.ticket));
    println!("empty state {seed:x}; rejected zero then accepted {:x} in {} words; ticket {} owner {}",d.raw,d.words,d.ticket,owner);
}