from pathlib import Path
import json,subprocess as sp,hashlib,os,zipfile,sys
d=Path(__file__).resolve().parent;r=d.parent;s=r/'ordinary-proportional-main-pinned'
h=lambda b:hashlib.sha256(b).hexdigest()
sha=lambda p:h(p.read_bytes())
j=json.loads((d/'index.json').read_bytes())
sels={}
for k,v in j['images'].items():
    env={a:b for a,b in os.environ.items() if not a.startswith(('JNOX_','CARGO_FEATURE_'))}
    env.update(v['env'])
    if k=='mixed':env['CARGO_FEATURE_PROPORTIONAL_BENCH']='1'
    x=sp.run([d/'selector.exe'],env=env,capture_output=True)
    (d/k/'selector.stdout').write_bytes(x.stdout);(d/k/'selector.stderr').write_bytes(x.stderr)
    ok=(v['expected_error'].encode() in x.stderr and x.returncode!=0) if v['expected_error'] else x.returncode==0
    if k in ('lottery1','lottery2','stride'):ok=ok and ('jnox_prop_case="'+k+'"').encode() in x.stdout
    sels[k]=dict(exit=x.returncode,ok=ok)
ev=s/'docs/evidence';evj=json.loads((ev/'evd-055.json').read_bytes());z=ev/evj['archive']['file']
assert sha(z)==evj['archive']['sha256']
ar={}
with zipfile.ZipFile(z) as a:
    for line in a.read('FILES.sha256').decode().splitlines():
        digest,name=line.split('  ',1);assert h(a.read(name))==digest
    assert len(a.namelist())==35
    a.extractall(d/'archive-replay')
    for k in ['lottery1','lottery2','stride']:
        b=d/'archive-replay';v=b/'ordinary-136-first-three'/k
        x=sp.check_output([sys.executable,b/'ordinary-proportional-independent/score.py','score',k,v/'uart','--elf',v/'kernel.elf','--exceptions',v/'exceptions'])
        out=json.loads(x);old=json.loads((v/'score.json').read_bytes())
        assert all(out[key]==old[key] for key in ('raw_rows','grants','counts','whole_service','findings','first_guest_record')) and out['complete_arithmetic_and_mechanism_observation']
        ar[k]=True
g={}
for k in ar:
    p=d/'guests'/k;q=json.loads((p/'score.json').read_bytes());e=(p/'exceptions').read_text()
    g[k]=dict(qualified=q['complete_arithmetic_and_mechanism_observation'],findings=q['findings'],counts=q['counts'],service=q['whole_service'],phase_service=[[sum(a[6] for a in q['grants'][l:u] if a[1]==i) for i in range(3)] for l,u in [(0,8),(8,16)]] if k=='stride' else None,irq=e.count('[IRQ]'),svc=e.count('[SVC]'),eret=e.count('Exception return'),outcome=json.loads((p/'outcome.json').read_bytes()),hashes={f.name:sha(f) for f in p.iterdir()})
aud=json.loads((d/'audit.json').read_bytes())
report=dict(source=j['revision'],tree=j['tree'],build_index_sha=sha(d/'index.json'),freeze_sha=sha(d/'guests/freeze.json'),launch_sha=sha(d/'launch.py'),comparisons={k:dict(whole=v['whole_identical'],load=v['comparison']['identical'],text=v['comparison']['text_identical'],sha=v['sha256'],reference=v['reference_sha']) for k,v in j['images'].items() if 'comparison'in v},builds={k:[v['exit'],v['ok'],v['expected_error']] for k,v in j['images'].items()},standalone_selectors=sels,native=dict(results=(d/'native.log').read_text().strip().splitlines()[-1],log_sha=sha(d/'native.log'),witness=(d/'witness.log').read_text().strip(),first_harness_attempt='compile failed because scratch harness omitted feedback_policy; original compiler diagnostics retained, second harness includes the actual pinned module'),guests=g,archive=dict(zip_sha=sha(z),zip_entries=35,manifest_verified=34,replays=ar,verifier_sha=sha(b/'ordinary-136-first-three/verification.json')),audit=dict(findings=aud['findings'],typed=aud['evidence']['EVD-055'],sha=sha(d/'audit.json')),scope='Three ordinary default-clock guests. Both control images built and compared only; no new control timing observations. No injected timing or enforcement arms. External exceptions establish ordered PCs; integer service and fingerprints use guest data. Windows-built ELFs copied to native Linux /tmp. Historical first captures kept separately.')
(d/'verification.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(sels,sha(d/'verification.json'))