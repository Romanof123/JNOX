from pathlib import Path
import subprocess as sp,hashlib,json,os,shutil
d=Path(__file__).resolve().parent;r=d.parent;s=r/'ordinary-proportional-main-pinned'
exec((r/'partition-parent-builds/batches.py').read_text().split('def batch(')[0])
pre=json.loads((r/'mask-prop-builds/index.json').read_bytes())['images']
ctl=json.loads((r/'control53-integrated-gate/builds.json').read_bytes())
base=dict(JNOX_BOARD='virt',JNOX_PROFILE='proportional',JNOX_APP='lottery1')
cases=[(k,dict(base,JNOX_APP=k),None,None,r/'mask-prop-builds'/k/'kernel.elf',pre[k]['sha256']) for k in ['lottery1','lottery2','stride']]
for k in ['markers-rm-marker','markers-rm-baseline']:
    opts={n:v for n,v in ctl[k]['env'].items() if n.startswith('JNOX_')};cases.append((k,opts,None,None,r/'control53-integrated-gate'/k/'kernel.elf',ctl[k]['sha256']))
for name,changes,feature,err in [('wrong-control',dict(JNOX_CONTROL_CASE='healthy'),None,'JNOX_CONTROL_CASE must be unset for JNOX_PROFILE=proportional'),('wrong-board',dict(JNOX_BOARD='pi4'),None,'ordinary proportional requires virt and no benchmark features'),('wrong-app',dict(JNOX_APP='invalid'),None,'ordinary proportional requires an explicit lottery, stride or diagnostic app'),('wrong-profile',dict(JNOX_PROFILE='aperiodic'),None,'invalid aperiodic application'),('mixed',{},'proportional-bench','ordinary proportional requires virt and no benchmark features')]:
    cases.append((name,dict(base,**changes),feature,err,None,None))
idx=dict(revision=sp.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),tree=sp.check_output(['git','rev-parse','HEAD^{tree}'],cwd=s,text=True).strip(),rustc=sp.check_output(['rustc','+1.95.0','-vV'],text=True),images={})
assert idx['revision']=='589e927bdc2e21ed68de1315d030d6231d18bacb' and not sp.check_output(['git','status','--porcelain'],cwd=s)
for k,opts,feat,err,ref,old in cases:
    out=d/k;out.mkdir();argv=['cargo','+1.95.0','build','--release','--locked','-j1']+(['--features',feat] if feat else [])
    env={a:b for a,b in os.environ.items() if not a.startswith(('JNOX_','RUST','CARGO_TARGET_','CARGO_PROFILE_')) and a!='CARGO_ENCODED_RUSTFLAGS'};env.update(opts,CARGO_TARGET_DIR=str(d/'target'),CARGO_BUILD_JOBS='1',TEMP=str(out),TMP=str(out))
    run=sp.run(argv,cwd=s/'kernel',env=env,stdout=sp.PIPE,stderr=sp.STDOUT)
    (out/'build.log').write_bytes(run.stdout)
    row=dict(env=opts,argv=argv,exit=run.returncode,log_sha256=h(run.stdout),expected_error=err,ok=bool(run.returncode and err.encode() in run.stdout) if err else run.returncode==0)
    if not run.returncode:
        e=out/'kernel.elf';shutil.copyfile(d/'target/aarch64-unknown-none/release/jnox-kernel',e);row.update(sha256=h(e.read_bytes()))
        if ref:
            assert h(ref.read_bytes())==old
            row.update(reference_sha=old,whole_identical=e.read_bytes()==ref.read_bytes(),comparison=compare(e,ref))
    idx['images'][k]=row;(d/'index.json').write_text(json.dumps(idx,indent=2))
    print(k,row['ok'],row.get('whole_identical'),row.get('comparison',{}).get('identical'),flush=True)