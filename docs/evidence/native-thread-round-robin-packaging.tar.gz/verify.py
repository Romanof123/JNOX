import hashlib, json, os, pathlib, subprocess, sys, tempfile
P=pathlib.Path
src, elf, prime, out = map(lambda p:P(p).resolve(),sys.argv[1:])
sha="9df9437b626da3bcaa4151f3db1370e7db24ae13"
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=src,text=True).strip()==sha
assert not subprocess.check_output(["git","diff","HEAD","--name-only"],cwd=src)
digest=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert digest(elf)=="17e27adc8a3a1d0532a87ad576ef345e6365f38362682bb2e1f6f4eb59d741ec"
scratch=P(tempfile.mkdtemp(prefix="rr316-package-"))
env={k:v for k,v in os.environ.items() if not k.startswith(("JNOX_","CARGO_FEATURE_"))}
cases=[
("threads-rr","--threads 2 --policy rr --quantum-ticks 625000","rr"),
("threads-coop","--threads 2","cooperative"),
("process-rr",f"--policy rr --priority 1 --peer-elf {prime} --peer-priority 1 --quantum-ticks 625000","rr"),
("missing","--threads 2 --policy rr",None),
("zero","--threads 2 --policy rr --quantum-ticks 0",None),
("over","--threads 2 --policy rr --quantum-ticks 9223372036854775808",None),
("peer",f"--threads 2 --policy rr --quantum-ticks 625000 --peer-elf {prime}",None),
("priority","--threads 2 --policy rr --quantum-ticks 625000 --priority 1",None),
("feedback","--threads 2 --policy mlfq",None),
("coop-quantum","--threads 2 --quantum-ticks 625000",None)]
results=[]
def run(name,cmd,cwd,environment,expected):
    p=subprocess.run(list(map(str,cmd)),cwd=cwd,env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    lines=[l.strip() for l in p.stdout.splitlines() if l.strip()]
    tail=lines[-5:]
    results.append(dict(case=name,command=list(map(str,cmd)),rc=p.returncode,expected=expected,tail=tail))
    print(name,p.returncode,tail,flush=True)
    assert p.returncode==expected
for name,flags,policy in cases:
    pkg=scratch/name
    inp=prime if name=="process-rr" else elf
    run("cli-"+name,["python3","tools/build_native_el0.py","--elf",inp,"--out",pkg]+flags.split(),src,env,0 if policy else 2)
    if policy:
        m=json.loads((pkg/"manifest.json").read_text())
        assert m["policy"]==policy and m["input"]["sha256"]==digest(inp) and m["kernel_elf_sha256"]==digest(pkg/"kernel.elf")
        assert len(m["slots"])==(2 if name=="process-rr" else 1)
        assert m.get("thread_capacity")== (None if name=="process-rr" else 2)
        if policy=="rr": assert m["quantum_ticks"]==625000
        if name=="threads-rr": assert m["scheduling_scope"]=="within_process"
        results[-1]["manifest"]={k:m.get(k) for k in ("commit","policy","thread_capacity","scheduling_scope","quantum_ticks","kernel_elf_sha256")}
    else:
        assert not (pkg/"kernel.elf").exists()
raw=dict(JNOX_ARCH="aarch64",JNOX_BOARD="virt",JNOX_PROFILE="native",JNOX_APP="process",JNOX_NATIVE_THREADS="2",JNOX_NATIVE_POLICY="rr",JNOX_NATIVE_ELF=str(elf),JNOX_NATIVE_ELF_SHA256=digest(elf),CARGO_TARGET_DIR=str(scratch/"raw-target"))
for name,extra,ok in [
("accepted",{"QUANTUM_TICKS":"625000"},True),("missing",{},False),("zero",{"QUANTUM_TICKS":"0"},False),("priority",{"QUANTUM_TICKS":"625000","PRIORITIES":"1"},False),("feedback",{"POLICY":"mlfq"},False)]:
    additions={f"JNOX_NATIVE_{k}":v for k,v in extra.items()}
    run("cargo-"+name,["cargo","build","--locked","--release","-j1","--target","aarch64-unknown-none"],src/"kernel",env|raw|additions,0 if ok else 101)
    results[-1]["build_env"]=raw|additions
(out/"results.json").write_text(json.dumps(results,indent=2)+"\n")
