#!/bin/sh
# Run from exact-head review worktree after extracting the committed sealed archive.
set -u
out=$1
sealed=$2
export PYTHONDONTWRITEBYTECODE=1
'/mnt/c/Program Files/Git/cmd/git.exe' rev-parse HEAD
'/mnt/c/Program Files/Git/cmd/git.exe' status --porcelain=v1
'/mnt/c/Program Files/Git/cmd/git.exe' rev-parse HEAD:docs/evidence/pi4-native-smp-first-execution-raw.tar.gz
'/mnt/c/Program Files/Git/cmd/git.exe' hash-object docs/evidence/pi4-native-smp-first-execution-raw.tar.gz
sha256sum docs/evidence/pi4-native-smp-first-execution-raw.tar.gz
python3 --version
python3 -m unittest discover -v -s tools -p test_pi4_native_smp_stage1.py >"$out/unit.log" 2>&1
printf "unit %s\n" "$?" >"$out/return-codes.txt"
for p in p1 p2 p3 p4 p5; do
    python3 tools/pi4_native_smp_stage1.py "$p" "$sealed/$p" >"$out/$p.json" 2>"$out/$p.stderr"
    printf "%s %s\n" "$p" "$?" >>"$out/return-codes.txt"
done
python3 "$out/independent.py" "$sealed" "$out" >"$out/independent.json" 2>"$out/independent.stderr"
printf "independent %s\n" "$?" >>"$out/return-codes.txt"
# Omit exactly one item from a temporary private replay input. Sealed archive stays intact.
scratch=$(mktemp -d)
for f in "$sealed"/p2/*; do
    case "${f##*/}" in exceptions.log) continue ;; esac
    ln -s "$(realpath "$f")" "$scratch/${f##*/}"
done
python3 tools/pi4_native_smp_stage1.py p2 "$scratch" >"$out/missing-trace.stdout" 2>"$out/missing-trace.stderr"
printf "missing-trace %s\n" "$?" >>"$out/return-codes.txt"
python3 tools/pi4_native_smp_stage1.py p1 "$sealed/p2" >"$out/wrong-session.stdout" 2>"$out/wrong-session.stderr"
printf "wrong-session %s\n" "$?" >>"$out/return-codes.txt"
cat "$out/return-codes.txt"
