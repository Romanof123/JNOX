#!/bin/sh
set -eu
cd /home/ywcho/arm-speed-lab-tools/qemu-11.1.3
q=build/qemu-system-aarch64
echo "Working directory: $(pwd)"
set -x
sha256sum "$q" include/plugins/qemu-plugin.h build/configure.log build/config.status build/config-host.h build/meson-private/cmd_line.txt tcg/tcg-op-ldst.c accel/tcg/translator.c accel/tcg/plugin-gen.c target/arm/helper.c target/arm/tcg/helper-a64.c target/arm/tcg/translate-a64.c
readelf -nW "$q" | grep 'Build ID'
"$q" --version
"$q" -help | grep -i -A1 '^-plugin'
"$q" -plugin help
grep -E '^exec ' build/config.status
grep -i -E 'config_plugin|tcg plugins|plugins +=|plugins +:' build/config-host.h build/meson-private/cmd_line.txt build/configure.log
nm -D --defined-only "$q" | grep ' T qemu_plugin_' | wc -l
nm -D --defined-only "$q" | grep ' T qemu_plugin_'
grep -nE 'QEMU_PLUGIN_VERSION|qemu_plugin_vcpu_discon_cb_t|QEMU_PLUGIN_DISCON_|qemu_plugin_register_vcpu_(discon_cb|idle_cb|resume_cb|insn_exec_cb|tb_trans_cb|tb_exec_cb|mem_cb)|qemu_plugin_(get_hwaddr|hwaddr_is_io|hwaddr_phys_addr|mem_is_store|mem_is_big_endian|mem_size_shift|mem_get_value|read_register|get_registers)' include/plugins/qemu-plugin.h
sed -n '161,200p;290,307p;684,708p;741,780p' include/plugins/qemu-plugin.h
sed -n '163,181p' accel/tcg/translator.c
sed -n '466,486p' accel/tcg/plugin-gen.c
sed -n '315,327p' tcg/tcg-op-ldst.c
sed -n '8919,8936p;9651,9659p;9668,9685p' target/arm/helper.c
sed -n '2060,2087p' target/arm/tcg/translate-a64.c
sed -n '714,727p;739,761p' target/arm/tcg/helper-a64.c
sed -n '1074,1123p' include/plugins/qemu-plugin.h
