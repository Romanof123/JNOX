"""Independent raw-frame and finite-domain checks, executed from the exact source root."""
import argparse
import copy
import hashlib
import json
import re
import struct
import sys
from itertools import product
from pathlib import Path
from random import Random

parser = argparse.ArgumentParser()
parser.add_argument("sealed", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
sys.path.insert(0, str(Path("tools").resolve()))
from pi4_native_smp_stage1 import evaluate

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def raw_check(position):
    root = args.sealed / position
    linked = json.loads((args.output / (position + ".json")).read_text())
    seal = json.loads((root / "session.json").read_bytes())
    assert digest(root / "session.json") == linked["session_sha256"]
    for name, expected in seal["files"].items():
        assert digest(root / name) == expected, name
    launch = json.loads((root / "launch.json").read_bytes())
    uart = (root / "uart.bin").read_text()
    ram = (root / "ram.bin").read_bytes()
    def records(name):
        return [tuple(map(int,r.split())) for r in re.findall(r"^NATIVE SMP " + name + r" ([\d ]+)$",uart,re.M)]
    def words(addr, n):
        return struct.unpack_from("<%dQ" % n, ram, addr-launch["ram_base"])
    def private(cpu_root, va):
        mask = (1 << 48) - 4096
        addr = cpu_root & mask
        for shift in (30,21,12):
            descriptor = words(addr+8*((va>>shift)&511),1)[0]
            assert descriptor & 3 == 3
            addr = descriptor & mask
        return addr + va%4096
    task = sorted(records("TASK"))
    positions = [[],[]]
    for cpu, base, length, width, dropped, frames, frame_size in sorted(records("JOURNAL")):
        assert not dropped and width == 37 and frame_size == 816
        rr = []
        for i in range(length):
            r = words(base+i*width*8,width)
            f,g = (words(frames+(2*i+side)*frame_size,102) for side in (0,1))
            assert r[:2] == (cpu,i)
            pid = r[6]
            candidate = None
            if pid < 2:
                assert f[32:34] == r[30:32] and f[33]&15 == 0 and task[pid][5] == r[21]
                addr = f[32]
                # Exhaustive allowlist derived from each retained disassembly.
                if pid == 0 and addr in (0x400484,0x400488,0x40048c,0x400490,0x400494,0x400498,
                        0x4004a0,0x4004a4,0x4004a8,0x4004ac,0x4004b0,0x4004b4,0x4004b8,0x4004bc,
                        0x4004c0,0x4004c4,0x4004c8):
                    candidate=f[8]&0xffffffff
                    assert 3<=candidate<=999999 and candidate%2
                if pid == 1 and addr in (0x400050,0x400054,0x400058,0x40005c,0x400060,0x400064,
                        0x400068,0x40006c,0x400070,0x400074,0x400078,0x40007c):
                    candidate=f[11]&0xffffffff
                    assert 1000001<=candidate<=1999999 and candidate%2
            rr.append((r,f,g,candidate))
        for i, ((x,f,g,p), (y,h,j,q)) in enumerate(zip(rr,rr[1:])):
            def ppi(r):
                return r[2]==1 and r[3]&1023==30 and r[10]==r[32]<=r[4] and r[33]&7==5
            if p is None or q is None or q<=p or x[6]!=x[7] or x[7]!=y[6] or not (ppi(x) and ppi(y)):
                continue
            assert f==g and x[5]<=y[8]<=y[4]
            positions[x[6]].append([cpu,i,i+1,p,q])
    assert positions==linked["advancing_ppi_pairs"]
    aligned = records("CAL")[0]
    offset=[aligned[0]-aligned[1],aligned[2]-aligned[1]]
    assert offset==linked["offset"]
    pas=[private(t[5],0x402000) for t in task]
    assert len(set(pas))==len(task)
    return dict(pos=position, files=len(seal["files"]), session=linked["session_sha256"], pairs=list(map(len,positions)),
                offset=offset, roots=[hex(t[5]) for t in task], result_pas=[hex(pa) for pa in pas],
                result_values=[struct.unpack_from("<I",ram,pa-launch["ram_base"])[0] for pa in pas],
                first_margin=min(linked["best_productive_chain"]["timestamp_margins"]),
                irq_margin=min(linked["best_productive_chain"]["exception_order_margins"]))

def row(cpu, row, resume, compare, entry, post=None):
    event=dict(cpu=cpu,row=row,resume=resume,prior_cval=compare,entry=entry)
    if post is not None:
        event["el0_after_return"]=post
    return event

def actual_order(pair1,pair2,offset):
    # Exhaust all possible return and interrupt instants, with one shared offset,
    # independent of the production margin functions. Small integral tick domain.
    a,c=pair1
    b,d=pair2
    if a["cpu"]==b["cpu"] or any(first["cpu"]!=last["cpu"] or last["row"]!=first["row"]+1
        or not last["resume"]<=last.get("el0_after_return",last["entry"]+1)<=last["entry"]
        for first,last in (pair1,pair2)):
        return False
    def ticks(lo,hi,cpu,delta):
        return range(lo+cpu*delta,hi+cpu*delta+1)
    for delta in range(offset[0],offset[1]+1):
        def irq(e):
            return ticks(max(e["resume"],e["prior_cval"],e.get("el0_after_return",0)),e["entry"],e["cpu"],delta)
        def ret(e):
            return ticks(e["resume"],e["el0_after_return"],e["cpu"],delta)
        for a0,b0,a1,b1,ra,rb in product(irq(a),irq(b),irq(c),irq(d),ret(c),ret(d)):
            if not (a0<b0<a1<b1 and ra<b0 and rb<a1):
                return False
    return True

def run_case(left,right,offset):
    observed=evaluate([[left],[right]],offset)
    expected=actual_order(left,right,offset) or actual_order(right,left,offset)
    assert observed["architectural_proof"] == expected, (left,right,offset,expected,observed)
    return expected, observed

def named():
    left=(row(0,4,95,100,102),row(0,5,108,124,126,110))
    right=(row(1,7,105,114,116),row(1,8,118,136,138,119))
    out={}
    def check(name,l,r,o,yes):
        result, detail=run_case(l,r,o)
        assert result==yes
        out[name]=detail
    check("positive",left,right,[-1,2],True)
    check("reverse_enumeration",right,left,[-1,2],True)
    shifted=copy.deepcopy((left,right))
    for pair in shifted:
        for r in pair: r["cpu"]=1-r["cpu"]
    check("opposite_cpus_and_offset",*shifted,[-2,1],True)
    for name,which,key,value in [
        ("touch_latest_return",0,"el0_after_return",113),("after_latest_entry",0,"el0_after_return",127),
        ("before_earliest_return",1,"el0_after_return",117),("intervening_irq",1,"row",10),
        ("missing_left",0,"el0_after_return",None),("missing_right",1,"el0_after_return",None),
        ("wrong_cpu",1,"cpu",0)]:
        alt=copy.deepcopy((left,right))
        e=alt[which][1]
        if value is None: del e[key]
        else: e[key]=value
        check(name,*alt,[-1,2],False)
    alt=copy.deepcopy((left,right)); alt[0][0]["entry"]=113
    check("irq_latency_tie",*alt,[-1,2],False)
    check("wide_offset_removes_proof",left,right,[-5,7],False)
    return out

rng=Random(356)
passed=positive=0
for i in range(1000):
    starts=sorted(rng.sample(range(20,60),4))
    x,v,y,w=starts
    def construct(cpu,i,t,after=False):
        r=rng.randint(min(t, (x if cpu==0 else v) + 1),t) if after else t-rng.randint(0,4)
        return row(cpu,i,r,t,t+rng.randint(0,2),r+rng.randint(0,min(2,t-r)) if after else None)
    # Generate physically viable intervals with return preceding a known user sample
    # and both after the previous trap; released rows need not share the same CPU.
    left=(construct(0,1,x),construct(0,2,y,True))
    right=(construct(1,4,v),construct(1,5,w,True))
    if left[1]["resume"]<=left[0]["entry"] or right[1]["resume"]<=right[0]["entry"]: continue
    result,_=run_case(left,right,[-rng.randint(0,2),rng.randint(0,2)])
    passed+=1; positive+=int(result)
print(json.dumps(dict(authenticated=[raw_check("p"+str(i)) for i in range(1,6)],
                      cases=named(), finite_domain={"seed":356,"valid":passed,"positive":positive,
                      "negative":passed-positive}),indent=2))