import subprocess,pathlib,time
p=pathlib.Path("/mnt/d/codex/jnox203-raw")
log=pathlib.Path.home()/"jnox203-fresh/default-final.log"
cmd=["qemu-system-aarch64","-machine","virt,gic-version=2","-cpu","cortex-a72","-accel","tcg","-smp","1","-m","128M","-nic","none","-display","none","-monitor","none","-serial","file:"+str(log),"-kernel",str(p/"default.elf")]
with (p/"capture-stderr.log").open("wb") as err:
 q=subprocess.Popen(cmd,stderr=err)
 until=time.monotonic()+100
 while q.poll() is None and time.monotonic()<until:
  time.sleep(.25)
  if log.exists() and b"AP END " in log.read_bytes(): break
 q.terminate();q.wait()
(p/"default-complete.log").write_bytes(log.read_bytes())
