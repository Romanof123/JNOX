cd /mnt/d/codex/jnox203-raw
for mode in absent default; do
timeout 5 qemu-system-aarch64 -machine virt,gic-version=2 -cpu cortex-a72 -accel tcg -smp 1 -m 128M -nic none -nographic -monitor none -serial stdio -kernel "$mode.elf" > "$mode-first-boot.log" 2>&1
echo "$mode $?" >> boot-exit.txt
done