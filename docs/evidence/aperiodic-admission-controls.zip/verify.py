import subprocess as sp, os,sys,itertools,hashlib,pathlib,json,shutil
P=pathlib.Path(__file__).resolve().parent
win=os.name=="nt"
osid="win" if win else "linux"
K=pathlib.Path("D:/codex/jnox203-iv/kernel") if win else pathlib.Path.home()/"jnox203-fresh/kernel"
env=dict(os.environ,CARGO_BUILD_JOBS="1",JNOX_PROFILE="aperiodic",JNOX_APP="a-ps")
if not win:
 env["PATH"]=str(pathlib.Path.home()/"jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin")+":"+env["PATH"]
def run(cmd,**kw):
 return sp.run(cmd,cwd=K,env=env,stdout=sp.PIPE,stderr=sp.STDOUT,**kw)
cases=[a+"-"+b for a,b in itertools.product("ab",["ps","ds","ss1","ss2"])]
keys="irq_latency irq_interference irq_uncertainty irq_handler submission arbitration preparation_switch preparation_instrumentation preparation_interference preparation_uncertainty server_work periodic_work service_switch receipt service_instrumentation service_interference service_uncertainty".split()
base=dict(target="virt-a72-gicv2-tcg-1cpu-128m",case="a-ps",**{"class":"justified-bound"},hz="62500000",**dict.fromkeys(keys,0))
base.update(irq_latency=62500,submission=250000,periodic_work=2812500)
def fmt(d):return "".join(f"{k}={v}\n" for k,v in d.items())+"---\nSynthetic test fixture only. No reviewed bounds.\n"
report=P/"fiction.txt"
report.write_bytes(fmt(base).encode())
digest=hashlib.sha256(report.read_bytes()).hexdigest()
tool=["cargo","+1.95.0"] if win else ["cargo"]
exe=P/("check.exe" if win else "check-linux")
source=K/"src/aperiodic_admission.rs"
driver=P/("driver-"+osid+".rs")
driver.write_text('#[path="'+source.as_posix()+'"] mod subject; fn main(){let args:Vec<_>=std::env::args().collect(); let mut input=String::new(); std::io::Read::read_to_string(&mut std::io::stdin(), &mut input).unwrap(); println!("{:?}",subject::check(&input,&args[1],args[2].parse().unwrap()));}')
rc=run((["rustc","+1.95.0"] if win else ["rustc"])+["--edition=2024",str(driver),"-o",str(exe)])
assert rc.returncode==0,rc.stdout
tests=[]
def t(label,expected,d=base,case="a-ps",hz="62500000",raw=None):
 r=run([str(exe),case,hz],input=(fmt(d) if raw is None else raw).encode())
 actual=r.stdout.decode().strip()
 tests.append([label,expected,actual,actual==expected])
for a,b in itertools.product(cases,repeat=2):t(a+" vs "+b,"Ok(())" if a==b else "Err(Scope)",dict(base,case=a),b)
for k,v,why in [("irq_latency",62501,"Irq"),("submission",250001,"Preparation"),("periodic_work",2812501,"Service"),("server_work",2812501,"Service"),("target","wrong","Scope"),("hz","62500001","Frequency"),("class","observed-maximum","Class"),("class","synthetic-control","Class"),("receipt","-1","Format"),("receipt",2**64,"Format")]:t(k+str(v),"Err("+why+")",dict(base,**{k:v}))
for k in base:t("omit "+k,"Err(Format)",{x:y for x,y in base.items() if x!=k})
for k in ["irq_interference","submission","receipt"]:t("overflow "+k,"Err(Overflow)",dict(base,**{k:2**64-1}))
for k,s in [("surplus",fmt(base).replace("---","extra=0\n---")),("order",fmt(base).replace("receipt=0\nservice_instrumentation=0","service_instrumentation=0\nreceipt=0")),("rationale",fmt(base).split("---")[0]+"---\n  \n")]:t(k,"Err(Format)",raw=s)
t("missing","Err(Missing)",raw="")
(P/(osid+"-parser.json")).write_text(json.dumps(tests,indent=1))
assert all(x[-1] for x in tests)
build=[]
for label,mode,r,p,expect in [("absent","admission",None,None,0),("default",None,None,None,0),("paired","admission",report,digest,0),("mismatch","admission",report,"0"*64,1),("missing-pin","admission",report,None,1),("missing-report","admission",None,digest,1),("upper-pin","admission",report,digest.upper(),1),("late","admission",None,None,1)]:
 for key,val in [("JNOX_AP_MODE",mode),("JNOX_AP_REPORT",r),("JNOX_AP_REPORT_SHA256",p),("JNOX_APERIODIC_LATE","1" if label=="late" else None)]:
  if val is None:env.pop(key,None)
  else:env[key]=str(val)
 res=run(tool+["build","--release","--locked","-j1"])
 (P/(osid+"-build-"+label+".log")).write_bytes(res.stdout)
 build.append([label,res.returncode,expect,(res.returncode!=0)==bool(expect)])
 (P/(osid+"-build.json")).write_text(json.dumps(build,indent=1))
 if not win and label in ("absent","default") and not res.returncode:
  elf=K/"target/aarch64-unknown-none/release/jnox-kernel"
  shutil.copyfile(elf,P/(label+".elf"))
  q=run(["timeout","4","qemu-system-aarch64","-machine","virt,gic-version=2","-cpu","cortex-a72","-accel","tcg","-smp","1","-m","128M","-nographic","-monitor","none","-serial","stdio","-kernel",str(elf)])
  (P/(label+"-first-uart.log")).write_bytes(q.stdout)
print(osid,len(tests),build)
