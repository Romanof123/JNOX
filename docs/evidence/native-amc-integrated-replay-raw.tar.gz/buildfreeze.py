from pathlib import Path
import datetime, hashlib, json, os, re, shlex, shutil, subprocess, sys
from elftools.elf.elffile import ELFFile
root=Path(__file__).resolve().parent
src=root/'source';raw=root/'raw'; out=src/'output/native-amc';out.mkdir(parents=True)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
os.environ['PATH']='/home/ywcho/.cargo/bin:'+os.environ['PATH']
def command(label,argv):
    prefix=raw/label
    (raw/(label+'.command')).write_text(shlex.join([str(a) for a in argv])+'\n')
    p=subprocess.run(argv,cwd=src,capture_output=True)
    (raw/(label+'.stdout')).write_bytes(p.stdout);(raw/(label+'.stderr')).write_bytes(p.stderr)
    (raw/(label+'.exit')).write_text(str(p.returncode)+'\n')
    print(label,p.returncode,flush=True)
    if p.returncode: raise RuntimeError(p.stderr[-2000:])
    return p.stdout.decode().strip()
rev=command('rev',['git','rev-parse','HEAD'])
base='84ee959677312e1ab3bcb3a3c5ce093d64c8344f'
command('base',['git','merge-base','--is-ancestor',base,rev])
assert not command('tracked',['git','status','--porcelain','--untracked-files=no'])
for n,cmd in [('clang',['clang','--version']),('rustc',['rustc','-Vv']),('qemu',['qemu-system-aarch64','--version']),('python',[sys.executable,'-V']),('lld',['ld.lld','--version']),('cargo',['cargo','--version']),('fs',['findmnt','-T',str(src),'-no','SOURCE,FSTYPE'])]:
    command(n,cmd)
cases=['within-lo','normal-hi','over-hi','staggered','refusal','overlap']
for i in range(4):
    command(f'slot{i}',['sh','sdk/native-aarch64/build.sh',f'examples/native-amc/slot{i}.c',f'output/native-amc/slot{i}.elf'])
freeze={'source':rev,'integrated_main':base,'cases':{},'capture_order':[[c,x] for c in cases for x in ('plain','trace')],'fixed':{'frequency':62500000,'quantum':3125000,'capture_timeout_seconds':30,'hardware':'QEMU virt GICv2 cortex-a72, one CPU default TCG, 128 MiB','requirements_sha256':sha(src/'docs/native-amc-applications.en-ko.md'),'observer_sha256':sha(src/'tools/native_amc_report.py'),'capture_script_sha256':sha(root/'firsts.py'),'QEMU_sha256':sha(Path(shutil.which('qemu-system-aarch64')).resolve())}}
for name in cases:
    count=2 if name in ['within-lo','refusal','overlap'] else 4
    cfg=f'examples/native-amc/config/{name}.json'
    args=['python3','tools/build_native_el0.py','--policy','amc','--elf','output/native-amc/slot0.elf']
    for i in range(1,count): args+=['--peer-elf',f'output/native-amc/slot{i}.elf']
    command(name,args+['--out',f'output/native-amc/{name}','--amc-manifest',cfg])
    pk=out/name; m=json.loads((pk/'manifest.json').read_bytes()); orig=json.loads((src/cfg).read_bytes())
    assert m['commit']==rev and not m['tracked_changes'] and len(m['slots'])==count and m['amc']==orig
    assert sha(src/cfg)==m['amc_input']['sha256'] and sha(pk/'kernel.elf')==m['kernel_elf_sha256'] and sha(pk/'amc-v1.txt')==m['amc_canonical']['sha256']
    linked=command('readelf-'+name,['aarch64-linux-gnu-readelf','--wide','--symbols',str(pk/'kernel.elf')])
    lines=[line.split() for line in linked.splitlines() if 'native_el0_mmu' in line and '6SPACES' in line and 'OBJECT' in line]
    assert len(lines)==1,lines
    addr=int(lines[0][1],16); extent=int(lines[0][2],0); stride,rem=divmod(extent,count)
    assert not rem and stride%4096==0 and addr%4096==0
    slots=[]
    for i,t in enumerate(orig['tasks']):
        sl=m['slots'][i]; expected=(i+1)<<48 | (addr+stride*i)
        assert sl['slot']==i and sl['amc_task']==t and sl['argv']==['/bin/app',*t['argv'][0]]
        assert sha(pk/sl['elf'])==sl['elf_sha256']==sha(out/f'slot{i}.elf') and sl['expected_ttbr0_el1']==expected
        with (pk/sl['elf']).open('rb') as fh:
            elf=ELFFile(fh); sym=elf.get_section_by_name('.symtab').get_symbol_by_name('amc_product')
            assert len(sym)==1 and sym[0]['st_size']==936
            slots.append(dict(id=i,elf_sha256=sl['elf_sha256'],expected_ttbr0_el1=hex(expected),entry=hex(elf['e_entry']),product_va=hex(sym[0]['st_value']),task=t))
    freeze['cases'][name]=dict(deployment_sha256=sha(src/cfg),canonical_sha256=sha(pk/'amc-v1.txt'),manifest_sha256=sha(pk/'manifest.json'),kernel_sha256=sha(pk/'kernel.elf'),slots=slots,resets=orig['resets'])
freeze['sealed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(raw/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
(raw/'freeze.sha256').write_text(sha(raw/'freeze.json')+'\n')
print('FROZEN',sha(raw/'freeze.json'),flush=True)
