import hashlib,json,glob
from pathlib import Path
from elftools.elf.elffile import ELFFile
p=Path.cwd();orig=Path(glob.glob(str(Path.home()/'jnox348-f2b2cd7.*'))[0]);fr=json.load(open(p/'raw/freeze.json'));fo=json.load(open(orig/'raw/freeze.json'))
def loads(f):
 with f.open('rb') as h:
    elf=ELFFile(h);return [(s['p_vaddr'],s['p_paddr'],s['p_flags'],s['p_filesz'],s['p_memsz'],s['p_align'],hashlib.sha256(s.data()).hexdigest()) for s in elf.iter_segments() if s['p_type']=='PT_LOAD']
report={}
for n in fr['cases']:
 a=fo['cases'][n];b=fr['cases'][n]; old=orig/'source/output/native-amc'/n;new=p/'source/output/native-amc'/n
 aa=loads(old/'kernel.elf');bb=loads(new/'kernel.elf')
 same=aa==bb
 report[n]=dict(load_same=same,old=aa,new=bb,old_sha=a['kernel_sha256'],new_sha=b['kernel_sha256'],matching_slots=a['slots']==b['slots'],matching_config=a['canonical_sha256']==b['canonical_sha256'] and a['deployment_sha256']==b['deployment_sha256'],apps={s['elf']:loads(old/s['elf'])==loads(new/s['elf']) for s in json.load(open(new/'manifest.json'))['slots']})
 print(n,same,a['kernel_sha256']==b['kernel_sha256'],report[n]['matching_slots'],report[n]['apps'])
(p/'load-report.json').write_text(json.dumps(report,indent=2))
