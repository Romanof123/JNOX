from elftools.elf.elffile import ELFFile
from pathlib import Path
import glob
p=Path.cwd();o=Path(glob.glob(str(Path.home()/'jnox348-f2b2cd7.*'))[0])
for c in ['within-lo','normal-hi','over-hi','staggered','refusal','overlap']:
 def sect(root):
    with (root/'source/output/native-amc'/c/'kernel.elf').open('rb') as f:return {s.name:(s['sh_addr'],s['sh_size'],s.data()) for s in ELFFile(f).iter_sections() if s['sh_flags']&2 and s['sh_type']!='SHT_NOBITS'}
 a,b=sect(o),sect(p)
 print(c)
 for k in a:
    x,y=a[k],b[k];ix=[j for j,(u,v) in enumerate(zip(x[2],y[2])) if u!=v]
    if ix or x[:2]!=y[:2]:print(k,x[:2],y[:2],len(ix),[(i,x[2][max(0,i-8):i+10].hex(),y[2][max(0,i-8):i+10].hex()) for i in ix[:4]])
