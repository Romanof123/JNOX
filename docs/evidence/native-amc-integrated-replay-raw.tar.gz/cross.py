import json,hashlib,subprocess
from pathlib import Path
p=Path.cwd(); a=json.load(open('compat/old-ext.json')); b=json.load(open('compat/ext/manifest.json'));assert a['extension_program']==b['extension_program']
orig='f2b2cd724ff8e3d8e7e403c5cc6a6e819f5f4ff0';data=json.load(open('six-bytes.json')); source=p/'source'
before=subprocess.check_output(['git','show',orig+':kernel/src/native_el0.rs'],cwd=source,text=True).splitlines();after=(source/'kernel/src/native_el0.rs').read_text().splitlines()
rows=[]
for v in data['normal-hi']:
 x,y=v['old_line'],v['new_line'];u,w=before[x-1],after[y-1];assert u.strip()==w.strip(),(x,y,u,w);rows.append(dict(old=x,new=y,expression=w.strip(),column=v['column']))
for n,v in json.load(open('load-report.json')).items():
 f=p/'original/captures'/(n+'-plain')/'kernel.elf'
 assert hashlib.sha256(f.read_bytes()).hexdigest()==v['old_sha'] and v['matching_slots'] and v['matching_config'] and all(v['apps'].values())
print(json.dumps(rows,indent=2))
