from pathlib import Path
import tarfile,json,subprocess,hashlib,os
p=Path.cwd();src=p/'source';d=p/'compat';d.mkdir();cases={}
def extract(archive,members):
 with tarfile.open(src/'docs/evidence'/archive) as t:
    for member,name in members.items():(d/name).write_bytes(t.extractfile(member).read())
extract('native-extension-applications-first.tar.gz',{'./voltage.elf':'voltage.elf','./temperature.elf':'temperature.elf','./alarms.elf':'alarms.elf','./accepted/manifest.json':'old-ext.json'})
extract('native-batch-applications-first.tar.gz',{'./products/batch.elf':'batch.elf','./products/urgent.elf':'urgent.elf','./products/arrival-srtf/manifest.json':'old-batch.json'})
rule=['--extension-program','examples/native-extension/rules/accepted.txt'];cfg=['--amc-manifest','examples/native-amc/config/within-lo.json']
ext=['--policy','extension','--elf',str(d/'voltage.elf'),'--peer-elf',str(d/'temperature.elf'),'--peer-elf',str(d/'alarms.elf'),*rule]
batch=['--policy','srtf','--elf',str(d/'batch.elf'),'--arg=--blocks','--arg','32768','--batch-job','0,18750000','--peer-elf',str(d/'urgent.elf'),'--peer-batch-job','6250000,625000']
amc=['--policy','amc','--elf','output/native-amc/slot0.elf','--peer-elf','output/native-amc/slot1.elf',*cfg]
for label,argv,ok in [('ext',ext,True),('batch',batch,True),('ext-amc',ext+cfg,False),('ext-batch',ext+['--batch-job','0,1'],False),('batch-ext',batch+rule,False),('batch-amc',batch+cfg,False),('amc-ext',amc+rule,False),('amc-batch',amc+['--batch-job','0,1'],False)]:
 cmd=['python3','tools/build_native_el0.py','--out',str(d/label),*argv];r=subprocess.run(cmd,cwd=src,capture_output=True);assert (r.returncode==0)==ok,(label,r.stderr);cases[label]=dict(cmd=cmd,rc=r.returncode,error=r.stderr.decode().splitlines()[-1:] if not ok else [],created_kernel=(d/label/'kernel.elf').is_file())
 if ok:
    old=json.load(open(d/('old-'+label+'.json')));new=json.load(open(d/label/'manifest.json'))
    for a,b in zip(old['slots'],new['slots'],strict=True):
       for k in ['slot','argv','elf_sha256','batch_job']:assert a.get(k)==b.get(k),(label,k)
    for k in ['policy','extension','batch_jobs']:assert old.get(k)==new.get(k),(label,k)
    cases[label]['slots']=new['slots'];cases[label]['policy']=new.get('policy');cases[label]['kernel_command']=new['kernel_command'];cases[label]['keys']=list(new)
 print(label,r.returncode,flush=True)
(p/'compat.json').write_text(json.dumps(cases,indent=2))
