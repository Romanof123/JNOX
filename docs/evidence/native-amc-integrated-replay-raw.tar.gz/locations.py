from elftools.elf.elffile import ELFFile
from pathlib import Path
import struct,glob,json,hashlib
p=Path.cwd();o=Path(glob.glob(str(Path.home()/'jnox348-f2b2cd7.*'))[0]);res={}
for c in json.load(open('raw/freeze.json'))['cases']:
 def read(root):
    with (root/'source/output/native-amc'/c/'kernel.elf').open('rb') as f:
      e=ELFFile(f);s=e.get_section_by_name('.rodata');return s['sh_addr'],s.data(),[(v['p_vaddr'],v['p_filesz'],v['p_memsz'],v['p_flags'],v.data()) for v in e.iter_segments() if v['p_type']=='PT_LOAD']
 addr,x,xx=read(o); add2,y,yy=read(p);assert addr==add2
 ver=[];diff=[]
 for a,b in zip(xx,yy):
    assert a[:4]==b[:4];diff.extend(a[0]+i for i,(l,r) in enumerate(zip(a[4],b[4])) if l!=r)
 assert len(diff)==6
 for off in diff:
    i=off-addr;ptr,n,line,col=struct.unpack_from('<QQII',x,i-16); ptr2,n2,line2,col2=struct.unpack_from('<QQII',y,i-16);assert (ptr,n,col)==(ptr2,n2,col)
    path=x[ptr-addr:ptr-addr+n].decode();assert path in ['src/native_el0.rs','src/main.rs','src/native_el0_mmu.rs']
    ver.append(dict(address=hex(off),path=path,old_line=line,new_line=line2,column=col))
 res[c]=ver;print(c,ver)
Path('six-bytes.json').write_text(json.dumps(res,indent=2))
