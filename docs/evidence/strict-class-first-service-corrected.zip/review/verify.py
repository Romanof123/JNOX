from pathlib import Path
import subprocess as sp,struct,re,json,hashlib
b=Path.home()/'jnox263-independent'; out=b/'review';out.mkdir(exist_ok=True);src=b/'checkout';check=src/'tools/mlq_receipt_check.py'
x=[1+i%16 for i in range(4096)];q=4000000;bound=2*8000000+min(8000000,q)+q
for d in sorted((b/'first').iterdir()):
 c=d/'capture';data=(c/'audit.bin').read_bytes();w=struct.unpack('<30Q',data);ref='refuse' in d.name; args=['python3',str(check)];args+=['--refused'] if ref else []
 sp.run(args+[c/'audit.bin'],check=True)
 assert w[:6]==(2 if ref else 4,62500000,q,q,bound,bound-int(ref))
 t=(c/'int.trace').read_text();nm=sp.check_output(['aarch64-linux-gnu-nm','-nS',d/'kernel.elf'],text=True); dump=sp.check_output(['aarch64-linux-gnu-objdump','-d',d/'kernel.elf'],text=True);(out/(d.name+'.dis')).write_text(dump)
 pc=int(re.search(r'PC=(\w+)',(c/'registers.txt').read_text())[1],16)
 if ref:
  assert not any(w[6:]) and not t and (not (c/'trace.bin').exists() or not any((c/'trace.bin').read_bytes()))
  assert re.search(r'^\s*'+hex(pc-4)[2:]+r':.*wfe|^\s*'+hex(pc-4)[2:]+r':.*wfi',dump,re.M)
 else:
  epoch,s,f=w[6:9];charges=w[9:13];g=s-epoch-sum(charges);o=charges[2]-q;lat=f-s;blocks=w[24]
  assert 0<epoch<s<f and all(0<a<=8000000 for a in charges[:3]) and charges[3]==0 and min(g,o,lat)>=0
  assert w[13:18]==(g,o,lat,g+o+lat,f-epoch) and w[16]<=q and w[17]<=bound
  assert w[18:]==(sum(x),sum(v*v for v in x),sum(v%2 for v in x)*blocks,max(x),15,1,blocks,1,1,0,max(x),blocks) and 1<=blocks<=2000000
  assert re.findall(r'Taking exception \d+ \[(\w+)\]',t)==['SVC','SVC','IRQ','SVC','SVC'];irq=int(re.search(r'\[IRQ\].*?with ELR (0x\w+)',t,re.S)[1],16)
  resume=int(re.findall(r'Exception return .*? PC (0x\w+)',t)[-1],16);assert resume==irq
  wsyms=[(int(a,16),int(z,16)) for a,z in re.findall(r'^(\w+) (\w+) t .*?mlq_admission6worker.*$',nm,re.M)];assert len(wsyms)==4 and any(a<=irq<a+z for a,z in wsyms)
  a,z=next((a,z) for a,z in wsyms if a<=irq<a+z);body=sp.check_output(['aarch64-linux-gnu-objdump','-d',f'--start-address={a}',f'--stop-address={a+z}',d/'kernel.elf'],text=True);assert body.index('ldar')<body.index('ldrb')<body.index('#0x10\n') and 'lsl #12' in body
  assert int(re.search(r'^(\w+) \w+ T fixed_runtime_idle',nm,re.M)[1],16)<=pc<int(re.search(r'^(\w+) \w+ T fixed_runtime_idle',nm,re.M)[1],16)+8
  if (c/'trace.bin').exists():
   raw=(c/'trace.bin').read_bytes(); assert struct.unpack_from('<QQ',raw)==(6,w[1]);r=[struct.unpack_from('<131Q',raw,16+i*1048) for i in range(6)]
   assert [(v[3],v[0],v[10]) for v in r]==[(4,0,0),(0,1,1),(1,1,2),(2,4,3),(3,1,2),(2,1,4)]
   tally=[0]*4;st=int(re.search(r'^(\w+) \w+ b .*multilevel_service6STACKS',nm,re.M)[1],16)
   for v in r[1:]:
    owner=v[3];fp=v[8];assert st+owner*16384<=fp<=st+(owner+1)*16384-832 and fp%16==0 and v[59]&0x8f==5
    assert v[5]==v[4]+q and v[6]>v[4];tally[owner]+=v[6]-v[4];assert tuple(tally)==v[23:27]
    assert v[9]==(5<<32|30 if v[0]==4 else 0x56000001)
   assert tuple(charges)==r[3][23:27] and s==r[4][4] and r[3][6]>=r[3][5] and r[3][58]==r[4][14]==irq and r[3][8]==r[4][13] and max(tally[:3])<=8000000
   assert len(set(v[1] for v in r[1:]))==4
   assert r[3][1]==a and re.search(r'mrs\s+x\d+, cntpct_el0',dump[dump.index(hex(r[4][1])[2:]+ ' <'):],re.I)
 for i in ([0,1,2,3,4,5]+list(range(6,30)) if ref else [0,1,2,3,4,5,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29]):
  mutant=list(w);mutant[i]=1 if mutant[i]==0 else 0; p=out/'mutation.bin';p.write_bytes(struct.pack('<30Q',*mutant));assert sp.run(args+[p],capture_output=True).returncode!=0,(d,i)
 (out/(d.name+'.json')).write_text(json.dumps(list(w)))
print('PASS originals, mutation controls, QEMU exception streams, worker mappings and trace accounting')
