from pathlib import Path
import json,struct,re,subprocess as sp,zipfile
b=Path.home()/'jnox263-independent';rows=json.loads((b/'legacy/comparison.json').read_text());z=zipfile.ZipFile('/mnt/d/codex/jnox259260-baseline.zip');result={}
for r in rows:
 if r['loads_equal']:continue
 d=b/'legacy'/r['selector'];old=z.read(next(n for n in z.namelist() if n.endswith('/'+d.name+'/kernel.elf') or n==d.name+'/kernel.elf'));new=(d/'kernel.elf').read_bytes()
 s=sp.check_output(['readelf','-WS',d/'kernel.elf'],text=True);a,o,l=[int(x,16) for x in re.search(r'\.rodata\s+PROGBITS\s+(\w+)\s+(\w+)\s+(\w+)',s).groups()]
 changed=[]; diff={i for i in range(o,o+l) if old[i]!=new[i]}
 for i in sorted(diff):
  ptr,length=struct.unpack_from('<QQ',new,i-16);assert length==25 and new[o+ptr-a:o+ptr-a+length]==b'src/multilevel_service.rs'
  col=struct.unpack_from('<I',new,i+4)[0];changed.append((struct.unpack_from('<I',old,i)[0],struct.unpack_from('<I',new,i)[0],col))
 result[d.name]=changed
(b/'review/location-diffs.json').write_text(json.dumps(result,indent=2));print(result)
