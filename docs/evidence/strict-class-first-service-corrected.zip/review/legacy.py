from pathlib import Path
import json,zipfile,hashlib,subprocess as sp,os,re
b=Path.home()/'jnox263-independent'; src=b/'checkout'; out=b/'legacy';out.mkdir()
zpath=Path('/mnt/d/codex/jnox259260-baseline.zip')
assert hashlib.sha256(zpath.read_bytes()).hexdigest()=='e6b226c7e8f8d430bbe0167b437acbb7626d771eb090f28e2f7f71971861f20e'
z=zipfile.ZipFile(zpath); name=next(n for n in z.namelist() if n.endswith('matrix.json')); old=json.loads(z.read(name)); records=[]
for r in old:
 app,mode,p=r['app'],r['mode'],r['profile']; d=out/(app+'-'+mode);d.mkdir()
 env=dict(os.environ,PATH=str(Path.home()/'jnox-169-first-e203caa/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')+':/usr/bin:/bin',CARGO_TARGET_DIR=str(b/'legacy-target'),JNOX_PROFILE=p,JNOX_APP=app)
 if mode=='trace':env['JNOX_'+p.upper()+'_TRACE']='1'
 f=b/'legacy-target/aarch64-unknown-none/release/jnox-kernel'
 with (d/'build.log').open('wb') as log:sp.run(['cargo','build','--release','--locked','--target','aarch64-unknown-none','-j1'],env=env,cwd=src/'kernel',stdout=log,stderr=sp.STDOUT,check=True)
 data=f.read_bytes();(d/'kernel.elf').write_bytes(data);cur=sp.check_output(['readelf','-Wl',f],text=True)
 seg=[]
 for m in re.finditer(r'^  LOAD\s+(0x\w+)\s+(0x\w+)\s+(0x\w+)\s+(0x\w+)\s+(0x\w+)',cur,re.M):
  off,va,pa,fs,ms=map(lambda x:int(x,16),m.groups());seg.append(dict(offset=off,va=va,pa=pa,filesz=fs,memsz=ms,sha256=hashlib.sha256(data[off:off+fs]).hexdigest()))
 prior=z.read(name.removesuffix('matrix.json')+d.name+'/kernel.elf'); sections={}
 for blob,file in [(prior,'old'),(data,'new')]:
  temp=b/'elf-tmp';temp.write_bytes(blob); s=sp.check_output(['readelf','-WS',temp],text=True); sections[file]={}
  for n,typ,addr,off,size in re.findall(r'\[\s*\d+\]\s+(\.\S+)\s+(\S+)\s+(\w+)\s+(\w+)\s+(\w+)',s):
   a,o,l=[int(x,16) for x in [addr,off,size]];sections[file][n]=(a,l,None if typ=='NOBITS' else hashlib.sha256(blob[o:o+l]).hexdigest())
 diffs=[k for k in sections['new'] if sections['new'][k]!=sections['old'].get(k)]
 boot=None
 if p=='multilevel':
  with (d/'boot.log').open('wb') as log:boot=sp.run(['python3','tools/qemu_boot.py','--runs','1','--timeout','10','--profile',app,'--kernel',str(f)],cwd=src,stdout=log,stderr=sp.STDOUT).returncode
 records.append(dict(selector=d.name,segments=seg,loads_equal=seg==r['segments'],elf_equal=data==prior,different_sections=diffs,boot_rc=boot));(out/'comparison.json').write_text(json.dumps(records,indent=2))
