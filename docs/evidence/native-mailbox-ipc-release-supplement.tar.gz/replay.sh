#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:$PATH"
export PYTHONDONTWRITEBYTECODE=1
root=$(cd "$(dirname "$0")"; pwd)
out=${1:?provide a new output directory}
src=${2:?provide clean candidate checkout}
cd "$src"
test "$(git rev-parse HEAD^{tree})" = b50b4ce3969715a3229924011f976ef5fee794eb
test -z "$(git status --porcelain -uno)"
mkdir -p "$out"
sh sdk/native-aarch64/build.sh "$root/finite_sender.c" "$out/sender.elf"
sh sdk/native-aarch64/build.sh "$root/finite_receiver.c" "$out/receiver.elf"
for policy in fifo rr; do
    quantum=()
    if [[ "$policy" == rr ]]; then quantum=(--quantum-ticks 625000); fi
    pkg="$out/finite-$policy"
    python3 tools/build_native_el0.py --out "$pkg" --policy "$policy" "${quantum[@]}" --priority 7 --peer-priority 1 --elf "$out/sender.elf" --peer-elf "$out/receiver.elf" --mailbox-route 0:1
    python3 tools/native_el0_capture.py "$out/cap-$policy" "$pkg/kernel.elf" "$pkg/user.elf" "$root/finite_sender.c" "$(git rev-parse HEAD)" --plain --expect-exit 76
    cat "$out/cap-$policy/uart.bin" | tail -3
done
