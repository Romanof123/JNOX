#include <errno.h>
#include <jnox/mailbox.h>
#include <time.h>

volatile uint64_t send_times[3];
volatile long send_results[5];

static uint64_t now_ns(void) {
    struct timespec value;
    if (clock_gettime(CLOCK_MONOTONIC, &value) != 0) return 0;
    return (uint64_t)value.tv_sec * 1000000000ULL + value.tv_nsec;
}

int main(void) {
    for (unsigned i = 0; i < 4; ++i) {
        send_results[i] = jnox_mailbox_send(1, 100 + i, 0);
        if (send_results[i] != 0) return 81;
    }
    send_times[0] = now_ns();
    if (!send_times[0]) return 82;
    send_times[1] = send_times[0] + 2000000000ULL;
    send_results[4] = jnox_mailbox_send(1, 104, send_times[1]);
    send_times[2] = now_ns();
    if (send_results[4] != 0 || send_times[2] <= send_times[0]) return 83;
    return send_times[2] < send_times[1] ? 76 : 84;
}
