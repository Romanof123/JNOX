#include <errno.h>
#include <jnox/mailbox.h>
#include <time.h>

volatile uint64_t received[5];
volatile uint64_t receive_times[3];
volatile long receive_results[2];

static uint64_t now_ns(void) {
    struct timespec value;
    if (clock_gettime(CLOCK_MONOTONIC, &value) != 0) return 0;
    return (uint64_t)value.tv_sec * 1000000000ULL + value.tv_nsec;
}

int main(void) {
    uint64_t now = now_ns();
    if (!now) return 85;
    uint64_t due = now + 60000000ULL;
    struct timespec wake = {.tv_sec = due / 1000000000ULL, .tv_nsec = due % 1000000000ULL};
    if (clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &wake, 0) != 0) return 86;
    for (unsigned i = 0; i < 5; ++i) {
        jnox_mailbox_result result = jnox_mailbox_receive(0);
        received[i] = result.word;
        if (result.status || result.word != 100 + i) return 87;
    }
    receive_times[0] = now_ns();
    receive_times[1] = receive_times[0] + 20000000ULL;
    receive_results[0] = jnox_mailbox_receive(receive_times[1]).status;
    receive_times[2] = now_ns();
    if (receive_results[0] != -ETIMEDOUT || receive_times[2] < receive_times[1]) return 88;
    receive_results[1] = jnox_mailbox_receive(0).status;
    return receive_results[1] == -EAGAIN ? 77 : 89;
}
