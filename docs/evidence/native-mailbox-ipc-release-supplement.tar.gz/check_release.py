#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def symbols(path):
    table = subprocess.check_output(["aarch64-linux-gnu-nm", "-S", str(path)], text=True)
    return {r[3]: (int(r[0], 16), int(r[1], 16))
            for line in table.splitlines() if len(r := line.split()) == 4}


def read_variable(data, ram_base, root, info, signed=False):
    def offset(pa, width):
        pos = pa - ram_base
        assert 0 <= pos and pos + width <= len(data)
        return pos

    result = []
    address, size = info
    for va in range(address, address + size, 8):
        table = root
        for shift in (30, 21, 12):
            desc, = struct.unpack_from("<Q", data, offset(table + 8 * ((va >> shift) & 511), 8))
            assert desc & 3 == 3
            table = desc & 0x0000fffffffff000
        result.append(struct.unpack_from("<q" if signed else "<Q", data, offset(table + (va & 4095), 8))[0])
    return result


def review(root, policy):
    pkg, cap = root / ("finite-" + policy), root / ("cap-" + policy)
    launch = json.loads((cap / "launch.json").read_text())
    manifest = json.loads((pkg / "manifest.json").read_text())
    session = json.loads((cap / "session.json").read_text())
    assert manifest == launch["argument_package"] and manifest["commit"] == "1f9a56354e5b8fa04251fc5101e28ec0d83dad85"
    assert manifest["tracked_changes"] == "" and manifest["policy"] == policy and manifest["board"] == "virt"
    args = launch["argv"]
    assert args[args.index("-smp") + 1] == "1" and args[args.index("-cpu") + 1] == "cortex-a72"
    assert manifest["mailbox_routes"] == [{"caller": 0, "owner": 1}] and not manifest.get("ipc_routes")
    for file, sha in session["hashes"].items():
        assert digest(cap / file) == sha, file
    assert digest(pkg / "kernel.elf") == launch["kernel_sha256"] == session["hashes"]["kernel.elf"]
    uart = (cap / "uart.bin").read_text()
    assert re.findall(r"^NATIVE EL0 EXIT PID (\d+) (\d+)$", uart, re.M) == [("0", "76"), ("1", "77")]
    assert re.findall(r"^NATIVE MAILBOX STATE (\d+) (\d+) (\d+)$", uart, re.M) == [("0","0","0"), ("1","0","4")]
    assert "NATIVE FIXED DROPPED 0\n" in uart and "FAULT" not in uart
    data = (cap / "ram.bin").read_bytes()
    [(roots, total_size)] = [info for name, info in symbols(pkg / "kernel.elf").items() if "native_el0_mmu6SPACES" in name]
    values = {}
    for pid, keys in enumerate([["send_times", "send_results"], ["received", "receive_times", "receive_results"]]):
        slot = manifest["slots"][pid]
        elf = pkg / slot["elf"]
        assert digest(elf) == slot["elf_sha256"] and slot["elf_sha256"] in uart
        syms = symbols(elf)
        for key in keys:
            values[key] = read_variable(data, launch["ram_base"], roots + pid * (total_size // 2), syms[key], key.endswith("results"))
    assert values["send_results"] == [0]*5 and values["received"] == [100,101,102,103,104]
    assert values["receive_results"] == [-110,-11]
    s, deadline, resume = values["send_times"]
    assert deadline == s + 2000000000 and s < resume < deadline
    r, end, timeout = values["receive_times"]
    assert end == r + 20000000 and r < end <= timeout
    events = [list(map(int, fields.split())) for fields in re.findall(r"^NATIVE FIXED EVENT (.+)$", uart, re.M)]
    assert all(len(ev) == 21 for ev in events)
    sends, recvs = [[ev for ev in events if ev[1] == op] for op in (24,25)]
    idle = (1 << 64) - 1
    assert len(sends) == 5 and len(recvs) == 7
    assert all(ev[3:5] == [0,0] for ev in sends[:4]) and sends[4][3:5] == [0,1]
    assert recvs[0][3:5] == [1,0] and sends[4][0] < recvs[0][0] < sends[4][11]
    assert any(ev[1] == 3 and ev[3:5] == [0,1] and recvs[0][0] < ev[0] < recvs[1][0] for ev in events)
    assert recvs[5][3:5] == [1,idle] and recvs[5][0] < recvs[5][11]
    assert any(ev[1] == 4 and ev[3:5] == [idle,1] and recvs[5][11] <= ev[0] < recvs[6][0] for ev in events)
    return {"policy":policy,"kernel":launch["kernel_sha256"],"ram":session["hashes"]["ram.bin"],
            "uart":session["hashes"]["uart.bin"],"events":len(events),**values}


if __name__ == "__main__":
    print(json.dumps([review(Path(sys.argv[1]), p) for p in ["fifo", "rr"]], indent=2))
