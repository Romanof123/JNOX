import pathlib,zipfile,io,re,subprocess,json
P=pathlib.Path('jnox227-release-proof')
for line in (P/'final.txt').read_text(encoding='utf-8-sig').splitlines():
 if ' docs/evidence/' in line: ref,doc,_=line.split()
 if not line.startswith('ZIP '):continue
 name=line.split()[1]
 z=zipfile.ZipFile(io.BytesIO(subprocess.check_output(['git','-C','jnox227-release','show',ref+':docs/evidence/'+name])))
 def glance(z,depth):
  names=z.namelist()
  for n in names:
   if n.endswith('.zip') and depth<2:
    print('nested',n);glance(zipfile.ZipFile(io.BytesIO(z.read(n))),depth+1)
   if '/' not in n.strip('/') and re.search('csv|summary|crosscheck.log|outcomes|verify.log|report|analysis|independent.log|\.tsv',n,re.I):
    print(name,n,z.read(n)[:170].decode(errors='replace'))
    if not n.endswith('.py'):
     out=P/'source_tables'/name;out.mkdir(exist_ok=True,parents=True);(out/(str(depth)+'-'+n)).write_bytes(z.read(n))
 glance(z,0)

