import pathlib,subprocess,sys,hashlib,zipfile,io,re,json,difflib,collections
P=pathlib.Path(__file__).resolve().parent
R=P.parent/'jnox227-release'
def run(*a):return subprocess.check_output(a,cwd=R,stderr=subprocess.STDOUT)
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return run('git',*a)
def blob(ref,path):
 try:return git('show',ref+':'+path)
 except subprocess.CalledProcessError:
  git('fetch','origin',ref)
  return git('show',ref+':'+path)
base='a658576e7697051b0bf2ecb1d9d81e4c3eeb78c5'
head=sys.argv[1];tree=git('merge-tree','--write-tree',base,head).decode().strip()
print('base/head/tree',base,head,tree)
changed=set(); links=set()
for f in ['README.md','README.ko.md','docs/scheduling-release-cases.en.md','docs/scheduling-release-cases.md']:
 old=blob(base,f).decode();new=blob(tree,f).decode()
 for url in set(re.findall(r'\]\(([^)]+)\)',new))-set(re.findall(r'\]\(([^)]+)\)',old)):
  if url.startswith('https://github.com/Romanof123/JNOX/blob/'):
   ref,path=url.split('/blob/')[1].split('/',1)
  elif '://' not in url:ref,path=tree,str((pathlib.PurePosixPath(f).parent/url))
  else:continue
  links.add((ref,path))
 if not f.startswith('docs'):continue
 def rows(s):return {i.split('|')[1].strip():i for i in s.splitlines() if i.startswith('| POL-')}
 a,b=rows(old),rows(new); assert len(a)==len(b)==18 and set(a)==set(b)
 keys=[k for k in a if a[k]!=b[k]];assert keys==['POL-004','POL-006','POL-011','POL-013','POL-018'];assert all(a[k].split('|')[-2:]==b[k].split('|')[-2:] for k in a); print(f, keys,'18 retained gates')
for ref,path in sorted(links):
 data=blob(ref,path);print(ref,path,sha(data)); doc=data.decode()
 if not path.endswith('.md'):continue
 for zpath in dict.fromkeys(re.findall(r'\]\(([^):]+\.zip)\)',doc)):
  archive=blob(ref,str(pathlib.PurePosixPath(path).parent/zpath));z=zipfile.ZipFile(io.BytesIO(archive));assert z.testzip() is None
  print('ZIP',zpath,sha(archive),len(z.namelist()))
  prefix=pathlib.Path(path).stem
  listing=[(n,sha(z.read(n))) for n in z.namelist() if not n.endswith('/')]
  (P/(prefix+'.manifest.json')).write_text(json.dumps(listing,indent=1))
  for n in z.namelist():
   if re.search('summary|outcome|verdict|matrix|score|result|replay|aggregate|comparison',n,re.I) and n.endswith(('.tsv','.json','.txt','.csv','.log')) and z.getinfo(n).file_size<700000:
    dest=P/'extracts'/prefix/pathlib.Path(n);dest.parent.mkdir(exist_ok=True,parents=True);dest.write_bytes(z.read(n))
