from pathlib import Path
import csv,json,collections,ast,io,subprocess,zipfile
P=Path(__file__).resolve().parent
def archive(ref,name):
 b=subprocess.check_output(['git','-C',str(P.parent/'jnox227-release'),'show',ref+':docs/evidence/'+name+'.zip'])
 return zipfile.ZipFile(io.BytesIO(b))
def sub(z,n):return zipfile.ZipFile(io.BytesIO(z.read(n)))
def check(label,test,values):assert test,label;print(label,values)
for title,expected in [('native-partition-packager-corrected-first',[(3,5),(1,1)]),('native-partition-irq-phases-first',[(3,5),(1,4)])]:
 t=list(csv.DictReader(next((P/'source_tables'/(title+'.zip')).glob('*transitions.tsv')).open(),delimiter='\t'))
 values={}
 for table in 'pq':
  for clk in ('default','icount3'):
   rr=[r for r in t if r['table']==table and r['clock']==clk]
   values[table,clk]=tuple(len({r['round'] for r in rr if int(r['margin_'+mode])<0}) for mode in ['plain','phase'])
   assert all(r['newgen']=='2' for r in rr if min(int(r['margin_'+mode]) for mode in ['plain','phase'])<0)
 check(title,len(t)==210 and [values[k,'default'] for k in 'pq']==expected and all(values[k,'icount3']==(0,0) for k in 'pq'),values)
t=list(csv.DictReader(next(P.glob('source_tables/*frame-pairs*/0-boots.csv')).open()))
v=collections.Counter((x['revision'],x['table'],x['clock']) for x in t if int(x['maximum'])>62500);check('40 frame boots',len(t)==40 and sorted(v.values())==[4,4,5,5] and all(k[-1]=='default' for k in v),v)
old=next(P.glob('source_tables/*ordinary-first*/0-crosscheck.log')).read_text().splitlines()[:4]
v=[max(row[-1] for row in ast.literal_eval(l[l.index('['):])) for l in old];check('earliest P/Q',v[0]==73392 and all(a<=62500 for a in v[1:]),v)
z=archive('663b598e','native-marker-share-first');w=sub(z,'original.zip');d=json.loads(w.read('observed.json'))['marker_observation'];v=[i for i in d['intervals'] if i['cause']=='irq' and i['outside_cpu_ns'][0]>0];check('weighted marker joined bounds',len(d['intervals'])==38 and len(v)==12,(len(d['intervals']),len(v),len(w.read('observed/markers.bin'))))
for p in P.glob('extracts/pi4-crc*'):
 files=list(p.glob('stream-*/replay-?.json'));assert len(files)==6
 for f in files:
  d=json.loads(f.read_bytes());assert d['destination_cpu']==int('global' in f.parent.name) and d['qualifying_inner_pc'] and any(a['task']==0 and a['index']==4194304 and a['value']==0x78d22ad1 for a in d['activation_summaries'])
 print(p.name,len(files),'global 2->CPU1 other 4->CPU0, CRC 0x78d22ad1')
z=archive('51356443','pi4-crc-stream-first-builds')
for n in z.namelist():
 if n.endswith('/build.rc'):print(n,z.read(n).strip())
assert all(z.read(f'first/stream-{t}/build.rc').strip()==b'101' and z.read(f'first/original-{t}/freeze.rc').strip()==b'0' for t in ('global','clustered','partitioned'))
assert not any('first-1/attempt' in n for n in z.namelist())
s=json.loads(next(P.glob('source_tables/control-guard*/0-summary.json')).read_bytes());assert len(s)==16;print('healthy',[(r['id'],r['failures']) for r in s if 'a0' in r['id']])
d=json.loads(next(P.glob('extracts/native-thread*/**/result.json')).read_bytes());assert len(d['intervals'])==35
print('host intervals',len(d['intervals']))
import struct
z=archive('a658576e','ordinary-extension-jobs-first');w=sub(z,'jnox223-first-raw.zip')
for mode in ['normal','legacy']:
 for cap in ['plain','captured']:assert w.read(mode+'.'+cap+'.rc').strip()==b'0'
print(w.read('normal.replay')[-800:])
z=archive('663b598e','native-marker-share-first')
import tempfile
with tempfile.TemporaryDirectory() as td:
 for k in ['independent.py','original.zip']:(Path(td)/k).write_bytes(z.read(k))
 print(subprocess.check_output(['python',str(Path(td)/'independent.py')]).decode())
from elftools.elf.elffile import ELFFile
z=archive('447e777d','pi4-crc-mainline-first')
for t in ['global','partitioned','clustered']:
 pair=[ELFFile(io.BytesIO(z.read(f'{a}-{t}/frozen/kernel.elf'))) for a in ['base','legacy']]
 assert pair[0].get_section_by_name('.text').data()==pair[1].get_section_by_name('.text').data()
 a,b=[b''.join(s.data() for s in e.iter_segments() if s['p_type']=='PT_LOAD') for e in pair]
 assert len(a)==len(b) and sum(u!=v for u,v in zip(a,b))==3
 print(t,'identical .text, 3 differing PT_LOAD bytes')
z=archive('a658576e','ordinary-extension-jobs-first');w=sub(z,'jnox223-first-raw.zip');rows=list(struct.iter_unpack('<5Q',w.read('normal.capture/trace.bin')))
print('extension captured records',rows)
assert len(rows)==9 and sum(r[1]==0 for r in rows)==3 and [r[3] for r in rows if r[1]==0][-1]==9900 and any(r[3]==62 for r in rows)
