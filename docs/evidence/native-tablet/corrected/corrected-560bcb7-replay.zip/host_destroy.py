"""Exercise graceful mapped-surface destruction on a live host compositor."""
import argparse
import array
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
import tempfile
import time
from reader import need,digest


def words(*args):
    return struct.pack("<"+"I"*len(args),*args)


def string(text):
    blob=text.encode()+b"\0"
    return words(len(blob))+blob+b"\0"*(-len(blob)%4)


class Peer:
    def __init__(self,path,role,journal):
        self.sock=socket.socket(socket.AF_UNIX)
        self.sock.settimeout(3)
        self.sock.connect(str(path))
        self.role=role
        self.journal=journal

    def send(self,obj,op,body=b"",fd=None):
        msg=words(obj,(8+len(body))<<16|op)+body
        self.journal.append([self.role,"send",msg.hex()])
        ancillary=[] if fd is None else [(socket.SOL_SOCKET,socket.SCM_RIGHTS,array.array("i",[fd]))]
        n=self.sock.sendmsg([msg],ancillary)
        self.sock.sendall(msg[n:])

    def until(self,obj,op):
        while True:
            h=self.sock.recv(8,socket.MSG_WAITALL)
            need(len(h)==8,"host peer closed before event")
            source,header=struct.unpack("<II",h)
            size,code=divmod(header,65536)
            need(size>=8 and size%4==0,"interrupt in Wayland message")
            b=self.sock.recv(size-8,socket.MSG_WAITALL) if size>8 else b""
            need(len(b)==size-8,"truncated host packet")
            self.journal.append([self.role,"recv",(h+b).hex()])
            need((source,code)!=(1,0),"wl_display.error "+b.hex())
            if (source,code)==(obj,op):
                return struct.unpack("<"+"I"*(len(b)//4),b)

    def map(self):
        self.send(1,1,words(2))
        for name,iface,idx in [(1,"wl_compositor",3),(2,"wl_shm",4),(3,"xdg_wm_base",5),(4,"wl_seat",6)]:
            self.send(2,0,words(name)+string(iface)+words(1,idx))
        need(self.until(6,0)==(3,),"host seat")
        self.send(6,0,words(7))
        self.send(3,0,words(8))
        self.send(5,2,words(9,8))
        self.send(9,1,words(10))
        self.send(10,3,string("org.jnox."+self.role))
        self.send(8,6)
        serial,=self.until(9,0)
        self.send(9,4,words(serial))
        with tempfile.TemporaryFile() as f:
            f.truncate(128*96*4)
            self.send(4,0,words(11,128*96*4),f.fileno())
        self.send(11,0,words(12,0,128,96,512,1))
        self.send(8,1,words(12,0,0))
        self.send(8,6)
        self.until(12,0)


def exercise(host,log):
    with tempfile.TemporaryDirectory() as tmp:
        display=Path(tmp)/"display"
        device=Path(tmp)/"tablet"
        env=dict(os.environ,JNOX_WAYLAND_TEST_POINTER=str(device))
        with subprocess.Popen([host,display],stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,env=env) as proc:
            sockets=[]
            try:
                for _ in range(300):
                    if display.exists():
                        break
                    time.sleep(.01)
                for role in ("Pulse","Tiles"):
                    peer=Peer(display,role,log)
                    sockets.append(peer)
                    peer.map()
                a,b=sockets
                with socket.socket(socket.AF_UNIX,socket.SOCK_DGRAM) as tablet:
                    def packet(*rows):
                        for typ,code,value in (*rows,(0,0,0)):
                            data=struct.pack("<Q",typ<<48|code<<32|value)
                            log.append(["tablet","send",data.hex()])
                            tablet.sendto(data,str(device))
                    packet((3,0,120),(3,1,88))
                    first=a.until(7,0)
                    need(first[1:]==(8,104*256,64*256),"Pulse front before explicit destruction")
                    # xdg roles must be destroyed in order. Keep A's connection and wl_pointer alive.
                    for obj in (10,9,8):
                        a.send(obj,0)
                    a.send(1,0,words(15))
                    a.until(15,0)
                    enters=b.until(7,0)
                    need(enters[1:]==(8,8*256,8*256),"Tiles refocused at stationary cursor")
                    packet((3,0,125),(3,1,92))
                    motion=b.until(7,2)
                    need(motion[1:]==(13*256,12*256),"Tiles motion after old focused surface destruction")
                    a.send(1,0,words(16))
                    a.until(16,0)
                    seen=[bytes.fromhex(x[2]) for x in log if x[:2]==["Pulse","recv"]]
                    need(any(x==words(1,12<<16|1,8) for x in seen),"wl_surface object not deleted")
                    return {"first_enter":first,"survivor_enter":enters,"survivor_motion":motion}
            finally:
                for p in sockets:
                    p.sock.close()
                proc.terminate()


if __name__=="__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("host",type=Path)
    cli.add_argument("report",type=Path)
    cfg=cli.parse_args()
    journal=[]
    out={"host_sha256":digest(cfg.host.read_bytes()),"journal":journal}
    try:
        out["observed"]=exercise(cfg.host.resolve(),journal)
        out["outcome"]="PASS"
    except Exception as e:
        out.update(outcome="FAIL",reason=repr(e))
    cfg.report.write_text(json.dumps(out,indent=2)+"\n")
    print(out["outcome"],out.get("observed",out.get("reason")))
    raise SystemExit(out["outcome"]!="PASS")
