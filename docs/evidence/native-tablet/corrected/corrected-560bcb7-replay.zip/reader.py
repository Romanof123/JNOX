"""Offline reader for JNOX #451. Input paths refer only to recorded artifacts."""
import argparse
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import re
import struct
import zlib


def need(value, message):
    if not value:
        raise ValueError(message)


def u16(data, offset):
    return struct.unpack_from("<H", data, offset)[0]


def u32(data, offset):
    return struct.unpack_from("<I", data, offset)[0]


def words(data):
    return [v for v, in struct.iter_unpack("<Q", data)]


def digest(data):
    return hashlib.sha256(data).hexdigest()


class Elf:
    def __init__(self, path):
        self.image = path.read_bytes()
        d = self.image
        need(d[:6] == b"\x7fELF\x02\x01" and u16(d, 18) == 183, f"{path}: AArch64 ELF")
        self.entry, ph = struct.unpack_from("<QQ",d,24)
        ph_step, ph_count = struct.unpack_from("<HH",d,54)
        code=[]
        for i in range(ph_count):
            typ, flags, off, va, _, filesz, _, _ = struct.unpack_from("<II6Q",d,ph+i*ph_step)
            if typ==1 and flags&1 and va<=self.entry<=va+filesz-32:
                start=off+self.entry-va
                code.append(d[start:start+32])
        self.entry_code,=code
        sec_off, = struct.unpack_from("<Q", d, 40)
        sec_size, sec_count = struct.unpack_from("<HH", d, 58)
        secs = [struct.unpack_from("<IIQQQQIIQQ", d, sec_off + i * sec_size)
                for i in range(sec_count)]
        self.symbols = {}
        for _, typ, _, _, off, size, link, _, _, step in secs:
            if typ != 2:
                continue
            names = secs[link][4]
            for i in range(off, off + size, step):
                name, _, _, ndx, addr, length = struct.unpack_from("<IBBHQQ", d, i)
                if name and ndx:
                    start = names + name
                    key = d[start:d.index(b"\0", start)].decode()
                    self.symbols[key] = addr, length

    def get(self, key):
        return self.symbols[key]


class Pages:
    def __init__(self, path):
        raw = zlib.decompress(path.read_bytes())
        need(len(raw) % 4104 == 0, "incomplete sparse physical page")
        self.data = {}
        for i in range(0, len(raw), 4104):
            pa, = struct.unpack_from("<Q", raw, i)
            need(pa % 4096 == 0 and pa not in self.data, "bad archived physical address")
            self.data[pa] = raw[i+8:i+4104]

    def translate(self, root, va):
        mask = 0x0000fffffffff000
        table = root
        need(0 <= va < 1 << 39, "unsupported VA")
        for shift in (30, 21, 12):
            desc, = struct.unpack_from("<Q", self.data[table], ((va >> shift) & 511) * 8)
            need(desc & 1, f"unmapped EL0 VA {va:#x}")
            if shift != 12 and desc & 2:
                need(not desc & (1 << 61), "table blocks EL0")
                table = desc & mask
                continue
            need((shift != 12 or desc & 2) and desc & 64 and desc & 1024, "unreadable EL0 leaf")
            low = (1 << shift) - 1
            return (desc & mask & ~low) | (va & low)

    def load(self, root, addr, size):
        chunks = []
        while size:
            pa = self.translate(root, addr)
            offset = pa & 4095
            count = min(size, 4096 - offset)
            chunks.append(self.data[pa-offset][offset:offset+count])
            addr += count
            size -= count
        return b"".join(chunks)


class Package:
    def __init__(self, path):
        manifest = json.loads((path / "manifest.json").read_bytes())
        self.kernel = Elf(path / "kernel.elf")
        self.kernel_hash = digest(self.kernel.image)
        need(self.kernel_hash == manifest["kernel_elf_sha256"], "package kernel identity")
        roots, = [v for k, v in self.kernel.symbols.items() if "native_el0_mmu" in k and "6SPACES" in k]
        base, size = roots
        need(base % 4096 == 0 and size % 16384 == 0, "address-space root alignment")
        self.roots = [base + i * size // 4 for i in range(4)]
        self.elfs = [Elf(path / name) for name in
                     ("user.elf", "native_peer.elf", "native_peer2.elf", "native_peer3.elf")]
        for i, elf in enumerate(self.elfs):
            need(digest(elf.image) == manifest["slots"][i]["elf_sha256"] and
                 elf.image in self.kernel.image, f"embedded image for role {i}")


def expected_evdev(packet):
    result = []
    for event in packet:
        data = event["data"]
        if event["type"] == "abs":
            result.append((3, {"x": 0, "y": 1}[data["axis"]], data["value"]))
        else:
            need(event["type"] == "btn" and data["button"] == "left" and
                 isinstance(data["down"], bool), "unexpected QMP event")
            result.append((1, 272, int(data["down"])))
    return result + [(0, 0, 0)]


def ring(data, base, n=16):
    need(len(data) == 8192, "two page-aligned captured queues")
    avail = n * 16
    used = (avail + 4 + 2*n + 3) & ~3
    return u16(data, avail+2), u16(data, used+2), used+4, avail+4


def decode_dma(path, pkg):
    path = path / "injection"
    commands = [json.loads(line)["events"] for line in (path/"qmp-input.jsonl").read_text().splitlines()]
    expected = [expected_evdev(row) for row in commands]
    shape = [[(t,c) for t,c,_ in row] for row in expected]
    need(shape == [[(3,0),(3,1),(0,0)],[(1,272),(0,0)],[(1,272),(0,0)]]*2 and
         [expected[i][0][2] for i in (1,2,4,5)] == [1,0,1,0], "two independent motion/down/up triples")
    base, extent = pkg.kernel.get("jnox_tablet_queues")
    prev = (path / "before-queues.bin").read_bytes()
    n = 16
    prev_a, prev_u, used, available = ring(prev, base, n)
    need(prev_a == n and prev_u == 0 and extent == len(prev), "fresh populated eventq")
    reports = []
    event_sequence = 0
    for stage, packet in enumerate(expected, 1):
        q = (path/f"{stage}-queues.bin").read_bytes()
        a, u, _, _ = ring(q,base,n)
        need((u-prev_u) % 65536 == len(packet) and (a-prev_a) % 65536 == len(packet),
             f"stage {stage} used and replenished lengths")
        journal = (path/f"{stage}-events.bin").read_bytes()
        need(len(journal) == 64*32, "kernel receipt extent")
        rows = []
        for index, want in enumerate(packet):
            slot = (prev_u + index) % n
            desc, size = struct.unpack_from("<II", q, used+8*slot)
            need(desc < n and size == 8, "used element length/id")
            outstanding = [u16(prev,available+2*((prev_u+j)%n)) for j in range(n)]
            need(len(set(outstanding))==n and desc in outstanding, "completion refers to available buffer")
            addr, capacity, flags, _ = struct.unpack_from("<QIHH", q, 16*desc)
            old_addr, old_capacity, old_flags, _ = struct.unpack_from("<QIHH", prev, 16*desc)
            need((addr,capacity,flags)==(old_addr,old_capacity,old_flags) and
                 flags==2 and capacity>=size and base+used+8*n <= addr <= base+4096-size,
                 "writable descriptor points into captured event storage")
            need(u16(q,available+2*((prev_a+index)%n)) == desc, "consumed buffer returned to available ring")
            event = q[addr-base:addr-base+8]
            actual = struct.unpack("<HHi", event)
            need(actual == want, f"stage {stage} event {index} QMP vs actual DMA {actual} != {want}")
            event_sequence += 1
            seq, word, receipt_id, receipt_size = struct.unpack_from("<4Q",journal,32*((event_sequence-1)%64))
            need((seq,word,receipt_id,receipt_size) == (event_sequence,int.from_bytes(event,"little"),desc,8),
                 "transferred event and kernel receipt disagree")
            rows.append({"desc":desc, "pa":hex(addr), "bytes":event.hex(), "event":actual})
        need(len(set(r["desc"] for r in rows))==len(rows),"duplicate completion within one stage")
        reports.append({"used":u,"available":a,"events":rows})
        prev, prev_u, prev_a = q, u, a
    return reports


def ledger(pages, pkg):
    elf = pkg.elfs[0]
    root = pkg.roots[0]
    counter, extent = elf.get("jnox_wayland_wire_head")
    need(extent >= 16, "journal header")
    count, lost = struct.unpack("<QQ", pages.load(root,counter,16))
    addr, extent = elf.get("jnox_wayland_wire")
    need(lost == 0 and count <= extent//120, "wire journal lost/overwritten")
    records = []
    for i in range(count):
        data = pages.load(root, addr + 120*i,120)
        seq, fd, direction, size, nfds = struct.unpack_from("<QiIII",data)
        need(seq==i+1 and fd>=0 and direction in (1,2,3,4) and size<=64 and nfds<=8,
             "invalid journal record")
        records.append((seq,fd,direction,data[56:56+size]))
    return records


def decode_stream(records):
    """Follow v1 object creation and decode pointer-relevant transactions in both directions."""
    open_fds, peers = {}, []
    serials = set()
    for seq, fd, direction, segment in records:
        if direction == 3:
            need(fd not in open_fds, "duplicate stream accept")
            peer = {"fd":fd,"objects":{1:"wl_display"},"partial":[bytearray(),bytearray()],
                    "events":[],"caps":[],"title":None,"requests":[],"closed":False,"surfaces":set(),"keyboard_keys":[]}
            peers.append(peer)
            open_fds[fd] = peer
            continue
        p = open_fds[fd]
        if direction == 4:
            p["closed"] = True
            del open_fds[fd]
            continue
        buf = p["partial"][direction-1]
        buf.extend(segment)
        while len(buf) >= 8:
            obj, header = struct.unpack_from("<II",buf)
            size, opcode = header>>16, header & 65535
            need(size>=8 and size % 4 == 0, "invalid Wayland header")
            if len(buf)<size:
                break
            body = bytes(buf[8:size])
            del buf[:size]
            iface = p["objects"].get(obj)
            if direction==1:
                child = {("wl_display",1):"wl_registry",("wl_seat",0):"wl_pointer",("wl_seat",1):"wl_keyboard",
                         ("wl_compositor",0):"wl_surface",("xdg_wm_base",2):"xdg_surface",
                         ("xdg_surface",1):"xdg_toplevel"}.get((iface,opcode))
                if iface=="wl_registry" and opcode==0:
                    length=u32(body,4)
                    child=body[8:8+length-1].decode()
                    child_id=u32(body,8+((length+3)&~3)+4)
                elif child:
                    child_id=u32(body,0)
                if child:
                    p["objects"][child_id]=child
                    if child=="wl_surface":
                        p["surfaces"].add(child_id)
                    if child=="wl_pointer":
                        p["requests"].append([seq,"get_pointer",child_id])
                if iface=="xdg_toplevel" and opcode==2:
                    length=u32(body,0)
                    p["title"]=body[4:4+length-1].decode()
                if iface=="wl_surface" and opcode==0:
                    p["requests"].append([seq,"destroy_surface",obj])
                continue
            if iface=="wl_display" and opcode==1:
                p["objects"].pop(u32(body,0),None)
            if iface=="wl_seat" and opcode==0:
                p["caps"].append(u32(body,0))
            if iface=="wl_keyboard" and opcode==3:
                p["keyboard_keys"].append(list(struct.unpack("<IIII",body)))
            if iface!="wl_pointer":
                continue
            layout={0:("enter","<IIii"),1:("leave","<II"),2:("motion","<Iii"),3:("button","<IIII")}
            need(opcode in layout, "unexpected v1 pointer event")
            name, fmt=layout[opcode]
            args=struct.unpack(fmt,body)
            if name in ("enter","leave","button"):
                need(args[0]!=0 and args[0] not in serials, "duplicate or zero pointer serial")
                serials.add(args[0])
            if name in ("enter","leave"):
                need(args[1] in p["surfaces"], "event refers to foreign or unknown surface")
            p["events"].append([seq,name,*args])
    for p in peers:
        need(not any(p.pop("partial")), "partial trailing wire packet")
        del p["objects"],p["surfaces"]
    need(len(peers)==2 and {p["title"] for p in peers}=={"Pulse","Tiles"},"two identified peers")
    return {p["title"]:p for p in peers}


def get_clients(pages, pkg):
    clients={}
    for idx,title in ((1,"Pulse"),(2,"Tiles")):
        elf, root=pkg.elfs[idx],pkg.roots[idx]
        ptr,size=elf.get("wayland_pointer_witness")
        witness=words(pages.load(root,ptr,size))
        basic,size=elf.get("wayland_client_witness")
        app=words(pages.load(root,basic,size))
        need(len(witness)==11 and len(app)==32 and app[0]==idx and not any(app[2:5]),
             "process-private role/receipt schema")
        clients[title]={"receipt":witness,"direct_denials":app[28],"buffer_va":app[21],
                        "receipt_pa":hex(pages.translate(root,ptr))}
    need(clients["Pulse"]["receipt_pa"]!=clients["Tiles"]["receipt_pa"],"aliased client receipts")
    return clients


def wire_and_receipts(peers,clients):
    for title,p in peers.items():
        r=clients[title]["receipt"]
        need(p["caps"] and r[0]==p["caps"][-1],"wire vs EL0 seat capability")
        cnt=Counter()
        xy=[0,0]
        ent=btn=0
        focus=pressed=False
        for _,name,*args in p["events"]:
            cnt[name]+=1
            if name=="enter":
                need(not focus,"enter without prior leave")
                focus=True
                ent=args[0]
                xy=args[-2:]
            elif name=="leave":
                need(focus,"leave without focus")
                focus=False
            elif name=="motion":
                need(focus,"unfocused motion")
                xy=args[-2:]
            elif name=="button":
                serial,_,code,state=args
                need(focus and code==272 and state==int(not pressed),"button direction/focus")
                cnt["down" if state else "up"]+=1
                btn=serial
                pressed=bool(state)
        derived=[cnt["enter"],cnt["leave"],cnt["motion"],cnt["down"],cnt["up"],*xy,ent,btn]
        need(derived==r[1:10],f"{title} wire vs client {derived} != {r[1:10]}")


def switch_order(peers,old,new,old_serial,new_serial):
    a,=[e for e in peers[old]["events"] if e[1:3]==["leave",old_serial]]
    b,=[e for e in peers[new]["events"] if e[1:3]==["enter",new_serial]]
    need(a[0]<b[0],f"{old} leave record {a[0]} follows {new} enter record {b[0]}")
    return [a[0],b[0]]


def focus_switches(peers):
    # Serials are derived by per-connection event position; they are not used as send timestamps.
    previous=[("Pulse","Tiles",0,0),("Tiles","Pulse",0,1),("Pulse","Tiles",1,1)]
    transitions=[]
    for old,new,leave_index,enter_index in previous:
        old_events=[e for e in peers[old]["events"] if e[1]=="leave"]
        new_events=[e for e in peers[new]["events"] if e[1]=="enter"]
        pair=switch_order(peers,old,new,old_events[leave_index][2],new_events[enter_index][2])
        transitions.append([old,new,*pair])
    return transitions


ORIGINS={"Pulse":(16,24),"Tiles":(112,80)}


def check_screen(path,pages,pkg,clients,titles=("Tiles","Pulse")):
    image=path.read_bytes()
    prefix=b"P6\n320 240\n255\n"
    need(image.startswith(prefix) and len(image)==len(prefix)+320*240*3, "QMP screen geometry")
    screen=image[len(prefix):]
    canvas=bytearray(bytes.fromhex("18232d")*(320*240))
    color={}
    for title in titles:
        idx=1 if title=="Pulse" else 2
        buf=pages.load(pkg.roots[idx],clients[title]["buffer_va"],128*96*4)
        rgb=bytearray(128*96*3)
        rgb[0::3],rgb[1::3],rgb[2::3]=buf[2::4],buf[1::4],buf[0::4]
        color[title]=digest(rgb)
        x,y=ORIGINS[title]
        for row in range(96):
            start=((y+row)*320+x)*3
            canvas[start:start+384]=rgb[row*384:(row+1)*384]
    need(canvas==screen,"QEMU RGB mismatches process-private buffer composition")
    return {"frame":digest(screen),"client_buffers":color}


def scene(path,pkg,name):
    pages=Pages(path/(name+".pages.z"))
    for i,elf in enumerate(pkg.elfs):
        if i==2 and name=="b-dead":
            continue
        need(pages.load(pkg.roots[i],elf.entry,32)==elf.entry_code,
             f"slot {i} saved executable entry differs from package")
    clients=get_clients(pages,pkg)
    peers=decode_stream(ledger(pages,pkg))
    wire_and_receipts(peers,clients)
    layers={"b-dead":("Pulse",),"a2":("Pulse",),"tiles-front":("Pulse","Tiles"),
            "b-front":("Pulse","Tiles"),"b1":("Pulse","Tiles")}.get(name,("Tiles","Pulse"))
    return {"clients":clients,"wire":peers,"screen":check_screen(path/(name+".ppm"),pages,pkg,clients,layers)}


def read_mmio(path):
    data=json.loads(path.read_bytes())
    regs={}
    bases=set()
    for key,row in data.items():
        if not key.startswith("0x"):
            continue
        match=re.fullmatch(r"\s*([0-9a-fA-F]+):\s+0x([0-9a-fA-F]+)\s*", row)
        need(match, f"unrecognized raw HMP xp row {row!r}")
        at, value=(int(i,16) for i in match.groups())
        delta=int(key,16)
        bases.add(at-delta)
        regs[delta]=value
    need(len(bases)==1, "inconsistent physical MMIO address")
    return bases.pop(),regs,data


def live_registers(path):
    base,r,raw=read_mmio(path/"initial.device.json")
    need((r[0],r[4],r[8],r[0x70],r[0x44])==(0x74726976,2,18,15,1),
         "modern virtio-input with DRIVER_OK and selected queue active")
    need("virtio-tablet-device" in raw["qtree"],"QEMU topology lacks tablet")
    transport=words((path/"injection"/"transport.bin").read_bytes())
    state=words((path/"injection"/"before-state.bin").read_bytes())
    need(base==state[0] and state[1:3]==[1,1] and transport[0:2]==[r[4],r[8]] and
         transport[5]&1 and not transport[4]&~transport[2] and not transport[5]&~transport[3] and
         transport[6]==48+(base-0xa000000)//0x200 and transport[7]==0 and
         min(transport[8:10])>=16 and transport[10]==r[0x70],"driver acquisition vs raw MMIO")
    return {"base":hex(base),"mmio":r,"transport_receipt":transport,
            "kernel_axis_ranges":state[3:7],"selected_config":r.get(0x100),
            "raw_selected_axis_values":[r.get(0x108),r.get(0x10c)]}


def lifecycle(path):
    b,rx,_=read_mmio(path/"initial.device.json")
    end,tx,_=read_mmio(path/"terminal.device.json")
    need(b==end and rx[0x70]==15 and rx[0x44]==1 and tx[0x70]==0 and
         tx[0x44]==0 and tx[0x60]==0,"MMIO status/selected ready reset")
    ring_bytes=(path/"jnox_tablet_queues.terminal.bin").read_bytes()
    need(len(ring_bytes)==8192 and not any(ring_bytes),"two DMA pages not cleared after retirement")
    state=words((path/"jnox_tablet_state.terminal.bin").read_bytes())
    need(state[1:3]==[0,2] and state[11]==1,"owner retirement and one completed reset")
    return {"phys_base":hex(b),"live_regs":rx,"terminal_regs":tx,
            "terminal_state":state,"two_cleared_dma_pages":digest(ring_bytes),
            "limit":"HMP records QueueReady for the selected queue; no individual read from the other queue."}


def retired_queue_status(path):
    base,_,_=read_mmio(path/"terminal.device.json")
    pairs=json.loads((path/"retired-queue-ready.json").read_bytes())
    need([idx for idx,_ in pairs]==[0,1],"queue-ready readback selectors")
    for _,row in pairs:
        addr,value=row.strip().split(":")
        need(int(addr,16)==base+0x44 and int(value,16)==0,"retired queue is ready")
    return pairs


def complete_history(path):
    base=path/"injection"
    commands=[json.loads(line)["events"] for line in (base/"qmp-input.jsonl").read_text().splitlines()]
    actions=[json.loads(line) for line in (path/"observer-commands.jsonl").read_text().splitlines()]
    need([p for _,kind,p in actions if kind=="PL011"]==["6e","6b","71"],"restack, disconnect and shutdown actions")
    commands += [obj["events"] for _,kind,obj in actions if kind=="QMP"]
    expected=[row for cmd in commands for row in expected_evdev(cmd)]
    data=(path/"jnox_tablet_events.terminal.bin").read_bytes()
    state=words((path/"jnox_tablet_state.terminal.bin").read_bytes())
    need(len(expected)==state[9]==24 and state[10]==len(commands)==10,"complete terminal input count")
    for i,row in enumerate(expected):
        seq,word,desc,n=struct.unpack_from("<QQQQ",data,i*32)
        need((seq,n)==(i+1,8) and desc<16 and struct.unpack("<HHi",word.to_bytes(8,"little"))==row,
             f"terminal observer QMP-to-device history event {i+1}")
    return {"reports":len(commands),"kernel_receipt_completions":len(expected),
            "separately_sampled_raw_dma_completions":14}


def exits(path):
    return parse_exits((path/"uart").read_bytes())


def parse_exits(data):
    lines=data.decode("ascii","replace").splitlines()
    rec=[re.fullmatch(r"NATIVE EL0 EXIT PID (\d+) (\d+)",line.strip()) for line in lines]
    seen=sorted((int(m[1]),int(m[2])) for m in rec if m)
    need(seen==[(0,0),(1,71),(2,72),(3,0)], f"EL0 process exits {seen}")
    return seen


def check_trajectory(first,last,reports,axis):
    for i,title in enumerate(("Pulse","Tiles")):
        ev=reports[i*3]["events"]
        xy=[]
        for j,span in enumerate((319,239)):
            lo,hi=axis[2*j:2*j+2]
            raw=ev[j]["event"][2]
            need(hi>lo and lo<=raw<=hi,"negotiated tablet axis")
            xy.append((raw-lo)*span//(hi-lo))
        origin=ORIGINS[title]
        local=[(val-offset)*256 for val,offset in zip(xy,origin)]
        wire=last["wire"][title]["events"]
        before=first["wire"][title]["events"]
        need(wire[:len(before)]==before,"wire prefix changed")
        segment=wire[len(before):]
        enter=[r for r in segment if r[1]=="enter"]
        buttons=[r for r in segment if r[1]=="button"]
        need(len(enter)==1 and enter[0][-2:]==local and len(buttons)==2 and
             [r[-1] for r in buttons]==[1,0] and enter[0][0]<buttons[0][0]<buttons[1][0],
             f"{title} DMA-to-local mapping and button order")
        need(first["screen"]["client_buffers"][title]!=last["screen"]["client_buffers"][title],
             f"{title} backing unchanged after press")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("package",type=Path)
    parser.add_argument("capture",type=Path)
    parser.add_argument("--absent",action="store_true")
    parser.add_argument("--report",type=Path)
    parser.add_argument("--hardware",type=Path, help="same-kernel hardware-register capture if separate")
    args=parser.parse_args()
    pkg=Package(args.package)
    path=args.capture
    result={"kernel":pkg.kernel_hash,"source":str(path),"scopes":{}}
    scores=result["scopes"]
    def score(key,fn):
        try:
            v=fn()
            scores[key]={"outcome":"PASS","details":v}
            return v
        except (ValueError,KeyError,IndexError,StopIteration,FileNotFoundError,struct.error) as exc:
            scores[key]={"outcome":"FAIL_OR_MISSING","reason":str(exc)}
    init=score("initial_client_wire_screen",lambda:scene(path,pkg,"initial"))
    def selection():
        mice=json.loads((path/"mice.json").read_text())
        cmd=json.loads((path/"command.json").read_text())
        need(("virtio-tablet-device" in cmd)==(not args.absent),"QEMU command tablet topology")
        need(any(m["current"] and m["absolute"] for m in mice)==(not args.absent),"QMP active absolute device")
        return mice
    score("qemu_topology",selection)
    score("four_guest_process_exits",lambda:exits(path))
    if init:
        def seat():
            for title,p in init["wire"].items():
                need(p["caps"]==[2 if args.absent else 3] and
                     bool(p["requests"])==(not args.absent) and not p["events"],f"{title} initial seat")
            return {k:v["caps"] for k,v in init["wire"].items()}
        score("seat_capabilities",seat)
        def denial():
            counts={t:c["direct_denials"] for t,c in init["clients"].items()}
            need(all(v==5 for v in counts.values()),"per-client denial count lacks both tablet operations")
            return {"private_counters":counts,"limit":"Aggregate counter; per-command results require linked-client evidence."}
        score("nonowner_counters",denial)
    if not args.absent:
        hw=args.hardware or path
        score("live_hardware",lambda:live_registers(hw))
        score("owner_exit_device_reset",lambda:lifecycle(hw))
        score("both_queue_ready_after_exit",lambda:retired_queue_status(hw))
        if (path/"observer-commands.jsonl").exists():
            score("all_host_commands_and_terminal_receipts",lambda:complete_history(path))
        reports=score("qmp_dma_and_syn",lambda:decode_dma(path,pkg))
        both=score("both_clicks_client_wire_screen",lambda:scene(path,pkg,"both-clicked"))
        overlap=score("overlap_client_wire_screen",lambda:scene(path,pkg,"overlap-motion"))
        if init and both and reports:
            state=words((path/"injection"/"before-state.bin").read_bytes())
            score("axis_and_application_delivery",lambda:check_trajectory(init,both,reports,state[3:7]))
        if both and overlap:
            def movement():
                a=overlap["wire"]["Pulse"]["events"][len(both["wire"]["Pulse"]["events"]):]
                b=overlap["wire"]["Tiles"]["events"][len(both["wire"]["Tiles"]["events"]):]
                need([r[1] for r in b]==["leave"] and [r[1] for r in a]==["enter","motion"]
                     and b[0][0]<a[0][0]<a[1][0] and a[0][-2:]==[104*256,66*256] and
                     a[1][-2:]==[109*256,71*256],"overlap topmost recipient and local motion")
                return [*b,*a]
            score("overlap_focus",movement)
        front=score("focus_restack_scene",lambda:scene(path,pkg,"tiles-front"))
        if front:
            score("both_directions_and_restack_actual_sends",lambda:focus_switches(front["wire"]))
        dead=score("focus_disconnect_scene",lambda:scene(path,pkg,"b-dead"))
        if front and dead:
            def disconnect():
                a,b="Pulse","Tiles"
                aa,bb=front["wire"][a],front["wire"][b]
                end_a,end_b=dead["wire"][a],dead["wire"][b]
                need(not bb["closed"] and end_b["closed"] and not end_a["closed"],"focused peer disconnected")
                need(bb["events"][-1][1]=="enter" and aa["events"][-1][1]=="leave",
                     "front peer had pointer before losing connection")
                delta=end_a["events"][len(aa["events"]):]
                need(delta and delta[0][1]=="enter" and delta[-1][1]=="motion" and
                     delta[-1][-2:]==[114*256,76*256],"remaining surface received refocus and motion")
                return {"surviving_peer_events":delta,"disconnected_peer_events":end_b["events"][len(bb["events"]):]}
            score("focused_disconnect_retarget",disconnect)
    raw=json.dumps(result,indent=2)
    if args.report:
        args.report.write_text(raw+"\n")
    print(json.dumps({k:(v["outcome"],v.get("reason")) for k,v in scores.items()},indent=2))
    return int(any(v["outcome"]!="PASS" for v in scores.values()))


if __name__=="__main__":
    raise SystemExit(main())
