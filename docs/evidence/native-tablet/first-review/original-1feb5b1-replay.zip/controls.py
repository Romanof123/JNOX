"""Run reversible corruptions only against copies of frozen capture data."""
from pathlib import Path
import argparse
import json
import shutil
import struct
import tempfile
from reader import (Package,Pages,decode_dma,scene,decode_stream,ledger,
                    get_clients,wire_and_receipts,check_screen,live_registers,lifecycle)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("package",type=Path)
    parser.add_argument("capture",type=Path)
    parser.add_argument("hardware",type=Path)
    parser.add_argument("--report",type=Path)
    args=parser.parse_args()
    p=Package(args.package)
    results={}
    def test(name,func):
        try:
            func()
        except (ValueError,KeyError,IndexError,struct.error) as e:
            results[name]=str(e)
        else:
            raise RuntimeError("control accepted: "+name)
    decode_dma(args.capture,p)
    scene(args.capture,p,"both-clicked")
    live_registers(args.hardware)
    lifecycle(args.hardware)
    with tempfile.TemporaryDirectory() as folder:
        root=Path(folder)
        shutil.copytree(args.capture/"injection",root/"injection")
        q=root/"injection"/"1-queues.bin"
        original=q.read_bytes()
        base,_=p.kernel.get("jnox_tablet_queues")
        desc,=struct.unpack_from("<I",original,296)
        addr,=struct.unpack_from("<Q",original,16*desc)
        for name,off in (("DMA X value",addr-base+4),("used byte count",300),
                         ("descriptor writable bit",16*desc+12),("used index",294),
                         ("replenished descriptor",260)):
            data=bytearray(original)
            data[off]^=1
            q.write_bytes(data)
            test(name,lambda:decode_dma(root,p))
        q.write_bytes(original)
        wire=root/"injection"/"qmp-input.jsonl"
        rows=[json.loads(line) for line in wire.read_text().splitlines()]
        rows[1]["events"][0]["data"]["down"]=False
        wire.write_text("\n".join(json.dumps(r) for r in rows)+"\n")
        test("QMP press replaced by release",lambda:decode_dma(root,p))
        src=args.capture
        pages=Pages(src/"both-clicked.pages.z")
        raw=ledger(pages,p)
        peers=decode_stream(raw)
        clients=get_clients(pages,p)
        assert clients["Pulse"]["receipt"][4]==1
        ptr,_=p.elfs[1].get("wayland_pointer_witness")
        pa=pages.translate(p.roots[1],ptr+4*8)
        key=pa&~4095
        data=bytearray(pages.data[key])
        data[pa-key]^=1
        pages.data[key]=bytes(data)
        test("Pulse private press byte",lambda:wire_and_receipts(peers,get_clients(pages,p)))
        # Replace an actual button serial with an earlier enter serial in the captured stream.
        pulse=peers["Pulse"]
        enter=next(s for s in pulse["events"] if s[1]=="enter")
        button=next(s for s in pulse["events"] if s[1]=="button")
        p_object=next(r[2] for r in pulse["requests"] if r[1]=="get_pointer")
        word=struct.pack("<IIIIII",p_object,24<<16|3,*button[2:])
        altered=False
        for i,(seq,fd,dr,payload) in enumerate(raw):
            if seq==button[0] and word in payload:
                raw[i]=(seq,fd,dr,payload.replace(word,word[:8]+struct.pack("<I",enter[2])+word[12:]))
                altered=True
                break
        if not altered:
            raise ValueError("button spans capture chunks; record a stream-level control")
        test("duplicate serial in real Wayland packet",lambda:decode_stream(raw))
        ppm=root/"both-clicked.ppm"
        data=bytearray((src/ppm.name).read_bytes())
        data[-2]^=1
        ppm.write_bytes(data)
        test("one QEMU RGB channel",lambda:check_screen(ppm,pages,p,clients))
        for name in ("initial.device.json","terminal.device.json","jnox_tablet_state.terminal.bin",
                     "jnox_tablet_queues.terminal.bin"):
            shutil.copy2(args.hardware/name,root/name)
        file=root/"terminal.device.json"
        initial=json.loads((root/"initial.device.json").read_bytes())
        terminal=json.loads(file.read_bytes())
        terminal["0x70"]=initial["0x70"]
        file.write_text(json.dumps(terminal))
        test("terminal DEVICE_STATUS still live",lambda:lifecycle(root))
    out=json.dumps(results,indent=2)
    print(out)
    if args.report:
        args.report.write_text(out+"\n")


if __name__=="__main__":
    main()
