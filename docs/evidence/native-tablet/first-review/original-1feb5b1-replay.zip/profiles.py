"""Independent ordinary keyboard/headless evidence and linked permission-call checks."""
import argparse
import json
import re
import subprocess
from pathlib import Path
from reader import Package,Pages,Elf,digest,need,ledger,decode_stream,check_screen,get_clients,parse_exits


def main_code(path):
    return subprocess.check_output(["aarch64-linux-gnu-objdump","-d","--disassemble=main",path],text=True)


def headless(build):
    pkg=build/"headless-pkg"
    elf=(pkg/"user.elf").read_bytes()
    need(elf in (pkg/"kernel.elf").read_bytes(),"headless test kernel embeds app")
    uart=(build/"headless.uart").read_text().splitlines()
    need("NATIVE EL0 ELF "+digest(elf) in uart and "NATIVE EL0 EXIT 47" in uart,"headless loaded ID and return")
    asm=main_code(pkg/"user.elf")
    syscalls=[int(v,16) for v in re.findall(r"mov\s+w8, #0x(\w+)\s+//[^\n]*\n[^\n]+svc\s+",asm)]
    need(syscalls==[197,197,72] and asm.count("cmn\tx0, #0x26")==3 and
         "mov\tw9, #0x2f" in asm and "csel\tw0, w9, w8, eq" in asm,"headless three -38 branches and exit 47")
    return {"sha256":digest(elf),"serial":uart,"disassembly":asm}


def denied(build):
    pkg=Package(build/"package")
    seen=[]
    for i in (1,2):
        asm=main_code(build/"package"/("native_peer.elf" if i==1 else "native_peer2.elf"))
        r=re.search(r"([0-9a-f]+):\s+[0-9a-f]+\s+mov\s+w8, #0xc5.*?svc\s+#0x4a01.*?cmn\s+x0, #0x1.*?b.eq"
                    r".*?mov\s+w0, #0x1.*?mov\s+w8, #0xc5.*?svc\s+#0x4a01.*?cmn\s+x0, #0x1.*?b.eq"
                    r".*?ldr\s+x8, \[x9, #248\].*?add\s+x8, x8, #0x2.*?str\s+x8, \[x9, #248\]",asm,re.S)
        need(r and "mov\tx0, xzr" in asm[:r.start()],"first/second tablet call and EPERM checks")
        emit=r.group(0)
        witness,_=pkg.elfs[i].get("wayland_client_witness")
        bases=re.findall(r"adrp\s+x9, ([0-9a-f]+)",asm[:r.start()])
        need(int(bases[-1],16)+248==witness+28*8, "linked W[28] address")
        seen.append({"role":i,"elf":digest(pkg.elfs[i].image),"witness_28":hex(witness+224),"disassembly":emit})
    return seen


def keyboard(build):
    capture=build/"keyboard-rerun"
    pkg=Package(capture/"package")
    stages={"initial":("Tiles","Pulse"),"a1":("Tiles","Pulse"),"b-front":("Pulse","Tiles"),
            "b1":("Pulse","Tiles"),"b-dead":("Pulse",),"a2":("Pulse",)}
    result=[]
    for n in (1,2):
        run=capture/("cold-"+str(n))
        trace=[json.loads(s) for s in (run/"events.jsonl").read_text().splitlines()]
        cmd,_,kernel=next(payload for _,kind,payload in trace if kind=="launch")
        need(kernel==pkg.kernel_hash and "virtio-tablet-device" not in cmd,"keyboard launch identity")
        keys=b"".join(bytes.fromhex(v) for _,tag,v in trace if tag=="pl011")
        need(keys==b"xnxkxq","keyboard PL011 inputs")
        frames={}
        for stage,layers in stages.items():
            pages=Pages(run/(stage+".pages.z"))
            peers=decode_stream(ledger(pages,pkg))
            clients={}
            for i,title in ((1,"Pulse"),(2,"Tiles")):
                if title not in layers:
                    continue
                addr,sz=pkg.elfs[i].get("wayland_client_witness")
                data=pages.load(pkg.roots[i],addr,sz)
                val=lambda j:int.from_bytes(data[j*8:j*8+8],"little")
                need(val(0)==i and val(2)==0,"keyboard private receipt")
                clients[title]={"buffer_va":val(21)}
            screen=check_screen(run/(stage+".ppm"),pages,pkg,clients,layers)
            for peer in peers.values():
                need(peer["caps"]==[2] and not peer["events"] and
                     not any(r[1]=="get_pointer" for r in peer["requests"]),"keyboard-only wire")
            frames[stage]=screen
        sequence={k:[(r[2],r[3]) for r in p["keyboard_keys"]] for k,p in peers.items()}
        need([code for code,state in sequence["Pulse"] if state]==[45,45] and
             [code for code,state in sequence["Tiles"] if state]==[45,37],"keyboard focus and delivered keycodes")
        result.append({"cold":n,"kernel":kernel,"keys":keys.decode(),"wire_keys":sequence,"frames":frames,
                       "exits":parse_exits((run/"uart.bin").read_bytes())})
    return result


if __name__=="__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("build",type=Path)
    cli.add_argument("result",type=Path)
    config=cli.parse_args()
    report={}
    for name,func in (("linked_nonowner_branches",denied),("headless",headless),("keyboard",keyboard)):
        try:
            report[name]={"outcome":"PASS","details":func(config.build)}
        except Exception as exc:
            report[name]={"outcome":"FAIL_OR_MISSING","reason":repr(exc)}
    config.result.write_text(json.dumps(report,indent=2)+"\n")
    print({k:(v["outcome"],v.get("reason")) for k,v in report.items()})
