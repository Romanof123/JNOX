import pathlib, shutil, subprocess as s,time,json,hashlib
D=pathlib.Path('/mnt/d/codex/.jnox-work/next-fixed/ordinary-mutex-first')
H=pathlib.Path.home()/'jnox-149-first-47ea890'
H.mkdir()
for i,app in enumerate(['ordinary-pi','ordinary-pi','ordinary-ceiling','ordinary-ceiling']):
    tag=f'{i+1:02}-{app}-'+('traced' if i%2 else 'plain')
    p=H/tag;p.mkdir()
    elf=p/'kernel.elf';shutil.copy2(D/(app+'.elf'),elf)
    for name,cmd in [('disasm',['aarch64-linux-gnu-objdump','-dC',elf]),('symbols',['aarch64-linux-gnu-nm','-nC',elf])]:
        with (p/name).open('w') as f:s.run(cmd,stdout=f,check=True)
    argv=['qemu-system-aarch64','-machine','virt,gic-version=2','-cpu','cortex-a72','-smp','1','-accel','tcg','-m','128M','-nodefaults','-display','none','-monitor','none','-serial','stdio','-kernel',str(elf)]
    if i%2:argv+=['-d','int','-D',str(p/'external.log')]
    m=dict(argv=argv,revision='47ea89049b3efd2dd74642562a9973e15ad26a15',sha256=hashlib.sha256(elf.read_bytes()).hexdigest(),start=time.time(),allowance=15)
    (p/'attempt.json').write_text(json.dumps(m,indent=2))
    with (p/'uart').open('wb') as f,(p/'stderr').open('wb') as err:
        q=s.Popen(argv,stdout=f,stderr=err,stdin=s.DEVNULL)
        begin=time.monotonic()
        while q.poll() is None and time.monotonic()-begin<15:
            if b'MUTEX END' in (p/'uart').read_bytes():break
            time.sleep(.01)
        m['cause']='guest-process-exit' if q.poll() is not None else ('host-stop-after-footer' if b'MUTEX END' in (p/'uart').read_bytes() else 'host-timeout')
        if q.poll() is None:q.terminate()
        m.update(status=q.wait(),elapsed=time.monotonic()-begin)
    (p/'result.json').write_text(json.dumps(m,indent=2));shutil.copytree(p,D/tag)
    print(tag,m['cause'],(p/'uart').read_text().splitlines()[:5],flush=True)
